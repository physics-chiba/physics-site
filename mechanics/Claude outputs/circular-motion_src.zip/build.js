#!/usr/bin/env node
/* 円運動（circular-motion.html）の単一 HTML ビルド（2026-11-11 作り直し）
 * src/ の部品を決まった順に連結する。KaTeX は vendor/（フォントを埋め込み済みの CSS と JS）。
 * 共通フッター（src/99_footer.html）は </body> の直前にそのまま入れる（一字も変えない）。
 * node build.js        → dist/circular-motion.html（公開用：コメントと余白を取りのぞいて小さくする）
 * node build.js --raw  → 取りのぞかない（読みやすい版。くらべるとき用）
 */
'use strict';
const fs = require('fs'), path = require('path');
const ROOT = __dirname, SRC = path.join(ROOT, 'src'), VEN = path.join(ROOT, 'vendor');
const RAW = process.argv.includes('--raw');
const OUT = path.join(ROOT, 'dist', RAW ? 'circular-motion.raw.html' : 'circular-motion.html');
const read = p => fs.readFileSync(p, 'utf8');
const CSS = ['10_style.css', '15_page.css'];
const JS = ['30_physics.js', '40_draw.js', '45_sim.js', '50_mode1.js', '52_aexplain.js', '55_scene.js', '60_mode2.js', '62_fleming.js',
  '70_mode3.js', '72_m3snaps.js', '74_mode4.js', '75_graph.js', '80_page.js', '84_sitenav.js', '85_design.js', '90_boot.js'];

async function build() {
  let css = CSS.map(f => '/* ===== ' + f + ' ===== */\n' + read(path.join(SRC, f))).join('\n');
  let js = JS.map(f => '/* ===== ' + f + ' ===== */\n' + read(path.join(SRC, f))).join('\n');
  if (!RAW) {
    const CleanCSS = require('clean-css'), terser = require('terser');
    css = new CleanCSS({ level: 1 }).minify(css).styles;
    /* コメントと余白を取り、関数の中だけの変数名を短くする（toplevel は変えない：ページの中から名前で呼んでいる関数があるため） */
    const r = await terser.minify(js, { compress: { passes: 1 }, mangle: { toplevel: false }, format: { comments: false, ascii_only: false } });
    js = r.code;
  }
  const html = '<!DOCTYPE html>\n<html lang="ja">\n<head>\n' + read(path.join(SRC, '00_head.html')) +
    '<style>' + read(path.join(VEN, 'katex.css')) + '</style>\n<style>\n' + css + '\n</style>\n</head>\n<body id="top">\n' +
    read(path.join(SRC, '20_body.html')) +
    '<script>' + read(path.join(VEN, 'katex.js')) + '</script>\n<script>\n' + js + '\n</script>\n' +
    read(path.join(SRC, '99_footer.html')) + '\n</body>\n</html>\n';
  fs.mkdirSync(path.dirname(OUT), { recursive: true });
  fs.writeFileSync(OUT, html, 'utf8');
  console.log('出力: ' + OUT + ' (' + (Buffer.byteLength(html) / 1024).toFixed(0) + ' KB)');
}
build();
