/* =========================================================================
   50_mode1.js … モード1「円運動の基本的な物理量」
   なめらかな水平の台の中心の穴 O に糸を通し、台の下で手が糸を引いて、小球を水平に回す（等速円運動）。
   「✂ 糸を切る！」：上から見下ろす視点に変わり、はさみが出てきて台の上の糸を切る。
                     切った瞬間から、小球はその瞬間の速度 v⃗ のまま等速直線運動をする。
   動かせるのは半径 r・角速度 ω・質量 m の 3 つだけ。v・a・F・T・n はそれらから決まるメーター（2026-10-04 千葉さん。鍵のしくみはやめた）。
   角速度は 4 択（π/4・π/2・3π/4・π rad/s）。
   ========================================================================= */
'use strict';
var DEFS = {};
var M1KEYS = ['r', 'v', 'a', 'F', 'w', 'T', 'n'];
var M1NAME = { r: '半径', v: '速さ', a: '加速度', F: '向心力', w: '角速度', T: '周期', n: '回転数', m: '質量' };
var M1SYM = { r: 'r', v: 'v', a: 'a', F: 'F', w: '\\omega', T: 'T', n: 'n', m: 'm' };
var M1GRP = { w: 'grpW', T: 'grpW', n: 'grpW', r: 'grpR' };   /* 連動する組の色（スライダーと表で同じ色） */
/* 矢印の長さ［m］＝ 量 × これ（図の縮尺に比例）。a は ω = π（180°/s）でも中心を越えない長さ。
   F は「F = ma」なので、質量が M1.mRef（0.20 kg）のとき a と同じ長さ。質量が小さいほど F の矢印は短い */
var M1SC = { v: 0.35, a: 0.086 };
M1SC.F = M1SC.a / M1.mRef;
/* 質量を決める：小球の絵の大きさ（半径）は質量の 3 乗根に比例 */
function m1SetMass(m) { M1.m = m; M1.rb = 0.045 * Math.cbrt(m / 0.10); }
var M1VIEW0 = { az: -24, el: 30 };
var M1WTEX = ['\\dfrac{\\pi}{4}', '\\dfrac{\\pi}{2}', '\\dfrac{3\\pi}{4}', '\\pi'], M1WDEG = [45, 90, 135, 180];
function m1WIdx(w) { var b = 0; M1.W.forEach(function (q, i) { if (Math.abs(q - w) < Math.abs(M1.W[b] - w)) b = i; }); return b; }

/* 物理の (x, y)（上から見て左回りが正）→ 世界の座標（z が上・y は手前向き） */
function m1W(x, y, z) { return [x, -y, z || 0]; }

DEFS.m1s1 = {
  id: 'm1s1', mode: 'mode1', num: 1,
  title: '等速円運動の基本的な物理量',
  desc: '台の穴に通した糸で、小球を水平に回す。<span class="todo">$r$・$\\omega$・$m$ を変えて、ほかの量がどう変わるか見よう。</span>',
  /* 動かせるのは半径 r・角速度 ω・質量 m の 3 つだけ（2026-10-04 千葉さん）。ほかの v・a・F・T・n は、それらから決まる「メーター」 */
  varCols: [['r', 'w', 'm'], ['v', 'a', 'F', 'T', 'n']],
  varColNote: { 1: '以下の 5 つは、左の 3 つの値で決まる' },
  showFBtn: true,                            /* 「力を表示」は「軌跡を表示」のとなり（モードの帯には出さない） */
  vars: [
    { k: 'v', label: '速さ $v$', aria: '速さ', min: 0, max: 2.60, step: 0.02, def: 0.63, dec: 2, unit: 'm/s', meter: true },
    { k: 'a', label: '加速度 $a$', aria: '加速度', min: 0, max: 8.00, step: 0.02, def: 0.99, dec: 2, unit: 'm/s²', meter: true },
    { k: 'F', label: '向心力 $F$', aria: '向心力', min: 0, max: 1.600, step: 0.002, def: 0.099, dec: 3, unit: 'N', meter: true },
    { k: 'm', label: '小球の質量 $m$', aria: '小球の質量', min: 0.05, max: 0.20, step: 0.05, def: 0.20, dec: 2, unit: 'kg', cls: 'mrow' },   /* 0.05 刻み（2026-10-05 千葉さん） */
    { k: 'r', label: '半径 $r$', aria: '半径', min: 0.20, max: 0.80, step: 0.2, def: 0.60, dec: 2, unit: 'm', cls: 'grpR' },   /* 0.2 刻み */
    { k: 'T', label: '周期 $T$', aria: '周期', stops: [2, 8 / 3, 4, 8], stopLabels: ['2', '2.67', '4', '8 s'], def: 4, dec: 2, unit: 's', cls: 'grpW', meter: true },
    { k: 'n', label: '回転数 $n$', aria: '回転数', stops: [0.125, 0.25, 0.375, 0.5], stopLabels: ['0.125', '0.25', '0.375', '0.5 Hz'], def: 0.25, dec: 3, unit: 'Hz', cls: 'grpW', meter: true },
    { k: 'w', label: '角速度 $\\omega$', aria: '角速度', cls: 'grpW', stops: M1.W, stopLabels: ['0.79', '1.57', '2.36', '3.14 rad/s'], def: Math.PI / 2,
      fmt: function (x) {
        var i = m1WIdx(x);
        if (Math.abs(x - M1.W[i]) > 0.005) return fmt(x, 2) + ' rad/s <span class="wtex">（$\\approx ' + Math.round(x * 180 / Math.PI) + '^\\circ\\text{/s}$）</span>';   /* 「Ｆ一定・r小さくする」の途中の値 */
        return fmt(x, 2) + ' rad/s <span class="wtex">（$' + M1WTEX[i] + '\\ \\text{rad/s} = ' + M1WDEG[i] + '^\\circ\\text{/s}$）</span>';
      } }
  ],
  views: [{ label: '斜め上から', az: M1VIEW0.az, el: M1VIEW0.el }, { label: '上から', az: 0, el: 90 }, { label: '真横から', az: 0, el: 0 }],
  view0: 0,
  trailBtn: true, trailSec: 2,                 /* 「軌跡を表示」（既定 ON）：量を変えたときの半径の変化が残る */
  init: function (s) {
    s.p = { r: 0.60, w: Math.PI / 2, m: 0.20 }; /* 既定：r = 0.60 m、ω = π/2 rad/s（T = 4 s）、m = 0.20 kg（加速度の矢印が最初から見えるように。2026-10-07 千葉さん） */
    m1SetMass(s.p.m);
    s.ph = 0;                                    /* 角のずれ：θ = ωt + ph（量を変えても時刻は戻さない） */
    s.tCut = null; s.cutAnim = null;
    if (!s.cam) s.cam = { az: M1VIEW0.az, el: M1VIEW0.el };
    if (s.topPressed === undefined) s.topPressed = false;
  },
  disp: function (s, k) { return k === 'm' ? s.p.m : M1.derive(s.p.r, s.p.w)[k]; },
  onVar: function (s, k, x) {                  /* 動かせるのは r・ω・m だけ。m を変えたら F が変わるので「力を表示」を ON */
    s._wOld = s.p.w;
    if (k === 'r') s.p.r = x;
    else if (k === 'w') s.p.w = x;
    else if (k === 'm') { s.p.m = x; m1SetMass(x); if (!s.ms.showF) { s.ms.showF = true; syncModeBar('mode1'); } }
    else return false;
    s.sel = (k === 'm') ? 'F' : k;
    return true;
  },
  /* 量を変えたとき：糸を切る前なら、時刻をそのままにしてなめらかに変える。
     ω が変わったときは、いまの角 θ = ωt + ph が飛ばないように ph を変える（時刻は戻さない）。糸を切ったあとは最初から */
  onChanged: function (s) {
    if (s.tCut !== null || s.cutAnim) { s.tCut = null; s.cutAnim = null; s.ph = 0; s.syncCut(); return; }
    if (s._wOld && Math.abs(s._wOld - s.p.w) > 1e-12) s.ph = s._wOld * s.t + s.ph - s.p.w * s.t;
    return 'keepT';
  },
  afterBuild: function (s) {                   /* 変数エリアの左下に「Ｆ一定・r小さくする」 */
    var c = s.varbox && s.varbox.querySelector('.vcol0'); if (!c) return;
    var b = el('button', 'b demo', 'Ｆ一定・$r$ 小さくする'); b.type = 'button';
    b.innerHTML = mathify(b.innerHTML);
    b.title = '向心力 F を固定したまま、半径 r を最大から最小まで小さくしていく';
    b.addEventListener('click', function () { m1StartDemo(s); });
    c.appendChild(b); s.bDemo = b;
  },
  onReset: function (s) { s.tCut = null; s.cutAnim = null; s.ph = 0; s.syncCut(); },
  onRestart: function (s) { s.tCut = null; s.cutAnim = null; s.ph = 0; s.syncCut(); },
  onDefaults: function (s) { s.tCut = null; s.cutAnim = null; s.ph = 0; s.sel = null; s.cam = { az: M1VIEW0.az, el: M1VIEW0.el }; s.syncCut(); },
  /* 時間バーの右：何回転したか（糸を切ったあとは、切るまでの回転） */
  tInfoNum: function (s) {                     /* 何回転したか（整数）。糸を切ったあとは切るまでの回転 */
    var tt = (s.tCut !== null && s.t > s.tCut) ? s.tCut : m1TDisp(s);
    return { n: Math.floor((s.p.w * tt + s.ph) / TAU + 1e-9), pre: (s.tCut !== null && s.t > s.tCut) ? '切るまでに' : '', unit: '回転' };
  },
  tEnd: function (s) { return s.tCut === null ? M1.tMax : s.tCut + M1.exitAfter(s.p.r, s.p.w, s.tCut, s.ph); },
  buttons: [{ k: 'cut', label: '✂ 糸を切る！', cls: 'cut', inCanvas: true, onClick: function (s) { m1StartCut(s); } }],   /* 方眼紙の左上 */
  onView: function (s, i, user) {
    var vw = DEFS.m1s1.views[i]; s.cam = { az: vw.az, el: vw.el };
    if (user && i === 1) s.topPressed = true;
    syncTopGlow(s);
  },
  drag3d: function (s, dx, dy) {
    if (s.cutAnim) return;
    var r = s.cv.getBoundingClientRect(), k = s.W / Math.max(1, r.width);
    s.cam.az = ((s.cam.az - dx * k * 0.32) + 540) % 360 - 180;
    s.cam.el = clamp(s.cam.el - dy * k * 0.26, 0, 90);
    m1SyncViewBtns(s);
  },
  height: function (s, w) { return Math.round(clamp(w * 0.86, 340, 580)); },
  onPick: function (s, k) { s.sel = k; s.renderRight(); s.draw(); },
  msg: function (s) {
    if (s.demo) return '<b>向心力 $F$ を一定</b>にしたまま、半径 $r$ を小さくしていく。$mr\\omega^2 = F$ より $\\omega = \\sqrt{\\dfrac{F}{mr}}$ なので、$r$ が小さくなるほど角速度 $\\omega$ は大きくなる（速く回る）。この間は「❚❚ 一時停止」の他は操作できません。';
    if (s.cutAnim && !s.cutAnim.snipped) return 'はさみで糸を切ります…';
    if (s.tCut !== null && s.t > s.tCut) {
      if (s.ended) return '台のはしまで来たので止めました。<b>↺ リセット</b>で、糸につながった状態に戻ります。';
      return '糸を切ったので向心力がなくなった。小球は、切った瞬間の速度 $\\vec{v}$ のまま（接線方向に・同じ速さで）まっすぐ進む＝<b>等速直線運動</b>。';
    }
    if (s.t === 0 && !s.playing) return '▶ スタートを押して、小球が回っているときに「<b>✂ 糸を切る！</b>」を押してみよう。';
    return '<b>等速円運動</b>：速さ $v$ は一定。でも速度 $\\vec{v}$ の向きは円の接線方向で、たえず変わっている。';
  },
  draw: function (s, ctx, W, H) { drawM1(s, ctx, W, H); },
  right: function (s, R) { rightM1(s, R); }
};

function m1SyncViewBtns(s) {
  (s.vbtns || []).forEach(function (b, j) { var vw = DEFS.m1s1.views[j]; b.classList.toggle('on', Math.abs(s.cam.az - vw.az) < 0.5 && Math.abs(s.cam.el - vw.el) < 0.5); });
}

/* 「上から」は押されるまで光らせる（押してほしいボタン） */
function syncTopGlow(s) {
  if (!s.vbtns) return;
  var b = s.vbtns[1], on = !s.topPressed;
  b.classList.toggle('big', on); b.classList.toggle('glow', on);
  b.textContent = on ? '👆 上から見る！' : '上から';
}

/* ---------- 糸を切る：①上から見下ろす視点へ ②はさみが出てきて糸を切る ③そこから等速直線運動 ----------
   切っているあいだ（①②）は時刻を止める。切った瞬間 tCut から運動を再開する */
var M1CUT = { cam: 0.7, inT: 0.45, close: 0.45, fade: 0.7 };
function m1StartCut(s) {
  if (s.tCut !== null || s.cutAnim) return;
  if (s.strobe) s.t = m1TDisp(s);                    /* ストロボ中は、見えている位置で切る */
  var wasPlay = s.playing;
  s.playing = false; s.syncPlayLabel();
  s.cutAnim = { t0: performance.now(), cam0: { az: s.cam.az, el: s.cam.el }, snipped: false, wasPlay: wasPlay, k: 0 };
  s.topPressed = true; syncTopGlow(s);
  if (s.extra && s.extra.cut) { s.extra.cut.disabled = true; }
  var step = function (now) {
    var A = s.cutAnim; if (!A) return;
    var e = (now - A.t0) / 1000;
    A.e = e;
    var u = clamp(e / M1CUT.cam, 0, 1), ee = u * u * (3 - 2 * u);
    var daz = ((0 - A.cam0.az + 540) % 360) - 180;          /* 近いほうへ回す */
    s.cam.az = A.cam0.az + daz * ee; s.cam.el = A.cam0.el + (90 - A.cam0.el) * ee;
    m1SyncViewBtns(s);
    var tSnip = M1CUT.cam + M1CUT.inT + M1CUT.close;
    if (!A.snipped && e >= tSnip) {
      A.snipped = true; s.tCut = s.t; s.syncCut();
      SIMS.forEach(function (o) { if (o !== s && o.playing) { o.playing = false; o.syncPlayLabel(); } });
      s.playing = true; s.syncPlayLabel(); startLoop();     /* 切った瞬間から動きはじめる */
    }
    if (e >= tSnip + M1CUT.fade) { s.cutAnim = null; s.draw(); return; }
    if (!s.playing) s.draw();
    requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}
/* ストロボ中は 1 秒ごとにしか位置を見せない（パッパッパッ）。円運動のあいだは t = 0,1,2…、糸を切ったあとは切った瞬間から 1 秒ごと */
function m1TDisp(s) {
  if (!s.strobe) return s.t;
  if (s.tCut !== null && s.t > s.tCut) return s.tCut + Math.floor(s.t - s.tCut + 1e-9) + 1e-9;
  return Math.floor(s.t + 1e-9);
}
/* はさみ（添付の絵：黒い持ち手＋銀の刃）。(px,py)＝支点、(ax,ay)＝刃の向き（単位ベクトル）、open＝開き角［rad］ */
function scissors(ctx, px, py, ax, ay, open, k, alpha) {
  ctx.save(); ctx.globalAlpha = alpha; ctx.translate(px, py); ctx.rotate(Math.atan2(ay, ax)); ctx.scale(k, k);
  [-1, 1].forEach(function (sg) {
    ctx.save(); ctx.rotate(sg * open / 2);
    /* 刃（支点から先へ細くなる） */
    ctx.beginPath(); ctx.moveTo(-6, -4 * sg); ctx.quadraticCurveTo(30, -7 * sg, 66, -1 * sg); ctx.lineTo(66, 0.5 * sg); ctx.quadraticCurveTo(30, 4 * sg, -6, 3 * sg); ctx.closePath();
    var g = ctx.createLinearGradient(0, -6, 0, 6); g.addColorStop(0, '#e9ecef'); g.addColorStop(1, '#a7adb5');
    ctx.fillStyle = g; ctx.fill(); ctx.strokeStyle = '#2b2f35'; ctx.lineWidth = 1.4; ctx.stroke();
    /* 持ち手（黒い輪） */
    ctx.save(); ctx.rotate(-sg * 0.32);
    ctx.beginPath(); ctx.moveTo(-4, -3 * sg); ctx.lineTo(-22, -6 * sg); ctx.lineTo(-22, 2 * sg); ctx.lineTo(-4, 4 * sg); ctx.closePath();
    ctx.fillStyle = '#1d2024'; ctx.fill();
    ctx.beginPath(); ctx.ellipse(-36, 0, 15, 11, 0, 0, TAU); ctx.fillStyle = '#1d2024'; ctx.fill();
    ctx.beginPath(); ctx.ellipse(-36, 0, 9, 6, 0, 0, TAU); ctx.fillStyle = '#ffffff'; ctx.fill();
    ctx.restore();
    ctx.restore();
  });
  ctx.beginPath(); ctx.arc(0, 0, 4.2, 0, TAU); ctx.fillStyle = '#cfd4da'; ctx.fill(); ctx.strokeStyle = '#2b2f35'; ctx.lineWidth = 1.2; ctx.stroke();
  ctx.beginPath(); ctx.moveTo(-2.5, 1.5); ctx.lineTo(2.5, -1.5); ctx.stroke();
  ctx.restore();
}
/* 台の下で糸を持つ手（図 1 のように、こぶしで糸をにぎって下へ引く）。(x,y)＝こぶしの上（糸が入るところ）、s＝大きさ */
function handBelow(ctx, x, y, s) {
  ctx.save(); ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  ctx.fillStyle = '#f6e4d2'; ctx.strokeStyle = '#6d5a49'; ctx.lineWidth = 1.3;
  /* うで（下へ） */
  ctx.beginPath(); ctx.moveTo(x - s * 0.34, y + s * 0.9); ctx.lineTo(x - s * 0.30, y + s * 2.0); ctx.lineTo(x + s * 0.34, y + s * 2.0); ctx.lineTo(x + s * 0.36, y + s * 0.9); ctx.closePath(); ctx.fill(); ctx.stroke();
  /* こぶし */
  rrect(ctx, x - s * 0.48, y + s * 0.02, s * 0.92, s * 0.98, s * 0.28); ctx.fill(); ctx.stroke();
  /* 指（にぎった 4 本） */
  for (var i = 1; i <= 3; i++) { var yy = y + s * (0.02 + 0.245 * i); ctx.beginPath(); ctx.moveTo(x - s * 0.06, yy); ctx.lineTo(x + s * 0.42, yy); ctx.stroke(); }
  /* 親指 */
  ctx.beginPath(); ctx.ellipse(x - s * 0.30, y + s * 0.42, s * 0.16, s * 0.34, -0.25, 0, TAU); ctx.fill(); ctx.stroke();
  ctx.restore();
}

/* ---------- 図 ---------- */
function drawM1(s, ctx, W, H) {
  var tD = m1TDisp(s);                                        /* 見せる時刻（ストロボ中は 1 秒ごと） */
  var p = s.p, D = M1.derive(p.r, p.w), st = M1.state(p.r, p.w, tD, s.tCut, s.ph);
  var showF = s.ms.showF, cam = s.cam, top = cam.el > 75;
  var zb = M1.rb;                                             /* 小球の中心の高さ */
  /* 縮尺を固定する：台の四すみ（と少し上）を入れて外接矩形を求める */
  var pj0 = mkProj(cam.az, cam.el, 1, 0, 0), bx0 = 1e9, bx1 = -1e9, by0 = 1e9, by1 = -1e9;
  var take = function (q3) { var q = pj0.p(q3); bx0 = Math.min(bx0, q.x); bx1 = Math.max(bx1, q.x); by0 = Math.min(by0, q.y); by1 = Math.max(by1, q.y); };
  [-1, 1].forEach(function (sx) { [-1, 1].forEach(function (sy) { [-0.06, 0.40].forEach(function (z) { take([sx * M1.Lx, sy * M1.Ly, z]); }); }); });
  take([0, 0, -M1.handDepth(M1.R.r[0]) - 0.32]);            /* 台の下の手（うで）まで入れる（いちばん下がったとき） */
  var mgT = 48, mgB = 36, mgX = 10;
  var S = Math.min((W - 2 * mgX) / (bx1 - bx0), (H - mgT - mgB) / (by1 - by0));
  var cx = W / 2 - S * (bx0 + bx1) / 2, cy = mgT + (H - mgT - mgB) / 2 - S * (by0 + by1) / 2;
  var pj = mkProj(cam.az, cam.el, S, cx, cy), P = function (q) { return pj.p(q); };
  var dOf = function (n) { var a = pj0.p(n), o = pj0.p([0, 0, 0]); return a.d - o.d; };
  s._pj = pj;

  /* 台の下：穴 O から下へのびる糸と、それを引く手（台より先に描く → 台にかくれる部分は自然にかくれる）。
     上から見た図では手は描かない */
  var Lx = M1.Lx, Ly = M1.Ly, th = 0.06, showHand = cam.el < 80;
  var hb = P([0, 0, -th]), hh = P([0, 0, -M1.handDepth(p.r)]);   /* 糸の長さは一定：r を大きくすると手が上がる */
  if (showHand) {
    ctx.save(); ctx.strokeStyle = '#7a5a32'; ctx.lineWidth = 1.7; ctx.beginPath(); ctx.moveTo(hb.x, hb.y); ctx.lineTo(hh.x, hh.y); ctx.stroke(); ctx.restore();
  }
  /* 台：側面（見える面だけ）→ 上面（方眼）。四すみ */
  var tablePolys = [];
  var sides = [
    { n: [0, 1, 0], q: [[-Lx, Ly], [Lx, Ly]] }, { n: [0, -1, 0], q: [[Lx, -Ly], [-Lx, -Ly]] },
    { n: [1, 0, 0], q: [[Lx, Ly], [Lx, -Ly]] }, { n: [-1, 0, 0], q: [[-Lx, -Ly], [-Lx, Ly]] }];
  sides.forEach(function (f) {
    if (dOf(f.n) <= 1e-6) return;
    var a = P([f.q[0][0], f.q[0][1], 0]), b = P([f.q[1][0], f.q[1][1], 0]), c = P([f.q[1][0], f.q[1][1], -th]), d = P([f.q[0][0], f.q[0][1], -th]);
    tablePolys.push([a, b, c, d]);
    ctx.save(); ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.lineTo(c.x, c.y); ctx.lineTo(d.x, d.y); ctx.closePath();
    ctx.fillStyle = f.n[0] ? '#d9d2c4' : '#e4ddd0'; ctx.fill(); ctx.strokeStyle = '#8d877c'; ctx.lineWidth = 1; ctx.stroke(); ctx.restore();
  });
  var c4 = [[-Lx, -Ly], [Lx, -Ly], [Lx, Ly], [-Lx, Ly]].map(function (q) { return P([q[0], q[1], 0]); });
  ctx.save(); ctx.beginPath(); c4.forEach(function (q, i) { i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y); }); ctx.closePath();
  ctx.fillStyle = '#fbfaf6'; ctx.fill(); ctx.clip();
  [false, true].forEach(function (big) {                       /* 方眼（0.1 m ごと・0.5 m ごとに少し濃く）。色ごとにまとめて描く */
    ctx.strokeStyle = big ? '#e6dfd2' : '#f1ece3'; ctx.lineWidth = 1; ctx.beginPath();
    for (var gi = -20; gi <= 20; gi++) {
      if ((gi % 5 === 0) !== big) continue;
      var g = gi * 0.1, a1 = P([g, -Ly, 0]), a2 = P([g, Ly, 0]), b1 = P([-Lx, g, 0]), b2 = P([Lx, g, 0]);
      ctx.moveTo(a1.x, a1.y); ctx.lineTo(a2.x, a2.y); ctx.moveTo(b1.x, b1.y); ctx.lineTo(b2.x, b2.y);
    }
    ctx.stroke();
  });
  ctx.restore();
  ctx.save(); ctx.beginPath(); c4.forEach(function (q, i) { i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y); }); ctx.closePath();
  ctx.strokeStyle = '#8d877c'; ctx.lineWidth = 1.3; ctx.stroke(); ctx.restore();
  tablePolys.push(c4);
  /* 台にかくれた糸は破線（図 1 と同じ） */
  if (showHand) {
    ctx.save(); ctx.beginPath();
    tablePolys.forEach(function (pl) { pl.forEach(function (q, i) { i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y); }); ctx.closePath(); });
    ctx.clip(); ctx.setLineDash([4, 4]); ctx.strokeStyle = '#7a5a32'; ctx.lineWidth = 1.3;
    var h0 = P([0, 0, 0]); ctx.beginPath(); ctx.moveTo(h0.x, h0.y); ctx.lineTo(hh.x, hh.y); ctx.stroke(); ctx.restore();
    handBelow(ctx, hh.x, hh.y - 2, clamp(0.13 * S, 16, 30));   /* 手は台に重なっても見えるように、台のあとに描く */
  }
  if (!top) { var tl = P([Lx * 0.55, Ly, 0]); label(ctx, 'なめらかな水平の台', tl.x, tl.y - 10, { size: 11, color: COL.sub, halo: false }); }

  /* 円軌道（破線） */
  var C = function (ang, rr, z) { return P(m1W(rr * Math.cos(ang), rr * Math.sin(ang), z)); };
  ctx.save(); ctx.setLineDash([5, 5]); ctx.strokeStyle = '#8a929c'; ctx.lineWidth = 1.2; ctx.beginPath();
  for (var i = 0; i <= 96; i++) { var q = C(TAU * i / 96, p.r, zb); i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y); }
  ctx.stroke(); ctx.restore();

  var O = P([0, 0, zb]);
  /* 上から見た図だけ：基準の破線と θ = ωt */
  var circ = (st.phase === 'circle');
  {                                                           /* 円運動を始めた場所（θ = 0）を示す基準の破線：どちらの視点でも */
    var ref = C(0, p.r + 0.12, zb);
    ctx.save(); ctx.setLineDash([4, 4]); ctx.strokeStyle = '#6f7782'; ctx.lineWidth = 1.1; ctx.beginPath(); ctx.moveTo(O.x, O.y); ctx.lineTo(ref.x, ref.y); ctx.stroke(); ctx.restore();
  }
  if (top) {
    var thTot = circ ? st.th : s.tCut * p.w + s.ph, thv = thTot % TAU;
    var rA = Math.min(0.13, p.r * 0.45) * S;
    if (thv > 0.02) { ctx.save(); ctx.strokeStyle = COL.ink2; ctx.lineWidth = 1.3; ctx.beginPath(); ctx.arc(O.x, O.y, rA, 0, -thv, true); ctx.stroke(); ctx.restore(); }
    /* 「θ = ωt」の文字は動かさない（基準の破線の少し上の決まった場所）。角がまだ小さくて場所がないあいだは出さない */
    if (thTot > 0.9) {
      var bth = label(ctx, 'θ = ωt', O.x + (rA + 30) * Math.cos(-0.5), O.y + (rA + 30) * Math.sin(-0.5), { size: 12.5, color: COL.ink2 });
      s.addHit('w', bth);
    }
  }

  /* 穴 O（糸を通す） */
  var nb = P([0, 0, 0]), nt = nb, sinEl = Math.max(0.3, Math.sin(cam.el * Math.PI / 180));
  ctx.save(); ctx.fillStyle = '#2b323c'; ctx.beginPath(); ctx.ellipse(nb.x, nb.y, 4.6, 4.6 * sinEl, 0, 0, TAU); ctx.fill(); ctx.restore();
  {                                                           /* 「中心」の文字は動かさない。スタート前だけ「中心 O（穴）」、動きだしたら「中心」 */
    var started = (s.t > 0 || s.playing || s.cutAnim), ctxt = started ? '中心' : '中心 O（穴）';
    if (top) label(ctx, ctxt, O.x - 8, O.y + 15, { size: 11.5, color: COL.ink2, align: 'right' });   /* 上から：基準の破線（右）と r をよける */
    else label(ctx, ctxt, nb.x - 9, nb.y + 2, { size: 11.5, color: COL.ink2, align: 'right' });       /* 斜め上から：穴の左どなり */
  }

  /* ストロボ（1 秒ごと） */
  /* 円運動のあいだは t = 0, 1, 2 … 秒（直近の 1 周ぶん）。糸を切ったあとは、切った瞬間から 1 秒ごと（等間隔に並ぶのを見せる） */
  if (s.strobe) {
    var gts = [], tc = (s.tCut === null) ? Infinity : s.tCut;
    for (var k = 0; k <= Math.floor(Math.min(s.t, tc) + 1e-9); k++) if (k > Math.min(s.t, tc) - D.T + 1e-9) gts.push({ t: k, tag: k + ' s' });
    if (s.tCut !== null) for (var k2 = 0; s.tCut + k2 <= s.t + 1e-9; k2++) gts.push({ t: s.tCut + k2 + 1e-9, tag: k2 === 0 ? '切った瞬間' : '+' + k2 + ' s', line: 1 });
    var cs0 = (s.tCut !== null) ? M1.state(p.r, p.w, s.tCut, null, s.ph) : null, cutP = cs0 ? P(m1W(cs0.x, cs0.y, zb)) : null;
    gts.forEach(function (gg) {
      var g1 = M1.state(p.r, p.w, gg.t, s.tCut, s.ph), gp = P(m1W(g1.x, g1.y, zb));
      if (Math.abs(gg.t - tD) < 1e-6) gg.now = 1;              /* いま見えている小球の位置（札だけ書く） */
      if (!gg.line && cutP && Math.hypot(gp.x - cutP.x, gp.y - cutP.y) < 34) gg.tag = '';   /* 「切った瞬間」と重なる札は書かない */
      ctx.save(); ctx.globalAlpha = 0.55; ctx.strokeStyle = gg.line ? COL.vel : '#5d6875'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.arc(gp.x, gp.y, M1.rb * S, 0, TAU); ctx.stroke();
      ctx.globalAlpha = 0.85; ctx.fillStyle = gg.line ? COL.vel : '#5d6875'; ctx.font = '600 9.5px ' + FONT; ctx.textAlign = 'center'; ctx.fillText(gg.tag, gp.x, gp.y + M1.rb * S + 11); ctx.restore();
    });
  }

  var B = P(m1W(st.x, st.y, zb)), rpx = M1.rb * S;
  var ur = circ ? [st.x / p.r, st.y / p.r] : null;            /* 外向きの単位ベクトル（物理の座標） */
  /* 糸を切ったあとの道すじ（破線） */
  if (!circ) {
    var c0 = P(m1W(st.x0, st.y0, zb));
    ctx.save(); ctx.setLineDash([7, 5]); ctx.strokeStyle = COL.vel; ctx.globalAlpha = 0.75; ctx.lineWidth = 1.8;
    ctx.beginPath(); ctx.moveTo(c0.x, c0.y); ctx.lineTo(B.x, B.y); ctx.stroke(); ctx.restore();
    ctx.save(); ctx.fillStyle = COL.vel; ctx.beginPath(); ctx.arc(c0.x, c0.y, 2.6, 0, TAU); ctx.fill(); ctx.restore();
    if (!s.strobe) label(ctx, '糸を切った点', c0.x, c0.y + 14, { size: 10.5, color: COL.vel });
    /* 切れた糸：穴がわは切ったところに残り、小球がわは小球のうしろについていく */
    var u0 = [st.x0 / p.r, st.y0 / p.r], cutL = (p.r - M1.rb) / 2;
    var stub = P(m1W(u0[0] * cutL, u0[1] * cutL, zb));
    ctx.save(); ctx.strokeStyle = '#7a5a32'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(nt.x, nt.y); ctx.lineTo(stub.x, stub.y); ctx.stroke();
    var sp0 = Math.hypot(st.vx, st.vy), bk = [st.x - st.vx / sp0 * M1.rb, st.y - st.vy / sp0 * M1.rb];
    var tail = P(m1W(bk[0] - st.vx / sp0 * cutL, bk[1] - st.vy / sp0 * cutL, zb)), bkP = P(m1W(bk[0], bk[1], zb));
    ctx.beginPath(); ctx.moveTo(bkP.x, bkP.y); ctx.lineTo(tail.x, tail.y); ctx.stroke(); ctx.restore();
  } else {
    /* 糸：穴 O から小球の表面まで */
    var end = P(m1W(st.x - ur[0] * M1.rb, st.y - ur[1] * M1.rb, zb));
    ctx.save(); ctx.strokeStyle = '#7a5a32'; ctx.lineWidth = 1.7; ctx.beginPath(); ctx.moveTo(nb.x, nb.y); ctx.lineTo(end.x, end.y); ctx.stroke(); ctx.restore();
  }
  /* 半径 r の文字。上から見た図では教科書と同じく基準の破線（O–P₀）に、斜め上からの図では糸の中心寄りのわきに書く
     （小球の近くは v⃗・a⃗・F⃗ の文字があるので避ける） */
  if (top) {
    var rq = C(0, p.r * 0.5, zb), br0 = sym(ctx, 'r', rq.x, rq.y + 12, { size: 17, color: COL.ink });
    s.addHit('r', br0);
  } else if (circ) {
    var tx = -ur[1], ty = ur[0], fr = 0.42;
    var mr = P(m1W(st.x * fr, st.y * fr, zb)), mt = P(m1W(st.x * fr + tx * 0.08, st.y * fr + ty * 0.08, zb));
    var br = sym(ctx, 'r', mt.x + (mt.x - mr.x) * 0.5, mt.y + (mt.y - mr.y) * 0.5, { size: 17, color: COL.ink });
    s.addHit('r', br);
  }

  var stTr = s.strobe ? M1.state(p.r, p.w, s.t, s.tCut, s.ph) : st;   /* ストロボ中も、軌跡は本当の位置でとる（点どうしを直線で結ばない） */
  trailStep(ctx, s, function (x, y, z) { return P(m1W(x, y, z)); }, [stTr.x, stTr.y, zb], 0);   /* 軌跡（少し前までの道すじ） */
  /* 小球の影（台の上）と小球 */
  var sh = P(m1W(st.x, st.y, 0));
  ctx.save(); ctx.fillStyle = 'rgba(20,23,28,.16)'; ctx.beginPath(); ctx.ellipse(sh.x, sh.y, rpx * 1.05, rpx * 1.05 * Math.max(0.25, Math.sin(cam.el * Math.PI / 180)), 0, 0, TAU); ctx.fill(); ctx.restore();
  ballShape(ctx, B.x, B.y, rpx, '#c9d3de');
  if (s.strobe && (s.playing || s.t > 0) && s.t - tD < 0.16) {     /* ストロボが光った瞬間 */
    var fl = 1 - (s.t - tD) / 0.16;
    ctx.save(); ctx.globalAlpha = 0.55 * fl; ctx.fillStyle = '#fff6d6'; ctx.beginPath(); ctx.arc(B.x, B.y, rpx * 2.6, 0, TAU); ctx.fill();
    ctx.globalAlpha = 0.9 * fl; ctx.strokeStyle = '#e07b18'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(B.x, B.y, rpx * 1.9, 0, TAU); ctx.stroke(); ctx.restore();
  }

  /* ---- ベクトル（いちばん前面に） ---- */
  var vx = st.vx, vy = st.vy, sp = Math.hypot(vx, vy), uv = [vx / sp, vy / sp];
  var nOut = circ ? ur : (function () { var n = [-uv[1], uv[0]]; return (n[0] * st.x + n[1] * st.y >= 0) ? n : [-n[0], -n[1]]; })();
  /* 力（力を表示のとき） */
  if (showF) {
    if (circ) {                                              /* 向心力 F（糸が引く力）：作用点は糸のつく点 */
      var LF = D.F * M1SC.F, a0 = [st.x - ur[0] * M1.rb, st.y - ur[1] * M1.rb];
      var fa = P(m1W(a0[0], a0[1], zb)), fb = P(m1W(a0[0] - ur[0] * LF, a0[1] - ur[1] * LF, zb));
      var af = arrow(ctx, fa.x, fa.y, fb.x, fb.y, 'force', COL.hand);
      if (af) {                                              /* 文字は矢印のまん中の「進む向きのがわ」（うしろがわには a⃗ がある） */
        var fm = P(m1W(a0[0] - ur[0] * LF * 0.5 + uv[0] * 0.075, a0[1] - ur[1] * LF * 0.5 + uv[1] * 0.075, zb));
        var bf = sym(ctx, 'F', fm.x, fm.y, { size: 17, color: COL.hand, vec: true });
        s.addHit('F', bf); s.addHitSeg('F', af);
      }
    }
    /* 重力 mg と垂直抗力 N は鉛直方向でつりあっているので、このモードでは描かない（右の列に書く） */
  }
  /* 加速度 a（中心向き。力の矢印と重ならないよう、うしろがわへ少しずらす） */
  if (circ) {
    var La = D.a * M1SC.a, off = 0.085, s0 = [st.x - uv[0] * off, st.y - uv[1] * off];
    var aa = P(m1W(s0[0], s0[1], zb)), ab = P(m1W(s0[0] - ur[0] * La, s0[1] - ur[1] * La, zb));
    var ar = arrow(ctx, aa.x, aa.y, ab.x, ab.y, 'acc');
    if (ar) {
      var la = sym(ctx, 'a', ar.x2 + ar.uy * 12 + ar.ux * 3, ar.y2 - ar.ux * 12 + ar.uy * 3, { size: 17, color: COL.acc, vec: true });
      s.addHit('a', la); s.addHitSeg('a', ar);
    }
  }
  /* 速度 v（小球から外がわ＋上へ離して、小球の位置にまん中をそろえる） */
  {
    var Lv = sp * M1SC.v, oo = [st.x + nOut[0] * 0.13, st.y + nOut[1] * 0.13], zz = zb + (top ? 0 : 0.10);
    var va = P(m1W(oo[0] - uv[0] * Lv / 2, oo[1] - uv[1] * Lv / 2, zz)), vb = P(m1W(oo[0] + uv[0] * Lv / 2, oo[1] + uv[1] * Lv / 2, zz));
    var av = arrow(ctx, va.x, va.y, vb.x, vb.y, 'vel');
    if (av) {
      var ox = P(m1W(oo[0] + nOut[0] * 0.07, oo[1] + nOut[1] * 0.07, zz));
      var lv = sym(ctx, 'v', vb.x + av.ux * 10 + (ox.x - (va.x + vb.x) / 2) * 0.4, vb.y + av.uy * 10 + (ox.y - (va.y + vb.y) / 2) * 0.4, { size: 17, color: COL.vel, vec: true });
      s.addHit('v', lv); s.addHitSeg('v', av);
    }
  }
  /* 回る向き ω（決まった場所の円弧の矢印） */
  if (circ && cam.el >= 8) {                                  /* 真横からは円弧がつぶれるので描かない */
    /* 回る向き ω の矢印は動かさない（左上の決まった場所）。円弧の長さ（角）は ω に比例（0.45ω rad）＝ ω が大きいほど長い矢印 */
    /* 円弧の半径は r によらず一定（r を変えても矢印の長さが ω だけで決まるように。r を小さくしながら ω が大きくなる様子が見える） */
    var rw = M1.R.r[1] + 0.17, a1 = 1.80, a2 = a1 + 0.45 * p.w, pts = [];
    for (var j = 0; j <= 30; j++) pts.push(C(a1 + (a2 - a1) * j / 30, rw, zb));
    ctx.save(); ctx.strokeStyle = COL.ink2; ctx.fillStyle = COL.ink2; ctx.lineWidth = 2;
    ctx.beginPath(); pts.slice(0, 27).forEach(function (q, i) { i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y); }); ctx.stroke();
    var e1 = pts[30], e0 = pts[26], ex = e1.x - e0.x, ey = e1.y - e0.y, eL = Math.hypot(ex, ey) || 1; ex /= eL; ey /= eL;
    ctx.beginPath(); ctx.moveTo(e1.x, e1.y); ctx.lineTo(e1.x - ex * 10 - ey * 5, e1.y - ey * 10 + ex * 5); ctx.lineTo(e1.x - ex * 10 + ey * 5, e1.y - ey * 10 - ex * 5); ctx.closePath(); ctx.fill();
    ctx.restore();
    var mw = C((a1 + a2) / 2, rw + 0.10, zb);
    var bw = sym(ctx, 'ω', mw.x, mw.y, { size: 18, color: COL.ink2 });
    if (s.demo) { var mv = C((a1 + a2) / 2, rw + 0.30, zb); label(ctx, 'ω = ' + fmt(p.w, 2) + ' rad/s', mv.x, mv.y, { size: 13, bold: true, color: '#7a1f4f' }); }
    s.addHit('w', bw);
    s.hits.push({ k: 'w', seg: [pts[0].x, pts[0].y, pts[30].x, pts[30].y] });
  }
  drawEqualTicks(ctx);

  /* はさみ：視点が上に来てから、糸のまん中にすべりこみ、刃を閉じて切る。切ったあとは消えていく */
  var A = s.cutAnim;
  if (A && A.e !== undefined && A.e > M1CUT.cam) {
    var tcA = A.snipped ? s.tCut : s.t, sc0 = M1.state(p.r, p.w, tcA, null, s.ph), uu = [sc0.x / p.r, sc0.y / p.r], cl = (p.r - M1.rb) / 2;
    var cp = P(m1W(uu[0] * cl, uu[1] * cl, zb)), hp = P([0, 0, 0]);
    var sx = cp.x - hp.x, sy = cp.y - hp.y, sl = Math.hypot(sx, sy) || 1; sx /= sl; sy /= sl;   /* 画面での糸の向き */
    var ax = sy, ay = -sx;                                   /* はさみの刃の向き＝糸に垂直 */
    var e1 = clamp((A.e - M1CUT.cam) / M1CUT.inT, 0, 1), e2 = clamp((A.e - M1CUT.cam - M1CUT.inT) / M1CUT.close, 0, 1);
    var slide = 1 - e1 * e1 * (3 - 2 * e1), open = 0.75 * (1 - e2) + 0.04;
    var kS = clamp(S / 230, 0.5, 1.0), reach = 40 * kS;          /* はさみの大きさは図の縮尺に合わせる */
    var pvx = cp.x - ax * reach - ax * 90 * slide, pvy = cp.y - ay * reach - ay * 90 * slide;
    var alpha = A.snipped ? clamp(1 - (A.e - M1CUT.cam - M1CUT.inT - M1CUT.close) / M1CUT.fade, 0, 1) : clamp(e1 * 1.6, 0, 1);
    scissors(ctx, pvx, pvy, ax, ay, open, kS, alpha);
    if (A.snipped && alpha > 0.05) {                         /* 切れた瞬間の小さな印 */
      ctx.save(); ctx.globalAlpha = alpha; ctx.strokeStyle = '#e07b18'; ctx.lineWidth = 2;
      for (var q8 = 0; q8 < 6; q8++) { var aq = q8 * Math.PI / 3; ctx.beginPath(); ctx.moveTo(cp.x + Math.cos(aq) * 7, cp.y + Math.sin(aq) * 7); ctx.lineTo(cp.x + Math.cos(aq) * 13, cp.y + Math.sin(aq) * 13); ctx.stroke(); }
      ctx.restore();
    }
  }

  /* 左上：いまの状態（左上の「✂ 糸を切る！」ボタンの下） */
  /* 左上：いまの状態（「✂ 糸を切る！」の下） */
  pill(ctx, circ ? '状態：等速円運動' : '状態：等速直線運動', 10, 54, { color: circ ? COL.ink : '#9c4e06', border: circ ? 'rgba(20,23,28,.18)' : 'rgba(224,123,24,.6)', bg: circ ? '#ffffff' : '#fdf4e8' });
  if (s.demo) {                                            /* 「Ｆ一定・r 小さくする」の間：いまの r と ω を大きく見せる */
    var dtx = 'F = ' + fmt(D.F, 3) + ' N（一定）   r = ' + fmt(p.r, 2) + ' m   ω = ' + fmt(p.w, 2) + ' rad/s';
    pill(ctx, dtx, W - 10, H - 34, { size: 13, align: 'right', color: '#7a1f4f', bg: '#fdeef5', border: 'rgba(194,54,127,.55)' });
  }
  /* 下：周期 T・回転数 n（クリックできる札） */
  var bT = pill(ctx, '周期 T', 10, H - 30, { size: 12 });
  var bN = pill(ctx, '回転数 n', bT.x + bT.w + 8, H - 30, { size: 12 });
  s.addHit('T', bT); s.addHit('n', bN);
  /* えらんでいる量に印（うすいオレンジの輪） */
  if (s.sel) {
    s.hits.filter(function (h) { return h.k === s.sel && !h.seg; }).forEach(function (h) {
      ctx.save(); ctx.strokeStyle = 'rgba(224,123,24,.85)'; ctx.lineWidth = 2; ctx.setLineDash([]);
      rrect(ctx, h.x - 4, h.y - 3, h.w + 8, h.h + 6, 7); ctx.stroke(); ctx.restore();
    });
  }
}

/* ---------- 右の列：説明と公式 ---------- */
var M1INFO = {
  r: { t: '半径 $r$〔m〕',
    d: '円の中心から小球までの距離。この図では、穴 O から小球までの糸の長さが半径になる。',
    f: '図の中の糸（中心から小球まで）が半径 $r$。',
    eq: ['v = r\\omega', 'a = r\\omega^2 = \\dfrac{v^2}{r}', 'T = \\dfrac{2\\pi r}{v}'],
    note: '$\\omega$ をそのままにして $r$ を大きくすると、$v$・$a$・$F$ も大きくなる。' },
  v: { t: '速さ $v$〔m/s〕と速度 $\\vec{v}$',
    d: '速さ（速度の大きさ）は一定。でも速度の<b>向き</b>は円の接線方向で、たえず変わっている。',
    f: '青い矢印 $\\vec{v}$。いつも糸（半径）と垂直。糸を切ると、小球はその瞬間の $\\vec{v}$ の向きに、同じ速さでまっすぐ進む。',
    eq: ['v = \\dfrac{l}{t} = r\\,\\dfrac{\\theta}{t} = r\\omega', 'v = \\dfrac{2\\pi r}{T}'] },
  w: { t: '角速度 $\\omega$〔rad/s〕',
    d: '1 秒あたりに回転する角度（中心角）。単位はラジアン毎秒（rad/s）。',
    f: '「上から」の図の $\\theta=\\omega t$ の角が、1 秒に $\\omega$ ずつ増える。黒い円弧の矢印が回る向き。',
    eq: ['\\theta = \\omega t', 'v = r\\omega', '\\omega = \\dfrac{2\\pi}{T} = 2\\pi n'] },
  T: { t: '周期 $T$〔s〕',
    d: '1 回転するのにかかる時間。1 回転すると、中心角は $2\\pi$ rad、移動距離は円周 $2\\pi r$。',
    f: '「1 秒ごとのストロボ」を ON にすると、1 周の間に小球の位置が $T$ 秒ぶん（およそ $T$ 個）残る。',
    eq: ['T = \\dfrac{2\\pi r}{v} = \\dfrac{2\\pi}{\\omega}', 'n = \\dfrac{1}{T}'] },
  n: { t: '回転数 $n$〔Hz〕',
    d: '1 秒あたりの回転の回数。単位はヘルツ（Hz）＝ 回/s。',
    f: '$T$ 秒で 1 回転するので、1 秒では $\\dfrac{1}{T}$ 回転する。',
    eq: ['n = \\dfrac{1}{T}', '\\omega = 2\\pi n'] },
  a: { t: '加速度 $\\vec{a}$〔m/s²〕',
    d: '速さは一定でも、速度の向きが変わるので加速度がある。向きはいつも<b>円の中心向き</b>（向心加速度）。',
    f: 'オレンジの矢印 $\\vec{a}$。いつも中心を向き、速度 $\\vec{v}$ と垂直。糸を切ると 0 になる。',
    note: '運動方程式 $m\\vec{a} = \\vec{F}$ より、<b>加速度 $\\vec{a}$ と向心力 $\\vec{F}$ はいつも同じ向き</b>（どちらも円の中心向き）。',
    explainA: true,
    eq: ['a = r\\omega^2 = \\dfrac{v^2}{r} = v\\omega'] },
  F: { t: '向心力 $\\vec{F}$〔N〕',
    d: '等速円運動をさせるのに必要な、中心向きの力（合力）。運動方程式 $ma=F$ に $a=r\\omega^2$ を入れると $mr\\omega^2=F$。',
    f: 'ピンクの矢印 $\\vec{F}$。この図では、台の下で手が引いている糸が小球を引く力（張力）が向心力のはたらきをしている。',
    note: '運動方程式 $m\\vec{a} = \\vec{F}$ より、<b>向心力 $\\vec{F}$ と加速度 $\\vec{a}$ はいつも同じ向き</b>（どちらも円の中心向き）。<br>小球には重力 $mg$ と台からの垂直抗力 $N$ もはたらくが、鉛直方向でつり合っている（$N=mg$）ので、この図では省いている。図の $\\vec{F}$ の長さは $\\vec{a}$ の長さ × $\\dfrac{m}{0.20\\ \\text{kg}}$（$F=ma$）。質量 $m$ を大きくすると、同じ $a$ でも必要な $F$ は大きくなる。',
    eq: ['mr\\omega^2 = F', 'm\\dfrac{v^2}{r} = F'] }
};
function m1Num(k, D) {
  var m = M1.m;
  switch (k) {
    case 'r': return 'r = ' + fmt(D.r, 2) + '\\ \\text{m}';
    case 'v': return 'v = r\\omega = ' + fmt(D.r, 2) + '\\times' + fmt(D.w, 2) + ' = ' + fmt(D.v, 2) + '\\ \\text{m/s}';
    case 'w': return '\\omega = \\dfrac{2\\pi}{T} = \\dfrac{2\\pi}{' + fmt(D.T, 2) + '} = ' + fmt(D.w, 2) + '\\ \\text{rad/s}';
    case 'T': return 'T = \\dfrac{2\\pi}{\\omega} = \\dfrac{2\\pi}{' + fmt(D.w, 2) + '} = ' + fmt(D.T, 2) + '\\ \\text{s}';
    case 'n': return 'n = \\dfrac{1}{T} = \\dfrac{1}{' + fmt(D.T, 2) + '} = ' + fmt(D.n, 3) + '\\ \\text{Hz}';
    case 'a': return 'a = r\\omega^2 = ' + fmt(D.r, 2) + '\\times' + fmt(D.w, 2) + '^2 = ' + fmt(D.a, 2) + '\\ \\text{m/s}^2';
    case 'F': return 'F = mr\\omega^2 = ' + fmt(m, 2) + '\\times' + fmt(D.r, 2) + '\\times' + fmt(D.w, 2) + '^2 = ' + fmt(D.F, 3) + '\\ \\text{N}';
  }
  return '';
}
function rightM1(s, R) {
  var D = M1.derive(s.p.r, s.p.w), k = s.sel;
  var h = '<p class="qhow">スライダーを動かすか、<b>図の中の文字（$r$・$v$・$a$・$F$・$\\omega$・$T$・$n$）をクリック</b>すると、下に説明と公式が出る。<b>動かせるのは半径 $r$・角速度 $\\omega$・質量 $m$ の 3 つ</b>。他の量（$v$・$a$・$F$・$T$・$n$）は、それらから決まる値をメーターで表示する。</p>';
  h += '<div class="qpick"><span class="ql">選択：</span>' + M1KEYS.map(function (q) {
    return '<button type="button" class="tiny qbtn' + (q === k ? ' on' : '') + '" data-q="' + q + '">' + M1NAME[q] + ' ' + tex(M1SYM[q]) + '</button>';
  }).join('') + '</div>';
  if (!k) {
    h += '<div class="qcard intro"><p class="qt">説明と公式</p><p>スライダーを動かすか、図の中の文字（$r$・$\\vec{v}$・$\\vec{a}$・$\\vec{F}$・$\\omega$）や、図の下の「周期 $T$」「回転数 $n$」をクリックすると、ここにその量の説明と公式が出ます。</p></div>';
  } else {
    var I = M1INFO[k];
    h += '<div class="qcard"><p class="qt">' + I.t + '</p><p>' + I.d + '</p>' +
      '<p class="qf"><span class="qtag">図では</span>' + I.f + '</p>' +
      '<div class="qeq">' + I.eq.map(function (e) { return '<div>' + tex(e, true) + '</div>'; }).join('') + '</div>' +
      '<p class="qnow"><span class="qtag now">いまの値</span>' + tex(m1Num(k, D)) + '</p>' +
      (I.note ? '<p class="qnote">' + I.note + '</p>' : '') +
      (I.explainA ? '<div class="aexhost"></div>' : '') + '</div>';   /* 説明アニメは折りたたまずに最初から（2026-10-07 千葉さん） */
  }
  /* 7 つの量の関係の表：r と ω が決まれば全部決まる。いまの値もいっしょに */
  var REL = [
    ['r', 'r', '2 倍', 'そのまま', 2, 'm'], ['v', 'r\\omega', '2 倍', '2 倍', 2, 'm/s'], ['a', 'r\\omega^2', '2 倍', '4 倍', 2, 'm/s²'],
    ['F', 'mr\\omega^2', '2 倍', '4 倍', 3, 'N'], ['w', '\\omega', 'そのまま', '2 倍', 2, 'rad/s'],
    ['T', '\\dfrac{2\\pi}{\\omega}', 'そのまま', '\\tfrac{1}{2} 倍', 2, 's'], ['n', '\\dfrac{\\omega}{2\\pi}', 'そのまま', '2 倍', 3, 'Hz']];
  h += '<div class="relbox"><p class="ttl">7 つの量の関係</p><p class="relcap"><b>ほぼ半径 $r$ と角速度 $\\omega$ の 2 つで決まる。力 $F$ のみ質量 $m$ も関係する。</b></p>' +
    '<table class="reltab"><thead><tr><th>量</th><th>$r$ と $\\omega$ で表すと</th><th>$r$ を 2 倍</th><th>$\\omega$ を 2 倍</th><th>いまの値</th></tr></thead><tbody>' +
    REL.map(function (q) {
      var tw = q[3].indexOf('\\') >= 0 ? tex(q[3].replace(' 倍', '')) + ' 倍' : q[3];
      var cl = [M1GRP[q[0]] || '', q[0] === k ? 'on' : ''].join(' ').trim();
      return '<tr' + (cl ? ' class="' + cl + '"' : '') + '><th>' + M1NAME[q[0]] + ' ' + tex(M1SYM[q[0]]) + '</th><td>' + tex(q[1]) + '</td><td>' + q[2] + '</td><td>' + tw + '</td><td class="num">' + fmt(D[q[0]], q[4]) + ' <span class="u">' + q[5] + '</span></td></tr>';
    }).join('') + '</tbody></table>' +
    '<p class="relcap">中心方向の運動方程式：' + tex('mr\\omega^2 = F') + '　または　' + tex('m\\dfrac{v^2}{r} = F') + '。他に ' + tex('v = \\dfrac{2\\pi r}{T}') + '、' + tex('a = \\dfrac{v^2}{r}') + ' とも書ける。</p></div>' +
    '<p class="assume">小球の質量 $m$ は今 ' + fmt(s.p.m, 2) + ' kg。</p>';
  R.innerHTML = mathify(h);
  Object.keys(s.sl || {}).forEach(function (q) { s.sl[q].row.classList.toggle('sel', q === k); });   /* 選んでいる量はスライダーも強調 */
  R.querySelectorAll('[data-q]').forEach(function (b) {
    b.addEventListener('click', function () { s.sel = b.dataset.q; s.renderRight(); s.draw(); });
  });
  aexpMount(R.querySelector('.aexhost'));
}
/* ---------- 「Ｆ一定・r小さくする」：F を一定に保ったまま、r を最大→最小へ少しずつ小さくする ----------
   ω = √(F/(m r)) が大きくなっていく様子を見せる。時刻はふつうに進め（戻さない）、
   ω を変えるたびに角 θ = ωt + ph が飛ばないよう ph を変える。表示中は操作を受け付けない（コントロールと図を inert にする） */
var M1DEMO = { hold: 0.8, dur: 8.0, tail: 0.6 };
function m1StartDemo(s) {
  if (s.demo) return;
  var R = M1.R.r, w0 = M1.W[1];                          /* r = 0.80 m、ω = π/2 から → 終わりは r = 0.20 m、ω = π（m = 0.10 kg のとき） */
  var th = s.p.w * s.t + s.ph;
  s.playing = false; s.tCut = null; s.cutAnim = null; s.syncCut(); s.ended = false;
  if (s.t > M1.tMax - 12) s.t = 0;                       /* 時間バーの終わりが近いときだけ 0 から */
  s.p.r = R[1]; s.p.w = w0; s.ph = th - w0 * s.t;
  var F0 = M1.m * R[1] * w0 * w0;
  s.sel = 'w';
  s.setBusy(true);
  s.bDemo.textContent = '実行中…';
  s.demo = { e: 0, F0: F0, last: 0, rr: 0 };
  if (!s.ms.showF) { s.ms.showF = true; syncModeBar('mode1'); }   /* 一定に保つ F の矢印を見せる */
  s.syncPlayLabel(); s.renderRight(); s.draw();
  var tick = function (ts) {
    var d = s.demo; if (!d) return;
    if (s.busy && s.busy.paused) { d.last = ts; requestAnimationFrame(tick); return; }   /* 一時停止中 */
    var dt = d.last ? Math.min(0.05, (ts - d.last) / 1000) : 0; d.last = ts; d.e += dt;
    var u = clamp((d.e - M1DEMO.hold) / M1DEMO.dur, 0, 1), sm = u * u * (3 - 2 * u);
    var wOld = s.p.w;
    s.p.r = R[1] - (R[1] - R[0]) * sm;
    s.p.w = Math.sqrt(d.F0 / (M1.m * s.p.r));
    s.ph += (wOld - s.p.w) * s.t;                       /* 角が飛ばないように */
    s.t = Math.min(s.t + dt, M1.tMax);
    s.draw();
    if (ts - d.rr > 250 || u >= 1) { d.rr = ts; s.renderRight(); }
    if (d.e < M1DEMO.hold + M1DEMO.dur + M1DEMO.tail) requestAnimationFrame(tick);
    else m1EndDemo(s);
  };
  requestAnimationFrame(tick);
}
function m1EndDemo(s) {
  if (!s.demo) return;
  s.demo = null;
  var wO = s.p.w; s.p.r = M1.R.r[0]; s.p.w = M1.W[3]; s.ph += (wO - s.p.w) * s.t;   /* 終わりは r = 0.20 m、ω = π ちょうどに */
  s.setBusy(false);
  s.bDemo.innerHTML = mathify('Ｆ一定・$r$ 小さくする');
  s.lastMsg = null;
  s.playing = false; s.togglePlay();                     /* そのまま回し続ける */
  s.renderRight(); s.draw();
}

/* 糸を切るボタンの見た目（切ったあとは押せない） */
Sim.prototype.syncCut = function () {
  var b = this.extra && this.extra.cut; if (!b) return;
  var done = (this.tCut !== null && this.tCut !== undefined);
  b.disabled = done; b.classList.toggle('done', done);
  b.textContent = done ? '✂ 糸を切った' : '✂ 糸を切る！';
};
