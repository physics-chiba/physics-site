/* =========================================================================
   75_graph.js … モード3 の右下のグラフ（力–時刻、エネルギー–時刻）
   experiment-graph-ui の決めごと：
   ・グラフの中をドラッグ＝上下左右に動かす（横軸 t はグラフどうしで共有、縦はそのグラフだけ）
   ・横軸／縦軸の目盛りのところをドラッグ＝拡大縮小。「スケールをリセット」でもとにもどす
   ・クリックでその時刻を選ぶ（見出しに値・すべてのグラフに縦線）。もう一度で解除。右上の「最大化」
   ・枠の外は描かない（clip）。軸には矢印。縦軸は必ず 0 を含み、目盛りは 1・2・2.5・5×10ⁿ
   エネルギーの線は E → U → K の順に描く（重なったとき K が消えないように）。色は K＝緑・U＝茶の破線・E＝濃紺の太線
   ========================================================================= */
'use strict';
var GCOL = { K: '#2e8b57', U: '#8b5a2b', E: '#1f2a5a' };
var GPAD = { l: 50, r: 12, t: 10, b: 28 };
function niceStep(range, target) {
  var raw = range / target, p = Math.pow(10, Math.floor(Math.log(raw) / Math.LN10)), c = [1, 2, 2.5, 5, 10];
  for (var i = 0; i < c.length; i++) if (raw <= c[i] * p * 1.0001) return c[i] * p;
  return 10 * p;
}
/* 0 を必ず入れた、きりのいい範囲。上端に余裕 */
function niceRange(lo, hi) {
  lo = Math.min(lo, 0); hi = Math.max(hi, 0); if (hi - lo < 1e-9) hi = lo + 1;
  if (lo > -1e-6 * (hi - lo)) lo = 0;                    /* 計算誤差の小さな負の値で、0 より下に目盛りを足さない */
  var st = niceStep(hi - lo, 4), a = Math.floor(lo / st + 1e-9) * st, b = Math.ceil(hi / st - 1e-9) * st;
  if (b - hi < 0.55 * st) b += st;
  if (lo < -1e-9 && lo - a < 0.3 * st) a -= st;
  return { lo: a, hi: b };
}
var MAX_SVG = '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M3 8V3h5M12 3h5v5M17 12v5h-5M8 17H3v-5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><path d="M3 3l5 5M17 3l-5 5M17 17l-5-5M3 17l5-5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>';

/* s のグラフ一式を host に作る。defs = [{ key, title, unit, ylab, series:[{name, color, width, dash, f(p)}], hlines:[{y, color, name}], sel(p) → 見出しの文字 }] */
function m3Graphs(s, host, defs, tr) {
  var tEnd = tr.tEnd;
  s.gx = { lo: 0, hi: tEnd, d0: { lo: 0, hi: tEnd } };
  s.gSel = null;
  s.graphs = [];
  var bar = el('div', 'gbar');
  var rs = el('button', 'tiny greset', 'スケールをリセット'); rs.type = 'button';
  bar.appendChild(el('span', 'gtip', 'ドラッグで移動・目盛りをドラッグで拡大縮小・クリックで値')); bar.appendChild(rs);
  host.appendChild(bar);
  defs.forEach(function (d) {
    var box = el('div', 'gbox'), hd = el('div', 'ghead');
    hd.appendChild(el('span', 'gt', mathify(d.title)));
    var sel = el('span', 'gsel', ''); hd.appendChild(sel);
    var mx = el('button', 'gmax', MAX_SVG); mx.type = 'button'; mx.title = '最大化'; mx.setAttribute('aria-label', 'このグラフを最大化');
    hd.appendChild(mx); box.appendChild(hd);
    var cv = el('canvas', 'gcv'); box.appendChild(cv);
    var lg = el('div', 'gleg', d.series.map(function (q) {
      return '<span><i style="border-top:' + (q.width || 2) + 'px ' + (q.dash ? 'dashed' : 'solid') + ' ' + q.color + '"></i>' + mathify(q.name) + '</span>';
    }).join('') + (d.hlines || []).map(function (q) { return '<span><i style="border-top:1.5px dashed ' + q.color + '"></i>' + mathify(q.name) + '</span>'; }).join(''));
    box.appendChild(lg);
    host.appendChild(box);
    var g = { d: d, cv: cv, box: box, sel: sel, tr: tr };
    g.auto = function () {
      var lo = 0, hi = 0;
      tr.pts.forEach(function (p) { d.series.forEach(function (q) { var y = q.f(p); if (y < lo) lo = y; if (y > hi) hi = y; }); });
      (d.hlines || []).forEach(function (q) { hi = Math.max(hi, q.y); lo = Math.min(lo, q.y); });
      return niceRange(lo, hi);
    };
    g.yr = g.auto(); g.y0 = { lo: g.yr.lo, hi: g.yr.hi };
    mx.addEventListener('click', function () { var on = !box.classList.contains('gmaxed'); box.classList.toggle('gmaxed', on); mx.title = on ? '元の大きさに戻す' : '最大化'; m3DrawGraphs(s); });
    m3BindGraph(s, g);
    s.graphs.push(g);
  });
  rs.addEventListener('click', function () { s.gx.lo = s.gx.d0.lo; s.gx.hi = s.gx.d0.hi; s.graphs.forEach(function (g) { g.yr = { lo: g.y0.lo, hi: g.y0.hi }; }); s.gSel = null; m3DrawGraphs(s); });
}
function m3Rect(g) { var W = g.W, H = g.H; return { x0: GPAD.l, x1: W - GPAD.r, y0: GPAD.t, y1: H - GPAD.b }; }
function m3BindGraph(s, g) {
  var down = null;
  g.cv.addEventListener('pointerdown', function (ev) {
    var b = g.cv.getBoundingClientRect(), x = ev.clientX - b.left, y = ev.clientY - b.top, R = m3Rect(g);
    var zone = (x < R.x0) ? 'y' : (y > R.y1 ? 'x' : 'pan');
    down = { x: ev.clientX, y: ev.clientY, lx: x, zone: zone, moved: false, gx: { lo: s.gx.lo, hi: s.gx.hi }, yr: { lo: g.yr.lo, hi: g.yr.hi } };
    g.cv.setPointerCapture(ev.pointerId); ev.preventDefault();
  });
  g.cv.addEventListener('pointermove', function (ev) {
    if (!down) return;
    var dx = ev.clientX - down.x, dy = ev.clientY - down.y, R = m3Rect(g);
    if (Math.hypot(dx, dy) > 4) down.moved = true;
    if (!down.moved) return;
    var sx = (down.gx.hi - down.gx.lo) / (R.x1 - R.x0), sy = (down.yr.hi - down.yr.lo) / (R.y1 - R.y0);
    if (down.zone === 'pan') {                                   /* 横は全部のグラフ、縦はこのグラフだけ */
      s.gx.lo = down.gx.lo - dx * sx; s.gx.hi = down.gx.hi - dx * sx;
      g.yr = { lo: down.yr.lo + dy * sy, hi: down.yr.hi + dy * sy };
    } else if (down.zone === 'x') {
      var f = Math.exp(-dx * 0.01), c = (down.gx.lo + down.gx.hi) / 2, h = (down.gx.hi - down.gx.lo) / 2 * f;
      s.gx.lo = c - h; s.gx.hi = c + h;
    } else {
      var f2 = Math.exp(dy * 0.01), c2 = (down.yr.lo + down.yr.hi) / 2, h2 = (down.yr.hi - down.yr.lo) / 2 * f2;
      g.yr = { lo: c2 - h2, hi: c2 + h2 };
    }
    m3DrawGraphs(s);
  });
  var up = function () {
    if (down && !down.moved && down.zone === 'pan') {          /* クリック：その時刻を選ぶ／同じところでもう一度で解除 */
      var R = m3Rect(g), t = s.gx.lo + (down.lx - R.x0) / (R.x1 - R.x0) * (s.gx.hi - s.gx.lo);
      t = clamp(t, 0, g.tr.tEnd);
      if (s.gSel !== null && Math.abs((s.gSel - t) / (s.gx.hi - s.gx.lo) * (R.x1 - R.x0)) < 6) s.gSel = null; else s.gSel = t;
      m3DrawGraphs(s);
    }
    down = null;
  };
  g.cv.addEventListener('pointerup', up);
  g.cv.addEventListener('pointercancel', function () { down = null; });
}
function m3DrawGraphs(s) { (s.graphs || []).forEach(function (g) { m3DrawGraph(s, g); }); }
function m3DrawGraph(s, g) {
  if (!g.cv.isConnected || !g.cv.offsetParent) return;            /* 見えていないグラフは描かない */
  var big = g.box.classList.contains('gmaxed');
  if (!g.Wc || g._big !== big) { g.Wc = Math.max(200, Math.floor(g.cv.clientWidth || g.box.clientWidth || 300)); g._big = big; }   /* 幅は毎回はかり直さない（はかると描画が止まる） */
  var W = g.Wc, H = big ? Math.max(260, Math.floor(window.innerHeight * 0.7)) : 170;
  g.W = W; g.H = H;
  var R = m3Rect(g), gx = s.gx, yr = g.yr, d = g.d, tr = g.tr, dpr = Math.min(2, Math.max(1, window.devicePixelRatio || 1));
  var X = function (t) { return R.x0 + (t - gx.lo) / (gx.hi - gx.lo) * (R.x1 - R.x0); };
  var Y = function (y) { return R.y1 - (y - yr.lo) / (yr.hi - yr.lo) * (R.y1 - R.y0); };
  /* 動かない部分（目盛り・軸・線・選んだ時刻）は、範囲が変わったときだけ別の canvas に描いておく */
  var key = [W, H, dpr, gx.lo, gx.hi, yr.lo, yr.hi, s.gSel].join('|');
  if (g._key !== key || !g.layer) {
    g._key = key;
    if (!g.layer) g.layer = document.createElement('canvas');
    g.layer.width = Math.round(W * dpr); g.layer.height = Math.round(H * dpr);
    var ctx = g.layer.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.lineJoin = 'round';
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H);
  /* 目盛りと格子 */
    var sx = niceStep(gx.hi - gx.lo, Math.max(3, Math.floor((R.x1 - R.x0) / 70))), sy = niceStep(yr.hi - yr.lo, 4);
    ctx.save(); ctx.font = '600 10.5px ' + FONT; ctx.fillStyle = '#5d6875'; ctx.strokeStyle = '#eef0f2'; ctx.lineWidth = 1;
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    for (var tx = Math.ceil(gx.lo / sx) * sx; tx <= gx.hi + 1e-9; tx += sx) { var px = X(tx); ctx.beginPath(); ctx.moveTo(px, R.y0); ctx.lineTo(px, R.y1); ctx.stroke(); ctx.fillText(+tx.toFixed(6) + '', px, R.y1 + 4); }
    ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    for (var ty = Math.ceil(yr.lo / sy) * sy; ty <= yr.hi + 1e-9; ty += sy) { var py = Y(ty); ctx.beginPath(); ctx.moveTo(R.x0, py); ctx.lineTo(R.x1, py); ctx.stroke(); ctx.fillText(+ty.toFixed(6) + '', R.x0 - 5, py); }
    ctx.restore();
    /* 軸（矢印つき）。横軸は y = 0 の高さ、縦軸は t = 0 の位置（見えないときは枠のはし） */
    var ax = clamp(Y(0), R.y0, R.y1), ay = clamp(X(0), R.x0, R.x1);
    ctx.save(); ctx.strokeStyle = '#2b323c'; ctx.fillStyle = '#2b323c'; ctx.lineWidth = 1.3;
    ctx.beginPath(); ctx.moveTo(R.x0, ax); ctx.lineTo(R.x1 + 6, ax); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(R.x1 + 10, ax); ctx.lineTo(R.x1 + 2, ax - 4); ctx.lineTo(R.x1 + 2, ax + 4); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(ay, R.y1); ctx.lineTo(ay, R.y0 - 4); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(ay, R.y0 - 8); ctx.lineTo(ay - 4, R.y0); ctx.lineTo(ay + 4, R.y0); ctx.closePath(); ctx.fill();
    ctx.font = 'italic 12px ' + MATH; ctx.textAlign = 'right'; ctx.textBaseline = 'bottom'; ctx.fillText('t', R.x1 + 2, ax - 5);
    ctx.font = '600 10px ' + FONT; ctx.fillText('〔s〕', R.x1 + 4, H - 1);
    ctx.textAlign = 'left'; ctx.textBaseline = 'top'; ctx.fillText(d.ylab, 3, 0);
    ctx.restore();
    /* 線（枠の中だけ） */
    ctx.save(); ctx.beginPath(); ctx.rect(R.x0, R.y0, R.x1 - R.x0, R.y1 - R.y0); ctx.clip();
    (d.hlines || []).forEach(function (q) { ctx.strokeStyle = q.color; ctx.setLineDash([6, 4]); ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(R.x0, Y(q.y)); ctx.lineTo(R.x1, Y(q.y)); ctx.stroke(); });
    ctx.setLineDash([]);
    d.series.forEach(function (q) {
      ctx.strokeStyle = q.color; ctx.lineWidth = q.width || 2; ctx.setLineDash(q.dash || []); ctx.lineJoin = 'round'; ctx.beginPath();
      var first = true, prevKind = null;
      tr.pts.forEach(function (p) {
        var x = X(p.t), y = Y(q.f(p));
        if (first || (q.gap && prevKind !== p.kind && (prevKind === 'fly' || p.kind === 'fly'))) { ctx.moveTo(x, y); first = false; } else ctx.lineTo(x, y);
        prevKind = p.kind;
      });
      ctx.stroke();
    });
    ctx.setLineDash([]);
  /* 選んだ時刻（すべてのグラフに縦線） */
    if (s.gSel !== null) {
      var qs = M3.at(tr, s.gSel), xs = X(qs.t);
      ctx.strokeStyle = '#3d4c5a'; ctx.setLineDash([4, 3]); ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(xs, R.y0); ctx.lineTo(xs, R.y1); ctx.stroke(); ctx.setLineDash([]);
      d.series.forEach(function (q) {
        var yy = Y(q.f(qs));
        ctx.strokeStyle = q.color; ctx.setLineDash([2, 3]); ctx.beginPath(); ctx.moveTo(R.x0, yy); ctx.lineTo(xs, yy); ctx.stroke(); ctx.setLineDash([]);
        ctx.fillStyle = '#fff'; ctx.strokeStyle = q.color; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(xs, yy, 4.2, 0, TAU); ctx.fill(); ctx.stroke();
      });
    }
    ctx.restore();
  }
  var ctx2 = prep(g.cv, W, H);
  ctx2.drawImage(g.layer, 0, 0, W, H);
  ctx2.save(); ctx2.beginPath(); ctx2.rect(R.x0, R.y0, R.x1 - R.x0, R.y1 - R.y0); ctx2.clip();
  /* いまの時刻のカーソル */
  var q0 = M3.at(tr, s.t), xc = X(q0.t);
  ctx2.strokeStyle = 'rgba(224,123,24,.85)'; ctx2.lineWidth = 1.6; ctx2.beginPath(); ctx2.moveTo(xc, R.y0); ctx2.lineTo(xc, R.y1); ctx2.stroke();
  d.series.forEach(function (q) { ctx2.fillStyle = q.color; ctx2.beginPath(); ctx2.arc(xc, Y(q.f(q0)), 3.6, 0, TAU); ctx2.fill(); });
  ctx2.restore();
  var st = s.gSel === null ? '' : '（' + d.sel(M3.at(tr, s.gSel)) + '）';
  if (g.sel.textContent !== st) g.sel.textContent = st;
}
