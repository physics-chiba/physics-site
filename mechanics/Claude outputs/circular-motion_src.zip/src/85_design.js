/* =========================================================================
   デザイン試作の動き（2026-10）
   ・ヒーローのステージ：同じ等速円運動を、外の観測者（慣性系）と一緒に回る観測者（非慣性系）から並べて見せる。
   ・スライドバーの塗り（--p）、タブ列の下の進み具合（--prog）。
   ・画面に見えていないとき・動きを減らす設定のときは動かさない（重くしない：第 21 回の教訓）。
   ========================================================================= */
(function(){
  "use strict";
  const RM = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const MATH = '"KaTeX_Math","KaTeX_Main",serif',
        JP = '"Hiragino Sans","Hiragino Kaku Gothic ProN","Yu Gothic",YuGothic,"Noto Sans JP",Meiryo,sans-serif';

  /* ===== ヒーローのステージ：同じ等速円運動を「外の観測者」と「一緒に回る観測者」から並べて見せる =====
     左＝慣性系（上から見た台）。小球は回り、張力 S が向心力。遠心力は描かない。
     右＝非慣性系（小球と一緒に回る）。小球は止まって見え、台と外の観測者が逆向きに回る。S と遠心力がつりあう（等長マーク）。 */
  function initStage(){
    const cv = document.getElementById("heroCv"); if(!cv) return;
    const ctx = cv.getContext("2d");
    const K = { S:"#ff6aa8", v:"#5aa7ff", a:"#ffa64d", cf:"#c3ccd6", obsA:"#5aa7ff", obsB:"rgba(243,239,230,.45)" };
    let W=0, H=0, dpr=1, run=false, raf=0, last=0, t=0, paused=false, rate=1;
    const OM = 1.25;
    function setup(){
      const r = cv.getBoundingClientRect(); dpr = Math.min(2, window.devicePixelRatio||1);
      W = Math.max(280, r.width); H = Math.max(170, r.height);
      cv.width = Math.round(W*dpr); cv.height = Math.round(H*dpr); ctx.setTransform(dpr,0,0,dpr,0,0);
    }
    function arr(x1,y1,x2,y2,col,lw,dash,dot){
      const dx=x2-x1, dy=y2-y1, L=Math.hypot(dx,dy); if(L<2) return;
      const ux=dx/L, uy=dy/L, h=Math.min(11, L*0.6);
      ctx.save(); ctx.strokeStyle=col; ctx.fillStyle=col; ctx.lineWidth=lw||2.6; ctx.lineCap="round";
      if(dash) ctx.setLineDash(dash);
      ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(x2-ux*h*0.8,y2-uy*h*0.8); ctx.stroke(); ctx.setLineDash([]);
      ctx.beginPath(); ctx.moveTo(x2,y2); ctx.lineTo(x2-ux*h-uy*h*0.5,y2-uy*h+ux*h*0.5); ctx.lineTo(x2-ux*h+uy*h*0.5,y2-uy*h-ux*h*0.5); ctx.closePath();
      if(dash){ ctx.fillStyle="#161a20"; ctx.fill(); ctx.lineWidth=1.8; ctx.stroke(); } else ctx.fill();
      if(dot){ ctx.beginPath(); ctx.arc(x1,y1,3,0,7); ctx.fillStyle=col; ctx.fill(); }
      ctx.restore();
      return {ux, uy, L};
    }
    function tick(x,y,ux,uy,n,col){
      ctx.save(); ctx.strokeStyle=col; ctx.lineWidth=2; for(let i=0;i<n;i++){ const d=(i-(n-1)/2)*4.6, cx=x+ux*d, cy=y+uy*d;
        ctx.beginPath(); ctx.moveTo(cx-uy*5.5,cy+ux*5.5); ctx.lineTo(cx+uy*5.5,cy-ux*5.5); ctx.stroke(); } ctx.restore();
    }
    function sym(s,x,y,col,size,sub){
      ctx.save(); ctx.fillStyle=col; ctx.textAlign="center"; ctx.textBaseline="middle"; ctx.font="italic "+size+"px "+MATH; ctx.fillText(s,x,y);
      if(sub){ const w=ctx.measureText(s).width; ctx.font=Math.round(size*0.7)+"px "+JP; ctx.textAlign="left"; ctx.fillText(sub,x+w/2+2,y+size*0.15); }
      ctx.restore();
    }
    function stick(x,y,ux,uy,s,col,lw){
      const px=-uy, py=ux, P=(du,dp)=>[x+ux*du*s+px*dp*s, y+uy*du*s+py*dp*s];
      ctx.save(); ctx.strokeStyle=col; ctx.lineWidth=lw; ctx.lineCap="round";
      const hip=P(.38,0), sh=P(.64,0), hd=P(.8,0);
      ctx.beginPath(); ctx.arc(hd[0],hd[1],s*.13,0,7); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(hip[0],hip[1]); ctx.lineTo(sh[0],sh[1]); ctx.stroke();
      const f1=P(0,-.17), f2=P(0,.17); ctx.beginPath(); ctx.moveTo(f1[0],f1[1]); ctx.lineTo(hip[0],hip[1]); ctx.lineTo(f2[0],f2[1]); ctx.stroke();
      const e1=P(.5,-.17), e2=P(.5,.17), h1=P(.38,-.12), h2=P(.38,.12);
      ctx.beginPath(); ctx.moveTo(h1[0],h1[1]); ctx.lineTo(e1[0],e1[1]); ctx.lineTo(sh[0],sh[1]); ctx.lineTo(e2[0],e2[1]); ctx.lineTo(h2[0],h2[1]); ctx.stroke();
      ctx.restore();
    }
    function text(s,x,y,col,size,al,bold){ ctx.save(); ctx.fillStyle=col; ctx.font=(bold?"700 ":"600 ")+size+"px "+JP; ctx.textAlign=al||"center"; ctx.textBaseline="middle"; ctx.fillText(s,x,y); ctx.restore(); }

    /* 1 枚ぶん。rot＝一緒に回る観測者から見るか。th＝小球の角（外から見た角） */
    function panel(x0, w, rot, th){
      const narrow = w < 330;
      const cx = x0 + w/2, cy = H*0.5, R = Math.min(w*0.26, H*0.27), rt = R*1.32;
      const view = rot? -th : 0;                         /* 絵全体を −θ 回す（非慣性系）。小球は右に止まる */
      const P = (ang, rr)=>[cx + rr*Math.cos(ang+view), cy - rr*Math.sin(ang+view)];
      /* 地面の方眼（パネル全体）：外から見ると止まっている。一緒に回る観測者から見ると、方眼全体が逆向きに回って見える */
      ctx.save(); ctx.beginPath(); ctx.rect(x0+2, 26, w-4, H-50); ctx.clip();
      ctx.translate(cx,cy); ctx.rotate(-view); ctx.lineWidth=1;
      const gs = R/2.5, ext = Math.hypot(w, H);
      const ext2 = Math.hypot(w, H)/2 + gs;                 /* パネルの外接円まで描けば足りる。線はまとめて 1 回で描く（軽くするため） */
      ctx.strokeStyle = "rgba(243,239,230,.10)"; ctx.beginPath();
      for(let k=-Math.ceil(ext2/gs); k<=Math.ceil(ext2/gs); k++){ if(k===0) continue; ctx.moveTo(k*gs,-ext2); ctx.lineTo(k*gs,ext2); ctx.moveTo(-ext2,k*gs); ctx.lineTo(ext2,k*gs); }
      ctx.stroke();
      ctx.strokeStyle = "rgba(243,239,230,.26)"; ctx.beginPath(); ctx.moveTo(0,-ext2); ctx.lineTo(0,ext2); ctx.moveTo(-ext2,0); ctx.lineTo(ext2,0); ctx.stroke();
      ctx.restore();
      /* 軌道 */
      ctx.save(); ctx.setLineDash([4,5]); ctx.strokeStyle="rgba(243,239,230,.25)"; ctx.beginPath(); ctx.arc(cx,cy,R,0,7); ctx.stroke(); ctx.restore();
      /* くぎ・糸・小球 */
      const b = P(th, R), rb = Math.max(7, R*0.11), ux = (b[0]-cx)/R, uy = (b[1]-cy)/R;
      ctx.strokeStyle="#c9a77a"; ctx.lineWidth=1.6; ctx.beginPath(); ctx.moveTo(cx,cy); ctx.lineTo(b[0]-ux*rb, b[1]-uy*rb); ctx.stroke();
      ctx.fillStyle="#f6f2e9"; ctx.beginPath(); ctx.arc(cx,cy,3.2,0,7); ctx.fill();
      const g = ctx.createRadialGradient(b[0]-rb*.35,b[1]-rb*.4,rb*.1,b[0],b[1],rb); g.addColorStop(0,"#fff"); g.addColorStop(.3,"#c9d3de"); g.addColorStop(1,"#56606c");
      ctx.fillStyle=g; ctx.beginPath(); ctx.arc(b[0],b[1],rb,0,7); ctx.fill();
      /* 力の矢印（同じ縮尺）：張力 S は糸のつく点から中心へ */
      const LS = R*0.62;
      const sA = [b[0]-ux*rb, b[1]-uy*rb];
      const aS = arr(sA[0], sA[1], sA[0]-ux*LS, sA[1]-uy*LS, K.S, 3.2, null, true);
      { const lt = [-Math.sin(th+view), -Math.cos(th+view)];      /* 進む向きのがわに書く（うしろがわには a がある） */
        sym("S", sA[0]-ux*LS*0.5 + lt[0]*15, sA[1]-uy*LS*0.5 + lt[1]*15, K.S, 17); }
      if(!rot){
        /* 速度（白抜き・小球の外がわに離して）・加速度（中心向き・うしろへずらす） */
        const tx = -uy, ty = ux;                             /* 画面での進む向き（左回り） */
        const vt = [-Math.sin(th+view), -Math.cos(th+view)];  /* d/dθ of (cos, −sin) */
        const ox = b[0]+ux*(rb+13), oy = b[1]+uy*(rb+13), Lv = R*0.75;
        arr(ox - vt[0]*Lv/2, oy - vt[1]*Lv/2, ox + vt[0]*Lv/2, oy + vt[1]*Lv/2, K.v, 2.6);
        sym("v", ox + vt[0]*(Lv/2+12) + ux*6, oy + vt[1]*(Lv/2+12) + uy*6, K.v, 17);
        const s0 = [b[0]-vt[0]*(rb+8), b[1]-vt[1]*(rb+8)];
        arr(s0[0], s0[1], s0[0]-ux*R*0.5, s0[1]-uy*R*0.5, K.a, 2.8);
        sym("a", s0[0]-ux*R*0.5 - vt[0]*12, s0[1]-uy*R*0.5 - vt[1]*12, K.a, 16);
        void tx; void ty;
      } else {
        /* 遠心力（見かけの力・破線）：作用点は小球の中心。S と同じ長さ → 等長マーク */
        arr(b[0], b[1], b[0]+ux*LS, b[1]+uy*LS, K.cf, 2.6, [6,4], true);
        text("遠心力", b[0]+ux*(LS+4), b[1]+uy*(LS+4) - 16, K.cf, narrow? 11 : 12.5, "center", true);
        const p1 = Math.min(LS*0.42, LS-13);
        tick(sA[0]-ux*p1, sA[1]-uy*p1, -ux, -uy, 1, K.S);
        tick(b[0]+ux*p1, b[1]+uy*p1, ux, uy, 1, K.cf);
      }
      /* 観測者：外の観測者は台の外（下）。非慣性系では回って見える */
      /* 頭の向き：外の観測者は「画面の上」（非慣性系では絵といっしょに回る）、一緒に回る観測者は「小球の角 + 90°」（非慣性系では画面の上） */
      const sz = narrow? 26 : 34;
      const oA = P(Math.PI*1.18, rt + 8), upA = [Math.cos(Math.PI/2+view), -Math.sin(Math.PI/2+view)];
      stick(oA[0], oA[1], upA[0], upA[1], sz, rot? K.obsB : K.obsA, rot? 1.6 : 2.4);
      /* 一緒に回る観測者：台の上、軌道のすぐ外・小球のうしろ。名前は足もとの下（矢印と重ならない） */
      const oB = P(th - 0.66, R*1.2), upB = [Math.cos(th+Math.PI/2+view), -Math.sin(th+Math.PI/2+view)];
      stick(oB[0], oB[1], upB[0], upB[1], sz*0.8, rot? K.obsA : K.obsB, rot? 2.4 : 1.6);
      if(!narrow){
        text("外の観測者", oA[0]-upA[0]*12, oA[1]-upA[1]*12, rot? "rgba(243,239,230,.45)" : K.obsA, 10.5, "center", !rot);
        text("一緒に回る観測者", oB[0]-upB[0]*12, oB[1]-upB[1]*12, rot? K.obsA : "rgba(243,239,230,.45)", 10.5, "center", rot);
      }
      /* 見出し（せまい画面では短く） */
      const T1 = narrow? (rot? "一緒に回る（非慣性系）" : "外から（慣性系）") : (rot? "一緒に回る観測者（非慣性系）から見る" : "外の観測者（慣性系）から見る");
      const T2 = narrow? (rot? "S と遠心力がつりあう" : "S が向心力") : (rot? "小球は止まって見える：S と遠心力がつりあう" : "小球は回り続ける：S が向心力（遠心力はない）");
      text(T1, cx, 16, "#f6f2e9", narrow? 11 : 13.5, "center", true);
      text(T2, cx, H-12, "rgba(243,239,230,.62)", narrow? 10 : 12, "center");
    }
    function draw(tt){
      ctx.clearRect(0,0,W,H);
      const th = OM*tt + 0.6, half = W/2;
      panel(0, half, false, th);
      ctx.save(); ctx.strokeStyle="rgba(255,255,255,.09)"; ctx.beginPath(); ctx.moveTo(half+.5, 10); ctx.lineTo(half+.5, H-10); ctx.stroke(); ctx.restore();
      panel(half, half, true, th);
    }
    function frame(ts){
      if(!run) return;
      const dtm = last? Math.min(0.05,(ts-last)/1000) : 0; last = ts;
      t += dtm*rate; draw(t);
      raf = requestAnimationFrame(frame);
    }
    function start(){ if(run || RM || paused) return; run = true; last = 0; raf = requestAnimationFrame(frame); }
    function stop(){ run = false; cancelAnimationFrame(raf); }
    setup(); draw(0);
    window.__hero = { frame:(tt)=>{ stop(); draw(tt); }, start, stop };
    let rz = 0; window.addEventListener("resize", ()=>{ clearTimeout(rz); rz = setTimeout(()=>{ setup(); draw(t); }, 120); });
    if("IntersectionObserver" in window){
      new IntersectionObserver((es)=>{ es.forEach(en=>{ (en.isIntersecting && !document.hidden)? start() : stop(); }); }, {threshold:0.05}).observe(cv);
    } else start();
    document.addEventListener("visibilitychange", ()=>{ if(document.hidden) stop(); else { const r=cv.getBoundingClientRect(); if(r.bottom>0 && r.top<innerHeight) start(); } });
    const ctl = document.querySelector("#hero .stagectl");
    if(ctl){
      const pp = ctl.querySelector(".pp"), sl = ctl.querySelector(".slow");
      if(sl){ if(RM) sl.hidden = true;
        sl.addEventListener("click", ()=>{ rate = (rate===1? 0.3 : 1); sl.setAttribute("aria-pressed", rate<1? "true" : "false"); }); }
      if(pp){ if(RM){ pp.hidden = true; }
        pp.addEventListener("click", ()=>{ paused = !paused; pp.classList.toggle("paused", paused); pp.setAttribute("aria-label", paused? "再生" : "一時停止");
          if(paused){ stop(); draw(t); } else { start(); } }); }
    }
    /* 図の再生を始めたら止める（同時に動くのは 1 つだけ） */
    document.addEventListener("click", (ev)=>{ if(ev.target.closest && ev.target.closest("button.b.play")) stop(); }, true);
  }

  /* スライドバーの塗り：値が変わったら --p を書きかえる（プログラムから値を入れたときも、軽い見回りで拾う） */
  function syncRange(el){ const mn = parseFloat(el.min)||0, mx = parseFloat(el.max), v = parseFloat(el.value);
    const p = (isFinite(mx) && mx>mn)? (v-mn)/(mx-mn)*100 : 0; const s = p.toFixed(1)+"%";
    if(el._p !== s){ el._p = s; el.style.setProperty("--p", s); } }
  function initRanges(){
    document.addEventListener("input", (ev)=>{ if(ev.target && ev.target.type === "range") syncRange(ev.target); }, true);
    const sweep = ()=>{ if(document.hidden) return; document.querySelectorAll(".mode.on input[type=range], .modebar input[type=range]").forEach(syncRange); alignTicks(); };
    sweep(); setInterval(sweep, 120);
  }

  /* スライドバーの下の目盛りの文字（e=0・e=0.5・e=1）を、つまみの位置にきっちり合わせる（第 29 回）
     文字の列を「左右の余白」で合わせていたので、ラベルやボタンの幅が変わるとずれていた。
     スライドバーの実際の位置と幅を測り、つまみの中心が来る位置に 1 つずつ置く（等間隔の目盛りとして） */
  function alignTicks(){
    document.querySelectorAll(".mode.on .vrow.ticks, .modebar .vrow.ticks").forEach(tr=>{
      let row = tr.previousElementSibling; while(row && !row.querySelector("input[type=range]")) row = row.previousElementSibling;
      const inp = row && row.querySelector("input[type=range]"); if(!inp) return;
      const ri = inp.getBoundingClientRect(); if(ri.width < 10) return;
      tr.classList.add("tk-on");
      const rt = tr.getBoundingClientRect(), TH = 9, sp = tr.children, n = sp.length;
      const key = Math.round(ri.left - rt.left)+":"+Math.round(ri.width); if(tr._tk === key) return; tr._tk = key;
      for(let i=0; i<n; i++){ const f = n>1? i/(n-1) : 0.5; sp[i].style.left = (ri.left - rt.left + TH + f*(ri.width - 2*TH)).toFixed(1)+"px"; }
    });
  }
  window.addEventListener("resize", ()=>{ document.querySelectorAll(".vrow.ticks").forEach(t=>{ t._tk = null; }); alignTicks(); });

  /* タブ列の下の進み具合 */
  function initProgress(){
    const nav = document.getElementById("tabs"); if(!nav) return;
    let pend = false;
    const upd = ()=>{ pend = false; const h = document.documentElement, max = h.scrollHeight - innerHeight;
      nav.style.setProperty("--prog", max>0? Math.min(1, Math.max(0, scrollY/max)).toFixed(4) : 0); };
    window.addEventListener("scroll", ()=>{ if(!pend){ pend = true; requestAnimationFrame(upd); } }, {passive:true});
    window.addEventListener("resize", upd); upd();
  }

  /* ヒーローの 3 つの要点：その章を開いて、本文の頭までスクロール */
  function initIdeas(){
    document.querySelectorAll("#hero .ideas a").forEach(a=>{
      a.addEventListener("click", (ev)=>{ ev.preventDefault(); const id = a.getAttribute("href").slice(1);
        if(typeof activateMode === "function") activateMode(id);
        history.replaceState(null, "", "#"+id);
        window.scrollTo({top: (typeof contentTop === "function"? contentTop() : 0), behavior:"auto"}); });
    });
  }

  /* 「■ 見出し」の ■ を、色のついた小さな四角にする（文字の■は環境で形がばらつく） */
  function decorate(root){
    if(!root) return;
    root.querySelectorAll(".gtitle span, .stagetitle, .ttl, .mt").forEach(el=>{
      if(el.dataset.sq) return; const n = el.firstChild;
      if(n && n.nodeType === 3 && /^\s*■\s*/.test(n.nodeValue)){ n.nodeValue = n.nodeValue.replace(/^\s*■\s*/, ""); const i = document.createElement("i"); i.className = "sq"; i.setAttribute("aria-hidden","true"); el.insertBefore(i, n); }
      el.dataset.sq = "1";
    });
  }
  function initDecorate(){
    if(typeof activateMode !== "function") return;
    const orig = activateMode;
    const showTab = ()=>{ const row = document.querySelector("#tabs .tabs-in"), on = row && row.querySelector(".tab.on"); if(!on || row.scrollWidth <= row.clientWidth) return;
      const l = on.offsetLeft - 24, r = on.offsetLeft + on.offsetWidth + 24;
      if(l < row.scrollLeft) row.scrollLeft = l; else if(r > row.scrollLeft + row.clientWidth) row.scrollLeft = r - row.clientWidth; };   // スマホ：選んだタブが見えるように横に送る
    const cur = ()=>document.querySelectorAll("#tabs .tab").forEach(b=>{ if(b.classList.contains("on")) b.setAttribute("aria-current","page"); else b.removeAttribute("aria-current"); });
    activateMode = function(id){ const r = orig.apply(this, arguments); decorate(document.getElementById(id)); showTab(); cur(); return r; };   // 章を開いたあと（シムは初めて開いたときに作られる）
    showTab(); cur();
    document.querySelectorAll(".mode.on").forEach(decorate);
  }
  /* タブ列：ヒーローを過ぎたら .stuck */
  function initStuck(){
    const hero = document.getElementById("hero"), nav = document.getElementById("tabs"); if(!hero || !nav || !("IntersectionObserver" in window)) return;
    new IntersectionObserver((es)=>{ es.forEach(en=>nav.classList.toggle("stuck", !en.isIntersecting)); }, {threshold:0}).observe(hero);
    const nb = nav.querySelector(".navbrand"); if(nb) nb.addEventListener("click", (ev)=>{ ev.preventDefault(); window.scrollTo({top:0, behavior:"auto"}); });
  }
  /* フッター：題名と章の目次 */
  function initFooter(){
    const f = document.querySelector("#wrap footer") || document.querySelector("body > footer"); if(!f) return;
    document.body.appendChild(f);
    const C = "①②③④⑤⑥⑦⑧⑨";
    const items = (typeof MODES !== "undefined"? MODES : []).map((m,i)=>'<li><a href="#'+m.id+'" data-mode="'+m.id+'"><b>'+C[i]+'</b>'+m.name+'</a></li>').join("");
    f.innerHTML = '<div class="ft-in"><p class="ft-mark">Circular Motion<span>円運動 〜外から見るか、一緒に回って見るか〜</span></p>'+
      '<ul class="ft-nav">'+items+'</ul>'+
      '<div class="ft-base"><span><a class="ft-home" href="'+SITE_HOME+'">⌂ 楽楽（らくらく）高校物理 トップページ</a>　／　高校物理 ・ 力学</span><span class="ft-r"><button type="button" class="ft-pages">ほかのページ一覧</button><a href="#top" class="ft-top">▲ ページの一番上へ</a></span></div></div>';
    f.querySelectorAll("a[data-mode]").forEach(a=>a.addEventListener("click", (ev)=>{ ev.preventDefault(); const id = a.dataset.mode;
      activateMode(id); history.replaceState(null, "", "#"+id); window.scrollTo({top:(typeof contentTop==="function"? contentTop() : 0), behavior:"auto"}); }));
    const fp = f.querySelector(".ft-pages"); if(fp) fp.addEventListener("click", ()=>{ if(window.SITENAV) window.SITENAV.open(); });
    const tp = f.querySelector(".ft-top"); if(tp) tp.addEventListener("click", (ev)=>{ ev.preventDefault(); window.scrollTo({top:0, behavior:"auto"}); });
  }

  document.addEventListener("DOMContentLoaded", ()=>{
    initFooter(); initDecorate(); initStage(); initRanges(); initProgress(); initIdeas(); initStuck();
  });
})();

