/* =========================================================================
   70_mode3.js … モード3「等速ではない円運動」（鉛直面内の円運動。2 次元の図）
   ・軌道は 30_physics.js の M3 で前もって計算（図・式・グラフが同じ点を見る）。
   ・非慣性系＝「一緒に円運動する観測者」は、小球に乗っている人。絵全体を −（小球の角）回して、小球を画面の決まった場所に止める。
     重力は「ほんとうの下」なので、回した絵の中では傾いて見える。
   ・非慣性系では遠心力 m v²/r と、接線方向の慣性力 −m a_t（速さが変わるため）を描く（2026-10 千葉さん：案 C。注釈つき）。
   ・はなれた／糸がたるんだあとは、観測者は円運動をやめるので、絵の回転はその瞬間の角で止める。
   ========================================================================= */
'use strict';
var M3CFG = {
  1: { box: { x0: -1.55, x1: 0.80, y0: -0.82, y1: 0.62 }, ref: 0, sgn: -1, surf: 'in', fName: 'N', fCol: '#7b3fd4' },
  2: { box: { x0: -0.95, x1: 1.45, y0: -0.10, y1: 0.80 }, ref: 0, sgn: 1, surf: 'out', fName: 'N', fCol: '#7b3fd4' },
  3: { box: { x0: -1.05, x1: 1.05, y0: -0.86, y1: 0.62 }, ref: Math.PI / 2, sgn: -1, surf: 'str', fName: 'S', fCol: '#c2367f' },
  /* モード4（2026-10-05）：gs＝形が同じセクション（4-1 は 3-1 と同じ内がわの面・1 周ぶん、4-2 は 3-3 と同じ糸・最下点から） */
  4: { box: { x0: -1.55, x1: 1.20, y0: -0.82, y1: 0.62 }, ref: 0, sgn: -1, surf: 'in', fName: 'N', fCol: '#7b3fd4', gs: 1 },
  5: { box: { x0: -1.05, x1: 1.05, y0: -0.86, y1: 0.62 }, ref: 0, sgn: -1, surf: 'str', fName: 'S', fCol: '#c2367f', gs: 3 }
};
function m3GS(sec) { return M3CFG[sec].gs || sec; }
var M3RB = 0.045;
var M3SNAPBOX = { 1: { x0: -0.72, x1: 0.72, y0: -0.60, y1: 0.62 }, 2: { x0: -0.70, x1: 1.30, y0: -0.04, y1: 1.02 }, 3: { x0: -0.72, x1: 0.72, y0: -0.74, y1: 0.62 },
  4: { x0: -0.72, x1: 0.72, y0: -0.60, y1: 0.62 }, 5: { x0: -0.72, x1: 0.72, y0: -0.70, y1: 0.66 } };
function m3Tr(s) { return M3.traj(s.def.sec, s.v.v0); }
function m3Base(o) {
  var d = Object.assign({
    mode: 'mode3', belowCanvas: true, strobe: false, views: null, baseRate: 1 / 3, trailSec: 0.6,   /* モード3 はふだん 1/3 の速さ（スローはさらに 0.3 倍） */
    height: function (s, w) { return Math.round(clamp(w * 0.72, 320, 480)); }
  }, o);
  var init0 = d.init;
  d.init = function (s) { if (s.rot === undefined) s.rot = !!modeState(d.mode).rot; if (init0) init0(s); };
  d.buttons = [
    { k: 'obsIn', label: '外（慣性系）から見る', cls: 'obs', seg: 'obs', segLabel: 'どの観測者から見るか', onClick: function (s) { m2SetRot(s, false); } },
    { k: 'obsRot', label: '一緒に円運動する観測者（非慣性系）から見る', cls: 'obs rotb', seg: 'obs', onClick: function (s) { m2SetRot(s, true); } },
    /* 「離れる瞬間」「たるむ瞬間」：その少し前から少しあとまでを、とてもゆっくり再生（momentum-and-collision の「傾く瞬間」と同じ考え） */
    { k: 'inst', inPlay: true, label: (m3GS(d.sec) === 3 ? '⏱ たるむ瞬間' : '⏱ 離れる瞬間') + '<br>をスローで', cls: 'instb two', onClick: function (s) { m3PlayInstant(s); } }
  ];
  d.onWindow = function (s, on) { if (s.extra.inst) s.extra.inst.classList.toggle('on', on); };
  d.tEnd = function (s) { return m3Tr(s).tEnd; };
  d.onChanged = function () { return 'stop'; };                 /* v0 を変えたら最初にもどす（2026-10-04 千葉さん） */
  d.below = function (s) { m2EqBox(s, d.eqs(s, M3.at(m3Tr(s), s.t))); };
  d.afterBuild = function (s) { m3BuildSnaps(s); m2SetRot(s, s.rot); };
  d.onResize = function (s) { m3DrawSnaps(s); };
  d.draw = function (s, ctx, W, H) { drawM3(s, ctx, W, H); };
  var right0 = d.right;
  d.right = function (s, R) {
    var tr = m3Tr(s);
    if (s.extra && s.extra.inst) {                              /* この v0 では起きない：横線を引いて「できない」ことを見せる */
      s.extra.inst.classList.toggle('nope', !tr.ev);
      s.extra.inst.title = tr.ev ? '' : 'いまの初速では' + (m3GS(d.sec) === 3 ? '糸はたるまない' : '面から離れない');
      s.extra.inst.setAttribute('aria-disabled', tr.ev ? 'false' : 'true');
    }
    m3DrawSnaps(s);
    /* グラフを右の列のいちばん上に置く（アニメとグラフを横に並べて見せる授業のため）。その下に立式と理論的背景 */
    R.innerHTML = '';
    var gh = el('div', 'gwrap'); R.appendChild(gh);
    R.insertAdjacentHTML('beforeend', mathify(right0(s, tr)));
    var dt = R.querySelector('details.theory');
    if (dt) dt.addEventListener('toggle', function () { s.theoryClosed = !dt.open; });
    var C = M3CFG[d.sec], fn = C.fName;
    m3Graphs(s, gh, [
      { key: 'F', title: (fn === 'N' ? '垂直抗力 $N$' : '糸の張力 $S$') + ' – 時刻 $t$', ylab: fn + '〔N〕',
        series: [{ name: (fn === 'N' ? '垂直抗力 $N$' : '張力 $S$'), color: C.fCol, width: 2.4, f: function (p) { return p.F; }, gap: true }],
        hlines: [{ y: M3.m * G, color: COL.force, name: '重力 $mg$' }],
        sel: function (p) { return 't = ' + fmt(p.t, 2) + ' s、' + fn + ' = ' + fmt(p.F, 2) + ' N'; } },
      { key: 'E', title: 'エネルギー – 時刻 $t$', ylab: 'E〔J〕',
        series: [{ name: '力学的エネルギー $E$', color: GCOL.E, width: 3.2, f: function (p) { return p.E; } },
                 { name: '位置エネルギー $U$', color: GCOL.U, width: 2, dash: [7, 4], f: function (p) { return p.U; } },
                 { name: '運動エネルギー $K$', color: GCOL.K, width: 2, f: function (p) { return p.K; } }],
        sel: function (p) { return 't = ' + fmt(p.t, 2) + ' s、K = ' + fmt(p.K, 2) + ' J、U = ' + fmt(p.U, 2) + ' J、E = ' + fmt(p.E, 2) + ' J'; } }
    ], tr);
    m3DrawGraphs(s);
  };
  d.live = function (s) { m3DrawGraphs(s); };
  return d;
}
/* 離れる／たるむ瞬間の前後 M3WIN 秒（シミュレーションの時間）を、ふだんの M3WIN.rate 倍の速さで再生 */
var M3WIN = { pre: 0.16, post: 0.16, rate: 0.05 };
function m3PlayInstant(s) {
  var tr = m3Tr(s);
  if (!tr.ev) {                                                    /* この v0 では離れない・たるまない */
    s.msg.innerHTML = mathify('<b>いまの $v_0$ では' + (m3GS(s.def.sec) === 3 ? '糸はたるまない' : '面から離れない') + '。</b>' +
      (s.def.sec === 3 ? '$0 < v_0 < \\sqrt{3gr}$ にしてから、もう一度押そう。' : (s.def.sec === 2 ? '$v_0$ を変えてからもう一度押そう。' : '$\\sqrt{2gr} < v_0 < \\sqrt{5gr}$ にしてから、もう一度押そう。')));
    s.lastMsg = null; return;
  }
  var te = tr.ev.t;
  s.playWindow(Math.max(0, te - M3WIN.pre), Math.min(tr.tEnd, te + M3WIN.post), M3WIN.rate, null);
}
/* 状態のひとこと */
function m3Phase(q, tr) {
  if (q.kind === 'floor') return '床の上を等速で進む';
  if (q.kind === 'fly') return tr.ev.kind === 'slack' ? '糸がたるんで放物運動' : (tr.ev.kind === 'top' ? '最高点から飛び出して放物運動' : '面から離れて放物運動');
  return '円運動（速さが変わる）';
}

/* ---------- 3-2 ループコースター（3 次元。2026-10-06 千葉さん） ----------
   ループはらせんのように 1 周で奥へ w だけずれる（入口のレールは手前、出口のレールは奥。真横から見ると今までの円と同じ）。
   z は手前が正。床の面は |z| ≤ floorZ。レールの幅は 2hw（z の向き） */
var M3LOOP = { w: 0.36, hw: 0.035, floorZ: 0.42, side: { az: 0, el: 0 }, obl: { az: -28, el: 30 } };
function m3LoopZc(a) { return M3LOOP.w / 2 - M3LOOP.w * clamp(a / TAU, 0, 1); }
function m3LoopZ(q, tr) {
  if (q.kind === 'floor') return q.x > 1e-3 ? -M3LOOP.w / 2 : M3LOOP.w / 2;
  if (q.kind === 'fly') return m3LoopZc(tr.ev.ang);
  return m3LoopZc(q.ang);
}
function m3DrawLoop3D(ctx, P, R, floorY, fx0, fx1) {
  var L = M3LOOP, ZF = L.floorZ, hw = L.hw;
  /* 床の面（方眼） */
  var c4 = [P(fx0, floorY, ZF), P(fx1, floorY, ZF), P(fx1, floorY, -ZF), P(fx0, floorY, -ZF)];
  ctx.save(); ctx.beginPath(); c4.forEach(function (p, i) { i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y); }); ctx.closePath();
  ctx.fillStyle = '#f1ece2'; ctx.fill(); ctx.strokeStyle = '#b9b0a0'; ctx.lineWidth = 1.2; ctx.stroke(); ctx.clip();
  ctx.strokeStyle = 'rgba(160,150,132,.35)'; ctx.lineWidth = 1;
  for (var gx = Math.ceil(fx0 / 0.1) * 0.1; gx <= fx1 + 1e-9; gx += 0.1) { var a = P(gx, floorY, ZF), b = P(gx, floorY, -ZF); ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); }
  for (var gz = -ZF; gz <= ZF + 1e-9; gz += 0.1) { var a2 = P(fx0, floorY, gz), b2 = P(fx1, floorY, gz); ctx.beginPath(); ctx.moveTo(a2.x, a2.y); ctx.lineTo(b2.x, b2.y); ctx.stroke(); }
  ctx.restore();
  /* レール（面の帯）：入口（手前）→ ループ → 出口（奥） */
  var pts = [];
  var nIn = 24; for (var i = 0; i <= nIn; i++) pts.push([fx0 + (0 - fx0) * i / nIn, floorY, L.w / 2]);
  var nL = 144; for (var k = 1; k <= nL; k++) { var an = TAU * k / nL; pts.push([R * Math.sin(an), -R * Math.cos(an), m3LoopZc(an)]); }
  var nOut = 20; for (var j = 1; j <= nOut; j++) pts.push([fx1 * j / nOut, floorY, -L.w / 2]);
  ctx.save(); ctx.lineJoin = 'round';
  for (var m = 1; m < pts.length; m++) {                         /* 帯（うす水色、半透明） */
    var p0 = pts[m - 1], p1 = pts[m], a0 = P(p0[0], p0[1], p0[2] + hw), a1 = P(p1[0], p1[1], p1[2] + hw), b1 = P(p1[0], p1[1], p1[2] - hw), b0 = P(p0[0], p0[1], p0[2] - hw);
    ctx.beginPath(); ctx.moveTo(a0.x, a0.y); ctx.lineTo(a1.x, a1.y); ctx.lineTo(b1.x, b1.y); ctx.lineTo(b0.x, b0.y); ctx.closePath();
    ctx.fillStyle = 'rgba(205,220,232,.55)'; ctx.fill();
  }
  ctx.strokeStyle = 'rgba(70,82,96,.35)'; ctx.lineWidth = 1;    /* 横木（立体に見えるように） */
  for (var t = 0; t < pts.length; t += 4) { var e0 = P(pts[t][0], pts[t][1], pts[t][2] + hw), e1 = P(pts[t][0], pts[t][1], pts[t][2] - hw); ctx.beginPath(); ctx.moveTo(e0.x, e0.y); ctx.lineTo(e1.x, e1.y); ctx.stroke(); }
  [hw, -hw].forEach(function (dz) {                              /* 両はしの線 */
    ctx.strokeStyle = '#3f4a56'; ctx.lineWidth = 1.7; ctx.beginPath();
    pts.forEach(function (p, n) { var u = P(p[0], p[1], p[2] + dz); n ? ctx.lineTo(u.x, u.y) : ctx.moveTo(u.x, u.y); }); ctx.stroke();
  });
  ctx.restore();
  var lb = P(R * 0.95, R * 0.62, m3LoopZc(Math.PI * 0.7)); label(ctx, 'なめらかなループ面', lb.x + 8, lb.y - 4, { size: 11, color: COL.sub, halo: false, align: 'left' });
}
/* 見る向き：いまの値（動かしている途中なら補間）と、なめらかに動かす */
function m3CamNow(s) {
  var A = s.camAnim; if (!A) return s.cam3;
  var k = clamp((performance.now() - A.t0) / A.dur, 0, 1), e = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
  s.cam3 = { az: A.from.az + (A.to.az - A.from.az) * e, el: A.from.el + (A.to.el - A.from.el) * e };
  if (k >= 1) s.camAnim = null;
  return s.cam3;
}
function m3CamGo(s, to, dur) {
  var from = m3CamNow(s) || to;
  s.camAnim = { from: { az: from.az, el: from.el }, to: { az: to.az, el: to.el }, t0: performance.now(), dur: dur || 900 };
  var tick = function () { if (!s.camAnim) { s.draw(); return; } if (!s.playing) s.draw(); requestAnimationFrame(tick); };
  requestAnimationFrame(tick);
}
function m3ToSide(s) { var c = m3CamNow(s); if (Math.abs(c.az) > 0.2 || c.el > 0.2) { m3CamGo(s, M3LOOP.side, 900); m3CamBtns(s, 1); } }
function m3CamBtns(s, i) { (s.vbtns || []).forEach(function (b, j) { b.classList.toggle('on', j === i); }); }

/* ===================== 図（3 セクション共通） ===================== */
function drawM3(s, ctx, W, H) {
  var sec = s.def.sec, GS = m3GS(sec), C = M3CFG[sec], tr = m3Tr(s), q = M3.at(tr, s.t), R = M3.R, m = M3.m, rb = M3RB, SN = !!s._snap, showF = SN || s.ms.showF;   /* SN：左下のコマ図を描いているとき（観測者・吹き出し・デコピンは描かない） */
  if (!SN && !s._snapKey) m3DrawSnaps(s);                       /* コマ図がまだなら（画面の外で幅がとれなかったとき）ここで描く */
  /* 絵の回転：小球の角（はなれたあとはその瞬間の角）だけ回す */
  var al = s.rot ? C.sgn * (q.ang - C.ref) : 0, ca = Math.cos(al), sa = Math.sin(al);
  var B = SN ? M3SNAPBOX[sec] : C.box, mg = SN ? { t: 8, b: 6, x: 6 } : { t: 40, b: 16, x: 10 };   /* コマ図は小球のまわりだけを大きく */
  /* 3-2（sec 4）：3 次元のループコースター。s.cam3＝{az, el}（度）。真横（0, 0）なら今までの 2 次元の図と同じ */
  var cam = (sec === 4 && !SN && s.cam3) ? m3CamNow(s) : null, D3 = !!cam && (Math.abs(cam.az) > 0.2 || cam.el > 0.2);
  var caz = 1, saz = 0, cel = 1, sel = 0;
  if (D3) { caz = Math.cos(cam.az * Math.PI / 180); saz = Math.sin(cam.az * Math.PI / 180); cel = Math.cos(cam.el * Math.PI / 180); sel = Math.sin(cam.el * Math.PI / 180); }
  var pj0 = function (X, Y, z) { if (!D3) return [X, Y]; var x1 = X * caz + z * saz, z1 = -X * saz + z * caz; return [x1, Y * cel - z1 * sel]; };   /* z は手前が正 */
  var S, ox, oy;
  if (!D3) { S = Math.min((W - 2 * mg.x) / (B.x1 - B.x0), (H - mg.t - mg.b) / (B.y1 - B.y0)); ox = W / 2 - S * (B.x0 + B.x1) / 2; oy = mg.t + (H - mg.t - mg.b) / 2 + S * (B.y0 + B.y1) / 2; }
  else {                                                         /* 見る向きを変えても、全体が図に入るように */
    var bb = [1e9, -1e9, 1e9, -1e9], ZF = M3LOOP.floorZ;
    [[B.x0, B.y0, 0], [B.x1, B.y0, 0], [B.x0, B.y1, 0], [B.x1, B.y1, 0], [B.x0, -R, ZF], [B.x1, -R, ZF], [B.x0, -R, -ZF], [B.x1, -R, -ZF], [0, R + 0.12, M3LOOP.w / 2], [0, R + 0.12, -M3LOOP.w / 2]].forEach(function (p3) {
      var u = pj0(p3[0], p3[1], p3[2]); bb[0] = Math.min(bb[0], u[0]); bb[1] = Math.max(bb[1], u[0]); bb[2] = Math.min(bb[2], u[1]); bb[3] = Math.max(bb[3], u[1]); });
    S = Math.min((W - 2 * mg.x) / (bb[1] - bb[0]), (H - mg.t - mg.b) / (bb[3] - bb[2])); ox = W / 2 - S * (bb[0] + bb[1]) / 2; oy = mg.t + (H - mg.t - mg.b) / 2 + S * (bb[2] + bb[3]) / 2;
  }
  var zb = D3 ? m3LoopZ(q, tr) : 0;                              /* 小球のいる奥行き（ループはらせんのように少しずつ奥へ） */
  var P = function (x, y, z) { var X = x * ca - y * sa, Y = x * sa + y * ca, u = pj0(X, Y, z === undefined ? zb : z); return { x: ox + S * u[0], y: oy - S * u[1] }; };
  var Vd = function (vx, vy) { return { x: vx * ca - vy * sa, y: -(vx * sa + vy * ca) }; };   /* 物理の向き → 画面の向き */
  var O = P(0, 0);
  ctx.fillStyle = '#fbfaf6'; ctx.fillRect(0, 0, W, H);
  /* 小球の中心（物理の点を、面の外がわ／内がわへ半径ぶんずらす） */
  var offOf = function (p) {
    if (GS === 3) return [0, 0];
    if (p.kind === 'floor') return [0, rb];
    var a = (p.kind === 'fly') ? tr.ev.ang : p.ang;
    if (GS === 1) return [-Math.sin(a) * rb, Math.cos(a) * rb];     /* 内がわ（中心向き） */
    return [Math.sin(a) * rb, Math.cos(a) * rb];                      /* 外がわ */
  };
  var of = offOf(q), bx = q.x + of[0], by = q.y + of[1], Bp = P(bx, by);
  /* ---- 背景：床・円筒面・人 ---- */
  var line = function (x1, y1, x2, y2, col, lw, dash) { var a = P(x1, y1), b = P(x2, y2); ctx.save(); ctx.strokeStyle = col; ctx.lineWidth = lw || 1.6; if (dash) ctx.setLineDash(dash); ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); ctx.restore(); };
  var hatch = function (pts, nx, ny) {                       /* 面の裏がわの斜線（物理の点の列と、裏がわの向き） */
    ctx.save(); ctx.strokeStyle = '#a9a193'; ctx.lineWidth = 1;
    pts.forEach(function (p, i) { if (i % 2) return; var a = P(p[0], p[1]), n = (nx !== undefined) ? [nx, ny] : p[2], b = P(p[0] + n[0] * 0.035 - (n[1]) * 0.02, p[1] + n[1] * 0.035 + n[0] * 0.02); ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); });
    ctx.restore();
  };
  var floorY = GS === 1 ? -R : (GS === 2 ? 0 : -0.80), fx0 = GS === 2 ? -0.95 : (GS === 1 ? -1.55 : -1.12), fx1 = sec === 4 ? 1.20 : (GS === 2 ? 1.45 : (GS === 1 ? 0 : 1.12));   /* 4-1 は右へ出ていく床もある */
  var fpts = []; for (var xx = fx0; xx <= fx1 + 1e-9; xx += 0.035) fpts.push([xx, floorY]);
  if (D3) m3DrawLoop3D(ctx, P, R, floorY, fx0, fx1);           /* 3-2 の 3 次元：床の面とループコースターのレール */
  else { hatch(fpts, 0, -1); line(fx0, floorY, fx1, floorY, '#2b323c', 1.8); }
  if (D3) {
    ctx.save(); ctx.fillStyle = '#2b323c'; ctx.beginPath(); ctx.arc(O.x, O.y, 2.6, 0, TAU); ctx.fill(); ctx.restore();
  } else if (GS === 1) {                                            /* 円筒面（内がわを走る）：円＋外がわの斜線 */
    /* 3-1：最下点から右がわを通って最高点まで（最高点の左には面がない）。4-1：1 周ぶん（ループ） */
    var aSp = sec === 4 ? TAU : Math.PI;
    var cp = []; for (var k = 0; k <= 90; k++) { var a = -Math.PI / 2 + aSp * k / 90; cp.push([R * Math.cos(a), R * Math.sin(a), [Math.cos(a), Math.sin(a)]]); }
    /* 斜線の間かくは床とそろえる（床は 0.035 m ごとの点の 1 つおき＝0.07 m）。円周 πR を同じ間かくで */
    var hp = [], nH = Math.round(aSp * R / 0.035);
    for (var kh = 0; kh <= nH; kh++) { var ah = -Math.PI / 2 + aSp * kh / nH; hp.push([R * Math.cos(ah), R * Math.sin(ah), [Math.cos(ah), Math.sin(ah)]]); }
    hatch(hp);
    ctx.save(); ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 2; ctx.beginPath(); cp.forEach(function (q2, i) { var pp = P(q2[0], q2[1]); i ? ctx.lineTo(pp.x, pp.y) : ctx.moveTo(pp.x, pp.y); }); ctx.stroke(); ctx.restore();
    ctx.save(); ctx.fillStyle = '#2b323c'; ctx.beginPath(); ctx.arc(O.x, O.y, 2.6, 0, TAU); ctx.fill(); ctx.restore();
    label(ctx, '中心', O.x - 6, O.y - 2, { size: 10.5, color: COL.sub, align: 'right' });
    var lb1 = P(R * 0.95, R * 0.62); label(ctx, sec === 4 ? 'なめらかなループ面' : 'なめらかな円筒面', lb1.x + 6, lb1.y - 4, { size: 11, color: COL.sub, halo: false, align: 'left' });
    if (s.mode === 'mode4') {                                     /* 4-1：最高点の印（スタート前から最後まで。2026-10-06 千葉さん） */
      var tp4 = P(0, R); ctx.save(); ctx.fillStyle = '#d1352b'; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(tp4.x, tp4.y, 4, 0, TAU); ctx.fill(); ctx.stroke(); ctx.restore();
      label(ctx, '最高点', tp4.x - 8, tp4.y - 12, { size: 11.5, bold: true, color: '#b2271b', align: 'right' });
    }
  } else if (GS === 2) {                                      /* 半円柱（外がわを走る） */
    ctx.save(); ctx.beginPath(); for (var k2 = 0; k2 <= 90; k2++) { var a2 = Math.PI * k2 / 90, pp = P(R * Math.cos(a2), R * Math.sin(a2)); k2 ? ctx.lineTo(pp.x, pp.y) : ctx.moveTo(pp.x, pp.y); }
    ctx.closePath(); ctx.fillStyle = '#e8e1d3'; ctx.fill(); ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 2; ctx.stroke(); ctx.restore();
    var lp = P(-R * 0.55, R * 0.35); label(ctx, 'なめらかな円筒面', lp.x, lp.y, { size: 11, color: COL.sub, halo: false });
  } else {                                                   /* 糸：中心の手。円の道すじ（破線） */
    ctx.save(); ctx.setLineDash([5, 5]); ctx.strokeStyle = '#8a929c'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(O.x, O.y, R * S, 0, TAU); ctx.stroke(); ctx.restore();
  }
  if (s.mode === 'mode4' && GS === 3 && !SN) {                    /* 4-2：最高点の印（4-1 と同じ。2026-10-07 千葉さん） */
    var tq4 = P(0, R); ctx.save(); ctx.fillStyle = '#d1352b'; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(tq4.x, tq4.y, 4, 0, TAU); ctx.fill(); ctx.stroke(); ctx.restore();
    label(ctx, '最高点', tq4.x - 8, tq4.y - 12, { size: 11.5, bold: true, color: '#b2271b', align: 'right' });
  }
  /* 外の観測者（床の上に立つ） */
  var hdIn;
  var up = function (foot, h, z) { var a = P(foot[0], foot[1], z), b = P(foot[0], foot[1] + h, z); var L = Math.hypot(b.x - a.x, b.y - a.y); return { a: a, ux: (b.x - a.x) / L, uy: (b.y - a.y) / L, L: L }; };
  if (GS === 3) {                                            /* 糸の一端は支柱の上のくぎ（中心）。支柱は奥にあるので、うすく描く */
    var pb = P(0, floorY), pt = P(0, -0.02);
    ctx.save(); ctx.strokeStyle = 'rgba(122,110,92,.55)'; ctx.lineWidth = 6; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(pb.x, pb.y); ctx.lineTo(pt.x, pt.y); ctx.stroke(); ctx.restore();
    ctx.save(); ctx.fillStyle = '#2b323c'; ctx.beginPath(); ctx.arc(O.x, O.y, 4, 0, TAU); ctx.fill(); ctx.restore();
    var fo3 = [-0.86, floorY], uo3 = up(fo3, 0.40);
    if (!SN) hdIn = observer(ctx, uo3.a.x, uo3.a.y, uo3.ux, uo3.uy, '外の観測者', !s.rot, uo3.L, { dy: 2 });
  } else {
    var fo = GS === 1 ? [-1.05, floorY] : [-0.72, floorY], uo = up(fo, 0.40, D3 ? 0.20 : 0);
    if (!SN) hdIn = observer(ctx, uo.a.x, uo.a.y, uo.ux, uo.uy, '外の観測者', !s.rot, uo.L, { dy: 2 });
  }
  /* 基準の線（中心から最下点／最高点へ）と、半径・角 θ（円の上にいるとき） */
  var refUp = GS === 2;
  if (q.kind === 'circle' || q.kind === 'fly') {
    line(0, 0, 0, refUp ? R * 1.0 : -R * 1.0, '#6f7782', 1.1, [4, 4]);
    var aNow = q.kind === 'fly' ? tr.ev.ang : q.ang, pr = GS === 2 ? [R * Math.sin(aNow), R * Math.cos(aNow)] : [R * Math.sin(aNow), -R * Math.cos(aNow)];
    if (q.kind === 'circle') line(0, 0, pr[0], pr[1], GS === 3 ? '#7a5a32' : '#6f7782', GS === 3 ? 1.8 : 1.1, GS === 3 ? null : [3, 3]);
    var an = aNow >= 0 ? aNow % TAU : -((-aNow) % TAU), aa = Math.abs(an);   /* θ は 180° を超えてもそのまま（0〜360°。1 周したら 0 から。2026-10-07 千葉さん） */
    if (aa > 0.15) {                                         /* 角 θ（基準線から、いまの半径まで） */
      var rA = 0.13, st0 = refUp ? Math.PI / 2 : -Math.PI / 2, a3 = (GS === 2 ? -1 : 1) * an;
      ctx.save(); ctx.strokeStyle = COL.ink2; ctx.lineWidth = 1.2; ctx.beginPath();
      for (var j = 0; j <= 24; j++) { var aj = st0 + a3 * j / 24, pj = P(rA * Math.cos(aj), rA * Math.sin(aj)); j ? ctx.lineTo(pj.x, pj.y) : ctx.moveTo(pj.x, pj.y); }
      ctx.stroke(); ctx.restore();
      var am = st0 + a3 / 2, pm = P((rA + 0.07) * Math.cos(am), (rA + 0.07) * Math.sin(am)); sym(ctx, 'θ', pm.x, pm.y, { size: 15 });
    }
    if (GS !== 3 && q.kind === 'circle') { var rl = P(pr[0] * 0.55 + 0.04, pr[1] * 0.55 + 0.04); sym(ctx, 'r', rl.x, rl.y, { size: 15 }); }
    if (GS === 3 && q.kind === 'circle') { var rl3 = P(pr[0] * 0.5 + (pr[1] >= 0 ? 0.05 : -0.05), pr[1] * 0.5 + 0.05); sym(ctx, 'r', rl3.x, rl3.y, { size: 15 }); }
  }
  /* はなれた点と、そのあとの道すじ */
  if (tr.ev && s.t >= tr.ev.t) {
    var e = M3.at(tr, tr.ev.t), eo = offOf(e), ep = P(e.x + eo[0], e.y + eo[1]);
    ctx.save(); ctx.setLineDash([6, 4]); ctx.strokeStyle = COL.vel; ctx.globalAlpha = 0.75; ctx.lineWidth = 1.6; ctx.beginPath();
    var fst = true; tr.pts.forEach(function (p) { if (p.t < tr.ev.t || p.t > s.t) return; var o2 = offOf(p), pp = P(p.x + o2[0], p.y + o2[1]); fst ? ctx.moveTo(pp.x, pp.y) : ctx.lineTo(pp.x, pp.y); fst = false; });
    ctx.stroke(); ctx.restore();
    ctx.save(); ctx.fillStyle = COL.vel; ctx.beginPath(); ctx.arc(ep.x, ep.y, 3, 0, TAU); ctx.fill(); ctx.restore();
    if (!(tr.ev.kind === 'top' && s.mode === 'mode4')) label(ctx, tr.ev.kind === 'slack' ? 'たるんだ点' : (tr.ev.kind === 'top' ? '最高点' : '離れた点'), ep.x + 14, ep.y + 14, { size: 10.5, color: COL.vel, align: 'left' });
  }
  /* 糸（3-3・4-2）：手から小球まで。たるんだあとは曲がった線 */
  if (GS === 3) {
    var hnd2 = P(0, 0);
    ctx.save(); ctx.strokeStyle = '#7a5a32'; ctx.lineWidth = 1.7; ctx.beginPath(); ctx.moveTo(hnd2.x, hnd2.y);
    if (q.kind === 'fly') { var mid = P(bx * 0.5 + 0.0, by * 0.5 - 0.10); ctx.quadraticCurveTo(mid.x, mid.y, Bp.x, Bp.y); } else ctx.lineTo(Bp.x, Bp.y);
    ctx.stroke(); ctx.restore();
  }
  /* 軌跡（少し前までの道すじ）→ 小球 */
  if (SN) {                                                     /* コマ図：それまでの道すじを点線で */
    ctx.save(); ctx.setLineDash([2, 4]); ctx.strokeStyle = 'rgba(22,99,181,.55)'; ctx.lineWidth = 1.6; ctx.beginPath();
    var f0 = true; tr.pts.forEach(function (p) { if (p.t > s.t || (tr.ev && p.t >= tr.ev.t)) return; var o2 = offOf(p), pp = P(p.x + o2[0], p.y + o2[1]); f0 ? ctx.moveTo(pp.x, pp.y) : ctx.lineTo(pp.x, pp.y); f0 = false; });
    ctx.stroke(); ctx.restore();
  } else {
    s.autoTrail = !!(tr.ev && s.t >= tr.ev.t - 0.25);           /* 離れる・たるむ・飛び出す前後は軌跡を自動で描く */
    trailStep(ctx, s, function (x, y, z) { return P(x, y, z); }, [bx, by, zb], C.sgn * (q.ang - C.ref));
  }
  ballShape(ctx, Bp.x, Bp.y, rb * S, '#c9d3de');
  /* デコピン：はじめの小球の位置のうしろから、進む向きへはじく（3-1・3-2 は右へ、3-3 は下へ） */
  if (s.t < 0.34 && !SN) {
    var q0 = M3.at(tr, 0), o0 = offOf(q0), B0 = P(q0.x + o0[0], q0.y + o0[1]);
    var fa = sec === 3 ? Math.PI / 2 : 0, back = rb * S + 38;
    if (s.v.v0 < 0.05) {                                          /* 初速度 0：デコピンではなく、手でそっと放す（mechanical-energy.html 1-2 と同じ） */
      var hA = (s.t <= 0.18) ? 1 : Math.max(0, 1 - (s.t - 0.18) / 0.22);
      if (hA > 0.02) dropHand(ctx, B0.x, B0.y, 0.5, clamp(s.t / 0.18, 0, 1), hA);
      if (s.t <= 1e-9) bubble(ctx, 'そっと手を放す（初速度 0）', B0.x + 6, B0.y - 58, { size: 12, bg: '#fff5e8', border: '#e07b18', color: '#a85c0c' });
    } else flickStart(ctx, s.t, s.v.v0, B0.x - Math.cos(fa) * back, B0.y - Math.sin(fa) * back, fa, sec === 3 ? 40 : 46, s.mode === 'mode4');
  }
  /* 一緒に回る観測者（小球に乗っている人）：頭は 3-1・3-3 では中心向き、3-2 では外向き。床の上では上向き */
  var upv;
  if (q.kind === 'floor') upv = [0, 1];
  else { var a4 = q.kind === 'fly' ? tr.ev.ang : q.ang; upv = GS === 2 ? [Math.sin(a4), Math.cos(a4)] : [-Math.sin(a4), Math.cos(a4)]; }
  var tv = [upv[1], -upv[0]], rf = [bx + upv[0] * rb * 0.6 + tv[0] * 0.065, by + upv[1] * rb * 0.6 + tv[1] * 0.065];   /* 力の矢印（中心を通る線）と重ならないよう横へ */
  var ur2 = up(rf, 1), u2 = P(rf[0] + upv[0] * 0.16, rf[1] + upv[1] * 0.16), a5 = P(rf[0], rf[1]);
  var Lr = Math.hypot(u2.x - a5.x, u2.y - a5.y);
  var handOn = s.v.v0 < 0.05 && s.t < 0.4 && !s.rot;            /* 手でそっと放すあいだは、小球に乗る観測者を描かない（手と重なるため） */
  var hdRot = (SN || handOn) ? null : observer(ctx, a5.x, a5.y, (u2.x - a5.x) / Lr, (u2.y - a5.y) / Lr, '', s.rot, Lr);
  if (!SN && !handOn) { var tq = P(rf[0] + tv[0] * 0.10 + upv[0] * 0.08, rf[1] + tv[1] * 0.10 + upv[1] * 0.08);   /* 名前は人の横（吹き出しと重ならないように） */
    ctx.save(); if (!s.rot) ctx.globalAlpha *= OBS_DIM;
    label(ctx, '一緒に回る観測者', tq.x, tq.y, { size: s.rot ? 11.5 : 10.5, bold: s.rot, color: s.rot ? COL.vel : '#9aa3ac', align: tv[0] >= 0 ? 'left' : 'right' }); ctx.restore(); }
  /* ---- 力 ---- */
  if (tr.fmax === undefined) { tr.fmax = 0; tr.pts.forEach(function (p) { tr.fmax = Math.max(tr.fmax, p.F); }); }
  var fmax = tr.fmax;
  var fs = Math.min(0.10, 0.50 / Math.max(fmax, m * G));        /* 矢印の長さ［m/N］：いちばん大きい力でも 0.50 m */
  var arr = function (x0, y0, dx, dy, L, kind, col, opt) {      /* 物理の点 (x0,y0) から向き (dx,dy) へ長さ L［m］ */
    var a = P(x0, y0), b = P(x0 + dx * L, y0 + dy * L);
    if (Math.hypot(b.x - a.x, b.y - a.y) < 3) return null;
    return arrow(ctx, a.x, a.y, b.x, b.y, kind, col, opt);
  };
  var tg = [upv[1], -upv[0]];                                   /* 横（接線）にずらす向き */
  if (showF) {
    var amg = arr(bx + tg[0] * 0.015, by + tg[1] * 0.015, 0, -1, m * G * fs, 'force', COL.force);
    if (amg) label(ctx, 'mg', amg.x2 + amg.ux * 10, amg.y2 + amg.uy * 10 + 2, { size: 13, bold: true, color: COL.force });
    if (q.kind !== 'fly' && q.F > 1e-6) {
      var cpt, dir;
      if (q.kind === 'floor') { cpt = [bx - tg[0] * 0.015, by - rb]; dir = [0, 1]; }
      else if (GS === 3) { var ul = Math.hypot(bx, by); dir = [-bx / ul, -by / ul]; cpt = [bx + dir[0] * rb, by + dir[1] * rb]; }
      else { cpt = [q.x - tg[0] * 0.015, q.y - tg[1] * 0.015]; dir = upv; }
      var aF = arr(cpt[0], cpt[1], dir[0], dir[1], q.F * fs, 'force', GS === 3 ? COL.hand : COL.norm);
      if (aF) {                                                   /* 重力と同じ向き（最高点付近）のときは、重力の矢印と反対がわへ文字をずらす */
        var sx = aF.uy * 8, sy = -aF.ux * 8;
        if (amg && Math.abs(aF.ux * amg.ux + aF.uy * amg.uy) > 0.8) { var dx0 = aF.x1 - amg.x1, dy0 = aF.y1 - amg.y1, dl = Math.hypot(dx0, dy0) || 1; sx = dx0 / dl * 16; sy = dy0 / dl * 16; }
        label(ctx, C.fName, aF.x2 + aF.ux * 11 + sx, aF.y2 + aF.uy * 11 + sy, { size: 13, bold: true, color: GS === 3 ? COL.hand : COL.norm });
      }
    }
    if (s.rot && q.kind === 'circle') {                          /* 見かけの力：遠心力（外向き）と、接線方向の慣性力 −m a_t */
      var rl2 = Math.hypot(q.x, q.y), uo2 = [q.x / rl2, q.y / rl2], v2 = q.v * q.v;
      var ac = arr(bx, by, uo2[0], uo2[1], m * v2 / R * fs, 'fict', COL.cent);
      centLabel(ctx, ac, s);
      var tdir = GS === 2 ? [Math.cos(q.ang), -Math.sin(q.ang)] : [Math.cos(q.ang), Math.sin(q.ang)];   /* 角が増える向き */
      var ft2 = -m * q.at, sgn2 = ft2 >= 0 ? 1 : -1;
      var at2 = arr(bx, by, tdir[0] * sgn2, tdir[1] * sgn2, Math.abs(ft2) * fs, 'fict', COL.cent);
      if (at2) label(ctx, '接線方向の慣性力', at2.x2 + at2.ux * 14, at2.y2 + at2.uy * 14 - 10, { size: 11, bold: true, color: COL.cent });
    }
  }
  /* 速度（慣性系だけ）：小球から外がわへ離して、まん中をそろえる */
  if (!s.rot && q.v > 0.02) {
    var nv = q.kind === 'floor' ? [0, 1] : (q.kind === 'fly' ? [-q.vy / q.v, q.vx / q.v] : (GS === 2 ? upv : [-upv[0], -upv[1]]));
    if (q.kind === 'fly' && nv[1] < 0) nv = [-nv[0], -nv[1]];
    var cv = [bx + nv[0] * 0.13, by + nv[1] * 0.13], Lv = q.v * 0.06, uvv = [q.vx / q.v, q.vy / q.v];
    var va = P(cv[0] - uvv[0] * Lv / 2, cv[1] - uvv[1] * Lv / 2), vb = P(cv[0] + uvv[0] * Lv / 2, cv[1] + uvv[1] * Lv / 2);
    var av = arrow(ctx, va.x, va.y, vb.x, vb.y, 'vel');
    if (av) sym(ctx, 'v', vb.x + av.ux * 10, vb.y + av.uy * 10 - 4, { size: 16, color: COL.vel, vec: true });
  }
  drawEqualTicks(ctx);
  /* 吹き出し：いまの視点の観測者のセリフ、できごと */
  var after = tr.ev && s.t >= tr.ev.t;
  var say = after ? M2SAY[tr.ev.kind] : (q.kind === 'floor' ? 'まっすぐ等速で進んでいるな' : (s.rot ? '力がつり合っているな' : '速さを変えながら円運動しているな'));
  if (!SN) speech(ctx, say, s.rot ? hdRot : hdIn);
  if (SN) { if (s._snapEv) eventBubble(ctx, tr.ev.kind, Bp.x, Bp.y - rb * S - 22); return; }   /* コマ図は「瞬間」のコマだけできごとの吹き出し */
  if (after && s.t - tr.ev.t < 1.6) {                          /* 観測者のセリフと重ならないよう、非慣性系では小球の下に出す */
    if (s.rot) eventBubble(ctx, tr.ev.kind, Bp.x, Bp.y + rb * S + 6, 'up'); else eventBubble(ctx, tr.ev.kind, Bp.x, Bp.y - rb * S - 22);
  }
  if (sec === 4 && tr.done === 'loop') {                       /* 3-2 ループ：最高点を通ったら「宙返りした！」（2026-10-06 千葉さん） */
    if (tr.tTop === undefined) { tr.tTop = null; for (var it = 0; it < tr.pts.length; it++) if (tr.pts[it].kind === 'circle' && tr.pts[it].ang >= Math.PI) { tr.tTop = tr.pts[it].t; break; } }
    if (tr.tTop !== null && s.t >= tr.tTop && s.t - tr.tTop < 0.7) { if (s.rot) eventBubble(ctx, 'loop', Bp.x, Bp.y + rb * S + 6, 'up'); else eventBubble(ctx, 'loop', Bp.x, Bp.y - rb * S - 22); }
  }
  pill(ctx, '状態：' + m3Phase(q, tr), 10, 10, { size: 12 });

}

/* ===================== 式（図の下の 2 つの箱） ===================== */
function m3Eqs(sec, q, tr) {
  var GS = m3GS(sec), m = M3.m, R = M3.R, v = q.v, F = q.F, th = Math.abs(q.ang), fn = GS === 3 ? 'S' : 'N';
  var nm = fmt(m * v * v / R, 2), mgc = fmt(m * G * Math.cos(th), 2);
  if (q.kind === 'floor') return {
    in: { h: '【慣性系】床の上を等速で進む', lines: [{ tag: 'bal', k: '鉛直方向：', t: 'N - mg = 0' }], note: '水平方向には力がはたらかない（等速直線運動）' },
    rot: { h: '【非慣性系】まだ円運動していない', lines: [{ tag: 'bal', k: '鉛直方向：', t: 'N - mg = 0' }], note: '等速で動いているあいだは、見かけの力ははたらかない' } };
  if (q.kind === 'fly') return {
    in: { h: '【慣性系】' + (tr.ev.kind === 'slack' ? '糸がたるんだ' : (tr.ev.kind === 'top' ? '最高点から飛び出した' : '面から離れた')) + '→ 放物運動', lines: [{ tag: 'eom', k: '', t: 'm\\vec{a} = m\\vec{g}' }], note: '重力だけを受けて落ちていく' },
    rot: { h: '【非慣性系】円運動をやめた', lines: [{ k: '', t: (GS === 3 ? 'S' : 'N') + ' = 0' }], note: '観測者は小球と一緒に落ちていく（円運動の非慣性系ではなくなる）' } };
  var Ls = {
    1: { in: [{ tag: 'eom', k: '中心方向：', t: 'm\\dfrac{v^2}{r} = N - mg\\cos\\theta', cf: 'N - mg\\cos\\theta', cfn: '中心向きの合力' }, { tag: 'eom', k: '接線方向：', t: 'ma_t = -mg\\sin\\theta' }],
         rot: [{ tag: 'bal', k: '中心方向：', t: 'N - mg\\cos\\theta - \\underbrace{m\\dfrac{v^2}{r}}_{\\text{遠心力}} = 0' }, { tag: 'bal', k: '接線方向：', t: '-mg\\sin\\theta \\underbrace{- ma_t}_{\\text{慣性力}} = 0' }] },
    2: { in: [{ tag: 'eom', k: '中心方向：', t: 'm\\dfrac{v^2}{r} = mg\\cos\\theta - N', cf: 'mg\\cos\\theta - N', cfn: '中心向きの合力' }, { tag: 'eom', k: '接線方向：', t: 'ma_t = mg\\sin\\theta' }],
         rot: [{ tag: 'bal', k: '中心方向：', t: 'mg\\cos\\theta - N - \\underbrace{m\\dfrac{v^2}{r}}_{\\text{遠心力}} = 0' }, { tag: 'bal', k: '接線方向：', t: 'mg\\sin\\theta \\underbrace{- ma_t}_{\\text{慣性力}} = 0' }] },
    3: { in: [{ tag: 'eom', k: '中心方向：', t: 'm\\dfrac{v^2}{r} = S - mg\\cos\\theta', cf: 'S - mg\\cos\\theta', cfn: '中心向きの合力' }, { tag: 'eom', k: '接線方向：', t: 'ma_t = -mg\\sin\\theta' }],
         rot: [{ tag: 'bal', k: '中心方向：', t: 'S - mg\\cos\\theta - \\underbrace{m\\dfrac{v^2}{r}}_{\\text{遠心力}} = 0' }, { tag: 'bal', k: '接線方向：', t: '-mg\\sin\\theta \\underbrace{- ma_t}_{\\text{慣性力}} = 0' }] }
  }[GS];
  var num = GS === 2 ? 'いま：' + nm + ' ＝ ' + mgc + ' − ' + fmt(F, 2) + '（N）' : 'いま：' + nm + ' ＝ ' + fmt(F, 2) + ' − (' + mgc + ')（' + fn + '）';
  var num2 = GS === 2 ? 'いま：' + mgc + ' − ' + fmt(F, 2) + ' − ' + nm + ' ＝ 0' : 'いま：' + fmt(F, 2) + ' − (' + mgc + ') − ' + nm + ' ＝ 0';
  return {
    in: { h: '【慣性系】円運動している（速さも変わる）', lines: Ls.in, num: num, note: '※ 慣性系に「遠心力」は存在しない。θ は' + (GS === 2 ? '最高点' : '最下点') + 'からの角' },
    rot: { h: '【非慣性系】止まって見える', lines: Ls.rot, num: num2, note: '※ 遠心力と接線方向の慣性力（注）は、一緒に回る観測者だけが感じる見かけの力' } };
}
/* 3-1・3-2 から ④-1 へ（なぜ N ≥ 0 が条件になるのか） */
var M3LINK4 = '<p class="m4link">なぜ $N \\ge 0$ が条件になるのか、くわしくは <a href="#4-1">④-1 最高点まで昇る条件</a> を参照。</p>';
var M3LINK42 = '<p class="m4link">なぜ $S \\ge 0$ が条件になるのか、くわしくは <a href="#4-2">④-2 糸による円運動で 1 周できるか</a> を参照。</p>';   /* 3-4 から ④-2 へ */
var M3NOTE = '<p class="qnote">（注）速さが変わる円運動では、一緒に回る観測者には、遠心力の他に<b>接線方向の慣性力 $-ma_t$</b> もはたらいて見える。高校の教科書では、ふつう中心方向（遠心力）だけを扱う。</p>';
/* 右の列の「立式」カード（モード2 と同じ形）。方向は「中心方向」と「接線方向」。sec ごとの式は m3Eqs と同じ */
function m3Frame(s, sec, inTxt, rotTxt) {
  var E = { 1: ['m\\dfrac{v^2}{r} = N - mg\\cos\\theta', 'ma_t = -mg\\sin\\theta', 'N - mg\\cos\\theta - m\\dfrac{v^2}{r} = 0', '-mg\\sin\\theta - ma_t = 0'],
            2: ['m\\dfrac{v^2}{r} = mg\\cos\\theta - N', 'ma_t = mg\\sin\\theta', 'mg\\cos\\theta - N - m\\dfrac{v^2}{r} = 0', 'mg\\sin\\theta - ma_t = 0'],
            3: ['m\\dfrac{v^2}{r} = S - mg\\cos\\theta', 'ma_t = -mg\\sin\\theta', 'S - mg\\cos\\theta - m\\dfrac{v^2}{r} = 0', '-mg\\sin\\theta - ma_t = 0'] }[m3GS(sec)];
  return m2Setup(s, {
    lead: { in: inTxt, rot: rotTxt },
    rows: [{ dir: '中心方向', in: ['eom', E[0], { 1: 'N - mg\\cos\\theta', 2: 'mg\\cos\\theta - N', 3: 'S - mg\\cos\\theta' }[m3GS(sec)], '中心向きの合力'], rot: ['bal', E[2]] }, { dir: '接線方向', in: ['eom', E[1]], rot: ['bal', E[3]] }],
    note: { in: '<p class="qnote">外（慣性系）から見ると加速度があるので' + T_EOM + 'を、<b>中心方向</b>（加速度 $\\dfrac{v^2}{r}$）と<b>接線方向</b>（加速度 $a_t$）に分けて立てる。慣性系に「遠心力」は存在しない。</p>', rot: M3NOTE } });
}
/* 「理論的背景」（力学的エネルギー保存則と、条件の導出）は折りたためる。既定は開いておく（2026-10-04 千葉さん） */
function m3TheoryOpen(s) { return '<details class="theory"' + (s.theoryClosed ? '' : ' open') + '><summary>理論的背景<span>（力学的エネルギー保存則・条件の導出）</span></summary><div class="thbody">'; }
function m3Energy(tr, eqTex) {
  return '<div class="qcard"><p class="qt">力学的エネルギー保存則</p><p>垂直抗力や張力は速度と垂直なので仕事をしない。重力だけが仕事をするので、力学的エネルギーは保存する（右下のグラフの $E$ が水平）。</p>' +
    '<div class="qeq">' + tex(eqTex, true) + '</div></div>';
}

/* ===================== セクション1 なめらかな円筒面をのぼる ===================== */
DEFS.m3s1 = m3Base({
  id: 'm3s1', num: 1, sec: 1, title: 'なめらかな円筒面を上る小球',
  desc: '小球（$m=0.20$ kg）をデコピンで弾き、なめらかな床を速さ $v_0$ で進ませて、半径 $r=0.50$ m のなめらかな円筒面の内側を上らせる。中心方向には<b>垂直抗力と重力の成分</b>の合力がはたらく。<span class="todo">$v_0$ を変えて ▶ スタートし、最高点まで達するか見よう。</span>',
  vars: [{ k: 'v0', label: '初速 $v_0$', aria: '初速', min: 1.0, max: 6.0, step: 0.1, def: 4.0, dec: 1, unit: 'm/s',
    mark: function () { return [{ x: Math.sqrt(2 * G * M3.R), label: '$\\sqrt{2gr}$' }, { x: Math.sqrt(5 * G * M3.R), label: '$\\sqrt{5gr}$' }]; } }],
  msg: function (s) {
    var tr = m3Tr(s), q = M3.at(tr, s.t), v0 = s.v.v0, r2 = Math.sqrt(2 * G * M3.R), r5 = Math.sqrt(5 * G * M3.R);
    if (tr.ev && tr.ev.kind === 'off' && s.t >= tr.ev.t) return '<b>面から離れた！</b>（$N = 0$）　$\\theta = ' + fmt(tr.ev.ang * 180 / Math.PI, 1) + '^\\circ$ で離れ、そのあとは放物運動。' + (s.ended ? '円筒面か床にぶつかったところで止めた。' : '');
    if (tr.ev && tr.ev.kind === 'top' && s.t >= tr.ev.t) return '<b>最高点に達した！</b>　その先には円筒面がないので、最高点から水平に飛び出して放物運動。';
    if (v0 >= r5) return '$v_0 \\ge \\sqrt{5gr} = ' + fmt(r5, 2) + '$ m/s なので、最高点まで面から離れずに達する。';
    if (v0 <= r2) return '$v_0 \\le \\sqrt{2gr} = ' + fmt(r2, 2) + '$ m/s なので、中心の高さまで上らずに止まり、滑り戻る（$N$ は 0 にならない）。';
    return '▶ スタート。$\\sqrt{2gr} < v_0 < \\sqrt{5gr}$ なので、中心より高いところで面から離れる。';
  },
  eqs: function (s, q) { return m3Eqs(1, q, m3Tr(s)); },
  right: function (s, tr) {
    var v0 = s.v.v0, R = M3.R, r5 = Math.sqrt(5 * G * R);
    var h = m3Frame(s, 1, '小球は円の中心へ向かう加速度 $\\dfrac{v^2}{r}$ をもつ。中心向きの合力は $N - mg\\cos\\theta$（$\\theta$ は最下点からの角）。',
      '一緒に回る観測者には小球が止まって見える。遠心力と接線方向の慣性力を加えて、力がつり合う。');
    h += m3TheoryOpen(s) + m3Energy(tr, '\\dfrac{1}{2}mv_0^{\\,2} = \\dfrac{1}{2}mv^2 + mgr(1 - \\cos\\theta)');
    h += '<div class="qcard derive"><p class="qt">最高点に達する条件</p><p>最高点（$\\theta = 180^\\circ$）で面から離れないためには $N \\ge 0$。最高点での速さを $v_1$ とすると</p>' +
      '<div class="qeq">' + eqRow('eom', 'm\\dfrac{v_1^{\\,2}}{r} = N + mg \\;\\Longrightarrow\\; v_1^{\\,2} \\ge gr') + tex('\\dfrac{1}{2}mv_0^{\\,2} = \\dfrac{1}{2}mv_1^{\\,2} + mg(2r)\\ \\Longrightarrow\\ v_0 \\ge \\sqrt{5gr}', true) + '</div>' +
      '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('\\sqrt{5gr} = \\sqrt{5\\times 9.8\\times ' + fmt(R, 2) + '} = ' + fmt(r5, 2) + '\\ \\text{m/s}') + '（いま ' + tex('v_0 = ' + fmt(v0, 1)) + ' m/s）</p>' +
      '<p class="qnote">$N = 0$ になる角は $\\cos\\theta = \\dfrac{2gr - v_0^{\\,2}}{3gr}$。$v_0 \\le \\sqrt{2gr}$ のときは、中心の高さまでで速さが 0 になり、滑り戻る。</p>' + M3LINK4 + '</div>';
    h += '</div></details>';
    h += '<p class="assume">' + tex('m = 0.20') + ' kg、' + tex('r = 0.50') + ' m、' + tex('g = 9.8') + ' m/s²。小球の大きさは考えない（図では面の内側に半径ぶんずらして描いた）。最高点の左には円筒面がない。</p>';
    return h;
  }
});
/* ===================== 3-2 なめらかなループ面を上る小球（2026-10-06。以前の 4-1 のループのアニメ＝M3.b4、sec 4） ===================== */
DEFS.m3sL = m3Base({
  id: 'm3sL', num: 2, sec: 4, title: 'なめらかなループ面を上る小球',
  desc: '小球（$m=0.20$ kg）をデコピンで弾き、なめらかな床を速さ $v_0$ で進ませて、半径 $r=0.50$ m のなめらかなループ面（1 周ぶんの円筒面）の内側を上らせる。中心方向には<b>垂直抗力と重力の成分</b>の合力がはたらく。図はループコースターを斜め上から見たもの（ドラッグで向きを変えられる）。▶ スタートを押すと、真横から見た図に変わる。<span class="todo">$v_0$ を変えて ▶ スタートし、宙返り（1 周）できるか見よう。</span>',
  vars: [{ k: 'v0', label: '初速 $v_0$', aria: '初速', min: 1.0, max: 6.0, step: 0.1, def: 5.5, dec: 1, unit: 'm/s',
    mark: function () { return [{ x: Math.sqrt(2 * G * M3.R), label: '$\\sqrt{2gr}$' }, { x: Math.sqrt(5 * G * M3.R), label: '$\\sqrt{5gr}$' }]; } }],
  msg: function (s) {
    var tr = m3Tr(s), v0 = s.v.v0, r2 = Math.sqrt(2 * G * M3.R), r5 = Math.sqrt(5 * G * M3.R);
    if (tr.ev && tr.ev.kind === 'off' && s.t >= tr.ev.t) return '<b>面から離れた！</b>（$N = 0$）　$\\theta = ' + fmt(tr.ev.ang * 180 / Math.PI, 1) + '^\\circ$ で離れ、そのあとは放物運動。' + (s.ended ? 'ループ面か床にぶつかったところで止めた。' : '');
    if (tr.done === 'loop' && tr.tTop != null && s.t >= tr.tTop) return '<b>宙返りした！</b>　最高点でも $N \\ge 0$ なので、面から離れずに 1 周した。' + (s.ended ? '1 周して右の床へ出ていった。' : '');
    if (v0 >= r5) return '$v_0 \\ge \\sqrt{5gr} = ' + fmt(r5, 2) + '$ m/s なので、最高点でも面から離れず、宙返りできる。';
    if (v0 <= r2) return '$v_0 \\le \\sqrt{2gr} = ' + fmt(r2, 2) + '$ m/s なので、中心の高さまで上らずに止まり、滑り戻る（$N$ は 0 にならない）。';
    return '▶ スタート。$\\sqrt{2gr} < v_0 < \\sqrt{5gr}$ なので、中心より高いところで面から離れる。';
  },
  eqs: function (s, q) { return m3Eqs(4, q, m3Tr(s)); },
  right: function (s, tr) {
    var v0 = s.v.v0, R = M3.R, r5 = Math.sqrt(5 * G * R);
    var h = m3Frame(s, 4, '小球は円の中心へ向かう加速度 $\\dfrac{v^2}{r}$ をもつ。中心向きの合力は $N - mg\\cos\\theta$（$\\theta$ は最下点からの角）。',
      '一緒に回る観測者には小球が止まって見える。遠心力と接線方向の慣性力を加えて、力がつり合う。');
    h += m3TheoryOpen(s) + m3Energy(tr, '\\dfrac{1}{2}mv_0^{\\,2} = \\dfrac{1}{2}mv^2 + mgr(1 - \\cos\\theta)');
    h += '<div class="qcard derive"><p class="qt">宙返りする（1 周する）条件</p><p>最高点（$\\theta = 180^\\circ$）で面から離れないためには $N \\ge 0$。$N$ は最高点で一番小さいので、最高点で $N \\ge 0$ なら 1 周できる。最高点での速さを $v_1$ とすると</p>' +
      '<div class="qeq">' + eqRow('eom', 'm\\dfrac{v_1^{\\,2}}{r} = N + mg \\;\\Longrightarrow\\; v_1^{\\,2} \\ge gr') + tex('\\dfrac{1}{2}mv_0^{\\,2} = \\dfrac{1}{2}mv_1^{\\,2} + mg(2r)\\ \\Longrightarrow\\ v_0 \\ge \\sqrt{5gr}', true) + '</div>' +
      '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('\\sqrt{5gr} = \\sqrt{5\\times 9.8\\times ' + fmt(R, 2) + '} = ' + fmt(r5, 2) + '\\ \\text{m/s}') + '（いま ' + tex('v_0 = ' + fmt(v0, 1)) + ' m/s）</p>' +
      '<p class="qnote">$N = 0$ になる角は $\\cos\\theta = \\dfrac{2gr - v_0^{\\,2}}{3gr}$。$v_0 \\le \\sqrt{2gr}$ のときは、中心の高さまでで速さが 0 になり、滑り戻る。</p>' + M3LINK4 + '</div>';
    h += '</div></details>';
    h += '<p class="assume">' + tex('m = 0.20') + ' kg、' + tex('r = 0.50') + ' m、' + tex('g = 9.8') + ' m/s²。小球の大きさは考えない（図では面の内側に半径ぶんずらして描いた）。ループは 1 周する間に少し奥へずれる（ループコースターの形）が、真横から見ると半径 ' + tex('r') + ' の円で、運動は円の面内で考える。1 周したら、右の床へ出ていく。</p>';
    return h;
  }
});
/* 3-2：3 次元のループコースター。最初は斜め上から、▶ スタートで真横からに変える */
(function (d) {
  d.views = [{ label: '斜め上から', az: M3LOOP.obl.az, el: M3LOOP.obl.el }, { label: '真横から', az: 0, el: 0 }]; d.view0 = 0;
  var init0 = d.init; d.init = function (s) { init0(s); s.cam3 = { az: M3LOOP.obl.az, el: M3LOOP.obl.el }; s.camAnim = null; };
  d.onView = function (s, i, user) { var vw = d.views[i]; if (user) m3CamGo(s, vw, 700); else { s.camAnim = null; s.cam3 = { az: vw.az, el: vw.el }; } };
  d.drag3d = function (s, dx, dy) {
    var c = m3CamNow(s); s.camAnim = null;
    s.cam3 = { az: clamp(c.az - dx * 0.35, -80, 80), el: clamp(c.el + dy * 0.30, 0, 70) }; m3CamBtns(s, -1);
  };
  d.onReset = function (s) { m3CamGo(s, M3LOOP.obl, 600); m3CamBtns(s, 0); };
  var ab0 = d.afterBuild;
  d.afterBuild = function (s) {
    ab0(s);
    var tp = s.togglePlay;
    s.togglePlay = function () {                                  /* ▶ スタートを押したら真横からに */
      tp.call(s);
      if (s.playing) m3ToSide(s);
    };
    var pw = s.playWindow;
    s.playWindow = function () { pw.apply(s, arguments); m3ToSide(s); };   /* 「⏱ 離れる瞬間をスローで」も真横から */
  };
})(DEFS.m3sL);
/* ===================== セクション3 なめらかな円筒面をすべりおりる ===================== */
DEFS.m3s2 = m3Base({
  id: 'm3s2', num: 3, sec: 2, title: 'なめらかな円筒面を滑りおりる小球',
  desc: '半径 $r=0.50$ m のなめらかな半円柱の最高点で、小球（$m=0.20$ kg）をデコピンで右向きに弾く（速さ $v_0$）。中心方向には<b>重力の成分と垂直抗力</b>の合力がはたらく。<span class="todo">$v_0$ を変えて ▶ スタートし、どこで面から離れるか見よう。</span>',
  vars: [{ k: 'v0', label: '初速 $v_0$', aria: '初速', min: 0.1, max: 2.2, step: 0.1, def: 0.1, dec: 1, unit: 'm/s' }],
  msg: function (s) {
    var tr = m3Tr(s), v0 = s.v.v0, c = 2 / 3 + v0 * v0 / (3 * G * M3.R);
    if (tr.ev && s.t >= tr.ev.t) return '<b>面から離れた！</b>（$N = 0$）　$\\cos\\theta = \\dfrac{2}{3} + \\dfrac{v_0^{\\,2}}{3gr} = ' + fmt(c, 3) + '$、$\\theta = ' + fmt(Math.acos(c) * 180 / Math.PI, 1) + '^\\circ$。そのあとは放物運動。';
    return '▶ スタート。滑りおりるにつれて速くなり、$N = mg\\cos\\theta - m\\dfrac{v^2}{r}$ がしだいに小さくなる。';
  },
  eqs: function (s, q) { return m3Eqs(2, q, m3Tr(s)); },
  right: function (s, tr) {
    var v0 = s.v.v0, R = M3.R, c = 2 / 3 + v0 * v0 / (3 * G * R);
    var h = m3Frame(s, 2, '中心向きの合力は $mg\\cos\\theta - N$（$\\theta$ は最高点からの角）。速くなるほど必要な向心力が大きくなり、$N$ が小さくなる。',
      '一緒に回る観測者には小球が止まって見える。遠心力が外向きにはたらき、$N$ を小さくしていく。');
    h += m3TheoryOpen(s) + m3Energy(tr, '\\dfrac{1}{2}mv_0^{\\,2} + mgr = \\dfrac{1}{2}mv^2 + mgr\\cos\\theta');
    h += '<div class="qcard derive"><p class="qt">面から離れる角</p><p>離れる瞬間は $N = 0$。中心方向の' + T_EOM + 'と力学的エネルギー保存則から</p>' +
      '<div class="qeq">' + eqRow('eom', 'm\\dfrac{v^2}{r} = mg\\cos\\theta') + tex('v^2 = v_0^{\\,2} + 2gr(1 - \\cos\\theta)', true) + tex('\\cos\\theta = \\dfrac{2}{3} + \\dfrac{v_0^{\\,2}}{3gr}', true) + '</div>' +
      '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('\\cos\\theta = ' + fmt(c, 3) + ',\\ \\ \\theta = ' + fmt(Math.acos(c) * 180 / Math.PI, 1) + '^\\circ') + '</p>' +
      '<p class="qnote">$v_0$ が小さいほど $\\cos\\theta \\to \\dfrac{2}{3}$（約 $48.2^\\circ$）に近づく。$v_0 \\ge \\sqrt{gr}$ だと最高点ですぐに離れる。</p>' + M3LINK4 + '</div>';
    h += '</div></details>';
    h += '<p class="assume">' + tex('m = 0.20') + ' kg、' + tex('r = 0.50') + ' m。小球の大きさは考えない（図では面の外側に半径ぶんずらして描いた）。</p>';
    return h;
  }
});
/* ===================== セクション3 糸による円運動 ===================== */
DEFS.m3s3 = m3Base({
  id: 'm3s3', num: 4, sec: 3, title: '糸による円運動',
  desc: '長さ $r=0.50$ m の糸の一端を支柱のくぎ（中心）に結び、糸を水平にした位置で小球（$m=0.20$ kg）をデコピンで下向きに弾く（速さ $v_0$）。中心方向には<b>張力と重力の成分</b>の合力がはたらく。<span class="todo">$v_0$ を変えて ▶ スタートし、最高点まで糸がたるまずに回れるか見よう。</span>',
  vars: [{ k: 'v0', label: '初速 $v_0$', aria: '初速', min: 0, max: 5.0, step: 0.1, def: 0, dec: 1, unit: 'm/s',
    mark: function () { return { x: Math.sqrt(3 * G * M3.R), label: '$\\sqrt{3gr}$' }; } }],
  msg: function (s) {
    var tr = m3Tr(s), v0 = s.v.v0, r3 = Math.sqrt(3 * G * M3.R);
    if (tr.ev && s.t >= tr.ev.t) return '<b>糸がたるんだ！</b>（$S = 0$）　そのあとは放物運動。糸がまたぴんと張ったところで止めた。';
    if (v0 >= r3) return '$v_0 \\ge \\sqrt{3gr} = ' + fmt(r3, 2) + '$ m/s なので、最高点でも $S \\ge 0$。糸がたるまずに回り続ける。';
    if (v0 === 0) return '$v_0 = 0$ では、反対がわの水平の位置まで上がって戻る（振り子）。$v_0$ を大きくしてみよう。';
    return '▶ スタート。$v_0 < \\sqrt{3gr}$ なので、中心より高いところで糸がたるむ。';
  },
  eqs: function (s, q) { return m3Eqs(3, q, m3Tr(s)); },
  right: function (s, tr) {
    var v0 = s.v.v0, R = M3.R, r3 = Math.sqrt(3 * G * R);
    var h = m3Frame(s, 3, '中心向きの合力は $S - mg\\cos\\theta$（$\\theta$ は最下点からの角）。',
      '一緒に回る観測者には小球が止まって見える。遠心力と接線方向の慣性力を加えて、力がつり合う。');
    h += m3TheoryOpen(s) + m3Energy(tr, '\\dfrac{1}{2}mv_0^{\\,2} + mgr = \\dfrac{1}{2}mv^2 + mgr(1 - \\cos\\theta)');
    h += '<div class="qcard derive"><p class="qt">最高点に達する条件</p><p>最高点で糸がたるまないためには $S \\ge 0$。最高点での速さを $v_1$ とすると</p>' +
      '<div class="qeq">' + eqRow('eom', 'm\\dfrac{v_1^{\\,2}}{r} = S + mg \\;\\Longrightarrow\\; v_1^{\\,2} \\ge gr') + tex('\\dfrac{1}{2}mv_0^{\\,2} = \\dfrac{1}{2}mv_1^{\\,2} + mgr\\ \\Longrightarrow\\ v_0 \\ge \\sqrt{3gr}', true) + '</div>' +
      '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('\\sqrt{3gr} = \\sqrt{3\\times 9.8\\times ' + fmt(R, 2) + '} = ' + fmt(r3, 2) + '\\ \\text{m/s}') + '（いま ' + tex('v_0 = ' + fmt(v0, 1)) + ' m/s）</p>' +
      '<p class="qnote">初めの位置（中心と同じ高さ）を基準にした。糸がたるむ角は $\\cos\\theta = -\\dfrac{v_0^{\\,2}}{3gr}$。</p>' + M3LINK42 + '</div>';
    h += '</div></details>';
    h += '<p class="assume">' + tex('m = 0.20') + ' kg、' + tex('r = 0.50') + ' m。糸の質量は考えない。中心（くぎ）は動かない。</p>';
    return h;
  }
});
