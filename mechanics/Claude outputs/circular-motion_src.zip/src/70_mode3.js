/* =========================================================================
   70_mode3.js … モード3「等速ではない円運動」（鉛直面内の円運動。2 次元の図）
   ・軌道は 30_physics.js の M3 で前もって計算（図・式・グラフが同じ点を見る）。
   ・非慣性系＝「一緒に円運動する観測者」は、小球に乗っている人。絵全体を −（小球の角）回して、小球を画面の決まった場所に止める。
     重力は「ほんとうの下」なので、回した絵の中では傾いて見える。
   ・非慣性系では遠心力 m v²/r と、接線方向の慣性力 −m a_t（速さが変わるため）を描く（2026-10 千葉さん：案 C。注釈つき）。
   ・はなれた／糸がたるんだあとは、観測者は円運動をやめるので、絵の回転はその瞬間の角で止める。
   ========================================================================= */
'use strict';
var M3CFG = {
  1: { box: { x0: -1.55, x1: 0.80, y0: -0.82, y1: 0.62 }, ref: 0, sgn: -1, surf: 'in', fName: 'N', fCol: '#7b3fd4' },
  2: { box: { x0: -0.95, x1: 1.45, y0: -0.10, y1: 0.80 }, ref: 0, sgn: 1, surf: 'out', fName: 'N', fCol: '#7b3fd4' },
  3: { box: { x0: -1.05, x1: 1.05, y0: -0.86, y1: 0.62 }, ref: Math.PI / 2, sgn: -1, surf: 'str', fName: 'S', fCol: '#c2367f' },
  /* モード4（2026-10-05）：gs＝形が同じセクション（4-1 は 3-1 と同じ内がわの面・1 周ぶん、4-2 は 3-3 と同じ糸・最下点から） */
  4: { box: { x0: -1.55, x1: 1.20, y0: -0.82, y1: 0.62 }, ref: 0, sgn: -1, surf: 'in', fName: 'N', fCol: '#7b3fd4', gs: 1 },
  5: { box: { x0: -1.05, x1: 1.05, y0: -0.86, y1: 0.62 }, ref: 0, sgn: -1, surf: 'str', fName: 'S', fCol: '#c2367f', gs: 3 },
  /* ③-5 糸による円運動（釘）：糸は 3-4 と同じ形。非慣性系では最下点 B に小球を止める（ref 0） */
  6: { box: { x0: -1.05, x1: 1.05, y0: -0.86, y1: 0.62 }, ref: 0, sgn: -1, surf: 'str', fName: 'S', fCol: '#c2367f', gs: 3 },
  /* ③-3 高さのあるループコースター：ループは 3-2（sec 4）と同じ。図の範囲は斜面の高さ h で変わる（m3BoxH） */
  7: { box: { x0: -1.55, x1: 1.20, y0: -0.82, y1: 0.62 }, ref: 0, sgn: -1, surf: 'in', fName: 'N', fCol: '#7b3fd4', gs: 1 }
};
/* ③-3：斜面の上はし（いちばん高い所より少し上）までが図に入る範囲 */
function m3SlopeTop(tr) { var g = tr.geo, R = M3.R, hT = g.hTop + 0.10; return { x: g.xj - hT / Math.tan(g.alpha), y: -R + hT }; }
function m3BoxH(tr) { var tp = m3SlopeTop(tr); return { x0: Math.min(-1.55, tp.x - 0.12), x1: 1.85, y0: -0.82, y1: Math.max(0.62, tp.y + 0.10) }; }   /* 右は外の観測者のぶん */
var M3LOOPBOX = { x0: -0.82, x1: 0.82, y0: -0.72, y1: 0.66 };   /* ③-3 非慣性系で円運動中に映す範囲（ループのまわり） */
function m3ZoomK(s, tr) {
  if (tr.tc === undefined) {                                     /* 円運動に入る時刻・（滑り戻るとき）円から出る時刻 */
    tr.tc = null; tr.tcOut = null;
    for (var i = 0; i < tr.pts.length; i++) { var p = tr.pts[i]; if (tr.tc === null && p.kind === 'circle') tr.tc = p.t; if (tr.tc !== null && tr.done === 'back' && p.kind !== 'circle' && p.x < -1e-3) { tr.tcOut = p.t; break; } }
  }
  if (tr.tc === null) return 0;
  var k = clamp((s.t - tr.tc) / 0.3, 0, 1);
  if (tr.tcOut !== null) k = Math.min(k, clamp((tr.tcOut + 0.3 - s.t) / 0.3, 0, 1));
  return k;
}
function m3IsLoop(sec) { return sec === 4 || sec === 7; }   /* 3 次元のループコースター（3-2・3-3） */
function m3GS(sec) { return M3CFG[sec].gs || sec; }
var M3RB = 0.045;
var M3SNAPBOX = { 1: { x0: -0.72, x1: 0.72, y0: -0.60, y1: 0.62 }, 2: { x0: -0.70, x1: 1.30, y0: -0.04, y1: 1.02 }, 3: { x0: -0.72, x1: 0.72, y0: -0.74, y1: 0.62 },
  4: { x0: -0.72, x1: 0.72, y0: -0.60, y1: 0.62 }, 5: { x0: -0.72, x1: 0.72, y0: -0.70, y1: 0.66 }, 6: { x0: -0.72, x1: 0.72, y0: -0.74, y1: 0.62 } };
function m3Tr(s) { return M3.traj(s.def.sec, s.v.v0, (s.def.sec === 3 || s.def.sec === 6) ? s.v.th0 : (s.def.sec === 7 ? s.v.h : undefined)); }
/* 3-4 の初期角度 θ0（度）と、それに応じた特徴的な初速（1 周できる最小の v0 ＝ √((3 + 2cosθ0)gr)。2026-10-13 千葉さん） */
var M3S3 = {
  crit: { 0: { k: 5, tex: '\\sqrt{5gr}' }, 30: { k: 3 + Math.sqrt(3), tex: '\\sqrt{(3+\\sqrt{3})gr}' }, 90: { k: 3, tex: '\\sqrt{3gr}' }, 180: { k: 1, tex: '\\sqrt{gr}' } },
  /* 中心の高さまで上がれない（振り子のように往復する）上限：√(2gr cosθ0)（θ0 < 90° のとき） */
  v0min180: 0.5,                             /* θ0 = 180°（最高点）では v0 ≥ 0.5 m/s（v0 = 0 だと、まっすぐ落ちてくぎを通ってしまうため） */
  low: { 0: { k: 2, tex: '\\sqrt{2gr}' }, 30: { k: Math.sqrt(3), tex: '\\sqrt{\\sqrt{3}\\,gr}' } }
};
/* 離れた／たるんだあとか（③-4 の θ0 = 180° では t = 0 でたるむが、スタート前は「まだ」とする） */
function m3After(s, tr) { return !!tr.ev && s.t >= tr.ev.t && (s.t > 0 || tr.ev.t > 0); }
function m3Th0(s) { return s.v.th0 === undefined ? 90 : s.v.th0; }
function m3S3Crit(th0) { var c = M3S3.crit[th0]; return { v: Math.sqrt(c.k * G * M3.R), tex: c.tex }; }
/* 非慣性系で絵を回すときの基準の角（スタートの瞬間は回さない） */
function m3Ref(s) { return s.def.sec === 3 ? m3Th0(s) * Math.PI / 180 : M3CFG[s.def.sec].ref; }
function m3Base(o) {
  var d = Object.assign({
    mode: 'mode3', belowCanvas: true, strobe: false, views: null, baseRate: 1 / 3, trailSec: 0.6,   /* モード3 はふだん 1/3 の速さ（スローはさらに 0.3 倍） */
    height: function (s, w) { return Math.round(clamp(w * 0.72, 320, 480)); }
  }, o);
  var init0 = d.init;
  d.init = function (s) { if (s.rot === undefined) s.rot = !!modeState(d.mode).rot; if (init0) init0(s); };
  d.buttons = [
    { k: 'obsIn', label: '外（慣性系）<br>から見る', cls: 'obs', seg: 'obs', segLabel: 'どの観測者から見るか', onClick: function (s) { m2SetRot(s, false); } },
    { k: 'obsRot', label: '一緒に円運動する観測者<br>（非慣性系）から見る', cls: 'obs rotb', seg: 'obs', onClick: function (s) { m2SetRot(s, true); } },
    /* 「離れる瞬間」「たるむ瞬間」：その少し前から少しあとまでを、とてもゆっくり再生（momentum-and-collision の「傾く瞬間」と同じ考え） */
    { k: 'inst', inPlay: true, label: (m3GS(d.sec) === 3 ? '⏱ たるむ瞬間' : '⏱ 離れる瞬間') + '<br>をスローで', cls: 'instb two', onClick: function (s) { m3PlayInstant(s); } }
  ];
  d.onWindow = function (s, on) { if (s.extra.inst) s.extra.inst.classList.toggle('on', on); };
  d.tEnd = function (s) { return m3Tr(s).tEnd; };
  d.onChanged = function (s, k) { if (d.fixVars) d.fixVars(s, k); return 'stop'; };   /* v0 を変えたら最初にもどす（2026-10-04 千葉さん）。fixVars：ほかの量に合わせて直す（③-4） */
  d.below = function (s) { m2EqBox(s, d.eqs(s, M3.at(m3Tr(s), s.t))); };
  d.afterBuild = function (s) { m3BuildSnaps(s); m2SetRot(s, s.rot); };
  d.onResize = function (s) { m3DrawSnaps(s); };
  d.draw = function (s, ctx, W, H) { drawM3(s, ctx, W, H); };
  var right0 = d.right;
  d.right = function (s, R) {
    var tr = m3Tr(s);
    if (s.extra && s.extra.inst) {                              /* この v0 では起きない：横線を引いて「できない」ことを見せる */
      s.extra.inst.classList.toggle('nope', !tr.ev);
      s.extra.inst.title = tr.ev ? '' : 'いまの初速では' + (m3GS(d.sec) === 3 ? '糸はたるまない' : '面から離れない');
      s.extra.inst.setAttribute('aria-disabled', tr.ev ? 'false' : 'true');
    }
    m3DrawSnaps(s);
    /* グラフを右の列のいちばん上に置く（アニメとグラフを横に並べて見せる授業のため）。その下に立式と理論的背景 */
    R.innerHTML = '';
    var gh = el('div', 'gwrap'); R.appendChild(gh);
    R.insertAdjacentHTML('beforeend', mathify(right0(s, tr)));
    var dt = R.querySelector('details.theory');
    if (dt) dt.addEventListener('toggle', function () { s.theoryClosed = !dt.open; });
    var C = M3CFG[d.sec], fn = C.fName;
    m3Graphs(s, gh, [
      { key: 'F', title: (fn === 'N' ? '垂直抗力 $N$' : '糸の張力 $S$') + ' – 時刻 $t$', ylab: fn + '〔N〕',
        series: [{ name: (fn === 'N' ? '垂直抗力 $N$' : '張力 $S$'), color: C.fCol, width: 2.4, f: function (p) { return p.F; }, gap: true }],
        hlines: [{ y: M3.m * G, color: COL.force, name: '重力 $mg$' }],
        sel: function (p) { return 't = ' + fmt(p.t, 2) + ' s、' + fn + ' = ' + fmt(p.F, 2) + ' N'; } },
      { key: 'E', title: 'エネルギー – 時刻 $t$', ylab: 'E〔J〕',
        series: [{ name: '力学的エネルギー $E$', color: GCOL.E, width: 3.2, f: function (p) { return p.E; } },
                 { name: '位置エネルギー $U$', color: GCOL.U, width: 2, dash: [7, 4], f: function (p) { return p.U; } },
                 { name: '運動エネルギー $K$', color: GCOL.K, width: 2, f: function (p) { return p.K; } }],
        sel: function (p) { return 't = ' + fmt(p.t, 2) + ' s、K = ' + fmt(p.K, 2) + ' J、U = ' + fmt(p.U, 2) + ' J、E = ' + fmt(p.E, 2) + ' J'; } }
    ], tr);
    m3DrawGraphs(s);
  };
  d.live = function (s) { m3DrawGraphs(s); };
  return d;
}
/* 離れる／たるむ瞬間の前後 M3WIN 秒（シミュレーションの時間）を、ふだんの M3WIN.rate 倍の速さで再生 */
var M3WIN = { pre: 0.16, post: 0.16, rate: 0.05 };
function m3PlayInstant(s) {
  var tr = m3Tr(s);
  if (!tr.ev) {                                                    /* この v0 では離れない・たるまない */
    s.msg.innerHTML = mathify('<b>いまの $v_0$ では' + (m3GS(s.def.sec) === 3 ? '糸はたるまない' : '面から離れない') + '。</b>' +
      (s.def.sec === 3 ? m3S3Hint(s) : s.def.sec === 6 ? m3S5Hint(s) : s.def.sec === 7 ? m3SHHint(s) : (s.def.sec === 2 ? '$v_0$ を変えてからもう一度押そう。' : '$\\sqrt{2gr} < v_0 < \\sqrt{5gr}$ にしてから、もう一度押そう。')));
    s.lastMsg = null; return;
  }
  var te = tr.ev.t;
  s.playWindow(Math.max(0, te - M3WIN.pre), Math.min(tr.tEnd, te + M3WIN.post), M3WIN.rate, null);
}
/* 状態のひとこと */
function m3Phase(q, tr) {
  if (q.kind === 'slope') return '斜面をすべりおりる（加速する）';
  if (q.kind === 'floor') return '床の上を等速で進む';
  if (q.kind === 'fly') return tr.ev.kind === 'slack' ? '糸がたるんで放物運動' : (tr.ev.kind === 'top' ? '最高点から飛び出して放物運動' : '面から離れて放物運動');
  if (q.cir === 'O') return '点 O を中心に円運動（半径 2r）';
  if (q.cir === 'C') return '釘 C を中心に円運動（半径 r）';
  return '円運動（速さが変わる）';
}

/* ---------- 3-2 ループコースター（3 次元。2026-10-06 千葉さん） ----------
   ループはらせんのように 1 周で奥へ w だけずれる（入口のレールは手前、出口のレールは奥。真横から見ると今までの円と同じ）。
   z は手前が正。床の面は |z| ≤ floorZ。レールの幅は 2hw（z の向き） */
var M3LOOP = { w: 0.36, hw: 0.035, floorZ: 0.42, side: { az: 0, el: 0 }, obl: { az: -28, el: 30 } };
function m3LoopZc(a) { return M3LOOP.w / 2 - M3LOOP.w * clamp(a / TAU, 0, 1); }
function m3LoopZ(q, tr) {
  if (q.kind === 'slope') return M3LOOP.w / 2;
  if (q.kind === 'floor') return q.x > 1e-3 ? -M3LOOP.w / 2 : M3LOOP.w / 2;
  if (q.kind === 'fly') return m3LoopZc(tr.ev.ang);
  return m3LoopZc(q.ang);
}
function m3DrawLoop3D(ctx, P, R, floorY, fx0, fx1, tr) {   /* tr があれば（③-3）斜面のレールもかく */
  var L = M3LOOP, ZF = L.floorZ, hw = L.hw;
  /* 床の面（方眼） */
  var c4 = [P(fx0, floorY, ZF), P(fx1, floorY, ZF), P(fx1, floorY, -ZF), P(fx0, floorY, -ZF)];
  ctx.save(); ctx.beginPath(); c4.forEach(function (p, i) { i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y); }); ctx.closePath();
  ctx.fillStyle = '#f1ece2'; ctx.fill(); ctx.strokeStyle = '#b9b0a0'; ctx.lineWidth = 1.2; ctx.stroke(); ctx.clip();
  ctx.strokeStyle = 'rgba(160,150,132,.35)'; ctx.lineWidth = 1;
  for (var gx = Math.ceil(fx0 / 0.1) * 0.1; gx <= fx1 + 1e-9; gx += 0.1) { var a = P(gx, floorY, ZF), b = P(gx, floorY, -ZF); ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); }
  for (var gz = -ZF; gz <= ZF + 1e-9; gz += 0.1) { var a2 = P(fx0, floorY, gz), b2 = P(fx1, floorY, gz); ctx.beginPath(); ctx.moveTo(a2.x, a2.y); ctx.lineTo(b2.x, b2.y); ctx.stroke(); }
  ctx.restore();
  /* レール（面の帯）：入口（手前）→ ループ → 出口（奥） */
  var pts = [];
  if (tr && tr.geo) {                                           /* ③-3：斜面（上はし → 下はし）→ 床 → ループ */
    var tp = m3SlopeTop(tr), xj = tr.geo.xj, nS = 30;
    var side = [P(tp.x, tp.y, L.w / 2), P(tp.x, floorY, L.w / 2), P(xj, floorY, L.w / 2)];   /* 斜面の台（横の面）をうすく */
    ctx.save(); ctx.beginPath(); side.forEach(function (p, i) { i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y); }); ctx.closePath(); ctx.fillStyle = 'rgba(214,204,186,.45)'; ctx.fill(); ctx.restore();
    for (var i0 = 0; i0 <= nS; i0++) pts.push([tp.x + (xj - tp.x) * i0 / nS, tp.y + (floorY - tp.y) * i0 / nS, L.w / 2]);
    for (var i1 = 1; i1 <= 12; i1++) pts.push([xj * (1 - i1 / 12), floorY, L.w / 2]);
  } else { var nIn = 24; for (var i = 0; i <= nIn; i++) pts.push([fx0 + (0 - fx0) * i / nIn, floorY, L.w / 2]); }
  var nL = 144; for (var k = 1; k <= nL; k++) { var an = TAU * k / nL; pts.push([R * Math.sin(an), -R * Math.cos(an), m3LoopZc(an)]); }
  var nOut = 20; for (var j = 1; j <= nOut; j++) pts.push([fx1 * j / nOut, floorY, -L.w / 2]);
  ctx.save(); ctx.lineJoin = 'round';
  for (var m = 1; m < pts.length; m++) {                         /* 帯（うす水色、半透明） */
    var p0 = pts[m - 1], p1 = pts[m], a0 = P(p0[0], p0[1], p0[2] + hw), a1 = P(p1[0], p1[1], p1[2] + hw), b1 = P(p1[0], p1[1], p1[2] - hw), b0 = P(p0[0], p0[1], p0[2] - hw);
    ctx.beginPath(); ctx.moveTo(a0.x, a0.y); ctx.lineTo(a1.x, a1.y); ctx.lineTo(b1.x, b1.y); ctx.lineTo(b0.x, b0.y); ctx.closePath();
    ctx.fillStyle = 'rgba(205,220,232,.55)'; ctx.fill();
  }
  ctx.strokeStyle = 'rgba(70,82,96,.35)'; ctx.lineWidth = 1;    /* 横木（立体に見えるように） */
  for (var t = 0; t < pts.length; t += 4) { var e0 = P(pts[t][0], pts[t][1], pts[t][2] + hw), e1 = P(pts[t][0], pts[t][1], pts[t][2] - hw); ctx.beginPath(); ctx.moveTo(e0.x, e0.y); ctx.lineTo(e1.x, e1.y); ctx.stroke(); }
  [hw, -hw].forEach(function (dz) {                              /* 両はしの線 */
    ctx.strokeStyle = '#3f4a56'; ctx.lineWidth = 1.7; ctx.beginPath();
    pts.forEach(function (p, n) { var u = P(p[0], p[1], p[2] + dz); n ? ctx.lineTo(u.x, u.y) : ctx.moveTo(u.x, u.y); }); ctx.stroke();
  });
  ctx.restore();
  var lb = P(R * 0.95, R * 0.62, m3LoopZc(Math.PI * 0.7)); label(ctx, 'なめらかなループ面', lb.x + 8, lb.y - 4, { size: 11, color: COL.sub, halo: false, align: 'left' });
}
/* 見る向き：いまの値（動かしている途中なら補間）と、なめらかに動かす */
function m3CamNow(s) {
  var A = s.camAnim; if (!A) return s.cam3;
  var k = clamp((performance.now() - A.t0) / A.dur, 0, 1), e = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
  s.cam3 = { az: A.from.az + (A.to.az - A.from.az) * e, el: A.from.el + (A.to.el - A.from.el) * e };
  if (k >= 1) s.camAnim = null;
  return s.cam3;
}
function m3CamGo(s, to, dur) {
  var from = m3CamNow(s) || to;
  s.camAnim = { from: { az: from.az, el: from.el }, to: { az: to.az, el: to.el }, t0: performance.now(), dur: dur || 900 };
  var tick = function () { if (!s.camAnim) { s.draw(); return; } if (!s.playing) s.draw(); requestAnimationFrame(tick); };
  requestAnimationFrame(tick);
}
function m3ToSide(s) { var c = m3CamNow(s); if (Math.abs(c.az) > 0.2 || c.el > 0.2) { m3CamGo(s, M3LOOP.side, 900); m3CamBtns(s, 1); } }
function m3CamBtns(s, i) { (s.vbtns || []).forEach(function (b, j) { b.classList.toggle('on', j === i); }); }

/* ===================== 図（3 セクション共通） ===================== */
function drawM3(s, ctx, W, H) {
  var sec = s.def.sec, GS = m3GS(sec), C = M3CFG[sec], tr = m3Tr(s), q = M3.at(tr, s.t), R = M3.R, m = M3.m, rb = M3RB, SN = !!s._snap, showF = SN || s.ms.showF;   /* SN：左下のコマ図を描いているとき（観測者・吹き出し・デコピンは描かない） */
  if (!SN && !s._snapKey) m3DrawSnaps(s);                       /* コマ図がまだなら（画面の外で幅がとれなかったとき）ここで描く */
  /* 絵の回転：小球の角（はなれたあとはその瞬間の角）だけ回す */
  var al = s.rot ? C.sgn * (q.ang - m3Ref(s)) : 0, ca = Math.cos(al), sa = Math.sin(al);
  /* ③-5（sec 6）：釘 C に触れたあとは C を中心に回る。cq＝いまの円の中心、Rq＝半径。非慣性系では、その中心のまわりに絵を回す */
  var S6 = sec === 6, r6 = M3.R / 2, onC = S6 && q.cir === 'C', cq = onC ? [0, -r6] : [0, 0], Rq = onC ? r6 : R, pv = s.rot ? cq : [0, 0];
  var B = sec === 7 ? m3BoxH(tr) : (SN ? M3SNAPBOX[sec] : C.box), mg = SN ? { t: 8, b: 6, x: 6 } : { t: sec === 7 ? 100 : 40, b: 16, x: 10 };
  /* ③-3：一緒に回る観測者から見るときは、円運動に入ったらループのまわりだけを大きく（0.3 秒かけて。滑り戻ったら元にもどす） */
  var kz = (sec === 7 && s.rot && !SN) ? m3ZoomK(s, tr) : 0;
  if (sec === 7 && SN && (s._snapIdx === 1 || s._snapIdx === 2)) B = M3LOOPBOX;   /* ③-3 のコマ図：2・3 コマ目はループのまわりだけ */
  if (kz > 0) {
    var BL = M3LOOPBOX, lz = function (a, b) { return a + (b - a) * kz; };
    B = { x0: lz(B.x0, BL.x0), x1: lz(B.x1, BL.x1), y0: lz(B.y0, BL.y0), y1: lz(B.y1, BL.y1) };
    mg = { t: lz(mg.t, 40), b: mg.b, x: mg.x };
  }   /* ③-3 は点 A の「手を放す」の吹き出しが状態の札と重ならないよう上をあける */   /* コマ図は小球のまわりだけを大きく */
  /* 3-2（sec 4）：3 次元のループコースター。s.cam3＝{az, el}（度）。真横（0, 0）なら今までの 2 次元の図と同じ */
  var cam = (m3IsLoop(sec) && !SN && s.cam3) ? m3CamNow(s) : null, D3 = !!cam && (Math.abs(cam.az) > 0.2 || cam.el > 0.2);
  var caz = 1, saz = 0, cel = 1, sel = 0;
  if (D3) { caz = Math.cos(cam.az * Math.PI / 180); saz = Math.sin(cam.az * Math.PI / 180); cel = Math.cos(cam.el * Math.PI / 180); sel = Math.sin(cam.el * Math.PI / 180); }
  var pj0 = function (X, Y, z) { if (!D3) return [X, Y]; var x1 = X * caz + z * saz, z1 = -X * saz + z * caz; return [x1, Y * cel - z1 * sel]; };   /* z は手前が正 */
  var S, ox, oy;
  if (!D3) { S = Math.min((W - 2 * mg.x) / (B.x1 - B.x0), (H - mg.t - mg.b) / (B.y1 - B.y0)); ox = W / 2 - S * (B.x0 + B.x1) / 2; oy = mg.t + (H - mg.t - mg.b) / 2 + S * (B.y0 + B.y1) / 2; }
  else {                                                         /* 見る向きを変えても、全体が図に入るように */
    var bb = [1e9, -1e9, 1e9, -1e9], ZF = M3LOOP.floorZ;
    (sec === 7 ? [[m3SlopeTop(tr).x + (B.x0 - m3SlopeTop(tr).x) * kz, B.y1, M3LOOP.w / 2], [m3SlopeTop(tr).x + (B.x0 - m3SlopeTop(tr).x) * kz, -R, M3LOOP.w / 2]] : []).concat([[B.x0, B.y0, 0], [B.x1, B.y0, 0], [B.x0, B.y1, 0], [B.x1, B.y1, 0], [B.x0, -R, ZF], [B.x1, -R, ZF], [B.x0, -R, -ZF], [B.x1, -R, -ZF], [0, R + 0.12, M3LOOP.w / 2], [0, R + 0.12, -M3LOOP.w / 2]]).forEach(function (p3) {
      var u = pj0(p3[0], p3[1], p3[2]); bb[0] = Math.min(bb[0], u[0]); bb[1] = Math.max(bb[1], u[0]); bb[2] = Math.min(bb[2], u[1]); bb[3] = Math.max(bb[3], u[1]); });
    S = Math.min((W - 2 * mg.x) / (bb[1] - bb[0]), (H - mg.t - mg.b) / (bb[3] - bb[2])); ox = W / 2 - S * (bb[0] + bb[1]) / 2; oy = mg.t + (H - mg.t - mg.b) / 2 + S * (bb[2] + bb[3]) / 2;
  }
  var zb = D3 ? m3LoopZ(q, tr) : 0;                              /* 小球のいる奥行き（ループはらせんのように少しずつ奥へ） */
  var P = function (x, y, z) { var X = pv[0] + (x - pv[0]) * ca - (y - pv[1]) * sa, Y = pv[1] + (x - pv[0]) * sa + (y - pv[1]) * ca, u = pj0(X, Y, z === undefined ? zb : z); return { x: ox + S * u[0], y: oy - S * u[1] }; };
  var Vd = function (vx, vy) { return { x: vx * ca - vy * sa, y: -(vx * sa + vy * ca) }; };   /* 物理の向き → 画面の向き */
  var O = P(0, 0);
  ctx.fillStyle = '#fbfaf6'; ctx.fillRect(0, 0, W, H);
  /* 小球の中心（物理の点を、面の外がわ／内がわへ半径ぶんずらす） */
  var offOf = function (p) {
    if (GS === 3) return [0, 0];
    if (p.kind === 'floor') return [0, rb];
    if (p.kind === 'slope') { var a7 = tr.geo.alpha; return [Math.sin(a7) * rb, Math.cos(a7) * rb]; }   /* 斜面の上がわ */
    var a = (p.kind === 'fly') ? tr.ev.ang : p.ang;
    if (GS === 1) return [-Math.sin(a) * rb, Math.cos(a) * rb];     /* 内がわ（中心向き） */
    return [Math.sin(a) * rb, Math.cos(a) * rb];                      /* 外がわ */
  };
  var of = offOf(q), bx = q.x + of[0], by = q.y + of[1], Bp = P(bx, by);
  /* ---- 背景：床・円筒面・人 ---- */
  var line = function (x1, y1, x2, y2, col, lw, dash) { var a = P(x1, y1), b = P(x2, y2); ctx.save(); ctx.strokeStyle = col; ctx.lineWidth = lw || 1.6; if (dash) ctx.setLineDash(dash); ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); ctx.restore(); };
  var hatch = function (pts, nx, ny) {                       /* 面の裏がわの斜線（物理の点の列と、裏がわの向き） */
    ctx.save(); ctx.strokeStyle = '#a9a193'; ctx.lineWidth = 1;
    pts.forEach(function (p, i) { if (i % 2) return; var a = P(p[0], p[1]), n = (nx !== undefined) ? [nx, ny] : p[2], b = P(p[0] + n[0] * 0.035 - (n[1]) * 0.02, p[1] + n[1] * 0.035 + n[0] * 0.02); ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); });
    ctx.restore();
  };
  var floorY = GS === 1 ? -R : (GS === 2 ? 0 : -0.80), fx0 = sec === 7 ? B.x0 + 0.02 : (GS === 2 ? -0.95 : (GS === 1 ? -1.55 : -1.12)), fx1 = sec === 7 ? 1.82 : m3IsLoop(sec) ? 1.20 : (GS === 2 ? 1.45 : (GS === 1 ? 0 : 1.12));   /* 4-1 は右へ出ていく床もある */
  var fpts = []; for (var xx = fx0; xx <= fx1 + 1e-9; xx += 0.035) fpts.push([xx, floorY]);
  if (D3) m3DrawLoop3D(ctx, P, R, floorY, fx0, fx1, sec === 7 ? tr : null);           /* 3-2 の 3 次元：床の面とループコースターのレール */
  else { hatch(fpts, 0, -1); line(fx0, floorY, fx1, floorY, '#2b323c', 1.8); }
  if (D3) {
    ctx.save(); ctx.fillStyle = '#2b323c'; ctx.beginPath(); ctx.arc(O.x, O.y, 2.6, 0, TAU); ctx.fill(); ctx.restore();
  } else if (GS === 1) {                                            /* 円筒面（内がわを走る）：円＋外がわの斜線 */
    /* 3-1：最下点から右がわを通って最高点まで（最高点の左には面がない）。4-1：1 周ぶん（ループ） */
    if (sec === 7) {                                              /* ③-3：斜面（台）＝なめらかに床へつながる */
      var tp7 = m3SlopeTop(tr), xj7 = tr.geo.xj, sp7 = [P(tp7.x, tp7.y), P(tp7.x, floorY), P(xj7, floorY)];
      ctx.save(); ctx.beginPath(); sp7.forEach(function (p, i) { i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y); }); ctx.closePath(); ctx.fillStyle = '#e8e1d3'; ctx.fill();
      ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(sp7[0].x, sp7[0].y); ctx.lineTo(sp7[2].x, sp7[2].y); ctx.stroke(); ctx.restore();
      var lb7 = P(tp7.x * 0.5 + xj7 * 0.5, tp7.y * 0.5 + floorY * 0.5); label(ctx, 'なめらかな斜面', lb7.x + 10, lb7.y - 8, { size: 11, color: COL.sub, halo: false, align: 'left' });
    }
    var aSp = m3IsLoop(sec) ? TAU : Math.PI;
    var cp = []; for (var k = 0; k <= 90; k++) { var a = -Math.PI / 2 + aSp * k / 90; cp.push([R * Math.cos(a), R * Math.sin(a), [Math.cos(a), Math.sin(a)]]); }
    /* 斜線の間かくは床とそろえる（床は 0.035 m ごとの点の 1 つおき＝0.07 m）。円周 πR を同じ間かくで */
    var hp = [], nH = Math.round(aSp * R / 0.035);
    for (var kh = 0; kh <= nH; kh++) { var ah = -Math.PI / 2 + aSp * kh / nH; hp.push([R * Math.cos(ah), R * Math.sin(ah), [Math.cos(ah), Math.sin(ah)]]); }
    hatch(hp);
    ctx.save(); ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 2; ctx.beginPath(); cp.forEach(function (q2, i) { var pp = P(q2[0], q2[1]); i ? ctx.lineTo(pp.x, pp.y) : ctx.moveTo(pp.x, pp.y); }); ctx.stroke(); ctx.restore();
    ctx.save(); ctx.fillStyle = '#2b323c'; ctx.beginPath(); ctx.arc(O.x, O.y, 2.6, 0, TAU); ctx.fill(); ctx.restore();
    label(ctx, '中心', O.x - 6, O.y - 2, { size: 10.5, color: COL.sub, align: 'right' });
    var lb1 = P(R * 0.95, R * 0.62); label(ctx, m3IsLoop(sec) ? 'なめらかなループ面' : 'なめらかな円筒面', lb1.x + 6, lb1.y - 4, { size: 11, color: COL.sub, halo: false, align: 'left' });
    if (s.mode === 'mode4') {                                     /* 4-1：最高点の印（スタート前から最後まで。2026-10-06 千葉さん） */
      var tp4 = P(0, R); ctx.save(); ctx.fillStyle = '#d1352b'; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(tp4.x, tp4.y, 4, 0, TAU); ctx.fill(); ctx.stroke(); ctx.restore();
      label(ctx, '最高点', tp4.x - 8, tp4.y - 12, { size: 11.5, bold: true, color: '#b2271b', align: 'right' });
    }
  } else if (GS === 2) {                                      /* 半円柱（外がわを走る） */
    ctx.save(); ctx.beginPath(); for (var k2 = 0; k2 <= 90; k2++) { var a2 = Math.PI * k2 / 90, pp = P(R * Math.cos(a2), R * Math.sin(a2)); k2 ? ctx.lineTo(pp.x, pp.y) : ctx.moveTo(pp.x, pp.y); }
    ctx.closePath(); ctx.fillStyle = '#e8e1d3'; ctx.fill(); ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 2; ctx.stroke(); ctx.restore();
    var lp = P(-R * 0.55, R * 0.35); label(ctx, 'なめらかな円筒面', lp.x, lp.y, { size: 11, color: COL.sub, halo: false });
  } else {                                                   /* 糸：中心の手。円の道すじ（破線） */
    ctx.save(); ctx.setLineDash([5, 5]); ctx.strokeStyle = '#8a929c'; ctx.lineWidth = 1.2; ctx.beginPath();
    if (S6) {                                                    /* ③-5：O のまわりの左半分（半径 2r）と、釘 C のまわりの円（半径 r） */
      var aT6 = m3Th0(s) * Math.PI / 180;                       /* 大きい円は、手を放す位置（θ0）から最下点まで（それより高い部分は消す） */
      for (var k6 = 0; k6 <= 60; k6++) { var a6 = aT6 * k6 / 60, p6 = P(-R * Math.sin(a6), -R * Math.cos(a6)); k6 ? ctx.lineTo(p6.x, p6.y) : ctx.moveTo(p6.x, p6.y); }
      ctx.stroke(); ctx.beginPath();
      for (var k7 = 0; k7 <= 36; k7++) { var a7 = Math.PI * k7 / 36, p7 = P(r6 * Math.sin(a7), -r6 - r6 * Math.cos(a7)); k7 ? ctx.lineTo(p7.x, p7.y) : ctx.moveTo(p7.x, p7.y); }   /* 小さい円は右半分だけ */
    } else ctx.arc(O.x, O.y, R * S, 0, TAU);
    ctx.stroke(); ctx.restore();
  }
  if (s.mode === 'mode4' && GS === 3 && !SN) {                    /* 4-2：最高点の印（4-1 と同じ。2026-10-07 千葉さん） */
    var tq4 = P(0, R); ctx.save(); ctx.fillStyle = '#d1352b'; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(tq4.x, tq4.y, 4, 0, TAU); ctx.fill(); ctx.stroke(); ctx.restore();
    label(ctx, '最高点', tq4.x - 8, tq4.y - 12, { size: 11.5, bold: true, color: '#b2271b', align: 'right' });
  }
  /* 外の観測者（床の上に立つ） */
  var hdIn;
  var up = function (foot, h, z) { var a = P(foot[0], foot[1], z), b = P(foot[0], foot[1] + h, z); var L = Math.hypot(b.x - a.x, b.y - a.y); return { a: a, ux: (b.x - a.x) / L, uy: (b.y - a.y) / L, L: L }; };
  if (GS === 3) {                                            /* 糸の一端は支柱の上のくぎ（中心）。支柱は奥にあるので、うすく描く */
    var pb = P(0, floorY), pt = P(0, -0.02);
    ctx.save(); ctx.strokeStyle = 'rgba(122,110,92,.55)'; ctx.lineWidth = 6; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(pb.x, pb.y); ctx.lineTo(pt.x, pt.y); ctx.stroke(); ctx.restore();
    ctx.save(); ctx.fillStyle = '#2b323c'; ctx.beginPath(); ctx.arc(O.x, O.y, 4, 0, TAU); ctx.fill(); ctx.restore();
    if (S6) {                                                    /* 釘 C（O の真下 r）と、点 O・C・B の名前 */
      var Cp = P(0, -r6); ctx.save(); ctx.fillStyle = '#2b323c'; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(Cp.x, Cp.y, 4.2, 0, TAU); ctx.fill(); ctx.stroke(); ctx.restore();
      label(ctx, 'O', O.x + 9, O.y - 8, { size: 12, bold: true, color: COL.sub, align: 'left' });
      label(ctx, 'C（釘）', Cp.x + 9, Cp.y - 6, { size: 12, bold: true, color: COL.sub, align: 'left' });
      var Bq = P(0, -R); label(ctx, 'B', Bq.x + 10, Bq.y + 12, { size: 12, bold: true, color: COL.sub, align: 'left' });
    }
    var fo3 = [-0.86, floorY], uo3 = up(fo3, 0.40);
    if (!SN) hdIn = observer(ctx, uo3.a.x, uo3.a.y, uo3.ux, uo3.uy, '外の観測者', !s.rot, uo3.L, { dy: 2 });
  } else {
    var fo = sec === 7 ? [1.55, floorY] : (GS === 1 ? [-1.05, floorY] : [-0.72, floorY]), uo = up(fo, 0.40, D3 ? 0.20 : 0);   /* ③-3 は左に斜面があるので右に立つ */
    if (!SN) hdIn = observer(ctx, uo.a.x, uo.a.y, uo.ux, uo.uy, '外の観測者', !s.rot, uo.L, { dy: 2 });
  }
  /* 基準の線（中心から最下点／最高点へ）と、半径・角 θ（円の上にいるとき） */
  var refUp = GS === 2;
  if (q.kind === 'circle' || q.kind === 'fly') {
    line(cq[0], cq[1], cq[0], cq[1] + (refUp ? Rq : -Rq), '#6f7782', 1.1, [4, 4]);
    var aNow = q.kind === 'fly' ? tr.ev.ang : q.ang, pr = GS === 2 ? [R * Math.sin(aNow), R * Math.cos(aNow)] : [cq[0] + Rq * Math.sin(aNow), cq[1] - Rq * Math.cos(aNow)];
    if (q.kind === 'circle' && !S6) line(0, 0, pr[0], pr[1], GS === 3 ? '#7a5a32' : '#6f7782', GS === 3 ? 1.8 : 1.1, GS === 3 ? null : [3, 3]);
    var an = aNow >= 0 ? aNow % TAU : -((-aNow) % TAU), aa = Math.abs(an);   /* θ は 180° を超えてもそのまま（0〜360°。1 周したら 0 から。2026-10-07 千葉さん） */
    if (aa > 0.15) {                                         /* 角 θ（基準線から、いまの半径まで） */
      var rA = 0.13, st0 = refUp ? Math.PI / 2 : -Math.PI / 2, a3 = (GS === 2 ? -1 : 1) * an;
      ctx.save(); ctx.strokeStyle = COL.ink2; ctx.lineWidth = 1.2; ctx.beginPath();
      for (var j = 0; j <= 24; j++) { var aj = st0 + a3 * j / 24, pj = P(cq[0] + rA * Math.cos(aj), cq[1] + rA * Math.sin(aj)); j ? ctx.lineTo(pj.x, pj.y) : ctx.moveTo(pj.x, pj.y); }
      ctx.stroke(); ctx.restore();
      var am = st0 + a3 / 2, pm = P(cq[0] + (rA + 0.07) * Math.cos(am), cq[1] + (rA + 0.07) * Math.sin(am)); sym(ctx, 'θ', pm.x, pm.y, { size: 15 });
    }
    if (GS !== 3 && q.kind === 'circle') { var rl = P(pr[0] * 0.55 + 0.04, pr[1] * 0.55 + 0.04); sym(ctx, 'r', rl.x, rl.y, { size: 15 }); }
    if (GS === 3 && q.kind === 'circle') { var rl3 = P((cq[0] + pr[0]) * 0.5 + (pr[1] - cq[1] >= 0 ? 0.05 : -0.05), (cq[1] + pr[1]) * 0.5 + 0.05); sym(ctx, S6 && !onC ? '2r' : 'r', rl3.x, rl3.y, { size: 15 }); }
  }
  /* はなれた点と、そのあとの道すじ */
  if (m3After(s, tr)) {
    var e = M3.at(tr, tr.ev.t), eo = offOf(e), ep = P(e.x + eo[0], e.y + eo[1]);
    ctx.save(); ctx.setLineDash([6, 4]); ctx.strokeStyle = COL.vel; ctx.globalAlpha = 0.75; ctx.lineWidth = 1.6; ctx.beginPath();
    var fst = true; tr.pts.forEach(function (p) { if (p.t < tr.ev.t || p.t > s.t) return; var o2 = offOf(p), pp = P(p.x + o2[0], p.y + o2[1]); fst ? ctx.moveTo(pp.x, pp.y) : ctx.lineTo(pp.x, pp.y); fst = false; });
    ctx.stroke(); ctx.restore();
    var ec = (S6 && tr.ev.cir === 'C') ? P(0, -r6) : P(0, 0);   /* 中心から、離れた／たるんだ点まで点線（2026-10-14 千葉さん） */
    ctx.save(); ctx.setLineDash([4, 4]); ctx.strokeStyle = COL.vel; ctx.lineWidth = 1.3; ctx.beginPath(); ctx.moveTo(ec.x, ec.y); ctx.lineTo(ep.x, ep.y); ctx.stroke(); ctx.restore();
    ctx.save(); ctx.fillStyle = COL.vel; ctx.beginPath(); ctx.arc(ep.x, ep.y, 3, 0, TAU); ctx.fill(); ctx.restore();
    if (!(tr.ev.kind === 'top' && s.mode === 'mode4')) label(ctx, tr.ev.kind === 'slack' ? 'たるんだ点' : (tr.ev.kind === 'top' ? '最高点' : '離れた点'), ep.x + 14, ep.y + 14, { size: 10.5, color: COL.vel, align: 'left' });
  }
  /* 糸（3-3・4-2）：手から小球まで。たるんだあとは曲がった線 */
  if (GS === 3) {
    var hnd2 = P(0, 0), hc = P(cq[0], cq[1]);
    ctx.save(); ctx.strokeStyle = '#7a5a32'; ctx.lineWidth = 1.7; ctx.beginPath(); ctx.moveTo(hnd2.x, hnd2.y);
    if (onC) ctx.lineTo(hc.x, hc.y);                             /* ③-5：釘に触れたあとは O → C → 小球 */
    if (q.kind === 'fly') { var mid = P((bx + cq[0]) * 0.5 + 0.0, (by + cq[1]) * 0.5 - 0.10); ctx.quadraticCurveTo(mid.x, mid.y, Bp.x, Bp.y); } else ctx.lineTo(Bp.x, Bp.y);
    ctx.stroke(); ctx.restore();
  }
  /* 軌跡（少し前までの道すじ）→ 小球 */
  if (SN) {                                                     /* コマ図：それまでの道すじを点線で */
    ctx.save(); ctx.setLineDash([2, 4]); ctx.strokeStyle = 'rgba(22,99,181,.55)'; ctx.lineWidth = 1.6; ctx.beginPath();
    var f0 = true; tr.pts.forEach(function (p) { if (p.t > s.t || (tr.ev && p.t >= tr.ev.t)) return; var o2 = offOf(p), pp = P(p.x + o2[0], p.y + o2[1]); f0 ? ctx.moveTo(pp.x, pp.y) : ctx.lineTo(pp.x, pp.y); f0 = false; });
    ctx.stroke(); ctx.restore();
  } else {
    s.autoTrail = !!(tr.ev && s.t >= tr.ev.t - 0.25);           /* 離れる・たるむ・飛び出す前後は軌跡を自動で描く */
    trailStep(ctx, s, function (x, y, z) { return P(x, y, z); }, [bx, by, zb], C.sgn * (q.ang - m3Ref(s)));
  }
  ballShape(ctx, Bp.x, Bp.y, rb * S, '#c9d3de');
  /* デコピン：はじめの小球の位置のうしろから、進む向きへはじく（3-1・3-2 は右へ、3-4 は円の接線方向に時計回り） */
  if (s.t < 0.34 && !SN) {
    var q0 = M3.at(tr, 0), o0 = offOf(q0), B0 = P(q0.x + o0[0], q0.y + o0[1]);
    var t0r = m3Th0(s) * Math.PI / 180, fa = sec === 3 ? Math.atan2(Math.sin(t0r), -Math.cos(t0r)) : (S6 ? t0r : (sec === 7 ? tr.geo.alpha : 0)), back = rb * S + 38;   /* 画面の向き（右が 0、下が π/2） */
    if (s.v.v0 < 0.05) {                                          /* 初速度 0：デコピンではなく、手でそっと放す（mechanical-energy.html 1-2 と同じ） */
      var hA = (s.t <= 0.18) ? 1 : Math.max(0, 1 - (s.t - 0.18) / 0.22);
      if (hA > 0.02) dropHand(ctx, B0.x, B0.y, 0.5, clamp(s.t / 0.18, 0, 1), hA);
      if (s.t <= 1e-9) bubble(ctx, 'そっと手を放す（初速度 0）', B0.x + 6, B0.y - 58, { size: 12, bg: '#fff5e8', border: '#e07b18', color: '#a85c0c' });
    } else flickStart(ctx, s.t, s.v.v0, B0.x - Math.cos(fa) * back, B0.y - Math.sin(fa) * back, fa, (sec === 3 || S6) ? 40 : 46, s.mode === 'mode4');
  }
  /* 一緒に回る観測者（小球に乗っている人）：頭は 3-1・3-3 では中心向き、3-2 では外向き。床の上では上向き */
  var upv;
  if (q.kind === 'floor') upv = [0, 1];
  else if (q.kind === 'slope') upv = [Math.sin(tr.geo.alpha), Math.cos(tr.geo.alpha)];   /* 斜面に垂直 */
  else { var a4 = q.kind === 'fly' ? tr.ev.ang : q.ang; upv = GS === 2 ? [Math.sin(a4), Math.cos(a4)] : [-Math.sin(a4), Math.cos(a4)]; }
  var tv = [upv[1], -upv[0]], rf = [bx + upv[0] * rb * 0.6 + tv[0] * 0.065, by + upv[1] * rb * 0.6 + tv[1] * 0.065];   /* 力の矢印（中心を通る線）と重ならないよう横へ */
  var ur2 = up(rf, 1), u2 = P(rf[0] + upv[0] * 0.16, rf[1] + upv[1] * 0.16), a5 = P(rf[0], rf[1]);
  var Lr = Math.hypot(u2.x - a5.x, u2.y - a5.y);
  var handOn = s.v.v0 < 0.05 && s.t < 0.4 && !s.rot;            /* 手でそっと放すあいだは、小球に乗る観測者を描かない（手と重なるため） */
  var hdRot = (SN || handOn) ? null : observer(ctx, a5.x, a5.y, (u2.x - a5.x) / Lr, (u2.y - a5.y) / Lr, '', s.rot, Lr);
  if (!SN && !handOn) { var tq = P(rf[0] + tv[0] * 0.10 + upv[0] * 0.08, rf[1] + tv[1] * 0.10 + upv[1] * 0.08);   /* 名前は人の横（吹き出しと重ならないように） */
    ctx.save(); if (!s.rot) ctx.globalAlpha *= OBS_DIM;
    label(ctx, '一緒に回る観測者', tq.x, tq.y, { size: s.rot ? 11.5 : 10.5, bold: s.rot, color: s.rot ? COL.vel : '#9aa3ac', align: tv[0] >= 0 ? 'left' : 'right' }); ctx.restore(); }
  /* ---- 力 ---- */
  if (tr.fmax === undefined) { tr.fmax = 0; tr.pts.forEach(function (p) { tr.fmax = Math.max(tr.fmax, p.F); }); }
  var fmax = tr.fmax;
  var fs = Math.min(0.10, 0.50 / Math.max(fmax, m * G));        /* 矢印の長さ［m/N］：いちばん大きい力でも 0.50 m */
  var arr = function (x0, y0, dx, dy, L, kind, col, opt) {      /* 物理の点 (x0,y0) から向き (dx,dy) へ長さ L［m］ */
    var a = P(x0, y0), b = P(x0 + dx * L, y0 + dy * L);
    if (Math.hypot(b.x - a.x, b.y - a.y) < 3) return null;
    return arrow(ctx, a.x, a.y, b.x, b.y, kind, col, opt);
  };
  var tg = [upv[1], -upv[0]];                                   /* 横（接線）にずらす向き */
  if (showF) {
    var amg = arr(bx + tg[0] * 0.015, by + tg[1] * 0.015, 0, -1, m * G * fs, 'force', COL.force);
    if (amg) label(ctx, 'mg', amg.x2 + amg.ux * 10, amg.y2 + amg.uy * 10 + 2, { size: 13, bold: true, color: COL.force });
    if (q.kind !== 'fly' && q.F > 1e-6) {
      var cpt, dir;
      if (q.kind === 'floor') { cpt = [bx - tg[0] * 0.015, by - rb]; dir = [0, 1]; }
      else if (GS === 3) { var ul = Math.hypot(bx - cq[0], by - cq[1]); dir = [(cq[0] - bx) / ul, (cq[1] - by) / ul]; cpt = [bx + dir[0] * rb, by + dir[1] * rb]; }
      else { cpt = [q.x - tg[0] * 0.015, q.y - tg[1] * 0.015]; dir = upv; }
      var aF = arr(cpt[0], cpt[1], dir[0], dir[1], q.F * fs, 'force', GS === 3 ? COL.hand : COL.norm);
      if (aF) {                                                   /* 重力と同じ向き（最高点付近）のときは、重力の矢印と反対がわへ文字をずらす */
        var sx = aF.uy * 8, sy = -aF.ux * 8;
        if (amg && Math.abs(aF.ux * amg.ux + aF.uy * amg.uy) > 0.8) { var dx0 = aF.x1 - amg.x1, dy0 = aF.y1 - amg.y1, dl = Math.hypot(dx0, dy0) || 1; sx = dx0 / dl * 16; sy = dy0 / dl * 16; }
        label(ctx, C.fName, aF.x2 + aF.ux * 11 + sx, aF.y2 + aF.uy * 11 + sy, { size: 13, bold: true, color: GS === 3 ? COL.hand : COL.norm });
      }
    }
    if (s.rot && q.kind === 'circle') {                          /* 見かけの力：遠心力（外向き）と、接線方向の慣性力 −m a_t */
      var rl2 = Math.hypot(q.x - cq[0], q.y - cq[1]), uo2 = [(q.x - cq[0]) / rl2, (q.y - cq[1]) / rl2], v2 = q.v * q.v;
      var ac = arr(bx, by, uo2[0], uo2[1], m * v2 / Rq * fs, 'fict', COL.cent);
      centLabel(ctx, ac, s);
      var tdir = GS === 2 ? [Math.cos(q.ang), -Math.sin(q.ang)] : [Math.cos(q.ang), Math.sin(q.ang)];   /* 角が増える向き */
      var ft2 = -m * q.at, sgn2 = ft2 >= 0 ? 1 : -1;
      var at2 = arr(bx, by, tdir[0] * sgn2, tdir[1] * sgn2, Math.abs(ft2) * fs, 'fict', COL.cent);
      if (at2) label(ctx, '接線方向の慣性力', at2.x2 + at2.ux * 14, at2.y2 + at2.uy * 14 - 10, { size: 11, bold: true, color: COL.cent });
    }
  }
  /* 速度（慣性系だけ）：小球から外がわへ離して、まん中をそろえる */
  if (!s.rot && q.v > 0.02) {
    var nv = q.kind === 'floor' ? [0, 1] : q.kind === 'slope' ? upv : (q.kind === 'fly' ? [-q.vy / q.v, q.vx / q.v] : (GS === 2 ? upv : [-upv[0], -upv[1]]));
    if (q.kind === 'fly' && nv[1] < 0) nv = [-nv[0], -nv[1]];
    var cv = [bx + nv[0] * 0.13, by + nv[1] * 0.13], Lv = q.v * 0.06, uvv = [q.vx / q.v, q.vy / q.v];
    var va = P(cv[0] - uvv[0] * Lv / 2, cv[1] - uvv[1] * Lv / 2), vb = P(cv[0] + uvv[0] * Lv / 2, cv[1] + uvv[1] * Lv / 2);
    var av = arrow(ctx, va.x, va.y, vb.x, vb.y, 'vel');
    if (av) sym(ctx, 'v', vb.x + av.ux * 10, vb.y + av.uy * 10 - 4, { size: 16, color: COL.vel, vec: true });
  }
  drawEqualTicks(ctx);
  /* 吹き出し：いまの視点の観測者のセリフ、できごと */
  var after = m3After(s, tr);
  var say = after ? M2SAY[tr.ev.kind] : (q.kind === 'slope' ? '斜面を加速しながら下っているな' : q.kind === 'floor' ? 'まっすぐ等速で進んでいるな' : (s.rot ? '力がつり合っているな' : '速さを変えながら円運動しているな'));
  if (!SN) speech(ctx, say, s.rot ? hdRot : hdIn);
  if (SN) { if (s._snapEv) eventBubble(ctx, tr.ev.kind, Bp.x, Bp.y - rb * S - 22); return; }   /* コマ図は「瞬間」のコマだけできごとの吹き出し */
  if (after && s.t - tr.ev.t < 1.6) {                          /* 観測者のセリフと重ならないよう、非慣性系では小球の下に出す */
    if (s.rot) eventBubble(ctx, tr.ev.kind, Bp.x, Bp.y + rb * S + 6, 'up'); else eventBubble(ctx, tr.ev.kind, Bp.x, Bp.y - rb * S - 22);
  }
  if (m3IsLoop(sec) && tr.done === 'loop') {                       /* 3-2 ループ：最高点を通ったら「宙返りした！」（2026-10-06 千葉さん） */
    if (tr.tTop === undefined) { tr.tTop = null; for (var it = 0; it < tr.pts.length; it++) if (tr.pts[it].kind === 'circle' && tr.pts[it].ang >= Math.PI) { tr.tTop = tr.pts[it].t; break; } }
    if (tr.tTop !== null && s.t >= tr.tTop && s.t - tr.tTop < 0.7) { if (s.rot) eventBubble(ctx, 'loop', Bp.x, Bp.y + rb * S + 6, 'up'); else eventBubble(ctx, 'loop', Bp.x, Bp.y - rb * S - 22); }
  }
  if (S6 && !SN && tr.tSw && tr.tSw.length) {                  /* ③-5：釘に触れた／離れた瞬間の吹き出し（0.6 秒） */
    var kS = -1; tr.tSw.forEach(function (ts, i) { if (ts <= s.t + 1e-9) kS = i; });
    if (kS >= 0 && s.t - tr.tSw[kS] < 0.6 && !m3After(s, tr)) {   /* たるんだあとは「糸がたるんだ！」だけ */
      var Cq = P(0, -r6); bubble(ctx, kS % 2 === 0 ? '釘に触れた！' : '釘から離れた', Cq.x - 46, Cq.y - 14, { size: 13, bg: '#dff2ee', border: '#0f8a8a', color: '#0a5c5c' });
    }
  }
  if (!SN) m3EvNote(s, tr, m3After(s, tr) && (tr.ev.kind === 'off' || tr.ev.kind === 'slack'));   /* 離れた／たるんだ角（それ以降、アニメの終わりまで） */
  pill(ctx, '状態：' + m3Phase(q, tr), 10, 10, { size: 12 });

}

/* 面から離れた／糸がたるんだときの cosθ を、図のあいている所（真ん中の右か左）に出す（2026-10-14 千葉さん）。θ はそのセクションの θ（3-4 は最高点から、ほかは最下点から） */
var M3EVSIDE = { 1: 'L', 2: 'L', 3: 'R', 4: 'R', 5: 'R', 6: 'R', 7: 'R' };
/* cos θ の値を、分数・文字式で（0.667 ではなく 2/3。入試ではこの形の出題が多い。2026-10-14 千葉さん）。
   ふつう cosθ = c0 − v0²/(3gr) の形。c0 は h・θ0 で決まる定数（v0 = 0 なら c0 だけ） */
function m3Frac(n, d) {                                         /* n/d（整数）を TeX の分数に */
  var g = function (a, b) { return b ? g(b, a % b) : a; }, k = g(Math.abs(n), Math.abs(d)) || 1; n /= k; d /= k;
  if (d < 0) { n = -n; d = -d; }
  if (n === 0) return '0';
  return (n < 0 ? '-' : '') + (d === 1 ? String(Math.abs(n)) : '\\dfrac{' + Math.abs(n) + '}{' + d + '}');
}
function m3EvCosTex(s, tr) {
  var sec = s.def.sec, v0 = s.v.v0 || 0, t0 = m3Th0(s), c0, sg = '-';
  if (tr.ev.t <= 1e-9) return '-1';                              /* 最高点で、はじめからたるむ */
  if (sec === 2) { c0 = '\\dfrac{2}{3}'; sg = '+'; }
  else if (sec === 3) c0 = { 0: '\\dfrac{2}{3}', 30: '\\dfrac{\\sqrt{3}}{3}', 90: '0', 180: '-\\dfrac{2}{3}' }[t0];
  else if (sec === 6) c0 = { 0: '\\dfrac{2}{3}', 30: '\\dfrac{2\\sqrt{3}-2}{3}', 90: '-\\dfrac{2}{3}', 180: '-2' }[t0];
  else if (sec === 7) c0 = m3Frac(Math.round(2 * (2 - 2 * s.v.h)), 6);
  else c0 = '\\dfrac{2}{3}';
  var vt = '\\dfrac{v_0^{\\,2}}{3gr}';
  if (v0 < 1e-9) return c0;
  return c0 === '0' ? (sg === '-' ? '-' : '') + vt : c0 + ' ' + sg + ' ' + vt;
}
/* 面から離れた／糸がたるんだときの cosθ を、図のあいている所（真ん中の右か左）に。canvas の上に重ねた HTML（KaTeX） */
var M3EVSIDE = { 1: 'L', 2: 'L', 3: 'R', 4: 'R', 5: 'R', 6: 'R', 7: 'R' };
function m3EvNote(s, tr, on) {
  if (!s._evn) { s._evn = el('div', 'm3evn'); s._evn.setAttribute('aria-live', 'polite'); s.cw.appendChild(s._evn); }
  var d = s._evn;
  if (!on) { if (d._k !== '') { d._k = ''; d.style.display = 'none'; } return; }
  var L = M3EVSIDE[s.def.sec] === 'L', key = tr.key + '|' + (L ? 'L' : 'R');
  if (d._k === key) return;
  d._k = key; d.style.display = '';
  d.classList.toggle('lft', L);
  d.innerHTML = '<b>' + (tr.ev.kind === 'off' ? '面から離れたとき' : '糸がたるんだとき') + '</b>' + tex('\\cos\\theta = ' + m3EvCosTex(s, tr));
}
/* ===================== 式（図の下の 2 つの箱） ===================== */
function m3Eqs(sec, q, tr) {
  var GS = m3GS(sec), m = M3.m, R = (sec === 6 && q.cir === 'C') ? M3.R / 2 : M3.R, v = q.v, F = q.F, th = Math.abs(q.ang), fn = GS === 3 ? 'S' : 'N';
  var nm = fmt(m * v * v / R, 2), mgc = fmt(m * G * Math.cos(th), 2);
  if (q.kind === 'slope') return {
    in: { h: '【慣性系】斜面をすべりおりる', lines: [{ tag: 'bal', k: '斜面に垂直：', t: 'N - mg\\cos\\alpha = 0' }, { tag: 'eom', k: '斜面に沿って：', t: 'ma = mg\\sin\\alpha' }], note: 'α は斜面の傾き（この図では 45°）' },
    rot: { h: '【非慣性系】まだ円運動していない', lines: [{ tag: 'bal', k: '斜面に垂直：', t: 'N - mg\\cos\\alpha = 0' }, { tag: 'bal', k: '斜面に沿って：', t: 'mg\\sin\\alpha - ma = 0' }], note: '一緒に加速する観測者には、斜面に沿って上向きの慣性力 ma がはたらいて見える' } };
  if (q.kind === 'floor') return {
    in: { h: '【慣性系】床の上を等速で進む', lines: [{ tag: 'bal', k: '鉛直方向：', t: 'N - mg = 0' }], note: '水平方向には力がはたらかない（等速直線運動）' },
    rot: { h: '【非慣性系】まだ円運動していない', lines: [{ tag: 'bal', k: '鉛直方向：', t: 'N - mg = 0' }], note: '等速で動いているあいだは、見かけの力ははたらかない' } };
  if (q.kind === 'fly') return {
    in: { h: '【慣性系】' + (tr.ev.kind === 'slack' ? '糸がたるんだ' : (tr.ev.kind === 'top' ? '最高点から飛び出した' : '面から離れた')) + '→ 放物運動', lines: [{ tag: 'eom', k: '', t: 'm\\vec{a} = m\\vec{g}' }], note: '重力だけを受けて落ちていく' },
    rot: { h: '【非慣性系】円運動をやめた', lines: [{ k: '', t: (GS === 3 ? 'S' : 'N') + ' = 0' }], note: '観測者は小球と一緒に落ちていく（円運動の非慣性系ではなくなる）' } };
  var Ls = {
    1: { in: [{ tag: 'eom', k: '中心方向：', t: 'm\\dfrac{v^2}{r} = N - mg\\cos\\theta', cf: 'N - mg\\cos\\theta', cfn: '中心向きの合力' }, { tag: 'eom', k: '接線方向：', t: 'ma_t = -mg\\sin\\theta' }],
         rot: [{ tag: 'bal', k: '中心方向：', t: 'N - mg\\cos\\theta - \\underbrace{m\\dfrac{v^2}{r}}_{\\text{遠心力}} = 0' }, { tag: 'bal', k: '接線方向：', t: '-mg\\sin\\theta \\underbrace{- ma_t}_{\\text{慣性力}} = 0' }] },
    2: { in: [{ tag: 'eom', k: '中心方向：', t: 'm\\dfrac{v^2}{r} = mg\\cos\\theta - N', cf: 'mg\\cos\\theta - N', cfn: '中心向きの合力' }, { tag: 'eom', k: '接線方向：', t: 'ma_t = mg\\sin\\theta' }],
         rot: [{ tag: 'bal', k: '中心方向：', t: 'mg\\cos\\theta - N - \\underbrace{m\\dfrac{v^2}{r}}_{\\text{遠心力}} = 0' }, { tag: 'bal', k: '接線方向：', t: 'mg\\sin\\theta \\underbrace{- ma_t}_{\\text{慣性力}} = 0' }] },
    3: { in: [{ tag: 'eom', k: '中心方向：', t: 'm\\dfrac{v^2}{r} = S - mg\\cos\\theta', cf: 'S - mg\\cos\\theta', cfn: '中心向きの合力' }, { tag: 'eom', k: '接線方向：', t: 'ma_t = -mg\\sin\\theta' }],
         rot: [{ tag: 'bal', k: '中心方向：', t: 'S - mg\\cos\\theta - \\underbrace{m\\dfrac{v^2}{r}}_{\\text{遠心力}} = 0' }, { tag: 'bal', k: '接線方向：', t: '-mg\\sin\\theta \\underbrace{- ma_t}_{\\text{慣性力}} = 0' }] }
  }[GS];
  var num = GS === 2 ? 'いま：' + nm + ' ＝ ' + mgc + ' − ' + fmt(F, 2) + '（N）' : 'いま：' + nm + ' ＝ ' + fmt(F, 2) + ' − (' + mgc + ')（' + fn + '）';
  var num2 = GS === 2 ? 'いま：' + mgc + ' − ' + fmt(F, 2) + ' − ' + nm + ' ＝ 0' : 'いま：' + fmt(F, 2) + ' − (' + mgc + ') − ' + nm + ' ＝ 0';
  return {
    in: { h: '【慣性系】円運動している（速さも変わる）', lines: Ls.in, num: num, note: '※ 慣性系に「遠心力」は存在しない。θ は' + (GS === 2 ? '最高点' : '最下点') + 'からの角' },
    rot: { h: '【非慣性系】止まって見える', lines: Ls.rot, num: num2, note: '※ 遠心力と接線方向の慣性力（注）は、一緒に回る観測者だけが感じる見かけの力' } };
}
/* 3-1・3-2 から ④-1 へ（なぜ N ≥ 0 が条件になるのか） */
var M3LINK4 = '<p class="m4link">なぜ $N \\ge 0$ が条件になるのか、くわしくは <a href="#4-1">④-1 最高点まで昇る条件</a> を参照。</p>';
var M3LINK42 = '<p class="m4link">なぜ $S \\ge 0$ が条件になるのか、くわしくは <a href="#4-2">④-2 糸による円運動で 1 周できるか</a> を参照。</p>';   /* 3-4 から ④-2 へ */
var M3NOTE = '<p class="qnote">（注）速さが変わる円運動では、一緒に回る観測者には、遠心力の他に<b>接線方向の慣性力 $-ma_t$</b> もはたらいて見える。高校の教科書では、ふつう中心方向（遠心力）だけを扱う。</p>';
/* 右の列の「立式」カード（モード2 と同じ形）。方向は「中心方向」と「接線方向」。sec ごとの式は m3Eqs と同じ */
function m3Frame(s, sec, inTxt, rotTxt) {
  var E = { 1: ['m\\dfrac{v^2}{r} = N - mg\\cos\\theta', 'ma_t = -mg\\sin\\theta', 'N - mg\\cos\\theta - m\\dfrac{v^2}{r} = 0', '-mg\\sin\\theta - ma_t = 0'],
            2: ['m\\dfrac{v^2}{r} = mg\\cos\\theta - N', 'ma_t = mg\\sin\\theta', 'mg\\cos\\theta - N - m\\dfrac{v^2}{r} = 0', 'mg\\sin\\theta - ma_t = 0'],
            3: ['m\\dfrac{v^2}{r} = S - mg\\cos\\theta', 'ma_t = -mg\\sin\\theta', 'S - mg\\cos\\theta - m\\dfrac{v^2}{r} = 0', '-mg\\sin\\theta - ma_t = 0'] }[m3GS(sec)];
  return m2Setup(s, {
    lead: { in: inTxt, rot: rotTxt },
    rows: [{ dir: '中心方向', in: ['eom', E[0], { 1: 'N - mg\\cos\\theta', 2: 'mg\\cos\\theta - N', 3: 'S - mg\\cos\\theta' }[m3GS(sec)], '中心向きの合力'], rot: ['bal', E[2]] }, { dir: '接線方向', in: ['eom', E[1]], rot: ['bal', E[3]] }],
    note: { in: '<p class="qnote">外（慣性系）から見ると加速度があるので' + T_EOM + 'を、<b>中心方向</b>（加速度 $\\dfrac{v^2}{r}$）と<b>接線方向</b>（加速度 $a_t$）に分けて立てる。慣性系に「遠心力」は存在しない。</p>', rot: M3NOTE } });
}
/* 「理論的背景」（力学的エネルギー保存則と、条件の導出）は折りたためる。既定は開いておく（2026-10-04 千葉さん） */
function m3TheoryOpen(s) { return '<details class="theory"' + (s.theoryClosed ? '' : ' open') + '><summary>理論的背景<span>（力学的エネルギー保存則・条件の導出）</span></summary><div class="thbody">'; }
function m3Energy(tr, eqTex) {
  return '<div class="qcard"><p class="qt">力学的エネルギー保存則</p><p>垂直抗力や張力は速度と垂直なので仕事をしない。重力だけが仕事をするので、力学的エネルギーは保存する（右下のグラフの $E$ が水平）。</p>' +
    '<div class="qeq">' + tex(eqTex, true) + '</div></div>';
}

/* ===================== セクション1 なめらかな円筒面をのぼる ===================== */
DEFS.m3s1 = m3Base({
  id: 'm3s1', num: 1, sec: 1, title: 'なめらかな円筒面を上る小球',
  desc: '床から円筒面の内側を上らせる。中心方向の力は<b>垂直抗力と重力の成分</b>。<span class="todo">$v_0$ を変えて ▶ スタートし、最高点まで達するか見よう。</span>',
  vars: [{ k: 'v0', label: '初速 $v_0$', aria: '初速', min: 1.0, max: 6.0, step: 0.1, def: 4.0, dec: 1, unit: 'm/s',
    mark: function () { return [{ x: Math.sqrt(2 * G * M3.R), label: '$\\sqrt{2gr}$' }, { x: Math.sqrt(5 * G * M3.R), label: '$\\sqrt{5gr}$' }]; } }],
  msg: function (s) {
    var tr = m3Tr(s), q = M3.at(tr, s.t), v0 = s.v.v0, r2 = Math.sqrt(2 * G * M3.R), r5 = Math.sqrt(5 * G * M3.R);
    if (tr.ev && tr.ev.kind === 'off' && s.t >= tr.ev.t) return '<b>面から離れた！</b>（$N = 0$）　$\\theta = ' + fmt(tr.ev.ang * 180 / Math.PI, 1) + '^\\circ$ で離れ、そのあとは放物運動。' + (s.ended ? '円筒面か床にぶつかったところで止めた。' : '');
    if (tr.ev && tr.ev.kind === 'top' && s.t >= tr.ev.t) return '<b>最高点に達した！</b>　その先には円筒面がないので、最高点から水平に飛び出して放物運動。';
    if (v0 >= r5) return '$v_0 \\ge \\sqrt{5gr} = ' + fmt(r5, 2) + '$ m/s なので、最高点まで面から離れずに達する。';
    if (v0 <= r2) return '$v_0 \\le \\sqrt{2gr} = ' + fmt(r2, 2) + '$ m/s なので、中心の高さまで上らずに止まり、滑り戻る（$N$ は 0 にならない）。';
    return '▶ スタート。$\\sqrt{2gr} < v_0 < \\sqrt{5gr}$ なので、中心より高いところで面から離れる。';
  },
  eqs: function (s, q) { return m3Eqs(1, q, m3Tr(s)); },
  right: function (s, tr) {
    var v0 = s.v.v0, R = M3.R, r5 = Math.sqrt(5 * G * R);
    var h = m3Frame(s, 1, '小球は円の中心へ向かう加速度 $\\dfrac{v^2}{r}$ をもつ。中心向きの合力は $N - mg\\cos\\theta$（$\\theta$ は最下点からの角）。',
      '一緒に回る観測者には小球が止まって見える。遠心力と接線方向の慣性力を加えて、力がつり合う。');
    h += m3TheoryOpen(s) + m3Energy(tr, '\\dfrac{1}{2}mv_0^{\\,2} = \\dfrac{1}{2}mv^2 + mgr(1 - \\cos\\theta)');
    h += '<div class="qcard derive"><p class="qt">最高点に達する条件</p><p>最高点（$\\theta = 180^\\circ$）で面から離れないためには $N \\ge 0$。最高点での速さを $v_1$ とすると</p>' +
      '<div class="qeq">' + eqRow('eom', 'm\\dfrac{v_1^{\\,2}}{r} = N + mg \\;\\Longrightarrow\\; v_1^{\\,2} \\ge gr') + tex('\\dfrac{1}{2}mv_0^{\\,2} = \\dfrac{1}{2}mv_1^{\\,2} + mg(2r)\\ \\Longrightarrow\\ v_0 \\ge \\sqrt{5gr}', true) + '</div>' +
      '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('\\sqrt{5gr} = \\sqrt{5\\times 9.8\\times ' + fmt(R, 2) + '} = ' + fmt(r5, 2) + '\\ \\text{m/s}') + '（いま ' + tex('v_0 = ' + fmt(v0, 1)) + ' m/s）</p>' +
      '<p class="qnote">$N = 0$ になる角は $\\cos\\theta = \\dfrac{2gr - v_0^{\\,2}}{3gr}$。$v_0 \\le \\sqrt{2gr}$ のときは、中心の高さまでで速さが 0 になり、滑り戻る。</p>' + M3LINK4 + '</div>';
    h += '</div></details>';
    h += '<p class="assume">' + tex('m = 0.20') + ' kg、' + tex('r = 0.50') + ' m、' + tex('g = 9.8') + ' m/s²。小球の大きさは考えない（図では面の内側に半径ぶんずらして描いた）。最高点の左には円筒面がない。</p>';
    return h;
  }
});
/* ===================== 3-2 なめらかなループ面を上る小球（2026-10-06。以前の 4-1 のループのアニメ＝M3.b4、sec 4） ===================== */
DEFS.m3sL = m3Base({
  id: 'm3sL', num: 2, sec: 4, title: 'なめらかなループ面を上る小球',
  desc: '床からループ面（1 周ぶんの円筒面）の内側を上らせる。中心方向の力は<b>垂直抗力と重力の成分</b>。<span class="todo">$v_0$ を変えて ▶ スタートし、宙返りできるか見よう。</span>',
  vars: [{ k: 'v0', label: '初速 $v_0$', aria: '初速', min: 1.0, max: 6.0, step: 0.1, def: 5.5, dec: 1, unit: 'm/s',
    mark: function () { return [{ x: Math.sqrt(2 * G * M3.R), label: '$\\sqrt{2gr}$' }, { x: Math.sqrt(5 * G * M3.R), label: '$\\sqrt{5gr}$' }]; } }],
  msg: function (s) {
    var tr = m3Tr(s), v0 = s.v.v0, r2 = Math.sqrt(2 * G * M3.R), r5 = Math.sqrt(5 * G * M3.R);
    if (tr.ev && tr.ev.kind === 'off' && s.t >= tr.ev.t) return '<b>面から離れた！</b>（$N = 0$）　$\\theta = ' + fmt(tr.ev.ang * 180 / Math.PI, 1) + '^\\circ$ で離れ、そのあとは放物運動。' + (s.ended ? 'ループ面か床にぶつかったところで止めた。' : '');
    if (tr.done === 'loop' && tr.tTop != null && s.t >= tr.tTop) return '<b>宙返りした！</b>　最高点でも $N \\ge 0$ なので、面から離れずに 1 周した。' + (s.ended ? '1 周して右の床へ出ていった。' : '');
    if (v0 >= r5) return '$v_0 \\ge \\sqrt{5gr} = ' + fmt(r5, 2) + '$ m/s なので、最高点でも面から離れず、宙返りできる。';
    if (v0 <= r2) return '$v_0 \\le \\sqrt{2gr} = ' + fmt(r2, 2) + '$ m/s なので、中心の高さまで上らずに止まり、滑り戻る（$N$ は 0 にならない）。';
    return '▶ スタート。$\\sqrt{2gr} < v_0 < \\sqrt{5gr}$ なので、中心より高いところで面から離れる。';
  },
  eqs: function (s, q) { return m3Eqs(4, q, m3Tr(s)); },
  right: function (s, tr) {
    var v0 = s.v.v0, R = M3.R, r5 = Math.sqrt(5 * G * R);
    var h = m3Frame(s, 4, '小球は円の中心へ向かう加速度 $\\dfrac{v^2}{r}$ をもつ。中心向きの合力は $N - mg\\cos\\theta$（$\\theta$ は最下点からの角）。',
      '一緒に回る観測者には小球が止まって見える。遠心力と接線方向の慣性力を加えて、力がつり合う。');
    h += m3TheoryOpen(s) + m3Energy(tr, '\\dfrac{1}{2}mv_0^{\\,2} = \\dfrac{1}{2}mv^2 + mgr(1 - \\cos\\theta)');
    h += '<div class="qcard derive"><p class="qt">宙返りする（1 周する）条件</p><p>最高点（$\\theta = 180^\\circ$）で面から離れないためには $N \\ge 0$。$N$ は最高点で一番小さいので、最高点で $N \\ge 0$ なら 1 周できる。最高点での速さを $v_1$ とすると</p>' +
      '<div class="qeq">' + eqRow('eom', 'm\\dfrac{v_1^{\\,2}}{r} = N + mg \\;\\Longrightarrow\\; v_1^{\\,2} \\ge gr') + tex('\\dfrac{1}{2}mv_0^{\\,2} = \\dfrac{1}{2}mv_1^{\\,2} + mg(2r)\\ \\Longrightarrow\\ v_0 \\ge \\sqrt{5gr}', true) + '</div>' +
      '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('\\sqrt{5gr} = \\sqrt{5\\times 9.8\\times ' + fmt(R, 2) + '} = ' + fmt(r5, 2) + '\\ \\text{m/s}') + '（いま ' + tex('v_0 = ' + fmt(v0, 1)) + ' m/s）</p>' +
      '<p class="qnote">$N = 0$ になる角は $\\cos\\theta = \\dfrac{2gr - v_0^{\\,2}}{3gr}$。$v_0 \\le \\sqrt{2gr}$ のときは、中心の高さまでで速さが 0 になり、滑り戻る。</p>' + M3LINK4 + '</div>';
    h += '</div></details>';
    h += '<p class="assume">' + tex('m = 0.20') + ' kg、' + tex('r = 0.50') + ' m、' + tex('g = 9.8') + ' m/s²。小球の大きさは考えない（図では面の内側に半径ぶんずらして描いた）。ループは 1 周する間に少し奥へずれる（ループコースターの形）が、真横から見ると半径 ' + tex('r') + ' の円で、運動は円の面内で考える。1 周したら、右の床へ出ていく。</p>';
    return h;
  }
});
/* 3-2・3-3：3 次元のループコースター。最初は斜め上から、▶ スタートで真横からに変える */
function m3Loop3D(d) {
  d.views = [{ label: '斜め上から', az: M3LOOP.obl.az, el: M3LOOP.obl.el }, { label: '真横から', az: 0, el: 0 }]; d.view0 = 0;
  var init0 = d.init; d.init = function (s) { init0(s); s.cam3 = { az: M3LOOP.obl.az, el: M3LOOP.obl.el }; s.camAnim = null; };
  d.onView = function (s, i, user) { var vw = d.views[i]; if (user) m3CamGo(s, vw, 700); else { s.camAnim = null; s.cam3 = { az: vw.az, el: vw.el }; } };
  d.drag3d = function (s, dx, dy) {
    var c = m3CamNow(s); s.camAnim = null;
    s.cam3 = { az: clamp(c.az - dx * 0.35, -80, 80), el: clamp(c.el + dy * 0.30, 0, 70) }; m3CamBtns(s, -1);
  };
  d.onReset = function (s) { m3CamGo(s, M3LOOP.obl, 600); m3CamBtns(s, 0); };
  var ab0 = d.afterBuild;
  d.afterBuild = function (s) {
    ab0(s);
    var tp = s.togglePlay;
    s.togglePlay = function () {                                  /* ▶ スタートを押したら真横からに */
      tp.call(s);
      if (s.playing) m3ToSide(s);
    };
    var pw = s.playWindow;
    s.playWindow = function () { pw.apply(s, arguments); m3ToSide(s); };   /* 「⏱ 離れる瞬間をスローで」も真横から */
  };
  return d;
}
m3Loop3D(DEFS.m3sL);
/* ===================== 3-3 高さのあるループコースター（2026-10-14 千葉さん。M3.b7、sec 7） ===================== */
/* h は r の倍数：r/2 から r/2 刻みで 3r まで、その次は 5r（最大）。1 周できる条件 v0² + 2gh ≥ 5gr、中心の高さまで上る条件 v0² + 2gh > 2gr */
var M3SH = {
  hs: [0.5, 1, 1.5, 2, 2.5, 3, 5], lab: ['\\tfrac{r}{2}', 'r', '\\tfrac{3r}{2}', '2r', '\\tfrac{5r}{2}', '3r', '5r'],
  /* 宙返りに必要な初速 √((5r − 2h)g)（h < 5r/2 のとき） */
  crit: { 0.5: '\\sqrt{4gr}', 1: '\\sqrt{3gr}', 1.5: '\\sqrt{2gr}', 2: '\\sqrt{gr}' },
  /* 中心の高さまで上るのに必要な初速 √(2g(r − h))（h < r のとき） */
  low: { 0.5: '\\sqrt{gr}' }
};
function m3SHLab(hK) { return M3SH.lab[M3SH.hs.indexOf(hK)]; }
function m3SHHint(s) { var hK = s.v.h, lo = M3SH.low[hK] ? M3SH.low[hK] + ' < v_0' : '0 \\le v_0', c = M3SH.crit[hK]; return c ? '$' + lo + ' < ' + c + '$ にしてから、もう一度押そう。' : '$h$ を $2r$ 以下にしてから、もう一度押そう（いまの $h$ では、どんな $v_0$ でも宙返りする）。'; }
DEFS.m3sH = m3Loop3D(m3Base({
  id: 'm3sH', num: 3, sec: 7, title: '高さのあるループコースター',
  desc: '高さ $h$ の点 A から斜面を下らせ、ループ面の内側を上らせる。<span class="todo">$h$ と $v_0$ を変えて ▶ スタートし、宙返りできるか見よう。</span>',
  varCols: [['v0'], ['h']],                  /* ③-4 と同じ 2 つのスライダー（左が初速、右が出発点の高さ） */
  vars: [{ k: 'v0', label: '初速 $v_0$', aria: '初速', min: 0, max: 5.0, step: 0.1, def: 0, dec: 1, unit: 'm/s',
    mark: function (s) {
      var hK = s.v.h, h = hK * M3.R, R = M3.R, out = [];
      if (hK < 1) out.push({ x: Math.sqrt(2 * G * (R - h)), label: '$' + M3SH.low[hK] + '$' });
      if (hK < 2.5) out.push({ x: Math.sqrt(G * (5 * R - 2 * h)), label: '$' + M3SH.crit[hK] + '$' });
      return out;
    } },
    { k: 'h', label: '出発点の高さ $h$', aria: '出発点の高さ', stops: M3SH.hs, stopLabels: ['$r/2$', '$r$', '$3r/2$', '$2r$', '$5r/2$', '$3r$', '$5r$'], def: 3,
      fmt: function (x) { return '$' + m3SHLab(x) + '$ = ' + fmt(x * M3.R, 2) + ' m'; } }],
  msg: function (s) {
    var tr = m3Tr(s), v0 = s.v.v0, hK = s.v.h, R = M3.R, h = hK * R, vb2 = v0 * v0 + 2 * G * h;
    if (tr.ev && tr.ev.kind === 'off' && s.t >= tr.ev.t) return '<b>面から離れた！</b>（$N = 0$）　$\\theta = ' + fmt(tr.ev.ang * 180 / Math.PI, 1) + '^\\circ$ で離れ、そのあとは放物運動。' + (s.ended ? 'ループ面か床にぶつかったところで止めた。' : '');
    if (tr.done === 'loop' && tr.tTop != null && s.t >= tr.tTop) return '<b>宙返りした！</b>　最高点でも $N \\ge 0$ なので、面から離れずに 1 周した。' + (s.ended ? '1 周して右の床へ出ていった。' : '');
    if (vb2 >= 5 * G * R - 1e-9) return (hK === 2.5 && v0 === 0 ? '$h = \\dfrac{5}{2}r$・$v_0 = 0$ は、最高点でちょうど $N = 0$（ぎりぎり宙返りできる）。' : '$v_0^{\\,2} + 2gh \\ge 5gr$ なので、最高点でも面から離れず、宙返りできる。');
    if (vb2 <= 2 * G * R) return '$v_0^{\\,2} + 2gh \\le 2gr$ なので、中心の高さまで上らずに止まり、滑り戻る（$N$ は 0 にならない）。';
    return '▶ スタート。$2gr < v_0^{\\,2} + 2gh < 5gr$ なので、中心より高いところで面から離れる。';
  },
  eqs: function (s, q) { return m3Eqs(7, q, m3Tr(s)); },
  right: function (s, tr) {
    var v0 = s.v.v0, hK = s.v.h, R = M3.R, m = M3.m, h = hK * R, vb2 = v0 * v0 + 2 * G * h, Ntop = m * vb2 / R - 5 * m * G;
    var hx = M3SH.crit[hK];
    var hd = m3Frame(s, 7, '小球は円の中心へ向かう加速度 $\\dfrac{v^2}{r}$ をもつ。中心向きの合力は $N - mg\\cos\\theta$（$\\theta$ は最下点からの角）。斜面と床では円運動していない。',
      '一緒に回る観測者には小球が止まって見える。遠心力と接線方向の慣性力を加えて、力がつり合う。');
    hd += m3TheoryOpen(s) + m3Energy(tr, '\\dfrac{1}{2}mv_0^{\\,2} + mgh = \\dfrac{1}{2}mv^2 + mgr(1 - \\cos\\theta)');
    hd += '<div class="qcard"><p class="qt">ループの点 B でレールがおよぼす力 $N$</p>' +
      '<p>頂点 C から測った角を $\\varphi$（$= \\angle\\mathrm{COB}$）とすると、B の床からの高さは $r + r\\cos\\varphi$。床を位置エネルギーの基準にして</p>' +
      '<div class="qeq">' + tex('\\dfrac{1}{2}mv_0^{\\,2} + mgh = \\dfrac{1}{2}mv_B^{\\,2} + mg(r + r\\cos\\varphi)', true) +
      eqRow('eom', 'm\\dfrac{v_B^{\\,2}}{r} = N + mg\\cos\\varphi') +
      tex('N = \\dfrac{m(v_0^{\\,2} + 2gh)}{r} - mg(2 + 3\\cos\\varphi)', true) + '</div>' +
      '<p class="qnote">$v_0 = 0$ なら $N = mg\\left(\\dfrac{2h}{r} - 2 - 3\\cos\\varphi\\right)$。$N$ は頂点 C（$\\varphi = 0$）で一番小さい。</p></div>';
    hd += '<div class="qcard derive"><p class="qt">頂点 C を通過する（宙返りする）条件</p><p>頂点 C で $N \\ge 0$ なら 1 周できる（上の式で $\\varphi = 0$）。</p>' +
      '<div class="qeq">' + tex('N_C = \\dfrac{m(v_0^{\\,2} + 2gh)}{r} - 5mg \\ge 0\\ \\Longrightarrow\\ v_0^{\\,2} + 2gh \\ge 5gr', true) +
      tex('v_0 = 0\\ \\text{なら}\\ \\ h \\ge \\dfrac{5}{2}r\\quad \\left(h_0 = \\dfrac{5}{2}r = ' + fmt(2.5 * R, 2) + '\\ \\text{m}\\right)', true) + '</div>' +
      '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('h = ' + m3SHLab(hK) + ' = ' + fmt(h, 2) + '\\ \\text{m}') + '、' + tex('v_0 = ' + fmt(v0, 1)) + ' m/s で ' +
      tex('N_C = ' + fmt(Ntop, 2) + '\\ \\text{N}') + (Ntop >= -1e-9 ? '（$\\ge 0$：宙返りできる）' : '（$< 0$：頂点に着く前に面から離れる）') +
      (hx ? '。この $h$ で宙返りに必要な初速は ' + tex('v_0 \\ge ' + hx) + ' = ' + fmt(Math.sqrt(G * (5 * R - 2 * h)), 2) + ' m/s' : '。この $h$ なら $v_0 = 0$ でも宙返りできる') + '</p>' +
      '<p class="qnote">$N = 0$ になる角（最下点から）は $\\cos\\theta = \\dfrac{2gr - (v_0^{\\,2} + 2gh)}{3gr}$。</p>' + M3LINK4 + '</div>';
    hd += '</div></details>';
    hd += '<p class="assume">' + tex('m = 0.20') + ' kg、' + tex('r = 0.50') + ' m、' + tex('g = 9.8') + ' m/s²。斜面の傾きは 45°。斜面・床・ループはなめらかにつながっていて、摩擦はない。小球の大きさは考えない（図では面の内側に半径ぶんずらして描いた）。</p>';
    return hd;
  }
}));
/* ===================== セクション3 なめらかな円筒面をすべりおりる ===================== */
DEFS.m3s2 = m3Base({
  id: 'm3s2', num: 4, sec: 2, title: 'なめらかな円筒面を滑りおりる小球',
  desc: '半円柱の最高点で小球を弾く。中心方向の力は<b>重力の成分と垂直抗力</b>。<span class="todo">$v_0$ を変えて ▶ スタートし、どこで面から離れるか見よう。</span>',
  vars: [{ k: 'v0', label: '初速 $v_0$', aria: '初速', min: 0.1, max: 2.2, step: 0.1, def: 0.1, dec: 1, unit: 'm/s' }],
  msg: function (s) {
    var tr = m3Tr(s), v0 = s.v.v0, c = 2 / 3 + v0 * v0 / (3 * G * M3.R);
    if (tr.ev && s.t >= tr.ev.t) return '<b>面から離れた！</b>（$N = 0$）　$\\cos\\theta = \\dfrac{2}{3} + \\dfrac{v_0^{\\,2}}{3gr} = ' + fmt(c, 3) + '$、$\\theta = ' + fmt(Math.acos(c) * 180 / Math.PI, 1) + '^\\circ$。そのあとは放物運動。';
    return '▶ スタート。滑りおりるにつれて速くなり、$N = mg\\cos\\theta - m\\dfrac{v^2}{r}$ がしだいに小さくなる。';
  },
  eqs: function (s, q) { return m3Eqs(2, q, m3Tr(s)); },
  right: function (s, tr) {
    var v0 = s.v.v0, R = M3.R, c = 2 / 3 + v0 * v0 / (3 * G * R);
    var h = m3Frame(s, 2, '中心向きの合力は $mg\\cos\\theta - N$（$\\theta$ は最高点からの角）。速くなるほど必要な向心力が大きくなり、$N$ が小さくなる。',
      '一緒に回る観測者には小球が止まって見える。遠心力が外向きにはたらき、$N$ を小さくしていく。');
    h += m3TheoryOpen(s) + m3Energy(tr, '\\dfrac{1}{2}mv_0^{\\,2} + mgr = \\dfrac{1}{2}mv^2 + mgr\\cos\\theta');
    h += '<div class="qcard derive"><p class="qt">面から離れる角</p><p>離れる瞬間は $N = 0$。中心方向の' + T_EOM + 'と力学的エネルギー保存則から</p>' +
      '<div class="qeq">' + eqRow('eom', 'm\\dfrac{v^2}{r} = mg\\cos\\theta') + tex('v^2 = v_0^{\\,2} + 2gr(1 - \\cos\\theta)', true) + tex('\\cos\\theta = \\dfrac{2}{3} + \\dfrac{v_0^{\\,2}}{3gr}', true) + '</div>' +
      '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('\\cos\\theta = ' + fmt(c, 3) + ',\\ \\ \\theta = ' + fmt(Math.acos(c) * 180 / Math.PI, 1) + '^\\circ') + '</p>' +
      '<p class="qnote">$v_0$ が小さいほど $\\cos\\theta \\to \\dfrac{2}{3}$（約 $48.2^\\circ$）に近づく。$v_0 \\ge \\sqrt{gr}$ だと最高点ですぐに離れる。</p>' + M3LINK4 + '</div>';
    h += '</div></details>';
    h += '<p class="assume">' + tex('m = 0.20') + ' kg、' + tex('r = 0.50') + ' m。小球の大きさは考えない（図では面の外側に半径ぶんずらして描いた）。</p>';
    return h;
  }
});
/* ===================== セクション3 糸による円運動（③-4） ===================== */
/* 「たるむ瞬間をスローで」が押せないときのヒント（θ0 ごとに、たるむ v0 の範囲） */
function m3S3Hint(s) {
  var t0 = m3Th0(s), c = M3S3.crit[t0].tex, lo = t0 === 180 ? '0 \\le v_0' : (M3S3.low[t0] ? M3S3.low[t0].tex + ' < v_0' : '0 < v_0');
  return '$' + lo + ' < ' + c + '$ にしてから、もう一度押そう。';
}
DEFS.m3s3 = m3Base({
  id: 'm3s3', num: 5, sec: 3, title: '糸による円運動',
  desc: 'くぎに結んだ糸の先の小球を、接線方向に弾く。中心方向の力は<b>張力と重力の成分</b>。<span class="todo">$\\theta_0$ と $v_0$ を変えて ▶ スタートし、最高点まで糸がたるまずに回れるか見よう。</span>',
  varCols: [['v0'], ['th0']],                /* 初速のスライダーを半分にして、右に初期角度（2026-10-13 千葉さん） */
  vars: [{ k: 'v0', label: '初速 $v_0$', aria: '初速', min: 0, max: 5.0, step: 0.1, def: 0, dec: 1, unit: 'm/s',
    allow: function (s) { return { lo: m3Th0(s) === 180 ? M3S3.v0min180 : 0, hi: 5.0 }; },   /* 180° のときは v0 の最小値を上げる（2026-10-13 千葉さん） */
    mark: function (s) { var c = m3S3Crit(m3Th0(s)); return { x: c.v, label: '$' + c.tex + '$' }; } },
    { k: 'th0', label: '初期角度 $\\theta_0$', aria: '初期角度', stops: [0, 30, 90, 180], prop: true, stopLabels: ['0°', '30°', '90°', '180°'], def: 90,   /* 角度に比例した位置（等間隔にしない） */
      fmt: function (x) { return x + '°'; } }],
  fixVars: function (s) { if (m3Th0(s) === 180 && s.v.v0 < M3S3.v0min180) { s.v.v0 = M3S3.v0min180; s.syncSliders(true); } },
  msg: function (s) {
    var tr = m3Tr(s), v0 = s.v.v0, t0 = m3Th0(s), c = m3S3Crit(t0), lo = M3S3.low[t0];
    if (m3After(s, tr)) return '<b>糸がたるんだ！</b>（$S = 0$）　そのあとは放物運動。糸がまたぴんと張ったところで止めた。';
    if (t0 === 180 && v0 < c.v) return '最高点で $v_0 < ' + c.tex + ' = ' + fmt(c.v, 2) + '$ m/s では、重力 $mg$ だけで、円運動に必要な中心向きの力 $m\\dfrac{v_0^{\\,2}}{r}$ より大きい（$S < 0$ が必要になる）。▶ スタートすると、糸はすぐにたるむ。';
    if (v0 >= c.v) return '$v_0 \\ge ' + c.tex + ' = ' + fmt(c.v, 2) + '$ m/s なので、最高点でも $S \\ge 0$。糸がたるまずに回り続ける。';
    if (v0 === 0) {
      if (t0 === 0) return '最下点で $v_0 = 0$ では動かない。$v_0$ を大きくしてみよう。';
      return '$v_0 = 0$ では、反対側の同じ高さ（$\\theta = ' + t0 + '^\\circ$）まで上がって戻る（振り子）。$v_0$ を大きくしてみよう。';
    }
    if (lo && v0 <= Math.sqrt(lo.k * G * M3.R)) return '$v_0 \\le ' + lo.tex + ' = ' + fmt(Math.sqrt(lo.k * G * M3.R), 2) + '$ m/s なので、中心の高さまで上がらない。糸はたるまずに往復する（振り子）。';
    return '▶ スタート。$v_0 < ' + c.tex + '$ なので、中心より高いところで糸がたるむ。';
  },
  eqs: function (s, q) { return m3Eqs(3, q, m3Tr(s)); },
  right: function (s, tr) {
    var v0 = s.v.v0, R = M3.R, t0 = m3Th0(s), c = m3S3Crit(t0), cs = { 0: '1', 30: '\\dfrac{\\sqrt{3}}{2}', 90: '0', 180: '-1' }[t0];
    var h = m3Frame(s, 3, '中心向きの合力は $S - mg\\cos\\theta$（$\\theta$ は最下点からの角）。',
      '一緒に回る観測者には小球が止まって見える。遠心力と接線方向の慣性力を加えて、力がつり合う。');
    h += m3TheoryOpen(s) + m3Energy(tr, '\\dfrac{1}{2}mv_0^{\\,2} + mgr(1 - \\cos\\theta_0) = \\dfrac{1}{2}mv^2 + mgr(1 - \\cos\\theta)');
    h += '<div class="qcard derive"><p class="qt">最高点に達する条件</p><p>最高点で糸がたるまないためには $S \\ge 0$。最高点での速さを $v_1$ とすると</p>' +
      '<div class="qeq">' + eqRow('eom', 'm\\dfrac{v_1^{\\,2}}{r} = S + mg \\;\\Longrightarrow\\; v_1^{\\,2} \\ge gr') +
      tex('\\dfrac{1}{2}mv_0^{\\,2} + mgr(1 - \\cos\\theta_0) = \\dfrac{1}{2}mv_1^{\\,2} + 2mgr\\ \\Longrightarrow\\ v_0 \\ge \\sqrt{(3 + 2\\cos\\theta_0)gr}', true) + '</div>' +
      '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('\\theta_0 = ' + t0 + '^\\circ') + ' なので ' + tex('\\cos\\theta_0 = ' + cs) + '、' +
      tex(c.tex + ' = ' + fmt(c.v, 2) + '\\ \\text{m/s}') + '（いま ' + tex('v_0 = ' + fmt(v0, 1)) + ' m/s）</p>' +
      '<p class="qnote">最下点を位置エネルギーの基準にした。糸がたるむ角は $\\cos\\theta = \\dfrac{2gr\\cos\\theta_0 - v_0^{\\,2}}{3gr}$。</p>' + M3LINK42 + '</div>';
    h += '</div></details>';
    h += '<p class="assume">' + tex('m = 0.20') + ' kg、' + tex('r = 0.50') + ' m。糸の質量は考えない。中心（くぎ）は動かない。</p>';
    return h;
  }
});
/* ===================== ③-5 糸による円運動（釘） ===================== */
/* 長さ 2r の糸（O に固定）。O の真下 r に釘 C。最下点 B を通ると C を中心に半径 r。r = 0.25 m（2r = M3.R = 0.50 m）。
   1 周できる最小の v0：釘のまわりの最高点で S ≥ 0 → v_B² ≥ 5gr、v_B² = v0² + 4gr(1 − cosθ0) → v0 ≥ √((1 + 4cosθ0)gr)。
   180° は右辺が負なので、かわりに「はじめに S ≥ 0」＝ v0 ≥ √(2gr)。2026-10-14 千葉さん */
var M3S5 = {
  r: M3.R / 2,
  crit: { 0: { k: 5, tex: '\\sqrt{5gr}' }, 30: { k: 1 + 2 * Math.sqrt(3), tex: '\\sqrt{(1+2\\sqrt{3})gr}' }, 90: { k: 1, tex: '\\sqrt{gr}' }, 180: { k: 2, tex: '\\sqrt{2gr}' } },
  /* 釘の高さ（C）まで上がらない（振り子のように往復する）上限：v_B² ≤ 2gr → v0 ≤ √((4cosθ0 − 2)gr)（0°・30°） */
  low: { 0: { k: 2, tex: '\\sqrt{2gr}' }, 30: { k: 2 * Math.sqrt(3) - 2, tex: '\\sqrt{(2\\sqrt{3}-2)gr}' } }
};
function m3S5Crit(th0) { var c = M3S5.crit[th0]; return { v: Math.sqrt(c.k * G * M3S5.r), tex: c.tex }; }
function m3S5Hint(s) {
  var t0 = m3Th0(s), c = M3S5.crit[t0].tex, lo = t0 === 180 ? M3S3.v0min180 + ' \\le v_0' : (M3S5.low[t0] ? M3S5.low[t0].tex + ' < v_0' : '0 \\le v_0');
  return '$' + lo + ' < ' + c + '$ にしてから、もう一度押そう。';
}
DEFS.m3s5 = m3Base({
  id: 'm3s5', num: 6, sec: 6, title: '糸による円運動（釘）',
  desc: '最下点 B で糸が釘 C に触れ、そのあとは <b>C を中心とする半径 $r$ の円運動</b>になる。<span class="todo">$\\theta_0$ と $v_0$ を変えて ▶ スタートし、最高点まで糸がたるまずに回れるか見よう。</span>',
  varCols: [['v0'], ['th0']],                /* ③-4 と同じスライダー */
  vars: [{ k: 'v0', label: '初速 $v_0$', aria: '初速', min: 0, max: 5.0, step: 0.1, def: 0, dec: 1, unit: 'm/s',
    allow: function (s) { return { lo: m3Th0(s) === 180 ? M3S3.v0min180 : 0, hi: 5.0 }; },
    mark: function (s) { var c = m3S5Crit(m3Th0(s)); return { x: c.v, label: '$' + c.tex + '$' }; } },
    { k: 'th0', label: '初期角度 $\\theta_0$', aria: '初期角度', stops: [0, 30, 90, 180], prop: true, stopLabels: ['0°', '30°', '90°', '180°'], def: 90,
      fmt: function (x) { return x + '°'; } }],
  fixVars: function (s) { if (m3Th0(s) === 180 && s.v.v0 < M3S3.v0min180) { s.v.v0 = M3S3.v0min180; s.syncSliders(true); } },
  msg: function (s) {
    var tr = m3Tr(s), v0 = s.v.v0, t0 = m3Th0(s), c = m3S5Crit(t0), lo = M3S5.low[t0], r = M3S5.r;
    if (m3After(s, tr)) return '<b>糸がたるんだ！</b>（$S = 0$）　そのあとは放物運動。糸がまたぴんと張ったところで止めた。';
    if (t0 === 180 && v0 < c.v) return '最高点で $v_0 < ' + c.tex + ' = ' + fmt(c.v, 2) + '$ m/s では、重力 $mg$ だけで、円運動（半径 $2r$）に必要な中心向きの力 $m\\dfrac{v_0^{\\,2}}{2r}$ より大きい。▶ スタートすると、糸はすぐにたるむ。';
    if (v0 >= c.v) return '$v_0 \\ge ' + c.tex + ' = ' + fmt(c.v, 2) + '$ m/s なので、釘に触れたあと、C のまわりの最高点でも $S \\ge 0$。糸がたるまずに回り続ける。';
    if (v0 === 0 && t0 === 0) return '最下点で $v_0 = 0$ では動かない。$v_0$ を大きくしてみよう。';
    if (lo && v0 <= Math.sqrt(lo.k * G * r)) return '$v_0 \\le ' + lo.tex + ' = ' + fmt(Math.sqrt(lo.k * G * r), 2) + '$ m/s なので、釘に触れたあと C の高さまで上がらない。糸はたるまずに往復する（振り子）。';
    return '▶ スタート。$v_0 < ' + c.tex + '$ なので、釘に触れたあと、C より高いところで糸がたるむ。';
  },
  eqs: function (s, q) { return m3Eqs(6, q, m3Tr(s)); },
  right: function (s, tr) {
    var v0 = s.v.v0, t0 = m3Th0(s), r = M3S5.r, m = M3.m, c = m3S5Crit(t0), cs = { 0: '1', 30: '\\dfrac{\\sqrt{3}}{2}', 90: '0', 180: '-1' }[t0];
    var vB2 = v0 * v0 + 4 * G * r * (1 - Math.cos(t0 * Math.PI / 180)), S1 = m * vB2 / (2 * r) + m * G, S2 = m * vB2 / r + m * G;
    var h = m3Frame(s, 6, '中心向きの合力は $S - mg\\cos\\theta$（$\\theta$ は、いま回っている円の中心から見た、最下点からの角）。釘に触れる前は中心 O・半径 $2r$、触れた後は中心 C・半径 $r$。',
      '一緒に回る観測者には小球が止まって見える。遠心力と接線方向の慣性力を加えて、力がつり合う。');
    h += m3TheoryOpen(s) + m3Energy(tr, '\\dfrac{1}{2}mv_0^{\\,2} + mg\\cdot 2r(1 - \\cos\\theta_0) = \\dfrac{1}{2}mv^2 + mgh');
    h += '<div class="qcard"><p class="qt">① 釘に触れる前（O のまわり・半径 $2r$）</p>' +
      '<p>最下点 B を位置エネルギーの基準（$h$ は B からの高さ）にすると、B での速さ $v_B$ は</p>' +
      '<div class="qeq">' + tex('\\dfrac{1}{2}mv_0^{\\,2} + mg\\cdot 2r(1 - \\cos\\theta_0) = \\dfrac{1}{2}mv_B^{\\,2}', true) + tex('\\Longrightarrow\\ v_B^{\\,2} = v_0^{\\,2} + 4gr(1 - \\cos\\theta_0)', true) +
      eqRow('eom', 'm\\dfrac{v_B^{\\,2}}{2r} = S_1 - mg') + '</div>' +
      '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('v_B = ' + fmt(Math.sqrt(vB2), 2) + '\\ \\text{m/s}') + '、' + tex('S_1 = ' + fmt(S1, 2) + '\\ \\text{N}') + '（釘に触れる直前）</p></div>';
    h += '<div class="qcard"><p class="qt">② 釘に触れた瞬間</p><p>張力は速度と垂直なので、速さは変わらない（$v_B$ のまま）。半径が $2r$ から $r$ になるので、中心向きに必要な力が大きくなり、<b>張力が急に大きくなる</b>。</p>' +
      '<div class="qeq">' + eqRow('eom', 'm\\dfrac{v_B^{\\,2}}{r} = S_2 - mg') + '</div>' +
      '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('S_2 = ' + fmt(S2, 2) + '\\ \\text{N}') + '（' + tex('S_1 = ' + fmt(S1, 2)) + ' N から増える。右上のグラフの段差）</p></div>';
    h += '<div class="qcard derive"><p class="qt">③ 釘に触れた後（C のまわり・半径 $r$）：最高点に達する条件</p>' +
      '<p>C の真上（B からの高さ $2r$）で糸がたるまないためには $S \\ge 0$。そこでの速さを $v_1$ とすると</p>' +
      '<div class="qeq">' + eqRow('eom', 'm\\dfrac{v_1^{\\,2}}{r} = S + mg \\;\\Longrightarrow\\; v_1^{\\,2} \\ge gr') +
      tex('\\dfrac{1}{2}mv_B^{\\,2} = \\dfrac{1}{2}mv_1^{\\,2} + mg\\cdot 2r\\ \\Longrightarrow\\ v_B^{\\,2} \\ge 5gr', true) +
      tex('v_0^{\\,2} + 4gr(1 - \\cos\\theta_0) \\ge 5gr\\ \\Longrightarrow\\ v_0 \\ge \\sqrt{(1 + 4\\cos\\theta_0)gr}', true) + '</div>' +
      '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('\\theta_0 = ' + t0 + '^\\circ') + ' なので ' + tex('\\cos\\theta_0 = ' + cs) + '、' +
      (t0 === 180 ? '右辺の中が負なので、この条件はいつも満たされる。かわりに、はじめ（O の真上）で ' + tex('S \\ge 0') + ' となる条件 ' + tex(c.tex + ' = ' + fmt(c.v, 2) + '\\ \\text{m/s}') :
        tex(c.tex + ' = ' + fmt(c.v, 2) + '\\ \\text{m/s}')) + '（いま ' + tex('v_0 = ' + fmt(v0, 1)) + ' m/s）</p>' +
      '<p class="qnote">釘のまわりで糸がたるむ角は $\\cos\\theta = \\dfrac{2gr - v_B^{\\,2}}{3gr}$（$\\theta$ は C から見た、最下点からの角）。たとえば $\\theta_0 = 90^\\circ$・$v_0 = 0$ なら $v_B^{\\,2} = 4gr$ で $\\cos\\theta = -\\dfrac{2}{3}$。</p>' + M3LINK42 + '</div>';
    h += '</div></details>';
    h += '<p class="assume">' + tex('m = 0.20') + ' kg、' + tex('r = 0.25') + ' m（糸の長さ ' + tex('2r = 0.50') + ' m）。糸の質量と釘の太さは考えない。O と釘 C は動かない。</p>';
    return h;
  }
});
