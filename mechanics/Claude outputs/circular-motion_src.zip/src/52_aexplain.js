/* =========================================================================
   52_aexplain.js … 1-1「a が中心方向を向き、v との関係式 a = vω = rω² が成り立つ理由」の説明アニメ
   ステップ式（自動で進む）。再生／一時停止・戻る／次へ・最大化・閉じる。
   画面の右下に浮かぶ小窓（右の列が描き直されても消えない）。
   ========================================================================= */
'use strict';
var AEXP = null;
var AEXP_STEPS = [
  { d: 1.5, h: '1. 等速円運動。始点での速度を $\\vec{v}$ とする', t: '小球は半径 $r$ の円の上を、一定の速さ $v$ で回る。始点での速度 $\\vec{v}$ は円の接線方向。' },
  { d: 1.7, h: '2. $\\Delta t$ 秒後の速度 $\\vec{v}\\,\'$', t: '$\\Delta t$ 秒後、小球は中心角 $\\Delta\\theta$ だけ進む。角速度が $\\omega$ なので $\\Delta\\theta = \\omega\\Delta t$。速度は $\\vec{v}\\,\'$ になる（大きさは同じ $v$、向きだけ $\\Delta\\theta$ 変わる）。' },
  { d: 4.5, h: '3. $\\vec{v}\\,\'$ を始点まで平行移動する', t: '2 つの速度を比べるため、$\\vec{v}\\,\'$ を始点まで平行移動する。$\\vec{v}$ と $\\vec{v}\\,\'$ のあいだの角も $\\Delta\\theta$。' },
  { d: 5.0, h: '4. 速度の変化 $\\Delta\\vec{v} = \\vec{v}\\,\' - \\vec{v}$', t: '速度の変化は $\\Delta\\vec{v} = \\vec{v}\\,\' - \\vec{v}$（$\\vec{v}$ の先から $\\vec{v}\\,\'$ の先へ向かう矢印）。加速度は $\\vec{a} = \\dfrac{\\Delta\\vec{v}}{\\Delta t}$ なので、$\\vec{a}$ は $\\Delta\\vec{v}$ と同じ向き。' },
  { d: 5.5, h: '5. $\\Delta\\theta$ が小さいとき $|\\Delta\\vec{v}| \\fallingdotseq v\\Delta\\theta$', t: '$\\vec{v}$ と $\\vec{v}\\,\'$ は半径 $v$、中心角 $\\Delta\\theta$ の扇形をつくる。$\\Delta\\theta$ が十分小さいとき、弦の長さ $|\\Delta\\vec{v}|$ は弧の長さ $v\\Delta\\theta$ とほぼ等しい。' },
  { d: 5.0, h: '6. $\\Delta t \\to 0$ にすると、$\\Delta\\vec{v}$ は中心を向く', t: '$\\Delta t$（$\\Delta\\theta$）を小さくしていくと、$\\Delta\\vec{v}$ は $\\vec{v}$ に垂直になり、<b>円の中心の向き</b>を指す。だから $\\vec{a}$ は中心向き。' },
  { d: 7.0, h: '7. 加速度の大きさ $a = v\\omega = r\\omega^2$', t: '$a = \\dfrac{|\\Delta\\vec{v}|}{\\Delta t} = \\dfrac{v\\Delta\\theta}{\\Delta t} = \\dfrac{v\\,\\omega\\Delta t}{\\Delta t} = v\\omega$。さらに $v = r\\omega$ を入れると $a = r\\omega^2 = \\dfrac{v^2}{r}$。<b>向きは円の中心向き。</b>' }
];
/* 右の列の「加速度 a」の説明の中に、折りたたまずに置く（2026-10-07 千葉さん）。右の列は何度も描き直されるので、
   箱は 1 つだけ作って、描き直されるたびに新しい置き場所（.aexhost）へ移す。初めて出たときは最初から再生 */
function aexpMount(host) {
  if (!host) { if (AEXP) { aexpPlay(false); AEXP.box.classList.remove('max'); AEXP.mounted = false; } return; }   /* a 以外を選んだら止める */
  var first = !AEXP;
  if (first) openAExplain();
  host.appendChild(AEXP.box); AEXP.box.classList.add('show');
  if (!AEXP.mounted) { AEXP.mounted = true; aexpGo(0); aexpPlay(true); } else aexpDraw();
}
function openAExplain() {
  if (AEXP) { AEXP.box.classList.add('show'); aexpPlay(true); return; }
  var box = el('div', 'aexp inline show'); box.setAttribute('role', 'region'); box.setAttribute('aria-label', '加速度が中心を向く理由の説明アニメ');
  box.innerHTML = '<div class="aexh"><b>$a$ が中心方向を向き、$v$ との関係式 $a = v\\omega = r\\omega^2$ が成り立つ理由</b>' +
    '<button type="button" class="aexmax" title="最大化" aria-label="最大化">' + MAX_SVG + '</button></div>' +
    '<canvas class="aexcv"></canvas><div class="aextxt"></div>' +
    '<div class="aexbar"><button type="button" class="b tiny aexprev">◀ 戻る</button><button type="button" class="b aexpp">❚❚ 一時停止</button><button type="button" class="b tiny aexnext">次へ ▶</button>' +
    '<span class="aexdots"></span><button type="button" class="b tiny aexrw">最初から</button></div>';
  box.querySelector('.aexh b').innerHTML = mathify(box.querySelector('.aexh b').innerHTML);
  AEXP = { box: box, cv: box.querySelector('.aexcv'), txt: box.querySelector('.aextxt'), step: 0, u: 0, playing: true, last: 0, raf: 0, shown: -1 };
  var dots = box.querySelector('.aexdots');
  AEXP_STEPS.forEach(function (st, i) { var b = el('button', 'aexdot'); b.type = 'button'; b.title = 'ステップ ' + (i + 1); b.addEventListener('click', function () { aexpGo(i); }); dots.appendChild(b); });
  box.querySelector('.aexmax').addEventListener('click', function () { box.classList.toggle('max'); aexpDraw(); });
  box.querySelector('.aexpp').addEventListener('click', function () { aexpPlay(!AEXP.playing); });
  box.querySelector('.aexprev').addEventListener('click', function () { aexpGo(Math.max(0, AEXP.step - (AEXP.u < 0.15 ? 1 : 0))); });
  box.querySelector('.aexnext').addEventListener('click', function () { aexpGo(Math.min(AEXP_STEPS.length - 1, AEXP.step + 1)); });
  box.querySelector('.aexrw').addEventListener('click', function () { aexpGo(0); aexpPlay(true); });
  document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape' && AEXP && AEXP.box.classList.contains('max')) { box.classList.remove('max'); aexpDraw(); } });   /* Esc で最大化をやめる */
}
/* 図の中の式：a⃗ = Δv⃗/Δt = (v⃗' − v⃗)/Δt（分数も canvas に描く） */
function aexpFormula(ctx, x, y, size) {
  var parts = [['a', true], ['=', false], ['F', ['Δv', true], ['Δt', false]], ['=', false], ['F', ["v'−v", 'vv'], ['Δt', false]]];
  ctx.save(); ctx.font = 'italic ' + size + 'px ' + MATH;
  var wOf = function (t) { return ctx.measureText(t).width; }, gap = 6, w = 0;
  var ws = parts.map(function (p) { var ww = p[0] === 'F' ? Math.max(wOf(p[1][0]) + (p[1][1] === 'vv' ? 14 : 0), wOf(p[2][0])) + 8 : wOf(p[0]); w += ww + gap; return ww; });
  w -= gap;
  ctx.fillStyle = 'rgba(255,255,255,.93)'; ctx.strokeStyle = 'rgba(193,46,104,.45)'; ctx.lineWidth = 1.2;
  rrect(ctx, x - 8, y - size * 1.45, w + 16, size * 2.9, 8); ctx.fill(); ctx.stroke();
  ctx.restore();
  var cx = x;
  parts.forEach(function (p, i) {
    var ww = ws[i];
    if (p[0] === 'F') {
      var nm = p[1][0], dn = p[2][0];
      if (p[1][1] === 'vv') {                                    /* v' − v（どちらにも矢印） */
        ctx.save(); ctx.font = 'italic ' + size + 'px ' + MATH; var w1 = ctx.measureText("v'").width, wm = ctx.measureText('−').width, w2 = ctx.measureText('v').width; ctx.restore();
        var sx = cx + (ww - (w1 + wm + w2 + 14)) / 2;
        sym(ctx, "v'", sx + w1 / 2, y - size * 0.62, { size: size, color: COL.acc, vec: true });
        label(ctx, '−', sx + w1 + 7 + wm / 2, y - size * 0.62, { size: size, color: COL.acc, halo: false });
        sym(ctx, 'v', sx + w1 + wm + 14 + w2 / 2, y - size * 0.62, { size: size, color: COL.acc, vec: true });
      } else sym(ctx, nm, cx + ww / 2, y - size * 0.62, { size: size, color: COL.acc, vec: !!p[1][1], vecSkip: nm.charAt(0) === 'Δ' ? 'Δ' : '' });   /* Δ はベクトルでない：v だけに矢印 */
      sym(ctx, dn, cx + ww / 2, y + size * 0.68, { size: size, color: COL.acc });
      ctx.save(); ctx.strokeStyle = COL.acc; ctx.lineWidth = 1.3; ctx.beginPath(); ctx.moveTo(cx, y); ctx.lineTo(cx + ww, y); ctx.stroke(); ctx.restore();
    } else if (p[0] === '=') label(ctx, '=', cx + ww / 2, y, { size: size, color: COL.acc, halo: false });
    else sym(ctx, p[0], cx + ww / 2, y, { size: size + 1, color: COL.acc, vec: p[1] });
    cx += ww + gap;
  });
}
function aexpGo(i) { AEXP.step = i; AEXP.u = 0; aexpDraw(); }
function aexpPlay(on) {
  AEXP.playing = on;
  AEXP.box.querySelector('.aexpp').textContent = on ? '❚❚ 一時停止' : '▶ 再生';
  cancelAnimationFrame(AEXP.raf); AEXP.last = 0;
  if (on) {
    var f = function (ts) {
      if (!AEXP.playing) return;
      var dt = AEXP.last ? Math.min(0.05, (ts - AEXP.last) / 1000) : 0; AEXP.last = ts;
      AEXP.u += dt / AEXP_STEPS[AEXP.step].d;
      if (AEXP.u >= 1) { if (AEXP.step < AEXP_STEPS.length - 1) { AEXP.step++; AEXP.u = 0; } else { AEXP.u = 1; aexpDraw(); aexpPlay(false); return; } }
      aexpDraw(); AEXP.raf = requestAnimationFrame(f);
    };
    AEXP.raf = requestAnimationFrame(f);
  } else aexpDraw();
}
function aexpDraw() {
  var A = AEXP, st = A.step, u = clamp(A.u, 0, 1), e = u * u * (3 - 2 * u);
  if (A.shown !== st) {
    A.shown = st;
    A.txt.innerHTML = mathify('<p class="aexhd">' + AEXP_STEPS[st].h + '</p><p>' + AEXP_STEPS[st].t + '</p>');
    A.box.querySelectorAll('.aexdot').forEach(function (b, i) { b.classList.toggle('on', i === st); b.classList.toggle('done', i < st); });
  }
  var big = A.box.classList.contains('max');
  var W = Math.max(280, Math.floor(A.cv.clientWidth || 480)), H = Math.round(W * (big ? 0.56 : 0.66));
  var ctx = prep(A.cv, W, H);
  var kz = big ? Math.max(1, Math.min(W / 640, H / 380)) : 1;   /* 最大化したら図も文字もまとめて拡大 */
  if (kz > 1) { ctx.scale(kz, kz); W = W / kz; H = H / kz; CVW = W; CVH = H; }
  ctx.fillStyle = '#fbfaf6'; ctx.fillRect(0, 0, W, H);
  var S = Math.min(W, H * 1.5) / 520;                         /* 図の縮尺（基準の幅 520） */
  var O = { x: W * 0.52, y: H * 0.88 }, R = 230 * S, L = 120 * S;
  var dth0 = 40 * Math.PI / 180, d5 = 5 * Math.PI / 180, d7 = 0.4 * Math.PI / 180;
  /* Δθ：ステップ 6 で 40° → 5°、ステップ 7 の前半でさらに 0 に近づける（a が中心を向くところまで見せる。2026-10-06 千葉さん） */
  var u7 = clamp(u / 0.55, 0, 1), e7 = u7 * u7 * (3 - 2 * u7);
  var dth = st < 5 ? dth0 : (st === 5 ? dth0 + (d5 - dth0) * e : d5 + (d7 - d5) * e7);
  var lin = u;                                                   /* ステップ 1・2 の小球は一定の速さ（ゆっくり止まって見えないように） */
  var P = function (ang, rr) { return { x: O.x + rr * Math.cos(ang), y: O.y - rr * Math.sin(ang) }; };
  /* 円（上の部分だけ見える）と中心 O */
  ctx.save(); ctx.strokeStyle = '#2e8b57'; ctx.lineWidth = 2.2; ctx.beginPath(); ctx.arc(O.x, O.y, R, Math.PI * 1.02, Math.PI * 1.98, false); ctx.stroke(); ctx.restore();
  ctx.save(); ctx.fillStyle = '#1b1f24'; ctx.beginPath(); ctx.arc(O.x, O.y, 3.5, 0, TAU); ctx.fill(); ctx.restore();
  label(ctx, 'O（中心）', O.x + 10, O.y - 10, { size: 12, color: COL.ink2, align: 'left' });
  var p0 = P(Math.PI / 2, R);                                    /* 始点（いちばん上） */
  /* ステップ 1：小球が円の上を動く */
  var ballAng = Math.PI / 2;
  var span0 = dth0 * AEXP_STEPS[0].d / AEXP_STEPS[1].d;         /* ステップ 1 と 2 で同じ角速度になるように */
  if (st === 0) ballAng = Math.PI / 2 - span0 * (1 - lin);     /* 右から一定の速さで始点へ（そのままステップ 2 へ続く） */
  if (st === 1) ballAng = Math.PI / 2 + dth * lin;
  if (st >= 2) ballAng = Math.PI / 2 + dth;
  var p1 = P(Math.PI / 2 + dth, R);
  /* 半径の破線と Δθ */
  var dline = function (a, b) { ctx.save(); ctx.setLineDash([5, 4]); ctx.strokeStyle = '#6f7782'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); ctx.restore(); };
  dline(O, p0);
  sym(ctx, 'r', (O.x + p0.x) / 2 - 12, (O.y + p0.y) / 2 + (st >= 5 ? 40 * S : 0), { size: 15 });
  if (st >= 1 && st <= 3) {
    var pb = P(Math.PI / 2 + dth * (st === 1 ? lin : 1), R); dline(O, pb);
    ctx.save(); ctx.fillStyle = 'rgba(46,170,110,.28)'; ctx.beginPath(); ctx.moveTo(O.x, O.y); ctx.arc(O.x, O.y, 36 * S, -Math.PI / 2, -Math.PI / 2 - dth * (st === 1 ? lin : 1), true); ctx.closePath(); ctx.fill(); ctx.restore();
    sym(ctx, 'Δθ', O.x - 22 * S, O.y - 60 * S, { size: 14 });
  }
  ctx.save(); ctx.fillStyle = '#1b1f24'; ctx.beginPath(); ctx.arc(p0.x, p0.y, 4, 0, TAU); ctx.fill(); ctx.restore();
  label(ctx, '始点', p0.x + 10, p0.y - 14, { size: 12, bold: true, color: COL.ink, align: 'left' });
  /* 速度の矢印：始点の v（左向き） */
  var vEnd = { x: p0.x - L, y: p0.y };
  arrow(ctx, p0.x, p0.y, vEnd.x, vEnd.y, 'vel');
  sym(ctx, 'v', vEnd.x - 4, vEnd.y - 16, { size: 16, color: COL.vel, vec: true });
  /* v' の向き（下向きに Δθ 回る） */
  var dv = { x: -Math.cos(dth), y: Math.sin(dth) };
  if (st >= 1) {
    var ang1 = Math.PI / 2 + dth * (st === 1 ? lin : 1), pp = P(ang1, R), dvv = { x: -Math.cos(ang1 - Math.PI / 2), y: Math.sin(ang1 - Math.PI / 2) };
    var from = pp, tip;
    if (st === 2) { from = { x: p1.x + (p0.x - p1.x) * e, y: p1.y + (p0.y - p1.y) * e }; }   /* 平行移動 */
    if (st >= 3) from = p0;
    if (st === 1) { ctx.save(); ctx.fillStyle = '#1b1f24'; ctx.beginPath(); ctx.arc(pp.x, pp.y, 4, 0, TAU); ctx.fill(); ctx.restore(); }
    if (st === 2 || st === 3) { ctx.save(); ctx.globalAlpha = 0.35; arrow(ctx, p1.x, p1.y, p1.x + dv.x * L, p1.y + dv.y * L, 'vel'); ctx.restore(); }
    tip = { x: from.x + (st === 1 ? dvv.x : dv.x) * L, y: from.y + (st === 1 ? dvv.y : dv.y) * L };
    arrow(ctx, from.x, from.y, tip.x, tip.y, 'vel');
    sym(ctx, "v'", tip.x - 12, tip.y + (st >= 5 ? 22 : 6), { size: 16, color: COL.vel, vec: true });
    if (st === 1) bubble(ctx, '始点から Δt 秒後', pp.x, pp.y - 8, { size: 12, bg: '#fff', border: '#8a929c', color: COL.ink2 });
    if (st >= 3) {
      /* Δv（v の先 → v' の先）と a（同じ向き、ピンク） */
      var t1 = { x: p0.x + dv.x * L, y: p0.y + dv.y * L }, k = st === 3 ? e : 1;
      var dvx = (t1.x - vEnd.x), dvy = (t1.y - vEnd.y);
      var dvOn = !(st === 6 && u > 0.8);                           /* ステップ 7：a が中心を向いたら Δv は消す（2026-10-07 千葉さん） */
      if (dvOn) { ctx.save(); ctx.strokeStyle = '#d1352b'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(vEnd.x, vEnd.y); ctx.lineTo(vEnd.x + dvx * k, vEnd.y + dvy * k); ctx.stroke(); ctx.restore(); }
      if (dvOn && k > 0.98) { arrow(ctx, vEnd.x, vEnd.y, t1.x, t1.y, 'force', '#d1352b', { noShift: true }); sym(ctx, 'Δv', vEnd.x + dvx / 2 - (st >= 5 ? 34 : 22), vEnd.y + dvy / 2, { size: 15, color: '#d1352b', vec: true, vecSkip: 'Δ' }); }
      if (st === 3 && k > 0.98 || st >= 4) {
        /* 加速度 a は Δv と同じ向き（始点から） */
        var al = Math.hypot(dvx, dvy) || 1, aL = (st >= 5 ? 110 : 90) * S;
        var ux = dvx / al, uy = dvy / al;
        if (st === 6) { var kk = clamp((u - 0.55) / 0.25, 0, 1); ux = ux * (1 - kk); uy = uy * (1 - kk) + kk; var ul = Math.hypot(ux, uy) || 1; ux /= ul; uy /= ul; }   /* 最後はぴったり中心向き */
        var ax = p0.x + ux * aL, ay = p0.y + uy * aL;
        if (st === 6 && u > 0.6) dline(p0, O);
        arrow(ctx, p0.x, p0.y, ax, ay, 'acc');
        sym(ctx, 'a', ax + 14, ay - 4, { size: 16, color: COL.acc, vec: true });
      }
    }
    if ((st === 2 && e > 0.97) || (st >= 3 && st <= 4)) {        /* Δθ（v と v' のあいだ）：弧と文字（2026-10-06 千葉さん） */
      var rr2 = 40 * S;
      ctx.save(); ctx.strokeStyle = '#2e8b57'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.arc(p0.x, p0.y, rr2, Math.PI, Math.PI - dth, true); ctx.stroke(); ctx.restore();
      var am2 = Math.PI - dth / 2; sym(ctx, 'Δθ', p0.x + Math.cos(am2) * (rr2 + 16), p0.y + Math.sin(am2) * (rr2 + 16) * 1 + 2, { size: 14, color: '#1f6b43' });
    }
    if (st >= 4) aexpFormula(ctx, p0.x + 30 * S, p0.y + 38 * S, 15);   /* a = Δv/Δt = (v' − v)/Δt */
    if (st === 4) {
      /* 扇形：半径 v、中心角 Δθ の弧（破線）と「弧の長さ vΔθ」 */
      ctx.save(); ctx.setLineDash([4, 3]); ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.arc(p0.x, p0.y, L, Math.PI, Math.PI - dth, true); ctx.stroke(); ctx.restore();
      var mid = { x: p0.x - L * Math.cos(dth / 2) - 26, y: p0.y + L * Math.sin(dth / 2) };
      label(ctx, '弧の長さ vΔθ', mid.x - 6, mid.y, { size: 12.5, bold: true, color: COL.ink, align: 'right' });
    }
  }
  if (st >= 5) {
    /* Δt → 0：直角の印 */
    ctx.save(); ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(p0.x - 12, p0.y); ctx.lineTo(p0.x - 12, p0.y + 12); ctx.lineTo(p0.x, p0.y + 12); ctx.stroke(); ctx.restore();
    if (st === 6) label(ctx, '向きは円の中心', p0.x + 14, p0.y + 90 * S, { size: 13, bold: true, color: '#b2560c', align: 'left' });
  }
  /* 小球（ステップ 1・2 で動く） */
  if (st <= 1) { var bp = P(ballAng, R); ballShape(ctx, bp.x, bp.y, 8, '#c9d3de'); }
  label(ctx, 'ステップ ' + (st + 1) + ' / ' + AEXP_STEPS.length, W - 10, 14, { size: 11, color: COL.sub, align: 'right' });
}
