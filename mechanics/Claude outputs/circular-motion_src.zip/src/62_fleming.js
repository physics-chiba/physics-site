/* =========================================================================
   62_fleming.js … 2-6「フレミング左手を確認」
   押すと、粒子が円の右側（+x 側）に来るまで進めて止め、粒子のまわりを拡大する。
   拡大図：左に粒子と v・B・F・I の矢印、右に左手（中指＝電流 I、人さし指＝磁場 B、親指＝力 F）。
   向きは図と同じカメラ（s.cam）で描くので、図をドラッグすると左手もいっしょに 3 次元で回る。
   負の電荷では、電流 I の向きは速度 v と逆。φ ≠ 90° のときは v の xy 面内の成分（B に垂直な成分）で考える。
   ========================================================================= */
'use strict';
var M2S6FLEMB = '✋ フレミング左手を確認';
/* 押す：粒子が円の右側に来るまで進めて止め、右の列の「回る向き」の中に拡大図を出す（もう一度押すと閉じる）。
   拡大図はアニメといっしょに動く（再生すると左手も回る）ので、円運動の途中の図と左手を同時に見せられる */
function m2s6Flem(s) {
  if (s.flem) { m2s6FlemClose(s); return; }
  if (Math.abs(s.v.B) < 1e-9) {
    s.msg.innerHTML = mathify('<b>$B = 0$ のときは力がはたらかない。</b>$B$ を 0 以外にしてから押そう。'); s.lastMsg = null; return;
  }
  if (!s.ms.showF) m2ForceOn(s);                                /* 力の矢印を自動で ON */
  var st = m2s6At(s, s.t), k = st.k;
  var d = k > 0 ? -st.phi : st.phi; d = ((d % TAU) + TAU) % TAU;   /* 円の右側（φ = 0）までの角 */
  if (d > TAU - 1e-3) d = 0;
  var dt = Math.abs(k) > 1e-9 ? d / Math.abs(k) : 0;
  if (s.t + dt > s.tEnd() - 0.01) { m2s6Restart(s); st = m2s6At(s, 0); d = k > 0 ? -st.phi : st.phi; d = ((d % TAU) + TAU) % TAU; dt = d / Math.abs(k); }
  s.flem = { open: true };
  s.extra.flem.innerHTML = '✕ 左手の図を閉じる'; s.extra.flem.classList.add('on');
  s.renderRight();                                              /* 「回る向き」に図の場所をつくる */
  if (s.flemBox && s.flemBox.scrollIntoView) s.flemBox.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  if (dt < 1e-3) { s.playing = false; s.syncPlayLabel(); s.draw(); }
  else s.playWindow(s.t, s.t + dt, Math.max(s.base, dt / 2.0), null, true);   /* 長くても 2 秒くらいで右側に着く */
}
function m2s6FlemClose(s, silent) {
  s.flem = null;
  if (s.inWindow) { s.endWindow(); s.playing = false; s.syncPlayLabel(); }
  if (s.extra && s.extra.flem) { s.extra.flem.innerHTML = M2S6FLEMB; s.extra.flem.classList.remove('on'); }
  if (!silent) { s.renderRight(); s.draw(); }
}
/* 右の列の図の canvas：ドラッグで向きを回す（メインの図と同じカメラ） */
function m2s6FlemBind(s, cv) {
  var last = null;
  cv.addEventListener('pointerdown', function (ev) { last = { x: ev.clientX, y: ev.clientY }; cv.setPointerCapture(ev.pointerId); });
  cv.addEventListener('pointermove', function (ev) {
    if (!last) return;
    var dx = ev.clientX - last.x, dy = ev.clientY - last.y; last = { x: ev.clientX, y: ev.clientY };
    s.def.drag3d(s, dx, dy); s.draw(); ev.preventDefault();
  });
  var up = function () { last = null; };
  cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
}
/* 凸包（拡大図の手のひら・手首を、箱の 8 点の影で塗る） */
function hull2(pts) {
  var p = pts.slice().sort(function (a, b) { return a.x - b.x || a.y - b.y; });
  var cr = function (o, a, b) { return (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x); };
  var lo = [], up = [];
  p.forEach(function (q) { while (lo.length >= 2 && cr(lo[lo.length - 2], lo[lo.length - 1], q) <= 0) lo.pop(); lo.push(q); });
  for (var i = p.length - 1; i >= 0; i--) { var q = p[i]; while (up.length >= 2 && cr(up[up.length - 2], up[up.length - 1], q) <= 0) up.pop(); up.push(q); }
  return lo.slice(0, -1).concat(up.slice(0, -1));
}
/* 右の列の canvas に描く。メインの図を描いたあとに呼ぶ（CVW などはここで入れかわる） */
function m2s6FlemPanel(s, st) {
  var cv = s.flemCv; if (!cv || !cv.isConnected) return;
  var w = Math.max(240, Math.floor(cv.parentNode.clientWidth || 360)), h = Math.round(w * 0.66);
  var ctx = prep(cv, w, h), x = 0, y = 0, W = w, g = st.g;
  ctx.fillStyle = '#fffdf8'; ctx.fillRect(0, 0, w, h);
  ctx.save();
  /* 物理の向き（右手系）：v（3 次元）、B（±z）、I（v の xy 成分、負の電荷なら逆）、F = I × B */
  var ct = Math.cos(g.th), sn = Math.sin(g.th), vh = [Math.cos(st.psi) * ct, Math.sin(st.psi) * ct, sn];
  var sq = g.q > 0 ? 1 : -1, sB = g.B > 0 ? 1 : -1;
  var eB = [0, 0, sB], eI = [sq * Math.cos(st.psi), sq * Math.sin(st.psi), 0];
  var eF = [eI[1] * eB[2] - eI[2] * eB[1], eI[2] * eB[0] - eI[0] * eB[2], eI[0] * eB[1] - eI[1] * eB[0]];
  var add = function (a, b, k) { return [a[0] + b[0] * k, a[1] + b[1] * k, a[2] + b[2] * k]; };
  var cen = [0.3, -0.15, 0.2];
  var HW = function (a, b, c) { return add(add(add([0, 0, 0], eI, a - cen[0]), eB, b - cen[1]), eF, c - cen[2]); };
  /* 縮尺と置き場所：どの向きから見ても矢印の先・文字・指先がはみ出さないよう、左右それぞれ外接矩形で合わせる（2026-10-05） */
  var pj1 = mkProj(s.cam.az, s.cam.el, 1, 0, 0), P1 = function (q) { return pj1.p(W3(q[0], q[1], q[2])); };
  var bb = function (pts) { var b = { x0: 1e9, x1: -1e9, y0: 1e9, y1: -1e9 }; pts.forEach(function (q) { var p = P1(q); b.x0 = Math.min(b.x0, p.x); b.x1 = Math.max(b.x1, p.x); b.y0 = Math.min(b.y0, p.y); b.y1 = Math.max(b.y1, p.y); }); return b; };
  var Lr = 1.25, ptsL = [[0, 0, 0]].concat([eB, eF, eI, vh].map(function (d) { return add([0, 0, 0], d, Lr * 1.55); }));
  var ptsR = [[0, -1.55, -0.5], [0, -1.55, 0.26], [0, 1.05, 0.12], [1.0, 0.1, -0.07], [0.05, -0.42, 0.98], [0.12, -0.97, -0.5], [0.12, 0.03, 0.26]].map(function (q) { return HW(q[0], q[1], q[2]); })
    .concat([add(HW(0.05, -0.42, 1.08), eF, 1.3), add(HW(0, 1.15, 0.12), eB, 1.3), add(HW(1.1, 0.1, -0.07), eI, 1.3)]);
  var bL = bb(ptsL), bR = bb(ptsR), top = y + 30, bot = y + h - 44, xm = x + w * 0.44;
  var SL = Math.min((xm - x - 16) / Math.max(0.5, bL.x1 - bL.x0), (bot - top) / Math.max(0.5, bL.y1 - bL.y0), 90);
  var SR = Math.min((x + w - xm - 16) / Math.max(0.5, bR.x1 - bR.x0), (bot - top) / Math.max(0.5, bR.y1 - bR.y0), 80);
  var S = SL;
  var pjL = mkProj(s.cam.az, s.cam.el, SL, (x + 8 + xm) / 2 - SL * (bL.x0 + bL.x1) / 2, (top + bot) / 2 - SL * (bL.y0 + bL.y1) / 2);
  var pjR = mkProj(s.cam.az, s.cam.el, SR, (xm + x + w - 8) / 2 - SR * (bR.x0 + bR.x1) / 2, (top + bot) / 2 - SR * (bR.y0 + bR.y1) / 2);
  var PL = function (q) { return pjL.p(W3(q[0], q[1], q[2])); }, PR = function (q) { return pjR.p(W3(q[0], q[1], q[2])); };
  /* 名前（「磁場」など）は記号のさらに先、矢印の向きへ置く（矢じりと重ならないように） */
  var subLab = function (ar, bx, txt, col) { var cx = bx.x + bx.w / 2, cy = bx.y + bx.h / 2; label(ctx, txt, cx + ar.ux * (bx.w / 2 + 16 + txt.length * 3), cy + ar.uy * (bx.h / 2 + 12), { size: 11, bold: true, color: col }); };
  /* ---- 左：粒子と 4 つの矢印 ---- */
  var O = [0, 0, 0], o2 = PL(O);
  var arr = function (dir, col, kind, txt, side, lab, dx) {
    var a = PL(O), b = PL(add(O, dir, Lr)); dx = dx || [0, 0];
    var ar = kind === 'vel' ? arrow(ctx, a.x + dx[0], a.y + dx[1], b.x + dx[0], b.y + dx[1], 'vel') : arrow(ctx, a.x + dx[0], a.y + dx[1], b.x + dx[0], b.y + dx[1], 'force', col, { noShift: true });
    if (ar) { var bx = tipLabel(ctx, ar, txt, col, { off: 14, size: 18, side: side || 0 }); if (lab && bx) subLab(ar, bx, lab, col); }
    return ar;
  };
  /* 奥から順に（重なりを自然に） */
  var L4 = [{ d: eB, c: M2S6COL.B, t: 'B', lab: '磁場' }, { d: eF, c: M2S6COL.f, t: 'F', lab: '力' }, { d: eI, c: M2S6COL.I, t: 'I', lab: g.q > 0 ? '電流（v と同じ向き）' : '電流（v と逆向き）' }, { d: vh, c: COL.vel, t: 'v', kind: 'vel', lab: '速度' }];
  L4.forEach(function (q) { q.dep = PL(add(O, q.d, 0.8)).d; });
  L4.sort(function (a, b) { return a.dep - b.dep; });
  /* I と v が重なるとき（正の電荷・φ = 0）は、I を画面で少しずらす */
  var vi = PL(add(O, vh, 1)), ii = PL(add(O, eI, 1)), sep = Math.hypot(vi.x - ii.x, vi.y - ii.y) < 10;
  L4.forEach(function (q) {
    var dx = null, side = 0, lab = q.lab;
    if (sep && (q.t === 'I' || q.t === 'v')) {                    /* v と I が重なる：I を少しずらし、文字を左右に分ける */
      var ux = ii.x - o2.x, uy = ii.y - o2.y, ll = Math.hypot(ux, uy) || 1;
      if (q.t === 'I') { dx = [-uy / ll * 10, ux / ll * 10]; side = 26; } else { side = -26; lab = '速度'; }
    }
    arr(q.d, q.c, q.kind || 'force', q.t, side, lab, dx);
  });
  ctx.save(); var gg = ctx.createRadialGradient(o2.x - 4, o2.y - 4, 1, o2.x, o2.y, 15);
  gg.addColorStop(0, '#fff'); gg.addColorStop(0.4, g.q > 0 ? '#f19a8f' : '#8fb6f1'); gg.addColorStop(1, g.q > 0 ? '#b83a2e' : '#2a5fb8');
  ctx.fillStyle = gg; ctx.beginPath(); ctx.arc(o2.x, o2.y, 14, 0, TAU); ctx.fill(); ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 1.2; ctx.stroke(); ctx.restore();
  label(ctx, g.q > 0 ? '+' : '−', o2.x, o2.y, { size: 15, bold: true, color: '#fff', halo: false });
  /* ---- 右：左手。手の座標 (a, b, c) ＝ (中指 I, 人さし指 B, 親指 F) の向き ---- */
  var items = [];
  var cap = function (pts, r) {                                    /* 指：太い線（丸い端） */
    for (var i = 0; i + 1 < pts.length; i++) {
      var p1 = PR(HW.apply(null, pts[i])), p2 = PR(HW.apply(null, pts[i + 1]));
      (function (p1, p2) { items.push({ d: (p1.d + p2.d) / 2, f: function () {
        ctx.save(); ctx.lineCap = 'round'; ctx.strokeStyle = '#a8705a'; ctx.lineWidth = 2 * r * SR + 2.6; ctx.beginPath(); ctx.moveTo(p1.x, p1.y); ctx.lineTo(p2.x, p2.y); ctx.stroke();
        ctx.strokeStyle = '#f2c9a8'; ctx.lineWidth = 2 * r * SR; ctx.beginPath(); ctx.moveTo(p1.x, p1.y); ctx.lineTo(p2.x, p2.y); ctx.stroke(); ctx.restore(); } }); })(p1, p2);
    }
  };
  var box = function (a0, a1, b0, b1, c0, c1, col) {                /* 手のひら・手首：箱の影 */
    var P8 = [], dsum = 0;
    [a0, a1].forEach(function (a) { [b0, b1].forEach(function (b) { [c0, c1].forEach(function (c) { var p = PR(HW(a, b, c)); P8.push(p); dsum += p.d; }); }); });
    var hl = hull2(P8);
    items.push({ d: dsum / 8 - 0.25, f: function () {
      ctx.save(); ctx.beginPath(); hl.forEach(function (p, i) { i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y); }); ctx.closePath();
      ctx.fillStyle = col; ctx.fill(); ctx.strokeStyle = '#a8705a'; ctx.lineWidth = 1.4; ctx.lineJoin = 'round'; ctx.stroke(); ctx.restore(); } });
  };
  box(-0.12, 0.10, -1.55, -0.95, -0.42, 0.18, '#ecbf9c');           /* 手首 */
  box(-0.12, 0.12, -0.97, 0.03, -0.50, 0.26, '#f2c9a8');            /* 手のひら */
  cap([[0, 0, 0.12], [0, 1.05, 0.12]], 0.1);                          /* 人さし指（B） */
  cap([[0.02, 0.0, -0.07], [0.18, 0.1, -0.07], [1.0, 0.1, -0.07]], 0.105);   /* 中指（I）：曲げて手のひらの向きへ */
  cap([[0.02, 0.0, -0.25], [0.26, 0.08, -0.25], [0.3, -0.2, -0.25]], 0.095);  /* 薬指（にぎる） */
  cap([[0.02, -0.04, -0.41], [0.22, 0.02, -0.41], [0.26, -0.2, -0.41]], 0.085); /* 小指（にぎる） */
  cap([[0.03, -0.62, 0.2], [0.05, -0.46, 0.5], [0.05, -0.42, 0.98]], 0.11);   /* 親指（F） */
  items.sort(function (a, b) { return a.d - b.d; });
  items.forEach(function (it) { it.f(); });
  /* 指の先から、その指が表す向きの矢印と名前 */
  var tipArr = function (p0, dir, col, txt, name) {
    var a = PR(add(p0, dir, 0.12)), b = PR(add(p0, dir, 0.75)), ar = arrow(ctx, a.x, a.y, b.x, b.y, 'force', col, { noShift: true });
    if (ar) { var bx = tipLabel(ctx, ar, txt, col, { off: 14, size: 17 }); if (bx) subLab(ar, bx, name, col); }
  };
  tipArr(HW(0.05, -0.42, 1.08), eF, M2S6COL.f, 'F', '親指');
  tipArr(HW(0, 1.15, 0.12), eB, M2S6COL.B, 'B', '人さし指');
  tipArr(HW(1.1, 0.1, -0.07), eI, M2S6COL.I, 'I', '中指');
  /* 文字 */
  label(ctx, '中指 ＝ 電流 I　人さし指 ＝ 磁場 B　親指 ＝ 力 F', x + 12, y + 16, { size: 12.5, bold: true, color: '#7a5600', align: 'left', clamp: false });
  var notes = [];
  if (g.q < 0) notes.push('負の電荷なので、電流 I の向きは速度 v と逆');
  if (Math.abs(g.th) > 1e-6) notes.push('φ ≠ 90°：v の xy 面内の成分（B に垂直）で考える');
  var hint = 'ドラッグで回せる（左の図も一緒に回る）';
  if (W < 560) { notes.push(hint); hint = ''; }
  notes.forEach(function (t, i) { label(ctx, t, x + 14, y + h - 14 - (notes.length - 1 - i) * 18, { size: 11.5, bold: true, color: t === 'ドラッグで回せる（左の図も一緒に回る）' ? COL.sub : '#b2560c', align: 'left', clamp: false }); });
  if (hint) label(ctx, hint, x + w - 12, y + h - 14, { size: 11, color: COL.sub, align: 'right', clamp: false });
  ctx.restore();
}

/* ---------- 2-7「電子のらせん運動を確認」：右の列「速度を分解して考える」の中の、粒子のまわりの拡大図 ----------
   粒子を中心に、まわりのらせんの一部・速度 v とその分解（v cosφ：B に垂直、v sinφ：B に平行）・ローレンツ力 F・磁場 B の向き。
   図と同じカメラ（ドラッグで回すと両方回る）。アニメといっしょに動く */
function m2s6VzPanel(s, st) {
  var cv = s.vzCv; if (!cv || !cv.isConnected) return;
  var w = Math.max(240, Math.floor(cv.parentNode.clientWidth || 360)), h = Math.round(w * 0.62);
  var ctx = prep(cv, w, h), g = st.g;
  ctx.fillStyle = '#fbfdff'; ctx.fillRect(0, 0, w, h);
  var add = function (a, b, k) { return [a[0] + b[0] * k, a[1] + b[1] * k, a[2] + b[2] * k]; };
  var rr = isFinite(st.r) && st.r > 1e-9 ? st.r : 1, ct = Math.cos(g.th), sn = Math.sin(g.th);
  var ur = [(st.x - st.cx) / rr, (st.y - st.cy) / rr, 0], uv = [Math.cos(st.psi), Math.sin(st.psi), 0], d3 = [uv[0] * ct, uv[1] * ct, sn];
  /* まわりのらせん（半径が 2.4 に見えるように縮める。形はそのまま） */
  var kz = 1.6 / rr, path = [], Tp = Math.abs(st.k) > 1e-9 ? TAU / Math.abs(st.k) : 4;
  for (var i = -40; i <= 40; i++) { var q = m2s6At(s, clamp(s.t + Tp * 0.22 * i / 40, 0, s.tEnd())); path.push([(q.x - st.x) * kz, (q.y - st.y) * kz, (q.z - st.z) * kz]); }
  var Lv = 2.6, o = add([0, 0, 0], ur, 0.3), vt = add(o, d3, Lv), vh = add(o, uv, Lv * ct), vzp = add(o, [0, 0, sn >= 0 ? 1 : -1], Lv * Math.abs(sn));
  var fT = add([0, 0, 0], ur, -1.6);
  var pj1 = mkProj(s.cam.az, s.cam.el, 1, 0, 0), bx = { x0: 1e9, x1: -1e9, y0: 1e9, y1: -1e9 };
  [[0, 0, 0], o, vt, vh, vzp, fT, add(vt, d3, 0.5), add(fT, ur, -0.4)].forEach(function (q) { var p = pj1.p(W3(q[0], q[1], q[2])); bx.x0 = Math.min(bx.x0, p.x); bx.x1 = Math.max(bx.x1, p.x); bx.y0 = Math.min(bx.y0, p.y); bx.y1 = Math.max(bx.y1, p.y); });
  var top = 34, bot = h - 30, left = 70, right = w - 14;
  var S = Math.min((right - left) / Math.max(1, bx.x1 - bx.x0), (bot - top) / Math.max(1, bx.y1 - bx.y0), 95);   /* 矢印が大きく入るように（らせんははみ出してよい） */
  var pj = mkProj(s.cam.az, s.cam.el, S, (left + right) / 2 - S * (bx.x0 + bx.x1) / 2, (top + bot) / 2 - S * (bx.y0 + bx.y1) / 2);
  var P = function (q) { return pj.p(W3(q[0], q[1], q[2])); };
  /* らせん（前のほうは濃く、うしろは薄く） */
  ctx.save(); ctx.lineWidth = 2.2; ctx.lineCap = 'round';
  for (var j = 1; j < path.length; j++) { var a = P(path[j - 1]), b = P(path[j]); ctx.strokeStyle = 'rgba(22,99,181,' + (j <= 40 ? 0.55 : 0.18) + ')'; ctx.setLineDash(j <= 40 ? [] : [4, 4]); ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); }
  ctx.restore();
  var O = P([0, 0, 0]);
  /* 力 F（中心向き） */
  var af = arrow(ctx, O.x, O.y, P(fT).x, P(fT).y, 'force', M2S6COL.f, { noShift: true });
  if (af) tipLabel(ctx, af, 'F', M2S6COL.f, { off: 13, size: 17 });
  /* 速度の分解：平行四辺形の補助線 → 成分（破線）→ v（白抜き） */
  var Po = P(o), Pv = P(vt), Ph = P(vh), Pz = P(vzp);
  ctx.save(); ctx.setLineDash([3, 3]); ctx.strokeStyle = 'rgba(22,99,181,.55)'; ctx.lineWidth = 1.1; ctx.beginPath(); ctx.moveTo(Ph.x, Ph.y); ctx.lineTo(Pv.x, Pv.y); ctx.moveTo(Pz.x, Pz.y); ctx.lineTo(Pv.x, Pv.y); ctx.stroke(); ctx.restore();
  var ah = arrow(ctx, Po.x, Po.y, Ph.x, Ph.y, 'comp', COL.vel, { noShift: true });
  if (ah) label(ctx, 'v sinφ（B に垂直・' + fmt(ct, 2) + 'v）', ah.x2 + ah.ux * 14, ah.y2 + ah.uy * 14 + 14, { size: 12, bold: true, color: COL.vel });
  var az = arrow(ctx, Po.x, Po.y, Pz.x, Pz.y, 'comp', COL.vel, { noShift: true });
  if (az) {                                                      /* v と反対がわに書く（重ならないように） */
    var lr = Pv.x < Po.x;
    label(ctx, 'v cosφ（B に平行・' + fmt(Math.abs(sn), 2) + 'v）', lr ? Math.max(az.x1, az.x2) + 10 : Math.min(az.x1, az.x2) - 10, Math.min(az.y1, az.y2) - 4, { size: 12, bold: true, color: COL.vel, align: lr ? 'left' : 'right' });
  }
  var av = arrow(ctx, Po.x, Po.y, Pv.x, Pv.y, 'vel');
  if (av) tipLabel(ctx, av, 'v', COL.vel, { off: 13, size: 18 });
  /* 角 φ（v と +z 軸＝磁場の向きのあいだ。2026-10-05 千葉さん訂正）を書き込む */
  if (Math.abs(sn) > 1e-3 && s.cam.el < 75) {                   /* 真上から見ると角がつぶれるので書かない（2026-10-06 千葉さん） */
    var Pzu = P(add(o, [0, 0, 1], Lv * 0.8));
    if (sn < 0) { ctx.save(); ctx.setLineDash([3, 3]); ctx.strokeStyle = '#6f7782'; ctx.beginPath(); ctx.moveTo(Po.x, Po.y); ctx.lineTo(Pzu.x, Pzu.y); ctx.stroke(); ctx.restore(); label(ctx, '+z', Pzu.x + 10, Pzu.y, { size: 11, color: '#6f7782' }); }
    var aH = Math.atan2(Pzu.y - Po.y, Pzu.x - Po.x), aV = Math.atan2(Pv.y - Po.y, Pv.x - Po.x), dA = aV - aH;
    while (dA > Math.PI) dA -= TAU; while (dA < -Math.PI) dA += TAU;
    var rA = Math.min(70, 0.55 * Math.hypot(Pv.x - Po.x, Pv.y - Po.y));
    ctx.save(); ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.arc(Po.x, Po.y, rA, aH, aH + dA, dA < 0); ctx.stroke(); ctx.restore();
    var aM = aH + dA / 2; sym(ctx, 'φ', Po.x + Math.cos(aM) * (rA + 13), Po.y + Math.sin(aM) * (rA + 13), { size: 16, color: '#2b323c' });
    label(ctx, 'φ = ' + fmt(90 - g.th * 180 / Math.PI, 0) + '°（v と磁場 B のなす角）', w - 10, 34, { size: 12, bold: true, color: '#2b323c', align: 'right', clamp: false });
  }
  /* 粒子 */
  ctx.save(); var gg = ctx.createRadialGradient(O.x - 3, O.y - 3, 1, O.x, O.y, 12);
  gg.addColorStop(0, '#fff'); gg.addColorStop(0.4, g.q > 0 ? '#f19a8f' : '#8fb6f1'); gg.addColorStop(1, g.q > 0 ? '#b83a2e' : '#2a5fb8');
  ctx.fillStyle = gg; ctx.beginPath(); ctx.arc(O.x, O.y, 11, 0, TAU); ctx.fill(); ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 1.1; ctx.stroke(); ctx.restore();
  label(ctx, g.q > 0 ? '+' : '−', O.x, O.y, { size: 13, bold: true, color: '#fff', halo: false });
  /* 磁場 B の向き（左下に小さく） */
  var b0 = { x: 30, y: g.B >= 0 ? h - 22 : h - 76 }, bz = pj.p(W3(0, 0, 0)), bz1 = pj.p(W3(0, 0, g.B >= 0 ? 1 : -1)), ul = Math.hypot(bz1.x - bz.x, bz1.y - bz.y) || 1;
  var bdx = (bz1.x - bz.x) / ul, bdy = (bz1.y - bz.y) / ul, aB = arrow(ctx, b0.x - bdx * 0, b0.y, b0.x + bdx * 46, b0.y + bdy * 46, 'force', M2S6COL.B, { noShift: true });
  if (aB) tipLabel(ctx, aB, 'B', M2S6COL.B, { off: 12, size: 16 });
  label(ctx, (s.v.pre ? M2S6PRE[s.v.pre].name : '粒子') + 'の周りを拡大（らせんは形をそのままに縮めて表示）', 10, 15, { size: 12, bold: true, color: '#1c4386', align: 'left', clamp: false });
  label(ctx, 'ドラッグで回せる', w - 10, h - 12, { size: 11, color: COL.sub, align: 'right', clamp: false });
}
