/* =========================================================================
   40_draw.js … 共通の描画部品（basics-of-motion-on-plane の 40_draw.js と同じ決めごと）
   ・力の矢印は作用点に「・」、同じ線上に重なったら少しずらす、同じ長さには等長マーク
   ・色はシリーズ全体で固定（力のベクトルの描き方ルール）
   ========================================================================= */
'use strict';
var FONT = '"Hiragino Sans","Hiragino Kaku Gothic ProN","Yu Gothic Medium","Yu Gothic",Meiryo,sans-serif';
var MATH = '"KaTeX_Math","Times New Roman",serif';
var SER = '"KaTeX_Main","Times New Roman",serif';
var COL = {
  force: '#d1352b',   /* 重力・一般の力＝赤 */
  norm: '#7b3fd4',    /* 垂直抗力＝むらさき */
  fric: '#0f8a8a',    /* 摩擦力＝青緑 */
  hand: '#c2367f',    /* 手・ひもの力（張力）・ばねの力＝ピンク */
  vel: '#1663b5',     /* 速度＝青の白抜き */
  acc: '#e07b18',     /* 加速度＝オレンジ */
  cent: '#3f4a54',    /* 遠心力（見かけの力）＝濃いグレーの破線（2026-10 千葉さんが選んだ） */
  euler: '#3f4a54',   /* 接線方向の慣性力（見かけの力）＝同じ濃いグレーの破線 */
  dim: '#14171c',     /* 寸法＝黒の細い破線 */
  ink: '#14171c', ink2: '#3a414c', sub: '#69717d', faint: '#9aa1ab',
  rule: '#e6e1d7', paper: '#f5f3ee'
};

var CVW = 0, CVH = 0, CVID = '';
/* canvas を高解像度で用意して ctx を返す（論理サイズ w×h で描ける） */
function prep(cv, w, h) {
  CVW = w; CVH = h; CVID = cv.id || '';
  _fArrows.length = 0;
  var dpr = Math.min(2, Math.max(1, window.devicePixelRatio || 1));   /* 画面の解像度に合わせる（ふつうの画面で 1.5 倍に描くと重い） */
  var W2 = Math.round(w * dpr), H2 = Math.round(h * dpr);
  if (cv.width !== W2 || cv.height !== H2) { cv.width = W2; cv.height = H2; }
  cv.style.height = h + 'px';
  var ctx = cv.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);
  ctx.lineJoin = 'round'; ctx.lineCap = 'butt';
  return ctx;
}
function fade(hex, a) {
  var n = parseInt(hex.slice(1), 16);
  return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
}

/* ---------- 力の矢印の重なりよけ・等長マーク ---------- */
var _fArrows = [];
function arrowShift(x1, y1, ux, uy, len) {
  var step = 5.5, n = 0;
  for (var i = 0; i < _fArrows.length; i++) {
    var a = _fArrows[i];
    if (a.cat !== 'F') continue;
    if (Math.abs(a.ux * uy - a.uy * ux) > 0.25) continue;
    var dPerp = Math.abs((a.x - x1) * uy - (a.y - y1) * ux);
    if (dPerp > 6) continue;
    var t0 = (a.x - x1) * ux + (a.y - y1) * uy;
    var t1 = t0 + a.len * ((a.ux * ux + a.uy * uy >= 0) ? 1 : -1);
    var lo = Math.min(t0, t1), hi = Math.max(t0, t1);
    if (hi > 1 && lo < len - 1) n++;
  }
  var rec = { x: x1, y: y1, ux: ux, uy: uy, len: len, cat: 'F', color: COL.force };
  _fArrows.push(rec);
  var out = { dx: 0, dy: 0, rec: rec };
  if (n) { var sgn = (n % 2) ? 1 : -1, mag = step * Math.ceil(n / 2); out.dx = -uy * mag * sgn; out.dy = ux * mag * sgn; }
  return out;
}
function drawEqualTicks(ctx) {
  ['F', 'V'].forEach(function (cat) {
    var groups = [];
    _fArrows.forEach(function (a) {
      if (a.cat !== cat || a.len < 19 || a.noTick) return;
      var g = null;
      for (var j = 0; j < groups.length; j++) if (Math.abs(groups[j].len - a.len) <= (cat === 'V' ? 0.35 : 0.8)) { g = groups[j]; break; }
      if (!g) { g = { len: a.len, items: [] }; groups.push(g); }
      g.items.push(a);
    });
    var eq = groups.filter(function (g) { return g.items.length >= 2; }).sort(function (p, q) { return q.len - p.len; });
    eq.forEach(function (g, i) { g.items.forEach(function (a) { equalTick(ctx, a, Math.min(3, i + 1)); }); });
  });
}
function equalTick(ctx, a, n) {
  var pos = Math.max(6, Math.min(a.len * 0.42, a.len - 13));
  var mx = a.x + a.ux * pos, my = a.y + a.uy * pos, px = -a.uy, py = a.ux;
  ctx.save(); ctx.strokeStyle = a.color; ctx.lineWidth = 2.1; ctx.lineCap = 'round'; ctx.setLineDash([]);
  for (var i = 0; i < n; i++) {
    var d = (i - (n - 1) / 2) * 4.6, cx = mx + a.ux * d, cy = my + a.uy * d;
    ctx.beginPath(); ctx.moveTo(cx - px * 5.6, cy - py * 5.6); ctx.lineTo(cx + px * 5.6, cy + py * 5.6); ctx.stroke();
  }
  ctx.restore();
}

/* 矢印。kind：force（力・実線）／fict（見かけの力・破線）／comp（分力・破線）／vel（速度・白抜き）／acc（加速度）／dim（寸法）
   戻り値：実際に描いた始点・終点（ずらしたあと） */
function arrow(ctx, x1, y1, x2, y2, kind, col, opt) {
  opt = opt || {};
  var dx = x2 - x1, dy = y2 - y1, len = Math.hypot(dx, dy);
  if (len < 1.5) return null;
  var ux = dx / len, uy = dy / len;
  if (kind === 'force' || kind === 'comp' || kind === 'fict') {
    if (!opt.noShift) {
      var sh = arrowShift(x1, y1, ux, uy, len);
      x1 += sh.dx; y1 += sh.dy; x2 += sh.dx; y2 += sh.dy;
      sh.rec.x = x1; sh.rec.y = y1; sh.rec.color = col || COL.force; sh.rec.noTick = (kind === 'comp' && !opt.tick);
    } else _fArrows.push({ x: x1, y: y1, ux: ux, uy: uy, len: len, cat: 'F', color: col || COL.force, noTick: (kind === 'comp' && !opt.tick) });
  } else if (kind === 'vel') {
    _fArrows.push({ x: x1, y: y1, ux: ux, uy: uy, len: len, cat: 'V', color: COL.vel });
  }
  var head = (kind === 'dim' ? 8 : (kind === 'vel' || kind === 'comp' || kind === 'fict' ? 11 : 12));
  if (head > len * 0.8) head = len * 0.8;
  var bx = x2 - ux * head, by = y2 - uy * head;
  var FC = col || COL.force;
  ctx.save(); ctx.lineJoin = 'round';
  if (kind === 'force') { ctx.strokeStyle = FC; ctx.fillStyle = FC; ctx.lineWidth = 3.4; }
  else if (kind === 'fict') { ctx.strokeStyle = FC; ctx.fillStyle = '#ffffff'; ctx.lineWidth = 3.0; ctx.setLineDash([7, 4]); }
  else if (kind === 'acc') { ctx.strokeStyle = COL.acc; ctx.fillStyle = COL.acc; ctx.lineWidth = 3.0; }
  else if (kind === 'vel') { ctx.strokeStyle = COL.vel; ctx.fillStyle = '#ffffff'; ctx.lineWidth = 2.4; }
  else if (kind === 'comp') { ctx.strokeStyle = FC; ctx.fillStyle = fade(FC, .38); ctx.lineWidth = 2.1; ctx.setLineDash([6, 4]); }
  else { ctx.strokeStyle = col || COL.dim; ctx.fillStyle = col || COL.dim; ctx.lineWidth = 1.2; ctx.setLineDash([5, 4]); }
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(bx, by); ctx.stroke();
  ctx.setLineDash([]);
  if (kind === 'force' || kind === 'comp' || kind === 'fict') {           /* 作用点を「・」で示す */
    ctx.beginPath(); ctx.arc(x1, y1, 3.1, 0, TAU); ctx.fillStyle = FC; ctx.fill();
    ctx.fillStyle = (kind === 'force') ? FC : (kind === 'fict' ? '#ffffff' : fade(FC, .38));
  }
  var wA = head * 0.5;
  ctx.beginPath(); ctx.moveTo(x2, y2); ctx.lineTo(bx - uy * wA, by + ux * wA); ctx.lineTo(bx + uy * wA, by - ux * wA); ctx.closePath();
  ctx.fill();
  if (kind === 'vel' || kind === 'comp' || kind === 'fict') { ctx.lineWidth = 2.0; ctx.stroke(); }
  ctx.restore();
  return { x1: x1, y1: y1, x2: x2, y2: y2, ux: ux, uy: uy, len: len };
}

/* 両矢印の寸法線 */
function dimLine(ctx, x1, y1, x2, y2, col) {
  var L = Math.hypot(x2 - x1, y2 - y1); if (L < 4) return;
  var ux = (x2 - x1) / L, uy = (y2 - y1) / L, h = Math.min(7, L / 3);
  ctx.save(); ctx.strokeStyle = col || COL.dim; ctx.fillStyle = col || COL.dim; ctx.lineWidth = 1.1; ctx.setLineDash([4, 3]);
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); ctx.setLineDash([]);
  [[x1, y1, -1], [x2, y2, 1]].forEach(function (p) {
    var bx = p[0] - ux * h * p[2], by = p[1] - uy * h * p[2];
    ctx.beginPath(); ctx.moveTo(p[0], p[1]); ctx.lineTo(bx - uy * h * .45, by + ux * h * .45); ctx.lineTo(bx + uy * h * .45, by - ux * h * .45); ctx.closePath(); ctx.fill();
  });
  ctx.restore();
}

/* ---------- 文字 ---------- */
var _txtBox = [];
/* ふつうの文字（日本語）。白フチつき。canvas の外にはみ出さないように寄せる */
function label(ctx, text, x, y, opt) {
  opt = opt || {};
  var size = opt.size || 13;
  ctx.save();
  ctx.font = (opt.bold ? '700 ' : '600 ') + size + 'px ' + FONT;
  ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
  var tw = ctx.measureText(text).width, al = opt.align || 'center';
  var left = al === 'right' ? x - tw : (al === 'left' ? x : x - tw / 2);
  if (opt.clamp !== false && CVW) { left = clamp(left, 4, Math.max(4, CVW - 4 - tw)); y = clamp(y, size / 2 + 3, CVH - size / 2 - 3); }
  if (opt.halo !== false) { ctx.strokeStyle = opt.haloColor || 'rgba(255,255,255,.92)'; ctx.lineWidth = opt.haloW || 4.5; ctx.lineJoin = 'round'; ctx.strokeText(text, left, y); }
  ctx.fillStyle = opt.color || COL.ink; ctx.fillText(text, left, y);
  ctx.restore();
  var box = { x: left, y: y - size / 2, w: tw, h: size };
  if (window.__labelLog) window.__labelLog.push({ cv: CVID, text: text, x: box.x, y: box.y, w: box.w, h: box.h });
  return box;
}
/* 物理量の記号（斜体）。opt.vec でベクトルの矢印、opt.sub で添え字、opt.tail でうしろにふつうの文字 */
function sym(ctx, s, x, y, opt) {
  opt = opt || {};
  var size = opt.size || 17, col = opt.color || COL.ink;
  ctx.save(); ctx.textBaseline = 'alphabetic';
  ctx.font = 'italic ' + size + 'px ' + MATH; var wb = ctx.measureText(s).width;
  var subS = opt.sub || '', ws = 0;
  if (subS) { ctx.font = Math.round(size * 0.7) + 'px ' + (opt.subItalic ? MATH : SER); ws = ctx.measureText(subS).width + 1; }
  var tail = opt.tail || '', wt = 0;
  if (tail) { ctx.font = '600 ' + Math.round(size * 0.78) + 'px ' + FONT; wt = ctx.measureText(tail).width + 3; }
  var W = wb + ws + wt, al = opt.align || 'center';
  var X = al === 'right' ? x - W : (al === 'left' ? x : x - W / 2);
  var Y = y + size * 0.34;                                     /* y は文字の上下のまん中 */
  if (opt.clamp !== false && CVW) { X = clamp(X, 4, Math.max(4, CVW - 4 - W)); Y = clamp(Y, size + 4, CVH - 5); }
  var draw = function (stroke) {
    ctx.font = 'italic ' + size + 'px ' + MATH; stroke ? ctx.strokeText(s, X, Y) : ctx.fillText(s, X, Y);
    if (subS) { ctx.font = Math.round(size * 0.7) + 'px ' + (opt.subItalic ? MATH : SER); stroke ? ctx.strokeText(subS, X + wb + 1, Y + size * 0.2) : ctx.fillText(subS, X + wb + 1, Y + size * 0.2); }
    if (tail) { ctx.font = '600 ' + Math.round(size * 0.78) + 'px ' + FONT; stroke ? ctx.strokeText(tail, X + wb + ws + 3, Y) : ctx.fillText(tail, X + wb + ws + 3, Y); }
  };
  if (opt.halo !== false) { ctx.strokeStyle = opt.haloColor || 'rgba(255,255,255,.94)'; ctx.lineWidth = 4.5; ctx.lineJoin = 'round'; draw(true); }
  ctx.fillStyle = col; draw(false);
  if (opt.vec) {                                               /* 文字の上の小さな矢印 */
    var pw = 0; if (opt.vecSkip) { ctx.font = 'italic ' + size + 'px ' + MATH; pw = ctx.measureText(opt.vecSkip).width; }   /* vecSkip：矢印をつけない頭の文字（Δv の Δ） */
    var ax0 = X + pw + (wb - pw) * 0.18, ax1 = X + wb * 0.98 + 1, ay = Y - size * 0.83;
    ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(ax0, ay); ctx.lineTo(ax1 - 2, ay); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(ax1 + 1, ay); ctx.lineTo(ax1 - 3.5, ay - 2.6); ctx.lineTo(ax1 - 3.5, ay + 2.6); ctx.closePath(); ctx.fill();
  }
  ctx.restore();
  var box = { x: X, y: Y - size * (opt.vec ? 1.05 : 0.8), w: W, h: size * (opt.vec ? 1.3 : 1.05) };
  if (window.__labelLog) window.__labelLog.push({ cv: CVID, text: s + subS + tail, x: box.x, y: box.y, w: box.w, h: box.h });
  return box;
}

/* ---------- 形 ---------- */
function rrect(ctx, x, y, w, h, r) {
  ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
}
/* 小球（立体感のある丸） */
function ballShape(ctx, x, y, r, col, alpha) {
  ctx.save(); ctx.globalAlpha = (alpha === undefined ? 1 : alpha);
  var g = ctx.createRadialGradient(x - r * .35, y - r * .4, r * .1, x, y, r);
  g.addColorStop(0, '#ffffff'); g.addColorStop(.25, col || '#b9c3cf'); g.addColorStop(1, '#5d6875');
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
  ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 1.2; ctx.stroke();
  ctx.restore();
}
/* 角の弧（画面の角で a0 → a1）と文字 */
function angArc(ctx, cx, cy, r, a0, a1, col, ccw) {
  ctx.save(); ctx.strokeStyle = col || COL.ink2; ctx.lineWidth = 1.3;
  ctx.beginPath(); ctx.arc(cx, cy, r, a0, a1, !!ccw); ctx.stroke(); ctx.restore();
}
/* 回る向きの矢印（円弧＋矢じり）。画面の角で a0 → a1 */
function spinArrow(ctx, cx, cy, rx, ry, a0, a1, col, lw) {
  ctx.save(); ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = lw || 2.2;
  var n = 36, pts = [];
  for (var i = 0; i <= n; i++) { var a = a0 + (a1 - a0) * i / n; pts.push([cx + rx * Math.cos(a), cy + ry * Math.sin(a)]); }
  ctx.beginPath(); pts.slice(0, n - 3).forEach(function (p, i) { i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]); }); ctx.stroke();
  var p1 = pts[n], p0 = pts[n - 4], dx = p1[0] - p0[0], dy = p1[1] - p0[1], L = Math.hypot(dx, dy) || 1, ux = dx / L, uy = dy / L, h = 10;
  ctx.beginPath(); ctx.moveTo(p1[0], p1[1]); ctx.lineTo(p1[0] - ux * h - uy * h * .5, p1[1] - uy * h + ux * h * .5); ctx.lineTo(p1[0] - ux * h + uy * h * .5, p1[1] - uy * h - ux * h * .5); ctx.closePath(); ctx.fill();
  ctx.restore();
  return pts[Math.round(n / 2)];
}
/* 棒人間。(x,y)＝足もと、(ux,uy)＝画面での「上」の向き */
function stickman(ctx, x, y, ux, uy, s, color, lw) {
  var px = -uy, py = ux;
  function P(du, dp) { return [x + ux * du * s + px * dp * s, y + uy * du * s + py * dp * s]; }
  ctx.save(); ctx.strokeStyle = color || COL.sub; ctx.lineWidth = lw || 2; ctx.lineCap = 'round';
  var hip = P(0.38, 0), sh = P(0.64, 0), hd = P(0.80, 0);
  ctx.beginPath(); ctx.arc(hd[0], hd[1], s * 0.13, 0, TAU); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(hip[0], hip[1]); ctx.lineTo(sh[0], sh[1]); ctx.stroke();
  var f1 = P(0, -0.17), f2 = P(0, 0.17);
  ctx.beginPath(); ctx.moveTo(f1[0], f1[1]); ctx.lineTo(hip[0], hip[1]); ctx.lineTo(f2[0], f2[1]); ctx.stroke();
  var e1 = P(0.50, -0.17), e2 = P(0.50, 0.17), h1 = P(0.38, -0.12), h2 = P(0.38, 0.12);   /* 腕はひじで曲げる */
  ctx.beginPath(); ctx.moveTo(h1[0], h1[1]); ctx.lineTo(e1[0], e1[1]); ctx.lineTo(sh[0], sh[1]); ctx.lineTo(e2[0], e2[1]); ctx.lineTo(h2[0], h2[1]); ctx.stroke();
  ctx.restore();
  return { x: hd[0], y: hd[1], r: s * 0.13 };                  /* 頭（吹き出しのしっぽを向ける） */
}
/* 観測者（棒人間＋名前）。active なら青くて太い＋「（いまの視点）」 */
var OBS_DIM = 0.42;
function observer(ctx, x, y, ux, uy, name, active, s, lab) {
  var col = active ? COL.vel : '#9aa3ac';
  lab = lab || {};
  ctx.save(); if (!active) ctx.globalAlpha *= OBS_DIM;          /* いまの視点でない観測者は、うすく（2026-10-06 千葉さん） */
  var hd = stickman(ctx, x, y, ux, uy, s || 30, col, active ? 2.4 : 1.7);
  var txt = name + (active ? '（いまの視点）' : '');
  var lx = x + (lab.dx || 0), ly = (uy < -0.2) ? y + 14 + (lab.dy || 0) : y + uy * (s || 30) * 1.15 + (lab.dy || 0);
  if (uy < -0.2 && lab.above) ly = y + uy * (s || 30) * 1.12 + (lab.dy || 0);
  if (name) label(ctx, txt, lx, ly, { size: active ? 11.5 : 10.5, bold: !!active, color: col, align: lab.align || 'center' });
  ctx.restore();
  return hd;
}

/* ---------- 吹き出し（rigid-body-dynamics.html と同じ形）----------
   side: 'down' … (x, y) はしっぽの先。箱はその上に出る（ふつうはこれ）／'up' … 箱は下に出る。
   箱は図の外にはみ出さないよう左右・上下に寄せる（しっぽの先は動かさない） */
function bubble(ctx, text, x, y, opt) {
  opt = opt || {};
  var side = opt.side || 'down', T = 8, size = opt.size || 14;
  ctx.save();
  ctx.font = 'bold ' + size + 'px ' + FONT;
  var w = ctx.measureText(text).width + 18, h = size + 14;
  if (side === 'down' && y - T - h < 4) side = 'up';             /* 上に場所がなければ下に出す */
  var bx = x - w / 2 + (opt.dx || 0), by = (side === 'up') ? y + T : y - T - h;
  if (CVW) { bx = clamp(bx, 4, Math.max(4, CVW - 4 - w)); by = clamp(by, 4, Math.max(4, CVH - 4 - h)); }
  var tx = clamp(x, bx + 10, bx + w - 10);
  var t1, t2, tp = [x, y];
  if (side === 'up') { t1 = [tx - 6, by]; t2 = [tx + 6, by]; } else { t1 = [tx - 6, by + h]; t2 = [tx + 6, by + h]; }
  ctx.fillStyle = opt.bg || '#fff5d6'; ctx.strokeStyle = opt.border || '#d9a545'; ctx.lineWidth = 1.4;
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(bx, by, w, h, Math.min(12, h / 2)); else ctx.rect(bx, by, w, h);
  ctx.save(); ctx.shadowColor = 'rgba(20,23,28,.16)'; ctx.shadowBlur = 14; ctx.shadowOffsetY = 4; ctx.fill(); ctx.restore();
  ctx.stroke();
  ctx.beginPath(); ctx.moveTo(t1[0], t1[1]); ctx.lineTo(tp[0], tp[1]); ctx.lineTo(t2[0], t2[1]); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(t1[0], t1[1]); ctx.lineTo(tp[0], tp[1]); ctx.lineTo(t2[0], t2[1]); ctx.stroke();
  ctx.fillStyle = opt.color || '#8a5000'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText(text, bx + w / 2, by + h / 2 + 0.5);
  ctx.restore();
  if (window.__labelLog) window.__labelLog.push({ cv: CVID, text: text, x: bx, y: by, w: w, h: h, pill: 1 });
  return { x: bx, y: by, w: w, h: h };
}
/* 物体のできごと（すべった！／糸が切れた！）。(x, y)＝物体の上のはし */
function eventBubble(ctx, kind, x, y, side) {
  var red = { size: 14, bg: '#fde2dc', border: '#d1352b', color: '#9b2418', side: side || 'down' }, yy = side === 'up' ? y : y - 4;
  if (kind === 'slip') return bubble(ctx, '滑り出した！', x, yy, { size: 14, bg: '#dff2ee', border: '#0f8a8a', color: '#0a5c5c', side: side || 'down' });
  if (kind === 'loop') return bubble(ctx, '宙返りした！', x, yy, { size: 14, bg: '#dff2ee', border: '#0f8a8a', color: '#0a5c5c', side: side || 'down' });
  if (kind === 'top') return bubble(ctx, '最高点に達した！', x, yy, { size: 14, bg: '#dff2ee', border: '#0f8a8a', color: '#0a5c5c', side: side || 'down' });
  var T = { cut: '糸が切れた！', off: '面から離れた！', slack: '糸がたるんだ！' }[kind];
  return T ? bubble(ctx, T, x, yy, red) : null;
}
/* いまの視点の観測者のセリフ。hd＝頭（observer の戻り値） */
function speech(ctx, text, hd) {
  if (!hd) return null;
  return bubble(ctx, text, hd.x, hd.y - hd.r - 3, { size: 12.5, bg: '#ffffff', border: COL.vel, color: '#123f73' });
}
/* 地面（ハッチつき）：左→右に渡すと、印は下に出る */
function groundLine(ctx, x1, x2, y, col) {
  ctx.save(); ctx.strokeStyle = col || '#2b323c'; ctx.lineWidth = 1.6;
  ctx.beginPath(); ctx.moveTo(x1, y); ctx.lineTo(x2, y); ctx.stroke();
  ctx.lineWidth = 1; ctx.strokeStyle = '#a9a193';
  ctx.beginPath(); ctx.rect(Math.min(x1, x2), y, Math.abs(x2 - x1), 10); ctx.clip();
  for (var X = Math.min(x1, x2); X < Math.max(x1, x2) + 9; X += 9) { ctx.beginPath(); ctx.moveTo(X, y); ctx.lineTo(X - 7, y + 8); ctx.stroke(); }
  ctx.restore();
}
/* 吹き出しのような小さな札（状態の表示など） */
function pill(ctx, text, x, y, opt) {
  opt = opt || {};
  ctx.save(); ctx.font = '700 ' + (opt.size || 12.5) + 'px ' + FONT;
  var w = ctx.measureText(text).width + 22, h = (opt.size || 12.5) + 12;
  var X = opt.align === 'right' ? x - w : x;
  ctx.shadowColor = 'rgba(20,23,28,.14)'; ctx.shadowBlur = 10; ctx.shadowOffsetY = 3;
  ctx.fillStyle = opt.bg || 'rgba(255,255,255,.97)'; rrect(ctx, X, y, w, h, h / 2); ctx.fill();
  ctx.shadowColor = 'transparent';
  ctx.strokeStyle = opt.border || 'rgba(20,23,28,.12)'; ctx.lineWidth = 1.2; ctx.stroke();
  ctx.fillStyle = opt.color || COL.ink; ctx.textBaseline = 'middle'; ctx.fillText(text, X + 11, y + h / 2 + .5);
  ctx.restore();
  if (window.__labelLog) window.__labelLog.push({ cv: CVID, text: text, x: X, y: y, w: w, h: h, pill: 1 });
  return { x: X, y: y, w: w, h: h };
}
/* 正射影（canvas-3d-view-drag スキル）。az, el は［度］ */
function mkProj(azDeg, elDeg, S, cx, cy) {
  var az = azDeg * Math.PI / 180, el = elDeg * Math.PI / 180;
  var ca = Math.cos(az), sa = Math.sin(az), ce = Math.cos(el), se = Math.sin(el);
  return {
    p: function (q) {
      var x1 = q[0] * ca - q[1] * sa, y1 = q[0] * sa + q[1] * ca;
      return { x: cx + x1 * S, y: cy - (q[2] * ce - y1 * se) * S, d: y1 * ce + q[2] * se };
    },
    S: S, el: elDeg, az: azDeg
  };
}

/* ---------- デコピン（mechanical-energy.html と同じ形）。モード3 の初速度を与える ----------
   flickHand：(x,y)＝こぶしの中心、ang＝はじく向き（画面の角、rad）、k＝0 曲げた指 → 1 はじいたあと、sc＝大きさ、alpha＝濃さ */
/* 小球をそっと放す手（mechanical-energy.html の dropHand と同じ形。真横やや上から見て、指先の下に小球）。
   (x,y)＝小球の中心、sc＝大きさ、open＝0〜1（1 で親指と人差し指をひらいた形）、alpha＝濃さ */
function dropHand(ctx, x, y, sc, open, alpha) {
  sc = sc || 1;
  var o = Math.max(0, Math.min(1, open || 0)), INK = '#3f4a54', SKIN = '#ffffff';
  ctx.save(); ctx.translate(x, y); ctx.scale(sc, sc);
  ctx.globalAlpha = (alpha === undefined) ? 1 : alpha; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  function limb(x0, y0, cx, cy, x1, y1, w) {
    ctx.beginPath(); ctx.moveTo(x0, y0); ctx.quadraticCurveTo(cx, cy, x1, y1);
    ctx.lineWidth = w + 3.4; ctx.strokeStyle = INK; ctx.stroke(); ctx.lineWidth = w; ctx.strokeStyle = SKIN; ctx.stroke();
  }
  limb(-28, -66, -58, -54, -66, -28, 12);
  limb(-14, -72, -46, -58, -52, -21, 13);
  limb(2, -74, -30, -60, -33, -16, 14);
  limb(16, -72, -10 - 9 * o, -58, -13 - 21 * o, -15 - 9 * o, 14);   /* 人差し指 */
  ctx.beginPath(); ctx.moveTo(-32, -62); ctx.bezierCurveTo(-8, -94, 42, -98, 64, -74); ctx.bezierCurveTo(80, -58, 62, -40, 34, -40); ctx.bezierCurveTo(10, -40, -12, -46, -32, -62); ctx.closePath();
  ctx.fillStyle = SKIN; ctx.fill(); ctx.lineWidth = 3.2; ctx.strokeStyle = INK; ctx.stroke();
  ctx.beginPath(); ctx.moveTo(56, -84); ctx.lineTo(96, -78); ctx.lineTo(96, -50); ctx.lineTo(58, -46); ctx.closePath();
  ctx.fillStyle = SKIN; ctx.fill(); ctx.lineWidth = 3.2; ctx.strokeStyle = INK; ctx.stroke();
  limb(42, -48, 40 + 10 * o, -25, 17 + 24 * o, -12 - 8 * o, 15);   /* 親指 */
  ctx.lineWidth = 1.3; ctx.strokeStyle = INK; ctx.globalAlpha *= 0.75;
  ctx.beginPath(); ctx.moveTo(-46, -47); ctx.lineTo(-38, -44); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(-26, -47); ctx.lineTo(-18, -45); ctx.stroke();
  ctx.restore();
}
function flickHand(ctx, x, y, ang, k, dir, sc, alpha) {
  k = Math.max(0, Math.min(1, k || 0)); sc = sc || 0.45;
  var SKIN = '#fbd7b7', INK = '#4a3730';
  function mix(a, b) { return a + (b - a) * k; }
  ctx.save(); ctx.translate(x, y); ctx.rotate(ang); if (dir < 0) ctx.scale(-1, 1); ctx.scale(sc, sc);
  ctx.globalAlpha = (alpha === undefined) ? 1 : alpha; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  ctx.lineWidth = 26; ctx.strokeStyle = SKIN; ctx.beginPath(); ctx.moveTo(-6, 10); ctx.lineTo(-96, 58); ctx.stroke();
  ctx.lineWidth = 3.4; ctx.strokeStyle = INK;
  ctx.beginPath(); ctx.moveTo(-14, -2); ctx.lineTo(-100, 46); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(-2, 22); ctx.lineTo(-92, 70); ctx.stroke();
  ctx.beginPath(); ctx.arc(0, 0, 30, 0, Math.PI * 2); ctx.fillStyle = SKIN; ctx.fill(); ctx.lineWidth = 3.4; ctx.strokeStyle = INK; ctx.stroke();
  ctx.lineWidth = 2.6;
  ctx.beginPath(); ctx.ellipse(24, -18, 15, 11, -0.35, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.ellipse(28, 2, 16, 12, -0.15, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.ellipse(22, 22, 17, 12, 0.15, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  var jx = mix(34, 44), jy = mix(-52, -20), tx = mix(52, 80), ty = mix(-16, -12);
  ctx.beginPath(); ctx.moveTo(16, -20); ctx.lineTo(jx, jy); ctx.lineTo(tx, ty); ctx.strokeStyle = INK; ctx.lineWidth = 18; ctx.stroke();
  ctx.lineWidth = 12; ctx.strokeStyle = SKIN; ctx.beginPath(); ctx.moveTo(16, -20); ctx.lineTo(jx, jy); ctx.lineTo(tx, ty); ctx.stroke();
  if (k > 0.15 && k < 0.95) {                                  /* はじいた瞬間の勢いの線 */
    ctx.strokeStyle = INK; ctx.lineWidth = 2.4; ctx.globalAlpha *= (1 - k);
    for (var i2 = -1; i2 <= 1; i2++) { ctx.beginPath(); ctx.moveTo(tx + 12, ty + i2 * 14); ctx.lineTo(tx + 30, ty + i2 * 20); ctx.stroke(); }
  }
  ctx.restore();
}
/* デコピン（まとめて）：時刻 t を渡すだけ。はじく前（t = 0）は曲げた指で待ち、はじいたらすっと消える。吹き出し「デコピン！」は手の真上 */
function flickStart(ctx, t, v0, cx, cy, ang, up, noBub) {        /* noBub：吹き出し「デコピン！」を出さない（モード4。2026-10-06 千葉さん） */
  if (!(Math.abs(v0) > 0.05) || t >= 0.34) return;
  var k = clamp(t / 0.10, 0, 1), a = (t <= 0.13) ? 1 : Math.max(0, 1 - (t - 0.13) / 0.18);
  if (a <= 0.02) return;
  flickHand(ctx, cx, cy, ang, k, 1, 0.42, a);
  if (noBub) return;
  ctx.save(); ctx.globalAlpha = a;
  bubble(ctx, 'デコピン！', cx, cy - (up || 48), { size: 12.5, bg: '#fff5e8', border: '#e07b18', color: '#a85c0c' });
  ctx.restore();
}
