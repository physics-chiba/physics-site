/* =========================================================================
   72_m3snaps.js … モード3 の左下の「コマ図」（momentum-and-collision.html 1-1 の 3 コマ図と同じ考え）
   いまの v₀ の動きを 4 コマで：3-1 なら「床を等速で進む → 円筒面をのぼる → 離れる瞬間 → 離れた後」。
   起きないとき（離れない・たるまない）は、そのときの動きの 4 コマ。
   コマは drawM3 を s._snap = true で別の canvas に描き、ならべて貼る。マウスを重ねる（タップする）と拡大。
   ========================================================================= */
'use strict';
/* ---- 拡大表示（momentum-and-collision.html と同じしくみ） ---- */
var ZOV = null, ZCV = null, ZCX = null;
function zoomInit() {
  if (ZOV) return;
  ZOV = el('div', 'zoomlay hidden'); ZCV = el('canvas'); ZOV.appendChild(ZCV); ZCX = ZCV.getContext('2d');
  document.body.appendChild(ZOV);
  document.addEventListener('click', function () { zoomHide(); });
  window.addEventListener('resize', function () { zoomHide(); });
  window.addEventListener('scroll', function () { zoomHide(); }, { passive: true });
}
function zoomShow(box) {
  var z = box._z; if (!z || !z.w || !z.h) return;
  zoomInit();
  var maxW = Math.min(window.innerWidth - 20, 1180), maxH = window.innerHeight - 20;
  var k = Math.min(maxW / z.w, maxH / z.h, 2.2);
  if (k < 1.12) return;
  var W = z.w * k, H = z.h * k, dpr = Math.min(2, window.devicePixelRatio || 1);
  ZCV.style.width = W + 'px'; ZCV.style.height = H + 'px';
  ZCV.width = Math.round(W * dpr); ZCV.height = Math.round(H * dpr);
  ZCX.setTransform(dpr * k, 0, 0, dpr * k, 0, 0); ZCX.clearRect(0, 0, z.w, z.h);
  z.draw(ZCX);
  var r = box.getBoundingClientRect();
  ZCV.style.left = clamp(r.left + r.width / 2 - W / 2, 8, Math.max(8, window.innerWidth - W - 8)) + 'px';
  ZCV.style.top = clamp(r.top + r.height / 2 - H / 2, 8, Math.max(8, window.innerHeight - H - 8)) + 'px';
  ZOV.classList.remove('hidden');
}
function zoomHide() { if (ZOV) ZOV.classList.add('hidden'); }
function regZoom(box) {
  if (!box || box._zreg) return; box._zreg = 1;
  box.classList.add('zoomable');
  box.addEventListener('mouseenter', function () { zoomShow(box); });
  box.addEventListener('mouseleave', function () { zoomHide(); });
  box.addEventListener('click', function (e) { e.stopPropagation(); zoomShow(box); });
}

/* ---- どの瞬間をコマにするか ---- */
function m3SnapList(sec, tr) {
  var P = tr.pts, tEnd = tr.tEnd, ev = tr.ev;
  var tc = 0; for (var i = 0; i < P.length; i++) if (P[i].kind === 'circle') { tc = P[i].t; break; }
  var tMaxAng = 0, am = -1; P.forEach(function (p) { if (p.kind === 'circle' && Math.abs(p.ang) > am) { am = Math.abs(p.ang); tMaxAng = p.t; } });
  var tLow = 0; if (sec === 3) { var lo = 1e9; P.forEach(function (p) { if (p.kind === 'circle' && p.t < (ev ? ev.t : tEnd) && p.y < lo) { lo = p.y; tLow = p.t; } }); }
  var after = function () { return ev ? Math.min(tEnd, ev.t + Math.max(0.12, (tEnd - ev.t) * 0.55)) : tEnd; };
  if (sec === 4 || sec === 5) {                                  /* モード4：最高点まで達するか */
    var tTop = 0, best = 9; P.forEach(function (p) { if (p.kind === 'circle' && Math.abs(p.ang - Math.PI) < best) { best = Math.abs(p.ang - Math.PI); tTop = p.t; } });
    var t0 = sec === 4 ? tc : 0, first = sec === 4 ? { label: '床を等速で進む', t: tc * 0.45 } : { label: '最下点で右へ打ち出す', t: 0.02 };
    if (ev) return [first, { label: sec === 4 ? '面を上る' : '糸を張ったまま上る', t: t0 + (ev.t - t0) * 0.5 },
      { label: sec === 4 ? '離れる瞬間（N = 0）' : 'たるむ瞬間（S = 0）', t: ev.t, ev: true }, { label: sec === 4 ? '離れた後' : 'たるんだ後', t: after() }];
    if (tr.done === 'loop') return [first, { label: '右側を上る', t: t0 + (tTop - t0) * 0.5 }, { label: '最高点を通る', t: tTop },
      { label: sec === 4 ? '1 周して出ていく' : '1 周する', t: Math.min(tEnd, tEnd - 0.02) }];
    return [first, { label: '右側を上る', t: t0 + (tMaxAng - t0) * 0.55 }, { label: '一番高い所', t: tMaxAng }, { label: sec === 4 ? '引き返して床へ' : '戻っていく', t: Math.min(tEnd, tMaxAng + (tMaxAng - t0) * 0.8) }];
  }
  if (sec === 1) {
    if (ev) return [{ label: '床を等速で進む', t: tc * 0.45 }, { label: '円筒面を上る', t: tc + (ev.t - tc) * 0.5 },
      { label: ev.kind === 'top' ? '最高点から飛び出す' : '離れる瞬間', t: ev.t, ev: true }, { label: ev.kind === 'top' ? '飛び出した後' : '離れた後', t: after() }];
    return [{ label: '床を等速で進む', t: tc * 0.45 }, { label: '円筒面を上る', t: tc + (tMaxAng - tc) * 0.55 },
      { label: '一番高い所', t: tMaxAng }, { label: '引き返して床へ', t: Math.min(tEnd, tEnd - 0.05) }];
  }
  if (sec === 2) return [{ label: '最高点から右へ', t: Math.min(0.03, ev.t * 0.1) }, { label: '面にそって滑りおりる', t: ev.t * 0.55 },
    { label: '離れる瞬間', t: ev.t, ev: true }, { label: '離れた後', t: after() }];
  if (ev) return [{ label: '下向きに打ち出す', t: 0.02 }, { label: '最下点を通る', t: tLow },
    { label: 'たるむ瞬間', t: ev.t, ev: true }, { label: 'たるんだ後', t: after() }];
  /* たるまない：1 周する */
  var tTop = 0, hi = -1e9; P.forEach(function (p) { if (p.kind === 'circle' && p.t > tLow && p.y > hi) { hi = p.y; tTop = p.t; } });
  if (hi < M3.R * 0.5) {                                          /* v0 = 0：振り子のように往復する */
    return [{ label: '静かに放す', t: 0.02 }, { label: '最下点を通る', t: tLow }, { label: '反対側で止まる', t: tTop }, { label: '戻っていく', t: Math.min(tEnd, tTop + (tTop - tLow) * 0.6) }];
  }
  return [{ label: '下向きに打ち出す', t: 0.02 }, { label: '最下点を通る', t: tLow }, { label: '最高点（たるまない）', t: tTop },
    { label: 'もとの高さに戻る', t: Math.min(tEnd, tTop + (tTop - tLow) * 0.5) }];
}

/* ---- 左の列のいちばん下に箱をつくる ---- */
function m3BuildSnaps(s) {
  var box = el('div', 'stagebox m3snaps');
  box.innerHTML = '<p class="stagetitle">コマ送りで見ると<span class="zhint">🔍 マウスを重ねると拡大</span></p>';
  s.snapCv = el('canvas'); box.appendChild(s.snapCv);
  s.L.appendChild(box); s.snapBox = box; s.snapImgs = [];
  regZoom(box);
}
var M3SNAP = { pw: 280, k: 3 };                                     /* コマ 1 つを描く大きさ（論理の幅）と解像度の倍率 */
function m3DrawSnaps(s) {
  if (!s.snapCv || !s.snapBox) return;
  var BW = Math.floor(s.snapBox.clientWidth - 8); if (BW < 120) return;
  var tr = m3Tr(s), key = BW + '|' + s.v.v0;
  if (s._snapKey === key) return; s._snapKey = key;
  var list = m3SnapList(s.def.sec, tr), n = list.length;
  var cols = BW < 470 ? 2 : n, rows = Math.ceil(n / cols);
  var bx = M3SNAPBOX[s.def.sec], pw0 = M3SNAP.pw, ph0 = Math.round((pw0 - 12) * (bx.y1 - bx.y0) / (bx.x1 - bx.x0) + 14);   /* 小球のまわりの範囲の縦横の比 */
  var keep = { t: s.t, rot: s.rot, trail: s.trail, at: s.autoTrail, hits: s.hits, cw: CVW, ch: CVH, id: CVID };
  s.snapImgs = list.map(function (sn) {
    var cv = document.createElement('canvas'), K = M3SNAP.k;
    cv.width = pw0 * K; cv.height = ph0 * K;
    var ctx = cv.getContext('2d'); ctx.setTransform(K, 0, 0, K, 0, 0);
    CVW = pw0; CVH = ph0; CVID = ''; _fArrows.length = 0;
    s.t = clamp(sn.t, 0, tr.tEnd); s.rot = false; s._snap = true; s._snapEv = !!sn.ev;
    try { drawM3(s, ctx, pw0, ph0); } catch (e) { /* 描けないコマは空白 */ }
    s._snap = false; s._snapEv = false;
    return { cv: cv, label: sn.label, ev: !!sn.ev };
  });
  s.t = keep.t; s.rot = keep.rot; s.trail = keep.trail; s.autoTrail = keep.at; s.hits = keep.hits; CVW = keep.cw; CVH = keep.ch; CVID = keep.id;
  var pw = BW / cols, ph = pw * ph0 / pw0, TH = 20, H = rows * (ph + TH);
  var paint = function (ctx) {
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, BW, H);
    s.snapImgs.forEach(function (im, i) {
      var cx = (i % cols) * pw, cy = Math.floor(i / cols) * (ph + TH);
      ctx.drawImage(im.cv, cx + 2, cy + TH, pw - 4, ph - 2);
      ctx.save(); var fz = 12, tx = (i + 1) + '. ' + im.label; ctx.font = '700 ' + fz + 'px ' + FONT; while (fz > 8 && ctx.measureText(tx).width > pw - 8) { fz -= 0.5; ctx.font = '700 ' + fz + 'px ' + FONT; } ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillStyle = im.ev ? '#b2560c' : '#31465e'; ctx.fillText(tx, cx + pw / 2, cy + 11); ctx.restore();
      if (i % cols) { ctx.save(); ctx.strokeStyle = '#e6eaef'; ctx.beginPath(); ctx.moveTo(cx, cy + 4); ctx.lineTo(cx, cy + TH + ph - 4); ctx.stroke(); ctx.restore(); }
      if (i % cols < cols - 1 && i < n - 1) {                       /* コマの間に小さな「→」 */
        ctx.save(); ctx.fillStyle = '#9aa5b1'; var ax = cx + pw, ay = cy + TH + ph / 2; ctx.beginPath(); ctx.moveTo(ax + 4, ay); ctx.lineTo(ax - 4, ay - 5); ctx.lineTo(ax - 4, ay + 5); ctx.closePath(); ctx.fill(); ctx.restore();
      }
    });
  };
  var dpr = Math.min(2, Math.max(1, window.devicePixelRatio || 1)), cv = s.snapCv;
  cv.width = Math.round(BW * dpr); cv.height = Math.round(H * dpr); cv.style.width = BW + 'px'; cv.style.height = H + 'px';
  var c2 = cv.getContext('2d'); c2.setTransform(dpr, 0, 0, dpr, 0, 0); paint(c2);
  s.snapBox._z = { w: BW, h: H, draw: paint };
}
