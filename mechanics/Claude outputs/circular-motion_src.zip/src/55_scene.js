/* =========================================================================
   55_scene.js … モード2・3で使う「斜め上から見た 3 次元の図」の共通部品
   ・縮尺は固定（回転軸のまわりの円柱 {R, z0, z1} を全部の向きで入れて外接矩形をとる → 回しても伸び縮みしない）
   ・非慣性系（一緒に回る観測者から見る）は「絵全体を鉛直軸のまわりに −φ 回す」だけ（観測者の描き方ルール）。
     物理量は同じで、見る向きだけが変わる。重力は「ほんとうの下」なので傾かない（鉛直軸のまわりの回転なので）。
   ========================================================================= */
'use strict';
/* 物理の (x, y)（上から見て左回りが正）と高さ z → 世界の座標（mkProj 用：z が上・y は手前向き） */
function W3(x, y, z) { return [x, -y, z || 0]; }

/* 図の準備。cyl＝[{R, z0, z1}]（回転軸のまわりの円柱。これが全部入るように縮尺を決める）
   frame＝絵全体を回す角［rad］（非慣性系のとき −φ）。戻り値の P(q) は世界座標 → 画面 */
function scene3d(s, W, H, cyl, frame, mg) {
  mg = mg || { t: 46, b: 30, x: 10 };
  var cam = s.cam, pj0 = mkProj(cam.az, cam.el, 1, 0, 0), bx0 = 1e9, bx1 = -1e9, by0 = 1e9, by1 = -1e9;
  cyl.forEach(function (c) {
    for (var k = 0; k < 24; k++) { var a = TAU * k / 24; [c.z0, c.z1].forEach(function (z) {
      var q = pj0.p([c.R * Math.cos(a), c.R * Math.sin(a), z]);
      bx0 = Math.min(bx0, q.x); bx1 = Math.max(bx1, q.x); by0 = Math.min(by0, q.y); by1 = Math.max(by1, q.y); }); }
  });
  var S = Math.min((W - 2 * mg.x) / (bx1 - bx0), (H - mg.t - mg.b) / (by1 - by0));
  var cx = W / 2 - S * (bx0 + bx1) / 2, cy = mg.t + (H - mg.t - mg.b) / 2 - S * (by0 + by1) / 2;
  /* 世界の y は物理の −y なので、物理で frame 回す ＝ 世界で −frame 回す */
  var pj = mkProj(cam.az, cam.el, S, cx, cy), cf = Math.cos(-(frame || 0)), sf = Math.sin(-(frame || 0));
  var rot = function (q) { return [q[0] * cf - q[1] * sf, q[0] * sf + q[1] * cf, q[2]]; };
  var sc = {
    S: S, el: cam.el, top: cam.el > 75, side: cam.el < 8,
    P: function (q) { return pj.p(rot(q)); },
    rot: rot,
    dOf: function (n) { var a = pj0.p(rot(n)), o = pj0.p([0, 0, 0]); return a.d - o.d; }
  };
  return sc;
}
/* 物理の座標で点を受けて画面へ */
function PP(sc, x, y, z) { return sc.P(W3(x, y, z)); }

/* 3 次元の矢印：p0（物理の x,y,z）から向き d（物理の dx,dy,dz の単位ベクトル）へ、長さ L［m］ */
function arrow3(ctx, sc, p0, d, L, kind, col, opt) {
  var a = PP(sc, p0[0], p0[1], p0[2]), b = PP(sc, p0[0] + d[0] * L, p0[1] + d[1] * L, p0[2] + d[2] * L);
  if (Math.hypot(b.x - a.x, b.y - a.y) < 3) return null;
  return arrow(ctx, a.x, a.y, b.x, b.y, kind, col, opt);
}
/* 矢印の先の少し外に記号を書く（向きのちがう矢印どうしのラベルが自然に離れる） */
function tipLabel(ctx, ar, text, col, opt) {
  if (!ar) return null;
  opt = opt || {};
  var off = opt.off || 13, side = opt.side || 0;
  var x = ar.x2 + ar.ux * off - ar.uy * side, y = ar.y2 + ar.uy * off + ar.ux * side;
  return sym(ctx, text, x, y, { size: opt.size || 16, color: col, vec: opt.vec !== false, sub: opt.sub, tail: opt.tail });
}

/* 床（外の世界）：方眼。非慣性系ではいっしょに回って見える */
function floor3(ctx, sc, half, z, step) {
  var c = [[-half, -half], [half, -half], [half, half], [-half, half]].map(function (q) { return PP(sc, q[0], q[1], z); });
  ctx.save(); ctx.beginPath(); c.forEach(function (q, i) { i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y); }); ctx.closePath();
  ctx.fillStyle = '#fbfaf6'; ctx.fill(); ctx.clip();
  var n = Math.round(half / step);
  [false, true].forEach(function (big) {                     /* 線は色ごとにまとめて 1 回で描く（軽くするため） */
    ctx.strokeStyle = big ? '#e6dfd2' : '#f1ece3'; ctx.lineWidth = 1; ctx.beginPath();
    for (var i = -n; i <= n; i++) {
      if ((i % 5 === 0) !== big) continue;
      var g = i * step, a1 = PP(sc, g, -half, z), a2 = PP(sc, g, half, z), b1 = PP(sc, -half, g, z), b2 = PP(sc, half, g, z);
      ctx.moveTo(a1.x, a1.y); ctx.lineTo(a2.x, a2.y); ctx.moveTo(b1.x, b1.y); ctx.lineTo(b2.x, b2.y);
    }
    ctx.stroke();
  });
  ctx.restore();
  ctx.save(); ctx.beginPath(); c.forEach(function (q, i) { i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y); }); ctx.closePath();
  ctx.strokeStyle = '#cfc8bb'; ctx.lineWidth = 1; ctx.stroke(); ctx.restore();
}
/* ターンテーブル（円板）。上面の高さ z、半径 R、厚さ th、ang＝円板の回転角（目印の線） */
function turntable3(ctx, sc, R, z, th, ang, opt) {
  opt = opt || {};
  var N = 72, top = [], bot = [];
  for (var i = 0; i < N; i++) { var a = TAU * i / N; top.push(PP(sc, R * Math.cos(a), R * Math.sin(a), z)); bot.push(PP(sc, R * Math.cos(a), R * Math.sin(a), z - th)); }
  /* 軸（下へ） */
  var ax0 = PP(sc, 0, 0, z - th), ax1 = PP(sc, 0, 0, z - th - 0.12);
  ctx.save(); ctx.strokeStyle = '#6f6a62'; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(ax0.x, ax0.y); ctx.lineTo(ax1.x, ax1.y); ctx.stroke(); ctx.restore();
  /* 側面（見えるところだけ：外向きの法線が手前を向く区間） */
  ctx.save(); ctx.fillStyle = '#d9d2c4'; ctx.beginPath();     /* 見える側面はまとめて 1 回で塗る */
  for (var j = 0; j < N; j++) {
    var a2 = TAU * (j + 0.5) / N, n = W3(Math.cos(a2), Math.sin(a2), 0);
    if (sc.dOf(n) <= 0) continue;
    var k = (j + 1) % N;
    ctx.moveTo(top[j].x, top[j].y); ctx.lineTo(top[k].x, top[k].y); ctx.lineTo(bot[k].x, bot[k].y); ctx.lineTo(bot[j].x, bot[j].y); ctx.closePath();
  }
  ctx.fill(); ctx.restore();
  /* 上面 */
  ctx.save(); ctx.beginPath(); top.forEach(function (q, i) { i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y); }); ctx.closePath();
  ctx.fillStyle = opt.fill || '#eee6d6'; ctx.fill(); ctx.strokeStyle = '#8d877c'; ctx.lineWidth = 1.3; ctx.stroke(); ctx.clip();
  /* 目印：90° ずつの 4 本の線だけ（円板といっしょに回る）。同心円や色の点は描かない（2026-10 千葉さん） */
  ctx.strokeStyle = 'rgba(122,110,92,.45)'; ctx.lineWidth = 1.2;
  for (var m = 0; m < 4; m++) { var am = ang + TAU * m / 4 + Math.PI / 4, c0 = PP(sc, 0, 0, z), c1 = PP(sc, R * Math.cos(am), R * Math.sin(am), z);
    ctx.beginPath(); ctx.moveTo(c0.x, c0.y); ctx.lineTo(c1.x, c1.y); ctx.stroke(); }
  ctx.restore();
}
/* 円（破線）：中心 (0,0,z)、半径 R */
function ring3(ctx, sc, R, z, col, dash) {
  ctx.save(); ctx.setLineDash(dash || [5, 5]); ctx.strokeStyle = col || '#8a929c'; ctx.lineWidth = 1.2; ctx.beginPath();
  for (var i = 0; i <= 96; i++) { var a = TAU * i / 96, q = PP(sc, R * Math.cos(a), R * Math.sin(a), z); i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y); }
  ctx.stroke(); ctx.restore();
}
/* 直方体の箱：中心 (x,y)、底面の高さ z、辺 2h、向き ang（物理の角） */
function box3(ctx, sc, x, y, z, h, ang, fill) {
  var ca = Math.cos(ang), sa = Math.sin(ang);
  var c = function (i, j, k) { var lx = i * h, ly = j * h; return [x + lx * ca - ly * sa, y + lx * sa + ly * ca, z + k * 2 * h]; };
  var faces = [
    { q: [c(-1, -1, 1), c(1, -1, 1), c(1, 1, 1), c(-1, 1, 1)], n: [0, 0, 1], f: '#f2c98a' },
    { q: [c(1, -1, 0), c(1, 1, 0), c(1, 1, 1), c(1, -1, 1)], n: [ca, sa, 0], f: '#d9a35a' },
    { q: [c(-1, -1, 0), c(-1, 1, 0), c(-1, 1, 1), c(-1, -1, 1)], n: [-ca, -sa, 0], f: '#d9a35a' },
    { q: [c(-1, 1, 0), c(1, 1, 0), c(1, 1, 1), c(-1, 1, 1)], n: [-sa, ca, 0], f: '#e3b471' },
    { q: [c(-1, -1, 0), c(1, -1, 0), c(1, -1, 1), c(-1, -1, 1)], n: [sa, -ca, 0], f: '#e3b471' }
  ];
  faces.forEach(function (fc) {
    if (sc.dOf(W3(fc.n[0], fc.n[1], fc.n[2])) <= 1e-6) return;
    var pts = fc.q.map(function (q) { return PP(sc, q[0], q[1], q[2]); });
    ctx.save(); ctx.beginPath(); pts.forEach(function (q, i) { i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y); }); ctx.closePath();
    ctx.fillStyle = fill || fc.f; ctx.fill(); ctx.strokeStyle = '#6b4a1f'; ctx.lineWidth = 1.1; ctx.stroke(); ctx.restore();
  });
}
/* 3 次元の棒人間：足もと foot（物理の座標）、背の高さ h［m］ */
function observer3(ctx, sc, foot, h, name, active, lab) {
  var a = PP(sc, foot[0], foot[1], foot[2]), b = PP(sc, foot[0], foot[1], foot[2] + h);
  var dx = b.x - a.x, dy = b.y - a.y, L = Math.hypot(dx, dy);
  var col = active ? COL.vel : '#9aa3ac';
  if (L < 12) {                                              /* 真上から見ると人は「頭のてっぺん」の丸 */
    ctx.save(); if (!active) ctx.globalAlpha *= OBS_DIM;
    ctx.strokeStyle = col; ctx.lineWidth = active ? 2.4 : 1.7; ctx.beginPath(); ctx.arc(a.x, a.y, 7, 0, TAU); ctx.stroke();
    ctx.beginPath(); ctx.arc(a.x, a.y, 2.5, 0, TAU); ctx.fillStyle = col; ctx.fill();
    if (name) label(ctx, name + (active ? '（いまの視点）' : ''), a.x + (lab && lab.dx || 0), a.y + 16, { size: active ? 11 : 10.5, bold: !!active, color: col });
    ctx.restore();
    return { x: a.x, y: a.y, r: 7 };
  }
  return observer(ctx, a.x, a.y, dx / L, dy / L, name, active, L, lab);
}
/* 一緒に回る観測者の札（非慣性系のときに図の上に出す） */
function frameBanner(ctx, W, rot) {
  if (!rot) return;
  label(ctx, '一緒に回る観測者から見ると、物体は止まって見える → 力のつり合い', W / 2, 62, { size: 12, bold: true, color: COL.cent });
}
