/* =========================================================================
   60_mode2.js … モード2「等速円運動と力」
   各セクションに「外（慣性系）から見る」「一緒に円運動する観測者（非慣性系）から見る」の切りかえ。
   ・非慣性系は絵全体を −φ 回す（55_scene.js）。遠心力（濃いグレーの破線）は非慣性系だけに描く。慣性系には絶対に描かない。
   ・図のすぐ下の式の箱には、切りかえに関係なく慣性系の式と非慣性系の式を 2 つ並べる（いまの視点のほうを強調）。
   ・式には必ず「運動方程式」「力のつり合いの式」の札をつける（色はページ全体で統一：.t-eom 赤／.t-bal 緑）。
   ・回転の角 φ = ωt + ph。量を変えても時刻は戻さず、角が飛ばないように ph を変える。
   ・いまの視点の観測者には吹き出し（セリフ）。すべった／糸が切れたときは物体の近くにも吹き出し。
   ========================================================================= */
'use strict';
var M2SC = {};                                   /* 矢印の縮尺［m / N］など（セクションごと） */

/* ---------- 共通 ---------- */
function m2Ang(s) { return s.v.w * s.t + (s.ph || 0); }
/* 式の札（運動方程式／力のつり合いの式） */
function eqTag(kind) { return kind ? '<span class="eqtag ' + kind + '">' + (kind === 'eom' ? '運動方程式' : '力のつり合いの式') + '</span>' : ''; }
/* 右の列の式（札＋式） */
/* 向心力の吹き出しは、式の真下・右よせに置き、しっぽを上（下線の向き）へ（2026-10-05 千葉さん） */
function eqRow(kind, t, cf, nm) { var m = '<span class="qeqm">' + tex(cf ? cfU(t, cf) : t, true) + '</span>'; return '<div class="qeqrow">' + eqTag(kind) + (cf ? '<span class="cfwrap">' + m + cfBub(cf, nm) + '</span>' : m) + '</div>'; }
/* 慣性系の運動方程式で「向心力」にあたる項に赤い下線を引き、吹き出しで「向心力は ○○」と書く（2026-10-05 千葉さん） */
function cfU(t, cf) { var i = t.lastIndexOf(cf); return i < 0 ? t : t.slice(0, i) + '\\textcolor{#d1352b}{\\underline{\\textcolor{#1b1f24}{' + cf + '}}}' + t.slice(i + cf.length); }
function cfBub(cf, nm) { return '<span class="cfbub"><b>向心力</b>は ' + tex(cf) + (nm ? '<small>（' + nm + '）</small>' : '') + '</span>'; }
/* 吹き出しのしっぽが、下線を引いた項（向心力＝右辺）の真下をさすように、吹き出しの位置としっぽの位置を合わせる。
   大きさが決まったとき（画面に出たとき・幅が変わったとき）に ResizeObserver で合わせ直す */
var CF_RO = (typeof ResizeObserver !== 'undefined') ? new ResizeObserver(function (es) { es.forEach(function (e) { cfAimOne(e.target); }); }) : null;
function cfAimOne(w) {
  var ul = w.querySelector('.katex .underline'), bub = w.querySelector('.cfbub');
  if (!ul || !bub) return;
  var rw = w.getBoundingClientRect(), ru = ul.getBoundingClientRect(); if (rw.width < 2 || ru.width < 2) return;
  var bw = bub.offsetWidth, x = ru.left + ru.width / 2 - rw.left;                  /* しっぽの先の x（cfwrap の左はしから） */
  var left = clamp(x - bw * 0.5, 0, Math.max(0, rw.width - bw));
  bub.style.marginLeft = left.toFixed(1) + 'px';
  bub.style.setProperty('--tx', clamp(x - left, 12, bw - 12).toFixed(1) + 'px');
}
/* 式の箱は何度も書きかえるので、ページから外れた吹き出しは見張りをやめる（見張りが増え続けて重くなっていた。2026-10-06） */
var CF_LIST = [];
function cfAim(root) {
  if (!root) return;
  if (CF_RO) CF_LIST = CF_LIST.filter(function (w) { if (w.isConnected) return true; CF_RO.unobserve(w); return false; });
  root.querySelectorAll('.cfwrap').forEach(function (w) { cfAimOne(w); if (CF_RO && !w._ro) { w._ro = 1; CF_RO.observe(w); CF_LIST.push(w); } });
}
var T_EOM = '<span class="t-eom">運動方程式</span>', T_BAL = '<span class="t-bal">力のつり合いの式</span>';

function m2Base(o) {
  var d = Object.assign({
    mode: 'mode2', belowCanvas: true, strobe: false,             /* モード2・3 は「1 秒ごとのストロボ」なし */
    views: [{ label: '斜め上から', az: -24, el: 26 }, { label: '真上から', az: 0, el: 90 }, { label: '真横から', az: 0, el: 0 }], view0: 0,
    height: function (s, w) { return Math.round(clamp(w * 0.74, 320, 500)); },
    tEnd: function () { return 30; }
  }, o);
  var init0 = d.init;
  d.init = function (s) {
    if (s.rot === undefined) s.rot = !!modeState(d.mode).rot;
    if (d.views && (d.view0 || 0) >= 0) { var vw = d.views[d.view0 || 0]; s.cam = { az: vw.az, el: vw.el }; }
    else if (!s.cam) s.cam = { az: -24, el: 20 };
    s.ph = 0; s.ramp = null; m2RampShow(s);
    if (init0) init0(s);
  };
  var onView0 = d.onView;
  d.onView = function (s, i, user) { var vw = d.views[i]; s.cam = { az: vw.az, el: vw.el }; if (onView0) onView0(s, i, user); };
  if (!o.noDrag) d.drag3d = function (s, dx, dy) {
    var r = s.cv.getBoundingClientRect(), k = s.W / Math.max(1, r.width);
    s.cam.az = ((s.cam.az - dx * k * 0.32) + 540) % 360 - 180;
    s.cam.el = clamp(s.cam.el - dy * k * 0.26, 0, 90);
    (s.vbtns || []).forEach(function (b, j) { var vw = d.views[j]; b.classList.toggle('on', Math.abs(s.cam.az - vw.az) < 0.5 && Math.abs(s.cam.el - vw.el) < 0.5); });
    if (d.onDragView) d.onDragView(s);
  };
  /* 観測者の切りかえ（対のボタン 2 つ）。d.ramp があれば「ω を大きくしていく」を図の左上に */
  d.buttons = [
    { k: 'obsIn', label: '外（慣性系）から見る', cls: 'obs', seg: 'obs', segLabel: 'どの観測者から見るか', onClick: function (s) { m2SetRot(s, false); } },
    { k: 'obsRot', label: '一緒に円運動する観測者（非慣性系）から見る', cls: 'obs rotb', seg: 'obs', onClick: function (s) { m2SetRot(s, true); } }
  ].concat(o.buttons || []);
  if (o.ramp) d.buttons.push({ k: 'ramp', label: '↗ ω を大きくしていく', cls: 'ramp', inCanvas: true, onClick: function (s) { m2StartRamp(s); } });
  /* 量を変えたとき：時刻は戻さず、角 φ = ωt + ph が飛ばないように ph を変える */
  var onVar0 = d.onVar;
  d.onVar = function (s, k, x) { s._wOld = s.v.w; if (onVar0) return onVar0(s, k, x); s.v[k] = x; return true; };
  var onCh0 = d.onChanged;
  /* 量を変えたら最初にもどす（2026-10-04 千葉さん）。2-6 だけは d.keepOnChange で続ける */
  d.onChanged = function (s, k) {
    s.rampNote = null;
    if (!d.keepOnChange) {
      /* ω（と ω を決める量 d.wKeys）を変えたときは最初にもどさず、そのまま変化させる（2026-10-05 千葉さん）。
         ただし、すでに滑った／糸が切れたあと（d.wBroken）は最初にもどす */
      var wKey = k === 'w' || (d.wKeys || []).indexOf(k) >= 0;
      if (!wKey || (d.wBroken && d.wBroken(s))) { if (onCh0) onCh0(s, k); return 'stop'; }
      if (s._wOld !== undefined && Math.abs(s._wOld - s.v.w) > 1e-12) s.ph += (s._wOld - s.v.w) * s.t;   /* 角が飛ばないように */
      if (d.onWKeep) d.onWKeep(s);
      s.t = Math.min(s.t, d.tEnd(s));
      return 'keepT';
    }
    if (s._wOld !== undefined && s.v.w && Math.abs(s._wOld - s.v.w) > 1e-12) s.ph += (s._wOld - s.v.w) * s.t;
    if (onCh0 && onCh0(s, k) === 'reset') { s.t = 0; s.ph = 0; return; }
    s.t = Math.min(s.t, d.tEnd(s));
    return 'keepT';
  };
  var onRs0 = d.onReset;
  d.onReset = d.onRestart = function (s) { s.ph = 0; m2RampShow(s); if (onRs0) onRs0(s); };
  var msg0 = d.msg;                                        /* 「ω を大きくしていく」が届かないときのひとことを優先 */
  if (msg0) d.msg = function (s) { return s.rampNote || msg0(s); };
  d.below = function (s) { m2EqBox(s, d.eqs(s)); };
  d.afterBuild = function (s) { m2SetRot(s, s.rot); };
  /* 「↗ ω を大きくしていく」を押したあと：ボタンの位置（図の左上）に「状態：等速円運動」→「状態：滑り出した」など（2026-10-06 千葉さん） */
  if (o.ramp && o.ramp.state) {
    var draw0 = d.draw;
    d.draw = function (s, ctx, W, H) {
      draw0(s, ctx, W, H);
      if (!s._rampOn) return;
      var st = o.ramp.state(s), circ = st === '等速円運動';
      pill(ctx, '状態：' + st, 10, 10, { size: 12.5, color: circ ? COL.ink : '#9c4e06', border: circ ? 'rgba(20,23,28,.18)' : 'rgba(224,123,24,.6)', bg: circ ? '#ffffff' : '#fdf4e8' });
    };
  }
  return d;
}
/* 「↗ ω を大きくしていく」のボタンをもとにもどす（リセット・最初の設定に戻す・量を変えたとき） */
function m2RampShow(s) { s._rampOn = false; if (s.extra && s.extra.ramp) s.extra.ramp.hidden = false; }
function m2SetRot(s, on) {
  s.rot = on;
  if (typeof syncGlobalRot === 'function' && document.getElementById('btnRot')) { clearTimeout(m2SetRot._t); m2SetRot._t = setTimeout(syncGlobalRot, 0); }   /* 右上の「全て」の表示をそろえる */
  if (s.extra && s.extra.obsIn) { s.extra.obsIn.classList.toggle('on', !on); s.extra.obsRot.classList.toggle('on', on); }
  s.draw(); s.renderRight();
}
/* モードの右上のスイッチ（全セクション） */
function m2SetModeRot(mid, on, quiet) {                        /* quiet：右上の「全て」から呼ぶとき（アドレスは変えない） */
  var ms = modeState(mid); ms.rot = on;
  SIMS.forEach(function (s) { if (s.mode === mid) m2SetRot(s, on); });
  if (ms._segb) { ms._segb[0].classList.toggle('on', !on); ms._segb[1].classList.toggle('on', on); }
  if (typeof m4SyncSegs === 'function') m4SyncSegs();
  if (!quiet && history.replaceState) history.replaceState(null, '', location.pathname + location.search + '#' + mid + (on ? '-rot' : ''));
  if (!quiet && typeof syncGlobalRot === 'function') syncGlobalRot();
}

/* ---------- 「ω を大きくしていく」：ω を少しずつ大きくし、限界の ω₀ に達したら一瞬止めてから、すべり出す／糸が切れる ----------
   d.ramp = { crit(s) → ω₀, fire(s, ω₀)（限界をこえさせる）, sync(s)（ω に連動する量をそろえる）, prep(s)（すべり・切れをもとにもどす）,
              noReach(s) → 届かないときのひとこと }。表示中は操作を受け付けない */
var M2RAMP = { pause: 0.8 };
function m2StartRamp(s) {
  var d = s.def, R = d.ramp; if (s.ramp) return;
  var vw = d.vars.filter(function (q) { return q.k === 'w'; })[0];
  if (R.prep) R.prep(s);
  s.t = 0; s.ph = 0; s.ended = false;
  var wc = R.crit(s);
  if (!(wc > vw.min && wc <= vw.max)) { s.rampNote = R.noReach(s); s.draw(); return; }
  var w0 = vw.min;                                          /* スライダーの最低値から、急に大きくしていく（約 1.6 秒。2026-10-06 千葉さん） */
  s.v.w = w0; if (R.sync) R.sync(s);
  var rate = Math.max(1.0, (wc - w0) / 1.6);
  s.setBusy(true);
  SIMS.forEach(function (o) { if (o !== s && o.playing) { o.playing = false; o.syncPlayLabel(); } });
  s.playing = false;
  s.ramp = { ph: 'up', last: 0, p: 0, wc: wc, rr: 0 };
  s._rampOn = true; s.extra.ramp.hidden = true;            /* 押したあとは、ボタンの位置（左上）に「状態：…」を書く（m2Base の draw） */
  var tick = function (ts) {
    var A = s.ramp; if (!A) return;
    if (s.busy && s.busy.paused) { A.last = ts; requestAnimationFrame(tick); return; }   /* 一時停止中 */
    var dt = A.last ? Math.min(0.05, (ts - A.last) / 1000) : 0; A.last = ts;
    if (A.ph === 'up') {
      var wO = s.v.w;
      s.v.w = Math.min(wc, s.v.w + rate * dt); if (R.sync) R.sync(s);
      s.ph += (wO - s.v.w) * s.t;
      s.t += dt;
      if (s.v.w >= wc - 1e-12) { A.ph = 'pause'; A.p = 0; }
    } else {
      A.p += dt;                                              /* 一瞬止めてから */
      if (A.p >= M2RAMP.pause) {
        var wO2 = s.v.w;
        R.fire(s, wc);
        s.ph += (wO2 - s.v.w) * s.t;
        if (R.after) R.after(s);
        s.ramp = null;
        s.setBusy(false);
        s.lastMsg = null; s.playing = true; s.syncPlayLabel(); startLoop(); s.renderRight();
        return;
      }
    }
    s.draw();
    if (ts - A.rr > 250) { A.rr = ts; s.renderRight(); }
    requestAnimationFrame(tick);
  };
  s.draw(); requestAnimationFrame(tick);
}

/* 式の箱（図のすぐ下）：慣性系と非慣性系を 2 つ並べる。いまの視点のほうを濃く。各行に「運動方程式」「力のつり合いの式」の札 */
function m2EqBox(s, eq) {
  if (!s.below) return;
  var now = performance.now();
  if (s.playing && s._eqT && now - s._eqT < 250) return;     /* 再生中は 1 秒に 4 回まで（式の組み直しは重い） */
  var key = JSON.stringify([eq, s.rot]);
  if (s._eqKey === key) return; s._eqKey = key; s._eqT = now;
  var one = function (q, on, cls) {
    return '<div class="eqcard ' + cls + (on ? ' on' : '') + '"><p class="eqh">' + q.h + (on ? '<span class="now">いまの視点</span>' : '') + '</p>' +
      q.lines.map(function (l) { return '<div class="eql2">' + eqTag(l.tag) + (l.k ? '<span class="eqk">' + l.k + '</span>' : '') + (l.cf ? '<span class="cfwrap">' + tex(cfU(l.t, l.cf)) + cfBub(l.cf, l.cfn) + '</span>' : tex(l.t)) + '</div>'; }).join('') +
      (q.num ? '<p class="eqnum">' + q.num + '</p>' : '') + (m2EqNote(q.note) ? '<p class="eqnote">' + m2EqNote(q.note) + '</p>' : '') + '</div>';
  };
  s.below.innerHTML = mathify('<div class="eqpair">' + one(eq.in, !s.rot, 'in') + one(eq.rot, s.rot, 'rot') + '</div>');
  cfAim(s.below);
}
/* 図の下の式の箱では「慣性系に『遠心力』は存在しない」は書かない（右の列だけに書く。2026-10-05 千葉さん） */
function m2EqNote(n) {
  if (!n) return '';
  var t = n.replace('※ 慣性系に「遠心力」は存在しない', '').replace(/^。/, '').trim();
  return t ? (t.indexOf('※') === 0 ? t : '※ ' + t) : '';
}
function f2(x) { return fmt(x, 2); }
function f3(x) { return fmt(x, 3); }
/* 画面での「上」（物理の z）を使って、物体のすぐ上に速度の矢印をまん中そろえで描く */
function velAbove(ctx, sc, c, v, scale, zOff, s) {
  var sp = Math.hypot(v[0], v[1]); if (sp < 1e-6) return null;
  var u = [v[0] / sp, v[1] / sp, 0], L = sp * scale, rl0 = Math.hypot(c[0], c[1]) || 1, o = [c[0] + c[0] / rl0 * 0.06, c[1] + c[1] / rl0 * 0.06, c[2] + zOff];
  var a = PP(sc, o[0] - u[0] * L / 2, o[1] - u[1] * L / 2, o[2]), b = PP(sc, o[0] + u[0] * L / 2, o[1] + u[1] * L / 2, o[2]);
  if (sc.top) {                                               /* 真上からは高さがつぶれるので、外がわへずらす */
    var rl = Math.hypot(c[0], c[1]) || 1, nx = c[0] / rl * 0.10, ny = c[1] / rl * 0.10;
    a = PP(sc, c[0] + nx - u[0] * L / 2, c[1] + ny - u[1] * L / 2, c[2]); b = PP(sc, c[0] + nx + u[0] * L / 2, c[1] + ny + u[1] * L / 2, c[2]);
  }
  var ar = arrow(ctx, a.x, a.y, b.x, b.y, 'vel');
  var lb = tipLabel(ctx, ar, 'v', COL.vel, { off: 11 });
  if (s && lb) s.addHit('v', lb);
  return ar;
}
/* 回る向き ω（慣性系だけ）：軸のまわりの決まった場所の円弧の矢印 */
function omegaArc3(ctx, sc, R, z, a1, a2) {
  if (sc.top || sc.side) return;                              /* 真上・真横からは円弧がつぶれて読めないので描かない */
  var pts = []; for (var j = 0; j <= 30; j++) { var a = a1 + (a2 - a1) * j / 30; pts.push(PP(sc, R * Math.cos(a), R * Math.sin(a), z)); }
  ctx.save(); ctx.strokeStyle = COL.ink2; ctx.fillStyle = COL.ink2; ctx.lineWidth = 2;
  ctx.beginPath(); pts.slice(0, 27).forEach(function (q, i) { i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y); }); ctx.stroke();
  var e1 = pts[30], e0 = pts[26], ex = e1.x - e0.x, ey = e1.y - e0.y, eL = Math.hypot(ex, ey) || 1; ex /= eL; ey /= eL;
  ctx.beginPath(); ctx.moveTo(e1.x, e1.y); ctx.lineTo(e1.x - ex * 10 - ey * 5, e1.y - ey * 10 + ex * 5); ctx.lineTo(e1.x - ex * 10 + ey * 5, e1.y - ey * 10 - ex * 5); ctx.closePath(); ctx.fill();
  ctx.restore();
  var m = PP(sc, (R + 0.09) * Math.cos((a1 + a2) / 2), (R + 0.09) * Math.sin((a1 + a2) / 2), z);
  sym(ctx, 'ω', m.x, m.y, { size: 17, color: COL.ink2 });
}
/* 遠心力の文字 */
function centLabel(ctx, ar, s) {
  if (!ar) return;
  var x = ar.x2 + ar.ux * 12, y = ar.y2 + ar.uy * 12;
  label(ctx, '遠心力', x + (ar.ux >= 0 ? 16 : -16), y - 10, { size: 12, bold: true, color: COL.cent });
}
/* 外の観測者：ターンテーブルより手前にいれば台のあとに、奥にいれば台の前に描く（台の下にもぐって見えないように）。描いたら頭を返す */
function m2Outer(ctx, sc, foot, h, active, when, zTab) {
  var front = sc.P(W3(foot[0], foot[1], foot[2])).d > sc.P(W3(0, 0, zTab || 0)).d;
  if ((when === 'front') === front) return observer3(ctx, sc, foot, h, '外の観測者', active, { dy: 2 });
  return null;
}
/* いまの視点の観測者のセリフ。ev＝'slip'／'cut' など（できごとがあればそのセリフ） */
var M2SAY = { slip: '滑ったな', cut: '糸が切れたな', off: '面から離れたな', slack: '糸がたるんだな', top: '最高点から飛び出したな' };
function m2Speech(ctx, s, hdIn, hdRot, ev, opt) {
  opt = opt || {};
  var hd = s.rot ? hdRot : hdIn; if (!hd) return;
  var t = ev ? M2SAY[ev] : (s.rot ? (opt.rotSay || '力がつり合っているな') : (opt.inSay || '中心方向に加速しているな'));
  speech(ctx, t, hd);
}
/* 一緒に回る観測者をターンテーブルの上のどこに立たせるか：物体と同じ円の上の、少し前（約 0.35 m はなれる）。
   半径が小さくて近すぎるときは、少し外がわに立つ */
function m2CoPos(ang, rObj, Rtab, tab) {
  var rr = Math.min(Math.max(rObj, 0.26), Rtab - 0.06), da = clamp(0.35 / rr, 0.6, 1.6), a = tab + da;   /* 進む向きの少し前（非慣性系の図では物体の奥に立つ） */
  return [rr * Math.cos(a), rr * Math.sin(a)];
}
/* 小人（物体の上に乗って一緒に回る観測者）。foot＝足もと（物理の座標） */
function m2Rider(ctx, sc, foot, active) { return observer3(ctx, sc, foot, 0.17, '', active); }
/* 右の列の共通の注意 */
function m2FrameNote(rot) {
  return rot ? '<p class="qnote">遠心力は、一緒に回る観測者だけが感じる<b>見かけの力（慣性力）</b>。</p>'
    : '<p class="qnote">外（慣性系）から見ると物体は円運動している（加速度がある）ので' + T_EOM + 'を立てる。<b>慣性系に「遠心力」は存在しない。</b></p>';
}
/* 右の列の「立式」カード（モード2・3 で同じ形）：いまの視点のぶんだけ、方向ごとに 1 行（方向の名前・札・式）。
   o = { lead:{in, rot}, rows:[{ dir:'水平方向（中心向き）', hl:'h', in:[札, 式], rot:[札, 式] }], note:{in, rot} } */
function m2Setup(s, o) {
  var k = s.rot ? 'rot' : 'in', hl = s.hl || '';
  return '<div class="qcard setup ' + k + '"><p class="qt">' + (s.rot ? '一緒に回る観測者（非慣性系）から見ると' : '外（慣性系）から見ると') + '<span class="now">いまの視点</span></p>' +
    '<p>' + o.lead[k] + '</p><div class="dirs">' +
    o.rows.map(function (r) { var q = r[k]; return '<div class="dirrow' + (r.hl && hl === r.hl ? ' hl' : '') + '"><span class="dirlab">' + r.dir + '</span>' + eqRow(q[0], q[1], q[2], q[3]) + '</div>'; }).join('') +
    '</div>' + ((o.note && o.note[k]) || m2FrameNote(s.rot)) + '</div>';
}
/* 重力と垂直抗力は左右に少しずらす（矢印が重ならないように）。ut＝画面で横に見える向き（接線） */
function m2GN(ctx, sc, c3, bot, ut, mg, fs, off) {
  var o = off || 0.018;
  var ag = arrow3(ctx, sc, [c3[0] - ut[0] * o, c3[1] - ut[1] * o, c3[2]], [0, 0, -1], mg * fs, 'force', COL.force);
  if (ag) label(ctx, 'mg', ag.x2, ag.y2 + 11, { size: 13, bold: true, color: COL.force });
  var an = arrow3(ctx, sc, [bot[0] + ut[0] * o, bot[1] + ut[1] * o, bot[2]], [0, 0, 1], mg * fs, 'force', COL.norm);
  if (an) label(ctx, 'N', an.x2 + 10, an.y2 - 4, { size: 13, bold: true, color: COL.norm });
}

/* ===================== セクション1 ターンテーブル（摩擦あり） ===================== */
M2SC.s1 = { F: 0.22, v: 0.22, a: 0.045 };
function m2s1Slip(s) { return s.v.w > M2.s1.wSlip(s.v.r, s.v.mu) + 1e-9; }
/* いまの箱の状態。s.slip0 = { t0, th0 }（すべり出した時刻と角）。すべる道すじは slipPath（角 0 から始まる）を th0 だけ回したもの */
function m2s1State(s) {
  var C = M2.s1, w = s.v.w, r = s.v.r, mu = s.v.mu, tab = m2Ang(s);
  if (!s.slip0) return { slip: false, th: tab, x: r * Math.cos(tab), y: r * Math.sin(tab), vx: -r * w * Math.sin(tab), vy: r * w * Math.cos(tab), rr: r, tab: tab };
  var P = C.slipPath(w, r, mu), tt = clamp(s.t - s.slip0.t0, 0, P.tOff);
  var lo = 0, hi = P.length - 1;
  while (hi - lo > 1) { var md = (lo + hi) >> 1; if (P[md].t <= tt) lo = md; else hi = md; }
  var a = P[lo], b = P[hi], u = (b.t > a.t) ? (tt - a.t) / (b.t - a.t) : 0;
  var c = Math.cos(s.slip0.th0), sn = Math.sin(s.slip0.th0), R2 = function (x, y) { return [x * c - y * sn, x * sn + y * c]; };
  var p = R2(a.x + (b.x - a.x) * u, a.y + (b.y - a.y) * u), v = R2(a.ux + (b.ux - a.ux) * u, a.uy + (b.uy - a.uy) * u);
  var q = { slip: true, x: p[0], y: p[1], vx: v[0], vy: v[1], tab: tab, tt: tt, z: (a.z || 0) + ((b.z || 0) - (a.z || 0)) * u, fly: !!b.fly };
  q.rr = Math.hypot(q.x, q.y); q.th = Math.atan2(q.y, q.x);
  q.relx = q.vx + w * q.y; q.rely = q.vy - w * q.x;
  return q;
}
DEFS.m2s1 = m2Base({
  id: 'm2s1', num: 1, title: 'ターンテーブル（摩擦あり）',
  varCols: [['w', 'r'], ['mu']],             /* スライダーの並びは 2-3 と同じ（2026-10-06 千葉さん） */
  desc: '粗いターンテーブルの上に箱（質量 $m=0.20$ kg）をのせる。向心力は<b>静止摩擦力</b>。$\\omega$ を大きくしていくと滑り出す。滑り出すときの角速度を $\\omega_0$ とよぶ（スライダーの目印）。<span class="todo">図の左上の「↗ ω を大きくしていく」を押して、滑り出すようすを見よう。</span>',
  vars: [
    { k: 'w', label: '角速度 $\\omega$', aria: '角速度', min: 0.5, max: 5.0, step: 0.05, def: 3.0, dec: 2, unit: 'rad/s',
      mark: function (s) { return { x: M2.s1.wSlip(s.v.r, s.v.mu), label: '$\\omega_0$' }; } },
    { k: 'r', label: '半径 $r$', aria: '半径', min: 0.10, max: 0.50, step: 0.01, def: 0.30, dec: 2, unit: 'm' },
    { k: 'mu', label: '静止摩擦係数 $\\mu$', aria: '静止摩擦係数', min: 0.10, max: 0.80, step: 0.05, def: 0.40, dec: 2, unit: '' }
  ],
  init: function (s) { s.slip0 = null; },
  wBroken: function (s) { return !!s.slip0 && s.t > 0; },
  onWKeep: function (s) { if (!s.slip0 && m2s1Slip(s)) s.slip0 = { t0: s.t, th0: m2Ang(s) }; },   /* ω₀ をこえたら、その場ですべり出す */
  /* 量を変えると最初にもどる（onReset）。ω₀ をこえていれば、最初からすべり出す */
  onReset: function (s) { s.slip0 = m2s1Slip(s) ? { t0: 0, th0: 0 } : null; },
  ramp: {
    crit: function (s) { return M2.s1.wSlip(s.v.r, s.v.mu); },
    prep: function (s) { s.slip0 = null; },
    fire: function (s, wc) { s.v.w = Math.min(5.0, wc * 1.02); },              /* ω₀ をほんの少しこえる */
    after: function (s) { s.slip0 = { t0: s.t, th0: m2Ang(s) }; },
    state: function (s) { return s.slip0 ? '滑り出した' : '等速円運動'; },
    noReach: function (s) { return 'この $r$・$\\mu$ では、滑り出す $\\omega_0 = ' + f2(M2.s1.wSlip(s.v.r, s.v.mu)) + '$ rad/s がスライダーの範囲（5.0 rad/s まで）を超えている。$r$ を大きくするか $\\mu$ を小さくしよう。'; }
  },
  tEnd: function (s) { return s.slip0 ? s.slip0.t0 + M2.s1.slipPath(s.v.w, s.v.r, s.v.mu).tOff : 30; },
  msg: function (s) {
    var ws = M2.s1.wSlip(s.v.r, s.v.mu);
    if (s.ramp) return s.ramp.ph === 'pause' ? '$\\omega$ が $\\omega_0 = ' + f2(ws) + '$ rad/s に達した！　必要な向心力 $mr\\omega^2$ が最大摩擦力 $\\mu mg$ と等しくなった。' :
      '$\\omega$ を少しずつ大きくしている（$\\omega_0 = ' + f2(ws) + '$ rad/s で、必要な向心力が最大摩擦力に達する）。この間は「❚❚ 一時停止」の他は操作できません。';
    if (s.slip0) return s.ended ? '滑って、ターンテーブルの外へとび出し、床に落ちた。' :
      '<b>滑り出した！</b>　必要な向心力 $mr\\omega^2$ が、最大摩擦力 $\\mu mg$ を超えた（$\\omega > \\omega_0 = \\sqrt{\\mu g/r}=' + f2(ws) + '$ rad/s）。';
    return '箱は静止摩擦力 $f$ で、ターンテーブルと一緒に回っている（向心力 $=f$）。左上の「↗ ω を大きくしていく」を押してみよう。';
  },
  eqs: function (s) {
    var m = M2.s1.m, w = s.v.w, r = s.v.r, mu = s.v.mu;
    var need = m * r * w * w, mg = m * G;
    if (s.slip0) return {
      in: { h: '【慣性系】滑っている', lines: [{ k: '水平方向（中心向き）：', t: 'mr\\omega^2 > \\mu mg' }], num: '必要な向心力 ' + f3(need) + ' N ＞ 最大摩擦力 ' + f3(mu * mg) + ' N', note: '摩擦力だけでは円運動を続けられない' },
      rot: { h: '【非慣性系】滑り出す', lines: [{ k: '水平方向（中心向き）：', t: 'mr\\omega^2 > \\mu mg' }], num: '遠心力 ' + f3(need) + ' N ＞ 最大摩擦力 ' + f3(mu * mg) + ' N', note: 'つり合わないので、外へ滑っていく' } };
    return {
      in: { h: '【慣性系】円運動している', lines: [{ tag: 'eom', k: '水平方向（中心向き）：', t: 'mr\\omega^2 = f', cf: 'f', cfn: '静止摩擦力' }, { tag: 'bal', k: '鉛直方向：', t: '0 = N - mg' }],
        num: 'いま：' + f3(need) + ' N ＝ ' + f3(need) + ' N（静止摩擦力 f）', note: '※ 慣性系に「遠心力」は存在しない' },
      rot: { h: '【非慣性系】止まって見える', lines: [{ tag: 'bal', k: '水平方向（中心向き）：', t: 'f - \\underbrace{mr\\omega^2}_{\\text{遠心力}} = 0' }, { tag: 'bal', k: '鉛直方向：', t: 'N - mg = 0' }],
        num: 'いま：' + f3(need) + ' − ' + f3(need) + ' ＝ 0', note: '※ 遠心力は一緒に回る観測者だけが感じる見かけの力' } };
  },
  draw: function (s, ctx, W, H) { drawM2s1(s, ctx, W, H); },
  right: function (s, R) { rightM2s1(s, R); }
});
function drawM2s1(s, ctx, W, H) {
  var C = M2.s1, w = s.v.w, r = s.v.r, mu = s.v.mu, st = m2s1State(s), m = C.m, h = 0.06;
  var tab = st.tab, frame = s.rot ? -tab : 0, showF = s.ms.showF;
  var sc = scene3d(s, W, H, [{ R: 0.86, z0: -0.20, z1: 0.50 }], frame);
  floor3(ctx, sc, 0.84, -0.18, 0.1);
  var hdIn = m2Outer(ctx, sc, [0.18, -0.76, -0.18], 0.40, !s.rot, 'back');
  turntable3(ctx, sc, C.R, 0, 0.04, tab);
  hdIn = m2Outer(ctx, sc, [0.18, -0.76, -0.18], 0.40, !s.rot, 'front') || hdIn;
  if (!s.rot && !sc.top) omegaArc3(ctx, sc, C.R + 0.12, 0, 1.9, 2.7);
  /* すべったあとの道すじ。慣性系：th0 だけ回した道すじ／非慣性系：ターンテーブルの上での道すじ */
  if (st.slip) {
    var P = C.slipPath(w, r, mu), th0 = s.slip0.th0;
    ctx.save(); ctx.setLineDash([5, 4]); ctx.strokeStyle = 'rgba(22,99,181,.7)'; ctx.lineWidth = 1.5; ctx.beginPath();
    var first = true;
    P.forEach(function (q) { if (q.t > st.tt) return; var ang = s.rot ? tab - w * q.t : th0;
      var cx = q.x * Math.cos(ang) - q.y * Math.sin(ang), cy = q.x * Math.sin(ang) + q.y * Math.cos(ang);
      var pp = PP(sc, cx, cy, 0.002); if (first) { ctx.moveTo(pp.x, pp.y); first = false; } else ctx.lineTo(pp.x, pp.y); });
    ctx.stroke(); ctx.restore();
  } else ring3(ctx, sc, r, 0.003, '#8a929c');
  var cx = st.x, cy = st.y, rr = st.rr;
  s.autoTrail = !!st.slip || !!s.ramp;                       /* 滑るときと ω を大きくしていくときは軌跡を自動で描く */
  trailStep(ctx, s, function (x, y, z) { return PP(sc, x, y, z); }, [cx, cy, (st.z || 0) + 0.004], -tab);   /* 軌跡（少し前までの道すじ） */
  var bz = st.z || 0;                                         /* 台からとび出したあとは落ちていく */
  box3(ctx, sc, cx, cy, bz, h, st.th);
  var op = m2CoPos(0, r, C.R, tab);                          /* 一緒に回る観測者：箱と同じがわ（少し前）に立つ */
  var hdRot = observer3(ctx, sc, [op[0], op[1], 0], 0.30, '一緒に回る観測者', s.rot, { dy: 2 });
  var ur = [cx / rr, cy / rr, 0], ut = [-ur[1], ur[0], 0], c3 = [cx, cy, bz + h];
  if (showF) {
    var fs = M2SC.s1.F;
    if (st.fly) { var agf = arrow3(ctx, sc, c3, [0, 0, -1], m * G * fs, 'force', COL.force); if (agf) label(ctx, 'mg', agf.x2, agf.y2 + 11, { size: 13, bold: true, color: COL.force }); }
    else m2GN(ctx, sc, c3, [cx, cy, 0], ut, m * G, fs, 0.02);
    /* 摩擦力：作用点は N と同じ（箱の底のまん中）。見やすいように少しだけずらす。すべっていなければ中心向き、すべっていれば相対速度と逆向き */
    var fd, fmag;
    if (!st.slip) { fd = [-ur[0], -ur[1], 0]; fmag = m * r * w * w; }
    else { var rl = Math.hypot(st.relx, st.rely) || 1; fd = [-st.relx / rl, -st.rely / rl, 0]; if (Math.hypot(st.relx, st.rely) < 1e-6) fd = [-ur[0], -ur[1], 0]; fmag = mu * m * G; }
    var af = st.fly ? null : arrow3(ctx, sc, [cx - ut[0] * 0.035, cy - ut[1] * 0.035, 0.004], fd, fmag * fs, 'force', COL.fric);
    if (af) { var lf = tipLabel(ctx, af, 'f', COL.fric, { off: 12, vec: false }); s.addHit('f', lf); }
    if (s.rot && !st.fly) {                                 /* 遠心力（見かけの力）：作用点は物体の中心 */
      var ac = arrow3(ctx, sc, c3, ur, m * rr * w * w * fs, 'fict', COL.cent);
      centLabel(ctx, ac, s);
    }
  }
  if (!s.rot) {
    if (!st.slip) {
      var aa0 = [cx - ut[0] * 0.07, cy - ut[1] * 0.07, h];   /* 加速度：中心向き（力の矢印と重ならないよう、うしろへずらす） */
      var aa = arrow3(ctx, sc, aa0, [-ur[0], -ur[1], 0], r * w * w * M2SC.s1.a, 'acc');
      tipLabel(ctx, aa, 'a', COL.acc, { off: 11 });
    }
    velAbove(ctx, sc, c3, [st.vx, st.vy], M2SC.s1.v, 2 * h + 0.10, s);
  }
  drawEqualTicks(ctx);
  m2Speech(ctx, s, hdIn, hdRot, st.slip ? 'slip' : null);
  if (st.slip && !s.ended) { var bt = PP(sc, cx, cy, 2 * h + 0.02); eventBubble(ctx, 'slip', bt.x, bt.y - (s.rot ? 6 : 34)); }
  else if (s.ramp && s.ramp.ph === 'pause') { var bp = PP(sc, cx, cy, 2 * h + 0.02); bubble(ctx, 'ω₀ に達した…', bp.x, bp.y - 34, { size: 13, bg: '#fff5d6', border: '#d9a545', color: '#8a5000' }); }
}
function rightM2s1(s, R) {
  var m = M2.s1.m, w = s.v.w, r = s.v.r, mu = s.v.mu, ws = M2.s1.wSlip(r, mu), slip = !!s.slip0;
  var h = m2Setup(s, {
    lead: { in: '箱は半径 $r$ の等速円運動をしている。中心向きの加速度 $a=r\\omega^2$ を生んでいるのは、ターンテーブルからの<b>静止摩擦力 $f$</b>。つまり <b>向心力 $F$ の役割をするのは静止摩擦力</b>。',
            rot: '一緒に回る観測者には、箱は止まって見える。中心から外向きに<b>遠心力 $mr\\omega^2$</b> がはたらき、静止摩擦力 $f$ とつり合っている。' },
    rows: [{ dir: '水平方向（中心向き）', in: ['eom', 'mr\\omega^2 = f', 'f', '静止摩擦力'], rot: ['bal', 'f - mr\\omega^2 = 0'] },
           { dir: '鉛直方向', in: ['bal', 'N - mg = 0'], rot: ['bal', 'N - mg = 0'] }] });
  if (slip || (s.ramp && s.ramp.ph === 'pause')) {
    h += '<div class="qcard derive"><p class="qt">滑り出す角速度 $\\omega_0$ の導出</p>' +
      '<p>滑らないための条件は、必要な摩擦力 $f$ が最大摩擦力 $\\mu N$ 以下であること。鉛直方向の' + T_BAL + 'より $N=mg$。</p>' +
      '<div class="qeq">' + tex('f \\le \\mu N \\;\\Longrightarrow\\; mr\\omega^2 \\le \\mu mg', true) + tex('\\omega \\le \\sqrt{\\dfrac{\\mu g}{r}} = \\omega_0', true) + '</div>' +
      '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('\\omega_0 = \\sqrt{\\dfrac{' + f2(mu) + '\\times 9.8}{' + f2(r) + '}} = ' + f2(ws) + '\\ \\text{rad/s}') + '</p>' +
      '<p>$\\omega$ がこの値を超えると<b>滑り出す</b>。$m$ が入っていないので、滑り出す $\\omega_0$ は質量によらない。</p></div>';
  } else {
    h += '<div class="qcard intro"><p class="qt">やってみよう</p><p>図の左上の「<b>↗ ω を大きくしていく</b>」を押すと、$\\omega$ が少しずつ大きくなり、スライダーの $\\omega_0$ の目印に達したところで箱が滑り出す。$r$ や $\\mu$ を変えると、$\\omega_0$ はどう変わるだろう？</p></div>';
  }
  h += '<p class="assume">箱の質量 ' + tex('m = 0.20') + ' kg、' + tex('g = 9.8') + ' m/s²。滑り出したあとの動摩擦係数も ' + tex('\\mu') + ' と同じとした。滑っている間は、他の見かけの力（コリオリの力）もはたらくが、高校の範囲外なので描いていない。</p>';
  R.innerHTML = mathify(h);
}

/* ===================== セクション2 ターンテーブル（摩擦なし）とばね ===================== */
M2SC.s2 = { F: 0.065, v: 0.12, a: 0.012 };
DEFS.m2s2 = m2Base({
  id: 'm2s2', num: 2, title: 'ターンテーブル（摩擦なし）とばね',
  desc: 'なめらかなターンテーブルの中心の柱に、ばね（$k=20$ N/m、自然長 $\\ell=0.30$ m）で小球（$m=0.20$ kg）をつなぐ。向心力は<b>ばねの弾性力</b>。<span class="todo">$\\omega$ を変えて、ばねの伸び $x$ がどう変わるか見よう。</span>',
  varCols: [['w'], ['x']],                   /* スライダーが 2 つなら 1 行に（1-1 と同じ 2 列） */
  vars: [
    { k: 'w', label: '角速度 $\\omega$', aria: '角速度', min: 1.0, max: 8.0, step: 0.05, def: 5.0, dec: 2, unit: 'rad/s' },
    { k: 'x', label: 'ばねの伸び $x$', aria: 'ばねの伸び', min: 0.003, max: 0.533, step: 0.001, def: 0.100, dec: 3, unit: 'm' }
  ],
  wKeys: ['x'],                              /* ばねの伸びを変えると ω が決まる。最初にもどさない */
  init: function (s) { s.v.x = M2.s2.xOf(s.v.w); },
  onVar: function (s, k, x) {
    if (k === 'w') { s.v.w = x; s.v.x = M2.s2.xOf(x); }
    else { s.v.x = x; s.v.w = M2.s2.wOf(x); }
    return true;
  },
  msg: function (s) {
    return 'ばねの弾性力 $kx$ が向心力。$\\omega$ を大きくすると、半径 $\\ell + x$ も大きくなるので、必要な向心力はもっと大きくなる。';
  },
  eqs: function (s) {
    var C = M2.s2, w = s.v.w, x = s.v.x, kx = C.k * x, mr = C.m * (C.l + x) * w * w;
    return {
      in: { h: '【慣性系】円運動している', lines: [{ tag: 'eom', k: '水平方向（中心向き）：', t: 'm(\\ell + x)\\omega^2 = kx', cf: 'kx', cfn: '弾性力' }, { tag: 'bal', k: '鉛直方向：', t: '0 = N - mg' }],
        num: 'いま：' + f3(mr) + ' N ＝ ' + f3(kx) + ' N', note: '※ 慣性系に「遠心力」は存在しない' },
      rot: { h: '【非慣性系】止まって見える', lines: [{ tag: 'bal', k: '水平方向（中心向き）：', t: 'kx - \\underbrace{m(\\ell + x)\\omega^2}_{\\text{遠心力}} = 0' }, { tag: 'bal', k: '鉛直方向：', t: 'N - mg = 0' }],
        num: 'いま：' + f3(kx) + ' − ' + f3(mr) + ' ＝ 0', note: '※ 遠心力は一緒に回る観測者だけが感じる見かけの力' } };
  },
  draw: function (s, ctx, W, H) { drawM2s2(s, ctx, W, H); },
  right: function (s, R) { rightM2s2(s, R); }
});
/* 3 次元のばね（画面の上で、軸に垂直なジグザグ） */
function spring3(ctx, sc, p0, p1, coils, amp) {
  var a = PP(sc, p0[0], p0[1], p0[2]), b = PP(sc, p1[0], p1[1], p1[2]);
  var dx = b.x - a.x, dy = b.y - a.y, L = Math.hypot(dx, dy); if (L < 2) return;
  var ux = dx / L, uy = dy / L, nx = -uy, ny = ux, lead = Math.min(8, L * 0.1), n = coils * 2;
  ctx.save(); ctx.strokeStyle = '#1c8f4a'; ctx.lineWidth = 1.8; ctx.lineJoin = 'round'; ctx.beginPath(); ctx.moveTo(a.x, a.y);
  ctx.lineTo(a.x + ux * lead, a.y + uy * lead);
  for (var i = 1; i < n; i++) { var f = lead + (L - 2 * lead) * i / n, sg = (i % 2) ? 1 : -1; ctx.lineTo(a.x + ux * f + nx * amp * sg, a.y + uy * f + ny * amp * sg); }
  ctx.lineTo(b.x - ux * lead, b.y - uy * lead); ctx.lineTo(b.x, b.y); ctx.stroke(); ctx.restore();
}
function drawM2s2(s, ctx, W, H) {
  var C = M2.s2, w = s.v.w, x = s.v.x, rr = C.l + x, th = m2Ang(s), frame = s.rot ? -th : 0, showF = s.ms.showF;
  var rb = 0.05, zb = rb, R = C.R;
  var sc = scene3d(s, W, H, [{ R: 1.10, z0: -0.22, z1: 0.42 }], frame);
  floor3(ctx, sc, 1.08, -0.20, 0.1);
  var hdIn = m2Outer(ctx, sc, [0.20, -1.02, -0.20], 0.46, !s.rot, 'back');
  turntable3(ctx, sc, R, 0, 0.04, th);
  hdIn = m2Outer(ctx, sc, [0.20, -1.02, -0.20], 0.46, !s.rot, 'front') || hdIn;
  if (!s.rot && !sc.top) omegaArc3(ctx, sc, R + 0.14, 0, 1.9, 2.6);
  ring3(ctx, sc, rr, 0.003, '#8a929c');
  /* 中心の柱 */
  var p0 = PP(sc, 0, 0, 0), p1 = PP(sc, 0, 0, 0.12);
  ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 5; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(p0.x, p0.y); ctx.lineTo(p1.x, p1.y); ctx.stroke(); ctx.restore();
  var cx = rr * Math.cos(th), cy = rr * Math.sin(th), ur = [Math.cos(th), Math.sin(th), 0], ut = [-ur[1], ur[0], 0];
  /* 自然長の位置の目印と、伸び x */
  var nl = [C.l * ur[0], C.l * ur[1]];
  var m1 = PP(sc, nl[0] - ut[0] * 0.05, nl[1] - ut[1] * 0.05, 0.002), m2 = PP(sc, nl[0] + ut[0] * 0.05, nl[1] + ut[1] * 0.05, 0.002);
  ctx.save(); ctx.strokeStyle = '#1c8f4a'; ctx.lineWidth = 1.5; ctx.setLineDash([3, 2]); ctx.beginPath(); ctx.moveTo(m1.x, m1.y); ctx.lineTo(m2.x, m2.y); ctx.stroke(); ctx.restore();
  spring3(ctx, sc, [0, 0, zb], [cx - ur[0] * rb, cy - ur[1] * rb, zb], 9, 5);
  /* 寸法：中心〜自然長 ℓ、自然長〜小球 x（進む向きと反対がわに） */
  var off = -0.10, d0 = PP(sc, ut[0] * off, ut[1] * off, 0.002), d1 = PP(sc, nl[0] + ut[0] * off, nl[1] + ut[1] * off, 0.002), d2 = PP(sc, cx + ut[0] * off, cy + ut[1] * off, 0.002);
  dimLine(ctx, d0.x, d0.y, d1.x, d1.y, '#1c8f4a'); dimLine(ctx, d1.x, d1.y, d2.x, d2.y, '#1c8f4a');
  sym(ctx, 'ℓ', (d0.x + d1.x) / 2, (d0.y + d1.y) / 2 + 12, { size: 15, color: '#1c8f4a' });
  sym(ctx, 'x', (d1.x + d2.x) / 2, (d1.y + d2.y) / 2 + 12, { size: 15, color: '#1c8f4a' });
  trailStep(ctx, s, function (x, y, z) { return PP(sc, x, y, z); }, [cx, cy, zb], -th);
  var B = PP(sc, cx, cy, zb); ballShape(ctx, B.x, B.y, rb * sc.S, '#c9d3de');
  var op = m2CoPos(0, rr, R, th);                            /* 一緒に回る観測者：小球と同じがわ（少し前） */
  var hdRot = observer3(ctx, sc, [op[0], op[1], 0], 0.30, '一緒に回る観測者', s.rot, { dy: 2 });
  var c3 = [cx, cy, zb], fs = M2SC.s2.F, kx = C.k * x;
  if (showF) {
    m2GN(ctx, sc, c3, [cx, cy, 0], ut, C.m * G, fs, 0.016);
    var ak = arrow3(ctx, sc, [cx - ur[0] * rb, cy - ur[1] * rb, zb], [-ur[0], -ur[1], 0], kx * fs, 'force', COL.hand);
    if (ak) { var bk = tipLabel(ctx, ak, 'kx', COL.hand, { off: 14, side: 12, vec: false }); s.addHit('kx', bk); }
    if (s.rot) centLabel(ctx, arrow3(ctx, sc, c3, ur, C.m * rr * w * w * fs, 'fict', COL.cent), s);
  }
  if (!s.rot) {
    var aa = arrow3(ctx, sc, [cx - ut[0] * 0.09, cy - ut[1] * 0.09, zb], [-ur[0], -ur[1], 0], rr * w * w * M2SC.s2.a, 'acc');
    tipLabel(ctx, aa, 'a', COL.acc, { off: 11 });
    velAbove(ctx, sc, c3, [-rr * w * Math.sin(th), rr * w * Math.cos(th)], M2SC.s2.v, 0.14, s);
  }
  drawEqualTicks(ctx);
  m2Speech(ctx, s, hdIn, hdRot, null);
}
function rightM2s2(s, R) {
  var C = M2.s2, w = s.v.w, x = s.v.x, wmax = Math.sqrt(C.k / C.m);
  var h = m2Setup(s, {
    lead: { in: '小球は半径 $\\ell + x$ の等速円運動をしている。<b>向心力の役割をするのはばねの弾性力 $kx$</b>。',
            rot: '小球は止まって見える。外向きの遠心力 $m(\\ell+x)\\omega^2$ と、ばねの弾性力 $kx$ がつり合っている。' },
    rows: [{ dir: '水平方向（中心向き）', in: ['eom', 'm(\\ell + x)\\omega^2 = kx', 'kx', '弾性力'], rot: ['bal', 'kx - m(\\ell + x)\\omega^2 = 0'] },
           { dir: '鉛直方向', in: ['bal', 'N - mg = 0'], rot: ['bal', 'N - mg = 0'] }] });
  h += '<div class="qcard"><p class="qt">伸び $x$ を求める</p><p>' + (s.rot ? T_BAL : T_EOM) + 'を $x$ について解くと</p>' +
    '<div class="qeq">' + tex('x = \\dfrac{m\\ell\\omega^2}{k - m\\omega^2}', true) + '</div>' +
    '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('x = \\dfrac{' + f2(C.m) + '\\times' + f2(C.l) + '\\times' + f2(w) + '^2}{' + C.k + ' - ' + f2(C.m) + '\\times' + f2(w) + '^2} = ' + f3(x) + '\\ \\text{m}') + '</p>' +
    '<p class="qnote">分母 $k - m\\omega^2$ が 0 に近づく（$\\omega \\to \\sqrt{k/m} = ' + f2(wmax) + '$ rad/s）と、伸びは限りなく大きくなる。この図では $\\omega$ を $0.8\\sqrt{k/m} = ' + f2(0.8 * wmax) + '$ rad/s までにしている。</p></div>';
  h += '<p class="assume">' + tex('m = 0.20') + ' kg、' + tex('k = 20') + ' N/m、' + tex('\\ell = 0.30') + ' m。ばねの質量と、ターンテーブルの面との摩擦は考えない。</p>';
  R.innerHTML = mathify(h);
}

/* ===================== セクション3 水平な台の下で糸を引く（1-1 と同じ形。張力が S0 をこえると糸が切れる） ===================== */
M2SC.s3 = { F: 0.045, v: 0.20, a: 0.03 };
function m2s3Cut(s) { return M2.s3.m * s.v.r * s.v.w * s.v.w > M2.s3.S0 + 1e-9; }
/* いまの小球の状態。s.cut0 = { t0, th0 }（切れた時刻と角）。切れたあとは、そのときの速度で等速直線運動 */
function m2s3State(s) {
  var r = s.v.r, w = s.v.w, ph = m2Ang(s);
  if (!s.cut0) return { cut: false, x: r * Math.cos(ph), y: r * Math.sin(ph), vx: -r * w * Math.sin(ph), vy: r * w * Math.cos(ph), ph: ph };
  var th0 = s.cut0.th0, tt = Math.max(0, s.t - s.cut0.t0), x0 = r * Math.cos(th0), y0 = r * Math.sin(th0), vx = -r * w * Math.sin(th0), vy = r * w * Math.cos(th0);
  return { cut: true, x: x0 + vx * tt, y: y0 + vy * tt, vx: vx, vy: vy, x0: x0, y0: y0, ph: ph, tt: tt };
}
DEFS.m2s3 = m2Base({
  id: 'm2s3', num: 3, title: '水平な台の下で糸を引く',
  desc: 'なめらかな水平の台の中心の穴に糸を通し、台の下で手が糸を引いて、小球（$m=0.50$ kg）を回す。向心力は<b>糸の張力</b>。糸が耐えられる最大の張力を $S_0=2.0$ N、そのときの角速度を $\\omega_0$ とよぶ。<span class="todo">図の左上の「↗ ω を大きくしていく」を押して、糸が切れるようすを見よう。</span>',
  varCols: [['w', 'r'], ['S']],
  vars: [
    { k: 'w', label: '角速度 $\\omega$', aria: '角速度', min: 0.5, max: 6.0, step: 0.05, def: 2.0, dec: 2, unit: 'rad/s',
      mark: function (s) { return { x: M2.s3.wCut(s.v.r), label: '$\\omega_0$' }; } },
    { k: 'r', label: '半径 $r$', aria: '半径', min: 0.20, max: 0.60, step: 0.01, def: 0.40, dec: 2, unit: 'm' },
    { k: 'S', label: '糸の張力 $S$', aria: '糸の張力', min: 0.05, max: 2.50, step: 0.005, def: 0.80, dec: 3, unit: 'N',
      mark: function () { return { x: M2.s3.S0, label: '$S_0$' }; } }
  ],
  views: [{ label: '斜め上から', az: -24, el: 30 }, { label: '真上から', az: 0, el: 90 }, { label: '真横から', az: 0, el: 0 }],
  init: function (s) { s.cut0 = null; s.v.S = M2.s3.m * s.v.r * s.v.w * s.v.w; },
  wKeys: ['S'], wBroken: function (s) { return !!s.cut0 && s.t > 0; },
  onWKeep: function (s) { if (!s.cut0 && m2s3Cut(s)) { s.cut0 = { t0: s.t, th0: m2Ang(s) }; s.setSlow(true); } },   /* S₀ をこえたら、その場で切れる */
  onVar: function (s, k, x) {
    var C = M2.s3;
    if (k === 'S') { s.v.S = x; s.v.w = Math.sqrt(x / (C.m * s.v.r)); }          /* 半径はそのまま、ω が変わる */
    else { s.v[k] = x; s.v.S = C.m * s.v.r * s.v.w * s.v.w; }
    return true;
  },
  onReset: function (s) { s.cut0 = m2s3Cut(s) ? { t0: 0, th0: 0 } : null; },
  ramp: {
    crit: function (s) { return M2.s3.wCut(s.v.r); },
    prep: function (s) { s.cut0 = null; },
    sync: function (s) { s.v.S = M2.s3.m * s.v.r * s.v.w * s.v.w; },
    fire: function (s) { s.v.S = M2.s3.m * s.v.r * s.v.w * s.v.w; },
    after: function (s) { s.cut0 = { t0: s.t, th0: m2Ang(s) }; s.setSlow(true); },   /* 切れたあとは速いので、スローにして見せる */
    state: function (s) { return s.cut0 ? '等速直線運動' : '等速円運動'; },
    noReach: function (s) { return 'この半径では、糸が切れる $\\omega_0 = ' + f2(M2.s3.wCut(s.v.r)) + '$ rad/s がスライダーの範囲（6 rad/s まで）を超えている。半径 $r$ を大きくしよう。'; }
  },
  tEnd: function (s) { return s.cut0 ? s.cut0.t0 + M2.s3.exitAfter(s.v.r, s.v.w, s.cut0.th0) : 30; },
  height: function (s, w) { return Math.round(clamp(w * 0.80, 340, 540)); },
  msg: function (s) {
    var wc = M2.s3.wCut(s.v.r);
    if (s.ramp) return s.ramp.ph === 'pause' ? '張力が $S_0 = 2.0$ N に達した！（$\\omega_0 = ' + f2(wc) + '$ rad/s）' : '$\\omega$ を少しずつ大きくしている。張力 $S = mr\\omega^2$ も大きくなる。この間は「❚❚ 一時停止」の他は操作できません。';
    if (s.cut0) return s.ended ? '台のはしまで来たので止めた。' : '<b>糸が切れた！</b>　向心力がなくなったので、小球は切れた瞬間の速度 $\\vec{v}$ のまま、まっすぐ進む（等速直線運動）。';
    return '向心力の役割をするのは<b>糸の張力 $S$</b>。左上の「↗ ω を大きくしていく」を押すと、張力が $S_0$ に達したところで糸が切れる。';
  },
  eqs: function (s) {
    var C = M2.s3, w = s.v.w, r = s.v.r, S = s.v.S, mr = C.m * r * w * w;
    if (s.cut0) return {
      in: { h: '【慣性系】糸が切れた', lines: [{ k: '水平方向（中心向き）：', t: '\\text{力がはたらかない}\\ (a = 0)' }, { tag: 'bal', k: '鉛直方向：', t: '0 = N - mg' }], note: '水平方向の力がないので、等速直線運動（慣性の法則）' },
      rot: { h: '【非慣性系】糸が切れた', lines: [{ k: '水平方向（中心向き）：', t: '\\text{張力なし} \\ \\Rightarrow\\ \\text{遠心力で外へ}' }], note: '回る観測者からは、小球が外へ遠ざかっていくように見える' } };
    return {
      in: { h: '【慣性系】円運動している', lines: [{ tag: 'eom', k: '水平方向（中心向き）：', t: 'mr\\omega^2 = S', cf: 'S', cfn: '張力' }, { tag: 'bal', k: '鉛直方向：', t: '0 = N - mg' }], num: 'いま：' + f3(mr) + ' N ＝ ' + f3(S) + ' N', note: '※ 慣性系に「遠心力」は存在しない' },
      rot: { h: '【非慣性系】止まって見える', lines: [{ tag: 'bal', k: '水平方向（中心向き）：', t: 'S - \\underbrace{mr\\omega^2}_{\\text{遠心力}} = 0' }, { tag: 'bal', k: '鉛直方向：', t: 'N - mg = 0' }], num: 'いま：' + f3(S) + ' − ' + f3(mr) + ' ＝ 0', note: '※ 遠心力は一緒に回る観測者だけが感じる見かけの力' } };
  },
  draw: function (s, ctx, W, H) { drawM2s3(s, ctx, W, H); },
  right: function (s, R) { rightM2s3(s, R); }
});
/* 台（方眼の上面＋見える側面）。もどり値：台がかくす多角形（台の下の糸を破線にするのに使う） */
function m2Table(ctx, sc, half, th) {
  var polys = [];
  [{ n: [0, 1], q: [[-half, half], [half, half]] }, { n: [0, -1], q: [[half, -half], [-half, -half]] },
   { n: [1, 0], q: [[half, half], [half, -half]] }, { n: [-1, 0], q: [[-half, -half], [-half, half]] }].forEach(function (f) {
    if (sc.dOf(W3(f.n[0], f.n[1], 0)) <= 1e-6) return;
    var a = PP(sc, f.q[0][0], f.q[0][1], 0), b = PP(sc, f.q[1][0], f.q[1][1], 0), c = PP(sc, f.q[1][0], f.q[1][1], -th), d = PP(sc, f.q[0][0], f.q[0][1], -th);
    polys.push([a, b, c, d]);
    ctx.save(); ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.lineTo(c.x, c.y); ctx.lineTo(d.x, d.y); ctx.closePath();
    ctx.fillStyle = f.n[0] ? '#d9d2c4' : '#e4ddd0'; ctx.fill(); ctx.strokeStyle = '#8d877c'; ctx.lineWidth = 1; ctx.stroke(); ctx.restore();
  });
  var c4 = [[-half, -half], [half, -half], [half, half], [-half, half]].map(function (q) { return PP(sc, q[0], q[1], 0); });
  ctx.save(); ctx.beginPath(); c4.forEach(function (q, i) { i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y); }); ctx.closePath();
  ctx.fillStyle = '#fbfaf6'; ctx.fill(); ctx.clip();
  [false, true].forEach(function (big) {                     /* 色ごとにまとめて描く */
    ctx.strokeStyle = big ? '#e6dfd2' : '#f1ece3'; ctx.lineWidth = 1; ctx.beginPath();
    for (var gi = -20; gi <= 20; gi++) {
      var g = gi * 0.1; if (Math.abs(g) > half || (gi % 5 === 0) !== big) continue;
      var a1 = PP(sc, g, -half, 0), a2 = PP(sc, g, half, 0), b1 = PP(sc, -half, g, 0), b2 = PP(sc, half, g, 0);
      ctx.moveTo(a1.x, a1.y); ctx.lineTo(a2.x, a2.y); ctx.moveTo(b1.x, b1.y); ctx.lineTo(b2.x, b2.y);
    }
    ctx.stroke();
  });
  ctx.restore();
  ctx.save(); ctx.beginPath(); c4.forEach(function (q, i) { i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y); }); ctx.closePath();
  ctx.strokeStyle = '#8d877c'; ctx.lineWidth = 1.3; ctx.stroke(); ctx.restore();
  polys.push(c4);
  return polys;
}
function drawM2s3(s, ctx, W, H) {
  var C = M2.s3, w = s.v.w, r = s.v.r, st = m2s3State(s), ph = st.ph, frame = s.rot ? -ph : 0, showF = s.ms.showF, rb = C.rb, zb = rb, half = C.half, th = 0.05;
  var depth = C.Lstr - r;                                        /* 台の下の糸の長さ（手の深さ）。r を大きくすると手が上がる */
  var sc = scene3d(s, W, H, [{ R: half * 1.42, z0: -th, z1: 0.30 }, { R: 0.12, z0: -(C.Lstr - 0.20) - 0.30, z1: 0 }], frame);
  var showHand = sc.el < 80, hb = PP(sc, 0, 0, -th), hh = PP(sc, 0, 0, -depth);
  if (showHand) { ctx.save(); ctx.strokeStyle = '#7a5a32'; ctx.lineWidth = 1.7; ctx.beginPath(); ctx.moveTo(hb.x, hb.y); ctx.lineTo(hh.x, hh.y); ctx.stroke(); ctx.restore(); }
  var polys = m2Table(ctx, sc, half, th);
  if (showHand) {                                                /* 台にかくれた糸は破線。手は台のあとに描く */
    ctx.save(); ctx.beginPath(); polys.forEach(function (pl) { pl.forEach(function (q, i) { i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y); }); ctx.closePath(); });
    ctx.clip(); ctx.setLineDash([4, 4]); ctx.strokeStyle = '#7a5a32'; ctx.lineWidth = 1.3;
    var h0 = PP(sc, 0, 0, 0); ctx.beginPath(); ctx.moveTo(h0.x, h0.y); ctx.lineTo(hh.x, hh.y); ctx.stroke(); ctx.restore();
    handBelow(ctx, hh.x, hh.y - 2, clamp(0.13 * sc.S, 14, 26));
  }
  var hdIn = observer3(ctx, sc, [0.70, -0.95, 0], 0.40, '外の観測者', !s.rot, { dy: 2 });
  if (!s.rot && !sc.top && !st.cut) omegaArc3(ctx, sc, r + 0.16, zb, 1.9, 2.7);
  if (!st.cut) ring3(ctx, sc, r, zb, '#8a929c');
  var O = PP(sc, 0, 0, 0), sinEl = Math.max(0.3, Math.sin(sc.el * Math.PI / 180));
  ctx.save(); ctx.fillStyle = '#2b323c'; ctx.beginPath(); ctx.ellipse(O.x, O.y, 4.4, 4.4 * sinEl, 0, 0, TAU); ctx.fill(); ctx.restore();
  var cx = st.x, cy = st.y, B = PP(sc, cx, cy, zb);
  var sp = Math.hypot(st.vx, st.vy), uv = [st.vx / sp, st.vy / sp];
  if (st.cut) {                                                   /* 切れたあと：道すじ（破線）と、切れた糸 */
    var c0 = PP(sc, st.x0, st.y0, zb);
    ctx.save(); ctx.setLineDash([7, 5]); ctx.strokeStyle = COL.vel; ctx.globalAlpha = 0.75; ctx.lineWidth = 1.8; ctx.beginPath(); ctx.moveTo(c0.x, c0.y); ctx.lineTo(B.x, B.y); ctx.stroke(); ctx.restore();
    var u0 = [st.x0 / r, st.y0 / r], cl = r * 0.45, stub = PP(sc, u0[0] * cl, u0[1] * cl, zb);
    ctx.save(); ctx.strokeStyle = '#7a5a32'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(O.x, O.y); ctx.lineTo(stub.x, stub.y); ctx.stroke();
    var bk = [cx - uv[0] * rb, cy - uv[1] * rb], tl = PP(sc, bk[0] - uv[0] * r * 0.4, bk[1] - uv[1] * r * 0.4, zb), bkP = PP(sc, bk[0], bk[1], zb);
    ctx.beginPath(); ctx.moveTo(bkP.x, bkP.y); ctx.lineTo(tl.x, tl.y); ctx.stroke(); ctx.restore();
  } else {
    var ur0 = [cx / r, cy / r], e = PP(sc, cx - ur0[0] * rb, cy - ur0[1] * rb, zb);
    ctx.save(); ctx.strokeStyle = '#7a5a32'; ctx.lineWidth = 1.7; ctx.beginPath(); ctx.moveTo(O.x, O.y); ctx.lineTo(e.x, e.y); ctx.stroke(); ctx.restore();
    var tx = -ur0[1], ty = ur0[0], rq = PP(sc, cx * 0.42 + tx * 0.07, cy * 0.42 + ty * 0.07, zb); sym(ctx, 'r', rq.x, rq.y, { size: 16 });
  }
  trailStep(ctx, s, function (x, y, z) { return PP(sc, x, y, z); }, [cx, cy, zb], -ph);
  ballShape(ctx, B.x, B.y, rb * sc.S, '#c9d3de');
  /* 一緒に回る観測者：小球の上に乗る（少しうしろにずらす） */
  var hdRot = m2Rider(ctx, sc, [cx - uv[0] * 0.02, cy - uv[1] * 0.02, 2 * rb], s.rot);
  s.autoTrail = st.cut || !!s.ramp;
  var rr = Math.hypot(cx, cy), ur = [cx / rr, cy / rr, 0], ut = [-ur[1], ur[0], 0], c3 = [cx, cy, zb], fs = M2SC.s3.F;
  if (showF) {
    m2GN(ctx, sc, c3, [cx, cy, 0], ut, C.m * G, fs, 0.014);
    if (!st.cut) {
      var aS = arrow3(ctx, sc, [cx - ur[0] * rb, cy - ur[1] * rb, zb], [-ur[0], -ur[1], 0], s.v.S * fs, 'force', COL.hand);
      if (aS) tipLabel(ctx, aS, 'S', COL.hand, { off: 12, side: 12, vec: false });
      if (s.rot) centLabel(ctx, arrow3(ctx, sc, c3, ur, C.m * r * w * w * fs, 'fict', COL.cent), s);
    }
  }
  if (!s.rot) {
    if (!st.cut) {
      var aa = arrow3(ctx, sc, [cx - ut[0] * 0.08, cy - ut[1] * 0.08, zb], [-ur[0], -ur[1], 0], r * w * w * M2SC.s3.a, 'acc');
      tipLabel(ctx, aa, 'a', COL.acc, { off: 11 });
    }
    velAbove(ctx, sc, c3, [st.vx, st.vy], M2SC.s3.v, 0.28, s);
  }
  drawEqualTicks(ctx);
  m2Speech(ctx, s, hdIn, hdRot, st.cut ? 'cut' : null);
  if (st.cut && !s.ended) eventBubble(ctx, 'cut', B.x, B.y - rb * sc.S - 30);
  else if (s.ramp && s.ramp.ph === 'pause') bubble(ctx, 'S₀ に達した…', B.x, B.y - rb * sc.S - 30, { size: 13, bg: '#fff5d6', border: '#d9a545', color: '#8a5000' });
}
function rightM2s3(s, R) {
  var C = M2.s3, w = s.v.w, r = s.v.r, wc = C.wCut(r);
  var h = m2Setup(s, {
    lead: { in: '小球は半径 $r$ の等速円運動。<b>向心力の役割をするのは糸の張力 $S$</b>。', rot: '小球は止まって見える。外向きの遠心力 $mr\\omega^2$ と張力 $S$ がつり合う。' },
    rows: [{ dir: '水平方向（中心向き）', in: ['eom', 'mr\\omega^2 = S', 'S', '張力'], rot: ['bal', 'S - mr\\omega^2 = 0'] },
           { dir: '鉛直方向', in: ['bal', 'N - mg = 0'], rot: ['bal', 'N - mg = 0'] }] });
  h += '<div class="qcard' + (s.cut0 ? ' derive' : '') + '"><p class="qt">糸が切れる角速度 $\\omega_0$</p><p>張力が $S_0$ に達したときに切れる。$mr\\omega_0^{\\,2} = S_0$ より</p>' +
    '<div class="qeq">' + tex('\\omega_0 = \\sqrt{\\dfrac{S_0}{mr}}', true) + '</div>' +
    '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('\\omega_0 = \\sqrt{\\dfrac{' + f2(C.S0) + '}{' + f2(C.m) + '\\times' + f2(r) + '}} = ' + f2(wc) + '\\ \\text{rad/s}') + '</p>' +
    '<p class="qnote">半径 $r$ が大きいほど、小さい $\\omega$ で切れる。糸が切れると向心力がなくなり、小球はそのときの速度の向き（接線方向）にまっすぐ飛ぶ。' +
    (s.rot && s.cut0 ? '回る観測者から見て外へ遠ざかる道すじが曲がって見えるのは、コリオリの力（高校の範囲外）のため。' : '') + '</p></div>';
  h += '<p class="assume">' + tex('m = 0.50') + ' kg、' + tex('S_0 = 2.0') + ' N。糸の質量と台の摩擦は考えない。糸が切れたあとは自動でスロー再生にしている（🐢 スローで切りかえ）。</p>';
  R.innerHTML = mathify(h);
}

/* ===================== セクション4 円錐振り子 ===================== */
var M2RES = '#2f3a8f';   /* 合力＝あい色 */
function m2ForceOn(s) { s.ms.showF = true; syncModeBar(s.mode); }   /* 力の矢印を自動で ON */
M2SC.s4 = { F: 0.12, v: 0.14, a: 0.014 };
/* 2-4：「張力を分解する」と「合力のみ表示」は同時に ON にならない（片方を ON にすると、もう片方は OFF。2026-10-06 千葉さん） */
function m2s4Chk(s) {
  if (s.decomp) s.resOnly = false;
  [['decomp', s.decomp], ['resOnly', s.resOnly]].forEach(function (q) { var b = s.extra && s.extra[q[0]]; if (b) { b.classList.toggle('on', !!q[1]); b.setAttribute('aria-pressed', q[1] ? 'true' : 'false'); } });
}
DEFS.m2s4 = m2Base({
  id: 'm2s4', num: 4, title: '円錐振り子',
  desc: '長さ $L=1.0$ m の糸で小球（$m=0.20$ kg）をつるし、水平面内で回す。向心力は<b>糸の張力の水平成分</b>。<span class="todo">右上の「真上から見る」「水平から見る」を押して、右の式と見比べよう。</span>',
  varCols: [['w'], ['S']],                   /* スライダーが 2 つなら 1 行に（1-1 と同じ 2 列） */
  wKeys: ['S'],                              /* S を変えても ω が変わるだけなので、最初にもどさない */
  vars: [
    { k: 'w', label: '角速度 $\\omega$', aria: '角速度', min: 3.20, max: 7.00, step: 0.02, def: 4.00, dec: 2, unit: 'rad/s' },
    { k: 'S', label: '糸の張力 $S$', aria: '糸の張力', min: 2.05, max: 9.80, step: 0.01, def: 3.20, dec: 2, unit: 'N' }
  ],
  views: [{ label: '斜め上から', az: -24, el: 16 }, { label: '真上から見る', az: 0, el: 90 }, { label: '水平から見る', az: -20, el: 0 }],
  view0: 0,
  init: function (s) { s.v.S = M2.s4.m * M2.s4.L * s.v.w * s.v.w; s.decomp = false; s.resF = false; s.resOnly = false; s.hl = null;
    if (s.extra && s.extra.resOnly) { s.extra.resOnly.classList.remove('on'); }
    if (s.extra && s.extra.decomp) { s.extra.decomp.classList.remove('on'); }
    if (s.extra && s.extra.resF) { s.extra.resF.classList.remove('on'); } },
  onVar: function (s, k, x) {
    var C = M2.s4;
    if (k === 'w') { s.v.w = x; s.v.S = C.m * C.L * x * x; } else { s.v.S = x; s.v.w = Math.sqrt(x / (C.m * C.L)); }
    return true;
  },
  onView: function (s, i) { s.hl = (i === 2) ? 'v' : (i === 1 ? 'h' : null); s.renderRight(); },
  onDragView: function (s) { if (s.hl) { s.hl = null; s.renderRight(); } },
  buttons: [{ k: 'decomp', label: '張力を分解する', cls: 'chkb', onClick: function (s, b) { s.decomp = !s.decomp; m2s4Chk(s); if (s.decomp && !s.ms.showF) m2ForceOn(s); s.draw(); } },
    { k: 'resF', label: '合力を表示（張力と重力を合成）', cls: 'chkb', onClick: function (s, b) { s.resF = !s.resF; b.classList.toggle('on', s.resF); b.setAttribute('aria-pressed', s.resF ? 'true' : 'false'); if (s.resF && !s.ms.showF) m2ForceOn(s); s.draw(); } },
    /* 合力のみ表示：張力と重力を消して、合力（水平・中心向き）だけ（2026-10-05 千葉さん） */
    { k: 'resOnly', label: '合力のみ表示', cls: 'chkb', onClick: function (s, b) { s.resOnly = !s.resOnly; if (s.resOnly) s.decomp = false; m2s4Chk(s); if (s.resOnly && !s.ms.showF) m2ForceOn(s); s.draw(); } }],
  msg: function (s) {
    var th = M2.s4.thOf(s.v.w) * 180 / Math.PI;
    return '$\\cos\\theta = \\dfrac{g}{L\\omega^2}$ より $\\theta = ' + fmt(th, 1) + '^\\circ$。$\\omega$ を大きくすると、小球は外へ広がって高く上がる。';
  },
  eqs: function (s) {
    var C = M2.s4, w = s.v.w, th = C.thOf(w), S = s.v.S, r = C.L * Math.sin(th), mr = C.m * r * w * w;
    return {
      in: { h: '【慣性系】円運動している', lines: [{ tag: 'eom', k: '水平方向（中心向き）：', t: 'mr\\omega^2 = S\\sin\\theta', cf: 'S\\sin\\theta', cfn: '張力の水平成分' }, { tag: 'bal', k: '鉛直方向：', t: '0 = S\\cos\\theta - mg' }],
        num: 'いま：' + f3(mr) + ' ＝ ' + f3(S * Math.sin(th)) + '、0 ＝ ' + f3(S * Math.cos(th)) + ' − ' + f3(C.m * G), note: '※ 慣性系に「遠心力」は存在しない' },
      rot: { h: '【非慣性系】止まって見える', lines: [{ tag: 'bal', k: '水平方向（中心向き）：', t: 'S\\sin\\theta - \\underbrace{mr\\omega^2}_{\\text{遠心力}} = 0' }, { tag: 'bal', k: '鉛直方向：', t: 'S\\cos\\theta - mg = 0' }],
        num: 'いま：' + f3(S * Math.sin(th)) + ' − ' + f3(mr) + ' ＝ 0', note: '※ 遠心力は一緒に回る観測者だけが感じる見かけの力' } };
  },
  draw: function (s, ctx, W, H) { drawM2s4(s, ctx, W, H); },
  right: function (s, R) { rightM2s4(s, R); }
});
function drawM2s4(s, ctx, W, H) {
  var C = M2.s4, w = s.v.w, L = C.L, th = C.thOf(w), r = L * Math.sin(th), zc = -L * Math.cos(th), ph = m2Ang(s);
  var frame = s.rot ? -ph : 0, showF = s.ms.showF, rb = 0.045, zf = -L - 0.30;
  var sc = scene3d(s, W, H, [{ R: 1.0, z0: zf, z1: 0.12 }], frame, { t: 46, b: 26, x: 10 });
  floor3(ctx, sc, 0.98, zf, 0.1);
  var hdIn = observer3(ctx, sc, [0.25, -0.90, zf], 0.45, '外の観測者', !s.rot, { dy: 2 });
  /* 天井の板 */
  var cp = [[-0.22, -0.12], [0.22, -0.12], [0.22, 0.12], [-0.22, 0.12]].map(function (q) { return PP(sc, q[0], q[1], 0.03); });
  ctx.save(); ctx.beginPath(); cp.forEach(function (q, i) { i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y); }); ctx.closePath();
  ctx.fillStyle = '#c9b48f'; ctx.fill(); ctx.strokeStyle = '#6b5a3a'; ctx.lineWidth = 1.2; ctx.stroke(); ctx.restore();
  var O = PP(sc, 0, 0, 0), Ax = PP(sc, 0, 0, zf);
  /* 鉛直の軸（破線）と、円軌道 */
  ctx.save(); ctx.setLineDash([4, 4]); ctx.strokeStyle = '#6f7782'; ctx.lineWidth = 1.1; ctx.beginPath(); ctx.moveTo(O.x, O.y); ctx.lineTo(Ax.x, Ax.y); ctx.stroke(); ctx.restore();
  ring3(ctx, sc, r, zc, '#8a929c');
  var cx = r * Math.cos(ph), cy = r * Math.sin(ph), ur = [Math.cos(ph), Math.sin(ph), 0], ut = [-ur[1], ur[0], 0];
  var c3 = [cx, cy, zc], us = [-cx / L, -cy / L, -zc / L];            /* 小球から支点への向き */
  var B = PP(sc, cx, cy, zc), Cc = PP(sc, 0, 0, zc);
  /* 半径 r（軸から小球へ、破線） */
  ctx.save(); ctx.setLineDash([3, 3]); ctx.strokeStyle = '#6f7782'; ctx.beginPath(); ctx.moveTo(Cc.x, Cc.y); ctx.lineTo(B.x, B.y); ctx.stroke(); ctx.restore();
  /* 円の中心：黒い点で目立たせる */
  ctx.save(); ctx.fillStyle = '#14171c'; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(Cc.x, Cc.y, 4.2, 0, TAU); ctx.fill(); ctx.stroke(); ctx.restore();
  label(ctx, '円の中心', Cc.x - 8, Cc.y + 13, { size: 11.5, bold: true, color: COL.ink, align: 'right' });
  var rl = PP(sc, cx * 0.5 - ut[0] * 0.06, cy * 0.5 - ut[1] * 0.06, zc); if (!sc.top) sym(ctx, 'r', rl.x, rl.y + 10, { size: 15 });
  /* 糸 */
  var sB = PP(sc, cx + us[0] * rb, cy + us[1] * rb, zc + us[2] * rb);
  ctx.save(); ctx.strokeStyle = '#7a5a32'; ctx.lineWidth = 1.7; ctx.beginPath(); ctx.moveTo(O.x, O.y); ctx.lineTo(sB.x, sB.y); ctx.stroke(); ctx.restore();
  /* 角 θ（支点で、軸と糸のあいだ）：真上からは描かない */
  if (!sc.top) {
    var arc = []; for (var j = 0; j <= 16; j++) { var f = j / 16, a = th * f, R0 = 0.16; arc.push(PP(sc, R0 * Math.sin(a) * ur[0], R0 * Math.sin(a) * ur[1], -R0 * Math.cos(a))); }
    ctx.save(); ctx.strokeStyle = COL.ink2; ctx.lineWidth = 1.2; ctx.beginPath(); arc.forEach(function (q, i) { i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y); }); ctx.stroke(); ctx.restore();
    var am = PP(sc, 0.26 * Math.sin(th / 2) * ur[0], 0.26 * Math.sin(th / 2) * ur[1], -0.26 * Math.cos(th / 2)); sym(ctx, 'θ', am.x, am.y, { size: 15 });
  }
  trailStep(ctx, s, function (x, y, z) { return PP(sc, x, y, z); }, [cx, cy, zc], -ph);
  ballShape(ctx, B.x, B.y, rb * sc.S, '#c9d3de');
  /* 一緒に回る観測者：小球の上に乗る（糸と重ならないよう、少し進む向きの後ろへずらす）。床の回転台は描かない */
  var hdRot = m2Rider(ctx, sc, [cx - ut[0] * 0.03, cy - ut[1] * 0.03, zc + rb], s.rot);
  if (!s.rot && !sc.top) omegaArc3(ctx, sc, r + 0.16, zc, 1.9, 2.6);
  var fs = M2SC.s4.F, S = s.v.S;
  if (showF) {
    var p0 = [cx + us[0] * rb, cy + us[1] * rb, zc + us[2] * rb];
    if (!s.resOnly) {
      var ag = arrow3(ctx, sc, c3, [0, 0, -1], C.m * G * fs, 'force', COL.force);
      if (ag) label(ctx, 'mg', ag.x2, ag.y2 + 11, { size: 13, bold: true, color: COL.force });
      var aS = arrow3(ctx, sc, p0, us, S * fs, 'force', COL.hand);
      if (aS) tipLabel(ctx, aS, 'S', COL.hand, { off: 12, side: -12, vec: false });
    }
    if (s.decomp && !s.resOnly) {                                          /* 分力：同じ作用点から、水平（中心向き）と鉛直（上向き） */
      var ah = arrow3(ctx, sc, p0, [-ur[0], -ur[1], 0], S * Math.sin(th) * fs, 'comp', COL.hand, { tick: true });
      if (ah) label(ctx, 'S sinθ', ah.x2 + ah.ux * 26, ah.y2 + ah.uy * 26 + 4, { size: 11.5, bold: true, color: COL.hand });
      var av = arrow3(ctx, sc, p0, [0, 0, 1], S * Math.cos(th) * fs, 'comp', COL.hand, { tick: true });
      if (av) label(ctx, 'S cosθ', av.x2, av.y2 - 12, { size: 11.5, bold: true, color: COL.hand });
    }
    if (s.resF || s.resOnly) {                               /* 合力 = 張力 + 重力：水平で中心向きだけ（平行四辺形の破線つき。合力のみのときは線なし） */
      var Sv = [us[0] * S * fs, us[1] * S * fs, us[2] * S * fs], gv = [0, 0, -C.m * G * fs];
      var tS = PP(sc, c3[0] + Sv[0], c3[1] + Sv[1], c3[2] + Sv[2]), tg = PP(sc, c3[0], c3[1], c3[2] + gv[2]);
      var tR = PP(sc, c3[0] + Sv[0], c3[1] + Sv[1], c3[2] + Sv[2] + gv[2]);
      if (!s.resOnly) {                                       /* 合力のみのときは、平行四辺形の補助線も描かない */
        ctx.save(); ctx.setLineDash([4, 4]); ctx.strokeStyle = '#4a5560'; ctx.lineWidth = 1.2; ctx.beginPath();
        ctx.moveTo(tS.x, tS.y); ctx.lineTo(tR.x, tR.y); ctx.moveTo(tg.x, tg.y); ctx.lineTo(tR.x, tR.y); ctx.stroke(); ctx.restore();
      }
      var aR = arrow3(ctx, sc, c3, [-ur[0], -ur[1], 0], S * Math.sin(th) * fs, 'force', M2RES, { noShift: true });
      if (aR) { var nx = -aR.uy, ny = aR.ux; if (ny < 0) { nx = -nx; ny = -ny; }     /* 矢印の下側に「合力」 */
        label(ctx, '合力', (aR.x1 + aR.x2) / 2 + nx * 22, (aR.y1 + aR.y2) / 2 + ny * 22 + 4, { size: 12.5, bold: true, color: M2RES }); }
    }
    if (s.rot) centLabel(ctx, arrow3(ctx, sc, c3, ur, C.m * r * w * w * fs, 'fict', COL.cent), s);
  }
  if (!s.rot) {
    var aa = arrow3(ctx, sc, [cx - ut[0] * 0.09, cy - ut[1] * 0.09, zc], [-ur[0], -ur[1], 0], r * w * w * M2SC.s4.a, 'acc');
    tipLabel(ctx, aa, 'a', COL.acc, { off: 11 });
    velAbove(ctx, sc, c3, [-r * w * Math.sin(ph), r * w * Math.cos(ph)], M2SC.s4.v, 0.14, s);
  }
  drawEqualTicks(ctx);
  m2Speech(ctx, s, hdIn, hdRot, null);
}
function rightM2s4(s, R) {
  var C = M2.s4, w = s.v.w, th = C.thOf(w), hl = s.hl || '';
  var h = '<p class="qlead">右上の「真上から見る」を押すと水平方向の式が、「水平から見る」を押すと鉛直方向の式が光る。観測者を切りかえると、その観測者の式に変わる。</p>';
  h += m2Setup(s, {
    lead: { in: '糸が引く力の水平成分 $S\\sin\\theta$ が向心力。鉛直方向には動かないので力がつり合う。', rot: '遠心力 $mr\\omega^2$ と $S\\sin\\theta$ がつり合う。鉛直方向も力がつり合う。' },
    rows: [{ dir: '水平方向（中心向き）', hl: 'h', in: ['eom', 'mr\\omega^2 = S\\sin\\theta', 'S\\sin\\theta', '張力の水平成分'], rot: ['bal', 'S\\sin\\theta - mr\\omega^2 = 0'] },
           { dir: '鉛直方向', hl: 'v', in: ['bal', 'S\\cos\\theta - mg = 0'], rot: ['bal', 'S\\cos\\theta - mg = 0'] }] });
  h += '<div class="qcard"><p class="qt">$S$ と $\\theta$ を求める</p><p>$r = L\\sin\\theta$ を水平方向の式に入れると $mL\\omega^2\\sin\\theta = S\\sin\\theta$ より</p>' +
    '<div class="qeq">' + tex('S = mL\\omega^2', true) + tex('\\cos\\theta = \\dfrac{mg}{S} = \\dfrac{g}{L\\omega^2}', true) + '</div>' +
    '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('S = ' + fmt(s.v.S, 2) + '\\ \\text{N},\\ \\ \\theta = ' + fmt(th * 180 / Math.PI, 1) + '^\\circ') + '</p>' +
    '<p class="qnote">$\\cos\\theta \\le 1$ なので $\\omega \\ge \\sqrt{g/L} = ' + f2(C.wMin()) + '$ rad/s のときだけ、この円運動ができる。</p></div>';
  h += '<p class="assume">' + tex('m = 0.20') + ' kg、' + tex('L = 1.0') + ' m、' + tex('g = 9.8') + ' m/s²。' + (s.rot ? '一緒に回る観測者は、小球の上に乗っている。' : '') + '</p>';
  R.innerHTML = mathify(h);
}

/* ===================== セクション5 太陽と地球 ===================== */
DEFS.m2s5 = m2Base({
  id: 'm2s5', num: 5, title: '太陽と地球',
  desc: '地球は太陽の周りを、ほぼ等速円運動している。向心力は<b>万有引力</b>。くわしくは <a href="https://physics-chiba.github.io/physics-site/mechanics/celestial-mechanics.html" target="_blank" rel="noopener">万有引力とケプラーの法則のページ</a> へ。<span class="todo">観測者を切りかえて、地球と周りの星の見え方を比べよう。</span>',
  vars: [],
  views: null, noDrag: true,
  init: function (s) { s.v.w = 0.6; },
  height: function (s, w) { return Math.round(clamp(w * 0.70, 300, 460)); },
  msg: function (s) { return s.rot ? '地球と一緒に回る観測者には、地球も太陽も止まって見え、周りの星が回って見える。万有引力と遠心力がつり合っている。' : '外から見ると、地球は万有引力を向心力として、太陽の周りを回り続ける。'; },
  eqs: function () {
    return {
      in: { h: '【慣性系】円運動している', lines: [{ tag: 'eom', k: '中心方向：', t: 'mr\\omega^2 = G\\dfrac{Mm}{r^2}', cf: 'G\\dfrac{Mm}{r^2}', cfn: '万有引力' }], note: '※ 慣性系に「遠心力」は存在しない' },
      rot: { h: '【非慣性系】止まって見える', lines: [{ tag: 'bal', k: '中心方向：', t: 'G\\dfrac{Mm}{r^2} - \\underbrace{mr\\omega^2}_{\\text{遠心力}} = 0' }], note: '※ 遠心力は一緒に回る観測者だけが感じる見かけの力' } };
  },
  draw: function (s, ctx, W, H) { drawM2s5(s, ctx, W, H); },
  right: function (s, R) {
    var h = m2Setup(s, {
      lead: { in: '地球（質量 $m$）は太陽（質量 $M$）の周りを半径 $r$ で回る。<b>向心力の役割をするのは万有引力</b> $G\\dfrac{Mm}{r^2}$。', rot: '地球は止まって見え、外向きの遠心力 $mr\\omega^2$ と万有引力がつり合う。' },
      rows: [{ dir: '中心方向（太陽向き）', in: ['eom', 'mr\\omega^2 = G\\dfrac{Mm}{r^2}', 'G\\dfrac{Mm}{r^2}', '万有引力'], rot: ['bal', 'G\\dfrac{Mm}{r^2} - mr\\omega^2 = 0'] }] }) +
      '<div class="qcard"><p class="qt">ここから分かること</p><p>$\\omega = \\dfrac{2\\pi}{T}$ を入れて整理すると $\\dfrac{T^2}{r^3} = \\dfrac{4\\pi^2}{GM}$。惑星によらず一定になる（ケプラーの第 3 法則）。</p>' +
      '<p><a class="golink" href="https://physics-chiba.github.io/physics-site/mechanics/celestial-mechanics.html" target="_blank" rel="noopener">万有引力とケプラーの法則のページへ →</a></p></div>' +
      '<p class="assume">太陽・地球の大きさと距離は、実際の比ではない。</p>';
    R.innerHTML = mathify(h);
  }
});
var M2STARS = (function () { var a = [], sd = 7; for (var i = 0; i < 90; i++) { sd = (sd * 9301 + 49297) % 233280; var u = sd / 233280; sd = (sd * 9301 + 49297) % 233280; var v = sd / 233280; sd = (sd * 9301 + 49297) % 233280; a.push([u * 2 - 1, v * 2 - 1, 0.6 + (sd / 233280) * 1.2]); } return a; })();
function drawM2s5(s, ctx, W, H) {
  var w = s.v.w, ph = m2Ang(s), frame = s.rot ? -ph : 0, cx = W / 2, cy = H / 2 + 8, R = Math.min(W, H) * 0.32, showF = s.ms.showF;
  /* 宇宙（夜） */
  ctx.save(); ctx.fillStyle = '#121722'; rrect(ctx, 0, 0, W, H, 0); ctx.fill(); ctx.restore();
  var cf = Math.cos(frame), sf = Math.sin(frame), half = Math.hypot(W, H) / 2;
  M2STARS.forEach(function (q) { var x = q[0] * half, y = q[1] * half, X = cx + x * cf + y * sf, Y = cy - (-x * sf + y * cf);
    ctx.fillStyle = 'rgba(246,242,233,.75)'; ctx.beginPath(); ctx.arc(X, Y, q[2], 0, TAU); ctx.fill(); });
  var P = function (x, y) { var X = x * Math.cos(frame) - y * Math.sin(frame), Y = x * Math.sin(frame) + y * Math.cos(frame); return { x: cx + X, y: cy - Y }; };
  ctx.save(); ctx.setLineDash([4, 5]); ctx.strokeStyle = 'rgba(246,242,233,.35)'; ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.stroke(); ctx.restore();
  /* 太陽 */
  var g = ctx.createRadialGradient(cx, cy, 2, cx, cy, 30); g.addColorStop(0, '#fff3c4'); g.addColorStop(0.5, '#f0b429'); g.addColorStop(1, 'rgba(240,180,41,0)');
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, 30, 0, TAU); ctx.fill();
  ctx.fillStyle = '#f0b429'; ctx.beginPath(); ctx.arc(cx, cy, 17, 0, TAU); ctx.fill();
  label(ctx, '太陽 M', cx, cy + 32, { size: 12, bold: true, color: '#f6d37a', halo: false });
  trailStep(ctx, s, function (x, y) { return P(x, y); }, [R * Math.cos(ph), R * Math.sin(ph), 0], -ph);
  var E = P(R * Math.cos(ph), R * Math.sin(ph)), ux = (E.x - cx) / R, uy = (E.y - cy) / R;
  var eg = ctx.createRadialGradient(E.x - 3, E.y - 3, 1, E.x, E.y, 10); eg.addColorStop(0, '#bfe3ff'); eg.addColorStop(1, '#2a73c8');
  ctx.fillStyle = eg; ctx.beginPath(); ctx.arc(E.x, E.y, 10, 0, TAU); ctx.fill();
  label(ctx, '地球 m', E.x + ux * 4 + uy * 30, E.y + uy * 4 - ux * 30, { size: 12, bold: true, color: '#bfe3ff', halo: false });
  var LF = R * 0.55;
  if (showF) {
    var af = arrow(ctx, E.x, E.y, E.x - ux * LF, E.y - uy * LF, 'force', '#ff6b5b');
    if (af) sym(ctx, 'F', af.x2 - af.uy * 14, af.y2 + af.ux * 14, { size: 16, color: '#ff8a7d', vec: true, haloColor: 'rgba(18,23,34,.9)' });
    if (s.rot) { var ac = arrow(ctx, E.x, E.y, E.x + ux * LF, E.y + uy * LF, 'fict', '#c3ccd6'); if (ac) label(ctx, '遠心力', ac.x2 + ux * 18, ac.y2 + uy * 18, { size: 12, bold: true, color: '#c3ccd6', halo: false }); }
  }
  if (!s.rot) {
    var tx = uy, ty = -ux;                                    /* 画面での進む向き（左回り） */
    var ox = E.x + ux * 22, oy = E.y + uy * 22, Lv = R * 0.38;
    var av = arrow(ctx, ox - tx * Lv / 2, oy - ty * Lv / 2, ox + tx * Lv / 2, oy + ty * Lv / 2, 'vel');
    if (av) sym(ctx, 'v', av.x2 + av.ux * 11, av.y2 + av.uy * 11, { size: 16, color: '#7fb6ff', vec: true, haloColor: 'rgba(18,23,34,.9)' });
    var a0x = E.x - tx * 18, a0y = E.y - ty * 18, aa = arrow(ctx, a0x, a0y, a0x - ux * R * 0.3, a0y - uy * R * 0.3, 'acc');
    if (aa) sym(ctx, 'a', aa.x2 - tx * 12, aa.y2 - ty * 12, { size: 15, color: '#ffa64d', vec: true, haloColor: 'rgba(18,23,34,.9)' });
  }
  drawEqualTicks(ctx);
  pill(ctx, s.rot ? '地球と一緒に回る観測者（非慣性系）から見る' : '外（慣性系）から見る', 10, 10, { size: 12, color: s.rot ? '#fff' : COL.ink, bg: s.rot ? COL.cent : '#fff' });
  label(ctx, '大きさ・距離は実際の比ではない', W - 8, H - 12, { size: 10.5, color: 'rgba(246,242,233,.55)', align: 'right', halo: false });
}

/* ===================== セクション6 正電荷のまわりの負電荷（静電気力） ===================== */
/* 2026-10-05 千葉さん：②-5（太陽と地球）と同じ見た目にして、万有引力と静電気力が「同じ形（逆 2 乗）」だと気づかせる。
   内部の id は m2sq（②-7 のローレンツ力が m2s6 のまま）。q₁・q₂ を変えたら最初にもどす */
var M2SQ = { k: 9.0e9, r: 0.30, m: 0.10 };
function m2sqF(v) { return M2SQ.k * v.q1 * 1e-6 * v.q2 * 1e-6 / (M2SQ.r * M2SQ.r); }   /* 静電気力の大きさ［N］ */
function m2sqW(v) { return Math.sqrt(m2sqF(v) / (M2SQ.m * M2SQ.r)); }                    /* mrω² = F より ω */
DEFS.m2sq = m2Base({
  id: 'm2sq', num: 6, title: '正電荷の周りの負電荷の円運動',
  desc: '負の電荷 $-q_2$（質量 $m$）が、正の電荷 $+q_1$（質量は圧倒的に大きい）の周りを、半径 $r$ で等速円運動する。向心力は<b>静電気力（クーロン力）</b>。<span class="todo">$q_1$・$q_2$ を変えて、②-5 の太陽と地球（万有引力）と比べよう。</span>',
  varCols: [['q1'], ['q2']],
  vars: [
    { k: 'q1', label: '正の電荷 $q_1$', aria: '正の電荷の電気量', min: 1, max: 3, step: 1, def: 1, dec: 0, unit: 'μC' },
    { k: 'q2', label: '負の電荷の大きさ $q_2$', aria: '負の電荷の電気量の大きさ', min: 1, max: 3, step: 1, def: 1, dec: 0, unit: 'μC' }
  ],
  views: null, noDrag: true,
  init: function (s) { s.v.w = m2sqW(s.v); },
  onVar: function (s, k, x) { s.v[k] = x; s.v.w = m2sqW(s.v); return true; },
  height: function (s, w) { return Math.round(clamp(w * 0.70, 300, 460)); },
  msg: function (s) {
    return s.rot ? '負の電荷と一緒に回る観測者には、2 つの電荷は止まって見える。静電気力と遠心力がつり合っている。'
      : '外から見ると、負の電荷は静電気力 $k\\dfrac{q_1q_2}{r^2}$ を向心力として回り続ける。②-5 の万有引力 $G\\dfrac{Mm}{r^2}$ と同じ形。$q_1$・$q_2$ を大きくすると力が大きくなり、速く回る。';
  },
  eqs: function (s) {
    var F = m2sqF(s.v), w = s.v.w, mr = M2SQ.m * M2SQ.r * w * w;
    return {
      in: { h: '【慣性系】円運動している', lines: [{ tag: 'eom', k: '中心方向：', t: 'mr\\omega^2 = k\\dfrac{q_1q_2}{r^2}', cf: 'k\\dfrac{q_1q_2}{r^2}', cfn: '静電気力' }], num: 'いま：' + f3(mr) + ' N ＝ ' + f3(F) + ' N', note: '※ 慣性系に「遠心力」は存在しない' },
      rot: { h: '【非慣性系】止まって見える', lines: [{ tag: 'bal', k: '中心方向：', t: 'k\\dfrac{q_1q_2}{r^2} - \\underbrace{mr\\omega^2}_{\\text{遠心力}} = 0' }], num: 'いま：' + f3(F) + ' − ' + f3(mr) + ' ＝ 0', note: '※ 遠心力は一緒に回る観測者だけが感じる見かけの力' } };
  },
  draw: function (s, ctx, W, H) { drawM2sq(s, ctx, W, H); },
  right: function (s, R) {
    var v = s.v, F = m2sqF(v), w = v.w, T = TAU / w;
    var h = m2Setup(s, {
      lead: { in: '負の電荷（質量 $m$）は正の電荷の周りを半径 $r$ で回る。<b>向心力の役割をするのは静電気力</b> $k\\dfrac{q_1q_2}{r^2}$（異なる符号の電荷は引き合う）。', rot: '負の電荷は止まって見え、外向きの遠心力 $mr\\omega^2$ と静電気力がつり合う。' },
      rows: [{ dir: '中心方向（正の電荷の向き）', in: ['eom', 'mr\\omega^2 = k\\dfrac{q_1q_2}{r^2}', 'k\\dfrac{q_1q_2}{r^2}', '静電気力'], rot: ['bal', 'k\\dfrac{q_1q_2}{r^2} - mr\\omega^2 = 0'] }] });
    h += '<div class="qcard"><p class="qt">いまの値</p><div class="qeq">' + tex('F = k\\dfrac{q_1q_2}{r^2} = \\dfrac{9.0\\times10^{9}\\times' + v.q1 + '\\times10^{-6}\\times' + v.q2 + '\\times10^{-6}}{0.30^2} = ' + f2(F) + '\\ \\text{N}', true) + '</div>' +
      '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('\\omega = \\sqrt{\\dfrac{F}{mr}} = ' + f2(w) + '\\ \\text{rad/s},\\ \\ T = \\dfrac{2\\pi}{\\omega} = ' + f2(T) + '\\ \\text{s}') + '</p>' +
      '<p class="qnote">$q_1$ や $q_2$ を 2 倍にすると、力 $F$ は 2 倍、$\\omega$ は $\\sqrt{2}$ 倍になる。</p></div>';
    h += '<div class="qcard"><p class="qt">万有引力と比べよう（②-5 と ②-6）</p>' +
      '<table class="reltab cmp"><thead><tr><th></th><th>②-5 太陽と地球</th><th>②-6 正電荷と負電荷</th></tr></thead><tbody>' +
      '<tr><th>向心力</th><td>万有引力</td><td>静電気力（クーロン力）</td></tr>' +
      '<tr><th>力の大きさ</th><td>' + tex('G\\dfrac{Mm}{r^2}') + '</td><td>' + tex('k\\dfrac{q_1q_2}{r^2}') + '</td></tr>' +
      '<tr><th>比例定数</th><td>' + tex('G = 6.67\\times10^{-11}') + '<br>N·m²/kg²</td><td>' + tex('k = 9.0\\times10^{9}') + '<br>N·m²/C²</td></tr>' +
      '<tr><th>向き</th><td>いつも引き合う</td><td>異符号は引き合う<br>同符号は退け合う</td></tr>' +
      '<tr><th>運動方程式</th><td>' + tex('mr\\omega^2 = G\\dfrac{Mm}{r^2}') + '</td><td>' + tex('mr\\omega^2 = k\\dfrac{q_1q_2}{r^2}') + '</td></tr>' +
      '</tbody></table>' +
      '<p>どちらも<b>「2 つの量の積に比例し、距離の 2 乗に反比例する」</b>（逆 2 乗の法則）。だから運動方程式も同じ形になり、同じように円運動できる。</p>' +
      '<p class="qnote">水素原子のボーア模型（陽子の周りを電子が回る）も、この形の円運動として考える。</p></div>';
    h += '<p class="assume">' + tex('m = 0.10') + ' kg、' + tex('r = 0.30') + ' m、' + tex('k = 9.0\\times10^{9}') + ' N·m²/C²。正の電荷は動かないとする。重力は考えない。大きさは実際の比ではない。</p>';
    R.innerHTML = mathify(h);
  }
});
function m2sqBall(ctx, x, y, r, pos) {                          /* 電荷の玉（＋は赤、−は青） */
  var g = ctx.createRadialGradient(x - r * 0.35, y - r * 0.35, 1, x, y, r);
  g.addColorStop(0, '#fff'); g.addColorStop(0.4, pos ? '#f19a8f' : '#8fb6f1'); g.addColorStop(1, pos ? '#b83a2e' : '#2a5fb8');
  ctx.save(); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 1.1; ctx.stroke(); ctx.restore();
  /* 「＋」「−」は線で描く（字では小さくて見えにくいため） */
  var hw = r * 0.5; ctx.save(); ctx.strokeStyle = '#fff'; ctx.lineWidth = Math.max(2, r * 0.22); ctx.lineCap = 'round'; ctx.beginPath();
  ctx.moveTo(x - hw, y); ctx.lineTo(x + hw, y); if (pos) { ctx.moveTo(x, y - hw); ctx.lineTo(x, y + hw); } ctx.stroke(); ctx.restore();
}
function drawM2sq(s, ctx, W, H) {
  var v = s.v, ph = m2Ang(s), frame = s.rot ? -ph : 0, cx = W / 2, cy = H / 2 + 8, R = Math.min(W, H) * 0.32, showF = s.ms.showF, prod = v.q1 * v.q2;
  ctx.save(); ctx.fillStyle = '#fbfaf6'; ctx.fillRect(0, 0, W, H); ctx.restore();
  var P = function (x, y) { var X = x * Math.cos(frame) - y * Math.sin(frame), Y = x * Math.sin(frame) + y * Math.cos(frame); return { x: cx + X, y: cy - Y }; };
  /* 方眼（非慣性系ではいっしょに回って見える：②-5 の星と同じ役目） */
  var half = Math.hypot(W, H) / 2 + 20, stp = 28;
  ctx.save(); ctx.lineWidth = 1;
  [false, true].forEach(function (big) {
    ctx.strokeStyle = big ? '#e6dfd2' : '#f1ece3'; ctx.beginPath();
    for (var i = -Math.ceil(half / stp); i <= Math.ceil(half / stp); i++) {
      if ((i % 3 === 0) !== big) continue;
      var a1 = P(i * stp, -half), a2 = P(i * stp, half), b1 = P(-half, i * stp), b2 = P(half, i * stp);
      ctx.moveTo(a1.x, a1.y); ctx.lineTo(a2.x, a2.y); ctx.moveTo(b1.x, b1.y); ctx.lineTo(b2.x, b2.y);
    }
    ctx.stroke();
  });
  ctx.restore();
  ctx.save(); ctx.setLineDash([4, 5]); ctx.strokeStyle = 'rgba(58,65,76,.45)'; ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.stroke(); ctx.restore();
  /* 正の電荷（中心） */
  m2sqBall(ctx, cx, cy, 17, true);
  label(ctx, '正の電荷 +q₁', cx, cy + 32, { size: 12, bold: true, color: '#9c2f24' });
  trailStep(ctx, s, function (x, y) { return P(x, y); }, [R * Math.cos(ph), R * Math.sin(ph), 0], -ph);
  var E = P(R * Math.cos(ph), R * Math.sin(ph)), ux = (E.x - cx) / R, uy = (E.y - cy) / R;
  m2sqBall(ctx, E.x, E.y, 10, false);
  label(ctx, '負の電荷 −q₂', E.x + ux * 70, E.y + uy * 70, { size: 12, bold: true, color: '#1c4386' });   /* 速度の矢印（外がわ 22px）よりさらに外 */
  var LF = R * 0.10 * prod;                                       /* 力の矢印は F（∝ q₁q₂）に比例 */
  if (showF) {
    var af = arrow(ctx, E.x - ux * 11, E.y - uy * 11, E.x - ux * (11 + LF), E.y - uy * (11 + LF), 'force', COL.force);   /* 粒子の「−」と重ならないよう、ふちから出す */
    if (af) sym(ctx, 'F', af.x2 - af.uy * 14, af.y2 + af.ux * 14, { size: 16, color: COL.force, vec: true });
    if (s.rot) { var ac = arrow(ctx, E.x + ux * 11, E.y + uy * 11, E.x + ux * (11 + LF), E.y + uy * (11 + LF), 'fict', COL.cent); if (ac) label(ctx, '遠心力', ac.x2 + ux * 18, ac.y2 + uy * 18, { size: 12, bold: true, color: COL.cent }); }
  }
  if (!s.rot) {
    var tx = uy, ty = -ux;                                          /* 画面での進む向き（左回り） */
    var ox = E.x + ux * 22, oy = E.y + uy * 22, Lv = R * 0.22 * Math.sqrt(prod);
    var av = arrow(ctx, ox - tx * Lv / 2, oy - ty * Lv / 2, ox + tx * Lv / 2, oy + ty * Lv / 2, 'vel');
    if (av) sym(ctx, 'v', av.x2 + av.ux * 11, av.y2 + av.uy * 11, { size: 16, color: COL.vel, vec: true });
    var a0x = E.x - tx * 18, a0y = E.y - ty * 18, aa = arrow(ctx, a0x, a0y, a0x - ux * R * 0.08 * prod, a0y - uy * R * 0.08 * prod, 'acc');
    if (aa) sym(ctx, 'a', aa.x2 - tx * 12, aa.y2 - ty * 12, { size: 15, color: COL.acc, vec: true });
  }
  drawEqualTicks(ctx);
  pill(ctx, s.rot ? '負の電荷と一緒に回る観測者（非慣性系）から見る' : '外（慣性系）から見る', 10, 10, { size: 12, color: s.rot ? '#fff' : COL.ink, bg: s.rot ? COL.cent : '#fff' });
  label(ctx, '大きさは実際の比ではない', W - 8, H - 12, { size: 10.5, color: COL.sub, align: 'right' });
}

/* ===================== セクション7 ローレンツ力と電子（2026-10-05 に 6 → 7。内部の id は m2s6 のまま） ===================== */
/* 一様な磁場 B（z 軸の向き。B < 0 は −z 向き）の中を、電荷 q・質量 m の粒子が速さ v で運動する。ローレンツ力 qvB が向心力。
   運動する面は xy 面（θ = 0）。θ（速度と水平面＝xy 面のなす角）≠ 0 なら、z 方向に等速で進みながら回る「らせん運動」。
   B・v・θ を変えても最初にもどさない：変えた瞬間の位置・速度の向きから、新しい円（らせん）を続ける（区間 segs をつなぐ）。
   電荷の正負・質量 m・|q|・「陽子／電子」を変えたら最初にもどす（2026-10 千葉さん）。
   正の電荷は上から見て右回り（F = qv × B）、負の電荷は左回り */
M2SC.s6 = { F: 0.15, v: 0.40, a: 0.15 };
var M2S6COL = { B: '#2e8b57', f: '#b07d00', I: '#7b3fd4' };   /* 磁場＝緑、ローレンツ力＝金、電流＝むらさき */
/* 「陽子」「電子」：m と |q| は本当の値に固定。速さは ×10⁶ m/s。方眼 1 目盛りはどちらも 1 cm。
   電子の円は 1000 倍に拡大して描く（grid＝図の 1 目盛りが表す本当の長さ［m］。2026-10-05 千葉さん） */
var M2S6PRE = {
  p: { name: '陽子', sign: 1, m: 1.673e-27, q: 1.602e-19, grid: 1e-2, gridTxt: '1 cm', lu: 1e-2, lun: 'cm', mTxt: '1.67 × 10<sup>−27</sup> kg', mTex: '1.67\\times10^{-27}' },
  e: { name: '電子', sign: -1, m: 9.109e-31, q: 1.602e-19, grid: 1e-5, gridTxt: '1 cm', zoom: 1000, lu: 1e-6, lun: 'μm', mTxt: '9.11 × 10<sup>−31</sup> kg', mTex: '9.11\\times10^{-31}' }
};
/* 計算に使う量（陽子・電子のときは、方眼の目盛りを単位にした値。m = 1、|q| = 1 とみなす） */
function m2s6P(s) {
  var v = s.v, th = (90 - m2s6Th(v)) * Math.PI / 180, P = v.pre ? M2S6PRE[v.pre] : null;   /* 中では「xy 面からの角」で計算する（φ は B＝z 軸となす角：2026-10-05 千葉さん訂正） */
  return P ? { m: 1, q: P.sign, u: v.u * P.m * 1e6 / (P.q * P.grid), B: v.B, th: th }
           : { m: v.m, q: v.q * v.qa, u: v.u, B: v.B, th: th };
}
function m2s6Seg0(s) {
  var p = m2s6P(s), up = p.u * Math.cos(p.th), r = Math.abs(p.B) < 1e-9 ? 0 : p.m * up / (Math.abs(p.q) * Math.abs(p.B));
  return { t0: 0, x0: 0, y0: p.q * p.B > 0 ? r : -r, z0: 0, psi0: 0, B: p.B, u: p.u, m: p.m, q: p.q, th: p.th };
}
function m2s6At(s, t) {
  var g = s.segs[0]; s.segs.forEach(function (q) { if (q.t0 <= t + 1e-12) g = q; });
  var k = -g.q * g.B / g.m, tau = t - g.t0, up = g.u * Math.cos(g.th), vz = g.u * Math.sin(g.th), z = g.z0 + vz * tau;
  if (Math.abs(k) < 1e-9) {                             /* B = 0：力がはたらかないので、まっすぐ進む */
    var xs = g.x0 + up * Math.cos(g.psi0) * tau, ys = g.y0 + up * Math.sin(g.psi0) * tau;
    return { x: xs, y: ys, z: z, psi: g.psi0, up: up, vz: vz, cx: xs, cy: ys, r: Infinity, g: g, phi: 0, k: 0 };
  }
  var ps = g.psi0 + k * tau, a = up / k;
  var x = g.x0 + a * (Math.sin(ps) - Math.sin(g.psi0)), y = g.y0 - a * (Math.cos(ps) - Math.cos(g.psi0));
  var cx = g.x0 - a * Math.sin(g.psi0), cy = g.y0 + a * Math.cos(g.psi0);
  return { x: x, y: y, z: z, psi: ps, up: up, vz: vz, cx: cx, cy: cy, r: Math.abs(a), g: g, phi: Math.atan2(y - cy, x - cx), k: k };
}
function m2s6New(s, apply) {                           /* B・v・φ を変える：いまの位置・速度の向きから新しい区間 */
  var st = m2s6At(s, s.t); apply();
  if (s.t <= 1e-9) { s.segs = [m2s6Seg0(s)]; return; }
  s.segs = s.segs.filter(function (q) { return q.t0 < s.t - 1e-12; });
  var p = m2s6P(s); s.segs.push({ t0: s.t, x0: st.x, y0: st.y, z0: st.z, psi0: st.psi, B: p.B, u: p.u, m: p.m, q: p.q, th: p.th });
}
/* らせん：z が ±M2S6ZMAX に着いたら止める（区間をたどって、その時刻を求める） */
var M2S6ZMAX = 8;
/* φ（速度と B＝z 軸のなす角。90° で xy 面内の円運動） */
function m2s6Th(v) { return v.th === undefined || v.th === null ? 90 : v.th; }
function m2s6HasTh(v) { return Math.abs(m2s6Th(v) - 90) > 0.5; }
function m2s6Helix(s) { return s.segs.some(function (g) { return Math.abs(g.th) > 1e-6; }); }
function m2s6TEnd(s) {
  var T = 120;
  for (var i = 0; i < s.segs.length; i++) {
    var g = s.segs[i], t1 = i + 1 < s.segs.length ? s.segs[i + 1].t0 : T, vz = g.u * Math.sin(g.th);
    if (Math.abs(vz) < 1e-9) continue;
    var tz = g.t0 + ((vz > 0 ? M2S6ZMAX : -M2S6ZMAX) - g.z0) / vz;
    if (tz >= g.t0 - 1e-9 && tz <= t1) return Math.max(g.t0, tz);
  }
  return T;
}
/* 「電子のらせん運動を確認」：電子・半径が図いっぱい・2 回転ほどで上の端に着く設定にして再生 */
var M2S6HELIX = { u: 6, th: 75, B: 1, az: -24, el: 16 };   /* φ = 75°（2026-10-06 千葉さん）。半径 3.3 目盛り・ピッチ約 5.6 目盛り（1.5 回転ほどで上の端） */
function m2s6HelixDemo(s) {
  if (s.flem) m2s6FlemClose(s, true);
  s.v.pre = 'e'; s.v.q = -1; s.v.u = M2S6HELIX.u; s.v.th = M2S6HELIX.th; s.v.B = M2S6HELIX.B; s.v.w = Math.abs(s.v.B) / s.v.m || 1e-6;
  m2s6Restart(s); m2s6Q(s);
  if (!s.vdec) { s.vdec = true; s.extra.vdec.classList.add('on'); s.extra.vdec.setAttribute('aria-pressed', 'true'); }
  if (!s.trailOn) { s.trailOn = true; s.extra.trail.classList.add('on'); s.extra.trail.setAttribute('aria-pressed', 'true'); }
  if (!s.ms.showF) m2ForceOn(s);
  s.cam = { az: M2S6HELIX.az, el: M2S6HELIX.el }; (s.vbtns || []).forEach(function (b) { b.classList.remove('on'); });
  if (s.rot) m2SetRot(s, false);
  s.syncSliders(true); s.renderRight();
  var vb = s.R && s.R.querySelector('.vzhost'); if (vb && vb.scrollIntoView) vb.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  SIMS.forEach(function (o) { if (o.playing) { o.playing = false; o.syncPlayLabel(); } });
  s.playing = true; s.syncPlayLabel(); s.draw(); startLoop();
}
function m2s6Restart(s) {                              /* 最初にもどす（軌跡・拡大図も消す） */
  s.endWindow && s.endWindow();
  s.t = 0; s.ph = 0; s.ended = false; s.trail = []; s.segs = [m2s6Seg0(s)];
}
/* ボタンの見た目と、陽子・電子のときの m・|q| のスライダーの固定 */
function m2s6Q(s) {
  var key = (s.v.pre || '') + s.v.q + (s.extra ? 'x' : '') + (s.sl ? 's' : ''); if (s._qKey === key) return; s._qKey = key;
  var v = s.v, on = { qp: !v.pre && v.q > 0, qn: !v.pre && v.q < 0, pp: v.pre === 'p', pe: v.pre === 'e' };
  Object.keys(on).forEach(function (k) { if (s.extra && s.extra[k]) { s.extra[k].classList.toggle('on', on[k]); s.extra[k].setAttribute('aria-pressed', on[k] ? 'true' : 'false'); } });
  ['m', 'qa'].forEach(function (k) {
    var q = s.sl && s.sl[k]; if (!q) return;
    var fix = !!v.pre; q.row.classList.toggle('locked', fix); q.row.classList.toggle('fixed', fix);
    q.inp.disabled = fix; q.dn.disabled = fix; q.up.disabled = fix;
    q.row.title = fix ? M2S6PRE[v.pre].name + 'の値に固定' : '';
  });
}
function m2s6SetQ(s, sign, pre) {
  if ((pre || null) === (s.v.pre || null) && (pre || s.v.q === sign)) return;
  s.v.pre = pre || null; s.v.q = sign;
  m2s6Restart(s); m2s6Q(s); s.syncSliders(true); s.syncPlayLabel(); s.draw(); s.renderRight();
}
/* 1.23 × 10^n（HTML の上つき） */
function m2s6Sci(x, d) {
  if (!isFinite(x) || x === 0) return fmt(x, d || 2);
  var n = Math.floor(Math.log10(Math.abs(x))), m = x / Math.pow(10, n);
  if (Math.abs(m) >= 9.995) { m /= 10; n++; }
  return fmt(m, d || 2) + ' × 10<sup>' + (n < 0 ? '−' + (-n) : n) + '</sup>';
}
function m2s6SciTex(x, d) {
  if (!isFinite(x) || x === 0) return fmt(x, d || 2);
  var n = Math.floor(Math.log10(Math.abs(x))), m = x / Math.pow(10, n);
  if (Math.abs(m) >= 9.995) { m /= 10; n++; }
  return fmt(m, d || 2) + '\\times10^{' + n + '}';
}
DEFS.m2s6 = m2Base({
  id: 'm2s6', num: 7, title: 'ローレンツ力と電子',
  desc: '一様な磁場 $\\vec{B}$（$z$ 軸の向き）の中で、電荷 $q$ をもつ粒子（陽子や電子など）が $xy$ 面内を速さ $v$ で動く。向心力は<b>ローレンツ力 $qvB$</b>。<span class="todo">$B$・$v$・$m$・$|q|$ を変えたり電荷の正負を切りかえたりして、軌跡の半径と回る向きの変化を見よう。速度と磁場のなす角 $\\varphi$ を $90^\\circ$ 以外にすると、らせん運動になる。</span>',
  varCols: [['B', 'u', 'th'], ['m', 'qa']],
  vars: [
    { k: 'B', label: '磁束密度 $B$（$+z$ 向きが正）', aria: '磁束密度', min: -4, max: 4, step: 1, def: 1, dec: 0, unit: 'T',
      fmt: function (x) { return x < -1e-9 ? '<span class="negv">' + fmt(x, 0) + ' T</span>' : fmt(x, 0) + ' T'; } },
    { k: 'u', label: '速さ $v$', aria: '速さ', min: 1, max: 6, step: 1, def: 4, dec: 0, unit: 'm/s',
      fmt: function (x, s) { return fmt(x, 0) + (s && s.v.pre ? ' × 10<sup>6</sup> m/s' : ' m/s'); } },
    { k: 'th', label: '速度と磁場（$z$ 軸）のなす角 $\\varphi$', aria: '速度と磁場のなす角', min: 0, max: 90, step: 15, def: 90, dec: 0, unit: '°',
      fmt: function (x) { return fmt(x, 0) + '°'; } },
    { k: 'm', label: '質量 $m$', aria: '質量', min: 1, max: 4, step: 1, def: 1, dec: 0, unit: 'kg',
      fmt: function (x, s) { return s && s.v.pre ? M2S6PRE[s.v.pre].mTxt : fmt(x, 0) + ' kg'; } },
    { k: 'qa', label: '電気量の大きさ $|q|$', aria: '電気量の大きさ', min: 1, max: 4, step: 1, def: 1, dec: 0, unit: 'C',
      fmt: function (x, s) { return s && s.v.pre ? '1.60 × 10<sup>−19</sup> C' : fmt(x, 0) + ' C'; } }
  ],
  views: [{ label: '斜め上から', az: -24, el: 34 }, { label: '真上から', az: 0, el: 90 }, { label: '真横から', az: 0, el: 0 }],
  trailSec: 4, keepOnChange: true, trailBtn: true,
  tEnd: function (s) { return s.segs ? m2s6TEnd(s) : 120; },
  init: function (s) { s.v.q = 1; s.v.pre = null; s.vdec = false; s.v.w = Math.abs(s.v.B) / s.v.m || 1e-6; s.segs = [m2s6Seg0(s)]; s.flem = null; m2s6Q(s);
    if (s.extra && s.extra.vdec) { s.extra.vdec.classList.remove('on'); s.extra.vdec.setAttribute('aria-pressed', 'false'); }
    if (s.extra && s.extra.flem) { s.extra.flem.innerHTML = M2S6FLEMB; s.extra.flem.classList.remove('on'); } },
  buttons: [
    { k: 'qp', label: '<i>＋</i>正の電荷', cls: 'qsw qplus', top: true, topLabel: '粒子の電荷：', onClick: function (s) { m2s6SetQ(s, 1, null); } },
    { k: 'qn', label: '<i>−</i>負の電荷', cls: 'qsw qminus', top: true, onClick: function (s) { m2s6SetQ(s, -1, null); } },
    { k: 'pp', label: '<i>＋</i>陽子', cls: 'qsw qplus qpre qpre0', top: true, onClick: function (s) { m2s6SetQ(s, 1, 'p'); } },
    { k: 'pe', label: '<i>−</i>電子', cls: 'qsw qminus qpre', top: true, onClick: function (s) { m2s6SetQ(s, -1, 'e'); } },
    { k: 'vdec', label: '速度を分解する', cls: 'chkb', onClick: function (s, b) { b.classList.remove('glowpick'); s.vdecSeen = true; s.vdec = !s.vdec; b.classList.toggle('on', s.vdec); b.setAttribute('aria-pressed', s.vdec ? 'true' : 'false'); s.renderRight(); s.draw(); } },
    { k: 'flem', label: '✋ フレミング左手を確認', cls: 'flemb', inCanvas: true, onClick: function (s) { m2s6Flem(s); } },
    { k: 'helix', label: '🌀 電子のらせん運動を確認', cls: 'flemb helixb', inCanvas: true, onClick: function (s) { m2s6HelixDemo(s); } }
  ],
  onVar: function (s, k, x) {
    if (k === 'm' || k === 'qa') { if (s.v.pre) return false; s.v[k] = x; s.v.w = Math.abs(s.v.B) / s.v.m || 1e-6; return true; }
    m2s6New(s, function () { s.v[k] = x; s.v.w = Math.abs(s.v.B) / s.v.m || 1e-6; }); return true;
  },
  onChanged: function (s, k) {
    if (k === 'm' || k === 'qa') { m2s6Restart(s); return 'reset'; }   /* 質量・電気量を変えたら最初にもどす */
  },
  onReset: function (s) { s.segs = [m2s6Seg0(s)]; },
  afterBuild: function (s) { m2s6Q(s); },
  msg: function (s) {
    var st = m2s6At(s, s.t), P = s.v.pre ? M2S6PRE[s.v.pre] : null;
    if (s.ended && Math.abs(st.z) >= M2S6ZMAX - 1e-6) return '<b>らせんの' + (st.z > 0 ? '上' : '下') + 'の端に着いたので止めた。</b>▶ で最初から。磁場に平行な成分 $v\\cos\\varphi$ のぶん、$z$ 方向に等速で進んでいる。';
    if (!isFinite(st.r)) return '$B = 0$ なのでローレンツ力がはたらかず、粒子はまっすぐ進む（等速直線運動）。';
    var cw = st.g.q * st.g.B > 0, th = m2s6Th(s.v);
    var rTxt = P ? '$r = ' + fmt(st.r * P.grid / P.lu, 2) + '$ ' + P.lun : '$r = \\dfrac{mv}{|q||B|} = ' + f2(st.r) + '$ m';
    return rTxt + '。磁場は ' + (s.v.B > 0 ? '$+z$ 向き' : '$-z$ 向き') + '、電荷は' + (st.g.q > 0 ? '正' : '負') + 'なので、上から見て<b>' + (cw ? '右回り' : '左回り') + '</b>。' +
      (Math.abs(th - 90) > 0.5 ? '$\\varphi = ' + fmt(th, 0) + '^\\circ$（$90^\\circ$ でない）なので、$z$ 方向に進みながら回る<b>らせん運動</b>。' : '$|B|$ を大きくすると半径が小さく、$v$ や $m$ を大きくすると半径が大きくなる。') +
      (P ? (P.zoom ? '電子の円は 1000 倍に拡大して描いている（実際はこの 1/1000）。' : '') + '（アニメは実際よりとてもゆっくり）' : '');
  },
  eqs: function (s) {
    var v = s.v, st = m2s6At(s, s.t), g = st.g, P = v.pre ? M2S6PRE[v.pre] : null, th = m2s6HasTh(v);
    var vv = th ? 'v\\sin\\varphi\\,' : 'v', lhs = 'm\\dfrac{(' + vv + ')^2}{r}', lhs0 = th ? lhs : 'm\\dfrac{v^2}{r}';
    var f, mv;
    if (P) { var vr = v.u * 1e6 * Math.cos(g.th); f = P.q * vr * Math.abs(v.B); mv = isFinite(st.r) ? P.m * vr * vr / (st.r * P.grid) : 0; }
    else { f = Math.abs(g.q) * st.up * Math.abs(v.B); mv = isFinite(st.r) ? g.m * st.up * st.up / st.r : 0; }
    var nf = P ? m2s6Sci(mv) + ' N ＝ ' + m2s6Sci(f) + ' N' : f2(mv) + ' N ＝ ' + f2(f) + ' N';
    var nr = P ? m2s6Sci(f) + ' − ' + m2s6Sci(mv) + ' ＝ 0' : f2(f) + ' − ' + f2(mv) + ' ＝ 0';
    return {
      in: { h: '【慣性系】円運動している', lines: [{ tag: 'eom', k: '中心方向：', t: lhs0 + ' = q' + vv + 'B', cf: 'q' + vv + 'B', cfn: 'ローレンツ力' }], num: 'いま：' + nf, note: '※ 慣性系に「遠心力」は存在しない' },
      rot: { h: '【非慣性系】止まって見える', lines: [{ tag: 'bal', k: '中心方向：', t: 'q' + vv + 'B - \\underbrace{' + lhs0 + '}_{\\text{遠心力}} = 0' }], num: 'いま：' + nr, note: '※ 遠心力は一緒に回る観測者だけが感じる見かけの力' } };
  },
  draw: function (s, ctx, W, H) { drawM2s6(s, ctx, W, H); },
  right: function (s, R) { rightM2s6(s, R); }
});
function rightM2s6(s, R) {
  var v = s.v, P = v.pre ? M2S6PRE[v.pre] : null, aB = Math.max(Math.abs(v.B), 1e-9), th = m2s6Th(v) * Math.PI / 180, hasTh = m2s6HasTh(v);
  var h = m2Setup(s, {
    lead: { in: '粒子は半径 $r$ の等速円運動。<b>向心力の役割をするのはローレンツ力 $qvB$</b>。ローレンツ力はいつも速度に垂直なので、速さは変わらない。', rot: '粒子は止まって見える。外向きの遠心力 $m\\dfrac{v^2}{r}$ とローレンツ力 $qvB$ がつり合う。' },
    rows: [{ dir: '中心方向', in: ['eom', 'm\\dfrac{v^2}{r} = qvB', 'qvB', 'ローレンツ力'], rot: ['bal', 'qvB - m\\dfrac{v^2}{r} = 0'] }] });
  /* 「速度を分解して考える」「回る向き」は立式カードのすぐ下（左のアニメと見くらべられるように。2026-10-05 千葉さん） */
  if (hasTh) {                                                     /* φ ≠ 90° のときだけ：速度を B に平行・垂直に分ける（らせん運動） */
    var up = 'v\\sin\\varphi', vz = 'v\\cos\\varphi';
    h += '<div class="qcard"><p class="qt">速度を分解して考える（らせん運動）</p>' +
      '<p>速度 $\\vec{v}$ を、<b>磁場 $\\vec{B}$ に垂直な成分 $' + up + '$</b>（$xy$ 面内）と、<b>磁場に平行な成分 $' + vz + '$</b>（$z$ 方向）に分ける。</p>' +
      '<p>・<b>垂直な成分</b>だけがローレンツ力 $f = q(' + up + ')B$ を受ける → $xy$ 面内では半径 $r = \\dfrac{m' + up + '}{qB}$ の等速円運動。</p>' +
      '<p>・<b>平行な成分</b>は力を受けない → $z$ 方向には速さ $' + vz + '$ の等速直線運動。</p>' +
      '<p>2 つを合わせると<b>らせん運動</b>。1 回転する間（周期 $T$）に $z$ 方向へ進む距離（ピッチ）は</p>' +
      '<div class="qeq">' + tex('p = (' + vz + ')\\,T = \\dfrac{2\\pi m' + vz + '}{qB}', true) + '</div>' +
      (s.vdec ? '<div class="flemhost vzhost"><canvas class="vzcv" aria-label="粒子の周りの拡大図"></canvas></div>' : '<p class="qnote">「速度を分解する」を押すと、図に 2 つの成分が出て、ここに粒子の周りの拡大図が出る。</p>') + '</div>';
  }
  h += '<div class="qcard flemcard"><p class="qt">回る向き</p><p>ローレンツ力の向きは、フレミングの左手の法則（$\\vec{F} = q\\vec{v}\\times\\vec{B}$）で決まる。磁場が $+z$ 向きなら、正の電荷は上から見て右回り、負の電荷（電子）は左回り。負の電荷の場合、電流の向きは粒子の運動と逆向きであることに注意。</p>' +
    (s.flem ? '<div class="flemhost"><canvas class="flemcv" aria-label="フレミングの左手の法則の図"></canvas></div>' : '<p class="qnote"><b>図の左上の「フレミング左手を確認」</b>を押すと、ここに左手の図が出る（円運動の図と一緒に見られる）。</p>') + '</div>';
  var now;
  if (Math.abs(v.B) < 1e-9) now = '$B = 0$ のときは円運動しない（まっすぐ進む）';
  else if (P) {
    var vr = v.u * 1e6, rr = P.m * vr * Math.sin(th) / (P.q * aB), TT = TAU * P.m / (P.q * aB);
    now = tex('r = \\dfrac{' + P.mTex + '\\times' + fmt(v.u, 1) + '\\times10^{6}' + (hasTh ? '\\sin' + fmt(v.th, 0) + '^\\circ' : '') + '}{1.60\\times10^{-19}\\times' + fmt(aB, 1) + '} = ' + fmt(rr / P.lu, 2) + (P.lun === 'μm' ? '\\ \\mu\\text{m}' : '\\ \\text{' + P.lun + '}')) +
      '<br>' + tex('T = \\dfrac{2\\pi m}{qB} = ' + m2s6SciTex(TT) + '\\ \\text{s}');
  } else {
    var r = v.m * v.u * Math.sin(th) / (v.qa * aB), T = TAU * v.m / (v.qa * aB);
    now = tex('r = \\dfrac{' + fmt(v.m, 1) + '\\times' + fmt(v.u, 1) + (hasTh ? '\\sin' + fmt(v.th, 0) + '^\\circ' : '') + '}{' + fmt(v.qa, 1) + '\\times' + fmt(aB, 1) + '} = ' + f2(r) + '\\ \\text{m},\\ \\ T = ' + f2(T) + '\\ \\text{s}');
  }
  h += '<div class="qcard"><p class="qt">半径と周期</p><p>運動方程式を $r$ について解くと' + (hasTh ? '（$\\varphi \\ne 90^\\circ$ のときは $v$ を $v\\sin\\varphi$ にかえる）' : '') + '</p><div class="qeq">' + tex('r = \\dfrac{mv}{qB},\\qquad T = \\dfrac{2\\pi r}{v} = \\dfrac{2\\pi m}{qB}', true) + '</div>' +
    '<p class="qnow"><span class="qtag now">いまの値</span>' + now + '</p>' +
    '<p class="qnote">周期 $T$ は<b>速さ $v$ によらない</b>（速いと半径が大きくなり、1 周の長さも長くなるため）。サイクロトロンはこの性質を使っている。</p>' +
    (P ? '<p class="qnote"><b>' + P.name + '</b>：質量と電気量は本当の値。方眼 1 目盛り ＝ 1 cm。' + (P.zoom ? '電子の円はとても小さいので、<b>1000 倍に拡大して</b>描いている（実際の半径は図の 1/1000）。' : '') + '1 周の時間は本当はとても短い（上の $T$）ので、アニメはゆっくりにしている。</p>' : '') + '</div>';
  h += '<p class="assume">' + (P ? P.name + 'の質量と電気量は本当の値。' : '見やすくするため、質量・電気量・速さ・磁束密度は扱いやすい数値にした。') + '重力は考えない。緑の矢印が磁場 ' + tex('\\vec{B}') + '、金色の矢印がローレンツ力。磁場は ' + tex('z') + ' 軸の向き、運動する面は ' + tex('xy') + ' 面。</p>';
  R.innerHTML = mathify(h);
  s.flemCv = R.querySelector('.flemcv'); s.flemBox = R.querySelector('.flemcard');
  s.vzCv = R.querySelector('.vzcv');
  if (s.vzCv) { m2s6FlemBind(s, s.vzCv); m2s6VzPanel(s, m2s6At(s, s.t)); }
  if (s.flemCv) { m2s6FlemBind(s, s.flemCv); m2s6FlemPanel(s, m2s6At(s, s.t)); }
}
function drawM2s6(s, ctx, W, H) {
  var st = m2s6At(s, s.t), v = s.v, g = st.g, showF = s.ms.showF, HALF = 7, P = v.pre ? M2S6PRE[v.pre] : null;
  m2s6Q(s);                                                     /* 電荷のボタンの見た目・スライダーの固定をいまの値にそろえる */
  /* 「速度を分解する」は φ ≠ 90° のときだけ出す。出てきたら押すまで光らせる（2026-10-05 千葉さん） */
  if (s.extra && s.extra.vdec) {
    var thOn = m2s6HasTh(v), vb0 = s.extra.vdec;
    if (vb0.hidden === thOn) { vb0.hidden = !thOn; vb0.classList.toggle('glowpick', thOn && !s.vdec && !s.vdecSeen); }
  }
  var frame = s.rot ? -st.phi : 0, ox = s.rot ? st.cx : 0, oy = s.rot ? st.cy : 0, oz = 0;
  var thS = 90 - m2s6Th(v);                                      /* xy 面からの角（正なら上へ進む） */                                        /* らせんのときは、上（下）の端 M2S6ZMAX までが入るように縦を広げる */
  var sc = scene3d(s, W, H, [{ R: HALF * 1.42, z0: thS < -0.5 ? -M2S6ZMAX : 0, z1: thS > 0.5 ? M2S6ZMAX : 1.6 }], frame);
  var Q = function (x, y, z) { return PP(sc, x - ox, y - oy, (z || 0) - oz); };
  s.trailWin = m2s6Helix(s) ? 200 : 0;                          /* らせんは全部残す（ばねの形を見せる） */
  /* 運動する面（粒子と同じ高さの xy 面。方眼）と磁場（緑の矢印） */
  var c4 = [[-HALF, -HALF], [HALF, -HALF], [HALF, HALF], [-HALF, HALF]].map(function (q) { return PP(sc, q[0], q[1], 0); });
  /* らせんで上へ進むとき、これまでの軌跡は面より下：先に描いて、半透明の面ごしに見せる */
  var below = g.th < -1e-6, trailFn = function () { trailStep(ctx, s, function (x, y, z) { return PP(sc, x, y, z - oz); }, [st.x, st.y, st.z], -st.phi, [st.x - st.cx, st.y - st.cy, st.z]); };
  if (below) trailFn();
  ctx.save(); ctx.beginPath(); c4.forEach(function (q, i) { i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y); }); ctx.closePath(); ctx.fillStyle = below ? 'rgba(251,250,246,.78)' : '#fbfaf6'; ctx.fill(); ctx.clip();
  for (var gi = -HALF; gi <= HALF; gi++) { ctx.strokeStyle = (gi % 3 === 0) ? '#e6dfd2' : '#f1ece3'; ctx.lineWidth = 1;
    var a1 = PP(sc, gi, -HALF, 0), a2 = PP(sc, gi, HALF, 0), b1 = PP(sc, -HALF, gi, 0), b2 = PP(sc, HALF, gi, 0); ctx.beginPath(); ctx.moveTo(a1.x, a1.y); ctx.lineTo(a2.x, a2.y); ctx.moveTo(b1.x, b1.y); ctx.lineTo(b2.x, b2.y); ctx.stroke(); }
  ctx.restore();
  ctx.save(); ctx.beginPath(); c4.forEach(function (q, i) { i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y); }); ctx.closePath(); ctx.strokeStyle = '#cfc8bb'; ctx.stroke(); ctx.restore();
  /* x・y・z 軸（方眼の手前の角）。z が磁場の向き */
  if (!s.rot) {
    var o3 = [-HALF + 0.7, -HALF + 0.7, 0], AX = [[1, 0, 0, 'x'], [0, 1, 0, 'y'], [0, 0, 1, 'z']];
    AX.forEach(function (q) {
      if (sc.top && q[3] === 'z') return;
      var a = PP(sc, o3[0], o3[1], 0), b = PP(sc, o3[0] + q[0] * 1.8, o3[1] + q[1] * 1.8, q[2] * 1.8);
      var ar = arrow(ctx, a.x, a.y, b.x, b.y, 'dim', '#3a414c');
      if (ar) sym(ctx, q[3], b.x + ar.ux * 10, b.y + ar.uy * 10, { size: 15, color: '#3a414c' });
    });
  }
  var bArrows = [];
  for (var bx = -HALF + 1; bx <= HALF - 0.5; bx += 2.4) for (var by = -HALF + 1; by <= HALF - 0.5; by += 2.4) bArrows.push([bx, by]);
  var Bl = (0.4 + 0.25 * Math.abs(v.B)) * (v.B >= 0 ? 1 : -1);   /* 磁場の矢印：|B| に比例して少し長く。B < 0 は下向き */
  if (Math.abs(v.B) > 1e-9) {
    if (sc.top) {                                               /* 真上からは ⊙（+z 向き＝紙面の裏から表へ）／⊗（−z 向き） */
      bArrows.forEach(function (q) { var p = PP(sc, q[0], q[1], 0); ctx.save(); ctx.strokeStyle = M2S6COL.B; ctx.fillStyle = M2S6COL.B; ctx.globalAlpha = 0.6; ctx.lineWidth = 1.4;
        ctx.beginPath(); ctx.arc(p.x, p.y, 6, 0, TAU); ctx.stroke();
        if (v.B > 0) { ctx.beginPath(); ctx.arc(p.x, p.y, 1.8, 0, TAU); ctx.fill(); } else { ctx.beginPath(); ctx.moveTo(p.x - 4, p.y - 4); ctx.lineTo(p.x + 4, p.y + 4); ctx.moveTo(p.x + 4, p.y - 4); ctx.lineTo(p.x - 4, p.y + 4); ctx.stroke(); }
        ctx.restore(); });
    } else bArrows.forEach(function (q) { var p0 = PP(sc, q[0], q[1], 0), p1 = PP(sc, q[0], q[1], Bl); ctx.save(); ctx.globalAlpha = 0.55; arrow(ctx, p0.x, p0.y, p1.x, p1.y, 'comp', M2S6COL.B); ctx.restore(); });   /* 力ではないので等長マークの対象にしない */
    var bl = PP(sc, HALF - 1.5, HALF - 1.5, sc.top ? 0 : Bl); sym(ctx, 'B', bl.x + 12, bl.y - 4, { size: 17, color: M2S6COL.B, vec: true });
  }
  var hdIn = observer3(ctx, sc, [-HALF + 2 - ox, HALF - 1.5 - oy, 0], 2.2, '外の観測者', !s.rot, { dy: 2 });   /* 奥の左（右下の凡例と重ならないように） */
  var hasTh = Math.abs(g.th) > 1e-6;
  /* いまの円（破線）と中心。らせんのときは中心を通る z 軸に平行な線も */
  if (isFinite(st.r)) {
    ctx.save(); ctx.setLineDash([5, 5]); ctx.strokeStyle = '#8a929c'; ctx.lineWidth = 1.2; ctx.beginPath();
    for (var i = 0; i <= 96; i++) { var aa = TAU * i / 96, pq = Q(st.cx + st.r * Math.cos(aa), st.cy + st.r * Math.sin(aa), st.z); i ? ctx.lineTo(pq.x, pq.y) : ctx.moveTo(pq.x, pq.y); }
    ctx.stroke(); ctx.restore();
    var Cp = Q(st.cx, st.cy, st.z); ctx.save(); ctx.fillStyle = '#2b323c'; ctx.beginPath(); ctx.arc(Cp.x, Cp.y, 2.8, 0, TAU); ctx.fill(); ctx.restore();
    if (hasTh && !sc.top) {                                     /* らせん：まわりの円柱（上と下の円・両わきの線）、中心の軸、いちばん右の点から上へ z 軸 */
      var zA = thS < 0 ? -M2S6ZMAX : 0, zB = thS > 0 ? M2S6ZMAX : 0, z1 = Q(st.cx, st.cy, zA), z2 = Q(st.cx, st.cy, zB);
      ctx.save(); ctx.setLineDash([2, 5]); ctx.strokeStyle = '#8a929c'; ctx.beginPath(); ctx.moveTo(z1.x, z1.y); ctx.lineTo(z2.x, z2.y); ctx.stroke(); ctx.restore();
      var ring = function (z) { var pts = []; for (var i2 = 0; i2 <= 72; i2++) { var a7 = TAU * i2 / 72; pts.push(Q(st.cx + st.r * Math.cos(a7), st.cy + st.r * Math.sin(a7), z)); } return pts; };
      var rA = ring(zA), rB = ring(zB), iL = 0, iR = 0;
      rA.forEach(function (p, i3) { if (p.x < rA[iL].x) iL = i3; if (p.x > rA[iR].x) iR = i3; });
      ctx.save(); ctx.setLineDash([4, 5]); ctx.strokeStyle = 'rgba(111,119,130,.55)'; ctx.lineWidth = 1;
      [rA, rB].forEach(function (rg) { ctx.beginPath(); rg.forEach(function (p, i4) { i4 ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y); }); ctx.stroke(); });
      ctx.beginPath(); ctx.moveTo(rA[iL].x, rA[iL].y); ctx.lineTo(rB[iL].x, rB[iL].y); ctx.moveTo(rA[iR].x, rA[iR].y); ctx.lineTo(rB[iR].x, rB[iR].y); ctx.stroke(); ctx.restore();
      if (!s.rot) {
        var zr0 = Q(st.cx + st.r, st.cy, zA), zr1 = Q(st.cx + st.r, st.cy, (thS > 0 ? M2S6ZMAX + 1.2 : 1.6));
        var za = arrow(ctx, zr0.x, zr0.y, zr1.x, zr1.y, 'dim', '#2b323c');
        if (za) sym(ctx, 'z', zr1.x + 10, zr1.y + 4, { size: 16, color: '#2b323c', tail: '（磁場の向き）' });
      }
    }
  }
  /* 軌跡（回転系では、回る中心から見た道すじ）。らせんは高さもいっしょに */
  if (!below) trailFn();
  /* 粒子 */
  var rb = 0.28, P0 = Q(st.x, st.y, st.z);
  ctx.save(); var gg = ctx.createRadialGradient(P0.x - 3, P0.y - 3, 1, P0.x, P0.y, rb * sc.S);
  gg.addColorStop(0, '#fff'); gg.addColorStop(0.4, g.q > 0 ? '#f19a8f' : '#8fb6f1'); gg.addColorStop(1, g.q > 0 ? '#b83a2e' : '#2a5fb8');
  ctx.fillStyle = gg; ctx.beginPath(); ctx.arc(P0.x, P0.y, rb * sc.S, 0, TAU); ctx.fill(); ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 1.1; ctx.stroke(); ctx.restore();
  label(ctx, g.q > 0 ? '+' : '−', P0.x, P0.y, { size: 13, bold: true, color: '#fff', halo: false });
  var rr = isFinite(st.r) && st.r > 1e-9 ? st.r : 1;
  var ur = [(st.x - st.cx) / rr, (st.y - st.cy) / rr, 0], uv = [Math.cos(st.psi), Math.sin(st.psi), 0];
  var hdRot = observer3(ctx, sc, [st.x - uv[0] * 0.35 - ox, st.y - uv[1] * 0.35 - oy, st.z + rb], 1.1, '', s.rot);   /* 一緒に回る観測者は粒子の上に乗る */
  var c3 = [st.x, st.y, st.z], f = Math.abs(g.q) * st.up * Math.abs(v.B);
  var A3 = function (p0, d, L, kind, col, opt) { return arrow3(ctx, sc, [p0[0] - ox, p0[1] - oy, p0[2] - oz], d, L, kind, col, opt); };
  if (showF && isFinite(st.r)) {
    var af = A3([st.x - ur[0] * rb, st.y - ur[1] * rb, st.z], [-ur[0], -ur[1], 0], f * M2SC.s6.F, 'force', M2S6COL.f);
    if (af) tipLabel(ctx, af, 'F', M2S6COL.f, { off: 13 });
    if (s.rot) centLabel(ctx, A3(c3, ur, g.m * st.up * st.up / st.r * M2SC.s6.F, 'fict', COL.cent), s);
  }
  if (!s.rot) {
    /* 速度：粒子の外側・少し上に、速度と平行に（観測者の描き方ルール：粒子と重ねない） */
    var ct = Math.cos(g.th), stt = Math.sin(g.th), d3 = [uv[0] * ct, uv[1] * ct, stt];
    var vc = [st.x + ur[0] * 0.9, st.y + ur[1] * 0.9, st.z + 0.4], Lv = g.u * M2SC.s6.v;
    var vt = [vc[0] - d3[0] * Lv / 2, vc[1] - d3[1] * Lv / 2, vc[2] - d3[2] * Lv / 2];
    var va = Q(vt[0], vt[1], vt[2]), vb = Q(vt[0] + d3[0] * Lv, vt[1] + d3[1] * Lv, vt[2] + d3[2] * Lv);
    var av = arrow(ctx, va.x, va.y, vb.x, vb.y, 'vel'); tipLabel(ctx, av, 'v', COL.vel, { off: 11 });
    if (s.vdec) {                                                 /* 速度を分解：xy 面内（B に垂直）と z 方向（B に平行） */
      var ah = A3(vt, [uv[0], uv[1], 0], g.u * ct * M2SC.s6.v, 'comp', COL.vel, { noShift: true });
      if (ah) label(ctx, 'v sinφ', (ah.x1 + ah.x2) / 2 + ah.uy * 14, (ah.y1 + ah.y2) / 2 - ah.ux * 14 + 4, { size: 11.5, bold: true, color: COL.vel });
      if (Math.abs(stt) > 1e-6) {
        var az = A3(vt, [0, 0, stt > 0 ? 1 : -1], g.u * Math.abs(stt) * M2SC.s6.v, 'comp', COL.vel, { noShift: true });
        if (az) label(ctx, 'v cosφ', Math.min(az.x1, az.x2) - 8, (az.y1 + az.y2) / 2, { size: 11.5, bold: true, color: COL.vel, align: 'right' });
        var tA = Q(vt[0] + uv[0] * g.u * ct * M2SC.s6.v, vt[1] + uv[1] * g.u * ct * M2SC.s6.v, vt[2]);   /* 平行四辺形の補助線 */
        ctx.save(); ctx.setLineDash([3, 3]); ctx.strokeStyle = 'rgba(22,99,181,.6)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(tA.x, tA.y); ctx.lineTo(vb.x, vb.y);
        if (az) { ctx.moveTo(az.x2, az.y2); ctx.lineTo(vb.x, vb.y); } ctx.stroke(); ctx.restore();
      }
    }
  }
  drawEqualTicks(ctx);
  m2Speech(ctx, s, hdIn, hdRot, null);
  /* 目立つ場所に「緑の矢印＝磁場」（2026-10-04 千葉さん） */
  /* 凡例は図の右下（2026-10-05 千葉さん） */
  pill(ctx, Math.abs(v.B) < 1e-9 ? '磁場なし（B = 0）' : '緑の矢印 ＝ 磁場 B（' + (v.B > 0 ? '+z 向き' : '−z 向き') + '）', W - 10, H - (W < 480 ? 96 : 64), { size: 12, color: '#1f6b43', bg: '#e8f5ee', border: 'rgba(46,139,87,.65)', align: 'right' });
  pill(ctx, '金色の矢印 ＝ ローレンツ力 F', W - 10, H - (W < 480 ? 66 : 34), { size: 11.5, color: '#7a5600', bg: '#fbf3dc', border: 'rgba(176,125,0,.55)', align: 'right' });
  pill(ctx, '方眼 1 目盛り ＝ ' + (P ? '1 cm' : '1 m') + (P && P.zoom ? '（電子の円は 1000 倍に拡大）' : ''), 10, H - 34, { size: 11, color: COL.ink2 });
  if (s.flem) m2s6FlemPanel(s, st);                             /* 右の列の「回る向き」の中の左手の図（アニメといっしょに動く） */
  if (s.vzCv) m2s6VzPanel(s, st);                               /* 右の列の「速度を分解して考える」の中の拡大図 */
}
