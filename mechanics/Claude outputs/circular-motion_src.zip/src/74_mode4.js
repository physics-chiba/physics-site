/* =========================================================================
   74_mode4.js … モード4「最高点まで昇る条件」（2026-10-06 作り直し）
   目的：プリント「☆円運動で考えるべき条件とその理由」を伝える。円運動中の速さ v と、垂直抗力 N（糸なら張力 S）を、
   角 θ（最下点から）の関数としてグラフで比べる。他のモードとはレイアウトが違う（80_page.js の d.custom）。
   4-1 なめらかな円筒面（3-1 と同じ、左側のない円筒面。軌道 M3.b1）、4-2 糸による円運動（最下点から打ち出す。軌道 M3.b5）。
   どちらも ① 最高点まで（v0 ≥ √5gr）② θ ≤ 90° の点まで（v0 ≤ √2gr、折り返す）③ 90° ≤ θ ≤ 180° の点まで（離れる・たるむ）の 3 つの図。
   v0 のスライダーは 3 つとも同じ見た目（3-1 と同じ範囲・√2gr・√5gr の目印）で、選べる範囲だけが場面ごとに狭い（vd.allow）。
   ========================================================================= */
'use strict';
/* N（または S）と角 θ の関係：F(θ) = (m/r){v0² + gr(3cosθ − 2)}、v² = v0² − 2gr(1 − cosθ) */
function m4F(v0, th) { return M3.m / M3.R * (v0 * v0 + G * M3.R * (3 * Math.cos(th) - 2)); }
function m4V2(v0, th) { return v0 * v0 - 2 * G * M3.R * (1 - Math.cos(th)); }
function m4VNow(v0, th) { return Math.sqrt(Math.max(0, m4V2(v0, th))); }
function m4Deg(th) { return fmt(th * 180 / Math.PI, 0); }
var M4PDF = 'pdf/circular-motion-conditions.pdf';               /* 理論的背景のプリント（mechanics/pdf/ に置く） */
var M4A = {
  allow: { 1: { lo: 4.95, hi: 6.0 }, 2: { lo: 1.0, hi: 3.13 }, 3: { lo: 3.15, hi: 4.90 } },   /* 端は √5gr・√2gr の小数第 2 位 */
  def: { 1: 5.5, 2: 2.5, 3: 4.0 },
  thStop: function (v0) { return Math.acos(clamp(1 - v0 * v0 / (2 * G * M3.R), -1, 1)); },          /* 速さが 0 になる角 */
  thOff: function (v0) { return Math.acos(clamp((2 * G * M3.R - v0 * v0) / (3 * G * M3.R), -1, 1)); } /* N（S）が 0 になる角 */
};
/* 面（N）と糸（S）で変わる言葉 */
var M4K = {
  N: { sec: 1, F: 'N', fName: '垂直抗力', col: '#7b3fd4', off: '面から離れる', offd: '面から離れた', offing: '面から離れて', keep: '面に触れている', noOff: '面から離れない',
       back: '面にそって滑り戻る', tag3: '面から離れる', inst3: '⏱ 離れる瞬間<br>をスローで' },
  S: { sec: 5, F: 'S', fName: '張力', col: '#c2367f', off: '糸がたるむ', offd: '糸がたるんだ', offing: '糸がたるんで', keep: '糸が張っている', noOff: '糸はたるまない',
       back: '振り子のように戻る', tag3: '糸がたるむ', inst3: '⏱ たるむ瞬間<br>をスローで' }
};
function m4K(s) { return M4K[s.def.fk]; }

/* いまの角（グラフの点）。円の上にいなければ、直前・直後の角（白抜きの点） */
function m4ThNow(s) {
  var tr = m3Tr(s), q = M3.at(tr, s.t);
  if (q.kind === 'circle') return { th: Math.abs(q.ang), on: true };         /* 糸の振り子で反対がわへ振れたときも角の大きさで */
  if (q.kind === 'fly') return { th: tr.ev.ang, on: false };
  return { th: 0, on: false };
}
/* 横軸の右はし：糸で 1 周する場合（4-2 ①）だけ 360°、他は 180° */
function m4XMax(s) { return (s.def.fk === 'S' && s.def.cs === 1) ? TAU : Math.PI; }

/* グラフ 1 枚（kind：'F'＝N または S、'v'＝速さ） */
function m4GDraw(s, cv, kind) {
  if (!cv || !cv.offsetParent) return;
  var K = m4K(s), cs = s.def.cs, v0 = s.v.v0, gr = G * M3.R;
  var W = Math.max(240, Math.floor(cv.parentNode.clientWidth || 320)), H = Math.round(clamp(W * 0.30, 140, 168));
  var ctx = prep(cv, W, H), pad = { l: 44, r: 14, t: 30, b: 22 };
  ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H);
  var xMax = m4XMax(s), D90 = Math.PI / 2;
  var thEnd = cs === 1 ? xMax : (cs === 2 ? M4A.thStop(v0) : M4A.thOff(v0));
  var f = function (th) { return kind === 'F' ? m4F(v0, th) : m4VNow(v0, th); };
  var col = kind === 'F' ? K.col : COL.vel, unit = kind === 'F' ? 'N' : 'm/s', nm = kind === 'F' ? K.F : 'v';
  var gEnd = Math.PI;                                            /* ③ の v の点線は、v² ≥ 0 の所まで */
  if (cs === 3 && kind === 'v') { var c0 = 1 - v0 * v0 / (2 * gr); if (c0 > -1) gEnd = Math.acos(c0); }
  /* 縦の範囲：描く部分から */
  var lo = 0, hi = 0, N0 = 160;
  for (var i = 0; i <= N0; i++) { var t0 = xMax * i / N0; if (cs === 2 && t0 > thEnd) break; if (cs === 3 && kind === 'v' && t0 > gEnd) break; var y0 = f(t0); lo = Math.min(lo, y0); hi = Math.max(hi, y0); }
  if (kind === 'v') { lo = 0; hi = Math.max(hi, v0); }
  var rg = niceRange(lo, hi);
  var X = function (th) { return pad.l + th / xMax * (W - pad.l - pad.r); }, Y = function (y) { return H - pad.b - (y - rg.lo) / (rg.hi - rg.lo) * (H - pad.t - pad.b); };
  /* 見るべき範囲に色（v のグラフは θ ≤ 90°、N・S のグラフは θ ≥ 90°） */
  var band = function (a, b, fill, txt, tc) {
    ctx.save(); ctx.fillStyle = fill; ctx.fillRect(X(a), pad.t, X(b) - X(a), H - pad.t - pad.b); ctx.restore();
    label(ctx, txt, (X(a) + X(b)) / 2, pad.t - 8, { size: 10, bold: true, color: tc });
  };
  /* θ = 90° の左右の塗り分けと「〜を見る」の文字はやめた（2026-10-14 千葉さん） */
  /* 目盛り */
  ctx.save(); ctx.font = '600 10px ' + FONT; ctx.fillStyle = '#5d6875'; ctx.strokeStyle = '#eef0f2'; ctx.lineWidth = 1;
  ctx.textAlign = 'center'; ctx.textBaseline = 'top';
  var big = xMax > Math.PI;
  for (var dg = 0; dg <= xMax * 180 / Math.PI + 0.1; dg += big ? 45 : 30) {
    var x = X(dg * Math.PI / 180); ctx.beginPath(); ctx.moveTo(x, pad.t); ctx.lineTo(x, H - pad.b); ctx.stroke();
    if (!big || dg % 90 === 0) ctx.fillText(dg + '°', x, H - pad.b + 3);
  }
  var sy = niceStep(rg.hi - rg.lo, 3); ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
  for (var yv = Math.ceil(rg.lo / sy - 1e-9) * sy; yv <= rg.hi + 1e-9; yv += sy) { var yy = Y(yv); ctx.beginPath(); ctx.moveTo(pad.l, yy); ctx.lineTo(W - pad.r, yy); ctx.stroke(); ctx.fillText(+yv.toFixed(6) + '', pad.l - 5, yy); }
  ctx.restore();
  /* 90°・180°（・270°）の線 */
  ctx.save(); ctx.setLineDash([4, 3]); ctx.strokeStyle = '#8a929c'; ctx.lineWidth = 1;
  [D90, Math.PI, 3 * D90].forEach(function (a) { if (a > xMax + 1e-9) return; ctx.beginPath(); ctx.moveTo(X(a), pad.t); ctx.lineTo(X(a), H - pad.b); ctx.stroke(); });
  ctx.restore();
  /* 軸（0 の線を太く） */
  ctx.save(); ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 1.3; ctx.beginPath(); ctx.moveTo(pad.l, Y(0)); ctx.lineTo(W - pad.r + 4, Y(0)); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(pad.l, H - pad.b); ctx.lineTo(pad.l, pad.t - 2); ctx.stroke(); ctx.restore();
  label(ctx, nm + '〔' + unit + '〕', 4, 9, { size: 10.5, bold: true, color: '#2b323c', align: 'left' });
  sym(ctx, 'θ', W - pad.r - 2, Y(0) - 9, { size: 13, color: '#2b323c' });
  /* 曲線：たどる部分は実線。③ の離れた（たるんだ）あとは点線（N・S は 0 より下＝ありえない、v はたどらない） */
  var seg = function (a, b, style) {
    if (b <= a) return;
    ctx.save(); ctx.lineWidth = style === 'ok' ? 2.6 : 1.7; ctx.strokeStyle = style === 'ok' ? col : (style === 'x' ? '#d1352b' : '#aab2bb');
    ctx.setLineDash(style === 'ok' ? [] : (style === 'x' ? [6, 4] : [3, 4]));
    ctx.beginPath(); var n = Math.max(2, Math.ceil((b - a) / xMax * 200));
    for (var k = 0; k <= n; k++) { var th = a + (b - a) * k / n, p = { x: X(th), y: Y(f(th)) }; k ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y); }
    ctx.stroke(); ctx.restore();
  };
  seg(0, Math.min(thEnd, xMax), 'ok');
  if (cs === 3) seg(thEnd, kind === 'v' ? gEnd : Math.PI, kind === 'F' ? 'x' : 'g');
  /* 大事な点 */
  var dot = function (th, y, c) { ctx.save(); ctx.fillStyle = c; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.arc(X(th), Y(y), 4.5, 0, TAU); ctx.fill(); ctx.stroke(); ctx.restore(); };
  var note = function (th, y, txt, c, dy) { var rt = th > xMax * 0.6; label(ctx, txt, X(th) + (rt ? -8 : 8), Y(y) + dy, { size: 10.5, bold: true, color: c, align: rt ? 'right' : 'left' }); };
  if (cs === 1) {
    var yt = f(Math.PI); dot(Math.PI, yt, col);
    var tx = '最高点で ' + nm + ' = ' + fmt(yt, 2) + ' ' + unit + (kind === 'F' ? ' ≥ 0' : '');
    if (big) label(ctx, tx, X(Math.PI), Y(yt) - 14, { size: 10.5, bold: true, color: col }); else note(Math.PI, yt, tx, col, -12);
  } else if (cs === 2) {
    var ys = f(thEnd); dot(thEnd, ys, kind === 'v' ? '#d1352b' : col);
    note(thEnd, ys, kind === 'v' ? 'v = 0（θ = ' + m4Deg(thEnd) + '°）' : K.F + ' = ' + fmt(ys, 2) + ' N > 0（θ = ' + m4Deg(thEnd) + '°）', kind === 'v' ? '#d1352b' : col, -12);
  } else {
    var yo = f(thEnd); dot(thEnd, yo, kind === 'F' ? '#d1352b' : col);
    if (kind === 'F') {
      label(ctx, K.F + ' = 0（θ = ' + m4Deg(thEnd) + '°）→ ' + (K.F === 'N' ? '離れる' : 'たるむ'), X(thEnd) - 8, Y(0) + 11, { size: 10.5, bold: true, color: '#d1352b', align: 'right' });
      label(ctx, K.F + ' < 0 はありえない', X(Math.PI) - 6, Y(f(Math.PI)) - 10, { size: 10, bold: true, color: '#d1352b', align: 'right' });
    } else {
      note(thEnd, yo, 'v = ' + fmt(yo, 2) + ' m/s > 0', col, -12);
      var tg = (thEnd + gEnd) / 2; label(ctx, (K.F === 'N' ? '面から離れる' : '糸がたるむ') + 'ので、この先はたどらない', X(tg) + 6, Y(f(tg)) - 10, { size: 9.5, color: '#7c8592', align: 'left' });
    }
  }
  /* いまの小球 */
  var nw = m4ThNow(s), yn = f(nw.th);
  ctx.save(); ctx.fillStyle = nw.on ? '#e07b18' : '#fff'; ctx.strokeStyle = '#e07b18'; ctx.lineWidth = 2.2; ctx.beginPath(); ctx.arc(X(nw.th), Y(yn), 5.2, 0, TAU); ctx.fill(); ctx.stroke(); ctx.restore();
  label(ctx, 'いま θ = ' + m4Deg(nw.th) + '°　' + nm + ' = ' + fmt(yn, 2) + ' ' + unit, W - pad.r, 9, { size: 10.5, bold: true, color: '#b2560c', align: 'right' });
}
function m4Graphs(s) { if (!s.gbox) return; m4GDraw(s, s.gbox.querySelector('.m4gF'), 'F'); m4GDraw(s, s.gbox.querySelector('.m4gV'), 'v'); }

/* ② の「折り返す瞬間」：一番高い所（速さ 0）の前後をゆっくり */
function m4TurnT(tr) {
  var t = null, am = -1; for (var i = 0; i < tr.pts.length; i++) { var p = tr.pts[i]; if (p.kind !== 'circle') continue; if (p.ang > am) { am = p.ang; t = p.t; } else if (p.ang < am - 1e-3) break; }
  return t;
}
/* ① の「最高点の瞬間」：最高点（θ = 180°）に達する前後をゆっくり */
function m4PlayTop(s) {
  var tr = m3Tr(s), t = null;
  if (tr.ev && tr.ev.kind === 'top') t = tr.ev.t;
  else for (var i = 0; i < tr.pts.length; i++) { var p = tr.pts[i]; if (p.kind === 'circle' && p.ang >= Math.PI) { t = p.t; break; } }
  if (t === null) return;
  s.playWindow(Math.max(0, t - M3WIN.pre), Math.min(tr.tEnd, t + M3WIN.post), M3WIN.rate, null);
}
function m4PlayTurn(s) {
  var tr = m3Tr(s), t = m4TurnT(tr); if (t === null) return;
  s.playWindow(Math.max(0, t - 0.22), Math.min(tr.tEnd, t + 0.22), 0.08, null);
}

/* 図の下のひとこと */
function m4SubMsg(s) {
  var K = m4K(s), cs = s.def.cs, v0 = s.v.v0, tr = m3Tr(s), F = K.F;
  if (cs === 1) {
    var tTop = null; tr.pts.forEach(function (p) { if (tTop === null && p.kind === 'circle' && p.ang >= Math.PI - 1e-6) tTop = p.t; });
    if (tTop === null && tr.ev && tr.ev.kind === 'top') tTop = tr.ev.t;
    var top = '最高点で $' + F + ' = ' + fmt(m4F(v0, Math.PI), 2) + '$ N $\\ge 0$、$v = ' + fmt(m4VNow(v0, Math.PI), 2) + '$ m/s。';
    if (tTop !== null && s.t >= tTop - 1e-6) return K.F === 'N' ? '<b>最高点に達した！</b>　' + top + 'この先に面はないので、水平に飛び出す。' : '<b>最高点を通った！</b>　' + top + (s.ended ? '1 周した。' : '');
    return '$v_0 = ' + fmt(v0, 2) + '$ m/s $\\ge \\sqrt{5gr}$ なので、最高点でも $' + F + ' \\ge 0$。▶ スタートで確かめよう。';
  }
  if (cs === 2) {
    var ts = M4A.thStop(v0), tt = m4TurnT(tr);
    if (tt !== null && s.t >= tt) return '<b>$\\theta = ' + m4Deg(ts) + '^\\circ$ で速さが 0 になった。</b>このとき $' + F + ' = ' + fmt(m4F(v0, ts), 2) + '$ N $> 0$（' + K.noOff + '）。そのまま' + K.back + '。';
    return '$v_0 = ' + fmt(v0, 2) + '$ m/s $\\le \\sqrt{2gr}$ なので、中心の高さ（$90^\\circ$）までに速さが 0 になるはず。▶ スタートで確かめよう。';
  }
  var to = M4A.thOff(v0);
  if (tr.ev && s.t >= tr.ev.t) return '<b>' + K.offd + '！</b>　$\\theta = ' + m4Deg(to) + '^\\circ$ で $' + F + ' = 0$。このとき $v = ' + fmt(m4VNow(v0, to), 2) + '$ m/s $> 0$ なので、放物運動を始める。';
  return '$\\sqrt{2gr} < v_0 = ' + fmt(v0, 2) + '$ m/s $< \\sqrt{5gr}$ なので、中心より高い所で $' + F + ' = 0$ になるはず。▶ スタートで確かめよう。';
}

/* 3 つの図の def（fk：'N'＝円筒面／'S'＝糸、cs：1〜3、gbox：その図のグラフの箱） */
function m4SubDef(fk, cs, gbox) {
  var K = M4K[fk], al = M4A.allow[cs];
  var d = {
    id: 'm4' + (fk === 'N' ? 'abc' : 'def').charAt(cs - 1), num: cs, cs: cs, fk: fk, sec: K.sec, mode: 'mode4', strobe: false, views: null, baseRate: 1 / 3, trailSec: 0.6, belowCanvas: false,
    height: function (s, w) { return Math.round(clamp(w * 0.53, 224, 336)); },
    vars: [{ k: 'v0', label: '初速 $v_0$', aria: '初速', min: 1.0, max: 6.0, step: 0.05, def: M4A.def[cs], dec: 2, unit: 'm/s',
      allow: function () { return al; },
      mark: function () { return [{ x: Math.sqrt(2 * G * M3.R), label: '$\\sqrt{2gr}$' }, { x: Math.sqrt(5 * G * M3.R), label: '$\\sqrt{5gr}$' }]; } }],
    onVar: function (s, k, x) { s.v[k] = clamp(x, al.lo, al.hi); return true; },     /* 選べる範囲の外へは動かない */
    buttons: [],
    init: function (s) { if (s.rot === undefined) s.rot = !!modeState('mode4').rot; },
    onWindow: function (s, on) { if (s.extra.inst) s.extra.inst.classList.toggle('on', on); },
    tEnd: function (s) { return m3Tr(s).tEnd; },
    onChanged: function () { return 'stop'; },
    afterBuild: function (s) { s.gbox = gbox; m2SetRot(s, s.rot); },
    draw: function (s, ctx, W, H) { drawM3(s, ctx, W, H); },
    live: function (s) { m4Graphs(s); },
    msg: function (s) { return m4SubMsg(s); }
  };
  if (cs === 1) d.buttons.push({ k: 'inst', inPlay: true, label: '⏱ 最高点の瞬間<br>をスローで', cls: 'instb two', onClick: function (s) { m4PlayTop(s); } });
  if (cs === 2) d.buttons.push({ k: 'inst', inPlay: true, label: '⏱ 折り返す瞬間<br>をスローで', cls: 'instb two', onClick: function (s) { m4PlayTurn(s); } });
  if (cs === 3) d.buttons.push({ k: 'inst', inPlay: true, label: K.inst3, cls: 'instb two', onClick: function (s) { m3PlayInstant(s); } });
  return d;
}

/* セクションの中身（HTML） */
function m4CaseHTML(fk, cs) {
  var K = M4K[fk], F = K.F;
  var head = { 1: '① 最高点まで到達する場合', 2: '② $\\theta \\le \\dfrac{\\pi}{2}$ の点まで到達する場合（折り返す）', 3: '③ $\\dfrac{\\pi}{2} \\le \\theta \\le \\pi$ の点まで到達する場合（' + K.tag3 + '）' }[cs];
  var pt = {
    1: '$' + F + '$ は最高点（$\\theta = 180^\\circ$）で一番小さい。だから<b>最高点で $' + F + ' \\ge 0$</b> なら、途中のどこでも $' + F + ' \\ge 0$。' +
       '最高点で $' + F + ' = \\dfrac{m}{r}(v_0^{\\,2} - 5gr) \\ge 0$ より $v_0 \\ge \\sqrt{5gr}$。' +
       '$v$ は最高点でも 0 にならない（$' + F + ' = 0$ のときでも $v^2 = gr > 0$）ので、<b>$v$ を考える必要はない</b>。',
    2: '$\\theta \\le 90^\\circ$ では $\\cos\\theta \\ge 0$ なので、$' + F + ' = \\dfrac{m}{r}(v^2 + gr\\cos\\theta) > 0$ が必ず成り立つ（<b>$' + F + '$ を考える必要はない</b>）。' +
       '$v$ は $\\theta$ とともに小さくなり、<b>$v = 0$ になった所で折り返す</b>。だから「その点で $v \\ge 0$」が到達する条件。' +
       '$v_0 \\fallingdotseq \\sqrt{2gr}$ では、$\\theta = 90^\\circ$ で $v = 0$ と $' + F + ' = 0$ が同時に起こる（$v$・$' + F + '$ どちらで考えてもよい）。',
    3: '$90^\\circ < \\theta$ では、$' + F + ' = 0$ になる点で $v^2 = -gr\\cos\\theta > 0$（$\\cos\\theta < 0$）なので、<b>$v$ は必ず正</b>（$v$ を考える必要はない）。' +
       '$' + F + '$ は $\\theta$ とともに小さくなり、<b>$' + F + ' = 0$ になった所で' + K.offing + '</b>放物運動を始める。だから「その点で $' + F + ' \\ge 0$」がその点に到達する条件。'
  }[cs];
  return '<section class="m4case c' + cs + '"><h3 class="m4ch">' + head + '</h3>' +
    '<div class="m4lay"><div class="m4simhost simhost"></div><div class="m4gbox">' +
      '<p class="m4gt"><span class="lg" style="color:' + K.col + '">●</span> ' + K.fName + ' $' + F + '$ と $\\theta$ の関係　$' + F + ' = \\dfrac{m}{r}(v^2 + gr\\cos\\theta)$</p><div class="m4gc"><canvas class="m4gF"></canvas></div>' +
      '<p class="m4gt"><span class="lg" style="color:#1663b5">●</span> 速さ $v$ と $\\theta$ の関係　$v^2 = v_0^{\\,2} + 2gr(\\cos\\theta - 1)$</p><div class="m4gc"><canvas class="m4gV"></canvas></div>' +
      '<p class="m4pt"><span class="m4ptt">ここに注目</span>' + pt + '</p>' +
    '</div></div></section>';
}
function m4SecHTML(fk) {
  var K = M4K[fk], F = K.F, str = fk === 'S';
  var pdf = str ? '' : '<p class="m4pdf"><a href="' + M4PDF + '" target="_blank" rel="noopener">📄 このページの理論的背景をまとめたPDFはこちら</a></p>';   /* 4-2 には付けない */
  var h = pdf +
    '<div class="m4top">' +
      '<div class="m4card m4scene">' +
        (str ? '<p>長さ $r=0.50$ m の糸の一端を中心のくぎに結び、他端につけた小球（$m=0.20$ kg）を、最下点で速さ $v_0$ で打ち出す。$v$ は角 $\\theta$ の点での速さ、$S$ はそこでの糸の張力。</p>'
             : '<p>小球（$m=0.20$ kg）を、なめらかな床を速さ $v_0$ で進ませて、半径 $r=0.50$ m のなめらかな円筒面の内側を上らせる。$v$ は角 $\\theta$ の点での速さ、$N$ はそこでの垂直抗力。</p>') + '</div>' +
      '<div class="m4card m4eq"><p class="m4h">使う式</p>' +
        /* 一緒に円運動する観測者から見るときは、向心方向の力のつり合いの式（.isrot で切りかえ） */
        '<div class="m4e-in"><p>・向心方向の' + T_EOM + '</p>' + tex('m\\dfrac{v^2}{r} = ' + F + ' - mg\\cos\\theta \\quad\\Longrightarrow\\quad ' + F + ' = \\dfrac{m}{r}(v^2 + gr\\cos\\theta)', true) + '</div>' +
        '<div class="m4e-rot"><p>・向心方向の' + T_BAL + '（遠心力 $m\\dfrac{v^2}{r}$ を加える）</p>' + tex(F + ' - mg\\cos\\theta - m\\dfrac{v^2}{r} = 0 \\quad\\Longrightarrow\\quad ' + F + ' = \\dfrac{m}{r}(v^2 + gr\\cos\\theta)', true) + '</div>' +
        '<p>・力学的エネルギー保存則</p>' + tex('\\dfrac{1}{2}mv_0^{\\,2} = mgr(1 - \\cos\\theta) + \\dfrac{1}{2}mv^2 \\quad\\Longrightarrow\\quad v^2 = v_0^{\\,2} + 2gr(\\cos\\theta - 1)', true) + '</div>' +
    '</div>' +
    '<div class="m4key"><b>考え方</b>：角 $\\theta$ の点まで円運動するには、そこまでの各点で <b>$v \\ge 0$</b>（その点を通過できる）と <b>$' + F + ' \\ge 0$</b>（' + K.keep + '）の<b>両方</b>が成り立つ必要がある。' +
      'でも実は、<b>$\\theta \\le 90^\\circ$ なら $v$ だけ、$90^\\circ < \\theta$ なら $' + F + '$ だけ</b>を見ればよい。3 つの場合のグラフで、$v$ と $' + F + '$ を比べて確かめよう。</div>' +
    m4CaseHTML(fk, 1) +
    '<div class="m4pair">' + m4CaseHTML(fk, 2) + m4CaseHTML(fk, 3) + '</div>' +
    '<div class="m4card m4conc"><p class="m4h">結論</p><p>「角 $\\theta$ の点まで、' + (str ? '糸がたるまずに' : '円筒面上を') + '円運動する必要十分条件」は、その点の速さ $v$、' + K.fName + ' $' + F + '$ を用いて</p>' +
      '<ol class="m4cl">' +
        '<li><span class="m4ci">（ⅰ）</span>「$\\theta < \\dfrac{\\pi}{2}$ の点まで到達する条件」なら　<b>$v \\ge 0$</b>　（つまり $' + F + '$ を考える必要なし）</li>' +
        '<li><span class="m4ci">（ⅱ）</span>「$\\theta = \\dfrac{\\pi}{2}$ の点まで到達する条件」なら　<b>$v \\ge 0$</b> または <b>$' + F + ' \\ge 0$</b>　（つまり $v$・$' + F + '$ どちらでもいい）</li>' +
        '<li><span class="m4ci">（ⅲ）</span>「$\\theta > \\dfrac{\\pi}{2}$ の点まで到達する条件」なら　<b>$' + F + ' \\ge 0$</b>　（つまり $v$ を考える必要なし）</li>' +
      '</ol>' +
      '<p>頻出の問題である、</p>' +
      '<p class="m4iv"><span class="m4ci">（Ⅳ）</span>「最高点（$\\theta = \\pi$）まで到達する条件」なら<b>「最高点で $' + F + ' \\ge 0$」</b>（つまり $v$ を考える必要なし）</p>' +
      (str ? '' : '<p class="m4small">' + '最高点で宙返りする条件（<a href="#3-2">3-2</a>）も同様。糸の張力で円運動する問題（④-2）における、最高点の到達条件も同じ結論「最高点で張力 $S \\ge 0$」（つまり $v$ を考える必要なし）。</p>') + '</div>' +
    '<div class="m4card m4sum"><p class="m4h">$v_0$ ごとに起こること（まとめ）</p><table class="reltab m4tab"><tbody>' +
      '<tr><th>$v_0 \\le \\sqrt{2gr}$</th><td>中心の高さまでに速さが 0 になり、' + (str ? '振り子のように往復する' : '滑り戻る') + '（$' + F + '$ は 0 にならない）</td></tr>' +
      '<tr><th>$\\sqrt{2gr} < v_0 < \\sqrt{5gr}$</th><td>中心より高い所で $' + F + ' = 0$ → ' + K.offing + '放物運動（速さは 0 でない）</td></tr>' +
      '<tr><th>$v_0 \\ge \\sqrt{5gr}$</th><td>最高点でも $' + F + ' \\ge 0$ → <b>' + (str ? '1 周できる' : '最高点まで到達できる（円筒面が 1 周あれば 1 周できる）') + '</b></td></tr>' +
    '</tbody></table></div>' + pdf;
  return mathify(h);
}
/* セクションの観測者の切りかえ（セクション名の右に 1 つ。そのセクションの 3 つの図をまとめて切りかえる） */
var M4SECS = [];
function m4SyncSegs() {
  M4SECS.forEach(function (o) { var on = !!(o.sims[0] && o.sims[0].rot); o.art.classList.toggle('isrot', on); o.btns.forEach(function (b) { b.classList.toggle('on', (b.dataset.rot === '1') === on); }); });
}
function m4Build(fk, art) {
  var cases = art.querySelectorAll('.m4case'), sims = [];
  [1, 2, 3].forEach(function (cs) {
    var box = cases[cs - 1], d = m4SubDef(fk, cs, box.querySelector('.m4gbox'));
    var sm = new Sim(d, box.querySelector('.m4simhost'), null);
    SIM_BY_ID[d.id] = sm; sims.push(sm);
  });
  SIM_BY_ID[art.id] = sims[0];
  var btns = [].slice.call(art.querySelectorAll('.secobs button'));
  btns.forEach(function (b) { b.addEventListener('click', function () { var on = b.dataset.rot === '1'; sims.forEach(function (s) { m2SetRot(s, on); }); m4SyncSegs(); }); });
  M4SECS.push({ sims: sims, btns: btns, art: art }); m4SyncSegs();
}
DEFS.m4s1 = { id: 'm4s1', num: 1, title: '円筒面を最高点まで昇ることができるか', mode: 'mode4', custom: true, obsSeg: true,
  html: function () { return m4SecHTML('N'); }, build: function (art) { m4Build('N', art); } };
DEFS.m4s2 = { id: 'm4s2', num: 2, title: '糸による円運動で 1 周できるか', mode: 'mode4', custom: true, obsSeg: true,
  html: function () { return m4SecHTML('S'); }, build: function (art) { m4Build('S', art); } };
