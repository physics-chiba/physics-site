/* =========================================================================
   30_physics.js … 物理の計算だけ（純粋な関数。描画を混ぜない）
   記号は教科書にそろえる：半径 r・速さ v・角速度 ω・周期 T・回転数 n・加速度 a・向心力 F・
   張力 S（周期 T と区別するため）・摩擦係数 μ・角 θ。
   ========================================================================= */
'use strict';
var G = 9.8;
var TAU = Math.PI * 2;
function clamp(x, a, b) { return x < a ? a : (x > b ? b : x); }
function roundTo(x, step) { return Math.round(x / step) * step; }

/* ---------- モード1：水平なめらかな台の上の等速円運動（中心の穴 O に糸を通し、台の下で手が引く） ---------- */
var M1 = {
  m: 0.10,            /* 小球の質量 [kg]（1-1 の質量スライダーで 0.05〜0.20 kg。M1.mRef は F の矢印の縮尺の基準） */
  mRef: 0.20,
  Lx: 1.40, Ly: 1.40, /* 台の半分の幅（横・奥行き）[m]。小球が台のはしに来たら止める。
                         既定（r = 0.40 m、ω = π/2 rad/s）なら、糸を切ったあと 1 秒ごとのストロボがどの向きでも 3 個以上並ぶ */
  W: [Math.PI / 4, Math.PI / 2, 3 * Math.PI / 4, Math.PI],   /* 角速度は 4 択（π/4・π/2・3π/4・π rad/s）＝ 2026-10 千葉さんの指定 */
  zHand: 1.0,         /* 台の下で糸を持つ手の高さ（既定 r = 0.40 m のとき）[m] */
  Lstr: 1.40,         /* 糸の全長 [m]：r ＋（台の下の長さ）。r を変えると手が上下する */
  handDepth: function (r) { return M1.Lstr - r; },
  rb: 0.045,          /* 小球の半径 [m]（絵の大きさ） */
  tMax: 30,           /* 糸を切らないときの時間バーの長さ [s] */
  R: {                /* スライダーの範囲（約束 A：r を動かすと ω 固定、ほかは r・m 固定で ω を変える） */
    r: [0.20, 0.80], w: [Math.PI / 4, Math.PI]
  },
  /* 半径と角速度から、ほかの量を全部出す */
  derive: function (r, w) {
    var v = r * w, a = r * w * w;
    return { r: r, w: w, v: v, a: a, F: M1.m * a, T: TAU / w, n: w / TAU };
  },
  /* ある量をスライダーで動かしたとき、新しい ω（r は固定）。r を動かしたときは ω をそのまま */
  omegaFrom: function (key, val, r, w) {
    switch (key) {
      case 'r': return w;
      case 'v': return val / r;
      case 'a': return Math.sqrt(Math.max(val, 0) / r);
      case 'F': return Math.sqrt(Math.max(val, 0) / M1.m / r);
      case 'w': return val;
      case 'T': return TAU / val;
      case 'n': return TAU * val;
    }
    return w;
  },
  /* 時刻 t の状態。tCut（糸を切った時刻）より後は等速直線運動。
     ph＝角のずれ（θ = ωt + ph）。量を変えても時刻は戻さず、角が飛ばないよう ph を変える */
  state: function (r, w, t, tCut, ph) {
    var cut = (tCut !== null && tCut !== undefined && t > tCut);
    var tc = cut ? tCut : t;
    var th = w * tc + (ph || 0);
    var x = r * Math.cos(th), y = r * Math.sin(th);
    var vx = -r * w * Math.sin(th), vy = r * w * Math.cos(th);
    if (!cut) return { phase: 'circle', th: th, x: x, y: y, vx: vx, vy: vy, ax: -w * w * x, ay: -w * w * y };
    var d = t - tCut;
    return { phase: 'line', th: th, x: x + vx * d, y: y + vy * d, vx: vx, vy: vy, ax: 0, ay: 0, x0: x, y0: y };
  },
  /* 糸を切ってから、小球が台のはし（|x| か |y| が L − rb）に着くまでの時間 */
  exitAfter: function (r, w, tCut, ph) {
    var s = M1.state(r, w, tCut, null, ph), best = Infinity;
    [[s.x, s.vx, M1.Lx - M1.rb], [s.y, s.vy, M1.Ly - M1.rb]].forEach(function (p) {
      if (p[1] > 1e-9) best = Math.min(best, (p[2] - p[0]) / p[1]);
      else if (p[1] < -1e-9) best = Math.min(best, (-p[2] - p[0]) / p[1]);
    });
    return best;
  }
};

/* 鍵（固定）つきの連動。key を x にしたいとき、鍵のかかった量を変えずにできる (r, ω) をさがす。
   locks：{ r, v, a, F, w, T, n } の true が固定。ω・T・n はどれか 1 つでも固定なら ω が動かせない。
   できないときは { ok:false, why:[邪魔をしている鍵] } を返す */
M1.solve = function (key, x, cur, locks) {
  var L = locks || {}, eps = 1e-6;
  if (key === 'm') {                                   /* 質量：ふつうは r・ω をそのままにして F だけ変わる。F が固定なら r を変えて F を保つ */
    if (!L.F) return { ok: true, r: cur.r, w: cur.w };
    if (L.a) return { ok: false, why: ['F', 'a'] };
    if (L.r || L.v) return { ok: false, why: ['F'].concat(L.r ? ['r'] : []).concat(L.v ? ['v'] : []) };
    var F0 = M1.m * cur.r * cur.w * cur.w, rN = F0 / (x * cur.w * cur.w);
    if (rN < M1.R.r[0] - eps || rN > M1.R.r[1] + eps) return { ok: false, why: ['F'], range: true };
    return { ok: true, r: rN, w: cur.w };
  }
  if (L[key]) return { ok: false, why: [key] };
  var wFix = ['w', 'T', 'n'].filter(function (k) { return L[k] && k !== key; });
  var D0 = M1.derive(cur.r, cur.w);
  var ws;
  if (key === 'w' || key === 'T' || key === 'n') {
    if (wFix.length) return { ok: false, why: wFix };
    ws = [key === 'w' ? x : (key === 'T' ? TAU / x : TAU * x)];
  } else ws = wFix.length ? [cur.w] : M1.W.slice();
  var cands = [];
  ws.forEach(function (w) {
    var rs = [];
    if (L.r) rs = [cur.r];
    else if (key === 'r') rs = [x];
    else if (key === 'v') rs = [x / w];
    else if (key === 'a') rs = [x / (w * w)];
    else if (key === 'F') rs = [x / (M1.m * w * w)];
    else if (L.v) rs = [D0.v / w];                     /* ω を変えるとき：v を保つ */
    else if (L.a || L.F) rs = [D0.a / (w * w)];        /* ω を変えるとき：a（F）を保つ */
    else rs = [cur.r];
    rs.forEach(function (r) {
      r = clamp(r, M1.R.r[0], M1.R.r[1]);
      var D = M1.derive(r, w);
      if (L.v && key !== 'v' && Math.abs(D.v - D0.v) > eps) return;
      if ((L.a || L.F) && key !== 'a' && key !== 'F' && Math.abs(D.a - D0.a) > eps) return;
      if (L.r && Math.abs(r - cur.r) > eps) return;
      cands.push({ r: r, w: w, err: Math.abs(D[key] - x) / Math.max(1e-9, Math.abs(x)), same: Math.abs(w - cur.w) < eps ? 0 : 1 });
    });
  });
  if (!cands.length) {
    var why = [];
    if (key !== 'r' && L.r) why.push('r');
    if (key !== 'v' && L.v) why.push('v');
    if (key !== 'a' && L.a) why.push('a');
    if (key !== 'F' && L.F) why.push('F');
    wFix.forEach(function (k) { why.push(k); });
    return { ok: false, why: why };
  }
  cands.sort(function (p, q) { return (p.err - q.err) || (p.same - q.same); });
  var c = cands[0];
  /* 動かした量がまったく変わらない（例：v を動かしたが r も ω も固定）ときは「動かせない」 */
  if (ws.length === 1 && L.r && key !== 'w' && key !== 'T' && key !== 'n') {   /* r も ω も固定：動かせる量がない */
    var why2 = [];
    if (L.r) why2.push('r'); wFix.forEach(function (k) { why2.push(k); });
    if (L.v && key !== 'v') why2.push('v'); if ((L.a) && key !== 'a') why2.push('a'); if (L.F && key !== 'F') why2.push('F');
    return { ok: false, why: why2 };
  }
  return { ok: true, r: c.r, w: c.w };
};


/* ---------- モード2：等速円運動と向心力 ---------- */
var M2 = {
  /* セクション1：ターンテーブルと箱（質量 m）。静止摩擦係数 μ（すべり出したあとの動摩擦係数も μ とする） */
  s1: { m: 0.20, R: 0.60, half: 0.045,
    wSlip: function (r, mu) { return Math.sqrt(mu * G / r); },
    /* すべるときの道すじ（慣性系）。ターンテーブルの上を、相対速度と逆向きに動摩擦力 μmg を受けて外へ */
    slipPath: function (w, r, mu) {
      var key = w.toFixed(4) + '|' + r.toFixed(4) + '|' + mu.toFixed(4);
      if (M2.s1._c && M2.s1._c.key === key) return M2.s1._c;
      var px = r, py = 0, ux = 0, uy = r * w, dt = 0.0005, t = 0, out = [{ t: 0, x: px, y: py, ux: ux, uy: uy, z: 0 }], R = M2.s1.R;   /* 箱の中心がふちに来るまで台の上をすべる */
      var acc = function (px, py, ux, uy) {
        var rx = ux + w * py, ry = uy - w * px, rl = Math.hypot(rx, ry);      /* 相対速度 = u − ω×p */
        if (rl < 1e-7) { var pl = Math.hypot(px, py) || 1; return [-mu * G * px / pl, -mu * G * py / pl]; }
        return [-mu * G * rx / rl, -mu * G * ry / rl];
      };
      while (t < 20) {
        var a1 = acc(px, py, ux, uy), mx = px + ux * dt / 2, my = py + uy * dt / 2, mux = ux + a1[0] * dt / 2, muy = uy + a1[1] * dt / 2;
        var a2 = acc(mx, my, mux, muy);
        px += mux * dt; py += muy * dt; ux += a2[0] * dt; uy += a2[1] * dt; t += dt;
        if (Math.round(t / dt) % 10 === 0) out.push({ t: t, x: px, y: py, ux: ux, uy: uy, z: 0 });
        if (Math.hypot(px, py) >= R) { out.push({ t: t, x: px, y: py, ux: ux, uy: uy, z: 0 }); break; }
      }
      /* 箱の中心がターンテーブルのふちをこえたら、台からとび出して床（z = −0.18 m）まで落ちる（2026-10-04 千葉さん：外に出るまで描く） */
      var t1 = t;
      for (var tau = 0.01; tau < 2; tau += 0.01) {
        var z = -0.5 * G * tau * tau;
        out.push({ t: t1 + tau, x: px + ux * tau, y: py + uy * tau, ux: ux, uy: uy, z: Math.max(z, -0.18), fly: 1 });
        if (z <= -0.18) break;
      }
      out.key = key; out.tOff = out[out.length - 1].t; out.tRim = t1; M2.s1._c = out; return out;
    },
    state: function (w, r, mu, t) {
      var slip = w > M2.s1.wSlip(r, mu) + 1e-9;
      if (!slip) { var th = w * t; return { slip: false, th: th, x: r * Math.cos(th), y: r * Math.sin(th), vx: -r * w * Math.sin(th), vy: r * w * Math.cos(th), f: M2.s1.m * r * w * w, rr: r }; }
      var P = M2.s1.slipPath(w, r, mu), tt = Math.min(t, P.tOff);
      var lo = 0, hi = P.length - 1;
      while (hi - lo > 1) { var md = (lo + hi) >> 1; if (P[md].t <= tt) lo = md; else hi = md; }
      var a = P[lo], b = P[hi], u = (b.t > a.t) ? (tt - a.t) / (b.t - a.t) : 0;
      var q = { slip: true, x: a.x + (b.x - a.x) * u, y: a.y + (b.y - a.y) * u, vx: a.ux + (b.ux - a.ux) * u, vy: a.uy + (b.uy - a.uy) * u };
      q.rr = Math.hypot(q.x, q.y); q.th = Math.atan2(q.y, q.x);
      q.relx = q.vx + w * q.y; q.rely = q.vy - w * q.x;
      return q;
    }
  },
  /* セクション2：ばね（自然長 ℓ、ばね定数 k）につないだ小球。kx = m(ℓ + x)ω² */
  s2: { m: 0.20, k: 20, l: 0.30, R: 0.95,
    xOf: function (w) { var s = M2.s2; return s.m * s.l * w * w / (s.k - s.m * w * w); },
    wOf: function (x) { var s = M2.s2; return Math.sqrt(s.k * x / (s.m * (s.l + x))); }
  },
  /* セクション3：水平な台の中心の穴に糸を通し、台の下で手が引く（1-1 と同じ形）。S = mrω²。張力が S0 をこえると糸が切れる */
  s3: { m: 0.50, S0: 2.0, half: 1.20, Lstr: 1.00, rb: 0.05,
    wCut: function (r) { var s = M2.s3; return Math.sqrt(s.S0 / (s.m * r)); },
    /* 糸が切れてから、台のはしに着くまでの時間（th0＝切れたときの角、v＝rω） */
    exitAfter: function (r, w, th0) {
      var s = M2.s3, x = r * Math.cos(th0), y = r * Math.sin(th0), vx = -r * w * Math.sin(th0), vy = r * w * Math.cos(th0), L = s.half - s.rb, best = Infinity;
      [[x, vx], [y, vy]].forEach(function (q) { if (q[1] > 1e-9) best = Math.min(best, (L - q[0]) / q[1]); else if (q[1] < -1e-9) best = Math.min(best, (-L - q[0]) / q[1]); });
      return best;
    }
  },
  /* セクション4：円錐振り子（糸の長さ L）。S = mLω²、cos θ = g/(Lω²) */
  s4: { m: 0.20, L: 1.0,
    wMin: function () { return Math.sqrt(G / M2.s4.L); },
    thOf: function (w) { return Math.acos(Math.min(1, G / (M2.s4.L * w * w))); }
  }
};

/* ---------- モード3：等速ではない円運動（鉛直面内）。半径 R、質量 m の小球（大きさは考えない） ----------
   どれも「軌道」を前もって計算して配列にしておき、時刻 t の状態は線形補間で取り出す（図・グラフ・式が同じ値を見る）。
   1 つの点：t, x, y（y は上向き）, vx, vy, kind（'floor'＝床・'circle'＝円の上・'fly'＝はなれて放物運動）,
            ang（円の上の角。3-1・3-3 は最下点から、3-2 は最高点から）, F（垂直抗力 N または張力 S）, at（接線加速度）, K, U, E */
var M3 = {
  m: 0.20, R: 0.50, dt: 0.0005, every: 8, _c: {},
  K: function (v) { return 0.5 * M3.m * v * v; },
  /* key ごとに 1 回だけ計算する */
  traj: function (sec, v0, th0) {                                 /* th0：3-4 の初期角度（度。最下点から）。ほかのセクションでは使わない */
    var key = sec + '|' + v0.toFixed(4) + (th0 === undefined ? '' : '|' + th0);
    if (M3._c[key]) return M3._c[key];
    var o = M3['b' + sec](v0, th0); o.key = key;
    o.tEnd = o.pts[o.pts.length - 1].t;
    var ks = Object.keys(M3._c); if (ks.length > 60) ks.slice(0, ks.length - 40).forEach(function (k) { delete M3._c[k]; });   /* 古い軌道は捨てる（メモリが増え続けないように） */
    M3._c[key] = o; return o;
  },
  /* 時刻 t の状態（補間） */
  at: function (tr, t) {
    var P = tr.pts, tt = clamp(t, 0, tr.tEnd), lo = 0, hi = P.length - 1;
    if (tt <= 0) { var q0 = {}; ['t', 'x', 'y', 'vx', 'vy', 'ang', 'F', 'at', 'K', 'U', 'E', 'kind', 'cir'].forEach(function (k) { q0[k] = P[0][k]; }); q0.v = Math.hypot(q0.vx, q0.vy); return q0; }   /* スタートの瞬間は最初の点（③-4 の θ0 = 180° で、t = 0 にたるむときも「まだ円の上」） */
    while (hi - lo > 1) { var md = (lo + hi) >> 1; if (P[md].t <= tt) lo = md; else hi = md; }
    var a = P[lo], b = P[hi], u = (b.t > a.t) ? (tt - a.t) / (b.t - a.t) : 0, q = {};
    ['t', 'x', 'y', 'vx', 'vy', 'ang', 'F', 'at', 'K', 'U', 'E'].forEach(function (k) { q[k] = a[k] + (b[k] - a[k]) * u; });
    q.kind = (u < 0.5 ? a : b).kind; if (a.kind !== b.kind) q.kind = a.kind;
    q.cir = (u < 0.5 ? a : b).cir; if (a.cir !== b.cir) q.cir = a.cir;   /* ③-5：どちらの点を中心に回っているか（'O'＝半径 2r、'C'＝釘・半径 r） */
    q.v = Math.hypot(q.vx, q.vy);
    return q;
  },
  /* 円の上を動く部分を RK4 で。f(φ) が角加速度。stop(φ, ω) が真になったら止める */
  /* val(φ, ω)：はなれる判定に使う量（N や S）。はなれた瞬間は、その量が 0 になる時刻まで 1 歩を縮めてそろえる */
  arc: function (out, t0, ph0, w0, acc, rec, stop, tMax, val) {
    var ph = ph0, w = w0, t = t0, dt = M3.dt, n = 0;
    var step = function (p, q, h) {
      var k1p = q, k1w = acc(p), k2p = q + k1w * h / 2, k2w = acc(p + k1p * h / 2), k3p = q + k2w * h / 2, k3w = acc(p + k2p * h / 2), k4p = q + k3w * h, k4w = acc(p + k3p * h);
      return [p + (k1p + 2 * k2p + 2 * k3p + k4p) * h / 6, q + (k1w + 2 * k2w + 2 * k3w + k4w) * h / 6];
    };
    rec(t, ph, w);
    while (t < tMax) {
      var nx = step(ph, w, dt), s = stop(nx[0], nx[1]);
      if (s && val && (s === 'off' || s === 'slack' || s === 'sw')) {   /* 'sw'（③-5 釘に触れる／離れる）：角 φ がちょうど 0 になる時刻にそろえる */
        var vf = s === 'sw' ? function (p) { return p; } : val;
        var a0 = vf(ph, w), a1 = vf(nx[0], nx[1]), f = clamp(a0 / (a0 - a1), 0, 1);
        nx = step(ph, w, dt * f); ph = nx[0]; w = nx[1]; t += dt * f; rec(t, ph, w);
        return { t: t, ph: ph, w: w, why: s };
      }
      ph = nx[0]; w = nx[1]; t += dt; n++;
      if (s || n % M3.every === 0) rec(t, ph, w);
      if (s) return { t: t, ph: ph, w: w, why: s };
    }
    return { t: t, ph: ph, w: w, why: 'time' };
  },
  /* 放物運動（はなれたあと）。hit(x, y) が真になるまで */
  fly: function (out, t0, x0, y0, vx, vy, ang, hit, U, tMax) {
    var m = M3.m;
    for (var tt = 0; t0 + tt <= tMax; tt += M3.dt * M3.every) {
      var x = x0 + vx * tt, y = y0 + vy * tt - G * tt * tt / 2, uy = vy - G * tt;
      var K = 0.5 * m * (vx * vx + uy * uy), Uu = U(y);
      out.push({ t: t0 + tt, x: x, y: y, vx: vx, vy: uy, kind: 'fly', ang: ang, F: 0, at: 0, K: K, U: Uu, E: K + Uu });
      if (tt > 0.02 && hit(x, y)) return t0 + tt;
    }
    return t0 + tMax;
  },
  /* 3-1 なめらかな円筒面（内がわ）をのぼる：床を右へ v0 → 最下点から円の内がわへ。φ＝最下点からの角（左回り）。
     円筒面は最下点から右がわを通って最高点まで（最高点の左には面がない：2026-10 千葉さん）。最高点に達したら水平に飛び出す */
  b1: function (v0) {
    var m = M3.m, R = M3.R, out = [], ev = null, xs = -0.40, U = function (y) { return m * G * (y + R); };
    var tin = -xs / v0;
    for (var t = 0; t < tin; t += 0.01) out.push({ t: t, x: xs + v0 * t, y: -R, vx: v0, vy: 0, kind: 'floor', ang: 0, F: m * G, at: 0, K: M3.K(v0), U: 0, E: M3.K(v0) });
    var rec = function (tt, ph, w) {
      var v = R * w, y = -R * Math.cos(ph), K = 0.5 * m * v * v;
      out.push({ t: tt, x: R * Math.sin(ph), y: y, vx: v * Math.cos(ph), vy: v * Math.sin(ph), kind: 'circle', ang: ph, F: m * (R * w * w + G * Math.cos(ph)), at: -G * Math.sin(ph), K: K, U: U(y), E: K + U(y) });
    };
    var r = M3.arc(out, tin, 0, v0 / R, function (ph) { return -G / R * Math.sin(ph); }, rec, function (ph, w) {
      var N = R * w * w + G * Math.cos(ph);
      if (N < -1e-7 && Math.abs(R * w) > 0.05) return 'off';     /* 面からはなれる（速さが 0 に近い折り返しでは判定しない） */
      if (w < 0 && ph <= 0) return 'back';                        /* もどってきて床へ */
      if (ph >= Math.PI) return 'top';                            /* 最高点に達した（その先に面はない） */
      return null;
    }, 12, function (ph, w) { return R * w * w + G * Math.cos(ph); });
    if (r.why === 'off' || r.why === 'top') {
      ev = { kind: r.why, t: r.t, ang: r.ph };
      var x0 = R * Math.sin(r.ph), y0 = -R * Math.cos(r.ph), v = R * r.w;
      /* 右半分の円筒面・左の床・図の左はしのどれかに着いたら止める */
      M3.fly(out, r.t, x0, y0, v * Math.cos(r.ph), v * Math.sin(r.ph), r.ph, function (x, y) { return (Math.hypot(x, y) >= R && x >= 0) || y <= -R || x < -1.5; }, U, 4);
    } else if (r.why === 'back') {
      var vf = Math.abs(R * r.w), last = out[out.length - 1].t;
      for (var t2 = 0.01; vf * t2 < 0.95 && t2 < 3; t2 += 0.01) out.push({ t: last + t2, x: -vf * t2, y: -R, vx: -vf, vy: 0, kind: 'floor', ang: 0, F: m * G, at: 0, K: M3.K(vf), U: 0, E: M3.K(vf) });
    }
    return { pts: out, ev: ev, sec: 1 };
  },
  /* 3-2 なめらかな円筒面（外がわ・上半分）をすべりおりる：最高点から右へ v0。θ＝最高点からの角（右回り） */
  b2: function (v0) {
    var m = M3.m, R = M3.R, out = [], ev = null, U = function (y) { return m * G * y; };
    var rec = function (tt, th, w) {
      var v = R * w, y = R * Math.cos(th), K = 0.5 * m * v * v;
      out.push({ t: tt, x: R * Math.sin(th), y: y, vx: v * Math.cos(th), vy: -v * Math.sin(th), kind: 'circle', ang: th, F: m * (G * Math.cos(th) - R * w * w), at: G * Math.sin(th), K: K, U: U(y), E: K + U(y) });
    };
    var r = M3.arc(out, 0, 0, v0 / R, function (th) { return G / R * Math.sin(th); }, rec, function (th, w) {
      return (G * Math.cos(th) - R * w * w < -1e-7) ? 'off' : (th >= Math.PI / 2 ? 'off' : null);
    }, 12, function (th, w) { return G * Math.cos(th) - R * w * w; });
    ev = { kind: 'off', t: r.t, ang: r.ph };
    var v = R * r.w;
    M3.fly(out, r.t, R * Math.sin(r.ph), R * Math.cos(r.ph), v * Math.cos(r.ph), -v * Math.sin(r.ph), r.ph, function (x, y) { return y <= 0; }, U, 3);
    return { pts: out, ev: ev, sec: 2 };
  },
  /* 3-4 糸による鉛直面内の円運動：最下点から角 θ0 の位置（右がわ）から、時計回り（φ が減る向き）に v0。φ＝最下点からの角。
     θ0 は 0°・30°・90°・180°（既定 90°＝糸が水平。2026-10-13 千葉さん） */
  b3: function (v0, th0d) {
    var m = M3.m, R = M3.R, out = [], ev = null, U = function (y) { return m * G * (y + R); };
    var th0 = (th0d === undefined ? 90 : th0d) * Math.PI / 180;
    var rec = function (tt, ph, w) {
      var v = R * w, y = -R * Math.cos(ph), K = 0.5 * m * v * v;
      out.push({ t: tt, x: R * Math.sin(ph), y: y, vx: v * Math.cos(ph), vy: v * Math.sin(ph), kind: 'circle', ang: ph, F: m * (R * w * w + G * Math.cos(ph)), at: -G * Math.sin(ph), K: K, U: U(y), E: K + U(y) });
    };
    var r;
    if (v0 * v0 / R + G * Math.cos(th0) < -1e-7) {                 /* 最高点で v0 < √(gr)：はじめから S < 0。すぐにたるむ */
      rec(0, th0, -v0 / R); out[0].F = 0; r = { t: 0, ph: th0, w: -v0 / R, why: 'slack' };   /* 張力は負にならない（0） */
    } else r = M3.arc(out, 0, th0, -v0 / R, function (ph) { return -G / R * Math.sin(ph); }, rec, function (ph, w) {
      return (R * w * w + G * Math.cos(ph) < -1e-7 && Math.abs(R * w) > 0.05) ? 'slack' : null;
    }, 6, function (ph, w) { return R * w * w + G * Math.cos(ph); });
    if (r.why === 'slack') {
      ev = { kind: 'slack', t: r.t, ang: r.ph };
      var v = R * r.w;
      M3.fly(out, r.t, R * Math.sin(r.ph), -R * Math.cos(r.ph), v * Math.cos(r.ph), v * Math.sin(r.ph), r.ph, function (x, y) { return Math.hypot(x, y) >= R; }, U, 3);
    }
    return { pts: out, ev: ev, sec: 3, th0: th0d === undefined ? 90 : th0d };
  },
  /* 3-5 糸による円運動（釘）：糸の長さ L = 2r（= M3.R）の一端を O（原点）に固定。O の真下 r の点 C（0, −r）に釘。
     小球は左がわの、最下点 B から角 θ0 の位置から反時計回り（右へ向かう向き）に v0。B を通る瞬間に糸が釘に触れ、
     そのあとは C を中心とする半径 r の円運動。もどってきて B を左向きに通ると、ふたたび O を中心に（振り子のとき）。
     φ＝それぞれの中心から見た、最下点からの角（右が正）。点に cir（'O' か 'C'）。2026-10-14 千葉さん */
  b6: function (v0, th0d) {
    var m = M3.m, L = M3.R, r = L / 2, cy = -r, out = [], ev = null, tMax = 6, tSw = [], U = function (y) { return m * G * (y + L); };
    var th0 = (th0d === undefined ? 90 : th0d) * Math.PI / 180;
    var mk = function (Rr, yc, cir) {
      return function (tt, ph, w) {
        var v = Rr * w, x = Rr * Math.sin(ph), y = yc - Rr * Math.cos(ph), K = 0.5 * m * v * v;
        out.push({ t: tt, x: x, y: y, vx: v * Math.cos(ph), vy: v * Math.sin(ph), kind: 'circle', cir: cir, ang: ph, F: m * (Rr * w * w + G * Math.cos(ph)), at: -G * Math.sin(ph), K: K, U: U(y), E: K + U(y) });
      };
    };
    var recO = mk(L, 0, 'O'), recC = mk(r, cy, 'C');
    var accO = function (ph) { return -G / L * Math.sin(ph); }, accC = function (ph) { return -G / r * Math.sin(ph); };
    var valO = function (ph, w) { return L * w * w + G * Math.cos(ph); }, valC = function (ph, w) { return r * w * w + G * Math.cos(ph); };
    var cir = 'O', ph = -th0, w = v0 / L, t = 0, res = null;
    if (v0 < 1e-9 && th0 < 1e-9) {                               /* 最下点で v0 = 0：動かない */
      for (var t0 = 0; t0 <= tMax + 1e-9; t0 += 0.05) recO(t0, 0, 0);
      return { pts: out, ev: null, sec: 6, th0: 0, tSw: [] };
    }
    if (valO(ph, w) < -1e-7) {                                   /* 最高点で v0 < √(2gr)：はじめから S < 0。すぐにたるむ */
      recO(0, ph, w); out[0].F = 0; res = { t: 0, ph: ph, w: w, why: 'slack' };
    } else {
      for (var guard = 0; guard < 400 && t < tMax - 1e-9; guard++) {
        if (cir === 'O' && ph >= 0 && w > 0) { cir = 'C'; ph = 0; w = w * L / r; tSw.push(t); }        /* 釘に触れる：速さはそのまま、半径が r に */
        else if (cir === 'C' && ph <= 0 && w < 0) { cir = 'O'; ph = 0; w = w * r / L; tSw.push(t); }   /* 釘から離れる：ふたたび O を中心に */
        if (cir === 'O') res = M3.arc(out, t, ph, w, accO, recO, function (p, q) {
          if (p >= 0 && q > 0) return 'sw';
          return (valO(p, q) < -1e-7 && Math.abs(L * q) > 0.05) ? 'slack' : null; }, tMax, valO);
        else res = M3.arc(out, t, ph, w, accC, recC, function (p, q) {
          if (p <= 0 && q < 0) return 'sw';
          return (valC(p, q) < -1e-7 && Math.abs(r * q) > 0.05) ? 'slack' : null; }, tMax, valC);
        t = res.t; ph = res.ph; w = res.w;
        if (res.why === 'sw') { ph = 0; continue; }
        break;
      }
    }
    if (res && res.why === 'slack') {
      ev = { kind: 'slack', t: res.t, ang: res.ph, cir: cir };
      var Rr = cir === 'C' ? r : L, yc = cir === 'C' ? cy : 0, v = Rr * res.w, n0 = out.length;
      M3.fly(out, res.t, Rr * Math.sin(res.ph), yc - Rr * Math.cos(res.ph), v * Math.cos(res.ph), v * Math.sin(res.ph), res.ph,
        function (x, y) { return Math.hypot(x, y - yc) >= Rr; }, U, 3);
      for (var k = n0; k < out.length; k++) out[k].cir = cir;
    }
    return { pts: out, ev: ev, sec: 6, th0: th0d === undefined ? 90 : th0d, tSw: tSw };
  },
  /* 4-1 円筒面のループ（内がわ・1 周ぶんの面がある）：床を右へ v0 → 最下点から円の内がわへ（3-1 と同じ向き）。
     1 周したら最下点から右の床へ出ていく。N < 0 になったら面から離れて放物運動（面にぶつかったら止める）。v0 ≤ √(2gr) はすべりもどる */
  b4: function (v0) {
    var m = M3.m, R = M3.R, out = [], ev = null, xs = -0.40, U = function (y) { return m * G * (y + R); };
    var tin = -xs / v0;
    for (var t = 0; t < tin; t += 0.01) out.push({ t: t, x: xs + v0 * t, y: -R, vx: v0, vy: 0, kind: 'floor', ang: 0, F: m * G, at: 0, K: M3.K(v0), U: 0, E: M3.K(v0) });
    var rec = function (tt, ph, w) {
      var v = R * w, y = -R * Math.cos(ph), K = 0.5 * m * v * v;
      out.push({ t: tt, x: R * Math.sin(ph), y: y, vx: v * Math.cos(ph), vy: v * Math.sin(ph), kind: 'circle', ang: ph, F: m * (R * w * w + G * Math.cos(ph)), at: -G * Math.sin(ph), K: K, U: U(y), E: K + U(y) });
    };
    var r = M3.arc(out, tin, 0, v0 / R, function (ph) { return -G / R * Math.sin(ph); }, rec, function (ph, w) {
      var N = R * w * w + G * Math.cos(ph);
      if (N < -1e-7 && Math.abs(R * w) > 0.05) return 'off';
      if (w < 0 && ph <= 0) return 'back';
      if (ph >= 2 * Math.PI) return 'loop';                       /* 1 周した */
      return null;
    }, 12, function (ph, w) { return R * w * w + G * Math.cos(ph); });
    if (r.why === 'off') {
      ev = { kind: 'off', t: r.t, ang: r.ph };
      var x0 = R * Math.sin(r.ph), y0 = -R * Math.cos(r.ph), v = R * r.w;
      M3.fly(out, r.t, x0, y0, v * Math.cos(r.ph), v * Math.sin(r.ph), r.ph, function (x, y) { return Math.hypot(x, y) >= R || y <= -R; }, U, 4);
    } else if (r.why === 'back' || r.why === 'loop') {
      var vf = Math.abs(R * r.w), last = out[out.length - 1].t, sg = r.why === 'back' ? -1 : 1;
      for (var t2 = 0.01; vf * t2 < 0.85 && t2 < 3; t2 += 0.01) out.push({ t: last + t2, x: sg * vf * t2, y: -R, vx: sg * vf, vy: 0, kind: 'floor', ang: 0, F: m * G, at: 0, K: M3.K(vf), U: 0, E: M3.K(vf) });
    }
    return { pts: out, ev: ev, sec: 4, done: r.why };
  },
  /* 3-3 高さのあるループコースター：高さ h（床から）の点 A から、傾き α の斜面を初速 v0 で下り、床を通って 3-2 と同じループへ。
     h は r の倍数（hK × r）。斜面と床はなめらかにつながっている（速さはそのまま）。点の kind：'slope'（斜面）・'floor'・'circle'・'fly'。
     ループを回れずに滑り戻ったら、床から斜面を上って、止まるところまで（そのあとまた下る：往復）。2026-10-14 千葉さん */
  H7: { alpha: 45 * Math.PI / 180, xj: -0.80 },
  b7: function (v0, hK) {
    var m = M3.m, R = M3.R, out = [], ev = null, U = function (y) { return m * G * (y + R); };
    var al = M3.H7.alpha, xj = M3.H7.xj, ca = Math.cos(al), sa = Math.sin(al), h = (hK === undefined ? 3 : hK) * R, gs = G * sa;
    var hTop = h + v0 * v0 / (2 * G);                                   /* 斜面の上でいちばん高い所（滑り戻ったとき） */
    var slopePt = function (tt, u, du) {                               /* u：斜面の下はしからの道のり（上が正）、du = du/dt */
      var x = xj - u * ca, y = -R + u * sa, vx = -du * ca, vy = du * sa, K = 0.5 * m * du * du;
      out.push({ t: tt, x: x, y: y, vx: vx, vy: vy, kind: 'slope', ang: 0, F: m * G * ca, at: gs, K: K, U: U(y), E: K + U(y) });
    };
    /* ① 斜面を下る：u = uA − v0 t − ½ g sinα t² が 0 になるまで */
    var uA = h / sa, t1 = (-v0 + Math.sqrt(v0 * v0 + 2 * gs * uA)) / gs, t = 0;
    for (var tt = 0; tt < t1; tt += 0.01) slopePt(tt, uA - v0 * tt - 0.5 * gs * tt * tt, -v0 - gs * tt);
    var vb = v0 + gs * t1; slopePt(t1, 0, -vb); t = t1;
    /* ② 床を右へ（x = xj → 0） */
    var tf = -xj / vb;
    for (var t2 = 0.01; t2 < tf; t2 += 0.01) out.push({ t: t + t2, x: xj + vb * t2, y: -R, vx: vb, vy: 0, kind: 'floor', ang: 0, F: m * G, at: 0, K: M3.K(vb), U: 0, E: M3.K(vb) });
    t += tf;
    /* ③ ループ（3-2 と同じ。最高点で N がちょうど 0 になる h = 5r/2 でも離れないよう、判定にわずかな余裕） */
    var rec = function (tt, ph, w) {
      var v = R * w, y = -R * Math.cos(ph), K = 0.5 * m * v * v;
      out.push({ t: tt, x: R * Math.sin(ph), y: y, vx: v * Math.cos(ph), vy: v * Math.sin(ph), kind: 'circle', ang: ph, F: m * (R * w * w + G * Math.cos(ph)), at: -G * Math.sin(ph), K: K, U: U(y), E: K + U(y) });
    };
    var r = M3.arc(out, t, 0, vb / R, function (ph) { return -G / R * Math.sin(ph); }, rec, function (ph, w) {
      var N = R * w * w + G * Math.cos(ph);
      if (N < -1e-6 && Math.abs(R * w) > 0.05) return 'off';
      if (w < 0 && ph <= 0) return 'back';
      if (ph >= 2 * Math.PI) return 'loop';
      return null;
    }, t + 12, function (ph, w) { return R * w * w + G * Math.cos(ph); });
    if (r.why === 'off') {
      ev = { kind: 'off', t: r.t, ang: r.ph };
      var x0 = R * Math.sin(r.ph), y0 = -R * Math.cos(r.ph), v = R * r.w;
      M3.fly(out, r.t, x0, y0, v * Math.cos(r.ph), v * Math.sin(r.ph), r.ph, function (x, y) { return Math.hypot(x, y) >= R || y <= -R; }, U, r.t + 4);
    } else if (r.why === 'loop') {
      var vf = Math.abs(R * r.w), last = out[out.length - 1].t;
      for (var t3 = 0.01; vf * t3 < 0.85 && t3 < 3; t3 += 0.01) out.push({ t: last + t3, x: vf * t3, y: -R, vx: vf, vy: 0, kind: 'floor', ang: 0, F: m * G, at: 0, K: M3.K(vf), U: 0, E: M3.K(vf) });
    } else if (r.why === 'back') {                                     /* 滑り戻る：床を左へ → 斜面を上って止まる → また下る（往復を 6 秒まで） */
      var vr = Math.abs(R * r.w), tb = out[out.length - 1].t, tEnd = tb + 6;
      while (tb < tEnd) {
        var tf2 = -xj / vr;
        for (var t4 = 0.01; t4 < tf2; t4 += 0.01) out.push({ t: tb + t4, x: -vr * t4, y: -R, vx: -vr, vy: 0, kind: 'floor', ang: 0, F: m * G, at: 0, K: M3.K(vr), U: 0, E: M3.K(vr) });
        tb += tf2;
        var tu = 2 * vr / gs;                                          /* 斜面を上って下りてくるまで */
        for (var t5 = 0; t5 <= tu + 1e-9; t5 += 0.01) slopePt(tb + t5, vr * t5 - 0.5 * gs * t5 * t5, vr - gs * t5);
        tb += tu;
        for (var t6 = 0.01; t6 < tf2; t6 += 0.01) out.push({ t: tb + t6, x: xj + vr * t6, y: -R, vx: vr, vy: 0, kind: 'floor', ang: 0, F: m * G, at: 0, K: M3.K(vr), U: 0, E: M3.K(vr) });
        tb += tf2;
        var r2 = M3.arc(out, tb, 0, vr / R, function (ph) { return -G / R * Math.sin(ph); }, rec, function (ph, w) { return (w < 0 && ph <= 0) ? 'back' : null; }, tb + 6);
        tb = r2.t;
      }
    }
    return { pts: out, ev: ev, sec: 7, done: r.why, th0: hK, geo: { xj: xj, alpha: al, hTop: Math.max(hK <= 3 ? 3 * R : h, r.why === 'back' ? hTop : h) } };   /* h ≤ 3r では斜面の高さは 3r に固定（小球を置く位置だけが変わる。2026-10-14 千葉さん） */
  },
  /* 4-2 糸による円運動（最下点から）：最下点で右向きに v0。S < 0 になったら糸がたるんで放物運動（糸がまた張ったら止める）。
     1 周したら止める。v0 ≤ √(2gr) はふりこのように往復する */
  b5: function (v0) {
    var m = M3.m, R = M3.R, out = [], ev = null, U = function (y) { return m * G * (y + R); };
    var rec = function (tt, ph, w) {
      var v = R * w, y = -R * Math.cos(ph), K = 0.5 * m * v * v;
      out.push({ t: tt, x: R * Math.sin(ph), y: y, vx: v * Math.cos(ph), vy: v * Math.sin(ph), kind: 'circle', ang: ph, F: m * (R * w * w + G * Math.cos(ph)), at: -G * Math.sin(ph), K: K, U: U(y), E: K + U(y) });
    };
    var r = M3.arc(out, 0, 0, v0 / R, function (ph) { return -G / R * Math.sin(ph); }, rec, function (ph, w) {
      if (R * w * w + G * Math.cos(ph) < -1e-7 && Math.abs(R * w) > 0.05) return 'slack';
      if (ph >= 2 * Math.PI) return 'loop';
      return null;
    }, 3.2, function (ph, w) { return R * w * w + G * Math.cos(ph); });
    if (r.why === 'slack') {
      ev = { kind: 'slack', t: r.t, ang: r.ph };
      var v = R * r.w;
      M3.fly(out, r.t, R * Math.sin(r.ph), -R * Math.cos(r.ph), v * Math.cos(r.ph), v * Math.sin(r.ph), r.ph, function (x, y) { return Math.hypot(x, y) >= R; }, U, 3);
    }
    return { pts: out, ev: ev, sec: 5, done: r.why };
  }
};
