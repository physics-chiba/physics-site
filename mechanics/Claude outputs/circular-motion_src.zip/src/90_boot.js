/* =========================================================================
   90_boot.js … 自動テスト用の窓口（window.TEST）と検算
   ========================================================================= */
'use strict';
function check() {
  var out = {};
  /* モード1：糸を切った直後の速度が、切る直前の v⃗ と向きも大きさも同じ */
  var worst = 0;
  [[0.5, TAU / 3, 1.3], [0.2, 3.1, 0.77], [0.8, 0.5, 5.2]].forEach(function (c) {
    var r = c[0], w = c[1], tc = c[2];
    var b = M1.state(r, w, tc - 1e-6, null), a = M1.state(r, w, tc + 1e-6, tc), a2 = M1.state(r, w, tc + 0.5, tc);
    worst = Math.max(worst, Math.abs(a.vx - b.vx), Math.abs(a.vy - b.vy), Math.abs(Math.hypot(a2.vx, a2.vy) - r * w));
    /* 直線上：0.5 s で v×0.5 だけ進む */
    worst = Math.max(worst, Math.abs(Math.hypot(a2.x - a2.x0, a2.y - a2.y0) - r * w * 0.5));
  });
  out.m1_cut_velocity_err = +worst.toExponential(2);
  /* モード1：v = rω、a = rω²、F = mrω²、T = 2π/ω、n = 1/T と、スライダーの連動（ω↔T、F↔a） */
  var D = M1.derive(0.40, Math.PI / 2);
  /* 既定のまま、どの瞬間に糸を切っても、切った瞬間から 1 秒ごとのストロボが 3 個以上並ぶ */
  var mn = Infinity; for (var tc = 0; tc < 4; tc += 0.01) mn = Math.min(mn, Math.floor(M1.exitAfter(0.40, Math.PI / 2, tc)) + 1);
  /* 鍵：既定（ω・T・r 固定）では v・a・F は動かせない。r の鍵を外せば v が変えられ、ω は変わらない */
  var cur = { r: 0.40, w: Math.PI / 2 };
  out.m1_lock_default_v_blocked_when_r_locked = !M1.solve('v', 1.0, cur, { w: 1, T: 1, n: 1, r: 1 }).ok;
  var s1 = M1.solve('v', 1.0, cur, { w: 1, T: 1 });
  out.m1_lock_v_changes_r = s1.ok && Math.abs(s1.w - Math.PI / 2) < 1e-12 && Math.abs(s1.r * s1.w - 1.0) < 1e-9;
  var s2 = M1.solve('w', Math.PI, cur, { r: 1 });
  out.m1_lock_w_changes = s2.ok && s2.r === 0.40 && s2.w === Math.PI;
  out.m1_lock_w_blocked_by_T = !M1.solve('w', Math.PI, cur, { r: 1, T: 1 }).ok;
  var s3 = M1.solve('w', Math.PI, cur, { v: 1 });
  out.m1_lock_keep_v = s3.ok && Math.abs(s3.r * s3.w - 0.40 * Math.PI / 2) < 1e-9;
  out.m1_strobe_min_dots = mn;
  out.m1_default = { r: D.r, v: +D.v.toFixed(4), a: +D.a.toFixed(4), F: +D.F.toFixed(5), w: +D.w.toFixed(4), T: +D.T.toFixed(4), n: +D.n.toFixed(4) };
  out.m1_link_T = +Math.abs(M1.omegaFrom('T', 4, 0.5, 1) - TAU / 4).toExponential(2);
  out.m1_link_F = +Math.abs(M1.derive(0.5, M1.omegaFrom('F', 0.3, 0.5, 1)).F - 0.3).toExponential(2);
  out.m1_link_a = +Math.abs(M1.derive(0.5, M1.omegaFrom('a', 3, 0.5, 1)).a - 3).toExponential(2);
  /* モード2：慣性系と非慣性系で同じ式（左辺と右辺）になるか。円錐振り子の 2 つの式、ばねの連動、すべり出す ω */
  var e4 = 0; [3.3, 4, 5.5, 7].forEach(function (w) { var C = M2.s4, th = C.thOf(w), S = C.m * C.L * w * w, r = C.L * Math.sin(th);
    e4 = Math.max(e4, Math.abs(C.m * r * w * w - S * Math.sin(th)), Math.abs(S * Math.cos(th) - C.m * G)); });
  out.m2_conical_err = +e4.toExponential(2);
  var e2 = 0; [1, 3, 5, 8].forEach(function (w) { var C = M2.s2, x = C.xOf(w); e2 = Math.max(e2, Math.abs(C.k * x - C.m * (C.l + x) * w * w), Math.abs(C.wOf(x) - w)); });
  out.m2_spring_err = +e2.toExponential(2);
  out.m2_slip_w = +M2.s1.wSlip(0.30, 0.40).toFixed(4);
  /* すべり出す直前（ω = ω_slip − 0.01）はすべらず、直後（+0.01）はすべる */
  var ws = M2.s1.wSlip(0.30, 0.40);
  out.m2_slip_switch = !M2.s1.state(ws - 0.01, 0.30, 0.40, 1).slip && M2.s1.state(ws + 0.01, 0.30, 0.40, 0.5).slip;
  /* 2-3：糸が切れる ω₀ で、張力がちょうど S0 */
  out.m2_cut_S0_err = +Math.abs(M2.s3.m * 0.4 * Math.pow(M2.s3.wCut(0.4), 2) - M2.s3.S0).toExponential(2);
  /* モード3：離れる角が公式と一致、境界の初速、力学的エネルギーの保存、非慣性系の中心方向のつりあい */
  var R3 = M3.R, eA = 0;
  [3.2, 4, 4.9].forEach(function (v0) { eA = Math.max(eA, Math.abs(M3.traj(1, v0).ev.ang - Math.acos((2 * G * R3 - v0 * v0) / (3 * G * R3)))); });
  [0.1, 1, 2.2].forEach(function (v0) { eA = Math.max(eA, Math.abs(M3.traj(2, v0).ev.ang - Math.acos(2 / 3 + v0 * v0 / (3 * G * R3)))); });
  [1, 2, 3.5].forEach(function (v0) { eA = Math.max(eA, Math.abs(Math.abs(M3.traj(3, v0).ev.ang) - Math.acos(-v0 * v0 / (3 * G * R3)))); });
  out.m3_leave_angle_err = +eA.toExponential(2);
  var v5 = Math.sqrt(5 * G * R3), v3 = Math.sqrt(3 * G * R3), v2 = Math.sqrt(2 * G * R3);
  out.m3_s1_top_just_above_5gr = M3.traj(1, v5 + 0.002).ev.kind === 'top' && M3.traj(1, v5 - 0.02).ev.kind === 'off';
  out.m3_s1_back_below_2gr = !M3.traj(1, v2 - 0.01).ev && M3.traj(1, v2 + 0.02).ev !== null;
  out.m3_s3_loop_just_above_3gr = !M3.traj(3, v3 + 0.002).ev && M3.traj(3, v3 - 0.02).ev !== null;
  var dr = 0, bal = 0;
  [[1, 4], [1, 5.5], [2, 0.1], [3, 2], [3, 4.5]].forEach(function (c) {
    var tr = M3.traj(c[0], c[1]), E0 = tr.pts[0].E;
    tr.pts.forEach(function (p) {
      dr = Math.max(dr, Math.abs(p.E - E0) / E0);
      if (p.kind !== 'circle') return;
      var v2p = p.vx * p.vx + p.vy * p.vy, mg = M3.m * G;
      var b = c[0] === 2 ? mg * Math.cos(p.ang) - p.F - M3.m * v2p / R3 : p.F - mg * Math.cos(p.ang) - M3.m * v2p / R3;
      bal = Math.max(bal, Math.abs(b));
    });
  });
  out.m3_energy_drift = +dr.toExponential(2);
  out.m3_rot_balance_err = +bal.toExponential(2);
  return out;
}
window.TEST = {
  check: check, sims: SIMS, byId: SIM_BY_ID, modes: MODES,
  activate: function (id) { activateMode(id); },
  sim: function (id) { return SIM_BY_ID[id]; },
  setT: function (id, t) { var s = SIM_BY_ID[id]; s.playing = false; s.setT(t); s.syncPlayLabel(); },
  setVar: function (id, k, x) { var s = SIM_BY_ID[id]; if (s.def.onVar) s.def.onVar(s, k, x); else s.v[k] = x; s.changed(k); }
};
