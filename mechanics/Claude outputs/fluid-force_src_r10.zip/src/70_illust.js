/* ①-2 の右の列：「水分子くん」のイラスト（SVG）
   深いところの水分子ほど、上にのっている仲間が多く、強く押されている（＝水圧が大きい）ことをイメージさせる */
function molFace(x, y, s, mood){
  /* mood 0：にこにこ、1：ふつう、2：つらい、3：とてもつらい（汗） */
  var e = '';
  var fill = ["#eaf6ff","#dcefff","#cfe6fb","#c2ddf6"][mood];
  e += '<rect x="'+x+'" y="'+y+'" width="'+s+'" height="'+s+'" rx="'+(s*0.18)+'" fill="'+fill+'" stroke="#2f6f9f" stroke-width="1.4"/>';
  var cx=x+s/2, ey=y+s*0.40, ex=s*0.17;
  if(mood===3){   /* ぎゅっと閉じた目 */
    e += '<path d="M'+(cx-ex-4)+' '+(ey-3)+' l4 3 l-4 3 M'+(cx+ex+4)+' '+(ey-3)+' l-4 3 l4 3" fill="none" stroke="#1b2b3a" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>';
  } else {
    e += '<circle cx="'+(cx-ex)+'" cy="'+ey+'" r="2.2" fill="#1b2b3a"/><circle cx="'+(cx+ex)+'" cy="'+ey+'" r="2.2" fill="#1b2b3a"/>';
  }
  var my=y+s*0.70, mw=s*0.18;
  if(mood===0) e += '<path d="M'+(cx-mw)+' '+(my-2)+' Q'+cx+' '+(my+5)+' '+(cx+mw)+' '+(my-2)+'" fill="none" stroke="#1b2b3a" stroke-width="1.5" stroke-linecap="round"/>';
  else if(mood===1) e += '<path d="M'+(cx-mw)+' '+my+' L'+(cx+mw)+' '+my+'" stroke="#1b2b3a" stroke-width="1.5" stroke-linecap="round"/>';
  else e += '<path d="M'+(cx-mw)+' '+(my+3)+' Q'+cx+' '+(my-4)+' '+(cx+mw)+' '+(my+3)+'" fill="none" stroke="#1b2b3a" stroke-width="1.5" stroke-linecap="round"/>';
  if(mood>=2) e += '<path d="M'+(x+s*0.86)+' '+(y+s*0.12)+' q3 5 0 7 q-3 -2 0 -7z" fill="#7cc4f0" stroke="#2f6f9f" stroke-width=".8"/>';
  return e;
}
function molArrows(x, y, s, L){
  var c="#b58900", a='';
  var ar=function(x1,y1,x2,y2){ var dx=x2-x1, dy=y2-y1, d=Math.hypot(dx,dy), ux=dx/d, uy=dy/d, h=6;
    return '<path d="M'+x1+' '+y1+' L'+(x2-ux*h*0.7)+' '+(y2-uy*h*0.7)+'" stroke="'+c+'" stroke-width="2.2" stroke-linecap="round"/>'+
      '<path d="M'+x2+' '+y2+' L'+(x2-ux*h-uy*3.2)+' '+(y2-uy*h+ux*3.2)+' L'+(x2-ux*h+uy*3.2)+' '+(y2-uy*h-ux*3.2)+'z" fill="'+c+'"/>'; };
  var m=x+s/2, n=y+s/2;
  a += ar(m, y-3-L, m, y-3) + ar(m, y+s+3+L, m, y+s+3) + ar(x-3-L, n, x-3, n) + ar(x+s+3+L, n, x+s+3, n);
  return a;
}
function molKunSVG(){
  var s=30, x0=18, y0=66, h='';
  h += '<svg class="molkun" viewBox="0 0 380 262" role="img" aria-label="水分子をイメージした図。深いところの水分子ほど、上に載っている仲間が多く、強く押されている">';
  /* 吹き出し */
  h += '<rect x="6" y="4" width="196" height="44" rx="14" fill="#fff" stroke="#2f6f9f" stroke-width="1.3"/>'+
       '<path d="M74 47 l8 12 l6 -12" fill="#fff" stroke="#2f6f9f" stroke-width="1.3"/><path d="M75 46 h12" stroke="#fff" stroke-width="2.4"/>'+
       '<text x="104" y="22" text-anchor="middle" font-size="11.5" font-weight="700" fill="#1f4e79">ぼくたち水分子は、隙間なく</text>'+
       '<text x="104" y="38" text-anchor="middle" font-size="11.5" font-weight="700" fill="#1f4e79">並んで、押し合っているよ</text>';
  /* 水そう */
  h += '<path d="M'+(x0-4)+' '+(y0-6)+' V'+(y0+5*s+4)+' H'+(x0+5*s+4)+' V'+(y0-6)+'" fill="none" stroke="#3a414c" stroke-width="2"/>';
  h += '<path d="M'+(x0-4)+' '+y0+' H'+(x0+5*s+4)+'" stroke="#4f8fc0" stroke-width="2"/>';
  for(var r=0;r<5;r++) for(var k=0;k<5;k++) h += molFace(x0+k*s+1, y0+r*s+1, s-2, Math.min(3,Math.floor(r*0.85)));
  h += '<text x="'+(x0+5*s+12)+'" y="'+(y0+12)+'" font-size="10.5" fill="#69717d">浅い</text>';
  h += '<text x="'+(x0+5*s+12)+'" y="'+(y0+5*s-4)+'" font-size="10.5" fill="#69717d">深い</text>';
  h += '<path d="M'+(x0+5*s+18)+' '+(y0+20)+' V'+(y0+5*s-18)+'" stroke="#9aa1ab" stroke-width="1.2"/><path d="M'+(x0+5*s+14)+' '+(y0+5*s-24)+' l4 7 l4 -7z" fill="#9aa1ab"/>';
  /* 右：1 つだけ取り出して比べる */
  var bx=262;
  h += '<rect x="214" y="58" width="160" height="196" rx="10" fill="none" stroke="#9aa1ab" stroke-dasharray="4 3"/>';
  h += '<text x="294" y="74" text-anchor="middle" font-size="11" font-weight="700" fill="#3a414c">1 つの水分子が押される力</text>';
  h += molArrows(bx, 92, 28, 8) + molFace(bx, 92, 28, 0);
  h += '<text x="294" y="142" text-anchor="middle" font-size="10.5" fill="#3a414c">浅い：上の仲間が少ない</text>';
  h += '<path d="M222 154 H366" stroke="#9aa1ab" stroke-dasharray="4 3"/>';
  h += molArrows(bx, 178, 28, 22) + molFace(bx, 178, 28, 3);
  h += '<text x="294" y="246" text-anchor="middle" font-size="10.5" fill="#3a414c">深い：上の仲間が多い</text>';
  h += '</svg>';
  return h;
}

/* ①-2：水の中に物体を入れたときの水分子（上の面を押す力より、下の面を押す力の方が大きい） */
function molKun2SVG(){
  var s=30, x0=20, y0=34, cols=5, rows=6, h='';
  h += '<svg class="molkun" viewBox="0 0 270 250" role="img" aria-label="水の中に物体を入れると、上の面は弱く、下の面は強く水分子に押される">';
  h += '<path d="M'+(x0-4)+' '+(y0-14)+' V'+(y0+rows*s+4)+' H'+(x0+cols*s+4)+' V'+(y0-14)+'" fill="none" stroke="#3a414c" stroke-width="2"/>';
  h += '<path d="M'+(x0-4)+' '+y0+' H'+(x0+cols*s+4)+'" stroke="#4f8fc0" stroke-width="2"/>';
  for(var r=0;r<rows;r++) for(var k=0;k<cols;k++){
    if(r>=1 && r<=4 && k>=1 && k<=3) continue;
    h += molFace(x0+k*s+1, y0+r*s+1, s-2, Math.min(3,Math.floor(r*0.7)));
  }
  var ox=x0+s, oy=y0+s, ow=3*s, oh=4*s;
  h += '<rect x="'+ox+'" y="'+oy+'" width="'+ow+'" height="'+oh+'" fill="#f3e3ea" stroke="#2b323c" stroke-width="1.6"/>';
  h += '<text x="'+(ox+ow/2)+'" y="'+(oy+oh/2-4)+'" text-anchor="middle" font-size="12" font-weight="700" fill="#3a414c">物体</text>';
  h += '<text x="'+(ox+ow/2)+'" y="'+(oy+oh/2+13)+'" text-anchor="middle" font-size="10.5" fill="#3a414c">（底面積 S）</text>';
  var c="#b58900";
  var ar=function(x1,y1,x2,y2){ var dx=x2-x1, dy=y2-y1, d=Math.hypot(dx,dy), ux=dx/d, uy=dy/d, hh=6;
    return '<path d="M'+x1+' '+y1+' L'+(x2-ux*hh*0.7)+' '+(y2-uy*hh*0.7)+'" stroke="'+c+'" stroke-width="2.2" stroke-linecap="round"/>'+
      '<path d="M'+x2+' '+y2+' L'+(x2-ux*hh-uy*3.2)+' '+(y2-uy*hh+ux*3.2)+' L'+(x2-ux*hh+uy*3.2)+' '+(y2-uy*hh-ux*3.2)+'z" fill="'+c+'"/>'; };
  for(var i=0;i<3;i++){ var x=ox+s*(i+0.5);
    h += ar(x, oy+2, x, oy+12);                 /* 上の面：短い（下向き） */
    h += ar(x, oy+oh-2, x, oy+oh-40); }         /* 下の面：長い（上向き） */
  for(var j=0;j<4;j++){ var y=oy+s*(j+0.5), L=10+j*5;
    h += ar(ox+2, y, ox+2+L, y) + ar(ox+ow-2, y, ox+ow-2-L, y); }
  /* 深さの寸法 */
  var dx2=x0+cols*s+22;
  h += '<path d="M'+(dx2-8)+' '+y0+' H'+(dx2+16)+'" stroke="#9aa1ab" stroke-dasharray="3 3"/>';
  h += '<path d="M'+(ox+ow)+' '+oy+' H'+(dx2+4)+' M'+(ox+ow)+' '+(oy+oh)+' H'+(dx2+34)+'" stroke="#9aa1ab" stroke-dasharray="3 3"/>';
  h += '<path d="M'+dx2+' '+(y0+3)+' V'+(oy-3)+'" stroke="#2f6f9f" stroke-width="1.2"/><path d="M'+(dx2+28)+' '+(y0+3)+' V'+(oy+oh-3)+'" stroke="#2f6f9f" stroke-width="1.2"/>';
  h += '<text x="'+(dx2+4)+'" y="'+(y0+s/2+4)+'" font-size="12" font-style="italic" fill="#2f6f9f">h₁</text>';
  h += '<text x="'+(dx2+32)+'" y="'+(oy+oh/2+4)+'" font-size="12" font-style="italic" fill="#2f6f9f">h₂</text>';
  h += '</svg>';
  return h;
}

/* ②-1：空気の分子をイメージ（地上ほど分子が多く、物体に強くぶつかる） */
function airKunSVG(){
  var h='';
  h += '<svg class="molkun" viewBox="0 0 380 262" role="img" aria-label="空気の分子をイメージした図。地上に近いほど分子が多く、物体に強く押す">';
  h += '<rect x="6" y="4" width="200" height="44" rx="14" fill="#fff" stroke="#2f6f9f" stroke-width="1.3"/>'+
       '<path d="M70 47 l8 12 l6 -12" fill="#fff" stroke="#2f6f9f" stroke-width="1.3"/><path d="M71 46 h12" stroke="#fff" stroke-width="2.4"/>'+
       '<text x="106" y="22" text-anchor="middle" font-size="11.5" font-weight="700" fill="#1f4e79">ぼくたち空気の分子は、飛び回って</text>'+
       '<text x="106" y="38" text-anchor="middle" font-size="11.5" font-weight="700" fill="#1f4e79">ものにぶつかっているよ</text>';
  /* 空の柱：上ほど分子が少ない */
  var bx=14, by=64, bw=170, bh=180;
  h += '<rect x="'+bx+'" y="'+by+'" width="'+bw+'" height="'+bh+'" fill="#eef6fd" stroke="#9aa1ab"/>';
  h += '<path d="M'+bx+' '+(by+bh)+' H'+(bx+bw)+'" stroke="#2b323c" stroke-width="2"/>';
  var rowsY=[80,106,128,148,166,184,202,220], per=[2,2,3,3,4,5,6,7];
  rowsY.forEach(function(y,i){ var n=per[i];
    for(var k=0;k<n;k++){ var x=bx+12+(bw-24)*(k+0.5+((i%2)?0.25:-0.1))/n; x=Math.min(bx+bw-12,Math.max(bx+12,x));
      var mood=i<3?0:(i<6?1:2), ss=16;
      h += molFace(x-ss/2, y-ss/2, ss, mood); } });
  h += '<text x="'+(bx+bw+8)+'" y="'+(by+14)+'" font-size="10.5" fill="#69717d">上空</text>';
  h += '<text x="'+(bx+bw+8)+'" y="'+(by+bh-4)+'" font-size="10.5" fill="#69717d">地上</text>';
  /* 右：同じ物体が受ける力を比べる */
  var ar=function(x1,y1,x2,y2,c){ var dx=x2-x1, dy=y2-y1, d=Math.hypot(dx,dy), ux=dx/d, uy=dy/d, hh=6;
    return '<path d="M'+x1+' '+y1+' L'+(x2-ux*hh*0.7)+' '+(y2-uy*hh*0.7)+'" stroke="'+c+'" stroke-width="2.2" stroke-linecap="round"/>'+
      '<path d="M'+x2+' '+y2+' L'+(x2-ux*hh-uy*3.2)+' '+(y2-uy*hh+ux*3.2)+' L'+(x2-ux*hh+uy*3.2)+' '+(y2-uy*hh-ux*3.2)+'z" fill="'+c+'"/>'; };
  var box=function(cx,cy,L){ var w=20,hh2=30, s2='<rect x="'+(cx-w/2)+'" y="'+(cy-hh2/2)+'" width="'+w+'" height="'+hh2+'" fill="#fff" stroke="#2b323c" stroke-width="1.4"/>';
    s2 += ar(cx,cy-hh2/2-3-L,cx,cy-hh2/2-3,"#b58900")+ar(cx,cy+hh2/2+3+L,cx,cy+hh2/2+3,"#b58900")+ar(cx-w/2-3-L,cy,cx-w/2-3,cy,"#b58900")+ar(cx+w/2+3+L,cy,cx+w/2+3,cy,"#b58900");
    return s2; };
  h += '<rect x="222" y="58" width="152" height="196" rx="10" fill="none" stroke="#9aa1ab" stroke-dasharray="4 3"/>';
  h += '<text x="298" y="74" text-anchor="middle" font-size="11" font-weight="700" fill="#3a414c">物体が押される力</text>';
  h += box(298,108,7);
  h += '<text x="298" y="150" text-anchor="middle" font-size="10.5" fill="#3a414c">上空：ぶつかる分子が少ない</text>';
  h += '<path d="M230 160 H366" stroke="#9aa1ab" stroke-dasharray="4 3"/>';
  h += box(298,198,18);
  h += '<text x="298" y="246" text-anchor="middle" font-size="10.5" fill="#3a414c">地上：ぶつかる分子が多い</text>';
  h += '</svg>';
  return h;
}
