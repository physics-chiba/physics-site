/* ---------------- ①-1 圧力と力の違い（吸盤） ----------------
   第8回：日本機械学会の「吸盤と大気圧」の実験をもとに、テーブルに貼りついた吸盤を、上の空気の分子が押す場面にした。
   吸盤の中は空気が押し出されて（ほぼ）真空。大気圧 p＝1.0×10⁵ Pa が吸盤の面積 S（テーブルに投影した円）に加わる。
   吸盤の直径を変えると、圧力の矢印の長さは同じまま本数が増え、力 F＝pS が大きくなる。
   ３次元表示が既定（ドラッグで視点、「斜め上から」「横から」）。２次元表示は真横から見た断面。
   世界座標［cm］：x 右、y 奥、z 上。テーブルの上面 z＝0、吸盤の中心は原点。 */
var S10 = {
  P:1.0e5, L:6, ZT:7, N:110,
  init:function(sec){
    var self=this; this.sec=sec;
    this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.d=6; this.hits=0; this.mols=null; this.flash=[]; this.v3=true; this.cam={az:-35, el:25};
    this.run=new Runner({
      begin:function(){ self.hits=0; self.flash=[]; },
      step:function(dt){ self.step(dt); return self.run.t>90; },
      draw:function(){ self.draw(); },
      reset:function(){ self.hits=0; self.flash=[]; self.mols=null; },
      info:function(r){ return '時間 <b>'+r.t.toFixed(1)+'</b> s<br>吸盤に当たる分子 10 s あたり 約 <b>'+(r.t>1? Math.round(self.hits/r.t*10) : '—')+'</b> 個'; }
    });
    this.run.bind(sec);
    this.sl=wireSlider(sec,"d",function(v){ return v.toFixed(1)+" cm"; },function(v){ self.d=v; self.hits=0; if(self.run.state==="run") self.run.t=0; else self.run.touch(); self.draw(); self.run.label(); });
    /* ３次元表示（既定で ON） */
    var b3=sec.querySelector(".v3btn"), vb=document.createElement("div"); vb.className="viewbtns3";
    vb.innerHTML='<button class="b tiny3" type="button" data-az="-35" data-el="25">斜め上から</button><button class="b tiny3" type="button" data-az="0" data-el="0">横から</button>';
    this.cv.parentElement.style.position="relative"; this.cv.parentElement.appendChild(vb); this.vb=vb;
    var set3=function(on){ self.v3=on; b3.classList.toggle("on", on); b3.setAttribute("aria-pressed", on); b3.textContent=on? "２次元表示にする" : "３次元表示"; vb.hidden=!on; self.draw(); };
    this.set3=set3;
    b3.addEventListener("click", function(){ b3.classList.remove("pglow"); set3(!self.v3); });
    vb.querySelectorAll("button").forEach(function(b){ b.addEventListener("click", function(){ self.cam.az=parseFloat(b.dataset.az); self.cam.el=parseFloat(b.dataset.el); self.draw(); }); });
    /* 視点ドラッグ（３次元表示のとき） */
    var cv=this.cv, last=null;
    cv.addEventListener("pointerdown", function(ev){ if(!self.v3) return; last={x:ev.clientX,y:ev.clientY}; cv.setPointerCapture(ev.pointerId); ev.preventDefault(); });
    cv.addEventListener("pointermove", function(ev){ if(!self.v3 || !last) return; var dx=ev.clientX-last.x, dy=ev.clientY-last.y; last={x:ev.clientX,y:ev.clientY};
      self.cam.az=((self.cam.az - dx*0.32 + 540)%360)-180; self.cam.el=clamp(self.cam.el - dy*0.26, 0, 88); self.draw(); ev.preventDefault(); });
    var end=function(){ last=null; }; cv.addEventListener("pointerup", end); cv.addEventListener("pointercancel", end);
    sec.querySelector(".resetall").addEventListener("click", function(){
      self.d=6; self.sl.set(6); self.cam={az:-35, el:25}; set3(false); b3.classList.add("pglow"); self.run.rate=1;
      var sb=sec.querySelector(".slowb"); if(sb) sb.classList.remove("on"); self.run.reset(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    set3(false);   /* 第9回：はじめは２次元表示。「３次元表示」ボタンは押されるまで光らせる */
  },
  R:function(){ return this.d/2; },
  S:function(){ return Math.PI*this.R()*this.R(); },          /* ［cm²］ */
  F:function(){ return this.P*this.S()*1e-4; },               /* ［N］ */
  cupZ:function(r){ var R=this.R(); return r<R? 0.55*(1-(r/R)*(r/R))+0.12 : 0; },   /* 吸盤の上の面の高さ */
  make:function(){
    var a=[], L=this.L;
    for(var i=0;i<this.N;i++){ var u=Math.random(), v=Math.random(), w=Math.random(), th=Math.random()*6.283, ph=Math.acos(2*Math.random()-1), sp=7+Math.random()*6;
      a.push({x:-L+u*2*L, y:-L+v*2*L, z:1.2+w*(this.ZT-1.4), vx:sp*Math.sin(ph)*Math.cos(th), vy:sp*Math.sin(ph)*Math.sin(th), vz:sp*Math.cos(ph)}); }
    this.mols=a;
  },
  step:function(dt){
    if(!this.mols) return; var L=this.L, ZT=this.ZT, R=this.R(), self=this, rr=0.25;
    this.mols.forEach(function(m){
      m.x+=m.vx*dt; m.y+=m.vy*dt; m.z+=m.vz*dt;
      if(m.x<-L){ m.x=-2*L-m.x; m.vx=-m.vx; } if(m.x>L){ m.x=2*L-m.x; m.vx=-m.vx; }
      if(m.y<-L){ m.y=-2*L-m.y; m.vy=-m.vy; } if(m.y>L){ m.y=2*L-m.y; m.vy=-m.vy; }
      if(m.z>ZT){ m.z=2*ZT-m.z; m.vz=-m.vz; }
      var r=Math.hypot(m.x,m.y), zb=self.cupZ(r)+rr;
      if(m.z<zb && m.vz<0){ m.z=2*zb-m.z; m.vz=-m.vz; if(r<R){ self.hits++; self.flash.push({x:m.x,y:m.y,z:zb-rr,a:1}); } }
    });
    for(var i=this.flash.length-1;i>=0;i--){ this.flash[i].a-=dt*3.5; if(this.flash[i].a<=0) this.flash.splice(i,1); }
  },
  draw:function(){
    if(!this.mols) this.make();
    if(this.v3) this.draw3(); else this.draw2();
    var S=this.S(), F=this.F();
    this.msg.innerHTML='大気圧 <i>p</i> = <span class="num">1.0×10⁵</span> Pa　吸盤の面積 <i>S</i> = <span class="num">'+fmt2(S*1e-4)+'</span> m²（<span class="num">'+(S<10? S.toFixed(1) : S.toFixed(0))+'</span> cm²）<br>'+
      '力 <i>F</i> = <i>pS</i> = <span class="num">'+fmt2(F)+'</span> N（約 <span class="num">'+(F/9.8<10? (F/9.8).toFixed(1) : (F/9.8).toFixed(0))+'</span> kg の物体にはたらく重力の大きさ）';
  },
  /* 共通：圧力の矢印を立てる点（吸盤の円の中、格子状） */
  /* 第9回：圧力の矢印の本数を面積に比例させる。３次元は 1 cm² に 1 本（ひまわりの種のならび方で円の中に均等に） */
  arrowPts:function(){ var R=this.R(), n=Math.max(1,Math.round(Math.PI*R*R)), a=[], ga=Math.PI*(3-Math.sqrt(5));
    for(var i=0;i<n;i++){ var rr=R*0.92*Math.sqrt((i+0.5)/n), th=i*ga; a.push([rr*Math.cos(th), rr*Math.sin(th)]); }
    return a; },
  Flen:function(){ return 0.8+3.8*this.F()/(this.P*Math.PI*25*1e-4); },   /* 直径 10 cm のとき約 4.6 cm */
  draw2:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return clamp(W*0.56, 260, 380); }), c=f.c, W=f.W, H=f.H;
    var s=Math.min((W-40)/(2*this.L), (H-30)/(this.ZT+5.5)), X=function(x){ return W/2+x*s; }, Y=function(z){ return 14+(self.ZT-z)*s; };
    c.clearRect(0,0,W,H);
    /* 空気（上）とテーブル */
    c.save(); c.fillStyle="#eef3f8"; c.fillRect(X(-this.L),Y(this.ZT),2*this.L*s,this.ZT*s); c.restore();
    c.save(); c.fillStyle="#d9c7ad"; c.strokeStyle="#8b7355"; c.lineWidth=1.4; c.fillRect(X(-this.L-0.5),Y(0),(2*this.L+1)*s,1.6*s); c.strokeRect(X(-this.L-0.5),Y(0),(2*this.L+1)*s,1.6*s); c.restore();
    T(c,"テーブル", X(-this.L)+6, Y(-0.8), {size:11.5, col:"#6b5539", bold:true});
    /* 分子（断面なので奥ゆきは無視） */
    this.mols.forEach(function(m){ molBall(c, X(m.x), Y(m.z), 3.2); });
    this.flash.forEach(function(q){ c.fillStyle="rgba(255,180,60,"+(0.85*q.a).toFixed(2)+")"; c.beginPath(); c.arc(X(q.x),Y(q.z),4+5*(1-q.a),0,7); c.fill(); });
    /* 吸盤（断面） */
    var R=this.R();
    c.save(); c.fillStyle="rgba(240,120,90,.85)"; c.strokeStyle="#a5452c"; c.lineWidth=1.6; c.beginPath(); c.moveTo(X(-R),Y(0));
    for(var k=0;k<=40;k++){ var x=-R+2*R*k/40; c.lineTo(X(x),Y(this.cupZ(Math.abs(x)))); } c.closePath(); c.fill(); c.stroke();
    c.fillStyle="#a5452c"; c.fillRect(X(-0.35),Y(this.cupZ(0)+0.9),0.7*s,0.9*s); c.restore();
    /* 面積 S（テーブルの面に投影した円の直径） */
    c.save(); c.strokeStyle="#e07b18"; c.lineWidth=3; c.beginPath(); c.moveTo(X(-R),Y(0)); c.lineTo(X(R),Y(0)); c.stroke(); c.restore();
    /* 圧力の矢印（同じ長さ）：吸盤の上の面へ下向き */
    var La=1.9;
    /* ２次元（断面）でも本数を面積に比例させる：半径 r cm なら r² 本 */
    var n2=Math.round(R*R);
    for(var i2=0;i2<n2;i2++){ var x2=-R*0.9+(n2>1? 1.8*R*i2/(n2-1) : 0.9*R); var zt=this.cupZ(Math.abs(x2)); arrow(c, X(x2), Y(zt+0.15+La), X(x2), Y(zt+0.15), COL.press, (n2>12? 1.6 : 2.2), (n2>12? 6 : 8)); }
    T(c,"圧力の矢印の本数は、面積に比例させている（半径 1 cm で 1 本）", 8, H-8, {size:10.5, col:COL.sub, halo:true});
    var wp=T(c,"圧力 ",X(-R)-10,Y(this.cupZ(0)+La*0.6),{size:13,bold:true,col:"#8a6a00",align:"right",halo:true});
    SYM(c,"p",null,X(-R)-8,Y(this.cupZ(0)+La*0.6),{size:15,bold:true,col:"#8a6a00",halo:true});
    /* 力 F：S の中心から下向き（テーブルの中へ、いちばん前に描く） */
    var Lf=this.Flen();
    fArrow(c, X(0), Y(0), X(0), Y(-Lf), COL.faceF, 6, 15);
    SYM(c,"F",null,X(0)-10,Y(-Lf*0.7),{size:15,bold:true,col:COL.faceF,halo:true,align:"right"}); T(c,"力 ",X(0)-24,Y(-Lf*0.7),{size:13,bold:true,col:COL.faceF,halo:true,align:"right"});
    var lS=T(c,"面積 ",X(R)+8,Y(0)-10,{size:12.5,bold:true,col:"#9c4e06",halo:true}); SYM(c,"S",null,X(R)+8+lS,Y(0)-10,{size:14,bold:true,col:"#9c4e06",halo:true});
    T(c,"分子は大きく描いています（真横から見た断面）", W-8, 12, {size:10.5, col:COL.sub, align:"right", halo:true});
    notebook(c,W,H);
  },
  draw3:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return clamp(W*0.66, 290, 420); }), c=f.c, W=f.W, H=f.H;
    var az=this.cam.az, el=this.cam.el, L=this.L, ZT=this.ZT;
    /* 縮尺の固定：箱（±L、z −8〜ZT）がいつも同じ大きさで入る */
    var pj0=mkProj3(az,el,1,0,0), x0=1e9,x1=-1e9,y0=1e9,y1=-1e9;
    [-L,L].forEach(function(x){ [-L,L].forEach(function(y){ [-5,ZT].forEach(function(z){ var p=pj0.p([x,y,z]); x0=Math.min(x0,p.x); x1=Math.max(x1,p.x); y0=Math.min(y0,p.y); y1=Math.max(y1,p.y); }); }); });
    var mg=10, S=Math.min((W-2*mg)/(x1-x0), (H-2*mg)/(y1-y0)), cx=W/2-S*(x0+x1)/2, cy=H/2-S*(y0+y1)/2;
    var pj=mkProj3(az,el,S,cx,cy), P=function(q){ return pj.p(q); };
    c.clearRect(0,0,W,H);
    var poly=function(pts,fill,stroke,lw){ c.beginPath(); pts.forEach(function(q,i){ var p=P(q); if(i) c.lineTo(p.x,p.y); else c.moveTo(p.x,p.y); }); c.closePath();
      if(fill){ c.fillStyle=fill; c.fill(); } if(stroke){ c.strokeStyle=stroke; c.lineWidth=lw||1; c.stroke(); } };
    /* テーブル（厚さ 1.6 cm の板）：見えている面を奥から */
    var Tz=-1.6, tb=[{pts:[[-L,-L,0],[L,-L,0],[L,L,0],[-L,L,0]],n:[0,0,1],col:"#e6d6bd"},{pts:[[-L,-L,Tz],[L,-L,Tz],[L,-L,0],[-L,-L,0]],n:[0,-1,0],col:"#cdb592"},
      {pts:[[-L,L,Tz],[L,L,Tz],[L,L,0],[-L,L,0]],n:[0,1,0],col:"#cdb592"},{pts:[[-L,-L,Tz],[-L,L,Tz],[-L,L,0],[-L,-L,0]],n:[-1,0,0],col:"#d5bf9e"},{pts:[[L,-L,Tz],[L,L,Tz],[L,L,0],[L,-L,0]],n:[1,0,0],col:"#d5bf9e"}];
    tb.forEach(function(fc){ if(v3dot(fc.n,pj.view)>1e-6) poly(fc.pts,fc.col,"#8b7355",1); });
    var R=this.R(), circ=function(r,z){ var a=[]; for(var k=0;k<48;k++){ var t=k/48*6.283; a.push([r*Math.cos(t), r*Math.sin(t), z]); } return a; };
    /* 分子：吸盤より奥のもの → 吸盤 → 手前のもの、の順に描く（奥ゆき d で分ける） */
    var pc=P([0,0,0]).d, items=this.mols.map(function(m){ var p=P([m.x,m.y,m.z]); return {p:p}; });
    var drawMol=function(it){ molBall(c, it.p.x, it.p.y, Math.max(2.4, S*0.22)); };
    items.filter(function(it){ return it.p.d<pc; }).forEach(drawMol);
    /* 吸盤：ふち（テーブルの面の円）と、ドーム（何本かの輪で） */
    poly(circ(R,0.001),"rgba(240,120,90,.25)","#a5452c",1.2);
    for(var j=5;j>=1;j--){ var r=R*j/5; poly(circ(r,this.cupZ(r*0.999)),"rgba(240,120,90,"+(0.35+0.08*(5-j))+")","rgba(165,69,44,.55)",0.8); }
    var kt=P([0,0,this.cupZ(0)+0.9]), kb=P([0,0,this.cupZ(0)]); c.save(); c.strokeStyle="#a5452c"; c.lineWidth=Math.max(4,S*0.6); c.lineCap="round"; c.beginPath(); c.moveTo(kb.x,kb.y); c.lineTo(kt.x,kt.y); c.stroke(); c.restore();
    /* 面積 S の円（オレンジ） */
    poly(circ(R,0.002),null,"#e07b18",2.6);
    this.flash.forEach(function(q){ var p=P([q.x,q.y,q.z]); c.fillStyle="rgba(255,180,60,"+(0.85*q.a).toFixed(2)+")"; c.beginPath(); c.arc(p.x,p.y,4+5*(1-q.a),0,7); c.fill(); });
    /* 圧力の矢印（同じ長さ・下向き） */
    var La=2.0;
    T(c,"圧力の矢印は 1 cm² に 1 本（本数が面積に比例）", 8, H-8, {size:10.5, col:COL.sub, halo:true});
    this.arrowPts().forEach(function(q){ var zt=self.cupZ(Math.hypot(q[0],q[1])), a=P([q[0],q[1],zt+0.15+La]), b=P([q[0],q[1],zt+0.15]); arrow(c,a.x,a.y,b.x,b.y,COL.press,2,7); });
    items.filter(function(it){ return it.p.d>=pc; }).forEach(drawMol);
    /* 力 F：S の中心から下向き（いちばん前） */
    var Lf=this.Flen(), f0=P([0,0,0]), f1=P([0,0,-Lf]);
    fArrow(c, f0.x, f0.y, f1.x, f1.y, COL.faceF, 6, 15);
    var lF=T(c,"力 ",f1.x+12,(f0.y+f1.y)/2+10,{size:13,bold:true,col:COL.faceF,halo:true}); SYM(c,"F",null,f1.x+12+lF,(f0.y+f1.y)/2+10,{size:15,bold:true,col:COL.faceF,halo:true});
    var pS=P([R*0.72,-R*0.72,0]); var lS=T(c,"面積 ",pS.x+14,pS.y+12,{size:12.5,bold:true,col:"#9c4e06",halo:true}); SYM(c,"S",null,pS.x+14+lS,pS.y+12,{size:14,bold:true,col:"#9c4e06",halo:true});
    var pa=P([-R,0,this.cupZ(0)+La+0.6]); var wp=T(c,"圧力 ",pa.x-36,pa.y,{size:13,bold:true,col:"#8a6a00",halo:true,align:"right"}); SYM(c,"p",null,pa.x-34,pa.y,{size:15,bold:true,col:"#8a6a00",halo:true});
    T(c,"分子は大きく描いています　ドラッグで回せる", W-8, 14, {size:10.5, col:COL.sub, align:"right", halo:true});
  }
};
/* 有効数字 2 けた（a.b×10ⁿ）。10 未満と 100 未満はそのまま */
function fmt2(v){
  if(v<10 && v>=0.1) return v.toFixed(1);
  if(v>=10 && v<100) return v.toFixed(0);
  var e=Math.floor(Math.log10(v)), m=v/Math.pow(10,e);
  if(m>=9.95){ m/=10; e++; }
  var sup={"0":"⁰","1":"¹","2":"²","3":"³","4":"⁴","5":"⁵","6":"⁶","7":"⁷","8":"⁸","9":"⁹","-":"⁻"};
  return m.toFixed(1)+"×10"+String(e).split("").map(function(ch){ return sup[ch]; }).join("");
}
/* 空気の分子（灰色の小さな玉） */
function molBall(c, x, y, r){ var g=c.createRadialGradient(x-r*0.35,y-r*0.4,0.3,x,y,r); g.addColorStop(0,"#ffffff"); g.addColorStop(1,"#9aa3ad");
  c.fillStyle=g; c.beginPath(); c.arc(x,y,r,0,7); c.fill(); }
/* 第9回：力 F は 1 本の矢印でかくことを強調する吹き出し。(x,y) … 吹き出しの左はしの中ほど、(tx,ty) … 指す先 */
function oneArrowNote(c, x, y, tx, ty){
  var l1="力 F の矢印は 1 本だけ", l2="（面全体が受ける力の合計）";
  c.save(); c.font="700 12.5px "+FONT; var w=Math.max(c.measureText(l1).width, c.measureText(l2).width*0.88)+18; c.restore();
  c.save(); c.strokeStyle=COL.faceF; c.lineWidth=1.4; c.beginPath(); c.moveTo(tx,ty); c.lineTo(x,y); c.stroke();
  c.fillStyle="#fff8ef"; rrect(c,x,y-20,w,40,8); c.fill(); c.lineWidth=2; c.stroke(); c.restore();
  T(c,l1,x+9,y-8,{size:12.5,bold:true,col:COL.faceF}); T(c,l2,x+9,y+9,{size:11,col:COL.faceF});
}
