/* ---------------- ①-4 液体による浮力 ----------------
   物体：幅・奥行き AW、高さ AH の縦長の直方体（上の面と下の面の圧力の差を見やすく）。
   ＜実際の動き＞は ②-2 と同じ並び（左に深さのものさし、ドラッグの案内は物体の左）。ビーカーは机の上。 */
var S14 = {
  AW:0.12, AH:0.30, D:1.0, AIR:0.34, HALF:0.42, BK:1.12,
  init:function(sec){
    var self=this; this.sec=sec;
    this.cvA=sec.querySelector('canvas[data-v="a"]'); this.cvB=sec.querySelector('canvas[data-v="b"]'); this.cvC=sec.querySelector('canvas[data-v="c"]');
    this.cv=sec.querySelector("canvas.main"); this.tab=sec.querySelector(".forcetab"); this.msg=sec.querySelector(".msgbox");
    this.di=0; this.li=1; this.view="a"; this.z0=0.66; this.z=this.z0; this.v=0; this.calm=0;
    this.run = new Runner({
      begin:function(){ self.z0=self.z; self.v=0; self.calm=0; },
      step:function(dt,r){ return self.step(dt,r); },
      draw:function(){ self.drawAll(); },
      reset:function(){ self.z=self.z0; self.v=0; },
      info:function(r){ return '上の面の深さ <b>'+Math.max(0,self.z-self.AH/2).toFixed(2)+'</b> m　時間 <b>'+r.t.toFixed(1)+'</b> s'; }
    });
    this.run.bind(sec.querySelector(".fcell.live"));
    sec.querySelectorAll(".fcell.pick").forEach(function(el){
      var go=function(){ self.view=el.dataset.v; sec.querySelectorAll(".fcell.pick").forEach(function(x){ x.classList.toggle("on", x===el); x.setAttribute("aria-pressed", x===el); }); self.drawAll(); };
      el.addEventListener("click", go); el.addEventListener("keydown", function(ev){ if(ev.key==="Enter"||ev.key===" "){ ev.preventDefault(); go(); } });
    });
    var chg=function(){ self.run.touch(); if(self.run.state==="idle"){ self.z=self.z0; self.v=0; } self.updVals(); self.drawAll(); };
    /* 第9回：物体と液体は、密度の小さい順に並べたスライダーで選ぶ（どちらが密度の大きい向きか、ひと目で分かる） */
    this.segD = wireSlider(sec,"dens",function(v){ var d=DENS[Math.round(v)]; return d.name+"　"+sci(d.rho)+" kg/m³"; },function(v){ self.di=Math.round(v); chg(); });
    this.segL = wireSlider(sec,"liq",function(v){ var d=LIQS[Math.round(v)]; return d.name+"　"+sci(d.rho)+" kg/m³"; },function(v){ self.li=Math.round(v); chg(); });
    sec.querySelector(".resetall").addEventListener("click", function(){
      self.di=0; self.li=1; self.segD.set(0); self.segL.set(1); self.view="a";
      sec.querySelectorAll(".fcell.pick").forEach(function(x){ x.classList.toggle("on", x.dataset.v==="a"); });
      self.run.rate=1; var sb=sec.querySelector(".slowb"); if(sb) sb.classList.remove("on");
      self.z0=0.66; self.run.reset(); self.updVals(); self.drawAll(); });
    bindDrag(this.cv, function(x,y){ var g=self.g; return g && Math.abs(x-g.X(0))<(self.AW/2)*g.s+14 && Math.abs(y-g.Y(self.z))<(self.AH/2)*g.s+12; },
      function(x,y){ var g=self.g; self.z = clamp((y-g.Y(0))/g.s, self.zmin(), self.zmax()); self.z0=self.z; self.v=0; self.run.touch(); self.drawAll(); }, null,
      function(){ return self.run.state!=="run"; });
    [this.cvA,this.cvB,this.cvC,this.cv].forEach(function(cv){ onResize(cv.parentElement, function(){ self.drawAll(); }); });
    this.updVals(); this.drawAll();
  },
  rhoL:function(){ return LIQS[this.li].rho; },
  updVals:function(){
    var d=DENS[this.di], l=LIQS[this.li];

  },
  zmin:function(){ return -this.AH/2 - 0.10; },
  zmax:function(){ return this.D - this.AH/2; },
  Vol:function(){ return this.AW*this.AW*this.AH; },
  m:function(){ return DENS[this.di].rho*this.Vol(); },
  sub:function(z){ return clamp(z+this.AH/2, 0, this.AH); },
  buoy:function(z){ return this.rhoL()*G*this.AW*this.AW*this.sub(z); },
  step:function(dt,r){
    var n=12, h=dt/n, A2=this.AW*this.AW, m=this.m(), rl=this.rhoL();
    for(var k=0;k<n;k++){
      var sb=this.sub(this.z), Fb=rl*G*A2*sb, me=m+0.5*rl*A2*sb;
      var Fd=0.5*1.05*rl*A2*(sb/this.AH)*this.v*Math.abs(this.v) + 2*(sb/this.AH)*this.v;
      this.v += ((m*G - Fb - Fd)/me)*h; this.z += this.v*h;
      if(this.z >= this.zmax()){ this.z=this.zmax(); if(this.v>0) this.v=0; }
    }
    var bottom = this.z >= this.zmax()-1e-6, net = m*G - this.buoy(this.z);
    if(r.t>0.6 && Math.abs(this.v)<0.004 && (bottom? net>=0 : Math.abs(net)<0.02*m*G+0.05)) this.calm+=dt; else this.calm=0;
    return this.calm>0.6 || r.t>15;
  },
  forces:function(){
    var m=this.m(), W=m*G, F=this.buoy(this.z), bottom=this.z>=this.zmax()-1e-6, N=bottom? Math.max(0,W-F) : 0;
    return {W:W, F:F, N:N, net:F+N-W};
  },
  balanced:function(fo){ return fo.N<0.01 && Math.abs(fo.F-fo.W) < 0.003*fo.W && Math.abs(this.v)<0.01 && this.run.state!=="run"; },
  /* 力の縮尺：液体を変えても重力の矢印の長さは変わらない（物体の重さと、水のときの浮力の大きい方で決める） */
  kForce:function(){ return 0.34/Math.max(this.m()*G, RHO_W*G*this.Vol()); },
  frame:function(cv, hOf, zTop, zBot, xL, xR){
    var f=fitCanvas(cv,hOf), W=f.W, H=f.H, s=Math.min((H-10)/(zBot-zTop), (W-8)/(xR-xL));
    var x0=(W-(xR-xL)*s)/2 - xL*s, yT=(H-(zBot-zTop)*s)/2 - zTop*s;
    return {c:f.c, W:W, H:H, s:s, X:function(x){ return x0+x*s; }, Y:function(z){ return yT+z*s; }};
  },
  /* 机の上のビーカー */
  beaker:function(g, half, legs){
    var c=g.c, l=LIQS[this.li], D=this.D, BK=this.BK, X=g.X, Y=g.Y, top=D-BK;
    var dt=Y(D)+3;
    c.save(); c.fillStyle="#c7a27c"; c.strokeStyle="#7a5c3e"; c.lineWidth=1.2;
    c.fillRect(X(-half-0.16), dt, (2*half+0.32)*g.s, 0.06*g.s); c.strokeRect(X(-half-0.16), dt, (2*half+0.32)*g.s, 0.06*g.s);
    if(legs){ [-half-0.10, half+0.04].forEach(function(x){ c.fillRect(X(x), dt+0.06*g.s, 0.06*g.s, 0.24*g.s); c.strokeRect(X(x), dt+0.06*g.s, 0.06*g.s, 0.24*g.s); }); }
    c.restore();
    c.fillStyle=l.fill; c.fillRect(X(-half), Y(0), 2*half*g.s, D*g.s);
    c.strokeStyle=l.surf; c.lineWidth=2; c.beginPath(); c.moveTo(X(-half),Y(0)); c.lineTo(X(half),Y(0)); c.stroke();
    c.save(); c.strokeStyle="rgba(90,110,130,.9)"; c.lineWidth=2.4; c.lineJoin="round";
    c.beginPath(); c.moveTo(X(-half)-5,Y(top)); c.lineTo(X(-half),Y(top)+4); c.lineTo(X(-half),Y(D)); c.lineTo(X(half),Y(D)); c.lineTo(X(half),Y(top)); c.stroke();
    c.strokeStyle="rgba(255,255,255,.75)"; c.lineWidth=2; c.beginPath(); c.moveTo(X(half)-5,Y(top)+10); c.lineTo(X(half)-5,Y(D)-8); c.stroke();
    c.restore();
  },
  block:function(g, dash){
    var c=g.c, w=this.AW, h=this.AH, d=DENS[this.di];
    if(dash){ c.save(); c.setLineDash([5,4]); c.strokeStyle=COL.dashed; c.lineWidth=1.6; c.strokeRect(g.X(-w/2),g.Y(this.z-h/2),w*g.s,h*g.s); c.restore(); return; }
    c.save(); c.fillStyle=d.fill; c.strokeStyle=d.line; c.lineWidth=1.8; c.fillRect(g.X(-w/2),g.Y(this.z-h/2),w*g.s,h*g.s); c.strokeRect(g.X(-w/2),g.Y(this.z-h/2),w*g.s,h*g.s); c.restore();
  },
  pressArrows:function(g){
    var self=this, c=g.c, rl=this.rhoL(), kL=3.4e-5*Math.min(1, RHO_W/rl*1.6);
    var pts=surfPoints("rect",{w:this.AW,h:this.AH},0.075);
    pts.forEach(function(p){ var d=self.z+p.y; if(d<=0.001) return;
      var L=Math.min(0.30, rl*G*d*kL), gp=0.008;
      arrow(c, g.X(p.x+p.nx*(gp+L)), g.Y(self.z+p.y+p.ny*(gp+L)), g.X(p.x+p.nx*gp), g.Y(self.z+p.y+p.ny*gp), COL.press, 1.9, 7); });
  },
  /* 長すぎる力の矢印は、途中を省略した印をつけて短く描く */
  capArrow:function(c, x, y1, len, dir, col, cap){
    var L=Math.min(len, cap), y2=y1+dir*L;
    fArrow(c, x, y1, x, y2, col, 3, 11);
    if(len>cap){ var ym=y1+dir*L*0.5; c.save(); c.fillStyle="#fff"; c.fillRect(x-8, ym-4, 16, 8); c.strokeStyle=col; c.lineWidth=1.6;
      c.beginPath(); c.moveTo(x-7,ym-1); c.lineTo(x+7,ym-5); c.moveTo(x-7,ym+5); c.lineTo(x+7,ym+1); c.stroke(); c.restore(); }
    return y2;
  },
  drawAll:function(){ this.drawA(); this.drawB(); this.drawC(); this.drawD(); this.alignSmall(); },
  hS:function(W){ return clamp(W*1.30, 150, 300); },
  smallFrame:function(cv){ return this.frame(cv, this.hS.bind(this), -0.30, this.D+0.10, -0.34, 0.34); },
  drawA:function(){
    var g=this.smallFrame(this.cvA), c=g.c; this.gA=g;
    c.clearRect(0,0,g.W,g.H); this.beaker(g,0.30,false); this.block(g); this.pressArrows(g);
  },
  drawB:function(){
    var g=this.smallFrame(this.cvB), c=g.c, w=this.AW, h=this.AH, z=this.z, rl=this.rhoL(); this.gB=g;
    c.clearRect(0,0,g.W,g.H); this.beaker(g,0.30,false); this.block(g);
    var kF=0.30/(rl*G*this.D*w*w);
    var h1=z-h/2, h2=z+h/2, F1=rl*G*Math.max(0,h1)*w*w, F2=rl*G*Math.max(0,h2)*w*w;
    if(h2>0){ var ym=Math.max(h1,0)+(h2-Math.max(h1,0))/2, Ls=0.05;
      [-1,1].forEach(function(sx){ arrow(c, g.X(sx*(w/2+0.01+Ls)), g.Y(ym), g.X(sx*(w/2+0.01)), g.Y(ym), COL.gray, 2, 8); }); }
    if(F1>0){ fArrow(c, g.X(0), g.Y(h1), g.X(0), g.Y(h1+F1*kF), COL.faceF, 2.6, 10); SYM(c,"F","1",g.X(0)-6,g.Y(h1)-9,{size:13,col:COL.faceF,halo:true,align:"right"}); }
    if(F2>0){ fArrow(c, g.X(0), g.Y(h2), g.X(0), g.Y(h2-F2*kF), COL.faceF, 2.6, 10); SYM(c,"F","2",g.X(0)+6,g.Y(h2)+10,{size:13,col:COL.faceF,halo:true}); }
    var F=F2-F1, xr=w/2+0.13, yb=Math.max(h1,0)+(h2-Math.max(h1,0))/2;
    if(F>0){ fArrow(c, g.X(xr), g.Y(yb), g.X(xr), g.Y(yb-F*kF*1.4), COL.buoy, 3, 11); SYM(c,"F",null,g.X(xr)+6,g.Y(yb-F*kF*1.4)+4,{size:14,col:COL.buoy,halo:true}); }
  },
  drawC:function(){
    var g=this.smallFrame(this.cvC), c=g.c, w=this.AW, h=this.AH, z=this.z, rl=this.rhoL(); this.gC=g;
    c.clearRect(0,0,g.W,g.H); this.beaker(g,0.30,false);
    var sb=this.sub(z), top=z+h/2-sb;
    c.save(); c.fillStyle="rgba(47,111,159,.30)"; c.fillRect(g.X(-w/2),g.Y(top),w*g.s,sb*g.s); c.restore();
    this.block(g,true);
    if(sb>0.002){
      var F=rl*G*w*w*sb, kF=0.26/(rl*G*w*w*h), yc=top+sb/2;
      fArrow(c, g.X(-w/2-0.05), g.Y(yc), g.X(-w/2-0.05), g.Y(yc-F*kF), COL.buoy, 2.6, 10);
      fArrow(c, g.X(w/2+0.05), g.Y(yc), g.X(w/2+0.05), g.Y(yc+F*kF), COL.grav, 2.6, 10);
      eqTicks(c, g.X(-w/2-0.05), g.Y(yc), g.X(-w/2-0.05), g.Y(yc-F*kF), 1, COL.buoy);
      eqTicks(c, g.X(w/2+0.05), g.Y(yc), g.X(w/2+0.05), g.Y(yc+F*kF), 1, COL.grav);
      SYM(c,"F",null,g.X(-w/2-0.09),g.Y(yc-F*kF*0.55),{size:14,col:COL.buoy,halo:true,align:"right"});   /* 「同じ体積の水」と重ならないよう、矢印の中ほどの左に */
      T(c,"ρV′g",g.X(w/2+0.05),g.Y(yc+F*kF)+11,{size:12,col:COL.grav,halo:true,align:"center",it:true});
      T(c,"同じ体積の"+LIQS[this.li].name, g.X(0), g.Y(top)-9, {size:10,align:"center",col:"#1f4e79",bold:true,halo:true});
    }
  },
  drawD:function(){
    var g=this.frame(this.cv, function(W){ return clamp(W*0.95, 280, 430); }, -this.AIR, this.D+0.32, -this.HALF-0.30, this.HALF+0.20), c=g.c, w=this.AW, h=this.AH, z=this.z;
    this.g=g;
    c.clearRect(0,0,g.W,g.H);
    c.fillStyle="#f7f4ee"; c.fillRect(0,0,g.W,g.H);
    this.beaker(g,this.HALF,true);
    /* 左に深さのものさし（②-2 の高さのものさしと同じ並び） */
    var xr=g.X(-this.HALF)-16;
    c.save(); c.strokeStyle="#69717d"; c.lineWidth=1; c.beginPath(); c.moveTo(xr,g.Y(0)); c.lineTo(xr,g.Y(this.D)); c.stroke();
    for(var q=0;q<=this.D+1e-6;q+=0.1){ var big=Math.round(q*10)%5===0; c.beginPath(); c.moveTo(xr-(big?7:4),g.Y(q)); c.lineTo(xr,g.Y(q)); c.stroke();
      if(big) T(c, q.toFixed(1)+" m", xr-9, g.Y(q), {size:10.5,col:COL.sub,align:"right"}); }
    arrow(c, xr, g.Y(0), xr, g.Y(this.D)+6, "#69717d", 1, 7); T(c,"深さ", xr-4, g.Y(0)-14, {size:10.5,col:COL.sub,align:"right"}); c.restore();
    var sb=this.sub(z), top=z+h/2-sb;
    this.block(g);   /* ＜実際の動き＞は (b) を選んでも (c) を選んでも同じ図 */
    var fo=this.forces(), kF=this.kForce()*g.s, cap=0.58*g.s;
    /* スタート前：手が物体の右下をつかんでいる → スタートを押すと消える（手をはなした） */
    if(this.run.state==="idle") pullHand(c, g.X(w/2), g.Y(z+h/2));
    if(this.view==="a") this.pressArrows(g);
    var xg=g.X(0)+5, xf=g.X(0)-5, bal=this.balanced(fo);
    var yg=this.capArrow(c, xg, g.Y(z), fo.W*kF, 1, COL.grav, cap);
    SYM(c,"mg",null,xg,yg+12,{size:14,col:COL.grav,halo:true,align:"center",bold:true});
    if(bal) eqTicks(c, xg, g.Y(z), xg, yg, 1, COL.grav);
    if(this.view!=="a" && fo.F>0.01){
      var yb=top+sb/2, yf=this.capArrow(c, xf, g.Y(yb), fo.F*kF, -1, COL.buoy, cap);
      SYM(c,"F",null,xf-4,yf-2,{size:14,col:COL.buoy,halo:true,align:"right",bold:true});
      if(bal) eqTicks(c, xf, g.Y(yb), xf, yf, 1, COL.buoy);
    }
    if(this.view!=="a" && fo.N>0.01){
      var xn=g.X(w/2)-3, yn=this.capArrow(c, xn, g.Y(this.D), fo.N*kF, -1, COL.norm, cap);
      SYM(c,"N",null,xn+5,yn+2,{size:14,col:COL.norm,halo:true,bold:true});
    }
    if(this.run.state==="idle") dragHint(c,"ドラッグ", g.X(-this.HALF)+6, g.Y(z)-22, {size:11});
    /* 第9回：何が「物体」で何が「液体」かを図に書きこむ */
    T(c,"物体", g.X(w/2)+8, g.Y(z-h/2)+2, {size:13,bold:true,col:DENS[this.di].line,halo:true});
    T(c,"液体（"+LIQS[this.li].name+"）", g.X(this.HALF)-8, g.Y(this.D)-14, {size:13,bold:true,col:"#1f4e79",halo:true,align:"right"});
    var row=function(k,v,cl){ return '<tr'+(cl?' class="'+cl+'"':'')+'><td class="k">'+k+'</td><td class="v">'+v+'</td></tr>'; };
    var dir = Math.abs(fo.net)<0.05? "つりあい（0 N）" : (fo.net>0? "上向き "+fo.net.toFixed(1)+" N" : "下向き "+(-fo.net).toFixed(1)+" N");
    this.tab.innerHTML = row('<span style="color:'+COL.grav+'">重力 '+tex("mg")+'</span>', fo.W.toFixed(1)+" N") +
      row('<span style="color:'+COL.buoy+'">浮力 '+tex("F=\\rho V'g")+'</span>', fo.F.toFixed(1)+" N") +
      (fo.N>0.01? row('<span style="color:'+COL.norm+'">垂直抗力 '+tex("N")+'</span>', fo.N.toFixed(1)+" N") : "") + row("合力", dir, "sum");
    var out = Math.max(0, h-sb)/h, ln=LIQS[this.li].name;
    this.msg.innerHTML = (sb>=h-1e-6? '物体は全部、'+ln+'の中。深さを変えても、浮力は変わらない。' :
      sb<=1e-6? '物体は'+ln+'の外。浮力ははたらかない。' : ln+'の面の上に出ている割合：<span class="num">'+Math.round(out*100)+'</span> %（'+ln+'の中の体積 '+tex("V'")+' が小さいほど、浮力は小さい）');
  },
  /* (a)〜(c) の液面の高さを、＜実際の動き＞の液面の高さにそろえる（横に並んでいるときだけ） */
  alignSmall:function(){
    var self=this, live=this.sec.querySelector(".fcell.live"), cells=this.sec.querySelectorAll(".fcell.pick");
    if(!live || !this.g) return;
    var lr=live.getBoundingClientRect(), dY=this.cv.getBoundingClientRect().top + this.g.Y(0);
    [[this.cvA,this.gA],[this.cvB,this.gB],[this.cvC,this.gC]].forEach(function(p){
      var cv=p[0], g=p[1]; if(!g) return;
      /* 第10回：すき間はカードの上にあける（白い枠の中に空白を作らない） → 見出しがビーカーの図のすぐ上に来る */
      var cell=cv.parentElement, cr=cell.getBoundingClientRect();
      if(cr.left>=lr.left-4 || cr.top>lr.bottom){ cell.style.marginTop="0px"; return; }        // 縦に並んでいる（せまい画面）
      var cur=parseFloat(cell.style.marginTop)||0, sY=cv.getBoundingClientRect().top + g.Y(0);
      var nm=Math.max(0, cur + (dY - sY)); if(Math.abs(nm-cur)>0.5) cell.style.marginTop=nm.toFixed(1)+"px";
    });
  }
};
