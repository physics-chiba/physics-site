/* =========================================================================
   モード③ 抵抗力（速度に起因）　※物理（本編）の内容
   抵抗力の色：濃いグレー（力のベクトルの描き方ルール ⑥ の空いている色）
   ========================================================================= */
COL.resist = "#3f4a54";

/* グラフの軸（矢印つき）と、きりのよい目盛り */
function niceStepV(r, n){ var raw=r/(n||5), p=Math.pow(10,Math.floor(Math.log10(raw))), f=raw/p; return (f<1.5?1:f<3?2:f<7?5:10)*p; }
function axesBox(c, L, Tp, R, B, xmax, ymax, xl, yl){
  var X=function(x){ return L+(R-L-10)*x/xmax; }, Y=function(y){ return B-(B-Tp-10)*y/ymax; };
  c.save(); c.fillStyle="#fff"; c.fillRect(L,Tp,R-L,B-Tp);
  var xs=niceStepV(xmax,5), ys=niceStepV(ymax,4);
  c.strokeStyle="#eef1f4"; c.lineWidth=1;
  for(var x=xs; x<=xmax+1e-9; x+=xs){ c.beginPath(); c.moveTo(X(x),Tp+8); c.lineTo(X(x),B); c.stroke(); }
  for(var y=ys; y<=ymax+1e-9; y+=ys){ c.beginPath(); c.moveTo(L,Y(y)); c.lineTo(R-8,Y(y)); c.stroke(); }
  arrow(c, L, B, R, B, "#2b323c", 1.4, 8); arrow(c, L, B, L, Tp, "#2b323c", 1.4, 8);
  for(var x2=xs; x2<=xmax+1e-9; x2+=xs) T(c, String(+x2.toFixed(3)), X(x2), B+10, {size:10,col:COL.sub,align:"center"});
  for(var y2=ys; y2<=ymax+1e-9; y2+=ys) T(c, String(+y2.toFixed(3)), L-4, Y(y2), {size:10,col:COL.sub,align:"right"});
  T(c, "0", L-4, B+8, {size:10,col:COL.sub,align:"right"});
  T(c, xl, R, B-10, {size:12,col:COL.ink,align:"right",it:true});
  T(c, yl, L+6, Tp+4, {size:12,col:COL.ink,it:true});
  c.restore();
  return {X:X, Y:Y};
}

/* ---------------- ③-1 空気の抵抗（雨粒の落下） ---------------- */
var S31 = {
  H0:1000,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.m=2.0; this.k=4.0;                     // ×10⁻⁶ kg、×10⁻⁶ kg/s
    this.run = new Runner({
      /* 終端速度に近づいたら早送り（1000 m 落ちるのに 200 s ほどかかるため） */
      step:function(dt,r){ var sp=self.speedAt(r.t); r.t += dt*(sp-1); return self.yAt(r.t) >= self.H0; },
      draw:function(){ self.draw(); },
      reset:function(){},
      info:function(r){ return '時間 <b>'+r.t.toFixed(r.t<10?2:1)+'</b> s'; }
    });
    this.run.bind(sec);
    this.sm = wireSlider(sec,"m",function(v){ return v.toFixed(1)+"×10⁻⁶ kg"; }, function(v){ self.m=v; self.run.reset(); });
    this.sk = wireSlider(sec,"k",function(v){ return v.toFixed(1)+"×10⁻⁶ kg/s"; }, function(v){ self.k=v; self.run.reset(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.m=2.0; self.k=4.0; self.sm.set(2.0); self.sk.set(4.0); self.run.rate=1;
      var sb=sec.querySelector(".slowb"); if(sb) sb.classList.remove("on"); self.run.reset(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    this.draw();
  },
  vf:function(){ return this.m*G/this.k; },
  tau:function(){ return this.m/this.k; },
  Tg:function(){ return Math.max(2, 5*this.tau()); },                 /* グラフの横軸の長さ */
  speedAt:function(t){ var t0=this.Tg(); return t<t0? 1 : Math.min(40, 1+(t-t0)*20); },
  vAt:function(t){ return this.vf()*(1-Math.exp(-t/this.tau())); },
  tEnd:function(){ var lo=0, hi=this.H0/this.vf()+10*this.tau()+1; for(var i=0;i<50;i++){ var m=(lo+hi)/2; if(this.yAt(m)<this.H0) lo=m; else hi=m; } return (lo+hi)/2; },
  yAt:function(t){ var tau=this.tau(); return this.vf()*(t - tau*(1-Math.exp(-t/tau))); },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return clamp(W*0.62, 300, 400); }), c=f.c, W=f.W, H=f.H;
    var t=this.run.t, y=Math.min(this.H0, this.yAt(t)), v=this.vAt(t), vf=this.vf(), fast=this.speedAt(t)>1.5 && this.run.state==="run";
    c.clearRect(0,0,W,H);
    var W1=Math.round(W*0.24), W2=Math.round(W*0.34), gap=8;
    /* ① 左：高さを固定した図（1000 m から落ちる） */
    var top=38, bot=H-20, Yh=function(hh){ return bot-(bot-top)*hh/self.H0; };
    var gr=c.createLinearGradient(0,0,0,H); gr.addColorStop(0,"#dfe9f3"); gr.addColorStop(1,"#cfdeec"); c.fillStyle=gr; c.fillRect(0,0,W1,H);
    T(c,"高さ（全体）",6,11,{size:10.5,col:COL.sub,bold:true});
    var xr=34; c.save(); c.strokeStyle="#69717d"; c.lineWidth=1; c.beginPath(); c.moveTo(xr,Yh(0)); c.lineTo(xr,Yh(this.H0)); c.stroke();
    for(var hh=0; hh<=this.H0; hh+=200){ c.beginPath(); c.moveTo(xr-4,Yh(hh)); c.lineTo(xr,Yh(hh)); c.stroke(); T(c, hh+"", xr-6, Yh(hh), {size:9.5,col:COL.sub,align:"right"}); }
    T(c,"m", xr-6, Yh(this.H0)-12, {size:9.5,col:COL.sub,align:"right"}); c.restore();
    c.fillStyle="#f7f9fb"; [[-12,0,10],[0,-4,13],[12,0,10]].forEach(function(q){ c.beginPath(); c.arc(W1*0.62+q[0],Yh(self.H0)+q[1],q[2],0,7); c.fill(); });
    ground(c, 4, W1-4, Yh(0));
    var dyp=Yh(this.H0-y);
    c.save(); c.fillStyle="#5aa7e6"; c.strokeStyle="#1f5f99"; c.lineWidth=1; c.beginPath(); c.arc(W1*0.62, dyp, 4.2, 0, 7); c.fill(); c.stroke(); c.restore();
    T(c, (this.H0-y).toFixed(0)+" m", W1*0.62+8, dyp, {size:10.5,col:"#1f4e79",bold:true,halo:true});
    if(fast) T(c,"早送り中", W1/2, H-8, {size:10.5,col:"#c0392b",bold:true,align:"center",halo:true});
    /* ② まん中：雨粒にはたらく力（拡大・雨粒を追いかけて見る） */
    var X2=W1+gap, cx=X2+W2*0.5, cy=H*0.44, pxm=60;
    var gr2=c.createLinearGradient(0,0,0,H); gr2.addColorStop(0,"#e4edf6"); gr2.addColorStop(1,"#d2e1ef"); c.fillStyle=gr2; c.fillRect(X2,0,W2,H);
    c.save(); c.beginPath(); c.rect(X2,0,W2,H); c.clip();
    var off=((y*pxm)%40+40)%40; c.strokeStyle="rgba(120,150,180,.45)"; c.lineWidth=1;
    for(var k=-1;k<14;k++){ var yy=k*40-off; c.beginPath(); c.moveTo(X2+6,yy); c.lineTo(X2+16,yy); c.moveTo(X2+W2-16,yy); c.lineTo(X2+W2-6,yy); c.stroke(); }
    var cyCloud=cy-26-y*pxm;
    if(cyCloud>-60){ c.fillStyle="#f7f9fb"; [[-30,0,22],[0,-8,28],[30,0,22],[0,10,24]].forEach(function(q){ c.beginPath(); c.arc(cx+q[0],cyCloud+q[1]-14,q[2],0,7); c.fill(); }); }
    c.restore();
    T(c,"雨粒にはたらく力（拡大）",X2+6,11,{size:10.5,col:COL.sub,bold:true});
    var r=11;
    c.save(); c.fillStyle="#5aa7e6"; c.strokeStyle="#1f5f99"; c.lineWidth=1.4;
    c.beginPath(); c.moveTo(cx,cy-r*1.7); c.quadraticCurveTo(cx+r*1.05,cy-r*0.2,cx+r,cy+r*0.15); c.arc(cx,cy+r*0.15,r,0,Math.PI); c.quadraticCurveTo(cx-r*1.05,cy-r*0.2,cx,cy-r*1.7); c.fill(); c.stroke();
    c.fillStyle="rgba(255,255,255,.7)"; c.beginPath(); c.ellipse(cx-r*0.35,cy-r*0.1,r*0.2,r*0.35,0.3,0,7); c.fill(); c.restore();
    var Fmg=this.m*G, Fr=this.k*v, kF=70/Fmg, FmgR=Fmg*1e-6, FrR=Fr*1e-6, term=(t>0 && Math.abs(Fmg-Fr)<0.003*Fmg);
    fArrow(c, cx+5, cy, cx+5, cy+Fmg*kF, COL.grav, 3, 11); SYM(c,"mg",null,cx+5,cy+Fmg*kF+12,{size:14,col:COL.grav,bold:true,halo:true,align:"center"});
    if(Fr*kF>2){ fArrow(c, cx-5, cy, cx-5, cy-Fr*kF, COL.resist, 3, 11); SYM(c,"kv",null,cx-9,cy-Fr*kF+4,{size:14,col:COL.resist,bold:true,halo:true,align:"right"}); }
    if(term){ eqTicks(c, cx+5, cy, cx+5, cy+Fmg*kF, 1, COL.grav); eqTicks(c, cx-5, cy, cx-5, cy-Fr*kF, 1, COL.resist); }
    var Lv=6+v*9;
    if(v>0.02){ var xv=cx+38; arrow(c, xv, cy-Lv/2, xv, cy+Lv/2, COL.vel, 3, 10); SYM(c,"v",null,xv+7,cy+Lv/2-2,{size:14,col:COL.vel,bold:true,halo:true}); }
    /* ③ 右：v–t グラフ（小さめ）。第8回：高さを 60 % に、横軸は地面に着くまで。終端速度にほぼ達したあとは ≈ で省略 */
    var gl=X2+W2+gap+34, gt=22, gr3=W-8, gb=gt+Math.round((H-52)*0.6), tmax=this.Tg(), tEnd=this.tEnd(), vmax=niceStepV(vf*1.2,4)*Math.ceil(vf*1.15/niceStepV(vf*1.2,4));
    T(c,"v–t グラフ", X2+W2+gap+4, 11, {size:10.5,col:COL.sub,bold:true});
    var xb=gl+(gr3-gl)*0.66, tA=Math.max(tmax, tEnd-tmax*0.6), xr=gr3-12;
    var GX=function(tt){ return (tt<=tmax)? gl+(xb-6-gl)*tt/tmax : xb+12+(xr-xb-12)*(tt-tA)/Math.max(1e-6,tEnd-tA); };
    var GY=function(vv){ return gb-(gb-gt-10)*vv/vmax; };
    c.save(); c.fillStyle="#fff"; c.fillRect(gl,gt,gr3-gl,gb-gt);
    var xs=niceStepV(tmax,4), ys=niceStepV(vmax,4); c.strokeStyle="#eef1f4"; c.lineWidth=1;
    for(var xx=xs; xx<=tmax+1e-9; xx+=xs){ c.beginPath(); c.moveTo(GX(xx),gt+8); c.lineTo(GX(xx),gb); c.stroke(); }
    for(var yy2=ys; yy2<=vmax+1e-9; yy2+=ys){ c.beginPath(); c.moveTo(gl,GY(yy2)); c.lineTo(gr3-8,GY(yy2)); c.stroke(); }
    c.restore();
    arrow(c, gl, gb, gr3, gb, "#2b323c", 1.4, 8); arrow(c, gl, gb, gl, gt, "#2b323c", 1.4, 8);
    for(var x3=xs; x3<=tmax+1e-9; x3+=xs) T(c, String(+x3.toFixed(3)), GX(x3), gb+10, {size:10,col:COL.sub,align:"center"});
    for(var y3=ys; y3<=vmax+1e-9; y3+=ys) T(c, String(+y3.toFixed(3)), gl-4, GY(y3), {size:10,col:COL.sub,align:"right"});
    T(c,"0", gl-4, gb+8, {size:10,col:COL.sub,align:"right"});
    T(c, tEnd.toFixed(0), xr, gb+10, {size:10,col:COL.sub,align:"center"});
    c.save(); c.strokeStyle="#2b323c"; c.lineWidth=1; c.beginPath(); c.moveTo(xr,gb-3); c.lineTo(xr,gb+3); c.stroke(); c.restore();
    /* 途中省略の印（≈）：横軸とグラフの線の上 */
    var brk=function(x,y){ c.save(); c.fillStyle="#fff"; c.fillRect(x-4,y-7,10,14); c.strokeStyle="#2b323c"; c.lineWidth=1.2;
      [-3,2].forEach(function(o){ c.beginPath(); c.moveTo(x-4+o,y+6); c.lineTo(x+4+o,y-6); c.stroke(); }); c.restore(); };
    brk(xb+3, gb);
    T(c,"t［s］", gr3, gb-10, {size:12,col:COL.ink,align:"right",it:true}); T(c,"v［m/s］", gl+6, gt+4, {size:12,col:COL.ink,it:true});
    c.save(); c.setLineDash([5,4]); c.strokeStyle=COL.resist; c.lineWidth=1.3; c.beginPath(); c.moveTo(gl,GY(vf)); c.lineTo(gr3-8,GY(vf)); c.stroke(); c.restore();
    T(c,"終端速度 "+vf.toFixed(1)+" m/s", gl+8, GY(vf)-9, {size:10.5,col:COL.resist,bold:true,halo:true});
    c.save(); c.strokeStyle=COL.vel; c.lineWidth=2.4; c.beginPath();
    var n=80, tg=Math.min(t,tmax); for(var i=0;i<=n;i++){ var tt=tg*i/n, vv=this.vAt(tt); if(i) c.lineTo(GX(tt),GY(vv)); else c.moveTo(GX(tt),GY(vv)); }
    c.stroke();
    if(t>tA){ c.beginPath(); c.moveTo(GX(tA),GY(this.vAt(tA))); c.lineTo(GX(Math.min(t,tEnd)),GY(this.vAt(Math.min(t,tEnd)))); c.stroke(); }
    c.restore();
    if(t>tmax) brk(xb+3, GY(vf));
    var tp=(t<=tmax)? t : (t<tA? tmax : Math.min(t,tEnd));
    if(t>0){ c.fillStyle=COL.vel; c.beginPath(); c.arc(GX(tp),GY(this.vAt(tp)),4,0,7); c.fill(); }
    if(t>tmax && t<tA) T(c,"（省略中）", (xb+xr)/2+6, GY(vf)+14, {size:10,col:COL.sub,align:"center",halo:true});
    var a=(Fmg-Fr)/this.m;
    this.msg.innerHTML='高さ <span class="num">'+(this.H0-y).toFixed(0)+'</span> m　速さ '+tex("v")+' ＝ <span class="num">'+v.toFixed(2)+'</span> m/s　加速度 '+tex("a")+' ＝ <span class="num">'+a.toFixed(2)+'</span> m/s²<br>（重力 '+tex("mg")+' ＝ <span class="num">'+sci(FmgR)+'</span> N、空気の抵抗力 '+tex("kv")+' ＝ <span class="num">'+sci(FrR>1e-12? FrR : 0)+'</span> N）';
  }
};

/* ---------------- ③-2 水から受ける抵抗（船） ----------------
   抵抗力を R = bv + cv² と近似する（実際の船の抵抗はもっと複雑）。船をドラッグして走らせる。 */
var S32 = {
  M:300, B:60, Cq:45, SPAN:24, VMAX:8,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.x=6; this.v=0; this.drag=false; this.tgt=null; this.wake=[];
    this.run = new Runner({
      startText:"▶ スタート（押し出す）",
      begin:function(r){ self.v=5.5; self.drag=false; },
      step:function(dt,r){ self.phys(dt); return r.t>0.5 && Math.abs(self.v)<0.03; },
      draw:function(){ self.draw(); },
      reset:function(){ self.v=0; self.x=6; self.wake=[]; },
      info:function(){ return '速さ <b>'+Math.abs(self.v).toFixed(2)+'</b> m/s'; }
    });
    this.run.bind(sec);
    sec.querySelector(".resetall").addEventListener("click", function(){ self.run.rate=1; var sb=sec.querySelector(".slowb"); if(sb) sb.classList.remove("on"); self.run.reset(); });
    var cv=this.cv;
    bindDrag(cv, function(x,y){ var g=self.g; return g && Math.abs(x-g.X(self.x))<g.s*1.8 && Math.abs(y-g.yw)<40; },
      function(x,y,first){ var g=self.g; if(self.run.state==="run") self.run.pause(); self.drag=true; self.tgt=g.Xinv(x); if(first){ self.grab=self.tgt-self.x; } self.loop(); },
      function(){ self.drag=false; self.loop(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    this.draw();
  },
  R:function(v){ var s=Math.abs(v); return this.B*s + this.Cq*s*s; },
  phys:function(dt){
    if(this.drag && this.tgt!==null){
      /* つかんでいる間：船は指（マウス）にそのままついていく。速さは動いた量からなめらかに求める */
      var dx=(this.tgt-this.grab)-this.x; dx-=Math.round(dx/this.SPAN)*this.SPAN;
      this.x=((this.x+dx)%this.SPAN+this.SPAN)%this.SPAN;
      if(dt>0){ var vi=clamp(dx/dt, -this.VMAX, this.VMAX); this.v += (vi-this.v)*Math.min(1, dt/0.07); }
    } else {
      var n=8, h=dt/n;
      for(var k=0;k<n;k++){
        var a=-(this.v>=0?1:-1)*this.R(this.v)/this.M, nv=this.v+a*h; if(nv*this.v<0) nv=0; this.v=nv;
        this.x=((this.x+this.v*h)%this.SPAN+this.SPAN)%this.SPAN;
      }
    }
    if(Math.abs(this.v)>0.3){ this.wake.push({x:this.x-(this.v>0?2.0:-2.0), age:0, a:Math.min(1,Math.abs(this.v)/this.VMAX)}); }
    this.wake.forEach(function(w){ w.age+=dt; }); this.wake=this.wake.filter(function(w){ return w.age<2.2; });
  },
  loop:function(){
    var self=this; if(this._raf) return; var last=0;
    var f=function(ts){ var dt=last? Math.min(0.05,(ts-last)/1000):0; last=ts;
      if(self.run.state==="run"){ self._raf=0; return; }
      self.phys(dt); self.draw();
      if(!self.drag && Math.abs(self.v)<0.01){ self.v=0; self._raf=0; self.draw(); return; }
      self._raf=requestAnimationFrame(f); };
    this._raf=requestAnimationFrame(f);
  },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return clamp(W*0.52, 260, 360); }), c=f.c, W=f.W, H=f.H;
    var s=W/this.SPAN, yw=H*0.50, X=function(x){ return x*s; };
    this.g={s:s, yw:yw, X:X, Xinv:function(px){ return px/s; }};
    c.clearRect(0,0,W,H);
    var gs=c.createLinearGradient(0,0,0,yw); gs.addColorStop(0,"#e7f0f8"); gs.addColorStop(1,"#f5f9fc"); c.fillStyle=gs; c.fillRect(0,0,W,yw);
    var gw=c.createLinearGradient(0,yw,0,H); gw.addColorStop(0,"#9fcbe9"); gw.addColorStop(1,"#5f97c4"); c.fillStyle=gw; c.fillRect(0,yw,W,H-yw);
    /* 航跡（波）：速いほど大きい */
    c.save(); this.wake.forEach(function(w){ var al=(1-w.age/2.2)*0.7*w.a, wx=X(w.x);
      c.strokeStyle="rgba(255,255,255,"+al.toFixed(3)+")"; c.lineWidth=2;
      c.beginPath(); c.ellipse(wx, yw+2, 6+w.age*26*w.a, 2+w.age*3*w.a, 0, 0, Math.PI*2); c.stroke(); }); c.restore();
    c.strokeStyle="#2f6f9f"; c.lineWidth=2; c.beginPath(); c.moveTo(0,yw); c.lineTo(W,yw); c.stroke();
    var bx=X(this.x), bl=Math.max(70, s*3.4), dir=this.v>=0?1:-1;
    var drawBoat=function(cx){
      c.save(); c.translate(cx, yw);
      c.fillStyle="#f2f2ee"; c.strokeStyle="#3a414c"; c.lineWidth=1.6;
      c.beginPath(); c.moveTo(-bl/2,-10); c.lineTo(bl/2,-10); c.lineTo(bl/2-14,9); c.lineTo(-bl/2+8,9); c.closePath(); c.fill(); c.stroke();
      c.fillStyle="#c0392b"; c.fillRect(-bl/2+4,-2,bl-16,4);
      c.fillStyle="#dfe7ee"; c.fillRect(-bl*0.22,-26,bl*0.36,16); c.strokeRect(-bl*0.22,-26,bl*0.36,16);
      c.restore();
    };
    drawBoat(bx); if(bx<bl) drawBoat(bx+W); if(bx>W-bl) drawBoat(bx-W);
    /* しぶき */
    if(Math.abs(this.v)>1){ var sp=Math.abs(this.v)/this.VMAX, fx=bx+dir*bl/2; c.save(); c.fillStyle="rgba(255,255,255,.85)";
      for(var i=0;i<6;i++){ c.beginPath(); c.arc(fx+dir*(3+i*3*sp), yw-2-i*2*sp, 2.2+sp*2, 0, 7); c.fill(); } c.restore(); }
    /* スタート直後：手で押し出す */
    if(this.run.state!=="idle" && this.run.t<0.45){ var al=this.run.t<0.25?1:Math.max(0,1-(this.run.t-0.25)/0.2); c.save(); c.globalAlpha=al; hand(c, bx-bl/2-12, yw-14, Math.PI); c.restore(); }
    /* 抵抗力：船底（水とふれているところ）から、速度と逆向き */
    var Rv=this.R(this.v), kR=Math.min(1.4, 160/this.R(this.VMAX)), yr=yw+9;
    if(Rv*kR>3) { fArrow(c, bx, yr, bx-dir*Rv*kR, yr, COL.resist, 3, 11); SYM(c,"R",null,bx-dir*(Rv*kR+10),yr+12,{size:14,col:COL.resist,bold:true,halo:true,align:"center"}); }
    /* 速度：船の上に離して */
    if(Math.abs(this.v)>0.05){ var Lv=10+Math.abs(this.v)*12, yv=yw-46; arrow(c, bx-dir*Lv/2, yv, bx+dir*Lv/2, yv, COL.vel, 3, 10); SYM(c,"v",null,bx+dir*(Lv/2+8),yv,{size:14,col:COL.vel,bold:true,halo:true,align:"center"}); }
    if(!this.drag && this.run.state!=="run" && Math.abs(this.v)<0.01) T(c,"↔ 船をつかんで、左右に走らせてみよう", W/2, yw+H*0.32, {size:12.5,col:"#fff",bold:true,align:"center",halo:3,haloCol:"rgba(31,78,121,.55)"});
    /* 右上：抵抗力の大きさ R と速さ v の関係 */
    var gw2=Math.min(220,W*0.36), gL=W-gw2-6, gT=8, gB=yw-60;
    if(gB-gT>70){
      c.save(); c.globalAlpha=0.95; var ax=axesBox(c, gL+28, gT, W-10, gB, this.VMAX, niceStepV(this.R(this.VMAX),3)*Math.ceil(this.R(this.VMAX)/niceStepV(this.R(this.VMAX),3)), "v", "R［N］"); c.restore();
      c.save(); c.strokeStyle=COL.resist; c.lineWidth=2; c.beginPath();
      for(var j=0;j<=40;j++){ var vv=this.VMAX*j/40; if(j) c.lineTo(ax.X(vv),ax.Y(this.R(vv))); else c.moveTo(ax.X(vv),ax.Y(this.R(vv))); } c.stroke(); c.restore();
      c.fillStyle=COL.resist; c.beginPath(); c.arc(ax.X(Math.min(Math.abs(this.v),this.VMAX)), ax.Y(this.R(this.v)), 4.5, 0, 7); c.fill();
    }
    this.msg.innerHTML='速さ '+tex("v")+' ＝ <span class="num">'+Math.abs(this.v).toFixed(2)+'</span> m/s　→　水の抵抗力 '+tex("R")+' ＝ <span class="num">'+Rv.toFixed(0)+'</span> N（速いほど大きい）';
  }
};

/* ---------------- ③-3 流体から受ける力（大学の内容） ---------------- */
var S33 = { init:function(){}, draw:function(){} };
