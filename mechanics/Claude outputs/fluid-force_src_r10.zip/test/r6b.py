import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
        pg=await b.new_page(viewport={'width':1440,'height':900})
        await pg.goto('file:///home/claude/ff/fluid-force.html'); await pg.wait_for_timeout(900)
        await pg.evaluate('gotoSec("s12")'); await pg.wait_for_timeout(300)
        await pg.click('#s12 button[data-chk="mol"]')
        for i in range(4):
            await pg.wait_for_timeout(250)
            await (await pg.query_selector('#s12 .sL')).screenshot(path=f'test/r6_s12_{i}.png')
        print(await pg.evaluate("[...document.querySelectorAll('#s12 input')].map(e=>e.outerHTML).join('\\n')"))
        await b.close()
asyncio.run(main())
