import asyncio, sys
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
        pg=await b.new_page(viewport={'width':1440,'height':900}); errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
        await pg.goto('file:///home/claude/ff/fluid-force.html'); await pg.wait_for_timeout(900)
        await pg.evaluate('gotoSec("s14")'); await pg.wait_for_timeout(300)
        await pg.click('#s14 .fcell.pick[data-v="c"]'); await pg.wait_for_timeout(300)
        await (await pg.query_selector('#s14')).screenshot(path='test/r6_s14.png')
        await pg.click('#tabs .tab[data-mode="mode2"]'); await pg.wait_for_timeout(300)
        await pg.evaluate('gotoSec("s21")'); await pg.wait_for_timeout(300)
        await (await pg.query_selector('#s21')).screenshot(path='test/r6_s21.png')
        await pg.evaluate('gotoSec("s22")'); await pg.wait_for_timeout(300)
        await pg.click('#s22 .fcell.pick[data-v="c"]'); await pg.wait_for_timeout(300)
        await (await pg.query_selector('#s22')).screenshot(path='test/r6_s22.png')
        await pg.click('#tabs .tab[data-mode="mode1"]'); await pg.wait_for_timeout(300)
        await pg.evaluate('gotoSec("s12")'); await pg.wait_for_timeout(300)
        print(errs); await b.close()
asyncio.run(main())
