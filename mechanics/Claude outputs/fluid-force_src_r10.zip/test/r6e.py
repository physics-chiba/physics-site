import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
        pg=await b.new_page(viewport={'width':1440,'height':1000})
        await pg.goto('file:///home/claude/ff/fluid-force.html'); await pg.wait_for_timeout(900)
        await pg.click('#tabs .tab[data-mode="mode2"]'); await pg.wait_for_timeout(300)
        await pg.evaluate('gotoSec("s22")'); await pg.wait_for_timeout(400)
        await (await pg.query_selector('#s22 .fcell.live canvas')).screenshot(path='test/r6e.png')
        await b.close()
asyncio.run(main())
