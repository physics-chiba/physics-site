import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
        pg=await b.new_page(viewport={'width':1440,'height':950}); errs=[]; pg.on('pageerror',lambda e: errs.append(str(e.stack)[:300]))
        await pg.goto('file:///home/claude/ff/fluid-force.html'); await pg.wait_for_timeout(900)
        await pg.evaluate('gotoSec("s10")'); await pg.wait_for_timeout(300)
        await pg.click('#s10 button.b.play'); await pg.wait_for_timeout(2500)
        await (await pg.query_selector('#s10 .sL')).screenshot(path='test/r8_s10a.png')
        await pg.click('#s10 .v3btn'); await pg.wait_for_timeout(500)
        await (await pg.query_selector('#s10 .sL')).screenshot(path='test/r8_s10b.png')
        await pg.evaluate('gotoSec("s13")'); await pg.wait_for_timeout(300); await pg.click('#s13 button.b.play'); await pg.wait_for_timeout(1500)
        await (await pg.query_selector('#s13 .sL')).screenshot(path='test/r8_s13.png')
        await pg.click('#tabs .tab[data-mode="mode3"]'); await pg.wait_for_timeout(300)
        await pg.evaluate('gotoSec("s31")'); await pg.wait_for_timeout(300); await pg.click('#s31 button.b.play'); await pg.wait_for_timeout(9000)
        await (await pg.query_selector('#s31 .sL')).screenshot(path='test/r8_s31.png')
        print(errs); await b.close()
asyncio.run(main())
