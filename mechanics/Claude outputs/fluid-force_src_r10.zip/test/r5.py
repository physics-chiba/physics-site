import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
        pg=await b.new_page(viewport={'width':1440,'height':900}); errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
        await pg.goto('file:///home/claude/ff/fluid-force.html'); await pg.wait_for_timeout(900)
        print('pglow mode1', await pg.evaluate("[...document.querySelectorAll('#mode1 .pglow')].map(e=>e.textContent)"))
        # 1-2 drag -> slider sync
        await pg.evaluate('gotoSec("s12")'); await pg.wait_for_timeout(300)
        box=await (await pg.query_selector('#s12 canvas.main')).bounding_box()
        g=await pg.evaluate('({x:S12.g.X(0), y:S12.g.Y(S12.zc)})')
        await pg.mouse.move(box['x']+g['x'],box['y']+g['y']); await pg.mouse.down()
        for i in range(6): await pg.mouse.move(box['x']+g['x'],box['y']+g['y']+i*10); await pg.wait_for_timeout(20)
        print('slider', await pg.evaluate("document.querySelector('#s12 .tsl input').value"), 'zc-h', await pg.evaluate('(S12.zc-S12.half()).toFixed(2)'), await pg.inner_text('#s12 .tinfo'))
        await pg.mouse.up()
        # 2-1 drag tinfo
        await pg.click('#tabs .tab[data-mode="mode2"]'); await pg.wait_for_timeout(300)
        await pg.evaluate('gotoSec("s21")'); await pg.wait_for_timeout(300)
        box=await (await pg.query_selector('#s21 canvas.main')).bounding_box(); g=await pg.evaluate('({x:S21.g.xo, y:S21.g.yc})')
        await pg.mouse.move(box['x']+g['x'],box['y']+g['y']); await pg.mouse.down()
        for i in range(6): await pg.mouse.move(box['x']+g['x'],box['y']+g['y']-i*15); await pg.wait_for_timeout(20)
        await pg.mouse.up(); print('2-1 tinfo', await pg.inner_text('#s21 .tinfo'))
        # 2-2 gas -> gravity arrow length constant
        await pg.evaluate('gotoSec("s22")'); await pg.wait_for_timeout(300)
        k1=await pg.evaluate('S22.Fref()'); await pg.click('#s22 button[data-g="gas"][data-v="air"]'); k2=await pg.evaluate('S22.Fref()'); print('Fref', k1, k2)
        el=await pg.query_selector('#s22'); await el.screenshot(path='test/r5_s22.png')
        # 3-2 drag right then left
        await pg.click('#tabs .tab[data-mode="mode3"]'); await pg.wait_for_timeout(300)
        await pg.evaluate('gotoSec("s32")'); await pg.wait_for_timeout(300)
        box=await (await pg.query_selector('#s32 canvas.main')).bounding_box(); g=await pg.evaluate('({x:S32.g.X(S32.x), y:S32.g.yw})')
        x=box['x']+g['x']; y=box['y']+g['y']-5
        await pg.mouse.move(x,y); await pg.mouse.down(); log=[]
        for i in range(15): x+=20; await pg.mouse.move(x,y); await pg.wait_for_timeout(25); log.append(round(await pg.evaluate('S32.v'),2))
        for i in range(25): x-=20; await pg.mouse.move(x,y); await pg.wait_for_timeout(25); log.append(round(await pg.evaluate('S32.v'),2))
        await pg.mouse.up(); print('3-2 v', log)
        print('pos match', await pg.evaluate('S32.g.X(S32.x)'), x-box['x'])
        print(errs); await b.close()
asyncio.run(main())
