import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
        pg=await b.new_page(viewport={'width':1440,'height':1000})
        await pg.goto('file:///home/claude/ff/fluid-force.html'); await pg.wait_for_timeout(900)
        await pg.evaluate('gotoSec("s12")'); await pg.wait_for_timeout(300)
        await pg.click('#s12 button[data-chk="mol"]'); await pg.wait_for_timeout(500)
        r=await pg.evaluate('''(()=>{var s=S12, g=s.g, out=[]; var D=s.D; var ys=s.mols.map(m=>m.z); var zs=[...new Set(ys.map(z=>z.toFixed(3)))]; return {D:D, rows:zs.slice(-4), s:g.s, YD:g.Y(D), lastY:zs.slice(-3).map(z=>g.Y(+z))};})()''')
        print(r)
        await b.close()
asyncio.run(main())
