import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
        pg=await b.new_page(viewport={'width':1440,'height':900}); errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
        await pg.goto('file:///home/claude/ff/fluid-force.html#1-2'); await pg.wait_for_timeout(900)
        await pg.click('#s12 .v3btn'); await pg.wait_for_timeout(300)
        el=await pg.query_selector('#s12 .sL'); await el.screenshot(path='test/v3_rect.png')
        box=await (await pg.query_selector('#s12 canvas.main')).bounding_box()
        await pg.mouse.move(box['x']+40, box['y']+box['height']-40); await pg.mouse.down()
        for i in range(10): await pg.mouse.move(box['x']+40+i*15, box['y']+box['height']-40-i*6); await pg.wait_for_timeout(20)
        await pg.mouse.up(); print('cam', await pg.evaluate('JSON.stringify(S12.cam)'))
        g=await pg.evaluate('S12.g3'); z0=await pg.evaluate('S12.zc')
        await pg.mouse.move(box['x']+g['ox'], box['y']+g['oy']); await pg.mouse.down()
        for i in range(8): await pg.mouse.move(box['x']+g['ox'], box['y']+g['oy']+i*6); await pg.wait_for_timeout(20)
        await pg.mouse.up(); print('zc', z0, await pg.evaluate('S12.zc'))
        await pg.click('#s12 button.seg[data-v="circle"]'); await pg.wait_for_timeout(200); await el.screenshot(path='test/v3_sphere.png')
        await pg.click('#s12 button.seg[data-v="trap"]'); await pg.click('#s12 button.b.play'); await pg.wait_for_timeout(600); await el.screenshot(path='test/v3_trap.png')
        await pg.evaluate('gotoSec("s31")'); await pg.wait_for_timeout(300); await pg.click('#s31 button.b.play'); await pg.wait_for_timeout(5000)
        el2=await pg.query_selector('#s31'); await el2.screenshot(path='test/s31_run.png')
        print(errs)
        await b.close()
asyncio.run(main())
