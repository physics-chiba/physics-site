import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
        pg=await b.new_page(viewport={'width':1920,'height':1000})
        await pg.goto('file:///home/claude/ff/fluid-force.html'); await pg.wait_for_timeout(900)
        await pg.evaluate('gotoSec("s12")'); await pg.wait_for_timeout(300)
        await pg.click('#s12 button[data-chk="mol"]')
        await pg.click('#s12 button.b.play'); 
        for i in range(8):
            await pg.wait_for_timeout(400)
            await (await pg.query_selector('#s12 canvas.main')).screenshot(path=f'test/r6c_{i}.png')
        await b.close()
asyncio.run(main())
