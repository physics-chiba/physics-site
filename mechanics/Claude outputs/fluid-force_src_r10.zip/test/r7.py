import asyncio
from playwright.async_api import async_playwright
async def shot(pg,sel,name): await (await pg.query_selector(sel)).screenshot(path='test/'+name)
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
        pg=await b.new_page(viewport={'width':1440,'height':950}); errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
        await pg.goto('file:///home/claude/ff/fluid-force.html'); await pg.wait_for_timeout(900)
        print('seclinks', await pg.evaluate("[...document.querySelectorAll('#mode1 .seclinks a')].map(a=>a.textContent+' '+a.getAttribute('href'))"))
        await pg.evaluate('gotoSec("s10")'); await pg.wait_for_timeout(300)
        await pg.click('#s10 button.b.play'); await pg.wait_for_timeout(2500)
        await shot(pg,'#s10','r7_s10.png')
        await pg.evaluate("(()=>{var i=document.querySelector('#s10 .vrow[data-k=\"S\"] input'); i.value=4; i.dispatchEvent(new Event('input'));})()"); await pg.wait_for_timeout(1500)
        await shot(pg,'#s10 .sL','r7_s10b.png')
        await pg.evaluate('gotoSec("s11")'); await pg.wait_for_timeout(300); await shot(pg,'#s11 .sL','r7_s11.png')
        await pg.evaluate('gotoSec("s13")'); await pg.wait_for_timeout(300); await shot(pg,'#s13 .sL','r7_s13.png')
        await pg.click('#tabs .tab[data-mode="mode2"]'); await pg.wait_for_timeout(300)
        await pg.evaluate('gotoSec("s21")'); await pg.wait_for_timeout(300); await shot(pg,'#s21 .sL','r7_s21a.png')
        await pg.click('#s21 button[data-g="shape"][data-v="ball"]'); await pg.evaluate("S21.z=10000; S21.draw()"); await pg.wait_for_timeout(200); await shot(pg,'#s21 .sL','r7_s21b.png')
        await pg.evaluate('gotoSec("s22")'); await pg.wait_for_timeout(300)
        await pg.click('#s22 button[data-g="gas"][data-v="air"]'); await pg.click('#s22 button.b.play'); await pg.wait_for_timeout(1500)
        await shot(pg,'#s22 .fcell.live','r7_s22.png')
        print(errs); await b.close()
asyncio.run(main())
