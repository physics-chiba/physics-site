import asyncio, json
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        pg = await b.new_page(viewport={'width':1440,'height':900})
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('file:///home/claude/ff/fluid-force.html'); await pg.wait_for_timeout(700)
        for sid,wait in [('s11',2200),('s12',700),('s13',700),('s14',300),('s21',700),('s22',2500),('s31',1200),('s32',600)]:
            await pg.evaluate(f'gotoSec("{sid}")'); await pg.wait_for_timeout(300)
            await pg.click(f'#{sid} button.b.play'); await pg.wait_for_timeout(wait)
            el=await pg.query_selector('#'+sid); await el.screenshot(path=f'test/run_{sid}.png')
            txt=await pg.inner_text(f'#{sid} button.b.play'); print(sid, txt)
        # 1-4 iron, view b
        await pg.evaluate('gotoSec("s14")'); await pg.wait_for_timeout(200)
        await pg.click('#s14 button[data-g="dens"][data-v="4"]')
        await pg.click('#s14 .fcell.pick[data-v="b"]')
        await pg.click('#s14 button.rst'); await pg.click('#s14 button.b.play'); await pg.wait_for_timeout(2500)
        el=await pg.query_selector('#s14 .fourgrid'); await el.screenshot(path='test/run_s14_iron.png')
        await pg.click('#s14 .fcell.pick[data-v="c"]'); await pg.click('#s14 button[data-g="dens"][data-v="1"]')
        await pg.click('#s14 button.b.play'); await pg.wait_for_timeout(3500)
        el=await pg.query_selector('#s14 .fourgrid'); await el.screenshot(path='test/run_s14_ice.png')
        print(await pg.inner_text('#s14 .msgbox'))
        await pg.click('#s14 .fcell.pick[data-v="b"]'); await pg.click('#s14 button[data-g="dens"][data-v="4"]'); await pg.click('#s14 button[data-g="liq"][data-v="3"]')
        await pg.click('#s14 button.rst'); await pg.click('#s14 button.b.play'); await pg.wait_for_timeout(4000)
        el=await pg.query_selector('#s14'); await el.screenshot(path='test/run_s14_hg.png')
        print(errs)
        pg2 = await b.new_page(viewport={'width':390,'height':844})
        await pg2.goto('file:///home/claude/ff/fluid-force.html#1-4'); await pg2.wait_for_timeout(900)
        print('sw390', await pg2.evaluate('document.documentElement.scrollWidth'))
        await b.close()
asyncio.run(main())
