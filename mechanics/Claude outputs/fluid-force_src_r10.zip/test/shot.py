import sys, asyncio, json
from playwright.async_api import async_playwright
URL = 'file:///home/claude/ff/fluid-force.html'
OUT = '/home/claude/ff/test/'

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        res = {}
        for (w, h) in [(1440, 900), (390, 844)]:
            pg = await b.new_page(viewport={'width': w, 'height': h})
            errs, ext = [], []
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.on('console', lambda m: errs.append('console:' + m.text) if m.type == 'error' else None)
            pg.on('request', lambda r: ext.append(r.url) if not r.url.startswith(('file:', 'data:')) else None)
            await pg.goto(URL); await pg.wait_for_timeout(800)
            await pg.evaluate('window.__hero && window.__hero.frame(1.2)')
            await pg.screenshot(path=OUT + f'hero_{w}.png')
            for sid in ['s11','s12','s13','s14','s21','s22','s31','s32','s33']:
                await pg.evaluate(f'gotoSec("{sid}")'); await pg.wait_for_timeout(400)
                el = await pg.query_selector('#' + sid)
                await el.screenshot(path=OUT + f'{sid}_{w}.png')
            # 全部を再生（最後まで）
            for sid in ['s11','s12','s13','s14','s21','s22','s31','s32','s33']:
                await pg.evaluate(f'gotoSec("{sid}")'); await pg.wait_for_timeout(200)
                await pg.evaluate(f"(()=>{{const b=document.querySelector('#{sid} button.b.play'); if(b) b.click();}})()")
                await pg.wait_for_timeout(200)
            sw = await pg.evaluate('document.documentElement.scrollWidth')
            res[w] = {'errs': errs, 'ext': ext, 'scrollW': sw}
            await pg.close()
        print(json.dumps(res, ensure_ascii=False, indent=1))
        await b.close()
asyncio.run(main())
