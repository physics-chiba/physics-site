import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
        pg=await b.new_page(viewport={'width':1440,'height':950}); errs=[]; pg.on('pageerror',lambda e: errs.append(str(e.stack)[:300]))
        await pg.goto('file:///home/claude/ff/fluid-force.html'); await pg.wait_for_timeout(900)
        await pg.evaluate('gotoSec("s10")'); await pg.wait_for_timeout(300)
        await pg.click('#s10 button.b.play'); await pg.wait_for_timeout(3000)
        await (await pg.query_selector('#s10 .sL')).screenshot(path='test/r9_s10a.png')
        await pg.click('#s10 .v3btn'); await pg.wait_for_timeout(500)
        await (await pg.query_selector('#s10 canvas.main')).screenshot(path='test/r9_s10b.png')
        await pg.evaluate('gotoSec("s13")'); await pg.wait_for_timeout(300)
        await (await pg.query_selector('#s13 canvas.main')).screenshot(path='test/r9_s13.png')
        await pg.evaluate('gotoSec("s14")'); await pg.wait_for_timeout(300)
        await (await pg.query_selector('#s14')).screenshot(path='test/r9_s14.png')
        await pg.click('#tabs .tab[data-mode="mode2"]'); await pg.wait_for_timeout(300)
        await pg.evaluate('gotoSec("s22")'); await pg.wait_for_timeout(300)
        await (await pg.query_selector('#s22')).screenshot(path='test/r9_s22.png')
        print(await pg.evaluate("[...document.querySelectorAll('#tabs .tab')].map(t=>t.textContent).join(' | ')"))
        print(errs); await b.close()
asyncio.run(main())
