import json
from playwright.sync_api import sync_playwright
url='file:///home/claude/shm/dist/simple-harmonic-motion.html'
O='/tmp/claude-0/-home-claude/2f9766fc-7cce-5ee2-a354-367640d60391/scratchpad/'
r={}
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1440,'height':1000})
    errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(url+'#1-1'); pg.wait_for_timeout(1200)
    pg.add_style_tag(content='.sec{content-visibility:visible !important}')
    # 1-1: light pressed at t=0.62 -> snaps to 0.5 (T/8=0.25) -> phi = pi*0.5 = pi/2
    r['l11']=pg.evaluate("""(()=>{const s=TEST.sim('m1s1'); s.setT(0.62); s.extra.light.click(); const a=[s.tOn, m1s1Phi(s)]; s.extra.light.click(); s.setT(1.13); s.extra.light.click(); a.push(s.tOn, m1s1Phi(s)); s.setT(3.0); s.draw(); return a;})()""")
    pg.query_selector('#m1s1').screenshot(path=O+'m11.png')
    # force buttons exclusive
    r['fbtn']=pg.evaluate("""(()=>{const s=TEST.sim('m1s2'); const a=[s.fmode]; s.extra.fAll.click(); a.push(s.fmode, s.extra.fNet.classList.contains('on')); s.extra.fAll.click(); a.push(s.fmode); s.toDefaults(); a.push(s.fmode); return a;})()""")
    r['fdef']=pg.evaluate("""['m1s2','m1s3'].map(id=>TEST.sim(id).fmode)""")
    # 1-3 phi buttons
    r['seg13']=pg.evaluate("""(()=>{const s=TEST.sim('m1s3'); const bs=s.sl.phi.seg.querySelectorAll('.vsegb'); bs[0].click(); return [bs.length, s.v.phi, bs[0].classList.contains('on')];})()""")
    pg.goto(url+'#mode2'); pg.wait_for_timeout(1200)
    pg.add_style_tag(content='.sec{content-visibility:visible !important}')
    r['fdef2']=pg.evaluate("""['m2s1','m2s2','m2s3','m2s4','m2s5','m2s6','m2s7'].map(id=>TEST.sim(id).fmode)""")
    # 2-8: change mass, read periods
    pg.goto(url+'#mode3'); pg.wait_for_timeout(1200)
    r['s8']=pg.evaluate("""(()=>{const s=TEST.sim('m3s1'); s.v.m=2.0; s.v.g='moon'; s.changed(); const out={}; ['base','A','m','g'].forEach(rw=>{out[rw]=['h','v','p'].map(c=>+s.period(c,s.cond(rw)).toFixed(3));}); s.toggle(); return out;})()""")
    pg.wait_for_timeout(1200)
    r['s8t']=pg.evaluate("TEST.sim('m3s1').t")
    pg.evaluate("TEST.sim('m3s1').reset()")
    pg.query_selector('#m3s1').screenshot(path=O+'m28.png')
    pg.set_viewport_size({'width':390,'height':844}); pg.wait_for_timeout(300)
    pg.query_selector('#m3s1').screenshot(path=O+'m28m.png')
    r['err']=errs
    print(json.dumps(r,ensure_ascii=False)); b.close()
