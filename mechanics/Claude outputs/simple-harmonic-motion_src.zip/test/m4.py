import json
from playwright.sync_api import sync_playwright
url='file:///home/claude/shm/dist/simple-harmonic-motion.html'
O='/tmp/claude-0/-home-claude/2f9766fc-7cce-5ee2-a354-367640d60391/scratchpad/'
r={}
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1440,'height':1000})
    errs=[]; pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: m.type=='error' and errs.append(m.text))
    pg.goto(url+'#mode4'); pg.wait_for_timeout(1500)
    r['q']=pg.evaluate("""(()=>{const s=TEST.sim('m4s1'); const out={}; [0.5,1,1.5,2].forEach(sr=>{s.v.sr=sr; const q=m4s1Q(s); out[sr]=[q.d,q.T,q.sep,q.t1,q.v0,q.t2].map(v=>+(+v).toFixed(4));}); return out;})()""")
    # v0 formula: g*sqrt(6M/k) at s=2d
    r['v0_formula']=pg.evaluate("9.8*Math.sqrt(6*1/100)")
    # N continuity and energy check while together
    r['Nchk']=pg.evaluate("""(()=>{const s=TEST.sim('m4s1'); s.v.sr=2; const q=m4s1Q(s); const a=m4s1State(s,q.t1-1e-6), b=m4s1State(s,q.t1+1e-6); return [a.N, a.xo, b.xo, a.vo, b.vo, b.vp];})()""")
    pg.evaluate("(()=>{const s=TEST.sim('m4s1'); s.v.sr=2; s.changed(); s.setT(0.0); s.draw();})()")
    pg.query_selector('#m4s1').screenshot(path=O+'m41a.png')
    pg.evaluate("(()=>{const s=TEST.sim('m4s1'); const q=m4s1Q(s); s.setT(q.t1+0.08); s.draw();})()")
    pg.query_selector('#m4s1').screenshot(path=O+'m41b.png')
    for w in [360,768,1100]:
        pg.set_viewport_size({'width':w,'height':900}); pg.wait_for_timeout(400)
        r['ov%d'%w]=pg.evaluate("document.documentElement.scrollWidth-innerWidth")
    pg.set_viewport_size({'width':390,'height':900}); pg.wait_for_timeout(400)
    pg.query_selector('#m4s1').screenshot(path=O+'m41m.png')
    r['errs']=errs
print(json.dumps(r,ensure_ascii=False,indent=1))
