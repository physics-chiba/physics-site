import json,sys
from playwright.sync_api import sync_playwright
url='file:///home/claude/shm/dist/simple-harmonic-motion.html'
O='/tmp/claude-0/-home-claude/2f9766fc-7cce-5ee2-a354-367640d60391/scratchpad/'
shots=sys.argv[1:] 
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1440,'height':1000})
    errs=[]; pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: m.type in ('error','warning') and errs.append(m.text[:150]))
    for sh in shots:
        sec,js=(sh.split('|')+[''])[:2]
        pg.goto(url+'#'+sec); pg.wait_for_timeout(1300); pg.add_style_tag(content='.sec{content-visibility:visible !important}')
        sid={'1':'m1s','2':'m2s','3':'m3s','4':'m4s'}[sec[0]]+sec.split('-')[1]
        pg.query_selector('#'+sid).scroll_into_view_if_needed(); pg.wait_for_timeout(500)
        if js: pg.evaluate(js); pg.wait_for_timeout(300)
        pg.query_selector('#'+sid).screenshot(path=O+'r_'+sec+'.png')
    print(errs)
