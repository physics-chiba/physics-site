from playwright.sync_api import sync_playwright
O='/tmp/claude-0/-home-claude/2f9766fc-7cce-5ee2-a354-367640d60391/scratchpad/st'
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1440,'height':900})
    errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('file:///home/claude/shm/dist/simple-harmonic-motion.html#1-2'); pg.wait_for_timeout(900)
    pg.add_style_tag(content='.sec{content-visibility:visible !important}')
    pg.evaluate("modeState('mode1').showF=true; syncModeBar('mode1')")
    shots=[('m1s2',"s.initMode='end'; s.setT(0); s.draw()",'a'),('m1s2',"s.setT(0.9); s.onPick? 0:0; s.def.onPick(s,'v')",'b'),
           ('m1s3',"s.initMode='end'; s.setT(0)",'a'),('m1s3',"s.initMode='center'; s.setT(0.05)",'b'),('m1s3',"s.setT(0.5)",'c'),('m1s2',"s.initMode='center'; s.setT(0.06)",'c')]
    for sid,js,tag in shots:
        pg.evaluate("(()=>{const s=TEST.sim('%s'); %s; s.draw();})()"%(sid,js))
        pg.query_selector('#cv_'+sid).screenshot(path=f'{O}_{sid}_{tag}.png')
    pg.query_selector('#simR_m1s2').screenshot(path=O+'_R2.png')
    print(errs)
    b.close()
