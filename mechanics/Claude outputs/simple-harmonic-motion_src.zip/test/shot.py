import sys
from playwright.sync_api import sync_playwright
O='/tmp/claude-0/-home-claude/2f9766fc-7cce-5ee2-a354-367640d60391/scratchpad/'
url='file:///home/claude/shm/dist/simple-harmonic-motion.html#'
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':int(sys.argv[1]) if sys.argv[1].isdigit() else 1440,'height':1000})
    errs=[]; pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: m.type in ('error','warning') and errs.append(m.text[:200]))
    for a in sys.argv[2:]:
        h,sid,js=(a.split('|')+['',''])[:3]
        pg.goto(url+h); pg.wait_for_timeout(1500)
        pg.add_style_tag(content='.sec{content-visibility:visible !important} #tabs{position:static !important}')
        e=pg.query_selector('#'+sid); e.scroll_into_view_if_needed(); pg.wait_for_timeout(300)
        if js: pg.evaluate(js); pg.wait_for_timeout(400)
        e.screenshot(path=O+'s_'+sid+'.png')
    print(errs)
