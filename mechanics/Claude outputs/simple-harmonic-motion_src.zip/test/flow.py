import json
from playwright.sync_api import sync_playwright
url='file:///home/claude/shm/dist/simple-harmonic-motion.html'
O='/tmp/claude-0/-home-claude/2f9766fc-7cce-5ee2-a354-367640d60391/scratchpad/f'
res={}
with sync_playwright() as p:
    b=p.chromium.launch()
    pg=b.new_page(viewport={'width':1280,'height':900})
    errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(url+'#1-2'); pg.wait_for_timeout(900)
    pg.add_style_tag(content='.sec{content-visibility:visible !important}')
    # ω 大きく → m が 1 段小さく
    res['before']=pg.evaluate("(()=>{const s=TEST.sim('m1s2');return [s.v.m,s.v.k]})()")
    pg.evaluate("TEST.sim('m1s2').sl.m.up.click()")
    res['after_m_up']=pg.evaluate("(()=>{const s=TEST.sim('m1s2');return [s.v.m,s.v.k,+s.disp('w').toFixed(3),+s.disp('T').toFixed(3),+s.disp('f').toFixed(3)]})()")
    pg.evaluate("TEST.sim('m1s2').sl.phi.up.click()")
    res['phi_eq']=pg.evaluate("TEST.sim('m1s2').sl.phi.eq.textContent.slice(0,60)")
    pg.evaluate("TEST.sim('m1s2').toDefaults()")
    # ドラッグ：小球を下へ
    cv=pg.query_selector('#cv_m1s2'); cv.scroll_into_view_if_needed(); pg.wait_for_timeout(200)
    bb=cv.bounding_box()
    ball=pg.evaluate("(()=>{const s=TEST.sim('m1s2');const G=m1s2Geo(s.W,s.H);const B=m1s2Ball(s,G);return [G.xs,B.y,G.cy,G.S]})()")
    pg.mouse.move(bb['x']+ball[0], bb['y']+ball[1]); pg.mouse.down(); pg.mouse.move(bb['x']+ball[0], bb['y']+ball[2]+0.07*ball[3], steps=6); pg.mouse.up()
    res['drag']=pg.evaluate("(()=>{const s=TEST.sim('m1s2');return [+s.v.A.toFixed(3), +s.v.phi.toFixed(4)]})()")
    # 再生して最後まで
    pg.evaluate("(()=>{const s=TEST.sim('m1s2'); s.setT(s.tEnd()-0.05); s.togglePlay();})()"); pg.wait_for_timeout(400)
    res['endlabel']=pg.evaluate("TEST.sim('m1s2').bPlay.textContent")
    # グラフのドラッグ
    g=pg.query_selector('#m1s2 .g-x canvas'); gb=g.bounding_box()
    g0=pg.evaluate("JSON.stringify(TEST.sim('m1s2').gx)")
    pg.mouse.move(gb['x']+gb['width']/2, gb['y']+gb['height']/2); pg.mouse.down(); pg.mouse.move(gb['x']+gb['width']/2-80, gb['y']+gb['height']/2+10, steps=5); pg.mouse.up()
    res['graphpan']=[g0, pg.evaluate("JSON.stringify(TEST.sim('m1s2').gx)")]
    # どのグラフもドラッグできるか（全セクション）
    ok=[]
    for sid in ['m1s2','m1s3']:
        for gc in pg.query_selector_all('#'+sid+' .gbox canvas'):
            gc.scroll_into_view_if_needed(); q=gc.bounding_box()
            y0=pg.evaluate("(c)=>{const s=TEST.sim('%s');const g=s.graphs.find(x=>x.cv===c);return g.yr.lo}"%sid, gc)
            pg.mouse.move(q['x']+q['width']/2,q['y']+q['height']/2); pg.mouse.down(); pg.mouse.move(q['x']+q['width']/2,q['y']+q['height']/2+20,steps=4); pg.mouse.up()
            y1=pg.evaluate("(c)=>{const s=TEST.sim('%s');const g=s.graphs.find(x=>x.cv===c);return g.yr.lo}"%sid, gc)
            ok.append(abs(y1-y0)>1e-9)
    res['graphs_draggable']=ok
    # 全セクションを最後まで再生
    for sid in ['m1s1','m1s2','m1s3']:
        pg.evaluate("(()=>{const s=TEST.sim('%s'); s.toDefaults(); for(let t=0;t<s.tEnd();t+=0.05){s.setT(t);} s.setT(s.tEnd());})()"%sid)
    res['footer']=pg.evaluate("document.documentElement.outerHTML.includes('physics-chiba.goatcounter.com') && document.documentElement.outerHTML.includes('sg-glow')")
    # 光る→押すと消える
    pg.goto(url); pg.wait_for_timeout(1200)
    res['glow_initial']=pg.evaluate("!!document.querySelector('#bPlay.sg-glow')")
    pg.evaluate("document.getElementById('bPlay').click()"); pg.wait_for_timeout(500)
    res['glow_after_click']=pg.evaluate("!!document.querySelector('.sg-glow')")
    # 幅
    sc={}
    for w in [320,360,390,768,1024,1440]:
        pg.set_viewport_size({'width':w,'height':860}); pg.wait_for_timeout(250)
        sc[w]=pg.evaluate("document.documentElement.scrollWidth - innerWidth")
    res['hscroll']=sc
    pg.set_viewport_size({'width':390,'height':844}); pg.goto(url+'#1-2'); pg.wait_for_timeout(900)
    pg.add_style_tag(content='.sec{content-visibility:visible !important}')
    for sid in ['m1s1','m1s2','m1s3']:
        pg.evaluate("(()=>{const s=TEST.sim('%s'); if(s.def.id==='m1s1'){s.light=true;s.tOn=0;} s.setT(2.6);})()"%sid)
        e=pg.query_selector('#'+sid+' .sL'); e.screenshot(path=O+'_390_'+sid+'.png')
    res['errors']=errs
    b.close()
print(json.dumps(res,ensure_ascii=False,indent=0))
