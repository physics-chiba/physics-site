from playwright.sync_api import sync_playwright
from PIL import Image
O='/tmp/claude-0/-home-claude/2f9766fc-7cce-5ee2-a354-367640d60391/scratchpad/s17_'
url='file:///home/claude/shm/dist/simple-harmonic-motion.html'
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1440,'height':1000})
    errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(url+'#mode1'); pg.wait_for_timeout(1500)
    pg.add_style_tag(content='.sec{content-visibility:visible !important} .tabs{position:static !important}')
    for sid in ['m1s1','m1s2','m1s3']:
        pg.evaluate("TEST.sim('%s').draw()"%sid); pg.wait_for_timeout(100)
        f=O+sid+'.png'; pg.query_selector('#'+sid).screenshot(path=f); im=Image.open(f); im.crop((0,0,im.size[0],min(im.size[1],900))).save(f)
    pg.goto(url+'#mode2'); pg.wait_for_timeout(1500)
    pg.add_style_tag(content='.sec{content-visibility:visible !important} .tabs{position:static !important}')
    for i in range(1,8):
        sid='m2s%d'%i
        pg.evaluate("TEST.sim('%s').draw()"%sid); pg.wait_for_timeout(100)
        f=O+sid+'.png'; pg.query_selector('#'+sid).screenshot(path=f); im=Image.open(f); im.crop((0,0,im.size[0],min(im.size[1],700))).save(f)
    pg.evaluate("(()=>{const s=TEST.sim('m2s2'); s.extra.fAll.click(); s.setT(0.04);})()"); pg.wait_for_timeout(100)
    pg.query_selector('#cv_m2s2').screenshot(path=O+'m2s2f.png')
    print(errs); b.close()
