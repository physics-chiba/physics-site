import sys
from playwright.sync_api import sync_playwright
from PIL import Image
O='/tmp/claude-0/-home-claude/2f9766fc-7cce-5ee2-a354-367640d60391/scratchpad/'
W=int(sys.argv[1]) if len(sys.argv)>1 else 1440
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':W,'height':1000})
    errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('file:///home/claude/shm/dist/simple-harmonic-motion.html#mode2'); pg.wait_for_timeout(1500)
    pg.add_style_tag(content='.sec{content-visibility:visible !important} .tabs{position:static !important}')
    for i in range(1,9):
        sid='m2s%d'%i
        if i<8: pg.evaluate("(()=>{const s=TEST.sim('%s'); s.setT(0); s.draw(); s.align();})()"%sid)
        pg.wait_for_timeout(150)
        f=O+'n_%s_%d.png'%(sid,W); pg.query_selector('#'+sid).screenshot(path=f)
        im=Image.open(f); im.crop((0,0,im.size[0],min(im.size[1],780))).save(f)
    print(errs); b.close()
