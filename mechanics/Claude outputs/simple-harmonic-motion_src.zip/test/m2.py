import sys, json
from playwright.sync_api import sync_playwright
O='/tmp/claude-0/-home-claude/2f9766fc-7cce-5ee2-a354-367640d60391/scratchpad/m2'
T=float(sys.argv[1]) if len(sys.argv)>1 else 0.9
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1440,'height':900})
    errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('file:///home/claude/shm/dist/simple-harmonic-motion.html#mode2'); pg.wait_for_timeout(1200)
    pg.add_style_tag(content='.sec{content-visibility:visible !important}')
    for i in range(1,8):
        sid='m2s%d'%i
        pg.evaluate("(()=>{const s=TEST.sim('%s'); s.setT(%f);})()"%(sid,T))
        pg.wait_for_timeout(150)
        pg.query_selector('#'+sid).screenshot(path=f'{O}_{sid}.png')
    print(errs)
    b.close()
