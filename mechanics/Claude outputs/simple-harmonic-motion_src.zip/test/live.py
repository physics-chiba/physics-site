import json, random
from playwright.sync_api import sync_playwright
url='file:///home/claude/shm/dist/simple-harmonic-motion.html#'
random.seed(2)
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1440,'height':900})
    errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)[:200])); pg.on('console', lambda m: m.type=='error' and errs.append(m.text[:200]))
    out={}
    for h,sid in [('4-1','m4s0'),('4-2','m4s1'),('4-3','m4s2'),('4-4','m4s3'),('4-5','m4s4'),('4-6','m4s5'),('3-2','m3s2'),('1-2','m1s2'),('2-3','m2s3'),('2-8','m2s8')]:
        pg.goto(url+h); pg.wait_for_timeout(1200)
        pg.evaluate("window.__ft=[]; (function f(t0){ requestAnimationFrame(function(t){ window.__ft.push(t-t0); f(t); }); })(performance.now())")
        btns=pg.query_selector_all('#'+sid+' button')
        btns=[x for x in btns if x.is_visible()]
        play=pg.query_selector('#'+sid+' .b.play') or pg.query_selector('#'+sid+' button.play')
        for i in range(14):
            bt=random.choice(btns)
            try: bt.click(timeout=1500)
            except Exception as e: pass
            pg.wait_for_timeout(120)
        if play: play.click(); pg.wait_for_timeout(1200)
        ft=pg.evaluate("window.__ft.slice(5)")
        ft=sorted(ft); out[sid]={'frames':len(ft),'median':round(ft[len(ft)//2],1) if ft else None,'p95':round(ft[int(len(ft)*0.95)],1) if ft else None}
    print(json.dumps(out)); print('errs',errs[:8])
