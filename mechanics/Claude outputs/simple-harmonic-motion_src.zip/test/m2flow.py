import json
from playwright.sync_api import sync_playwright
url='file:///home/claude/shm/dist/simple-harmonic-motion.html'
res={}
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1280,'height':900})
    errs=[]; pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: m.type=='error' and errs.append(m.text))
    reqs=[]; pg.on('request', lambda r: (not r.url.startswith('file:') and not r.url.startswith('data:')) and reqs.append(r.url))
    pg.goto(url+'#mode2'); pg.wait_for_timeout(1000)
    pg.add_style_tag(content='.sec{content-visibility:visible !important}')
    ids=['m2s%d'%i for i in range(1,8)]
    drag={}
    for sid in ids:
        pg.evaluate("(()=>{const s=TEST.sim('%s'); s.det.open=true;})()"%sid); pg.wait_for_timeout(150)
        ok=[]
        for gc in pg.query_selector_all('#'+sid+' .gbox canvas'):
            gc.scroll_into_view_if_needed(); q=gc.bounding_box()
            y0=pg.evaluate("(c)=>{const s=TEST.sim('%s');const g=s.graphs.find(x=>x.cv===c);return g?g.yr.lo:null}"%sid, gc)
            if y0 is None: continue
            pg.mouse.move(q['x']+q['width']/2,q['y']+q['height']/2); pg.mouse.down(); pg.mouse.move(q['x']+q['width']/2,q['y']+q['height']/2+20,steps=4); pg.mouse.up()
            y1=pg.evaluate("(c)=>{const s=TEST.sim('%s');const g=s.graphs.find(x=>x.cv===c);return g.yr.lo}"%sid, gc)
            ok.append(abs(y1-y0)>1e-9)
        drag[sid]=ok
        # 全部の目盛りを動かして最後まで再生
        pg.evaluate("""(()=>{const s=TEST.sim('%s'); for (const k in s.sl){ const sl=s.sl[k]; for(let i=0;i<8;i++){ if(sl.up) sl.up.click(); } for(let i=0;i<8;i++){ if(sl.dn) sl.dn.click(); } }
           for(let t=0;t<s.tEnd();t+=0.05){s.setT(t);} s.setT(s.tEnd()); s.toDefaults(); })()"""%sid)
        # スナップのホバー
        cs=pg.query_selector_all('#'+sid+' .snapcell'); cs[-1].scroll_into_view_if_needed(); cs[-1].hover(); pg.wait_for_timeout(150)
        vis=pg.evaluate("(sid)=>{const b=document.querySelector('#'+sid+' .snapbox'); const z=b.querySelector('.snapzin canvas'); const c=[...b.querySelectorAll('.snapcell')]; return [z.width>0, c[c.length-1].classList.contains('on'), c.every(x=>x.querySelector('canvas').width>0)]}", sid); drag[sid].append(('snapz',vis))   # 2026-10-19 拡大図は箱の中
        pg.mouse.move(5,5)
    res['drag']=drag
    for sid in ['m2s3','m2s4']:
        pg.evaluate("(()=>{const s=TEST.sim('%s'); s.extra.oNat.click(); s.extra.oEq.click(); s.extra.oNat.click();})()"%sid)
        res[sid+'_org']=pg.evaluate("(()=>{const s=TEST.sim('%s'); const a=s.org; s.toDefaults(); return [a, s.org]})()"%sid)
    sc={}
    for w in [320,360,390,768,1024,1440]:
        pg.set_viewport_size({'width':w,'height':860}); pg.wait_for_timeout(250)
        for sid in ids: pg.evaluate("(()=>{const s=TEST.sim('%s'); s.det.open=true;})()"%sid)
        pg.wait_for_timeout(150)
        sc[w]=pg.evaluate("document.documentElement.scrollWidth - innerWidth")
    res['hscroll']=sc
    res['errors']=errs; res['external']=reqs
    print(json.dumps(res,ensure_ascii=False))
    b.close()
