# モード④の問題・解答を PDF にする（physics-site/PDF に置く。2026-10-18 千葉さん）
import json, os
from playwright.sync_api import sync_playwright
url='file:///home/claude/shm/dist/simple-harmonic-motion.html#mode4'
OUT='/home/claude/shm/out/PDF/'
CSS = """
@page { size: A4; margin: 14mm 14mm 16mm; }
html,body{background:#fff !important}
body{margin:0;font-family:"Noto Sans JP","Noto Sans CJK JP",sans-serif;color:#14171c;font-size:10.5pt;line-height:1.85}
.exbody{padding:0 !important;overflow:visible !important}
.exstrip figure, .exqa, .exfig{break-inside:avoid}
img.fig{display:block;margin:0 auto;max-width:100%}
.pfoot{margin-top:14px;font-size:8.5pt;color:#69717d;text-align:right}
"""
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':900,'height':1200}, device_scale_factor=2)
    pg.goto(url); pg.wait_for_timeout(1500)
    items=pg.evaluate("MODES.find(m=>m.id==='mode4').secs.filter(s=>DEFS[s].exam).map(s=>[s, DEFS[s].exam.pdf, !!DEFS[s].exam.noProb])")
    styles=pg.evaluate("[...document.querySelectorAll('style')].map(s=>s.textContent).join('\\n')")
    made=[]
    for sid, slug, noProb in items:
        for kind in (['ans'] if noProb else ['prob','ans']):
            pg.evaluate(f"examOpen('{sid}','{kind}')"); pg.wait_for_timeout(900)
            html=pg.evaluate("""(()=>{const b=document.querySelector('#examov .exbody').cloneNode(true); const src=document.querySelectorAll('#examov .exbody canvas');
              b.querySelectorAll('canvas').forEach((c,i)=>{const im=document.createElement('img'); im.className='fig'; im.src=src[i].toDataURL('image/png'); im.style.width=src[i].getBoundingClientRect().width+'px'; c.replaceWith(im);}); return b.outerHTML;})()""")
            pg.keyboard.press('Escape')
            doc='<!doctype html><html lang="ja"><head><meta charset="utf-8"><style>'+styles+'</style><style>'+CSS+'</style></head><body>'+html+'<p class="pfoot">楽楽（らくらく）高校物理「単振動」 simple-harmonic-motion.html</p></body></html>'
            pp=b.new_page(); pp.set_content(doc, wait_until='load'); pp.wait_for_timeout(400)
            fn=OUT+slug+('-problem' if kind=='prob' else '-answer')+'.pdf'
            pp.pdf(path=fn, format='A4', print_background=True, margin={'top':'14mm','bottom':'16mm','left':'14mm','right':'14mm'}); pp.close()
            made.append((os.path.basename(fn), os.path.getsize(fn)))
    print(json.dumps(made, ensure_ascii=False))
