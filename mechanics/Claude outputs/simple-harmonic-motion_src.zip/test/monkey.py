# 生徒がしそうな操作をひととおり試す：全部のボタン・スライダーの±・再生・コマ送り・リセット・最初の設定に戻す。エラーと描画時間を調べる
import json, random
from playwright.sync_api import sync_playwright
url='file:///home/claude/shm/dist/simple-harmonic-motion.html#'
random.seed(1)
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1440,'height':900})
    errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)[:200])); pg.on('console', lambda m: m.type=='error' and errs.append(m.text[:200]))
    pg.goto(url+'mode1'); pg.wait_for_timeout(1000)
    res={}
    for m in ['mode1','mode2','mode3','mode4']:
        pg.evaluate(f"activateMode('{m}')"); pg.wait_for_timeout(800)
        ids=pg.evaluate(f"MODES.find(x=>x.id==='{m}').secs")
        for sid in ids:
            r=pg.evaluate("""(sid)=>{const s=TEST.sim(sid); if(!s||!s.L) return 'nosim';
              const art=document.getElementById(sid); const btns=[...art.querySelectorAll('button')].filter(b=>!b.closest('.exbtns'));
              let n=0; const t0=performance.now();
              for(const b of btns){ try{ b.click(); n++; if(s.playing){ for(let i=0;i<20;i++){ s.t=Math.min(s.tEnd(), s.t+0.05); s.draw(); } } b.click(); }catch(e){ return 'ERR '+b.textContent+' '+e; } }
              for(const k in s.sl){ const sl=s.sl[k]; for(let i=0;i<4;i++){ if(sl.up) sl.up.click(); } for(let i=0;i<6;i++){ if(sl.dn) sl.dn.click(); } }
              for(let t=0;t<s.tEnd();t+=s.tEnd()/40){ s.setT(t); }
              if(s.bStep) for(let i=0;i<20;i++) s.bStep.click();
              s.toDefaults && s.toDefaults(); s.resetT && s.resetT();
              const t1=performance.now(); for(let i=0;i<30;i++){ s.setT(s.tEnd()*i/30); } const dt=(performance.now()-t1)/30;
              if(s.playing) s.togglePlay();
              return {buttons:n, msPerFrame:+dt.toFixed(2), total:+(t1-t0).toFixed(0)};}""", sid)
            res[sid]=r
    pg.wait_for_timeout(500)
    print(json.dumps(res, ensure_ascii=False)); print('errs', errs[:10])
