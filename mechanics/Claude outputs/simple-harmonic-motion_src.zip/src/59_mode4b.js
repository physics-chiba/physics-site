/* =========================================================================
   59_mode4b.js … モード④ ④-2〜④-5（2026-10-18 千葉さん）
   ④-2 ばねでつながれた 2 球（3 つの視点）／④-3 ベルトコンベア（滑るだけ）／
   ④-4 ベルトコンベア（滑ったりくっついたり。観測者 A・B）／④-5 ゴムひも
   形は ④-1 と同じ：見出しの右に問題・解答のボタン、右の列にグラフ。
   ========================================================================= */
'use strict';
/* 右の列の x–t（v–t）グラフ。o = { t0, t1, lo, hi, cur, ylab, yunit, ser: [{ col, w, dash, f(t) → 値 or null, seg(t) → 色 }], hl: [{ y, txt, col }], H } */
function m4Plot(cv, o) {
  if (!cv || !cv.offsetParent) return;
  var W = Math.max(240, Math.floor(cv.clientWidth || 300)), H = o.H || 170, ctx = prep(cv, W, H);
  var x0 = 44, x1 = W - 18, y0 = H - 22, y1 = o.zones ? 46 : 14, X = function (t) { return x0 + (t - o.t0) / (o.t1 - o.t0) * (x1 - x0); }, Y = function (v) { return y0 - (v - o.lo) / (o.hi - o.lo) * (y0 - y1); };
  var yz = clamp(Y(0), y1, y0);
  axisArrow(ctx, x0, yz, x1 + 8, yz); axisArrow(ctx, x0, y0 + 2, x0, y1 - 8);
  sym(ctx, 't', x1 + 8, yz - 10, { size: 13 }); sym(ctx, o.ylab || 'x', x0 - 8, y1 - 2, { size: 13, align: 'right' });
  if (o.yunit) label(ctx, '〔' + o.yunit + '〕', x0 + 6, y1 - 2, { size: 9.5, align: 'left', color: '#69717d' });
  label(ctx, '0', x0 - 6, yz, { size: 10, align: 'right' });
  if (o.zones) m4Zones(ctx, o.zones, X, x0, x1, y1, y0);
  (o.hl || []).forEach(function (h) { var y = Y(h.y); dotted(ctx, x0, y, x1, y, h.col || 'rgba(192,57,43,.6)', [5, 3]); label(ctx, h.txt, x1, y - 8, { size: 10, color: h.col || '#c0392b', align: 'right', bold: true }); });
  var tc = clamp(o.cur, o.t0, o.t1);
  o.ser.forEach(function (sr) {
    var N = 300, prev = null, pc = null;
    ctx.save(); ctx.lineWidth = sr.w || 2.2; if (sr.dash) ctx.setLineDash(sr.dash);
    if (sr.dash && !sr.seg) {                                        /* 点線は 1 本の線として描く（短い線分ごとに描くと点線にならず、実線に見えていた。2026-10-25） */
      ctx.strokeStyle = sr.col; ctx.beginPath(); var on = false;
      for (var k = 0; k <= N; k++) { var tk = o.t0 + (tc - o.t0) * k / N, vk = sr.f(tk); if (vk === null || vk === undefined) { on = false; continue; } var px = X(tk), py = Y(clamp(vk, o.lo - (o.hi - o.lo) * 0.05, o.hi + (o.hi - o.lo) * 0.05)); if (on) ctx.lineTo(px, py); else ctx.moveTo(px, py); on = true; }
      ctx.stroke(); ctx.restore(); return;
    }
    for (var i = 0; i <= N; i++) {
      var t = o.t0 + (tc - o.t0) * i / N, v = sr.f(t), c = sr.seg ? sr.seg(t) : sr.col;
      if (v === null || v === undefined) { prev = null; continue; }
      var p = [X(t), Y(clamp(v, o.lo - (o.hi - o.lo) * 0.05, o.hi + (o.hi - o.lo) * 0.05))];
      if (prev) { ctx.strokeStyle = c; ctx.beginPath(); ctx.moveTo(prev[0], prev[1]); ctx.lineTo(p[0], p[1]); ctx.stroke(); }
      prev = p; pc = c;
    }
    ctx.restore();
    if (prev && !sr.dash) { ctx.save(); ctx.fillStyle = pc; ctx.beginPath(); ctx.arc(prev[0], prev[1], 3.6, 0, TAU); ctx.fill(); ctx.restore(); }
  });
  dotted(ctx, X(tc), y1, X(tc), y0, 'rgba(20,23,28,.35)', [4, 4]);
  if (o.legend) { var lx = x0 + 6; o.legend.forEach(function (lg) { ctx.save(); ctx.strokeStyle = lg.col; ctx.lineWidth = 2.4; if (lg.dash) ctx.setLineDash(lg.dash); ctx.beginPath(); ctx.moveTo(lx, H - 6); ctx.lineTo(lx + 14, H - 6); ctx.stroke(); ctx.restore(); var b = label(ctx, lg.txt, lx + 18, H - 6, { size: 10, align: 'left', color: '#3a414c' }); lx += 26 + b.w; }); }
}
/* グラフの上のはしに、区間ごとの運動の名前（両矢印＋横書き）。運動が切りかわる時刻に縦の線（2026-10-25 千葉さん）。
   zones：[{ t0, t1, txt, col }]。区間が字より狭いときは 2 行に分ける（txt2 があればそれを使う） */
function m4Zones(ctx, zones, X, x0, x1, y1, y0) {
  var ya = y1 - 9;
  zones.forEach(function (z, i) {
    var a = clamp(X(z.t0), x0, x1), b = clamp(X(z.t1), x0, x1), col = z.col || '#3a414c'; if (b - a < 6) return;
    if (i > 0) { ctx.save(); ctx.strokeStyle = 'rgba(20,23,28,.45)'; ctx.lineWidth = 1.1; ctx.beginPath(); ctx.moveTo(a, ya - 30); ctx.lineTo(a, y0); ctx.stroke(); ctx.restore(); }
    var h = Math.min(6, (b - a) / 4);
    ctx.save(); ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.moveTo(a + 2, ya); ctx.lineTo(b - 2, ya); ctx.stroke();
    [[a + 2, 1], [b - 2, -1]].forEach(function (p) { ctx.beginPath(); ctx.moveTo(p[0], ya); ctx.lineTo(p[0] + p[1] * h, ya - 3.2); ctx.lineTo(p[0] + p[1] * h, ya + 3.2); ctx.closePath(); ctx.fill(); });
    ctx.font = '700 10px ' + FONT; var one = ctx.measureText(z.txt).width <= b - a - 4; ctx.restore();
    var lines = one ? [z.txt] : (z.txt2 || [z.txt.slice(0, Math.ceil(z.txt.length / 2)), z.txt.slice(Math.ceil(z.txt.length / 2))]);
    lines.forEach(function (t, j) { label(ctx, t, (a + b) / 2, ya - 8 - (lines.length - 1 - j) * 12, { size: 10, bold: true, color: col }); });
  });
}
/* スタート前に、これから動く向きに動かないように押さえている手（dir：手が押す向き。指先が (x, y)）。スタートしたら消す */
function m4Hand(ctx, x, y, dx, dy, sc, flip) { ctx.save(); ctx.translate(x, y); ctx.rotate(Math.atan2(dy, dx) - Math.PI / 2); if (flip) ctx.scale(-1, 1); dropHand(ctx, 0, 12 * (sc || 0.4), sc || 0.4, 1, 1); ctx.restore(); }   /* flip：左右を反転した手 */
function m4Held(s) { return s.t === 0 && !s.playing; }
function m4Card(s, html) { var c = el('div', 'qcard m4card'); c.innerHTML = mathify(html); s.R.appendChild(c); return c; }
/* 図の左上のボタンを「どれか 1 つ」にそろえる */
function m4Seg(s, keys, k) { keys.forEach(function (p) { var b = s.extra[p[1]]; if (b) { b.classList.toggle('on', k === p[0]); b.setAttribute('aria-pressed', k === p[0] ? 'true' : 'false'); } }); }
/* 水平な床の目印（視点が動くとき、床が動いて見えるように）。off：床のずれ［px］ */
function m4FloorMarks(ctx, xa, xb, y, off, step) {
  step = step || 60; ctx.save(); ctx.strokeStyle = '#c9a86a'; ctx.lineWidth = 2.2; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.rect(xa, y + 1, xb - xa, 14); ctx.clip();
  var o = ((off % step) + step) % step;
  for (var x = xa - step + o; x < xb + step; x += step) { ctx.beginPath(); ctx.moveTo(x, y + 3); ctx.lineTo(x - 6, y + 12); ctx.stroke(); }
  ctx.restore();
}

/* ===================== ④-2 ばねでつながれた 2 球 =====================
   なめらかな床の上で、質量 m₁（左 A）・m₂（右 B）をばね（k、自然の長さ L）でつなぎ、ばねを a だけ伸ばして放す。B に初速度 v₀（右向き）を与えることもできる。
   u ＝ ばねの伸び：u = a cos ωt + (u̇₀/ω) sin ωt、ω = √(k/μ)、μ = m₁m₂/(m₁+m₂)。重心は Vc で等速。
   視点：外（慣性系）／A の上の観測者（非慣性系：B に慣性力 −m₂a₁）／重心とともに動く観測者（慣性系） */
var M42 = { k: 20, L: 1.3, a: 0.5, ms: [0.5, 1.0, 2.0], v0s: [0, 0.6], r: 0.13 };
/* 放し方（2026-10-18 千葉さん）：'sim'＝A と B を同時に放す／'seq'＝A を放し、A がつりあいの位置（ばねが自然の長さ）に来たときに B を放す */
function m4s2Q(s) {
  var m1 = s.v.m1, m2 = s.v.m2, k = M42.k, M = m1 + m2, mu = m1 * m2 / M, w = Math.sqrt(k / mu), seq = s.rel === 'seq', w1 = Math.sqrt(k / m1);
  var q = { m1: m1, m2: m2, k: k, mu: mu, w: w, T: TAU / w, a: M42.a, L: M42.L, seq: seq, w1: w1, tH: seq ? Math.PI / 2 / w1 : 0 };
  if (seq) { q.X2 = -1.0 + (q.L + q.a) * m1 / M; q.vH = q.a * w1; q.Vc = m1 * q.vH / M; q.XcH = q.X2 - q.L * m1 / M; }
  else { q.Vc = 0; q.XcH = 0; }
  return q;
}
function m4s2At(q, t) {
  var M = q.m1 + q.m2;
  if (q.seq && t < q.tH) {                                       /* B は手で押さえている。A だけが単振動（ω₁ = √(k/m₁)） */
    var u0 = q.a * Math.cos(q.w1 * t), x1h = q.X2 - (q.L + u0), v1h = q.a * q.w1 * Math.sin(q.w1 * t);
    return { u: u0, Xc: (q.m1 * x1h + q.m2 * q.X2) / M, vc: q.m1 * v1h / M, ac: q.k * u0 / M, x1: x1h, x2: q.X2, v1: v1h, v2: 0, a1: q.k * u0 / q.m1, a2: 0, hold: true };
  }
  var tau = t - q.tH, u, du;
  if (q.seq) { u = -q.vH / q.w * Math.sin(q.w * tau); du = -q.vH * Math.cos(q.w * tau); }
  else { u = q.a * Math.cos(q.w * tau); du = -q.a * q.w * Math.sin(q.w * tau); }
  var Xc = q.XcH + q.Vc * tau, len = q.L + u;
  return { u: u, du: du, Xc: Xc, vc: q.Vc, ac: 0, x1: Xc - q.m2 / M * len, x2: Xc + q.m1 / M * len, v1: q.Vc - q.m2 / M * du, v2: q.Vc + q.m1 / M * du, a1: q.k * u / q.m1, a2: -q.k * u / q.m2, hold: false };
}
DEFS.m4s2 = {
  id: 'm4s2', mode: 'mode4', num: 3, title: 'ばねでつながれた 2 球（入試頻出）', short: 'ばねでつながれた 2 球',
  desc: 'なめらかな水平面の上で、小球 A（質量 $m_1$）と小球 B（質量 $m_2$）を、ばね定数 $k$ の軽いばねでつなぐ。ばねを自然の長さから $a$ だけ伸ばして、手で押さえてから放す。<span class="todo">図の左上で放し方と視点を切りかえて、どの視点でも「周期」が同じことを確かめよう。「A を放してから…B を放す」では、B を放したあと重心が等速で動き、外から見た運動は「重心の等速運動 ＋ 単振動」になる。</span>',
  strobe: false, showFBtn: true, fDefault: 'all', vecBtn: 'v を消す', belowCanvas: true, baseRate: 0.5,
  exam: { src: '入試頻出問題（数値・言いまわしを変えて作り直したもの）', pdf: 'shm-two-balls', prob: function () { return m4s2Prob(); }, ans: function () { return m4s2Ans(); }, fig: function (k, ctx, W, H) { m4s2Fig(k, ctx, W, H); } },
  buttons: [
    { k: 'rSim', label: 'A と B を同時に放す', cls: 'm4rel on', inCanvas: true, onClick: function (s) { m4s2Rel(s, 'sim'); } },
    { k: 'rSeq', label: 'A を放してから、しばらくして、A がつりあいの位置に来たときに B を放す', cls: 'm4rel', inCanvas: true, onClick: function (s) { m4s2Rel(s, 'seq'); } },
    { k: 'vOut', label: '外（慣性系）から見る', cls: 'm4only on', inCanvas: true, onClick: function (s) { m4s2View(s, 'out'); } },
    { k: 'vA', label: '小球 A の上の観測者（非慣性系）から見る', cls: 'm4only', inCanvas: true, onClick: function (s) { m4s2View(s, 'A'); } },
    { k: 'vG', label: '重心とともに動く観測者（慣性系）から見る', cls: 'm4only', inCanvas: true, onClick: function (s) { m4s2View(s, 'G'); } }
  ],
  vars: [
    { k: 'm1', label: 'A の質量 $m_1$', stops: M42.ms, stopLabels: ['0.5', '1.0', '2.0 kg'], def: 1.0, aria: 'A の質量', fmt: function (x) { return x.toFixed(1) + ' kg'; } },
    { k: 'm2', label: 'B の質量 $m_2$', stops: M42.ms, stopLabels: ['0.5', '1.0', '2.0 kg'], def: 1.0, aria: 'B の質量', fmt: function (x) { return x.toFixed(1) + ' kg'; } },
  ],
  varCols: [['m1'], ['m2']],
  init: function (s) { s.view = 'out'; s.rel = 'sim'; },
  onDefaults: function (s) { m4s2View(s, 'out'); m4s2Rel(s, 'sim'); },
  onChanged: function () { return 'stop'; },
  tEnd: function (s) { var q = m4s2Q(s); return q.seq ? q.tH + 1.6 * q.T : 3 * q.T; },
  tInfo: function (s) { return periodInfo(m4s2Q(s).T); },
  gT: function (s) { return m4s2Q(s).T; },
  height: function (s, w) { return w < 560 ? 400 : Math.round(clamp(w * 0.50, 270, 360)); },   /* せまい画面ではボタンが 3 段になるので高く */
  afterBuild: function (s) {
    s.R.innerHTML = '';
    var cb = s.cv.parentNode.querySelector('.cvbtns'), rr = el('div', 'm4relrow'); [s.extra.rSim, s.extra.rSeq].forEach(function (b) { rr.appendChild(b); }); cb.insertBefore(rr, cb.firstChild);   /* 放し方のボタンは、視点のボタンの上に */
    s.xT = m4Card(s, '<p class="qt"></p>').firstChild; s.xCv = el('canvas', 'm4cv'); s.R.lastChild.appendChild(s.xCv);
    s.vT = m4Card(s, '<p class="qt"></p>').firstChild; s.vCv = el('canvas', 'm4cv'); s.R.lastChild.appendChild(s.vCv);
    m4s2Titles(s);
    s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);
  },
  draw: function (s, ctx, W, H) { drawM4S2(s, ctx, W, H); drawM4S2X(s); },
  msg: function (s) {
    var q = m4s2Q(s);
    if (q.seq && s.t < q.tH) return 'B を手で押さえたまま A だけを放した。A は B を壁とした水平ばね振り子（$\\omega_1 = \\sqrt{\\dfrac{k}{m_1}}$）。A がつりあいの位置（ばねが自然の長さ）に来たら B を放す。';
    return { out: '外から見ると、重心は' + (q.seq ? '一定の速さ $V = \\dfrac{m_1v}{m_1 + m_2}$（$v$：B を放したときの A の速さ）で動き' : '動かず') + '、2 球は重心に対して逆向きに振動する。',
      A: 'A の上の観測者から見ると、A は止まって見え、B は A の周りで単振動する。B には慣性力 $-m_2a_1$（破線）がはたらく。',
      G: '重心とともに動く観測者から見ると、重心は止まり、A と B はそれぞれ重心をはさんで逆向きに単振動する。' }[s.view];
  },
  right: function (s, R) { m4s2Right(s, R); }
};
function m4s2Rel(s, k) { s.rel = k; m4Seg(s, [['sim', 'rSim'], ['seq', 'rSeq']], k); if (s.cv) { s.resetT(); s.draw(); s.renderRight(); } }
function m4s2View(s, k) { s.view = k; m4Seg(s, [['out', 'vOut'], ['A', 'vA'], ['G', 'vG']], k); m4s2Titles(s); if (s.cv) { s.draw(); s.renderRight(); } }
/* グラフの題は視点ごとに「外（慣性系）から見た x–t グラフ」のように（2026-10-18 千葉さん） */
function m4s2Titles(s) {
  if (!s.xT) return; var who = { out: '外（慣性系）', A: '小球 A の上の観測者（非慣性系）', G: '重心とともに動く観測者（慣性系）' }[s.view || 'out'];
  s.xT.innerHTML = mathify(who + 'から見た $x$–$t$ グラフ'); s.vT.innerHTML = mathify(who + 'から見た $v$–$t$ グラフ');
}
function m4s2Frame(s, q, st) { var s0 = m4s2At(q, 0); return s.view === 'A' ? { x: st.x1 - s0.x1, v: st.v1, a: st.a1 } : (s.view === 'G' ? { x: st.Xc - s0.Xc, v: st.vc, a: st.ac } : { x: 0, v: 0, a: 0 }); }
function drawM4S2(s, ctx, W, H) {
  var q = m4s2Q(s), st = m4s2At(q, s.t), fr = m4s2Frame(s, q, st), S = W / 4.4, cx = W * 0.47, yF = H * 0.70, X = function (x) { return cx + (x - fr.x) * S; };
  var rA = M42.r * S * Math.cbrt(q.m1), rB = M42.r * S * Math.cbrt(q.m2);
  ctx.save(); ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(14, yF); ctx.lineTo(W - 14, yF); ctx.stroke(); ctx.restore();
  m4FloorMarks(ctx, 14, W - 14, yF, -fr.x * S, 70);
  label(ctx, 'なめらかで水平な床', 18, yF + 26, { size: 10.5, color: '#8d9097', align: 'left' });
  var x1 = X(st.x1), x2 = X(st.x2), xg = X(st.Xc), yA = yF - rA, yB = yF - rB, yS = yF - Math.min(rA, rB);
  springDense(ctx, x1 + rA, yS, x2 - rB, yS, q.L * S - rA - rB, { r: 8, lead: 6, k: q.k, Lmin: (q.L - q.a) * S - rA - rB });
  ballShape(ctx, x1, yA, rA, '#9cc3e8'); ballShape(ctx, x2, yB, rB, '#f2c48d');
  label(ctx, 'A', x1, yA, { size: 12, bold: true }); label(ctx, 'B', x2, yB, { size: 12, bold: true });
  /* 重心 */
  dotted(ctx, xg, yF - 4, xg, yF + 40, 'rgba(192,57,43,.6)', [3, 3]); ctx.save(); ctx.fillStyle = '#c0392b'; ctx.beginPath(); ctx.arc(xg, yS, 4, 0, TAU); ctx.fill(); ctx.restore();
  label(ctx, s.view === 'G' ? '重心（止まって見える）' : (q.seq ? (st.hold ? '重心（B を押さえている間は加速）' : '重心（等速で動く）') : '重心（動かない）'), xg, yF + 46, { size: 10.5, color: '#c0392b', bold: true });
  /* 観測者（棒人間）：A の上・重心の下・床の外 */
  observer(ctx, x1, yA - rA - 2, 0, -1, '', s.view === 'A', 26);
  observer(ctx, xg, H - 8, 0, -1, '', s.view === 'G', 22);
  observer(ctx, W - 40, yF, 0, -1, '', s.view === 'out', 26);
  /* 速度と加速度（その視点から見たもの。小球の上に離して：速度、その上に加速度）。外から見るときは v₁・a₁、
     A の上・重心の観測者から見るときは相対速度・相対加速度を v_{A→B} のように書く（inertia-force.html ②-3 と同じ書き方。2026-10-18 千葉さん） */
  var vref = q.seq ? q.vH : q.a * q.w * Math.max(q.m1, q.m2) / (q.m1 + q.m2), aref = q.k * q.a / Math.min(q.m1, q.m2);
  if (!s.hideVec) {
    var ob = { out: null, A: 'A', G: 'G' }[s.view];
    [[x1, yA - rA, st.v1 - fr.v, st.a1 - fr.a, 'A', '1'], [x2, yB - rB, st.v2 - fr.v, st.a2 - fr.a, 'B', '2']].forEach(function (b) {
      if (s.view === 'A' && b[4] === 'A') return;                  /* A の上の観測者から見ると A は止まっている */
      var sub = ob ? ob + '→' + b[4] : b[5], yv = b[1] - 40, ya = b[1] - 78;
      if (Math.abs(b[2]) > 0.02) { var L = b[2] / vref * 46; vArrowAt(ctx, b[0], b[1], 0, -1, 40, 1, 0, L, false); sym(ctx, 'v', b[0] + Math.abs(L) / 2 + 10, yv - 2, { size: 13.5, color: COL.vel, sub: sub, align: 'left' }); }
      if (Math.abs(b[3]) > 0.05) { var La = b[3] / aref * 40; arrow(ctx, b[0] - La / 2, ya, b[0] + La / 2, ya, 'acc'); sym(ctx, 'a', b[0] + Math.abs(La) / 2 + 10, ya - 2, { size: 13.5, color: COL.acc, sub: sub, align: 'left' }); }
    });
  }
  /* 力：ばねの弾性力（接点から）。A の上の観測者なら、慣性力 −m·a₁（破線）も */
  if (s.fmode) {
    var fs = 46 / (q.k * q.a), F = q.k * st.u, net = fNet(s);
    if (s.view !== 'A' || !net) { fArrow(ctx, x1 + rA, yS, 1, 0, F * fs, COL.hand, net ? null : 'ku', { ly: -14, noShift: true }); }
    fArrow(ctx, x2 - rB, yS, 1, 0, -F * fs, COL.hand, net && s.view !== 'A' ? 'F' : 'ku', { ly: -14, noShift: true });
    if (s.view === 'A') {
      arrow(ctx, x2, yB + rB * 0.45, x2 - q.m2 * st.a1 * fs, yB + rB * 0.45, 'fict', COL.inert || '#3f4a54', { noShift: true });
      if (Math.abs(st.a1) > 0.05) sym(ctx, '−m₂a₁', x2 - q.m2 * st.a1 * fs + (st.a1 > 0 ? -8 : 8), yB + rB * 0.45 + 14, { size: 12.5, color: COL.inert || '#3f4a54', align: st.a1 > 0 ? 'right' : 'left' });
      arrow(ctx, x1, yA + rA * 0.45, x1 - q.m1 * st.a1 * fs, yA + rA * 0.45, 'fict', COL.inert || '#3f4a54', { noShift: true });
    }
  }
  if (!m4Held(s) && st.hold) m4Hand(ctx, x2, yB - rB, 0, 1, 0.36, true);   /* B を押さえている間（B の手は左右反転） */
  if (m4Held(s)) {                                               /* 2 つの手で、縮まないように押さえている（スタートで消える） */
    m4Hand(ctx, x1, yA - rA, 0, 1, 0.36); m4Hand(ctx, x2, yB - rB, 0, 1, 0.36, true);
    bubble(ctx, '自然の長さから a 伸ばして押さえる → 放す', (x1 + x2) / 2, yS + 40, { size: 12, bg: '#fff5e8', border: '#e07b18', color: '#a85c0c', side: 'up' });
  }
  drawEqualTicks(ctx);
}
function drawM4S2X(s) {
  var q = m4s2Q(s), fr0 = function (t) { return m4s2Frame(s, q, m4s2At(q, t)).x; }, span = q.seq ? 2.4 : 1.6;
  m4Plot(s.xCv, { t0: 0, t1: q.seq ? q.tH + 1.6 * q.T : 3 * q.T, lo: -span, hi: span, cur: s.t, ylab: 'x', yunit: 'm', H: 190,
    ser: [{ col: '#3f7fc1', f: function (t) { return m4s2At(q, t).x1 - fr0(t); } }, { col: '#d0801f', f: function (t) { return m4s2At(q, t).x2 - fr0(t); } }, { col: '#c0392b', dash: [5, 4], w: 1.6, f: function (t) { return m4s2At(q, t).Xc - fr0(t); } }],
    legend: [{ col: '#3f7fc1', txt: 'A' }, { col: '#d0801f', txt: 'B' }, { col: '#c0392b', dash: [5, 4], txt: '重心' }] });
  var fv = function (t) { return m4s2Frame(s, q, m4s2At(q, t)).v; }, vr = (q.seq ? q.vH : q.a * q.w) * 1.15;
  m4Plot(s.vCv, { t0: 0, t1: q.seq ? q.tH + 1.6 * q.T : 3 * q.T, lo: -vr, hi: vr, cur: s.t, ylab: 'v', yunit: 'm/s', H: 170,
    ser: [{ col: '#3f7fc1', f: function (t) { return m4s2At(q, t).v1 - fv(t); } }, { col: '#d0801f', f: function (t) { return m4s2At(q, t).v2 - fv(t); } }, { col: '#c0392b', dash: [5, 4], w: 1.6, f: function (t) { return m4s2At(q, t).vc - fv(t); } }],
    legend: [{ col: '#3f7fc1', txt: 'A' }, { col: '#d0801f', txt: 'B' }, { col: '#c0392b', dash: [5, 4], txt: '重心' }] });
}
function m4s2Right(s, R) {
  var q = m4s2Q(s), h, seqTxt = q.seq ? '<p class="qnote">「A を放してから…」のとき：B を押さえている間は、A だけが B を壁とした単振動（$\\omega_1 = \\sqrt{\\dfrac{k}{m_1}}$）。B を放した瞬間、ばねは自然の長さで、A の速さは $v = a\\omega_1$、B は静止。ここから下の説明があてはまる（重心の速さは $V = \\dfrac{m_1v}{m_1 + m_2}$）。</p>' : '';
  if (s.view === 'out') h = '<p class="qt">外（慣性系）から見る</p><p class="eqline">' + eqTag('eom') + 'A：$m_1a_1 = ku$　B：$m_2a_2 = -ku$</p>' +
    '<p>（$u$：ばねの伸び）。外力がないので運動量の和は一定で、<b>重心は' + (q.seq ? '一定の速度 $V$ で右へ動く' : '動かない') + '</b>。</p>' +
    '<p><b>動き</b>：A と B は、重心をはさんで<b>いつも逆向きに</b>動く。ばねが伸びているときは引き合って近づき、縮んでいるときは押し合って離れる。' + (q.seq ? '外から見ると、A・B の運動は「重心の等速運動 ＋ 単振動」で、波打ちながら右へ進む（$x$–$t$ グラフ）。' : '重心は止まっているので、A・B はそれぞれ定まった位置を中心に往復する。') + '</p>' +
    '<p><b>速度</b>：運動量保存より $m_1v_1 + m_2v_2 = ' + (q.seq ? '(m_1 + m_2)V' : '0') + '$。ばねが自然の長さのとき、A・B の速さ（重心から見た速さ）は最大。ばねが最も伸びた・縮んだとき、A・B の速度は' + (q.seq ? 'どちらも $V$（重心から見ると 0）' : 'どちらも 0') + '。</p>';
  else if (s.view === 'A') h = '<p class="qt">小球 A の上の観測者（非慣性系）から見る</p>' +
    '<p>A は加速度 $a_1 = \\dfrac{ku}{m_1}$ で動くので、A の上の観測者から見ると、B には慣性力 $-m_2a_1$ がはたらく。B の相対加速度を $a_{\\mathrm{A}\\to\\mathrm{B}} = a_2 - a_1$ とすると</p>' +
    '<p class="eqline">' + eqTag('eom') + '$m_2a_{\\mathrm{A}\\to\\mathrm{B}} = -ku - m_2a_1 = -k\\left(1 + \\dfrac{m_2}{m_1}\\right)u$</p>' +
    '<p><b>動き</b>：この観測者には <b>A は止まって見え</b>、床は A と逆向きに動いて見える。B は、A から距離 $L$（ばねが自然の長さ）の位置を中心に、<b>A に近づいたり離れたりする単振動</b>をする。振幅はばねの伸び縮みと同じ $a$（「A を放してから…」のときは $\\dfrac{v}{\\omega}$）。</p>' +
    '<p><b>速度</b>：B の相対速度 $v_{\\mathrm{A}\\to\\mathrm{B}} = v_2 - v_1$ は、ばねの長さが変わる速さそのもの。ばねが自然の長さのとき最大、最も伸びた・縮んだときに 0。重心は A に対して前後に動いて見える。</p>';
  else h = '<p class="qt">重心とともに動く観測者（慣性系）から見る</p>' +
    '<p>重心は等速（または静止）なので、この観測者は慣性系。慣性力は考えなくてよい。A・B の重心からの相対速度を $v_{\\mathrm{G}\\to\\mathrm{A}}$、$v_{\\mathrm{G}\\to\\mathrm{B}}$ とすると、運動量の和は 0：$m_1v_{\\mathrm{G}\\to\\mathrm{A}} + m_2v_{\\mathrm{G}\\to\\mathrm{B}} = 0$。</p>' +
    '<p><b>動き</b>：<b>重心は止まって見え</b>、A と B は重心をはさんで<b>左右対称に（質量に反比例した振幅で）逆向きに単振動</b>する。A の振幅はばねの伸び縮みの $\\dfrac{m_2}{m_1 + m_2}$ 倍、B は $\\dfrac{m_1}{m_1 + m_2}$ 倍（重い方が小さく動く）。</p>' +
    '<p><b>速度</b>：$v_{\\mathrm{G}\\to\\mathrm{A}}$ と $v_{\\mathrm{G}\\to\\mathrm{B}}$ はいつも逆向きで、大きさの比は $m_2 : m_1$。ばねが自然の長さのとき最大、最も伸びた・縮んだときに 0。相対加速度も同じ比で逆向き。</p>';
  h += seqTxt + '<div class="qeq">$$\\omega = \\sqrt{\\frac{k}{\\mu}},\\quad \\mu = \\frac{m_1m_2}{m_1 + m_2},\\quad T = 2\\pi\\sqrt{\\frac{m_1m_2}{k(m_1 + m_2)}}$$</div>' +
    '<p class="qnow"><span class="qtag now">いまの値</span>$k = ' + q.k + '$ N/m、$\\mu = ' + fmt(q.mu, 3) + '$ kg、$T = ' + sig2(q.T) + '$ s（どの視点でも同じ）</p>';
  R.innerHTML = mathify('<div class="qcard">' + h + '</div>');
}
function m4s2Prob() {
  return '<h4 class="exh">問題の設定</h4><div class="exbox"><p>なめらかな水平面の上に、質量 $m_1$ の小球 A と質量 $m_2$ の小球 B を置き、ばね定数 $k$、自然の長さ $L$ の軽いばねでつなぐ。ばねを自然の長さから $a$ だけ伸ばした状態で、A・B を同時に静かに放した。右向きを正とする。</p></div>' +
    '<h4 class="exh">図</h4><div class="exfig"><canvas data-fig="setup" data-h="130"></canvas></div>' +
    '<h4 class="exh">問</h4><ol class="exol">' +
    '<li>放したあと、A・B の重心はどのように運動するか。理由とともに答えよ。</li>' +
    '<li>ばねの伸びが $u$ のとき、A と B の加速度 $a_1$、$a_2$ を求めよ。</li>' +
    '<li>A の上の観測者から見た B の加速度を $a\'$ とする。慣性力を使って、B の運動方程式を書け。</li>' +
    '<li>この振動の周期 $T$ を求めよ。</li>' +
    '<li>$m_1 = m_2 = m$ のとき、ばねが自然の長さになる瞬間の A の速さ $v$ を求めよ。</li>' +
    '<li>重心とともに動く観測者から見ると、A はどのような運動をするか。振動の中心と振幅を答えよ。</li></ol>';
}
function m4s2Ans() {
  return '<h4 class="exh">時間の流れで見る（$m_1 = m_2$、外から見る）</h4>' +
    exStrip([['a', 'ⓐ 放した直後', 'ばねは $a$ 伸び'], ['b', 'ⓑ 自然の長さ', '速さ最大'], ['c', 'ⓒ 最も縮む', '速さ 0'], ['d', 'ⓓ 自然の長さ', '逆向きに速さ最大'], ['e', 'ⓔ もとの長さ', '1 周期']], 90, true) +
    '<h4 class="exh">解答と解き方</h4>' +
    exQA('(1) 重心の運動', '静止したまま（動かない）', '<p>A・B が受ける水平方向の力は、ばねの弾性力（内力）だけ。外力の和が 0 なので運動量の和は一定で、はじめ 0 だから重心の速度は 0 のまま。</p>') +
    exQA('(2) 加速度', '$a_1 = \\dfrac{ku}{m_1}$、$a_2 = -\\dfrac{ku}{m_2}$', '<p>' + eqTag('eom') + 'A：$m_1a_1 = ku$（右向き）、B：$m_2a_2 = -ku$（左向き）。</p>') +
    exQA('(3) A の上の観測者から見た B', '$m_2a\' = -ku - m_2a_1 = -k\\left(1 + \\dfrac{m_2}{m_1}\\right)u$', '<p>A は加速度 $a_1$ で動くので、A の上の観測者から見ると B には慣性力 $-m_2a_1$ がはたらく。A から見た B の変位はばねの伸び $u$ と同じだけ変わるので、$a\'$ は $u$ の加速度。</p>') +
    exQA('(4) 周期', '$T = 2\\pi\\sqrt{\\dfrac{m_1m_2}{k(m_1 + m_2)}}$', '<p>(3) を $a\' = -\\dfrac{k(m_1 + m_2)}{m_1m_2}u$ と変形し、$a\' = -\\omega^2u$ と比べる。$\\mu = \\dfrac{m_1m_2}{m_1 + m_2}$（換算質量）とおくと $T = 2\\pi\\sqrt{\\dfrac{\\mu}{k}}$。どの視点で見ても周期は同じ。</p>') +
    exQA('(5) 自然の長さでの A の速さ', '$v = a\\sqrt{\\dfrac{k}{2m}}$', '<p>重心は動かないので A・B は同じ速さ $v$ で逆向き。力学的エネルギー保存：$\\dfrac{1}{2}ka^2 = \\dfrac{1}{2}mv^2 \\times 2$。</p>') +
    exQA('(6) 重心から見た A の運動', '重心から左へ $\\dfrac{m_2}{m_1 + m_2}L$ の位置を中心に、振幅 $\\dfrac{m_2}{m_1 + m_2}a$ の単振動', '<p>重心から A までの距離は、つねにばねの長さの $\\dfrac{m_2}{m_1 + m_2}$ 倍。ばねの長さは $L$ を中心に振幅 $a$ で振動するので、A の振動はその $\\dfrac{m_2}{m_1 + m_2}$ 倍。周期は (4) と同じ。</p>');
}
function m4s2Fig(key, ctx, W, H) {
  var q = m4s2Q({ v: { m1: 1, m2: 1, v0: 0 } }), S = W / 4.2, cx = W / 2, yF = H - 26, r = M42.r * S;
  var t = { setup: 0, a: 0, b: q.T / 4, c: q.T / 2, d: 3 * q.T / 4, e: q.T }[key], st = m4s2At(q, t), X = function (x) { return cx + x * S; };
  floorAt(ctx, 8, W - 8, yF);
  var x1 = X(st.x1), x2 = X(st.x2), yS = yF - r;
  springDense(ctx, x1 + r, yS, x2 - r, yS, q.L * S - 2 * r, { r: key === 'setup' ? 6 : 4, lead: 3, k: q.k, thin: 0.7, Lmin: (q.L - q.a) * S - 2 * r });
  ballShape(ctx, x1, yS, r, '#9cc3e8'); ballShape(ctx, x2, yS, r, '#f2c48d');
  label(ctx, 'A', x1, yS, { size: 10, bold: true }); label(ctx, 'B', x2, yS, { size: 10, bold: true });
  dotted(ctx, cx, yS - r - 6, cx, yF + 14, 'rgba(192,57,43,.6)', [3, 3]);
  if (key === 'setup') { label(ctx, 'm₁', x1, yS - r - 10, { size: 11 }); label(ctx, 'm₂', x2, yS - r - 10, { size: 11 }); label(ctx, '自然の長さ L から a 伸ばす', cx, 14, { size: 11, color: '#5d6875' }); return; }
  var vr = st.v2 / (q.a * q.w / 2);
  if (Math.abs(vr) > 0.05) { vArrowAt(ctx, x1, yS - r, 0, -1, 8, 1, 0, -vr * 22, false); vArrowAt(ctx, x2, yS - r, 0, -1, 8, 1, 0, vr * 22, false); }
  var F = q.k * st.u, fs = 22 / (q.k * q.a);
  if (Math.abs(F) > 0.05) { fArrow(ctx, x1 + r, yS + 4, 1, 0, F * fs, COL.hand, null, { noShift: true }); fArrow(ctx, x2 - r, yS + 4, 1, 0, -F * fs, COL.hand, null, { noShift: true }); }
  drawEqualTicks(ctx);
}

/* ===================== ④-3 ベルトコンベア（滑るだけ） =====================
   左の壁にばね（k）、ばねの先に小物体（m）。ベルトは右へ速さ V。小物体はいつもベルトに対して左へ滑るので、動摩擦力 μ′mg はいつも右向き。
   自然の長さの位置で、床に対して静止した状態から始める：x = x₀(1 − cos ωt)、x₀ = μ′mg/k。最大の速さ x₀ω < V ならこのとおり。 */
var M43 = { m: 0.5, k: 20, mu2: 0.4, Vs: [1.0, 2.0, 3.0], L: 0.9 };
function m4s3Q(s) { var w = Math.sqrt(M43.k / M43.m), x0 = M43.mu2 * M43.m * G / M43.k; return { m: M43.m, k: M43.k, mu2: M43.mu2, w: w, T: TAU / w, x0: x0, V: s.v.V, vmax: x0 * w }; }
function m4s3At(q, t) { return { x: q.x0 * (1 - Math.cos(q.w * t)), v: q.x0 * q.w * Math.sin(q.w * t) }; }
DEFS.m4s3 = {
  id: 'm4s3', mode: 'mode4', num: 4, title: 'ベルトコンベアの上の単振動（ベルトが速いため必ず滑る）', short: 'ベルトコンベア（必ず滑る）',
  desc: 'ばね（ばね定数 $k$）の先に、質量 $m$ の小物体をつける。小物体は、右へ一定の速さ $V$ で動くベルトの上にある（動摩擦係数 $\\mu\'$）。小物体が床に対して静止した状態、ばねが自然の長さの位置から運動を始めるとする。すると、小物体は置いた瞬間からベルトに対して左へ滑る。<span class="todo">ベルトの速さ $V$ を変えても、小物体の運動が変わらないことを確かめよう。</span>',
  strobe: false, showFBtn: true, fDefault: 'all', vecBtn: 'v を消す', belowCanvas: true, baseRate: 0.5,
  exam: { src: '典型問題（参考：physicmath.net の解説。数値・言いまわしを変えて作り直したもの）', pdf: 'shm-belt-slip', prob: function () { return m4s3Prob(); }, ans: function () { return m4s3Ans(); }, fig: function (k, ctx, W, H) { m4s3Fig(k, ctx, W, H); } },
  vars: [{ k: 'V', label: 'ベルトの速さ $V$', stops: M43.Vs, stopLabels: ['1.0', '2.0', '3.0 m/s'], def: 2.0, aria: 'ベルトの速さ', fmt: function (x) { return x.toFixed(1) + ' m/s'; } }],
  onChanged: function () { return 'keepT'; },
  tEnd: function (s) { return 3 * m4s3Q(s).T; },
  tInfo: function (s) { return periodInfo(m4s3Q(s).T); },
  gT: function (s) { return m4s3Q(s).T; },
  height: function (s, w) { return Math.round(clamp(w * 0.42, 230, 300)); },
  afterBuild: function (s) {
    s.R.innerHTML = '';
    m4Card(s, '<p class="qt">$x$–$t$ グラフ<span class="qtsub">（$x$：自然の長さからの伸び）</span></p>'); s.xCv = el('canvas', 'm4cv'); s.R.lastChild.appendChild(s.xCv);
    m4Card(s, '<p class="qt">$v$–$t$ グラフ<span class="qtsub">（床から見た速度）</span></p>'); s.vCv = el('canvas', 'm4cv'); s.R.lastChild.appendChild(s.vCv);
    s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);
  },
  draw: function (s, ctx, W, H) { var q = m4s3Q(s), st = m4s3At(q, s.t); drawBelt(s, ctx, W, H, { L: M43.L, k: q.k, x: st.x, v: st.v, V: q.V, vs: 40, slip: true, mu2: q.mu2, m: q.m, xs: [[0, '自然の長さ', '#5d6875'], [q.x0, '振動の中心 x₀', '#c0392b'], [2 * q.x0, '最も伸びた所 2x₀', '#5d6875']], S: 1.0 }); drawM4S3G(s); },
  msg: function (s) { var q = m4s3Q(s); return '小物体の速さはいつも $V$ より小さい（最大 $' + fmt(q.vmax, 2) + '$ m/s）ので、ベルトに対していつも左へ滑り、動摩擦力 $\\mu\'mg$ はいつも右向き。だから、振動の中心 $x_0 = \\dfrac{\\mu\'mg}{k}$ の単振動になる。'; },
  right: function (s, R) { var q = m4s3Q(s); R.innerHTML = mathify('<div class="qcard"><p class="eqline">' + eqTag('eom') + '$ma = -kx + \\mu\'mg = -k\\left(x - \\dfrac{\\mu\'mg}{k}\\right)$</p><p>振動の中心 $x_0 = \\dfrac{\\mu\'mg}{k}$、周期 $T = 2\\pi\\sqrt{\\dfrac{m}{k}}$。<b>$V$ は式に入らない</b>（動摩擦力は、滑る速さによらない）。</p><p class="qnow"><span class="qtag now">この図では</span>$m = ' + q.m + '$ kg、$k = ' + q.k + '$ N/m、$\\mu\' = ' + q.mu2 + '$：$x_0 = ' + fmt(q.x0, 3) + '$ m、最大の速さ $' + fmt(q.vmax, 2) + '$ m/s $< V$</p></div>'); }
};
/* ベルトコンベアの図（④-3・④-4 共通）。o = { L, k, x, v, V, slip, f（摩擦力。右向き正）, view, xs: [[x, 名前, 色]] } */
function drawBelt(s, ctx, W, H, o) {
  var S = (W - 140) / (o.L + 0.5), xw = 40, yB = H * 0.62, bw = 46, bh = 34, X = function (x) { return xw + (o.L + x) * S; };
  var Vview = o.view === 'B' ? o.V : 0;                         /* 観測者 B（ベルト）から見ると、ベルトは止まって見える */
  /* 壁 */
  wallLeftAt(ctx, xw, yB - 70, yB - 2); ctx.save(); ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(xw, yB - 70); ctx.lineTo(xw, yB); ctx.stroke(); ctx.restore();
  /* ベルト（上の面の目印が速さ V で流れる） */
  var bx0 = xw + 8, bx1 = W - 14, rr = 16;
  ctx.save(); ctx.fillStyle = '#e9edf1'; ctx.strokeStyle = '#59636e'; ctx.lineWidth = 1.6; rrect(ctx, bx0, yB, bx1 - bx0, 2 * rr, rr); ctx.fill(); ctx.stroke(); ctx.restore();
  [bx0 + rr, bx1 - rr].forEach(function (x) { ctx.save(); ctx.strokeStyle = '#59636e'; ctx.fillStyle = '#fff'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.arc(x, yB + rr, rr - 5, 0, TAU); ctx.fill(); ctx.stroke(); ctx.restore(); });
  var off = (o.V - Vview) * s.t * S * 0.35;                      /* 目印の動き（見やすいように実際の 0.35 倍） */
  m4FloorMarks(ctx, bx0 + rr, bx1 - rr, yB - 1, off, 34);
  var vs = o.vs || 40;                                           /* 速度の縮尺［px/(m/s)］。ベルトの速さ V の矢印と小物体の速度の矢印で同じ（2026-10-18 千葉さん） */
  if (o.view !== 'B') { arrow(ctx, W * 0.62, yB + 2 * rr + 16, W * 0.62 + o.V * vs, yB + 2 * rr + 16, 'vel'); label(ctx, 'ベルトの速さ V', W * 0.62 + o.V * vs + 8, yB + 2 * rr + 16, { size: 10.5, color: COL.vel, align: 'left' }); }
  else label(ctx, '観測者 B から見ると、ベルトは止まり、床と壁が左へ V で動いて見える', W / 2, yB + 2 * rr + 16, { size: 10.5, color: COL.vel });
  /* 位置の目印 */
  (o.xs || []).forEach(function (r, i) { var xx = X(r[0]), yl = yB - 70 - i * 15; dotted(ctx, xx, yl + 6, xx, yB - 2, r[2] === '#c0392b' ? 'rgba(192,57,43,.6)' : 'rgba(20,23,28,.3)', [4, 3]); label(ctx, r[1], xx + 4, yl, { size: 10, color: r[2], bold: r[2] === '#c0392b', align: 'left' }); });   /* 名前は階段状に（重ならないように） */
  /* ばねと小物体 */
  var xb = X(o.x);
  springDense(ctx, xw, yB - bh / 2, xb - bw / 2, yB - bh / 2, o.L * S - bw / 2, { r: 9, lead: 6, k: o.k, Lmin: (o.L - 0.05) * S - bw / 2 });
  ctx.save(); ctx.fillStyle = o.slip ? '#e4d3b4' : '#cfe3d4'; ctx.strokeStyle = '#6b5532'; ctx.lineWidth = 1.4; ctx.fillRect(xb - bw / 2, yB - bh, bw, bh); ctx.strokeRect(xb - bw / 2, yB - bh, bw, bh); ctx.restore();
  label(ctx, 'm', xb, yB - bh / 2, { size: 12, bold: true });
  var ptxt = o.slip ? '滑っている' : 'ベルトと一緒（くっついている）'; ctx.save(); ctx.font = '700 11px ' + FONT; var pw2 = ctx.measureText(ptxt).width / 2 + 16; ctx.restore();   /* 右に切れないように */
  pill(ctx, ptxt, W - 12, 46, { align: 'right', bg: o.slip ? '#fff2e0' : '#e3f4e8', color: o.slip ? '#a85c0c' : '#1f7a3f', size: 11 });
  /* 速度（その観測者から見た速度。小物体の上に離して）・力 */
  var vrel = o.v - Vview;
  if (!s.hideVec && Math.abs(vrel) > 0.01) vArrowAt(ctx, xb, yB - bh, 0, -1, 14, 1, 0, vrel * vs, true);
  if (m4Held(s)) m4Hand(ctx, xb + bw / 2, yB - bh / 2, -1, 0, 0.34);   /* スタート前：右へ動かないように押さえる */
  if (s.fmode) {
    var fs = 60 / (o.k * 0.25), Fk = -o.k * o.x, f = o.f !== undefined ? o.f : o.mu2 * o.m * G;
    if (fNet(s)) netArrow(ctx, xb - bw / 2, yB - bh / 2, 1, 0, (Fk + f) * fs, 'F', { ly: -14 });
    else { fArrow(ctx, xb - bw / 2, yB - bh / 2, 1, 0, Fk * fs, COL.hand, '−kx', { ly: -14, noShift: true }); fArrow(ctx, xb, yB, 1, 0, f * fs, COL.fric, o.slip ? 'μ′mg' : 'f', { ly: 14, noShift: true }); }
  }
  drawEqualTicks(ctx);
  return { yB: yB, xb: xb, S: S, bx0: bx0 + rr, bx1: bx1 - rr, run: o.V * s.t * S * 0.35 };   /* run：ベルトが動いて見える量（目印と同じ） */
}
function drawM4S3G(s) {
  var q = m4s3Q(s);
  m4Plot(s.xCv, { t0: 0, t1: 3 * q.T, lo: -0.02, hi: 2.4 * q.x0, cur: s.t, ylab: 'x', yunit: 'm', H: 160, hl: [{ y: q.x0, txt: '振動の中心 x₀' }], ser: [{ col: XCOL, f: function (t) { return m4s3At(q, t).x; } }] });
  m4Plot(s.vCv, { t0: 0, t1: 3 * q.T, lo: -1.2 * q.vmax, hi: 1.12 * M43.Vs[M43.Vs.length - 1],   /* 縦軸は V を変えても同じ（2026-10-18 千葉さん） */ cur: s.t, ylab: 'v', yunit: 'm/s', H: 160, hl: [{ y: q.V, txt: 'ベルトの速さ V', col: COL.vel }], ser: [{ col: COL.vel, f: function (t) { return m4s3At(q, t).v; } }] });
}
function m4s3Prob() {
  return '<h4 class="exh">問題の設定</h4><div class="exbox"><p>図のように、左の壁に一端を固定したばね定数 $k$ の軽いばねの他端に、質量 $m$ の小物体をつける。小物体は、右へ一定の速さ $V$ で動くベルトコンベアの上に乗っている。小物体とベルトの間の動摩擦係数を $\\mu\'$、重力加速度の大きさを $g$ とする。ばねが自然の長さになる位置で、小物体を床に対して静止させてから放した。ばねの自然の長さからの伸びを $x$（右向きを正）とする。$V$ は十分に大きく、小物体はいつもベルトに対して滑っているものとする。</p></div>' +
    '<h4 class="exh">図</h4><div class="exfig"><canvas data-fig="setup" data-h="150"></canvas></div>' +
    '<h4 class="exh">問</h4><ol class="exol">' +
    '<li>小物体がベルトから受ける摩擦力の向きと大きさを答えよ。</li>' +
    '<li>小物体の加速度を $a$ として、運動方程式を書け。</li>' +
    '<li>振動の中心の位置 $x_0$ と周期 $T$ を求めよ。</li>' +
    '<li>ばねの伸びの最大値を求めよ。</li>' +
    '<li>小物体の速さの最大値を求めよ。また、このような運動になるために $V$ が満たすべき条件を求めよ。</li>' +
    '<li>$V$ を 2 倍にすると、小物体の運動はどう変わるか。</li></ol>';
}
function m4s3Ans() {
  return '<h4 class="exh">時間の流れで見る</h4>' +
    exStrip([['a', 'ⓐ 放した直後', '$x = 0$、$v = 0$'], ['b', 'ⓑ 振動の中心', '$x = x_0$、速さ最大'], ['c', 'ⓒ 最も伸びた所', '$x = 2x_0$、$v = 0$'], ['d', 'ⓓ 戻る途中', '左向きに動く'], ['e', 'ⓔ 1 周期後', '$x = 0$、$v = 0$']], 110, true) +
    '<h4 class="exh">解答と解き方</h4>' +
    exQA('(1) 摩擦力', '右向きに $\\mu\'mg$', '<p>小物体の速さはいつも $V$ より小さいので、<b>ベルトから見ると小物体はいつも左へ滑っている</b>。動摩擦力は相対速度と逆向き（右向き）で、大きさ $\\mu\'mg$。</p>') +
    exQA('(2) 運動方程式', '$ma = -kx + \\mu\'mg$', '') +
    exQA('(3) 振動の中心と周期', '$x_0 = \\dfrac{\\mu\'mg}{k}$、$T = 2\\pi\\sqrt{\\dfrac{m}{k}}$', '<p>$ma = -k\\left(x - \\dfrac{\\mu\'mg}{k}\\right)$ と変形する。振動の中心は、弾性力と動摩擦力がつりあう位置。</p>') +
    exQA('(4) 最大の伸び', '$2x_0 = \\dfrac{2\\mu\'mg}{k}$', '<p>$x = 0$ で速さ 0 なので、そこが振動の端。振幅は $x_0$、反対の端は $2x_0$。$x = x_0(1 - \\cos\\omega t)$。</p>') +
    exQA('(5) 最大の速さと条件', '$v_{\\max} = x_0\\omega = \\mu\'g\\sqrt{\\dfrac{m}{k}}$、条件 $V > \\mu\'g\\sqrt{\\dfrac{m}{k}}$', '<p>小物体がベルトより速くならなければ、滑る向きは変わらない。</p>') +
    exQA('(6) $V$ を 2 倍にすると', '変わらない', '<p>動摩擦力の大きさ $\\mu\'mg$ は、滑る速さによらない。(5) の条件を満たすかぎり、運動はまったく同じ。</p>');
}
function m4s3Fig(key, ctx, W, H) {
  var q = m4s3Q({ v: { V: 2.0 } }), t = { setup: 0, a: 0, b: q.T / 4, c: q.T / 2, d: 3 * q.T / 4, e: q.T }[key], st = m4s3At(q, t);
  var fake = { t: key === 'setup' ? 0 : t, hideVec: false, fmode: key === 'setup' ? null : 'all' };
  ctx.save(); if (key !== 'setup') { ctx.translate(0, 0); }
  m4BeltMini(ctx, W, H, q, st, key === 'setup');
  ctx.restore();
}
function m4BeltMini(ctx, W, H, q, st, setup) {
  var L = 0.6, S = (W - 30) / (L + 0.45), xw = 12, yB = H - 34, bw = 26, bh = 20, X = function (x) { return xw + (L + x) * S; };
  wallLeftAt(ctx, xw, yB - 44, yB - 2);
  ctx.save(); ctx.fillStyle = '#e9edf1'; ctx.strokeStyle = '#59636e'; ctx.lineWidth = 1.2; rrect(ctx, xw + 4, yB, W - xw - 8, 18, 9); ctx.fill(); ctx.stroke(); ctx.restore();
  var xb = X(st.x);
  springDense(ctx, xw, yB - bh / 2, xb - bw / 2, yB - bh / 2, L * S - bw / 2, { r: 5, lead: 3, k: q.k, thin: 0.7, Lmin: (L - 0.03) * S - bw / 2 });
  ctx.save(); ctx.fillStyle = '#e4d3b4'; ctx.strokeStyle = '#6b5532'; ctx.lineWidth = 1.2; ctx.fillRect(xb - bw / 2, yB - bh, bw, bh); ctx.strokeRect(xb - bw / 2, yB - bh, bw, bh); ctx.restore();
  dotted(ctx, X(0), yB - 40, X(0), yB, 'rgba(20,23,28,.3)', [3, 3]); dotted(ctx, X(q.x0), yB - 40, X(q.x0), yB, 'rgba(192,57,43,.6)', [3, 3]);
  if (setup) { label(ctx, 'k', xw + L * S * 0.4, yB - bh - 8, { size: 12 }); label(ctx, 'm', xb, yB - bh / 2, { size: 11, bold: true }); arrow(ctx, W - 90, yB + 26, W - 50, yB + 26, 'vel'); label(ctx, 'V', W - 44, yB + 26, { size: 12, color: COL.vel, align: 'left' }); label(ctx, '自然の長さ', X(0), yB - 48, { size: 10, color: '#5d6875' }); return; }
  var fs = 22 / (q.k * q.x0 * 2);
  fArrow(ctx, xb, yB, 1, 0, q.mu2 * q.m * G * fs, COL.fric, null, { noShift: true });
  if (Math.abs(st.x) > 1e-4) fArrow(ctx, xb - bw / 2, yB - bh / 2, 1, 0, -q.k * st.x * fs, COL.hand, null, { noShift: true });
  if (Math.abs(st.v) > 0.02) vArrowAt(ctx, xb, yB - bh, 0, -1, 6, 1, 0, st.v / q.vmax * 20, false);
  drawEqualTicks(ctx);
}

/* ===================== ④-4 ベルトコンベア（滑ったりくっついたり） =====================
   ベルトの速さ V は小さい。静止摩擦係数 μ > 動摩擦係数 μ′。自然の長さの位置で、ベルトに対して静止した状態から始める。
   ① ベルトと一緒に速さ V で右へ（静止摩擦力 kx）→ ② x₁ = μmg/k で滑り出す → ③ 中心 x₀ = μ′mg/k の単振動 →
   ④ 速度がふたたび V になる x₂ = 2x₀ − x₁ でくっつく → ① に戻る。滑っている間の振幅 A = √((m/k)V² + ((μ−μ′)mg/k)²) */
var M44 = { m: 0.5, k: 20, mu: 0.5, mu2: 0.3, Vs: [0.2, 0.3, 0.4], L: 0.9 };
function m4s4Q(s) {
  var m = M44.m, k = M44.k, w = Math.sqrt(k / m), x1 = M44.mu * m * G / k, x0 = M44.mu2 * m * G / k, V = s.v.V, D = x1 - x0;
  var A = Math.sqrt(V * V / (w * w) + D * D), ph = Math.atan2(V / w, D), tS0 = x1 / V, tSl = (Math.PI + 2 * ph) / w, x2 = 2 * x0 - x1, tSt = (x1 - x2) / V;
  return { m: m, k: k, mu: M44.mu, mu2: M44.mu2, w: w, T: TAU / w, x1: x1, x0: x0, x2: x2, V: V, D: D, A: A, ph: ph, tS0: tS0, tSl: tSl, tSt: tSt, cyc: tSl + tSt };
}
function m4s4At(q, t) {
  if (t < q.tS0) return { x: q.V * t, v: q.V, slip: false, f: q.k * q.V * t };          /* 最初：自然の長さから x₁ まで一緒に */
  var tt = (t - q.tS0) % q.cyc;
  if (tt < q.tSl) { var X = q.D * Math.cos(q.w * tt) + q.V / q.w * Math.sin(q.w * tt); return { x: q.x0 + X, v: -q.D * q.w * Math.sin(q.w * tt) + q.V * Math.cos(q.w * tt), slip: true, f: q.mu2 * q.m * G }; }
  var x = q.x2 + q.V * (tt - q.tSl); return { x: x, v: q.V, slip: false, f: q.k * x };
}
DEFS.m4s4 = {
  id: 'm4s4', mode: 'mode4', num: 5, title: 'ベルトコンベアの上の単振動（滑ったりくっついたり）', short: 'ベルトコンベア（滑ったりくっついたり）',
  desc: '④-3 と同じ装置で、ベルトの速さ $V$ を小さくする。静止摩擦係数を $\\mu$、動摩擦係数を $\\mu\'$（$\\mu \\gt \\mu\'$）とする。ばねが自然の長さの位置で、小物体がベルトに対して静止した状態から運動が始まる。<span class="todo">小物体がベルトに対して静止した状態（ベルトと同じ速度）なら両者はくっついて一緒に動くので小物体は等速直線運動するが、最大摩擦力を越えると滑り出し、単振動をする。このように 2 つの運動が切り替わるのを、右の $x$–$t$ グラフからも確認しよう。</span>',
  strobe: false, showFBtn: true, fDefault: 'all', vecBtn: 'v を消す', belowCanvas: true, baseRate: 0.5,
  exam: { src: '典型問題（参考：physicmath.net の解説。数値・言いまわしを変えて作り直したもの）', pdf: 'shm-belt-stickslip', prob: function () { return m4s4Prob(); }, ans: function () { return m4s4Ans(); }, fig: function (k, ctx, W, H) { m4s4Fig(k, ctx, W, H); } },
  buttons: [
    { k: 'vA', label: '観測者 A（床）から見る', cls: 'm4only on', inCanvas: true, onClick: function (s) { s.view = 'A'; m4Seg(s, [['A', 'vA'], ['B', 'vB']], 'A'); s.draw(); } },
    { k: 'vB', label: '観測者 B（ベルト）から見る', cls: 'm4only', inCanvas: true, onClick: function (s) { s.view = 'B'; m4Seg(s, [['A', 'vA'], ['B', 'vB']], 'B'); s.draw(); } }],
  vars: [{ k: 'V', label: 'ベルトの速さ $V$', stops: M44.Vs, stopLabels: ['0.2', '0.3', '0.4 m/s'], def: 0.3, aria: 'ベルトの速さ', fmt: function (x) { return x.toFixed(1) + ' m/s'; } }],
  init: function (s) { s.view = 'A'; },
  onDefaults: function (s) { s.view = 'A'; m4Seg(s, [['A', 'vA'], ['B', 'vB']], 'A'); },
  onChanged: function () { return 'stop'; },
  tEnd: function (s) { var q = m4s4Q(s); return q.tS0 + 2 * q.cyc; },
  gT: function (s) { return m4s4Q(s).cyc; },
  height: function (s, w) { return Math.round(clamp(w * 0.46, 250, 320)); },
  afterBuild: function (s) {
    s.R.innerHTML = '';
    m4Card(s, '<p class="qt">$x$–$t$ グラフ<span class="qtsub">（<span style="color:#1f7a3f">緑：くっついている</span>／<span style="color:#d0801f">オレンジ：滑っている</span>）</span></p>'); s.xCv = el('canvas', 'm4cv'); s.R.lastChild.appendChild(s.xCv);
    m4Card(s, '<p class="qt">$v$–$t$ グラフ<span class="qtsub">（床から見た速度）</span></p>'); s.vCv = el('canvas', 'm4cv'); s.R.lastChild.appendChild(s.vCv);
    s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);
  },
  draw: function (s, ctx, W, H) {
    var q = m4s4Q(s), st = m4s4At(q, s.t);
    var g = drawBelt(s, ctx, W, H, { L: M44.L, k: q.k, x: st.x, v: st.v, V: q.V, vs: 130, slip: st.slip, f: st.f, mu2: q.mu2, m: q.m, view: s.view, xs: [[q.x2, 'x₂', '#5d6875'], [q.x0, '中心 x₀', '#c0392b'], [q.x1, 'x₁', '#5d6875']] });
    /* 観測者 B はベルトにのって、ベルトと同じ速さ V で右へ動く（B の視点では止まり、床と A が左へ動く）。2026-10-18 千葉さん */
    var span = g.bx1 - g.bx0 - 60, wrap = function (x) { return g.bx0 + 30 + (((x - g.bx0 - 30) % span) + span) % span; };
    var xB = s.view === 'B' ? g.bx0 + 30 + span * 0.82 : wrap(g.bx0 + 30 + span * 0.82 + g.run), xA = s.view === 'B' ? wrap(g.bx0 + 30 + span * 0.05 - g.run) : g.bx0 + 30 + span * 0.05;
    ctx.save(); ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(14, H - 8); ctx.lineTo(W - 14, H - 8); ctx.stroke(); ctx.restore();
    m4FloorMarks(ctx, 14, W - 14, H - 8, s.view === 'B' ? -g.run : 0, 40);
    observer(ctx, xA, H - 8, 0, -1, '', s.view === 'A', 26); label(ctx, 'A（床）', xA + 14, H - 22, { size: 10.5, color: s.view === 'A' ? COL.vel : '#9aa3ac', align: 'left', bold: s.view === 'A' });
    observer(ctx, xB, g.yB, 0, -1, '', s.view === 'B', 26); label(ctx, 'B（ベルト）', xB, g.yB - 36, { size: 10.5, color: s.view === 'B' ? COL.vel : '#9aa3ac', bold: s.view === 'B' });
    if (!s.hideVec) vArrowAt(ctx, s.view === 'B' ? xA : xB, s.view === 'B' ? H - 8 - 30 : g.yB - 30, 0, -1, 18, 1, 0, (s.view === 'B' ? -1 : 1) * q.V * 130, false);
    if (s.view === 'B') label(ctx, st.slip ? 'B から見ると小物体は左へ滑る → 動摩擦力は右向き' : 'B から見ると小物体は止まっている → 静止摩擦力', W / 2, 16, { size: 11, bold: true, color: COL.vel });
    drawM4S4G(s);
  },
  msg: function (s) {
    var q = m4s4Q(s), st = m4s4At(q, s.t);
    return st.slip ? '滑っている：動摩擦力 $\\mu\'mg$（右向き）とばねの力で、中心 $x_0 = \\dfrac{\\mu\'mg}{k}$ の単振動。速度がふたたび $V$ になる $x_2 = 2x_0 - x_1$ でベルトにくっつく。'
      : 'くっついている：小物体はベルトと一緒に速さ $V$ で動く。静止摩擦力 $f = kx$ がばねの力とつりあう。$f$ が最大摩擦力 $\\mu mg$ に達する $x_1 = \\dfrac{\\mu mg}{k}$ で滑り出す。';
  },
  right: function (s, R) { var q = m4s4Q(s); R.innerHTML = mathify('<div class="qcard"><p class="qnow"><span class="qtag now">この図では</span>$m = ' + q.m + '$ kg、$k = ' + q.k + '$ N/m、$\\mu = ' + q.mu + '$、$\\mu\' = ' + q.mu2 + '$：$x_1 = ' + fmt(q.x1, 3) + '$ m、$x_0 = ' + fmt(q.x0, 3) + '$ m、$x_2 = ' + fmt(q.x2, 3) + '$ m、滑る間の振幅 $A = ' + fmt(q.A, 3) + '$ m</p><div class="qeq">$$A = \\sqrt{\\frac{m}{k}V^2 + \\left\\{\\frac{(\\mu - \\mu\')mg}{k}\\right\\}^2}$$</div></div>'); }
};
function drawM4S4G(s) {
  var q = m4s4Q(s), t1 = q.tS0 + 2 * q.cyc, seg = function (t) { return m4s4At(q, t).slip ? '#d0801f' : '#1f7a3f'; };
  var zs = [{ t0: 0, t1: q.tS0, txt: '等速直線運動', txt2: ['等速直線', '運動'], col: '#1f7a3f' }];   /* くっついている＝ベルトと一緒に等速、滑っている＝単振動 */
  for (var c = 0, tc0 = q.tS0; tc0 < t1; c++) { zs.push({ t0: tc0, t1: Math.min(t1, tc0 + q.tSl), txt: '単振動', col: '#d0801f' }); zs.push({ t0: tc0 + q.tSl, t1: Math.min(t1, tc0 + q.cyc), txt: '等速直線運動', txt2: ['等速直線', '運動'], col: '#1f7a3f' }); tc0 += q.cyc; }
  m4Plot(s.xCv, { t0: 0, t1: t1, lo: -0.01, hi: q.x0 + q.A * 1.15, cur: s.t, ylab: 'x', yunit: 'm', H: 190, zones: zs, hl: [{ y: q.x1, txt: 'x₁ = μmg/k', col: '#5d6875' }, { y: q.x0, txt: '中心 x₀' }, { y: q.x2, txt: 'x₂', col: '#5d6875' }], ser: [{ col: '#1f7a3f', w: 2.6, seg: seg, f: function (t) { return m4s4At(q, t).x; } }] });
  m4Plot(s.vCv, { t0: 0, t1: t1, lo: -q.A * q.w * 1.1, hi: Math.max(q.A * q.w, q.V) * 1.15, cur: s.t, ylab: 'v', yunit: 'm/s', H: 150, hl: [{ y: q.V, txt: 'V', col: COL.vel }], ser: [{ col: COL.vel, w: 2.4, seg: function (t) { return m4s4At(q, t).slip ? '#d0801f' : '#1f7a3f'; }, f: function (t) { return m4s4At(q, t).v; } }] });
}
function m4s4Prob() {
  return '<h4 class="exh">問題の設定</h4><div class="exbox"><p>④-3 と同じ装置で、ベルトの速さ $V$ を小さくした。小物体とベルトの間の静止摩擦係数を $\\mu$、動摩擦係数を $\\mu\'$（$\\mu \\gt \\mu\'$）とする。ばねが自然の長さの位置で、小物体がベルトに対して静止した状態から運動が始まった。ばねの伸びを $x$（右向きを正）とする。</p></div>' +
    '<h4 class="exh">問</h4><ol class="exol">' +
    '<li>小物体がベルトと一緒に動いているとき、小物体がベルトから受ける摩擦力の種類・向き・大きさを $x$ で答えよ。</li>' +
    '<li>小物体がベルトに対して滑り始めるときの伸び $x_1$ を求めよ。</li>' +
    '<li>滑っている間の運動方程式を書き、振動の中心 $x_0$ と周期 $T$ を求めよ。</li>' +
    '<li>滑り始めた瞬間の小物体の速さは $V$ である。滑っている間の振幅 $A$ を求めよ。</li>' +
    '<li>小物体がふたたびベルトに対して静止するときの伸び $x_2$ を、$x_0$・$x_1$ で表せ。</li>' +
    '<li>この後、小物体はどのような運動をくり返すか。</li></ol>';
}
function m4s4Ans() {
  return '<h4 class="exh">時間の流れで見る（1 往復）</h4>' +
    exStrip([['a', 'ⓐ くっついて右へ', '静止摩擦力 $kx$'], ['b', 'ⓑ $x = x_1$', '滑り出す'], ['c', 'ⓒ 滑る', '中心 $x_0$ の単振動'], ['d', 'ⓓ $x = x_2$', '速度 $V$ に戻る'], ['e', 'ⓔ ふたたび一緒に', '①に戻る']], 110, true) +
    '<h4 class="exh">解答と解き方</h4>' +
    exQA('(1) 一緒に動いているとき', '静止摩擦力、右向き、大きさ $kx$', '<p>速さ $V$ 一定なので合力は 0：静止摩擦力 $f$ がばねの弾性力 $kx$（左向き）とつりあう。</p>') +
    exQA('(2) 滑り始める伸び', '$x_1 = \\dfrac{\\mu mg}{k}$', '<p>$f = kx$ が最大摩擦力 $\\mu mg$ に達したとき。</p>') +
    exQA('(3) 滑っている間', '$ma = -kx + \\mu\'mg$、$x_0 = \\dfrac{\\mu\'mg}{k}$、$T = 2\\pi\\sqrt{\\dfrac{m}{k}}$', '<p>小物体の速さは $V$ より小さく、ベルトから見ると左へ滑るので、動摩擦力は右向き。</p>') +
    exQA('(4) 振幅', '$A = \\sqrt{\\dfrac{m}{k}V^2 + \\left\\{\\dfrac{(\\mu - \\mu\')mg}{k}\\right\\}^2}$', '<p>中心 $x_0$ からの変位 $X = x - x_0$ で単振動のエネルギー：$\\dfrac{1}{2}mV^2 + \\dfrac{1}{2}k(x_1 - x_0)^2 = \\dfrac{1}{2}kA^2$。</p>') +
    exQA('(5) ふたたびくっつく位置', '$x_2 = 2x_0 - x_1$', '<p>単振動では、中心について対称な位置で速さが等しい。$x_1$ で速度 $V$ だった小物体は、中心 $x_0$ について反対がわの $x_2$ で、ふたたび速度 $V$（右向き）になる。そこでベルトと速度がそろってくっつく。</p>') +
    exQA('(6) その後の運動', '①〜④をくり返す', '<p>$x_2$ から $x_1$ まではベルトと一緒に速さ $V$（グラフでは直線）、$x_1$ から $x_2$ までは中心 $x_0$ の単振動（グラフでは正弦曲線の一部）。$x_2 < x_1$ では静止摩擦力 $kx_2 < \\mu mg$ なので、くっついたままでいられる。</p>');
}
function m4s4Fig(key, ctx, W, H) {
  var q = m4s4Q({ v: { V: 0.3 } }), ts = { a: q.tS0 * 0.5, b: q.tS0, c: q.tS0 + q.tSl * 0.5, d: q.tS0 + q.tSl, e: q.tS0 + q.tSl + q.tSt * 0.5 }, st = m4s4At(q, ts[key] + (key === 'b' ? 1e-4 : 0));
  var L = 0.6, S = (W - 30) / (L + 0.3), xw = 12, yB = H - 34, bw = 26, bh = 20, X = function (x) { return xw + (L + x) * S; };
  wallLeftAt(ctx, xw, yB - 44, yB - 2);
  ctx.save(); ctx.fillStyle = '#e9edf1'; ctx.strokeStyle = '#59636e'; ctx.lineWidth = 1.2; rrect(ctx, xw + 4, yB, W - xw - 8, 18, 9); ctx.fill(); ctx.stroke(); ctx.restore();
  var xb = X(st.x);
  springDense(ctx, xw, yB - bh / 2, xb - bw / 2, yB - bh / 2, L * S - bw / 2, { r: 5, lead: 3, k: q.k, thin: 0.7, Lmin: (L - 0.03) * S - bw / 2 });
  ctx.save(); ctx.fillStyle = st.slip ? '#e4d3b4' : '#cfe3d4'; ctx.strokeStyle = '#6b5532'; ctx.lineWidth = 1.2; ctx.fillRect(xb - bw / 2, yB - bh, bw, bh); ctx.strokeRect(xb - bw / 2, yB - bh, bw, bh); ctx.restore();
  [[q.x2, '#5d6875'], [q.x0, '#c0392b'], [q.x1, '#5d6875']].forEach(function (r) { dotted(ctx, X(r[0]), yB - 40, X(r[0]), yB, r[1] === '#c0392b' ? 'rgba(192,57,43,.6)' : 'rgba(20,23,28,.3)', [3, 3]); });
  var fs = 22 / (q.k * q.x1);
  fArrow(ctx, xb, yB, 1, 0, st.f * fs, COL.fric, null, { noShift: true }); fArrow(ctx, xb - bw / 2, yB - bh / 2, 1, 0, -q.k * st.x * fs, COL.hand, null, { noShift: true });
  if (Math.abs(st.v) > 0.01) vArrowAt(ctx, xb, yB - bh, 0, -1, 6, 1, 0, st.v / q.V * 14, false);
  label(ctx, st.slip ? '滑る' : 'くっつく', W / 2, 12, { size: 10.5, bold: true, color: st.slip ? '#a85c0c' : '#1f7a3f' });
  drawEqualTicks(ctx);
}

/* ===================== ④-5 ゴムひもでつるした小球 =====================
   天井からゴムひも（伸びたときだけばね定数 k）で質量 m の小球をつるす。つりあいの伸び l₁ = mg/k。さらに 2l₁ 引き下げて放す。
   x：つりあいの位置を原点、上向きが正。自然の長さは x = l₁。x < l₁：中心 0・振幅 2l₁ の単振動。x > l₁：ゴムがたるみ、投げ上げ。
   自然の長さでの速さ v₁ = g√(3m/k)、最高点は自然の長さから 3mg/(2k) 上。実際の周期 (4π/3)√(m/k) + 2√(3m/k)。 */
var M45 = { m: 0.2, k: 20, L0: 0.5 };
function m4s5Q() {
  var m = M45.m, k = M45.k, w = Math.sqrt(k / m), l1 = m * G / k, A = 2 * l1, tA = (2 * Math.PI / 3) / w, v1 = w * Math.sqrt(A * A - l1 * l1), tF = 2 * v1 / G;
  return { m: m, k: k, w: w, Ts: TAU / w, l1: l1, A: A, tA: tA, v1: v1, tF: tF, T: 2 * tA + tF, hmax: v1 * v1 / (2 * G) };
}
function m4s5At(q, t) {
  var tt = t % q.T;
  if (tt < q.tA) return { x: -q.A * Math.cos(q.w * tt), v: q.A * q.w * Math.sin(q.w * tt), slack: false };
  if (tt < q.tA + q.tF) { var u = tt - q.tA; return { x: q.l1 + q.v1 * u - 0.5 * G * u * u, v: q.v1 - G * u, slack: true }; }
  var u2 = tt - q.tA - q.tF, th = (4 * Math.PI / 3) + q.w * u2;   /* 下がる側の単振動（自然の長さ → 下の端）。x = −A cos θ で θ = 4π/3 から 2π（下向きに動く。2026-10-18 修正） */
  return { x: -q.A * Math.cos(th), v: q.A * q.w * Math.sin(th), slack: false };
}
function m4s5Spring(q, t) { return { x: -q.A * Math.cos(q.w * t), v: q.A * q.w * Math.sin(q.w * t) }; }   /* もしもばねだったら */
DEFS.m4s5 = {
  id: 'm4s5', mode: 'mode4', num: 6, title: 'ゴムひもでつるした小球', short: 'ゴムひも',
  desc: '天井からゴムひもで質量 $m$ の小球をつるす。ゴムひもは伸びているときだけ、ばね定数 $k$ のばねと同じ力をおよぼし、たるむと力は 0 になる。つりあいの位置から、さらに $2l_1$（$l_1$ はつりあいでの伸び）引き下げて放す。<span class="todo">ゴムがたるむと、小球は投げ上げの運動になる。「ばねだったら」を表示して、単振動との違いを見よう。</span>',
  strobe: false, showFBtn: true, fDefault: 'all', vecBtn: 'v を消す', belowCanvas: true, baseRate: 0.4,
  exam: { src: '典型問題（参考：physicmath.net の解説。数値・言いまわしを変えて作り直したもの）', pdf: 'shm-rubber', prob: function () { return m4s5Prob(); }, ans: function () { return m4s5Ans(); }, fig: function (k, ctx, W, H) { m4s5Fig(k, ctx, W, H); } },
  buttons: [{ k: 'ghost', label: 'もしもばねだったら（点線）を表示', cls: 'chkb on', onClick: function (s, b) { s.ghost = !s.ghost; b.classList.toggle('on', s.ghost); s.draw(); } }],
  init: function (s) { s.ghost = true; },                           /* 「ばねだったら」は最初から表示（2026-10-18 千葉さん） */
  onDefaults: function (s) { s.ghost = true; if (s.extra.ghost) s.extra.ghost.classList.add('on'); },
  tEnd: function () { return 2 * m4s5Q().T; },
  tInfo: function () { var q = m4s5Q(); return '<span class="tpl">周期</span><b>' + tex('T =') + ' ' + sig2(q.T) + '</b> s<span class="tnote">（ばねなら ' + sig2(q.Ts) + ' s）</span>'; },
  gT: function () { return m4s5Q().T; },
  height: function (s, w) { return Math.round(clamp(w * 0.66, 340, 460)) + 40; },
  afterBuild: function (s) {
    s.R.innerHTML = '';
    m4Card(s, '<p class="qt">$x$–$t$ グラフ<span class="qtsub">（<span style="color:#1f8a4c">緑：単振動</span>／<span style="color:#d0801f">オレンジ：投げ上げ</span>／点線：ばねだったら）</span></p>'); s.xCv = el('canvas', 'm4cv'); s.R.lastChild.appendChild(s.xCv);
    m4Card(s, '<p class="qt">$v$–$t$ グラフ<span class="qtsub">（<span style="color:#1f8a4c">緑：単振動</span>／<span style="color:#d0801f">オレンジ：投げ上げ</span>／点線：ばねだったら）</span></p>'); s.vCv = el('canvas', 'm4cv'); s.R.lastChild.appendChild(s.vCv);   /* ④-5 と同じく v–t も（2026-10-25 千葉さん） */
    s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);
  },
  draw: function (s, ctx, W, H) { drawM4S5(s, ctx, W, H); var q = m4s5Q();
    m4Plot(s.xCv, { t0: 0, t1: 2 * q.T, lo: -q.A * 1.15, hi: (q.l1 + q.hmax) * 1.15, cur: s.t, ylab: 'x', yunit: 'm', H: 190, hl: [{ y: q.l1, txt: '自然の長さ', col: '#5d6875' }],
      ser: [{ col: '#1f8a4c', w: 2.6, seg: function (t) { return m4s5At(q, t).slack ? '#d0801f' : '#1f8a4c'; }, f: function (t) { return m4s5At(q, t).x; } }, { col: 'rgba(20,23,28,.45)', w: 1.5, dash: [5, 4], f: function (t) { return m4s5Spring(q, t).x; } }] });
    m4Plot(s.vCv, { t0: 0, t1: 2 * q.T, lo: -q.A * q.w * 1.15, hi: q.A * q.w * 1.15, cur: s.t, ylab: 'v', yunit: 'm/s', H: 170,
      ser: [{ col: '#1f8a4c', w: 2.6, seg: function (t) { return m4s5At(q, t).slack ? '#d0801f' : '#1f8a4c'; }, f: function (t) { return m4s5At(q, t).v; } }, { col: 'rgba(20,23,28,.45)', w: 1.5, dash: [5, 4], f: function (t) { return m4s5Spring(q, t).v; } }] });
  },
  msg: function (s) { var q = m4s5Q(), st = m4s5At(q, s.t); return st.slack ? 'ゴムひもがたるんでいる：小球にはたらく力は重力だけ。投げ上げの運動（最高点は自然の長さから $\\dfrac{3mg}{2k}$ 上）。' : 'ゴムひもが伸びている：つりあいの位置を中心とする単振動（振幅 $2l_1$）。自然の長さを通る速さは $g\\sqrt{\\dfrac{3m}{k}} = ' + fmt(q.v1, 2) + '$ m/s。'; },
  right: function (s, R) { var q = m4s5Q(); R.innerHTML = mathify('<div class="qcard"><p class="qt">実際の周期</p><div class="qeq">$$T = \\underbrace{\\frac{4\\pi}{3}\\sqrt{\\frac{m}{k}}}_{\\text{単振動の部分}} + \\underbrace{2\\sqrt{\\frac{3m}{k}}}_{\\text{投げ上げの部分}}$$</div><p>ばねなら $T = 2\\pi\\sqrt{\\dfrac{m}{k}}$。</p><p class="qnow"><span class="qtag now">この図では</span>$m = ' + q.m + '$ kg、$k = ' + q.k + '$ N/m、$l_1 = ' + fmt(q.l1, 3) + '$ m：$T = ' + sig2(q.T) + '$ s（ばねなら ' + sig2(q.Ts) + ' s）</p></div>'); }
};
function drawM4S5(s, ctx, W, H) {
  var q = m4s5Q(), st = m4s5At(q, s.t), top = 22, cx = W * 0.50, xTop = q.l1 + q.hmax + 0.03, xBot = -q.A - 0.05, S = (H - top - 66) / (M45.L0 + q.l1 - xBot), Y = function (x) { return top + (M45.L0 + q.l1 - x) * S; }, rb = 12;   /* 下に、左の図の名前の場所（2026-10-25） */
  refArea(ctx, 0, 0, W * 0.36, H, 'r');                             /* 左の参考の図のエリア（背景と境の実線。2026-10-25 千葉さん） */
  ceilingAt(ctx, cx - 50, cx + 50, top);
  var yb = Y(st.x), yN = Y(q.l1);
  /* 左に「自然の長さ」「つりあいの位置」（②-3 と同じ。2026-10-18 千葉さん） */
  [[W * 0.10, null, '自然の長さの位置'], [W * 0.25, 0, 'つりあいの位置']].forEach(function (r) {
    ceilingAt(ctx, r[0] - 22, r[0] + 22, top);
    ctx.save(); ctx.strokeStyle = '#7a4a2a'; ctx.lineWidth = 3; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(r[0], top);
    if (r[1] === null) { ctx.lineTo(r[0], yN - rb); ctx.stroke(); ctx.restore(); ctx.save(); ctx.setLineDash([4, 3]); ctx.strokeStyle = 'rgba(20,23,28,.5)'; ctx.lineWidth = 1.3; ctx.beginPath(); ctx.arc(r[0], yN, rb, 0, TAU); ctx.stroke(); ctx.restore(); }   /* 小球の中心が自然の長さの線の上 */
    else { ctx.lineTo(r[0], Y(0) - rb); ctx.stroke(); ctx.restore(); ballShape(ctx, r[0], Y(0), rb, '#d9b77a'); }
    var lt = W < 480 ? [r[2].replace('の位置', ''), 'の位置'] : [r[2]];   /* せまい画面では 2 行に */
    lt.forEach(function (t, j) { label(ctx, t, r[0], H - 12 - (lt.length - 1 - j) * 13, { size: 10.5, color: r[1] === null ? '#5d6875' : '#c0392b', bold: r[1] !== null }); });
  });
  /* ゴムひも：伸びていれば直線（太さは伸びで少し細く）、たるんでいれば波線 */
  ctx.save(); ctx.strokeStyle = '#7a4a2a'; ctx.lineCap = 'round';
  if (!st.slack) { ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(cx, top); ctx.lineTo(cx, yb - rb); ctx.stroke(); }
  else { ctx.lineWidth = 2.4; var Ls = yN - rb - top, Lc = Math.max(4, yb - rb - top); ctx.beginPath(); ctx.moveTo(cx, top); for (var i = 1; i <= 40; i++) { var f = i / 40, amp = Math.sqrt(Math.max(0, Ls * Ls - Lc * Lc)) * 0.18; ctx.lineTo(cx + amp * Math.sin(f * Math.PI * 3), top + f * Lc); } ctx.stroke(); }
  ctx.restore();
  /* 目印の線 */
  [[q.l1, '自然の長さ（x = l₁）', '#5d6875'], [0, 'つりあいの位置 O', '#c0392b'], [-q.A, '放す位置（x = −2l₁）', '#5d6875'], [q.l1 + q.hmax, '最高点（自然の長さから 3mg/2k 上）', '#a85c0c']].forEach(function (r) { var y = Y(r[0]); dotted(ctx, W * 0.04, y, W - 16, y, r[2] === '#c0392b' ? 'rgba(192,57,43,.55)' : 'rgba(20,23,28,.28)', [4, 3]); label(ctx, r[1], cx + 64, y - 8, { size: 10.5, color: r[2], align: 'left', bold: r[2] === '#c0392b' }); });
  dimLine(ctx, cx - 48, Y(q.l1), cx - 48, Y(0)); sym(ctx, 'l₁', cx - 56, (Y(q.l1) + Y(0)) / 2, { size: 13, align: 'right' });
  if (s.ghost) { var sg = m4s5Spring(q, s.t); ctx.save(); ctx.globalAlpha = 0.3; springDense(ctx, cx + 34, top, cx + 34, Y(sg.x) - rb, M45.L0 * S, { r: 7, lead: 6, k: q.k, thin: 0.8 }); ctx.restore(); ctx.save(); ctx.setLineDash([4, 3]); ctx.strokeStyle = 'rgba(20,23,28,.55)'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.arc(cx + 34, Y(sg.x), rb, 0, TAU); ctx.stroke(); ctx.restore(); label(ctx, 'ばね', cx + 34, Y(sg.x) + rb + 10, { size: 10, color: '#5d6875' }); }
  ballShape(ctx, cx, yb, rb, '#d9b77a');
  if (s.t === 0 && !s.playing) { m4Hand(ctx, cx + 5, yb - rb + 2, 0, 1, 0.34); handBubble(ctx, '2l₁ 引き下げて押さえる → 放す', cx + rb + 4, yb + 18, 'r'); }
  pill(ctx, st.slack ? 'ゴムがたるむ：投げ上げ' : '単振動', W - 12, 40, { align: 'right', bg: st.slack ? '#fff2e0' : '#e3f4e8', color: st.slack ? '#a85c0c' : '#1f7a3f', size: 11.5 });
  var vref = q.A * q.w;
  if (!s.hideVec && Math.abs(st.v) > 0.03) vArrowAt(ctx, cx, yb, 1, 0, rb + 24, 0, -1, st.v / vref * 44, true);
  if (s.fmode) {
    var fs = 26 / (q.m * G), Fr = st.slack ? 0 : q.k * (q.l1 - st.x);
    if (fNet(s)) netArrow(ctx, cx, yb - rb, 0, -1, (Fr - q.m * G) * fs, 'F', { lx: -16, al: 'right' });
    else { fArrow(ctx, cx - 5, yb, 0, 1, q.m * G * fs, COL.force, 'mg', { lx: -14, noShift: true }); if (Fr > 1e-6) fArrow(ctx, cx + 5, yb - rb, 0, -1, Fr * fs, COL.hand, '弾性力', { lx: 26, noShift: true }); }
  }
  drawEqualTicks(ctx);
}
function m4s5Prob() {
  return '<h4 class="exh">問題の設定</h4><div class="exbox"><p>天井に一端を固定した軽いゴムひもの他端に、質量 $m$ の小球をつるす。ゴムひもは、自然の長さより伸びているときはばね定数 $k$ のばねと同じ弾性力をおよぼし、たるんでいるときは力をおよぼさない。重力加速度の大きさを $g$ とする。つりあいの位置から、さらに $2l_1$（$l_1$ はつりあいでのゴムの伸び）だけ小球を引き下げて、静かに放した。小球は鉛直方向にだけ動き、天井には届かないものとする。</p></div>' +
    '<h4 class="exh">図</h4><div class="exfig"><canvas data-fig="setup" data-h="230"></canvas></div>' +
    '<h4 class="exh">問</h4><ol class="exol">' +
    '<li>$l_1$ を求めよ。</li>' +
    '<li>放してから、ゴムひもが自然の長さになるまでの運動は単振動である。その中心・振幅・角振動数を答えよ。</li>' +
    '<li>ゴムひもが自然の長さになる瞬間の小球の速さ $v_1$ を求めよ。</li>' +
    '<li>小球は、自然の長さの位置からどれだけ上まで上がるか。</li>' +
    '<li>小球が放した位置に戻るまでの時間（この運動の周期）$T$ を求めよ。</li></ol>';
}
function m4s5Ans() {
  return '<h4 class="exh">時間の流れで見る</h4>' +
    exStrip([['a', 'ⓐ 放した直後', '下の端'], ['b', 'ⓑ つりあいの位置', '速さ最大'], ['c', 'ⓒ 自然の長さ', 'ゴムがたるみ始める'], ['d', 'ⓓ 最高点', '速さ 0'], ['e', 'ⓔ ふたたび自然の長さ', '単振動に戻る']], 210) +
    '<h4 class="exh">解答と解き方</h4>' +
    exQA('(1) つりあいでの伸び', '$l_1 = \\dfrac{mg}{k}$', '<p>' + eqTag('bal') + '$kl_1 = mg$</p>') +
    exQA('(2) 単振動の中心・振幅・角振動数', '中心：つりあいの位置、振幅 $2l_1$、角振動数 $\\omega = \\sqrt{\\dfrac{k}{m}}$', '<p>ゴムが伸びている間は、ばねと同じ。つりあいの位置を原点に上向きを正とすると $ma = -kx$。</p>') +
    exQA('(3) 自然の長さでの速さ', '$v_1 = g\\sqrt{\\dfrac{3m}{k}}$', '<p>自然の長さは $x = l_1$。単振動のエネルギー：$\\dfrac{1}{2}k(2l_1)^2 = \\dfrac{1}{2}mv_1^2 + \\dfrac{1}{2}kl_1^2$ より $v_1 = l_1\\sqrt{\\dfrac{3k}{m}}$。$l_1 = \\dfrac{mg}{k}$ を入れる。</p>') +
    exQA('(4) 最高点', '自然の長さから $\\dfrac{3mg}{2k}$ 上', '<p>ゴムがたるむと重力だけ：投げ上げ。$h = \\dfrac{v_1^2}{2g} = \\dfrac{3mg}{2k}$。</p>') +
    exQA('(5) 周期', '$T = \\dfrac{4\\pi}{3}\\sqrt{\\dfrac{m}{k}} + 2\\sqrt{\\dfrac{3m}{k}}$', '<p>単振動の部分：$x = -2l_1\\cos\\omega t$ が $l_1$ になるのは $\\omega t = \\dfrac{2\\pi}{3}$。上りと下りで $\\dfrac{4\\pi}{3\\omega}$。投げ上げの部分：$\\dfrac{2v_1}{g} = 2\\sqrt{\\dfrac{3m}{k}}$。</p>');
}
function m4s5Fig(key, ctx, W, H) {
  var q = m4s5Q(), t = { setup: 0, a: 0, b: q.Ts / 4, c: q.tA, d: q.tA + q.tF / 2, e: q.tA + q.tF }[key], st = m4s5At(q, t + (key === 'c' ? 1e-4 : 0) - (key === 'e' ? 1e-4 : 0));
  var top = 14, cx = W * 0.42, S = (H - top - 18) / (M45.L0 + q.l1 + q.A + 0.03), Y = function (x) { return top + (M45.L0 + q.l1 - x) * S; }, rb = 7, yb = Y(st.x);
  ceilingAt(ctx, cx - 24, cx + 24, top);
  ctx.save(); ctx.strokeStyle = '#7a4a2a'; ctx.lineWidth = 2;
  if (!st.slack && key !== 'd') { ctx.beginPath(); ctx.moveTo(cx, top); ctx.lineTo(cx, yb - rb); ctx.stroke(); }
  else { var Lc = yb - rb - top, Ls = Y(q.l1) - rb - top, amp = Math.sqrt(Math.max(0, Ls * Ls - Lc * Lc)) * 0.18; ctx.beginPath(); ctx.moveTo(cx, top); for (var i = 1; i <= 30; i++) { var f = i / 30; ctx.lineTo(cx + amp * Math.sin(f * Math.PI * 3), top + f * Lc); } ctx.stroke(); }
  ctx.restore();
  dotted(ctx, 6, Y(q.l1), W - 6, Y(q.l1), 'rgba(20,23,28,.3)', [3, 3]); dotted(ctx, 6, Y(0), W - 6, Y(0), 'rgba(192,57,43,.5)', [3, 3]);
  if (key === 'setup' || key === 'a') { label(ctx, '自然の長さ', W - 6, Y(q.l1) - 7, { size: 9.5, align: 'right', color: '#5d6875' }); label(ctx, 'つりあい', W - 6, Y(0) - 7, { size: 9.5, align: 'right', color: '#c0392b' }); }
  if (key === 'setup') { dimLine(ctx, cx + 30, Y(q.l1), cx + 30, Y(0)); sym(ctx, 'l₁', cx + 38, (Y(q.l1) + Y(0)) / 2, { size: 12, align: 'left' }); dimLine(ctx, cx + 30, Y(0), cx + 30, Y(-q.A)); sym(ctx, '2l₁', cx + 38, (Y(0) + Y(-q.A)) / 2, { size: 12, align: 'left' }); }
  ballShape(ctx, cx, yb, rb, '#d9b77a');
  if (key !== 'setup' && Math.abs(st.v) > 0.03) vArrowAt(ctx, cx, yb, 1, 0, rb + 8, 0, -1, st.v / (q.A * q.w) * 24, false);
}
