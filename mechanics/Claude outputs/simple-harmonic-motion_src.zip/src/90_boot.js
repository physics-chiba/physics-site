/* =========================================================================
   90_boot.js … 自動テスト用の窓口（window.TEST）と検算
   ========================================================================= */
'use strict';
/* x(t) の上向きのゼロ点の間かく（グラフの山と山の間と同じ）から周期を測る */
function measurePeriod(f, T) {
  var dt = T / 2000, ups = [];
  for (var t = 0; t < 3.2 * T; t += dt) { var a = f(t), b = f(t + dt); if (a < 0 && b >= 0) ups.push(t + dt * (-a) / (b - a)); }
  return ups.length >= 2 ? ups[ups.length - 1] - ups[ups.length - 2] : NaN;
}
function check() {
  var out = {};
  /* ①-2：すべての m・k の組で、いまの周期（2π√(m/k)）と x–t の山と山の間が一致 */
  var eT = 0;
  M1.s2.m.forEach(function (m) { M1.s2.k.forEach(function (k) {
    var w = SHM.omega(k, m), T = SHM.period(k, m);
    [0, Math.PI / 2].forEach(function (phi) { eT = Math.max(eT, Math.abs(measurePeriod(function (t) { return SHM.st(0.1, w, phi, t).x; }, T) - T) / T); });
  }); });
  out.m1_period_rel_err = +eT.toExponential(2);
  /* ①-1・①-2：円の上の点 P の高さと、影（①-1）・小球（①-2）の高さが毎フレーム一致（図の座標で） */
  var eP = 0, W = 640, H = 420, g1 = m1s1Geo(W, H);
  for (var t = 0; t < 4; t += 0.013) {
    var th = M1.s1.w * t, py = g1.cy - g1.R * Math.sin(th), sh = g1.cy - SHM.st(M1.s1.A, M1.s1.w, 0, t).x * (g1.R / M1.s1.A);
    eP = Math.max(eP, Math.abs(py - sh));
  }
  var fake = { v: { A: 0.12, m: 1.0, k: 20, phi: 0 }, t: 0 }, G2 = m1s2Geo(W, H);
  PHI.forEach(function (ph) {
    fake.v.phi = ph;
    for (var t2 = 0; t2 < 4; t2 += 0.011) {
      fake.t = t2; var q = m1s2Q(fake), st = SHM.st(q.A, q.w, q.phi, t2), R = q.A * G2.S;
      eP = Math.max(eP, Math.abs((G2.cy - R * Math.sin(st.th)) - m1s2Ball(fake, G2).y));
    }
  });
  out.m1_circle_vs_shadow_px = +eP.toExponential(2);
  /* ①-3：運動エネルギー＋位置エネルギーが一定（½kA²） */
  var eE = 0, f3 = { v: { A: 0.13, phi: -Math.PI / 2 } };
  for (var t3 = 0; t3 < 6; t3 += 0.007) { var s3 = m1s3State(f3, t3); eE = Math.max(eE, Math.abs(s3.E - 0.5 * M1.s3.k * 0.13 * 0.13)); }
  out.m1_energy_drift_J = +eE.toExponential(2);
  /* ===== モード② ===== */
  var O = function (id) { return DEFS[id].O; }, rel = function (a, b) { return Math.abs(a - b) / Math.abs(b); };
  /* 周期：x–t の山と山の間 ＝ 公式。②-2 は 2π√(m/(k₁+k₂))、②-4 は θ によらない、②-6 は 2π√(l/g) で m・θ₀ によらない、②-7 は 2π√(h/g) で S によらない */
  var eT2 = 0, T4 = [], T6 = {}, T7 = [];
  var per = function (id, v, Tf) {
    var f = { v: v, org: 0, t: 0 }, Q = O(id).Q(f);
    eT2 = Math.max(eT2, rel(measurePeriod(function (t) { return SHM.st(Q.A, Q.w, Q.phi, t).x; }, Q.T), Tf), rel(Q.T, Tf));
    return Q.T;
  };
  per('m2s1', { A: 0.1, phi: 0 }, TAU * Math.sqrt(M2.s1.m / M2.s1.k));
  M2.s2.k.forEach(function (k1) { M2.s2.k.forEach(function (k2) { per('m2s2', { k1: k1, k2: k2, A: 0.1, phi: 0 }, TAU * Math.sqrt(M2.s2.m / (k1 + k2))); }); });
  per('m2s3', { A: 0.2, phi: 0 }, TAU * Math.sqrt(M2.s3.m / M2.s3.k));
  M2.s4.th.forEach(function (th) { T4.push(per('m2s4', { th: th, A: 0.1, phi: 0 }, TAU * Math.sqrt(M2.s4.m / M2.s4.k))); });
  M2.s6.l.forEach(function (l) { M2.s6.m.forEach(function (m) { M2.s6.th.forEach(function (th) { var T = per('m2s6', { l: l, m: m, th: th, phi: 0 }, TAU * Math.sqrt(l / G)); T6[l] = T6[l] || []; T6[l].push(T); }); }); });
  M2.s7.S.forEach(function (S) { M2.s7.rb.forEach(function (rb) { M2.s7.d.forEach(function (d) {
    var h = rb * M2.s7.Hb / M2.s7.rho; T7.push([rb, per('m2s7', { S: S, rb: rb, d: d }, TAU * Math.sqrt(h / G))]);
  }); }); });
  out.m2_period_rel_err = +eT2.toExponential(2);
  /* ②-8 地球トンネル：x–t の山と山の間 ＝ 2π√(R/g)、放す位置によらない */
  var eTT = 0; M2T.x0.forEach(function (x0) { var f = { v: { x0: x0 } }, q = m2tQ(f); eTT = Math.max(eTT, rel(measurePeriod(function (t) { return m2tState(f, t).x; }, q.T), TAU * Math.sqrt(M2T.R / G))); });
  out.m2_s8_tunnel_T_rel_err = +eTT.toExponential(2);
  out.m2_s4_T_spread = +(Math.max.apply(null, T4) - Math.min.apply(null, T4)).toExponential(2);
  var sp6 = 0; Object.keys(T6).forEach(function (l) { sp6 = Math.max(sp6, Math.max.apply(null, T6[l]) - Math.min.apply(null, T6[l])); });
  out.m2_s6_T_spread_same_l = +sp6.toExponential(2);
  var sp7 = 0; M2.s7.rb.forEach(function (rb) { var a = T7.filter(function (p) { return p[0] === rb; }).map(function (p) { return p[1]; }); sp7 = Math.max(sp7, Math.max.apply(null, a) - Math.min.apply(null, a)); });
  out.m2_s7_T_spread_same_rho = +sp7.toExponential(2);
  /* x = 0 の切りかえ（②-3・②-4）：図の小球の位置は変わらず、グラフの x だけが d ずれる */
  var eOrg = 0, box = { x0: 0, y0: 0, w: 640, h: 440 };
  [['m2s3', { A: 0.2, phi: Math.PI / 2 }], ['m2s4', { th: 45, A: 0.12, phi: Math.PI / 2 }]].forEach(function (c) {
    for (var t = 0; t < 3; t += 0.037) {
      var f0 = { v: c[1], org: 0, t: t, def: DEFS[c[0]] }, f1 = { v: c[1], org: 1, t: t, def: DEFS[c[0]] };
      var r0 = m2State(f0, t), r1 = m2State(f1, t), g0 = O(c[0]).geo(f0, box), g1 = O(c[0]).geo(f1, box), p0 = g0.pos(r0.X), p1 = g1.pos(r1.X), d = O(c[0]).Q(f1).d;
      eOrg = Math.max(eOrg, Math.hypot(p0.x - p1.x, p0.y - p1.y), Math.abs(r1.x - r0.x - d) * 1000);
    }
  });
  out.m2_org_toggle_err = +eOrg.toExponential(2);
  /* ②-5：振幅は半周期ごとに 2μ′mg/k ずつ減る。止まった位置で |kx| ≤ μmg、止まる直前の端では |kx| > μmg */
  var eF = 0, okStop = true;
  M2.s5.mu.forEach(function (mu) { M2.s5.mu2.forEach(function (mu2) { if (mu <= mu2) return; M2.s5.X0.forEach(function (X0) {
    var F = frictionSegs(M2.s5.m, M2.s5.k, mu, mu2, X0), xs = mu * M2.s5.m * G / M2.s5.k;
    for (var i = 0; i < F.segs.length; i++) {
      var x0 = F.segs[i].x0, x1 = i + 1 < F.segs.length ? F.segs[i + 1].x0 : F.xStop, a0 = Math.abs(x0);
      if (x0 * x1 < 0) eF = Math.max(eF, Math.abs((a0 - Math.abs(x1)) - 2 * mu2 * M2.s5.m * G / M2.s5.k));   /* 中心をこえて反対がわまで行ったとき */
      else eF = Math.max(eF, Math.abs(x0 + x1 - 2 * F.segs[i].c));                                            /* 中心をこえずに止まるとき：中心について対称な位置 */
      if (a0 <= xs) okStop = false;
      var e = frictionAt(F, F.segs[i].t1 - 1e-9); eF = Math.max(eF, Math.abs(e.v) * 1e-3);
    }
    if (Math.abs(F.xStop) > xs + 1e-12) okStop = false;
  }); }); });
  out.m2_s5_decrement_err_m = +eF.toExponential(2); out.m2_s5_stop_ok = okStop;
  /* 力学的エネルギーの保存（②-1〜②-4・②-7 は一定。②-6 は sinθ ≒ θ の近似の分だけ 1 % 以下のずれ） */
  var eE2 = 0, eE6 = 0;
  [['m2s1', { A: 0.15, phi: 0.3 }], ['m2s2', { k1: 5, k2: 20, A: 0.1, phi: 1 }], ['m2s3', { A: 0.3, phi: 0 }], ['m2s4', { th: 60, A: 0.18, phi: 0 }], ['m2s7', { S: 0.01, rb: 0.5e3, d: 0.04 }]].forEach(function (c) {
    var f = { v: c[1], org: 0, def: DEFS[c[0]] }, E0 = null;
    for (var t = 0; t < 4; t += 0.0071) { var r = m2State(f, t); if (E0 === null) E0 = r.E; eE2 = Math.max(eE2, Math.abs(r.E - E0) / E0); }
  });
  var f6 = { v: { l: 1, m: 0.5, th: 15, phi: 0 }, org: 0, def: DEFS.m2s6 }, E6 = null;
  for (var t6 = 0; t6 < 4; t6 += 0.0071) { var r6 = m2State(f6, t6); if (E6 === null) E6 = r6.E; eE6 = Math.max(eE6, Math.abs(r6.E - E6) / E6); }
  out.m2_energy_rel_drift = +eE2.toExponential(2); out.m2_s6_energy_rel_drift = +eE6.toExponential(2);
  /* ===== モード③ ===== */
  var e32 = 0, dv = 0; M3.s2.m.forEach(function (m) { M3.s2.k.forEach(function (k) {
    var f = { v: { m: m, k: k } }, q = m3s2Q(f);
    for (var t = 0; t < 2 * q.T; t += q.T / 97) {
      var r = m3s2State(f, t); e32 = Math.max(e32, Math.abs(r.E - 0.5 * k * q.l0 * q.l0), Math.abs(r.E2));
      var va = Math.sqrt(Math.max(0, k / m * (q.l0 * q.l0 - r.x * r.x))), vb = Math.sqrt(Math.max(0, -2 / m * (r.Ug + r.Ue)));
      dv = Math.max(dv, Math.abs(va - vb), Math.abs(va - Math.abs(r.v)));
    }
  }); });
  out.m3_s2_energy_drift_J = +e32.toExponential(2); out.m3_s2_v_a_vs_b = +dv.toExponential(2);
  /* ===== モード④ ===== */
  var q41 = m4s1Q({ v: { sr: 2.0 } }), st41 = m4s1At(q41, q41.t1);
  out.m4_s1 = { N_at_sep: +st41.N.toExponential(2), x_sep_minus_d: +(st41.xo - q41.d).toExponential(2), v0_err: +(q41.v0 - G * Math.sqrt(6 * q41.M / q41.k)).toExponential(2) };
  var q44 = m4s4Q({ v: { V: 0.3 } }), e44 = m4s4At(q44, q44.tS0 + q44.tSl - 1e-9);
  out.m4_s4 = { x2_err: +(e44.x - q44.x2).toExponential(2), v_at_x2_minus_V: +(e44.v - q44.V).toExponential(2), stick_static_ok: q44.k * q44.x2 <= q44.mu * q44.m * G };
  var q45 = m4s5Q(), e45 = m4s5At(q45, q45.tA - 1e-9);
  out.m4_s5 = { v_nat_err: +(e45.v - G * Math.sqrt(3 * q45.m / q45.k)).toExponential(2), hmax_err: +(q45.hmax - 1.5 * q45.m * G / q45.k).toExponential(2), T_err: +(q45.T - (4 * Math.PI / 3 * Math.sqrt(q45.m / q45.k) + 2 * Math.sqrt(3 * q45.m / q45.k))).toExponential(2) };
  var q42 = m4s2Q({ v: { m1: 1, m2: 2 }, rel: 'seq' }), e0 = m4s2At(q42, q42.tH + 1e-6), e1 = m4s2At(q42, q42.tH + 1.7), p0 = q42.m1 * e0.v1 + q42.m2 * e0.v2, p1 = q42.m1 * e1.v1 + q42.m2 * e1.v2;
  out.m4_s2 = { momentum_drift: +(p1 - p0).toExponential(2), T: +q42.T.toFixed(4), T_formula: +(TAU * Math.sqrt(q42.m1 * q42.m2 / (q42.k * (q42.m1 + q42.m2)))).toFixed(4) };
  out.m1_defaults = { s1_T: +(TAU / M1.s1.w).toFixed(4), s2_w: +SHM.omega(M1.s2.k0, M1.s2.m0).toFixed(4), s2_T: +SHM.period(M1.s2.k0, M1.s2.m0).toFixed(4), s3_T: +SHM.period(M1.s3.k, M1.s3.m).toFixed(4), s3_E: +(0.5 * M1.s3.k * M1.s3.A * M1.s3.A).toFixed(5) };
  return out;
}
window.TEST = {
  check: check,
  sim: function (id) { return SIM_BY_ID[id]; },
  sims: function () { return SIMS.map(function (s) { return s.def.id; }); }
};
