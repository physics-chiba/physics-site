/* =========================================================================
   47_graph.js … x–t・v–t・a–t（とエネルギー–t）のグラフを縦に重ねる（spring-launch.html と同じ考え）
   ・グラフはあらかじめ描かず、アニメと同時に描いていく。右端（窓の長さ Tw）まで行ったら、
     左に戻って、それまでのグラフを太い線でなぞる（前の回の線はそのまま残す）
   ・3 つのグラフに、いまの時刻の縦線（灰色の破線）。t 軸の目盛りは T/4・T/2・3T/4・T …
   ・experiment-graph-ui：枠の中をドラッグ＝移動（横はグラフ全部で共有、縦はそのグラフだけ）、
     縦軸の目盛り＝縦の拡大縮小、横軸の目盛り＝横の拡大縮小、「スケールをリセット」。ホイールは使わない
   ・軸には矢印。縦軸は必ず 0 を含み、上下に余裕。枠の外は描かない（clip）
   ========================================================================= */
'use strict';
var ECOL = { K: '#22a465', U: '#63390c', E: '#38475a' };       /* エネルギーの 3 色（エネルギーのグラフの作り方.md） */
var XCOL = '#1c8f4a';                                        /* 変位 x（変位ベクトル）は緑（添付動画と同じ。力・速度・加速度の色は使わない） */
var GPAD = { l: 52, r: 16, t: 20, b: 26 };
function niceStep(range, target) {
  var raw = range / target, p = Math.pow(10, Math.floor(Math.log(raw) / Math.LN10)), c = [1, 2, 2.5, 5, 10];
  for (var i = 0; i < c.length; i++) if (raw <= c[i] * p * 1.0001) return c[i] * p;
  return 10 * p;
}
/* 0 を必ず入れた、きりのいい範囲。データが端まで 0.55 目盛り以内なら 1 目盛り外へ（0 がわの端はのばさない） */
function niceRange(lo, hi) {
  var dlo = lo, dhi = hi;
  lo = Math.min(lo, 0); hi = Math.max(hi, 0); if (hi - lo < 1e-12) hi = lo + 1;
  var st = niceStep(hi - lo, 4), a = Math.floor(lo / st + 1e-9) * st, b = Math.ceil(hi / st - 1e-9) * st;
  if (dhi > 1e-12 && dhi > b - st * 0.55) b += st;
  if (dlo < -1e-12 && dlo < a + st * 0.55) a -= st;
  return { lo: a, hi: b, step: st };
}
/* グラフ一式を s.gHost に作る。
   defs = [{ key, title, ysym, yunit, series:[{ name, color, width, dash, f(q) }], range(s) → {lo, hi}, val(q) → 見出しの値 }]
   s.def.gq(s, t)＝その時刻の状態、s.def.gWin(s)＝窓の長さ、s.def.gT(s)＝周期（t 軸の目盛り） */
function shmGraphs(s, defs) {
  var host = s.gHost; host.innerHTML = '';
  s.graphs = [];
  /* 「ドラッグで移動・目盛りをドラッグで拡大縮小」と「スケールをリセット」は、モード①・② では使わないので出さない（2026-10-16 千葉さん） */
  defs.forEach(function (d) {
    var box = el('div', 'gbox g-' + d.key), hd = el('div', 'ghead');
    hd.appendChild(el('span', 'gt', mathify(d.title)));
    var vv = el('span', 'gsel', ''); hd.appendChild(vv);
    box.appendChild(hd);
    var cv = el('canvas', 'gcv'); box.appendChild(cv);
    if (d.series.length > 1) box.appendChild(el('div', 'gleg', d.series.map(function (q) {
      return '<span><i style="border-top:' + (q.width || 2) + 'px ' + (q.dash ? 'dashed' : 'solid') + ' ' + q.color + '"></i>' + mathify(q.name) + '</span>';
    }).join('')));
    (d.host ? d.host(s) : host).appendChild(box);           /* d.host：このグラフだけ別の場所に置く（モード② のエネルギー − t グラフ） */
    var g = { d: d, cv: cv, box: box, vv: vv };
    s.graphs.push(g);
  });
  shmGraphReset(s);
}
/* 窓の長さ・縦の範囲を最初に戻す（量を変えたときも呼ぶ） */
function shmGraphReset(s) {
  var Tw = s.def.gWin(s);
  s.gx = { lo: 0, hi: Tw }; s._gTw = Tw;
  (s.graphs || []).forEach(function (g) { var r = g.d.range(s); g.yr = niceRange(r.lo, r.hi); g.Wc = 0; g.user = false; });
}
function shmRect(g) { return { x0: GPAD.l, x1: g.W - GPAD.r, y0: GPAD.t, y1: g.H - GPAD.b }; }
function shmBindGraph(s, g) {
  var down = null;
  g.cv.addEventListener('pointerdown', function (ev) {
    var b = g.cv.getBoundingClientRect(), x = ev.clientX - b.left, y = ev.clientY - b.top, R = shmRect(g);
    var zone = (x < R.x0) ? 'y' : (y > R.y1 ? 'x' : 'pan');
    down = { x: ev.clientX, y: ev.clientY, zone: zone, moved: false, gx: { lo: s.gx.lo, hi: s.gx.hi }, yr: { lo: g.yr.lo, hi: g.yr.hi } };
    g.cv.setPointerCapture(ev.pointerId); ev.preventDefault();
  });
  g.cv.addEventListener('pointermove', function (ev) {
    if (!down) return;
    var dx = ev.clientX - down.x, dy = ev.clientY - down.y, R = shmRect(g);
    if (Math.hypot(dx, dy) > 3) down.moved = true;
    if (!down.moved) return;
    g.user = true;
    var sx = (down.gx.hi - down.gx.lo) / (R.x1 - R.x0), sy = (down.yr.hi - down.yr.lo) / (R.y1 - R.y0);
    if (down.zone === 'pan') {
      s.gx.lo = down.gx.lo - dx * sx; s.gx.hi = down.gx.hi - dx * sx;
      g.yr = { lo: down.yr.lo + dy * sy, hi: down.yr.hi + dy * sy, step: g.yr.step };
    } else if (down.zone === 'x') {
      var f = Math.exp(-dx * 0.01), c = (down.gx.lo + down.gx.hi) / 2, h = (down.gx.hi - down.gx.lo) / 2 * f;
      s.gx.lo = c - h; s.gx.hi = c + h;
    } else {
      var f2 = Math.exp(dy * 0.01), c2 = (down.yr.lo + down.yr.hi) / 2, h2 = (down.yr.hi - down.yr.lo) / 2 * f2;
      g.yr = { lo: c2 - h2, hi: c2 + h2 };
    }
    shmDrawGraphs(s);
  });
  var up = function () { down = null; };
  g.cv.addEventListener('pointerup', up);
  g.cv.addEventListener('pointercancel', up);
}
function shmDrawGraphs(s) {
  if (!s.graphs) return;
  if (Math.abs(s.def.gWin(s) - s._gTw) > 1e-9) shmGraphReset(s);    /* 周期が変わった */
  s.graphs.forEach(function (g) { shmDrawGraph(s, g); });
}
/* t 軸の目盛りの文字（T の分数）。n/4 を約分して T/4・T/2・3T/4・T・5T/4 … */
function tFracLabel(ctx, n, x, y) {
  var g = function (a, b) { return b ? g(b, a % b) : a; }, d = 4, k = g(n, d), nn = n / k, dd = d / k;
  ctx.save(); ctx.fillStyle = '#5d6875'; ctx.textAlign = 'center';
  var num = (nn === 1 ? '' : String(nn));
  if (dd === 1) {                                              /* T・2T */
    ctx.textBaseline = 'top'; ctx.font = '600 10.5px ' + SER; var w0 = ctx.measureText(num).width;
    ctx.font = 'italic 11.5px ' + MATH; var w1 = ctx.measureText('T').width, X = x - (w0 + w1) / 2;
    ctx.textAlign = 'left'; ctx.font = '600 10.5px ' + SER; ctx.fillText(num, X, y + 3);
    ctx.font = 'italic 11.5px ' + MATH; ctx.fillText('T', X + w0, y + 2);
  } else {                                                     /* 分数：分子 nT、分母 dd */
    ctx.textBaseline = 'alphabetic'; ctx.font = '600 9.5px ' + SER; var a0 = ctx.measureText(num).width;
    ctx.font = 'italic 10.5px ' + MATH; var a1 = ctx.measureText('T').width, X2 = x - (a0 + a1) / 2;
    ctx.textAlign = 'left'; ctx.font = '600 9.5px ' + SER; ctx.fillText(num, X2, y + 10);
    ctx.font = 'italic 10.5px ' + MATH; ctx.fillText('T', X2 + a0, y + 10);
    ctx.strokeStyle = '#5d6875'; ctx.lineWidth = 0.9; var hw = Math.max(5, (a0 + a1) / 2 + 1);
    ctx.beginPath(); ctx.moveTo(x - hw, y + 12.5); ctx.lineTo(x + hw, y + 12.5); ctx.stroke();
    ctx.textAlign = 'center'; ctx.font = '600 9.5px ' + SER; ctx.fillText(String(dd), x, y + 22);
  }
  ctx.restore();
}
function shmDrawGraph(s, g) {
  if (!g.cv.isConnected || !g.cv.offsetParent) return;
  if (!g.Wc) g.Wc = Math.max(200, Math.floor(g.cv.clientWidth || g.box.clientWidth || 300));
  var W = g.Wc, H = g.d.H ? g.d.H(s) : (s.def.gH ? s.def.gH(s) : 112);
  g.W = W; g.H = H; g.cv.style.height = H + 'px';
  var R = shmRect(g), d = g.d;
  if (d.scale && !g.user) {                                    /* アニメのベクトルと同じ長さ（px）で描く：縦の範囲は縮尺から決める */
    var sc = d.scale(s), hh = (R.y1 - R.y0) / 2 / sc; g.yr = { lo: -hh, hi: hh };
  }
  var gx = s.gx, yr = g.yr, dpr = Math.min(2, Math.max(1, window.devicePixelRatio || 1));
  var Tw = s._gTw, T = s.def.gT ? s.def.gT(s) : null;
  var X = function (t) { return R.x0 + (t - gx.lo) / (gx.hi - gx.lo) * (R.x1 - R.x0); };
  var Y = function (y) { return R.y1 - (y - yr.lo) / (yr.hi - yr.lo) * (R.y1 - R.y0); };
  /* 動かない部分（目盛り・軸）は、範囲が変わったときだけ別の canvas に描いておく */
  var key = [W, H, dpr, gx.lo, gx.hi, yr.lo, yr.hi, T].join('|');
  if (g._key !== key || !g.layer) {
    g._key = key;
    if (!g.layer) g.layer = document.createElement('canvas');
    g.layer.width = Math.round(W * dpr); g.layer.height = Math.round(H * dpr);
    var ctx = g.layer.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.lineJoin = 'round';
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H);
    /* 縦軸の数字は、グラフの高さに合わせて 3 つくらい（細かくしない。2026-10-16 千葉さん） */
    var mx = clamp(Math.floor((R.y1 - R.y0) / 22), 3, 5), sy = yr.step || niceStep(yr.hi - yr.lo, 4);
    var nTk = function (st) { return Math.floor(yr.hi / st + 1e-9) - Math.ceil(yr.lo / st - 1e-9) + 1; };
    for (var kk = 0; kk < 12 && nTk(sy) > mx; kk++) sy = niceStep(sy * 1.2, 1);       /* 数字は 3〜5 個まで */
    ctx.save(); ctx.strokeStyle = '#eef0f2'; ctx.lineWidth = 1;
    ctx.font = '600 10px ' + FONT; ctx.fillStyle = '#5d6875'; ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    for (var ty = Math.ceil(yr.lo / sy - 1e-9) * sy; ty <= yr.hi + 1e-9; ty += sy) {
      var py = Y(ty); ctx.beginPath(); ctx.moveTo(R.x0, py); ctx.lineTo(R.x1, py); ctx.stroke();
      ctx.fillText(fmtTick(ty, sy), R.x0 - 5, py);
    }
    /* t の目盛り：T/4 ごと（せまいときは T/2・T ごと） */
    if (T) {
      var q = T / 4, px1 = (R.x1 - R.x0) / (gx.hi - gx.lo) * q, every = px1 >= 30 ? 1 : (px1 >= 15 ? 2 : 4);
      for (var n = Math.ceil(gx.lo / q - 1e-9); n * q <= gx.hi + 1e-9; n++) {
        if (n <= 0) continue;
        var px = X(n * q);
        ctx.strokeStyle = (n % 4 === 0) ? '#e2e5e9' : '#f1f3f5'; ctx.beginPath(); ctx.moveTo(px, R.y0); ctx.lineTo(px, R.y1); ctx.stroke();
        if (n % every === 0) tFracLabel(ctx, n, px, R.y1 + 1);
      }
    } else {
      var sx = niceStep(gx.hi - gx.lo, 5); ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      for (var tx = Math.ceil(gx.lo / sx) * sx; tx <= gx.hi + 1e-9; tx += sx) { var pxx = X(tx); ctx.beginPath(); ctx.moveTo(pxx, R.y0); ctx.lineTo(pxx, R.y1); ctx.stroke(); ctx.fillText(fmtTick(tx, sx), pxx, R.y1 + 4); }
    }
    ctx.restore();
    /* 軸（矢印つき）。横軸は y = 0、縦軸は t = 0 */
    var ax = clamp(Y(0), R.y0, R.y1), ay = clamp(X(0), R.x0, R.x1);
    ctx.save(); ctx.strokeStyle = '#2b323c'; ctx.fillStyle = '#2b323c'; ctx.lineWidth = 1.3;
    ctx.beginPath(); ctx.moveTo(R.x0, ax); ctx.lineTo(R.x1 + 4, ax); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(R.x1 + 9, ax); ctx.lineTo(R.x1 + 1, ax - 4); ctx.lineTo(R.x1 + 1, ax + 4); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(ay, R.y1); ctx.lineTo(ay, R.y0 - 2); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(ay, R.y0 - 8); ctx.lineTo(ay - 4, R.y0); ctx.lineTo(ay + 4, R.y0); ctx.closePath(); ctx.fill();
    ctx.font = 'italic 12px ' + MATH; ctx.textAlign = 'right'; ctx.textBaseline = 'bottom'; ctx.fillText('t', R.x1 + 9, ax - 4);
    /* 縦軸の名前（記号と単位）：左上 */
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.font = 'italic 12px ' + MATH; ctx.fillText(d.ysym, 4, 0);
    var wsym = ctx.measureText(d.ysym).width; ctx.font = '600 9.5px ' + FONT; ctx.fillText('〔' + d.yunit + '〕', 4 + wsym + 1, 1);
    ctx.restore();
  }
  var c2 = prep(g.cv, W, H);
  c2.drawImage(g.layer, 0, 0, W, H);
  c2.save(); c2.beginPath(); c2.rect(R.x0, R.y0 - 2, R.x1 - R.x0, R.y1 - R.y0 + 4); c2.clip();
  /* 曲線：pass 回目。前の回はそのまま、いまの回（0〜tc）を太くなぞる */
  var t = s.t, pass = Math.floor(t / Tw + 1e-9), tc = t - pass * Tw, N = 320;
  if (s.ended && pass > 0 && tc < 1e-6) { pass -= 1; tc = Tw; }
  /* 軽くするため（2026-10-16 千葉さん）：1 回ぶん（窓の長さ）の値を、条件が変わったときだけ計算しておき、毎フレームはそれをなぞるだけにする */
  var sig = [pass, Tw, W, H, JSON.stringify(s.v), s.org || 0, s.dragX === undefined ? '' : s.dragX].join('|');
  if (g._sig !== sig) {
    g._sig = sig; g._pts = {};
    [pass - 1, pass].forEach(function (pp) {
      if (pp < 0) return;
      var sts = []; for (var i = 0; i <= N; i++) sts.push(s.def.gq(s, pp * Tw + Tw * i / N));
      d.series.forEach(function (q) { g._pts[q.name + '@' + pp] = sts.map(function (st) { return q.f(st); }); });
    });
  }
  var curve = function (q, base, g0, g1, lw, alpha) {
    if (g1 <= g0) return;
    var arr = g._pts[q.name + '@' + Math.round(base / Tw)];
    c2.save(); c2.strokeStyle = q.color; c2.lineWidth = lw; c2.globalAlpha = alpha; c2.setLineDash(q.dash || []); c2.lineJoin = 'round'; c2.beginPath();
    var iEnd = Math.min(N, Math.floor(g1 / Tw * N + 1e-9));
    for (var i = 0; i <= iEnd; i++) { var gg = Tw * i / N; if (i) c2.lineTo(X(gg), Y(arr[i])); else c2.moveTo(X(gg), Y(arr[i])); }
    if (g1 > Tw * iEnd / N + 1e-9) c2.lineTo(X(g1), Y(q.f(s.def.gq(s, base + g1))));   /* いまの点まで */
    c2.stroke(); c2.restore();
  };
  var started = s.t > 0 || s.playing;
  if (started) d.series.forEach(function (q) {
    var w = q.width || 2;
    if (pass > 0) curve(q, (pass - 1) * Tw, 0, Tw, w, 0.55);      /* 前の回（うすめ） */
    curve(q, pass * Tw, 0, tc, w + (pass > 0 ? 0.9 : 0), 1);      /* いまの回（2 回目からは太くなぞる） */
  });
  /* いまの時刻の縦線（灰色の破線）と点 */
  var xc = X(tc);
  c2.strokeStyle = 'rgba(93,104,117,.75)'; c2.lineWidth = 1.2; c2.setLineDash([4, 3]); c2.beginPath(); c2.moveTo(xc, R.y0); c2.lineTo(xc, R.y1); c2.stroke(); c2.setLineDash([]);
  var q0 = s.def.gq(s, t);
  if (started) d.series.forEach(function (q) {
    var yv = Y(q.f(q0)), y0 = Y(0);
    if (d.arrow && Math.abs(yv - y0) > 3) {                   /* いまの値を、アニメのベクトルと同じ長さの矢印で */
      var hd = Math.min(9, Math.abs(yv - y0) * 0.6), sg = yv < y0 ? -1 : 1;
      c2.save(); c2.strokeStyle = q.color; c2.fillStyle = q.color; c2.lineWidth = 3; c2.beginPath(); c2.moveTo(xc, y0); c2.lineTo(xc, yv - sg * hd); c2.stroke();
      c2.beginPath(); c2.moveTo(xc, yv); c2.lineTo(xc - 4.5, yv - sg * hd); c2.lineTo(xc + 4.5, yv - sg * hd); c2.closePath(); c2.fill(); c2.restore();
    } else { c2.fillStyle = q.color; c2.beginPath(); c2.arc(xc, yv, 3.4, 0, TAU); c2.fill(); }
  });
  c2.restore();
  /* 見出しの数値（KaTeX にするので重い）：再生中は 1 秒に 6 回まで */
  var nowT = performance.now();
  if (!s.playing || !g._vT || nowT - g._vT > 160) {
    g._vT = nowT;
    var vt = d.val ? d.val(q0) : '';
    if (g.vv._h !== vt) { g.vv._h = vt; g.vv.innerHTML = mathify(vt); }
  }
}
function fmtTick(v, st) {
  var dg = Math.max(0, -Math.floor(Math.log(st) / Math.LN10 + 1e-9) + (Math.abs(st / Math.pow(10, Math.floor(Math.log(st) / Math.LN10 + 1e-9)) - 2.5) < 1e-6 ? 1 : 0));
  var s = v.toFixed(Math.min(4, dg)); if (/^-0(\.0*)?$/.test(s)) s = s.slice(1);
  return s.replace('-', '−');
}
/* x–t・v–t・a–t の 3 枚（ysign：x の正の向きのことば） */
function xvaDefs(s) {
  return [
    { key: 'x', title: '$x$–$t$ グラフ', ysym: 'x', yunit: 'm', series: [{ name: 'x', color: XCOL, width: 2.2, f: function (q) { return q.x; } }],
      range: function (s) { var M = s.def.gAmp(s).x; return { lo: -M, hi: M }; }, val: function (q) { return '$x =$ ' + fmt(q.x, 3) + ' m'; } },
    { key: 'v', title: '$v$–$t$ グラフ', ysym: 'v', yunit: 'm/s', series: [{ name: 'v', color: COL.vel, width: 2.2, f: function (q) { return q.v; } }],
      range: function (s) { var M = s.def.gAmp(s).v; return { lo: -M, hi: M }; }, val: function (q) { return '$v =$ ' + fmt(q.v, 3) + ' m/s'; } },
    { key: 'a', title: '$a$–$t$ グラフ', ysym: 'a', yunit: 'm/s²', series: [{ name: 'a', color: COL.acc, width: 2.2, f: function (q) { return q.a; } }],
      range: function (s) { var M = s.def.gAmp(s).a; return { lo: -M, hi: M }; }, val: function (q) { return '$a =$ ' + fmt(q.a, 2) + ' m/s²'; } }
  ];
}
/* エネルギー–t（K・U・E）。描く順は E → U → K（重なっても K が消えない） */
function energyDef() {
  return { key: 'E', title: 'エネルギー–$t$ グラフ', ysym: 'E', yunit: 'J',
    series: [
      { name: '力学的エネルギー $E$', color: ECOL.E, width: 3.2, f: function (q) { return q.E; } },
      { name: '位置エネルギー $U$', color: ECOL.U, width: 2, dash: [7, 4], f: function (q) { return q.U; } },
      { name: '運動エネルギー $K$', color: ECOL.K, width: 2, f: function (q) { return q.K; } }],
    range: function (s) { return { lo: 0, hi: s.def.gAmp(s).E }; },
    val: function (q) { return '$K$ ' + fmt(q.K, 3) + '　$U$ ' + fmt(q.U, 3) + '　$E$ ' + fmt(q.E, 3) + ' J'; } };
}
