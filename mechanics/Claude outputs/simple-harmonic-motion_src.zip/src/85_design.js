/* =========================================================================
   デザイン試作の動き（2026-10）
   ・ヒーローのステージ：等速円運動・鉛直ばね振り子・右へ流れるストロボを並べて、単振動は等速円運動の影であることを見せる。
   ・スライドバーの塗り（--p）、タブ列の下の進み具合（--prog）。
   ・画面に見えていないとき・動きを減らす設定のときは動かさない（重くしない：第 21 回の教訓）。
   ========================================================================= */
(function(){
  "use strict";
  const RM = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const MATH = '"KaTeX_Math","KaTeX_Main",serif',
        JP = '"Hiragino Sans","Hiragino Kaku Gothic ProN","Yu Gothic",YuGothic,"Noto Sans JP",Meiryo,sans-serif';

  /* ===== ヒーローのステージ（案 B）：等速円運動（左）・鉛直ばね振り子（中）・右へ流れるストロボ（右、教科書 図 58） =====
     円の上の点の高さと、おもりの高さを点線で結ぶ（いつも同じ高さ＝単振動は等速円運動の影）。
     おもりの位置を一定の時間ごとに右へ並べていくと、正弦曲線になる。 */
  function initStage(){
    const cv = document.getElementById("heroCv"); if(!cv) return;
    const ctx = cv.getContext("2d");
    const C = { ink:"#0a2540", dim:"rgba(10,37,64,.55)", faint:"rgba(10,37,64,.16)", ball:"#7fd3f0", rim:"#0e5c86", brand:"#0e5c86", link:"rgba(54,182,232,.95)", ray:"rgba(54,182,232,.09)" };   /* 水色を基調に（2026-10-25 千葉さん） */
    let W=0, H=0, dpr=1, run=false, raf=0, last=0, t=0, paused=false, rate=1;
    const OM = 2.2, PER = 2*Math.PI/OM;
    let g = null;
    function setup(){
      const r = cv.getBoundingClientRect(); dpr = Math.min(2, window.devicePixelRatio||1);
      W = Math.max(280, r.width); H = Math.max(170, r.height);
      cv.width = Math.round(W*dpr); cv.height = Math.round(H*dpr); ctx.setTransform(dpr,0,0,dpr,0,0);
      const R = Math.min(H*0.30, W*0.10), cy = H*0.53, cx = Math.max(R + 22, W*0.10);
      const xs = cx + R + Math.max(46, W*0.10), x0 = xs + Math.max(34, W*0.06), x1 = W - 22;
      g = { R, cy, cx, xs, x0, x1, top: 12, flow: Math.max(40, (x1 - x0)/(2.4*PER)) };
    }
    function text(s,x,y,col,size,al,bold){ ctx.save(); ctx.fillStyle=col; ctx.font=(bold?"700 ":"600 ")+size+"px "+JP; ctx.textAlign=al||"center"; ctx.textBaseline="middle"; ctx.fillText(s,x,y); ctx.restore(); }
    function ball(x,y,r,a){ ctx.save(); ctx.globalAlpha=a; const gr=ctx.createRadialGradient(x-r*.35,y-r*.4,r*.1,x,y,r); gr.addColorStop(0,"#fff"); gr.addColorStop(.3,C.ball); gr.addColorStop(1,C.rim);
      ctx.fillStyle=gr; ctx.beginPath(); ctx.arc(x,y,r,0,7); ctx.fill(); ctx.restore(); }
    function coil(x,y1,y2){                 /* コイルを横から見たばね */
      const L=y2-y1, r=7, lead=6, b=r*0.55, n=Math.max(6, Math.round((g.cy-g.top-2*lead-2*b)/(1.15*b)+0.5)), p=Math.max(0.6,(L-2*lead-2*b)/(n-0.5));
      ctx.save(); ctx.strokeStyle="rgba(10,37,64,.42)"; ctx.lineWidth=0.9; ctx.beginPath(); ctx.moveTo(x,y1);
      const t0=-Math.PI/2, t1=Math.PI/2+2*Math.PI*(n-1);
      for(let i=0;i<=n*36;i++){ const tt=t0+(t1-t0)*i/(n*36), al=lead+b+p*(tt+Math.PI/2)/(2*Math.PI)+b*Math.sin(tt); ctx.lineTo(x+r*Math.cos(tt), y1+al); }
      ctx.lineTo(x,y2); ctx.stroke(); ctx.restore();
    }
    function draw(tt){
      if(!g) return;
      const { R, cy, cx, xs, x0, x1, top, flow } = g;
      ctx.clearRect(0,0,W,H);
      const th = OM*tt, px = cx + R*Math.cos(th), py = cy - R*Math.sin(th), rb = Math.max(7, R*0.16);
      /* 左から差しこむ平行な光（円を照らし、その影が右に落ちる） */
      ctx.save(); ctx.strokeStyle=C.ray; ctx.lineWidth=1; for(let y=cy-R-6; y<=cy+R+6; y+=11){ ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(cx+R+4, y); ctx.stroke(); } ctx.restore();
      /* つりあいの位置（振動の中心）の線 */
      ctx.save(); ctx.strokeStyle=C.faint; ctx.setLineDash([5,5]); ctx.beginPath(); ctx.moveTo(cx-R-8, cy); ctx.lineTo(x1, cy); ctx.stroke(); ctx.restore();
      /* 右：ストロボ（一定の時間ごとのおもりの位置が右へ流れる） */
      const dt = PER/11, k1 = Math.floor(tt/dt);
      ctx.save(); ctx.beginPath(); ctx.rect(x0-rb-2, 0, x1-x0+rb+4, H); ctx.clip();
      const tg = ctx.createLinearGradient(x0, 0, x1, 0); tg.addColorStop(0, "rgba(14,92,134,.85)"); tg.addColorStop(1, "rgba(127,211,240,.35)");   /* 影の軌跡：手前ほど濃く */
      ctx.strokeStyle=tg; ctx.lineWidth=2; ctx.beginPath();
      for(let i=0;i<=160;i++){ const ti = tt - i*(x1-x0)/flow/160; if(ti<0) break; const X = x0 + (tt-ti)*flow, Y = cy - R*Math.sin(OM*ti); i? ctx.lineTo(X,Y) : ctx.moveTo(X,Y); }
      ctx.stroke();
      for(let k=k1; k>=0; k--){ const ti = k*dt, X = x0 + (tt-ti)*flow; if(X > x1+rb) break; ball(X, cy - R*Math.sin(OM*ti), rb*0.62, 0.12 + 0.78*Math.pow(Math.max(0, 1-(X-x0)/(x1-x0)), 1.4)); }   /* 古い影ほど薄く、小さめの粒に */
      ctx.restore();
      text("時間の経過 →", x1-4, H-12, C.dim, 11, "right");
      /* 中：鉛直ばね振り子 */
      ctx.save(); ctx.strokeStyle=C.dim; ctx.lineWidth=1.4; ctx.beginPath(); ctx.moveTo(xs-26, top); ctx.lineTo(xs+26, top); ctx.stroke();
      ctx.lineWidth=1; for(let x=xs-26+6; x<=xs+26; x+=7){ ctx.beginPath(); ctx.moveTo(x, top); ctx.lineTo(x-6, top-7); ctx.stroke(); } ctx.restore();
      coil(xs, top, py - rb);
      /* 円の点 P とおもりを結ぶ高さの線 */
      ctx.save(); ctx.strokeStyle=C.link; ctx.lineWidth=1.3; ctx.setLineDash([3,4]); ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(x0, py); ctx.stroke(); ctx.restore();
      ball(xs, py, rb, 1);
      /* 左：等速円運動 */
      ctx.save(); ctx.strokeStyle=C.dim; ctx.lineWidth=1.3; ctx.beginPath(); ctx.arc(cx, cy, R, 0, 7); ctx.stroke();
      ctx.strokeStyle="rgba(10,37,64,.5)"; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(px, py); ctx.stroke();
      ctx.save(); const hl = ctx.createRadialGradient(px, py, 0, px, py, rb*2.4); hl.addColorStop(0, "rgba(54,182,232,.35)"); hl.addColorStop(1, "rgba(54,182,232,0)"); ctx.fillStyle=hl; ctx.beginPath(); ctx.arc(px, py, rb*2.4, 0, 7); ctx.fill(); ctx.restore();   /* 光を受ける点 P */
      ctx.fillStyle=C.ink; ctx.beginPath(); ctx.arc(cx, cy, 2.4, 0, 7); ctx.fill(); ctx.restore();
      ball(px, py, rb*0.8, 1);
      /* 振幅 A（つりあいの位置から上端まで） */
      const xa = xs + rb + 16;
      ctx.save(); ctx.strokeStyle=C.brand; ctx.fillStyle=C.brand; ctx.lineWidth=1.2; ctx.setLineDash([3,3]); ctx.beginPath(); ctx.moveTo(xa, cy); ctx.lineTo(xa, cy-R); ctx.stroke(); ctx.setLineDash([]);
      [[cy,1],[cy-R,-1]].forEach(([y,sg])=>{ ctx.beginPath(); ctx.moveTo(xa, y); ctx.lineTo(xa-3.5, y+6*sg*-1); ctx.lineTo(xa+3.5, y+6*sg*-1); ctx.closePath(); ctx.fill(); });
      ctx.font="italic 13px "+MATH; ctx.textAlign="left"; ctx.textBaseline="middle"; ctx.fillText("A", xa+5, cy-R/2); ctx.restore();
      text("等速円運動", cx, Math.min(H-12, cy+R+16), C.dim, 11);
      text("ばね振り子", xs, Math.min(H-12, cy+R+16), C.dim, 11);
      if(W > 520) text("つりあいの位置", (cx+R+xs)/2, cy+11, "rgba(10,37,64,.45)", 10.5);
    }
    function frame(ts){
      if(!run) return;
      const dtm = last? Math.min(0.05,(ts-last)/1000) : 0; last = ts;
      t += dtm*rate; draw(t);
      raf = requestAnimationFrame(frame);
    }
    function start(){ if(run || RM || paused) return; run = true; last = 0; raf = requestAnimationFrame(frame); }
    function stop(){ run = false; cancelAnimationFrame(raf); }
    setup(); t = 2.4*PER; draw(t);
    window.__hero = { frame:(tt)=>{ stop(); t = tt; draw(tt); }, start, stop };
    let rz = 0; window.addEventListener("resize", ()=>{ clearTimeout(rz); rz = setTimeout(()=>{ setup(); draw(t); }, 120); });
    if("IntersectionObserver" in window){
      new IntersectionObserver((es)=>{ es.forEach(en=>{ (en.isIntersecting && !document.hidden)? start() : stop(); }); }, {threshold:0.05}).observe(cv);
    } else start();
    document.addEventListener("visibilitychange", ()=>{ if(document.hidden) stop(); else { const r=cv.getBoundingClientRect(); if(r.bottom>0 && r.top<innerHeight) start(); } });
    const ctl = document.querySelector("#hero .stagectl");
    if(ctl){
      const pp = ctl.querySelector(".pp"), sl = ctl.querySelector(".slow");
      if(sl){ if(RM) sl.hidden = true;
        sl.addEventListener("click", ()=>{ rate = (rate===1? 0.3 : 1); sl.setAttribute("aria-pressed", rate<1? "true" : "false"); }); }
      if(pp){ if(RM){ pp.hidden = true; }
        pp.addEventListener("click", ()=>{ paused = !paused; pp.classList.toggle("paused", paused); pp.setAttribute("aria-label", paused? "再生" : "一時停止");
          if(paused){ stop(); draw(t); } else { start(); } }); }
    }
    /* 図の再生を始めたら止める（同時に動くのは 1 つだけ） */
    document.addEventListener("click", (ev)=>{ if(ev.target.closest && ev.target.closest("button.b.play")) stop(); }, true);
  }

  /* スライドバーの塗り：値が変わったら --p を書きかえる（プログラムから値を入れたときも、軽い見回りで拾う） */
  function syncRange(el){ const mn = parseFloat(el.min)||0, mx = parseFloat(el.max), v = parseFloat(el.value);
    const p = (isFinite(mx) && mx>mn)? (v-mn)/(mx-mn)*100 : 0; const s = p.toFixed(1)+"%";
    if(el._p !== s){ el._p = s; el.style.setProperty("--p", s); } }
  function initRanges(){
    document.addEventListener("input", (ev)=>{ if(ev.target && ev.target.type === "range") syncRange(ev.target); }, true);
    const sweep = ()=>{ if(document.hidden) return; document.querySelectorAll(".mode.on input[type=range], .modebar input[type=range]").forEach(syncRange); alignTicks(); };
    sweep(); setInterval(sweep, 120);
  }

  /* スライドバーの下の目盛りの文字（e=0・e=0.5・e=1）を、つまみの位置にきっちり合わせる（第 29 回）
     文字の列を「左右の余白」で合わせていたので、ラベルやボタンの幅が変わるとずれていた。
     スライドバーの実際の位置と幅を測り、つまみの中心が来る位置に 1 つずつ置く（等間隔の目盛りとして） */
  function alignTicks(){
    document.querySelectorAll(".mode.on .vrow.ticks, .modebar .vrow.ticks").forEach(tr=>{
      let row = tr.previousElementSibling; while(row && !row.querySelector("input[type=range]")) row = row.previousElementSibling;
      const inp = row && row.querySelector("input[type=range]"); if(!inp) return;
      const ri = inp.getBoundingClientRect(); if(ri.width < 10) return;
      tr.classList.add("tk-on");
      const rt = tr.getBoundingClientRect(), TH = 9, sp = tr.children, n = sp.length;
      const key = Math.round(ri.left - rt.left)+":"+Math.round(ri.width); if(tr._tk === key) return; tr._tk = key;
      for(let i=0; i<n; i++){ const f = n>1? i/(n-1) : 0.5; sp[i].style.left = (ri.left - rt.left + TH + f*(ri.width - 2*TH)).toFixed(1)+"px"; }
    });
  }
  window.addEventListener("resize", ()=>{ document.querySelectorAll(".vrow.ticks").forEach(t=>{ t._tk = null; }); alignTicks(); });

  /* タブ列の下の進み具合 */
  function initProgress(){
    const nav = document.getElementById("tabs"); if(!nav) return;
    let pend = false;
    const upd = ()=>{ pend = false; const h = document.documentElement, max = h.scrollHeight - innerHeight;
      nav.style.setProperty("--prog", max>0? Math.min(1, Math.max(0, scrollY/max)).toFixed(4) : 0); };
    window.addEventListener("scroll", ()=>{ if(!pend){ pend = true; requestAnimationFrame(upd); } }, {passive:true});
    window.addEventListener("resize", upd); upd();
  }

  /* ヒーローの 3 つの要点：その章を開いて、本文の頭までスクロール */
  function initIdeas(){
    document.querySelectorAll("#hero .ideas a").forEach(a=>{
      a.addEventListener("click", (ev)=>{ ev.preventDefault(); const id = a.getAttribute("href").slice(1);
        /* 「#3-2」のような節のアドレスなら、その章を開いて節までスクロール（2026-10-18：ヒーローの式③ → ③-2 が動かなかった） */
        const q = (typeof parseHash === "function") ? parseHash("#"+id) : {};
        if(q.mode && q.sec){ activateMode(q.mode.id); history.replaceState(null, "", "#"+id); scrollToSec(q.sec); return; }
        if(typeof activateMode === "function") activateMode(id);
        history.replaceState(null, "", "#"+id);
        window.scrollTo({top: (typeof contentTop === "function"? contentTop() : 0), behavior:"auto"}); });
    });
  }

  /* 「■ 見出し」の ■ を、色のついた小さな四角にする（文字の■は環境で形がばらつく） */
  function decorate(root){
    if(!root) return;
    root.querySelectorAll(".gtitle span, .stagetitle, .ttl, .mt").forEach(el=>{
      if(el.dataset.sq) return; const n = el.firstChild;
      if(n && n.nodeType === 3 && /^\s*■\s*/.test(n.nodeValue)){ n.nodeValue = n.nodeValue.replace(/^\s*■\s*/, ""); const i = document.createElement("i"); i.className = "sq"; i.setAttribute("aria-hidden","true"); el.insertBefore(i, n); }
      el.dataset.sq = "1";
    });
  }
  function initDecorate(){
    if(typeof activateMode !== "function") return;
    const orig = activateMode;
    const showTab = ()=>{ const row = document.querySelector("#tabs .tabs-in"), on = row && row.querySelector(".tab.on"); if(!on || row.scrollWidth <= row.clientWidth) return;
      const l = on.offsetLeft - 24, r = on.offsetLeft + on.offsetWidth + 24;
      if(l < row.scrollLeft) row.scrollLeft = l; else if(r > row.scrollLeft + row.clientWidth) row.scrollLeft = r - row.clientWidth; };   // スマホ：選んだタブが見えるように横に送る
    const cur = ()=>document.querySelectorAll("#tabs .tab").forEach(b=>{ if(b.classList.contains("on")) b.setAttribute("aria-current","page"); else b.removeAttribute("aria-current"); });
    activateMode = function(id){ const r = orig.apply(this, arguments); decorate(document.getElementById(id)); showTab(); cur(); return r; };   // 章を開いたあと（シムは初めて開いたときに作られる）
    showTab(); cur();
    document.querySelectorAll(".mode.on").forEach(decorate);
  }
  /* タブ列：ヒーローを過ぎたら .stuck */
  function initStuck(){
    const hero = document.getElementById("hero"), nav = document.getElementById("tabs"); if(!hero || !nav || !("IntersectionObserver" in window)) return;
    new IntersectionObserver((es)=>{ es.forEach(en=>nav.classList.toggle("stuck", !en.isIntersecting)); }, {threshold:0}).observe(hero);
    const nb = nav.querySelector(".navbrand"); if(nb) nb.addEventListener("click", (ev)=>{ ev.preventDefault(); window.scrollTo({top:0, behavior:"auto"}); });
  }
  /* フッター：題名と章の目次 */
  function initFooter(){
    const f = document.querySelector("#wrap footer") || document.querySelector("body > footer"); if(!f) return;
    document.body.appendChild(f);
    const C = "①②③④⑤⑥⑦⑧⑨";
    const items = (typeof MODES !== "undefined"? MODES : []).map((m,i)=>'<li><a href="#'+m.id+'" data-mode="'+m.id+'"><b>'+C[i]+'</b>'+m.name+'</a></li>').join("");
    f.innerHTML = '<div class="ft-in"><p class="ft-mark">Simple Harmonic Motion<span>単振動 〜等速円運動の影として見る〜</span></p>'+
      '<ul class="ft-nav">'+items+'</ul>'+
      '<div class="ft-base"><span><a class="ft-home" href="'+SITE_HOME+'">⌂ 楽楽（らくらく）高校物理 トップページ</a>　／　高校物理 ・ 力学</span><span class="ft-r"><button type="button" class="ft-pages">ほかのページ一覧</button><a href="#top" class="ft-top">▲ ページの一番上へ</a></span></div></div>';
    f.querySelectorAll("a[data-mode]").forEach(a=>a.addEventListener("click", (ev)=>{ ev.preventDefault(); const id = a.dataset.mode;
      activateMode(id); history.replaceState(null, "", "#"+id); window.scrollTo({top:(typeof contentTop==="function"? contentTop() : 0), behavior:"auto"}); }));
    const fp = f.querySelector(".ft-pages"); if(fp) fp.addEventListener("click", ()=>{ if(window.SITENAV) window.SITENAV.open(); });
    const tp = f.querySelector(".ft-top"); if(tp) tp.addEventListener("click", (ev)=>{ ev.preventDefault(); window.scrollTo({top:0, behavior:"auto"}); });
  }

  document.addEventListener("DOMContentLoaded", ()=>{
    initFooter(); initDecorate(); initStage(); initRanges(); initProgress(); initIdeas(); initStuck();
  });
})();


