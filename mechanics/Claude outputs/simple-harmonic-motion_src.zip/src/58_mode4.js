/* =========================================================================
   58_mode4.js … モード④ 入試物理（celestial-mechanics.html の「③ 入試物理」と同じ形。2026-10-18 千葉さん）
   ・見出しの右に「問題はこちら。まず解いてから以下を読もう」「解答と解き方はこちら」。押すと問題・解答の窓が開く。
     解答には、振動の様子を並べた図のように、時間の流れにそって変化を示した図を入れる。
   ・問題の主要な部分だけをアニメとグラフにする（右の列：グラフ・対応する円運動）。
   このファイル：共通部品（問題・解答の窓、右の列のグラフ）と ④-1。④-2 以降は 59_mode4b.js。
   ========================================================================= */
'use strict';

/* ===================== 共通：問題・解答の窓 ===================== */
/* d.exam = { src: '出典', prob: function () → HTML, ans: function () → HTML, fig: function (key, canvas) } */
/* 問題・解答は PDF（physics-site/PDF）を別のタブで開く（問題を見ながら解けるように。2026-10-18 千葉さん） */
var EXAM_PDF_DIR = '../PDF/';
function examBtns(sid) {
  var d = DEFS[sid]; if (!d || !d.exam) return '';
  var f = EXAM_PDF_DIR + d.exam.pdf;
  return '<div class="exbtns">' + (d.exam.noProb ? '' : '<a class="problink" href="' + f + '-problem.pdf" target="_blank" rel="noopener">問題はこちら。まず解いてから以下を読もう</a>') +
    '<a class="problink ans" href="' + f + '-answer.pdf" target="_blank" rel="noopener">' + (d.exam.noProb ? '解説はこちら' : '解答と解き方はこちら') + '</a></div>';
}
function examOverlay() {
  var ov = document.getElementById('examov');
  if (ov) return ov;
  ov = el('div', 'examov'); ov.id = 'examov'; ov.hidden = true;
  ov.innerHTML = '<div class="exwin" role="dialog" aria-modal="true" aria-labelledby="exttl"><div class="exbar"><span id="exttl"></span><button type="button" class="exclose">× 閉じる</button></div><div class="exbody"></div></div>';
  document.body.appendChild(ov);
  var close = function () { ov.hidden = true; document.body.classList.remove('exopen'); if (ov._from) ov._from.focus(); };
  ov.querySelector('.exclose').addEventListener('click', close);
  ov.addEventListener('click', function (e) { if (e.target === ov) close(); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !ov.hidden) close(); });
  return ov;
}
function examOpen(sid, kind, from) {
  var d = DEFS[sid]; if (!d || !d.exam) return;
  var ov = examOverlay(), mi = MODES.findIndex(function (m) { return m.id === d.mode; });
  ov.querySelector('#exttl').innerHTML = CIRC[mi] + '-' + d.num + '　' + d.short + '　<b>' + (kind === 'ans' ? '解答と解き方' : '問題文') + '</b>';
  var body = ov.querySelector('.exbody');
  body.innerHTML = mathify('<div class="exhead' + (kind === 'ans' ? ' ans' : '') + '"><h3>' + CIRC[mi] + '-' + d.num + '　' + d.short + (kind === 'ans' ? '　—　解答と解き方' : '') + '</h3>' + (d.exam.src ? '<p>出典：' + d.exam.src + '</p>' : '') + '</div>' + (kind === 'ans' ? d.exam.ans() : d.exam.prob()));
  ov._from = from || null; ov.hidden = false; document.body.classList.add('exopen'); body.scrollTop = 0;
  requestAnimationFrame(function () {                       /* 図（canvas）は、窓が出てから幅に合わせて描く */
    body.querySelectorAll('canvas[data-fig]').forEach(function (cv) {
      var W = Math.floor(cv.clientWidth || +cv.getAttribute('width') || 200), H = +cv.getAttribute('data-h') || Math.round(W * 1.4);
      cv.style.height = H + 'px'; d.exam.fig(cv.getAttribute('data-fig'), prep(cv, W, H), W, H);
    });
    var x = ov.querySelector('.exclose'); if (x) x.focus();
  });
}
document.addEventListener('click', function (e) {
  var b = e.target.closest && e.target.closest('button[data-exam]'); if (!b) return;
  examOpen(b.getAttribute('data-sid'), b.getAttribute('data-exam'), b);
});
/* 解答の「時間の流れで見る」の図の並び：figs = [[key, '見出し', '説明'], ...] */
function exStrip(figs, h, rows) {                             /* rows：横に長い図（水平の運動）は 1 行に 1 コマ */
  return '<div class="exstrip n' + figs.length + (rows ? ' rows' : '') + '">' + figs.map(function (f) {
    return '<figure><canvas data-fig="' + f[0] + '" data-h="' + (h || 250) + '"></canvas><figcaption><b>' + f[1] + '</b>' + (f[2] ? '<br>' + f[2] : '') + '</figcaption></figure>';
  }).join('') + '</div>';
}
/* 解答の 1 問ぶん：q＝問い、a＝答え、body＝解き方 */
function exQA(q, a, body) { return '<div class="exqa"><p class="exq">' + q + '</p><div class="exans"><span class="exansl">答</span>' + a + '</div>' + (body || '') + '</div>'; }

/* ===================== 共通：右の列のグラフ ===================== */
/* エネルギー − t グラフ。o = { t0, t1, Emax, cur, ser: [{ name, col, w, dash, f(t) → 値 or null }], marks: [{ t, txt }], shade: [t, t'] } */
function m4EnergyT(cv, o) {
  if (!cv || !cv.offsetParent) return;
  var W = Math.max(240, Math.floor(cv.clientWidth || 300)), H = 190, ctx = prep(cv, W, H);
  var x0 = 40, x1 = W - 18, y0 = H - 26, y1 = 14, X = function (t) { return x0 + (t - o.t0) / (o.t1 - o.t0) * (x1 - x0); }, Y = function (e) { return y0 - e / o.Emax * (y0 - y1); };
  if (o.shade) { ctx.save(); ctx.fillStyle = 'rgba(120,130,145,.10)'; ctx.fillRect(X(o.shade[0]), y1 - 4, X(Math.min(o.t1, o.shade[1])) - X(o.shade[0]), y0 - y1 + 4); ctx.restore(); if (o.shadeTxt) label(ctx, o.shadeTxt, (X(o.shade[0]) + X(Math.min(o.t1, o.shade[1]))) / 2, y1 + 8, { size: 10, color: '#69717d' }); }
  axisArrow(ctx, x0, y0, x1 + 8, y0); axisArrow(ctx, x0, y0 + 4, x0, y1 - 6);
  sym(ctx, 't', x1 + 8, y0 - 10, { size: 13 }); sym(ctx, 'E', x0 - 8, y1, { size: 13, align: 'right' }); label(ctx, '0', x0 - 6, y0 + 9, { size: 10, align: 'right' });
  (o.marks || []).forEach(function (mk) { var xx = X(mk.t); dotted(ctx, xx, y1, xx, y0, 'rgba(192,57,43,.6)', [4, 3]); label(ctx, mk.txt, xx, y0 + 13, { size: 10, color: '#c0392b', bold: true }); });
  var tc = Math.min(o.cur, o.t1);
  o.ser.forEach(function (sr) {
    ctx.save(); ctx.strokeStyle = sr.col; ctx.lineWidth = sr.w || 2.2; if (sr.dash) ctx.setLineDash(sr.dash);
    ctx.beginPath(); var pen = false;
    for (var i = 0; i <= 240; i++) { var t = o.t0 + (tc - o.t0) * i / 240, v = sr.f(t); if (v === null || v === undefined) { pen = false; continue; } if (!pen) { ctx.moveTo(X(t), Y(v)); pen = true; } else ctx.lineTo(X(t), Y(v)); }
    ctx.stroke(); ctx.restore();
  });
  /* 凡例 */
  var lx = x0 + 8; o.ser.forEach(function (sr) { ctx.save(); ctx.strokeStyle = sr.col; ctx.lineWidth = 2.4; if (sr.dash) ctx.setLineDash(sr.dash); ctx.beginPath(); ctx.moveTo(lx, H - 7); ctx.lineTo(lx + 16, H - 7); ctx.stroke(); ctx.restore(); var w = label(ctx, sr.name, lx + 20, H - 7, { size: 10, align: 'left', color: '#3a414c' }); lx += 30 + (w && w.w ? w.w : sr.name.length * 9); });
}
/* 対応する円運動：半径 A、中心 (cx, cy)、いまの角 th（x = A sin th、x は上向き）。lines：[{ x, txt, col }] の横線 */
function m4Circle(ctx, cx, cy, Rp, th, opt) {
  opt = opt || {};
  ctx.save(); ctx.strokeStyle = '#9aa1ab'; ctx.lineWidth = 1.3; ctx.beginPath(); ctx.arc(cx, cy, Rp, 0, TAU); ctx.stroke(); ctx.restore();
  dotted(ctx, cx - Rp - 8, cy, cx + Rp + 40, cy, 'rgba(20,23,28,.3)', [4, 3]);
  (opt.lines || []).forEach(function (ln) { var y = cy - ln.x * Rp; dotted(ctx, cx - Rp - 8, y, cx + Rp + 40, y, ln.col || 'rgba(192,57,43,.7)', [5, 3]); label(ctx, ln.txt, cx + Rp + 42, y, { size: 10, color: ln.col || '#c0392b', align: 'left', bold: true }); });
  var px = cx + Rp * Math.cos(th), py = cy - Rp * Math.sin(th);
  ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(px, py); ctx.stroke(); ctx.restore();
  dotted(ctx, px, py, cx + Rp + 30, py, 'rgba(20,23,28,.4)', [3, 3]);
  ballShape(ctx, px, py, 5, '#d9b77a'); label(ctx, 'P', px + 10 * Math.cos(th) + 6, py - 10 * Math.sin(th), { size: 11, bold: true });
  spinArrow(ctx, cx, cy, Rp + 10, Rp + 10, 0.3, 1.1, '#3a414c', 1.5); sym(ctx, 'ω', cx + (Rp + 22) * Math.cos(0.75), cy - (Rp + 22) * Math.sin(0.75), { size: 13 });
  return { px: px, py: py };
}

/* ===================== ④-1 台と一緒に単振動する物体（2016 広島大） =====================
   x：一体のときのつりあいの位置を原点、鉛直上向きが正。小物体を上から手で押して、台を s だけ押し下げてから放す。
   一体のあいだ：x = −s cos ωt（ω = √(k/(M+m))）。小物体が受ける垂直抗力 N = Mg(1 − x/d)。
   s > d なら x = d（ばねが自然の長さ）で N = 0 になって小物体が台から離れ、そのあとは小物体は投げ上げ、台は台だけのつりあいの位置の周りで単振動。
   小物体がふたたび台にのったら止める（そのあとは扱わない）。 */
var M4 = { s1: { M: 1.0, m: 1.0, k: 100, Ln: 1.3, sr: [0.5, 1.0, 1.5, 2.0], sr0: 2.0, pre: 1.6 } };
function m4s1Q(s) {
  var M = M4.s1.M, m = M4.s1.m, k = M4.s1.k, d = (M + m) * G / k, w = Math.sqrt(k / (M + m)), sv = s.v.sr * d;
  var sep = sv > d + 1e-9, t1 = sep ? Math.acos(-d / sv) / w : Infinity, v0 = sep ? w * Math.sqrt(sv * sv - d * d) : 0;
  var wp = Math.sqrt(k / m), xpe = d - m * G / k;
  var q = { M: M, m: m, k: k, d: d, w: w, T: TAU / w, s: sv, sep: sep, t1: t1, v0: v0, wp: wp, xpe: xpe, t2: Infinity };
  if (sep) {                                                    /* ふたたび台にのる時刻（小物体の底 ＝ 台の上面） */
    for (var tau = 0.01; tau < 6; tau += 0.0005) { var st = m4s1Sep(q, tau); if (st.xo <= st.xp + 1e-6) { q.t2 = t1 + tau; break; } }
  }
  return q;
}
function m4s1Sep(q, tau) {                                       /* 離れたあと（τ = t − t₁） */
  var xo = q.d + q.v0 * tau - 0.5 * G * tau * tau, vo = q.v0 - G * tau;
  var u = q.d - q.xpe, xp = q.xpe + u * Math.cos(q.wp * tau) + q.v0 / q.wp * Math.sin(q.wp * tau), vp = -u * q.wp * Math.sin(q.wp * tau) + q.v0 * Math.cos(q.wp * tau);
  return { xo: xo, vo: vo, xp: xp, vp: vp };
}
function m4s1At(q, t) {
  if (t <= q.t1) { var x = -q.s * Math.cos(q.w * t), v = q.s * q.w * Math.sin(q.w * t); return { together: true, xo: x, xp: x, vo: v, vp: v, N: q.M * G * (1 - x / q.d), x: x, a: -q.w * q.w * x }; }
  var st = m4s1Sep(q, Math.min(t, q.t2) - q.t1); st.together = false; st.N = 0; st.x = st.xp; return st;
}
function m4s1State(s, t) { return m4s1At(m4s1Q(s), t); }
var M4S1EASE = function (p) { p = clamp(p, 0, 1); return p * p * (3 - 2 * p); };
DEFS.m4s1 = {
  id: 'm4s1', mode: 'mode4', num: 2, title: '台と一緒に単振動する物体（2016 広島大）', short: '台と一緒に単振動する物体', custom: true,
  desc: 'ばね定数 $k$ の軽いばねを鉛直に立て、上端に質量 $m$ の薄い台をつける。台の上に質量 $M$ の小物体を載せると、ばねは自然の長さから $d$ だけ縮んでつりあった（この位置を原点 O、鉛直上向きを $x$ の正の向きとする）。小物体を上から手で押して台を $s$ だけ押し下げ、静かに放す。<span class="todo">「(1)(2) 手で押し下げる」で放す前のようすを見てから、「(3)〜(9) 手を放す」。「小物体と台を一体として見る」「小物体のみ見る」「台のみ見る」の 3 つの図と、右の対応する円運動を見比べよう。</span>',
  strobe: false, showFBtn: true, fDefault: 'all', vecBtn: 'v を消す', baseRate: 0.5, stgCls: 'solo',
  exam: { src: '2016 広島大（一部を書きかえています）', pdf: 'shm-platform', prob: function () { return m4s1Prob(); }, ans: function () { return m4s1Ans(); }, fig: function (k, ctx, W, H) { m4s1Fig(k, ctx, W, H); } },
  buttons: [
    { k: 'press', label: '(1)(2) 手で押し下げる', cls: 'm4press glow', inCanvas: true, onClick: function (s) { m4s1Press(s); } },
    { k: 'go', label: '(3)〜(9) 手を放す', cls: 'm4press', inCanvas: true, onClick: function (s) { if (s.extra.go) s.extra.go.classList.remove('glow'); if (s.ended || s.t >= s.tEnd()) s.resetT(); if (!s.playing) s.togglePlay(); } },
    /* circular-motion.html 3-1 と同じ：時間バーのとなりに「⏱ 離れる瞬間をスローで」 */
    { k: 'slowSep', label: '⏱ 離れる瞬間を<br>スローで', cls: 'two', inPlay: true, onClick: function (s) { var q = m4s1Q(s); if (!q.sep) return; s.pre = null; s.playWindow(Math.max(0, q.t1 - 0.14), q.t1 + 0.14, 0.06); } }
  ],
  vars: [{ k: 'sr', label: '押し下げる長さ $s$', stops: M4.s1.sr, stopLabels: ['0.5d', '1.0d', '1.5d', '2.0d'], def: M4.s1.sr0, aria: '押し下げる長さ', fmt: function (x) { return x.toFixed(1) + ' $d$（' + fmt(x * (M4.s1.M + M4.s1.m) * G / M4.s1.k, 3) + ' m）'; } }],
  html: function () {                                         /* 図は左右をまとめた横長、その下を左右に分ける（左：エネルギー・N–x、右：解説）。2026-10-18 千葉さん */
    return '<div class="secdesc">' + mathify(this.desc) + '</div><div class="m4top"><div class="simhost" id="simL_m4s1"></div></div>' +
      '<div class="m4bL m4two"></div><div class="sR m4bR" id="simR_m4s1"></div>';   /* エネルギーと N–x は左右に並べ、その下に解説（2026-10-18 千葉さん） */
  },
  build: function (art) { SIM_BY_ID.m4s1 = new Sim(DEFS.m4s1, art.querySelector('#simL_m4s1'), art.querySelector('#simR_m4s1')); },
  init: function (s) { s.pre = null; },
  onDefaults: function (s) { s.pre = null; if (s.extra.press) { s.extra.press.classList.remove('done'); s.extra.press.classList.add('glow'); } if (s.extra.go) s.extra.go.classList.remove('glow'); },
  onChanged: function (s) { s.pre = null; return 'stop'; },
  tEnd: function (s) { var q = m4s1Q(s); return q.sep ? q.t2 + 0.3 : 2 * q.T; },
  tInfo: function (s) { return periodInfo(m4s1Q(s).T) + '<span class="tnote">（一体のとき）</span>'; },
  gT: function (s) { return m4s1Q(s).T; },
  height: function (s, w) { return w < 700 ? 520 : Math.round(clamp(w * 0.40, 400, 480)) + 40; },
  afterBuild: function (s) {
    ctlSide(s);                                                   /* 左：すべて最初の設定に戻す…・▶ スタート・時間バー／右：押し下げる長さ */
    var bl = s.L.closest('article').querySelector('.m4bL');
    var c2 = el('div', 'qcard m4card m4ecard'); c2.innerHTML = mathify('<p class="qt">エネルギー − $t$ グラフ<span class="qtsub">（小物体と台をひとまとめに）</span></p><p class="qnote">$E = \\dfrac{1}{2}(M + m)v^2 + \\dfrac{1}{2}kx^2$。$x$ はつりあいの位置からの変位で、$U = \\dfrac{1}{2}kx^2$ は重力と弾性力の合力による位置エネルギー（<a class="xlink" href="#3-2">③-2</a>）。</p>');
    s.eCv = el('canvas', 'm4cv'); c2.appendChild(s.eCv);
    s.ePop = el('div', 'm4pop'); s.ePop.hidden = true;
    s.ePop.innerHTML = mathify('<button type="button" class="m4popx" aria-label="閉じる">×</button><p class="qt">離れたあと</p><p>小物体は重力だけを受けて<b>投げ上げ</b>の運動、台は<b>台だけのつりあいの位置</b>を中心とする単振動になる。小物体と台をひとまとめにした単振動ではないので、$U = \\dfrac{1}{2}kx^2$ は使えない。重力の位置エネルギーと、ばねの弾性力による位置エネルギーを<b>別々に</b>使う。</p><p>それでも<b>力学的エネルギーは保存している</b>（重力も弾性力も保存力で、垂直抗力は 0）：</p><p>小物体：$\\dfrac{1}{2}Mv^2 + Mgh = $ 一定　台：$\\dfrac{1}{2}mv^2 + mgh + \\dfrac{1}{2}k(\\text{縮み})^2 = $ 一定</p>');
    c2.appendChild(s.ePop); s.ePop.querySelector('.m4popx').addEventListener('click', function () { s.ePop.hidden = true; });
    s.eCv.addEventListener('click', function (ev) { var r = s.eCv.getBoundingClientRect(); if (s._shadeX !== undefined && ev.clientX - r.left >= s._shadeX) s.ePop.hidden = !s.ePop.hidden; });
    s.eCv.addEventListener('mousemove', function (ev) { var r = s.eCv.getBoundingClientRect(); s.eCv.style.cursor = (s._shadeX !== undefined && ev.clientX - r.left >= s._shadeX) ? 'pointer' : ''; });
    bl.appendChild(c2);
    var c1 = el('div', 'qcard m4card'); c1.innerHTML = mathify('<p class="qt">$N$–$x$ グラフ<span class="qtsub">（小物体が台から受ける垂直抗力）</span></p>'); s.nxCv = el('canvas', 'm4cv'); c1.appendChild(s.nxCv); bl.appendChild(c1);
  },
  draw: function (s, ctx, W, H) { drawM4S1(s, ctx, W, H); drawM4S1NX(s); drawM4S1E(s); },
  msg: function (s) {
    var q = m4s1Q(s), st = m4s1State(s, s.t);
    if (s.pre !== null) return '(1) 手で押す前は、ばねは自然の長さから $d$ 縮んでつりあっている。(2) 小物体を上から手で押して、台を $s$ 押し下げて支える。小物体と台をひとまとめにすると、手が押す力は $F_s = ks$。';
    if (s.t === 0 && !s.playing) return '(2) 手で $s$ だけ押し下げて支えている。「(3)〜(9) 手を放す」（▶ スタートと同じ）で手を放す。';
    if (!q.sep) return '$s \\le d$ なので、小物体は台から離れず、台と一体のまま単振動する。';
    if (st.together) return '小物体と台は一体となって単振動している。小物体が受ける $N = Mg\\left(1 - \\dfrac{x}{d}\\right)$ は、$x$ が大きくなるほど小さくなる。';
    if (s.t < q.t2) return '<b>$x = d$（ばねが自然の長さ）で $N = 0$ になり、小物体が台から離れた。</b>離れる瞬間の速さ $v_0 = ' + fmt(q.v0, 2) + '$ m/s。小物体は投げ上げ、台は台だけのつりあいの位置の周りで単振動する。';
    return '小物体がふたたび台に乗った（このあとは扱わない）。';
  },
  right: function (s, R) { m4s1Right(s, R); }
};
/* (1)(2)：つりあいの位置から、手で上から押して s まで押し下げる（1.2 s）→ 0.6 s 支える。そのあと t = 0（放す直前）に戻る */
function m4s1Press(s) {
  if (s.playing) s.togglePlay();
  s.resetT();
  var t0 = performance.now(), dur = M4.s1.pre * 1000;
  s.pre = 0; if (s.extra.press) { s.extra.press.classList.remove('glow'); s.extra.press.classList.add('done'); } if (s.extra.go) s.extra.go.classList.add('glow');   /* 押したことが分かるように（2026-10-18 千葉さん） */
  var step = function (now) {
    if (s.pre === null) return;
    s.pre = Math.min(1, (now - t0) / dur); s.draw();
    if (s.pre < 1) requestAnimationFrame(step); else { s.pre = null; s.draw(); }
  };
  requestAnimationFrame(step);
}
/* 図の座標。x は台の上の面（＝小物体の底・ばねの上の端）の位置。左から：参考の 3 図／一体／小物体のみ／台のみ／x 軸／対応する円運動 */
function m4s1Geo(W, H, q) {
  var nar = W < 700, yb = nar ? 46 : 86, Ln = M4.s1.Ln, xg = q.d - Ln, xTop = 0.56, S = (H - yb - 60) / (xTop - xg);   /* 広い画面：床の下に、左の図の名前の場所（3 行ほど下。2026-10-25） */
  var g = { Ln: Ln, xg: xg, S: S, nar: nar, Y: function (x) { return H - yb - (x - xg) * S; }, pw: 48, ph: 7, bw: 34, bh: 24 };
  if (nar) { g.refs = []; g.pan = [W * 0.17, W * 0.42]; g.ax = W * 0.60; g.cc = null; }   /* せまい画面：参考の図と円運動は出さない */
  else { g.refs = [W * 0.035, W * 0.095, W * 0.155]; g.pan = [W * 0.27, W * 0.42, W * 0.57]; g.ax = W * 0.67; g.cc = W * 0.86; }
  return g;
}
function m4s1Spring(ctx, x, y0, y1, g, q, fade) {
  ctx.save(); if (fade) ctx.globalAlpha *= fade;
  springDense(ctx, x, y0, x, y1, g.Ln * g.S, { r: 8, lead: 5, k: q.k, thin: 0.5, Lmin: ((g.Ln - 3 * q.d) * g.S) * 0.8 });   /* 細めのばね（2026-10-18 千葉さん） */
  ctx.restore();
}
function m4s1Plat(ctx, x, y, g, fade) { ctx.save(); if (fade) ctx.globalAlpha *= fade; ctx.fillStyle = '#9aa1ab'; ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.3; ctx.fillRect(x - g.pw / 2, y, g.pw, g.ph); ctx.strokeRect(x - g.pw / 2, y, g.pw, g.ph); ctx.restore(); }
function m4s1Obj(ctx, x, yb, g, fade) { ctx.save(); if (fade) ctx.globalAlpha *= fade; ctx.fillStyle = '#e4d3b4'; ctx.strokeStyle = '#6b5532'; ctx.lineWidth = 1.3; ctx.fillRect(x - g.bw / 2, yb - g.bh, g.bw, g.bh); ctx.strokeRect(x - g.bw / 2, yb - g.bh, g.bw, g.bh); ctx.restore(); }
/* 台（上の面が y）・小物体（底が yo）・ばね（下の端 yg → 台の下の面）をまとめて描く */
function m4s1Set(ctx, x, yg, yp, yo, g, q, fP, fO) {
  m4s1Spring(ctx, x, yg, yp + g.ph, g, q, fP);
  ctx.save(); if (fP) ctx.globalAlpha *= fP; ctx.fillStyle = '#9aa1ab'; ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.3; ctx.fillRect(x - g.pw / 2, yp, g.pw, g.ph); ctx.strokeRect(x - g.pw / 2, yp, g.pw, g.ph); ctx.restore();
  if (yo !== null) m4s1Obj(ctx, x, yo, g, fO);
}
function m4s1Now(s, q) {
  var pre = s.pre !== null, held = pre || (s.t === 0 && !s.playing);
  if (pre) { var x = -q.s * M4S1EASE(s.pre / 0.75); return { held: true, pre: true, together: true, xo: x, xp: x, vo: 0, vp: 0, N: 0, x: x }; }
  if (held) return { held: true, together: true, xo: -q.s, xp: -q.s, vo: 0, vp: 0, N: 0, x: -q.s };
  var st = m4s1State(s, s.t); st.held = false; return st;
}
function drawM4S1(s, ctx, W, H) {
  var q = m4s1Q(s), g = m4s1Geo(W, H, q), Y = g.Y, st = m4s1Now(s, q), yg = Y(g.xg), xpe = q.d - q.m * G / q.k;
  var xL = g.nar ? 8 : g.refs[0] - 26;
  if (!g.nar) refArea(ctx, 0, 0, g.refs[2] + 62, H, 'r');          /* 左の参考の図のエリア（背景と境の実線。2026-10-25 千葉さん） */
  floorAt(ctx, xL, g.pan[g.pan.length - 1] + 40, yg);
  /* 左の 3 つの図 */
  if (!g.nar) [[g.refs[0], q.d, ['自然の長さ', 'の位置'], false, false], [g.refs[1], xpe, ['台だけの', 'つりあい', 'の位置'], true, false], [g.refs[2], 0, ['つりあい', 'の位置'], true, true]].forEach(function (r) {   /* 名前は「〜の位置」（2026-10-25） */
    var yt = Y(r[1]);
    if (r[3]) m4s1Set(ctx, r[0], yg, yt, r[4] ? yt : null, g, q);
    else { m4s1Spring(ctx, r[0], yg, yt, g, q); ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(r[0] - 10, yt); ctx.lineTo(r[0] + 10, yt); ctx.stroke(); ctx.restore(); }
    r[2].forEach(function (t, i) { label(ctx, t, r[0], yg + 44 + i * 13, { size: 10.5, color: r[4] ? '#c0392b' : '#5d6875', bold: r[4] }); });   /* 図の間がせまいので行を分ける */
  });
  /* 基準の線（台の上の面の高さ）と x 軸 */
  var lines = [[q.d, '自然の長さ（x = d）', '#5d6875'], [xpe, '台だけのつりあい', '#8d9097'], [0, 'O（つりあいの位置）', '#c0392b'], [-q.s, 'x = −s（始まりの位置）', '#5d6875']];
  lines.forEach(function (r) { dotted(ctx, xL, Y(r[0]), g.ax, Y(r[0]), r[0] === 0 ? 'rgba(192,57,43,.55)' : 'rgba(20,23,28,.30)', [4, 3]); label(ctx, r[1], g.ax + 6, Y(r[0]) - 7, { size: 10, color: r[2], bold: r[0] === 0, align: 'left' }); });
  if (!g.nar) { var xdl = g.refs[2] + g.pw / 2 + 10; dimLine(ctx, xdl, Y(q.d), xdl, Y(0)); sym(ctx, 'd', xdl + 8, (Y(q.d) + Y(0)) / 2, { size: 14, align: 'left' }); }
  axisArrow(ctx, g.ax, yg - 2, g.ax, 30); sym(ctx, 'x', g.ax - 9, 34, { size: 14, align: 'right' });
  /* 3 つの図（一体／小物体のみ／台のみ） */
  var yp = Y(st.xp), yo = Y(st.xo), fs = 22 / (q.M * G), vref = q.s * q.w || 1;
  /* 3 つの図の仕切り線と、「小物体のみ」「台のみ」の背景（薄い灰色） */
  var hg = g.pan.length > 1 ? (g.pan[1] - g.pan[0]) / 2 : 60;
  ctx.save(); ctx.fillStyle = 'rgba(120,128,140,.08)';
  g.pan.forEach(function (cx, i) { if (i > 0) ctx.fillRect(cx - hg, 30, 2 * hg, yg - 30); }); ctx.restore();
  g.pan.forEach(function (cx, i) { dotted(ctx, cx + hg, 30, cx + hg, yg + 6, 'rgba(20,23,28,.35)', [2, 0]); if (i === 0) dotted(ctx, cx - hg, 30, cx - hg, yg + 6, 'rgba(20,23,28,.35)', [2, 0]); });
  var st1 = (!st.held && !st.together) ? m4s1At(q, q.t1) : st, yp1 = Y(st1.xp), yo1 = Y(st1.xo);   /* 一体の図は、離れたら止める */
  var titles = g.nar ? ['一体として見る', '小物体のみ見る'] : ['小物体と台を一体として見る', '小物体のみ見る', '台のみ見る'];
  _fArrows.length = 0;
  g.pan.forEach(function (cx, i) {
    drawEqualTicks(ctx); _fArrows.length = 0;                       /* 同じ大きさの印は、それぞれの図の中だけでつける（図をまたいでつけない。2026-10-18 千葉さん） */
    label(ctx, titles[i], cx, 46, { size: 11, bold: true, color: COL.ink2 });
    var fP = i === 1 ? 0.22 : 1, fO = i === 2 ? 0.22 : 1;
    if (st.held) fP = fO = 1;
    if (i === 0 && !st.held && !st.together) { m4s1Set(ctx, cx, yg, yp1, yo1, g, q); label(ctx, '離れた瞬間で止めている', cx, yo1 - g.bh - 14, { size: 10.5, color: '#a85c0c', bold: true }); return; }
    m4s1Set(ctx, cx, yg, yp, yo, g, q, fP, fO);
    if (st.held) {
      dropHand(ctx, cx + 4, yo - g.bh + 4, 0.34, 1, 1);
      if (i === 0) m4s1HeldForces(ctx, cx, yo, yp, g, q, st.x, s);
      else if (fAll(s)) {                                         /* 押さえているときも、小物体・台にはたらく力を書く */
        var fh = 14 / (q.M * G), Fh = q.k * (-st.x), Nh = q.M * G + Fh;
        if (i === 1) { fArrow(ctx, cx - 9, yo - g.bh, 0, 1, Fh * fh, '#1f8a4c', 'F', { lx: -14, noShift: true }); fArrow(ctx, cx - 2, yo - g.bh / 2, 0, 1, q.M * G * fh, COL.force, 'Mg', { lx: -18, ly: 8, noShift: true }); fArrow(ctx, cx + 9, yo, 0, -1, Nh * fh, COL.norm, 'N', { lx: 12, noShift: true }); }
        else { fArrow(ctx, cx - 12, yp + g.ph / 2, 0, 1, q.m * G * fh, COL.force, 'mg', { lx: -14, noShift: true }); fArrow(ctx, cx - 2, yp, 0, 1, Nh * fh, COL.norm, 'N', { lx: -12, ly: 8, noShift: true }); fArrow(ctx, cx + 12, yp + g.ph, 0, -1, q.k * (q.d - st.x) * fh, COL.hand, 'k(d + s)', { lx: 34, noShift: true }); }
      }
      return;
    }
    if (i === 0) {                                              /* 一体：重力 (M+m)g（全体の中心から）と弾性力 k(d − x)（ばねとの接点から）。離れたら別々 */
      if (st.together) {
        if (fAll(s)) { fArrow(ctx, cx - 7, (yo - g.bh + yp + g.ph) / 2, 0, 1, (q.M + q.m) * G * fs, COL.force, '(M+m)g', { lx: -34, noShift: true }); fArrow(ctx, cx + 7, yp + g.ph, 0, -1, q.k * (q.d - st.xp) * fs, COL.hand, 'k(d − x)', { lx: 32, noShift: true }); }
        else if (fNet(s)) netArrow(ctx, cx, yp + g.ph, 0, -1, -q.k * st.x * fs, '−kx', { lx: 24 });
        if (!s.hideVec && Math.abs(st.vo) > 0.03) vArrowAt(ctx, cx, yo - g.bh, 0, -1, 16, 0, -1, clamp(st.vo / vref, -1.6, 1.6) * 36, true);
      } else label(ctx, '離れたら別々', cx, yo - g.bh - 14, { size: 10.5, color: '#a85c0c', bold: true });
    } else if (i === 1) {                                       /* 小物体：Mg（中心から）と N（台との接点から） */
      if (fAll(s)) { fArrow(ctx, cx - 6, yo - g.bh / 2, 0, 1, q.M * G * fs, COL.force, 'Mg', { lx: -16, noShift: true }); if (st.N > 1e-6) fArrow(ctx, cx + 6, yo, 0, -1, st.N * fs, COL.norm, 'N', { lx: 12, noShift: true }); }
      else if (fNet(s)) netArrow(ctx, cx, yo - g.bh / 2, 0, -1, (st.N - q.M * G) * fs, 'F', { lx: 22 });
      if (!s.hideVec && Math.abs(st.vo) > 0.03) vArrowAt(ctx, cx, yo - g.bh, 0, -1, 16, 0, -1, clamp(st.vo / vref, -1.6, 1.6) * 36, true);
      if (!st.together && s.t < q.t2) bubble(ctx, '離れた！ N = 0', cx + 62, yo - g.bh / 2, { size: 11.5, bg: '#fff5e8', border: '#e07b18', color: '#a85c0c' });
    } else {                                                    /* 台：mg・k(d − x)（下の接点から）・N（小物体から。上の接点から） */
      var Fsp = q.k * (q.d - st.xp);
      if (fAll(s)) { fArrow(ctx, cx - 12, yp + g.ph / 2, 0, 1, q.m * G * fs, COL.force, 'mg', { lx: -14, noShift: true }); fArrow(ctx, cx + 12, yp + g.ph, 0, -1, Fsp * fs, COL.hand, 'k(d − x)', { lx: 30, noShift: true }); if (st.N > 1e-6) fArrow(ctx, cx - 2, yp, 0, 1, st.N * fs, COL.norm, 'N', { lx: -12, ly: 6, noShift: true }); }
      else if (fNet(s)) netArrow(ctx, cx + 12, yp + g.ph, 0, -1, (Fsp - q.m * G - st.N) * fs, 'F', { lx: 22 });
      if (!s.hideVec && Math.abs(st.vp) > 0.03) vArrowAt(ctx, cx + g.pw / 2, yp + g.ph / 2, 1, 0, 34, 0, -1, clamp(st.vp / vref, -1.6, 1.6) * 36, true);
    }
  });
  if (st.pre && s.pre > 0.75) bubble(ctx, '(2) この状態で支える', g.pan[0], Y(-q.s) + 54, { size: 11.5, bg: '#fff5e8', border: '#e07b18', color: '#a85c0c', side: 'up' });
  if (st.pre && s.pre < 0.05) bubble(ctx, '(1) つりあいの位置', g.pan[0] + 60, Y(0) - g.bh - 24, { size: 11.5, bg: '#fff', border: '#c0392b', color: '#c0392b' });
  /* 対応する円運動（半径 s。中心は O の高さ。P の高さ＝一体のときの x） */
  if (g.cc) m4s1Circle(s, ctx, g, q, st);
  drawEqualTicks(ctx);
}
function m4s1Circle(s, ctx, g, q, st) {
  var Y = g.Y, cx = g.cc, cy = Y(0), R = q.s * g.S, t = st.held ? 0 : Math.min(s.t, q.t1), ph = -Math.PI / 2, th = ph + q.w * t;
  var dir = function (a, r) { return { x: cx + r * Math.cos(a), y: cy - r * Math.sin(a) }; };
  ctx.save(); ctx.strokeStyle = '#8d9097'; ctx.lineWidth = 1.3; ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.stroke(); ctx.restore();
  dotted(ctx, cx - R - 10, cy, cx + R + 10, cy, 'rgba(20,23,28,.35)', [3, 3]);                 /* 基準の直径 */
  var p0 = dir(ph, R); dotted(ctx, cx, cy, p0.x, p0.y, 'rgba(20,23,28,.55)', [3, 3]);           /* 始まりの位置への線 */
  label(ctx, '始まり', p0.x - 8, p0.y + 4, { size: 10, color: '#5d6875', align: 'right' });
  var arc = function (a0, a1, r, col, lw) { ctx.save(); ctx.strokeStyle = col; ctx.lineWidth = lw; ctx.beginPath(); ctx.arc(cx, cy, r, -a0, -a1, a1 > a0); ctx.stroke(); ctx.restore(); };
  arc(0, ph, 14, '#7a4fb8', 1.5); var pl = dir(ph / 2, 25); sym(ctx, 'ϕ', pl.x, pl.y, { size: 12, color: '#7a4fb8' });
  if (t > 0.01) { arc(ph, th, Math.min(30, R * 0.6), '#3a414c', 1.3); var lw = dir(ph + q.w * t / 2, Math.min(30, R * 0.6) + 11); sym(ctx, 'ωt', lw.x, lw.y, { size: 12 }); }
  if (q.sep) { var yd = Y(q.d); dotted(ctx, cx - R - 14, yd, cx + R + 14, yd, 'rgba(192,57,43,.7)', [5, 3]); label(ctx, 'x = d で離れる', cx + R + 6, yd - 9, { size: 10, color: '#c0392b', bold: true, align: 'left' }); }
  var P = dir(th, R);
  ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(P.x, P.y); ctx.stroke(); ctx.fillStyle = '#3a414c'; ctx.beginPath(); ctx.arc(cx, cy, 2.4, 0, TAU); ctx.fill(); ctx.restore();
  dotted(ctx, P.x, P.y, g.pan[0] + g.pw / 2 + 4, P.y, 'rgba(22,99,181,.55)', [3, 4]);         /* P の高さ ＝ 一体のときの台の上の面 */
  ballShape(ctx, P.x, P.y, 5.5, M2BALL);
  if (q.sep && !st.held && s.t >= q.t1 - 1e-6) {                  /* 離れる瞬間：v₀ = ω√(s² − d²) */
    ctx.save(); ctx.strokeStyle = COL.vel; ctx.lineWidth = 2.4; ctx.beginPath(); ctx.moveTo(cx, P.y); ctx.lineTo(P.x, P.y); ctx.stroke(); ctx.restore();
    label(ctx, '√(s² − d²)', (cx + P.x) / 2, P.y - 10, { size: 10, color: COL.vel, bold: true });
    label(ctx, 'v₀ = ω√(s² − d²)', cx, cy + R + 34, { size: 11, color: COL.vel, bold: true });
  }
  label(ctx, '対応する等速円運動（半径 s）', cx, Math.min(g.Y(g.xg) + 14, cy + R + 18), { size: 10.5, color: COL.ink2 });
}
/* (2)：小物体と台をひとまとめにした物体にはたらく力（手の力 F・重力 (M+m)g・ばねの弾性力 k(d+s)）。縮尺は Mg が 14 px */
function m4s1HeldForces(ctx, cx, yo, yp, g, q, x, s) {
  if (!fAll(s)) return;                                          /* 支えているあいだは合力 0 */
  var fs = 14 / (q.M * G), Fh = q.k * (-x), cy = (yo - g.bh + yp + g.ph) / 2;
  if (Fh > 1e-6) fArrow(ctx, cx - 9, yo - g.bh, 0, 1, Fh * fs, '#1f8a4c', 'F', { lx: -14, noShift: true });
  fArrow(ctx, cx, cy, 0, 1, (q.M + q.m) * G * fs, COL.force, '(M+m)g', { lx: -40, ly: 2, noShift: true });
  fArrow(ctx, cx + 9, yp + g.ph, 0, -1, q.k * (q.d - x) * fs, COL.hand, 'k(d + s)', { lx: 36, noShift: true });
}
/* 下の左：N–x グラフ */
function drawM4S1NX(s) {
  var cv = s.nxCv; if (!cv || !cv.offsetParent) return;
  var q = m4s1Q(s), st0 = m4s1Now(s, q), st = st0.held ? { together: true, xo: -q.s, N: q.M * G * (1 + q.s / q.d) } : st0;
  var W = Math.max(240, Math.floor(cv.clientWidth || 300)), H = 200, ctx = prep(cv, W, H);
  var x0 = 46, x1 = W - 20, y0 = H - 30, y1 = 16, xl = -2.2 * q.d, xr = 2.2 * q.d, Nmax = 3.2 * q.M * G;
  var X = function (x) { return x0 + (x - xl) / (xr - xl) * (x1 - x0); }, Yn = function (n) { return y0 - n / Nmax * (y0 - y1); };
  ctx.save(); ctx.strokeStyle = '#eef0f2'; [1, 2, 3].forEach(function (k) { ctx.beginPath(); ctx.moveTo(x0, Yn(k * q.M * G)); ctx.lineTo(x1, Yn(k * q.M * G)); ctx.stroke(); }); ctx.restore();
  axisArrow(ctx, x0 - 4, y0, x1 + 8, y0); axisArrow(ctx, X(0), y0 + 4, X(0), y1 - 6);
  sym(ctx, 'x', x1 + 8, y0 - 10, { size: 13 }); sym(ctx, 'N', X(0) + 10, y1 - 4, { size: 13, align: 'left' });
  [1, 2, 3].forEach(function (k) { label(ctx, k === 1 ? 'Mg' : k + 'Mg', X(0) - 6, Yn(k * q.M * G), { size: 10, align: 'right', color: '#5d6875' }); });
  [[-2, '−2d'], [-1, '−d'], [1, 'd'], [2, '2d']].forEach(function (r) { var xx = X(r[0] * q.d); ctx.save(); ctx.strokeStyle = '#2b323c'; ctx.beginPath(); ctx.moveTo(xx, y0 - 3); ctx.lineTo(xx, y0 + 3); ctx.stroke(); ctx.restore(); label(ctx, r[1], xx, y0 + 13, { size: 10, color: '#5d6875' }); });
  label(ctx, 'O', X(0) + 7, y0 + 12, { size: 10.5, bold: true });
  var xa = -q.s, xb = Math.min(q.s, q.d);
  ctx.save(); ctx.strokeStyle = 'rgba(123,63,212,.35)'; ctx.setLineDash([4, 4]); ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(X(xl), Yn(q.M * G * (1 - xl / q.d))); ctx.lineTo(X(q.d), Yn(0)); ctx.stroke(); ctx.restore();
  ctx.save(); ctx.strokeStyle = COL.norm; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(X(xa), Yn(q.M * G * (1 - xa / q.d))); ctx.lineTo(X(xb), Yn(q.M * G * (1 - xb / q.d))); ctx.stroke(); ctx.restore();
  if (q.sep) { ctx.save(); ctx.strokeStyle = COL.norm; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(X(q.d), Yn(0)); ctx.lineTo(X(1.6 * q.d), Yn(0)); ctx.stroke(); ctx.restore(); label(ctx, '離れたあと N = 0', X(1.6 * q.d), Yn(0) - 12, { size: 10, color: COL.norm }); }
  var px = st.together ? st.xo : q.d;
  ctx.save(); ctx.fillStyle = '#c0392b'; ctx.beginPath(); ctx.arc(X(clamp(px, xl, xr)), Yn(st.N), 5, 0, TAU); ctx.fill(); ctx.restore();
  label(ctx, 'N = ' + fmt(st.N, 1) + ' N', x1, y1 + 2, { size: 11, bold: true, color: COL.norm, align: 'right' });
}
/* 下の左：エネルギー − t（一体のあいだ。離れたあとは薄い灰色の帯。押すと説明） */
function drawM4S1E(s) {
  var q = m4s1Q(s), M = q.M + q.m, tEndG = q.sep ? q.t1 * 1.3 : q.T, held = m4s1Now(s, q).held, E0 = 0.5 * q.k * q.s * q.s;
  m4EnergyT(s.eCv, { t0: 0, t1: tEndG, Emax: 0.5 * q.k * Math.pow(2 * q.d, 2) * 1.08, cur: held ? 0 : s.t,
    marks: q.sep ? [{ t: q.t1, txt: '離れる' }] : [], shade: q.sep ? [q.t1, tEndG] : null, shadeTxt: '離れたあと ▸（押す）',
    ser: [{ name: 'E（一定）', col: ECOL.E, w: 3, f: function (t) { return t <= q.t1 ? E0 : null; } },
      { name: 'U = ½kx²', col: ECOL.U, dash: [6, 4], f: function (t) { if (t > q.t1) return null; var x = -q.s * Math.cos(q.w * t); return 0.5 * q.k * x * x; } },
      { name: '½(M+m)v²', col: ECOL.K, f: function (t) { if (t > q.t1) return null; var v = q.s * q.w * Math.sin(q.w * t); return 0.5 * M * v * v; } }] });
  if (s.eCv && q.sep) { var W = Math.max(240, Math.floor(s.eCv.clientWidth || 300)); s._shadeX = 40 + q.t1 / tEndG * (W - 18 - 40); } else s._shadeX = undefined;
}
/* 下の右：解説 */
function m4s1Right(s, R) {
  var q = m4s1Q(s);
  R.innerHTML = mathify('<div class="qcard"><h3 class="m4point">この問題のポイント</h3><p class="qt">① 一体のときの運動（(3)(4)）</p><p>小物体と台をひとまとめにすると、力は重力 $(M + m)g$ と弾性力 $k(d - x)$。つりあいの式 $kd = (M + m)g$ を使うと</p><p class="eqline">' + eqTag('eom') + '$(M + m)a = k(d - x) - (M + m)g = -kx$</p><p>$T = 2\\pi\\sqrt{\\dfrac{M + m}{k}}$。</p>' +
    '<p class="qt">② 垂直抗力 $N$（(5)〜(8)）</p><p class="eqline">' + eqTag('eom') + '小物体：$Ma = N - Mg$</p><p>$a = -\\dfrac{k}{M + m}x = -\\dfrac{g}{d}x$ を入れて $N = Mg\\left(1 - \\dfrac{x}{d}\\right)$。$N = 0$ となる $x = d$（ばねの自然の長さ）で離れる。</p>' +
    '<p class="qt">③ (9) 単振動のエネルギー保存で $v_0$ を求める</p>' +
    '<p>小物体と台が一体で単振動している間（$-s \\le x \\le d$）は、つりあいの位置からの変位 $x$ を使って</p><div class="qeq">$$\\frac{1}{2}(M + m)v^2 + \\frac{1}{2}kx^2 = \\text{一定}$$</div>' +
    '<p>が成りたつ。ここで $\\dfrac{1}{2}kx^2$ は、重力と弾性力の<b>合力</b>による位置エネルギー（<a class="xlink" href="#3-2">③-2</a>）なので、重力の位置エネルギーを別に足してはいけない。放した位置（$x = -s$、$v = 0$）と離れる位置（$x = d$、$v = v_0$）で比べると</p>' +
    '<div class="qeq">$$\\frac{1}{2}k s^2 = \\frac{1}{2}(M + m)v_0^2 + \\frac{1}{2}kd^2 \\quad\\Rightarrow\\quad v_0 = \\sqrt{\\frac{k(s^2 - d^2)}{M + m}}$$</div>' +
    '<p>$m = M$、$s = 2d$ のとき $v_0 = \\sqrt{\\dfrac{3kd^2}{2M}}$。$d = \\dfrac{2Mg}{k}$ を入れて <b>$v_0 = g\\sqrt{\\dfrac{6M}{k}}$</b>。</p>' +
    '<p class="qnote">対応する円運動で見ると：半径 $s$ の円の上の点が $x = d$ の高さにあるとき、速さの $x$ 成分は $\\omega\\sqrt{s^2 - d^2}$（$\\omega = \\sqrt{\\dfrac{k}{M + m}}$）。同じ式になる。</p>' +
    '<p class="qnow"><span class="qtag now">この図では</span>$M = m = ' + q.M.toFixed(1) + '$ kg、$k = ' + q.k + '$ N/m、$d = ' + fmt(q.d, 3) + '$ m、$T = ' + sig2(q.T) + '$ s' + (q.sep ? '、$v_0 = ' + fmt(q.v0, 2) + '$ m/s' : '（離れない）') + '</p></div>');
}
/* ---------- 問題・解答 ---------- */
function m4s1Prob() {
  return '<h4 class="exh">問題の設定</h4><div class="exbox">' +
    '<p>図のように、ばね定数 $k$ の軽いばねを床の上に鉛直に立て、上端に質量 $m$ の薄い台を取りつけた。台の上に質量 $M$ の小物体を静かに載せると、ばねは自然の長さから $d$ だけ縮み、台と小物体は静止した。この位置をつりあいの位置とする。ばねは鉛直方向にだけ伸び縮みし、重力加速度の大きさを $g$ とする。</p></div>' +
    '<h4 class="exh">図</h4><div class="exfig"><canvas data-fig="setup" data-h="250"></canvas><p class="excap">図　(a) 自然の長さ　(b) つりあい　(c) 手で $s$ 押し下げたとき</p></div>' +
    '<h4 class="exh">問</h4><ol class="exol">' +
    '<li>$d$ を $k$、$M$、$m$、$g$ で表せ。</li>' +
    '<li>つりあいの位置から、小物体を上から手で押して、台をさらに $s$ だけ押し下げて支えた。手が小物体を押す力の大きさ $F_s$ を求めよ。</li></ol>' +
    '<p class="exmid">$s$ が小さいとき手を放すと、小物体は台と一体となって振動した。つりあいの位置を原点 O とし、鉛直上向きに $x$ 軸をとる。</p><ol class="exol" start="3">' +
    '<li>変位が $x$ のとき、小物体と台をひとまとめにしたものにはたらく力（合力）$F$ を求めよ。</li>' +
    '<li>この振動の周期 $T$ を求めよ。</li></ol>' +
    '<p class="exmid">次に $s$ を大きくすると、小物体は途中で台から離れて飛び上がった。離れるまでの小物体と台の加速度を $a$（上向きを正）、小物体が台から受ける垂直抗力の大きさを $N$ とする。</p><ol class="exol" start="5">' +
    '<li>小物体と台の運動方程式を、それぞれ書け。</li>' +
    '<li>$N$ を $M$、$d$、$x$、$g$ で表せ。</li>' +
    '<li>$s > d$ のとき、$N$ と $x$ の関係をグラフに表せ（横軸 $x$ は $-s$ から $s$ まで）。</li>' +
    '<li>小物体が台から離れるときの変位 $x_0$ を求めよ。</li>' +
    '<li>$m = M$、$s = 2d$ のとき、小物体が台から離れる瞬間の速さ $v_0$ を $M$、$k$、$g$ で表せ。</li></ol>';
}
function m4s1Ans() {
  return '<h4 class="exh">時間の流れで見る（$s = 2d$、$m = M$）</h4>' +
    exStrip([['a', 'ⓐ 押し下げて支える', '$x = -s$、合力 0'], ['b', 'ⓑ 手を放した直後', '上向きに加速'], ['c', 'ⓒ つりあいの位置', '速さ最大'], ['d', 'ⓓ $x = d$', '$N = 0$ で離れる'], ['e', 'ⓔ 離れたあと', '小物体は投げ上げ']], 250) +
    '<h4 class="exh">解答と解き方</h4>' +
    exQA('(1) ばねの縮み $d$', '$d = \\dfrac{(M + m)g}{k}$', '<p>小物体と台をひとまとめにすると、重力 $(M + m)g$ とばねの弾性力 $kd$ がつりあう：' + eqTag('bal') + '$kd = (M + m)g$。</p>') +
    exQA('(2) 手が押す力 $F_s$', '$F_s = ks$', '<p>ひとまとめにした物体には、手の力 $F_s$（下向き）・重力 $(M + m)g$（下向き）・弾性力 $k(d + s)$（上向き）。' + eqTag('bal') + '$k(d + s) = (M + m)g + F_s$ に (1) を使うと $F_s = ks$。</p>') +
    exQA('(3) 変位 $x$ での合力 $F$', '$F = -kx$', '<p>ばねの縮みは $d - x$ なので　$F = k(d - x) - (M + m)g = -kx$（(1) を使った）。つりあいの位置を原点にしたので、重力が消えて $-kx$ だけが残る（<a class="xlink" href="#3-3">③-3</a>）。</p>') +
    exQA('(4) 周期 $T$', '$T = 2\\pi\\sqrt{\\dfrac{M + m}{k}}$', '<p>' + eqTag('eom') + '$(M + m)a = -kx$ より $a = -\\dfrac{k}{M + m}x$。$a = -\\omega^2 x$ と比べて $\\omega = \\sqrt{\\dfrac{k}{M + m}}$。</p>') +
    exQA('(5) 運動方程式', '小物体：$Ma = N - Mg$　　台：$ma = k(d - x) - mg - N$', '<p>台は小物体から、垂直抗力の反作用 $N$（下向き）を受ける。</p>') +
    exQA('(6) 垂直抗力 $N$', '$N = Mg\\left(1 - \\dfrac{x}{d}\\right)$', '<p>2 式を足すと $(M + m)a = -kx$。$k = \\dfrac{(M + m)g}{d}$ なので $a = -\\dfrac{g}{d}x$。小物体の式に入れて $N = M(g + a) = Mg\\left(1 - \\dfrac{x}{d}\\right)$。</p>') +
    exQA('(7) $N$–$x$ グラフ', '傾きが負の直線（下の図）', '<div class="exfig"><canvas data-fig="nx" data-h="200"></canvas></div><p>$x = -s$ で $Mg\\left(1 + \\dfrac{s}{d}\\right)$、$x = 0$ で $Mg$、$x = d$ で $0$。$x > d$ では離れているので $N = 0$。</p>') +
    exQA('(8) 離れる位置 $x_0$', '$x_0 = d$', '<p>$N = 0$ より $x = d$。<b>ばねが自然の長さになる位置</b>で離れる。台だけのつりあいの位置（自然の長さより $\\dfrac{mg}{k}$ 下）を過ぎると、台の加速度は小物体（$-g$）より大きく下向きになるので、ここから先はいっしょに動けない。</p>') +
    exQA('(9) 離れる瞬間の速さ $v_0$', '$v_0 = g\\sqrt{\\dfrac{6M}{k}}$',
      '<p><b>単振動のエネルギー保存を使う。</b>小物体と台が一体で単振動している間（$-s \\le x \\le d$）は、つりあいの位置からの変位 $x$ を使って</p><p style="text-align:center">$\\dfrac{1}{2}(M + m)v^2 + \\dfrac{1}{2}kx^2 = $ 一定</p>' +
      '<p>が成りたつ。$\\dfrac{1}{2}kx^2$ は重力と弾性力の<b>合力</b>による位置エネルギー（③-2）なので、重力の位置エネルギーを別に足してはいけない。放した位置（$x = -s$、$v = 0$）と離れる位置（$x = d$、$v = v_0$）で比べると</p>' +
      '<p style="text-align:center">$\\dfrac{1}{2}ks^2 = \\dfrac{1}{2}(M + m)v_0^2 + \\dfrac{1}{2}kd^2$　より　$v_0 = \\sqrt{\\dfrac{k(s^2 - d^2)}{M + m}}$</p>' +
      '<p>$m = M$、$s = 2d$ を入れると $v_0^2 = \\dfrac{3kd^2}{2M}$。(1) より $d = \\dfrac{2Mg}{k}$ なので $v_0^2 = \\dfrac{3k}{2M}\\cdot\\dfrac{4M^2g^2}{k^2} = \\dfrac{6Mg^2}{k}$、$v_0 = g\\sqrt{\\dfrac{6M}{k}}$。</p>' +
      '<p>（別解）重力・弾性力の位置エネルギーを別々に使っても同じ答えになるが、計算はずっと長くなる。対応する円運動で見ると：半径 $s$ の円の上の点が $x = d$ の高さにあるとき、速さの $x$ 成分は $\\omega\\sqrt{s^2 - d^2}$（$\\omega = \\sqrt{\\dfrac{k}{M + m}}$）。</p>');
}
/* 解答・問題の図。key：setup（問題の図）／a〜e（時間の流れ）／nx（N–x グラフ） */
function m4s1Fig(key, ctx, W, H) {
  var q = m4s1Q({ v: { sr: 2.0 } }), Ln = M4.s1.Ln, xg = q.d - Ln, xTop = 0.56, S = (H - 34) / (xTop - xg), Y = function (x) { return H - 24 - (x - xg) * S; };
  var g = { Ln: Ln, S: S, ph: 6, pw: 40, bw: 28, bh: 20 };
  var spr = function (x, y1) { springDense(ctx, x, Y(xg), x, y1, Ln * S, { r: 7, lead: 4, k: q.k, thin: 0.7, Lmin: ((Ln - 3 * q.d) * S - 6) * 0.8 }); };
  var plat = function (x, y) { m4s1Plat(ctx, x, y, g); }, obj = function (x, yb) { m4s1Obj(ctx, x, yb, g); };
  if (key === 'nx') { drawM4S1NXStatic(ctx, W, H, q); return; }
  if (key === 'setup') {
    var xs = [W * 0.18, W * 0.48, W * 0.78];
    floorAt(ctx, 10, W - 10, Y(xg));
    spr(xs[0], Y(q.d) + 6); ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(xs[0] - 10, Y(q.d) + 6); ctx.lineTo(xs[0] + 10, Y(q.d) + 6); ctx.stroke(); ctx.restore();
    spr(xs[1], Y(0) + 6); plat(xs[1], Y(0)); obj(xs[1], Y(0));
    spr(xs[2], Y(-q.s) + 6); plat(xs[2], Y(-q.s)); obj(xs[2], Y(-q.s)); dropHand(ctx, xs[2] + 3, Y(-q.s) - g.bh + 3, 0.28, 1, 1);
    dotted(ctx, xs[0] - 30, Y(q.d) + 6, W - 8, Y(q.d) + 6, 'rgba(20,23,28,.35)', [3, 3]); dotted(ctx, xs[1] - 30, Y(0), W - 8, Y(0), 'rgba(192,57,43,.55)', [3, 3]); dotted(ctx, xs[2] - 30, Y(-q.s), W - 8, Y(-q.s), 'rgba(20,23,28,.35)', [3, 3]);
    dimLine(ctx, xs[1] + 30, Y(q.d) + 6, xs[1] + 30, Y(0)); sym(ctx, 'd', xs[1] + 38, (Y(q.d) + Y(0)) / 2, { size: 13, align: 'left' });
    dimLine(ctx, xs[2] + 30, Y(0), xs[2] + 30, Y(-q.s)); sym(ctx, 's', xs[2] + 38, (Y(0) + Y(-q.s)) / 2, { size: 13, align: 'left' });
    label(ctx, 'O', W - 12, Y(0) - 8, { size: 11, bold: true, color: '#c0392b', align: 'right' });
    ['(a)', '(b)', '(c)'].forEach(function (t, i) { label(ctx, t, xs[i], H - 8, { size: 11 }); });
    label(ctx, 'M', xs[1], Y(0) - g.bh / 2, { size: 10, bold: true }); label(ctx, '台 m', xs[1] - g.pw / 2 - 4, Y(0) + 3, { size: 9.5, align: 'right' });
    return;
  }
  /* 時間の流れの 1 コマ */
  var t = { a: 0, b: 0.02, c: q.T / 4, d: q.t1, e: q.t1 + 0.6 * (q.t2 - q.t1) }[key], st = m4s1At(q, t), cx = W * 0.46;
  floorAt(ctx, cx - 36, cx + 36, Y(xg));
  dotted(ctx, 6, Y(0), W - 6, Y(0), 'rgba(192,57,43,.5)', [3, 3]); dotted(ctx, 6, Y(q.d) + 6, W - 6, Y(q.d) + 6, 'rgba(20,23,28,.3)', [3, 3]);
  if (key === 'a') { label(ctx, 'O', W - 6, Y(0) - 7, { size: 9.5, color: '#c0392b', align: 'right' }); label(ctx, '自然長', W - 6, Y(q.d) - 1, { size: 9, color: '#5d6875', align: 'right' }); }
  spr(cx, Y(st.xp) + 6); plat(cx, Y(st.xp)); obj(cx, Y(st.xo));
  var fs = 13 / (q.M * G);
  if (key === 'a') { dropHand(ctx, cx + 3, Y(st.xo) - g.bh + 3, 0.26, 1, 1); fArrow(ctx, cx + 8, Y(st.xp) + 6, 0, -1, q.k * (q.d + q.s) * fs, COL.hand, null, { noShift: true }); fArrow(ctx, cx - 8, Y(st.xo) - g.bh, 0, 1, q.k * q.s * fs, '#1f8a4c', null, { noShift: true }); fArrow(ctx, cx, (Y(st.xo) - g.bh + Y(st.xp)) / 2, 0, 1, (q.M + q.m) * G * fs, COL.force, null, { noShift: true }); }
  else {
    fArrow(ctx, cx - 5, Y(st.xo) - g.bh / 2, 0, 1, q.M * G * fs, COL.force, null, { noShift: true });
    if (st.N > 1e-6) fArrow(ctx, cx + 5, Y(st.xo), 0, -1, st.N * fs, COL.norm, null, { noShift: true });
    var vr = st.vo / (q.s * q.w);
    if (Math.abs(vr) > 0.04) vArrowAt(ctx, cx, Y(st.xo) - g.bh, 0, -1, 10, 0, -1, vr * 30, false);
  }
  label(ctx, key === 'a' ? 'F = ks' : (st.N > 1e-6 ? 'N = ' + fmt(st.N / (q.M * G), 1) + 'Mg' : 'N = 0'), cx, H - 8, { size: 10.5, bold: true, color: key === 'a' ? '#1f8a4c' : COL.norm });
  drawEqualTicks(ctx);
}
function drawM4S1NXStatic(ctx, W, H, q) {
  var x0 = 40, x1 = W - 20, y0 = H - 28, y1 = 14, xl = -2.3 * q.d, xr = 2.3 * q.d, Nmax = 3.3 * q.M * G;
  var X = function (x) { return x0 + (x - xl) / (xr - xl) * (x1 - x0); }, Yn = function (n) { return y0 - n / Nmax * (y0 - y1); };
  axisArrow(ctx, x0 - 4, y0, x1 + 8, y0); axisArrow(ctx, X(0), y0 + 4, X(0), y1 - 6);
  sym(ctx, 'x', x1 + 8, y0 - 10, { size: 13 }); sym(ctx, 'N', X(0) + 10, y1 - 2, { size: 13, align: 'left' });
  [1, 2, 3].forEach(function (k) { dotted(ctx, x0, Yn(k * q.M * G), x1, Yn(k * q.M * G), 'rgba(20,23,28,.18)', [3, 3]); label(ctx, k === 1 ? 'Mg' : k + 'Mg', X(0) - 6, Yn(k * q.M * G), { size: 10, align: 'right' }); });
  [[-2, '−s'], [-1, '−d'], [1, 'd'], [2, 's']].forEach(function (r) { var xx = X(r[0] * q.d); dotted(ctx, xx, y1, xx, y0, 'rgba(20,23,28,.18)', [3, 3]); label(ctx, r[1], xx, y0 + 13, { size: 10 }); });
  label(ctx, 'O', X(0) + 7, y0 + 12, { size: 10.5, bold: true });
  ctx.save(); ctx.strokeStyle = COL.norm; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(X(-2 * q.d), Yn(3 * q.M * G)); ctx.lineTo(X(q.d), Yn(0)); ctx.lineTo(X(2 * q.d), Yn(0)); ctx.stroke(); ctx.restore();
}
