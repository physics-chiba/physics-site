/* =========================================================================
   50_mode1.js … モード① 単振動の基本的な物理量
   ①-1 単振動と等速円運動の関係（ライトで横から照らした影）
   ①-2 単振動の基本的な物理量（左に等速円運動、右に鉛直ばね振り子。「大きく／小さく」のボタン）
   ①-3 単振動のエネルギー（基本）（水平ばね振り子とエネルギー − 変位のグラフ）
   x の正の向き：①-1・①-2 は上向き（教科書 図 59）、①-3 は右向き
   ========================================================================= */
'use strict';
var DEFS = {};

/* ---------- 共通：初期位相 φ（①-2 はスライダー 9 段、ほかはボタン 5 択）とドラッグ ---------- */
var PHI = [-Math.PI, -3 * Math.PI / 4, -Math.PI / 2, -Math.PI / 4, 0, Math.PI / 4, Math.PI / 2, 3 * Math.PI / 4, Math.PI];
var PHITEX = ['-\\pi', '-\\dfrac{3\\pi}{4}', '-\\dfrac{\\pi}{2}', '-\\dfrac{\\pi}{4}', '0', '\\dfrac{\\pi}{4}', '\\dfrac{\\pi}{2}', '\\dfrac{3\\pi}{4}', '\\pi'];
/* x = A sin(ωt + φ) に代入した結果 */
var PHISUB = ['A\\sin(\\omega t - \\pi) = -A\\sin\\omega t', 'A\\sin\\left(\\omega t - \\dfrac{3\\pi}{4}\\right)', 'A\\sin\\left(\\omega t - \\dfrac{\\pi}{2}\\right) = -A\\cos\\omega t', 'A\\sin\\left(\\omega t - \\dfrac{\\pi}{4}\\right)',
  'A\\sin(\\omega t + 0) = A\\sin\\omega t', 'A\\sin\\left(\\omega t + \\dfrac{\\pi}{4}\\right)', 'A\\sin\\left(\\omega t + \\dfrac{\\pi}{2}\\right) = A\\cos\\omega t', 'A\\sin\\left(\\omega t + \\dfrac{3\\pi}{4}\\right)', 'A\\sin(\\omega t + \\pi) = -A\\sin\\omega t'];
var PHI5 = [0, 2, 4, 6, 8];                                     /* ボタン 5 択：−π, −π/2, 0, π/2, π */
function phiIdx(p) { var b = 0; PHI.forEach(function (q, i) { if (Math.abs(q - p) < Math.abs(PHI[b] - p)) b = i; }); return b; }
/* five：ボタンの 5 択（①-2 以外）。そうでなければ ①-2 の 9 段のスライダー（−3π/4・3π/4 も選べる） */
function phiVar(def0, five) {
  var ids = five ? PHI5 : PHI.map(function (q, i) { return i; });
  var i0 = ids.indexOf(4), i2 = ids.indexOf(6);
  return { k: 'phi', label: '初期位相 $\\phi$', aria: '初期位相', stops: ids.map(function (i) { return PHI[i]; }), prop: !five, seg: !!five, modTau: !!five, def: def0,   /* modTau：π と −π は同じ角なので、両方のボタンを ON に見せる（2026-10-25 千葉さん） */
   
    stopLabels: ids.map(function (i) { return '$' + (five ? PHITEX[i] : PHITEX[i].replace(/\\dfrac/g, '\\tfrac')) + '$'; }),
    stopNotes: five ? [] : [{ i: i0, html: '中心で<br>初速度' }, { i: i2, html: '端で<br>放す' }],   /* ボタンのときは注記なし（2026-10-16 千葉さん） */
    fmt: function (x) { return '$\\phi = ' + PHITEX[phiIdx(x)] + '$'; },
    eqLine: function (s) { return five ? '$x = A\\sin(\\omega t + \\phi)$<br>$\\phantom{x} = ' + PHISUB[phiIdx(s.v.phi)] + '$'   /* ボタンのときは小さく 2 行 */
      : '$x = A\\sin(\\omega t + \\phi) = ' + PHISUB[phiIdx(s.v.phi)] + '$'; } };
}
/* スタートの手：t = 0 で速度が 0 なら指でつまんで「そっと放す」。速度があればデコピンで「初速度を与える」（向きは初速の向き）。
   スタート前（t = 0 で止まっている）は、手の位置に吹き出しで「そっと放す」「初速度を与える」と書く（2026-10-16 千葉さん）。
   時間は見た目の時間（再生の速さ base で割る）で考える。
   ・そっと放す：指を開くのに 0.08 s、そのあと 0.14 s で消える
   ・デコピン：手の位置は動かさず、0.05 s ではじき、0.27 s で消える（前の 80 %）
   opt.flip：手を上下逆に（下から支える。鉛直・斜面のばね振り子） */
function startHand(s, ctx, bx, by, rb, dir, v0, opt) {
  opt = opt || {};
  if (s.dragging) return;
  var t = s.t / (s.base || 1), pre = s.t === 0 && !s.playing, rv = opt.hh || rb;   /* opt.hh：物体の縦の半分（おもりを重ねたとき） */
  if (Math.abs(v0) > 1e-9) {
    if (t >= 0.27) return;
    var k = clamp(t / 0.05, 0, 1), a = (t <= 0.07) ? 1 : Math.max(0, 1 - (t - 0.07) / 0.2); if (a <= 0.02) return;
    /* はじく向き u と、指が当たる物体の表面の点 C を決め、はじく前の指先が C のすぐ手前に来るように手の中心を置く。
       はじいた指先は物体の裏に少しもぐる（物体はあとから描くので隠れる）。2026-10-19 千葉さん */
    var hx, hy, ang, dr, ux, uy, cx, cy;
    if (dir === 'up') {                                     /* 縦：上向きなら下から、下向きなら右上から（ばねと重ねない） */
      if (v0 > 0) { ux = 0; uy = -1; dr = 1; cx = bx; cy = by + rv; }
      else { ux = -Math.sin(0.35); uy = Math.cos(0.35); dr = -1; cx = bx + rb * 0.8; cy = by - rv; }
    } else {                                                /* 横：ばねと重ならないよう上からななめに */
      if (v0 > 0) { ux = Math.cos(0.55); uy = Math.sin(0.55); dr = 1; }
      else { ux = -Math.cos(0.55); uy = Math.sin(0.55); dr = -1; }
      cx = bx - ux * rb; cy = by - uy * rb;
    }
    ang = Math.atan2(uy, ux) + (dr < 0 ? Math.PI : 0);
    var ca = Math.cos(ang), sa = Math.sin(ang), lx = dr * 52, ly = -16;   /* はじく前の指先（手の中心から。flickHand の座標） */
    hx = cx - (lx * ca - ly * sa) * 0.42 - ux * 2; hy = cy - (lx * sa + ly * ca) * 0.42 - uy * 2;
    flickHand(ctx, hx, hy, ang, k, dr, 0.42, a);
    if (pre) { if (hx < bx - 1) handBubble(ctx, '初速度を与える', hx - 34, hy, 'l', opt.bubGap); else handBubble(ctx, '初速度を与える', hx + 32, hy, 'r', opt.bubGap); }
    return;
  }
  if (t > 0.22) return;
  var open = clamp(t / 0.08, 0, 1), al = t <= 0.08 ? 1 : Math.max(0, 1 - (t - 0.08) / 0.14), sc = 0.42 * rb / 13;
  var ay = by + (opt.hh ? (opt.flip ? 1 : -1) * (opt.hh - 7) : 0);
  if (!opt.bubOnly) dropHandAt(ctx, bx, ay, sc, open, al, opt.flip);
  if (pre && !opt.noBub) {   /* opt.noBub：吹き出しはあとで（bubOnly で）描く。ほかの絵より前に出すため */                                                       /* opt.bubPos：'r'（手の右・ふつう）／'l'（手の左）／'d'（手の下）。ほかの絵と重ならない所を選ぶ（2026-10-19 千葉さん） */
    var fy = opt.flip ? 1 : -1, pos = opt.bubPos || 'r', gp = 9 + (opt.bubGap || 0), bw = handBubbleW(ctx, HOLD_TXT);
    if (pos === 'r' && CVW && bx + 98 * sc + gp + bw > CVW - 4) pos = 'l';          /* 右に入らなければ手の左へ（手や物体に重ねない） */
    else if (pos === 'l' && bx - 75 * sc - gp - bw < 4) pos = 'r';
    if (pos === 'l') handBubble(ctx, HOLD_TXT, bx - 75 * sc, ay + fy * 45 * sc + (opt.bubDy || 0), 'l', opt.bubGap);
    else if (pos === 'd') handBubble(ctx, HOLD_TXT, bx + 30 * sc, ay + (opt.flip ? 100 : 30) * sc + (opt.bubDy || 0), 'd', opt.bubGap);
    else handBubble(ctx, HOLD_TXT, bx + 98 * sc, ay + fy * 62 * sc + (opt.bubDy || 0), 'r', opt.bubGap);
  }   /* 手の右に（矢印は手を指す） */
}
/* 指でつまむ手。flip なら上下を逆に（小球の下から支える） */
function dropHandAt(ctx, x, y, sc, open, al, flip) {
  if (!flip) { dropHand(ctx, x, y, sc, open, al); return; }
  ctx.save(); ctx.translate(x, y); ctx.scale(1, -1); dropHand(ctx, 0, 0, sc, open, al); ctx.restore();
}
/* 手の位置の吹き出し（スタート前だけ）。(x, y)＝手のはし。side 'r'：吹き出しは右、矢印は左（手）を指す／'l'：その逆。
   ばね・物体・力の矢印と重ならないよう、手の横に出す（2026-10-16 千葉さん） */
var HOLD_TXT = 'つりあいから\nずらしてから\nそっと放す';   /* スタート前の吹き出し（2026-10-19 千葉さん） */
function handBubbleFont() { return CVW && CVW < 480 ? 11 : 12; }   /* せまい画面では少し小さく */
function handBubbleW(ctx, txt) { ctx.save(); ctx.font = 'bold ' + handBubbleFont() + 'px ' + FONT; var w = Math.max.apply(null, String(txt).split('\n').map(function (t) { return ctx.measureText(t).width; })) + 18; ctx.restore(); return w; }
function handBubble(ctx, txt, x, y, side, gap) {
  ctx.save(); ctx.font = 'bold ' + handBubbleFont() + 'px ' + FONT;
  var lines = String(txt).split('\n'), lh = handBubbleFont() + 3;                   /* 改行（\n）で複数行に（2026-10-19 千葉さん） */
  var w = Math.max.apply(null, lines.map(function (t) { return ctx.measureText(t).width; })) + 18, h = 11 + lh * lines.length, T = 9 + (gap || 0), r = side !== 'l';
  if (side === 'd') {                                               /* 下に出す（矢印は上へ） */
    var dx = clamp(x - w / 2, 4, Math.max(4, (CVW || 999) - 4 - w)), dy = Math.min(y + T, Math.max(4, (CVH || 999) - 4 - h)), tx = clamp(x, dx + 10, dx + w - 10);
    ctx.fillStyle = '#fff5e8'; ctx.strokeStyle = '#e07b18'; ctx.lineWidth = 1.4;
    ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(dx, dy, w, h, 10); else ctx.rect(dx, dy, w, h);
    ctx.save(); ctx.shadowColor = 'rgba(20,23,28,.16)'; ctx.shadowBlur = 12; ctx.shadowOffsetY = 3; ctx.fill(); ctx.restore(); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(tx - 6, dy); ctx.lineTo(x, y); ctx.lineTo(tx + 6, dy); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(tx - 6, dy); ctx.lineTo(x, y); ctx.lineTo(tx + 6, dy); ctx.stroke();
    ctx.fillStyle = '#a85c0c'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    lines.forEach(function (t, i) { ctx.fillText(t, dx + w / 2, dy + h / 2 + 0.5 + (i - (lines.length - 1) / 2) * lh); });
    ctx.restore(); return;
  }   /* gap：横の矢印などをよけて、吹き出しを遠くに（矢印は長くなる） */
  if (r && CVW && x + T + w > CVW - 4) r = false;                  /* 右に場所がなければ左へ */
  if (!r && x - T - w < 4) r = true;
  var bx = r ? x + T : x - T - w, by = clamp(y - h / 2, 4, Math.max(4, (CVH || 999) - 4 - h)), ty = clamp(y, by + 7, by + h - 7);
  ctx.fillStyle = '#fff5e8'; ctx.strokeStyle = '#e07b18'; ctx.lineWidth = 1.4;
  ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(bx, by, w, h, 10); else ctx.rect(bx, by, w, h);
  ctx.save(); ctx.shadowColor = 'rgba(20,23,28,.16)'; ctx.shadowBlur = 12; ctx.shadowOffsetY = 3; ctx.fill(); ctx.restore(); ctx.stroke();
  var ex = r ? bx : bx + w;                                         /* 矢印（手の向き） */
  ctx.beginPath(); ctx.moveTo(ex, ty - 6); ctx.lineTo(x, y); ctx.lineTo(ex, ty + 6); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(ex, ty - 6); ctx.lineTo(x, y); ctx.lineTo(ex, ty + 6); ctx.stroke();
  ctx.fillStyle = '#a85c0c'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  lines.forEach(function (t, i) { ctx.fillText(t, bx + w / 2, by + h / 2 + 0.5 + (i - (lines.length - 1) / 2) * lh); });
  ctx.restore();
}

/* =====================================================================
   ①-1 単振動と等速円運動の関係
   ===================================================================== */
function m1s1Geo(W, H) {
  var R = Math.min(W * 0.16, H * 0.29), cy = H * 0.50, lx = Math.max(W * 0.10, 40);
  var cx = Math.max(lx + R + 34, W * 0.30), xw = cx + R + Math.max(26, W * 0.07);
  var g0 = xw + 26, g1 = W - 22;
  return { R: R, cx: cx, cy: cy, lx: lx, xw: xw, g0: g0, g1: g1 };
}
DEFS.m1s1 = {
  id: 'm1s1', mode: 'mode1', num: 1,
  title: '単振動と等速円運動の関係',
  desc: '等速円運動をしている小球に、真横からライトの光を当てて、壁に映る影を見る。ライトをつけた時刻を $t = 0$ として、影の位置を記録する。<span class="todo">スタートで円運動が始まる。いろいろなタイミングで「ライトを点灯」を押して、記録されるグラフの形と式 $x = A\\sin(\\omega t + \\phi)$ の $\\phi$ を見比べよう。</span>',
  strobe: false, noDefBtn: true,
  tEnd: function () { return tBarOf(2); },
  init: function (s) { s.light = false; s.tOn = null; },
  onDefaults: function (s) { s.light = false; s.tOn = null; m1s1Sync(s); },
  onReset: function (s) { if (s.light) s.tOn = 0; m1s1Sync(s); },
  onRestart: function (s) { if (s.light) s.tOn = 0; },
  buttons: [{ k: 'light', label: '💡 ライトを<br>点灯', cls: 'lightb two', afterPlay: true, onClick: function (s) {
    s.light = !s.light; s.tOn = s.light ? m1s1Snap(s.t) : null; m1s1Sync(s); s.draw(); s.renderRight();
  } }],
  afterBuild: function (s) { m1s1Sync(s); },
  tInfo: function (s) { return periodInfo(TAU / M1.s1.w); },
  stepT: function () { return TAU / M1.s1.w; },
  height: function (s, w) { return Math.round(clamp(w * 0.56, 260, 420)); },
  live: function (s) { m1s1Sync(s); },
  /* 図の下の説明（左下）は出さない（2026-10-16 千葉さん） */
  draw: function (s, ctx, W, H) { drawM1S1(s, ctx, W, H); },
  right: function (s, R) { rightM1S1(s, R); }
};
/* ライトをつける時刻：押した時刻にいちばん近い T/8 の倍数（その時刻を t = 0 とする。2026-10-16 千葉さん） */
function m1s1Snap(t) { var q = TAU / M1.s1.w / 8; return Math.round(t / q) * q; }
/* ライトをつけたときの P の角（初期位相 φ）。−π〜π の 9 つのどれか（PHI の番号） */
function m1s1Phi(s) { if (s.tOn === null || s.tOn === undefined) return 4; var a = M1.s1.w * s.tOn; a = a - TAU * Math.round(a / TAU); if (a <= -Math.PI + 1e-6) a = Math.PI; return phiIdx(a); }
function m1s1Sync(s) {
  var b = s.extra && s.extra.light; if (!b) return;
  var txt = s.light ? '💡 ライトを<br>消す' : '💡 ライトを<br>点灯';
  if (b._h !== txt) { b._h = txt; b.innerHTML = txt; }
  b.classList.toggle('on', s.light);
  var want = !s.light && s.t > 0;                          /* 円運動が始まったら、押されるまで光らせる */
  if (b.classList.contains('glow') !== want) b.classList.toggle('glow', want);
}
function drawM1S1(s, ctx, W, H) {
  var g = m1s1Geo(W, H), A = M1.s1.A, w = M1.s1.w, T = TAU / w, S = g.R / A;
  var th = w * s.t, px = g.cx + g.R * Math.cos(th), py = g.cy - g.R * Math.sin(th), rb = Math.max(7, g.R * 0.11);
  var wallTop = g.cy - g.R * 1.5, wallBot = g.cy + g.R * 1.5;
  /* 光（点灯しているときだけ）：縦に並べた 2 つのライトから、左から右へまっすぐ（平行な光） */
  var lh = g.R * 1.25, lyT = g.cy - lh * 0.52, lyB = g.cy + lh * 0.52, bT = lyT - lh / 2 + 3, bB = lyB + lh / 2 - 3;
  if (s.light) {
    ctx.save();
    var gr = ctx.createLinearGradient(g.lx, 0, g.xw, 0); gr.addColorStop(0, 'rgba(255,211,77,.30)'); gr.addColorStop(1, 'rgba(255,211,77,.16)');
    ctx.fillStyle = gr; ctx.fillRect(g.lx, bT, g.xw - g.lx, bB - bT);
    ctx.strokeStyle = 'rgba(224,152,24,.75)'; ctx.lineWidth = 1.3; ctx.setLineDash([6, 4]);
    for (var ri = 0; ri < 3; ri++) { var ry = g.cy + (ri - 1) * g.R;   /* 光の線は 3 本：x = A・0・−A の高さ（2026-10-16 千葉さん） */
      ctx.beginPath(); ctx.moveTo(g.lx + 4, ry); ctx.lineTo(g.xw - 8, ry); ctx.stroke();
      ctx.setLineDash([]); ctx.fillStyle = 'rgba(224,152,24,.75)'; ctx.beginPath(); ctx.moveTo(g.xw - 3, ry); ctx.lineTo(g.xw - 9, ry - 3); ctx.lineTo(g.xw - 9, ry + 3); ctx.closePath(); ctx.fill(); ctx.setLineDash([6, 4]);
    }
    ctx.setLineDash([]); ctx.restore();
    label(ctx, '光', (g.lx + g.cx) / 2 + 6, bT - 10, { size: 11.5, color: '#b26b00' });
  }
  lampShape(ctx, g.lx, lyT, lh, s.light); lampShape(ctx, g.lx, lyB, lh, s.light);
  label(ctx, s.light ? 'ライト' : 'ライト（消灯）', g.lx - 12, bB + 14, { size: 11.5, color: COL.ink2 });
  /* 壁 */
  ctx.save(); ctx.fillStyle = s.light ? '#fbf3dc' : '#eceae4'; ctx.strokeStyle = '#8d9097'; ctx.lineWidth = 1.2;
  ctx.fillRect(g.xw, wallTop, 9, wallBot - wallTop); ctx.strokeRect(g.xw, wallTop, 9, wallBot - wallTop); ctx.restore();
  label(ctx, s.light ? '壁（影が単振動）' : '壁', g.xw + 4.5, wallBot + 14, { size: 11.5, color: COL.ink2, bold: s.light });
  /* 円と小球 */
  ctx.save(); ctx.strokeStyle = '#8d9097'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.arc(g.cx, g.cy, g.R, 0, TAU); ctx.stroke();
  ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.3; ctx.beginPath(); ctx.moveTo(g.cx, g.cy); ctx.lineTo(px, py); ctx.stroke();
  ctx.fillStyle = '#3a414c'; ctx.beginPath(); ctx.arc(g.cx, g.cy, 2.6, 0, TAU); ctx.fill(); ctx.restore();
  spinArrow(ctx, g.cx, g.cy, g.R + 13, g.R + 13, -0.25, -1.05, '#3a414c', 1.8);
  sym(ctx, 'ω', g.cx + (g.R + 26) * Math.cos(0.65), g.cy - (g.R + 26) * Math.sin(0.65), { size: 15 });
  label(ctx, '等速円運動', g.cx, g.cy + g.R + 18, { size: 11.5, color: COL.ink2 });
  if (s.light) {
    dotted(ctx, px + rb, py, g.xw, py, 'rgba(20,23,28,.6)');
    /* 影（壁の面に映る） */
    ctx.save(); ctx.fillStyle = 'rgba(20,23,28,.82)'; ctx.beginPath(); ctx.ellipse(g.xw + 1.5, py, 3.5, rb, 0, 0, TAU); ctx.fill(); ctx.restore();
  }
  if (!s.playing) radiusA(ctx, g.cx, g.cy, px, py, Math.sin(th) >= 0 ? -1 : 1);   /* 止まっているときだけ、半径に両矢印と A */
  ballShape(ctx, px, py, rb, '#d9b77a');
  /* 壁の右：影の位置の記録（x–t グラフ）。窓は 2 周期ぶん。右端まで行ったら、左に戻ってなぞる */
  var gw = g.g1 - g.g0, Tw = 2 * T, X = function (tt) { return g.g0 + tt / Tw * gw; }, Y = function (x) { return g.cy - x * S; };
  ctx.save(); ctx.strokeStyle = 'rgba(20,23,28,.10)'; ctx.lineWidth = 1;
  [A, -A].forEach(function (x) { ctx.setLineDash([3, 3]); ctx.beginPath(); ctx.moveTo(g.g0, Y(x)); ctx.lineTo(g.g1, Y(x)); ctx.stroke(); });
  ctx.setLineDash([]); ctx.restore();
  axisArrow(ctx, g.g0, wallBot, g.g0, wallTop - 4);
  axisArrow(ctx, g.g0, g.cy, g.g1 + 10, g.cy);
  sym(ctx, 'x', g.g0 + 9, wallTop + 2, { size: 14, align: 'left' });
  sym(ctx, 't', g.g1 + 6, g.cy - 11, { size: 14, align: 'right' });
  sym(ctx, 'A', g.g0 - 5, Y(A), { size: 13, align: 'right' }); sym(ctx, '−A', g.g0 - 5, Y(-A), { size: 13, align: 'right' });
  label(ctx, 'O', g.g0 - 9, g.cy + 9, { size: 11, halo: false });
  for (var n = 1; n <= 8; n++) { var xx = X(n * T / 4); ctx.save(); ctx.strokeStyle = '#2b323c'; ctx.beginPath(); ctx.moveTo(xx, g.cy - 3); ctx.lineTo(xx, g.cy + 3); ctx.stroke(); ctx.restore(); if (n % 2 === 0) tFracLabel(ctx, n, xx, g.cy + 4); }
  /* グラフの t は、ライトをつけた時刻 tOn から測る（t′ = t − tOn）。だから cos 型・−sin 型などにもなる */
  if (s.light && s.tOn !== null && s.t > s.tOn) {
    var el1 = s.t - s.tOn, pass = Math.floor(el1 / Tw + 1e-9);
    for (var k = 0; k <= pass; k++) {
      var ta = k * Tw, tb = Math.min(el1, (k + 1) * Tw); if (tb <= ta) continue;
      var cur = (k === pass);
      ctx.save(); ctx.strokeStyle = cur ? '#14171c' : 'rgba(20,23,28,.38)'; ctx.lineWidth = cur && pass > 0 ? 3 : 2.2; ctx.beginPath();
      for (var i = 0, N = Math.max(2, Math.ceil(200 * (tb - ta) / Tw)); i <= N; i++) { var tt = ta + (tb - ta) * i / N, yy = Y(A * Math.sin(w * (tt + s.tOn))); i ? ctx.lineTo(X(tt - k * Tw), yy) : ctx.moveTo(X(tt - k * Tw), yy); }
      ctx.stroke(); ctx.restore();
    }
    var xc = X(el1 - pass * Tw);
    dotted(ctx, g.xw + 9, py, xc, py, 'rgba(20,23,28,.25)');
    ctx.save(); ctx.fillStyle = '#14171c'; ctx.beginPath(); ctx.arc(xc, py, 3.4, 0, TAU); ctx.fill(); ctx.restore();
    if (s.t - s.tOn >= T) bubble(ctx, '正弦曲線', X(1.25 * T), Y(A) - 6, { size: 13, bg: '#fff5d6', border: '#d9a545', color: '#8a5000' });
  }
  drawEqualTicks(ctx);
}
function rightM1S1(s, R) {
  var T = TAU / M1.s1.w;
  var h = '<div class="qcard"><p class="qt">等速円運動を真横から見ると</p>' +
    '<p>半径 $A$、角速度 $\\omega$ の等速円運動をする小球に、真横から光を当てる。壁に映る影は、壁の上を<b>上下に往復</b>する。この影の運動が<b>単振動</b>である。</p>' +
    '<p>ライトをつけた時刻を $t = 0$ とし、そのとき小球が水平（右）から角 $\\phi$ の位置にいたとすると、時刻 $t$ の角は $\\omega t + \\phi$。影の位置（変位）$x$ は</p>' +
    '<div class="qeq">$$x = A\\sin(\\omega t + \\phi)$$</div>' +
    '<p>影の位置を時間の経過とともに並べたグラフは<b>正弦曲線</b>になる。ライトをつけるタイミングで $\\phi$ が変わり、$\\cos$ 型や $-\\sin$ 型のグラフにもなる（この $\\phi$ を<b>初期位相</b>という）。</p>' +
    (s.tOn !== null && s.tOn !== undefined ? '<p class="qnow"><span class="qtag now">いま</span>ライトをつけたのは、円運動のスタートから ' + fmt(s.tOn, 2) + ' s 後（$\\tfrac{T}{8}$ 刻み）。$\\phi = ' + PHITEX[m1s1Phi(s)] + '$ なので　$x = ' + PHISUB[m1s1Phi(s)] + '$</p>' : '') + '</div>' +
    '<details class="qcard m2card m11tab"><summary class="qt">単振動の物理量の解説</summary><table class="reltab grid1"><tbody>' +
    '<tr><th>振幅 $A$〔m〕</th><td class="l">振動の中心から端までの長さ（円の半径）</td></tr>' +
    '<tr><th>周期 $T$〔s〕</th><td class="l">1 回の振動にかかる時間（円運動の周期と同じ）</td></tr>' +
    '<tr><th>振動数 $f$〔Hz〕</th><td class="l">1 秒あたりの振動の回数　$f = \\dfrac{1}{T}$</td></tr>' +
    '<tr><th>角振動数 $\\omega$〔rad/s〕</th><td class="l">円運動の角速度にあたる量　$\\omega = \\dfrac{2\\pi}{T} = 2\\pi f$</td></tr>' +
    '<tr><th>位相 $\\omega t$〔rad〕</th><td class="l">どのような振動状態かを表す角。$2\\pi$ 進むごとに 1 回振動する</td></tr>' +
    '</tbody></table>' +
    '<p class="qnow"><span class="qtag now">この図では</span>$A = ' + fmt(M1.s1.A, 2) + '$ m、$\\omega = \\pi$ rad/s、$T = \\dfrac{2\\pi}{\\omega} = ' + fmt(T, 1) + '$ s</p></details>';
  R.innerHTML = mathify(h);
  var dt = R.querySelector('details.m11tab');                       /* 最初はたたんでおく（開いたら、描き直しても開いたまま） */
  if (dt) { dt.open = !!s.tabOpen; dt.addEventListener('toggle', function () { s.tabOpen = dt.open; }); }
}


/* =====================================================================
   ①-2 単振動の基本的な物理量（等速円運動と並べる）
   左の列：アニメ（変位・速度・加速度のベクトル）→「等速円運動と単振動の対応」
   右の列：スライダー（circular-motion.html ①-1 と同じ形）→ x–t・v–t・a–t グラフ → 解説カード
   グラフの縦の長さはアニメのベクトルの長さと同じ（px）。x：S、v：0.8 S/ω、a：0.6 S/ω²
   ===================================================================== */
var M1S2V = 0.8, M1S2A = 0.6;                                 /* 円の半径に対する速度・加速度ベクトルの長さの比 */
function m1s2Q(s) {
  var A = s.dragX !== undefined ? Math.abs(s.dragX) : s.v.A, m = s.v.m, k = s.v.k, w = SHM.omega(k, m);
  var phi = s.dragX !== undefined ? (s.dragX < 0 ? -Math.PI / 2 : Math.PI / 2) : s.v.phi;
  return { A: A, m: m, k: k, w: w, T: TAU / w, f: w / TAU, phi: phi };
}
DEFS.m1s2 = {
  id: 'm1s2', mode: 'mode1', num: 2,
  title: '単振動の基本的な物理量',
  desc: '左は半径 $A$ の等速円運動、右はばね振り子の単振動。変位・速度・加速度のベクトルと、それぞれのグラフ（右）を見比べる。<span class="todo">振幅 $A$・ばね定数 $k$・おもりの数（質量 $m$）・初期位相 $\\phi$ を変えて、他の量がどう変わるか見よう。スタート前におもりをドラッグして振幅を変えることもできる。</span>',
  strobe: false, showFBtn: true, fDefault: 'net', vecBtn: 'x, v, a を消す', graphs: true, stgCls: 'solo', belowCanvas: true,
  varCols: [['A', 'k', 'm'], ['vm', 'am', 'w', 'T', 'f']], varWide: ['phi'],   /* φ のスライダーは ①-3 の前のスライダーの半分くらいの長さ（CSS で幅をおさえる） */
  varColNote: { 1: '以下の 5 つは、左の値で決まる（直接は変えられない）' },
  vars: [
    { k: 'A', label: '振幅 $A$', aria: '振幅', stops: M1.s2.A, stopLabels: ['0.04', '0.06', '0.08', '0.10', '0.12', '0.14 m'], def: M1.s2.A0, cls: 'grpA',
      fmt: function (x) { return (M1.s2.A.some(function (q) { return Math.abs(q - x) < 1e-9; }) ? fmt(x, 2) : fmt(x, 3)) + ' m'; } },
    { k: 'k', label: 'ばね定数 $k$', aria: 'ばね定数', stops: M1.s2.k, stopLabels: ['2.5', '5', '10', '20', '40 N/m'], def: M1.s2.k0, fmt: function (x) { return (x % 1 ? fmt(x, 1) : fmt(x, 0)) + ' N/m'; } },
    { k: 'm', label: 'おもりの数（質量 $m$）', aria: 'おもりの数', stops: M1.s2.m, stopLabels: ['1', '2', '3', '4', '5', '6 個'], def: M1.s2.m0, fmt: function (x) { return Math.round(x / M1.s2.mW) + ' 個（' + fmt(x, 2) + ' kg）'; } },
    { k: 'w', label: '角振動数 $\\omega$', aria: '角振動数', min: 0, max: 13, step: 0.01, def: 0, meter: true, cls: 'grpW', fmt: function (x) { return fmt(x, 2) + ' rad/s'; } },
    { k: 'T', label: '周期 $T$', aria: '周期', min: 0, max: 8, step: 0.01, def: 0, meter: true, cls: 'grpW', fmt: function (x) { return sig2(x) + ' s'; } },
    { k: 'f', label: '振動数 $f$', aria: '振動数', min: 0, max: 2.1, step: 0.001, def: 0, meter: true, cls: 'grpW', fmt: function (x) { return fmt(x, 2) + ' Hz'; } },
    { k: 'vm', label: '速さの最大値 $A\\omega$', aria: '速さの最大値', min: 0, max: 1.8, step: 0.01, def: 0, meter: true, cls: 'grpA', fmt: function (x) { return fmt(x, 2) + ' m/s'; } },
    { k: 'am', label: '加速度の最大値 $A\\omega^2$', aria: '加速度の最大値', min: 0, max: 23, step: 0.01, def: 0, meter: true, cls: 'grpA', fmt: function (x) { return fmt(x, 2) + ' m/s²'; } },
    phiVar(0, false)
  ],
  disp: function (s, k) { var q = m1s2Q(s); return { w: q.w, T: q.T, f: q.f, vm: q.A * q.w, am: q.A * q.w * q.w }[k] !== undefined ? { w: q.w, T: q.T, f: q.f, vm: q.A * q.w, am: q.A * q.w * q.w }[k] : s.v[k]; },
  init: function (s) { s.sel = null; },
  onDefaults: function (s) { s.sel = null; m1s2Focus(s, null); shmGraphReset(s); },
  /* アニメの左上：「変位 x に注目する」など（押すと、ほかの量の矢印とグラフをたたむ。もう一度押すと元に戻る。2026-10-16 千葉さん） */
  buttons: [{ k: 'fx', label: '変位 $x$ に注目する', cls: 'focb', inCanvas: true, onClick: function (s) { m1s2Focus(s, s.focus === 'x' ? null : 'x'); } },
    { k: 'fv', label: '速度 $v$ に注目する', cls: 'focb', inCanvas: true, onClick: function (s) { m1s2Focus(s, s.focus === 'v' ? null : 'v'); } },
    { k: 'fa', label: '加速度 $a$ に注目する', cls: 'focb', inCanvas: true, onClick: function (s) { m1s2Focus(s, s.focus === 'a' ? null : 'a'); } },
    /* 注目しているときだけ、そのボタンの右に「コマ送り」（上のコマ送りと同じ。光らせる）。「さらに詳しく」は廃止し、その書きこみは注目したときに出す（2026-10-18 千葉さん） */
    { k: 'fs', label: 'コマ<br>送り', cls: 'focb fstepb glow', inCanvas: true, onClick: function (s) { s.stepFrame(); } }],
  /* おもりの数（質量）を変えても止めずに続ける：いまの位相 ωt + ϕ を保つように時刻をなおす（グラフは描き直す）。2026-10-18 千葉さん */
  onChanged: function (s, k) {
    if (k === 'm' && s._wPrev) { var w1 = m1s2Q(s).w; s.t = s.t * s._wPrev / w1; s._wPrev = w1; if (s.graphs) shmGraphReset(s); return 'keepT'; }
    s._wPrev = m1s2Q(s).w; if (s.graphs) shmGraphReset(s);
  },
  onPick: function (s, k) { var map = { vm: 'v', am: 'a', f: 'T' }; k = map[k] || k; s.sel = (s.sel === k ? null : k); s.renderRight(); s.draw(); },
  afterBuild: function (s) {
    shmGraphs(s, m1s2Graphs());
    /* 右の列：スライダー → グラフ → 解説（解説だけを描き直す） */
    s.R.innerHTML = ''; var sw = el('div', 'row2 sliders inR'); sw.appendChild(s.varbox); s.R.appendChild(sw); s.varbox.classList.add('inR');   /* .sliders の中に入れる（スライダーの目盛りの位置の CSS がそのまま効く） */
    s.R.appendChild(s.gHost); s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);
    s.bStep.classList.add('glow'); s._wPrev = m1s2Q(s).w;          /* コマ送りを光らせる（2026-10-18 千葉さん） */
    m1s2Focus(s, null);
  },
  tEnd: function (s) { return tBarOf(m1s2Q(s).T); },
  tInfo: function (s) { return periodInfo(m1s2Q(s).T); },
  gq: function (s, t) { var q = m1s2Q(s); return SHM.st(q.A, q.w, q.phi, t); },
  gWin: function (s) { return 2 * m1s2Q(s).T; },
  gT: function (s) { return m1s2Q(s).T; },
  gAmp: function (s) { var q = m1s2Q(s); return { x: q.A, v: q.A * q.w, a: q.A * q.w * q.w }; },
  height: function (s, w) { return Math.round(clamp(w * 0.62, w < 480 ? 360 : 300, 430)); },   /* せまい画面では、スタート前の吹き出しの場所を下にとる */
  dragHit: function (s, x, y) { var G2 = m1s2Geo(s.W, s.H), b = m1s2Ball(s, G2); return Math.abs(x - G2.xs) < b.rb + 10 && Math.abs(y - b.y) < b.hh + 10; },
  dragMove: function (s, x, y) { var G2 = m1s2Geo(s.W, s.H), xv = clamp((G2.cy - y) / G2.S, -0.14, 0.14); if (Math.abs(xv) < 0.02) xv = xv < 0 ? -0.02 : 0.02; s.dragX = xv; },
  dragEnd: function (s) { if (s.dragX === undefined) return; s.v.A = Math.abs(s.dragX); s.v.phi = s.dragX < 0 ? -Math.PI / 2 : Math.PI / 2; s.dragX = undefined; },
  draw: function (s, ctx, W, H) { drawM1S2(s, ctx, W, H); },
  right: function (s, R) { rightM1S2(s); }
};
/* 「〜に注目する」：x・v・a のどれか 1 つだけを見せる（もう一度押すと元に戻る）。
   ・x／v：ほかの 2 つの矢印とグラフをたたみ、力の矢印も出さない ・a：x・v をたたみ、「合力のみを表示」を ON
   ・どれかを押したら「x, v, a を消す」は OFF。▶ スタート・リセットでは変わらない。「すべて最初の設定に戻す」で解除 */
function m1s2Focus(s, k) {
  s.focus = k;
  if (k && s.hideVec) { s.hideVec = false; if (s.extra.vec) { s.extra.vec.classList.remove('on'); s.extra.vec.setAttribute('aria-pressed', 'false'); } }
  if (k === 'a') { s.fmode = 'net'; s.syncFBtns(); }               /* 加速度に注目：合力の矢印を表示（ma = F） */
  [['x', 'fx'], ['v', 'fv'], ['a', 'fa']].forEach(function (p) { var b = s.extra[p[1]]; if (!b) return; if (b.innerHTML.indexOf('$') >= 0) b.innerHTML = mathify(b.innerHTML); b.classList.toggle('on', k === p[0]); b.setAttribute('aria-pressed', k === p[0] ? 'true' : 'false'); });
  var fsb = s.extra.fs; if (fsb) { fsb.hidden = !k; var fb = k && s.extra['f' + k]; if (fb) fsb.style.top = fb.offsetTop + 'px'; }   /* 注目ボタンのとなりにコマ送り */
  (s.graphs || []).forEach(function (g) { g.box.hidden = !!k && g.d.key !== k; g.Wc = 0; });
  s.draw(); s.align();
}
function m1s2Geo(W, H) {
  var Rmax = clamp(Math.min(W * 0.17, H * 0.29), 38, 108), S = Rmax / 0.14, cy = H * 0.52, cx = Math.max(Rmax + 40, W * 0.25);
  var xs = Math.max(cx + Rmax + 80, W * 0.62), xa = Math.min(W - 30, xs + Math.max(86, W * 0.2));
  return { S: S, Rmax: Rmax, cy: cy, cx: cx, xs: xs, xa: xa, top: 14 };
}
function m1s2Ball(s, G2) {
  var q = m1s2Q(s), x = s.dragX !== undefined ? s.dragX : SHM.st(q.A, q.w, q.phi, s.t).x;
  var n = Math.round(q.m / M1.s2.mW), hh = (n * 9 + (n - 1) * 1.5) / 2;   /* おもり（1 個 0.25 kg）を n 個つり下げる。y はおもり全体のまん中 */
  return { x: x, y: G2.cy - x * G2.S, rb: 13, hh: hh, n: n };
}
/* グラフ（縦の縮尺をアニメのベクトルとそろえる） */
/* グラフの縦は、前の 60 %（2026-10-16 千葉さん）。縮尺はアニメのベクトルの長さに比例（fr 倍）のまま */
/* グラフの高さ。ふだんは最初の 36 %。「〜に注目する」のときは、そのグラフをアニメと同じ高さにして、
   グラフの 0 の高さをアニメの x 軸の O（つりあいの位置）の高さにそろえる。縮尺もアニメのベクトルと同じ（2026-10-16 千葉さん） */
function m1s2Hdr(s, key) {
  var g = (s.graphs || []).filter(function (q) { return q.d.key === key; })[0];
  if (g && !g.box.hidden && g.box.offsetParent) { var h = g.cv.getBoundingClientRect().top - g.box.getBoundingClientRect().top; if (h > 0) return h; }
  return 26;
}
function m1s2GH(s, key) {
  var G2 = m1s2Geo(s.W || 600, s.H || 400);
  if (key && s.focus === key) return Math.round(2 * (G2.cy + 1 - m1s2Hdr(s, key) - GPAD.t) + GPAD.t + GPAD.b);
  return Math.max(96, Math.round(0.36 * (2 * (G2.Rmax + 10) + 46)));
}
function m1s2GF(s, key) { if (key && s.focus === key) return 1; var G2 = m1s2Geo(s.W || 600, s.H || 400); return ((m1s2GH(s) - GPAD.t - GPAD.b) / 2 - 3) / (G2.Rmax + 10); }
function m1s2Graphs() {
  var D = xvaDefs();
  D[0].scale = function (s) { return m1s2GF(s, 'x') * m1s2Geo(s.W, s.H).S; };
  D[1].scale = function (s) { return m1s2GF(s, 'v') * M1S2V * m1s2Geo(s.W, s.H).S / m1s2Q(s).w; };
  D[2].scale = function (s) { return m1s2GF(s, 'a') * M1S2A * m1s2Geo(s.W, s.H).S / Math.pow(m1s2Q(s).w, 2); };
  D.forEach(function (d) { d.H = function (s) { return m1s2GH(s, d.key); }; d.arrow = true; });
  return D;
}
function drawM1S2(s, ctx, W, H) {
  var G2 = m1s2Geo(W, H), q = m1s2Q(s), st = SHM.st(q.A, q.w, q.phi, s.t), sel = s.sel, R = q.A * G2.S;
  var th = st.th, px = G2.cx + R * Math.cos(th), py = G2.cy - R * Math.sin(th), rP = 6;
  var B = m1s2Ball(s, G2), hi = function (k) { return sel === k ? '#c9670c' : null; };
  var started = s.t > 0 || s.playing;
  /* つりあいの位置（振動の中心）の線と、P と小球を結ぶ高さの線 */
  dotted(ctx, G2.cx - R - 10, G2.cy, G2.xa, G2.cy, 'rgba(20,23,28,.22)', [5, 4]);
  dotted(ctx, px, py, G2.xs, py, 'rgba(20,23,28,.38)', [4, 4]);
  /* 円 */
  ctx.save(); ctx.strokeStyle = '#8d9097'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.arc(G2.cx, G2.cy, R, 0, TAU); ctx.stroke();
  ctx.fillStyle = '#3a414c'; ctx.beginPath(); ctx.arc(G2.cx, G2.cy, 2.6, 0, TAU); ctx.fill(); ctx.restore();
  /* 初期位相 φ（水平から測った出発の角）と、そこから測った角 ωt */
  var th0 = q.phi, dth = th - th0;
  if (Math.abs(th0) > 1e-9) {
    ctx.save(); ctx.strokeStyle = '#7a4fb8'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(G2.cx, G2.cy, 15, 0, -th0, th0 > 0); ctx.stroke(); ctx.restore();
    dotted(ctx, G2.cx, G2.cy, G2.cx + R + 6, G2.cy, 'rgba(20,23,28,.3)', [3, 3]);
    sym(ctx, 'ϕ', G2.cx + 24 * Math.cos(th0 / 2), G2.cy - 24 * Math.sin(th0 / 2), { size: 13, color: '#7a4fb8' });
  }
  var cyc = dth - TAU * Math.floor(dth / TAU + 1e-9);            /* ωt の角は 1 周期ごとに描き直す（前の周期の弧は残さない。2026-10-16 千葉さん） */
  if (started && cyc > 0.05 && !s.focus) {                       /* 注目しているときは、角 ωt(+ϕ) を中心からのおうぎ形で書くので、こちらは出さない */
    dotted(ctx, G2.cx, G2.cy, G2.cx + R * Math.cos(th0), G2.cy - R * Math.sin(th0), 'rgba(20,23,28,.35)', [3, 3]);
    var ra = Math.min(30, R * 0.62), ddd = cyc;
    ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.3; ctx.beginPath(); ctx.arc(G2.cx, G2.cy, ra, -th0, -th0 - ddd, true); ctx.stroke(); ctx.restore();
    var am = th0 + ddd / 2, bw = sym(ctx, 'ωt', G2.cx + (ra + 12) * Math.cos(am), G2.cy - (ra + 12) * Math.sin(am), { size: 13, color: hi('w') || '#3a414c' }); s.addHit('w', bw);
  }
  spinArrow(ctx, G2.cx, G2.cy, R + 14, R + 14, -0.2, -1.0, hi('w') || '#3a414c', 1.8);
  var bo = sym(ctx, 'ω', G2.cx + (R + 27) * Math.cos(0.6), G2.cy - (R + 27) * Math.sin(0.6), { size: 15, color: hi('w') || COL.ink }); s.addHit('w', bo);
  label(ctx, '等速円運動（半径 A）', G2.cx, Math.min(H - 10, G2.cy + G2.Rmax + 36), { size: 11.5, color: COL.ink2 });
  /* 円の上の点 P：変位（中心 → P、緑）・速度（接線、青）・加速度（中心向き、オレンジ）と、その x 成分（破線） */
  var tx = -Math.sin(th), ty = -Math.cos(th), nx = Math.cos(th), ny = -Math.sin(th);
  var Lv = M1S2V * R, La = M1S2A * R, sh = 5;
  var fk = s.focus, showX = !s.hideVec && (!fk || fk === 'x'), showV = !s.hideVec && (!fk || fk === 'v'), showA = !s.hideVec && (!fk || fk === 'a'), showFo = fk !== 'x' && fk !== 'v';
  if (showX) { var dx = arrow(ctx, G2.cx, G2.cy, px, py, 'vel', XCOL); xArrowRestyle(ctx, G2.cx, G2.cy, px, py); s.addHitSeg('x', dx); }
  else { ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.3; ctx.beginPath(); ctx.moveTo(G2.cx, G2.cy); ctx.lineTo(px, py); ctx.stroke(); ctx.restore(); }
  ballShape(ctx, px, py, rP, '#d9b77a');
  if (showV && (started || Math.abs(Math.cos(th0)) > 1e-6)) {
    var av = arrow(ctx, px, py, px + tx * Lv, py + ty * Lv, 'vel'); s.addHitSeg('v', av);
    compArrow(ctx, px, py, px, py + ty * Lv, COL.vel);
    sym(ctx, 'v', px + tx * Lv + nx * 12, py + ty * Lv + ny * 12, { size: 14, color: hi('v') || COL.vel, vec: true });   /* ベクトルの記号（2026-10-18） */
    dotted(ctx, px, py + ty * Lv, G2.xs + B.rb + 14, py + ty * Lv, 'rgba(22,99,181,.45)', [2, 3]);
  }
  var ox = -ny * sh, oy = nx * sh;                          /* 加速度は半径の線と重ならないよう、少し横にずらす */
  if (showA) {
    var aa = arrow(ctx, px + ox, py + oy, px + ox - nx * La, py + oy - ny * La, 'acc'); s.addHitSeg('a', aa);
    sym(ctx, 'a', px + ox - nx * (La + 12) - tx * 8, py + oy - ny * (La + 12) - ty * 8, { size: 14, color: hi('a') || COL.acc, vec: true });   /* v と同じく、矢印の先の近くに a（2026-10-18 千葉さん） */
    compArrow(ctx, px + ox, py + oy, px + ox, py + oy - ny * La, COL.acc);
    dotted(ctx, px + ox, py + oy - ny * La, G2.xs + B.rb + 30, py - ny * La, 'rgba(224,123,24,.45)', [2, 3]);
  }
  if (!s.playing) radiusA(ctx, G2.cx, G2.cy, px, py, 1, hi('x') || '#14171c');   /* 止まっているときだけ、半径に両矢印と A（動いている間は消す） */
  label(ctx, 'P', px + nx * 16 - tx * 10, py + ny * 16 - ty * 10, { size: 12, bold: true });
  /* 右：鉛直ばね振り子 */
  ceilingAt(ctx, G2.xs - 34, G2.xs + 34, G2.top);
  springDense(ctx, G2.xs, G2.top, G2.xs, B.y - B.hh, G2.cy - G2.top - 12, { r: 8, k: q.k, Lmin: G2.cy - G2.top - 0.14 * G2.S - 30 });
  if (s.t < 0.5 && s.dragX === undefined && !fk) startHand(s, ctx, G2.xs, B.y, B.rb, 'up', Math.cos(q.phi), { hh: B.hh, flip: true, bubGap: 34, bubPos: B.y > G2.cy && W >= 480 ? 'l' : 'd' });   /* 吹き出し：おもりが上なら手の下、下なら手の左（ほかの矢印・文字と重ねない） */
  weightStack(ctx, G2.xs, B.y, B.n, B.rb);
  if (!(W < 480 && s.t === 0 && !s.playing)) label(ctx, '単振動', G2.xs,   /* せまい画面のスタート前は、吹き出しの場所なので出さない */ Math.min(H - 10, G2.cy + G2.Rmax + 36), { size: 11.5, color: COL.ink2 });
  /* 小球の変位（左、O から）・速度（右）・加速度（さらに右）。長さは円の上の点の x 成分と同じ */
  var xL = G2.xs - B.rb - 14;
  if (showX && Math.abs(B.y - G2.cy) > 3) { var bxv = arrow(ctx, xL, G2.cy, xL, B.y, 'vel', XCOL); xArrowRestyle(ctx, xL, G2.cy, xL, B.y); s.addHitSeg('x', bxv); sym(ctx, 'x', xL - 12, (G2.cy + B.y) / 2, { size: 14, color: hi('x') || XCOL }); }
  if (showV && s.dragX === undefined && (started || Math.abs(Math.cos(th0)) > 1e-6)) {
    var vy = ty * Lv, x1 = G2.xs + B.rb + 14;
    if (Math.abs(vy) > 2) { var bv = arrow(ctx, x1, B.y, x1, B.y + vy, 'vel'); s.addHitSeg('v', bv); sym(ctx, 'v', x1 + 10, B.y + vy, { size: 14, color: hi('v') || COL.vel, align: 'left' }); }
  }
  var ay = -ny * La, x2 = G2.xs + B.rb + 30;
  if (showA && s.dragX === undefined && Math.abs(ay) > 2) { var ba = arrow(ctx, x2, B.y, x2, B.y + ay, 'acc'); s.addHitSeg('a', ba); sym(ctx, 'a', x2 + 10, B.y + ay, { size: 14, color: hi('a') || COL.acc, align: 'left' }); }
  /* 力：合力（−kx）はばねとおもりの接点から。個別ならばねの弾性力（接点から）と重力（中心から）を左右にずらして */
  var yC = B.y - B.hh;
  if (showFo && fNet(s)) {
    var Fx = -q.k * B.x, Fm = q.k * 0.14;
    if (Math.abs(Fx) > Fm * 0.02) { var LF = 46 * Fx / Fm, bf = arrow(ctx, G2.xs, yC, G2.xs, yC - LF, 'force', COL.force, { noShift: true }); s.addHitSeg('F', bf); var bF = sym(ctx, '−kx', G2.xs - 10, yC - LF + (LF > 0 ? -8 : 8), { size: 14, color: hi('F') || COL.force, align: 'right', tail: '（合力）' }); s.addHit('F', bF); }
  } else if (showFo && fAll(s)) {
    var d0 = q.m * G / q.k, Fs = q.k * (d0 - B.x), fs2 = 58 / (q.m * G + q.k * 0.14);
    var b1 = arrow(ctx, G2.xs - 5, yC, G2.xs - 5, yC - Fs * fs2, 'force', COL.hand, { noShift: true }); if (b1) sym(ctx, 'k(d − x)', G2.xs - 14, yC - Fs * fs2 - 2, { size: 13, color: COL.hand, align: 'right' });
    var b2 = arrow(ctx, G2.xs + 5, B.y, G2.xs + 5, B.y + q.m * G * fs2, 'force', COL.force, { noShift: true }); if (b2) sym(ctx, 'mg', G2.xs - 8, B.y + q.m * G * fs2 + 2, { size: 13, color: COL.force, align: 'right' });
  }
  /* 右はしの x 軸（上向きが正） */
  var xTop = G2.cy - G2.Rmax - 20, xBot = G2.cy + G2.Rmax + 16;
  axisArrow(ctx, G2.xa, xBot, G2.xa, Math.max(8, xTop));
  var bxl = sym(ctx, 'x', G2.xa + 8, Math.max(14, xTop + 6), { size: 15, align: 'left', color: hi('x') || COL.ink }); s.addHit('x', bxl);
  label(ctx, 'O', G2.xa + 10, G2.cy, { size: 11.5, align: 'left' });
  [[q.A, 'A'], [-q.A, '−A']].forEach(function (p) { var y = G2.cy - p[0] * G2.S; ctx.save(); ctx.strokeStyle = '#2b323c'; ctx.beginPath(); ctx.moveTo(G2.xa - 4, y); ctx.lineTo(G2.xa + 4, y); ctx.stroke(); ctx.restore(); label(ctx, p[1], G2.xa + 9, y, { size: 11, align: 'left', color: '#5d6875' }); });
  if (fk && s.dragX === undefined) m1s2DetailDraw(ctx, G2, q, th, px, py, R, fk, Lv, La);   /* 注目したら、成分の分解・x 軸への映し・色ぬりを（動いている間も）出す（2026-10-18 千葉さん） */
  if (fk && s.dragX === undefined) {                               /* 注目したときの同じ大きさの印は 3 つの注目でそろえる（2026-10-25 千葉さん）：
       円の上のベクトルの x 成分（縦）・小球のベクトル・x 軸に映したもの の 3 本に、同じ印（1 本線）をつける */
    _fArrows.forEach(function (a) { a.noTick = true; });
    var segs = fk === 'x' ? [[px, G2.cy, py], [xL, G2.cy, B.y], [G2.xa - 16, G2.cy, py]]
      : fk === 'v' ? [[px, py, py + ty * Lv], [G2.xs + B.rb + 14, B.y, B.y + ty * Lv], [G2.xa, py, py + ty * Lv]]
      : [[px + ox, py + oy, py + oy - ny * La], [x2, B.y, B.y + ay], [G2.xa, py, py - ny * La]];
    var mcol = fk === 'x' ? XCOL : fk === 'v' ? COL.vel : COL.acc;
    segs.forEach(function (g) { var L = g[2] - g[1]; if (Math.abs(L) > 14) equalTick(ctx, { x: g[0], y: g[1], ux: 0, uy: L > 0 ? 1 : -1, len: Math.abs(L), color: mcol }, 1); });
  }
  if (!fk && showA && s.dragX === undefined && Math.abs(Math.cos(th)) < 0.02) {   /* ωt + ϕ = ±π/2（端）：円の加速度ベクトルと、x 軸の上の映し（注目しないときは小球の a）が同じ長さ ⇒「＝」の印 */
    eqSign(ctx, px + ox, py + oy, -nx, -ny, La, COL.acc);
    if (fk === 'a') eqSign(ctx, G2.xa, py, 0, -ny, La, COL.acc, -1); else eqSign(ctx, x2, B.y, 0, -ny, La, COL.acc);
  }
  if (s.dragging) label(ctx, '離すと、この位置から静かに放す', G2.xs, Math.max(14, B.y - B.rb - 18), { size: 11.5, bold: true, color: '#9c4e06' });
  drawEqualTicks(ctx);
}
/* 「さらに詳しく」：教科書の図のように、角 ωt（ϕ があれば ωt + ϕ）と、x 軸への成分を書きこむ */
function m1s2DetailDraw(ctx, G2, q, th, px, py, R, fk, Lv, La) {
  var thn = th - TAU * Math.floor(th / TAU);                      /* 角は 0〜2π に戻す（1 周したあとに円が重なって描かれないように。2026-10-18 千葉さん） */
  var tl = Math.abs(q.phi) < 1e-9 ? 'ωt' : 'ωt+ϕ', xa = G2.xa, GR = 'rgba(46,160,90,.22)', GL = '#1c8f4a';
  /* 中心の角（薄い緑のおうぎ形） */
  ctx.save(); ctx.fillStyle = GR; ctx.beginPath(); ctx.moveTo(G2.cx, G2.cy); ctx.arc(G2.cx, G2.cy, 28, 0, -thn, true); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = GL; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.arc(G2.cx, G2.cy, 28, 0, -thn, true); ctx.stroke(); ctx.restore();
  dotted(ctx, G2.cx, G2.cy, G2.cx + R + 8, G2.cy, 'rgba(20,23,28,.45)', [4, 3]);
  sym(ctx, tl, G2.cx + 44 * Math.cos(thn / 2), G2.cy - 44 * Math.sin(thn / 2), { size: 14, color: GL });
  var Q = { x: xa, y: py };
  ctx.save(); ctx.fillStyle = '#14171c'; ctx.beginPath(); ctx.arc(Q.x, Q.y, 3.4, 0, TAU); ctx.fill(); ctx.restore();
  label(ctx, 'Q', Q.x + 12, Q.y + 12, { size: 12, bold: true });
  if (fk === 'x') {                                               /* 変位：P の高さ ＝ A sin ωt */
    dotted(ctx, px, py, px, G2.cy, 'rgba(28,143,74,.7)', [3, 3]);
    dimLine(ctx, xa - 16, G2.cy, xa - 16, py, XCOL);
    label(ctx, 'x = A sin ' + (tl === 'ωt' ? 'ωt' : '(ωt+ϕ)'), xa - 22, (G2.cy + py) / 2, { size: 12.5, bold: true, color: XCOL, align: 'right' });
  } else if (fk === 'v') {                                        /* 速度：円の上は Aω（接線方向）。x 軸に映すと Aω cos ωt */
    var tx = -Math.sin(th), ty = -Math.cos(th), vx = px + tx * Lv, vy = py + ty * Lv;
    ctx.save(); ctx.fillStyle = 'rgba(22,99,181,.12)'; ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(xa, py); ctx.lineTo(xa, vy); ctx.lineTo(vx, vy); ctx.closePath(); ctx.fill(); ctx.restore();
    dotted(ctx, vx, vy, xa, vy, 'rgba(22,99,181,.6)', [4, 3]); dotted(ctx, px, vy, px, py, 'rgba(20,23,28,.45)', [3, 3]);
    var nx = Math.cos(th), ny = -Math.sin(th), m = 8;                 /* P の直角の印（半径と速度） */
    ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.1; ctx.beginPath(); ctx.moveTo(px - nx * m, py - ny * m); ctx.lineTo(px - nx * m + tx * m, py - ny * m + ty * m); ctx.lineTo(px + tx * m, py + ty * m); ctx.stroke(); ctx.restore();
    ctx.save(); ctx.fillStyle = GR; ctx.beginPath(); ctx.moveTo(px, py); ctx.arc(px, py, 18, -Math.PI / 2, Math.atan2(ty, tx), true); ctx.closePath(); ctx.fill(); ctx.restore();
    sym(ctx, tl, px - 10, py - 30, { size: 13, color: GL, align: 'right' });
    label(ctx, 'Aω', vx - 8, vy - 8, { size: 13, bold: true, color: COL.vel, align: 'right' });
    arrow(ctx, xa, py, xa, vy, 'vel');
    label(ctx, 'Aω cos ' + (tl === 'ωt' ? 'ωt' : '(ωt+ϕ)'), xa + 10, (py + vy) / 2, { size: 12.5, bold: true, color: COL.vel, align: 'left' });
  } else {                                                        /* 加速度：円の上は Aω²（中心向き）。x 軸に映すと −Aω² sin ωt */
    var ax = px - Math.cos(th) * La, ay = py + Math.sin(th) * La;
    ctx.save(); ctx.fillStyle = 'rgba(224,123,24,.12)'; ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(xa, py); ctx.lineTo(xa, ay); ctx.lineTo(ax, ay); ctx.closePath(); ctx.fill(); ctx.restore();
    dotted(ctx, ax, ay, xa, ay, 'rgba(224,123,24,.6)', [4, 3]); dotted(ctx, px, py, px - La * 1.1, py, 'rgba(20,23,28,.45)', [3, 3]);
    ctx.save(); ctx.fillStyle = GR; ctx.beginPath(); ctx.moveTo(px, py); ctx.arc(px, py, 18, Math.PI, Math.atan2(Math.sin(th), -Math.cos(th)), true); ctx.closePath(); ctx.fill(); ctx.restore();
    sym(ctx, tl, px - 34, py + 12, { size: 13, color: GL, align: 'right' });
    label(ctx, 'Aω²', ax - 6, ay + 12, { size: 13, bold: true, color: COL.acc, align: 'right' });
    arrow(ctx, xa, py, xa, ay, 'acc');
    label(ctx, '−Aω² sin ' + (tl === 'ωt' ? 'ωt' : '(ωt+ϕ)'), xa + 10, (py + ay) / 2, { size: 12.5, bold: true, color: COL.acc, align: 'left' });
  }
}
/* おもり（1 個 0.25 kg）を n 個つり下げた形。(x, y)＝全体のまん中、w2＝横幅の半分 */
function weightStack(ctx, x, y, n, w2) {
  var h = 9, gap = 1.5, top = y - (n * h + (n - 1) * gap) / 2;
  ctx.save(); ctx.lineWidth = 1.2; ctx.strokeStyle = '#5b4a2e';
  for (var i = 0; i < n; i++) {
    var yy = top + i * (h + gap), gr = ctx.createLinearGradient(x - w2, 0, x + w2, 0);
    gr.addColorStop(0, '#b08c4c'); gr.addColorStop(0.45, '#ecd5a0'); gr.addColorStop(1, '#a07c3e');
    ctx.fillStyle = gr; rrect(ctx, x - w2, yy, 2 * w2, h, 2.5); ctx.fill(); ctx.stroke();
  }
  ctx.restore();
}
/* 変位ベクトル：緑の実線（中は塗りつぶし）に描き直す（速度の白抜きと区別する） */
function xArrowRestyle(ctx, x1, y1, x2, y2) {
  var L = Math.hypot(x2 - x1, y2 - y1); if (L < 2) return;
  var ux = (x2 - x1) / L, uy = (y2 - y1) / L, h = Math.min(11, L * 0.8), bx = x2 - ux * h, by = y2 - uy * h;
  ctx.save(); ctx.fillStyle = XCOL; ctx.beginPath(); ctx.moveTo(x2, y2); ctx.lineTo(bx - uy * h * .5, by + ux * h * .5); ctx.lineTo(bx + uy * h * .5, by - ux * h * .5); ctx.closePath(); ctx.fill(); ctx.restore();
}
var M1S2ROWS = [
  { k: 'x', h: '位置', c: '中心からの距離 $r$（一定）', o: '変位 $x = A\\sin(\\omega t + \\phi)$' },
  { k: 'v', h: '速さ・速度', c: '$v = r\\omega$　円周方向', o: '$v = A\\omega\\cos(\\omega t + \\phi)$' },
  { k: 'a', h: '加速度', c: '$a = \\dfrac{v^2}{r} = r\\omega^2$　中心向き', o: '$a = -A\\omega^2\\sin(\\omega t + \\phi) = -\\omega^2 x$' },
  { k: 'F', h: '運動方程式', c: '$m\\dfrac{v^2}{r} = F$　$(mr\\omega^2 = F)$<br><small>↑向心力</small>', o: '$ma = -Kx$<br><small>↑復元力</small>' },
  { k: 'w', h: '角速度', c: '$\\omega = \\dfrac{2\\pi}{T}$', o: '角振動数 $\\omega = \\sqrt{\\dfrac{K}{m}}$' },
  { k: 'T', h: '周期', c: '$T = \\dfrac{2\\pi}{\\omega} = \\dfrac{2\\pi r}{v}$', o: '$T = 2\\pi\\sqrt{\\dfrac{m}{K}}$　$f = \\dfrac{1}{T}$' }
];
var M1S2NAME = { x: '変位 $x$', v: '速度 $v$', a: '加速度 $a$', F: '復元力 $F$', w: '角振動数 $\\omega$', T: '周期 $T$' };
function rightM1S2(s) {
  var q = m1s2Q(s), k = s.sel;
  /* 左下：等速円運動と単振動の対応 */
  var h = '<div class="cmpbox"><p class="cmpttl">等速円運動と単振動の対応</p>' +
    '<div class="qpick"><span class="ql">選択：</span>' + Object.keys(M1S2NAME).map(function (key) {
      return '<button type="button" class="tiny qbtn' + (key === k ? ' on' : '') + '" data-q="' + key + '">' + M1S2NAME[key] + '</button>'; }).join('') + '</div>' +
    '<div class="cmpfig"><canvas class="cmpcv" data-f="c" aria-label="等速円運動の図"></canvas><canvas class="cmpcv" data-f="o" aria-label="単振動の図（縦向き）"></canvas></div>' +
    '<table class="reltab cmptab"><thead><tr><th></th><th>等速円運動</th><th>単振動</th></tr></thead><tbody>' +
    M1S2ROWS.map(function (r) { return '<tr' + (r.k === k ? ' class="on"' : '') + '><th>' + r.h + '</th><td>' + r.c + '</td><td>' + r.o + '</td></tr>'; }).join('') +
    '</tbody></table></div>';
  s.below.innerHTML = mathify(h);
  /* 右：解説カード */
  var i = phiIdx(q.phi);
  /* ω と T：公式といまの値だけ（くわしい導き方はモード②へ。2026-10-16 千葉さん） */
  var r = '<div class="qcard keybox' + (k === 'w' || k === 'T' || k === 'F' ? ' hl' : '') + '"><p class="qt">$\\omega$ と $T$ の公式</p>' +
    '<div class="qeq">$$\\omega = \\sqrt{\\dfrac{K}{m}},\\qquad T = \\dfrac{2\\pi}{\\omega} = 2\\pi\\sqrt{\\dfrac{m}{K}},\\qquad f = \\dfrac{1}{T}$$</div>' +
    '<p class="qnow"><span class="qtag now">いま</span>$K = k = ' + vtex(q.k) + '$ N/m、$m = ' + vtex(q.m) + '$ kg だから　$\\omega = \\sqrt{\\dfrac{' + vtex(q.k) + '}{' + vtex(q.m) + '}} = ' + fmt(q.w, 2) + '$ rad/s、$T = 2\\pi\\sqrt{\\dfrac{' + vtex(q.m) + '}{' + vtex(q.k) + '}} = ' + sig2(q.T) + '$ s</p>' +
    '<p class="qnote">この式がどうして出てくるかは、<a class="xlink" href="#2-2">こちらへ</a>。</p></div>' +
    '<div class="qcard"><p class="qt">初期位相 $\\phi$</p>' +
    '<p>時刻 $0$ に、円の上の点 P が水平（右）から角 $\\phi$ だけ回った位置にあるとき、時刻 $t$ の位相（回転角）は $\\omega t + \\phi$ になる。この $\\phi$ を<b>初期位相</b>という。単振動の変位の式は</p>' +
    '<div class="qeq">$$x = A\\sin(\\omega t + \\phi)$$</div>' +
    '<table class="reltab grid1 phitab"><tbody>' +
    '<tr' + (i === 4 ? ' class="on"' : '') + '><th>$\\phi = 0$</th><td class="l">中心（$x = 0$）から正の向きに初速を与える。$x = A\\sin\\omega t$</td></tr>' +
    '<tr' + (i === 6 ? ' class="on"' : '') + '><th>$\\phi = \\dfrac{\\pi}{2}$</th><td class="l">端（$x = A$）で静かに放す。$x = A\\cos\\omega t$</td></tr>' +
    '<tr' + (i === 8 || i === 0 ? ' class="on"' : '') + '><th>$\\phi = \\pm\\pi$</th><td class="l">中心から負の向きに初速を与える。$x = -A\\sin\\omega t$</td></tr>' +
    '<tr' + (i === 2 ? ' class="on"' : '') + '><th>$\\phi = -\\dfrac{\\pi}{2}$</th><td class="l">端（$x = -A$）で静かに放す。$x = -A\\cos\\omega t$</td></tr>' +
    '</tbody></table>' +
    '<p class="qnote">左の図の紫の角が $\\phi$。$\\phi$ を変えると、グラフが横（時間の向き）にずれるだけで、形（振幅・周期）は変わらない。</p>' +
    '<p class="qnow"><span class="qtag now">いま</span>$\\phi = ' + PHITEX[i] + '$ なので　$x = ' + PHISUB[i] + '$</p></div>';
  if (s.Rdyn) s.Rdyn.innerHTML = mathify(r);
  Object.keys(s.sl || {}).forEach(function (key) {
    var on = key === k || (k === 'x' && key === 'A') || (k === 'v' && key === 'vm') || (k === 'a' && key === 'am') || (k === 'T' && (key === 'f'));
    s.sl[key].row.classList.toggle('sel', on); });
  s.below.querySelectorAll('[data-q]').forEach(function (b) { b.addEventListener('click', function () { s.sel = (s.sel === b.dataset.q ? null : b.dataset.q); s.renderRight(); s.draw(); }); });
  s.below.querySelectorAll('canvas.cmpcv').forEach(function (cv) { drawCmpFig(cv, cv.dataset.f); });
}
function vtex(x) { return (x % 1 === 0) ? String(x) : String(+x.toPrecision(3)); }
/* 表の上の 2 つの図（添付図 1。右の単振動は縦向きに作り直した） */
function drawCmpFig(cv, f) {
  var W = Math.max(120, Math.floor(cv.clientWidth || 160)), H = 132, ctx = prep(cv, W, H);
  if (f === 'c') {
    var cx = W * 0.45, cy = H * 0.56, r = Math.min(46, W * 0.28), th = 0.95, px = cx + r * Math.cos(th), py = cy - r * Math.sin(th);
    ctx.save(); ctx.strokeStyle = '#8d9097'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.stroke();
    ctx.strokeStyle = '#3a414c'; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(px, py); ctx.stroke(); ctx.restore();
    arrow(ctx, px - Math.sin(th) * 3, py - Math.cos(th) * 3, px - Math.sin(th) * 34 - Math.cos(th) * 3, py - Math.cos(th) * 34 + Math.sin(th) * 3, 'vel');
    arrow(ctx, px, py, px - Math.cos(th) * 28, py + Math.sin(th) * 28, 'force', COL.hand, { noShift: true });
    ballShape(ctx, px, py, 6, '#d9b77a');
    sym(ctx, 'v', px - Math.sin(th) * 34 - 10, py - Math.cos(th) * 34 - 4, { size: 13, color: COL.vel });
    sym(ctx, 'F', px - Math.cos(th) * 18 + 10, py + Math.sin(th) * 18 + 8, { size: 13, color: COL.hand });
    sym(ctx, 'r', (cx + px) / 2 - 8, (cy + py) / 2 + 2, { size: 12 });
  } else {
    var xs = W * 0.40, top = 10, cy2 = H * 0.56, xb = 22, yb = cy2 - xb;
    ceilingAt(ctx, xs - 22, xs + 22, top);
    springDense(ctx, xs, top, xs, yb - 8, cy2 - top - 8, { r: 6, lead: 5 });
    dotted(ctx, xs - 30, cy2, xs + 44, cy2, 'rgba(20,23,28,.3)', [4, 3]);
    arrow(ctx, xs, yb, xs, yb + 26, 'force', COL.force, { noShift: true });
    ballShape(ctx, xs, yb, 8, '#d9b77a');
    arrow(ctx, xs + 18, yb + 14, xs + 18, yb - 14, 'vel');
    sym(ctx, '−Kx', xs + 6, yb + 34, { size: 12, color: COL.force, align: 'left' });
    axisArrow(ctx, W - 16, H - 10, W - 16, 12); sym(ctx, 'x', W - 8, 16, { size: 12 });
    label(ctx, 'O', W - 26, cy2, { size: 10 });
    sym(ctx, 'v', xs + 30, yb - 12, { size: 12, color: COL.vel });
  }
}

/* =====================================================================
   ①-3 単振動のエネルギー（基本）：エネルギー − t グラフだけ
   ===================================================================== */
function m1s3Q(s) {
  var m = M1.s3.m, k = M1.s3.k, w = SHM.omega(k, m);
  return { A: s.v.A, m: m, k: k, w: w, T: TAU / w, phi: s.v.phi };
}
function m1s3State(s, t) {
  var q = m1s3Q(s), st = SHM.st(q.A, q.w, q.phi, t), e = SHM.energy(q.m, q.k, st.x, st.v);
  return { x: st.x, v: st.v, a: st.a, K: e.K, U: e.U, E: e.E };
}
DEFS.m1s3 = {
  id: 'm1s3', mode: 'mode1', num: 3,
  title: '単振動のエネルギー（基本）',
  desc: 'なめらかな水平面の上の水平ばね振り子（$m = ' + M1.s3.m.toFixed(1) + '$ kg、$k = ' + M1.s3.k + '$ N/m）。下のグラフは、横軸に変位 $x$ をとったエネルギーのグラフ。<span class="todo">スタートを押して、運動エネルギー $K$ と位置エネルギー $U$ の和がいつも同じ高さになることを確かめよう。</span>',
  strobe: false, showFBtn: true, fDefault: 'net', vecBtn: 'v を消す', graphs: true,
  varCols: [['A'], ['phi']],
  vars: [{ k: 'A', label: '振幅 $A$', min: 0.04, max: M1.s3.Amax, step: 0.01, def: M1.s3.A, aria: '振幅', fmt: function (x) { return fmt(x, 2) + ' m'; } }, phiVar(Math.PI / 2, true)],
  init: function (s) { },
  onDefaults: function (s) { shmGraphReset(s); },
  onChanged: function (s) { if (s.graphs) shmGraphReset(s); },
  afterBuild: function (s) {
    shmGraphs(s, [energyDef()]);
    /* 右の列の上に、振幅 A と初期位相 ϕ（ボタン）。その下に説明（2026-10-16 千葉さん） */
    s.R.innerHTML = ''; var sw = el('div', 'row2 sliders inR'); sw.appendChild(s.varbox); s.R.appendChild(sw); s.varbox.classList.add('inR');
    s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);
  },
  tEnd: function (s) { return tBarOf(m1s3Q(s).T); },
  tInfo: function (s) { return periodInfo(m1s3Q(s).T); },
  gq: function (s, t) { return m1s3State(s, t); },
  gWin: function (s) { return 2 * m1s3Q(s).T; },
  gT: function (s) { return m1s3Q(s).T; },
  gH: function () { return 150; },
  gAmp: function (s) { var q = m1s3Q(s); return { E: 0.5 * q.k * M1.s3.Amax * M1.s3.Amax }; },   /* 縦軸は最大の振幅で固定（振幅を大きくすると、エネルギーが大きくなるのが見える。2026-10-16 千葉さん） */
  height: function (s, w) { return Math.round(clamp(w * 0.74, w < 480 ? 370 : 330, 470)); },   /* せまい画面では、上に吹き出しの場所をとる */
  dragHit: function (s, x, y) { var g = m1s3Geo(s.W, s.H), b = m1s3Ball(s, g); return Math.hypot(x - b.x, y - b.y) < b.rb + 10; },
  dragMove: function (s, x) { var g = m1s3Geo(s.W, s.H), xv = clamp((x - g.xO) / g.S, -M1.s3.Amax, M1.s3.Amax); if (Math.abs(xv) < 0.04) xv = xv < 0 ? -0.04 : 0.04; s.dragX = xv; },
  dragEnd: function (s) { if (s.dragX === undefined) return; s.v.A = Math.round(Math.abs(s.dragX) * 100) / 100; s.v.phi = s.dragX < 0 ? -Math.PI / 2 : Math.PI / 2; s.dragX = undefined; },
  live: function (s) { m1s3Live(s); },
  msg: function (s) {
    var q = m1s3Q(s);
    if (s.t < q.T) return '小球は、つりあいの位置（自然の長さの位置 $x = 0$）を中心に振動する。1 往復すると、グラフがぬり分けられる。';
    return '<b>つりあいの位置（$x = 0$）で運動エネルギーが最大</b>、<b>振動の端（$x = \\pm A$）で位置エネルギーが最大</b>。2 つの和（力学的エネルギー $E$）はいつも同じ高さ。';
  },
  draw: function (s, ctx, W, H) { drawM1S3(s, ctx, W, H); },
  right: function (s, R) { rightM1S3(s, R); }
};

function m1s3Geo(W, H) {
  var S = Math.min(W * 0.36, 300) / M1.s3.Amax, xO = W * 0.52, yF = Math.round(H * 0.25 + (W < 480 ? 40 : 0));
  return { S: S, xO: xO, yF: yF, xW: Math.max(14, xO - 0.30 * S - 30), e0: H - 34, eTop: yF + 64 };
}
function m1s3Ball(s, g) {
  var x = s.dragX !== undefined ? s.dragX : m1s3State(s, s.t).x, rb = 14;
  return { xv: x, x: g.xO + x * g.S, y: g.yF - rb, rb: rb };
}
function drawM1S3(s, ctx, W, H) {
  var g = m1s3Geo(W, H), q = m1s3Q(s), b = m1s3Ball(s, g), st = m1s3State(s, s.t);
  var A = s.dragX !== undefined ? Math.abs(s.dragX) : q.A, E = 0.5 * q.k * A * A;
  var X = function (x) { return g.xO + x * g.S; };
  /* 上：水平ばね振り子 */
  wallLeftAt(ctx, g.xW, g.yF - 52, g.yF);
  floorAt(ctx, g.xW, W - 12, g.yF);
  springDense(ctx, g.xW, b.y, b.x - b.rb, b.y, g.xO - 14 - g.xW, { r: 8, k: q.k });
  dotted(ctx, g.xO, g.yF - 54, g.xO, g.yF, 'rgba(20,23,28,.35)', [4, 3]);
  label(ctx, '自然の長さの位置', g.xO + 5, g.yF + 18, { size: 10.5, color: '#5d6875', align: 'left' });   /* 床の下へ（速度の矢印と重ねない。2026-10-18） */
  if (s.t < 0.5 && s.dragX === undefined) startHand(s, ctx, b.x, b.y, b.rb, 'right', Math.cos(q.phi), Math.sin(q.phi) < 0 ? { bubPos: 'l', bubDy: W < 480 ? -34 : -14 } : { bubDy: W < 480 ? -34 : 0 });   /* 左の端では、合力の名前と重ならないよう手の左に */
  ballShape(ctx, b.x, b.y, b.rb, '#d9b77a');
  label(ctx, 'なめらかな水平面', W - 70, g.yF + 16, { size: 10.5, color: '#8d9097' });
  /* 速度（小球の上に離して）・弾性力（ばねとの接点から） */
  if (s.dragX === undefined && !s.hideVec && Math.abs(st.v) > 0.03 * q.A * q.w) {
    var L = 14 + 34 * Math.abs(st.v) / (q.A * q.w), sg = st.v > 0 ? 1 : -1, yv = b.y - b.rb - (fAll(s) ? 36 : 14);   /* 垂直抗力の矢印の先より上 */
    arrow(ctx, b.x - sg * L / 2, yv, b.x + sg * L / 2, yv, 'vel'); sym(ctx, 'v', b.x + sg * (L / 2 + 10), yv - 2, { size: 14, color: COL.vel });
  }
  /* 力：合力（＝弾性力 −kx。ばねとの接点から）／個別なら弾性力・重力・垂直抗力（重力と垂直抗力は左右にずらす）。縮尺は共通 */
  if (fNet(s) || fAll(s)) {
    var xv = b.xv, fs3 = 48 / (q.k * M1.s3.Amax), LF = -q.k * xv * fs3;   /* 弾性力はいつも「最大で 48 px」の縮尺。重力 mg と垂直抗力 N は弾性力よりずっと大きいので、縮めて描く（2026-10-18：個別表示で弾性力が短すぎて消えていた） */
    if (Math.abs(LF) > 2) { arrow(ctx, b.x - b.rb, b.y, b.x - b.rb + LF, b.y, 'force', COL.hand, { noShift: true }); sym(ctx, '−kx', b.x - b.rb + LF, b.y - 14, { size: 14, color: COL.hand, align: LF > 0 ? 'left' : 'right', tail: fNet(s) ? '（合力）' : '' }); }
    if (fAll(s)) {
      var Lg = 34;
      arrow(ctx, b.x - 5, b.y, b.x - 5, b.y + Lg, 'force', COL.force, { noShift: true }); sym(ctx, 'mg', b.x - 12, b.y + Lg, { size: 13, color: COL.force, align: 'right' });
      arrow(ctx, b.x + 5, g.yF, b.x + 5, g.yF - Lg, 'force', COL.norm, { noShift: true }); sym(ctx, 'N', b.x + 14, g.yF - Lg, { size: 13, color: COL.norm, align: 'left' });
      label(ctx, '※ mg と N は縮めて描いている', W - 12, g.yF + 32, { size: 10, color: '#8d9097', align: 'right' });
    }
  }
  /* 下：エネルギー − 変位 x のグラフ（横軸は上の図と同じ位置・同じ縮尺） */
  var Hp = g.e0 - g.eTop, ek = Hp * 0.92 / (0.5 * q.k * M1.s3.Amax * M1.s3.Amax), YE = function (e) { return g.e0 - e * ek; };   /* 縦の縮尺は最大の振幅で固定 */
  [-A, A].forEach(function (x) { dotted(ctx, X(x), g.yF + 2, X(x), g.e0, 'rgba(20,23,28,.25)', [4, 3]); });
  /* 1 往復したら、放物線の上（運動エネルギー）と下（位置エネルギー）をぬる */
  var full = s.t >= q.T && s.dragX === undefined;
  if (full) {
    ctx.save();
    ctx.fillStyle = 'rgba(34,164,101,.16)'; ctx.beginPath(); ctx.moveTo(X(-A), YE(E));
    for (var i = 0; i <= 80; i++) { var x1 = -A + 2 * A * i / 80; ctx.lineTo(X(x1), YE(0.5 * q.k * x1 * x1)); }
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = 'rgba(99,57,12,.13)'; ctx.beginPath(); ctx.moveTo(X(-A), g.e0);
    for (var j = 0; j <= 80; j++) { var x2 = -A + 2 * A * j / 80; ctx.lineTo(X(x2), YE(0.5 * q.k * x2 * x2)); }
    ctx.lineTo(X(A), g.e0); ctx.closePath(); ctx.fill(); ctx.restore();
  }
  /* 軸 */
  axisArrow(ctx, X(-M1.s3.Amax) - 16, g.e0, W - 14, g.e0);
  axisArrow(ctx, g.xO, g.e0 + 4, g.xO, g.eTop - 22);
  label(ctx, 'エネルギー', g.xO - 8, g.eTop - 20, { size: 11, align: 'right', color: COL.ink2 });
  label(ctx, '変位', W - 34, g.e0 + 15, { size: 11, align: 'right', color: COL.ink2 }); sym(ctx, 'x', W - 22, g.e0 + 15, { size: 13 });
  label(ctx, 'O', g.xO - 9, g.e0 + 13, { size: 11, halo: false });
  sym(ctx, 'A', X(A), g.e0 + 15, { size: 13 }); label(ctx, '−', X(-A) - 9, g.e0 + 15, { size: 12, halo: false }); sym(ctx, 'A', X(-A) + 3, g.e0 + 15, { size: 13 });
  /* 放物線 U = ½kx²（動いたところまで描く）と E の線 */
  var lo = 0, hi = 0;
  if (s.dragX !== undefined || (s.t === 0 && !s.playing)) { lo = hi = b.xv; }
  else if (s.t >= q.T / 2) { lo = -A; hi = A; }
  else { for (var n = 0; n <= 60; n++) { var xx = m1s3State(s, s.t * n / 60).x; lo = Math.min(lo, xx); hi = Math.max(hi, xx); } }
  if (hi - lo > 1e-4) {
    ctx.save(); ctx.strokeStyle = '#14171c'; ctx.lineWidth = 1.8; ctx.beginPath();
    for (var p = 0; p <= 80; p++) { var x3 = lo + (hi - lo) * p / 80; p ? ctx.lineTo(X(x3), YE(0.5 * q.k * x3 * x3)) : ctx.moveTo(X(x3), YE(0.5 * q.k * x3 * x3)); }
    ctx.stroke(); ctx.restore();
  }
  ctx.save(); ctx.strokeStyle = ECOL.E; ctx.lineWidth = 3.2; ctx.beginPath(); ctx.moveTo(X(-A), YE(E)); ctx.lineTo(X(A), YE(E)); ctx.stroke(); ctx.restore();
  sym(ctx, 'E', X(-A) - 12, YE(E), { size: 14, color: ECOL.E });
  /* いまの x の位置に、U（下）と K（その上）を積み上げる */
  var Uc = 0.5 * q.k * b.xv * b.xv, xc = X(b.xv);
  if (Uc * ek > 3) eArrow(ctx, xc, g.e0, xc, YE(Uc), ECOL.U);
  if ((E - Uc) * ek > 3) eArrow(ctx, xc, YE(Uc), xc, YE(E), ECOL.K);
  var lx = xc + (b.xv > 0.6 * A ? -10 : 10), al = b.xv > 0.6 * A ? 'right' : 'left';
  if ((E - Uc) * ek > 18) label(ctx, '運動エネルギー ½mv²', lx, (YE(E) + YE(Uc)) / 2, { size: 11, color: ECOL.K, align: al });
  if (Uc * ek > 18) label(ctx, '位置エネルギー ½kx²', lx, (g.e0 + YE(Uc)) / 2, { size: 11, color: ECOL.U, align: al });
  bubble(ctx, '力学的エネルギー E = ½mv² + ½kx² = 一定', X(0.62 * A), YE(E) - 4, { size: 12 });
  drawEqualTicks(ctx);
}
function rightM1S3(s, R) {
  var q = m1s3Q(s);
  var h = '<div class="qcard keybox"><p class="qt">ここが大事</p><ul class="pts">' +
    '<li>単振動は必ず、<b>つりあいの位置を中心として</b>振動する。</li>' +
    '<li>つりあいの位置（$x = 0$）で、<b>運動エネルギーが最大</b>（速さが最大）。</li>' +
    '<li>振動の端（$x = \\pm A$）で、<b>位置エネルギーが最大</b>（速さは 0）。</li>' +
    '<li>2 つの和の力学的エネルギーは一定：$E = \\dfrac{1}{2}mv^2 + \\dfrac{1}{2}kx^2 = \\dfrac{1}{2}kA^2$</li></ul></div>' +
    '<div class="qcard"><p class="qt">いまの値</p><p class="qnow m13now"></p></div>' +
    /* なぜ一定になるのか：x・v を代入する（前の ③-1 の説明をここへ。2026-10-18 千葉さん） */
    '<div class="qcard"><p class="qt">なぜ一定？：力学的エネルギーに $x$・$v$ を代入する</p>' +
    '<p>変位 $x$、速さ $v$ のときの力学的エネルギーは $E = \\dfrac{1}{2}mv^2 + \\dfrac{1}{2}kx^2$。ここに</p>' +
    '<div class="qeq">$$x = A\\sin(\\omega t + \\phi),\\qquad v = A\\omega\\cos(\\omega t + \\phi),\\qquad k = m\\omega^2$$</div><p>を代入すると</p>' +
    '<div class="qeq">$$\\begin{aligned} E &= \\dfrac{1}{2}m\\{A\\omega\\cos(\\omega t + \\phi)\\}^2 + \\dfrac{1}{2}(m\\omega^2)\\{A\\sin(\\omega t + \\phi)\\}^2 \\\\ &= \\dfrac{1}{2}m\\omega^2A^2\\{\\cos^2(\\omega t + \\phi) + \\sin^2(\\omega t + \\phi)\\} \\\\ &= \\dfrac{1}{2}m\\omega^2A^2 = \\dfrac{1}{2}kA^2 \\end{aligned}$$</div>' +
    '<p>$t$（つまり $x$）に関係なく一定になる。これは水平ばね振り子だけでなく、単振動をしているすべての物体で成りたつ（$k$ を $K$ にかえる）。鉛直ばね振り子などでの使い方は <a href="#3-2" class="xlink">③-2 単振動のエネルギー $U = \\dfrac{1}{2}kx^2$</a> へ。</p></div>';
  R.innerHTML = mathify(h);
  s._now = R.querySelector('.m13now'); s._nowH = null; m1s3Live(s);
}
function m1s3Live(s) {
  if (!s._now) return;
  var now = performance.now(); if (s.playing && s._nowT && now - s._nowT < 120) return; s._nowT = now;   /* 再生中は 1 秒に 8 回まで */
  var st = s.dragX !== undefined ? (function () { var e = SHM.energy(M1.s3.m, M1.s3.k, s.dragX, 0); return { x: s.dragX, v: 0, K: e.K, U: e.U, E: e.E }; })() : m1s3State(s, s.t);
  var h = '$x =$ ' + fmt(st.x, 3) + ' m　$v =$ ' + fmt(st.v, 3) + ' m/s<br>' +
    '<span style="color:' + ECOL.K + '">$K = \\dfrac{1}{2}mv^2 =$ ' + fmt(st.K, 4) + ' J</span><br>' +
    '<span style="color:' + ECOL.U + '">$U = \\dfrac{1}{2}kx^2 =$ ' + fmt(st.U, 4) + ' J</span><br>' +
    '<b style="color:' + ECOL.E + '">$E = K + U =$ ' + fmt(st.E, 4) + ' J</b>';
  if (h === s._nowH) return; s._nowH = h; s._now.innerHTML = mathify(h);
}
