/* =========================================================================
   52_mode2.js … モード② 色んな単振動
   ②-1 水平ばね振り子／②-2 両側ばね／②-3 鉛直ばね振り子／②-4 斜め台の上のばね振り子／
   ②-5 水平で摩擦がある場合／②-6 単振り子／②-7 浮力による単振動
   どのセクションも同じ作り（m2Def）：
     左の列：スライダー → 2 段目（x = 0 の切りかえ・すべて最初の設定に戻す・力を表示）→ ▶ スタート＋時間バー → 図
             → 図の下に「対応する円運動とエネルギー − t グラフ」（既定はたたむ）
     右の列：振動の様子を並べた図（マウスをかざすと拡大）→ x–t・v–t・a–t グラフ → 立式（① 力 → ② 運動方程式 → ③ 中心・ω・T）
   変位：X＝つりあいの位置からの変位（物理の計算はこれ）。x＝図とグラフに出す変位（x = X + 原点のずれ）
   ========================================================================= */
'use strict';
var M2BALL = '#d9b77a';

/* ---------- 共通の作り ---------- */
function m2Def(o) {
  var d = {
    id: o.id, mode: 'mode2', num: o.num, title: o.title, short: o.short, desc: o.desc,
    strobe: false, showFBtn: true, fDefault: null, fGlow: true, fNetLabel: o.fNetLabel, vecBtn: 'v を消す', graphs: true, stgCls: 'solo', belowCanvas: true,   /* 力の表示の既定：②-1 は合力のみ、他は個別（2026-10-16 千葉さん） */
    baseRate: o.rate || 0.5,
    vars: o.vars, varCols: o.varCols, varWide: o.varWide, varColNote: o.varColNote,
    buttons: o.buttons,
    O: o,
    init: function (s) { s.circOn = false; s.cardOpen = true; if (o.init) o.init(s); },   /* 右下の解説は最初から開いておく（2026-10-16 千葉さん） */
    onDefaults: function (s) { if (o.onDefaults) o.onDefaults(s); m2Sync(s); },
    onChanged: function (s, k) { if (o.onChanged) o.onChanged(s, k); s.resize(); if (s.graphs) shmGraphReset(s); m2Snaps(s); },   /* ②-4 は θ で図の高さが変わる */
    tEnd: function (s) { return o.tEnd ? o.tEnd(s) : tBarOf(o.Q(s).T); },
    tInfo: function (s) { return periodInfo(o.Q(s).T); },
    gq: function (s, t) { return m2State(s, t); },
    gWin: function (s) { return o.gWin ? o.gWin(s) : 2 * o.Q(s).T; },
    gT: function (s) { return o.Q(s).T; },
    gAmp: function (s) { var Q = o.Q(s); return { x: Math.abs(Q.off || 0) + Q.A, v: Q.A * Q.w, a: Q.A * Q.w * Q.w, E: o.E0 ? o.E0(s) : 0.5 * Q.K * Q.A * Q.A }; },
    height: function (s, w) {
      var h = o.height(w, s), Q = o.Q(s);
      if (s.circOn && o.circ === 'below') { var g = o.geo(s, { x0: 0, y0: 0, w: w, h: h }); h += Math.round(2 * Q.Amax * g.S + 44); }
      if (s.circOn && o.circ === 'normal') h += o.circExtra(w, h, s);
      return h + (o.topRef || 0);                                   /* 上に「つりあいの位置」の参考の図（②-1・②-2） */
    },
    dragHit: o.noDrag ? null : function (s, x, y) { var g = m2Geo(s), b = g.pos(m2State(s, s.t).X); return Math.hypot(x - b.x, y - b.y) < g.rb + 10; },
    dragMove: function (s, x, y) {
      var g = m2Geo(s), p0 = g.pos(0), X = ((x - p0.x) * g.u[0] + (y - p0.y) * g.u[1]) / g.S, Q = o.Q(s);
      X = clamp(X, -Q.Amax, Q.Amax); if (Math.abs(X) < Q.Amin) X = X < 0 ? -Q.Amin : Q.Amin; s.dragX = X;
    },
    dragEnd: function (s) { if (s.dragX === undefined) return; o.setAmp(s, s.dragX); s.dragX = undefined; },
    afterBuild: function (s) {
      /* 右の列：スライダー → グラフ → 振動の様子を並べた図 → 立式（①-2 と同じ並び。アニメと x–t グラフの上をそろえやすい。2026-10-16 千葉さん） */
      s.R.innerHTML = '';
      if (s.varbox) { var sw = el('div', 'row2 sliders inR'); sw.appendChild(s.varbox); s.R.appendChild(sw); s.varbox.classList.add('inR'); }
      /* x–t・v–t・a–t グラフはまとめてたたんでおく（クリックで開く。2026-10-16 千葉さん） */
      var gdet = el('details', 'gdet'); gdet.innerHTML = '<summary>' + tex('x') + '–' + tex('t') + ' グラフなど（クリックしよう）</summary>';
      gdet.appendChild(s.gHost); s.R.appendChild(gdet); s.gdet = gdet;
      gdet.addEventListener('toggle', function () { (s.graphs || []).forEach(function (g) { g.Wc = 0; }); s.draw(); if (!gdet.open) { s.gHost.style.marginTop = ''; s.cw.style.marginTop = ''; } });
      s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);
      /* 図の下：対応する円運動とエネルギー − t グラフ（既定はたたむ） */
      var det = el('details', 'circdet'); det.innerHTML = '<summary>対応する円運動とエネルギー − ' + tex('t') + ' グラフ</summary>';
      s.eHost = el('div', 'ehost'); det.appendChild(s.eHost); s.below.appendChild(det); s.det = det;
      det.addEventListener('toggle', function () { s.circOn = det.open; s.resize(); (s.graphs || []).forEach(function (g) { g.Wc = 0; }); s.draw(); });
      s.snapBox = el('div', 'snapbox'); s.below.appendChild(s.snapBox);   /* 振動の様子を並べた図は、対応する円運動の欄の下（2026-10-16 千葉さん） */
      var D = xvaDefs();
      D[0].range = function (s) { var Q = o.Q(s), c = Q.off || 0; return { lo: Math.min(c - Q.A, -Q.A * 0.2), hi: Math.max(c + Q.A, Q.A * 0.2) }; };
      if (o.xLabel) D[0].title = o.xLabel;
      var E = energyDef(); E.host = function (s) { return s.eHost; }; E.H = function () { return 150; };
      if (o.eRange) E.range = o.eRange;
      shmGraphs(s, D.concat([E]));
      m2Snaps(s);
      if (o.afterBuild) o.afterBuild(s);
      m2Sync(s);
    },
    live: function (s) { if (o.live) o.live(s); },
    msg: function (s) { return o.msg ? o.msg(s) : ''; },
    draw: function (s, ctx, W, H) { m2Draw(s, ctx, W, H); },
    right: function (s) {
      if (!s.Rdyn) return;
      s.Rdyn.innerHTML = mathify(o.card(s));
      var dt = s.Rdyn.querySelector('details.m2card');                /* たたんでおく（開いたら、描き直しても開いたまま） */
      if (dt) { dt.open = !!s.cardOpen; dt.addEventListener('toggle', function () { s.cardOpen = dt.open; }); }
      if (o.afterCard) o.afterCard(s);
    }
  };
  return d;
}
function m2Sync(s) { var o = s.def.O; if (o.sync) o.sync(s); }
/* その時刻の状態。X：つりあいの位置からの変位、x：図とグラフの変位 */
function m2State(s, t) {
  var o = s.def.O, Q = o.Q(s), r;
  if (o.state) r = o.state(s, t);
  else { var st = SHM.st(Q.A, Q.w, Q.phi, t); r = { X: st.x, v: st.v, a: st.a }; }
  if (s.dragX !== undefined && t === s.t) r = { X: s.dragX, v: 0, a: -Q.w * Q.w * s.dragX };
  r.x = r.X + (Q.off || 0);
  var e = o.energy ? o.energy(s, r) : { K: 0.5 * Q.m * r.v * r.v, U: 0.5 * Q.K * r.X * r.X };
  r.K = e.K; r.U = e.U; r.E = e.K + e.U;
  return r;
}
/* 図の大きさ（円を右に出すときは、図の部分をせまくする） */
function m2Box(s) {
  var o = s.def.O, W = s.W, H = s.H, tr = o.topRef || 0;           /* tr：上の参考の図の高さ（その下から描く） */
  if (s.circOn && o.circ === 'right') return { x0: 0, y0: 0, w: W * 0.66, h: H };
  if (s.circOn && o.circ === 'below') return { x0: 0, y0: tr, w: W, h: o.height(W, s) };
  if (tr) return { x0: 0, y0: tr, w: W, h: H - tr };
  if (s.circOn && o.circ === 'normal') { var h0 = o.height(W, s), ex = o.circExtra(W, h0, s); return { x0: 0, y0: ex, w: W, h: h0 }; }   /* 斜面：上に場所をあけ、斜面に垂直な向きに円を置く */
  return { x0: 0, y0: 0, w: W, h: H };
}
function m2Geo(s) { return s.def.O.geo(s, m2Box(s)); }
function m2Draw(s, ctx, W, H) {
  var o = s.def.O, g = m2Geo(s), st = m2State(s, s.t);
  o.scene(s, ctx, g, st, {});
  if (s.circOn) m2Circle(s, ctx, g, st);
  if (s.dragging) { var b = g.pos(st.X); label(ctx, '離すと、この位置から静かに放す', b.x, Math.max(14, b.y - g.rb - 30), { size: 11.5, bold: true, color: '#9c4e06' }); }
  drawEqualTicks(ctx);
  m2SnapCheck(s);
}
/* 斜面：円の中心は、つりあいの位置から斜面に垂直に、x 軸（斜面から rb + 50）より外がわへ */
function m2NormOff(Q, g) { return Q.Amax * g.S + g.rb + 50 + 22; }
/* 対応する円運動：振動の向きに沿って A sin θ の位置にくる点 P。円の中心は振動の中心の横（または下） */
function m2Circle(s, ctx, g, st) {
  var o = s.def.O, Q = o.Q(s), c = o.circState ? o.circState(s, s.t) : { c: 0, R: Q.A, th: Q.w * s.t + Q.phi };
  if (s.dragX !== undefined) c = { c: 0, R: Math.abs(s.dragX), th: s.dragX < 0 ? -Math.PI / 2 : Math.PI / 2 };
  var R = c.R * g.S, u = g.u, n, ctr, base = g.pos(c.c);
  if (o.circ === 'right') {
    n = g.nCirc;
    ctr = { x: s.W * 0.83, y: base.y };                                                /* 鉛直：図の右（同じ高さ） */
  } else if (o.circ === 'normal') {
    n = g.n; var off = m2NormOff(Q, g); ctr = { x: base.x + n[0] * off, y: base.y + n[1] * off };   /* 斜面：つりあいの位置から斜面に垂直な向きへ */
  } else { n = [0, 1]; ctr = { x: base.x, y: m2Box(s).h + 22 + Q.Amax * g.S }; }      /* 水平：図の下 */
  var px = ctr.x + R * (Math.sin(c.th) * u[0] - Math.cos(c.th) * n[0]), py = ctr.y + R * (Math.sin(c.th) * u[1] - Math.cos(c.th) * n[1]);
  ctx.save(); ctx.strokeStyle = '#8d9097'; ctx.lineWidth = 1.3; ctx.beginPath(); ctx.arc(ctr.x, ctr.y, Math.max(1, R), 0, TAU); ctx.stroke();
  ctx.strokeStyle = '#3a414c'; ctx.beginPath(); ctx.moveTo(ctr.x, ctr.y); ctx.lineTo(px, py); ctx.stroke();
  ctx.fillStyle = '#3a414c'; ctx.beginPath(); ctx.arc(ctr.x, ctr.y, 2.4, 0, TAU); ctx.fill(); ctx.restore();
  /* ①-2 と同じ見た目：基準の直径（点線）・初期位相 ϕ の角・ωt の角（1 周期ごとに描き直す）（2026-10-16 千葉さん） */
  dotted(ctx, ctr.x - n[0] * (R + 10), ctr.y - n[1] * (R + 10), ctr.x + n[0] * (R + 10), ctr.y + n[1] * (R + 10), 'rgba(20,23,28,.35)', [3, 3]);
  var dir = function (th, r) { return { x: ctr.x + r * (Math.sin(th) * u[0] - Math.cos(th) * n[0]), y: ctr.y + r * (Math.sin(th) * u[1] - Math.cos(th) * n[1]) }; };
  var arcTh = function (a0, a1, r, col, lw) { if (Math.abs(a1 - a0) < 0.02) return; ctx.save(); ctx.strokeStyle = col; ctx.lineWidth = lw; ctx.beginPath(); for (var i = 0; i <= 40; i++) { var p = dir(a0 + (a1 - a0) * i / 40, r); if (i) ctx.lineTo(p.x, p.y); else ctx.moveTo(p.x, p.y); } ctx.stroke(); ctx.restore(); };
  if (!o.circState && s.dragX === undefined && R > 14) {
    var ph = Q.phi, rr = Math.min(16, R * 0.4);
    if (Math.abs(ph) > 1e-9) { arcTh(0, ph, rr, '#7a4fb8', 1.5); var pl = dir(ph / 2, rr + 10); sym(ctx, 'ϕ', pl.x, pl.y, { size: 12.5, color: '#7a4fb8' }); }
    var dth = Q.w * s.t, cyc = dth - TAU * Math.floor(dth / TAU + 1e-9);
    if ((s.t > 0 || s.playing) && cyc > 0.05) {
      var p0 = dir(ph, R); dotted(ctx, ctr.x, ctr.y, p0.x, p0.y, 'rgba(20,23,28,.35)', [3, 3]);
      var ra = Math.min(28, R * 0.62); arcTh(ph, ph + cyc, ra, '#3a414c', 1.3);
      var lw2 = dir(ph + cyc / 2, ra + 11); sym(ctx, 'ωt', lw2.x, lw2.y, { size: 12.5, color: '#3a414c' });
    }
  }
  var b = g.pos(st.X);
  dotted(ctx, px, py, b.x, b.y, 'rgba(22,99,181,.6)', [3, 4]);
  ballShape(ctx, px, py, 6, M2BALL);
  label(ctx, '対応する等速円運動', ctr.x, ctr.y + Math.max(R, 10) + 14, { size: 11, color: COL.ink2 });
}

/* ---------- 振動の様子を並べた図（教科書 図 137 のように）。2026-10-19 千葉さん：
   ・それぞれの場面は、前に拡大図で見せていたくわしい図（力の名前・式つき）を、もとから描く。
   ・横長の図（②-1・②-2・②-5・②-8）は、上下の余白を半分につめて縦に並べ、右の空いた所に拡大図。
   ・縦長の図（②-3・②-4・②-6・②-7）は、左右の余白を半分につめて横に並べ、下の空いた所に拡大図（前の 1.3 倍）。
   ・拡大図は、マウスをかざした（タップした）場面。はじめは ⓐ。
   ・o.snapCrop＝[左, 右]（横の割合）のときは、その範囲だけ切り出す（②-7 は水のまわりだけ）。 ---------- */
function m2SnapO(s) { return s.def.O || s.def.snapO; }
function m2SnapKind(o) { return o.snapKind || ((o.snapAsp || 1.35) >= 1 ? 'v' : 'h'); }
function m2Snaps(s) {
  var o = m2SnapO(s); if (!s.snapBox || !o || !o.snaps) return;
  var list = o.snaps(s), kind = m2SnapKind(o);
  s.snapBox.className = 'snapbox k' + kind;
  s.snapBox.innerHTML = '<p class="snapttl">振動の様子を並べた図<span class="snaphint">（図にマウスをかざす・タップすると、' + (kind === 'h' ? '右' : '下') + '<span class="snapnarrow">（スマホでは下）</span>に大きく出る）</span></p><div class="snapwrap"><div class="snaprow n' + list.length + '"></div><div class="snapzin"><canvas></canvas><p></p></div></div>';
  var row = s.snapBox.querySelector('.snaprow');
  s._snapList = list; s._snapCells = []; s._snapSel = 0;
  list.forEach(function (f, i) {
    var cell = el('div', 'snapcell' + (i === 0 ? ' sel' : '')), cv = el('canvas'); cell.appendChild(cv);
    cell.appendChild(el('p', 'snapcap', mathify(f.cap + (f.eq ? '<br><span class="snapeq">' + f.eq + '</span>' : '')))); row.appendChild(cell);
    cell.tabIndex = 0; s._snapCells.push({ cell: cell, cv: cv, f: f });
    var show = function () { m2SnapZoom(s, i); };
    cell.addEventListener('mouseenter', show); cell.addEventListener('focus', show);
    cell.addEventListener('mouseleave', function () { m2SnapZoom(s, s._snapSel); });
    cell.addEventListener('click', function () { s._snapSel = i; s._snapCells.forEach(function (c, j) { c.cell.classList.toggle('sel', j === i); }); m2SnapZoom(s, i); });
  });
  s._snapW = 0; requestAnimationFrame(function () { m2SnapRenderAll(s); });
}
/* 図が見えていて幅が変わったら描きなおす（m2Draw などから毎回よぶ。軽い） */
function m2SnapCheck(s) {
  if (!s.snapBox || !s._snapCells) return;
  var w = s.snapBox.clientWidth; if (w > 50 && Math.abs(w - (s._snapW || 0)) > 16) m2SnapRenderAll(s);
}
/* 描いてから、色のある所（透明でない所）の範囲を調べる（css px） */
function m2SnapBBox(cv, W, H) {
  var r = cv.width / W, d = cv.getContext('2d').getImageData(0, 0, cv.width, cv.height).data, w = cv.width, h = cv.height, x0 = w, x1 = -1, y0 = h, y1 = -1;
  for (var y = 0; y < h; y += 2) for (var x = 0; x < w; x += 2) if (d[(y * w + x) * 4 + 3] > 10) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
  if (x1 < 0) return { x0: 0, y0: 0, x1: W, y1: H };
  return { x0: x0 / r, y0: y0 / r, x1: (x1 + 2) / r, y1: (y1 + 2) / r };
}
function m2SnapOff(s, f, W, H) { var cv = document.createElement('canvas'); m2SnapDraw(s, cv, f, W, H, true); return cv; }
/* 切り出す範囲（W×H の図の中の割合）。kind h：上下の余白を半分に／v：左右の余白を半分に */
function m2SnapFrac(o, kind, W, H, bbs) {
  var u = bbs.reduce(function (a, b) { return { x0: Math.min(a.x0, b.x0), y0: Math.min(a.y0, b.y0), x1: Math.max(a.x1, b.x1), y1: Math.max(a.y1, b.y1) }; });
  var pad = 4, c = { x0: 0, x1: 1, y0: 0, y1: 1 };
  if (kind === 'h') { c.y0 = Math.max(0, (u.y0 - pad) * 0.5) / H; c.y1 = (H - Math.max(0, (H - u.y1 - pad) * 0.5)) / H; }
  else { c.x0 = Math.max(0, (u.x0 - pad) * 0.5) / W; c.x1 = (W - Math.max(0, (W - u.x1 - pad) * 0.5)) / W; }
  if (o.snapCrop) { c.x0 = o.snapCrop[0]; c.x1 = o.snapCrop[1]; }
  return c;
}
/* 図をかき、切り出した範囲を見える canvas へ写す */
function m2SnapBlit(dst, src, W, H, c) {
  var r = src.width / W, sx = Math.round(c.x0 * W * r), sy = Math.round(c.y0 * H * r), sw = Math.round((c.x1 - c.x0) * W * r), sh = Math.round((c.y1 - c.y0) * H * r);
  dst.width = sw; dst.height = sh; var ctx = dst.getContext('2d'); ctx.clearRect(0, 0, sw, sh); ctx.drawImage(src, sx, sy, sw, sh, 0, 0, sw, sh);
  return { w: sw / r, h: sh / r };
}
function m2SnapRenderAll(s) {
  var o = m2SnapO(s), kind = m2SnapKind(o), asp = o.snapAsp || 1.35, box = s.snapBox, cells = s._snapCells; if (!cells || !cells.length) return;
  var bw = box.clientWidth; if (bw < 50) return; s._snapW = bw;
  var cw0 = Math.max(60, Math.floor(cells[0].cell.clientWidth - 6));
  var W, H, c;
  if (kind === 'h') {                                             /* 列の幅でそのまま描く（文字の大きさはそのまま） */
    W = cw0; H = Math.round(W * asp);
    var offs = cells.map(function (k) { return m2SnapOff(s, k.f, W, H); });
    c = m2SnapFrac(o, kind, W, H, offs.map(function (cv) { return m2SnapBBox(cv, W, H); }));
    cells.forEach(function (k, i) { m2SnapBlit(k.cv, offs[i], W, H, c); k.cv.style.width = '100%'; k.cv.style.height = 'auto'; });
  } else {                                                        /* 前の拡大図の大きさで一度描いて、左右をつめた割合を求め、セルの幅に合うように描きなおす */
    var W0 = Math.round(Math.min(340, 460 / asp)), H0 = Math.round(W0 * asp);
    var c0 = m2SnapFrac(o, kind, W0, H0, cells.map(function (k) { return m2SnapBBox(m2SnapOff(s, k.f, W0, H0), W0, H0); }));
    W = Math.round(cw0 / (c0.x1 - c0.x0)); W = Math.max(W, Math.round(W0 * 0.75)); H = Math.round(W * asp);
    var offs2 = cells.map(function (k) { return m2SnapOff(s, k.f, W, H); });
    c = m2SnapFrac(o, kind, W, H, offs2.map(function (cv) { return m2SnapBBox(cv, W, H); }));
    cells.forEach(function (k, i) { m2SnapBlit(k.cv, offs2[i], W, H, c); k.cv.style.width = '100%'; k.cv.style.height = 'auto'; });
    s._snapZ0 = W0;
  }
  var fit = function () { cells.forEach(function (k) {             /* 式がセルの幅に入らなければ、小さくする（数式の字体が読みこまれたあとにもう一度） */
    var e = k.cell.querySelector('.snapeq'); if (!e) return; e.style.transform = ''; e.style.margin = '';
    var room = k.cell.clientWidth - 6, w = e.offsetWidth; if (w > room) { var sc = Math.max(0.5, room / w); e.style.transform = 'scale(' + sc.toFixed(3) + ')'; e.style.margin = '0 ' + (-(w - room) / 2).toFixed(1) + 'px'; }
  }); };
  fit(); if (document.fonts && document.fonts.ready) document.fonts.ready.then(fit); setTimeout(fit, 800);
  m2SnapZoom(s, s._snapSel || 0);
}
/* 拡大図（箱の中の空いた所）。横長：右の列の幅いっぱい／縦長：前の拡大図の 1.3 倍 */
function m2SnapZoom(s, i) {
  var o = m2SnapO(s), kind = m2SnapKind(o), asp = o.snapAsp || 1.35, k = s._snapCells && s._snapCells[i]; if (!k) return;
  var zin = s.snapBox.querySelector('.snapzin'), zc = zin.querySelector('canvas'), zw = Math.max(120, Math.floor(zin.clientWidth - 12)); if (zin.clientWidth < 50) return;
  var W, H, c, off;
  if (kind === 'h') { W = zw; H = Math.round(W * asp); off = m2SnapOff(s, k.f, W, H); c = m2SnapFrac(o, kind, W, H, [m2SnapBBox(off, W, H)]); }
  else {
    var W0 = Math.round(Math.min(340, 460 / asp)), H0 = Math.round(W0 * asp);   /* 前の拡大図（W0 の幅で全体）を 1.3 倍に。切り出した幅が入らなければ小さく */
    var c0 = m2SnapFrac(o, kind, W0, H0, [m2SnapBBox(m2SnapOff(s, k.f, W0, H0), W0, H0)]);
    /* 高さの上限：小さいタブレット（画面の高さ 760 px ほど）で、並べた図と拡大図がいっしょに画面に入る大きさ（2026-10-19 千葉さん） */
    var vh = Math.min(window.innerHeight || 760, 760), rowH = s.snapBox.querySelector('.snaprow').offsetHeight || 300, hMax = Math.max(180, vh - rowH - 150);
    W = Math.round(Math.min(W0 * 1.3, zw / (c0.x1 - c0.x0), hMax / asp)); H = Math.round(W * asp); off = m2SnapOff(s, k.f, W, H); c = m2SnapFrac(o, kind, W, H, [m2SnapBBox(off, W, H)]);
  }
  var sz = m2SnapBlit(zc, off, W, H, c); zc.style.width = Math.min(zw, Math.round(sz.w)) + 'px'; zc.style.height = 'auto';
  zin.querySelector('p').innerHTML = mathify(k.f.cap + (k.f.eq ? '<br>' + k.f.eq : ''));
  s._snapCells.forEach(function (c2, j) { c2.cell.classList.toggle('on', j === i); });
}
function m2SnapDraw(s, cv, f, W, H, big) {
  var o = m2SnapO(s), ctx = prep(cv, W, H), box = { x0: 0, y0: 0, w: W, h: H }, g = o.geo(s, box, true);
  var Q = o.Q(s), X = f.X, r = { X: X, v: f.v || 0, a: -Q.w * Q.w * X, x: X + (Q.off || 0) };
  o.scene(s, ctx, g, r, { snap: true, big: big, frame: f });
  drawEqualTicks(ctx);
}

/* ---------- 図の部品 ---------- */
/* 力の矢印＋記号（記号は矢印の先）。L＝長さ［px］、(ux, uy)＝向き */
function fArrow(ctx, x, y, ux, uy, L, col, txt, opt) {
  if (Math.abs(L) < 2) return null;
  var a = arrow(ctx, x, y, x + ux * L, y + uy * L, opt && opt.kind || 'force', col, opt);
  if (txt && a) { var sx = (opt && opt.lx) || 0, sy = (opt && opt.ly) || 0; sym(ctx, txt, a.x2 + a.ux * 12 + sx, a.y2 + a.uy * 12 + sy, { size: (opt && opt.size) || 14, color: col }); }
  return a;
}
/* 合力の矢印（「合力のみを表示」）：作用点はばね（糸）と物体の接点。記号のあとに「（合力）」 */
function netArrow(ctx, x, y, ux, uy, L, name, opt) {
  opt = opt || {};
  if (Math.abs(L) < 2) return null;
  var a = arrow(ctx, x, y, x + ux * L, y + uy * L, 'force', COL.force, { noShift: true });
  if (a && name) {                                                 /* 横向きの矢印は、記号を矢印の先の外がわに（物体と重ねない） */
    var hz = Math.abs(a.ux) > 0.7, al = opt.al || (hz ? (a.ux > 0 ? 'left' : 'right') : 'center');
    sym(ctx, name, a.x2 + a.ux * (hz ? 6 : 12) + (opt.lx || 0), a.y2 + a.uy * 12 + (opt.ly || 0), { size: 14, color: COL.force, align: al, tail: '（合力）' });
  }
  return a;
}
/* つりあいの位置を表す点線のとなりの「つりあいの位置」（赤字。②-1〜②-7 で同じ字体。2026-10-16 千葉さん） */
function eqLabel(ctx, x, y, al, txt) { label(ctx, txt || 'つりあいの位置', x, y, { size: 10.5, bold: true, color: '#c0392b', align: al || 'left' }); }
/* 速度の矢印：物体から n の向きに off だけ離した所に、u の向きで */
function vArrowAt(ctx, bx, by, nx, ny, off, ux, uy, L, lab) {
  if (Math.abs(L) < 3) return;
  var cx = bx + nx * off, cy = by + ny * off, sg = L > 0 ? 1 : -1, l = Math.abs(L);
  arrow(ctx, cx - ux * sg * l / 2, cy - uy * sg * l / 2, cx + ux * sg * l / 2, cy + uy * sg * l / 2, 'vel');
  if (lab !== false) sym(ctx, 'v', cx + ux * sg * (l / 2 + 10), cy + uy * sg * (l / 2 + 10) - 2, { size: 13.5, color: COL.vel });
}
/* x 軸（向き u、原点 p0、目盛り「O」と、ラベル） */
function m2Axis(ctx, p0, u, a0, a1, lab, o) {
  o = o || {};
  axisArrow(ctx, p0.x + u[0] * a0, p0.y + u[1] * a0, p0.x + u[0] * a1, p0.y + u[1] * a1);
  var n = [-u[1], u[0]];
  ctx.save(); ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 1.3; ctx.beginPath(); ctx.moveTo(p0.x + n[0] * 4, p0.y + n[1] * 4); ctx.lineTo(p0.x - n[0] * 4, p0.y - n[1] * 4); ctx.stroke(); ctx.restore();
  label(ctx, 'O', p0.x + (o.oDx || n[0] * 12), p0.y + (o.oDy || n[1] * 12), { size: 11.5, bold: true });
  sym(ctx, 'x', p0.x + u[0] * (a1 + 10) + (o.xDx || 0), p0.y + u[1] * (a1 + 10) + (o.xDy || 0), { size: 14 });
  if (lab) label(ctx, lab, p0.x + u[0] * (a1 + 10) + (o.lDx || 0), p0.y + u[1] * (a1 + 10) + (o.lDy !== undefined ? o.lDy : 16), { size: 10.5, color: '#5d6875', align: o.lAl || 'center' });
}
/* 立式カード（① 力 → ② 運動方程式 → ③ 振動の中心・ω・T） */
function m2Card(c) {
  /* 「〜の運動方程式と周期」として折りたたむ（クリックで開く。最初はたたんでおく。2026-10-16 千葉さん） */
  return '<details class="qcard m2card"><summary class="qt">' + c.ttl + 'の運動方程式と周期</summary>' +
    '<div class="stp"><p class="sh"><b>①</b> 小球にはたらく力を書く</p>' + c.f + '</div>' +
    '<div class="stp"><p class="sh"><b>②</b> 運動方程式を $ma = -K(x - x_0)$ の形にする</p>' + c.eq + '</div>' +
    '<div class="stp"><p class="sh"><b>③</b> $a$ と $x$ の関係式を作り、$a = -\\omega^2x$ と比べて $\\omega$・$T$ を求める</p>' + c.read + '</div>' +
    (c.note || '') + '</details>';
}
/* ③：運動方程式から a と x の関係式を作り、単振動の式 a = −ω²x と比べて ω を求める（2026-10-16 千葉さん）。
   aRhs：a = の右辺、wTex：ω、TTex：T、note：あとに書く文、shifted：x − x₀ の形（比べるのは a = −ω²(x − x₀)）、approx：≒ */
function m2Read(aRhs, wTex, TTex, note, shifted, approx) {
  return '<p>運動方程式の両辺を $m$ でわって、$a$ と $x$ の関係式を作ると</p><div class="qeq">$$a ' + (approx ? '' : '= ') + aRhs + '$$</div>' +
    '<p>これを単振動の加速度の式 $a = -\\omega^2 ' + (shifted ? '(x - x_0)' : 'x') + '$ と比べると</p>' +
    '<div class="qeq">$$\\omega = ' + wTex + ',\\qquad T = \\dfrac{2\\pi}{\\omega} = ' + TTex + '$$</div>' + (note ? '<p>' + note + '</p>' : '');
}
function eqL(tag, body) { return '<p class="eqline">' + eqTag(tag) + body + '</p>'; }
/* 初期位相 φ のスライダー（①-2・①-3 と同じもの） */
function m2Phi(def0) { return phiVar(def0, true); }        /* モード② はボタンの 5 択（2026-10-16 千葉さん） */
function m2SetAmp(s, X) { s.v.A = Math.round(Math.abs(X) * 100) / 100; if (s.v.phi !== undefined) s.v.phi = X < 0 ? -Math.PI / 2 : Math.PI / 2; }
/* x = 0 の位置の切りかえ（②-3・②-4） */
function orgButtons() {
  return [
    { k: 'oEq', label: 'つりあいの位置<br>を $x = 0$', cls: 'obs two', seg: 'org', segLabel: 'x = 0 の位置', onClick: function (s) { setOrg(s, 0); } },
    { k: 'oNat', label: '自然長の位置<br>を $x = 0$', cls: 'obs two', seg: 'org', onClick: function (s) { setOrg(s, 1); } }
  ];
}
function setOrg(s, v) { s.org = v; syncOrg(s); if (s.graphs) { shmGraphReset(s); } s.draw(); s.renderRight(); m2Snaps(s); }
function syncOrg(s) {
  if (!s.extra.oEq) return;
  [s.extra.oEq, s.extra.oNat].forEach(function (b, i) { var on = (s.org || 0) === i; b.classList.toggle('on', on); b.setAttribute('aria-pressed', on ? 'true' : 'false'); if (b.innerHTML.indexOf('$') >= 0) b.innerHTML = mathify(b.innerHTML); });
}

/* =====================================================================
   ②-1 水平ばね振り子
   ===================================================================== */
function hGeo(s, box, Amax, small) {
  var S = Math.min(box.w * 0.18 / Amax, 1440), yF = box.y0 + box.h * (small ? 0.56 : 0.60), xO = box.x0 + box.w * 0.56;   /* 横の縮尺は前の 60 %（下の円も 60 % になる。2026-10-16 千葉さん） */
  var rb = small ? 7 : 15, xW = Math.max(box.x0 + (small ? 6 : 10), xO - Amax * S - (small ? 40 : 0.30 * box.w));   /* ばねの自然の長さを長めに（縮んでもつぶれない） */
  return { S: S, yF: yF, xO: xO, rb: rb, xW: xW, u: [1, 0], pos: function (X) { return { x: xO + X * S, y: yF - rb }; } };
}
DEFS.m2s1 = m2Def({
  id: 'm2s1', num: 1, title: '水平ばね振り子', circ: 'below', rate: 0.25, netName: '−kx',
  desc: 'なめらかな水平面の上で、ばねにつけた小球が振動する。自然の長さの位置 O がつりあいの位置。<span class="todo">スタート前に小球をドラッグして、好きな位置から放してみよう。</span>',
  vars: [{ k: 'A', label: '振幅 $A$', min: 0.04, max: M2.s1.Amax, step: 0.01, def: M2.s1.A, aria: '振幅', fmt: function (x) { return fmt(x, 2) + ' m'; } }, m2Phi(Math.PI / 2)],
  varCols: [['A'], ['phi']],
  Q: function (s) { var m = M2.s1.m, K = M2.s1.k, w = Math.sqrt(K / m); return { m: m, K: K, w: w, T: TAU / w, A: s.v.A, phi: s.v.phi, Amax: M2.s1.Amax, Amin: 0.02 }; },
  setAmp: m2SetAmp,
  height: function (w) { return Math.round(clamp(w * 0.24, w < 480 ? 180 : 140, 180)); },   /* せまい画面では、上に吹き出しの場所をとる */
  geo: function (s, box, small) { return hGeo(s, box, M2.s1.Amax, small); },
  snapAsp: 0.62, topRef: 64,                                     /* 上に「つりあいの位置」の参考の図（2026-10-25 千葉さん） */
  scene: function (s, ctx, g, st, opt) { hScene(s, ctx, g, st, opt, [{ k: M2.s1.k, side: -1, name: '−kx' }]); },
  snaps: function (s) {
    var A = M2.s1.Amax * 0.8;
    return [{ cap: 'ⓐ つりあいの位置', X: 0 }, { cap: 'ⓑ 手をはなす', X: A, hand: true }, { cap: 'ⓒ $x>0$ のとき', X: A * 0.5, v: -1, eq: '$F = -kx < 0$' }, { cap: 'ⓓ $x<0$ のとき', X: -A * 0.5, v: -1, eq: '$F = -kx > 0$' }];
  },
  card: function (s) {
    var Q = DEFS.m2s1.O.Q(s);
    return m2Card({ ttl: '水平ばね振り子', f: '<p>水平方向の力は弾性力 $-kx$ だけ（重力 $mg$ と垂直抗力 $N$ は鉛直方向でつりあう）。</p>',
      eq: eqL('eom', '$ma = -kx$') + '<p>$K = k$、$x_0 = 0$ の形になっている。</p>',
      read: m2Read('-\\dfrac{k}{m}x', '\\sqrt{\\dfrac{k}{m}}', '2\\pi\\sqrt{\\dfrac{m}{k}}', '振動の中心は $x_0 = 0$（自然の長さの位置＝つりあいの位置）。') +
        '<p class="qnow"><span class="qtag now">いまの値</span>$m = ' + Q.m.toFixed(2) + '$ kg、$k = ' + Q.K + '$ N/m なので $T = ' + sig2(Q.T) + '$ s</p>' });
  }
});
/* ②-1・②-2 の上の参考の図：つりあいの位置（＝自然の長さの位置）で小球が止まっているようす。横の位置は下のアニメと同じ（2026-10-25 千葉さん） */
function hRef(s, ctx, g, springs, Q, right, xR) {
  var tr = s.def.O.topRef, yF = tr - 14, yb = yF - g.rb;
  refArea(ctx, 0, 0, s.W, tr, 'b');
  wallLeftAt(ctx, g.xW, yF - 40, yF);
  if (springs.length > 1) hatchSeg(ctx, right, yF, right, yF - 40, 1, 8);
  floorAt(ctx, g.xW, xR, yF);
  springs.forEach(function (sp) {
    var L0 = g.xO - g.rb - g.xW, o2 = { r: 8, lead: 8, k: sp.k, thin: 1, Lmin: L0 - Q.Amax * g.S };
    if (sp.side < 0) springDense(ctx, g.xW, yb, g.xO - g.rb, yb, L0, o2); else springDense(ctx, g.xO + g.rb, yb, right, yb, L0, o2);
  });
  ballShape(ctx, g.xO, yb, g.rb, M2BALL);
  label(ctx, 'つりあいの位置', g.xO - 4, 13, { size: 10.5, bold: true, color: '#c0392b', align: 'right' });
  if (s.W >= 560) label(ctx, springs.length > 1 ? '（2 本のばねがどちらも自然の長さ）' : '（ばねは自然の長さ）', g.xO + 4, 13,   /* せまい画面では（ ）は出さない */ { size: 10, color: '#5d6875', align: 'left' });
}
/* 水平の振り子の図（②-1・②-2）。springs：[{ k, side（−1 左のかべ・+1 右のかべ）, name }] */
function hScene(s, ctx, g, st, opt, springs) {
  var snap = opt.snap, big = opt.big, sm = snap && !big, b = g.pos(st.X), W = s.W, right = g.xO + (g.xO - g.xW);
  var kMax = Math.max.apply(null, springs.map(function (sp) { return sp.k; }));
  var Q = s.def.O.Q(s), showF = snap || fAll(s), net = !snap && fNet(s), fs = (sm ? 16 : 50) / Math.max(kMax * Q.Amax, Q.m * G);   /* 縮尺：1 本のばねの最大の弾性力（または重力）が 50 px */
  var xR = springs.length > 1 ? right : (snap ? g.xO + (g.xO - g.xW) * 0.9 : Math.min(W - 10, right + 80));
  if (!snap && s.def.O.topRef) hRef(s, ctx, g, springs, Q, right, xR);
  wallLeftAt(ctx, g.xW, g.yF - (sm ? 26 : 52), g.yF);
  if (springs.length > 1) hatchSeg(ctx, right, g.yF, right, g.yF - (sm ? 26 : 52), 1, sm ? 5 : 8);
  floorAt(ctx, g.xW, xR, g.yF);
  springs.forEach(function (sp) {
    var L0 = g.xO - g.rb - g.xW;
    var o2 = { r: sm ? 4 : 8, lead: sm ? 3 : 8, k: sp.k, thin: sm ? 0.6 : 1, Lmin: L0 - Q.Amax * g.S };
    if (sp.side < 0) springDense(ctx, g.xW, b.y, b.x - g.rb, b.y, L0, o2);
    else springDense(ctx, b.x + g.rb, b.y, right, b.y, L0, o2);
  });
  dotted(ctx, g.xO, g.yF - (sm ? 30 : 50), g.xO, g.yF + (snap ? 0 : 26), 'rgba(20,23,28,.35)', [4, 3]);
  if (!snap) { label(ctx, '＝ 自然の長さの位置', g.xO + 12, g.yF + 41, { size: 10.5, color: '#5d6875', align: 'left' }); var lR = s.t === 0 && !s.playing && st.X < 0; if (!(lR && s.W < 480 && springs.length > 1)) eqLabel(ctx, g.xO + (lR ? 5 : -5), g.yF - 46, lR ? 'left' : 'right'); }   /* スタート前に左の端で手を出すときは、点線の右に（手と重ねない） */   /* 点線の上の左に赤字 */
  if (!snap && s.t < 0.5) startHand(s, ctx, b.x, b.y, g.rb, 'right', Math.cos(Q.phi), st.X < 0 ? { bubPos: 'l', bubDy: s.W < 480 ? -24 : -14 } : { bubDy: s.W < 480 ? -24 : 0 });   /* x < 0 では O の点線と重ならないよう手の左に */
  if (opt.frame && opt.frame.hand) dropHand(ctx, b.x, b.y, (big ? 0.42 : 0.2) * g.rb / 13, 0, 1);
  ballShape(ctx, b.x, b.y, g.rb, M2BALL);
  /* 速度（小球の上）・力 */
  var vref = Q.A * Q.w || 1, vs = snap ? (opt.frame.v || 0) * 0.7 : (s.hideVec ? 0 : 1) * st.v / vref;
  if (Math.abs(vs) > 0.03) vArrowAt(ctx, b.x, b.y, 0, -1, (showF && !sm) ? Math.max(g.rb + 14, Q.m * G * fs - g.rb + 30) : g.rb + (sm ? 8 : 14), 1, 0, vs * (sm ? 28 : 40), !sm);   /* 速度は垂直抗力の矢印の先（と記号 N）より上に */
  if (net) netArrow(ctx, b.x - g.rb, b.y, 1, 0, -Q.K * st.X * 50 / (Q.K * Q.Amax), s.def.O.netName || 'F', { ly: -12 });   /* 合力だけのときの縮尺：最大で 50 px */   /* 合力：左のばねとの接点から */
  if (showF) {
    /* 弾性力は必ず、そのばねと小球の接点から（2026-10-16 千葉さん）。両側ばねの 2 つの弾性力は同じ向きになるので、
       左のばねの力は接点を少し上に、右のばねの力は少し下にずらして重ならないようにする（記号も上・下に分ける） */
    springs.forEach(function (sp, i) {
      var F = -sp.k * st.X, L = F * fs, two = springs.length > 1, dy = two ? (sp.side < 0 ? -1 : 1) * (sm ? 2.5 : 6) : 0;
      var cx = b.x + sp.side * g.rb * Math.sqrt(1 - Math.pow(dy / g.rb, 2));   /* 球の表面の点 */
      fArrow(ctx, cx, b.y + dy, 1, 0, L, COL.hand, sm ? null : sp.name, { ly: dy > 0 ? 13 : -12, noShift: true });
    });
    var dx = sm ? 2.5 : 6;                                           /* 重力と垂直抗力は同じ線上に来るので左右にずらす */
    fArrow(ctx, b.x - dx, b.y, 0, 1, Q.m * G * fs, COL.force, sm ? null : 'mg', { lx: -8 });
    fArrow(ctx, b.x + dx, g.yF, 0, -1, Q.m * G * fs, COL.norm, sm ? null : 'N', { lx: 10 });
  }
  if (!snap) m2Axis(ctx, { x: g.xO, y: g.yF + 26 }, [1, 0], -(g.xO - g.xW) + 14, Math.min(W - 30, xR) - g.xO, '', { oDy: 15, oDx: 0, xDy: -12 });
}

/* =====================================================================
   ②-2 両側ばね
   ===================================================================== */
DEFS.m2s2 = m2Def({
  id: 'm2s2', num: 2, title: '水平ばね振り子（両側ばね）', short: '両側ばね', circ: 'below', rate: 0.2, netName: '−(k₁+k₂)x',
  desc: 'ばね定数 $k_1$・$k_2$ の 2 本のばねを小球の両側につなぐ。2 本とも自然の長さのとき、小球は $x = 0$ にある。<span class="todo">$k_1$・$k_2$ を変えて、周期がどう変わるか確かめよう。</span>',
  vars: [
    { k: 'k1', label: 'ばね定数 $k_1$', stops: M2.s2.k, stopLabels: ['10', '20', '40 N/m'], def: 20, aria: 'ばね定数 k1', fmt: function (x) { return x + ' N/m'; } },
    { k: 'k2', label: 'ばね定数 $k_2$', stops: M2.s2.k, stopLabels: ['10', '20', '40 N/m'], def: 20, aria: 'ばね定数 k2', fmt: function (x) { return x + ' N/m'; } },
    { k: 'A', label: '振幅 $A$', min: 0.04, max: M2.s2.Amax, step: 0.01, def: M2.s2.A, aria: '振幅', fmt: function (x) { return fmt(x, 2) + ' m'; } }, m2Phi(Math.PI / 2)],
  varCols: [['k1', 'k2'], ['A', 'phi']],
  Q: function (s) { var m = M2.s2.m, K = s.v.k1 + s.v.k2, w = Math.sqrt(K / m); return { m: m, K: K, w: w, T: TAU / w, A: s.v.A, phi: s.v.phi, Amax: M2.s2.Amax, Amin: 0.02 }; },
  setAmp: m2SetAmp,
  height: function (w) { return Math.round(clamp(w * 0.24, w < 480 ? 180 : 140, 180)); },   /* せまい画面では、上に吹き出しの場所をとる */
  geo: function (s, box, small) { var g = hGeo(s, { x0: box.x0, y0: box.y0, w: box.w, h: box.h }, M2.s2.Amax, small); g.xO = box.x0 + box.w * 0.5; g.xW = Math.max(box.x0 + (small ? 6 : 10), g.xO - M2.s2.Amax * g.S - (small ? 34 : 0.27 * box.w)); var xO = g.xO, S = g.S, rb = g.rb, yF = g.yF; g.pos = function (X) { return { x: xO + X * S, y: yF - rb }; }; return g; },
  scene: function (s, ctx, g, st, opt) {
    hScene(s, ctx, g, st, opt, [{ k: s.v.k1, side: -1, name: '−k₁x' }, { k: s.v.k2, side: 1, name: '−k₂x' }]);
    if (!opt.snap) { var b = g.pos(st.X), yl = g.yF + 15; label(ctx, 'ばね定数 k₁', (g.xW + g.xO) / 2 - 20, yl, { size: 11, color: COL.ink2 }); label(ctx, 'ばね定数 k₂', (g.xO + g.xO + (g.xO - g.xW)) / 2 + 20, yl, { size: 11, color: COL.ink2 }); }   /* 床の下（x 軸の上）に。上は手と吹き出しを置く（2026-10-19 千葉さん） */
  },
  snapAsp: 0.62, topRef: 64,                                     /* 上に「つりあいの位置」の参考の図（2026-10-25 千葉さん） */
  snaps: function (s) { var A = M2.s2.Amax * 0.8; return [{ cap: 'ⓐ つりあいの位置', X: 0 }, { cap: 'ⓑ 手をはなす', X: A, hand: true }, { cap: 'ⓒ $x>0$ のとき', X: A * 0.5, v: -1, eq: '$F = -k_1x - k_2x < 0$' }, { cap: 'ⓓ $x<0$ のとき', X: -A * 0.5, v: -1, eq: '$F = -k_1x - k_2x > 0$' }]; },
  card: function (s) {
    var Q = DEFS.m2s2.O.Q(s);
    return m2Card({ ttl: '両側ばね', f: '<p>変位 $x$ のとき、左のばねは $x$ 伸びて $-k_1x$、右のばねは $x$ 縮んで $-k_2x$。どちらも <b>同じ向き（O の向き）</b>に小球を押し引きする。</p>',
      eq: eqL('eom', '$ma = -k_1x - k_2x = -(k_1 + k_2)x$') + '<p>$K = k_1 + k_2$、$x_0 = 0$。</p>',
      read: m2Read('-\\dfrac{k_1 + k_2}{m}x', '\\sqrt{\\dfrac{k_1 + k_2}{m}}', '2\\pi\\sqrt{\\dfrac{m}{k_1 + k_2}}', '振動の中心は $x_0 = 0$。') + '<p class="qnow"><span class="qtag now">いまの値</span>$k_1 + k_2 = ' + Q.K + '$ N/m、$T = ' + sig2(Q.T) + '$ s</p>' });
  }
});

/* =====================================================================
   ②-3 鉛直ばね振り子（下向きが正。x = 0 はつりあいの位置／自然長の位置を切りかえ）
   ===================================================================== */
function m2s3Q(s) { var m = M2.s3.m, K = M2.s3.k, w = Math.sqrt(K / m), d = m * G / K; return { m: m, K: K, w: w, T: TAU / w, A: s.v.A, phi: s.v.phi, Amax: M2.s3.Amax, Amin: 0.03, d: d, off: s.org ? d : 0 }; }
function vGeo(s, box, small) {
  var Q = m2s3Q(s), Ltot = M2.s3.L0 + Q.d + Q.Amax + 0.08, top = box.y0 + (small ? 8 : 18);
  var ex = (!small && !s.circOn) ? 64 : 0;                        /* 下に、左の図の名前と吹き出しの場所をとる（2026-10-25） */
  var S = (box.h - (small ? 18 : 40) - ex) / Ltot, xs = box.x0 + box.w * (small ? 0.42 : 0.42), rb = small ? 7 : 13;
  var yN = top + M2.s3.L0 * S, yE = yN + Q.d * S;
  return { S: S, top: top, xs: xs, rb: rb, yN: yN, yE: yE, u: [0, 1], nCirc: [1, 0], circOff: box.w * 0.62, pos: function (X) { return { x: xs, y: yE + X * S }; } };
}
DEFS.m2s3 = m2Def({
  id: 'm2s3', num: 3, title: '鉛直ばね振り子', circ: 'right',
  desc: '天井からつるしたばねに小球をつけ、上下に振動させる。鉛直下向きを $x$ の正の向きにとる。<span class="todo">「x = 0 の位置」を切りかえても、運動そのものは変わらない（グラフが上下にずれるだけ）ことを確かめよう。</span>',
  buttons: orgButtons(),
  vars: [{ k: 'A', label: '振幅 $A$', min: 0.04, max: M2.s3.Amax, step: 0.01, def: M2.s3.A, aria: '振幅', fmt: function (x) { return fmt(x, 2) + ' m'; } }, m2Phi(Math.PI / 2)],
  varCols: [['A'], ['phi']],
  init: function (s) { s.org = 0; },
  onDefaults: function (s) { s.org = 0; syncOrg(s); },
  sync: function (s) { syncOrg(s); },
  Q: m2s3Q, setAmp: m2SetAmp,
  energy: function (s, r) { var Q = m2s3Q(s); return { K: 0.5 * Q.m * r.v * r.v, U: 0.5 * Q.K * r.X * r.X }; },
  height: function (w) { return Math.round(clamp(w * 0.47, 216, 312)) + 64; },     /* 前の 60 %（2026-10-16 千葉さん）＋下の名前と吹き出しの場所 */
  geo: function (s, box, small) { return vGeo(s, box, small); },
  scene: function (s, ctx, g, st, opt) { vScene(s, ctx, g, st, opt, m2s3Q(s)); },
  snapAsp: 2.1,
  snaps: function (s) {
    var Q = m2s3Q(s), A = Q.Amax;
    return [{ cap: 'ⓐ つりあいの位置', X: 0, eq: '力のつりあいの式 $-kd + mg = 0$' }, { cap: 'ⓑ 手をはなす', X: A, hand: true },
      { cap: 'ⓒ $x>0$', X: A * 0.55, v: -1, eq: '$F = -k(x+d) + mg = -kx$' }, { cap: 'ⓓ $-d<x<0$', X: -Q.d * 0.5, v: -1, eq: '$F = -k(d-|x|) + mg = -kx$' },
      { cap: 'ⓔ $x<-d$', X: -Q.d * 1.35, v: -1, eq: '$F = k(|x|-d) + mg = -kx$' }];
  },
  card: function (s) {
    var Q = m2s3Q(s), nat = !!s.org;
    var eq = nat ? eqL('eom', '$ma = -kx + mg = -k\\left(x - \\dfrac{mg}{k}\\right) = -k(x - d)$') + '<p>$K = k$、$x_0 = d$（$kd = mg$）。$X = x - d$ とおくと $ma = -kX$。</p>'
      : '<p class="eqline">' + eqTag('bal') + '$-kd + mg = 0$（つりあいの位置）</p>' + eqL('eom', '$ma = -k(x + d) + mg = -kx$') + '<p>$K = k$、$x_0 = 0$。</p>';
    return m2Card({ ttl: '鉛直ばね振り子（' + (nat ? '自然長の位置を $x = 0$' : 'つりあいの位置を $x = 0$') + '）',
      f: '<p>重力 $mg$（下向き）と、ばねの弾性力（' + (nat ? '伸び $x$ なので $kx$、上向き' : '伸び $x + d$ なので $k(x + d)$、上向き') + '）。</p>',
      eq: eq,
      read: (nat ? m2Read('-\\dfrac{k}{m}(x - d)', '\\sqrt{\\dfrac{k}{m}}', '2\\pi\\sqrt{\\dfrac{m}{k}}', '$X = x - d$ とおくと $a = -\\dfrac{k}{m}X$ の形。振動の中心は $x_0 = d = \\dfrac{mg}{k}$（つりあいの位置）。周期は水平ばね振り子と同じ。', true) : m2Read('-\\dfrac{k}{m}x', '\\sqrt{\\dfrac{k}{m}}', '2\\pi\\sqrt{\\dfrac{m}{k}}', '振動の中心は $x_0 = 0$（つりあいの位置）。周期は水平ばね振り子と同じ。')) +
        '<p class="qnow"><span class="qtag now">いまの値</span>$d = \\dfrac{mg}{k} = ' + fmt(Q.d, 2) + '$ m、$T = ' + sig2(Q.T) + '$ s</p>',
      note: '<p class="rednote">振幅 $A$ は「つりあいの位置」〜「初期位置」。単振動は必ず、つりあいの位置を中心として振動する。</p>' });
  }
});
/* 鉛直の図（②-3）：天井・ばね・小球・自然長とつりあいの位置の線・d の寸法・x 軸（下向き） */
function vScene(s, ctx, g, st, opt, Q) {
  var snap = opt.snap, big = opt.big, sm = snap && !big, b = g.pos(st.X), showF = snap || fAll(s), net = !snap && fNet(s), fs = (sm ? 14 : 30) / (Q.m * G);
  ceilingAt(ctx, g.xs - (sm ? 16 : 34), g.xs + (sm ? 16 : 34), g.top);
  if (!snap && !s.circOn && s.W >= 480) {                         /* 左に「自然長のときのばね」と「つりあっている状態のばね」（対応する円運動を出すとき・せまい画面では消す。2026-10-16 千葉さん） */
    refArea(ctx, 0, 0, (g.xs * 0.52 + 26 + g.xs - 60) / 2, s.H, 'r');   /* 参考の図のエリア（背景と境の実線） */
    [[g.xs * 0.22, g.yN, false, '自然長の位置'], [g.xs * 0.52, g.yE, true, 'つりあいの位置']].forEach(function (r) {   /* 名前は「〜の位置」で、3 行ほど下に（2026-10-25 千葉さん） */
      ceilingAt(ctx, r[0] - 18, r[0] + 18, g.top);
      springDense(ctx, r[0], g.top, r[0], r[1] - (r[2] ? g.rb : 0), g.yE - g.top - g.rb, { r: 8, lead: 8, k: Q.K, Lmin: g.yE - g.top - g.rb - Q.Amax * g.S });   /* 右のばねと同じ巻き数（同じばね） */
      if (r[2]) ballShape(ctx, r[0], r[1], g.rb, M2BALL);
      if (r[2] && fAll(s)) {                                     /* 「全ての力を個別表示」：つりあいの図にも弾性力 kd（ばねとの接点から）と重力 mg（左右にずらす） */
        fArrow(ctx, r[0] - 5, r[1] - g.rb, 0, -1, Q.K * Q.d * fs, COL.hand, 'kd', { lx: -16, noShift: true });
        fArrow(ctx, r[0] + 5, r[1], 0, 1, Q.m * G * fs, COL.force, 'mg', { lx: 14, noShift: true });
      }
      label(ctx, r[3], r[0], r[1] + (r[2] ? g.rb + 13 : 12) + 40, { size: 10.5, color: r[2] ? '#c0392b' : '#5d6875', bold: r[2] });
    });
  }
  var dl = sm ? g.xs - 22 : (snap || s.circOn ? g.xs - 60 : g.xs * 0.1);   /* 左のばねの絵とつながるように */
  dotted(ctx, dl, g.yN, g.xs + (sm ? 22 : 130), g.yN, 'rgba(20,23,28,.35)', [5, 4]);
  dotted(ctx, dl, g.yE, g.xs + (sm ? 22 : 130), g.yE, 'rgba(20,23,28,.45)', [5, 4]);
  if (!sm) {
    label(ctx, '自然長', g.xs + (snap ? 30 : 134), g.yN, { size: 10.5, color: '#5d6875', align: 'left' });
    eqLabel(ctx, g.xs + (snap ? 30 : 134), g.yE, 'left');
    dimLine(ctx, g.xs - 48, g.yN, g.xs - 48, g.yE); sym(ctx, 'd', g.xs - 60, (g.yN + g.yE) / 2, { size: 14 });
  }
  springDense(ctx, g.xs, g.top, g.xs, b.y - g.rb, g.yE - g.top - g.rb, { r: sm ? 4 : 8, lead: sm ? 3 : 8, k: Q.K, thin: sm ? 0.6 : 1, Lmin: g.yE - g.top - g.rb - Q.Amax * g.S });
  /* 手は下から支える（上から持つとばねと重なる。2026-10-16 千葉さん） */
  if (!snap && s.t < 0.5) startHand(s, ctx, b.x, b.y, g.rb, 'up', -Math.cos(Q.phi), s.circOn ? (st.X < 0 ? { flip: true, bubPos: 'd' } : { flip: true, bubPos: 'l', bubDy: 14 }) : { flip: true, bubPos: 'd' });   /* 吹き出しは手の下（下に場所をとってある）。円運動を出すときは左か下 */
  if (opt.frame && opt.frame.hand) dropHandAt(ctx, b.x, b.y, (big ? 0.42 : 0.2) * g.rb / 13, 0, 1, true);
  ballShape(ctx, b.x, b.y, g.rb, M2BALL);
  var vref = Q.A * Q.w || 1, vs = snap ? (opt.frame.v || 0) * 0.7 : (s.hideVec ? 0 : 1) * st.v / vref;
  if (Math.abs(vs) > 0.03) vArrowAt(ctx, b.x, b.y, 1, 0, g.rb + (sm ? 10 : 22), 0, 1, vs * (sm ? 28 : 40), !sm);
  if (net) netArrow(ctx, b.x, b.y - g.rb, 0, 1, -Q.K * st.X * 46 / (Q.K * Q.Amax), 'F', { lx: -16, al: 'right' });   /* 合力だけのときの縮尺：最大で 46 px */   /* 合力：ばねとの接点から（下向きが正） */
  if (showF) {
    var Fs = Q.K * (st.X + Q.d), dx3 = sm ? 2.5 : 5;           /* 弾性力の大きさ（上向きを正）。縮んでいれば負＝下向き。重力と同じ線上なので左右にずらす */
    fArrow(ctx, b.x - dx3, b.y - g.rb, 0, -1, Fs * fs, COL.hand, sm ? null : (s.org ? 'kx' : 'k(x+d)'), { lx: -30, noShift: true });
    fArrow(ctx, b.x + dx3, b.y, 0, 1, Q.m * G * fs, COL.force, sm ? null : 'mg', { lx: 12, noShift: true });
  }
  if (!snap) {
    var p0 = { x: g.xs + 104, y: s.org ? g.yN : g.yE };
    m2Axis(ctx, p0, [0, 1], -(p0.y - g.top) + 8, (g.yE - p0.y) + Q.Amax * g.S + 24, '（下向きが正）', { oDx: -12, oDy: 0, xDx: 10, lDx: 18, lDy: 0, lAl: 'left' });
  }
}

/* =====================================================================
   ②-4 斜め台の上のばね振り子（斜面にそって下向きが正）
   ===================================================================== */
function m2s4Q(s) { var m = M2.s4.m, K = M2.s4.k, w = Math.sqrt(K / m), th = s.v.th * Math.PI / 180, d = m * G * Math.sin(th) / K; return { m: m, K: K, w: w, T: TAU / w, A: s.v.A, phi: s.v.phi, Amax: M2.s4.Amax, Amin: 0.03, d: d, th: th, off: s.org ? d : 0 }; }
function sGeo(s, box, small) {
  var Q = m2s4Q(s), th = Q.th, c = Math.cos(th), sn = Math.sin(th), Ls = M2.s4.L0 + 0.42 + Q.Amax + 0.16;
  var rb = small ? 7 : 12, tp = small ? 10 + 30 * c : 16 + (rb + 50) * c;   /* 上：かべ（小さい図）・x 軸（斜面から rb + 50）がはみ出さないだけあける */
  var S = Math.min((box.w - (small ? 16 : 120)) / (Ls * c + 0.1), (box.h - tp - (small ? 8 : 24)) / (Ls * sn));
  var x0 = box.x0 + (small ? 10 : Math.max(40, (box.w - Ls * c * S) * 0.35)), y0 = box.y0 + tp, u = [c, sn], n = [sn, -c];   /* 図が小さいときは少し中央へ */
  var sN = M2.s4.L0 * S, sE = sN + Q.d * S;
  var P = function (sl, h) { return { x: x0 + u[0] * sl + n[0] * h, y: y0 + u[1] * sl + n[1] * h }; };
  return { S: S, x0: x0, y0: y0, u: u, n: n, rb: rb, sN: sN, sE: sE, Ls: Ls * S, P: P, nCirc: n, circOff: Math.min(box.w * 0.36, 160) + rb, pos: function (X) { return P(sE + X * S, rb); } };
}
DEFS.m2s4 = m2Def({
  id: 'm2s4', num: 4, title: '斜め台の上のばね振り子', short: '斜面のばね振り子', circ: 'normal',
  circExtra: function (w, h, s) {             /* 円がはみ出さないだけ上をあける：中心の高さ＝つりあいの位置から斜面に垂直に off、さらに半径 */
    var g = sGeo(s, { x0: 0, y0: 0, w: w, h: h }), Q = m2s4Q(s), off = m2NormOff(Q, g), b = g.pos(0);
    return Math.max(0, Math.round(off * Math.cos(Q.th) + Q.Amax * g.S + 34 - b.y));
  },
  desc: 'なめらかな斜面の上端にばねをつけ、斜面にそって小球を振動させる。斜面にそって下向きを $x$ の正の向きにとる。<span class="todo">傾きの角 $\\theta$ を変えると、つりあいの位置だけがずれて、周期は変わらないことを、時間バーの右の「周期 $T$」で確かめよう。</span>',
  buttons: orgButtons().concat([{ k: 'dec', label: '重力を斜面に平行・<br>垂直に分解する', cls: 'chkb two', onClick: function (s, b) { s.dec = !s.dec; b.classList.toggle('on', s.dec); b.setAttribute('aria-pressed', s.dec ? 'true' : 'false'); if (s.dec && !fAll(s)) { s.fmode = 'all'; s.syncFBtns(); } s.draw(); } }]),
  vars: [{ k: 'th', label: '傾きの角 $\\theta$', stops: M2.s4.th, stopLabels: ['15', '30', '45', '60°'], def: 30, aria: '傾きの角', fmt: function (x) { return x + '°'; } },
    { k: 'A', label: '振幅 $A$', min: 0.04, max: M2.s4.Amax, step: 0.01, def: M2.s4.A, aria: '振幅', fmt: function (x) { return fmt(x, 2) + ' m'; } }, m2Phi(Math.PI / 2)],
  varCols: [['th', 'A'], ['phi']],
  init: function (s) { s.org = 0; s.dec = false; },
  onDefaults: function (s) { s.org = 0; s.dec = false; syncOrg(s); if (s.extra.dec) s.extra.dec.classList.remove('on'); },
  sync: function (s) { syncOrg(s); if (s.extra.dec) s.extra.dec.innerHTML = '重力を斜面に平行・<br>垂直に分解する'; },
  Q: m2s4Q, setAmp: m2SetAmp,
  height: function (w, s) {                   /* 傾きが小さいときは図が低くなるので、下の余白を残さない */
    var hm = Math.round(clamp(w * 0.37, 180, 264)); if (!s) return hm;   /* 前の 60 % */
    var g = sGeo(s, { x0: 0, y0: 0, w: w, h: hm }), need = g.y0 + g.Ls * g.u[1] + 34;
    return Math.round(clamp(need, 200, hm));
  },
  geo: function (s, box, small) { return sGeo(s, box, small); },
  scene: function (s, ctx, g, st, opt) { sScene(s, ctx, g, st, opt); },
  snapAsp: 1.0,
  snaps: function (s) { var Q = m2s4Q(s), A = Q.Amax; return [{ cap: 'ⓐ つりあいの位置', X: 0, eq: '$-kd + mg\\sin\\theta = 0$' }, { cap: 'ⓑ 手をはなす', X: A, hand: true }, { cap: 'ⓒ $x>0$', X: A * 0.5, v: -1, eq: '$F = -k(x+d) + mg\\sin\\theta = -kx$' }, { cap: 'ⓓ $x<0$', X: -A * 0.6, v: -1, eq: '$F = -kx > 0$' }]; },
  card: function (s) {
    var Q = m2s4Q(s), nat = !!s.org;
    var eq = nat ? eqL('eom', '$ma = -kx + mg\\sin\\theta = -k\\left(x - \\dfrac{mg\\sin\\theta}{k}\\right)$') + '<p>$K = k$、$x_0 = d = \\dfrac{mg\\sin\\theta}{k}$。</p>'
      : '<p class="eqline">' + eqTag('bal') + '$-kd + mg\\sin\\theta = 0$</p>' + eqL('eom', '$ma = -k(x + d) + mg\\sin\\theta = -kx$') + '<p>$K = k$、$x_0 = 0$。</p>';
    return m2Card({ ttl: '斜面のばね振り子（' + (nat ? '自然長の位置を $x = 0$' : 'つりあいの位置を $x = 0$') + '）',
      f: '<p>斜面方向には、重力の斜面方向の成分 $mg\\sin\\theta$（下向き）と、ばねの弾性力（上向き）。垂直抗力 $N$ と $mg\\cos\\theta$ は斜面に垂直な方向でつりあう。</p>',
      eq: eq,
      read: (s.org ? m2Read('-\\dfrac{k}{m}(x - d)', '\\sqrt{\\dfrac{k}{m}}', '2\\pi\\sqrt{\\dfrac{m}{k}}', '振動の中心は $x_0 = d$（つりあいの位置）。周期は $\\theta$ によらない。', true) : m2Read('-\\dfrac{k}{m}x', '\\sqrt{\\dfrac{k}{m}}', '2\\pi\\sqrt{\\dfrac{m}{k}}', '振動の中心はつりあいの位置。周期は $\\theta$ によらない。')) + '<p class="qnow"><span class="qtag now">いまの値</span>$\\theta = ' + s.v.th + '^\\circ$：$d = ' + fmt(Q.d, 3) + '$ m、$T = ' + sig2(Q.T) + '$ s</p>',
      note: '<p class="rednote">$\\theta$ を変えても、変わるのはつりあいの位置だけ。単振動は必ず、つりあいの位置を中心として振動する。</p>' });
  }
});
function sScene(s, ctx, g, st, opt) {
  var Q = m2s4Q(s), snap = opt.snap, big = opt.big, sm = snap && !big, b = g.pos(st.X), showF = snap || fAll(s), net = !snap && fNet(s), fs = (sm ? 14 : 32) / (Q.m * G);
  var A0 = g.P(0, 0), A1 = g.P(g.Ls, 0);
  /* 斜面（三角の台）と上端のかべ */
  ctx.save(); ctx.fillStyle = '#f1ede6'; ctx.beginPath(); ctx.moveTo(A0.x, A0.y); ctx.lineTo(A1.x, A1.y); ctx.lineTo(A0.x, A1.y); ctx.closePath(); ctx.fill(); ctx.restore();
  hatchSeg(ctx, A0.x, A1.y, A1.x, A1.y, 1, sm ? 5 : 8);
  ctx.save(); ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(A0.x, A0.y); ctx.lineTo(A1.x, A1.y); ctx.moveTo(A0.x, A0.y); ctx.lineTo(A0.x, A1.y); ctx.stroke(); ctx.restore();
  var W0 = g.P(0, sm ? 26 : 50); hatchSeg(ctx, W0.x, W0.y, A0.x, A0.y, 1, sm ? 5 : 8);
  if (!sm) { var r = 34; ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(A1.x, A1.y, r, Math.PI, Math.PI + Q.th); ctx.stroke(); ctx.restore(); sym(ctx, 'θ', A1.x - r - 10, A1.y - 8, { size: 14 }); }
  var pN = g.P(g.sN, g.rb), pE = g.P(g.sE, g.rb);
  [pN, pE].forEach(function (p, i) { var a = { x: p.x - g.n[0] * (sm ? 18 : 40), y: p.y - g.n[1] * (sm ? 18 : 40) }, c = { x: p.x + g.n[0] * (sm ? 16 : 34), y: p.y + g.n[1] * (sm ? 16 : 34) }; dotted(ctx, a.x, a.y, c.x, c.y, 'rgba(20,23,28,.4)', [4, 3]); if (!sm) { if (i) eqLabel(ctx, a.x - 4, a.y + 14, 'right'); else label(ctx, '自然長', a.x - 4, a.y - 2, { size: 10.5, color: '#5d6875', align: 'right' }); } });   /* 名前は台の中（上の x 軸・O と重ならない） */
  var st0 = g.P(0, g.rb);
  springDense(ctx, st0.x, st0.y, b.x - g.u[0] * g.rb, b.y - g.u[1] * g.rb, g.sE - g.rb, { r: sm ? 4 : 7, lead: sm ? 3 : 8, k: Q.K, thin: sm ? 0.6 : 1, Lmin: g.sE - g.rb - Q.Amax * g.S });
  /* 手は下から支える（上下逆。2026-10-16 千葉さん） */
  if (!snap && s.t < 0.5) startHand(s, ctx, b.x, b.y, g.rb, 'right', Math.cos(Q.phi), { flip: true, bubDy: st.X < 0 ? 38 : 0 });   /* x < 0 では x 軸の矢印をよけて下へ */
  if (opt.frame && opt.frame.hand) dropHandAt(ctx, b.x, b.y, (big ? 0.42 : 0.2) * g.rb / 13, 0, 1, true);
  ballShape(ctx, b.x, b.y, g.rb, M2BALL);
  var vref = Q.A * Q.w || 1, vs = snap ? (opt.frame.v || 0) * 0.7 : (s.hideVec ? 0 : 1) * st.v / vref;
  var vOff = (showF && !sm) ? Math.max(g.rb + 22, Q.m * G * Math.cos(Q.th) * fs - g.rb + 34) : g.rb + (sm ? 10 : 22);   /* 速度は垂直抗力の矢印の先（と記号 N）よりさらに外がわ */
  if (Math.abs(vs) > 0.03) vArrowAt(ctx, b.x, b.y, g.n[0], g.n[1], vOff, g.u[0], g.u[1], vs * (sm ? 28 : 40), !sm);
  if (net) netArrow(ctx, b.x - g.u[0] * g.rb, b.y - g.u[1] * g.rb, g.u[0], g.u[1], -Q.K * st.X * 46 / (Q.K * Q.Amax), 'F', { ly: -10 });   /* 合力：ばねとの接点から、斜面にそって */
  if (showF) {
    var Fs = Q.K * (st.X + Q.d), cp = { x: b.x - g.u[0] * g.rb, y: b.y - g.u[1] * g.rb }, gnd = { x: b.x - g.n[0] * g.rb, y: b.y - g.n[1] * g.rb };
    fArrow(ctx, cp.x, cp.y, -g.u[0], -g.u[1], Fs * fs, COL.hand, sm ? null : (s.org ? 'kx' : 'k(x+d)'));
    fArrow(ctx, gnd.x, gnd.y, g.n[0], g.n[1], Q.m * G * Math.cos(Q.th) * fs, COL.norm, sm ? null : 'N');
    fArrow(ctx, b.x, b.y, 0, 1, Q.m * G * fs, COL.force, sm ? null : 'mg');
    if (s.dec && !snap) {
      arrow(ctx, b.x, b.y, b.x + g.u[0] * Q.m * G * Math.sin(Q.th) * fs, b.y + g.u[1] * Q.m * G * Math.sin(Q.th) * fs, 'comp', COL.force);
      arrow(ctx, b.x, b.y, b.x - g.n[0] * Q.m * G * Math.cos(Q.th) * fs, b.y - g.n[1] * Q.m * G * Math.cos(Q.th) * fs, 'comp', COL.force);
      var e1 = { x: b.x + g.u[0] * (Q.m * G * Math.sin(Q.th) * fs + 16), y: b.y + g.u[1] * (Q.m * G * Math.sin(Q.th) * fs + 16) };
      label(ctx, 'mg sinθ', e1.x + 6, e1.y - 6, { size: 11.5, color: COL.force, align: 'left' });
      var e2 = { x: b.x - g.n[0] * (Q.m * G * Math.cos(Q.th) * fs + 14), y: b.y - g.n[1] * (Q.m * G * Math.cos(Q.th) * fs + 14) };
      label(ctx, 'mg cosθ', e2.x - 4, e2.y + 8, { size: 11.5, color: COL.force, align: 'right' });
    }
  }
  if (!snap) {
    var o0 = s.org ? g.sN : g.sE, p0 = g.P(o0, g.rb + 50);
    m2Axis(ctx, p0, g.u, -o0 + 10, (g.sE - o0) + Q.Amax * g.S + 30, '', { oDx: g.n[0] * 12, oDy: g.n[1] * 12 });
  }
}

/* =====================================================================
   ②-5 水平で摩擦がある場合（x = 0 は自然長の位置に固定）
   ===================================================================== */
function m2s5F(s) { return frictionSegs(M2.s5.m, M2.s5.k, s.v.mu, s.v.mu2, s.v.X0); }
DEFS.m2s5 = m2Def({
  id: 'm2s5', num: 5, title: '水平で摩擦がある場合', short: '摩擦があるとき', circ: 'below', noDrag: true,
  desc: 'あらい水平面の上で、ばねを $X_0$ だけ伸ばしてから静かに放す（静止摩擦係数 $\\mu$、動摩擦係数 $\\mu\'$）。<span class="todo">振幅が半周期ごとに同じ長さだけ減り、やがて止まることを確かめよう。</span>',
  vars: [{ k: 'mu2', label: '動摩擦係数 $\\mu\'$', stops: M2.s5.mu2, stopLabels: ['0.05', '0.10', '0.15'], def: 0.10, aria: '動摩擦係数', fmt: function (x) { return x.toFixed(2); } },
    { k: 'mu', label: '静止摩擦係数 $\\mu$', stops: M2.s5.mu, stopLabels: ['0.20', '0.30'], def: 0.20, aria: '静止摩擦係数', fmt: function (x) { return x.toFixed(2); } },
    { k: 'X0', label: 'はじめの伸び $X_0$', stops: M2.s5.X0, stopLabels: ['0.20', '0.30', '0.40 m'], def: 0.40, aria: 'はじめの伸び', fmt: function (x) { return x.toFixed(2) + ' m'; } }],
  varCols: [['mu2', 'mu'], ['X0']],
  Q: function (s) { var m = M2.s5.m, K = M2.s5.k, w = Math.sqrt(K / m); return { m: m, K: K, w: w, T: TAU / w, A: s.v.X0, phi: Math.PI / 2, Amax: 0.40, Amin: 0.05 }; },
  setAmp: function () { },
  state: function (s, t) { var r = frictionAt(m2s5F(s), t); return { X: r.x, v: r.v, a: r.a, seg: r.seg, moving: r.moving }; },
  tEnd: function (s) { var F = m2s5F(s); return F.tStop + 0.6 * TAU / F.w; },
  gWin: function (s) { var F = m2s5F(s); return F.tStop + 0.6 * TAU / F.w; },
  energy: function (s, r) { return { K: 0.5 * M2.s5.m * r.v * r.v, U: 0.5 * M2.s5.k * r.X * r.X }; },
  E0: function (s) { return 0.5 * M2.s5.k * s.v.X0 * s.v.X0; },
  circState: function (s, t) {
    var F = m2s5F(s), r = frictionAt(F, t); if (r.seg < 0) return { c: F.xStop, R: 0, th: 0 };
    var g = F.segs[r.seg], u = g.x0 - g.c, ph = F.w * (t - g.t0) + Math.PI / 2;
    return u >= 0 ? { c: g.c, R: u, th: ph } : { c: g.c, R: -u, th: ph + Math.PI };
  },
  onChanged: function (s, k) { if (k === 'mu' && s.v.mu <= s.v.mu2) s.v.mu = 0.30; if (k === 'mu2' && s.v.mu <= s.v.mu2) s.v.mu = 0.30; },
  height: function (w) { return Math.round(clamp(w * 0.30, w < 480 ? 226 : 212, 232)); },     /* x 軸の下の「±μ′mg/k」「つりあいの位置」が入る高さ（低いと下の字が上に寄せられて、緑の字を隠していた。2026-10-19） */
  geo: function (s, box, small) { var g = hGeo(s, box, 0.42, small); g.bw = small ? 24 : 36; g.bh = small ? 20 : 30;   /* 並べた図でも物体を大きめに（摩擦力が床との接点から出ているのが分かるように） */ var xO = g.xO, S = g.S, yF = g.yF, bh = g.bh; g.rb = g.bw / 2; g.pos = function (X) { return { x: xO + X * S, y: yF - bh / 2 }; }; return g; },
  scene: function (s, ctx, g, st, opt) { fScene(s, ctx, g, st, opt); },
  snapAsp: 0.62,
  snaps: function (s) { var F = m2s5F(s); var a = F.segs[0] ? F.segs[0].x0 : 0.4; return [{ cap: 'ⓐ 静かに放す', X: a, hand: true }, { cap: 'ⓑ 左へ動く', X: a * 0.4, v: -1, eq: '$ma = -kx + \\mu\'mg$' }, { cap: 'ⓒ 右へ動く', X: -a * 0.3, v: 1, eq: '$ma = -kx - \\mu\'mg$' }, { cap: 'ⓓ 止まる', X: F.xStop, eq: '$|kx| \\le \\mu mg$' }]; },
  msg: function (s) {
    var F = m2s5F(s), r = frictionAt(F, s.t);
    if (!r.moving && s.t > 0) return '<b>止まった！</b>　止まった位置 $x = ' + fmt(F.xStop, 3) + '$ m で、$|kx| = ' + fmt(Math.abs(M2.s5.k * F.xStop), 2) + '$ N $\\le \\mu mg = ' + fmt(s.v.mu * M2.s5.m * G, 2) + '$ N なので、静止摩擦力で止まったまま。';
    return '振幅は半周期ごとに $\\dfrac{2\\mu\'mg}{k} = ' + fmt(2 * F.xf, 3) + '$ m ずつ減る（x–t グラフの山の高さが、半周期ごとに同じだけ低くなる）。';
  },
  card: function (s) {
    var F = m2s5F(s);
    return m2Card({ ttl: '摩擦がある水平ばね振り子', f: '<p>水平方向の力は弾性力 $-kx$ と動摩擦力 $\\mu\'mg$（<b>動く向きと逆向き</b>）。</p>',
      eq: eqL('eom', '左へ動くとき $ma = -kx + \\mu\'mg = -k\\left(x - \\dfrac{\\mu\'mg}{k}\\right)$') + eqL('eom', '右へ動くとき $ma = -kx - \\mu\'mg = -k\\left(x + \\dfrac{\\mu\'mg}{k}\\right)$'),
      read: m2Read('-\\dfrac{k}{m}\\left(x \\mp \\dfrac{\\mu\'mg}{k}\\right)', '\\sqrt{\\dfrac{k}{m}}', '2\\pi\\sqrt{\\dfrac{m}{k}}', '（複号は上が左へ動くとき）。半周期 $\\pi\\sqrt{\\dfrac{m}{k}}$ ごとに、振動の中心が $x_0 = +\\dfrac{\\mu\'mg}{k}$ と $-\\dfrac{\\mu\'mg}{k}$ で入れかわる。周期の式は摩擦がないときと同じ。', true) +
        '<p class="qnow"><span class="qtag now">いまの値</span>$\\dfrac{\\mu\'mg}{k} = ' + fmt(F.xf, 3) + '$ m、半周期ごとに振幅が $' + fmt(2 * F.xf, 3) + '$ m ずつ減る。止まる位置 $x = ' + fmt(F.xStop, 3) + '$ m</p>',
      note: '<p class="qnote">止まった位置で $|kx| \\le \\mu mg$ なら、静止摩擦力で止まったまま。</p>' });
  }
});
function fScene(s, ctx, g, st, opt) {
  var snap = opt.snap, big = opt.big, sm = snap && !big, b = g.pos(st.X), W = s.W, Q = DEFS.m2s5.O.Q(s), showF = snap || fAll(s), net = !snap && fNet(s), fs = (sm ? 14 : 28) / (Q.m * G);
  var xR = snap ? g.xO + (g.xO - g.xW) * 0.9 : Math.min(W - 10, g.xO + (g.xO - g.xW) + 60);
  wallLeftAt(ctx, g.xW, g.yF - (sm ? 26 : 52), g.yF);
  ctx.save(); ctx.fillStyle = 'rgba(160,140,110,.18)'; ctx.fillRect(g.xW, g.yF, xR - g.xW, sm ? 4 : 7); ctx.restore();
  floorAt(ctx, g.xW, xR, g.yF);
  if (!snap) label(ctx, 'あらい水平面（μ, μ′）', g.xW + 4, g.yF + 60, { size: 10.5, color: '#8d9097', align: 'left' });   /* ばねの下（物体の矢印と重ならない） */
  springDense(ctx, g.xW, b.y, b.x - g.bw / 2, b.y, g.xO - g.bw / 2 - g.xW, { r: sm ? 4 : 7, lead: sm ? 3 : 8, k: Q.K, thin: sm ? 0.6 : 1 });
  dotted(ctx, g.xO, g.yF - (sm ? 30 : 50), g.xO, g.yF + (snap ? 0 : 30), 'rgba(20,23,28,.35)', [4, 3]);
  if (!snap) {
    /* 振動の中心 ±μ′mg/k は x 軸の下に（物体の周りの矢印・記号と重ならないように） */
    var F = m2s5F(s); [F.xf, -F.xf].forEach(function (c, i) { var X = g.xO + c * g.S; dotted(ctx, X, g.yF + 4, X, g.yF + 52, 'rgba(15,138,138,.6)', [2, 3]); label(ctx, i ? '−μ′mg/k' : '+μ′mg/k', X + (i ? -3 : 3), g.yF + 61, { size: 9.5, color: '#0f8a8a', align: i ? 'right' : 'left' }); });
    eqLabel(ctx, g.xO, g.yF + 75, 'center', 'つりあいの位置（動く向きで ±μ′mg/k が入れかわる）');
  }
  if (opt.frame && opt.frame.hand) dropHand(ctx, b.x, b.y, (big ? 0.42 : 0.2), 0, 1);
  if (!snap && s.t < 0.5) startHand(s, ctx, b.x, b.y, g.bh / 2, 'right', 0, { bubDy: s.W < 480 ? -24 : 0 });
  ctx.save(); ctx.fillStyle = '#e4d3b4'; ctx.strokeStyle = '#6b5532'; ctx.lineWidth = 1.3; ctx.fillRect(b.x - g.bw / 2, b.y - g.bh / 2, g.bw, g.bh); ctx.strokeRect(b.x - g.bw / 2, b.y - g.bh / 2, g.bw, g.bh); ctx.restore();
  var vs = snap ? (opt.frame.v || 0) * 0.7 : (s.hideVec ? 0 : 1) * st.v / (Q.A * Q.w);
  if (Math.abs(vs) > 0.02) vArrowAt(ctx, b.x, b.y, 0, -1, (showF && !sm) ? Q.m * G * fs - g.bh / 2 + 30 : g.bh / 2 + (sm ? 8 : 14), 1, 0, vs * (sm ? 28 : 40), !sm);
  if (net) {                                                        /* 合力（弾性力＋摩擦力）：ばねとの接点から */
    var vn = st.v, frN = Math.abs(vn) > 1e-9 ? -Math.sign(vn) * s.v.mu2 * Q.m * G : (s.t > 0 ? Q.K * st.X : 0);
    netArrow(ctx, b.x - g.bw / 2, b.y, 1, 0, (-Q.K * st.X + frN) * 70 / (Q.K * 0.42), 'F', { ly: -12 });
  }
  if (showF) {
    var fh = (sm ? 30 : 70) / (Q.K * 0.42);
    if (snap) { var F5 = m2s5F(s), a5 = F5.segs[0] ? F5.segs[0].x0 : 0.4; fh = Math.min(26 / (s.v.mu2 * Q.m * G), 110 / (Q.K * a5)); fs *= 0.6; }   /* 並べた図：摩擦力が 22 px ほどに見える縮尺（弾性力も同じ縮尺。2026-10-19） */                          /* 横向きの力（弾性力・摩擦力）は合力と同じ縮尺。重力と垂直抗力は縮めて描く（2026-10-18：摩擦力が 3 px しかなく見えなかった） */
    var vv = snap ? (opt.frame.v || 0) : st.v, moving = Math.abs(vv) > 1e-9, fr = 0;
    if (moving) fr = -Math.sign(vv) * s.v.mu2 * Q.m * G;           /* 動摩擦力：動く向きと逆向き */
    else if (snap ? !opt.frame.hand : s.t > 0) fr = Q.K * st.X;     /* 止まっているとき：静止摩擦力が弾性力とつり合う（放す前は手が支える） */
    var dx = sm ? 2.5 : 6;                                           /* 重力と垂直抗力は同じ線上に来るので左右にずらす */
    fArrow(ctx, b.x - dx, b.y, 0, 1, Q.m * G * fs, COL.force, sm ? null : 'mg', { lx: -8 });
    fArrow(ctx, b.x + dx, g.yF, 0, -1, Q.m * G * fs, COL.norm, sm ? null : 'N', { lx: 10 });
    /* 弾性力と摩擦力は、重力・垂直抗力のあとに描いて前に出す（かくれないように。2026-10-19 千葉さん）。摩擦力は床と物体の接点（底面）から */
    fArrow(ctx, b.x - g.bw / 2, b.y, 1, 0, -Q.K * st.X * fh, COL.hand, sm ? null : '−kx', { ly: -12 });
    fArrow(ctx, b.x + (fr < 0 ? -1 : 1) * g.bw * 0.25, g.yF, 1, 0, fr * fh, COL.fric, sm ? null : (moving ? 'μ′mg' : 'f'), { ly: snap ? 20 : 14, lx: (fr < 0 ? -1 : 1) * (snap ? 18 : 8) });   /* 並べた図では mg の記号と重ねない */
    if (!snap) label(ctx, '※ mg と N は縮めて描いている', W - 12, g.yF - 64, { size: 10, color: '#8d9097', align: 'right' });
  }
  if (!snap) {
    var Fz = m2s5F(s), r = frictionAt(Fz, s.t);
    if (!r.moving && s.t > 0) bubble(ctx, '止まった！', b.x, b.y - g.bh / 2 - 8, { size: 13, bg: '#dff2ee', border: '#0f8a8a', color: '#0a5c5c' });
    m2Axis(ctx, { x: g.xO, y: g.yF + 30 }, [1, 0], -(g.xO - g.xW) + 14, Math.min(W - 30, xR) - g.xO, '', { oDy: 14, oDx: 9, xDy: -12 });   /* O は目盛りの右（mg の記号は矢印の左） */
    label(ctx, '＝ 自然長の位置', g.xO + 18, g.yF + 44, { size: 10.5, color: '#5d6875', align: 'left' });
  }
}

/* =====================================================================
   ②-6 単振り子（振れ幅が小さいとき）
   ===================================================================== */
function m2s6Q(s) { var l = s.v.l, m = s.v.m, w = Math.sqrt(G / l), th0 = s.v.th * Math.PI / 180, A = l * th0; return { m: m, K: m * G / l, w: w, T: TAU / w, A: A, phi: s.v.phi, Amax: l * 15 * Math.PI / 180, Amin: l * 2 * Math.PI / 180, l: l, th0: th0 }; }
function pGeo(s, box, small) {
  var Q = m2s6Q(s), top = box.y0 + (small ? 8 : 22), S = (box.h - (small ? 26 : 70)) / (2.0 + 0.06), px = box.x0 + box.w * (small || s.W < 480 ? 0.48 : 0.58), rb = small ? 6 : 12;   /* 左に参考の図があるので右へ（2026-10-25） */
  S = Math.min(S, (box.w * 0.45) / (2.0 * Math.sin(15 * Math.PI / 180)));
  var L = Q.l * S;
  var pos = function (X) { var th = X / Q.l; return { x: px + L * Math.sin(th), y: top + L * Math.cos(th) }; };
  return { S: S, top: top, px: px, rb: rb, L: L, u: [1, 0], pos: pos };
}
DEFS.m2s6 = m2Def({
  id: 'm2s6', num: 6, title: '単振り子', circ: 'below', rate: 1, fNetLabel: '復元力のみ表示',
  afterBuild: function (s) {                                      /* 図の下（左）：重力の x 成分が負であること・F = −mg sinθ を図で（2026-10-16 千葉さん） */
    var box = el('div', 'p6fig'); box.innerHTML = mathify('<p class="p6ttl">重力の $x$ 成分（復元力）</p><canvas></canvas><p class="p6txt">$x$ 軸は、最下点 O から円弧にそって右向きを正にとる。小球が O の右（$x > 0$）にあるとき、重力 $mg$ を糸の向きと円弧の接線の向きに分けると、接線の向きの成分は左向き（$x$ の負の向き）なので<br>$F = -mg\\sin\\theta$<br>$\\theta$ が小さいとき $\\sin\\theta \\fallingdotseq \\theta = \\dfrac{x}{l}$ より　$F \\fallingdotseq -\\dfrac{mg}{l}x$（復元力）</p>');
    s.below.insertBefore(box, s.below.firstChild);
    var cv = box.querySelector('canvas'), drawIt = function () { if (cv.offsetParent) drawP6Fig(cv); };
    requestAnimationFrame(drawIt); window.addEventListener('resize', function () { clearTimeout(cv._t); cv._t = setTimeout(drawIt, 100); });
    s.p6draw = drawIt;
  },
  desc: '長さ $l$ の軽い糸に小球をつるし、鉛直面内で小さく振らせる。最下点 O から糸にそって右向きを $x$ の正の向きにとる。<span class="todo">糸の長さ $l$・質量 $m$・振れ幅を変えて、周期が何で決まるか確かめよう。</span>',
  vars: [{ k: 'l', label: '糸の長さ $l$', stops: M2.s6.l, stopLabels: ['0.25', '0.5', '1', '2 m'], def: 2.0, aria: '糸の長さ', fmt: function (x) { return (x < 1 ? x.toFixed(2) : x.toFixed(1)) + ' m'; } },
    { k: 'm', label: '小球の質量 $m$', stops: M2.s6.m, stopLabels: ['0.1', '0.5', '1 kg'], def: 0.50, aria: '質量', fmt: function (x) { return x.toFixed(2) + ' kg'; } },
    { k: 'th', label: '振れ幅の角 $\\theta_0$', stops: M2.s6.th, stopLabels: ['5', '10', '15°'], def: 10, aria: '振れ幅の角', fmt: function (x) { return x + '°'; } }, m2Phi(Math.PI / 2)],
  varCols: [['l', 'm'], ['th', 'phi']],
  Q: m2s6Q,
  setAmp: function (s, X) { var Q = m2s6Q(s), d = Math.abs(X) / Q.l * 180 / Math.PI, b = M2.s6.th[0]; M2.s6.th.forEach(function (q) { if (Math.abs(q - d) < Math.abs(b - d)) b = q; }); s.v.th = b; s.v.phi = X < 0 ? -Math.PI / 2 : Math.PI / 2; },
  energy: function (s, r) { var Q = m2s6Q(s), th = r.X / Q.l; return { K: 0.5 * Q.m * r.v * r.v, U: Q.m * G * Q.l * (1 - Math.cos(th)) }; },
  height: function (w) { return Math.round(clamp(w * 0.44, 200, 300)); },     /* 前の 60 % */
  geo: function (s, box, small) { return pGeo(s, box, small); },
  scene: function (s, ctx, g, st, opt) { pScene(s, ctx, g, st, opt); },
  snapAsp: 1.2,
  snaps: function (s) { var Q = m2s6Q(s), A = Q.l * 15 * Math.PI / 180; return [{ cap: 'ⓐ つりあいの位置', X: 0 }, { cap: 'ⓑ 手をはなす', X: A, hand: true }, { cap: 'ⓒ $x>0$', X: A * 0.5, v: -1, eq: '$F = -mg\\sin\\theta \\fallingdotseq -\\dfrac{mg}{l}x$' }, { cap: 'ⓓ $x<0$', X: -A * 0.5, v: -1, eq: '$F \\fallingdotseq -\\dfrac{mg}{l}x > 0$' }]; },
  card: function (s) {
    var Q = m2s6Q(s);
    return m2Card({ ttl: '単振り子（振れ幅が小さいとき）', f: '<p>小球にはたらく力は重力 $mg$ と糸の張力 $S$。円の接線方向（運動の向き）の力は、重力の成分 $-mg\\sin\\theta$ だけ（$S$ は運動の向きと垂直）。</p>',
      eq: '<p>$\\theta$ が小さいとき $\\sin\\theta \\fallingdotseq \\theta = \\dfrac{x}{l}$ なので</p>' + eqL('eom', '$ma = -mg\\sin\\theta \\fallingdotseq -\\dfrac{mg}{l}x$') + '<p>$K = \\dfrac{mg}{l}$、$x_0 = 0$（最下点）。</p>',
      read: m2Read('\\fallingdotseq -\\dfrac{g}{l}x', '\\sqrt{\\dfrac{g}{l}}', '2\\pi\\sqrt{\\dfrac{l}{g}}', '周期は糸の長さ $l$ と $g$ だけで決まり、質量 $m$ や振れ幅によらない（振り子の等時性）。', false, true) +
        '<p class="qnow"><span class="qtag now">いまの値</span>$T = 2\\pi\\sqrt{\\dfrac{' + vtex(Q.l) + '}{9.8}} = ' + sig2(Q.T) + '$ s</p>',
      note: '<p class="qnote">もしも加速度運動する電車の中だったら、見かけの重力 $mg\'$ を考えて $T = 2\\pi\\sqrt{\\dfrac{l}{g\'}}$ になる。くわしくは慣性力のページの <a class="xlink" href="inertia-force.html#2-4">②-4 電車の中の振り子の周期</a> を見よう。</p>' });
  }
});
/* ②-6 の図の下の説明図（添付図のような、重力の分解） */
function drawP6Fig(cv) {
  var W = Math.max(240, Math.min(360, Math.floor(cv.clientWidth || 300))), H = Math.round(W * 1.05), ctx = prep(cv, W, H);
  var px = W * 0.36, top = 12, L = H * 0.52, th = 14 * Math.PI / 180, bx = px + L * Math.sin(th), by = top + L * Math.cos(th), ox = px, oy = top + L, rb = 9;
  ceilingAt(ctx, px - 40, px + 40, top);
  dotted(ctx, px, top, px, oy + 6, 'rgba(20,23,28,.45)', [6, 4]);
  ctx.save(); ctx.strokeStyle = 'rgba(20,23,28,.4)'; ctx.setLineDash([4, 4]); ctx.beginPath(); ctx.arc(px, top, L, Math.PI / 2 - 0.42, Math.PI / 2 + 0.42); ctx.stroke(); ctx.restore();
  ctx.save(); ctx.strokeStyle = '#6b5532'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(px, top); ctx.lineTo(bx - Math.sin(th) * rb, by - Math.cos(th) * rb); ctx.stroke(); ctx.restore();
  ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.1; ctx.beginPath(); ctx.arc(px, top, 34, Math.PI / 2 - th, Math.PI / 2); ctx.stroke(); ctx.restore();
  sym(ctx, 'θ', px + 44 * Math.sin(th / 2), top + 46 * Math.cos(th / 2), { size: 13 });
  sym(ctx, 'l', px + L * 0.5 * Math.sin(th) + 10, top + L * 0.5 * Math.cos(th), { size: 14 });
  ballShape(ctx, ox, oy, rb, M2BALL, 0.45); label(ctx, 'O', ox - 4, oy + 18, { size: 11.5, bold: true });
  /* x 軸：最下点から円弧にそって右向き（オレンジ） */
  ctx.save(); ctx.strokeStyle = '#e07b18'; ctx.lineWidth = 2.4; ctx.beginPath(); ctx.arc(px, top, L + 22, Math.PI / 2 + 0.16, Math.PI / 2 - 0.40, true); ctx.stroke(); ctx.restore();
  var ae = Math.PI / 2 - 0.40, axx = px + (L + 22) * Math.cos(ae), ayy = top + (L + 22) * Math.sin(ae), tx = Math.sin(ae), ty = -Math.cos(ae);
  ctx.save(); ctx.fillStyle = '#e07b18'; ctx.beginPath(); ctx.moveTo(axx + tx * 9, ayy + ty * 9); ctx.lineTo(axx - ty * 5, ayy + tx * 5); ctx.lineTo(axx + ty * 5, ayy - tx * 5); ctx.closePath(); ctx.fill(); ctx.restore();
  label(ctx, 'x 軸（右向きが正）', axx + 8, ayy - 14, { size: 11.5, bold: true, color: '#c76a0e', align: 'left' });
  /* 重力 mg と、その分解（糸の向き・接線の向き） */
  var Lg = H * 0.36, gx2 = bx, gy2 = by + Lg;
  var Lr = Lg * Math.cos(th), Lt = Lg * Math.sin(th), rx = Math.sin(th), ry = Math.cos(th), ux = -Math.cos(th), uy = Math.sin(th);
  dotted(ctx, bx + rx * Lr, by + ry * Lr, gx2, gy2, 'rgba(20,23,28,.45)', [3, 3]);
  dotted(ctx, bx + ux * Lt, by + uy * Lt, gx2, gy2, 'rgba(20,23,28,.45)', [3, 3]);
  arrow(ctx, bx, by, bx + rx * Lr, by + ry * Lr, 'comp', COL.force, { noShift: true });
  arrow(ctx, bx, by, bx + ux * Lt, by + uy * Lt, 'comp', COL.force, { noShift: true, tick: false });
  arrow(ctx, bx, by, gx2, gy2, 'force', COL.force, { noShift: true });
  ballShape(ctx, bx, by, rb, M2BALL);
  sym(ctx, 'mg', gx2 - 10, gy2 - 4, { size: 14, color: COL.force, align: 'right' });
  sym(ctx, 'mg cosθ', bx + rx * Lr + 8, by + ry * Lr - 4, { size: 12, color: COL.force, align: 'left' });
  label(ctx, 'F = −mg sinθ', bx + ux * Lt - 6, by + uy * Lt + 16, { size: 12, bold: true, color: COL.force, align: 'right' });
  ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.1; ctx.beginPath(); ctx.arc(gx2, gy2, 30, -Math.PI / 2 - th, -Math.PI / 2); ctx.stroke(); ctx.restore();
  sym(ctx, 'θ', gx2 - 13, gy2 - 40, { size: 12.5 });
  drawEqualTicks(ctx);
}
function pScene(s, ctx, g, st, opt) {
  var Q = m2s6Q(s), snap = opt.snap, big = opt.big, sm = snap && !big, b = g.pos(st.X), showF = snap || fAll(s), net = !snap && fNet(s), fs = (sm ? 16 : 30) / (Q.m * G);
  var th = st.X / Q.l, rb = g.rb * Math.cbrt(Q.m / 0.5);
  if (sm) rb = g.rb;
  if (!snap && s.W >= 480) {                                       /* 左に参考の図：つりあいの位置（糸が鉛直で小球が止まっている。2026-10-25 千葉さん）。せまい画面では出さない */
    var xr = s.W * 0.14, rr = rb;
    refArea(ctx, 0, 0, s.W * 0.28, s.H, 'r');
    ceilingAt(ctx, xr - 30, xr + 30, g.top);
    ctx.save(); ctx.strokeStyle = '#6b5532'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(xr, g.top); ctx.lineTo(xr, g.top + g.L - rr); ctx.stroke(); ctx.restore();
    ballShape(ctx, xr, g.top + g.L, rr, M2BALL);
    label(ctx, 'つりあいの位置', xr, Math.min(s.H - 10, g.top + g.L + rr + 40), { size: 10.5, bold: true, color: '#c0392b' });
  }
  ceilingAt(ctx, g.px - (sm ? 18 : 40), g.px + (sm ? 18 : 40), g.top);
  dotted(ctx, g.px, g.top, g.px, g.top + g.L + (sm ? 10 : 44), 'rgba(20,23,28,.35)', [4, 3]);
  if (!snap) eqLabel(ctx, g.px + 14, Math.min(s.H - 10, g.top + g.L + 54), 'left');      /* 最下点がつりあいの位置（点線の下のはし） */
  if (!sm) { ctx.save(); ctx.strokeStyle = 'rgba(20,23,28,.22)'; ctx.setLineDash([3, 4]); ctx.beginPath(); ctx.arc(g.px, g.top, g.L, Math.PI / 2 - 0.3, Math.PI / 2 + 0.3); ctx.stroke(); ctx.restore(); }
  var cp = { x: b.x - Math.sin(th) * rb, y: b.y - Math.cos(th) * rb };     /* 糸と小球の接点 */
  ctx.save(); ctx.strokeStyle = '#6b5532'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(g.px, g.top); ctx.lineTo(cp.x, cp.y); ctx.stroke(); ctx.restore();
  if (!sm && Math.abs(th) > 0.02) { ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(g.px, g.top, 30, Math.PI / 2, Math.PI / 2 - th, th > 0); ctx.stroke(); ctx.restore(); sym(ctx, 'θ', g.px + 40 * Math.sin(th / 2), g.top + 40 * Math.cos(th / 2) + 4, { size: 13 }); }
  if (!sm) { sym(ctx, 'l', g.px + (g.L / 2) * Math.sin(th) - 12, g.top + (g.L / 2) * Math.cos(th), { size: 14 }); }
  if (!snap && s.t < 0.5) startHand(s, ctx, b.x, b.y, rb, 'right', Math.cos(Q.phi));
  if (opt.frame && opt.frame.hand) dropHand(ctx, b.x, b.y, (big ? 0.42 : 0.2), 0, 1);
  ballShape(ctx, b.x, b.y, rb, M2BALL);
  if (net) {                                                       /* 「復元力のみ表示」：重力を分解して、円弧の接線方向（x の向き）の成分 F = −mg sinθ だけ（小球の中心から） */
    var tu0 = [Math.cos(th), -Math.sin(th)], Ft = -Q.m * G * Math.sin(th), Lr = Ft * 44 / (Q.m * G * Math.sin(15 * Math.PI / 180));   /* 縮尺：振れ幅 15° の端で 44 px */
    if (Math.abs(Lr) > 2) { var ar = arrow(ctx, b.x, b.y, b.x + tu0[0] * Lr, b.y + tu0[1] * Lr, 'force', COL.force, { noShift: true });
      if (ar) label(ctx, 'F = −mg sinθ', ar.x2 + (Lr < 0 ? -6 : 6), ar.y2 - 14, { size: 12, bold: true, color: COL.force, align: Lr < 0 ? 'right' : 'left' }); }
  }
  var vs = snap ? (opt.frame.v || 0) * 0.7 : (s.hideVec ? 0 : 1) * st.v / (Q.A * Q.w || 1), tu = [Math.cos(th), -Math.sin(th)];
  if (Math.abs(vs) > 0.03) vArrowAt(ctx, b.x, b.y, 0, 1, (showF && !sm) ? Q.m * G * fs + 24 : rb + (sm ? 9 : 16), tu[0], tu[1], vs * (sm ? 28 : 40), !sm);   /* 速度は小球の下（重力の矢印の先よりさらに下） */
  if (showF) {
    var S = Q.m * G * Math.cos(th) + Q.m * st.v * st.v / Q.l;
    fArrow(ctx, cp.x, cp.y, -Math.sin(th), -Math.cos(th), S * fs, COL.hand, sm ? null : 'S', { lx: -10 });
    fArrow(ctx, b.x, b.y, 0, 1, Q.m * G * fs, COL.force, sm ? null : 'mg');
    if (!sm && Math.abs(th) > 0.03) {
      var Lt = -Q.m * G * Math.sin(th) * fs;
      arrow(ctx, b.x, b.y, b.x + tu[0] * Lt, b.y + tu[1] * Lt, 'comp', COL.force, { tick: false });
      label(ctx, '−mg sinθ', b.x + (Lt < 0 ? -rb - 8 : rb + 8), b.y - rb - 4, { size: 11.5, color: COL.force, align: Lt < 0 ? 'right' : 'left' });   /* 小球の斜め上（x 軸・mg と重ならない） */
    }
  }
  if (!snap) m2Axis(ctx, { x: g.px, y: g.top + g.L + 34 }, [1, 0], -Math.min(g.px - 20, Q.Amax * g.S + 40), Math.min(s.W - g.px - 40, Q.Amax * g.S + 50), '', { oDy: 14, oDx: 0, xDy: -12 });
}

/* =====================================================================
   ②-7 浮力による単振動（鉛直下向きが正。x = 0 は静止しているときの物体の底の位置）
   ===================================================================== */
function m2s7Q(s) { var rho = M2.s7.rho, S = s.v.S, Hb = M2.s7.Hb, m = s.v.rb * S * Hb, h = m / (rho * S), w = Math.sqrt(G / h); return { m: m, K: rho * S * G, w: w, T: TAU / w, A: s.v.d, phi: Math.PI / 2, Amax: 0.04, Amin: 0.01, h: h, S: S, Hb: Hb, rho: rho }; }
function bGeo(s, box, small) {
  var Q = m2s7Q(s), yW = box.y0 + box.h * (small ? 0.42 : 0.40), S = Math.min((box.h * 0.48) / (Q.Hb + 0.05), box.w * 0.5 / 0.30) * (small ? 1 : 1);
  var bw = (Q.S / 0.10) * S, yBot0 = yW + Q.h * S;
  /* 左に「底面が液面と同じ高さのとき」「つりあいのとき」の 2 つの図（②-3 と同じ。対応する円運動を出すときと、幅がせまいときは出さない。2026-10-18 千葉さん） */
  var side = !small && !s.circOn && bw * (M2.s7.S[2] / Q.S) < box.w * 0.16, xc = box.x0 + box.w * (side ? 0.56 : 0.42);
  return { S: S, yW: yW, xc: xc, bw: bw, yBot0: yBot0, side: side, rb: Math.max(8, bw / 2), u: [0, 1], nCirc: [1, 0], circOff: box.w * 0.62, box: box,
    pos: function (X) { return { x: xc, y: yBot0 + X * S - Q.Hb * S / 2 }; } };
}
DEFS.m2s7 = m2Def({
  id: 'm2s7', num: 7, title: '浮力による単振動', short: '浮力', circ: 'right', rate: 0.4, noDrag: true,
  desc: '密度 $\\rho$ の液体に、断面積 $S$ の直方体を浮かべる。少し押し下げてから放すと、上下に単振動する。<span class="todo">液体中の体積が変わると浮力が変わるようすを見よう。断面積や物体の密度を変えて、周期が何で決まるか確かめよう。</span>',
  vars: [{ k: 'S', label: '断面積 $S$', stops: M2.s7.S, stopLabels: ['0.005', '0.010', '0.020 m²'], def: 0.010, aria: '断面積', fmt: function (x) { return x.toFixed(3) + ' m²'; } },
    { k: 'rb', label: '物体の密度', stops: M2.s7.rb, stopLabels: ['0.25', '0.50', '0.75'], def: 0.50e3, aria: '物体の密度', fmt: function (x) { return (x / 1000).toFixed(2) + ' × 10³ kg/m³'; } },
    { k: 'd', label: '押し下げる長さ $d$', stops: M2.s7.d, stopLabels: ['0.02', '0.04 m'], def: 0.04, aria: '押し下げる長さ', fmt: function (x) { return x.toFixed(2) + ' m'; } }],
  varCols: [['S', 'rb'], ['d']],
  Q: m2s7Q, setAmp: function () { },
  energy: function (s, r) { var Q = m2s7Q(s); return { K: 0.5 * Q.m * r.v * r.v, U: 0.5 * Q.K * r.X * r.X }; },
  height: function (w) { return Math.round(clamp(w * 0.36, 186, 252)); },     /* 前の 60 % */
  geo: function (s, box, small) { return bGeo(s, box, small); },
  scene: function (s, ctx, g, st, opt) { bScene(s, ctx, g, st, opt); },
  snapAsp: 1.1, snapCrop: [0.16, 0.64],                          /* 並べた図は水のまわりだけ（2026-10-19 千葉さん） */
  snaps: function (s) { var Q = m2s7Q(s); return [{ cap: 'ⓐ つりあいの位置', X: 0, eq: '$\\rho hSg = mg$' }, { cap: 'ⓑ $d$ 押し下げて放す', X: Q.A, hand: true }, { cap: 'ⓒ $x>0$', X: Q.A * 0.5, v: -1, eq: '$F = mg - \\rho(h+x)Sg = -\\rho Sg\\,x$' }, { cap: 'ⓓ $x<0$', X: -Q.A * 0.6, v: -1, eq: '$F = -\\rho Sg\\,x > 0$' }]; },
  live: function (s) { },
  card: function (s) {
    var Q = m2s7Q(s);
    return m2Card({ ttl: '浮力による単振動', f: '<p>重力 $mg$（下向き）と浮力 $\\rho Vg$（上向き）。液体中の体積は $V = S(h + x)$ なので、<b>沈むほど浮力が大きくなる</b>。</p>',
      eq: '<p class="eqline">' + eqTag('bal') + '$\\rho hSg = mg$（つりあいの位置で、液体中の深さ $h$）</p>' + eqL('eom', '$ma = mg - \\rho S(h + x)g = -\\rho Sg\\,x$') + '<p>$K = \\rho Sg$、$x_0 = 0$。</p>',
      read: m2Read('-\\dfrac{\\rho Sg}{m}x = -\\dfrac{g}{h}x', '\\sqrt{\\dfrac{g}{h}}', '2\\pi\\sqrt{\\dfrac{h}{g}}', '（$m = \\rho hS$ を使った）。周期は、つりあいの位置で液体中に沈んでいる深さ $h$ だけで決まる（断面積や質量そのものにはよらない）。') +
        '<p class="qnow"><span class="qtag now">いまの値</span>$m = ' + fmt(Q.m, 2) + '$ kg、$h = ' + fmt(Q.h, 3) + '$ m、$T = 2\\pi\\sqrt{\\dfrac{' + fmt(Q.h, 2) + '}{9.8}} = ' + sig2(Q.T) + '$ s</p>',
      note: '<p class="qnote">物体の上面はいつも液面より上、底面はいつも液体の中にあるとする。容器は十分に広く、液面の高さは変わらないとする。物体が液体から受ける力は浮力だけと考える。</p>' });
  }
});
function bScene(s, ctx, g, st, opt) {
  var Q = m2s7Q(s), snap = opt.snap, big = opt.big, sm = snap && !big, showF = snap || fAll(s), net = !snap && fNet(s), fs = (sm ? 16 : 30) / (Q.m * G);
  var box = g.box, x0 = box.x0 + (sm ? 4 : 14), x1 = box.x0 + box.w * (snap ? 0.94 : (s.circOn ? 0.90 : (g.side ? 0.86 : 0.80))), yBot = box.y0 + box.h - (sm ? 6 : (!snap && g.side ? 48 : 30));   /* 左の図があるときは、水槽の下に名前を書く場所をとる */
  var bot = g.yBot0 + st.X * g.S, topY = bot - Q.Hb * g.S, xl = g.xc - g.bw / 2;
  var xSep = (box.x0 + box.w * 0.33 + g.bw * 0.6 + g.xc - g.bw / 2 - 34) / 2;   /* 左の参考の図のエリアの右はし */
  if (!snap && g.side) refArea(ctx, 0, 0, xSep, s.H, 'n');
  /* 容器と液体 */
  ctx.save(); ctx.fillStyle = 'rgba(90,167,255,.16)'; ctx.fillRect(x0, g.yW, x1 - x0, yBot - g.yW);
  ctx.strokeStyle = '#3f74a8'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(x0, g.yW); ctx.lineTo(x1, g.yW); ctx.stroke();
  ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(x0, g.yW - (sm ? 12 : 40)); ctx.lineTo(x0, yBot); ctx.lineTo(x1, yBot); ctx.lineTo(x1, g.yW - (sm ? 12 : 40)); ctx.stroke(); ctx.restore();
  if (!sm) label(ctx, '液体（密度 ρ）', x1 - 8, yBot - 14, { size: 10.5, color: '#3f74a8', align: 'right' });
  if (!snap && g.side) {                                         /* 左の 2 つの図：底面が液面と同じ高さ／つりあい（同じ水槽の中に） */
    refLine(ctx, xSep, 0, s.H);                                   /* 境の実線（水の上にも見えるように、水槽のあとに） */
    [[box.x0 + box.w * 0.13, g.yW, '底面が液面と', '同じ高さの位置', false], [box.x0 + box.w * 0.33, g.yBot0, 'つりあいの位置', '', true]].forEach(function (r) {   /* 名前は「〜の位置」で、水槽の下に（2026-10-25 千葉さん） */
      var bb = r[1], tt = bb - Q.Hb * g.S, l = r[0] - g.bw / 2;
      ctx.save(); ctx.fillStyle = '#ead9b8'; ctx.fillRect(l, tt, g.bw, bb - tt);
      if (bb > g.yW) { ctx.fillStyle = 'rgba(31,111,214,.30)'; ctx.fillRect(l, g.yW, g.bw, bb - g.yW); }
      ctx.strokeStyle = '#6b5532'; ctx.lineWidth = 1.2; ctx.strokeRect(l, tt, g.bw, bb - tt); ctx.restore();
      if (fAll(s)) {
        var cyy = (tt + bb) / 2;
        fArrow(ctx, r[0] - 6, cyy, 0, 1, Q.m * G * fs, COL.force, 'mg', { noShift: true, lx: -10 });
        if (r[4]) fArrow(ctx, r[0] + 6, (g.yW + bb) / 2, 0, -1, Q.m * G * fs, '#b58900', 'ρhSg', { noShift: true, lx: 22 });
      }
      label(ctx, r[2], r[0], yBot + 16, { size: 10.5, color: r[4] ? '#c0392b' : '#5d6875', bold: r[4] }); if (r[3]) label(ctx, r[3], r[0], yBot + 30, { size: 10.5, color: '#5d6875' });
    });
  }
  /* 物体：液体の外は木の色、液体の中は青くぬって「液体中の体積」を見せる */
  ctx.save(); ctx.fillStyle = '#ead9b8'; ctx.fillRect(xl, topY, g.bw, bot - topY);
  var yIn = Math.max(g.yW, topY); ctx.fillStyle = 'rgba(31,111,214,.30)'; ctx.fillRect(xl, yIn, g.bw, bot - yIn);
  ctx.strokeStyle = 'rgba(31,111,214,.55)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.rect(xl, yIn, g.bw, bot - yIn); ctx.clip();
  for (var k = -g.bw; k < bot - yIn + g.bw; k += 7) { ctx.beginPath(); ctx.moveTo(xl + k, yIn); ctx.lineTo(xl + k - (bot - yIn), bot); ctx.stroke(); }
  ctx.restore();
  ctx.save(); ctx.strokeStyle = '#6b5532'; ctx.lineWidth = 1.4; ctx.strokeRect(xl, topY, g.bw, bot - topY); ctx.restore();
  if (!sm) {
    /* h（つりあいの位置で沈んでいる深さ）と x（つりあいの位置からの変位）を分けて書く（2026-10-16 千葉さん） */
    dimLine(ctx, xl - 14, g.yW, xl - 14, g.yBot0); sym(ctx, 'h', xl - 22, (g.yW + g.yBot0) / 2, { size: 13, align: 'right' });
    if (Math.abs(bot - g.yBot0) > 5) { dimLine(ctx, xl - 34, g.yBot0, xl - 34, bot, '#1663b5'); sym(ctx, 'x', xl - 42, (g.yBot0 + bot) / 2, { size: 13, align: 'right', color: '#1663b5' }); }
    if (!snap) label(ctx, '液体中の体積 V = S(h + x)', g.xc, bot + 20, { size: 11, color: '#1f5fa8', bold: true });   /* 物体の真下（右の速度・x 軸と重ならない） */
    dotted(ctx, xl - 40, g.yBot0, xl + g.bw + 40, g.yBot0, 'rgba(20,23,28,.4)', [4, 3]);
    if (!snap) eqLabel(ctx, xl + g.bw + 44, g.yBot0, 'left');
  }
  if (opt.frame && opt.frame.hand) { dropHand(ctx, g.xc, topY, big ? 0.4 : 0.2, 0, 1); }
  if (!snap) {                                                     /* 押し下げていた手を、そっと放す（見た目の時間で 0.22 s で消える） */
    var tr = s.t / (s.base || 1);
    if (tr < 0.22) { var al = tr <= 0.08 ? 1 : Math.max(0, 1 - (tr - 0.08) / 0.14); dropHand(ctx, g.xc, topY, 0.42, clamp(tr / 0.08, 0, 1), al); }
    if (s.t === 0 && !s.playing) handBubble(ctx, HOLD_TXT, g.xc + 98 * 0.42, topY - 62 * 0.42, 'r');
  }
  var vs = snap ? (opt.frame.v || 0) * 0.7 : (s.hideVec ? 0 : 1) * st.v / (Q.A * Q.w);
  if (Math.abs(vs) > 0.03) vArrowAt(ctx, g.xc, (topY + bot) / 2, 1, 0, g.bw / 2 + (sm ? 10 : 22), 0, 1, vs * (sm ? 28 : 40), !sm);
  if (net) netArrow(ctx, g.xc, (topY + bot) / 2, 0, 1, -Q.K * st.X * 46 / (Q.K * Q.Amax), 'F', { lx: -14, al: 'right' });   /* 合力（重力＋浮力）：物体の中心から */
  if (showF) {
    var cy = (topY + bot) / 2, Fb = Q.rho * Q.S * (Q.h + st.X) * G, cb = (yIn + bot) / 2;
    var dx = sm ? 3 : 7;                                         /* 重力と浮力は同じ線上にくるので、左右にずらす */
    fArrow(ctx, g.xc - dx, cy, 0, 1, Q.m * G * fs, COL.force, sm ? null : 'mg', { noShift: true, lx: -10 });
    fArrow(ctx, g.xc + dx, cb, 0, -1, Fb * fs, '#b58900', sm ? null : 'ρVg', { noShift: true, lx: 18 });
  }
  if (!snap) m2Axis(ctx, { x: x1 + 18, y: g.yBot0 }, [0, 1], -(g.yBot0 - g.yW) - 30, yBot - g.yBot0 - 10, '', { oDx: 12, oDy: 0, xDx: 10 });
}
