/* =========================================================================
   54_mode2s8.js … ②-8 まとめ：周期がどの物理量に依存するのか（2026-10-16 千葉さん）
   左の列：4 × 4 の表のように並べたアニメ
             列：水平ばね振り子・鉛直ばね振り子・単振り子
             行：基準／振幅（スライダー）／質量（スライダー）／重力加速度（ボタン：月・地球・上昇中のエレベーター）
           それぞれのアニメの右上に周期。スライダー・ボタンの横に ▶ スタートと ↺ リセットだけ。
           どれかのスタートを押すと、全部の行がいっしょに（同じ時刻から）動く。最初は全部が基準と同じ。
   右の列：周期の式と、何によって決まるかのまとめ（答えはたたんでおく）
   どのアニメも、端（x = +A）で静かに放す：x = A cos ωt
   ========================================================================= */
'use strict';
var M2S8 = {
  m: 0.50, k: 10, A: 0.10, l: 0.50, g: G,                     /* 基準：T ばね = 2π√(m/k) = 1.40 s、T 振り子 = 2π√(l/g) = 1.42 s */
  As: [0.05, 0.10, 0.15], ms: [0.25, 0.50, 1.0, 2.0],
  gs: [{ k: 'moon', label: '月で実験<br>（$g$ が小さい）', g: 1.6, short: '月' }, { k: 'earth', label: '地球で実験<br>（基準）', g: G, short: '地球' },
    { k: 'elev', label: '上昇中のエレベーター<br>（上向きに加速中：$g$ が大きい）', g: G + 4.9, short: 'エレベーター' }],
  Sx: 220,                                                    /* 振動の縮尺 px/m（全部のセルで同じ） */
  Sd: 26                                                      /* 鉛直ばねの「つりあいまでの伸び d」は縮めて描く px/m */
};
var M2S8COLS = [{ k: 'h', name: '水平ばね振り子' }, { k: 'v', name: '鉛直ばね振り子' }, { k: 'p', name: '単振り子' }];
var M2S8ROWS = [{ k: 'base', name: '基準' }, { k: 'A', name: '振幅 $A$' }, { k: 'm', name: '質量 $m$' }, { k: 'g', name: '重力加速度 $g$' }];

/* ③-1 として表示（前の ②-8 を移した。2026-10-18 千葉さん）。左右の列をまとめた所に、まず ②-1〜②-7 の表、その下に前の ②-8 */
var M3S1TAB = [
  { n: '②-1', a: '2-1', t: '水平ばね振り子', eq: 'ma = -kx', K: 'k', w: '\\sqrt{\\dfrac{k}{m}}', T: '2\\pi\\sqrt{\\dfrac{m}{k}}', c: '自然の長さの位置', hl: true },
  { n: '②-2', a: '2-2', t: '水平ばね振り子（両側ばね）', eq: 'ma = -(k_1 + k_2)x', K: 'k_1 + k_2', w: '\\sqrt{\\dfrac{k_1 + k_2}{m}}', T: '2\\pi\\sqrt{\\dfrac{m}{k_1 + k_2}}', c: '2 本とも自然の長さの位置' },
  { n: '②-3', a: '2-3', t: '鉛直ばね振り子', eq: 'ma = -kx', K: 'k', w: '\\sqrt{\\dfrac{k}{m}}', T: '2\\pi\\sqrt{\\dfrac{m}{k}}', c: '自然の長さから $d = \\dfrac{mg}{k}$ だけ下', hl: true },
  { n: '②-4', a: '2-4', t: '斜め台の上のばね振り子', eq: 'ma = -kx', K: 'k', w: '\\sqrt{\\dfrac{k}{m}}', T: '2\\pi\\sqrt{\\dfrac{m}{k}}', c: '自然の長さから斜面にそって $d = \\dfrac{mg\\sin\\theta}{k}$ だけ下' },
  { n: '②-5', a: '2-5', t: '水平で摩擦がある場合', eq: 'ma = -k\\left(x \\mp \\dfrac{\\mu\'mg}{k}\\right)', K: 'k', w: '\\sqrt{\\dfrac{k}{m}}', T: '2\\pi\\sqrt{\\dfrac{m}{k}}', c: '$x = \\pm\\dfrac{\\mu\'mg}{k}$（動く向きで入れかわる）' },
  { n: '②-6', a: '2-6', t: '単振り子', eq: 'ma \\fallingdotseq -\\dfrac{mg}{l}x', K: '\\dfrac{mg}{l}', w: '\\sqrt{\\dfrac{g}{l}}', T: '2\\pi\\sqrt{\\dfrac{l}{g}}', c: '最下点', hl: true },
  { n: '②-7', a: '2-7', t: '浮力による単振動', eq: 'ma = -\\rho Sg\\,x', K: '\\rho Sg', w: '\\sqrt{\\dfrac{\\rho Sg}{m}} = \\sqrt{\\dfrac{g}{h}}', T: '2\\pi\\sqrt{\\dfrac{h}{g}}', c: '重力と浮力がつりあう位置（$\\rho hSg = mg$）' },
  { n: '②-8', a: '2-8', t: '地球トンネルの単振動', eq: 'ma = -\\dfrac{mg}{R}x', K: '\\dfrac{mg}{R}', w: '\\sqrt{\\dfrac{g}{R}}', T: '2\\pi\\sqrt{\\dfrac{R}{g}}', c: '地球の中心' }   /* 2026-10-18 千葉さん */
];
DEFS.m3s1 = {
  id: 'm3s1', mode: 'mode3', num: 1, title: '各単振動の周期は、ある物理量に依存して変わる<small class="ttnote">※暗記事項ではない</small>', short: '周期は何で決まる？', custom: true,
  html: function () {
    var t = mathify('<div class="m3tabwrap"><table class="reltab m3tab"><thead><tr><th>単振動</th><th>運動方程式</th><th>$K$</th><th>$\\omega = \\sqrt{\\dfrac{K}{m}}$</th><th>$T = 2\\pi\\sqrt{\\dfrac{m}{K}}$</th><th>つりあいの位置</th></tr></thead><tbody>' +
      M3S1TAB.map(function (r) { return '<tr><th><a class="xlink" href="#' + r.a + '">' + r.n + '</a>　' + r.t + '</th><td>$' + r.eq + '$</td><td>$' + r.K + '$</td><td>$\\omega = ' + r.w + '$</td><td>$T = ' + r.T + '$</td><td class="l">' + r.c + '</td></tr>'; }).join('') +
      '</tbody></table></div>' +
      '<p class="m3tabnote">$x$ は、つりあいの位置（振動の中心）からの変位（②-5 は自然の長さの位置から）。</p>' +
      '<div class="qcard keybox m3key"><p>$K$ とは、その単振動における「ばね定数」にあたる量であり、$F = -\\bigcirc x$ の形に変形したときの「$\\bigcirc$」に当たる量。覚えるのではなく、各単振動について力を書き合力の式を導くことにより、自分で求められるようになろう。つりあいの位置も自分で求めること。</p>' +
      '<p><b>ばねによる振動と単振り子の $\\omega$、$T$ はうっすら覚えておこう。</b></p></div>');
    return t + '<p class="m3cap">例：3 つの振り子の比較</p><div class="secdesc">水平ばね振り子・鉛直ばね振り子・単振り子を、振幅・質量・重力加速度だけを変えて「基準」と比べる。どれも端で静かに放す。<span class="todo">スライダーやボタンで 1 つの量だけを変えてスタートし、周期（右上）が変わるもの・変わらないものを見分けよう。</span></div>' +
      '<div class="s8wrap"><div class="sL s8L"></div><div class="sR s8R"></div></div>';
  },
  build: function (art) { SIM_BY_ID.m3s1 = new M2S8Sim(art.querySelector('.s8L'), art.querySelector('.s8R')); }
};

function M2S8Sim(L, R) {
  this.L = L; this.R = R; this.def = DEFS.m3s1; this.mode = 'mode3';
  this.v = { A: M2S8.A, m: M2S8.m, g: 'earth' };
  this.t = 0; this.playing = false; this.cells = []; this.starts = [];
  this.build(); this.renderRight();
  var self = this;
  window.addEventListener('resize', function () { clearTimeout(self._rz); self._rz = setTimeout(function () { self.draw(); }, 90); });
  requestAnimationFrame(function () { self.draw(); });
  if (window.IntersectionObserver) new IntersectionObserver(function (es) { es.forEach(function (e) { if (!e.isIntersecting && self.playing) { self.playing = false; self.sync(); } }); }).observe(this.grid);   /* 画面から消えたら止める */
}
/* 行ごとの条件（その行で変えた量だけが基準と違う） */
M2S8Sim.prototype.cond = function (row) {
  var c = { A: M2S8.A, m: M2S8.m, g: M2S8.g, gk: 'earth' };
  if (row === 'A') c.A = this.v.A;
  if (row === 'm') c.m = this.v.m;
  if (row === 'g') { var q = M2S8.gs.filter(function (z) { return z.k === this.v.g; }, this)[0]; c.g = q.g; c.gk = q.k; }
  return c;
};
M2S8Sim.prototype.period = function (col, c) { return col === 'p' ? TAU * Math.sqrt(M2S8.l / c.g) : TAU * Math.sqrt(c.m / M2S8.k); };
M2S8Sim.prototype.build = function () {
  var self = this, L = this.L;
  var tb = el('div', 's8grid'); L.appendChild(tb); this.grid = tb;
  /* 見出しの行 */
  /* 左上：▶ スタート・コマ送り・↺ リセット（全部の行に共通で 1 つ。2026-10-16 千葉さん）と時刻 */
  var tcell = el('div', 's8h s8corner'), bb = el('div', 's8btns');
  var bp = el('button', 'b play s8play', '▶ スタート'); bp.type = 'button'; bp.addEventListener('click', function () { self.toggle(); });
  var bs = el('button', 'b stepb two s8step', 'コマ<br>送り'); bs.type = 'button'; bs.title = '押すごとに 1/16 周期（基準）ずつ進める'; bs.addEventListener('click', function () { self.stepFrame(); });
  var br = el('button', 'b s8reset', '↺ リセット'); br.type = 'button'; br.addEventListener('click', function () { self.reset(); });
  [bp, bs, br].forEach(function (b) { bb.appendChild(b); }); tcell.appendChild(bb); self.starts.push(bp);
  this.tval = el('span', 's8t', ''); tcell.appendChild(this.tval); tb.appendChild(tcell);
  M2S8COLS.forEach(function (c) { tb.appendChild(el('div', 's8h', c.name)); });
  M2S8ROWS.forEach(function (r) {
    var lab = el('div', 's8lab s8lab_' + r.k);
    lab.appendChild(el('p', 's8ln', mathify(r.name)));
    if (r.k === 'A' || r.k === 'm') {
      var stops = r.k === 'A' ? M2S8.As : M2S8.ms, box = el('div', 's8ctl');
      var inp = el('input'); inp.type = 'range'; inp.min = '0'; inp.max = String(stops.length - 1); inp.step = '1'; inp.setAttribute('aria-label', r.k === 'A' ? '振幅' : '質量');
      var val = el('span', 's8v', '');
      inp.addEventListener('input', function () { self.v[r.k] = stops[+inp.value]; self.changed(); });
      box.appendChild(inp); box.appendChild(val); lab.appendChild(box);
      r._inp = inp; r._val = val; r._stops = stops;
    }
    if (r.k === 'g') {
      var sg = el('div', 's8seg'); sg.setAttribute('role', 'group'); sg.setAttribute('aria-label', 'どこで実験するか');
      r._btns = M2S8.gs.map(function (q) { var b = el('button', 'b s8gb', mathify(q.label)); b.type = 'button'; b.addEventListener('click', function () { self.v.g = q.k; self.changed(); }); sg.appendChild(b); return b; });
      lab.appendChild(sg);
    }
    tb.appendChild(lab);
    M2S8COLS.forEach(function (c) {
      var cell = el('div', 's8cell'), cv = el('canvas'); cv.id = 'cv_m2s8_' + r.k + c.k; cv.setAttribute('aria-label', c.name + '（' + r.name.replace(/\$/g, '') + '）');
      cell.appendChild(cv); tb.appendChild(cell);
      self.cells.push({ row: r.k, col: c.k, cv: cv, cell: cell });
    });
    r._el = lab;
  });
  this.rows = M2S8ROWS;
  this.msg = el('div', 'msgbox'); L.appendChild(this.msg);
  this.sync();
};
M2S8Sim.prototype.sync = function () {
  var self = this;
  this.rows.forEach(function (r) {
    if (r._inp) { var i = r._stops.indexOf(self.v[r.k]); r._inp.value = String(i); r._inp.style.setProperty('--p', (i / (r._stops.length - 1) * 100).toFixed(1) + '%'); r._val.textContent = (r.k === 'A' ? fmt(self.v.A, 2) + ' m' : fmt(self.v.m, 2) + ' kg'); }
    if (r._btns) r._btns.forEach(function (b, i) { var on = M2S8.gs[i].k === self.v.g; b.classList.toggle('on', on); b.setAttribute('aria-pressed', on ? 'true' : 'false'); });
  });
  var txt = this.playing ? '❚❚ 一時停止' : '▶ スタート';
  this.starts.forEach(function (b) { if (b.textContent !== txt) b.textContent = txt; });
  var ch = [];
  if (this.v.A !== M2S8.A) ch.push('振幅'); if (this.v.m !== M2S8.m) ch.push('質量'); if (this.v.g !== 'earth') ch.push('重力加速度');
  var m = ch.length ? 'いま基準と違うのは「' + ch.join('」「') + '」の行。<b>右上の周期が基準と同じ（灰色）か、違う（オレンジ）か</b>を見よう。' : 'いまは全部の行が基準と同じ。スライダーやボタンで 1 つの量だけを変えてみよう。';
  if (m !== this._m) { this._m = m; this.msg.innerHTML = mathify(m); }
};
/* 量を変えたら、全部を最初の時刻からいっしょに（比べやすいように） */
M2S8Sim.prototype.changed = function () { this.t = 0; this.sync(); this.draw(); };
M2S8Sim.prototype.toggle = function () {
  var self = this;
  this.playing = !this.playing; this.sync();
  if (this.playing) {
    SIMS.forEach(function (s) { if (s.playing) { s.playing = false; s.syncPlayLabel(); } });
    var last = 0;
    var loop = function (ts) {
      if (!self.playing) return;
      var dt = last ? Math.min(0.05, (ts - last) / 1000) : 0; last = ts;
      self.t += dt; if (self.t >= 30) { self.t = 30; self.playing = false; self.sync(); }
      self.draw(); if (self.playing) requestAnimationFrame(loop);
    };
    requestAnimationFrame(loop);
  }
};
/* コマ送り：基準の周期（ばね振り子）の 1/16 ずつ。最初はいちばん近い 1/16 の倍数へ */
M2S8Sim.prototype.stepFrame = function () {
  var q = TAU * Math.sqrt(M2S8.m / M2S8.k) / 16, n = this.t / q;
  this.playing = false; this.t = Math.abs(n - Math.round(n)) > 1e-6 ? Math.round(n) * q : this.t + q; this.sync(); this.draw();
};
M2S8Sim.prototype.reset = function () { this.playing = false; this.t = 0; this.sync(); this.draw(); };
M2S8Sim.prototype.draw = function () {
  var self = this;
  if (!this.grid.offsetParent) return;
  var tv = '$t =$ ' + fmt(this.t, 1) + ' s'; if (tv !== this._tv) { this._tv = tv; this.tval.innerHTML = mathify(tv); }
  this.cells.forEach(function (c) {
    var W = Math.max(90, Math.floor(c.cell.clientWidth || 160)), H = W < 130 ? 120 : 150;
    var ctx = prep(c.cv, W, H), cd = self.cond(c.row);
    m2s8Draw(ctx, c.col, cd, self.t, W, H, self.period(c.col, cd), self.period(c.col, self.cond('base')));
  });
};
/* 月面の模様（下のはし）：灰色の地面と、いくつかのクレーター */
function m2s8Moon(ctx, W, H) {
  var y0 = H - 16;
  ctx.save(); ctx.fillStyle = '#d9d8d3'; ctx.beginPath(); ctx.moveTo(0, H); ctx.lineTo(0, y0 + 4);
  for (var i = 0; i <= 20; i++) { var x = W * i / 20; ctx.lineTo(x, y0 + 3 * Math.sin(i * 1.7)); }
  ctx.lineTo(W, H); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = '#a9a7a0'; ctx.lineWidth = 1; ctx.stroke();
  [[0.16, 7, 5], [0.42, 10, 6], [0.7, 6, 4], [0.88, 9, 5]].forEach(function (c) {
    ctx.fillStyle = '#c3c1ba'; ctx.beginPath(); ctx.ellipse(W * c[0], y0 + c[1], c[2] * 1.6, c[2] * 0.7, 0, 0, TAU); ctx.fill(); ctx.strokeStyle = '#9f9c94'; ctx.stroke();
  });
  ctx.restore();
}
/* 上昇中のエレベーター：かごの長方形と、横の上向きの矢印（加速度） */
function m2s8Elev(ctx, W, H) {
  ctx.save(); ctx.strokeStyle = '#5d6875'; ctx.lineWidth = 2; ctx.strokeRect(4, 4, W - 26, H - 8);
  var ax = W - 11; ctx.strokeStyle = COL.acc; ctx.fillStyle = COL.acc; ctx.lineWidth = 2.6;
  ctx.beginPath(); ctx.moveTo(ax, H * 0.78); ctx.lineTo(ax, H * 0.3); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(ax, H * 0.22); ctx.lineTo(ax - 5, H * 0.32); ctx.lineTo(ax + 5, H * 0.32); ctx.closePath(); ctx.fill();
  ctx.restore();
}
/* 1 つのセルの図 */
function m2s8Draw(ctx, col, cd, t, W, H, T, T0) {
  var w = TAU / T, x = cd.A * Math.cos(w * t), S = M2S8.Sx * (W < 130 ? 0.62 : 1), rb = (W < 130 ? 6 : 8) * Math.cbrt(cd.m / 0.5);
  /* 背景の色は変えない。月：下に月面の模様／上昇中のエレベーター：全体を長方形でかこみ、横に上向きの矢印（2026-10-16 千葉さん） */
  if (cd.gk === 'moon') m2s8Moon(ctx, W, H);
  if (cd.gk === 'elev') m2s8Elev(ctx, W, H);
  if (col === 'h') {                                          /* 水平ばね振り子：重力は周期に関係しない */
    var yF = H * 0.62, xO = W * 0.58, xW = 8, y = yF - rb;
    wallLeftAt(ctx, xW, yF - 34, yF); floorAt(ctx, xW, cd.gk === 'elev' ? W - 26 : W - 6, yF);
    dotted(ctx, xO, yF - 40, xO, yF + 10, 'rgba(20,23,28,.3)', [3, 3]);
    springDense(ctx, xW, y, xO + x * S - rb, y, xO - rb - xW, { r: 5, lead: 4, k: M2S8.k, thin: 0.7 });
    ballShape(ctx, xO + x * S, y, rb, M2BALL);
  } else if (col === 'v') {                                   /* 鉛直ばね振り子：g・m でつりあいの位置（伸び d）は変わる */
    var top = 8, cx = W * 0.4, L0 = 26, d = cd.m * cd.g / M2S8.k, yN = top + L0, yE = yN + d * M2S8.Sd, yb = yE + x * S;
    ceilingAt(ctx, cx - 20, cx + 20, top);
    dotted(ctx, cx - 30, yE, cx + 34, yE, 'rgba(20,23,28,.35)', [3, 3]);
    springDense(ctx, cx, top, cx, yb - rb, yE - top - rb, { r: 5, lead: 4, k: M2S8.k, thin: 0.7 });
    ballShape(ctx, cx, yb, rb, M2BALL);
    label(ctx, 'つりあい', cx + 36, yE, { size: 9.5, color: '#5d6875', align: 'left' });
  } else {                                                    /* 単振り子：m・振幅によらず、g で変わる */
    var px = W * 0.42, tp = 8, Lp = M2S8.l * S, th = x / M2S8.l, bx = px + Lp * Math.sin(th), by = tp + Lp * Math.cos(th);
    ceilingAt(ctx, px - 18, px + 18, tp);
    dotted(ctx, px, tp, px, tp + Lp + 8, 'rgba(20,23,28,.3)', [3, 3]);
    ctx.save(); ctx.strokeStyle = '#6b5532'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(px, tp); ctx.lineTo(bx - Math.sin(th) * rb, by - Math.cos(th) * rb); ctx.stroke(); ctx.restore();
    ballShape(ctx, bx, by, rb, M2BALL);
  }
  /* 右上に周期（基準と同じなら灰色、ちがえばオレンジ） */
  var same = Math.abs(T - T0) < 1e-9, txt = 'T = ' + sig2(T) + ' s';
  ctx.save(); ctx.font = 'bold ' + (W < 130 ? 10.5 : 12) + 'px ' + FONT; ctx.textAlign = 'right'; ctx.textBaseline = 'top';
  var tw = ctx.measureText(txt).width, RX = cd.gk === 'elev' ? W - 28 : W - 8, TY = cd.gk === 'elev' ? 9 : 4;   /* エレベーターは長方形の内がわに */
  ctx.fillStyle = same ? '#f1efea' : '#fff1de'; rrect(ctx, RX - tw - 4, TY, tw + 8, 18, 5); ctx.fill();
  if (!same) { ctx.strokeStyle = '#e07b18'; ctx.lineWidth = 1.2; ctx.stroke(); }
  ctx.fillStyle = same ? '#69717d' : '#b35c00'; ctx.fillText(txt, RX, TY + 3); ctx.restore();
  if (cd.gk !== 'earth') label(ctx, 'g = ' + fmt(cd.g, 1) + ' m/s²', cd.gk === 'elev' ? 9 : 6, cd.gk === 'moon' ? H - 26 : H - 13, { size: 9.5, color: '#5d6875', align: 'left' });
}
M2S8Sim.prototype.renderRight = function () {
  var h = '<div class="qcard"><p class="qt">周期の式</p>' +          /* 簡潔に（2026-10-18 千葉さん） */
    '<p>ばね振り子（水平・鉛直）：$T = 2\\pi\\sqrt{\\dfrac{m}{k}}$<br>単振り子：$T = 2\\pi\\sqrt{\\dfrac{l}{g}}$</p>' +
    '<p class="qnote">基準：$m = ' + M2S8.m.toFixed(2) + '$ kg、$k = ' + M2S8.k + '$ N/m、$A = ' + M2S8.A.toFixed(2) + '$ m、$l = ' + M2S8.l.toFixed(2) + '$ m、$g = 9.8$ m/s²。鉛直ばね振り子の「つりあいまでの伸び」は、縮めて描いている。</p></div>' +
    '<details class="qcard s8ans"><summary>まとめ（予想してから開こう）</summary>' +
    '<table class="reltab s8tab"><thead><tr><th></th><th>水平ばね</th><th>鉛直ばね</th><th>単振り子</th></tr>' +
    '<tr class="s8f"><th></th><td>$T = 2\\pi\\sqrt{\\dfrac{m}{k}}$</td><td>$T = 2\\pi\\sqrt{\\dfrac{m}{k}}$</td><td>$T = 2\\pi\\sqrt{\\dfrac{l}{g}}$</td></tr></thead><tbody>' +
    '<tr><th>振幅 $A$</th><td>変わらない</td><td>変わらない</td><td>変わらない<br><small>（振れ幅が小さいとき）</small></td></tr>' +
    '<tr><th>質量 $m$</th><td class="y">変わる</td><td class="y">変わる</td><td>変わらない</td></tr>' +
    '<tr><th>重力加速度 $g$</th><td>変わらない</td><td>変わらない<br><small>（つりあいの位置は変わる）</small></td><td class="y">変わる</td></tr></tbody></table>' +
    '<p>ばね振り子の周期は $m$ と $k$ だけ、単振り子の周期は $l$ と $g$ だけで決まる。どれも振幅にはよらない（<b>等時性</b>）。</p>' +
    '<p><b>重力加速度を変えたときの単振り子</b>：周期の式 $T = 2\\pi\\sqrt{\\dfrac{l}{g}}$ の $g$ を、その場所での重力加速度 $g\'$ にかえて考える。</p>' +
    '<p>・月で実験：$g\' = 1.6$ m/s² だから　$T = 2\\pi\\sqrt{\\dfrac{0.50}{1.6}} \\fallingdotseq 3.5$ s（地球より長い）</p>' +
    '<p>・上昇中のエレベーター（上向きの加速度 $a$）の中では、見かけの重力加速度が $g\' = g + a$ になる。くわしくは慣性力のページの <a class="xlink" href="inertia-force.html#2-4">②-4</a> を見よう。この図では $a = 4.9$ m/s² としているので、$g\' = 9.8 + 4.9 = 14.7$ m/s² だから　$T = 2\\pi\\sqrt{\\dfrac{0.50}{14.7}} \\fallingdotseq 1.2$ s（地球より短い）</p>' +
    '<p class="qnote">ばね振り子の周期 $T = 2\\pi\\sqrt{\\dfrac{m}{k}}$ には $g$ が入っていないので、月でもエレベーターでも変わらない（鉛直ばね振り子では、つりあいの位置だけが変わる）。</p></details>';
  this.R.innerHTML = mathify(h);
};
/* テスト用：sim と同じように扱えるように */
M2S8Sim.prototype.resize = function () { };
M2S8Sim.prototype.syncPlayLabel = function () { this.sync(); };
