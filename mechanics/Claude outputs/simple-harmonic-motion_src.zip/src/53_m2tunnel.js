/* =========================================================================
   53_m2tunnel.js … ②-8 地球トンネルの単振動（2026-10-18 千葉さん。前の構想では ④-7）
   celestial-mechanics.html#m3-2 をもとに簡潔に：中心を通るまっすぐな穴で、地表より内がわの x₀ から静かに放す。
   穴の中では F = −(GMm/R³)x = −(mg/R)x（GM = gR²）なので、中心 O を振動の中心とする単振動。T = 2π√(R/g) ≒ 84 分。
   x の正の向きは右向き。時刻は「分」で表す。
   ========================================================================= */
'use strict';
var M2T = { R: 6.371e6, g: G, x0: [0.25, 0.50, 0.75, 1.0], x00: 1.0 };
function m2tQ(s) {
  var w = Math.sqrt(M2T.g / M2T.R), A = s.v.x0 * M2T.R;
  return { w: w, T: TAU / w, A: A, R: M2T.R };
}
function m2tState(s, t) { var q = m2tQ(s), c = Math.cos(q.w * t); return { x: q.A * c, v: -q.A * q.w * Math.sin(q.w * t), a: -q.w * q.w * q.A * c }; }
DEFS.m2s8 = {
  id: 'm2s8', mode: 'mode2', num: 8, title: '地球トンネルの単振動', short: '地球トンネル',
  desc: '地球を半径 $R$・密度が一様な球とみなし、中心 O を通るまっすぐな細い穴（トンネル）をあける。穴の中の位置 $x_0$ から小球を静かに放す（自転や空気の抵抗は考えない）。<span class="todo">放す位置 $x_0$ を変えても、往復にかかる時間（周期）が変わらないことを確かめよう。</span>',
  strobe: false, showFBtn: true, fDefault: 'all', fNetLabel: '万有引力を表示', vecBtn: 'v を消す', belowCanvas: true, baseRate: 900,
  vars: [{ k: 'x0', label: '放す位置 $x_0$', stops: M2T.x0, stopLabels: ['0.25R', '0.50R', '0.75R', 'R（地表）'], def: M2T.x00, aria: '放す位置', fmt: function (x) { return fmt(x, 2) + ' $R$'; } }],
  tFmt: function (t) { return fmt(t / 60, 1) + ' 分'; },
  tEnd: function (s) { return 2 * m2tQ(s).T; },
  tInfo: function (s) { var T = m2tQ(s).T; return '<span class="tpl">周期</span><b>' + tex('T =') + ' ' + sig2(T / 1000) + ' × 10³</b> s（約 ' + Math.round(T / 60) + ' 分）'; },
  gT: function (s) { return m2tQ(s).T; },
  height: function (s, w) { return Math.round(clamp(w * 0.62, 300, 420)); },
  afterBuild: function (s) {
    ctlOneRow(s);                                                 /* 放す位置のバーを半分にして、右に時間バー（2026-10-18 千葉さん） */
    if (s.extra && s.extra.fNet) s.extra.fNet.hidden = true;        /* 力は万有引力 1 つだけなので「合力のみ」は出さない */
    var nb = el('div', 'qcard m2tfx'); nb.innerHTML = mathify('<p class="qt">小球が受ける力 $F$ と位置 $x$ の関係（$F$–$x$ グラフ）</p>'); s.fxCv = el('canvas'); nb.appendChild(s.fxCv); s.below.appendChild(nb);
    s.snapBox = el('div', 'snapbox'); s.below.appendChild(s.snapBox); m2Snaps(s);   /* 振動の様子を並べた図（2026-10-19 千葉さん） */
  },
  draw: function (s, ctx, W, H) { drawM2T(s, ctx, W, H); drawM2TFx(s); m2SnapCheck(s); },
  msg: function (s) { var q = m2tQ(s); return '放す位置によらず、周期は $T = 2\\pi\\sqrt{\\dfrac{R}{g}} \\fallingdotseq ' + Math.round(q.T / 60) + '$ 分。地表から放すと、約 ' + Math.round(q.T / 120) + ' 分で地球の反対がわに着く。'; },
  right: function (s, R) { rightM2T(s, R); }
};
function drawM2T(s, ctx, W, H) {
  var q = m2tQ(s), st = m2tState(s, s.t), cx = W * 0.47, cy = H * 0.46, Rp = Math.min(W * 0.36, H * 0.40), S = Rp / q.R, X = function (x) { return cx + x * S; };
  /* 地球（断面）と穴 */
  ctx.save(); var gr = ctx.createRadialGradient(cx - Rp * 0.3, cy - Rp * 0.3, Rp * 0.1, cx, cy, Rp);
  gr.addColorStop(0, '#dbe9f7'); gr.addColorStop(1, '#a9c6e6'); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(cx, cy, Rp, 0, TAU); ctx.fill();
  ctx.strokeStyle = '#3f74a8'; ctx.lineWidth = 1.6; ctx.stroke();
  ctx.fillStyle = '#f7f3ea'; ctx.fillRect(cx - Rp, cy - 6, 2 * Rp, 12); ctx.strokeStyle = '#6b7a8c'; ctx.lineWidth = 1; ctx.strokeRect(cx - Rp, cy - 6, 2 * Rp, 12); ctx.restore();
  label(ctx, '地球（密度が一様な球）', cx, cy - Rp - 14, { size: 11.5, color: '#2f5f8f', bold: true });
  label(ctx, 'トンネル', cx - Rp * 0.62, cy - 16, { size: 10.5, color: '#5d6875' });
  /* x 軸・目盛り */
  axisArrow(ctx, cx - Rp - 30, cy + Rp * 0.55, cx + Rp + 40, cy + Rp * 0.55); sym(ctx, 'x', cx + Rp + 44, cy + Rp * 0.55 - 12, { size: 14 });
  [[-1, '−R'], [-0.5, ''], [0, 'O'], [0.5, ''], [1, 'R']].forEach(function (r) { var xx = X(r[0] * q.R), yy = cy + Rp * 0.55; ctx.save(); ctx.strokeStyle = '#2b323c'; ctx.beginPath(); ctx.moveTo(xx, yy - 4); ctx.lineTo(xx, yy + 4); ctx.stroke(); ctx.restore(); if (r[1]) label(ctx, r[1], xx, yy + 15, { size: 11, bold: r[0] === 0 }); });
  dotted(ctx, cx, cy - 6, cx, cy + Rp * 0.55, 'rgba(192,57,43,.55)', [4, 3]);
  label(ctx, '振動の中心（地球の中心）', cx + 6, cy + Rp * 0.42, { size: 10.5, color: '#c0392b', bold: true, align: 'left' });
  /* 放す位置の印 */
  var xs = X(q.A); ctx.save(); ctx.strokeStyle = '#7a4fb8'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.arc(xs, cy, 7, 0, TAU); ctx.stroke(); ctx.restore();
  label(ctx, '放す位置 x₀', xs, cy + 20, { size: 10.5, color: '#7a4fb8' });
  /* 半径 |x| の球（その内がわの質量だけが効く） */
  var rx = Math.abs(st.x) * S;
  if (rx > 6) { ctx.save(); ctx.setLineDash([5, 4]); ctx.strokeStyle = 'rgba(31,95,168,.75)'; ctx.fillStyle = 'rgba(31,95,168,.10)'; ctx.lineWidth = 1.3; ctx.beginPath(); ctx.arc(cx, cy, rx, 0, TAU); ctx.fill(); ctx.stroke(); ctx.restore(); }
  /* 小球・速度（上に離して）・万有引力（小球から） */
  var bx = X(st.x); ballShape(ctx, bx, cy, 7, '#c0392b');
  var vref = q.A * q.w;
  if (!s.hideVec && Math.abs(st.v) > 0.02 * vref) vArrowAt(ctx, bx, cy, 0, -1, 26, 1, 0, st.v / vref * 46, true);
  if (s.fmode) { var L = -st.x / q.R * 52; if (Math.abs(L) > 2) fArrow(ctx, bx, cy, 1, 0, L, COL.force, 'F', { ly: 16, noShift: true }); }
  var hf = s.t === 0 && !s.playing ? 1 : clamp(1 - s.t / (0.05 * q.T), 0, 1);   /* 手で持っていて、放すと手が消えていく */
  if (hf > 0) { ctx.save(); ctx.globalAlpha = hf; dropHand(ctx, X(q.A) + 4, cy + 1 - (1 - hf) * 30, 0.34, 1, 1);   /* 指先が小球の上にふれる位置。放すと上へ離れて消える */ ctx.restore(); }
  if (s.t === 0 && !s.playing) handBubble(ctx, 'ここから静かに放す', xs + 30, cy - 46, 'r');
  label(ctx, '半径 |x| の球の内がわの質量だけが、中心に集まっているとみなせる', cx, H - 12, { size: 10.5, color: '#1f5fa8' });
  drawEqualTicks(ctx);
}
function drawM2TFx(s) {
  var cv = s.fxCv; if (!cv || !cv.offsetParent) return;
  var q = m2tQ(s), st = m2tState(s, s.t), W = Math.max(240, Math.floor(cv.clientWidth || 300)), H = 170, ctx = prep(cv, W, H);
  var x0 = 30, x1 = W - 24, ym = H / 2, X = function (x) { return (x0 + x1) / 2 + x / q.R * (x1 - x0) / 2.4; }, Y = function (f) { return ym - f * (H / 2 - 18); };
  axisArrow(ctx, x0, ym, x1 + 10, ym); axisArrow(ctx, X(0), H - 6, X(0), 8);
  sym(ctx, 'x', x1 + 10, ym - 12, { size: 13 }); sym(ctx, 'F', X(0) + 8, 12, { size: 13, align: 'left' });
  [[-1, '−R'], [1, 'R']].forEach(function (r) { var xx = X(r[0] * q.R); dotted(ctx, xx, 10, xx, H - 8, 'rgba(20,23,28,.2)', [3, 3]); label(ctx, r[1], xx, ym + 13, { size: 10.5 }); });
  label(ctx, 'mg', X(0) - 6, Y(1), { size: 10, align: 'right', color: '#5d6875' }); label(ctx, '−mg', X(0) - 6, Y(-1), { size: 10, align: 'right', color: '#5d6875' });
  ctx.save(); ctx.strokeStyle = COL.force; ctx.lineWidth = 2.6; ctx.beginPath(); ctx.moveTo(X(-q.R), Y(1)); ctx.lineTo(X(q.R), Y(-1)); ctx.stroke(); ctx.restore();
  label(ctx, '傾き −mg/R の直線', X(0.5 * q.R) + 8, Y(-0.5) - 8, { size: 10.5, color: COL.force, align: 'left', bold: true });
  ctx.save(); ctx.fillStyle = '#c0392b'; ctx.beginPath(); ctx.arc(X(st.x), Y(-st.x / q.R), 4.5, 0, TAU); ctx.fill(); ctx.restore();
}
function rightM2T(s, R) {
  var q = m2tQ(s);
  var h = '<div class="qcard"><p class="qt">① 小球にはたらく力を書く</p>' +
    '<p>地球の中心から $|x|$ の所では、<b>半径 $|x|$ の球の内がわの質量 $M\' = M\\left(\\dfrac{|x|}{R}\\right)^3$ だけが、中心に集まっているとみなせる</b>（外がわの殻からの万有引力は打ち消しあう）。</p>' +
    '<div class="qeq">$$F = -G\\frac{M\'m}{x^2}\\cdot\\frac{x}{|x|} = -\\frac{GMm}{R^3}x = -\\frac{mg}{R}x$$</div>' +
    '<p class="qnote">地表での重力 $mg = G\\dfrac{Mm}{R^2}$ より $GM = gR^2$ を使った。</p>' +
    '<p class="qt">② 運動方程式を $ma = -Kx$ の形にする</p>' + '<p class="eqline">' + eqTag('eom') + '$ma = -\\dfrac{mg}{R}x$</p><p>$K = \\dfrac{mg}{R}$。振動の中心は $x = 0$（地球の中心）。</p>' +
    '<p class="qt">③ $\\omega$・$T$ を読みとる</p>' + '<div class="qeq">$$\\omega = \\sqrt{\\frac{g}{R}},\\qquad T = 2\\pi\\sqrt{\\frac{R}{g}}$$</div>' +
    '<p class="qnow"><span class="qtag now">いまの値</span>$R = 6.37 \\times 10^6$ m、$g = 9.8$ m/s² より　$T = ' + sig2(q.T / 1000) + ' \\times 10^3$ s（約 ' + Math.round(q.T / 60) + ' 分）。放す位置 $x_0$ にはよらない。</p></div>' +
    '<div class="qcard"><p>地表より外から落とした場合や、初速度を与えた場合は、万有引力のページで扱っている。</p><p><a class="xlink" href="celestial-mechanics.html#m3-2">詳しくはこちら（万有引力・ケプラーの法則と天体物理学 ③-2 地球トンネル）</a></p></div>';
  R.innerHTML = mathify(h);
}
/* ---------- ②-8 振動の様子を並べた図（穴のまわりだけ・横長。2026-10-19 千葉さん） ----------
   ②-1 などと同じしくみ（m2Snaps）で描く。X は R を 1 とした位置。 */
DEFS.m2s8.snapO = {
  snapAsp: 0.5, snapKind: 'h',
  Q: function () { return { w: 1, off: 0 }; },
  snaps: function () {
    return [{ cap: 'ⓐ 静かに放す（$x = x_0$）', X: 0.8, hand: true, eq: '$F = -\\dfrac{mg}{R}x_0$' },
      { cap: 'ⓑ $x>0$ のとき（左へ）', X: 0.4, v: -0.87, eq: '$F = -\\dfrac{mg}{R}x < 0$' },
      { cap: 'ⓒ 中心 O を通る', X: 0, v: -1, eq: '$F = 0$（速さが最大）' },
      { cap: 'ⓓ $x<0$ のとき（左へ）', X: -0.4, v: -0.87, eq: '$F = -\\dfrac{mg}{R}x > 0$' }];
  },
  geo: function (s, box) {
    var W = box.w, H = box.h, S = (W - 40) / 2.25;
    return { W: W, H: H, cx: box.x0 + W / 2, cy: box.y0 + H * 0.52, S: S, X: function (x) { return box.x0 + W / 2 + x * S; } };
  },
  scene: function (s, ctx, g, st, opt) {
    var cy = g.cy, xl = g.X(-1), xr = g.X(1), bh = 24, th = 7, big = opt.big;
    ctx.save(); ctx.fillStyle = '#c6dbf1'; ctx.fillRect(xl, cy - bh, xr - xl, 2 * bh);           /* 地球の中（穴のまわりだけ） */
    ctx.fillStyle = '#f7f3ea'; ctx.fillRect(xl - 8, cy - th, xr - xl + 16, 2 * th);
    ctx.strokeStyle = '#6b7a8c'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(xl, cy - th); ctx.lineTo(xr, cy - th); ctx.moveTo(xl, cy + th); ctx.lineTo(xr, cy + th); ctx.stroke();
    ctx.strokeStyle = '#3f74a8'; ctx.lineWidth = 1.6; [xl, xr].forEach(function (x) { ctx.beginPath(); ctx.moveTo(x, cy - bh); ctx.lineTo(x, cy - th); ctx.moveTo(x, cy + th); ctx.lineTo(x, cy + bh); ctx.stroke(); });
    ctx.restore();
    label(ctx, '地表', xl - 3, cy - bh + 7, { size: 10, color: '#2f5f8f', align: 'right' }); label(ctx, '地表', xr + 3, cy - bh + 7, { size: 10, color: '#2f5f8f', align: 'left' });   /* 地表の外がわに（手と重ねない） */
    dotted(ctx, g.cx, cy - bh - 4, g.cx, cy + bh + 18, 'rgba(192,57,43,.6)', [4, 3]);
    axisArrow(ctx, xl - 6, cy + bh + 14, xr + 14, cy + bh + 14); sym(ctx, 'x', xr + 16, cy + bh + 3, { size: 13 });
    label(ctx, 'O', g.cx - 7, cy + bh + 25, { size: 10.5 });
    var bx = g.X(st.X), rb = big ? 7 : 6;
    if (opt.frame && opt.frame.hand) dropHand(ctx, bx + 4, cy + 1, big ? 0.34 : 0.3, 1, 1);
    ballShape(ctx, bx, cy, rb, '#c0392b');
    var L = -st.X * (big ? 52 : 44);
    if (Math.abs(L) > 2) fArrow(ctx, bx, cy, 1, 0, L, COL.force, 'F', { ly: 15, noShift: true });
    if (st.v) vArrowAt(ctx, bx, cy, 0, -1, bh + 6, 1, 0, st.v * 0.7 * (big ? 50 : 42), true);
  }
};
