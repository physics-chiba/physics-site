/* =========================================================================
   30_physics.js … 物理の計算だけ（純粋な関数。描画を混ぜない）
   記号は教科書（p.79〜87）にそろえる：変位 x・振幅 A・角振動数 ω・周期 T・速度 v・加速度 a・
   運動方程式 ma = −Kx（K：正の定数）、ばね定数 k、質量 m。
   単振動の式：x = A sin(ωt + φ)、v = Aω cos(ωt + φ)、a = −ω²x
   ========================================================================= */
'use strict';
var G = 9.8;
var TAU = Math.PI * 2;
function clamp(x, a, b) { return x < a ? a : (x > b ? b : x); }
function roundTo(x, step) { return Math.round(x / step) * step; }

var SHM = {
  /* 単振動の状態。phi＝初期位相。x0c＝振動の中心（ふつう 0） */
  st: function (A, w, phi, t, x0c) {
    var th = w * t + phi, s = Math.sin(th), c = Math.cos(th);
    return { x: (x0c || 0) + A * s, v: A * w * c, a: -A * w * w * s, th: th };
  },
  omega: function (K, m) { return Math.sqrt(K / m); },
  period: function (K, m) { return TAU * Math.sqrt(m / K); },
  /* 初期位置の選び方 → 振幅と初期位相。'end'＝端（x = +A）で静かに放す、'center'＝中心で正の向きに初速、
     数値＝ドラッグで離した位置 x0（そこで静かに放す） */
  initOf: function (mode, A) {
    if (mode === 'center') return { A: A, phi: 0 };
    if (typeof mode === 'number') return { A: Math.abs(mode), phi: mode >= 0 ? Math.PI / 2 : -Math.PI / 2 };
    return { A: A, phi: Math.PI / 2 };
  },
  /* エネルギー（水平ばね振り子・K = k） */
  energy: function (m, k, x, v) { var K = 0.5 * m * v * v, U = 0.5 * k * x * x; return { K: K, U: U, E: K + U }; }
};

/* ---------- モード1 の数値（2026-10-15 千葉さん：案A） ---------- */
var M1 = {
  s1: { A: 0.10, w: Math.PI },                               /* ①-1：等速円運動（T = 2.0 s） */
  s2: {                                                      /* ①-2：「大きく／小さく」のとびとびの値 */
    A: [0.04, 0.06, 0.08, 0.10, 0.12, 0.14],
    m: [0.25, 0.50, 0.75, 1.0, 1.25, 1.5], mW: 0.25,          /* 質量はおもりの個数（1 個 0.25 kg × 1〜6 個。2026-10-16 千葉さん） */
    k: [2.5, 5, 10, 20, 40],
    A0: 0.10, m0: 0.50, k0: 5   /* k の既定は 5 N/m（2026-10-18 千葉さん） */
  },
  s3: { m: 1.0, k: 3.2, A: 0.10, Amax: 0.15 }                /* ①-3：水平ばね振り子（T = 3.5 s：ゆっくり見せる。2026-10-15 千葉さん） */
};
/* 時間バーの長さ：周期の 8 倍（12〜40 s） */
function tBarOf(T) { return clamp(8 * T, 12, 40); }

/* ---------- モード2 の数値（2026-10-15 千葉さん：案A。ふだんは実際よりゆっくり再生） ---------- */
var M2 = {
  s1: { m: 0.10, k: 20, A: 0.10, Amax: 0.15 },                         /* ②-1 水平ばね振り子（弾性力 kA が重力 mg より大きくなるよう、軽いおもりで速く振動。1/4 の速さで再生。2026-10-16 千葉さん） */
  s2: { m: 0.10, k: [10, 20, 40], A: 0.10, Amax: 0.15 },               /* ②-2 両側ばね（k₁・k₂）。②-1 と同じく弾性力が目立つように。1/5 の速さで再生 */
  s3: { m: 0.50, k: 10, L0: 0.50, A: 0.20, Amax: 0.30 },               /* ②-3 鉛直ばね振り子（d = mg/k = 0.49 m） */
  s4: { m: 0.50, k: 10, L0: 0.40, A: 0.12, Amax: 0.18, th: [15, 30, 45, 60] },   /* ②-4 斜面（d = mg sinθ/k） */
  s5: { m: 0.50, k: 10, mu: [0.20, 0.30], mu2: [0.05, 0.10, 0.15], X0: [0.20, 0.30, 0.40] },   /* ②-5 摩擦（μ・μ′） */
  s6: { l: [0.25, 0.50, 1.0, 2.0], m: [0.10, 0.50, 1.0], th: [5, 10, 15] },     /* ②-6 単振り子（振れ幅は小さい） */
  s7: { rho: 1.0e3, S: [0.005, 0.010, 0.020], rb: [0.25e3, 0.50e3, 0.75e3], Hb: 0.20, d: [0.02, 0.04] }  /* ②-7 浮力 */
};
/* ②-5：あらい水平面のばね振り子。半周期ごとに中心が ±μ′mg/k に入れかわる。止まった位置で |kx| ≦ μmg なら止まったまま。
   戻り値：{ segs:[{t0, t1, c, x0}], tStop, xStop, w } */
function frictionSegs(m, k, mu, mu2, X0) {
  var w = Math.sqrt(k / m), Th = Math.PI / w, xf = mu2 * m * G / k, xs = mu * m * G / k;
  var segs = [], t = 0, x = X0;
  for (var i = 0; i < 60; i++) {
    if (Math.abs(x) <= xs + 1e-12) break;                     /* 静止摩擦で止まったまま */
    var c = x > 0 ? xf : -xf;                                 /* 左へ動くとき摩擦は右向き → 中心は +xf */
    var x1 = 2 * c - x;
    segs.push({ t0: t, t1: t + Th, c: c, x0: x });
    t += Th; x = x1;
  }
  return { segs: segs, tStop: t, xStop: x, w: w, xf: xf, xs: xs };
}
function frictionAt(F, t) {
  for (var i = 0; i < F.segs.length; i++) {
    var g = F.segs[i];
    if (t <= g.t1 + 1e-12) {
      var tau = Math.max(0, t - g.t0), cs = Math.cos(F.w * tau), sn = Math.sin(F.w * tau), u = g.x0 - g.c;
      return { x: g.c + u * cs, v: -u * F.w * sn, a: -F.w * F.w * u * cs, seg: i, moving: true };
    }
  }
  return { x: F.xStop, v: 0, a: 0, seg: -1, moving: false };
}
