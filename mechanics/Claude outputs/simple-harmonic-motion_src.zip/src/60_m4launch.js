/* =========================================================================
   60_m4launch.js … ④-1 ばねで打ち出される小球（spring-launch.html をもとに。2026-10-18 千葉さん）
   左の壁にばね（k）、右端に小球（m）。自然の長さから d 縮めて放す。x：自然の長さの位置が原点、右向きが正。
   問1：自然の長さで小球が離れる（そのあとは等速）。問2：離れない（単振動を続ける）。
   左上に問題文、右上に「解説はこちら」（PDF）だけ。
   ========================================================================= */
'use strict';
var M4G = '#1f7a3f', M4O = '#d0801f';                               /* ④-5 と同じ：緑＝単振動、オレンジ＝等速直線運動 */
var M40 = { m: 1.0, k: 50, L0: 0.55, ds: [0.10, 0.15, 0.20], d0: 0.20 };
function m4s0Q(s) { var w = Math.sqrt(M40.k / M40.m), d = s.v.d; return { m: M40.m, k: M40.k, w: w, T: TAU / w, d: d, v0: d * w, tq: Math.PI / 2 / w, th: 2 * Math.PI / 3 / w, p2: s.prob === 2 }; }
function m4s0At(q, t) {
  if (q.p2 || t <= q.tq) return { x: -q.d * Math.cos(q.w * t), v: q.d * q.w * Math.sin(q.w * t), on: true };
  return { x: q.v0 * (t - q.tq), v: q.v0, on: false };
}
DEFS.m4s0 = {
  id: 'm4s0', mode: 'mode4', num: 1, title: 'ばねで打ち出される小球', short: 'ばねで打ち出される小球',
  wideHead: true,                                                 /* 問題文は左右の列をまとめて横いっぱい・2 列（2026-10-18 千葉さん） */
  desc2: ['<p>なめらかな水平面の上で、左の壁に固定したばね定数 $k$ の軽いばねの右端に、質量 $m$ の小球をおく。自然の長さの位置を原点 O とし、右向きを $x$ の正の向きとする。ばねを自然の長さから $d$ だけ縮めてから、静かに放す。</p>' +
    '<p class="m4pq"><b>問1</b>　ばねが自然の長さの位置まで来たら、小球はばねから離れるとする。<br>(1) 放してから自然の長さに至るまでの時間はいくらか。<br>(2) $x = \\dfrac{1}{2}d$ のときの小球の速さはいくらか。</p>',
    '<p class="m4pq"><b>問2</b>　ばねと小球がくっついており、ばねが自然の長さの位置まで来ても<b>小球は離れない</b>とする。<br>(1) 放してから $x = \\dfrac{1}{2}d$ に至るまでの時間はいくらか。<br>(2) $x = \\dfrac{1}{2}d$ のときの小球の速さはいくらか。</p>'],
  desc: '<span class="todo">図の左上で問1・問2を切りかえて、自然の長さを過ぎたあとの運動の違いと、$x = \\dfrac{1}{2}d$ を通る時刻を確かめよう。</span>',
  strobe: false, showFBtn: true, fDefault: 'net', vecBtn: 'v を消す', belowCanvas: true, baseRate: 0.4,
  exam: { src: '', pdf: 'shm-launch', noProb: true, prob: function () { return ''; }, ans: function () { return m4s0Ans(); }, fig: function (k, ctx, W, H) { m4s0Fig(k, ctx, W, H); } },
  buttons: [
    { k: 'p1', label: '問1 自然の長さで離れる', cls: 'm4only on', inCanvas: true, onClick: function (s) { m4s0Prob(s, 1); } },
    { k: 'p2', label: '問2 離れない', cls: 'm4only', inCanvas: true, onClick: function (s) { m4s0Prob(s, 2); } }],
  vars: [{ k: 'd', label: '縮める長さ $d$', stops: M40.ds, stopLabels: ['0.10', '0.15', '0.20 m'], def: M40.d0, aria: '縮める長さ', fmt: function (x) { return x.toFixed(2) + ' m'; } }],
  init: function (s) { s.prob = 1; },
  onDefaults: function (s) { m4s0Prob(s, 1); },
  onChanged: function () { return 'stop'; },
  tEnd: function (s) { var q = m4s0Q(s); return q.p2 ? 2 * q.T : q.tq + 0.55; },
  tInfo: function (s) { return periodInfo(m4s0Q(s).T) + '<span class="tnote">（ばねについている間）</span>'; },
  gT: function (s) { return m4s0Q(s).T; },
  height: function (s, w) { return Math.round(clamp(w * 0.40, 220, 290)); },
  afterBuild: function (s) {
    s.R.innerHTML = '';
    ctlOneRow(s);                                                 /* 縮める長さの右に時間バー */
    var cc = el('div', 'qcard m4card m4circ'); cc.innerHTML = mathify('<p class="qt">対応する等速円運動（半径 $d$）</p>'); s.cCv = el('canvas', 'm4cv'); cc.appendChild(s.cCv); s.below.appendChild(cc);
    m4Card(s, '<p class="qt">かかる時間は、対応する等速円運動で考える</p>' +       /* x–t グラフの上の解説（2026-10-19 千葉さん） */
      '<ul class="m4tl"><li><b>問1(1)</b>　左の端 → 自然の長さの位置（中心）は、円運動で $\\dfrac{\\pi}{2}$ 回るので <b>$\\dfrac{1}{4}$ 周期</b>。</li>' +
      '<li><b>問2(1)</b>　左の端 → $x = \\dfrac{1}{2}d$ は、円運動で $\\dfrac{2\\pi}{3}$ 回るので <b>$\\dfrac{1}{3}$ 周期</b>。</li></ul>' +
      '<p class="m4miss"><b>ありがちなミス</b>　小球が等速で動くと考えて「$2d$ を $\\dfrac{1}{2}$ 周期で進むから、$\\dfrac{3}{2}d$ なら $\\dfrac{3}{8}$ 周期」と書いてしまう人が多い。単振動は中心で速く、端で遅いので、時間は進んだ距離に比例しない。アニメの下の等速円運動で、点がどれだけの角度を回ったかをよくイメージしよう。</p>');
    m4Card(s, '<p class="qt">$x$–$t$ グラフ<span class="qtsub">（<span style="color:#1f7a3f">緑：単振動</span>／<span style="color:#d0801f">オレンジ：等速直線運動</span>）</span></p>'); s.xCv = el('canvas', 'm4cv'); s.R.lastChild.appendChild(s.xCv);
    m4Card(s, '<p class="qt">$v$–$t$ グラフ<span class="qtsub">（<span style="color:#1f7a3f">緑：単振動</span>／<span style="color:#d0801f">オレンジ：等速直線運動</span>）</span></p>'); s.vCv = el('canvas', 'm4cv'); s.R.lastChild.appendChild(s.vCv);
    s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);
    /* 問1・問2 の下に、小問ごとのボタン：押すと最初から再生して、その場面で止まる（2026-10-19 千葉さん） */
    var tl = s.cw.querySelector('.cvbtns'); tl.classList.add('m4s0q'); tl.appendChild(el('span', 'cvbrk'));
    s.qBtns = [];
    [[1, 1, '問1 (1)'], [1, 2, '問1 (2)'], [2, 1, '問2 (1)'], [2, 2, '問2 (2)']].forEach(function (p) {
      var b = el('button', 'b m4only m4qb'); b.type = 'button'; b.textContent = p[2];
      b.title = p[0] === 1 && p[1] === 1 ? '自然の長さに至るまで' : 'x = d/2 に至るまで';
      b.addEventListener('click', function () { m4s0Go(s, p[0], p[1], b); }); tl.appendChild(b); s.qBtns.push(b);
    });
  },
  draw: function (s, ctx, W, H) { drawM4S0(s, ctx, W, H); drawM4S0G(s); drawM4S0C(s); }   /* 右の列は上に詰める（アニメの上のはしにはそろえない。2026-10-19 千葉さん） */,
  msg: function (s) {
    var q = m4s0Q(s), st = m4s0At(q, s.t);
    if (s.t === 0 && !s.playing) return 'ばねを $d$ 縮めて、手で押さえている。▶ スタートで放す。';
    if (!st.on) return '自然の長さで弾性力が 0 になり、小球は離れた。そのあとは速さ $v_0 = d\\sqrt{\\dfrac{k}{m}} = ' + fmt(q.v0, 2) + '$ m/s の等速直線運動。';
    return q.p2 ? '小球はばねにつながれたまま、自然の長さの位置（O）を中心に振幅 $d$ の単振動を続ける。' : 'ばねが自然の長さになるまでは、O を中心とする単振動（の一部）。';
  },
  right: function () { }
};
/* 対応する等速円運動（②-1 と同じく図の下。横の位置はアニメと同じ縮尺。中心は O の真下） */
function drawM4S0C(s) {
  var cv = s.cCv; if (!cv || !cv.offsetParent) return;
  var q = m4s0Q(s), W = Math.max(240, Math.floor(cv.clientWidth || 300)), S = (W - 60) / (M40.L0 + 0.95 + 0.06), R = q.d * S, H = Math.round(2 * R + 54), ctx = prep(cv, W, H);
  var X0 = 24 + M40.L0 * S, cy = R + 18, st = m4s0At(q, s.t), tc = (q.p2 || st.on) ? s.t : q.tq, th = q.w * tc - Math.PI / 2;
  ctx.save(); ctx.strokeStyle = '#8d9097'; ctx.lineWidth = 1.3; ctx.beginPath(); ctx.arc(X0, cy, R, 0, TAU); ctx.stroke(); ctx.restore();
  dotted(ctx, X0, cy - R - 10, X0, cy + R + 10, 'rgba(20,23,28,.35)', [3, 3]);                    /* 基準の直径（縦） */
  var P = { x: X0 + R * Math.sin(th), y: cy + R * Math.cos(th) }, p0 = { x: X0 - R, y: cy };
  dotted(ctx, X0, cy, p0.x, p0.y, 'rgba(20,23,28,.55)', [3, 3]); label(ctx, '始まり', p0.x - 6, p0.y, { size: 10, color: '#5d6875', align: 'right' });
  ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(X0, cy); ctx.lineTo(P.x, P.y); ctx.stroke(); ctx.restore();
  if (tc > 0.005) { var ra = Math.min(26, R * 0.55), a0 = Math.PI, a1 = Math.PI - q.w * tc; ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.3; ctx.beginPath(); ctx.arc(X0, cy, ra, a0, a1, true); ctx.stroke(); ctx.restore(); sym(ctx, 'ωt', X0 + (ra + 12) * Math.cos(Math.PI - q.w * tc / 2), cy + (ra + 12) * Math.sin(Math.PI - q.w * tc / 2), { size: 12 }); }
  var xh = X0 + q.d / 2 * S; dotted(ctx, xh, 4, xh, H - 4, 'rgba(192,57,43,.55)', [4, 3]); label(ctx, 'x = d/2', xh + 4, H - 10, { size: 10, color: '#c0392b', align: 'left' });
  dotted(ctx, P.x, P.y, P.x, 0, 'rgba(22,99,181,.6)', [3, 4]);                                     /* 真上の小球へ（正射影） */
  ballShape(ctx, P.x, P.y, 5.5, M2BALL);
  if (!q.p2 && !st.on) label(ctx, '離れたあとは、円運動と対応しない（等速直線運動）', X0 + R + 14, cy, { size: 10.5, color: '#a85c0c', bold: true, align: 'left' });
}
/* 右の列のいちばん上（グラフ）を、アニメの上のはしにそろえる */
function m4AlignTop(s) {
  if (s.playing) return; var first = s.R.querySelector('.m4card'); if (!first || !s.cw) return;
  first.style.marginTop = '0px'; var d = s.cw.getBoundingClientRect().top - first.getBoundingClientRect().top;
  if (window.innerWidth > 880 && d > 0) first.style.marginTop = Math.round(d) + 'px';
}
function m4s0Prob(s, k) { s.prob = k; m4Seg(s, [[1, 'p1'], [2, 'p2']], k); (s.qBtns || []).forEach(function (b) { b.classList.remove('on'); }); if (s.cv) { s.resetT(); s.draw(); } }
/* 小問のボタン：問1(1) は自然の長さまで、問1(2)・問2(1)(2) は x = d/2 まで再生して止める */
function m4s0Go(s, p, part, btn) {
  m4s0Prob(s, p); btn.classList.add('on');
  var q = m4s0Q(s), t1 = p === 1 ? (part === 1 ? q.tq : q.tq + 0.5 / q.w) : q.th;
  s.playWindow(0, t1, s.base * (s.slow ? 0.3 : 1));
}
function m4s0Scene(ctx, W, H, q, st, o) {
  o = o || {};
  var S = (W - 60) / (M40.L0 + 0.95 + 0.06), xw = 24, yF = H - (o.mini ? 26 : 50), rb = o.mini ? 10 : 15, X = function (x) { return xw + (M40.L0 + x) * S; };
  floorAt(ctx, xw, W - 10, yF); wallLeftAt(ctx, xw, yF - (o.mini ? 46 : 70), yF);
  var yc = yF - rb, xb = X(st.x), xs = st.on ? xb - rb : X(0) - rb;  /* 離れたあとのばねの端は自然の長さで止まる（ばねは軽い） */
  springDense(ctx, xw, yc, xs, yc, M40.L0 * S - rb, { r: o.mini ? 6 : 9, lead: 5, k: q.k, thin: o.mini ? 0.7 : 1, Lmin: (M40.L0 - 0.2) * S - rb });
  dotted(ctx, X(0), yF - (o.mini ? 40 : 66), X(0), yF + (o.mini ? 6 : 18), 'rgba(20,23,28,.4)', [4, 3]);
  dotted(ctx, X(q.d / 2), yF - (o.mini ? 40 : 66), X(q.d / 2), yF + (o.mini ? 6 : 18), 'rgba(192,57,43,.6)', [4, 3]);
  if (!o.mini) {
    label(ctx, 'O（自然の長さ）', X(0) - 4, yF + 30, { size: 10.5, color: '#5d6875', align: 'right' });
    label(ctx, 'x = d/2', X(q.d / 2) + 4, yF + 30, { size: 10.5, color: '#c0392b', bold: true, align: 'left' });
    axisArrow(ctx, X(-0.3), yF + 14, W - 14, yF + 14); sym(ctx, 'x', W - 16, yF + 2, { size: 13 });
  }
  ballShape(ctx, xb, yc, rb, '#d9b77a');
  return { X: X, yF: yF, yc: yc, xb: xb, rb: rb, S: S };
}
function drawM4S0(s, ctx, W, H) {
  var q = m4s0Q(s), st = m4s0At(q, s.t), g = m4s0Scene(ctx, W, H, q, st), held = s.t === 0 && !s.playing;
  if (W > 520) label(ctx, q.p2 ? '問2：離れない（単振動を続ける）' : '問1：自然の長さで離れる', W - 12, 16, { size: 11.5, bold: true, color: '#1f4f8a', align: 'right' });
  if (held) { m4Hand(ctx, g.xb + g.rb, g.yc, -1, 0, 0.34); }
  if (!s.hideVec && Math.abs(st.v) > 0.02) vArrowAt(ctx, g.xb, g.yc - g.rb, 0, -1, 30, 1, 0, st.v / q.v0 * 46, true);
  if (s.fmode) {
    var fs = 46 / (q.k * q.d), F = st.on ? -q.k * st.x : 0, fv = 22;
    if (fNet(s)) netArrow(ctx, g.xb - g.rb, g.yc, 1, 0, F * fs, 'F', { ly: -14 });
    else {
      if (Math.abs(F) > 1e-6) fArrow(ctx, g.xb - g.rb, g.yc, 1, 0, F * fs, COL.hand, '弾性力', { ly: -14, noShift: true });
      fArrow(ctx, g.xb - 5, g.yc, 0, 1, fv, COL.force, 'mg', { lx: -12, noShift: true }); fArrow(ctx, g.xb + 5, g.yF, 0, -1, fv, COL.norm, 'N', { lx: 12, noShift: true });
    }
  }
  if (!st.on) label(ctx, '離れた → 等速直線運動', g.xb, g.yc - g.rb - 60, { size: 11.5, bold: true, color: '#a85c0c' });
  drawEqualTicks(ctx);
}
function drawM4S0G(s) {
  var q = m4s0Q(s), t1 = q.p2 ? 2 * q.T : q.tq + 0.55, hl = [{ y: q.d / 2, txt: 'x = d/2', col: '#c0392b' }];
  var mk = function (cv) { return cv; };
  m4Plot(s.xCv, { t0: 0, t1: t1, lo: -q.d * 1.15, hi: q.p2 ? q.d * 1.15 : q.v0 * 0.55 * 1.05, cur: s.t, ylab: 'x', yunit: 'm', H: 166, hl: hl,   /* 前の 80 %＋上の運動の名前の場所 */
    zones: q.p2 ? [{ t0: 0, t1: t1, txt: '単振動（ばねとくっついたまま）', col: M4G }] : [{ t0: 0, t1: q.tq, txt: '単振動', col: M4G }, { t0: q.tq, t1: t1, txt: '等速直線運動', col: M4O }],
    ser: [{ col: M4G, w: 2.6, seg: function (t) { return m4s0At(q, t).on ? M4G : M4O; }, f: function (t) { return m4s0At(q, t).x; } }] });
  m4Plot(s.vCv, { t0: 0, t1: t1, lo: q.p2 ? -q.v0 * 1.15 : -0.05, hi: q.v0 * 1.15, cur: s.t, ylab: 'v', yunit: 'm/s', H: 128, hl: [{ y: q.v0, txt: 'v₀ = dω', col: COL.vel }],
    ser: [{ col: M4G, w: 2.6, seg: function (t) { return m4s0At(q, t).on ? M4G : M4O; }, f: function (t) { return m4s0At(q, t).v; } }] });   /* ④-5 と同じ色分け（緑：単振動／オレンジ：等速直線運動。2026-10-25 千葉さん） */
  [s.xCv, s.vCv].forEach(function (cv) { if (!cv || !cv.offsetParent) return; var ctx = cv.getContext('2d'), W = Math.max(240, Math.floor(cv.clientWidth)), x0 = 44, x1 = W - 18, Hh = cv.height / (window.devicePixelRatio || 1);
    ctx.save(); ctx.setTransform(window.devicePixelRatio || 1, 0, 0, window.devicePixelRatio || 1, 0, 0);
    (q.p2 ? [[q.th, 'T/3', '#c0392b'], [q.tq, 'T/4', '#5d6875']] : [[q.tq, 'T/4', '#5d6875']]).forEach(function (r) { var xx = x0 + r[0] / t1 * (x1 - x0); dotted(ctx, xx, cv === s.xCv ? 46 : 14, xx, Hh - 22, r[2] === '#c0392b' ? 'rgba(192,57,43,.55)' : 'rgba(20,23,28,.3)', [3, 3]); label(ctx, r[1], xx + (r[1] === 'T/3' ? 3 : -3), Hh - 8, { size: 10, color: r[2], bold: true, align: r[1] === 'T/3' ? 'left' : 'right' }); });   /* T/4 は線の左、T/3 は右に（重ならないように） */
    ctx.restore(); });
}
function m4s0Ans() {
  return '<h4 class="exh">時間の流れで見る</h4>' +
    exStrip([['a', 'ⓐ 放す直前', '$x = -d$、$v = 0$'], ['b', 'ⓑ 自然の長さ', '$t = \\dfrac{T}{4}$、速さ最大 $d\\omega$'], ['c', 'ⓒ 問1：$x = \\dfrac{1}{2}d$', '離れたあと。等速 $d\\omega$'], ['d', 'ⓓ 問2：$x = \\dfrac{1}{2}d$', '$t = \\dfrac{T}{3}$'], ['e', 'ⓔ 問2：$x = d$', '$t = \\dfrac{T}{2}$。ここで戻る']], 90, true) +
    '<h4 class="exh">考え方</h4><div class="exbox"><p>ばねに触れている間、小球は O（自然の長さの位置）を中心とする振幅 $d$ の単振動をする。$\\omega = \\sqrt{\\dfrac{k}{m}}$、$T = 2\\pi\\sqrt{\\dfrac{m}{k}}$。$t = 0$ で $x = -d$（左の端）から静かに放すので、初期位相 $\\phi = -\\dfrac{\\pi}{2}$：</p>' +
    '<p style="text-align:center">$x = d\\sin\\left(\\omega t - \\dfrac{\\pi}{2}\\right) = -d\\cos\\omega t$、　$v = d\\omega\\cos\\left(\\omega t - \\dfrac{\\pi}{2}\\right) = d\\omega\\sin\\omega t$</p></div>' +
    '<h4 class="exh">問1（自然の長さで離れる）</h4>' +
    exQA('(1) 自然の長さに至るまでの時間', '$t = \\dfrac{T}{4} = \\dfrac{\\pi}{2}\\sqrt{\\dfrac{m}{k}}$', '<p>$x = -d\\cos\\omega t = 0$ となるのは $\\omega t = \\dfrac{\\pi}{2}$。左の端から中心までは $\\dfrac{1}{4}$ 周期。</p>') +
    exQA('(2) $x = \\dfrac{1}{2}d$ での速さ', '$v = d\\sqrt{\\dfrac{k}{m}}$', '<p>$x = \\dfrac{1}{2}d$ は自然の長さの位置 O より右。小球は O でばねから離れ、そのあとは力を受けないので、O での速さ（単振動の速さの最大値）$v_0 = d\\omega = d\\sqrt{\\dfrac{k}{m}}$ のまま等速直線運動をする。</p>' +
      '<p>エネルギー保存則で求めてもよい：$\\dfrac{1}{2}kd^2 = \\dfrac{1}{2}mv^2$（離れたあと、ばねの弾性エネルギーは 0）。</p>') +
    '<h4 class="exh">問2（離れない）</h4>' +
    exQA('(1) $x = \\dfrac{1}{2}d$ に至るまでの時間', '$t = \\dfrac{T}{3} = \\dfrac{2\\pi}{3}\\sqrt{\\dfrac{m}{k}}$', '<p>$-d\\cos\\omega t = \\dfrac{1}{2}d$ より $\\cos\\omega t = -\\dfrac{1}{2}$、はじめて成りたつのは $\\omega t = \\dfrac{2\\pi}{3}$。対応する円運動で、点が $\\dfrac{2\\pi}{3}$ だけ回ったとき（$\\dfrac{1}{3}$ 周）。</p>' +
      '<p><b>ありがちなミス</b>　「$-d$ から $d$ までの $2d$ を半周期 $\\dfrac{T}{2}$ で進むから、$\\dfrac{3}{2}d$ 進むのは $\\dfrac{3}{4} \\times \\dfrac{T}{2} = \\dfrac{3}{8}T$」としてしまう。これは小球が<b>等速</b>で動くと考えたときの答え。単振動では中心ほど速く、端ほど遅いので、時間は距離に比例しない。対応する等速円運動で、回った角度 $\\dfrac{2\\pi}{3}$ から求める。</p>') +
    exQA('(2) $x = \\dfrac{1}{2}d$ での速さ', '$v = \\dfrac{\\sqrt{3}}{2}d\\sqrt{\\dfrac{k}{m}}$',
      '<p><b>解法 A（速度の式を使う）</b>　$v = d\\omega\\sin\\omega t$ に $\\omega t = \\dfrac{2\\pi}{3}$ を入れて $v = d\\omega \\cdot \\dfrac{\\sqrt{3}}{2} = \\dfrac{\\sqrt{3}}{2}d\\sqrt{\\dfrac{k}{m}}$。（$x = A\\sin(\\omega t + \\phi)$ のとき $v = A\\omega\\cos(\\omega t + \\phi)$ を使った。）</p>' +
      '<p><b>解法 B（エネルギー保存則を使う）</b>　$\\dfrac{1}{2}kd^2 = \\dfrac{1}{2}mv^2 + \\dfrac{1}{2}k\\left(\\dfrac{d}{2}\\right)^2$ より $v^2 = \\dfrac{3kd^2}{4m}$、$v = \\dfrac{\\sqrt{3}}{2}d\\sqrt{\\dfrac{k}{m}}$。</p>' +
      '<p>時間を聞かれていなければ、解法 B のほうが速い。時間が必要なら、解法 A（または対応する円運動）を使う。問1(2) との違い（ばねにつながっているので、$x > 0$ ではばねが伸びて小球を引き戻し、遅くなる）にも注意。</p>');
}
function m4s0Fig(key, ctx, W, H) {
  var q = m4s0Q({ v: { d: 0.20 }, prob: (key === 'd' || key === 'e') ? 2 : 1 }), t = { a: 0, b: q.tq, c: q.tq + 0.5 / q.w, d: q.th, e: q.T / 2 }[key], st = m4s0At(q, t);
  var g = m4s0Scene(ctx, W, H, q, st, { mini: true });
  if (key === 'a') m4Hand(ctx, g.xb + g.rb, g.yc, -1, 0, 0.24);
  if (Math.abs(st.v) > 0.02) vArrowAt(ctx, g.xb, g.yc - g.rb, 0, -1, 8, 1, 0, st.v / q.v0 * 26, false);
  var F = st.on ? -q.k * st.x : 0; if (Math.abs(F) > 1e-6) fArrow(ctx, g.xb - g.rb, g.yc + 3, 1, 0, F * 22 / (q.k * q.d), COL.hand, null, { noShift: true });
  drawEqualTicks(ctx);
}
