/* =========================================================================
   80_page.js … ページの組み立て（ヒーロー・タブ列・章の扉・セクションのカード・コンテンツ一覧・アドレス）
   デザイン統一キット（momentum-and-collision.html）の骨組みと同じ。
   ========================================================================= */
'use strict';
var MODES = [
  { id: 'mode1', name: '単振動の基本的な物理量', secs: ['m1s1', 'm1s2', 'm1s3'], rotSwitch: false,
    en: 'Describing Simple Harmonic Motion',
    lead: '一直線上の往復振動を単振動という。単振動は、等速円運動を真横から見た影（数学的には正射影と呼ぶ）で理解することができる。変位 $x$・速度 $v$・加速度 $a$ が常に変わり、正負が変化する運動である。単振動を理解するために、等速円運動と見比べ、グラフを元に考えよう。円運動がまだ理解不十分な人は <a class="xlink" href="circular-motion.html#mode1">等速円運動のページ（モード①）</a> を参照。' },
  { id: 'mode2', name: '色んな単振動', secs: ['m2s1', 'm2s2', 'm2s3', 'm2s4', 'm2s5', 'm2s6', 'm2s7', 'm2s8'], rotSwitch: false,
    en: 'Oscillations in Various Settings',
    lead: 'ばね・振り子・浮力など、いろいろな単振動がある。どれも ① 力を書き、② 運動方程式を $ma=-K(x-x_0)$ の形にすれば、③ 振動の中心 $x_0$・角振動数 $\\omega=\\sqrt{\\dfrac{K}{m}}$・周期 $T=2\\pi\\sqrt{\\dfrac{m}{K}}$ が読み取れる。単振動は必ず、<b>つりあいの位置を中心として</b>振動する。' },
  { id: 'mode3', name: '「単振動」で理解すべき3つのこと', secs: ['m3s1', 'm3s2', 'm3s3'], rotSwitch: false,
    en: 'Essentials for Exam-Level Problems',
    lead: '3つのことを理解することを意識して問題演習しよう。周期が何で決まるか、つりあいの位置からの変位 $x$ を使った単振動のエネルギー $U=\\dfrac{1}{2}Kx^2$、そして $x$ 座標の原点のとり方。' },
  { id: 'mode4', name: '入試物理', secs: ['m4s0', 'm4s1', 'm4s2', 'm4s3', 'm4s4', 'm4s5'], rotSwitch: false,
    en: 'Exam-Level Problems',
    lead: '単振動は力学最高峰の難易度であり、かつ応用範囲もとても広いです。それでいて波動分野の基礎でもあるので、習得必須です。各シミュレーションには問題を添付しているので、まず自分で問題を解き、答えは「解答」を開いて確かめよう。その後アニメーションを確認し、自分で図を何度も書いて頭の中で「単振動」を再現できるようにしてください。' }
];
var CIRC = '①②③④⑤⑥⑦⑧⑨';
var GLOBAL = { hideEq: false, rot: false };
/* アドレスに ?rot=1 があれば、最初から「全て：一緒に円運動する観測者（非慣性系）から見る」を ON（2026-10-11 千葉さん） */
try { GLOBAL.rot = /(?:^|[?&])rot=(1|on|true)(?:&|$)/i.test(location.search); } catch (e) { }
var SIM_BY_ID = {}, MODE_BUILT = {};

function buildPage() {
  var wrap = document.getElementById('wrap'), h = '';
  document.getElementById('hero').innerHTML =
    '<div class="hero-in">' +
      '<div class="hero-top">' +
        '<nav class="crumbs" aria-label="現在地"><a class="crumb-home" href="' + SITE_HOME + '" title="楽楽（らくらく）高校物理のトップページへ"><svg class="atom" viewBox="0 0 32 32" aria-hidden="true"><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#3ea0e0" stroke-width="2"/><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#7b5bd6" stroke-width="2" transform="rotate(60 16 16)"/><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#e07b18" stroke-width="2" transform="rotate(120 16 16)"/><circle cx="16" cy="16" r="3.6" fill="#5aa7ff"/></svg><span>楽楽（らくらく）高校物理</span></a><span class="cs" aria-hidden="true">/</span><a class="crumb" href="' + SITE_HOME + '#sec-mechanics">力学</a><span class="cs" aria-hidden="true">/</span><span class="crumb now" aria-current="page">単振動</span><span class="kdot"></span><span class="en">Simple Harmonic Motion</span></nav>' +
        '<div class="topbtns" role="group" aria-label="ページ全体の表示"><button id="btnEq" type="button"></button></div>' +
      '</div>' +
      '<h1 class="hero-title"><span class="t1"><span class="nb" data-sh="単振動">単振動</span></span><span class="t2">〜等速円運動の影として見る〜</span></h1>' +
      '<div class="introrow">' +
        '<p class="lead2">ばねにつけたおもりの往復運動は、等速円運動を真横から見た影の運動と同じ。振動の中心・振幅・周期を読み取り、エネルギーまで理解しよう。</p>' +
        '<button id="bToc" class="tocbtn" type="button" aria-haspopup="true" aria-expanded="false"><span class="ti" aria-hidden="true"></span>コンテンツ一覧</button>' +
      '</div>' +
      '<div id="tocpanel" class="tocpanel" hidden></div>' +
      '<figure class="stage" aria-label="等速円運動する点の高さと、鉛直ばね振り子のおもりの高さはいつも同じ。おもりの位置を時間の経過とともに並べると正弦曲線になる">' +
        '<canvas id="heroCv"></canvas>' +
        '<figcaption class="stagecap"><span class="live" aria-hidden="true"></span><span class="sct">等速円運動する点（左）の高さと、ばねにつけたおもり（中）の高さは、いつも同じ。おもりの位置を時間の経過とともに右へ並べると（右）、正弦曲線になる。</span>' +
        '<span class="stagectl" role="group" aria-label="アニメの操作"><button type="button" class="slow" aria-pressed="false" title="ゆっくり再生">🐢 スロー</button><button type="button" class="pp" aria-label="一時停止"><i></i></button></span></figcaption>' +
      '</figure>' +
      '<ol class="ideas">' +
        '<li><a href="#mode1"><span class="in" aria-label="①"><b>1</b></span><span class="ie">$x=A\\sin(\\omega t+\\phi)$</span><span class="ij">単振動は等速円運動の影</span><span class="ia" aria-hidden="true">→</span></a></li>' +
        '<li><a href="#mode2"><span class="in" aria-label="②"><b>2</b></span><span class="ie">$ma=-K(x-x_0)$</span><span class="ij">振動の中心はつりあいの位置</span><span class="ia" aria-hidden="true">→</span></a></li>' +
        '<li><a href="#3-2"><span class="in" aria-label="③"><b>3</b></span><span class="ie">$\\dfrac{1}{2}mv^2+\\underset{U}{\\underline{\\dfrac{1}{2}Kx^2}}=$ 一定</span><span class="ij">$x$ はつりあいの位置からの変位</span><span class="ia" aria-hidden="true">→</span></a></li>' +
      '</ol>' +
    '</div>';
  document.getElementById('tabs').innerHTML = '<div class="tabs-in"><div class="navsite"><a class="navhome" href="' + SITE_HOME + '" aria-label="ホーム（楽楽高校物理のトップページ）" title="ホーム（楽楽高校物理のトップページ）"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3.5 10.8 12 4l8.5 6.8" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M6 9.5V20h4.5v-5.5h3V20H18V9.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg></a><button class="navpages" id="bPages" type="button" aria-haspopup="dialog" aria-expanded="false" aria-controls="siteDrawer"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="3.5" width="7" height="7" rx="1.6" fill="currentColor"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.6" fill="currentColor" opacity=".55"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.6" fill="currentColor" opacity=".55"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.6" fill="currentColor"/></svg><span>ページ一覧</span></button></div>' +
    MODES.map(function (m, i) { return '<button class="tab" type="button" data-mode="' + m.id + '"><span class="tn">' + CIRC[i] + '</span><span class="tl">' + m.name + '</span></button>'; }).join('') +
    '</div><span class="tprog" aria-hidden="true"></span>';

  MODES.forEach(function (m, i) {
    h += '<section class="mode" id="' + m.id + '">' +
      '<header class="modehead"><div class="mh-num" aria-hidden="true"><span>' + (i + 1) + '</span></div><div class="mh-body"><p class="mh-en">Chapter ' + String(i + 1).padStart(2, '0') + ' — ' + m.en + '</p>' +
      '<h2><span class="mh-c">' + CIRC[i] + '</span>' + m.name + '</h2><p class="mh-lead">' + m.lead + '</p></div></header>' +
      (m.secs.filter(function (sid) { return DEFS[sid]; }).length < 2 ? '' :          /* セクションが 1 つだけのモード（①）は、セクションへのリンクを出さない（2026-10-12 千葉さん） */
      '<div class="seclinks">' + m.secs.filter(function (sid) { return DEFS[sid]; }).map(function (sid) {
        return '<a href="#' + (i + 1) + '-' + DEFS[sid].num + '" data-toc="' + sid + '">' + CIRC[i] + '-' + DEFS[sid].num + '　' + (DEFS[sid].short || DEFS[sid].title) + '</a>'; }).join('') + '</div>') +
      '<div class="modebar" id="mbar_' + m.id + '"></div>';
    if (!m.secs.length) h += '<div class="sec soon"><div class="sL"><p class="secdesc">このモードは、モード1を確認していただいたあとで作ります。</p></div></div>';
    m.secs.forEach(function (sid) {
      var d = DEFS[sid]; if (!d) return;
      if (d.custom) {                                    /* 4-1 など：セクション独自のレイアウト（d.html で中身、d.build で図を作る） */
        h += '<article class="sec secwide" id="' + sid + '"><div class="swin"><div class="sechead"><span class="secnum">' + CIRC[i] + '-' + d.num + '</span><h2>' + d.title + '</h2>' + (d.exam ? examBtns(sid) : '') +
          (d.obsSeg ? '<div class="seg secobs" role="group" aria-label="どの観測者から見るか"><button type="button" class="b obs" data-rot="0">外（慣性系）から見る</button><button type="button" class="b obs rotb" data-rot="1">一緒に円運動する観測者（非慣性系）から見る</button></div>' : '') +
          '</div>' + d.html() + '</div></article>';
        return;
      }
      if (d.wideHead) {                                  /* 見出しと問題文（説明）は左右の列をまとめて横いっぱい。説明は 2 列に分けられる（d.desc2）。2026-10-18 千葉さん */
        h += '<article class="sec widehead" id="' + sid + '"><div class="shead"><div class="sechead"><span class="secnum">' + CIRC[i] + '-' + d.num + '</span><h2>' + d.title + '</h2>' + (d.exam ? examBtns(sid) : '') + '</div>' +
          (d.desc2 ? '<div class="secdesc desc2"><div>' + d.desc2[0] + '</div><div>' + d.desc2[1] + '</div></div>' : '') + (d.desc ? '<div class="secdesc">' + d.desc + '</div>' : '') + '</div>' +
          '<div class="sL"><div class="simhost" id="simL_' + sid + '"></div></div><div class="sR" id="simR_' + sid + '"></div></article>';
        return;
      }
      h += '<article class="sec" id="' + sid + '"><div class="sL">' +
        '<div class="sechead"><span class="secnum">' + CIRC[i] + '-' + d.num + '</span><h2>' + d.title + '</h2></div>' +
        '<div class="secdesc">' + (d.desc || '') + '</div><div class="simhost" id="simL_' + sid + '"></div></div>' +
        '<div class="sR" id="simR_' + sid + '"></div></article>';
    });
    h += '</section>';
  });
  h += '<div class="card slownote"><p>このモードの図は、実際よりゆっくり再生している。時間バーの右の「周期 $T$」は実際の値。</p></div>';   /* モード② のときだけ見える（2026-10-16 千葉さん） */
  h += '<div class="card purpose"><p class="lead">【目的】</p><ol>' +
    '<li>単振動が等速円運動を真横から見た影（正射影）の運動であることを理解し、変位・速度・加速度と、振幅 $A$・角振動数 $\\omega$・周期 $T$ の関係を説明できるようになる。</li>' +
    '<li>力を見極めて運動方程式を立て、変形して $ma = -K(x - x_0)$ の形にして、振動の中心 $x_0$・角振動数 $\\omega = \\sqrt{K/m}$・周期 $T = 2\\pi\\sqrt{m/K}$ を読み取れるようになる。単振動は必ずつりあいの位置を中心に振動することと、エネルギーの関係、対応する円運動との関係を、いろいろな単振動で確かめる。</li>' +
    '<li>つりあいの位置からの変位 $x$ を使った単振動のエネルギー $\\dfrac{1}{2}mv^2 + \\dfrac{1}{2}Kx^2 = $ 一定 を使って、鉛直ばね振り子などの入試問題を解けるようになる。</li></ol></div>';
  h += '<footer></footer>';
  wrap.innerHTML = h;
  document.title = '単振動';
  wrap.querySelectorAll('.purpose,.slownote,.modehead,.secdesc,.sechead h2,.seclinks a,.gnote').forEach(function (e) { e.innerHTML = mathify(e.innerHTML); });
  document.querySelectorAll('#hero .ideas .ie, #hero .ideas .ij, #hero .stagecap .sct').forEach(function (e) { e.innerHTML = mathify(e.innerHTML); });
  if (GLOBAL.rot) MODES.forEach(function (m) { if (m.rotSwitch) modeState(m.id).rot = true; });
  setupGlobalButtons();
  MODES.forEach(function (m) { buildModeBar(m); });
  buildToc();
  document.querySelectorAll('#tabs .tab').forEach(function (b) {
    b.addEventListener('click', function () {
      activateMode(b.dataset.mode); history.replaceState(null, '', '#' + modeHash(b.dataset.mode));
      window.scrollTo({ top: Math.min(window.pageYOffset, contentTop()), behavior: 'auto' });
    });
  });
  document.querySelectorAll('.seclinks a[data-toc]').forEach(function (a) {
    a.addEventListener('click', function (ev) { ev.preventDefault(); var sid = a.dataset.toc; history.replaceState(null, '', '#' + addrOf(sid)); scrollToSec(sid); });
  });
  window.addEventListener('hashchange', function () { gotoHash(); });
  gotoHash(true);
  if (document.fonts && document.fonts.load) {
    Promise.all(['italic 17px KaTeX_Math', '16px KaTeX_Main'].map(function (f) { return document.fonts.load(f); })).then(function () { SIMS.forEach(function (s) { s.draw(); }); alignAll(); });
  }
}

/* モードの見出しの下：「表示：力を表示」＋（モード2・3）観測者の切りかえスイッチ */
function buildModeBar(m) {
  var bar = document.getElementById('mbar_' + m.id); if (!bar) return;
  var ms = modeState(m.id);
  /* 力の表示は、各セクションの「合力のみを表示」「全ての力を個別表示」で切りかえる（モード全体のチェックはやめた。2026-10-16 千葉さん） */
  if (m.rotSwitch) {
    /* モード全体の観測者の切りかえ（各シムと同じ対のボタン。アドレスは #mode2-rot） */
    var rw = el('span', 'rotsw'); rw.appendChild(el('span', 'lbl', '全セクション：'));
    var sg = el('div', 'seg'); sg.setAttribute('role', 'group'); sg.setAttribute('aria-label', '全セクションをどの観測者から見るか');
    var b0 = el('button', 'b obs', '外（慣性系）から見る'), b1 = el('button', 'b obs rotb', '一緒に円運動する観測者（非慣性系）から見る');
    [b0, b1].forEach(function (b, i) { b.type = 'button'; b.addEventListener('click', function () { m2SetModeRot(m.id, i === 1); }); sg.appendChild(b); });
    rw.appendChild(sg); bar.appendChild(rw); ms._segb = [b0, b1];
    b0.classList.toggle('on', !ms.rot); b1.classList.toggle('on', !!ms.rot);
  }
}

function syncGlobalButtons() {
  var bE = document.getElementById('btnEq');
  bE.innerHTML = '<span class="sw" aria-hidden="true"><i></i></span><span class="swl">式・考え方エリアを閉じる</span><span class="swv">' + (GLOBAL.hideEq ? 'ON' : 'OFF') + '</span>';
  bE.setAttribute('aria-pressed', GLOBAL.hideEq ? 'true' : 'false'); bE.classList.toggle('off', !GLOBAL.hideEq);
  document.body.classList.toggle('hideeq', GLOBAL.hideEq);
  if (typeof alignAll === 'function') requestAnimationFrame(alignAll);
  var bR = document.getElementById('btnRot');
  if (bR) {
    bR.innerHTML = '<span class="sw" aria-hidden="true"><i></i></span><span class="swl">全て：一緒に円運動する観測者（非慣性系）から見る</span><span class="swv">' + (GLOBAL.rot ? 'ON' : 'OFF') + '</span>';
    bR.setAttribute('aria-pressed', GLOBAL.rot ? 'true' : 'false'); bR.classList.toggle('off', !GLOBAL.rot);
  }
}
function setupGlobalButtons() {
  var bE = document.getElementById('btnEq');
  bE.addEventListener('click', function () {
    GLOBAL.hideEq = !GLOBAL.hideEq; syncGlobalButtons();
    SIMS.forEach(function (s) { if (s.cv.offsetParent) { s.resize(); s.draw(); } });
  });
  var bR = document.getElementById('btnRot');
  if (bR) bR.addEventListener('click', function () { setGlobalRot(!GLOBAL.rot); });
  syncGlobalButtons();
}
/* 全てのモード（観測者を切りかえられるモード）の切りかえを、まとめて ON／OFF */
function setGlobalRot(on) {
  GLOBAL.rot = on;
  MODES.forEach(function (m) { if (m.rotSwitch) m2SetModeRot(m.id, on, true); });
  syncGlobalButtons();
}
/* どれか 1 つの切りかえを変えたら、右上の表示もそろえる（全部が非慣性系なら ON） */
function syncGlobalRot() {
  var rm = MODES.filter(function (m) { return m.rotSwitch; }).map(function (m) { return m.id; });
  var all = rm.every(function (id) { return !!modeState(id).rot; }) && SIMS.every(function (s) { return rm.indexOf(s.mode) < 0 || !!s.rot; });
  if (GLOBAL.rot !== all) { GLOBAL.rot = all; syncGlobalButtons(); }
}
function modeHash(mid) { var ms = modeState(mid); return mid + (ms.rot ? '-rot' : ''); }
function activateMode(id) {
  var m = MODES.find(function (x) { return x.id === id; }); if (!m) return;
  document.querySelectorAll('#tabs .tab').forEach(function (b) { b.classList.toggle('on', b.dataset.mode === id); });
  document.querySelectorAll('.mode').forEach(function (s) { s.classList.toggle('on', s.id === id); });
  document.body.classList.toggle('inm1', id === 'mode1');
  document.body.classList.toggle('inm2', id === 'mode2');            /* 文字クリックの注意はモード1 だけ */
  SIMS.forEach(function (s) { if (s.mode !== id && s.playing) { s.playing = false; s.syncPlayLabel(); } });
  if (!MODE_BUILT[id]) {
    MODE_BUILT[id] = 1;
    m.secs.forEach(function (sid) {
      var d = DEFS[sid]; if (!d) return;
      if (d.custom) { d.build(document.getElementById(sid)); return; }
      if (d.own) { SIM_BY_ID[sid] = d.own(document.getElementById('simL_' + sid), document.getElementById('simR_' + sid)); return; }   /* ②-8：表のように並べたアニメ（Sim を使わない） */
      SIM_BY_ID[sid] = new Sim(d, document.getElementById('simL_' + sid), document.getElementById('simR_' + sid));
      if (d.exam && !d.wideHead) { var R = document.getElementById('simR_' + sid), w = document.createElement('div'); w.innerHTML = examBtns(sid); R.insertBefore(w.firstChild, R.firstChild); }   /* モード④：右上に問題・解答（PDF） */
    });
  } else SIMS.forEach(function (s) { if (s.mode === id) { s.resize(); s.draw(); } });
  requestAnimationFrame(function () { requestAnimationFrame(alignAll); });
}
var hasDef = function (k) { return Object.prototype.hasOwnProperty.call(DEFS, k); };
function addrOf(sid) {
  var i = MODES.findIndex(function (x) { return x.secs.indexOf(sid) >= 0; });
  return (i < 0 || !hasDef(sid)) ? sid : (i + 1) + '-' + DEFS[sid].num;
}
/* アドレス：#mode1／#mode2／#mode2-rot（非慣性系で始める）／#1-1 のようなセクション */
function parseHash(hs) {
  hs = String(hs || '').replace('#', '');
  var m = /^(mode\d)(-rot)?$/.exec(hs);
  if (m) { var mo = MODES.find(function (x) { return x.id === m[1]; }); return mo ? { mode: mo, rot: !!m[2] } : {}; }
  var q = /^(\d+)-(\d+)$/.exec(hs);
  if (q) { var mo2 = MODES[+q[1] - 1]; if (mo2) { var sid = mo2.secs.find(function (s) { return hasDef(s) && String(DEFS[s].num) === q[2]; }); return sid ? { mode: mo2, sec: sid } : { mode: mo2 }; } }
  return {};
}
function contentTop() { var h = document.getElementById('hero'); return h ? h.offsetTop + h.offsetHeight : 0; }
function tabbarH() { var tb = document.getElementById('tabs'); if (!tb) return 0; return (getComputedStyle(tb).position === 'sticky') ? tb.getBoundingClientRect().height : 0; }
function scrollToSec(sid) {
  var go = function () { var e = document.getElementById(sid); if (!e) return; var y = e.getBoundingClientRect().top + window.pageYOffset - tabbarH() - 8; window.scrollTo({ top: Math.max(0, y), behavior: 'auto' }); };
  go(); requestAnimationFrame(function () { requestAnimationFrame(go); }); setTimeout(go, 180);
}
function buildToc() {
  var p = document.getElementById('tocpanel'), b = document.getElementById('bToc'); if (!p || !b) return;
  var h = '<div class="tochead"><b>コンテンツ一覧</b><button type="button" class="tocx" aria-label="閉じる">×</button></div>';
  MODES.forEach(function (m, i) {
    h += '<div class="tocmode">' + CIRC[i] + ' ' + m.name + '</div><ul>';
    m.secs.forEach(function (sid) { var d = DEFS[sid]; if (!d) return;
      h += '<li><a href="#' + addrOf(sid) + '" data-toc="' + sid + '">' + CIRC[i] + '-' + d.num + '　' + mathify(String(d.title).replace(/<[^>]+>/g, '')) + '</a></li>'; });
    if (!m.secs.length) h += '<li><a href="#' + m.id + '" data-tocm="' + m.id + '">（準備中）</a></li>';
    h += '</ul>';
  });
  p.innerHTML = h;
  var close = function () { p.hidden = true; b.setAttribute('aria-expanded', 'false'); };
  b.addEventListener('click', function (ev) { ev.stopPropagation(); p.hidden = !p.hidden; b.setAttribute('aria-expanded', p.hidden ? 'false' : 'true'); });
  p.querySelector('.tocx').addEventListener('click', close);
  document.addEventListener('click', function (ev) { if (!p.hidden && !p.contains(ev.target) && ev.target !== b) close(); });
  document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape') close(); });
  p.querySelectorAll('[data-toc]').forEach(function (a) {
    a.addEventListener('click', function (ev) {
      ev.preventDefault(); close();
      var sid = a.getAttribute('data-toc'), mo = MODES.find(function (x) { return x.secs.indexOf(sid) >= 0; }); if (!mo) return;
      activateMode(mo.id); history.replaceState(null, '', '#' + addrOf(sid)); scrollToSec(sid);
    });
  });
  p.querySelectorAll('[data-tocm]').forEach(function (a) {
    a.addEventListener('click', function (ev) { ev.preventDefault(); close(); activateMode(a.dataset.tocm); history.replaceState(null, '', '#' + a.dataset.tocm); window.scrollTo({ top: contentTop(), behavior: 'auto' }); });
  });
}
function gotoHash(first) {
  var q = parseHash(location.hash);
  if (!q.mode) { if (first) activateMode(MODES[0].id); return; }
  if (first && GLOBAL.rot && q.rot === false) q.rot = true;            /* ?rot=1 のときは、#mode2 などでも非慣性系で始める */
  if (q.rot !== undefined && q.mode.rotSwitch) { modeState(q.mode.id).rot = q.rot; }
  activateMode(q.mode.id);
  if (q.rot !== undefined && q.mode.rotSwitch && typeof m2SetModeRot === 'function') m2SetModeRot(q.mode.id, q.rot);
  if (q.sec) scrollToSec(q.sec);
  else if (!first) window.scrollTo({ top: contentTop(), behavior: 'auto' });
  else if (location.hash) scrollToSec(q.mode.id);
}

document.addEventListener('DOMContentLoaded', function () { buildPage(); });

