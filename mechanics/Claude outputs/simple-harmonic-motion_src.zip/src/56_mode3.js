/* =========================================================================
   56_mode3.js … モード③ 単振動のエネルギー（入試レベル）
   ③-1 周期がどの物理量に依存するのか（54_mode2s8.js。前の ②-8 を移した。2026-10-18 千葉さん）
   ③-2 単振動のエネルギー U = ½kx²（鉛直ばね振り子。U = ½kx² は重力と弾性力の合力による位置エネルギー。
        （ア）U = ½kx² を使う解き方と（イ）重力・弾性力の位置エネルギーを別々に使う解き方が、同じ v になる）
   どちらも 右の列：スライダー → エネルギー − t グラフ（アニメと上をそろえる）→ 説明
   ========================================================================= */
'use strict';
var M3 = {
  s2: { m: [0.25, 0.5, 1.0], k: [5, 10, 20], m0: 0.5, k0: 10, Lnat: 0.40 }               /* ③-2：自然の長さの位置でそっと放す（A = l₀ = mg/k） */
};
/* 右の列にスライダーとグラフ、その下に説明（①-2・モード② と同じ並び） */
function m3RightLayout(s) {
  s.R.innerHTML = '';
  if (s.varbox) { var sw = el('div', 'row2 sliders inR'); sw.appendChild(s.varbox); s.R.appendChild(sw); s.varbox.classList.add('inR'); }
  s.R.appendChild(s.gHost); s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);
}
/* エネルギーの棒（縦）。x＝棒のまん中、y0＝0 の高さ、val〔J〕、sc〔px/J〕 */
function m3Bar(ctx, x, y0, val, sc, col, lab, w, dash) {
  var h = val * sc; w = w || 22;
  ctx.save(); ctx.fillStyle = fade(col, dash ? .18 : .32); ctx.strokeStyle = col; ctx.lineWidth = 1.6; if (dash) ctx.setLineDash([5, 3]);
  ctx.fillRect(x - w / 2, Math.min(y0, y0 - h), w, Math.abs(h)); if (Math.abs(h) > 0.5) ctx.strokeRect(x - w / 2, Math.min(y0, y0 - h), w, Math.abs(h));
  ctx.restore();
  if (lab) label(ctx, lab, x, h >= 0 ? y0 - h - 10 : y0 - h + 11, { size: 10.5, bold: true, color: col });
}

/* =====================================================================
   ③-2 単振動のエネルギーのより本質的理解のために（鉛直ばね振り子・下向きが正・x はつりあいの位置から）
   ===================================================================== */
function m3s2Q(s) { var m = s.v.m, k = s.v.k, w = Math.sqrt(k / m), l0 = m * G / k; return { m: m, k: k, w: w, T: TAU / w, l0: l0, A: l0 }; }
function m3s2State(s, t) {
  var q = m3s2Q(s), x = -q.l0 * Math.cos(q.w * t), v = q.l0 * q.w * Math.sin(q.w * t), a = -q.w * q.w * x;
  var K = 0.5 * q.m * v * v, U = 0.5 * q.k * x * x;                        /* （ア）U = ½kx²（重力と弾性力の合力による位置エネルギー） */
  var Ug = -q.m * G * (q.l0 + x), Ue = 0.5 * q.k * Math.pow(q.l0 + x, 2);  /* （イ）重力（基準：自然の長さの位置）と弾性力（伸び l₀ + x） */
  return { x: x, v: v, a: a, K: K, U: U, E: K + U, Ug: Ug, Ue: Ue, E2: K + Ug + Ue };
}
DEFS.m3s2 = {
  id: 'm3s2', mode: 'mode3', num: 2, title: '単振動のエネルギー $U=\\dfrac{1}{2}kx^2$', short: '単振動のエネルギー',
  wideHead: true,                                                 /* 問題文は横いっぱい・2 列、スライダーの右に時間バー（④-1 と同じ。2026-10-18 千葉さん） */
  desc2: ['<b>単振動のエネルギー $U = \\dfrac{1}{2}kx^2$ の $x$ は、自然の長さからの伸び縮みではなく、つりあいの位置からの変位である。</b>天井からつるしたばね（ばね定数 $k$）におもり（質量 $m$）をつけると、ばねは $l_0$ だけ伸びてつりあう。ばねが自然の長さになるまでおもりを持ち上げて、そっと放す。つりあいの位置を原点 O、鉛直下向きを $x$ の正の向きにとる。', '<span class="todo">（ア）$U = \\dfrac{1}{2}kx^2$ を使う考え方と、（イ）重力と弾性力の位置エネルギーを別々に使う考え方があるが、どちらも正しい。しかし、左下の解説プリントを読むと、$v$ を求める際は（ア）の方がはるかに楽であることが分かる。</span>'],
  strobe: false, showFBtn: true, fDefault: 'all', vecBtn: 'v を消す', graphs: true, stgCls: 'solo', belowCanvas: true, baseRate: 0.5,
  varCols: [['m'], ['k']],
  vars: [{ k: 'm', label: '質量 $m$', stops: M3.s2.m, stopLabels: ['0.25', '0.50', '1.0 kg'], def: M3.s2.m0, aria: '質量', fmt: function (x) { return fmt(x, 2) + ' kg'; } },
    { k: 'k', label: 'ばね定数 $k$', stops: M3.s2.k, stopLabels: ['5', '10', '20 N/m'], def: M3.s2.k0, aria: 'ばね定数', fmt: function (x) { return x + ' N/m'; } }],
  onChanged: function (s) { s.resize(); if (s.graphs) shmGraphReset(s); },
  onDefaults: function (s) { shmGraphReset(s); },
  afterBuild: function (s) {
    var A = { key: 'Ea', title: '（ア）$U = \\dfrac{1}{2}kx^2$ を使い、力学的エネルギー $E = \\dfrac{1}{2}mv^2 + \\dfrac{1}{2}kx^2$', ysym: 'E', yunit: 'J',
      series: [{ name: '力学的エネルギー $E$', color: ECOL.E, width: 3.2, f: function (q) { return q.E; } },
        { name: '位置エネルギー $\\dfrac{1}{2}kx^2$', color: ECOL.U, width: 2, dash: [7, 4], f: function (q) { return q.U; } },
        { name: '運動エネルギー $\\dfrac{1}{2}mv^2$', color: ECOL.K, width: 2, f: function (q) { return q.K; } }],
      range: function (s) { var q = m3s2Q(s); return { lo: 0, hi: 0.5 * q.k * q.l0 * q.l0 }; }, H: function () { return 150; },
      val: function (q) { return '$E$ ' + fmt(q.E, 3) + ' J'; } };
    var B = { key: 'Eb', title: '（イ）重力と弾性力を別々に考え、力学的エネルギー $E = \\dfrac{1}{2}mv^2 + U_{\\text{重}} + U_{\\text{弾}}$', ysym: 'E', yunit: 'J',
      series: [{ name: '和 $E\'$', color: ECOL.E, width: 3.2, f: function (q) { return q.E2; } },
        { name: '重力 $U_{\\text{重}}$', color: '#d1352b', width: 2, dash: [7, 4], f: function (q) { return q.Ug; } },
        { name: '弾性力 $U_{\\text{弾}}$', color: '#c2367f', width: 2, dash: [3, 3], f: function (q) { return q.Ue; } },
        { name: '運動エネルギー $\\dfrac{1}{2}mv^2$', color: ECOL.K, width: 2, f: function (q) { return q.K; } }],
      range: function (s) { var q = m3s2Q(s); return { lo: -2 * q.k * q.l0 * q.l0, hi: 2 * q.k * q.l0 * q.l0 }; }, H: function () { return 170; },
      val: function (q) { return '$E\'$ ' + fmt(q.E2, 3) + ' J'; } };
    shmGraphs(s, [A, B]); m3RightLayout(s);
    var srow = s.R.querySelector('.row2.sliders.inR'); s.varbox.classList.remove('inR'); ctlOneRow(s); if (srow) srow.remove();
    /* 図の下：解説プリント（千葉さんの PDF を画像にしてはる）。押すと大きく */
    var fig = el('figure', 'm3pdf');
    fig.innerHTML = mathify('<figcaption>解説プリント「単振動のエネルギーを用いた解き方の解説」（押すと大きく表示）<span class="m3row"><span class="m3cap">↓ $v$ を求める際に（ア）の方がはるかに楽</span><button type="button" class="m3tab">別のページで開く ↗</button></span></figcaption><img alt="解説プリント：単振動のエネルギーを用いた解き方の解説（例題と、（ア）（イ）2 通りの解き方）" width="' + M3_PDF_WH[0] + '" height="' + M3_PDF_WH[1] + '">');
    fig.querySelector('img').src = M3_PDF_IMG;
    fig.querySelector('.m3tab').addEventListener('click', function (e) { e.stopPropagation(); m3PdfTab(fig.querySelector('img').src); });   /* 別のタブで（2026-10-25 千葉さん） */
    fig.addEventListener('click', function () { m3PdfOpen(fig.querySelector('img').src); });   /* 大きく表示は body 直下の重ね画面で（セクションの中の position: fixed は、ページの部品にとじこめられて真っ白になっていた。2026-10-19） */
    s.below.appendChild(fig);
  },
  tEnd: function (s) { return tBarOf(m3s2Q(s).T); },
  tInfo: function (s) { return periodInfo(m3s2Q(s).T); },
  gq: function (s, t) { return m3s2State(s, t); },
  gWin: function (s) { return 2 * m3s2Q(s).T; },
  gT: function (s) { return m3s2Q(s).T; },
  gAmp: function (s) { var q = m3s2Q(s); return { E: 0.5 * q.k * q.l0 * q.l0 }; },
  height: function (s, w) { return Math.round(clamp(w * 0.62, 300, 420)); },
  draw: function (s, ctx, W, H) { drawM3S2(s, ctx, W, H); },
  live: function (s) { m3s2Live(s); },
  right: function (s, R) { rightM3S2(s, R); }
};
function drawM3S2(s, ctx, W, H) {
  var q = m3s2Q(s), st = m3s2State(s, s.t), Wp = W * 0.5, top = 14, Lnat = M3.s2.Lnat, rb = 12;
  var S = (H - top - 40) / (Lnat + 2 * q.l0 + 0.06), xs = Wp * 0.42, yN = top + Lnat * S, yE = yN + q.l0 * S, by = yE + st.x * S;
  ceilingAt(ctx, xs - 30, xs + 30, top);
  dotted(ctx, xs - 70, yN, Wp - 10, yN, 'rgba(20,23,28,.4)', [5, 4]);
  dotted(ctx, xs - 70, yE, Wp - 10, yE, 'rgba(20,23,28,.5)', [5, 4]);
  label(ctx, '自然の長さ', xs - 74, yN, { size: 10.5, color: '#5d6875', align: 'right' });
  label(ctx, 'つりあいの位置', xs - 74, yE, { size: 10.5, bold: true, color: '#c0392b', align: 'right' });
  dimLine(ctx, xs - 44, yN, xs - 44, yE); sym(ctx, 'l₀', xs - 56, (yN + yE) / 2, { size: 13 });
  springDense(ctx, xs, top, xs, by - rb, yE - top - rb, { r: 8, k: q.k, Lmin: yN - top - rb });
  var hOpt = s.W < 480 ? { flip: true, bubPos: 'd', bubDy: 50 } : { flip: true, bubDy: 26 };
  if (s.t < 0.5) startHand(s, ctx, xs, by, rb, 'up', 0, Object.assign({ noBub: true }, hOpt));   /* 吹き出しは「自然の長さ」の点線より下に（2026-10-19） */
  ballShape(ctx, xs, by, rb, '#d9b77a');
  if (!s.hideVec && Math.abs(st.v) > 0.03 * q.l0 * q.w) vArrowAt(ctx, xs, by, 1, 0, rb + 30, 0, 1, st.v / (q.l0 * q.w) * 40, true);
  var fs = 40 / (q.m * G);
  if (fNet(s)) netArrow(ctx, xs, by - rb, 0, 1, -q.k * st.x * 46 / (q.k * q.l0), '−kx', { lx: -14, al: 'right' });
  if (fAll(s)) {
    var Fs = q.k * (q.l0 + st.x);
    fArrow(ctx, xs - 5, by - rb, 0, -1, Fs * fs, COL.hand, 'k(l₀ + x)', { lx: 38, noShift: true });   /* 記号はばねの右（左の l₀ の寸法と重ねない） */
    fArrow(ctx, xs + 5, by, 0, 1, q.m * G * fs, COL.force, 'mg', { lx: 12, noShift: true });
  }
  var ax = xs + 64; m2Axis(ctx, { x: ax, y: yE }, [0, 1], -(yE - top) + 6, q.l0 * S + 26, '', { oDx: -12, oDy: 0, xDx: 10 });
  /* 右：エネルギーの棒。（ア）K と ½kx² の積み上げ ＝ E（一定）。（イ）K・U重・U弾（U重 は負にもなる）の和 E′（一定） */
  var e0 = 0.5 * q.k * q.l0 * q.l0, sc = (H * 0.40) / (4 * e0), y0 = H * 0.52, xa = Wp + (W - Wp) * 0.20, xb = Wp + (W - Wp) * 0.62;
  ctx.save(); ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(Wp + 8, y0); ctx.lineTo(W - 8, y0); ctx.stroke(); ctx.restore();
  label(ctx, '0', Wp + 6, y0, { size: 10, align: 'right', color: '#5d6875' });
  ctx.save(); ctx.fillStyle = fade(ECOL.U, .35); ctx.fillRect(xa - 14, y0 - st.U * sc, 28, st.U * sc);
  ctx.fillStyle = fade(ECOL.K, .4); ctx.fillRect(xa - 14, y0 - (st.U + st.K) * sc, 28, st.K * sc); ctx.restore();
  ctx.save(); ctx.strokeStyle = ECOL.E; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(xa - 24, y0 - st.E * sc); ctx.lineTo(xa + 24, y0 - st.E * sc); ctx.stroke(); ctx.restore();
  label(ctx, '（ア）', xa, H - 30, { size: 11.5, bold: true }); label(ctx, 'E = ½mv² ＋ ½kx²', xa, H - 14, { size: 10.5, color: COL.ink2 });
  if (st.K * sc > 12) label(ctx, '½mv²', xa + 24, y0 - st.U * sc - st.K * sc / 2, { size: 11, bold: true, color: ECOL.K, align: 'left' });   /* （ア）の棒の中身 */
  if (st.U * sc > 12) label(ctx, 'U', xa + 24, y0 - st.U * sc / 2, { size: 11, bold: true, color: ECOL.U, align: 'left' });
  m3Bar(ctx, xb - 26, y0, st.K, sc, ECOL.K, '½mv²', 18);
  m3Bar(ctx, xb, y0, st.Ug, sc, '#d1352b', 'U重', 18, true);
  m3Bar(ctx, xb + 26, y0, st.Ue, sc, '#c2367f', 'U弾', 18);
  ctx.save(); ctx.strokeStyle = ECOL.E; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(xb - 40, y0 - st.E2 * sc); ctx.lineTo(xb + 40, y0 - st.E2 * sc); ctx.stroke(); ctx.restore();
  label(ctx, '（イ）', xb, H - 30, { size: 11.5, bold: true }); label(ctx, 'E = ½mv² ＋ U重 ＋ U弾', xb, H - 14, { size: 10.5, color: COL.ink2 });
  label(ctx, '太線：和（一定）', W - 8, 12, { size: 10, color: ECOL.E, align: 'right' });
  if (s.t < 0.5) startHand(s, ctx, xs, by, rb, 'up', 0, Object.assign({ bubOnly: true }, hOpt));   /* スタート前の吹き出しは最後に描いて、x 軸などより前に（2026-10-25 千葉さん） */
  drawEqualTicks(ctx);
}
function rightM3S2(s, R) {
  var h = '<div class="qcard"><p class="qt">（ア）重力と弾性力の合力による位置エネルギー</p>' +
    '<p>つりあいの位置からの変位 $x$ のとき、おもりにはたらく重力と弾性力の合力は $F = mg - k(l_0 + x) = -kx$（$kl_0 = mg$）。この合力を「保存力」と考えると、その位置エネルギーは</p>' +
    '<div class="qeq">$$U = \\dfrac{1}{2}kx^2$$</div><p class="qnote">（位置エネルギーの基準は、つりあいの位置）</p>' +
    '<p>となり、水平ばね振り子と同じように $\\dfrac{1}{2}mv^2 + \\dfrac{1}{2}kx^2 = $ 一定 が使える。<b>$x$ は自然の長さからの伸びではなく、つりあいの位置からの変位</b>。ここでの $k$ は、運動方程式 $ma = -Kx$ の $K$（この場合 $K = k$）。</p></div>' +
    '<div class="qcard"><p class="qt">いまの速さ $v$ を 2 通りで求める</p><div class="m32now"></div></div>';
  R.innerHTML = mathify(h);
  s._now = R.querySelector('.m32now'); s._nowH = null; m3s2Live(s);
}
function m3s2Live(s) {
  if (!s._now) return;
  var now = performance.now(); if (s.playing && s._nowT && now - s._nowT < 160) return; s._nowT = now;
  var q = m3s2Q(s), st = m3s2State(s, s.t), x = st.x;
  var va = Math.sqrt(Math.max(0, (q.k / q.m) * (q.l0 * q.l0 - x * x)));                   /* （ア） */
  var vb = Math.sqrt(Math.max(0, 2 / q.m * (-(st.Ug + st.Ue))));                            /* （イ）E′ = 0（自然の長さで静止） */
  var h = '<p class="m3q">いま $x =$ ' + fmt(x, 3) + ' m（$l_0 =$ ' + fmt(q.l0, 3) + ' m）</p>' +
    '<p class="m3a"><b>（ア）</b>$\\dfrac{1}{2}mv^2 + \\dfrac{1}{2}kx^2 = 0 + \\dfrac{1}{2}kl_0^2$ より　$v = \\sqrt{\\dfrac{k}{m}(l_0^2 - x^2)} =$ <b>' + fmt(va, 3) + '</b> m/s</p>' +
    '<p class="m3a"><b>（イ）</b>$\\dfrac{1}{2}mv^2 - mg(l_0 + x) + \\dfrac{1}{2}k(l_0 + x)^2 = 0 + 0 + 0$ より　$v =$ <b>' + fmt(vb, 3) + '</b> m/s</p>' +
    '<p class="qnote">（イ）は重力の位置エネルギーの基準を自然の長さの位置にした。どちらも同じ $v$（アニメの速さ ' + fmt(Math.abs(st.v), 3) + ' m/s）。<b class="m3easy">（ア）の方が計算が楽。</b></p>';
  if (h === s._nowH) return; s._nowH = h; s._now.innerHTML = mathify(h);
}

/* =====================================================================
   ③-3 x 座標の原点について（②-3 と同じ鉛直ばね振り子。図の下に x–t グラフだけ。2026-10-18 千葉さん）
   右の列：「つりあいの位置を x = 0」「自然長の位置を x = 0」の 2 通りの周期の導出 → ＜まとめ＞ → ＜入試問題で意識すべきこと＞
   ===================================================================== */
DEFS.m3s3 = {
  id: 'm3s3', mode: 'mode3', num: 3, title: '$x$ 座標の原点について', short: '$x$ 座標の原点',
  desc: '②-3 と同じ鉛直ばね振り子（鉛直下向きが $x$ の正の向き）。<span class="todo">「つりあいの位置を $x = 0$」「自然長の位置を $x = 0$」を切りかえて、運動そのものは同じでも、$x$–$t$ グラフと運動方程式の形がどう変わるかを見比べよう。</span>',
  strobe: false, showFBtn: true, fDefault: 'all', vecBtn: 'v を消す', graphs: true, stgCls: 'solo', baseRate: 0.5,
  buttons: orgButtons(),                                            /* 振幅・初期位相のスライダーはなくし、その場所に x = 0 の切りかえを大きく（光らせる）。2026-10-18 千葉さん */
  init: function (s) { s.org = 0; s.v.A = M2.s3.A; s.v.phi = Math.PI / 2; },
  onDefaults: function (s) { s.org = 0; syncOrg(s); shmGraphReset(s); },
  onChanged: function (s) { if (s.graphs) shmGraphReset(s); },
  afterBuild: function (s) {
    var D = xvaDefs()[0];
    D.range = function (s) { var Q = m2s3Q(s), c = Q.off || 0; return { lo: Math.min(c - Q.A, -Q.A * 0.2), hi: Math.max(c + Q.A, Q.A * 0.2) }; };
    D.H = function () { return 120; };                                 /* 前の 70 %（2026-10-19 千葉さん） */
    shmGraphs(s, [D]); syncOrg(s);
    var seg = s.extra.oEq.parentNode, big = el('div', 'row2 orgbig'), ctr = s.L.querySelector('.ctrls');
    big.appendChild(seg); ctr.insertBefore(big, ctr.firstChild);
    var sl = ctr.querySelector('.row2.sliders'); if (sl && !sl.querySelector('input')) sl.remove();
  },
  tEnd: function (s) { return tBarOf(m2s3Q(s).T); },
  tInfo: function (s) { return periodInfo(m2s3Q(s).T); },
  gq: function (s, t) { var Q = m2s3Q(s), st = SHM.st(Q.A, Q.w, Q.phi, t); return { X: st.x, x: st.x + Q.off, v: st.v, a: st.a }; },
  gWin: function (s) { return 2 * m2s3Q(s).T; },
  gT: function (s) { return m2s3Q(s).T; },
  gAmp: function (s) { var Q = m2s3Q(s); return { x: Q.off + Q.A, v: Q.A * Q.w, a: Q.A * Q.w * Q.w }; },
  height: function (s, w) { return Math.round(clamp(w * 0.58, 260, 380)) + 64; },   /* 下に、左の図の名前と吹き出しの場所 */
  draw: function (s, ctx, W, H) {
    var Q = m2s3Q(s), g = vGeo(s, { x0: 0, y0: 0, w: W, h: H }), st = SHM.st(Q.A, Q.w, Q.phi, s.t);
    vScene(s, ctx, g, { X: st.x, v: st.v, a: st.a, x: st.x + Q.off }, {}, Q);
    drawEqualTicks(ctx);
  },
  right: function (s, R) { rightM3S3(s, R); }
};
function rightM3S3(s, R) {
  var nat = !!s.org, Q = m2s3Q(s);
  var h = '<div class="qcard m33c' + (nat ? '' : ' on') + '"><p class="qt">つりあいの位置を $x = 0$</p>' +
    '<p>重力 $mg$（下向き）、弾性力は伸び $x + d$ なので $k(x + d)$（上向き）。つりあいの式 $kd = mg$。</p>' +
    eqL('eom', '$ma = -k(x + d) + mg = -kx$') +
    '<p>$a = -\\dfrac{k}{m}x$ を $a = -\\omega^2 x$ と比べて　$\\omega = \\sqrt{\\dfrac{k}{m}},\\ T = 2\\pi\\sqrt{\\dfrac{m}{k}}$。振動の中心は $x = 0$。</p></div>' +
    '<div class="qcard m33c' + (nat ? ' on' : '') + '"><p class="qt">自然長の位置を $x = 0$</p>' +
    '<p>重力 $mg$（下向き）、弾性力は伸び $x$ なので $kx$（上向き）。</p>' +
    eqL('eom', '$ma = -kx + mg = -k\\left(x - \\dfrac{mg}{k}\\right) = -k(x - d)$') +
    '<p>$X = x - d$ とおくと $a = -\\dfrac{k}{m}X$。$a = -\\omega^2 X$ と比べて　$\\omega = \\sqrt{\\dfrac{k}{m}},\\ T = 2\\pi\\sqrt{\\dfrac{m}{k}}$（同じ）。振動の中心は $x = d$。</p></div>' +
    '<div class="qcard keybox"><p class="qt">＜まとめ＞</p>' +
    '<p><b>つりあいの位置を $x = 0$ にした方が楽。</b>合力がすぐに $-kx$ の形になる。</p>' +
    '<p>また、<a class="xlink" href="#3-2">③-2</a> の単振動のエネルギー $U = \\dfrac{1}{2}kx^2$ の $x$ は、つりあいの位置からの変位である。だから、つりあいの位置を $x = 0$ にしておけば、その $x$ 座標が<b>そのまま単振動のエネルギーの $x$ に使える</b>（自然長の位置を $x = 0$ にすると $U = \\dfrac{1}{2}k(x - d)^2$ と書き直す必要がある）。</p></div>' +
    '<div class="qcard"><p class="qt">＜入試問題で意識すべきこと＞</p>' +
    '<p>特に <a class="xlink" href="#2-3">鉛直ばね振り子</a>・<a class="xlink" href="#2-4">斜め台の上のばね振り子</a>・<a class="xlink" href="#2-5">摩擦がある場合</a>・<a class="xlink" href="#2-7">浮力による単振動</a> では、次を意識しておこう。</p>' +
    '<ul class="pts"><li>問題文で $x$ 軸の原点が<b>つりあいの位置</b>ならば、合力の式が $-kx$ と簡単になる。</li>' +
    '<li>問題文で $x$ 軸の原点が<b>自然長の位置</b>ならば、合力の式が $x = 0$ で $0$ にならない $-k(x - x_0)$ の形になる（$x_0$ はつりあいの位置）。</li></ul>' +
    '<p class="qnote">いま：$d = \\dfrac{mg}{k} = ' + fmt(Q.d, 2) + '$ m。グラフは、自然長の位置を $x = 0$ にすると $d$ だけ上下にずれる（形は同じ）。</p></div>';
  R.innerHTML = mathify(h);
}

/* 解説プリントを画面いっぱいに大きく表示（クリック・Esc で閉じる） */
function m3PdfOpen(src) {
  var ov = el('div', 'm3pdfov'); ov.innerHTML = '<p class="m3pdfbar">解説プリント（どこかを押すか Esc で閉じる）<button type="button" class="m3tab">別のページで開く ↗</button></p><img alt="解説プリント（拡大）">';
  ov.querySelector('.m3tab').addEventListener('click', function (e) { e.stopPropagation(); m3PdfTab(src); });
  ov.querySelector('img').src = src; document.body.appendChild(ov); document.body.style.overflow = 'hidden';
  var close = function () { ov.remove(); document.body.style.overflow = ''; document.removeEventListener('keydown', key); };
  var key = function (e) { if (e.key === 'Escape') close(); };
  ov.addEventListener('click', close); document.addEventListener('keydown', key);
}

/* 解説プリントを別のページ（新しいタブ）で開く。画像は data: URL なので、blob: URL にして開く（data: のままだとブラウザが開かない） */
function m3PdfTab(src) {
  try {
    var b64 = src.split(',')[1], mime = (src.match(/^data:([^;]+);/) || [])[1] || 'image/jpeg', bin = atob(b64), u8 = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
    var url = URL.createObjectURL(new Blob([u8], { type: mime }));
    var w = window.open(url, '_blank'); if (!w) m3PdfOpen(src);
  } catch (e) { m3PdfOpen(src); }
}
