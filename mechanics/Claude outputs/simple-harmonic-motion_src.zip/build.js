#!/usr/bin/env node
/* 単振動（simple-harmonic-motion.html）の単一 HTML ビルド
 * src/ の部品を決まった順に連結する。KaTeX は CSS / JS / フォント(woff2 を base64) をすべて埋め込み、完全オフライン。
 * 共通フッター（src/99_footer.html）は </body> の直前にそのまま入れる（一字も変えない）。
 */
'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const SRC = path.join(ROOT, 'src');
const OUT = path.join(ROOT, 'dist', 'simple-harmonic-motion.html');
const KATEX = path.join(ROOT, 'node_modules', 'katex', 'dist');

/* 2026-11-11：全モードを開いて使われていなかった KaTeX_Math-BoldItalic（太い斜体）と KaTeX_Typewriter（等幅）は入れない（約 40 KB 減） */
const FONT_WHITELIST = [
  'KaTeX_Main-Regular', 'KaTeX_Main-Bold', 'KaTeX_Main-Italic',
  'KaTeX_Math-Italic',
  'KaTeX_Size1-Regular', 'KaTeX_Size2-Regular', 'KaTeX_Size3-Regular', 'KaTeX_Size4-Regular',
  'KaTeX_AMS-Regular'
];
/* 2026-11-11：公開用のファイルだけ、自前の JS・CSS の説明書き（コメント）と空白を詰める（src/ はそのまま）。
   名前の付けかえ（mangle）はしない＝関数名・変数名はそのまま残り、テストやほかのファイルからの呼び出しも変わらない。
   node build.js --no-min で、詰めない版（読みやすい版）を出す。 */
const MIN = process.argv.indexOf('--no-min') === -1;
function minJs(code) { return MIN ? require('esbuild').transformSync(code, { loader: 'js', minifyWhitespace: true, minifySyntax: true, legalComments: 'none', charset: 'utf8' }).code : code; }
function minCss(code) { return MIN ? require('esbuild').transformSync(code, { loader: 'css', minify: true, legalComments: 'none', charset: 'utf8' }).code : code; }
function read(p) { return fs.readFileSync(p, 'utf8'); }

/* KaTeX の CSS を @font-face ブロック単位で走査して差し替える（一括正規表現置換はしない） */
function inlineKatexCss() {
  const css = read(path.join(KATEX, 'katex.min.css'));
  const out = []; let i = 0;
  while (i < css.length) {
    const at = css.indexOf('@font-face{', i);
    if (at === -1) { out.push(css.slice(i)); break; }
    out.push(css.slice(i, at));
    const end = css.indexOf('}', at);
    if (end === -1) { out.push(css.slice(at)); break; }
    const face = rewriteFontFace(css.slice(at, end + 1));
    if (face) out.push(face);
    i = end + 1;
  }
  return out.join('');
}
function rewriteFontFace(block) {
  const m = block.indexOf('fonts/'); if (m === -1) return null;
  const tail = block.slice(m + 6); const dot = tail.indexOf('.'); if (dot === -1) return null;
  const name = tail.slice(0, dot);
  if (FONT_WHITELIST.indexOf(name) === -1) return null;
  const woff2 = path.join(KATEX, 'fonts', name + '.woff2'); if (!fs.existsSync(woff2)) return null;
  const b64 = fs.readFileSync(woff2).toString('base64');
  const srcAt = block.indexOf('src:'); if (srcAt === -1) return null;
  return block.slice(0, srcAt) + 'src:url(data:font/woff2;base64,' + b64 + ') format("woff2")}';
}

const CSS = ['10_style.css', '15_page.css', '16_shm.css'];
const JS = [
  '30_physics.js',
  '40_draw.js',
  '42_parts.js',
  '45_sim.js',
  '47_graph.js',
  '50_mode1.js',
  '52_mode2.js', '53_m2tunnel.js', '54_mode2s8.js', '56_mode3.js', '57_m3img.js', '58_mode4.js', '59_mode4b.js', '60_m4launch.js',
  '80_page.js',
  '84_sitenav.js',
  '85_design.js',
  '90_boot.js'
];

function build() {
  const katexCss = inlineKatexCss();
  const katexJs = read(path.join(KATEX, 'katex.min.js'));
  const css = CSS.map(f => '/* ===== ' + f + ' ===== */\n' + read(path.join(SRC, f))).join('\n');
  const js = JS.filter(f => fs.existsSync(path.join(SRC, f)))
    .map(f => '/* ===== ' + f + ' ===== */\n' + read(path.join(SRC, f))).join('\n');
  const html = '<!DOCTYPE html>\n<html lang="ja">\n<head>\n' + read(path.join(SRC, '00_head.html')) +
    '<style>' + katexCss + '</style>\n<style>\n' + minCss(css) + '\n</style>\n</head>\n<body id="top">\n' +
    read(path.join(SRC, '20_body.html')) +
    '<script>' + katexJs + '</script>\n<script>\n' + minJs(js) + '\n</script>\n' +
    read(path.join(SRC, '99_footer.html')) + '\n</body>\n</html>\n';
  fs.mkdirSync(path.dirname(OUT), { recursive: true });
  fs.writeFileSync(OUT, html, 'utf8');
  console.log('出力: ' + OUT + ' (' + (Buffer.byteLength(html) / 1024).toFixed(0) + ' KB)');
}
build();
