/* ---------------- ②-3 熱力学第二法則（大学の内容）：2 つのアニメ ----------------
   左：室温の部屋に置いた氷がとける。右：振り子が空気の抵抗などで止まる（力学的エネルギー → 熱）。
   「逆向きに再生する」を ON にすると、時間を逆にした映像になる。エネルギー保存則には反しないのに、自然には決して起こらない。 */
var S23 = {
  TEND:14,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.rev=false;
    this.run=new Runner({
      step:function(dt){ return self.run.t>=self.TEND; },
      draw:function(){ self.draw(); },
      reset:function(){},
      info:function(r){ return '時間 <b>'+Math.min(r.t,self.TEND).toFixed(1)+'</b> s'; }
    });
    this.run.bind(sec);
    this.cr=wireChk(sec,"rev",function(on){ self.rev=on; self.run.reset(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.rev=false; self.cr.set(false); self.run.rate=1; var sb=sec.querySelector(".slowb"); if(sb) sb.classList.remove("on"); self.run.reset(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    this.draw();
  },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return clamp(W*0.52, 280, 380); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var t=Math.min(this.run.t,this.TEND), u=this.rev? this.TEND-t : t, x=u/this.TEND;   /* u … 映像の中の時刻 */
    var pw=W/2;
    /* ===== 左：氷がとける ===== */
    T(c,"① 室温（25 ℃）に置いた氷", 12, 14, {size:13, bold:true});
    var yD=H-40, cx=pw/2;
    c.save(); c.fillStyle="#c9bfb4"; c.fillRect(14,yD+14,pw-28,6); c.restore();
    c.save(); c.fillStyle="#f4f6f8"; c.strokeStyle="#8b949d"; c.lineWidth=1.5; c.beginPath(); c.ellipse(cx,yD+6,pw*0.36,14,0,0,7); c.fill(); c.stroke(); c.restore();
    var melt=clamp(x*1.1,0,1), pud=Math.sqrt(melt);
    if(pud>0.01){ c.save(); c.fillStyle="rgba(120,180,235,.55)"; c.beginPath(); c.ellipse(cx,yD+4,pw*0.31*pud+8,9*pud+2,0,0,7); c.fill(); c.restore(); }
    if(melt<1){ var s=58*Math.cbrt(1-melt); iceCube(c, cx-s/2-s*0.15, yD+2-s, s); }
    T(c, melt>=1? "すっかり水になった" : (melt>0? "とけていく" : "氷"), cx, yD+34, {size:11.5, col:COL.sub, align:"center"});
    if(!this.rev && t>0 && melt<1){ for(var i=0;i<2;i++){ var ax=cx+(i? 62:-62); heatFlow(c, ax+(i?24:-24), yD-58, ax, yD-26, 5, ((this.run.t*0.8)+i*0.5)%1); }
      T(c,"まわりの空気から熱", cx, yD-76, {size:11, col:COL.heat, align:"center", bold:true}); }
    /* ===== 右：振り子が止まる ===== */
    var ox=pw+pw/2, oy=34, L=Math.min(H-110, pw*0.55), th0=0.62, tau=8, om=2.6;
    T(c,"② 揺れている振り子", pw+12, 14, {size:13, bold:true});
    var amp=th0*Math.exp(-u/tau), th=amp*Math.cos(om*u);
    c.save(); c.fillStyle="#7f8c8d"; c.fillRect(ox-30,oy-6,60,6); c.restore();
    var bx=ox+L*Math.sin(th), by=oy+L*Math.cos(th);
    c.save(); c.strokeStyle="#3a414c"; c.lineWidth=1.5; c.beginPath(); c.moveTo(ox,oy); c.lineTo(bx,by); c.stroke(); c.restore();
    c.save(); var g=c.createRadialGradient(bx-4,by-5,2,bx,by,13); g.addColorStop(0,"#fff"); g.addColorStop(1,"#4d7ea8"); c.fillStyle=g; c.strokeStyle="#2c4a63"; c.lineWidth=1.4; c.beginPath(); c.arc(bx,by,13,0,7); c.fill(); c.stroke(); c.restore();
    /* エネルギーの棒：力学的エネルギー（青）＋熱（オレンジ）＝一定 */
    var Em=Math.exp(-2*u/tau), bxL=pw+20, byB=H-18, bw=pw-40, bh=14;
    c.save(); c.fillStyle="#1663b5"; c.fillRect(bxL, byB-bh, bw*Em, bh); c.fillStyle=COL.heat; c.fillRect(bxL+bw*Em, byB-bh, bw*(1-Em), bh);
    c.strokeStyle="#3a414c"; c.lineWidth=1; c.strokeRect(bxL, byB-bh, bw, bh); c.restore();
    T(c,"力学的エネルギー", bxL, byB-bh-9, {size:10.5, col:"#1663b5", bold:true}); T(c,"熱（空気・支点）", bxL+bw, byB-bh-9, {size:10.5, col:COL.heat, bold:true, align:"right"});
    c.save(); c.strokeStyle="#d5cfc3"; c.lineWidth=1; c.beginPath(); c.moveTo(pw,24); c.lineTo(pw,H-8); c.stroke(); c.restore();
    /* 逆向き：自然には起こらない */
    if(this.rev && this.run.t>0){ c.save(); c.fillStyle="rgba(255,255,255,.55)"; c.fillRect(0,0,W,H); c.restore();
      c.save(); c.strokeStyle="rgba(192,57,43,.85)"; c.lineWidth=8; c.lineCap="round"; var m=Math.min(W,H)*0.28;
      [[W*0.25,H*0.5],[W*0.75,H*0.5]].forEach(function(p){ c.beginPath(); c.moveTo(p[0]-m*0.55,p[1]-m*0.55); c.lineTo(p[0]+m*0.55,p[1]+m*0.55); c.moveTo(p[0]+m*0.55,p[1]-m*0.55); c.lineTo(p[0]-m*0.55,p[1]+m*0.55); c.stroke(); }); c.restore();
      T(c,"自然には決して起こらない", W/2, H/2, {size:18, bold:true, col:"#c0392b", align:"center", halo:5}); }
    notebook(c,W,H);
    this.msg.innerHTML=this.rev?
      '逆向きの映像：水がひとりでに凍り（まわりへ熱を出し）、止まっていた振り子がひとりでに揺れ始める（まわりの熱が力学的エネルギーにもどる）。<b>エネルギー保存則には反していないのに、自然には起こらない。</b>' :
      '氷はまわりの空気から熱を受け取ってとける。振り子の力学的エネルギーは、空気の抵抗などで少しずつ熱に変わり、振り子は止まる。どちらも、<b>ひとりでには逆向きに起こらない</b>（不可逆変化）。';
  }
};
