/* =========================================================================
   モード① 物質と比熱（1-1〜1-3）
   ========================================================================= */

/* ---------------- ①-1 ブラウン運動 ----------------
   水分子（小さい粒）が大きな微粒子にぶつかって、微粒子がふらふら動く。
   水分子の速さは √(絶対温度) に比例。微粒子は質量が大きいので、ゆっくり不規則に動く。 */
var S11 = {
  N:230, RM:2.6, RB:14, MB:10, V0:190,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.tc=20; this.showMol=false; this.showPath=true; this.mols=null; this.path=[];
    this.run=new Runner({
      begin:function(){},
      step:function(dt){ self.step(dt); return self.run.t>180; },
      draw:function(){ self.draw(); },
      reset:function(){ self.mols=null; self.path=[]; },
      info:function(r){ return '時間 <b>'+r.t.toFixed(1)+'</b> s'; }
    });
    this.run.bind(sec);
    this.sl=wireTSlider(sec,"t",function(v){ self.setT(v); self.draw(); self.run.label(); });
    this.cm=wireChk(sec,"mol",function(on){ self.showMol=on; mb.classList.remove("megaglow"); self.draw(); });
    var mb=sec.querySelector('button[data-chk="mol"]'); if(mb) mb.classList.add("megaglow");   /* 押されるまで思いきり光らせる */
    this.cp=wireChk(sec,"path",function(on){ self.showPath=on; if(!on) self.path=[]; self.draw(); });
    sec.querySelector(".resetall").addEventListener("click", function(){
      self.tc=20; self.sl.set(20); self.showMol=false; self.cm.set(false); self.showPath=true; self.cp.set(true);
      self.run.rate=1; var sb=sec.querySelector(".slowb"); if(sb) sb.classList.remove("on"); self.run.reset(); });
    onResize(this.cv.parentElement, function(){ self.mols=null; self.path=[]; self.draw(); });
    this.draw();
  },
  /* 顕微鏡（横から見た図）とプレパラート。プレパラートの水の位置を返す */
  microscope:function(c, x, y, w, h){
    var s=Math.min(w/120, h/230), ox=x+(w-120*s)/2, oy=y+(h-230*s)/2+6*s;
    function P(px,py){ return [ox+px*s, oy+py*s]; }
    function R(px,py,pw,ph,fill){ var p=P(px,py); c.fillStyle=fill; c.fillRect(p[0],p[1],pw*s,ph*s); c.strokeRect(p[0],p[1],pw*s,ph*s); }
    c.save(); c.strokeStyle="#3a414c"; c.lineWidth=1.3; c.lineJoin="round";
    /* アーム（C の字） */
    c.fillStyle="#5d6773"; c.beginPath(); var a=P(96,205); c.moveTo(a[0],a[1]);
    a=P(96,80); c.lineTo(a[0],a[1]); a=P(96,44); var b=P(62,36);   /* 第10回：アームの先を鏡筒の中まで入れて、つなげる */ c.quadraticCurveTo(a[0],a[1],b[0],b[1]);
    a=P(62,58); c.lineTo(a[0],a[1]); a=P(82,60); b=P(82,84); c.quadraticCurveTo(a[0],a[1],b[0],b[1]);
    a=P(82,205); c.lineTo(a[0],a[1]); c.closePath(); c.fill(); c.stroke();
    /* 台 */
    c.fillStyle="#4a535e"; c.beginPath(); a=P(14,226); c.moveTo(a[0],a[1]); a=P(24,205); c.lineTo(a[0],a[1]); a=P(112,205); c.lineTo(a[0],a[1]); a=P(118,226); c.lineTo(a[0],a[1]); c.closePath(); c.fill(); c.stroke();
    /* 鏡筒・接眼レンズ・対物レンズ */
    R(40,26,26,92,"#e9edf1"); R(43,6,20,22,"#cfd6de"); R(45,118,16,14,"#cfd6de"); R(48,132,10,10,"#b8c1cb");
    /* 調節ねじ */
    var kn=P(98,112); c.fillStyle="#cfd6de"; c.beginPath(); c.arc(kn[0],kn[1],7*s,0,7); c.fill(); c.stroke();
    /* ステージ */
    R(18,156,68,7,"#6b7480");
    /* 光源（台の上） */
    var mr=P(53,205); c.fillStyle="#fff6c9"; c.beginPath(); c.ellipse(mr[0],mr[1],9*s,4*s,0,Math.PI,0); c.fill(); c.stroke();
    /* プレパラート（スライドガラス・水・カバーガラス） */
    c.fillStyle="rgba(200,225,245,.9)"; a=P(20,151); c.fillRect(a[0],a[1],66*s,5*s); c.strokeRect(a[0],a[1],66*s,5*s);
    c.fillStyle="#7fb7e3"; a=P(44,148.5); c.fillRect(a[0],a[1],18*s,2.6*s);
    c.fillStyle="rgba(235,245,252,.95)"; a=P(41,147); c.fillRect(a[0],a[1],24*s,1.8*s); c.strokeRect(a[0],a[1],24*s,1.8*s);
    c.restore();
    var lt=P(60,6), la=P(30,157), lb=P(26,180);
    T(c,"顕微鏡", lt[0]+8, lt[1]+8, {size:12, bold:true, col:COL.ink});
    c.save(); c.strokeStyle="#1f6fb2"; c.lineWidth=1; c.beginPath(); c.moveTo(la[0],la[1]); c.lineTo(lb[0],lb[1]-7); c.stroke(); c.restore();
    T(c,"プレパラート", lb[0]-14, lb[1]+2, {size:11, bold:true, col:"#1f6fb2"});
    var w0=P(53,149);
    return {x:w0[0], y:w0[1]};
  },
  vScale:function(tc){ return Math.sqrt(Math.max(0,tc+273)/293); },
  setT:function(v){
    var k0=this.vScale(this.tc), k1=this.vScale(v); this.tc=v;
    if(!this.mols) return;
    var f=(k0>1e-6)? k1/k0 : 0;
    if(k0<1e-6 && k1>0){ this.mols=null; return; }            /* 絶対零度から温めたときは配りなおす */
    this.mols.forEach(function(m){ m.vx*=f; m.vy*=f; }); this.B.vx*=f; this.B.vy*=f;
  },
  make:function(g){
    var a=[], k=this.vScale(this.tc), self=this;
    for(var i=0;i<this.N;i++){
      var x, y; do{ x=g.x0+6+Math.random()*(g.x1-g.x0-12); y=g.y0+6+Math.random()*(g.y1-g.y0-12); }while(Math.hypot(x-(g.x0+g.x1)/2, y-(g.y0+g.y1)/2)<this.RB+6);
      var sp=this.V0*k*Math.sqrt(-2*Math.log(1-Math.random()*0.999))/1.25, th=Math.random()*6.283;
      a.push({x:x, y:y, vx:sp*Math.cos(th), vy:sp*Math.sin(th)});
    }
    this.mols=a; this.B={x:(g.x0+g.x1)/2, y:(g.y0+g.y1)/2, vx:0, vy:0}; this.path=[{x:this.B.x, y:this.B.y}];
  },
  step:function(dt){
    var g=this.g; if(!g || !this.mols) return;
    var n=Math.max(1, Math.ceil(dt/0.006)), h=dt/n, B=this.B, rr=this.RM+this.RB, M=this.MB;
    for(var s=0;s<n;s++){
      B.x+=B.vx*h; B.y+=B.vy*h;
      if(B.x<g.x0+this.RB){ B.x=g.x0+this.RB; B.vx=Math.abs(B.vx); } if(B.x>g.x1-this.RB){ B.x=g.x1-this.RB; B.vx=-Math.abs(B.vx); }
      if(B.y<g.y0+this.RB){ B.y=g.y0+this.RB; B.vy=Math.abs(B.vy); } if(B.y>g.y1-this.RB){ B.y=g.y1-this.RB; B.vy=-Math.abs(B.vy); }
      for(var i=0;i<this.mols.length;i++){ var m=this.mols[i];
        m.x+=m.vx*h; m.y+=m.vy*h;
        if(m.x<g.x0+this.RM){ m.x=2*(g.x0+this.RM)-m.x; m.vx=-m.vx; } if(m.x>g.x1-this.RM){ m.x=2*(g.x1-this.RM)-m.x; m.vx=-m.vx; }
        if(m.y<g.y0+this.RM){ m.y=2*(g.y0+this.RM)-m.y; m.vy=-m.vy; } if(m.y>g.y1-this.RM){ m.y=2*(g.y1-this.RM)-m.y; m.vy=-m.vy; }
        var dx=m.x-B.x, dy=m.y-B.y, d=Math.hypot(dx,dy);
        if(d<rr && d>1e-6){ var nx=dx/d, ny=dy/d, vrel=(m.vx-B.vx)*nx+(m.vy-B.vy)*ny;
          if(vrel<0){ var J=2*vrel/(1+1/M);            /* 弾性衝突（水分子の質量 1、微粒子 M） */
            m.vx-=J*nx; m.vy-=J*ny; B.vx+=J*nx/M; B.vy+=J*ny/M; }
          m.x=B.x+nx*rr; m.y=B.y+ny*rr; }
      }
    }
    if(this.showPath){ var L=this.path[this.path.length-1]; if(!L || Math.hypot(L.x-B.x,L.y-B.y)>2.5){ this.path.push({x:B.x,y:B.y}); if(this.path.length>900) this.path.shift(); } }
  },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return clamp(W*0.62, 280, 400); }), c=f.c, W=f.W, H=f.H;
    /* 第5回：左に顕微鏡とプレパラート、右に顕微鏡で見たようす */
    var mw=clamp(W*0.27, 104, 200), g={x0:mw+8, y0:12, x1:W-12, y1:H-12}; this.g=g;
    if(!this.mols || this._W!==W){ this._W=W; this.make(g); }
    c.clearRect(0,0,W,H);
    var sl=this.microscope(c, 6, 10, mw-14, H-20);
    /* プレパラートから「見えている範囲」へ、拡大の点線 */
    c.save(); c.strokeStyle="rgba(47,111,159,.5)"; c.lineWidth=1; c.setLineDash([4,4]); c.beginPath();
    c.moveTo(sl.x, sl.y); c.lineTo(g.x0, g.y0+4); c.moveTo(sl.x, sl.y); c.lineTo(g.x0, g.y1-4); c.stroke(); c.restore();
    c.save(); c.fillStyle="#dcecf7"; rrect(c,g.x0,g.y0,g.x1-g.x0,g.y1-g.y0,10); c.fill(); c.restore();
    if(this.showPath && this.path.length>1){ c.save(); c.strokeStyle="rgba(192,57,43,.75)"; c.lineWidth=1.6; c.lineJoin="round"; c.beginPath();
      this.path.forEach(function(p,i){ if(i) c.lineTo(p.x,p.y); else c.moveTo(p.x,p.y); }); c.stroke(); c.restore(); }
    if(this.showMol){ c.save(); c.fillStyle="#2f7fd6";
      this.mols.forEach(function(m){ c.beginPath(); c.arc(m.x,m.y,self.RM,0,7); c.fill(); }); c.restore(); }
    var B=this.B, gr=c.createRadialGradient(B.x-5,B.y-6,2,B.x,B.y,this.RB);
    gr.addColorStop(0,"#fff3c4"); gr.addColorStop(1,"#d49a2a");
    c.save(); c.fillStyle=gr; c.strokeStyle="#8a5a12"; c.lineWidth=1.4; c.beginPath(); c.arc(B.x,B.y,this.RB,0,7); c.fill(); c.stroke(); c.restore();
    /* 温度計（水にさしこむ） */
    thermometer(c, g.x1-34, g.y1-38, g.y0+30, this.tc, -273, 100, {ticks:[-273,0,100], dec:0});
    /* スタート前だけ、何が見えているかを書く */
    if(this.run.state==="idle"){
      T(c,"水", g.x0+16, g.y1-18, {size:15, bold:true, col:"#1f6fb2", halo:true});
      c.save(); c.strokeStyle="#8a5a12"; c.lineWidth=1.2; c.beginPath(); c.moveTo(B.x+this.RB*0.75, B.y-this.RB*0.75); c.lineTo(B.x+this.RB+16, B.y-this.RB-14); c.stroke(); c.restore();
      T(c,"花粉", B.x+this.RB+18, B.y-this.RB-18, {size:15, bold:true, col:"#8a5a12", halo:true});
    }
    var lab=this.showMol? "青い点：水分子" : "顕微鏡で見えるのは、微粒子（黄色）の動きだけ";
    T(c, lab, g.x0+10, g.y0+14, {size:11.5, col:COL.sub, halo:true});
    notebook(c,W,H);
    var K=this.tc+273;
    this.msg.innerHTML='水の温度 <span class="num">'+this.tc.toFixed(0)+'</span> ℃（絶対温度 <span class="num">'+K.toFixed(0)+'</span> K）'+
      (K<=0? '　<b>絶対零度：水分子も微粒子も止まる</b>' : '　水分子の速さは、20 ℃ のときの <span class="num">'+this.vScale(this.tc).toFixed(2)+'</span> 倍');
  }
};

/* ---------------- ①-2 物質の三態 ----------------
   左から固体（氷）・液体（水）・気体（水蒸気）。3 つとも温度計をさしておく。
   スライダー 1 本で、3 つとも「それぞれの状態のまま」温度を上げる。 */
var S12 = {
  RNG:[[-40,-5],[5,95],[105,200]], NAMES:["固体（氷）","液体（水）","気体（水蒸気）"],
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.u=0.3; this.clk=0; this.liq=null; this.gas=null;
    this.run=new Runner({
      step:function(dt){ self.clk+=dt; self.step(dt); return false; },
      draw:function(){ self.draw(); },
      reset:function(){ self.clk=0; self.liq=null; self.gas=null; },
      info:function(){ return ''; }
    });
    this.run.bind(sec);
    this.sl=wireTSlider(sec,"u",function(v){ var k0=self.gasK(); self.u=v/100; var k1=self.gasK();
      if(self.gas) self.gas.forEach(function(p){ p.vx*=k1/k0; p.vy*=k1/k0; }); self.draw(); self.run.label(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.u=0.3; self.sl.set(30); self.run.rate=1;
      var sb=sec.querySelector(".slowb"); if(sb) sb.classList.remove("on"); self.run.reset(); });
    onResize(this.cv.parentElement, function(){ self.liq=null; self.gas=null; self.draw(); });
    this.draw();
  },
  temp:function(i){ var r=this.RNG[i]; return r[0]+(r[1]-r[0])*this.u; },
  lvAbs:function(tc){ return clamp((tc+50)/250,0,1); },   /* 色は 3 つ共通の物差しで（氷が青、水蒸気が赤み） */
  gasK:function(){ return Math.sqrt((this.temp(2)+273)/373); },
  box:function(i,W,H){ var gap=14, bw=(W-24-2*gap)/3, x=12+i*(bw+gap); return {x:x, y:58, w:bw, h:H-58-14}; },
  initParts:function(W,H){
    /* 第5回：液体の粒子も、固体・気体と同じように箱全体に散らばせる（温度計の分だけ右をあける） */
    var b=this.box(1,W,H), r=8.5, a=[], iw=b.w-44, ih=b.h-20, nx=3, ny=5;
    for(var i=0;i<nx*ny;i++){ var ix=i%nx, iy=Math.floor(i/nx);
      a.push({x:b.x+10+r+(iw-2*r)*(ix+0.5+(Math.random()-0.5)*0.5)/nx, y:b.y+10+r+(ih-2*r)*(iy+0.5+(Math.random()-0.5)*0.5)/ny, vx:(Math.random()-0.5)*40, vy:(Math.random()-0.5)*40}); }
    this.liq=a;
    var bg=this.box(2,W,H), k=this.gasK(), q=[];
    for(var j=0;j<7;j++){ var th=Math.random()*6.283, sp=110*k*(0.7+Math.random()*0.6);
      q.push({x:bg.x+20+Math.random()*(bg.w-40), y:bg.y+20+Math.random()*(bg.h-40), vx:sp*Math.cos(th), vy:sp*Math.sin(th)}); }
    this.gas=q;
  },
  step:function(dt){
    if(!this.liq) return; var W=this._W, H=this._H, r=8.5;
    /* 液体：近くの粒子と押し合いながら動きまわる（箱全体に散らばる） */
    var b=this.box(1,W,H), lv=this.u, sp=25+70*lv, L=this.liq, n=Math.max(1,Math.ceil(dt/0.01)), h=dt/n;
    for(var s=0;s<n;s++){
      L.forEach(function(p){ p.vx+=(Math.random()-0.5)*sp*6*h; p.vy+=(Math.random()-0.5)*sp*6*h;
        var v=Math.hypot(p.vx,p.vy); if(v>sp){ p.vx*=sp/v; p.vy*=sp/v; } });
      for(var i=0;i<L.length;i++) for(var j=i+1;j<L.length;j++){ var A=L[i], B=L[j], dx=B.x-A.x, dy=B.y-A.y, d=Math.hypot(dx,dy)||1;
        if(d<2*r+1){ var o=(2*r+1-d)/2, nx=dx/d, ny=dy/d; A.x-=nx*o; A.y-=ny*o; B.x+=nx*o; B.y+=ny*o;
          var rv=(B.vx-A.vx)*nx+(B.vy-A.vy)*ny; if(rv<0){ A.vx+=rv*nx; A.vy+=rv*ny; B.vx-=rv*nx; B.vy-=rv*ny; } }
        else if(d<2*r+9){ var k2=6*h; A.vx+=dx/d*k2; A.vy+=dy/d*k2; B.vx-=dx/d*k2; B.vy-=dy/d*k2; } }   /* 引き合う力（結びつき） */
      L.forEach(function(p){ p.x+=p.vx*h; p.y+=p.vy*h;
        if(p.x<b.x+r+2){ p.x=b.x+r+2; p.vx=Math.abs(p.vx); } if(p.x>b.x+b.w-r-36){ p.x=b.x+b.w-r-36; p.vx=-Math.abs(p.vx); }
        if(p.y>b.y+b.h-r-2){ p.y=b.y+b.h-r-2; p.vy=-Math.abs(p.vy); } if(p.y<b.y+r+2){ p.y=b.y+r+2; p.vy=Math.abs(p.vy); } });
    }
    /* 気体：ばらばらに飛びまわる */
    var bg=this.box(2,W,H);
    this.gas.forEach(function(p){ p.x+=p.vx*dt; p.y+=p.vy*dt;
      if(p.x<bg.x+r+2){ p.x=bg.x+r+2; p.vx=Math.abs(p.vx); } if(p.x>bg.x+bg.w-r-2){ p.x=bg.x+bg.w-r-2; p.vx=-Math.abs(p.vx); }
      if(p.y<bg.y+r+2){ p.y=bg.y+r+2; p.vy=Math.abs(p.vy); } if(p.y>bg.y+bg.h-r-2){ p.y=bg.y+bg.h-r-2; p.vy=-Math.abs(p.vy); } });
  },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return clamp(W*0.55, 250, 360); }), c=f.c, W=f.W, H=f.H;
    if(!this.liq || this._W!==W || this._H!==H){ this._W=W; this._H=H; this.initParts(W,H); }
    c.clearRect(0,0,W,H);
    for(var i=0;i<3;i++){
      var b=this.box(i,W,H), tc=this.temp(i), lv=this.lvAbs(tc);
      c.save(); c.fillStyle="#fbfcfd"; c.strokeStyle="#3a414c"; c.lineWidth=1.8; c.fillRect(b.x,b.y,b.w,b.h); c.strokeRect(b.x,b.y,b.w,b.h); c.restore();
      T(c, this.NAMES[i], b.x+b.w/2, 16, {size:14, bold:true, align:"center"});
      if(i===0) latticeParticles(c, b.x+10, b.y+10, b.w-44, b.h-20, this.u, this.clk, {nx:3, ny:4, r:8.5, a0:0.6, a1:5, col:heatCol(lv)});
      if(i===1) this.liq.forEach(function(p){ ball(c,p.x,p.y,8.5,0,heatCol(lv)); });
      if(i===2){ this.gas.forEach(function(p){ ball(c,p.x,p.y,8.5,0,heatCol(lv)); });
        /* 速度の矢印（青）：粒子と重ならないよう、粒子のふちから出す */
        c.save(); c.beginPath(); c.rect(b.x+1,b.y+1,b.w-2,b.h-2); c.clip();
        this.gas.forEach(function(p){ var v=Math.hypot(p.vx,p.vy)||1, ux=p.vx/v, uy=p.vy/v, L=v*0.22;
          arrow(c, p.x+ux*11, p.y+uy*11, p.x+ux*(11+L), p.y+uy*(11+L), COL.vel, 1.8, 7); }); c.restore(); }
      /* 温度計（上からさしこむ） */
      /* 3 本とも同じ目盛り（−60〜220 ℃）。氷の赤い液は低く、水蒸気は高い */
      thermometer(c, b.x+b.w-24, b.y+b.h-22, 30, tc, -60, 220, {ticks:[-50,0,100,200], side:"left", dec:0, vsize:12});
    }
    var g0=this.box(0,W,H), g2=this.box(2,W,H);
    notebook(c,W,H);
    /* 第7回：図の下の数値の箱は出さない（温度は温度計で読む） */
    if(this.msg) this.msg.style.display="none";
  }
};

