/* ---------------- ①-3 物質に加えた熱と状態変化 ----------------
   三脚の上のビーカーに固体 100 g。バーナーで一定の割合で熱を加える。右上の大きなボタンで「水」「エタノール」。
   上：温度と加えた熱量のグラフ（横幅は実際の熱量の比）、下：ビーカー（温度計をさす）と、水面のあたりの粒子のようす。
   時間バーで、好きな時刻へ戻したり進めたりできる（状態は時刻 t だけで決まる）。 */
var SUBST13 = {
  water:{name:"水", sol:"氷", liq:"水", gas:"水蒸気", T0:-20, Tm:0, Tb:100, ci:1.93, Lf:334, cl:4.18, Lv:2257, cv:2.06, Tmin:-30, Tmax:140},
  eth:{name:"エタノール", sol:"固体のエタノール", liq:"液体のエタノール", gas:"気体のエタノール", T0:-130, Tm:-114, Tb:78, ci:1.0, Lf:109, cl:2.42, Lv:838, cv:1.42, Tmin:-140, Tmax:120}
};
var S13 = {
  M:100, RATE:3000, DV:20,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.sub="water"; this.clk=0; this.gasP=[]; this.bub=[]; this.setup();
    this.run=new Runner({
      startText:"▶ スタート（加熱する）",
      step:function(dt){ self.clk+=dt; self.stepParts(dt); return self.run.t>=self.tEnd; },
      draw:function(){ self.draw(); },
      reset:function(){ self.bub=[]; self.gasP=[]; },
      info:function(){ return ''; }
    });
    this.run.bind(sec);
    this.tb=wireTimeBar(sec, this.run, function(){ return self.tEnd; }, function(){ self.bub=[]; self.gasP=[]; });
    /* 右上の大きなボタン：水／エタノール */
    var bx=document.createElement("div"); bx.className="subbtns";
    bx.innerHTML='<button type="button" data-s="water" class="on">水</button><button type="button" data-s="eth">エタノール</button>';
    this.cv.parentElement.style.position="relative"; this.cv.parentElement.appendChild(bx); this.subBox=bx;
    var pick=function(k){ self.sub=k; bx.querySelectorAll("button").forEach(function(b){ b.classList.toggle("on", b.dataset.s===k); }); self.setup(); self.run.reset(); };
    bx.querySelectorAll("button").forEach(function(b){ b.addEventListener("click", function(){ pick(b.dataset.s); }); });
    this.pick=pick;
    sec.querySelector(".resetall").addEventListener("click", function(){ self.run.rate=1; var sb=sec.querySelector(".slowb"); if(sb) sb.classList.remove("on"); pick("water"); });
    var anim=function(){ if(self.sec.offsetParent!==null && self.run.state!=="run"){ self.clk+=0.016; self.stepParts(0.016, true); self.draw(); } requestAnimationFrame(anim); };
    onResize(this.cv.parentElement, function(){ self.draw(); });
    this.draw(); requestAnimationFrame(anim);
  },
  /* 熱量の区間と、それぞれにかかる時間（沸騰の間は早送り） */
  setup:function(){
    var d=SUBST13[this.sub], m=this.M; this.d=d;
    this.Qs=[m*d.ci*(d.Tm-d.T0), m*d.Lf, m*d.cl*(d.Tb-d.Tm), m*d.Lv, m*d.cv*this.DV];
    this.Qtot=this.Qs.reduce(function(a,b){ return a+b; },0);
    /* 第5回：グラフの横軸は、水とエタノールで共通の物差し（多い方＝水の全熱量） */
    var self=this; this.Qscale=Math.max.apply(null, Object.keys(SUBST13).map(function(k){ var e=SUBST13[k]; return m*(e.ci*(e.Tm-e.T0)+e.Lf+e.cl*(e.Tb-e.Tm)+e.Lv+e.cv*self.DV); }));
    var R=this.RATE; this.ff=[1,1,1,Math.max(1, this.Qs[3]/(R*12)),1];
    this.dur=this.Qs.map(function(q,i){ return q/(R*this.ff[i]); }, this);
    this.tEnd=this.dur.reduce(function(a,b){ return a+b; },0);
  },
  Qof:function(t){ var a=0, q=0; for(var k=0;k<5;k++){ if(t<=a+this.dur[k]) return q+(t-a)*this.RATE*this.ff[k]; a+=this.dur[k]; q+=this.Qs[k]; } return this.Qtot; },
  ffAt:function(t){ var a=0; for(var k=0;k<5;k++){ if(t<=a+this.dur[k]) return this.ff[k]; a+=this.dur[k]; } return 1; },
  /* いまの状態：ph 0 固体が温まる／1 とける／2 液体が温まる／3 沸騰／4 気体が温まる。fm＝とけた割合、fv＝蒸発した割合 */
  stateQ:function(q){
    var Qs=this.Qs, d=this.d, ph=0, acc=0;
    for(ph=0; ph<5; ph++){ if(q<=acc+Qs[ph]+1e-9) break; acc+=Qs[ph]; } if(ph>4) ph=4;
    var x=Qs[ph]>0? clamp((q-acc)/Qs[ph],0,1) : 1, T, fm=0, fv=0;
    if(ph===0){ T=d.T0+(d.Tm-d.T0)*x; } else if(ph===1){ T=d.Tm; fm=x; } else if(ph===2){ T=d.Tm+(d.Tb-d.Tm)*x; fm=1; }
    else if(ph===3){ T=d.Tb; fm=1; fv=x; } else { T=d.Tb+this.DV*x; fm=1; fv=1; }
    return {ph:ph, T:T, fm:fm, fv:fv, Q:q};
  },
  stepParts:function(dt, idle){
    var st=this.stateQ(this.Qof(this.run.t));
    if(!idle && st.ph===3 && Math.random()<dt*14) this.bub.push({u:Math.random(), y:0, r:2+Math.random()*3});
    for(var i=this.bub.length-1;i>=0;i--){ this.bub[i].y+=dt*(0.9+this.bub[i].r*0.12); if(this.bub[i].y>1) this.bub.splice(i,1); }
    /* 拡大の窓の気体の粒子：液面から飛び出し、窓の外へ出ていく */
    var z=this.z; if(!z) return;
    if(!idle && st.ph===3 && Math.random()<dt*7) this.gasP.push({x:z.x+12+Math.random()*(z.w-24), y:z.ys-8, vx:(Math.random()-0.5)*60, vy:-(70+Math.random()*60)});
    if(!idle && st.ph===4 && Math.random()<dt*5) this.gasP.push({x:z.x+12+Math.random()*(z.w-24), y:z.y+z.h-10, vx:(Math.random()-0.5)*90, vy:-(110+Math.random()*80)});
    for(var j=this.gasP.length-1;j>=0;j--){ var p=this.gasP[j]; p.x+=p.vx*dt; p.y+=p.vy*dt;
      if(p.x<z.x+8){ p.x=z.x+8; p.vx=Math.abs(p.vx); } if(p.x>z.x+z.w-8){ p.x=z.x+z.w-8; p.vx=-Math.abs(p.vx); }
      if(p.y<z.y-70) this.gasP.splice(j,1); }
  },
  draw:function(){
    var self=this, d=this.d, f=fitCanvas(this.cv, function(W){ return clamp(W*0.92, 460, 620); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var q=this.Qof(this.run.t), st=this.stateQ(q);
    if(this.tb) this.tb.sync();
    /* ===== 上：グラフ ===== */
    var gx0=96, gy0=Math.round(H*0.43), gx1=W-16, gy1=52;
    var Tmin=d.Tmin, Tmax=d.Tmax;
    var X=function(qq){ return gx0+(gx1-14-gx0)*qq/self.Qscale; }, Y=function(t){ return gy0-(gy0-gy1-12)*(t-Tmin)/(Tmax-Tmin); };
    var acc=[0]; this.Qs.forEach(function(qq,i){ acc.push(acc[i]+qq); });
    var nm=[d.sol, d.sol+"と"+d.liq, d.liq, d.liq+"と"+d.gas, d.gas];
    var rc=["rgba(120,150,230,.20)","rgba(120,170,230,.16)","rgba(110,180,240,.20)","rgba(240,140,140,.12)","rgba(240,120,120,.20)"];
    for(var i=0;i<5;i++){ var xa=X(acc[i]), xb=X(acc[i+1]); c.fillStyle=rc[i]; c.fillRect(xa, Y(Tmax)+6, xb-xa, Y(Tmin)-Y(Tmax)-6); }
    c.save(); c.setLineDash([3,4]); c.strokeStyle="#b9c0c8"; c.lineWidth=1;
    [d.Tm,d.Tb].forEach(function(t){ c.beginPath(); c.moveTo(gx0,Y(t)); c.lineTo(gx1-14,Y(t)); c.stroke(); });
    for(var i2=1;i2<5;i2++){ c.beginPath(); c.moveTo(X(acc[i2]),Y(Tmin)); c.lineTo(X(acc[i2]),Y(Tmax)+6); c.stroke(); }
    c.restore();
    T(c, d.Tm+"（融点）", gx0-4, Y(d.Tm), {size:10.5, col:COL.sub, align:"right"}); T(c, d.Tb+"（沸点）", gx0-4, Y(d.Tb), {size:10.5, col:COL.sub, align:"right"});
    axes(c, gx0, gy0, gx1, gy1, "加えた熱量 Q", "温度〔℃〕");
    var curve=function(qq){ return self.stateQ(qq).T; };
    c.save(); c.strokeStyle="rgba(105,113,125,.55)"; c.setLineDash([4,4]); c.lineWidth=1.3; c.beginPath();
    for(var k2=0;k2<=240;k2++){ var qa=this.Qtot*k2/240; if(k2) c.lineTo(X(qa),Y(curve(qa))); else c.moveTo(X(qa),Y(curve(qa))); } c.stroke(); c.restore();
    c.save(); c.strokeStyle="#d1352b"; c.lineWidth=3; c.lineJoin="round"; c.beginPath();
    for(var k3=0;k3<=300;k3++){ var qb=q*k3/300; if(k3) c.lineTo(X(qb),Y(curve(qb))); else c.moveTo(X(qb),Y(curve(qb))); } c.stroke(); c.restore();
    c.save(); c.fillStyle="#d1352b"; c.beginPath(); c.arc(X(q),Y(st.T),4.5,0,7); c.fill(); c.restore();
    var dbl=function(xa,xb,y,lab1,lab2){ arrow(c,(xa+xb)/2,y,xa+2,y,COL.heat,2.4,8); arrow(c,(xa+xb)/2,y,xb-2,y,COL.heat,2.4,8);
      var wl=Math.max(70, Math.min(xb-xa-10, 92)); c.save(); c.fillStyle="#fff4e5"; c.strokeStyle=COL.heat; c.lineWidth=1; rrect(c,(xa+xb)/2-wl/2,y-30,wl,24,5); c.fill(); c.stroke(); c.restore();
      T(c,lab1,(xa+xb)/2,y-23,{size:10.5,bold:true,align:"center",col:"#9c4e06"}); T(c,lab2,(xa+xb)/2,y-12,{size:10,align:"center",col:"#9c4e06"}); };
    if(q>acc[1]+1) dbl(X(acc[1]),X(acc[2]),Y(d.Tm)-12,"融解熱",d.Lf+" J/g");
    if(q>acc[3]+1) dbl(X(acc[3]),X(acc[4]),Y(d.Tb)-12,"蒸発熱",d.Lv+" J/g");
    for(var i3=0;i3<5;i3++){ var xa2=X(acc[i3]), xb2=X(acc[i3+1]); if(xb2-xa2>40){ var lab=nm[i3]; if(lab.length*10>xb2-xa2) lab=["固体","固体と液体","液体","液体と気体","気体"][i3];
      T(c, lab, (xa2+xb2)/2, Y(Tmin)-9, {size:10.5, align:"center", col:(i3>=3?"#c0392b":"#1f6fb2"), bold:true}); } }
    /* ===== 下：三脚・ビーカー・バーナー ===== */
    var yDesk=H-14, cxB=Math.max(110, W*0.21), bw=Math.min(160, W*0.26), bh=bw*0.80;
    c.save(); c.fillStyle="#c9bfb4"; c.fillRect(8,yDesk,W*0.48,5); c.restore();
    var on=(this.run.state==="run");
    var yTop=yDesk-Math.max(78, bh*0.72);
    burner(c, cxB, yDesk, on, this.clk, 1);
    tripod(c, cxB, yTop, yDesk, bw+26);
    var bx0=cxB-bw/2, by0=yTop-bh, yb=by0+bh-2;
    var s=bw*0.27, hs=s*1.95, L1=hs*0.62;                 /* 氷の山の高さ、とけきったときの液面 */
    var liqH=L1*st.fm*(1-st.fv), wTop=yb-liqH;
    c.save(); c.beginPath(); c.rect(bx0+1,by0+4,bw-2,bh-5); c.clip();
    if(liqH>0.5){ c.fillStyle=(this.sub==="water")? "rgba(90,160,225,.55)" : "rgba(150,190,220,.45)"; c.fillRect(bx0, wTop, bw, liqH);
      c.strokeStyle="#2f6f9f"; c.lineWidth=1.5; c.beginPath(); c.moveTo(bx0,wTop); c.lineTo(bx0+bw,wTop); c.stroke(); }
    /* 固体：下の方からとけていく（液面より上の部分だけ描く）。とけるにつれて少し沈む */
    if(st.fm<1){ var sink=(hs-L1)*st.fm; c.save(); c.beginPath(); c.rect(bx0, by0-200, bw, (yb-L1*st.fm)-(by0-200)); c.clip();
      iceStack(c, cxB, yb+sink, s, (this.sub==="water")? 1 : 0.85); c.restore(); }
    this.bub.forEach(function(b){ var yy=yb-2-b.y*(liqH-6); if(liqH>8){ c.strokeStyle="rgba(255,255,255,.95)"; c.lineWidth=1.2; c.beginPath(); c.arc(bx0+10+b.u*(bw-20), yy, b.r, 0, 7); c.stroke(); } });
    c.restore();
    beakerGlass(c, bx0, by0, bw, bh);
    if(st.ph===3 && on){ c.save(); c.strokeStyle="rgba(150,160,170,.45)"; c.lineWidth=2;
      for(var w=0;w<3;w++){ var xw=bx0+bw*(0.3+0.2*w), ph=this.clk*2+w; c.beginPath();
        for(var k4=0;k4<=10;k4++){ c.lineTo(xw+5*Math.sin(ph+k4*0.6), by0-4-k4*4); } c.stroke(); } c.restore(); }
    thermometer(c, bx0+bw-18, yb-12, by0-62, st.T, d.Tmin, d.Tmax, {ticks:[d.Tm, d.Tb], dec:0});
    T(c, d.name+" 100 g", bx0+4, by0-12, {size:12, bold:true});
    /* スタート前だけ、固体の名前を書く */
    if(this.run.state==="idle" && q<=0) T(c, d.sol, cxB-8, yb-hs-12, {size:13, bold:true, col:"#1f6fb2", align:"center", halo:true});
    T(c,"バーナー", cxB+28, yDesk-10, {size:10.5, col:COL.sub});
    /* ===== 拡大の窓：液面（固体の上の面）のあたり。窓の外へ飛んでいく気体の粒子も描く ===== */
    var zx=bx0+bw+40, zw=Math.min(210, W-zx-112), zy=by0-6, zh=Math.min(150, yDesk-zy-8);
    if(zw>100){
      var ys=zy+zh*0.50+zh*0.42*st.fv*(st.ph>=3?1:0);     /* 拡大の窓の中の物質の上の面 */
      this.z={x:zx, y:zy, w:zw, h:zh, ys:ys};
      c.save(); c.strokeStyle="rgba(47,111,159,.55)"; c.lineWidth=1; c.setLineDash([3,3]); c.beginPath(); c.moveTo(bx0+bw*0.45, (liqH>2? wTop : yb-hs*0.5)); c.lineTo(zx, zy+zh*0.5); c.stroke(); c.restore();
      c.save(); c.fillStyle="#fbfdff"; c.strokeStyle="#2f6f9f"; c.lineWidth=1.6; rrect(c,zx,zy,zw,zh,8); c.fill(); c.stroke(); c.clip();
      this.zoom(c, zx, zy, zw, zh, ys, st); c.restore();
      /* 窓の外へ出ていく粒子（うすくなりながら） */
      /* 気体の粒子：液面（気体だけになったら窓の下）から上へ飛び、窓の外へ出ていく。止めていても、時間バーで動かしても見えるように、時刻から位置を決める */
      if(st.ph>=3){ var n=(st.ph===3)? 2+Math.round(7*st.fv) : 9, y0=(st.ph===3)? ys-6 : zy+zh-8, span=y0-(zy-70);
        for(var i=0;i<n;i++){ var p=PH[i+40], u=((i*0.618)+self.clk*(0.16+0.10*p[2]))%1, gy=y0-u*span, gx=zx+10+(((i*0.377)+0.08*Math.sin(self.clk*1.7*p[2]+p[0]))%1)*(zw-20);
          var al=(gy<zy)? clamp(1-(zy-gy)/70,0,1) : 1; c.save(); c.globalAlpha=al; ball(c,gx,gy,6.5,0,heatCol(0.9)); c.restore(); } }
      /* 第7回：何が起こっているかを小さく書く */
      if(st.ph===2) T(c,"蒸発が起こっている", zx+zw/2, zy+zh+12, {size:10.5, bold:true, col:"#c0392b", align:"center", halo:true});
      if(st.ph===3) T(c,"沸騰：液体の内部からも気体になる", zx+zw/2, zy+zh+12, {size:10.5, bold:true, col:"#c0392b", align:"center", halo:true});
      var stName=(this.sub==="water"? [d.sol+"（固体）", "固体と液体", d.liq+"（液体）", "液体と気体", d.gas+"（気体）"] : ["固体","固体と液体","液体","液体と気体","気体"])[st.ph], stCol=(st.ph>=3? "#c0392b" : "#1f6fb2");
      var tx=zx+zw+10, tw=Math.min(104,W-tx-8); c.save(); c.fillStyle=stCol; rrect(c,tx,zy+zh/2-16,tw,32,6); c.fill(); c.restore();
      T(c, stName, tx+tw/2, zy+zh/2, {size:(stName.length>7? 10.5 : 12.5), bold:true, col:"#fff", align:"center"});
    }
    var ff=this.ffAt(this.run.t);
    if(on && ff>1) T(c,"早送り ×"+ff.toFixed(0), W-12, 46, {size:12, bold:true, col:"#9c4e06", align:"right", halo:true});
    notebook(c,W,H);
    var txt=["熱は、"+d.sol+"の温度を上げることに使われる","熱は、"+d.sol+"（固体）を"+d.liq+"（液体）にすることに使われる。温度は "+d.Tm+" ℃ のまま","熱は、"+d.liq+"の温度を上げることに使われる","熱は、"+d.liq+"（液体）を"+d.gas+"（気体）にすることに使われる。温度は "+d.Tb+" ℃ のまま","熱は、"+d.gas+"の温度を上げることに使われる"][st.ph];
    this.msg.innerHTML=(q<=0? '初め：'+d.sol+' 100 g（'+d.T0+' ℃）。スタートで、バーナーから一定の割合で熱を加える' : '<b>'+txt+'</b>')+
      '<br>時間 <span class="num">'+this.run.t.toFixed(1)+'</span> s　温度 <span class="num">'+st.T.toFixed(1)+'</span> ℃　加えた熱量 <span class="num">'+(q/1000).toFixed(1)+'</span> kJ';
  },
  /* 拡大の窓の中。ys より下が物質（固体は＋印のまわりでふるえる、液体は動きまわる）。固体は下の方からとける */
  zoom:function(c, x, y, w, h, ys, st){
    var clk=this.clk, r=6.5, sp=2*r+3;
    c.fillStyle="#fbfdff"; c.fillRect(x,y,w,h);
    T(c,"外（空気中）", x+6, y+10, {size:10, col:COL.sub});
    if(st.ph>=4 || ys>=y+h-2) return;
    var hb=y+h-ys, liqTop=(st.ph===0)? y+h : (st.ph===1? y+h-hb*st.fm : ys);
    /* 液体の部分 */
    if(liqTop<y+h-1){
      /* 第7回：液体の粒子は、1 つ 1 つのエネルギーがばらばら（少し誇張）。色と揺れの大きさで表す。エネルギーは時間とともに入れ替わる */
      var d=this.d, Tl=(st.ph<=1)? 0 : (st.ph===2? clamp((st.T-d.Tm)/(d.Tb-d.Tm),0,1) : 1);
      var nx=Math.max(1,Math.floor((w-6)/sp)), ny=Math.max(1,Math.floor((y+h-liqTop-2)/sp)), k=0;
      for(var jy=0;jy<ny;jy++) for(var ix=0;ix<nx;ix++){ var p=PH[(k++)%PH.length]; if(((ix*7+jy*3)%9)===4) continue;
        var e=clamp(0.12+0.30*Tl+0.62*Math.pow(0.5+0.5*Math.sin(clk*(0.5+0.6*p[2])+p[0]*3.1),3),0,1), am=1.5+6*e;
        ball(c, x+4+sp*(ix+0.5)+am*Math.sin(clk*(1.6+1.4*e)*p[2]+p[0]), y+h-3-sp*(jy+0.5)+am*0.8*Math.sin(clk*(1.9+1.4*e)*p[2]+p[1]), r, 0, heatCol(e)); }
      c.strokeStyle="rgba(47,111,159,.6)"; c.lineWidth=1.2; c.beginPath(); c.moveTo(x,liqTop); c.lineTo(x+w,liqTop); c.stroke();
      /* 蒸発：表面の近くの、エネルギーの大きい粒子が空気中へ飛び出す（沸騰する前から） */
      if(st.ph===2){ var nE=1+Math.round(3*Tl);
        for(var j=0;j<nE;j++){ var U=clk/2.6+j*0.37, u=U-Math.floor(U), cyc=Math.floor(U), fx=((j*0.61+cyc*0.29)%1);
          var ex=x+14+fx*(w-28), ey=liqTop-2-u*(liqTop-y+20);
          c.save(); c.globalAlpha=(u<0.1? u/0.1 : 1); ball(c, ex+3*Math.sin(clk*5+j), ey, r, 0, heatCol(1)); c.restore(); } }
      /* 沸騰：液体の内側に泡ができ、内部からも気体になって出ていく */
      if(st.ph===3){ for(var jb=0;jb<3;jb++){ var Ub=clk/1.9+jb*0.33, ub=Ub-Math.floor(Ub), cb=Math.floor(Ub), fb=((jb*0.53+cb*0.31)%1);
          var bxb=x+22+fb*(w-44), byb=y+h-10-ub*(y+h-10-liqTop), rb=7+7*ub;
          c.save(); c.fillStyle="rgba(255,255,255,.92)"; c.strokeStyle="rgba(47,111,159,.8)"; c.lineWidth=1.3; c.beginPath(); c.arc(bxb,byb,rb,0,7); c.fill(); c.stroke(); c.restore();
          ball(c, bxb+2*Math.sin(clk*7+jb), byb, 5, 0, heatCol(1)); } }
    }
    /* 固体の部分（液体の上） */
    if(st.ph<=1 && liqTop>ys+4){
      var nx2=Math.max(1,Math.round(w/(sp+1))), ny2=Math.max(1,Math.round((liqTop-ys)/(sp+1)));
      latticeParticles(c, x+2, ys, w-4, liqTop-ys, (st.ph===0? 0.3 : 0.6), clk, {nx:nx2, ny:ny2, r:r, a0:0.5, a1:2.5, col:heatCol(0.0), noMark:true});
    }
  }
};
