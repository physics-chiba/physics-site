/* ---------------- ①-5 熱平衡（熱量の保存） ----------------
   第2回：1-4 とレイアウトをそろえる。左は鉄 1.0 kg（80 ℃）に固定。右の物質（比熱）と質量を選ぶ（初め 20 ℃）。
   熱容量 C＝mc は結果として計算して表示する。質量を変えると、右の物体の大きさ（液体なら量）が変わる。
   「固体と固体」：鉄のブロックと、えらんだ固体のブロックをくっつける。
   「固体と液体」：鉄の球を、えらんだ液体に入れる。境目を拡大した窓で、粒子がエネルギーを渡すようす。
   熱の矢印は、熱が移動している間だけ。矢印そのものは動かさず、中を「熱の粒」が流れる（流れる速さ＝熱の移る速さ）。
   状態は時刻だけで決まる（初めに最後まで計算しておく）ので、時間バーで戻したり進めたりできる。 */
var SOL15 = [
  {name:"銀", sh:"銀", c:0.235}, {name:"銅", sh:"銅", c:0.384}, {name:"鉄", sh:"鉄", c:0.448},
  {name:"コンクリート", sh:"コン", c:0.8}, {name:"アルミニウム", sh:"アルミ", c:0.902}, {name:"木材", sh:"木材", c:1.3}
];
var LIQ15 = [
  {name:"菜種油", sh:"油", c:2.04}, {name:"エタノール", sh:"エタノール", c:2.42}, {name:"海水", sh:"海水", c:3.93}, {name:"水", sh:"水", c:4.18}
];
var S15 = {
  K:20, KOUT:5, TR:20, CL:0.448, ML:1.0, TA0:80, TB0:20, RUNSEC:25,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.kind="ss"; this.si=4; this.m=1.0; this.lid=false; this.clk=0; this.ph=0; this.zw=null;
    this.compute();
    this.run=new Runner({
      step:function(dt){ self.clk+=dt; self.ph=(self.ph+dt*(0.12+0.9*Math.abs(self.at(self.ts()).P)/self.Pmax))%1; return self.run.t>self.T0 && self.ts()>=self.tEnd; },
      draw:function(){ self.draw(); },
      reset:function(){},
      info:function(){ return ''; }
    });
    this.run.bind(sec);
    this.tb=wireTimeBar(sec, this.run, function(){ return self.T0+self.tEnd/self.spd; }, function(){});
    this.cg=colGrid(sec, {B:true, lc:"hot", rc:"cold"});
    var inp=sec.querySelector('.vrow[data-k="sub"] input'), tk=sec.querySelector('.cticks');
    this.sg=wireSlider(sec,"sub",function(v){ var d=self.list()[Math.round(v)]; return d? d.name+"　"+d.c+" J/(g·K)" : ""; },function(v){ self.si=Math.round(v); self.changed(); });
    this.mg=wireSlider(sec,"mass",function(v){ return v.toFixed(1)+" kg"+(Math.abs(v-1)<1e-6? "（左と同じ）" : ""); },function(v){ self.m=v; self.changed(); });
    var setList=function(){ var L=self.list(); inp.max=L.length-1; tk.innerHTML=L.map(function(d){ return '<span'+(d.name==="水"?' class="w"':'')+'>'+d.sh+'</span>'; }).join(''); self.sg.set(self.si); };
    this.setList=setList;
    this.sk=wireSeg(sec,"kind",function(v){ self.kind=v; self.si=(v==="ss")? 4 : 3; setList(); self.changed(); });
    /* 第10回：組み合わせのボタンは、①-3 の物質のボタンと同じく、図の右上に大きく置く */
    var kb=document.createElement("div"); kb.className="subbtns"; this.kb=kb; kb.innerHTML='<span class="subcap">組み合わせ</span>';
    sec.querySelectorAll('button.seg[data-g="kind"]').forEach(function(b){ kb.appendChild(b); });
    var sl0=sec.querySelector(".segl"); if(sl0 && /組み合わせ/.test(sl0.textContent)) sl0.remove();
    /* 第15回：組み合わせのボタンは、左右の操作の箱の上（2 つの箱をまとめた幅のまん中）に置く */
    kb.classList.add("cgK"); this.cg.el.insertBefore(kb, this.cg.el.firstChild);
    this.cl=wireChk(sec,"lid",function(on){ self.lid=on; self.changed(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.kind="ss"; self.sk.set("ss"); self.si=4; self.m=1.0; self.mg.set(1); setList();
      self.lid=false; self.cl.set(false); self.run.rate=1; var s2=sec.querySelector(".slowb"); if(s2) s2.classList.remove("on"); self.changed(); });
    setList();
    var anim=function(){ if(self.sec.offsetParent!==null && self.run.state!=="run"){ self.clk+=0.016; self.draw(); } requestAnimationFrame(anim); };
    onResize(this.cv.parentElement, function(){ self.draw(); });
    this.draw(); requestAnimationFrame(anim);
  },
  list:function(){ return this.kind==="ss"? SOL15 : LIQ15; },
  sub:function(){ var L=this.list(); return L[clamp(this.si,0,L.length-1)]; },
  CA:function(){ return this.ML*1000*this.CL; }, CB:function(){ return this.m*1000*this.sub().c; },
  Tf:function(){ return (this.CA()*this.TA0+this.CB()*this.TB0)/(this.CA()+this.CB()); },
  changed:function(){ this.compute(); this.run.reset(); },
  /* 最後まで計算しておく（0.05 s きざみ） */
  compute:function(){
    this.T0=(this.kind==="sl")? 3.0 : 0.6;     /* 第9回：ふれるまでの時間。鉄球はゆっくり等速で入れる */
    var CA=this.CA(), CB=this.CB(), TA=this.TA0, TB=this.TB0, t=0, h=0.05, H=[];
    for(var i=0;i<40000;i++){
      var P=this.K*(TA-TB), La=this.lid? this.KOUT*(TA-this.TR) : 0, Lb=this.lid? this.KOUT*(TB-this.TR) : 0;
      H.push([t,TA,TB,P]);
      var done=this.lid? (Math.abs(TA-this.TR)<0.3 && Math.abs(TB-this.TR)<0.3) : Math.abs(TA-TB)<0.05;
      if(done || t>900) break;
      TA-=(P+La)*h/CA; TB+=(P-Lb)*h/CB; t+=h;
    }
    this.H=H; this.tEnd=t; this.spd=Math.max(1, t/this.RUNSEC); this.Pmax=this.K*(this.TA0-this.TB0);
  },
  /* 第6回：ふれるまで（はじめの 0.5 s）は温度を変えない。実験の中の時刻はふれた瞬間から数える */
  T0:0.5,
  ts:function(){ return Math.min(this.tEnd, Math.max(0, this.run.t-this.T0)*this.spd); },     /* 実験の中の時刻［s］ */
  at:function(t){ var i=Math.min(this.H.length-1, Math.floor(t/0.05)), a=this.H[i]; return {t:a[0], TA:a[1], TB:a[2], P:a[3]}; },
  /* 第5回：スタート前は、2 つの物体をふれさせない（固体どうしはすき間、鉄球は液体の外）。スタートで 0.5 s かけてふれさせる */
  touchU:function(){ if(this.run.state==="idle" && this.run.t<=0) return 0; return clamp(this.run.t/this.T0,0,1); },
  draw:function(){
    var self=this, wide=(this.cv.parentElement.clientWidth>=760);
    var f=fitCanvas(this.cv, function(W){ return wide? clamp(W*0.28, 270, 330) : clamp(W*0.98, 470, 660);   /* 第10回：上の空白をなくす */ }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H); if(this.tb) this.tb.sync();
    var st=this.at(this.ts()), u=this.touchU();
    var moving=(this.run.state==="run" && u>=1 && Math.abs(st.P)>this.Pmax*0.01);   /* 熱が移動している間だけ、熱の矢印を出す */
    /* 第5回：広い画面では「図 → 拡大の窓 → 温度と時間のグラフ」を横に並べる。せまい画面では図の下にグラフ */
    /* 第7回：3 つの列（左の物質｜右の物質｜グラフ）。固体同士は容器が 1・2 列にまたがり、境目に 2 つの物体。固体と液体は 1 列目に容器、2 列目に拡大の窓 */
    var c1=W*0.31, c2=W*0.62;
    if(wide){
      if(this.kind==="ss") this.drawSS(c,0,c2,H-6,st,moving,u); else this.drawSL(c,0,c1,c1+14,c2-c1-28,H-6,st,moving,u);
      this.drawGraph(c, c2+34, H-26, W-14, 34, st);
    } else {
      var figH=Math.round(H*0.54);
      if(this.kind==="ss") this.drawSS(c,0,W,figH,st,moving,u); else this.drawSL(c,0,W*0.42,W*0.42+28,W*0.58-40,figH,st,moving,u);
      this.drawGraph(c, 46, H-26, W-16, figH+34, st);
    }
    if(this.cg) this.cg.set(this.cv, [c1,c2], wide);
    /* 第11回：組み合わせのボタンは、断熱容器の右上・グラフの左上（2 列目の右はし）に置く */

    notebook(c,W,H);
    var Qa=this.CA()*(this.TA0-st.TA), Qb=this.CB()*(st.TB-this.TB0), nB=this.sub().name;
    this.msg.innerHTML='熱容量 '+tex("C=mc")+'：鉄 <span class="num">'+this.CA().toFixed(0)+'</span> J/K　／　'+nB+' <span class="num">'+this.CB().toFixed(0)+'</span> J/K<br>'+
      '鉄が失った熱量 <span class="num">'+(Qa/1000).toFixed(2)+'</span> kJ　／　'+nB+'が得た熱量 <span class="num">'+(Qb/1000).toFixed(2)+'</span> kJ'+
      (this.lid? '（ふたが開いているので、熱が外へ逃げる）' : '（等しい：熱量の保存）')+
      '<br>熱平衡の温度（計算）：'+tex("t=\\dfrac{C_\\mathrm{A}t_\\mathrm{A}+C_\\mathrm{B}t_\\mathrm{B}}{C_\\mathrm{A}+C_\\mathrm{B}}")+' = <span class="num">'+this.Tf().toFixed(1)+'</span> ℃';
  },
  /* 断熱容器とふた（ふたは左はしを軸に少しだけ開ける） */
  /* 第10回：断熱容器は分厚い壁（断熱材）で描く。中の容器は (x, y, w, h)。壁の厚さ TW は外側に描く */
  TW:12,
  vessel:function(c, x, y, w, h, open){
    var t=this.TW;
    var hatch=function(px,py,pw,ph){ c.save(); c.fillStyle="#e2dccf"; c.fillRect(px,py,pw,ph); c.beginPath(); c.rect(px,py,pw,ph); c.clip();
      c.strokeStyle="rgba(120,108,88,.45)"; c.lineWidth=1; c.beginPath(); for(var k=-ph; k<pw+ph; k+=7){ c.moveTo(px+k,py+ph); c.lineTo(px+k+ph,py); } c.stroke(); c.restore();
      c.save(); c.strokeStyle="#3a414c"; c.lineWidth=1.6; c.strokeRect(px,py,pw,ph); c.restore(); };
    hatch(x-t, y, t, h+t); hatch(x+w, y, t, h+t); hatch(x, y+h, w, t);       /* 左右の壁と底 */
    c.save(); c.fillStyle="#f7f9fb"; c.fillRect(x,y,w,h); c.strokeStyle="rgba(58,65,76,.45)"; c.lineWidth=1.2; c.strokeRect(x+4,y+4,w-8,h-6); c.restore();
    if(open){ T(c,"断熱容器", x+w/2, y-8, {size:11, col:COL.sub, align:"center"}); return; }
    if(this.lid){ var ang=0.24, L=w+2*t; c.save(); c.translate(x-t, y); c.rotate(-ang); hatch(0, -t, L, t); c.restore();
      T(c,"ふたが開いている", x+w-6, y-L*Math.sin(ang)-t+2, {size:11.5, bold:true, col:"#c0392b", align:"right", halo:true});
      if(this.run.state==="run") for(var i=0;i<2;i++){ var xx=x+w*(0.70+0.18*i); heatFlow(c, xx, y+18, xx, y-16, 5, (this.clk*0.5+i*0.3)%1, {k:0.6}); } }
    else { hatch(x-t, y-t, w+2*t, t);
      T(c,"断熱容器（ふたを閉じている）", x-t, y-t-9, {size:11, col:COL.sub}); }
  },
  lvOf:function(T){ return clamp((T-15)/70,0,1); },
  drawSS:function(c,X0,AW,Hf,st,moving,u){
    var self=this, vw=Math.min(460, AW*0.86), vx=X0+(AW-vw)/2, vy=60, vh=Hf-vy-this.TW;
    this.vessel(c, vx, vy, vw, vh);
    var base=Math.min(vw*0.28, vh*0.62), sA=base, sB=base*Math.cbrt(this.m)*0.92, floor=vy+vh-10, gap=40*(1-u), xm=vx+vw/2;
    var blk=function(x, s, T, k0, col){ var y=floor-s; c.save(); c.fillStyle=col; c.strokeStyle="#3a414c"; c.lineWidth=2; c.fillRect(x,y,s,s); c.strokeRect(x,y,s,s); c.restore();
      var n=Math.max(2,Math.round(s/34)); latticeParticles(c, x+6, y+6, s-12, s-12, self.lvOf(T), self.clk+k0, {nx:n, ny:n, r:Math.min(8, s/(n*3.2)), a0:0.8, a1:6, k0:k0*10}); return y; };
    var xa=xm-gap/2, xb=xm+gap/2;
    var yA=blk(xa-sA, sA, st.TA, 0, "#eceef1"), yB=blk(xb, sB, st.TB, 1, "#fdfdfd");
    thermometer(c, xa-sA+16, floor-sA*0.45, yA-46, st.TA, 0, 90, {ticks:[0,90], noNum:true, dec:1});
    thermometer(c, xb+sB-16, floor-sB*0.45, yB-46, st.TB, 0, 90, {ticks:[0,90], noNum:true, dec:1});
    if(vw<330){   /* せまい画面：名前は容器の下に書く（温度計と重ねない） */
      T(c,"鉄 1.0 kg", xa-sA/2, vy+vh+14, {size:11.5, bold:true, align:"center"});
      T(c, this.sub().sh+" "+this.m.toFixed(1)+" kg", xb+sB/2, vy+vh+14, {size:11.5, bold:true, align:"center"});
    } else {
      T(c,"鉄 1.0 kg", xa-8, floor-sA-14, {size:12.5, bold:true, align:"right", halo:true});
      T(c, this.sub().name+" "+this.m.toFixed(1)+" kg", xb+8, floor-sB-14, {size:12.5, bold:true, halo:true});
    }
    if(u<=0) T(c,"スタートで、2 つを触れさせる", xm, vy+26, {size:12, bold:true, col:"#9c4e06", align:"center", halo:true});
    if(moving){ var lw=3+13*clamp(Math.abs(st.P)/this.Pmax,0,1), cy=floor-Math.min(sA,sB)/2;
      heatFlow(c, xm-56, cy, xm+56, cy, lw, this.ph, {k:Math.abs(st.P)/this.Pmax});
      T(c,"熱 Q", xm, cy-lw/2-16, {size:13, bold:true, col:COL.heat, align:"center", halo:true}); }
    else if(this.ts()>=this.tEnd-1e-6 && !this.lid) T(c,"熱平衡（熱の移動が止まった）", xm, vy+26, {size:13, bold:true, col:"#1c8f4a", align:"center", halo:true});
  },
  drawSL:function(c,X0,AW,ZX,ZW,Hf,st,moving,u){
    var self=this, vw=Math.min(250, AW-24), vx=X0+16, r=Math.min(30, vw*0.13), vy=Math.max(40, 2*r+74), vh=Hf-vy-this.TW;
    this.vessel(c, vx, vy, vw, vh, u<1);
    var lvl=(vh-12)*clamp(0.30+0.30*this.m,0,0.92), wl=vy+vh-lvl;      /* 液体の量で液面の高さが変わる */
    c.save(); c.fillStyle="rgba(90,160,225,.42)"; c.fillRect(vx+6, wl, vw-12, vy+vh-wl-1); c.strokeStyle="#2f6f9f"; c.lineWidth=1.5; c.beginPath(); c.moveTo(vx+6,wl); c.lineTo(vx+vw-6,wl); c.stroke(); c.restore();
    /* スタート前は、鉄球を糸でつるして液体の外に。スタートで沈める */
    var bxc=vx+vw*0.34, byIn=vy+vh-r-8, byOut=vy-r-16, byc=byOut+(byIn-byOut)*u;     /* 第9回：落とさずに、等速でそっと入れる */
    if(u<1){ c.save(); c.strokeStyle="#69717d"; c.lineWidth=1.2; c.beginPath(); c.moveTo(bxc,0); c.lineTo(bxc,byc-r); c.stroke(); c.restore(); }
    var lvA=this.lvOf(st.TA), gr=c.createRadialGradient(bxc-r*0.3,byc-r*0.35,2,bxc,byc,r);
    gr.addColorStop(0,"#fff"); gr.addColorStop(1, heatCol(lvA));
    c.save(); c.fillStyle=gr; c.strokeStyle="#3a414c"; c.lineWidth=1.8; c.beginPath(); c.arc(bxc,byc,r,0,7); c.fill(); c.stroke(); c.restore();
    T(c,"鉄球 1.0 kg", bxc+r+6, byc+4, {size:11.5, bold:true, halo:true});
    thermometer(c, bxc+r*0.45, byc+r*0.2, byc-r-34, st.TA, 0, 90, {ticks:[0,90], noNum:true, dec:1, br:6});
    if(u<=0) T(c,"スタートで鉄球を液体に入れる", bxc+r+8, byc-r+2, {size:11.5, bold:true, col:"#9c4e06", halo:true});
    thermometer(c, vx+vw-24, vy+vh-24, vy-26, st.TB, 0, 90, {ticks:[0,90], noNum:true, dec:1, br:6});
    T(c, this.sub().name+" "+this.m.toFixed(1)+" kg", vx+vw-36, wl+16, {size:12, bold:true, col:"#2f6f9f", align:"right"});
    /* 拡大の窓：鉄球の表面と液体の境目 */
    var zx=ZX, zy=Math.max(26, vy-30), zw=ZW, zh=Hf-zy;
    if(zw>150 && u<1){
      c.save(); c.fillStyle="#fff"; c.strokeStyle="rgba(224,123,24,.55)"; c.setLineDash([5,4]); c.lineWidth=1.6; rrect(c,zx,zy,zw,zh,8); c.fill(); c.stroke(); c.restore();
      T(c,"鉄球が液体に入ると、", zx+zw/2, zy+zh/2-10, {size:11.5, col:COL.sub, align:"center"});
      T(c,"ここに境目を拡大して表示", zx+zw/2, zy+zh/2+10, {size:11.5, col:COL.sub, align:"center"});
    } else if(zw>150){
      c.save(); c.strokeStyle="rgba(224,123,24,.7)"; c.setLineDash([3,3]); c.lineWidth=1; c.beginPath(); c.moveTo(bxc+r*0.95, byc-r*0.3); c.lineTo(zx, zy+zh*0.5); c.stroke(); c.restore();
      c.save(); c.fillStyle="#fff"; c.strokeStyle="#e07b18"; c.lineWidth=2; rrect(c,zx,zy,zw,zh,8); c.fill(); c.stroke(); c.clip();
      var mx=zx+zw*0.42;
      /* 第11回：鉄球の表面は少しカーブさせる（球のふくらみ）。境目 x(y)＝mx＋bg×(1−((y−中央)/(0.62 zh))²) */
      var bg=Math.min(16, zw*0.05), yc0=zy+zh/2, bx=function(y){ var q=(y-yc0)/(zh*0.62); return mx+bg*(1-q*q); };
      var edge=function(){ for(var k=0;k<=24;k++){ var y=zy+zh*k/24; c.lineTo(bx(y),y); } };
      c.fillStyle="rgba(90,160,225,.22)"; c.fillRect(zx,zy,zw,zh);
      c.fillStyle="#eceff3"; c.beginPath(); c.moveTo(zx,zy); edge(); c.lineTo(zx,zy+zh); c.closePath(); c.fill();
      latticeParticles(c, zx+4, zy+8, mx-zx-8, zh-16, lvA, this.clk, {nx:3, ny:4, r:9, a0:0.8, a1:7});
      var lvB=this.lvOf(st.TB), ww=zx+zw-mx;
      if(!this.zw){ this.zw=[]; for(var i=0;i<10;i++){ var th=Math.random()*6.283; this.zw.push({x:Math.random(), y:Math.random(), vx:Math.cos(th), vy:Math.sin(th)}); } }
      var sp=0.12+0.35*lvB, dt=0.016;
      this.zw.forEach(function(p){ p.x+=p.vx*sp*dt; p.y+=p.vy*sp*dt;
        if(p.x<0.12){ p.x=0.12; p.vx=Math.abs(p.vx); } if(p.x>0.94){ p.x=0.94; p.vx=-Math.abs(p.vx); } if(p.y<0.06){ p.y=0.06; p.vy=Math.abs(p.vy); } if(p.y>0.94){ p.y=0.94; p.vy=-Math.abs(p.vy); }
        ball(c, mx+p.x*ww, zy+p.y*zh, 8, 0, heatCol(lvB)); });
      c.strokeStyle="#3a414c"; c.lineWidth=2; c.beginPath(); c.moveTo(bx(zy),zy); edge(); c.stroke();
      if(moving){ var lw=3+11*clamp(Math.abs(st.P)/this.Pmax,0,1); heatFlow(c, mx-50, zy+zh/2, mx+56, zy+zh/2, lw, this.ph, {k:Math.abs(st.P)/this.Pmax});
        T(c,"熱 Q", mx, zy+zh/2-lw/2-16, {size:12.5, bold:true, col:COL.heat, align:"center", halo:true}); }
      c.restore();
      T(c,"境目を拡大（鉄の粒子 ｜ 液体の分子）", zx+4, zy-9, {size:10.5, col:COL.sub});
    }
    if(u>=1 && this.ts()>=this.tEnd-1e-6 && !this.lid) T(c,"熱平衡", vx+vw/2, vy+16, {size:13, bold:true, col:"#1c8f4a", align:"center", halo:true});
  },
  drawGraph:function(c, gx0, gy0, gx1, gy1, st){
    var self=this, Tmax=90, Tmin=0, tmax=this.tEnd*1.03;
    var X=function(t){ return gx0+(gx1-gx0-14)*t/tmax; }, Y=function(T){ return gy0-(gy0-gy1-14)*(T-Tmin)/(Tmax-Tmin); };
    c.save(); c.strokeStyle="#e6e1d7"; c.lineWidth=1; for(var v=20; v<=Tmax+1e-6; v+=20){ c.beginPath(); c.moveTo(gx0,Y(v)); c.lineTo(gx1-14,Y(v)); c.stroke(); T(c,String(v),gx0-5,Y(v),{size:10,col:COL.sub,align:"right"}); } c.restore();
    var xs=niceStep(tmax,5); for(var tt=xs; tt<tmax-xs*0.75; tt+=xs) T(c, String(Math.round(tt)), X(tt), gy0+10, {size:10, col:COL.sub, align:"center"});
    axes(c, gx0, gy0, gx1, gy1, "時間〔s〕", "温度〔℃〕");
    if(!this.lid){ var tf=this.Tf(); c.save(); c.setLineDash([5,4]); c.strokeStyle="#1c8f4a"; c.lineWidth=1.3; c.beginPath(); c.moveTo(gx0,Y(tf)); c.lineTo(gx1-14,Y(tf)); c.stroke(); c.restore();
      T(c,"熱平衡の温度 "+tf.toFixed(1)+" ℃", gx1-16, Y(tf)-9, {size:10.5, col:"#1c8f4a", align:"right", halo:true}); }
    else { c.save(); c.setLineDash([2,4]); c.strokeStyle="#8b949d"; c.beginPath(); c.moveTo(gx0,Y(this.TR)); c.lineTo(gx1-14,Y(this.TR)); c.stroke(); c.restore(); T(c,"室温 "+this.TR+" ℃", gx1-16, Y(this.TR)+10, {size:10.5, col:COL.sub, align:"right"}); }
    var n=Math.min(this.H.length-1, Math.floor(st.t/0.05)), step=Math.max(1,Math.floor(this.H.length/400));
    var line=function(k,col){ c.save(); c.strokeStyle=col; c.lineWidth=2.6; c.beginPath(); for(var i=0;i<=n;i+=step){ var p=self.H[i]; if(i) c.lineTo(X(p[0]),Y(p[k])); else c.moveTo(X(p[0]),Y(p[k])); } var q=self.H[n]; c.lineTo(X(q[0]),Y(q[k])); c.stroke(); c.restore(); };
    line(1,"#c0392b"); line(2,"#1f6fb2");
    T(c,"鉄", X(0)+6, Y(this.TA0)-10, {size:12, bold:true, col:"#c0392b"}); T(c,this.sub().name, X(0)+6, Y(this.TB0)+12, {size:12, bold:true, col:"#1f6fb2"});
  }
};
