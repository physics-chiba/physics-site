import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
        pg=await b.new_page(viewport={'width':1440,'height':950}); errs=[]; pg.on('pageerror',lambda e: errs.append(str(e.stack)[:300]))
        await pg.goto('file:///home/claude/te/thermal-energy.html'); await pg.wait_for_timeout(900)
        await pg.evaluate('gotoSec("s13")'); await pg.wait_for_timeout(400)
        async def at(frac,name):
            await pg.evaluate(f"(()=>{{var i=document.querySelector('#s13 .tbar input'); i.value={int(frac*1000)}; i.dispatchEvent(new Event('input'));}})()")
            await pg.wait_for_timeout(300)
            await (await pg.query_selector('#s13 canvas.main')).screenshot(path='test/'+name)
        await at(0,'t13_0.png'); await at(0.12,'t13_melt.png'); await at(0.55,'t13_boil.png'); await at(0.97,'t13_gas.png')
        await pg.click('#s13 .subbtns button[data-s="eth"]'); await pg.wait_for_timeout(300); await at(0.5,'t13_eth.png')
        await pg.evaluate('gotoSec("s15")'); await pg.wait_for_timeout(300)
        await pg.click('#s15 button[data-g="kind"][data-v="sl"]'); await pg.click('#s15 button[data-chk="lid"]'); await pg.click('#s15 button.b.play'); await pg.wait_for_timeout(3000)
        await (await pg.query_selector('#s15 .sL')).screenshot(path='test/t15sl.png')
        print(errs); await b.close()
asyncio.run(main())
