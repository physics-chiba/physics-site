import asyncio, sys
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
        pg=await b.new_page(viewport={'width':1440,'height':950}); errs=[]; pg.on('pageerror',lambda e: errs.append(str(e.stack)[:300]))
        await pg.goto('file:///home/claude/te/thermal-energy.html'); await pg.wait_for_timeout(1200)
        await pg.screenshot(path='test/hero.png')
        waits={'s11':3000,'s12':2500,'s13':14000,'s14':5000,'s15':6000,'s21':1500,'s22':3000,'s23':4000}
        for sid,w in waits.items():
            await pg.evaluate(f'gotoSec("{sid}")'); await pg.wait_for_timeout(400)
            bp=await pg.query_selector(f'#{sid} button.b.play')
            if bp: await bp.click()
            await pg.wait_for_timeout(w)
            await (await pg.query_selector(f'#{sid}')).screenshot(path=f'test/{sid}.png')
        print(errs); await b.close()
asyncio.run(main())
