import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
        pg=await b.new_page(viewport={'width':1440,'height':950}); errs=[]; pg.on('pageerror',lambda e: errs.append(str(e.stack)[:300]))
        await pg.goto('file:///home/claude/te/thermal-energy.html'); await pg.wait_for_timeout(1000)
        await (await pg.query_selector('#hero canvas')).screenshot(path='test/h4_0.png'); await pg.wait_for_timeout(2500)
        await (await pg.query_selector('#hero canvas')).screenshot(path='test/h4_1.png')
        await pg.evaluate('gotoSec("s15")'); await pg.wait_for_timeout(300)
        await pg.click('#s15 button.b.play'); await pg.wait_for_timeout(700)
        await (await pg.query_selector('#s15 canvas.main')).screenshot(path='test/f4_0.png'); await pg.wait_for_timeout(4000)
        await (await pg.query_selector('#s15 canvas.main')).screenshot(path='test/f4_1.png')
        await pg.click('#s15 button[data-g="kind"][data-v="sl"]'); await pg.click('#s15 button.b.play'); await pg.wait_for_timeout(1500)
        await (await pg.query_selector('#s15 canvas.main')).screenshot(path='test/f4_2.png')
        print(errs); await b.close()
asyncio.run(main())
