import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
        pg=await b.new_page(viewport={'width':1440,'height':900}); errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
        await pg.goto('file:///home/claude/te/thermal-energy.html'); await pg.wait_for_timeout(1200)
        st=await pg.query_selector('#hero canvas')
        for i in range(4):
            await st.screenshot(path=f'test/h3_{i}.png'); await pg.wait_for_timeout(180)
        print(errs); await b.close()
asyncio.run(main())
