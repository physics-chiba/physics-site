import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
        pg=await b.new_page(viewport={'width':1440,'height':950}); errs=[]; pg.on('pageerror',lambda e: errs.append(str(e.stack)[:400]))
        await pg.goto('file:///home/claude/te/thermal-energy.html'); await pg.wait_for_timeout(900)
        await pg.evaluate('gotoSec("s15")'); await pg.wait_for_timeout(300)
        await pg.click('#s15 button[data-g="kind"][data-v="sl"]'); await pg.click('#s15 button.b.play'); await pg.wait_for_timeout(2500)
        await (await pg.query_selector('#s15 .sL')).screenshot(path='test/s15sl.png')
        await pg.click('#tabs .tab[data-mode="mode2"]'); await pg.wait_for_timeout(300)
        await pg.evaluate('gotoSec("s21")'); await pg.wait_for_timeout(300)
        await pg.click('#s21 button[data-g="act"][data-v="push"]'); await pg.click('#s21 button.b.play'); await pg.wait_for_timeout(1500)
        await (await pg.query_selector('#s21 .sL')).screenshot(path='test/s21push.png')
        await pg.wait_for_timeout(2000)
        await pg.click('#s21 button[data-g="act"][data-v="cool"]'); await pg.click('#s21 button.b.play'); await pg.wait_for_timeout(1500)
        await (await pg.query_selector('#s21 .sL')).screenshot(path='test/s21cool.png')
        print(await pg.inner_text('#s21 .msgbox'))
        print(errs); await b.close()
asyncio.run(main())
