import asyncio, json
from playwright.async_api import async_playwright
URL='file:///home/claude/te/thermal-energy.html'; OUT='/home/claude/te/test/'
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        res={}
        for w,h in [(1440,900),(390,844)]:
            pg=await b.new_page(viewport={'width':w,'height':h}); errs=[]
            pg.on('pageerror', lambda e: errs.append(str(e)))
            await pg.goto(URL); await pg.wait_for_timeout(800)
            await pg.evaluate('window.__hero && window.__hero.frame(3)')
            await (await pg.query_selector('#hero')).screenshot(path=OUT+f'r6_hero_{w}.png')
            for sid in ['s11','s15','s21','s31','s23']:
                await pg.evaluate(f'gotoSec("{sid}")'); await pg.wait_for_timeout(350)
                if w==1440: await (await pg.query_selector('#'+sid)).screenshot(path=OUT+f'r6_{sid}.png')
            if w==1440:
                await pg.evaluate('gotoSec("s15")'); await pg.click('#s15 button.b.play'); await pg.wait_for_timeout(300)
                v=await pg.evaluate('[S15.at(S15.ts()).TA, S15.touchU()]'); res['s15_at0.3']=v
                await pg.evaluate('gotoSec("s21")'); await pg.click('#s21 button[data-v="free"]'); await pg.wait_for_timeout(1500)
                await (await pg.query_selector('#s21 .sL')).screenshot(path=OUT+'r6_s21free.png')
                await pg.click('#s21 button[data-v="push"]'); await pg.wait_for_timeout(1500)
                await (await pg.query_selector('#s21 .sL')).screenshot(path=OUT+'r6_s21push.png')
                await pg.evaluate('gotoSec("s23")'); await pg.evaluate("S23.run.toggle(); S23.run.t=22; S23.draw();"); await pg.wait_for_timeout(200)
                await (await pg.query_selector('#s23 canvas.main')).screenshot(path=OUT+'r6_s23rev.png')
            sw=await pg.evaluate('document.documentElement.scrollWidth')
            res[w]={'errs':errs,'sw':sw}
            await pg.close()
        print(json.dumps(res))
        await b.close()
asyncio.run(main())
