import asyncio, json
from playwright.async_api import async_playwright
URL='file:///home/claude/te/thermal-energy.html'; OUT='/home/claude/te/test/'
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        pg=await b.new_page(viewport={'width':1440,'height':900}); errs=[]
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto(URL); await pg.wait_for_timeout(800)
        pos="(s)=>{const r=document.querySelector('#'+s+' canvas.main').getBoundingClientRect(); return [Math.round(r.top+scrollY),Math.round(r.left),Math.round(r.width),Math.round(r.height)]}"
        out={}
        await pg.evaluate('gotoSec("s14")'); await pg.wait_for_timeout(300)
        a=[await pg.evaluate(pos,'s14')]
        await pg.click('#s14 button.b.play'); await pg.wait_for_timeout(300); a.append(await pg.evaluate(pos,'s14'))
        for v in ['0','5','8']:
            await pg.evaluate("(v)=>{const i=document.querySelector('#s14 .vrow[data-k=sub] input'); i.value=v; i.dispatchEvent(new Event('input',{bubbles:true}));}", v)
            await pg.wait_for_timeout(150); a.append(await pg.evaluate(pos,'s14'))
        await pg.evaluate("()=>{const i=document.querySelector('#s14 .vrow[data-k=mass] input'); i.value='2'; i.dispatchEvent(new Event('input',{bubbles:true}));}")
        await pg.wait_for_timeout(150); a.append(await pg.evaluate(pos,'s14'))
        out['s14']=a
        for sid in ['s11','s12','s13','s14','s15','s21','s23']:
            await pg.evaluate(f'gotoSec("{sid}")'); await pg.wait_for_timeout(350)
            await (await pg.query_selector('#'+sid)).screenshot(path=OUT+f'r5_{sid}.png')
        # running shots
        await pg.evaluate('gotoSec("s13")'); await pg.click('#s13 button.b.play'); await pg.wait_for_timeout(2500)
        await (await pg.query_selector('#s13 canvas.main')).screenshot(path=OUT+'r5_s13run.png')
        await pg.evaluate('gotoSec("s15")'); await pg.click('#s15 button.b.play'); await pg.wait_for_timeout(1500)
        await (await pg.query_selector('#s15 canvas.main')).screenshot(path=OUT+'r5_s15run.png')
        await pg.click('#s15 button[data-v="sl"]'); await pg.wait_for_timeout(300)
        await (await pg.query_selector('#s15 canvas.main')).screenshot(path=OUT+'r5_s15sl0.png')
        await pg.click('#s15 button.b.play'); await pg.wait_for_timeout(1800)
        await (await pg.query_selector('#s15 canvas.main')).screenshot(path=OUT+'r5_s15sl1.png')
        await pg.evaluate('gotoSec("s21")'); await pg.click('#s21 .sub21go'); await pg.wait_for_timeout(2500)
        await (await pg.query_selector('#s21 .sub21')).screenshot(path=OUT+'r5_s21sub.png')
        await pg.evaluate('gotoSec("s23")'); await pg.evaluate("S23.run.toggle(); S23.run.t=22; S23.draw();"); await pg.wait_for_timeout(200)
        await (await pg.query_selector('#s23 canvas.main')).screenshot(path=OUT+'r5_s23rev.png')
        out['errs']=errs
        print(json.dumps(out))
        await b.close()
asyncio.run(main())
