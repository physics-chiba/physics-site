/* =========================================================================
   モード① 物質と比熱（1-4・1-5）
   ========================================================================= */

/* ---------------- ①-4 比熱 ----------------
   左：水 1.0 kg、右：えらんだ物質。同じバーナーで同じ熱量 Q を加える。 */
/* 比熱の小さい順（スライダーの左が小さく、右が大きい）。いちばん右は水（左と同じ物質で比べられる） */
var SUBS = [
  {name:"銀", sh:"銀", c:0.235, fill:"#e3e6ea"}, {name:"銅", sh:"銅", c:0.384, fill:"#e8b48a"}, {name:"鉄", sh:"鉄", c:0.448, fill:"#c9ccd1"},
  {name:"コンクリート", sh:"コン", c:0.8, fill:"#d8d4cc"}, {name:"アルミニウム", sh:"アルミ", c:0.902, fill:"#e6e9ee"}, {name:"木材", sh:"木材", c:1.3, fill:"#ecd2a4"},
  {name:"菜種油", sh:"油", c:2.04, fill:"#f6e7a8"}, {name:"海水", sh:"海水", c:3.93, fill:"#cfe6f5"}, {name:"水", sh:"水", c:4.18, fill:"#d4ebf9"}
];
/* 比熱のスライダーの下の目盛り（物質の名前） */
function cTicks(list){ return '<div class="cticks">'+list.map(function(d){ return '<span'+(d.name==="水"?' class="w"':'')+'>'+d.sh+'</span>'; }).join('')+'</div>'; }
var S14 = {
  CW:4.18, T0:20, RATE:2000, QMAX:60000,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.si=2; this.m=1.0; this.Q=0; this.clk=0;
    this.run=new Runner({
      startText:"▶ スタート（加熱する）",
      step:function(dt){ self.clk+=dt; self.Q=Math.min(self.Qstop(), self.RATE*self.run.t); return self.Q>=self.Qstop(); },
      draw:function(){ self.draw(); },
      reset:function(){ self.Q=0; },
      info:function(){ return ''; }
    });
    this.run.bind(sec);
    this.sg=wireSlider(sec,"sub",function(v){ var d=SUBS[Math.round(v)]; return d.name+"　"+d.c+" J/(g·K)"; },function(v){ self.si=Math.round(v); self.run.reset(); });
    this.mg=wireSlider(sec,"mass",function(v){ return v.toFixed(1)+" kg"+(Math.abs(v-1)<1e-6? "（水と同じ）" : ""); },function(v){ self.m=v; self.run.reset(); });
    this.tb=wireTimeBar(sec, this.run, function(){ return self.Qstop()/self.RATE; }, function(t){ self.Q=Math.min(self.Qstop(), self.RATE*t); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.si=2; self.m=1.0; self.sg.set(2); self.mg.set(1); self.run.rate=1;
      var sb=sec.querySelector(".slowb"); if(sb) sb.classList.remove("on"); self.run.reset(); });
    var anim=function(){ if(self.sec.offsetParent!==null && self.run.state!=="run"){ self.clk+=0.016; self.draw(); } requestAnimationFrame(anim); };
    onResize(this.cv.parentElement, function(){ self.draw(); });
    this.draw(); requestAnimationFrame(anim);
  },
  sub:function(){ return SUBS[this.si]; },
  Cs:function(){ return [1000*this.CW, this.m*1000*this.sub().c]; },        /* 熱容量 C＝mc［J/K］ */
  Qstop:function(){ var C=this.Cs(); return Math.min(this.QMAX, 80*Math.min(C[0],C[1])); },   /* 熱い方が 100 ℃ になったら止める */
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return clamp(W*0.62, 300, 420); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H); if(this.tb) this.tb.sync();
    var C=this.Cs(), names=["水","" +this.sub().name], ms=[1.0,this.m], cs=[this.CW,this.sub().c], fills=["#d4ebf9",this.sub().fill];
    var yDesk=H-12, on=(this.run.state==="run");
    T(c,"同じバーナーで、同じ熱量 Q を加える", W/2, 14, {size:13, bold:true, align:"center"});
    for(var i=0;i<2;i++){
      var cx=W*(i? 0.72:0.28), bw=Math.min(170, W*0.30), bh=Math.min(130, H*0.36), bx=cx-bw/2, by=yDesk-70-bh;
      var Tn=this.T0+this.Q/C[i], lv=clamp((Tn-this.T0)/80,0,1);
      /* 台とバーナー */
      burner(c, cx, yDesk, on, this.clk+i*0.37, 0.9);
      c.save(); c.fillStyle="#95a5a6"; c.fillRect(bx-10, by+bh, bw+20, 6); c.restore();
      c.save(); c.strokeStyle="#7f8a8a"; c.lineWidth=3.5; c.beginPath(); c.moveTo(bx-4,by+bh+6); c.lineTo(bx-14,yDesk); c.moveTo(bx+bw+4,by+bh+6); c.lineTo(bx+bw+14,yDesk); c.stroke(); c.restore();
      /* 物体 */
      c.save(); c.fillStyle=fills[i]; c.strokeStyle="#3a414c"; c.lineWidth=1.8; c.fillRect(bx,by,bw,bh); c.strokeRect(bx,by,bw,bh); c.restore();
      latticeParticles(c, bx+8, by+8, bw-46, bh-16, lv, this.clk+i*0.7, {nx:4, ny:3, r:8, a0:1.0, a1:7, k0:i*20});
      /* 温度計：物体の上からさしこむ */
      var th=thermometer(c, bx+bw-18, by+bh-20, by-70, Tn, 0, 100, {ticks:[0,50,100], dec:1});
      T(c, names[i]+"　"+ms[i].toFixed(1)+" kg", cx-30, by-58, {size:14.5, bold:true, align:"center"});
      T(c, "比熱 "+cs[i]+" J/(g·K)", cx-30, by-38, {size:11.5, col:COL.sub, align:"center"});
      T(c, "ΔT = "+(Tn-this.T0).toFixed(1)+" K", cx-30, by-18, {size:13, bold:true, col:COL.heat, align:"center"});
    }
    T(c,"粒子は大きく描いています", W-8, H-4, {size:10, col:COL.sub, align:"right", base:"bottom"});
    notebook(c,W,H);
    var dT=[this.Q/C[0], this.Q/C[1]];
    this.msg.innerHTML='加えた熱量 '+tex("Q")+' = <span class="num">'+(this.Q/1000).toFixed(1)+'</span> kJ　'+
      '水：'+tex("\\Delta T")+' = <span class="num">'+dT[0].toFixed(1)+'</span> K　／　'+this.sub().name+'：'+tex("\\Delta T")+' = <span class="num">'+dT[1].toFixed(1)+'</span> K'+
      '<br>熱容量 '+tex("C=mc")+'：水 <span class="num">'+(C[0]/1000).toFixed(2)+'</span> kJ/K　／　'+this.sub().name+' <span class="num">'+(C[1]/1000).toFixed(2)+'</span> kJ/K';
  }
};

