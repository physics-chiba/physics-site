import re,base64,subprocess,os,json
need=json.load(open('work/fontneed.json',encoding='utf-8'))
asc=set(chr(c) for c in range(0x20,0x7f)); greek=set(chr(c) for c in range(0x391,0x3ca))
def rng(a,b): return set(chr(c) for c in range(a,b+1))
def cps(chars): return ','.join('U+%04X'%ord(c) for c in sorted(chars))
SPEC={
 'KaTeX_Main_normal_400': set(need['KaTeX_Main|400|normal'])|asc|greek|rng(0xA0,0xFF)|rng(0x300,0x36F)|rng(0x20D0,0x20FF)|rng(0x2032,0x2037)|set('→⇒⟹−∗∘∣⋅⋯…≠≤≥±∞∂∇∫'),
 'KaTeX_Main_normal_700': asc|greek,
 'KaTeX_Main_italic_400': asc|greek,
 'KaTeX_Math_italic_400': asc|greek|rng(0x3D1,0x3F5),
 'KaTeX_Math_italic_700': asc|greek,
 'KaTeX_AMS_normal_400': set('≦≧≲≳≪≫∴∵')|asc,
}
t=open('src/00_head.html',encoding='utf-8').read()
def rep(m):
    name=f'{m.group(1)}_{m.group(2)}_{m.group(3)}'
    if name not in SPEC: return m.group(0)
    src=f'work/fonts/{name}.woff2'; out=f'work/fonts/{name}.min.woff2'
    open(src,'wb').write(base64.b64decode(m.group(4)))
    subprocess.run(['pyftsubset',src,'--unicodes='+cps(SPEC[name]),'--flavor=woff2','--layout-features=','--no-hinting','--desubroutinize','--drop-tables+=FFTM,GDEF,GPOS,GSUB','--output-file='+out,'--notdef-outline'],check=True)
    print(name,os.path.getsize(src),'->',os.path.getsize(out))
    return m.group(0).replace(m.group(4),base64.b64encode(open(out,'rb').read()).decode())
t2=re.sub(r'font-family:([A-Za-z_0-9]+);font-style:(\w+);font-weight:(\d+);src:url\(data:font/woff2;base64,([^)]*)\)',rep,t)
open('src/00_head.html','w',encoding='utf-8').write(t2)
print(len(t),len(t2))
