import json,os,hashlib
S='src/'; man=json.load(open(S+'manifest.json'))
full=''.join(open(S+n,encoding='utf-8').read() for n in man)
def rep1(t,a,b):
    assert t.count(a)==1,(a[:60],t.count(a)); return t.replace(a,b)
m4=full
R=[('<title>剛体と力のモーメント</title>','<title>箱の回転　～傾くのが先かすべるのが先か～</title>'),
('content="高校物理・力学のシミュレーション。力のモーメント、剛体のつりあい、重心、箱が傾くかすべるか、安定なつりあいと不安定なつりあいを、自分で動かして確かめられる。"','content="高校物理・力学のシミュレーション。板の上や床の上の箱は、傾くのが先かすべるのが先か。箱の形・静止摩擦係数・力の作用点を変えて、自分で動かして確かめられる。"'),
('<span class="crumb now" aria-current="page">剛体と力のモーメント</span>','<span class="crumb now" aria-current="page">箱の回転　～傾くのが先かすべるのが先か～</span>'),
('<span class="en">Rigid Bodies &amp; Moment of Force</span>','<span class="en">Tip or Slip</span>'),
('<span class="t1"><span class="nb">剛体と</span><span class="nb">力のモーメント</span></span><span class="t2"><span class="nb">〜力は"どこに"はたらくかで、</span><span class="nb">動き方が変わる〜</span></span>','<span class="t1"><span class="nb">箱の回転</span></span><span class="t2">〜傾くのが先かすべるのが先か〜</span>'),
('<p class="ft-mark">Rigid Bodies &amp; Moment of Force<span>剛体と力のモーメント 〜力は"どこに"はたらくかで、動き方が変わる〜</span>','<p class="ft-mark">Tip or Slip<span>箱の回転　～傾くのが先かすべるのが先か～</span>'),
('<script>\n/* ===== 14_canvas_theme.js','<script>\nwindow.ONLY_MODE = 4;   /* モード 4 だけの版 */\n/* ===== 14_canvas_theme.js')]
for a,b in R: m4=rep1(m4,a,b)
os.makedirs('dist/publish',exist_ok=True)
open('dist/publish/rigid-body-dynamics.html','w',encoding='utf-8').write(full)
open('dist/publish/rotation-box_tip-or-slip.html','w',encoding='utf-8').write(m4)
for f in ['rigid-body-dynamics.html','rotation-box_tip-or-slip.html']:
    print(f,hashlib.md5(open('dist/publish/'+f,'rb').read()).hexdigest())
