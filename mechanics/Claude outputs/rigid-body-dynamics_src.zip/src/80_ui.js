/* ===== 80_ui.js ===== */
/* 状態 st と DOM。render は st だけから描く。
   姉妹ページ（basics-of-motion-on-plane.html）の 80_ui.js を、
   「1 列・グラフなし・再生ボタンなし」のこのページ向けに削ったもの。 */
'use strict';

var st = { cur: 'm1s1', sims: {} };

function V(s) {
  var o = {}, k;
  for (k in s.v) o[k] = s.v[k];
  for (k in s.o) o[k] = s.o[k];
  o.ab = s.ab; o.bp = s.bp;
  return o;
}

function $(id) { return document.getElementById(id); }

function initState() {
  Object.keys(DEFS).forEach(function (id) {
    var d = DEFS[id];
    var s = { v: {}, o: {}, ab: d.abDef || '4:4', bp: d.bpDef || 1, touched: false, anim: null, view: null,
      playing: false, slow: false, started: false,
      _ans: { th: 0, playing: false, slow: false, max: 36.8699 },
      _ans2: { th: 0, playing: false, slow: false, max: 36.8699 },
      /* ＜解答＞の図の「力を表示／分解した力を表示」（ブロックごと） */
      _av: { a1: { F: true, Fc: false }, a2: { F: true, Fc: false }, a3: { F: true, Fc: false } } };
    (d.vars || []).forEach(function (vd) { s.v[vd.k] = vd.def; });
    (d.vis || []).forEach(function (vd) { s.o['show' + vd.k] = !!vd.def; });
    if (d.reset) d.reset(s);
    if (d.cam3d) s.cam = { az: d.cam3d.az, el: d.cam3d.el, zoom: d.cam3d.zoom || 1 };
    st.sims[id] = s;
  });
}

/* ===== 凡例の小さな矢印 ===== */
function drawLegend() {
  var list = document.querySelectorAll('#legend canvas');
  Array.prototype.forEach.call(list, function (cv) {
    var ctx = prep(cv, 56, 16);
    var ck = cv.getAttribute('data-col');
    arrow(ctx, 4, 8, 50, 8, cv.getAttribute('data-kind'), 0.8, ck ? (COL[ck] || ck) : null);
  });
}

/* ===== タブ（1 段・3 つ） ===== */
/* いま選んでいるタブを、列の中でまん中あたりへ送る（ページごとは動かさない） */
function centerTab(box, b) {
  if (!box || !b) return;
  if (box.scrollWidth <= box.clientWidth + 1) { box.scrollLeft = 0; return; }
  var r = b.getBoundingClientRect(), br = box.getBoundingClientRect();
  box.scrollLeft += (r.left - br.left) - (box.clientWidth - r.width) / 2;
}
/* 章ごとの英字の副題（第 58 回） */
var MODE_EN = { 1: 'Moment of Force', 2: 'Equilibrium of Rigid Bodies', 3: 'Center of Gravity', 4: 'Tip or Slip', 5: 'Stable and Unstable Equilibrium', 6: 'Motion of the Center of Mass' };
/* 本文の始まり（ヒーローの下）：タブを押したらここまでもどす（第 58 回・見本の contentTop） */
function contentTop() { var h = $('hero'); return h ? h.offsetTop + h.offsetHeight : 0; }
function buildTabs() {
  var mode = modeOf(st.cur);
  /* 上の段：モード */
  var mtb = $('modetabs');
  if (mtb) {
    mtb.innerHTML = '';
    var mOn = null;
    MODES.forEach(function (m) {
      var b = document.createElement('button');
      /* タブは短い名前（正式名称 m.name はコンテンツ一覧で使う）。第 58 回：丸数字と名前を分けて、見本と同じ形に */
      var tn = String(m.tab || m.name), c0 = tn.charAt(0);
      b.innerHTML = '<span class="tn">' + c0 + '</span><span class="tl">' + tn.slice(1).replace(/^　/, '') + '</span>';
      b.className = 'tab' + (m === mode ? ' on' : '');
      if (m === mode) b.setAttribute('aria-current', 'page');
      if (m === mode) mOn = b;
      b.addEventListener('click', function () {
        var id = m.ids.filter(function (q) { return !!DEFS[q]; })[0];
        if (!id) return;
        gotoSim(id);
        window.scrollTo({ top: Math.min(window.pageYOffset, contentTop()), behavior: 'auto' });   /* 第 58 回：本文の頭（ヒーローの下）まで */
      });
      mtb.appendChild(b);
    });
    centerTab(mtb, mOn);
  }
  /* 下の段：そのモードのセクション → 第 64 回：セクションは縦に並べるので、2 段目のタブは出さない（circular-motion.html と同じ） */
  var stb = $('simtabs');
  if (stb) { stb.innerHTML = ''; stb.style.display = 'none'; }
  var tip = $('modetip');
  if (tip) tip.innerHTML = mode.tip || '';          /* tip は HTML（<br> で改行） */
  /* 第 58 回：章の扉（丸の番号・Chapter 0n — 英字・正式名称）と、セクションへのピル */
  if ($('mhNum')) $('mhNum').textContent = mode.n;
  if ($('mhEn')) $('mhEn').textContent = 'Chapter ' + (mode.n < 10 ? '0' : '') + mode.n + ' — ' + (MODE_EN[mode.n] || '');
  if ($('mhTitle')) $('mhTitle').textContent = String(mode.name).replace(/^[①-⑨]　/, '');
  var sl = $('seclinks');
  if (sl) {
    sl.innerHTML = '';
    mode.ids.forEach(function (id) {
      if (!DEFS[id]) return;
      var a = document.createElement('a');
      a.href = '#' + prettyOf(id);
      a.textContent = DEFS[id].tab;
      a.setAttribute('data-sim', id);
      if (id === st.cur) { a.className = 'on'; a.setAttribute('aria-current', 'true'); }
      a.addEventListener('click', function (ev) { ev.preventDefault(); gotoSim(id); scrollToSub(1); });   /* 第 64 回：下に並んだそのセクションへ */
      sl.appendChild(a);
    });
  }
  var pp = $('modepurpose');                         /* モード 4 だけ：【このページの目的】をタブの下に */
  document.documentElement.classList.toggle('haspurpose', !!mode.purpose);   /* 上に目的があるモード（4）では、下の【このページの目的】を出さない */
  if (pp) {
    pp.hidden = !mode.purpose;
    pp.innerHTML = mode.purpose ? '<p class="lead">【このページの目的】</p><ol>' +
      mode.purpose.map(function (t) { return '<li>' + t + '</li>'; }).join('') + '</ol>' : '';
  }
}

/* 変数 1 行（ラベル／−／数値／＋／スライダー） */
function varRowHtml(vd) {
  var h = '<div class="vrow" data-vrow="' + vd.k + '">' +
    '<span class="vlab">' + mathHtml(vd.label) + '</span>' +
    '<button class="stp" data-var="' + vd.k + '" data-dir="-1">−</button>' +
    '<span class="vval" data-vval="' + vd.k + '"></span>' +
    '<button class="stp" data-var="' + vd.k + '" data-dir="1">＋</button>' +
    '<input type="range" class="vsl" data-vsl="' + vd.k + '" min="' + vd.min + '" max="' + vd.max + '" step="' + vd.step + '">';
  return h + '</div>';
}

/* 目盛りつきスライダー。
   上段：赤い印（傾く角 θ₀／傾く力 F₀）の真上に「傾く角 θ₀ = …」、その下に「傾かない｜傾く」
   下段：青緑の印（すべる角 θ_s／すべる力 F_s）の左右に「すべらない｜すべる」、真下に「すべる角 θ_s = …」
   となりに「傾く瞬間」「すべる瞬間」ボタン（先に来るほうが濃いオレンジ、あとのほうは薄く×つき）。 */
function tickSliderHtml(d, vd) {
  var k = vd.k;
  return '<div class="tickslider' + (d.zone2Rev ? ' rev2' : '') + (d.tickInline ? ' inline' : '') + '" data-tick="' + k + '">' +
    '<div class="tsrow1"><span class="vlab">' + mathHtml(vd.label) + '</span>' +
    '<button class="stp" data-var="' + k + '" data-dir="-1">−</button>' +
    '<span class="vval" data-vval="' + k + '"></span>' +
    '<button class="stp" data-var="' + k + '" data-dir="1">＋</button>' +
    (d.moment && !d.momentInPlay ? '<span class="gap3">　　　</span><button class="warm mom" id="bMoment">' + d.moment.label + '</button>' : '') +
    (d.moment2 ? '<button class="warm mom mom2" id="bMoment2">' + d.moment2.label + '</button>' : '') + '</div>' +
    '<div class="tswrap' + (d.tick2 === false ? ' notick2' : '') + '">' +
    '<div class="tsval tsval1" id="tslab_' + k + '"></div>' +
    '<div class="tszone tszone1" id="tszone_' + k + '"><span class="tsl">' + (d.zone1 ? d.zone1[0] : '傾かない') + '</span><span class="tsr">' + (d.zone1 ? d.zone1[1] : '傾く') + '</span></div>' +
    '<div class="tsmark tsmark1" id="tsmark_' + k + '"><span class="tsm"></span></div>' +
    '<input type="range" class="vsl" data-vsl="' + k + '" min="' + vd.min + '" max="' + vd.max + '" step="' + vd.step + '">' +
    '<div class="tsmark tsmark2" id="tsmark2_' + k + '"><span class="tsm"></span></div>' +
    '<div class="tszone tszone2" id="tszone2_' + k + '"><span class="tsl">' + (d.zone2 ? d.zone2[0] : 'すべらない') + '</span><span class="tsr">' + (d.zone2 ? d.zone2[1] : 'すべる') + '</span></div>' +
    '<div class="tsval tsval2" id="tslab2_' + k + '"></div>' +
    '</div></div>';
}
/* 目盛りの位置 [%] に合わせて、印・ゾーンの文字・値を置く */
function placeTick(k, no, at, labelHtml, vd) {
  var mk = $('tsmark' + (no === 1 ? '' : '2') + '_' + k), zn = $('tszone' + (no === 1 ? '' : '2') + '_' + k), lb = $('tslab' + (no === 1 ? '' : '2') + '_' + k);
  var on = at !== undefined && at !== null && isFinite(at) && at >= vd.min && at <= vd.max;
  var p = on ? clamp((at - vd.min) / (vd.max - vd.min), 0, 1) * 100 : null;
  [mk, zn, lb].forEach(function (el) { if (el) el.style.display = on ? '' : 'none'; });
  if (!on) return;
  /* C3（第 55 回）：つまみの中心は、バーの左端から 9 px（つまみの半径）〜右端から 9 px の間を動く。印・文字もそこに合わせる */
  var pos = 'calc(9px + (100% - 18px) * ' + (p / 100).toFixed(5) + ')';
  mk.style.left = pos;
  zn.style.setProperty('--tp', pos);
  lb.style.left = pos;
  /* 端に近いときは、文字が枠からはみ出さないように寄せる */
  lb.style.transform = p < 14 ? 'translateX(-' + (p / 14 * 50).toFixed(0) + '%)' : (p > 86 ? 'translateX(-' + (50 + (p - 86) / 14 * 50).toFixed(0) + '%)' : 'translateX(-50%)');
  lb.innerHTML = mathHtml(labelHtml || '');
  renderMath(lb);
}

/* 題名の頭の番号（①-1 など）を墨のピルにする（第 58 回）。文字はそのまま */
function numPill(html) { return String(html).replace(/^([①-⑨]-\d+(?:-\(\d+\))?)　/, '<span class="secnum">$1</span>　'); }
/* ===== パネルの組み立て ===== */
function buildPanel() {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  var h = [];
  document.documentElement.classList.toggle('linkonly', !!d.linkOnly);   /* モード 5：使い方のヒント・【このページの目的】を出さない */
  if (d.linkOnly) {                                  /* 紹介とリンクだけのセクション（モード 5） */
    $('simhost').innerHTML = '<div class="simhead"><div class="simtitle">' + numPill(mathHtml(d.title)) + '</div></div>' + d.linkHtml(s);
    var h3 = $('hint3d'); if (h3) h3.style.display = 'none';
    renderMath($('simhost'));
    return;
  }
  h.push('<div class="simhead"><div class="simtitle">' + numPill(mathHtml(d.title)) +
    (d.titleBtn ? '<span class="gap3">　　　</span><button id="bTitleBtn" class="tbtn warm">' + d.titleBtn + '</button>' : '') +
    (d.titleVis ? '<span class="gap3">　　　</span><span class="titlesw"><label' + (s.o['show' + d.titleVis.k] ? '' : ' class="vflash"') + '><input type="checkbox" data-vis="show' + d.titleVis.k + '"' + (s.o['show' + d.titleVis.k] ? ' checked' : '') + '> ' + d.titleVis.label + '</label></span>' : '') +   /* 第 56 回：題名の横のスイッチ（②-1 の「力と作用線を表示」と同じ見た目） */
    '</div></div>');
  if (d.preHtml) h.push(d.preHtml(s));             /* 操作欄の上に（モード 5：「やじろべえ」の見出し） */
  h.push('<div class="simgrid one"><div class="cv">');
  /* 図の上の行：左＝主役のボタン＋変数のカード／右＝a:b のボタン＋表示チェック */
  h.push('<div class="cvtop toprow' + (d.split ? ' split' : '') + (d.ctrlCompact ? ' m3ctrl' : '') + '" id="cvtop"><div class="cvleft">');
  /* 再生ボタン（姉妹ページと同じ）：▶ スタート／スロー再生／↺ リセット */
  if (d.varGroups) { /* 再生ボタンはグループの中に置く */ }
  else if (!d.noPlay) {
    h.push('<div class="ctrl playctrl' + (d.momentInPlay ? ' tight' : '') + '"><div class="btnrow">' +
      '<button id="bPlay">▶ スタート</button>' +
      '<button id="bSlow" class="sub">スロー再生</button>' +
      '<button id="bReset" class="sub">↺ リセット</button>' +
      '<span class="gap3">　　　</span>' +
      '<button id="bResetAll" class="resetall">すべて最初の<br>設定に戻す</button>' +
      (d.momentInPlay && d.moment ? '<button class="warm mom" id="bMoment">' + d.moment.label + '</button>' : '') +   /* 2-3：「すべる瞬間」ボタンはリセットのとなり */
      '<span class="playnote" id="playnote">' + (d.playNote || '') + '</span></div></div>');
  } else if (!d.noResetAll) {
    h.push('<div class="ctrl playctrl solo"><div class="btnrow small">' +
      '<button id="bResetAll" class="resetall">すべて最初の<br>設定に戻す</button>' +
      '<span class="playnote" id="playnote">' + (d.playNote || '') + '</span></div></div>');
  }
  var vlist = d.vars || [];
  var grouped = {};
  (d.varGroups || []).forEach(function (g) { (g.keys || []).forEach(function (k) { grouped[k] = 1; }); });
  var plain = vlist.filter(function (vd) { return !vd.tick && !grouped[vd.k] && !vd.noCtl; });   /* noCtl … 操作欄には出さない（図の下のカードに置く） */
  var ticked = vlist.filter(function (vd) { return !!vd.tick && !grouped[vd.k]; });
  ticked.forEach(function (vd) { h.push(tickSliderHtml(d, vd)); });
  if (plain.length && !d.plainSide) {
    h.push('<div class="cvvars" id="cvvars">');
    plain.forEach(function (vd) { h.push(varRowHtml(vd)); });
    h.push('</div>');
  }
  /* 「すべるより先に傾く」「傾くより先にすべる」の薄オレンジのボタン（その設定なら濃く） */
  if (d.presets && d.presets.length) {
    h.push('<div class="presets">');
    d.presets.forEach(function (a, i) { h.push('<button class="warm" data-pre="' + i + '" id="pre_' + i + '">' + a.label + '</button>'); });
    h.push('</div>');
  }
  /* 図ごとに区切ったスライダーのまとまり（左の図／右の図 …） */
  function groupHtml(g) {
    var hh = [];
    hh.push('<div class="ctrl grp">' + (g.label ? '<div class="gttl">' + mathHtml(g.label) + '</div>' : ''));   /* 見出しなしのグループもある */
    if (g.html) hh.push(g.html(s));                   /* そのグループだけのボタンなど（モード 5：左右それぞれのスタート） */
    if (g.play && g.playOnly) {
      hh.push('<div class="btnrow small"><button id="bPlay">' + (d.playLabel ? d.playLabel(s) : '▶ スタート') + '</button>' +
        (g.auto ? '<button id="bAuto" class="warm">' + g.auto + '</button>' : '') +
        (g.reset ? '<button id="bReset" class="sub">↺ リセット</button>' : '') + '</div>');
    } else if (g.play && !d.noPlay) {
      hh.push('<div class="btnrow small">' +
        '<button id="bPlay">▶ スタート</button>' +
        '<button id="bSlow" class="sub">スロー再生</button>' +
        '<button id="bReset" class="sub">↺ リセット</button>' +
        '<button id="bResetAll" class="resetall">すべて最初の<br>設定に戻す</button></div>');
    }
    if (g.inline) {                     /* スライダーなしで 1 行にまとめる（間に境界線） */
      hh.push('<div class="vinline">');
      (g.keys || []).forEach(function (k, ki) {
        var vd = vlist.filter(function (q) { return q.k === k; })[0];
        if (!vd) return;
        var bm = '<button class="stp" data-var="' + vd.k + '" data-dir="-1">−</button>', bp2 = '<button class="stp" data-var="' + vd.k + '" data-dir="1">＋</button>';
        var rv = g.revBtn && g.revBtn.indexOf(k) >= 0;      /* 1-1 左のおもり：数が大きいほど左なので ＋ を左に */
        hh.push('<span class="vin' + (ki ? ' sep' : '') + '"><span class="vlab">' + mathHtml(vd.label) + '</span>' +
          (rv ? bp2 : bm) + '<span class="vval" data-vval="' + vd.k + '"></span>' + (rv ? bm : bp2) + '</span>');
      });
      hh.push('</div>');
    } else {
      (g.keys || []).forEach(function (k) {
        var vd = vlist.filter(function (q) { return q.k === k; })[0];
        if (vd) hh.push(vd.tick ? tickSliderHtml(d, vd) : varRowHtml(vd));
      });
    }
    if (g.note) hh.push('<div class="gnote">' + mathHtml(g.note) + '</div>');
    hh.push('</div>');
    return hh.join('');
  }
  (d.varGroups || []).filter(function (g) { return !g.side; }).forEach(function (g) { h.push(groupHtml(g)); });
  [].forEach(function (g, gi) {
    h.push('<div class="ctrl grp"><div class="gttl">' + mathHtml(g.label) + '</div>');
    if (g.play && !d.noPlay) {
      h.push('<div class="btnrow small">' +
        '<button id="bPlay">▶ スタート</button>' +
        '<button id="bSlow" class="sub">スロー再生</button>' +
        '<button id="bReset" class="sub">↺ リセット</button>' +
        '<button id="bResetAll" class="resetall">すべて最初の<br>設定に戻す</button></div>');
    }
    (g.keys || []).forEach(function (k) {
      var vd = vlist.filter(function (q) { return q.k === k; })[0];
      if (vd) h.push(vd.tick ? tickSliderHtml(d, vd) : varRowHtml(vd));
    });
    if (g.note) h.push('<div class="gnote">' + mathHtml(g.note) + '</div>');
    h.push('</div>');
  });
  if (d.sideHtml) h.push(d.sideHtml(s));
  h.push('</div><div class="cvside">');
  if (d.visFirst) h.push(visHtml());                 /* チェックボックスを右上に（モード 5） */
  (d.varGroups || []).filter(function (g) { return !!g.side; }).forEach(function (g) { h.push(groupHtml(g)); });
  /* a:b のボタン（＋ r3 の b′） */
  if (!d.noAB) {
    h.push('<div class="cvopts abrow"><span class="ablab">' + (d.abLabel || '操作対象の箱の 幅a:高さb') + '</span><span class="abbtns">');
    P.box.KEYS.forEach(function (k) {
      h.push('<button class="ab' + (s.ab === k ? ' on' : '') + '" data-ab="' + k + '">' + k + '</button>');
    });
    h.push('</span></div>');
  }
  if (d.bpKeys) {
    h.push('<div class="cvopts abrow"><span class="ablab">' + mathHtml(d.bpLabel) + '</span><span class="abbtns">');
    d.bpKeys.forEach(function (o) {
      h.push('<button class="ab' + (Math.abs(s.bp - o.v) < 1e-9 ? ' on' : '') + '" data-bp="' + o.v + '">' + mathHtml(o.label) + '</button>');
    });
    h.push('</span></div>');
  }
  function visHtml() {
    var hv = ['<div class="opts">'];
    d.vis.forEach(function (vd) {
      /* 「力を表示」（ないときは最初のチェック）は、チェックが入るまでオレンジに光らせて目立たせる */
      var fk = d.vis.some(function (x) { return x.k === 'F'; }) ? 'F' : d.vis[0].k;
      var fl = (vd.k === fk && !s.o['show' + fk]) ? ' class="vflash"' : '';
      hv.push('<label' + fl + '><input type="checkbox" data-vis="show' + vd.k + '"' + (s.o['show' + vd.k] ? ' checked' : '') + '> ' + mathHtml(vd.label) + '</label>');
    });
    hv.push('</div>');
    return hv.join('');
  }
  if (d.vis && d.vis.length && !d.visFirst) h.push(visHtml());
  if (plain.length && d.plainSide) {                 /* 2-3：μ のスライダーは右の列（チェックの下） */
    h.push('<div class="cvvars" id="cvvars">');
    plain.forEach(function (vd) { h.push(varRowHtml(vd)); });
    h.push('</div>');
  }
  if (d.graph) h.push('<div class="fgraph"><canvas id="fgraph"></canvas></div>');
  h.push('</div></div>');
  /* 図 */
  if (d.drawSide || d.stageSide) h.push('<div class="stagerow">');     /* モード 2：左 60 % が図、右 40 % に 3 つの図 */
  h.push('<div class="cvstage' + ((d.actions && d.actions.length && !d.actionsInCv) ? '' : ' nobar') + '">');
  h.push('<canvas id="mainCv" class="dragcv"></canvas>');
  /* ＜説明文＞（モード 1〜3）：図の左上。d.guides = [{ key, x（左はしの位置 0〜1）, cls }] */
  (d.guides || []).forEach(function (g) {
    if (g.inCv) return;
    h.push('<div class="guide ' + (g.cls || '') + '" style="left:calc(' + ((g.x || 0) * 100) + '% + 10px)">' + guideHtml(g.key) + '</div>');
  });
  if (d.cvHtml) h.push(d.cvHtml(s));                 /* 図に重ねるボタン（モード 5：左右それぞれのスタート） */
  /* 図の左上に重ねる：操作の案内文（HTML なので図の縮小で文字がつぶれない）＋主役のボタン */
  var gIn = (d.guides || []).filter(function (g) { return g.inCv; })[0];
  if (d.cvNote || gIn || d.cvTitle || d.actionsInCv || (d.topActions && d.topActions.length)) {
    h.push('<div class="incv">');
    if (d.cvTitle) h.push('<div class="cvtitle">' + numPill(d.cvTitle) + '</div>');
    if (gIn) h.push('<div class="guide static">' + guideHtml(gIn.key) + '</div>');
    if (d.actionsInCv && d.actions) {
      h.push('<div class="topacts cvacts">');
      d.actions.forEach(function (a, i) { h.push('<button class="warm' + (a.alt ? ' alt' : '') + '" data-act="' + i + '" id="act_' + i + '">' + a.label + '</button>'); });
      h.push('</div>');
    }
    if (d.cvNote) h.push('<div class="cvnote">' + d.cvNote + '</div>');
    if (d.topActions && d.topActions.length) {
      h.push('<div class="topacts">');
      d.topActions.forEach(function (a, i) {
        h.push('<button class="' + tactCls(d, s, a, i) + '" data-tact="' + i + '" id="tact_' + i + '">' + a.label + '</button>');
      });
      h.push('</div>');
    }
    h.push('</div>');
  }
  h.push('</div>');
  if (d.drawSide) h.push('<div class="sidefig"><canvas id="sideCv"></canvas></div></div>');
  else if (d.stageSide) h.push('<div class="sidefig sidehtml">' + d.stageSide(s) + '</div></div>');   /* 右 40 % に HTML（2-1：説明とリンク） */
  if (d.actions && d.actions.length && !d.actionsInCv) {
    h.push('<div class="cvbar"><div class="acts n' + Math.min(5, d.actions.length) + '">');
    d.actions.forEach(function (a, i) { h.push('<button class="warm' + (a.alt ? ' alt' : '') + '" data-act="' + i + '" id="act_' + i + '">' + a.label + '</button>'); });
    h.push('</div></div>');
  }
  h.push('<div class="resbar" id="resbar"></div>');
  if (d.subSplit) h.push('<div class="cvsub split2" style="grid-template-columns:' + (d.split * 100) + '% 1fr"><p>' + mathHtml(d.subSplit[0]) + '</p><p>' + mathHtml(d.subSplit[1]) + '</p></div>');   /* 図と同じ所で区切る */
  if (d.sub) h.push('<p class="cvsub">' + mathHtml(d.sub) + '</p>');
  h.push('</div></div>');
  /* 図の下のカード（考え方／問題／解答） */
  if (d.below) h.push('<div class="below" id="below">' + mathHtml(d.below(s)) + '</div>');
  $('simhost').innerHTML = h.join('');
  var h3d = $('hint3d');
  if (h3d) h3d.style.display = d.drag3d ? '' : 'none';

  /* --- イベント --- */
  var host = $('simhost');
  Array.prototype.forEach.call(host.querySelectorAll('[data-tact]'), function (b) {
    b.addEventListener('click', function () {
      var ti = +b.getAttribute('data-tact');
      d.topActions[ti].fn(s);
      if (!s._tactDone) s._tactDone = {};
      s._tactDone[ti] = true;                 /* 一度押したら、もう光らせない */
      s.touched = true; refreshActs(); renderActive();
    });
  });
  Array.prototype.forEach.call(host.querySelectorAll('[data-act]'), function (b) {
    b.addEventListener('click', function () {
      d.actions[+b.getAttribute('data-act')].fn(s);
      s.touched = true; syncVarVals(); refreshActs(); renderActive();
    });
  });
  Array.prototype.forEach.call(host.querySelectorAll('[data-ab]'), function (b) {
    b.addEventListener('click', function () { setAB(b.getAttribute('data-ab')); });
  });
  Array.prototype.forEach.call(host.querySelectorAll('[data-pre]'), function (b) {
    b.addEventListener('click', function () {
      d.presets[+b.getAttribute('data-pre')].fn(s);
      s.touched = true; syncVarVals(); refreshActs(); renderActive();
    });
  });
  if ($('bPlay')) $('bPlay').addEventListener('click', onPlay);
  if ($('bSlow')) $('bSlow').addEventListener('click', function () { s.slow = !s.slow; setPlayLabel(); });
  if ($('bReset')) $('bReset').addEventListener('click', function () {
    if (d.onReset) { d.onReset(s); setPlayLabel(); refreshActs(); renderActive(); return; }   /* そのシミュレーション独自のリセット */
    resetSim();
  });
  if ($('bResetAll')) $('bResetAll').addEventListener('click', function () { resetAll(); });
  Array.prototype.forEach.call(host.querySelectorAll('[data-bp]'), function (b) {
    b.addEventListener('click', function () { setBP(+b.getAttribute('data-bp')); });
  });
  Array.prototype.forEach.call(host.querySelectorAll('[data-vis]'), function (el) {
    el.addEventListener('change', function () {
      s.o[el.getAttribute('data-vis')] = el.checked;
      s.touched = true;
      if (el.checked && el.parentNode) el.parentNode.classList.remove('vflash');   /* 押されたら光りをやめる */
      if (d.onVis) d.onVis(s, el.getAttribute('data-vis'), el.checked);
      renderActive();
    });
  });
  Array.prototype.forEach.call(host.querySelectorAll('[data-vsl]'), function (r) {
    r.addEventListener('input', function () { setVar(r.getAttribute('data-vsl'), +r.value); });
  });
  Array.prototype.forEach.call(host.querySelectorAll('[data-var]'), function (b) {
    b.addEventListener('click', function () { stepVar(b.getAttribute('data-var'), +b.getAttribute('data-dir')); });
  });
  /* ＜解答＞の図の力のチェックボックス（data-ansv="a1F" のように、ブロック名＋F/Fc） */
  Array.prototype.forEach.call(host.querySelectorAll('[data-ansv]'), function (cb) {
    cb.addEventListener('change', function () {
      var k = cb.getAttribute('data-ansv'), blk = k.slice(0, 2), which = k.slice(2);
      s._av[blk][which] = cb.checked;
      var lab = cb.parentNode; if (lab && lab.classList) lab.classList.remove('vflash');
      if (d.drawBelow) d.drawBelow(s);
    });
  });
  Array.prototype.forEach.call(host.querySelectorAll('[data-open]'), function (b) {
    b.addEventListener('click', function () {
      var box = $(b.getAttribute('data-open'));
      if (!box) return;
      b.classList.remove('glow');
      var open = box.classList.toggle('open');
      b.textContent = open ? (b.getAttribute('data-close-label') || '解答をとじる') : (b.getAttribute('data-open-label') || '解答を見る');
      if (open) { renderMath(box); if (d.drawBelow) d.drawBelow(s); }
    });
  });
  if ($('bAnsPlay')) {
    $('bAnsPlay').addEventListener('click', function () {
      var a = s._ans;
      if (a.playing) { a.playing = false; setAnsLabel(s); return; }
      if (a.th >= a.max - 1e-9) a.th = 0;
      a.playing = true; setAnsLabel(s);
    });
    $('bAnsSlow').addEventListener('click', function () { s._ans.slow = !s._ans.slow; setAnsLabel(s); });
    $('bAnsReset').addEventListener('click', function () {
      s._ans.playing = false; s._ans.th = 0; setAnsLabel(s);
      if (d.drawBelow) d.drawBelow(s);
    });
    setAnsLabel(s);
  }
  if ($('bAns2Play')) {
    $('bAns2Play').addEventListener('click', function () {
      var a = s._ans2;
      if (a.playing) { a.playing = false; setAnsLabel(s); return; }
      if (a.th >= a.max - 1e-9) a.th = 0;
      a.playing = true; setAnsLabel(s);
    });
    $('bAns2Slow').addEventListener('click', function () { s._ans2.slow = !s._ans2.slow; setAnsLabel(s); });
    $('bAns2Reset').addEventListener('click', function () {
      s._ans2.playing = false; s._ans2.th = 0; setAnsLabel(s);
      if (d.drawBelow) d.drawBelow(s);
    });
  }
  /* 「比較してみよう」のリンクで、もう一方のシミュレーションへ飛ぶ */
  Array.prototype.forEach.call(host.querySelectorAll('[data-goto]'), function (a) {
    a.addEventListener('click', function (ev) {
      ev.preventDefault();
      var g = a.getAttribute('data-goto').split(':');
      if (g[1] === 'top') { gotoSim(g[0]); scrollToSub(1); return; }   /* 図（アニメ）の所へ */
      gotoSim(g[0], g[1] ? +g[1] : 0);
      if (g[1]) scrollToSub(+g[1]);   /* 1-2 の ②・④ などへ */
      else scrollToThink();     /* 飛んだ先の ＜考え方＞ の見出しを画面の上端にそろえる */
    });
  });
  if (d.moment && $('bMoment')) $('bMoment').addEventListener('click', function () { startMoment(d, s, d.moment); });
  if (d.moment2 && $('bMoment2')) $('bMoment2').addEventListener('click', function () { if (!$('bMoment2').disabled) startMoment(d, s, d.moment2); });
  if (d.drag3d) attach3dDrag(d, s); else if (d.drag) attachSimDrag(d, s);
  if (d.wire) d.wire(s, host);         /* そのシミュレーションだけの配線 */

  syncVarVals();
  refreshActs();
  setPlayLabel();
  renderMath(host);
  if (d.drawBelow) d.drawBelow(s);
}

/* ===== 再生（主役の変数を既定値からだんだん大きくしていく） ===== */
function playVar(d) { return (d.vars || [])[0]; }
function onPlay() {
  var d = DEFS[st.cur], s = st.sims[st.cur], vd = playVar(d);
  if (d.play) { d.play(s); s.touched = true; setPlayLabel(); refreshActs(); renderActive(); return; }   /* そのシミュレーション独自の「再生」（1-1 の「指で押す」など） */
  if (!vd) return;
  if (s.playing) { s.playing = false; setPlayLabel(); return; }
  s.anim = null;
  var stopAt = playStopAt(d, s, vd);
  if (!s.started || playAtEnd(d, s.v[vd.k], stopAt)) { s.v[vd.k] = vd.def; s.started = true; }
  s.playing = true; s.touched = true;
  setPlayLabel(); syncVarVals(); refreshActs(); renderActive();
}
/* すべてを既定値にもどす（変数・a:b・b′・チェック・視点・解答の図） */
function resetAll() {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  s.playing = false; s.anim = null; s.started = false; s.slow = false; s.touched = false;
  s._vt = {};
  (d.vars || []).forEach(function (vd) { s.v[vd.k] = vd.def; });
  (d.vis || []).forEach(function (vd) { s.o['show' + vd.k] = !!vd.def; });
  if (d.titleVis) s.o['show' + d.titleVis.k] = false;
  if (d.reset) d.reset(s);              /* そのシミュレーションだけの初期化 */
  s.ab = d.abDef || '4:4';
  s.bp = d.bpDef || 1;
  if (d.cam3d) s.cam = { az: d.cam3d.az, el: d.cam3d.el, zoom: d.cam3d.zoom || 1 };
  s._av = { a1: { F: true, Fc: false }, a2: { F: true, Fc: false }, a3: { F: true, Fc: false } };
  s._tactDone = {};
  if (s._ans) { s._ans.th = 0; s._ans.playing = false; s._ans.slow = false; }
  if (s._ans2) { s._ans2.th = 0; s._ans2.playing = false; s._ans2.slow = false; }
  buildPanel();
  renderActive();
}

function resetSim() {
  var d = DEFS[st.cur], s = st.sims[st.cur], vd = playVar(d);
  s.playing = false; s.anim = null; s.started = false;
  if (vd) s.v[vd.k] = vd.def;
  setPlayLabel(); syncVarVals(); refreshActs(); renderActive();
}
/* ＜解答＞の中の図の再生ボタン */
function setAnsLabel(s) {
  [['bAnsPlay', 'bAnsSlow', s._ans], ['bAns2Play', 'bAns2Slow', s._ans2]].forEach(function (q) {
    var b = $(q[0]), bs = $(q[1]), a = q[2];
    if (!b || !a) return;
    b.textContent = a.playing ? '❚❚ 一時停止' : (a.th >= a.max - 1e-9 ? '▶ もう一度' : '▶ スタート');
    if (bs) { bs.className = a.slow ? '' : 'sub'; bs.textContent = a.slow ? 'スロー再生中' : 'スロー再生'; }
  });
}

/* 再生が最後まで行って止まっているか（＝つぎに押すと「最初から」になる） */
/* 再生の向き：playRate が負なら、値を減らしていく */
function playDir(d) { return (d.playRate || 5) < 0 ? -1 : 1; }
function playStopAt(d, s, vd) {
  if (playDir(d) < 0) return d.playStop ? Math.max(vd.min, d.playStop(V(s))) : vd.min;
  return d.playStop ? Math.min(vd.max, d.playStop(V(s))) : vd.max;
}
function playAtEnd(d, val, stopAt) {
  return playDir(d) < 0 ? val <= stopAt + 1e-9 : val >= stopAt - 1e-9;
}
function playFinished(d, s) {
  if (!d || !s || s.playing || !s.started) return false;
  var vd = playVar(d);
  if (!vd) return false;
  return playAtEnd(d, s.v[vd.k], playStopAt(d, s, vd));
}
function setPlayLabel() {
  var d = DEFS[st.cur], s = st.sims[st.cur], b = $('bPlay'), bs = $('bSlow');
  if (!b) return;
  if (d.playLabel) { b.textContent = d.playLabel(s); b.className = ''; return; }
  b.textContent = s.playing ? '❚❚ 一時停止' : (playFinished(d, s) ? '▶ 最初から' : '▶ スタート');
  b.className = '';
  if (bs) { bs.className = s.slow ? '' : 'sub'; bs.textContent = s.slow ? 'スロー再生中' : 'スロー再生'; }
}

/* a:b（操作対象の箱）を変える */
function setAB(key) {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  if (!P.box.dims(key)) return;
  s.ab = key; s.touched = true; s.anim = null;
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-ab]'), function (b) {
    b.className = 'ab' + (b.getAttribute('data-ab') === key ? ' on' : '');
  });
  if (d.onAB) d.onAB(s);
  syncVarVals(); refreshActs(); renderActive();
}
function setBP(val) {
  var s = st.sims[st.cur];
  s.bp = val; s.touched = true; s.anim = null;
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-bp]'), function (b) {
    b.className = 'ab' + (Math.abs(+b.getAttribute('data-bp') - val) < 1e-9 ? ' on' : '');
  });
  syncVarVals(); refreshActs(); renderActive();
}

/* 変数を直接セット／±で動かす */
function setVar(k, val, quiet) {
  var d = DEFS[st.cur], s = st.sims[st.cur], vd = null;
  d.vars.forEach(function (x) { if (x.k === k) vd = x; });
  if (!vd) return;
  var nv = clamp(Math.round(val / vd.step) * vd.step, vd.min, vd.max);
  if (Math.abs(nv - s.v[k]) < 1e-9) return;
  s.v[k] = +nv.toFixed(6);
  if (!quiet) { s.touched = true; s.anim = null; s.playing = false; setPlayLabel(); }
  syncVarVals(); refreshActs(); renderActive();
  if (d.drawBelow) belowSoon(d, s);
}
/* スライダーを変えたら ＜解答＞ も作り直す。少し待ってから（動かしている間は「計算中…」） */
var _belowT = 0;
function belowSoon(d, s) {
  var box = $('below');
  if (box && /^m3/.test(d.id)) box.classList.add('busy');   /* 重心（モード 3）の ＜解答＞ に「計算中…」 */
  clearTimeout(_belowT);
  _belowT = setTimeout(function () {
    if (DEFS[st.cur] === d) d.drawBelow(s);
    var b2 = $('below'); if (b2) b2.classList.remove('busy');
  }, 350);
}
function stepVar(k, dir) {
  var d = DEFS[st.cur], s = st.sims[st.cur], vd = null;
  d.vars.forEach(function (x) { if (x.k === k) vd = x; });
  if (!vd) return;
  setVar(k, s.v[k] + dir * vd.step);
}

/* 数値の表示・スライダーの位置・目盛りの印をそろえる */
function syncVarVals() {
  var d = DEFS[st.cur], s = st.sims[st.cur], host = $('simhost');
  if (!host) return;
  var v = V(s);
  (d.vars || []).forEach(function (vd) {
    var txt = vd.fmtv ? vd.fmtv[Math.round(s.v[vd.k])] : fmt(s.v[vd.k], vd.dec) + vd.unit;   /* fmtv … 値の代わりに出す文字（R/4 など） */
    Array.prototype.forEach.call(host.querySelectorAll('[data-vval="' + vd.k + '"]'), function (el) { el.textContent = txt; });
    Array.prototype.forEach.call(host.querySelectorAll('[data-vsl="' + vd.k + '"]'), function (r) {
      if (+r.value !== s.v[vd.k]) r.value = s.v[vd.k];
    });
    if (vd.tick) {                                  /* θ₀・θ_s（F₀・F_s）の目盛り */
      var tk = vd.tick(v);
      placeTick(vd.k, 1, tk.at, tk.label, vd);
      placeTick(vd.k, 2, tk.at2, tk.label2, vd);
    }
  });
}

/* オレンジのボタン：いまの状態がその条件なら濃く */
/* 図の左上のボタンの見た目。glow＝まだ押されていないので光らせる */
function tactCls(d, s, a, i) {
  var v = V(s);
  var on = !!(a.is && a.is(v, s));
  var glow = !!a.glow && !on && !(s._tactDone && s._tactDone[i]);
  return 'warm' + (a.prim ? ' prim' : '') + (on ? ' on' : '') + (glow ? ' glow' : '');
}
function refreshActs() {
  var d = DEFS[st.cur], s = st.sims[st.cur], v = V(s);
  (d.topActions || []).forEach(function (a, i) {
    var b = $('tact_' + i); if (!b) return;
    b.className = tactCls(d, s, a, i);
  });
  /* 傾く瞬間／滑る瞬間：先に来るほうを濃く、あとのほうは薄く×（押せない） */
  if (d.moment2 && $('bMoment') && $('bMoment2')) {
    var sf = d.slipFirst ? d.slipFirst(v) : false;
    var b1 = $('bMoment'), b2 = $('bMoment2');
    b1.className = 'warm mom' + (sf ? ' off' : ''); b1.disabled = sf;
    b2.className = 'warm mom mom2' + (sf ? '' : ' off'); b2.disabled = !sf;
    b1.title = sf ? '先にすべるので、傾く瞬間は来ない' : ''; b2.title = sf ? '' : '先に傾くので、すべる瞬間は来ない';
  }
  (d.presets || []).forEach(function (a, i) {
    var b = $('pre_' + i); if (!b) return;
    b.className = 'warm' + ((a.is && a.is(v, s)) ? ' on' : '');
  });
  (d.actions || []).forEach(function (a, i) {
    var b = $('act_' + i); if (!b) return;
    b.className = 'warm' + (a.alt ? ' alt' : '') + ((a.is && a.is(v, s)) ? ' on' : '') + ((a.dim && a.dim(s)) ? ' dim' : '');
  });
}

/* ===== 「傾く瞬間」のスロー再生 =====
   θ₀（F′₀）の直前 → ちょうど → 直後 を、ゆっくり動かす。作用線のチェックを自動で ON にする。 */
function startMoment(d, s, m) {
  m = m || d.moment;
  var v = V(s);
  var seg = m.range(v);                              /* { k, from, to } */
  s.o.showL = true;
  var el = $('simhost').querySelector('[data-vis="showL"]');
  if (el) el.checked = true;
  s.touched = true;
  s.anim = { k: seg.k, from: seg.from, to: seg.to, dur: m.dur || 4.2, t0: null, hold: seg.hold || 0.9 };
  s.v[seg.k] = seg.from;
  syncVarVals(); refreshActs(); renderActive();
}

/* ===== 図のドラッグ（r2：板／r3：ばね） ===== */
function attachSimDrag(d, s) {
  var cv = $('mainCv'), dragging = false;
  function toLocal(ev) {
    var r = cv.getBoundingClientRect();
    return { lx: (ev.clientX - r.left) / r.width * (cv._cw || cwOf(d, s)), ly: (ev.clientY - r.top) / r.height * (cv._ch || chOf(d, s)) };
  }
  cv.addEventListener('pointerdown', function (ev) {
    var w = toLocal(ev);
    if (!d.dragDown || !d.dragDown(s, w.lx, w.ly)) return;
    dragging = true; cv.setPointerCapture(ev.pointerId);
    s.touched = true; s.anim = null; s._dragging = true;      /* ドラッグ中（モード 3：質点を見せる） */
    if (!d.dragNoDown) d.drag(s, w.lx, w.ly);                  /* dragNoDown … 押しただけでは動かさない（1-1：ダブルクリックで押す指） */
    syncVarVals(); refreshActs(); renderActive(); ev.preventDefault();
  });
  cv.addEventListener('pointermove', function (ev) {
    var w = toLocal(ev);
    if (!dragging) {                    /* つかめる所だけ手のマーク（ほかは矢印のまま） */
      var t0 = s._dragT;
      cv.style.cursor = (d.dragDown && d.dragDown(s, w.lx, w.ly)) ? 'grab' : 'default';
      s._dragT = t0;
      return;
    }
    cv.style.cursor = 'grabbing';
    d.drag(s, w.lx, w.ly); syncVarVals(); refreshActs(); renderActive(); ev.preventDefault();
  });
  function end() { if (dragging && d.dragUp) d.dragUp(s); if (dragging) { dragging = false; s._dragging = false; renderActive(); } }
  cv.addEventListener('pointerup', end);
  cv.addEventListener('pointercancel', end);
}

/* ===== 3 次元の視点操作（r1）。板の上でドラッグしたときは θ を変える ===== */
function attach3dDrag(d, s) {
  var cv = $('mainCv'), last = null, mode = null;
  function toLocal(ev) {
    var r = cv.getBoundingClientRect();
    return { lx: (ev.clientX - r.left) / r.width * (cv._cw || cwOf(d, s)), ly: (ev.clientY - r.top) / r.height * (cv._ch || chOf(d, s)) };
  }
  cv.style.cursor = 'grab';              /* 3 次元の図はどこをドラッグしても視点が回る */
  cv.addEventListener('pointerdown', function (ev) {
    var w = toLocal(ev);
    mode = (d.dragDown && d.dragDown(s, w.lx, w.ly)) ? 'plate' : 'cam';
    last = { x: ev.clientX, y: ev.clientY, lx: w.lx, ly: w.ly };
    cv.setPointerCapture(ev.pointerId); ev.preventDefault();
  });
  cv.addEventListener('pointermove', function (ev) {
    if (!last) return;
    var dx = ev.clientX - last.x, dy = ev.clientY - last.y;
    var w = toLocal(ev);
    last = { x: ev.clientX, y: ev.clientY, lx: w.lx, ly: w.ly };
    if (mode === 'plate') {
      s.touched = true; s.anim = null;
      d.drag(s, w.lx, w.ly, dx, dy);
      syncVarVals();
    } else {
      var r = cv.getBoundingClientRect(), k = (cv._cw || cwOf(d, s)) / Math.max(1, r.width);
      s.cam.az = (s.cam.az - dx * k * 0.32 + 540) % 360 - 180;
      s.cam.el = clamp(s.cam.el - dy * k * 0.26, 0, 88);
      s.touched = true;
    }
    refreshActs(); renderActive(); ev.preventDefault();
  });
  function end() { last = null; mode = null; }
  cv.addEventListener('pointerup', end);
  cv.addEventListener('pointercancel', end);
  /* ★ホイールでの拡大縮小はつけない（授業中にスクロールしただけで図が変わってしまうため）★ */
}

/* ===== 判定の吹き出しは、出てから 3 秒で消す =====
   key … 箱ごとの名前、kind … 'tip' | 'slip' | null。出しはじめの時刻を s._vt に覚え、3 秒すぎたら false。 */
var VERDICT_MS = 3000;
function verdictAlive(s, key, kind) {
  if (!s._vt) s._vt = {};
  var now = (window.performance && performance.now) ? performance.now() : Date.now();
  var rec = s._vt[key];
  if (!kind) { delete s._vt[key]; return false; }
  if (!rec || rec.kind !== kind) { rec = s._vt[key] = { kind: kind, t0: now }; }
  var left = VERDICT_MS - (now - rec.t0);
  if (left <= 0) return false;
  if (!s._vtTimer) s._vtTimer = setTimeout(function () { s._vtTimer = null; renderActive(); }, left + 30);
  return true;
}

/* ===== 描画 ===== */
function chOf(d, s) { return (typeof d.ch === 'function') ? Math.round(d.ch(V(s), s)) : d.ch; }
function cwOf(d, s) { return (typeof d.cw === 'function') ? Math.round(d.cw(V(s), s)) : d.cw; }
/* 画面が狭い（列の幅が 600px 未満）ときは、図を「たて長」に組み直す（s._narrow） */
function narrowOf(cv) {
  var w = cv.clientWidth || (cv.parentNode && cv.parentNode.clientWidth) || 0;
  return w > 0 && w < 600;
}
/* 横置きのスマホ・小さいタブレット（画面のたてが低い）。図を小さくし、ズームアップを大きく見せる */
function shortOf() { return window.innerHeight <= 560 && window.innerWidth > window.innerHeight; }
/* 図の高さが画面に収まるように、図の列の幅に上限をかける（姉妹ページの fitStageHeight と同じ考え方） */
function fitStage(d, s) {
  var stage = document.querySelector('#simhost .cvstage');
  var cv = $('mainCv');
  if (!stage || !cv) return;
  stage.style.maxWidth = ''; stage.style.marginLeft = stage.style.marginRight = '';
  if (d.stageW && !s._short && !s._narrow) {           /* stageW … 図の横幅を小さく（1-2 ① は 70 %） */
    stage.style.maxWidth = Math.round(d.stageW * 100) + '%'; stage.style.marginLeft = stage.style.marginRight = 'auto';
  }
  if (!s._short) return;
  var top = cv.getBoundingClientRect().top + window.scrollY - (document.querySelector('#simhost').getBoundingClientRect().top + window.scrollY);
  var avail = window.innerHeight - 150 - top;                 /* タブ・見出しのぶんを空ける */
  if (avail < 120) avail = 120;
  var w = Math.round(avail * (cv._cw || 780) / (cv._ch || 290));
  stage.style.maxWidth = Math.max(320, w) + 'px';
}

function renderActive() {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  var cv = $('mainCv');
  if (!cv) return;
  s._short = shortOf();                       /* 横置きで画面が低い → 図の左に操作パネル */
  s._narrow = !s._short && narrowOf(cv);      /* たて置きの細い画面 → たてに積む */
  var ch = chOf(d, s), cw = cwOf(d, s);
  cv._ch = ch; cv._cw = cw;
  var ctx = prep(cv, cw, ch);
  ctx.save();
  ctx.beginPath(); ctx.rect(0, 0, cw, ch); ctx.clip();
  d.draw(ctx, s, cw, ch);
  drawEqualTicks(ctx);
  if (typeof notebookGrid === 'function' && gridOK(d)) {     /* C5（第 55 回）：ほかを全部描いたあとで、うしろに方眼を敷く */
    ctx.save(); ctx.globalCompositeOperation = 'destination-over'; notebookGrid(ctx, cw, ch); ctx.restore();
  }
  ctx.restore();
  var scv = $('sideCv');
  if (scv && d.drawSide) {                    /* 右の 3 つの図：高さを左の図にそろえる（幅 40 % : 60 %） */
    var sw = 400, sh = Math.round(sw * 1.5 * ch / cw);
    if (scv.parentNode && scv.parentNode.parentNode && getComputedStyle(scv.parentNode.parentNode).flexDirection === 'column') sh = Math.max(sh, 420);
    var sctx = prep(scv, sw, sh);
    d.drawSide(sctx, s, sw, sh);
  }
  renderResbar(d, s);
  fitStage(d, s);
  var gcv = $('fgraph');
  if (gcv && d.graph) drawFricGraph(gcv, d.graph, V(s), s);
}

/* 図のすぐ下の「計算結果の帯」 */
function renderResbar(d, s) {
  var el = $('resbar');
  if (!el || !d.result) { if (el) el.innerHTML = ''; return; }
  var r = d.result(V(s), s);
  var key = JSON.stringify(r);
  if (el._key === key) return;
  el._key = key;
  var h = '';
  (r.items || []).forEach(function (it) {
    h += '<span class="ritem' + (it.kbox ? ' kbox' : '') + (it.stack ? ' stack' : '') + (it.cls ? ' ' + it.cls : '') + '"><span class="rk">' + mathHtml(it.k) + '</span><span class="rv">' + (it.stack ? '= ' : '') + mathHtml(it.v) + '</span></span>';   /* stack … 式のあとで改行して「= 値」 */
  });
  if (r.note) h += '<span class="rnote">' + mathHtml(r.note) + '</span>';
  el.innerHTML = h;
  renderMath(el);
}

/* .tex の中身を KaTeX で組む（1 度だけ） */
function renderMath(root) {
  if (!root || !window.katex) return;
  Array.prototype.forEach.call(root.querySelectorAll('.tex'), function (el) {
    if (el.getAttribute('data-done')) return;
    el.setAttribute('data-done', '1');
    var src = el.textContent;
    el.textContent = '';
    try { window.katex.render(src, el, { throwOnError: false }); }
    catch (e) { el.textContent = src; }
  });
}

/* ===== 画面の切りかえ（URL は #r1 #r2 #r3） ===== */
/* ★アドレスは「#モード-セクション」（#1-1, #1-2, #2-1 … #4-3）★ 古い書き方（#r1, #m1s1 など）も読める */
function prettyOf(id) {
  for (var i = 0; i < MODES.length; i++) {
    var k = MODES[i].ids.indexOf(id);
    if (k >= 0) return MODES[i].n + '-' + (k + 1);
  }
  return id;
}
function hashOf() { return prettyOf(st.cur) + (st.sub ? '-' + st.sub : ''); }   /* 1-2 は ①〜④ にもアドレス（#1-2-3 など） */
function parseHash(h) {
  h = (h || '').replace('#', '');
  var i = h.search(/[!?]/);
  if (i >= 0) h = h.slice(0, i);
  var m = /^(\d+)-(\d+)(?:-(\d+))?$/.exec(h);
  if (m) {
    for (var j = 0; j < MODES.length; j++) {
      if (MODES[j].n === +m[1]) { var id = MODES[j].ids[+m[2] - 1]; if (id) return { id: id, sub: (m[3] && DEFS[id] && DEFS[id].subs && +m[3] <= DEFS[id].subs) ? +m[3] : 0 }; }
    }
  }
  /* 古い書き方（#r1 など）。DEFS 自身のキーだけを通す（#constructor などで止まらないように） */
  return { id: Object.prototype.hasOwnProperty.call(DEFS, h) ? h : '' };
}
function syncHash() {
  var want = '#' + hashOf();
  if (location.hash !== want) { st._skipHash = true; location.hash = want; }
}
/* ＜考え方＞ のカードを画面のいちばん上へ（リンクで飛んだとき用） */
function scrollToThink() {
  var go = function () {
    var bl = $('below'); if (!bl) return;
    var card = bl.querySelector('.bcard');
    if (!card) return;
    var tb = $('tabbar'), hh = tb ? tb.getBoundingClientRect().height : 0;
    var y = card.getBoundingClientRect().top + (window.pageYOffset || document.documentElement.scrollTop || 0) - hh - 6;
    window.scrollTo(0, Math.max(0, y));
  };
  go();
  if (window.requestAnimationFrame) requestAnimationFrame(function () { requestAnimationFrame(go); });
  setTimeout(go, 120);
}
/* 1-2 の ①〜④ のカードへ（① は図のいちばん上） */
function scrollToSub(sub) {
  var go = function () {
    var el = sub > 1 ? document.getElementById('m1card' + sub) : $('simhost');
    if (!el) return;
    var tb = $('tabbar'), hh = tb ? tb.getBoundingClientRect().height : 0;   /* 上に固定したタブのぶん下げる */
    var y = el.getBoundingClientRect().top + (window.pageYOffset || document.documentElement.scrollTop || 0) - hh - 6;
    window.scrollTo(0, Math.max(0, y));
  };
  go();
  if (window.requestAnimationFrame) requestAnimationFrame(function () { requestAnimationFrame(go); });
  setTimeout(go, 120);
}
/* ===== コンテンツ一覧（モードとセクションの題名・リンク） ===== */
function buildToc() {
  var p = $('tocpanel'), b = $('bToc'); if (!p || !b) return;
  var h = '<div class="tochead"><b>コンテンツ一覧</b><button type="button" class="tocx" aria-label="閉じる">×</button></div>';
  MODES.forEach(function (m) {
    h += '<div class="tocmode">' + m.name + '</div><ul>';
    m.ids.forEach(function (id, k) {
      var d = DEFS[id]; if (!d) return;
      var adr = m.n + '-' + (k + 1);
      h += '<li><a href="#' + adr + '" data-toc="' + id + '">' + mathHtml(String(d.title).replace(/<br>/g, '　').replace(/<[^>]+>/g, '')) + '</a></li>';
      if (d.subs && id === 'm1s2') {                  /* 1-2 は ①〜④ も */
        var subT = ['①-2-(1)　作用線の違い', '①-2-(2)　力 1 つで、回転しないような力の加え方はあるか？', '①-2-(3)　力 2 つで、回転しないような力の加え方はあるか？', '①-2-(4)　力 3 つで、回転しないような力の加え方はあるか？'];
        subT.forEach(function (t, j) { h += '<li class="tocsub"><a href="#' + adr + '-' + (j + 1) + '" data-toc="' + id + '" data-tocsub="' + (j + 1) + '">' + t + '</a></li>'; });
      }
    });
    h += '</ul>';
  });
  p.innerHTML = h;
  renderMath(p);
  function close() { p.hidden = true; b.setAttribute('aria-expanded', 'false'); }
  b.addEventListener('click', function (ev) { ev.stopPropagation(); p.hidden = !p.hidden; b.setAttribute('aria-expanded', p.hidden ? 'false' : 'true'); });
  p.querySelector('.tocx').addEventListener('click', close);
  document.addEventListener('click', function (ev) { if (!p.hidden && !p.contains(ev.target) && ev.target !== b) close(); });
  document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape') close(); });
  Array.prototype.forEach.call(p.querySelectorAll('[data-toc]'), function (a) {
    a.addEventListener('click', function (ev) {
      ev.preventDefault(); close();
      var sub = +(a.getAttribute('data-tocsub') || 0);
      gotoSim(a.getAttribute('data-toc'), sub);
      scrollToSub(sub > 1 ? sub : 1);
    });
  });
}
function gotoSim(id, sub) {
  if (!DEFS[id]) return;
  st.sub = sub || 0;
  var m = modeOf(id);
  /* 第 64 回：別のモードなら、そのモードのセクションを全部縦に並べ直す。同じモードなら、そのセクションを生かすだけ */
  if (STK.mode !== m) { st.cur = id; buildTabs(); buildStack(m, id); }
  else stkActivate(id);
  STK.hold = performance.now();
  if (st.sub) scrollToSub(st.sub);
  syncHash();
}

/* ===== アニメーション（「傾く瞬間」のスロー再生だけ） ===== */
var lastTs = null;
function tick(ts) {
  var s = st.sims[st.cur], d = DEFS[st.cur];
  if (lastTs === null) lastTs = ts;
  var dt = Math.min(0.05, (ts - lastTs) / 1000);
  lastTs = ts;
  if (typeof MW !== 'undefined' && MW.run) mwStep(dt);          /* 1-1 の「力のモーメントの 2 通りの求め方」（第 55 回：輪をこの 1 本にまとめた） */
  if (typeof soloWatch === 'function') soloWatch(ts);           /* 画面の外に出たシムは止める */
  if (window.heroTick) window.heroTick(ts);                      /* 第 58 回：ヒーローのステージもこの 1 本の輪で動かす */
  if (s && s.playing && !s.anim && playVar(d)) {
    var vd = playVar(d), rate = (d.playRate || 5) * (s.slow ? 0.25 : 1);
    var nv = s.v[vd.k] + rate * dt;
    var stopAt = playStopAt(d, s, vd);            /* 動きだしたら、ほどよく止める */
    var done = false;
    if (playAtEnd(d, nv, stopAt)) { nv = stopAt; s.playing = false; done = true; }
    s.v[vd.k] = +nv.toFixed(3);
    if (done) { s.v[vd.k] = +stopAt.toFixed(3); setPlayLabel(); }   /* 値を入れてから「最初から」に変える */
    syncVarVals(); refreshActs(); renderActive();
  }
  if (s && ((s._ans && s._ans.playing) || (s._ans2 && s._ans2.playing))) {   /* ＜解答＞の図：θ を上げて傾く瞬間で止める */
    [s._ans, s._ans2].forEach(function (a2) {
      if (!a2 || !a2.playing) return;
      a2.th += (a2.slow ? 2.2 : 8) * dt;
      if (a2.th >= a2.max) { a2.th = a2.max; a2.playing = false; setAnsLabel(s); }
    });
    if (d.drawBelow) d.drawBelow(s);
  }
  if (s && d.tickBelow) d.tickBelow(s, dt);
  if (s && d.tickMain && d.tickMain(s, dt)) { renderActive(); if (d.playLabel) setPlayLabel(); }
  if (s && s.anim && s.anim.kind === 'push') {
    if (stepPushAnim(s, dt)) renderActive();
  } else if (s && s.anim) {
    var a = s.anim;
    if (a.t0 === null) a.t0 = ts;
    var e = (ts - a.t0) / 1000;
    var tot = a.dur + a.hold;
    var k;
    if (e < a.hold * 0.5) k = 0;                                       /* 直前で少し止まる */
    else if (e < a.hold * 0.5 + a.dur) k = (e - a.hold * 0.5) / a.dur;
    else k = 1;
    var val = a.from + (a.to - a.from) * k;
    s.v[a.k] = +val.toFixed(4);
    syncVarVals(); refreshActs(); renderActive();
    if (e >= tot + 0.6) { s.anim = null; }
  }
  requestAnimationFrame(tick);
}

