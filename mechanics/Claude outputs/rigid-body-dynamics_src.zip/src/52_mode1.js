/* ===== 52_mode1.js ===== */
/* ============================================================
   モード 1　剛体の性質と力のモーメント
     m1s1 … 力のモーメント（左：箱を指で押す／右：天びん）
     m1s2 … 剛体への力のはたらき（①作用線の違い ②力 1 つ ③力 2 つ）
   ============================================================ */
'use strict';

/* ===== 磁石スナップ（正解の位置で「ぴたっ」と吸いつく） =====
   val … いまの値、goal … 正解の値、r … 吸いつく半径。
   ★いったん吸いついたら、はなれる半径は大きくする（ヒステリシス）★ 呼ぶ側で
     r = snapped ? R_OUT : R_IN とする。 */
function snapTo(val, goal, r) {
  var d = Math.abs(val - goal);
  if (d <= r) return { v: goal, on: true, near: 1 };
  return { v: val, on: false, near: clamp(1 - (d - r) / (r * 3), 0, 1) };
}
function snapGlow(ctx, x, y, r, col, near) {
  ctx.save();
  ctx.globalAlpha = 0.25 + 0.45 * near;
  ctx.strokeStyle = col || '#e07b18'; ctx.lineWidth = 3;
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.stroke();
  ctx.globalAlpha = 0.10 + 0.16 * near;
  ctx.fillStyle = col || '#e07b18';
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
}
/* 落ち着いた色の吹き出し（「傾いている」など）／つりあいの吹き出し */
function calmBubble(ctx, text, x, y, size) {
  bubble(ctx, text, x, y, { side: 'down', size: size || 14, dx: 0,
    bg: '#eef3f8', border: '#8ba4bd', color: '#3d4c5a' });
}
function okBubble(ctx, text, x, y, size) {
  bubble(ctx, text, x, y, { side: 'down', size: size || 14, dx: 0,
    bg: '#dff2ee', border: '#0f8a8a', color: '#0a5c5c' });
}
/* 点線（うで など） */
function dotLine(ctx, x1, y1, x2, y2, col, lw, dash) {
  ctx.save();
  ctx.strokeStyle = col; ctx.lineWidth = lw || 1.8; ctx.setLineDash(dash || [3, 4]);
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
  ctx.restore();
}
/* 寸法の両矢印（縦）。x … 位置、y1〜y2、text … 横に書く文字 */
function dimV(ctx, x, y1, y2, text, side) {
  ctx.save(); ctx.strokeStyle = '#1b1f24'; ctx.fillStyle = '#1b1f24'; ctx.lineWidth = 1.3;
  ctx.beginPath(); ctx.moveTo(x, y1); ctx.lineTo(x, y2); ctx.stroke();
  [[y1, y2], [y2, y1]].forEach(function (q) {           /* ↕：矢じりは両はしで外向き */
    if (Math.abs(y2 - y1) < 12) return;
    var dir = q[0] < q[1] ? -1 : 1;                     /* 外向き（上のはしは上、下のはしは下） */
    ctx.beginPath(); ctx.moveTo(x, q[0]); ctx.lineTo(x - 5, q[0] - dir * 9); ctx.lineTo(x + 5, q[0] - dir * 9);
    ctx.closePath(); ctx.fill();
  });
  ctx.beginPath(); ctx.moveTo(x - 6, y1); ctx.lineTo(x + 6, y1); ctx.moveTo(x - 6, y2); ctx.lineTo(x + 6, y2); ctx.stroke();
  ctx.restore();
  if (text) label(ctx, text, x + (side < 0 ? -8 : 8), (y1 + y2) / 2, { size: 14, bold: true, color: '#1b1f24', align: side < 0 ? 'right' : 'left' });
}

/* ===== 人さし指で指す手（線画。白い手・こい輪郭）=====
   (x, y) … 指先、ang … 指さす向き（0 ＝ 上、π/2 ＝ 右）、sc … 大きさ */
function pointHand(ctx, x, y, ang, sc) {
  sc = sc || 1;
  var INK = '#2a3036', SKIN = '#ffffff';
  ctx.save();
  ctx.translate(x, y); ctx.rotate(ang); ctx.scale(sc, sc);
  ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  ctx.fillStyle = SKIN; ctx.strokeStyle = INK; ctx.lineWidth = 2.4;
  function rr(x0, y0, w, h, r) {
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(x0, y0, w, h, r); else ctx.rect(x0, y0, w, h);
    ctx.fill(); ctx.stroke();
  }
  /* 手首 */
  rr(-4, 70, 34, 30, 3);
  /* にぎった 3 本の指（手のひら側の出っぱり） */
  rr(5, 32, 13, 24, 6.5);
  rr(16, 35, 13, 23, 6.5);
  rr(27, 39, 12, 22, 6);
  /* 手のひら */
  ctx.beginPath();
  ctx.moveTo(-8, 44);
  ctx.lineTo(-8, 66); ctx.quadraticCurveTo(-8, 78, 4, 78);
  ctx.lineTo(28, 78); ctx.quadraticCurveTo(40, 78, 40, 66);
  ctx.lineTo(40, 52); ctx.lineTo(-8, 44);
  ctx.closePath(); ctx.fill(); ctx.stroke();
  /* 親指（左がわ） */
  ctx.beginPath();
  ctx.moveTo(-6, 50); ctx.quadraticCurveTo(-20, 40, -26, 46);
  ctx.quadraticCurveTo(-30, 52, -20, 60); ctx.lineTo(-7, 70);
  ctx.fill(); ctx.stroke();
  /* 人さし指（のばす） */
  ctx.beginPath();
  ctx.moveTo(-7, 48); ctx.lineTo(-7, 7); ctx.arc(0, 7, 7, Math.PI, 0); ctx.lineTo(7, 46);
  ctx.fill(); ctx.stroke();
  /* しわ */
  ctx.lineWidth = 1.4;
  ctx.beginPath(); ctx.moveTo(-3, 26); ctx.lineTo(3, 26); ctx.stroke();
  ctx.restore();
}

/* ============ m1s1　力のモーメント ============ */
/* 箱：幅 10 cm・高さ 20 cm・質量 0.50 kg。右下の蝶つがいのまわりに回れる。指で押す力は F = 3.0 N（一定） */
var M1 = { MU: 0.80, BW: 0.10, BH: 0.20, MASS: 0.50, FN: 3.0, BEAM: 0.60, NPOS: 6, TSCALE: 0.28, PUSH: 0.6, GAP: 7 };
M1.I = M1.MASS * (M1.BW * M1.BW + M1.BH * M1.BH) / 3;          /* 右下の角のまわりの慣性モーメント */
M1.H0 = M1.MASS * G * M1.BW / (2 * M1.FN);                      /* これより高く押すと傾く [m]（≒ 8.2 cm） */
M1.THC = Math.atan(M1.BW / M1.BH);                              /* 重心が右下の角の真上に来る角 */

function balanceGoal(v) { return v.nL * 1 / Math.max(1, v.kR); }

/* ★1-1 の箱は蝶つがいで止めていない（4-3 と同じ、床の上に置いただけ）★
   ・すべる：指の力 F が最大摩擦力 μmg をこえると、床の上をすべる（すべっている間は動摩擦 μ'mg、μ' = 0.8μ）
   ・傾く　：右下の角のまわりのモーメント F·h が mg·w/2 をこえると、右下の角を軸に傾く
             （摩擦力は床の面にそってはたらくので、右下の角のまわりのモーメントは 0。傾く条件はすべっていても同じ）
   ・指は一定の時間（PUSH 秒）だけ押して、はなす。そのとき重心が角の真上をこえていなければ、もとにもどる */
function m1Torque(h, th, pushing) {                /* 右下の角のまわり（時計まわり＝右へ倒れる向きが正） */
  var tq = M1.MASS * G * (-M1.BW / 2 * Math.cos(th) + M1.BH / 2 * Math.sin(th));   /* 重力 */
  if (pushing) tq += M1.FN * (h * Math.cos(th) + M1.BW * Math.sin(th));             /* 指の力（水平） */
  return tq;
}
function m1PushStart(s) {
  var p = s._pa, keepX = (p && p.th < 1e-3) ? p.x : 0;      /* すべって止まった所から、また押せる（倒れていたら、もとの位置から） */
  s._pa = { ph: 'approach', t: 0, th: 0, om: 0, x: keepX, v: 0, moved: false, slid: false, maxTh: 0, back: false };
}
function m1PushStep(s, dt) {
  var a = s._pa; if (!a) return false;
  if (a.ph === 'done') {                           /* 倒れたら 2 秒後に、その場で箱を立てる */
    if (a.th <= 1e-3) return false;
    a.upT = (a.upT || 0) + dt;
    if (a.upT >= 2) s._pa = null;                  /* 2 秒たったら、リセットと同じ（いきなり、もとの位置に立っている） */
    return true;
  }
  var v = V(s), h = v.h / 100, mu = M1.MU, muk = 0.8 * mu;        /* あらい床（μ = 0.80 … 指の力ではすべらない） */
  a.t += dt;
  if (a.ph === 'approach') { if (a.t >= 0.15) { a.ph = 'push'; a.t = 0; } return true; }
  if (a.ph === 'push' && a.t >= M1.PUSH) { a.ph = 'free'; a.t = 0; }
  var pushing = a.ph === 'push';
  var n = 10, hdt = dt * M1.TSCALE / n, i;
  for (i = 0; i < n; i++) {
    /* 回転（右下の角のまわり） */
    var tq = m1Torque(h, a.th, pushing);
    if (a.th > 0 || tq > 0) {
      a.om += tq / M1.I * hdt;
      a.th += a.om * hdt;
      if (a.th <= 0) {                               /* 床にもどった：小さくはねて止まる */
        a.th = 0; a.om = (Math.abs(a.om) > 0.4) ? -a.om * 0.25 : 0;
        if (a.maxTh > 1 * DEG) a.back = true;
      }
    } else { a.om = 0; }
    if (a.th >= Math.PI / 2) { a.th = Math.PI / 2; a.om = 0; }
    a.maxTh = Math.max(a.maxTh, a.th);
    /* すべり（床の上） */
    var Fp = pushing ? M1.FN : 0;
    if (a.v <= 0) {
      a.v = 0;
      if (Fp > mu * M1.MASS * G) { a.v = 1e-6; a.slid = true; }       /* 最大摩擦力をこえた */
    }
    if (a.v > 0) {
      a.v += (Fp - muk * M1.MASS * G) / M1.MASS * hdt;
      if (a.v < 0) a.v = 0;
      a.x += a.v * hdt;
    }
  }
  if (a.th > 0.2 * DEG || a.v > 0) a.moved = true;
  if (a.ph === 'free') {
    var still = a.v === 0 && ((a.th === 0 && a.om === 0) || a.th >= Math.PI / 2);
    if (still && a.t > 0.2) a.ph = 'done';
  }
  return true;
}
function m1Reset(s) { s._pa = null; }

/* --- 左：箱を指で押す（床の上に置いた箱） --- */
function drawDoorPane(ctx, s, v, R) {
  var S = Math.min((R.w - 150) / (M1.BW + M1.BH + 0.14), (R.h - 110) / M1.BH, 800);
  var w = M1.BW * S, hh = M1.BH * S;
  var y1 = R.y0 + R.h - 44;
  var a = s._pa, th = a ? a.th : 0;
  var x0 = R.x0 + 110 + w;                                       /* はじめの右下の角 */
  var xmax = R.x0 + R.w - 10 - hh;                               /* 倒れても右の図にはみ出さない */
  var pv = { x: Math.min(xmax, x0 + (a ? a.x : 0) * S), y: y1 }; /* 右下の角（傾くときの回転軸） */
  var hm = v.h / 100;
  ground(ctx, R.x0 + 14, R.x0 + R.w - 14, y1);
  ctx.save();
  ctx.translate(pv.x, pv.y); ctx.rotate(th);
  ctx.fillStyle = BOXCOL.fill; ctx.strokeStyle = BOXCOL.line; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.rect(-w, -hh, w, hh); ctx.fill(); ctx.stroke();
  ctx.restore();
  function bp(dx, dy) {           /* 箱の左下を原点にした (dx 右, dy 上) */
    var X = -(w - dx), Y = -dy;
    return { x: pv.x + X * Math.cos(th) - Y * Math.sin(th), y: pv.y + X * Math.sin(th) + Y * Math.cos(th) };
  }
  var nb = bp(w / 2, hh * 0.78);                                   /* 「箱」の字（箱の中の上のほう） */
  label(ctx, '箱', nb.x, nb.y, { size: 15, bold: true, color: '#6b4a2e' });
  var showL = !!(s.o && s.o.showL);                               /* 「力と力の作用線を表示」 */
  if (th > 0.3 * DEG || showL) axisMark(ctx, pv.x, pv.y, '回転軸', { dx: 10, dy: 18, align: 'left' });   /* 傾くとき（と作用線を出すとき） */
  var ap = bp(0, hm * S);
  if (showL) {                                                     /* 指の力の作用線（水平な点線） */
    var ux0 = Math.cos(th), uy0 = Math.sin(th);
    ctx.save(); ctx.strokeStyle = fade(COL.hand, .7); ctx.lineWidth = 1.4; ctx.setLineDash([7, 5]);
    ctx.beginPath(); ctx.moveTo(ap.x - 110 * ux0, ap.y - 110 * uy0); ctx.lineTo(ap.x + (w + 150) * ux0, ap.y + (w + 150) * uy0); ctx.stroke(); ctx.restore();
    label(ctx, '作用線', ap.x - 100, ap.y - 14, { size: 13, bold: true, color: COL.hand, align: 'left' });
  }
  var still = !a || a.ph === 'done';
  if (!a || (a.ph === 'done' && th < 1e-3) || (!a.moved && a.ph !== 'push')) {   /* 箱の右に「高さ ○ cm」の ↕ */
    var dxx = pv.x + 24;
    dotLine(ctx, ap.x + 2, ap.y, dxx + 6, ap.y, 'rgba(27,31,36,.45)', 1, [3, 3]);
    dimV(ctx, dxx, y1, ap.y, '', 1);
    label(ctx, '高さ ' + fmt(v.h, 0) + ' cm', dxx + 10, Math.min((y1 + ap.y) / 2, y1 - 14), { size: 14, bold: true, color: '#1b1f24', align: 'left' });
    if (showL) label(ctx, '回転軸と作用線の距離 ＝', dxx + 10, Math.min((y1 + ap.y) / 2, y1 - 14) - 20, { size: 12.5, bold: true, color: '#1c8f4a', align: 'left' });
  }
  /* 指：はじめから箱のすぐそば。押す（箱といっしょに動く）→ はなす */
  var fx = ap.x - M1.GAP, fy = ap.y, touching = false;
  if (a && a.ph === 'approach') { fx = ap.x - M1.GAP + M1.GAP * clamp(a.t / 0.15, 0, 1); }
  else if (a && a.ph === 'push') { fx = ap.x; touching = true; a.rel = { x: ap.x, y: ap.y }; }   /* はなす位置を覚える */
  else if (a && (a.ph === 'free' || (a.ph === 'done' && th > 1e-3))) {
    /* はなしたあとは、はなした所から水平に少し下がって止まる（箱が倒れても、指は箱を追いかけない） */
    var rl = a.rel || { x: x0 - w, y: y1 - hm * S };
    fx = rl.x - M1.GAP - (a.ph === 'free' ? Math.min(26, a.t * 90) : 26); fy = rl.y;
  }
  else if (a && a.ph === 'done') { fx = ap.x - M1.GAP; }             /* 止まった箱のすぐそばに指 */
  pointHand(ctx, fx - 1, fy, Math.PI / 2, 0.62);
  s._door = { fx: fx, fy: fy, y1: y1, S: S };
  if (touching || showL) {                                         /* 作用線を出すときは、押す前から力の矢印を見せる */
    arrow(ctx, ap.x, ap.y, ap.x + 58, ap.y, 'force', 1.1, COL.hand);
    label(ctx, 'F', ap.x + 66, ap.y - 14, { size: 15, bold: true, color: COL.hand });
  }
  /* 吹き出し（箱の上） */
  var cs = [bp(0, 0), bp(w, 0), bp(w, hh), bp(0, hh)];
  var topY = Math.min.apply(null, cs.map(function (c) { return c.y; }));
  var midX = cs.reduce(function (t, c) { return t + c.x; }, 0) / 4;
  if (a && a.ph !== 'approach' && !a.restored) {
    if (a.th >= Math.PI / 2 - 1e-3 && still) bubble(ctx, '倒れた！', midX, topY - 14, { side: 'down', size: 15, dx: 0, bg: '#fde2dc', border: '#d1352b', color: '#9b2418' });
    else if (a.maxTh > 5 * DEG && !(a.back && still)) verdictBubble(ctx, 'tip', midX, topY - 14, 'down', 14);
    else if (a.back && still) calmBubble(ctx, '傾いたが、もどった', midX, topY - 14, 14);
    else if (a.slid) verdictBubble(ctx, 'slip', midX, topY - 14, 'down', 14);
    else if (!a.moved) calmBubble(ctx, '動かない…', midX, topY - 14, 14);
    if (a.slid && a.maxTh > 5 * DEG) label(ctx, 'すべりながら傾いた', midX, y1 + 22, { size: 13, bold: true, color: '#0a5c5c' });
  }
}

/* --- 右：天秤 --- */
function drawBalancePane(ctx, s, v, R) {
  var S = (R.w - 80) / (2 * M1.BEAM);
  var cx = R.x0 + R.w / 2, cy = R.y0 + R.h * 0.36;
  var half = M1.BEAM * S;
  var gL = v.nL / M1.NPOS * M1.BEAM, gR = s._rpos / M1.NPOS * M1.BEAM;
  var ML = 1 * gL, MR = v.kR * gR;
  var diff = MR - ML;
  var ang = clamp(diff * 0.9, -0.30, 0.30);
  var bal = Math.abs(diff) < 1e-6;
  var u = { x: Math.cos(ang), y: Math.sin(ang) };
  function bp(t) { return { x: cx + u.x * t, y: cy + u.y * t }; }
  var gyy = R.y0 + R.h - 44;
  /* 支柱 */
  ctx.save();
  ctx.fillStyle = '#c9d0d7'; ctx.strokeStyle = '#8b949e'; ctx.lineWidth = 1.2;
  ctx.beginPath(); ctx.moveTo(cx - 26, gyy); ctx.lineTo(cx + 26, gyy);
  ctx.lineTo(cx + 7, cy + 4); ctx.lineTo(cx - 7, cy + 4); ctx.closePath(); ctx.fill(); ctx.stroke();
  ctx.restore();
  ground(ctx, R.x0 + 20, R.x0 + R.w - 20, gyy);
  /* 棒 */
  ctx.save();
  ctx.strokeStyle = '#6b7885'; ctx.lineWidth = 7; ctx.lineCap = 'round';
  var e1 = bp(-half), e2 = bp(half);
  ctx.beginPath(); ctx.moveTo(e1.x, e1.y); ctx.lineTo(e2.x, e2.y); ctx.stroke();
  ctx.restore();
  /* 目盛り */
  var i;
  for (i = 1; i <= M1.NPOS; i++) {
    [-1, 1].forEach(function (sg) {
      var t = sg * i / M1.NPOS * half, p = bp(t), q = { x: p.x - u.y * 7, y: p.y + u.x * 7 };
      ctx.save(); ctx.strokeStyle = '#9aa7b3'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y); ctx.stroke(); ctx.restore();
      label(ctx, String(i), q.x - u.y * 9, q.y + u.x * 9, { size: 11.5, color: '#8795a2', avoid: false });
    });
  }
  var tn = bp(-half * 0.72);                                       /* 「天秤」の字（棒の左の上） */
  label(ctx, '天秤', tn.x + u.y * 22, tn.y - u.x * 22, { size: 14, bold: true, color: '#4e5a66' });
  pinMark(ctx, cx, cy, 5.5);                      /* 支点の蝶つがい（ここで傾くだけ） */
  label(ctx, '回転軸', cx, cy - 18, { size: 13, bold: true, color: COL.sub });   /* 回転軸の真上 */
  /* おもり */
  var w_sp = 25;
  function weights(t, n, col, hot) {
    var p = bp(t), i2;
    ctx.save(); ctx.strokeStyle = '#6b7885'; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x, p.y + 14); ctx.stroke(); ctx.restore();
    var sp = n > 1 ? Math.min(25, (gyy - 20 - (p.y + 29)) / (n - 1)) : 25;   /* 床にめりこまないよう、つめて重ねる */
    var rr = Math.min(11.5, sp / 2 + 0.5);
    w_sp = sp;
    for (i2 = 0; i2 < n; i2++) {
      var yy = p.y + 14 + 15 + i2 * sp;
      ctx.save();
      ctx.fillStyle = col; ctx.strokeStyle = hot ? '#a85c0c' : '#6b7885'; ctx.lineWidth = hot ? 2 : 1.3;
      ctx.beginPath(); ctx.arc(p.x, yy, rr, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
      ctx.restore();
    }
    return p;
  }
  var pL = weights(-v.nL / M1.NPOS * half, 1, '#e8eef5', false);
  var pR = weights(s._rpos / M1.NPOS * half, v.kR, '#ffe6c7', true);
  label(ctx, '1 個', pL.x - 18, pL.y + 14 + 15, { size: 13, color: '#3d4c5a', align: 'right' });
  label(ctx, v.kR + ' 個', pR.x + 32, pR.y + 14 + 15 + (v.kR - 1) * w_sp, { size: 13, bold: true, color: '#a85c0c' });
  s._snap = bal;
  if (s._snap) snapGlow(ctx, pR.x, pR.y + 8, 22, '#e07b18', 1);
  if (s.o && s.o.showL) {                        /* おもりの重力と作用線（鉛直な点線）、回転軸からの距離 */
    [[pL, 1], [pR, v.kR]].forEach(function (q) {
      var p = q[0], n = q[1], sp2 = q[0] === pL ? 25 : w_sp, rr2 = Math.min(11.5, sp2 / 2 + 0.5);
      var by = p.y + 14 + 15 + (n - 1) * sp2 + rr2;                /* いちばん下のおもりの下から */
      ctx.save(); ctx.strokeStyle = fade(COL.force, .6); ctx.lineWidth = 1.3; ctx.setLineDash([6, 4]);
      ctx.beginPath(); ctx.moveTo(p.x, p.y - 30); ctx.lineTo(p.x, gyy); ctx.stroke(); ctx.restore();
      arrow(ctx, p.x, by, p.x, Math.min(gyy - 20, by + 22 + 9 * n), 'force', 0.9, COL.force);   /* 重力（作用線の上） */
    });
    [pL, pR].forEach(function (p) {                /* 回転軸から作用線までの距離（うで）… 床の少し上 */
      var yy = gyy - 12;
      if (Math.abs(p.x - cx) < 6) return;
      arrow(ctx, (cx + p.x) / 2, yy, cx, yy, 'dim', 1); arrow(ctx, (cx + p.x) / 2, yy, p.x, yy, 'dim', 1);
      label(ctx, 'うで', (cx + p.x) / 2, yy - 11, { size: 12.5, bold: true, color: '#1c8f4a' });
    });
    dotLine(ctx, cx, cy, cx, gyy, 'rgba(27,31,36,.4)', 1, [3, 3]);   /* 回転軸の真下 */
  }
  if (bal) {
    okBubble(ctx, 'つりあった！', cx, cy - 62, 15);
    label(ctx, '左 1 個 × 距離 ' + v.nL + '　＝　右 ' + v.kR + ' 個 × 距離 ' + fmt(s._rpos, 0), R.x0 + R.w - 14, R.y0 + 24, { size: 15, bold: true, color: '#0a5c5c', align: 'right' });
  } else calmBubble(ctx, '傾いている', cx, cy - 62, 15);
  balEqHtml(v, s._rpos, bal);
  return { cx: cx, cy: cy, half: half, bp: bp };
}

DEFS['m1s1'] = {
  id: 'm1s1', tab: '①-1　力のモーメント', noAB: true,
  title: '①-1　力のモーメント（回転させるはたらき）とは何か',
  subSplit: ['同じ大きさの力でも、<b>回転軸から遠いところ</b>を押すほど回しやすい。<br><span class="small2">（あらい床の上の箱を考えている）</span>',
    '天秤は、左右の「力 × 軸からの距離」が等しいときにつりあう。<br><span id="m1balEq"></span>'],
  split: 0.46,            /* 上の操作パネルの左右の境目＝図の左右の境目（46 %） */
  cw: function (v, s) { return (s && s._narrow) ? 470 : 860; },
  ch: function (v, s) { return (s && s._narrow) ? 660 : 350; },
  vars: [
    { k: 'h', label: '指で押す高さ', unit: ' cm', min: 1, max: 20, step: 1, dec: 0, def: 4 },
    { k: 'nL', label: '左のおもりの位置', unit: '', min: 1, max: 6, step: 1, dec: 0, def: 6 },
    { k: 'kR', label: '右のおもりの数', unit: ' 個', min: 1, max: 6, step: 1, dec: 0, def: 3 }
  ],
  varGroups: [
    { label: '箱を指で押す', keys: ['h'], play: true, playOnly: true, reset: true, auto: '⏫ 自動で高くしていく' },
    { label: '天秤', side: true, keys: ['nL', 'kR'], inline: true, revBtn: ['nL'] }
  ],
  guides: [{ key: 'm1s1.left', x: 0 }, { key: 'm1s1.right', x: 0.46, cls: 'g2' }],
  play: function (s) { s._auto = null; m1AutoLabel(s); m1PushStart(s); },
  playLabel: function (s) { return '👉 指で押す'; },
  tickMain: function (s, dt) {
    var r = m1PushStep(s, dt), au = s._auto, a = s._pa;
    /* 自動で高くしていく：8 cm から 2 cm ずつ。止まったら次の高さへ、倒れたら終わり */
    if (au && a && a.ph === 'done') {
      if (a.th >= Math.PI / 2 - 1e-3) { s._auto = null; m1AutoLabel(s); return true; }
      au.wait += dt;
      if (au.wait >= 0.7) {
        if (s.v.h + 2 > 20) { s._auto = null; m1AutoLabel(s); return true; }
        s.v.h += 2; s._paH = s.v.h; au.wait = 0;
        m1PushStart(s);
        if (typeof syncVarVals === 'function') syncVarVals();
      }
      return true;
    }
    return r;
  },
  onReset: function (s) { m1Reset(s); s._auto = null; m1AutoLabel(s); },
  reset: function (s) { s._rpos = 4; s._snap = false; s._pa = null; },
  draw: function (ctx, s, W, H) {
    var v = V(s);
    if (s._rpos === undefined) { s._rpos = 4; }
    if (s._pa && s._paH !== v.h) s._pa = null;       /* 高さを変えたら、箱をもとにもどす */
    s._paH = v.h;
    var nar = !!s._narrow, sp = DEFS['m1s1'].split;
    var RA = nar ? { x0: 0, y0: 0, w: W, h: H * 0.48 } : { x0: 0, y0: 0, w: W * sp, h: H };
    var RB = nar ? { x0: 0, y0: H * 0.5, w: W, h: H * 0.5 } : { x0: W * sp, y0: 0, w: W * (1 - sp), h: H };
    drawDoorPane(ctx, s, v, RA);
    ctx.save(); ctx.strokeStyle = '#cfd8e0'; ctx.lineWidth = 1.2;
    if (nar) { ctx.beginPath(); ctx.moveTo(10, H * 0.49); ctx.lineTo(W - 10, H * 0.49); ctx.stroke(); }
    else { ctx.beginPath(); ctx.moveTo(W * sp, 0); ctx.lineTo(W * sp, H); ctx.stroke(); }
    ctx.restore();
    s._bal = drawBalancePane(ctx, s, v, RB);
  },
  dragNoDown: true,
  dragDown: function (s, lx, ly) {
    var dd = s._door;                                  /* 指（手の絵のあたり）をつかむと、押す高さを変える */
    if (dd && lx > dd.fx - 80 && lx < dd.fx + 16 && Math.abs(ly - dd.fy) < 36) { s._dragT = 'finger'; return true; }
    var b = s._bal; if (!b) return false;
    var pl = b.bp(-V(s).nL / M1.NPOS * b.half);          /* 左のおもりもドラッグできる */
    if (Math.hypot(lx - pl.x, ly - pl.y - 34) < 44) { s._dragT = 'balL'; return true; }
    var p = b.bp(s._rpos / M1.NPOS * b.half);
    s._dragT = 'bal';
    return Math.hypot(lx - p.x, ly - p.y - 34) < 56;
  },
  drag: function (s, lx, ly) {
    if (s._dragT === 'finger') {
      var dd = s._door; if (!dd) return;
      s.v.h = clamp(Math.round((dd.y1 - ly) / dd.S * 100), 1, 20);
      s._pa = null;
      return;
    }
    var b = s._bal, v = V(s); if (!b) return;
    if (s._dragT === 'balL') {                             /* 左のおもり：1〜6 の目盛りに置く */
      s.v.nL = clamp(Math.round(-(lx - b.cx) / b.half * M1.NPOS), 1, M1.NPOS);
      s._snap = Math.abs(v.kR * s._rpos - s.v.nL) < 1e-6;
      return;
    }
    var t = clamp(Math.round((lx - b.cx) / b.half * M1.NPOS), 1, M1.NPOS);   /* 右のおもりも 1〜6 の目盛り（整数）だけ */
    s._rpos = t;
    s._snap = Math.abs(v.kR * t - v.nL) < 1e-6;
  },
  keys: function (s, dir) {
    var v = V(s);
    var t = clamp(Math.round(s._rpos) + dir, 1, M1.NPOS);
    s._rpos = t; s._snap = Math.abs(v.kR * t - v.nL) < 1e-6;
  },
  below: function (s) {
    return '<div class="bcard"><h3>＜考え方＞　力のモーメント</h3>' +
      '<p>物体を回転させるはたらきを<b>力のモーメント</b>という。回転軸から力の<b>作用線</b>までの距離 $l$ を<b>うでの長さ</b>という。</p>' +
      '<div class="fmlbox"><span class="tex">M = F\\,l</span></div>' +
      '<p>$M$［N・m］…力のモーメント、$F$［N］…力の大きさ、$l$［m］…うでの長さ。' +
      '単位は<b>ニュートンメートル（記号 N・m）</b>。左の図では、押す高さがうでの長さ $l$ にあたる。</p></div>' +
      '<div class="bcard"><h3>力のモーメントの 2 通りの求め方</h3>' +
      '<div class="mwwrap"><canvas id="m1moment"></canvas>' +
      '<button class="dplay mwplay pulse" data-mwplay="0" style="left:1%">▶ スタート</button>' +
      '<button class="dplay mwplay pulse" data-mwplay="1" style="left:51%">▶ スタート</button></div>' +
      '<p class="mini">F の先をドラッグすると、F の向きが変わる（大きさは同じ）。(1) では作用線が変わるので<b>うでの長さ</b>が、(2) では <b>F sinθ</b> が変わる。</p>' +
      '<p>点 O から力の作用点 P までの距離を $L$［m］、OP の延長と力のなす角を $\\theta$ とする。</p>' +
      '<div class="fmlbox"><span class="tex">(1)\\ F \\times \\text{うでの長さ}\\qquad l = L\\sin\\theta \\quad\\Rightarrow\\quad M = F\\,l = F L \\sin\\theta</span></div>' +
      '<div class="fmlbox"><span class="tex">(2)\\ F \\text{ の OP に垂直な成分} \\times L\\qquad M = (F \\sin\\theta) \\times L</span></div>' +
      '<p>どちらで考えてもよい。(2) で <b>OP に平行な成分 $F\\cos\\theta$ は、O を回すはたらきをもたない</b>（作用線が O を通るから）。</p></div>';
  },
  drawBelow: function (s) {
    var cv = document.getElementById('m1moment');
    if (cv && cv.clientWidth > 0) drawMomentWays(cv);
  },
  titleVis: { k: 'L', label: '力と力の作用線を表示' },     /* 第 56 回：ボタン → ②-1 と同じスイッチ（s.o.showL） */
  wire: function (s, host) {
    wireMomentWays();
    /* 指をダブルクリック（スマホはダブルタップ）で押す */
    var mcv = document.getElementById('mainCv'), lastTap = null, downAt = null, movedAt = 0;
    if (mcv) mcv.addEventListener('pointerdown', function (ev) { downAt = { x: ev.clientX, y: ev.clientY }; });
    if (mcv) mcv.addEventListener('pointerup', function (ev) {
      if (downAt && Math.hypot(ev.clientX - downAt.x, ev.clientY - downAt.y) > 6) { lastTap = null; movedAt = Date.now(); return; }   /* ドラッグは「押す」に数えない */
      var r = mcv.getBoundingClientRect(), lx = (ev.clientX - r.left) / r.width * (mcv._cw || 860), ly = (ev.clientY - r.top) / r.height * (mcv._ch || 350);
      var dd = s._door;
      if (!dd || !(lx > dd.fx - 80 && lx < dd.fx + 16 && Math.abs(ly - dd.fy) < 36)) { lastTap = null; return; }
      var now = Date.now();
      if (lastTap && now - lastTap.t < 500 && Math.hypot(ev.clientX - lastTap.x, ev.clientY - lastTap.y) < 30) {
        lastTap = null; fingerPush();
      } else lastTap = { t: now, x: ev.clientX, y: ev.clientY };
    });
    function fingerPush() {                                   /* 押しはじめる（2 回続けて呼ばれても 1 回だけ） */
      var now = Date.now(); if (s._lastPush && now - s._lastPush < 600) return; s._lastPush = now;
      s._auto = null; m1AutoLabel(s); m1PushStart(s);
      if (typeof setPlayLabel === 'function') setPlayLabel();
      renderActive();
    }
    if (mcv) mcv.addEventListener('dblclick', function (ev) {  /* ブラウザのダブルクリックでも（取りこぼしのないように） */
      var r = mcv.getBoundingClientRect(), lx = (ev.clientX - r.left) / r.width * (mcv._cw || 860), ly = (ev.clientY - r.top) / r.height * (mcv._ch || 350);
      var dd = s._door;
      if (Date.now() - movedAt < 800) return;               /* ドラッグのすぐあとは数えない */
      if (dd && lx > dd.fx - 80 && lx < dd.fx + 16 && Math.abs(ly - dd.fy) < 36) { ev.preventDefault(); fingerPush(); }
    });
    var b = document.getElementById('bAuto');
    if (b) b.addEventListener('click', function () {
      if (s._auto) { s._auto = null; m1AutoLabel(s); return; }        /* もう一度押すと止める */
      s._auto = { wait: 0 };
      s.v.h = 4; s._paH = 4; m1PushStart(s);   /* 4 cm から */
      if (typeof syncVarVals === 'function') syncVarVals();
      m1AutoLabel(s);
    });
    m1AutoLabel(s);
  }
};
/* 図の下：回転軸のまわりの力のモーメントのつりあいの式（おもり 1 個の質量 m、目盛り 1 つ ＝ 10 cm） */
function balEqHtml(v, rpos, bal) {
  var el = document.getElementById('m1balEq'); if (!el) return;
  var L = v.nL * 10, Rr = Math.round(rpos) * 10, k = v.kR;
  var h = '<span class="small2">回転軸のまわりの力のモーメントのつりあいの式（おもり 1 個の質量 $m$、距離は cm）</span><br>' +
    '$mg \\times ' + L + '\\ \\text{cm} ' + (bal ? '=' : '\\neq') + ' ' + (k === 1 ? '' : k) + 'mg \\times ' + Rr + '\\ \\text{cm}$' + (bal ? '　（つりあう）' : '　（まだつりあわない）');
  if (el._h === h) return;
  el._h = h; el.innerHTML = mathHtml(h); renderMath(el);
}
function m1AutoLabel(s) {
  var b = document.getElementById('bAuto'); if (!b) return;
  b.textContent = s._auto ? '■ 自動を止める' : '⏫ 自動で高くしていく';
  b.classList.toggle('on', !!s._auto);
}

/* スパナ（上から見た図）。O … ナットの中心、ang … 柄の向き、len … O から柄の先まで [px] */
function spanner(ctx, O, ang, len) {
  ctx.save();
  ctx.translate(O.x, O.y); ctx.rotate(ang);
  ctx.fillStyle = '#c7ced6'; ctx.strokeStyle = '#4e5a66'; ctx.lineWidth = 1.6; ctx.lineJoin = 'round';
  /* 柄と頭（口の開いたスパナ）を 1 つの輪郭で描く。口は柄と反対がわ（左）に開く */
  ctx.beginPath();
  ctx.moveTo(18, -9); ctx.lineTo(len, -11);
  ctx.quadraticCurveTo(len + 14, 0, len, 11);
  ctx.lineTo(18, 9);
  ctx.arc(0, 0, 25, 0.38, Math.PI - 0.5, false);
  ctx.lineTo(7, 11); ctx.lineTo(7, -11);
  ctx.lineTo(25 * Math.cos(Math.PI + 0.5), 25 * Math.sin(Math.PI + 0.5));
  ctx.arc(0, 0, 25, Math.PI + 0.5, 2 * Math.PI - 0.38, false);
  ctx.closePath(); ctx.fill(); ctx.stroke();
  /* 柄のみぞ */
  ctx.strokeStyle = 'rgba(78,90,102,.5)'; ctx.lineWidth = 1.2;
  ctx.beginPath(); ctx.moveTo(34, 0); ctx.lineTo(len - 16, 0); ctx.stroke();
  ctx.restore();
  /* ナット（六角） */
  ctx.save();
  ctx.fillStyle = '#9aa5b0'; ctx.strokeStyle = '#3a444e'; ctx.lineWidth = 1.5;
  ctx.beginPath();
  for (var k = 0; k < 6; k++) {
    var a = ang + k * Math.PI / 3;
    var px = O.x + 12 * Math.cos(a), py = O.y + 12 * Math.sin(a);
    k ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
  }
  ctx.closePath(); ctx.fill(); ctx.stroke();
  ctx.restore();
}

/* ＜図＞ 力のモーメントの 2 通りの求め方（教科書と同じく、スパナに力を加える図）
   ・左 (1)、右 (2) それぞれに θ（F の向き）をもつ。F の先をドラッグすると向きだけ変わる
   ・▶ スタート … F がスパナとボルトを 0.5 秒まわす（まわる角は F sinθ に比例）→ 2 秒後にいきなりもとにもどる */
var MW = { W: 640, H: 330, th: [56 * DEG, 56 * DEG], rot: [0, 0], t: [-1, -1], hot: [false, false], hit: [null, null], raf: 0 };
function mwGeom(i) {
  var x0 = i * MW.W / 2, O = { x: x0 + 58, y: 232 }, L = 190;
  var ang = -14 * DEG - MW.rot[i];                           /* 柄の向き（少し右上がり）。まわると反時計まわりに */
  var uOP = { x: Math.cos(ang), y: Math.sin(ang) };
  var Pp = { x: O.x + uOP.x * L, y: O.y + uOP.y * L };
  var th = MW.th[i];
  var fu = { x: Math.cos(ang - th), y: Math.sin(ang - th) };   /* 力の向き（延長から反時計まわりに θ） */
  return { x0: x0, O: O, L: L, ang: ang, uOP: uOP, Pp: Pp, th: th, fu: fu, FL: 84 };
}
function drawMomentWays(cv) {
  var W = MW.W, H = MW.H, ctx = prep(cv, W, H);
  var i;
  NO_SHIFT = true;
  for (i = 0; i < 2; i++) {
    var g = mwGeom(i), x0 = g.x0, O = g.O, L = g.L, ang = g.ang, uOP = g.uOP, Pp = g.Pp, th = g.th, fu = g.fu, FL = g.FL;
    ctx.save(); ctx.beginPath(); ctx.rect(x0 + 2, 0, W / 2 - 4, H); ctx.clip();   /* となりの図にはみ出さない */
    spanner(ctx, O, ang, L + 22);
    axisMark(ctx, O.x, O.y, null);
    label(ctx, 'O', O.x - 38, O.y + 2, { size: 15, bold: true });
    /* OP の延長（点線） */
    dotLine(ctx, Pp.x, Pp.y, Pp.x + uOP.x * 70, Pp.y + uOP.y * 70, '#6b7885', 1.2, [4, 4]);
    /* L（O から P まで）を、スパナの上に ↔ で */
    var sL = th > 90 * DEG ? -1 : 1;                       /* θ が 90° をこえると、うで・F が上に来るので L は下に */
    var nu = { x: uOP.y * sL, y: -uOP.x * sL }, off = 32;
    var D0 = { x: O.x + nu.x * off, y: O.y + nu.y * off }, D1 = { x: Pp.x + nu.x * off, y: Pp.y + nu.y * off };
    ctx.save(); ctx.strokeStyle = 'rgba(27,31,36,.5)'; ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
    ctx.beginPath(); ctx.moveTo(O.x + nu.x * 14, O.y + nu.y * 14); ctx.lineTo(D0.x + nu.x * 6, D0.y + nu.y * 6);
    ctx.moveTo(Pp.x + nu.x * 6, Pp.y + nu.y * 6); ctx.lineTo(D1.x + nu.x * 6, D1.y + nu.y * 6); ctx.stroke(); ctx.restore();
    var Dm = { x: (D0.x + D1.x) / 2, y: (D0.y + D1.y) / 2 };
    arrow(ctx, Dm.x, Dm.y, D0.x, D0.y, 'dim', 1.1); arrow(ctx, Dm.x, Dm.y, D1.x, D1.y, 'dim', 1.1);
    label(ctx, 'L', Dm.x + nu.x * 14, Dm.y + nu.y * 14, { size: 16, bold: true, color: '#1b1f24' });
    /* 角 θ（OP の延長 → 力） */
    angArc(ctx, Pp.x, Pp.y, 30, ang - th, ang, '', 0, 0);
    label(ctx, 'θ', Pp.x + 42 * Math.cos(ang - th / 2), Pp.y + 42 * Math.sin(ang - th / 2), { size: 15, bold: true, color: '#3d4c5a' });
    var T = { x: Pp.x + fu.x * FL, y: Pp.y + fu.y * FL };
    if (MW.t[i] < 0) snapGlow(ctx, T.x, T.y, 15, COL.force, MW.hot[i] ? 1 : 0.35);   /* F の先はつかめる */
    if (i === 0) {
      /* 作用線（破線）と、うで（緑） */
      ctx.save(); ctx.strokeStyle = fade(COL.force, .6); ctx.lineWidth = 1.3; ctx.setLineDash([6, 4]);
      ctx.beginPath(); ctx.moveTo(Pp.x - fu.x * 230, Pp.y - fu.y * 230); ctx.lineTo(Pp.x + fu.x * 120, Pp.y + fu.y * 120); ctx.stroke();
      ctx.restore();
      var t = (Pp.x - O.x) * fu.x + (Pp.y - O.y) * fu.y;
      var Fo = { x: Pp.x - fu.x * t, y: Pp.y - fu.y * t };            /* O から作用線に下ろした垂線の足 */
      var armLen = Math.hypot(Fo.x - O.x, Fo.y - O.y);
      if (armLen > 2) {
        ctx.save(); ctx.strokeStyle = '#1c8f4a'; ctx.lineWidth = 2.6;
        ctx.beginPath(); ctx.moveTo(O.x, O.y); ctx.lineTo(Fo.x, Fo.y); ctx.stroke(); ctx.restore();
        /* 直角の印 */
        var nn = { x: (O.x - Fo.x), y: (O.y - Fo.y) }, nl = armLen || 1; nn.x /= nl; nn.y /= nl;
        var sg = (t > 1) ? 1 : -1;                                   /* 第 62 回：垂直（t ≒ 0）のときは印の向きを固定（回るアニメ中に左右に入れかわらない） */
        ctx.save(); ctx.strokeStyle = '#1c8f4a'; ctx.lineWidth = 1.2;
        ctx.beginPath(); ctx.moveTo(Fo.x + nn.x * 9, Fo.y + nn.y * 9); ctx.lineTo(Fo.x + nn.x * 9 + sg * fu.x * 9, Fo.y + nn.y * 9 + sg * fu.y * 9);
        ctx.lineTo(Fo.x + sg * fu.x * 9, Fo.y + sg * fu.y * 9); ctx.stroke(); ctx.restore();
        var ad = { x: Fo.x - O.x, y: Fo.y - O.y }, adl = armLen;
        var pn = { x: -ad.y / adl, y: ad.x / adl };
        if (pn.x * (Pp.x - O.x) + pn.y * (Pp.y - O.y) > 0) { pn.x = -pn.x; pn.y = -pn.y; }   /* スパナと反対がわに書く */
        label(ctx, 'うで l = L sinθ', (O.x + Fo.x) / 2 + pn.x * 24, (O.y + Fo.y) / 2 + pn.y * 24, { size: 14, bold: true, color: '#1c8f4a' });
      }
      arrow(ctx, Pp.x, Pp.y, T.x, T.y, 'force', 1.1, COL.force);
      label(ctx, 'F', Pp.x + fu.x * (FL + 26), Pp.y + fu.y * (FL + 26), { size: 16, bold: true, color: COL.force });
      label(ctx, 'P', Pp.x + 4, Pp.y + 20, { size: 15, bold: true });
      label(ctx, '(1)　F × うでの長さ', x0 + W / 4 + 30, 20, { size: 15, bold: true, color: '#1663b5' });
      label(ctx, 'M = F × L sinθ', x0 + W / 4, H - 16, { size: 16, bold: true, color: '#9b2418' });
    } else {
      /* (2) 作用線は描かない。OP に垂直な成分と平行な成分に分ける */
      var n2 = { x: uOP.y, y: -uOP.x };                           /* OP に垂直（上がわ） */
      var fsin = (fu.x * n2.x + fu.y * n2.y) * FL, fcos = (fu.x * uOP.x + fu.y * uOP.y) * FL;
      ctx.save(); ctx.strokeStyle = 'rgba(209,53,43,.45)'; ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
      ctx.beginPath(); ctx.moveTo(T.x, T.y); ctx.lineTo(Pp.x + n2.x * fsin, Pp.y + n2.y * fsin);
      ctx.moveTo(T.x, T.y); ctx.lineTo(Pp.x + uOP.x * fcos, Pp.y + uOP.y * fcos); ctx.stroke(); ctx.restore();
      arrow(ctx, Pp.x, Pp.y, T.x, T.y, 'force', 1.1, COL.force);
      label(ctx, 'F', T.x + fu.x * 26, T.y + fu.y * 26, { size: 16, bold: true, color: COL.force });
      if (Math.abs(fsin) > 6) {
        arrow(ctx, Pp.x, Pp.y, Pp.x + n2.x * fsin, Pp.y + n2.y * fsin, 'comp', 1.05, COL.force);
        label(ctx, 'F sinθ', Pp.x + n2.x * fsin - 10, Pp.y + n2.y * fsin - 12, { size: 14, bold: true, color: COL.force, align: 'right' });
      }
      if (Math.abs(fcos) > 6) {
        arrow(ctx, Pp.x, Pp.y, Pp.x + uOP.x * fcos, Pp.y + uOP.y * fcos, 'comp', 1.05, '#c0776f');
        label(ctx, 'F cosθ', Pp.x + uOP.x * fcos + (fcos >= 0 ? 6 : -6), Pp.y + uOP.y * fcos + (fcos >= 0 ? 20 : -14), { size: 14, color: '#b0564b', align: fcos >= 0 ? 'left' : 'right' });
      }
      label(ctx, 'P', Pp.x - 4, Pp.y + 22, { size: 15, bold: true });
      label(ctx, '(2)　F の OP に垂直な成分 × L', x0 + W / 4 + 30, 20, { size: 15, bold: true, color: '#1663b5' });
      label(ctx, 'M = F sinθ × L', x0 + W / 4, H - 16, { size: 16, bold: true, color: '#9b2418' });
    }
    ctx.restore();
  }
  NO_SHIFT = false;
  ctx.save(); ctx.strokeStyle = '#dde3e8'; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(W / 2, 12); ctx.lineTo(W / 2, H - 12); ctx.stroke(); ctx.restore();
}
/* スタートのアニメ（0.5 秒まわす → 2 秒後にもとにもどる） */
function mwStart(i) {
  if (MW.t[i] >= 0) return;
  MW.t[i] = 0; MW.rot[i] = 0;
  MW.run = true;            /* ★第 55 回：自分の requestAnimationFrame は始めない。共通の輪（tick）が mwStep を呼ぶ */
}
function mwStep(dt) {
  var any = false;
  for (var k = 0; k < 2; k++) {
    if (MW.t[k] < 0) continue;
    MW.t[k] += dt;
    var p = clamp(MW.t[k] / 0.5, 0, 1), e = p * (2 - p);
    MW.rot[k] = 0.36 * Math.sin(MW.th[k]) * e;            /* まわる角は F sinθ（＝モーメント）に比例 */
    if (MW.t[k] >= 2.5) { MW.t[k] = -1; MW.rot[k] = 0; } else any = true;
  }
  var cv = document.getElementById('m1moment');
  if (cv && cv.clientWidth > 0) drawMomentWays(cv);
  MW.run = any;
}
function wireMomentWays() {
  var cv = document.getElementById('m1moment'); if (!cv) return;
  Array.prototype.forEach.call(document.querySelectorAll('[data-mwplay]'), function (b) {
    b.addEventListener('click', function () { mwStart(+b.getAttribute('data-mwplay')); });
  });
  var grab = -1;
  function loc(ev) { var r = cv.getBoundingClientRect(); return { x: (ev.clientX - r.left) / r.width * MW.W, y: (ev.clientY - r.top) / r.height * MW.H }; }
  function hit(p) {
    var i = p.x < MW.W / 2 ? 0 : 1; if (MW.t[i] >= 0) return -1;
    var g = mwGeom(i), T = { x: g.Pp.x + g.fu.x * g.FL, y: g.Pp.y + g.fu.y * g.FL };
    if (Math.hypot(p.x - T.x, p.y - T.y) < 24) return i;
    var vx = T.x - g.Pp.x, vy = T.y - g.Pp.y, tt = ((p.x - g.Pp.x) * vx + (p.y - g.Pp.y) * vy) / (vx * vx + vy * vy);
    if (tt > 0.35 && tt < 1.1 && Math.abs((p.x - g.Pp.x) * vy - (p.y - g.Pp.y) * vx) / Math.hypot(vx, vy) < 12) return i;
    return -1;
  }
  function redraw() { if (cv.clientWidth > 0) drawMomentWays(cv); }
  cv.addEventListener('pointerdown', function (ev) {
    var i = hit(loc(ev)); if (i < 0) return;
    grab = i; MW.hot[i] = true; cv.style.cursor = 'grabbing';
    cv.setPointerCapture(ev.pointerId); ev.preventDefault(); redraw();
  });
  cv.addEventListener('pointermove', function (ev) {
    var p = loc(ev);
    if (grab < 0) {
      var h = hit(p), ch = false;
      [0, 1].forEach(function (k) { var on = h === k; if (MW.hot[k] !== on) { MW.hot[k] = on; ch = true; } });
      cv.style.cursor = h >= 0 ? 'grab' : 'default';
      if (ch) redraw();
      return;
    }
    var g = mwGeom(grab), a = Math.atan2(p.y - g.Pp.y, p.x - g.Pp.x);
    var th = Math.atan2(Math.sin(g.ang - a), Math.cos(g.ang - a));    /* 向きだけ（大きさは同じ） */
    MW.th[grab] = clamp(th, 0, Math.PI);
    redraw(); ev.preventDefault();
  });
  function end() { if (grab >= 0) { MW.hot[grab] = false; grab = -1; cv.style.cursor = 'default'; redraw(); } }
  cv.addEventListener('pointerup', end);
  cv.addEventListener('pointercancel', end);
  cv.addEventListener('pointerleave', function () { if (grab < 0 && (MW.hot[0] || MW.hot[1])) { MW.hot = [false, false]; redraw(); } });
}

/* ============ m1s2　剛体への力のはたらき ============ */
var M2 = { BW: 0.26, BH: 0.42, DR: 0.30, FN: 10 };
var DISC_COL = [
  { f: '#d1352b', arm: '#1c8f4a', armName: '緑' },      /* 赤い力 … うでは緑 */
  { f: '#1f63c9', arm: '#7b3fd4', armName: 'むらさき' },  /* 青い力 … うではむらさき */
  { f: '#e07b18', arm: '#0f8a8a', armName: '青緑' }      /* オレンジの力 … うでは青緑（④） */
];

/* --- ① 作用線の違い（床の上の箱を、中心よりやや上で押す） --- */
function drawSameLine(ctx, s, W, H) {
  var S = Math.min((W - 320) / M2.BW, (H - 190) / M2.BH);
  var w = M2.BW * S, hh = M2.BH * S;
  var cx = W / 2 + 40, gy = H - 80;                  /* 床の高さ */
  var ang = s._m1ang || 0, sx = s._m1sx || 0;
  var run = s.anim && s.anim.kind === 'push' ? s.anim.which : null;   /* アニメ中の力（ほかの力は消す） */
  ground(ctx, 20, W - 20, gy);
  /* 箱（右下の角のまわりに傾く。滑りは sx） */
  var brx = cx + w / 2 + sx, bry = gy;
  ctx.save();
  ctx.translate(brx, bry); ctx.rotate(ang);
  ctx.fillStyle = BOXCOL.fill; ctx.strokeStyle = BOXCOL.line; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.rect(-w, -hh, w, hh); ctx.fill(); ctx.stroke();
  ctx.restore();
  function bp(dx, dy) {                               /* 箱の右下を原点に（dx は左が＋、dy は上が＋） */
    var X = -dx, Y = -dy;
    return { x: brx + X * Math.cos(ang) - Y * Math.sin(ang), y: bry + X * Math.sin(ang) + Y * Math.cos(ang) };
  }
  var ap = bp(w, hh * 0.72);                          /* 作用点：左の面の、中心よりやや上 */
  var rp = bp(0, hh * 0.72);                          /* 右の面の同じ高さ（イ の糸をつける所） */
  var wu = { x: Math.cos(-40 * DEG), y: Math.sin(-40 * DEG) };
  if (run !== 'ウ') {
    ctx.save(); ctx.strokeStyle = '#e07b18'; ctx.lineWidth = 1.4; ctx.setLineDash([7, 5]);
    ctx.beginPath(); ctx.moveTo(ap.x - 200, ap.y); ctx.lineTo(ap.x + w + 210, ap.y); ctx.stroke();
    ctx.restore();
    if (!run) label(ctx, '同一作用線', ap.x + w + 214, ap.y - 14, { size: 14, bold: true, color: '#a85c0c', align: 'right' });
  }
  NO_SHIFT = true;
  if (!run) {                                          /* 止まっているとき：3 つの力をならべて見せる */
    arrow(ctx, ap.x - 96, ap.y, ap.x - 6, ap.y, 'force', 1.1, COL.force);
    label(ctx, 'ア', ap.x - 106, ap.y - 18, { size: 17, bold: true, color: COL.force, align: 'right' });
    arrow(ctx, rp.x + 16, ap.y, rp.x + 106, ap.y, 'force', 1.1, '#8a5a2b');
    label(ctx, 'イ', rp.x + 116, ap.y - 18, { size: 17, bold: true, color: '#8a5a2b', align: 'left' });
    arrow(ctx, ap.x, ap.y, ap.x + wu.x * 96, ap.y + wu.y * 96, 'force', 1.1, '#1c8f4a');
    label(ctx, 'ウ', ap.x + wu.x * 108, ap.y + wu.y * 108 - 6, { size: 17, bold: true, color: '#1c8f4a' });
  } else if (run === 'ア') {                           /* 指で左から押す（1-1 と同じ指） */
    pointHand(ctx, ap.x - 1, ap.y, Math.PI / 2, 0.62);
    arrow(ctx, ap.x, ap.y, ap.x + 84, ap.y, 'force', 1.1, COL.force);
    label(ctx, 'ア', ap.x + 92, ap.y - 16, { size: 17, bold: true, color: COL.force, align: 'left' });
  } else if (run === 'イ') {                           /* 手で糸を引く */
    var hx = rp.x + 120;
    string(ctx, rp.x, rp.y, hx, rp.y);
    hand(ctx, hx + 6, rp.y, 0);
    arrow(ctx, rp.x, rp.y, rp.x + 84, rp.y, 'force', 1.1, '#8a5a2b');
    label(ctx, 'イ', rp.x + 60, rp.y - 18, { size: 17, bold: true, color: '#8a5a2b' });
  } else if (run === 'ウ') {                           /* 指で斜め下から押す */
    pointHand(ctx, ap.x - wu.x, ap.y - wu.y, Math.PI / 2 - 40 * DEG, 0.62);
    arrow(ctx, ap.x, ap.y, ap.x + wu.x * 90, ap.y + wu.y * 90, 'force', 1.1, '#1c8f4a');
    label(ctx, 'ウ', ap.x + wu.x * 102, ap.y + wu.y * 102 - 6, { size: 17, bold: true, color: '#1c8f4a' });
  }
  NO_SHIFT = false;
  actPoint(ctx, ap.x, ap.y, '#1b1f24');
  if (!run) label(ctx, '作用点', ap.x + 10, ap.y + 22, { size: 13.5, color: COL.sub, align: 'left', avoid: true });
  /* 左下：まとめ／右下：いまの動きの結果 */
  label(ctx, '・ア と イ … 同じはたらき（同一作用線）', 22, H - 42, { size: 13, bold: true, color: '#3d4c5a', align: 'left' });
  label(ctx, '・ア と ウ … ちがうはたらき（同一作用点）', 22, H - 20, { size: 13, bold: true, color: '#3d4c5a', align: 'left' });
  if (s._m1msg) label(ctx, s._m1msg, W - 18, H - 31, { size: 13, bold: true, color: '#9b2418', align: 'right' });
}

/* --- ②③ 円盤（3 次元）＋ ドラッグできる力 --- */
function discGeom(stt, W, H) {
  var az = stt.az * DEG, el = stt.el * DEG, se = Math.sin(el), ce = Math.cos(el);
  /* ★縮尺は視点によらず一定★（斜め上から 34° のときの高さで決める） */
  var e34 = 34 * DEG, vH = 2 * M2.DR * Math.sin(e34) + 0.46 * Math.cos(e34);
  var S = Math.min((W - 60) / (2 * M2.DR + 0.5), (340 - 56) / vH);
  var cx = W / 2, cy = H / 2 - 0.01 * ce * S + 34;          /* 上に説明文とボタンのぶんをあける */
  return { pj: mkProj(az, el, S, cx, cy), S: S, cx: cx, cy: cy, ce: ce };
}
/* 円盤の上の力 i の、いまの（円盤といっしょに回った）位置と向き */
function discForce(stt, i) {
  var f = stt.f[i], rot = stt.rot || 0;
  var ca = Math.cos(rot), sa = Math.sin(rot);
  var px = f.x * ca - f.y * sa, py = f.x * sa + f.y * ca, aa = f.a + rot;
  var ux = Math.cos(aa), uy = Math.sin(aa), mag = f.mag || M2.FN;
  return { px: px, py: py, ux: ux, uy: uy, a: aa, arm: px * uy - py * ux, mag: mag, len: f.len * mag / M2.FN };   /* 矢印の長さは力の大きさに比例 */
}
function discScene(ctx, stt, W, H, n) {
  var g = discGeom(stt, W, H), pj = g.pj, S = g.S, ce = g.ce;
  var PJ = function (q) { return pj.p(q); };
  var TH = 0.035;
  var i, pts = [];
  for (i = 0; i <= 72; i++) {
    var a = i / 72 * Math.PI * 2;
    pts.push(PJ([M2.DR * Math.cos(a), M2.DR * Math.sin(a), 0]));
  }
  var low = pts.map(function (p) { return { x: p.x, y: p.y + TH * ce * S }; });
  /* 回転軸（下がわ：円盤より先に描いて「突き抜けている」ように） */
  var aDn = PJ([0, 0, -0.36]), aUp = PJ([0, 0, 0.286]), Ocp = PJ([0, 0, 0]);   /* 軸は上に 1.3 倍、下に 1.5 倍 */
  ctx.save();
  ctx.strokeStyle = '#8b949e'; ctx.lineWidth = 6; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(Ocp.x, Ocp.y); ctx.lineTo(aDn.x, aDn.y); ctx.stroke();
  ctx.restore();
  /* 円盤（厚みつき・分割線なし） */
  ctx.save();
  ctx.beginPath();
  pts.forEach(function (p, k) { k ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y); });
  for (var k2 = low.length - 1; k2 >= 0; k2--) ctx.lineTo(low[k2].x, low[k2].y);
  ctx.closePath();
  ctx.fillStyle = '#d8cbb4'; ctx.fill();
  ctx.strokeStyle = '#8a7a55'; ctx.lineWidth = 1.2; ctx.stroke();
  ctx.beginPath();
  pts.forEach(function (p, k) { k ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y); });
  ctx.closePath();
  ctx.fillStyle = '#efe4d4'; ctx.fill();
  ctx.strokeStyle = '#8a7a55'; ctx.lineWidth = 1.6; ctx.stroke();
  /* 分割線（円板といっしょに回るので、回っているかどうかが分かる） */
  ctx.clip();
  ctx.strokeStyle = 'rgba(138,122,85,.45)'; ctx.lineWidth = 1;
  for (i = 0; i < 8; i++) {
    var a2 = (stt.rot || 0) + i / 8 * Math.PI * 2;
    var q0 = PJ([0, 0, 0]), q1 = PJ([M2.DR * Math.cos(a2), M2.DR * Math.sin(a2), 0]);
    ctx.beginPath(); ctx.moveTo(q0.x, q0.y); ctx.lineTo(q1.x, q1.y); ctx.stroke();
  }
  ctx.restore();
  /* 回転軸（上がわ） */
  ctx.save();
  ctx.strokeStyle = '#6b7885'; ctx.lineWidth = 6; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(Ocp.x, Ocp.y); ctx.lineTo(aUp.x, aUp.y); ctx.stroke();
  ctx.restore();
  axisMark(ctx, Ocp.x, Ocp.y, null);
  /* 力 */
  var res = { pj: pj, seg: [], M: 0, cx: g.cx, cy: g.cy, rot: stt.rot || 0, arms: [], lab: [] };
  n = n || 1;
  /* 矢印の縮尺：④で F3 が 25 N をこえたときだけ（F3を自動設定で決めて、回っても変えない） */
  var ks = stt.ks || 1;
  res.ks = ks;
  NO_SHIFT = true;
  /* ===== 文字のかさなりよけ =====
     boxes … もう書いた文字・よけたい場所（説明文・ボタン・下の文字）。候補の位置を順にためして、かさならない所に書く */
  var boxes = (stt._zones || []).slice();
  ctx.save(); ctx.font = 'bold 14px ' + FONT;
  var bandR = 14 + ctx.measureText('うでの長さ').width + 10;
  for (i = 0; i < n; i++) bandR += ctx.measureText('l₁ = 00.0 cm').width + 14;
  ctx.restore();
  if (!stt.noText) boxes.push({ x0: 0, y0: H - 30, x1: bandR, y1: H });
  if (ks < 0.999 && !stt.noText) boxes.push({ x0: W - 290, y0: H - 28, x1: W, y1: H });
  function tw(t, sz) { ctx.save(); ctx.font = 'bold ' + sz + 'px ' + FONT; var w = ctx.measureText(t.replace(/_/g, '')).width; ctx.restore(); return w; }
  function ov(b) {
    var sum = 0;
    boxes.forEach(function (o) {
      var ox = Math.min(b.x1, o.x1) - Math.max(b.x0, o.x0), oy = Math.min(b.y1, o.y1) - Math.max(b.y0, o.y0);
      if (ox > 0 && oy > 0) sum += ox * oy;
    });
    if (b.x0 < 2) sum += (2 - b.x0) * 20; if (b.x1 > W - 2) sum += (b.x1 - W + 2) * 20;
    if (b.y0 < 2) sum += (2 - b.y0) * 20; if (b.y1 > H - 2) sum += (b.y1 - H + 2) * 20;
    return sum;
  }
  function place(t, sz, col, cands, optional) {
    var w = tw(t, sz) + 6, h = sz + 6, best = null;
    for (var c = 0; c < cands.length; c++) {
      var b = { x0: cands[c].x - w / 2, y0: cands[c].y - h / 2, x1: cands[c].x + w / 2, y1: cands[c].y + h / 2 };
      var sc = ov(b) + c * 0.01;
      if (!best || sc < best.sc) best = { sc: sc, b: b, p: cands[c] };
      if (sc < 1) break;
    }
    if (optional && best.sc >= 1) return;                     /* 空いている所がなければ書かない（「うで」） */
    boxes.push(best.b); best.b.t = t; res.lab.push(best.b);
    label(ctx, t, best.p.x, best.p.y, { size: sz, bold: true, color: col });
  }
  /* うでの足（回転軸から作用線に下ろした垂線の足）。重なっているうでは、色を交互の点線にして両方見えるように */
  var feet = [], armLab = [];
  for (i = 0; i < n; i++) {
    var qa = discForce(stt, i), ta = -(qa.px * qa.ux + qa.py * qa.uy);
    feet.push({ x: qa.px + qa.ux * ta, y: qa.py + qa.uy * ta, arm: qa.arm });
  }
  for (i = 0; i < n; i++) {
    var c = DISC_COL[i], q = discForce(stt, i);
    var Pp = PJ([q.px, q.py, 0]), Tp = PJ([q.px + q.ux * q.len * ks, q.py + q.uy * q.len * ks, 0]);
    var L0 = PJ([q.px - q.ux * 0.95, q.py - q.uy * 0.95, 0]), L1 = PJ([q.px + q.ux * 0.95, q.py + q.uy * 0.95, 0]);
    dotLine(ctx, L0.x, L0.y, L1.x, L1.y, fade(c.f, .55), 1.3, [6, 4]);        /* 作用線 */
    res.M += q.arm * q.mag;
    res.arms.push(Math.abs(q.arm));
    if (Math.abs(q.arm) > 1e-4) {
      var Fp = PJ([feet[i].x, feet[i].y, 0]);
      var grp = [], k;
      for (k = 0; k < n; k++) {
        if (Math.abs(feet[k].arm) < 1e-4) continue;
        var da = Math.atan2(feet[k].y, feet[k].x) - Math.atan2(feet[i].y, feet[i].x);
        if (Math.abs(Math.atan2(Math.sin(da), Math.cos(da))) < 4 * DEG) grp.push(k);
      }
      var gi = grp.indexOf(i), gk = grp.length;
      ctx.save();
      ctx.strokeStyle = c.arm; ctx.lineWidth = 2.6;
      if (gk > 1) { ctx.setLineDash([6, 6 * (gk - 1)]); ctx.lineDashOffset = -6 * gi; }   /* 色が交互にならぶ */
      else ctx.setLineDash([3, 4]);
      ctx.beginPath(); ctx.moveTo(Ocp.x, Ocp.y); ctx.lineTo(Fp.x, Fp.y); ctx.stroke();
      ctx.restore();
      var ax = Fp.x - Ocp.x, ay = Fp.y - Ocp.y, al = Math.hypot(ax, ay) || 1;
      if (al > 18) armLab.push({ i: i, a: Ocp, b: Fp, nx: -ay / al, ny: ax / al, col: c.arm });
    }
    res.seg.push({ x1: Pp.x, y1: Pp.y, x2: Tp.x, y2: Tp.y, lx1: L0.x, ly1: L0.y, lx2: L1.x, ly2: L1.y, i: i });
  }
  /* 矢印（先に全部描く） */
  for (i = 0; i < n; i++) {
    var c2 = DISC_COL[i], sg = res.seg[i];
    if (stt.hot === i) snapGlow(ctx, sg.x1, sg.y1, 17, c2.f, stt.hotMode === 'rot' ? 0.4 : 1);   /* つかもうとしている力 */
    arrow(ctx, sg.x1, sg.y1, sg.x2, sg.y2, 'force', 1.1, c2.f);
    ctx.save(); ctx.beginPath(); ctx.arc(sg.x1, sg.y1, 4.6, 0, Math.PI * 2);
    ctx.fillStyle = '#fff'; ctx.fill(); ctx.lineWidth = 2.4; ctx.strokeStyle = c2.f; ctx.stroke(); ctx.restore();
  }
  /* 力の名前：矢印の先 → 根もと → 先の横 → まん中の横 の順にためす */
  for (i = 0; i < n; i++) {
    var sg2 = res.seg[i], ul = Math.hypot(sg2.x2 - sg2.x1, sg2.y2 - sg2.y1) || 1;
    var qm = discForce(stt, i).mag;
    var ftxt = (n > 1 ? ('F' + (i + 1)) : 'F') + ' = ' + (Math.abs(qm - Math.round(qm)) < 0.05 ? fmt(qm, 0) : fmt(qm, 1)) + ' N';
    var ux = (sg2.x2 - sg2.x1) / ul, uy = (sg2.y2 - sg2.y1) / ul, nx = -uy, ny = ux;
    var w0 = tw(ftxt, 14), off = 8 + Math.abs(ux) * w0 / 2 + Math.abs(uy) * 9, dn = 12 + Math.abs(nx) * w0 / 2 + Math.abs(ny) * 9;
    var mx = (sg2.x1 + sg2.x2) / 2, my = (sg2.y1 + sg2.y2) / 2;
    place(ftxt, 14, DISC_COL[i].f, [
      { x: sg2.x2 + ux * off, y: sg2.y2 + uy * off }, { x: sg2.x1 - ux * (off + 6), y: sg2.y1 - uy * (off + 6) },
      { x: sg2.x2 + nx * dn, y: sg2.y2 + ny * dn }, { x: sg2.x2 - nx * dn, y: sg2.y2 - ny * dn },
      { x: mx + nx * dn, y: my + ny * dn }, { x: mx - nx * dn, y: my - ny * dn },
      { x: sg2.x2 + ux * (off + 22), y: sg2.y2 + uy * (off + 22) }, { x: sg2.x1 - ux * (off + 28), y: sg2.y1 - uy * (off + 28) },
      { x: sg2.x2 + nx * (dn + 20), y: sg2.y2 + ny * (dn + 20) }, { x: sg2.x2 - nx * (dn + 20), y: sg2.y2 - ny * (dn + 20) },
      { x: mx + nx * (dn + 20), y: my + ny * (dn + 20) }, { x: mx - nx * (dn + 20), y: my - ny * (dn + 20) }]);
  }
  /* 「回転軸」 */
  if (stt.el > 80) place('回転軸', 13, COL.sub, [{ x: Ocp.x - 34, y: Ocp.y + 16 }, { x: Ocp.x + 34, y: Ocp.y + 16 }, { x: Ocp.x - 34, y: Ocp.y - 16 }, { x: Ocp.x + 34, y: Ocp.y - 16 },
    { x: Ocp.x, y: Ocp.y + 26 }, { x: Ocp.x, y: Ocp.y - 26 }, { x: Ocp.x - 56, y: Ocp.y }, { x: Ocp.x + 56, y: Ocp.y }]);
  else place('回転軸', 13, COL.sub, [{ x: aUp.x, y: aUp.y - 14 }, { x: aUp.x - 34, y: aUp.y }, { x: aUp.x + 34, y: aUp.y }, { x: aDn.x - 34, y: aDn.y - 8 }]);
  /* 「うで」 */
  armLab.forEach(function (L) {
    var cands = [];
    [0.5, 0.35, 0.65, 0.8, 1.0, 1.25].forEach(function (t) {
      var px = L.a.x + (L.b.x - L.a.x) * t, py = L.a.y + (L.b.y - L.a.y) * t;
      [16, -16, 28, -28, 40, -40].forEach(function (d) { cands.push({ x: px + L.nx * d, y: py + L.ny * d }); });
    });
    place('うで', 13, L.col, cands, true);
  });
  if (ks < 0.999 && !stt.noText) label(ctx, '（入りきらないので、矢印は縮小して表示）', W - 12, H - 16, { size: 12, color: COL.sub, align: 'right' });
  /* 左下：うでの長さ（小数第 1 位、cm）。力が 2 つ以上なら 1 行にならべる */
  if (!stt.noText) {
  ctx.save();
  ctx.font = 'bold 14px ' + FONT; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
  var xx = 14, yy = H - 16;
  ctx.fillStyle = '#3d4c5a'; ctx.fillText('うでの長さ', xx, yy); xx += ctx.measureText('うでの長さ').width + 10;
  for (i = 0; i < n; i++) {
    var ts = (n > 1 ? 'l' + '₁₂₃'.charAt(i) : 'l') + ' = ' + fmt(res.arms[i] * 100, 1) + ' cm';
    ctx.fillStyle = DISC_COL[i].arm; ctx.fillText(ts, xx, yy); xx += ctx.measureText(ts).width + 14;
  }
  ctx.restore();
  }
  NO_SHIFT = false;
  return res;
}

function discCard(no, title, body) {
  return '<div class="bcard" id="m1card' + no + '"><h3 class="pillh">' + numPill(title) + '</h3>' +   /* 第 58 回：番号は墨のピル */
    '<div class="discrow"><div class="discmain"><div class="btnrow small discplay">' +
    '<button class="dplay pulse" data-dplay="' + no + '">▶ スタート</button>' +
    '<button class="sub" data-dreset="' + no + '">↺ リセット</button></div>' +
    '<div class="discwrap"><canvas id="m1disc' + no + '"></canvas>' +
    '<div class="discov"><div class="guide static">' + guideHtml('m1s2.d' + no) + '</div>' +
    '<div class="discview">' +
    '<button class="warm glow" data-dview="' + no + ':top">上から</button>' +
    '<button class="warm" data-dview="' + no + ':obl">斜め上から</button></div></div>' +
    '<div class="discovr"><div class="guide static gtr">' + guideHtml('m1s2.d' + no + 'r') + '</div>' +
    (no === 4 ? '<div class="discauto"><button class="warm" data-dauto="f3">F3を自動設定</button>' +
      '<button class="warm" data-dauto="concur">3 力の作用線を交わらせる</button>' +
      '<button class="warm" data-dauto="s22">②-2 糸でつるした棒と同じ状況</button>' +
      '<div class="autonote" id="m1auto4"></div></div>' : '') +
    '</div></div>' +
    '<div class="discstat" id="m1dstat' + no + '"></div>' +
    '<p class="mini dsign">モーメントは、上から見て<b>反時計回りを正</b>とする。</p></div>' +
    '<div class="discans"><button class="ansbtn" data-dans="' + no + '">' + ansLabel(no, false) + '</button>' +
    '<div class="discansbody" id="m1ansb' + no + '" hidden>' +
    (no === 4 ? '<p class="mini anslink">1 の例は <a class="cmplink" href="#2-2" data-goto="m2s2:top">②-2　糸でつるした棒</a> なので、見てみてください</p>' : '') +
    '<canvas id="m1ans' + no + '"></canvas></div></div></div>' + body + '</div>';
}
function ansLabel(no, open) { return '回転しない置き方の例（' + DISC_ANS[no].length + ' 通り）　' + (open ? '▲' : '▼'); }
function discFresh(no) {
  return { az: -34, el: 34, rot: 0, play: false, hot: -1, hotMode: '',
    f: (no === 2) ? [{ x: 0.0, y: -0.17, a: 0, len: 0.26 }]
      : (no === 3) ? [{ x: 0.0, y: -0.17, a: 0, len: 0.24 }, { x: 0.0, y: 0.17, a: Math.PI, len: 0.24 }]
      : [{ x: 0.0, y: -0.17, a: 0, len: 0.22 }, { x: 0.0, y: 0.17, a: Math.PI, len: 0.22 }, { x: 0.17, y: 0.0, a: Math.PI / 2, len: 0.22 }] };
}

DEFS['m1s2'] = {
  id: 'm1s2', tab: '①-2　剛体への力のはたらき　～作用線と回転～', noAB: true, noPlay: true, noResetAll: true,
  title: '①-2　剛体への力のはたらき　～作用線と回転～',
  sub: '剛体では、力の<b>大きさ・向き</b>が同じでも、<b>作用線</b>がちがえばはたらきがちがう。' +
    '逆に<b>作用線が同じなら、作用点を作用線上のどこに移してもはたらきは同じ</b>。',
  cw: function (v, s) { return (s && s._narrow) ? 470 : 780; },
  ch: function (v, s) { return 380; },
  stageW: 0.7,
  vars: [],
  cvTitle: '①-2-(1)　剛体では、「作用線」がちがえば力のはたらきがちがう。',
  subs: 4,                 /* ①〜④ にもアドレス（#1-2-1 〜 #1-2-4） */
  guides: [{ key: 'm1s2.one', inCv: true }],
  actionsInCv: true,
  actions: [
    { label: 'ア で押す', fn: function (s) { pushBox(s, 'ア'); }, dim: function (s) { return pushDim(s, 'ア'); } },
    { label: 'イ で引く', fn: function (s) { pushBox(s, 'イ'); }, dim: function (s) { return pushDim(s, 'イ'); } },
    { label: 'ウ で押す', fn: function (s) { pushBox(s, 'ウ'); }, dim: function (s) { return pushDim(s, 'ウ'); } }
  ],
  tickMain: function (s, dt) {
    var u = s._m1up; if (!u) return false;
    u.t += dt;
    if (u.t < 2) return false;
    s._m1ang = 0; s._m1sx = 0; s._m1msg = ''; s._m1up = null;   /* 2 秒たったら、リセットを押したように一瞬でもとにもどす */
    return true;
  },
  reset: function (s) {
    s._m1ang = 0; s._m1sx = 0; s._m1msg = ''; s._m1up = null;
    s._d2 = discFresh(2); s._d3 = discFresh(3); s._d4 = discFresh(4);
  },
  draw: function (ctx, s, W, H) {
    if (s._d2 === undefined) DEFS['m1s2'].reset(s);
    drawSameLine(ctx, s, W, H);
  },
  below: function (s) {
    return discCard(2, '①-2-(2)　力 1 つで、回転しないような力の加え方はあるか？',
      '<p>作用線の上で作用点を動かしても、はたらきは変わらない（うでの長さが変わらない）ことも確かめよう。</p>') +
      discCard(3, '①-2-(3)　力 2 つで、回転しないような力の加え方はあるか？',
        '<p>どちらの作用線も回転軸を通るようにするか、<b>逆向きの回転が打ち消しあう</b>ように置くと回転しない。</p>') +
      discCard(4, '①-2-(4)　力 3 つで、回転しないような力の加え方はあるか？',
        '<p>3 つの力の<b>モーメントの和 $F_1 l_1 + F_2 l_2 + F_3 l_3$（回す向きで ± をつける）が 0</b> になれば回らない。</p>' +
        '<p>「<b>3 力の作用線を交わらせる</b>」を押すと、力の向きだけを変えて 3 力の作用線を 1 点で交わらせる。' +
        '「<b>②-2 糸でつるした棒と同じ状況</b>」は、②-2 で θ = 30° のときの 3 力（赤＝重力 W、青＝糸の張力、オレンジ＝A にはたらく力。どれも 10 N）と同じ力の加わり方。</p>' +
        '<p>「<b>F3を自動設定</b>」を押すと、3 力の作用線が 1 点で交わっているとき（または 3 つとも平行なとき）、F3 の大きさを変えて回らないようにする（F1 と F2 が一直線上で打ち消しあうときは、F3 を回転軸を通る位置に動かす）。</p>');
  },
  drawBelow: function (s, only) {      /* only … 描き直す円盤の番号の配列（回っている円盤だけ。第 55 回） */
    if (s._d2 === undefined) DEFS['m1s2'].reset(s);
    if (!only) [2, 3, 4].forEach(function (no) {
      var ac = document.getElementById('m1ans' + no), bd = document.getElementById('m1ansb' + no);
      if (ac && bd && !bd.hidden && ac.clientWidth > 0) drawDiscAns(ac, no);
    });
    [[2, '_d2', '_r2'], [3, '_d3', '_r3d'], [4, '_d4', '_r4d']].forEach(function (q) {
      if (only && only.indexOf(q[0]) < 0) return;
      var cv = document.getElementById('m1disc' + q[0]);
      if (!cv || cv.clientWidth <= 0) return;
      var W = 620, H = 400, ctx = prep(cv, W, H);
      var stt = s[q[1]];
      /* 図に重ねた説明文・ボタンの場所（ここには文字を書かない。④の右上のボタンの下は OK） */
      var cr = cv.getBoundingClientRect(), kx = W / (cr.width || W), ky = H / (cr.height || H);
      stt._zones = [];
      Array.prototype.forEach.call(cv.parentNode.querySelectorAll('.discov .guide, .discview, .discovr .guide'), function (el) {
        var r = el.getBoundingClientRect();
        if (r.width > 0) stt._zones.push({ x0: (r.left - cr.left) * kx - 2, y0: (r.top - cr.top) * ky - 2, x1: (r.right - cr.left) * kx + 2, y1: (r.bottom - cr.top) * ky + 2 });
      });
      var res = discScene(ctx, stt, W, H, q[0] - 1);
      s[q[2]] = res;
      var zero = Math.abs(res.M) < 1e-3;
      /* 上から見て反時計回りを正（res.M は時計回りが正なので、符号を逆にして書く） */
      var Md = -res.M, cw = Md < 0;
      var mv = (cw ? '−' : '+') + fmt(Math.abs(Md), 1);             /* 小数第 1 位 */
      if (!zero && Math.abs(Md) < 0.05) mv = (cw ? '−' : '+') + '0.0…';
      var dir = cw ? '時計回り' : '反時計回り';
      var txt = zero ? (stt.play ? '回転しない！（M = 0）' : '回転しない！（M = 0）… スタートを押して確かめよう')
        : ((q[0] >= 3 ? 'モーメントの和 M = ' : 'M = ') + mv + ' N・m　' + dir + (stt.play ? 'に回っている！' : 'に回る … スタートを押して確かめよう'));
      var st_el = document.getElementById('m1dstat' + q[0]);
      if (st_el && st_el.__t !== txt) {
        st_el.__t = txt; st_el.textContent = txt;
        st_el.className = 'discstat ' + (zero ? 'ok' : 'ng');
      }
    });
  },
  /* 回転のアニメ（スタートを押したとき） */
  tickBelow: function (s, dt) {
    var moved = [];
    [['_d2', '_r2', 2], ['_d3', '_r3d', 3], ['_d4', '_r4d', 4]].forEach(function (q) {
      var stt = s[q[0]], res = s[q[1]];
      if (!stt || !stt.play || !res) return;
      var w = res.M * 0.12;                       /* 回る速さはモーメントに比例 */
      if (Math.abs(w) < 1e-4) return;
      stt.rot += w * dt; moved.push(q[2]);
    });
    if (moved.length) DEFS['m1s2'].drawBelow(s, moved);
  },
  wire: function (s, host) {
    if (s._d2 === undefined) DEFS['m1s2'].reset(s);
    function sttOf(no) { return s['_d' + no]; }
    Array.prototype.forEach.call(host.querySelectorAll('[data-dview]'), function (b) {
      b.addEventListener('click', function () {
        var q = b.getAttribute('data-dview').split(':');
        var d2 = sttOf(q[0]);
        if (q[1] === 'top') { d2.az = 0; d2.el = 90; } else { d2.az = -34; d2.el = 34; }
        Array.prototype.forEach.call(host.querySelectorAll('[data-dview^="' + q[0] + ':"]'), function (x) {
          x.classList.remove('glow'); x.classList.toggle('on', x === b);
        });
        DEFS['m1s2'].drawBelow(s);
      });
    });
    Array.prototype.forEach.call(host.querySelectorAll('[data-dplay]'), function (b) {
      b.addEventListener('click', function () {
        var d2 = sttOf(b.getAttribute('data-dplay'));
        d2.play = !d2.play;
        b.textContent = d2.play ? '❚❚ 一時停止' : '▶ スタート';
        b.classList.toggle('pulse', !d2.play);            /* 一時停止のときは光らせない */
        DEFS['m1s2'].drawBelow(s);
      });
    });
    Array.prototype.forEach.call(host.querySelectorAll('[data-dreset]'), function (b) {
      b.addEventListener('click', function () {
        var no = +b.getAttribute('data-dreset'), old = sttOf(no), fresh = discFresh(no);
        fresh.az = old.az; fresh.el = old.el;                /* 視点はそのまま */
        s['_d' + no] = fresh;
        Array.prototype.forEach.call(host.querySelectorAll('[data-dplay="' + no + '"]'), function (x) { x.textContent = '▶ スタート'; x.classList.add('pulse'); });
        DEFS['m1s2'].drawBelow(s);
      });
    });
    [[2, '_d2', '_r2'], [3, '_d3', '_r3d'], [4, '_d4', '_r4d']].forEach(function (q) { wireDiscDrag(s, q[0], q[1], q[2]); });
    Array.prototype.forEach.call(host.querySelectorAll('[data-dauto]'), function (b) {
      b.addEventListener('click', function () {
        var kd = b.getAttribute('data-dauto');
        var r = kd === 'f3' ? discAutoF3(s._d4) : (kd === 'concur' ? discConcur(s._d4) : disc22(s._d4)), el = document.getElementById('m1auto4');
        if (kd === 's22') Array.prototype.forEach.call(host.querySelectorAll('[data-dview^="4:"]'), function (x) {
          x.classList.remove('glow'); x.classList.toggle('on', x.getAttribute('data-dview') === '4:top');
        });
        if (el) { el.textContent = r.msg; el.className = 'autonote ' + (r.ok ? 'ok' : 'ng'); clearTimeout(el._tm); el._tm = setTimeout(function () { el.textContent = ''; }, 4000); }
        DEFS['m1s2'].drawBelow(s);
      });
    });
    Array.prototype.forEach.call(host.querySelectorAll('[data-dans]'), function (b) {
      b.addEventListener('click', function () {             /* 回転しない条件の解答（はじめは閉じている） */
        var no = b.getAttribute('data-dans'), bd = document.getElementById('m1ansb' + no);
        bd.hidden = !bd.hidden;
        b.textContent = ansLabel(no, !bd.hidden);
        b.classList.toggle('open', !bd.hidden);
        DEFS['m1s2'].drawBelow(s);
      });
    });
  }
};

/* 2 つの力の作用線の交点（平行なら null）。q … discForce の結果 */
function lineCross(a, b) {
  var den = a.ux * b.uy - a.uy * b.ux;
  if (Math.abs(den) < 1e-6) return null;
  var t = ((b.px - a.px) * b.uy - (b.py - a.py) * b.ux) / den;
  return { x: a.px + a.ux * t, y: a.py + a.uy * t };
}
/* ④「F3を自動設定」：3 力の作用線が 1 点で交わる（または 3 つとも平行）ときだけ、
   F3 の大きさ（と向きの正負）を変えて、モーメントの和を 0 にする */
function discAutoF3(stt) {
  var q1 = discForce(stt, 0), q2 = discForce(stt, 1), q3 = discForce(stt, 2);
  var X = lineCross(q1, q2), ok = false, moved = false;
  var M12 = q1.arm * q1.mag + q2.arm * q2.mag;
  /* F3 の作用線が回転軸を通っているとき（モーメントを打ち消せない）：F3 の向き・作用点を変えてから大きさを決める */
  if (Math.abs(q3.arm) < 1e-3 && Math.abs(M12) >= 1e-3) { discRedirectF3(stt, X, q1); moved = true; q3 = discForce(stt, 2); }
  var col12 = !X && Math.abs((q2.px - q1.px) * q1.uy - (q2.py - q1.py) * q1.ux) < 0.005;   /* F1 と F2 が同じ作用線の上 */
  if (col12 && Math.abs(M12) < 1e-3) {
    /* 2 力が一直線上で打ち消しあう → F3 を回転軸を通る位置へ平行に動かすだけでよい */
    if (Math.abs(q3.arm) < 1e-3) return { ok: true, msg: 'すでにつりあっている' };
    discStore(stt, 2, q3.px - q3.arm * q3.uy, q3.py + q3.arm * q3.ux);
    return { ok: true, msg: 'F1 と F2 が一直線上で打ち消しあうので、F3 を回転軸を通る位置に動かした' };
  }
  if (X) ok = Math.abs((X.x - q3.px) * q3.uy - (X.y - q3.py) * q3.ux) < 0.008;        /* F3 の作用線が交点から 0.8 cm 以内 */
  else if (col12) ok = true;                                                           /* 同じ作用線の上なら、どこでも交わる */
  else ok = Math.abs(q1.ux * q3.uy - q1.uy * q3.ux) < 1e-3;                            /* 3 つとも平行 */
  if (!ok) return { ok: false, msg: '3 力の作用線が 1 点で交わっていないと不可' };
  var need = -M12;
  if (Math.abs(q3.arm) < 1e-3) {
    if (Math.abs(need) < 1e-3) return { ok: true, msg: 'すでにつりあっている' };
    return { ok: false, msg: 'F3 の作用線が回転軸を通るので不可' };
  }
  var mag = need / q3.arm, f = stt.f[2];
  if (Math.abs(mag) < 0.5) return { ok: false, msg: 'F3 がほぼ 0 N になるので不可' };
  if (mag < 0) { f.a += Math.PI; mag = -mag; }                                        /* 向きを逆に（作用線は同じ） */
  f.mag = mag;
  stt.ks = mag > 25 ? discFitScale(stt) : undefined;                                  /* 25 N をこえたときだけ縮尺を変える */
  return { ok: true, msg: (moved ? 'F3 が回転軸を通っていたので向き（と作用点）を変え、' : '') + 'F3 = ' + fmt(mag, 1) + ' N にした' };
}
/* 矢印が図に入りきる縮尺（F3 が 25 N をこえたときだけ使う。回っても変わらないように、円板のどの向きでも入る大きさにする） */
function discFitScale(stt) {
  var g = discGeom(stt, 620, 400), ks = 1, i, t, a;
  for (i = 0; i < stt.f.length; i++) {
    var f = stt.f[i], R0 = Math.hypot(f.x, f.y), L = f.len * (f.mag || M2.FN) / M2.FN;
    for (t = 1; t > 0.1; t -= 0.05) {
      var okAll = true;
      for (a = 0; a < 12 && okAll; a++) {                                             /* 円板が回ったときのどの向きでも */
        var rot = a * Math.PI / 6, ca = Math.cos(rot), sa = Math.sin(rot);
        var px = f.x * ca - f.y * sa, py = f.x * sa + f.y * ca, aa = f.a + rot;
        var tp = g.pj.p([px + Math.cos(aa) * L * t, py + Math.sin(aa) * L * t, 0]);
        if (!(tp.x > 10 && tp.x < 610 && tp.y > 16 && tp.y < 378)) okAll = false;
      }
      if (okAll) break;
    }
    ks = Math.min(ks, Math.max(t, 0.1));
  }
  return ks;
}
/* 力 i の作用点（と向き）を、いまの円板の回りぐあいに合わせてしまう（画面の座標 → 円板の座標） */
function discStore(stt, i, px, py, aw) {
  var f = stt.f[i], rot = stt.rot || 0, cb = Math.cos(-rot), sb = Math.sin(-rot);
  f.x = px * cb - py * sb; f.y = px * sb + py * cb;
  if (aw !== undefined) f.a = aw - rot;
}
/* F3 の作用線が回転軸を通らないように、F3 の向き（必要なら作用点も）を変える。
   F1・F2 が交わるなら、その交点 X を通る向き（3 力が 1 点で交わる）。平行なら、F1 と同じ向き（3 つとも平行） */
function discRedirectF3(stt, X, q1) {
  for (var tries = 0; tries < 8; tries++) {
    var q3 = discForce(stt, 2), a;
    if (X) {
      var dx = X.x - q3.px, dy = X.y - q3.py;
      a = Math.hypot(dx, dy) > 1e-3 ? Math.atan2(dy, dx) : q3.a + Math.PI / 2;
    } else a = q1.a;
    var ux = Math.cos(a), uy = Math.sin(a);
    if (Math.abs(q3.px * uy - q3.py * ux) > 0.02) { discStore(stt, 2, q3.px, q3.py, a); return; }   /* うでが 2 cm 以上あれば OK */
    /* まだ回転軸を通る → 作用点を円板の中心のまわりに 50° まわして、やり直す */
    var r = Math.max(0.1, Math.hypot(q3.px, q3.py)), ph = Math.atan2(q3.py, q3.px) + 50 * DEG;
    discStore(stt, 2, r * Math.cos(ph), r * Math.sin(ph));
  }
}
/* 「3 力の作用線を交わらせる」：F1 と F2 の交点が円板の近くにあれば F3 だけ、なければ 3 つの作用点のまん中に向ける */
function discConcur(stt) {
  var q = [0, 1, 2].map(function (i) { return discForce(stt, i); });
  var X = lineCross(q[0], q[1]), idx = [2];
  if (!X || Math.hypot(X.x, X.y) > 0.42) {
    X = { x: (q[0].px + q[1].px + q[2].px) / 3, y: (q[0].py + q[1].py + q[2].py) / 3 };
    idx = [0, 1, 2];
  }
  idx.forEach(function (i) {
    var dx = X.x - q[i].px, dy = X.y - q[i].py;
    if (Math.hypot(dx, dy) < 1e-3) return;
    var a = Math.atan2(dy, dx);
    if (Math.cos(a - q[i].a) < 0) a += Math.PI;                                        /* いまの向きに近いほう */
    discStore(stt, i, q[i].px, q[i].py, a);
  });
  return { ok: true, msg: '3 力の作用線を 1 点で交わらせた（向きだけ変えた）' };
}
/* 「2-2 糸でつるした棒と同じ状況」：θ = 30° のときの 3 力（重力 W・糸の張力・A にはたらく力。どれも 10 N）*/
function disc22(stt) {
  var c = Math.cos(30 * DEG), sn = Math.sin(30 * DEG);
  stt.rot = 0; stt.az = 0; stt.el = 90; stt.ks = undefined;                                              /* 上から見る（2-2 の図と同じ形に見える） */
  stt.f = [{ x: 0, y: -0.02, a: Math.PI / 2, len: 0.15, mag: 10 },                  /* 重力 W（棒のまん中） */
    { x: 0.24, y: -0.02, a: Math.atan2(-sn, -c), len: 0.15, mag: 10 },                /* 糸の張力（B） */
    { x: -0.24, y: -0.02, a: Math.atan2(-sn, c), len: 0.15, mag: 10 }];               /* 壁から A にはたらく力 */
  return { ok: true, msg: '②-2（θ = 30°）と同じ 3 力にした' };
}

/* ===== 円盤の上の力のドラッグ =====
   ・矢印の根もと〜まん中（65 %）… 平行移動（move）
   ・矢印の先のほう、または点線の作用線 … 作用点のまわりに向きを変える（rot）
   ・マウスをのせるだけで、つかめる所だけ手のマークになる（ほかの所は矢印のまま）
   ・★吸いつき★ 回転軸を通る位置（うで 0）と、「モーメントの和が 0」になる位置
     （③ではもう一方の力と打ち消しあう位置）に、磁石のように吸いつく */
function wireDiscDrag(s, no, key, rkey) {
  var cv = document.getElementById('m1disc' + no); if (!cv) return;
  var grab = -1, mode = '', off = { x: 0, y: 0 }, offA = 0;
  function stt() { return s[key]; }
  function toLocal(ev) {
    var r = cv.getBoundingClientRect();
    return { lx: (ev.clientX - r.left) / r.width * 620, ly: (ev.clientY - r.top) / r.height * 400 };
  }
  /* 画面の点 → 円盤の上の点（z = 0 の面へ戻す）。mkProj：画面 y = cy + y1·sin(el)·S（z = 0） */
  function toModel(lx, ly) {
    var st2 = stt(), res = s[rkey];
    var az = st2.az * DEG, el = st2.el * DEG;
    var ca = Math.cos(az), sa = Math.sin(az), se = Math.sin(el);
    var X = (lx - res.cx) / res.pj.S, Y = (ly - res.cy) / res.pj.S;
    var x1 = X, y1 = (Math.abs(se) < 1e-6) ? 0 : Y / se;
    return { x: x1 * ca + y1 * sa, y: -x1 * sa + y1 * ca };
  }
  function segHit(px, py, x1, y1, x2, y2) {
    var vx = x2 - x1, vy = y2 - y1, L2 = vx * vx + vy * vy || 1;
    var t = ((px - x1) * vx + (py - y1) * vy) / L2, tc = clamp(t, 0, 1);
    return { d: Math.hypot(px - (x1 + vx * tc), py - (y1 + vy * tc)), t: t };
  }
  /* どの力の、どこ（move / rot）に当たっているか */
  function hitTest(lx, ly) {
    var res = s[rkey]; if (!res) return null;
    var best = null;
    res.seg.forEach(function (sg) {
      var h1 = segHit(lx, ly, sg.x1, sg.y1, sg.x2, sg.y2);
      var cand = null;
      if (h1.d < 15) cand = { i: sg.i, mode: (h1.t > 0.65 ? 'rot' : 'move'), d: h1.d };
      else if (Math.hypot(lx - sg.x2, ly - sg.y2) < 18) cand = { i: sg.i, mode: 'rot', d: 10 };
      else {
        var h2 = segHit(lx, ly, sg.lx1, sg.ly1, sg.lx2, sg.ly2);
        if (h2.d < 7) cand = { i: sg.i, mode: 'rot', d: h2.d + 8 };
      }
      if (cand && (!best || cand.d < best.d)) best = cand;
    });
    return best;
  }
  /* もう一方の力のモーメント（なければ 0） */
  function otherM(i) {                             /* ほかの力のモーメントの和 */
    var st2 = stt(), sum = 0;
    for (var k = 0; k < st2.f.length; k++) if (k !== i) { var qk = discForce(st2, k); sum += qk.arm * qk.mag; }
    return sum;
  }
  function store(f, px, py, aw) {
    var rot = stt().rot || 0;
    var cb = Math.cos(-rot), sb = Math.sin(-rot);
    f.x = px * cb - py * sb; f.y = px * sb + py * cb;
    if (aw !== undefined) f.a = aw - rot;
  }
  cv.addEventListener('pointerdown', function (ev) {
    var w = toLocal(ev), h = hitTest(w.lx, w.ly);
    if (!h) return;
    grab = h.i; mode = h.mode;
    var st2 = stt(), q = discForce(st2, grab), m = toModel(w.lx, w.ly);
    off = { x: q.px - m.x, y: q.py - m.y };
    offA = q.a - Math.atan2(m.y - q.py, m.x - q.px);
    st2.hot = grab; st2.hotMode = mode;
    cv.style.cursor = 'grabbing';
    cv.setPointerCapture(ev.pointerId); ev.preventDefault();
    DEFS['m1s2'].drawBelow(s);
  });
  cv.addEventListener('pointermove', function (ev) {
    var w = toLocal(ev), st2 = stt();
    if (grab < 0) {                                /* のせているだけ：つかめる所だけ手のマーク */
      var h = hitTest(w.lx, w.ly);
      cv.style.cursor = h ? 'grab' : 'default';
      var hi = h ? h.i : -1, hm = h ? h.mode : '';
      if (hi !== st2.hot || hm !== st2.hotMode) { st2.hot = hi; st2.hotMode = hm; DEFS['m1s2'].drawBelow(s); }
      return;
    }
    var f = st2.f[grab], q = discForce(st2, grab), m = toModel(w.lx, w.ly);
    var c0 = -otherM(grab) / q.mag;                 /* モーメントの和が 0 になる「うで」 */
    var goals = [0]; if (st2.f.length > 1 && Math.abs(c0) > 1e-6) goals.push(c0);
    if (st2.f.length === 3) {                         /* ④：ほかの 2 力の作用線の交点を通る位置にも吸いつく */
      var X = lineCross(discForce(st2, (grab + 1) % 3), discForce(st2, (grab + 2) % 3));
      if (X && Math.hypot(X.x, X.y) < 1.2) goals.push(X.x * q.uy - X.y * q.ux);
    }
    if (mode === 'move') {
      var px = m.x + off.x, py = m.y + off.y, ux = q.ux, uy = q.uy, RM = M2.DR * 0.97;
      /* ① 円板の外に出たら、いちばん近い縁の点へ（連続的に動くように、先に行う） */
      var r0 = Math.hypot(px, py);
      if (r0 > RM) { px *= RM / r0; py *= RM / r0; }
      var fx0 = px, fy0 = py;
      /* ② 吸いつき：作用線に垂直な向きに少しだけずらす */
      var arm = px * uy - py * ux, snapped = false;
      goals.forEach(function (gv) {
        if (snapped) return;
        var sn = snapTo(arm, gv, f.snapped ? 0.04 : 0.028);
        if (sn.on) { px += uy * (gv - arm); py -= ux * (gv - arm); snapped = true; }
      });
      /* ③ 吸いついた結果が縁の外なら、作用線にそって内がわへ（うでの長さは変えない） */
      if (snapped && Math.hypot(px, py) > RM) {
        var tt = px * ux + py * uy, gx = px - tt * ux, gy = py - tt * uy, d0 = Math.hypot(gx, gy);
        if (d0 < RM * 0.98) {
          var rr = Math.sqrt(RM * RM - d0 * d0) * 0.995;
          px = gx + ux * rr * (tt >= 0 ? 1 : -1); py = gy + uy * rr * (tt >= 0 ? 1 : -1);
          if (Math.hypot(px - fx0, py - fy0) > 0.12 * M2.DR) { px = fx0; py = fy0; snapped = false; }   /* 大きくとぶなら吸いつかない */
        } else { px = fx0; py = fy0; snapped = false; }
      }
      f.snapped = snapped;
      store(f, px, py);
    } else {
      var aw = Math.atan2(m.y - q.py, m.x - q.px) + offA;
      var R = Math.hypot(q.px, q.py), phi = Math.atan2(q.py, q.px), snappedA = false;
      if (no === 4) {                                 /* ④：向きは 15° きざみだけ（60°・120° の組み合わせに気づけるように） */
        var rr0 = stt().rot || 0, st15 = 15 * DEG;
        aw = Math.round((aw - rr0) / st15) * st15 + rr0;
        R = 0;                                        /* 吸いつきはしない */
      }
      if (R > 0.01) {
        goals.forEach(function (gv) {
          if (snappedA || Math.abs(gv) > R) return;
          var as = Math.asin(gv / R);
          [phi + as, phi + Math.PI - as].forEach(function (cand) {
            if (snappedA) return;
            var dd = Math.atan2(Math.sin(aw - cand), Math.cos(aw - cand));
            if (Math.abs(dd) < (f.snappedA ? 6 : 4) * DEG) { aw = cand; snappedA = true; }
          });
        });
      }
      f.snappedA = snappedA;
      store(f, q.px, q.py, aw);
    }
    DEFS['m1s2'].drawBelow(s);
    ev.preventDefault();
  });
  function end() {
    if (grab >= 0) { var st2 = stt(); st2.hot = -1; st2.hotMode = ''; }
    grab = -1; mode = ''; cv.style.cursor = 'default';
    DEFS['m1s2'].drawBelow(s);
  }
  cv.addEventListener('pointerup', end);
  cv.addEventListener('pointercancel', end);
  /* 力の矢印をダブルクリックすると、向きが反対になる（作用点・作用線はそのまま） */
  cv.addEventListener('dblclick', function (ev) {
    var w = toLocal(ev), h = hitTest(w.lx, w.ly);
    if (!h) return;
    var st2 = stt(); st2.f[h.i].a += Math.PI;
    ev.preventDefault();
    DEFS['m1s2'].drawBelow(s);
  });
  cv.addEventListener('pointerleave', function () {
    if (grab >= 0) return;
    var st2 = stt(); if (st2.hot !== -1) { st2.hot = -1; st2.hotMode = ''; DEFS['m1s2'].drawBelow(s); }
  });
}

/* ア・イ・ウ を押したときの動き（床の上の箱）。アニメのあいだは、ほかの力を消し、ほかのボタンを薄くする */
function pushDim(s, which) { return !!(s.anim && s.anim.kind === 'push' && s.anim.which !== which); }
function pushBox(s, which) {
  if (s.anim && s.anim.kind === 'push') return;
  s._m1msg = ''; s._m1sx = 0; s._m1ang = 0; s._m1up = null;   /* つぎの力で押すときは、はじめの位置から */
  s.anim = { kind: 'push', t: 0, dur: 1.15, which: which };
  if (typeof refreshActs === 'function') refreshActs();
}
function stepPushAnim(s, dt) {
  var a = s.anim; if (!a || a.kind !== 'push') return false;
  a.t += dt;
  var p = clamp(a.t / a.dur, 0, 1), e = p * (2 - p);
  /* ア・イ：作用線が同じ → 同じ動き（床の上をすべる）
     ウ　　：同じ作用点でも、ななめ上向き → 右下の角のまわりに倒れかける */
  var tx = (a.which === 'ウ') ? 8 : 70, ta = (a.which === 'ウ') ? 0.42 : 0;
  s._m1sx = tx * e; s._m1ang = ta * e;              /* 終わったら、その位置のまま（もとにもどさない） */
  if (a.t > a.dur * 0.5 && !s._m1msg) {
    s._m1msg = (a.which === 'ウ') ? 'ウ：向きがちがう → 倒れかける' :
      (a.which === 'ア' ? 'ア：床の上をすべる' : 'イ：ア とまったく同じ動き（すべる）');
  }
  if (a.t >= a.dur) {
    s.anim = null;
    if (a.which === 'ウ') s._m1up = { t: 0 };          /* ウ：2 秒後に箱を立てる */
    if (typeof refreshActs === 'function') refreshActs();
  }
  return true;
}


/* ===== 1-2 ②③④ の「回転しない置き方の例」（上から見た円板の図）=====
   1 つの例に図が 2 つ以上あるとき（figs）は、縮小して横にならべる。
   「特別な角度のときだけ」と思わないように、向きのちがう例もいっしょに見せる。
   fig … { f: [{ p（位置、半径 1）, d（向き）, c（色）, m（大きさの倍率）}], arm（うでを描く）, q（交わる点）}
         または { tri: [[x, y, 色], …] } … 力のベクトルを順につないだ三角形（ベクトル和 0） */
var DISC_ANS = {
  2: [   /* 第 61 回：答えは 1 つ（作用線が回転軸を通る）。第 63 回：図は 押す・引く・回転軸そのものを押す の 3 つ */
    { t: '作用線が回転軸を通る', r: 'うで 0（押しても、引いても、回転軸そのものを押しても）',
      figs: [{ f: [{ p: [1.31, 0], d: [-1, 0], c: 0 }], cap: '回転軸へ押す' },   /* 始点は円板の外 */
        { f: [{ p: [0.35, 0.35], d: [0.707, 0.707], c: 0 }], cap: '回転軸から引く' },
        { f: [{ p: [0, 0], d: [0.6, -0.8], c: 0 }], cap: '回転軸そのものを押す' }] }
  ],
  3: [
    { t: '2 つの力とも作用線が回転軸を通る', r: 'どちらも うで 0', f: [{ p: [0.55, 0], d: [1, 0], c: 0 }, { p: [0, 0.55], d: [0, 1], c: 1 }] },
    { t: 'うでの長さが同じで、回す向きが逆（同じ大きさ）', r: 'F₁l ＝ F₂l で打ち消しあう', r2: '（一直線上でなくても、ななめの向きでもよい）',
      figs: [{ f: [{ p: [-0.3, -0.45], d: [-1, 0], c: 0 }, { p: [0.3, -0.45], d: [1, 0], c: 1 }], arm: true },
        { f: [{ p: [0.246, 0.373], d: [0.5, -0.866], c: 0 }, { p: [-0.444, 0.051], d: [0.342, -0.94], c: 1 }], arm: true },
        { f: [{ p: [-0.45, 0.2], d: [0, -1], c: 0 }, { p: [0.45, -0.2], d: [0, -1], c: 1 }], arm: true },
        { f: [{ p: [0.141, 0.424], d: [0.707, -0.707], c: 0 }, { p: [-0.424, -0.141], d: [0.707, -0.707], c: 1 }], arm: true }] }
  ],
  4: [
    { t: '大きさのちがう 3 力（②-2 の棒と同じ）', r: '作用線が 1 点で交わり、力のベクトル和が 0',
      figs: [{ q: [-0.3, 0.3], f: [{ p: [0.05, 0.3], d: [1, 0], c: 0, m: 0.75 }, { p: [-0.3, 0.6], d: [0, 1], c: 1, m: 1 }, { p: [-0.54, -0.02], d: [-0.6, -0.8], c: 2, m: 1.25 }] },   /* どの作用線も回転軸を通らない */
        { tri: [[0.75, 0, 0], [0, 1, 1], [-0.75, -1, 2]] }] },
    { t: '3 つの力とも作用線が回転軸を通る', r: 'どれも うで 0', f: [{ p: [0.55, 0], d: [1, 0], c: 0 }, { p: [-0.3, 0.45], d: [-0.55, 0.83], c: 1 }, { p: [-0.3, -0.45], d: [-0.55, -0.83], c: 2 }] },
    { t: '2 つが打ち消しあい、のこり 1 つは回転軸を通る', r: 'F₁l ＝ F₂l、F₃ は うで 0（一直線上でなくてもよい）',
      figs: [{ f: [{ p: [-0.3, -0.45], d: [-1, 0], c: 0 }, { p: [0.3, -0.45], d: [1, 0], c: 1 }, { p: [0, 0.55], d: [0, 1], c: 2 }], arm: true },
        { f: [{ p: [0.246, 0.373], d: [0.5, -0.866], c: 0 }, { p: [-0.444, 0.051], d: [0.342, -0.94], c: 1 }, { p: [0.35, -0.4], d: [0.659, -0.753], c: 2 }], arm: true }] },
    { t: '片側の 2 つと、反対側の 1 つ（うでは 2 倍）', r: 'F₁l ＋ F₂l ＝ F₃(2l)（向きがばらばらでもよい）',
      figs: [{ f: [{ p: [-0.3, 0.4], d: [0, 1], c: 0 }, { p: [-0.3, -0.4], d: [0, 1], c: 1 }, { p: [0.6, 0], d: [0, 1], c: 2 }], arm: true },
        { f: [{ p: [0.15, 0.3], d: [-1, 0], c: 0 }, { p: [-0.335, -0.02], d: [0.5, -0.866], c: 1 }, { p: [0.615, -0.064], d: [-0.342, -0.94], c: 2 }], arm: true }] }
  ]
};
function discAnsH(a) { return a.figs ? (a.figs.length > 3 ? 396 : 250) : 200; }   /* 図 4 つは 2 行 × 2 列 */
/* 円板の図 1 つ（中心 cx, cy・半径 R） */
function drawAnsDisc(ctx, fg, cx, cy, R) {
  var k = R / 62;
  ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.fillStyle = '#efe4d4'; ctx.fill();
  ctx.strokeStyle = '#8a7a55'; ctx.lineWidth = 1.5; ctx.stroke(); ctx.restore();
  axisMark(ctx, cx, cy, null);
  var foots = fg.f.map(function (f) {                 /* うでの足（重なるうでは色を交互に） */
    var P = { x: cx + f.p[0] * R, y: cy - f.p[1] * R }, u = { x: f.d[0], y: -f.d[1] };
    var t = (cx - P.x) * u.x + (cy - P.y) * u.y;
    return { x: P.x + u.x * t, y: P.y + u.y * t };
  });
  fg.f.forEach(function (f, j) {
    var col = DISC_COL[f.c].f, P = { x: cx + f.p[0] * R, y: cy - f.p[1] * R }, u = { x: f.d[0], y: -f.d[1] };
    dotLine(ctx, P.x - u.x * 90 * k, P.y - u.y * 90 * k, P.x + u.x * 90 * k, P.y + u.y * 90 * k, fade(col, .55), 1.2, [5, 4]);
    var Fo = foots[j];
    if (fg.arm && Math.hypot(Fo.x - cx, Fo.y - cy) > 2) {   /* うで（回転軸から作用線へ） */
      var grp = [];
      foots.forEach(function (q, kk) { if (Math.hypot(q.x - Fo.x, q.y - Fo.y) < 2) grp.push(kk); });
      ctx.save(); ctx.strokeStyle = DISC_COL[f.c].arm; ctx.lineWidth = 2.4;
      if (grp.length > 1) { ctx.setLineDash([5, 5 * (grp.length - 1)]); ctx.lineDashOffset = -5 * grp.indexOf(j); }
      else ctx.setLineDash([3, 3]);
      ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(Fo.x, Fo.y); ctx.stroke(); ctx.restore();
    }
    var al = 38 * k * (f.m || 1);
    arrow(ctx, P.x, P.y, P.x + u.x * al, P.y + u.y * al, 'force', 0.85, col);
    ctx.save(); ctx.beginPath(); ctx.arc(P.x, P.y, 3.4, 0, Math.PI * 2); ctx.fillStyle = '#fff'; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = col; ctx.stroke(); ctx.restore();
  });
  if (fg.q) {                                          /* 作用線が交わる点 */
    var Qx = cx + fg.q[0] * R, Qy = cy - fg.q[1] * R;
    ctx.save(); ctx.beginPath(); ctx.arc(Qx, Qy, 4, 0, Math.PI * 2); ctx.fillStyle = '#fff'; ctx.fill(); ctx.lineWidth = 1.8; ctx.strokeStyle = '#1b1f24'; ctx.stroke(); ctx.restore();
  }
}
/* 力のベクトルを順につないだ図（三角形がとじる → ベクトル和 0） */
function drawAnsTri(ctx, tri, cx, cy, R) {
  var x = 0, y = 0, pts = [[0, 0]], i;
  tri.forEach(function (v) { x += v[0]; y += v[1]; pts.push([x, y]); });
  var xs = pts.map(function (p) { return p[0]; }), ys = pts.map(function (p) { return p[1]; });
  var x0 = Math.min.apply(null, xs), x1 = Math.max.apply(null, xs), y0 = Math.min.apply(null, ys), y1 = Math.max.apply(null, ys);
  var sc = 1.5 * R / Math.max(x1 - x0, y1 - y0, 1e-6), mx = (x0 + x1) / 2, my = (y0 + y1) / 2;
  function P(p) { return { x: cx + (p[0] - mx) * sc, y: cy - 6 - (p[1] - my) * sc }; }
  for (i = 0; i < tri.length; i++) {
    var A = P(pts[i]), B = P(pts[i + 1]), col = DISC_COL[tri[i][2]].f;
    arrow(ctx, A.x, A.y, B.x, B.y, 'force', 0.85, col);
    var dx = B.x - A.x, dy = B.y - A.y, dl = Math.hypot(dx, dy) || 1;
    /* 文字は三角形の外がわ（重心と反対がわ）に */
    var gx = cx, gy = cy - 6, mxp = (A.x + B.x) / 2, myp = (A.y + B.y) / 2, nx = -dy / dl, ny = dx / dl;
    if (nx * (mxp - gx) + ny * (myp - gy) < 0) { nx = -nx; ny = -ny; }
    label(ctx, 'F_' + (tri[i][2] + 1), mxp + nx * 14, myp + ny * 14, { size: 13, bold: true, color: col });
  }
  label(ctx, '力のベクトル和 = 0', cx, cy + R + 24, { size: 12.5, bold: true, color: '#3d4c5a' });
}
function drawDiscAns(cv, no) {
  var list = DISC_ANS[no], W = 400, H = 0;
  list.forEach(function (a) { H += discAnsH(a); });
  var ctx = prep(cv, W, H), y0 = 0;
  NO_SHIFT = true;
  list.forEach(function (a, i) {
    if (i) { ctx.save(); ctx.strokeStyle = '#d5dde5'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(8, y0); ctx.lineTo(W - 8, y0); ctx.stroke(); ctx.restore(); }
    label(ctx, (list.length > 1 ? (i + 1) + '　' : '') + a.t, 12, y0 + 18, { size: 14, bold: true, color: '#1f3b57', align: 'left' });
    if (!a.figs) {                                   /* 図 1 つ：左に図、右に文 */
      var cy = y0 + 112;
      drawAnsDisc(ctx, a, 88, cy, 62);
      label(ctx, a.r, 172, cy - 8, { size: 13.5, bold: true, color: '#0a5c5c', align: 'left' });
      label(ctx, '→ 回転しない（M = 0）', 172, cy + 16, { size: 13.5, bold: true, color: '#0a5c5c', align: 'left' });
    } else {                                         /* 図が 2 つ以上：縮小して横にならべ、文は下に */
      var n = a.figs.length, g4 = n > 3, R = g4 ? 42 : (n > 2 ? 40 : 46), cy2 = y0 + (g4 ? 100 : 108), nc = g4 ? 2 : n;
      a.figs.forEach(function (fg, k) {
        var cx = W * (k % nc + 0.5) / nc, cyk = cy2 + Math.floor(k / nc) * 130;
        ctx.save(); ctx.beginPath(); ctx.rect(W * (k % nc) / nc + 2, cyk - (g4 ? 64 : 80), W / nc - 4, g4 ? 128 : 170); ctx.clip();   /* 第 61 回：作用線の点線がとなりの図にはみ出さない */
        if (fg.tri) drawAnsTri(ctx, fg.tri, cx, cyk, R); else drawAnsDisc(ctx, fg, cx, cyk, R);
        ctx.restore();
        if (fg.cap) label(ctx, fg.cap, cx, cyk + R + 16, { size: 12, bold: true, color: '#3d4c5a' });   /* 第 61 回：図ごとの説明 */
      });
      var ty = y0 + (g4 ? 326 : 204);
      label(ctx, a.r, 12, ty, { size: 13, bold: true, color: '#0a5c5c', align: 'left' });
      if (a.r2) { ty += 24; label(ctx, a.r2, 12, ty, { size: 13, bold: true, color: '#0a5c5c', align: 'left' }); }
      label(ctx, '→ 回転しない（M = 0）', 12, ty + 24, { size: 13, bold: true, color: '#0a5c5c', align: 'left' });
    }
    y0 += discAnsH(a);
  });
  NO_SHIFT = false;
}

