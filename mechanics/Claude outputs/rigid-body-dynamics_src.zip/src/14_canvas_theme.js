/* ===== 14_canvas_theme.js ===== */
/* ===== C6　図の中の UI の色を紙と墨の色に（第 55 回） =====
   canvas に色を入れる瞬間（fillStyle・strokeStyle）に、下の表にある色だけを置きかえる。作図のコードは書きかえない（このファイルを外せば元にもどる）。
   ★表に入れるのは UI の色だけ：区切り線・薄い線・パネルの面・説明の灰色の文字・「つりあっていない」の吹き出し。
     物理の色（力の赤・垂直抗力のむらさき・摩擦の青緑・手のピンク・速度の青・A 青・B 赤・寸法の黒・物体の色）は入れない。 */
(function () {
  var MAP = {
    '#dde3e8': '#e6e0d6',   /* 図の左右の区切り線 */
    '#d5dde5': '#e2dcd1',   /* 区切りの破線 */
    '#e2e6ea': '#ebe6dd',   /* グラフの目盛り線（COL.grid） */
    '#fbfcfd': '#fcfaf6',   /* ズームアップの枠の中の面 */
    '#eef3f8': '#f6f3ee',   /* 「傾いている」などの吹き出しの面 */
    '#8ba4bd': '#b9ae9c',   /* 同じ吹き出しの線 */
    '#3d4c5a': '#3b4048',   /* 説明の濃い灰色の文字 */
    '#5b6672': '#61656d'    /* 説明の灰色の文字・軸（COL.sub・AX.col） */
  };
  var P2D = window.CanvasRenderingContext2D && CanvasRenderingContext2D.prototype;
  if (!P2D) return;
  ['fillStyle', 'strokeStyle'].forEach(function (prop) {
    var d = Object.getOwnPropertyDescriptor(P2D, prop);
    if (!d || !d.set) return;
    Object.defineProperty(P2D, prop, {
      configurable: true, enumerable: d.enumerable, get: d.get,
      set: function (v) { if (typeof v === 'string') { var k = v.toLowerCase(); if (MAP.hasOwnProperty(k)) v = MAP[k]; } d.set.call(this, v); }
    });
  });
})();

