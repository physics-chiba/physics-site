/* ===== 86_look.js ===== */
/* ===== 見た目の改善の小さな JS（第 55 回） ===== */

/* C5　図の背景を方眼ノートに。
   このページの図は「1 m の方眼」を持たず、1 つの図の中に縮尺のちがう領域（本体とズームアップ）が並ぶ。
   観測者が動く表示もない（どの図も地面＝紙に固定した立場）。そこで方眼は図の論理座標（＝紙）に固定する：
   画面の大きさを変えても図といっしょに伸び縮みし、物体とずれない。5-2 の揺れる地面は、方眼に対して動いて見える。
   ・細い線 20 px ごと、5 本ごとに少し濃い線。
   ・3 次元の図（モード 3 の重心の図・視点を回せる図）には描かない。座標軸を描く図（モード 3）にも描かない。 */
function gridOK(d) {
  if (!d || d.cam3d || d.drag3d || d.noGrid) return false;
  var m = modeOf(st.cur);
  return !(m && m.n === 3);
}
function notebookGrid(c, W, H) {
  var sp = 20, per = 5, k, x, y;
  c.save(); c.lineWidth = 1;
  for (k = 0; k * sp <= W; k++) {
    x = Math.round(k * sp) + 0.5;
    c.strokeStyle = (k % per === 0) ? '#eee8df' : '#f7f4ef';
    c.beginPath(); c.moveTo(x, 0); c.lineTo(x, H); c.stroke();
  }
  for (k = 0; k * sp <= H; k++) {
    y = Math.round(H - k * sp) - 0.5;              /* 下（床の側）からそろえる */
    c.strokeStyle = (k % per === 0) ? '#eee8df' : '#f7f4ef';
    c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke();
  }
  c.restore();
}

/* C2　スライドバーの塗り（--p）：操作したとき＋プログラムから値を入れたときも拾う（見えているものだけを 0.12 秒ごとに見回る） */
function syncRange(el) {
  var mn = parseFloat(el.min) || 0, mx = parseFloat(el.max), v = parseFloat(el.value);
  var s = ((isFinite(mx) && mx > mn) ? (v - mn) / (mx - mn) * 100 : 0).toFixed(1) + '%';
  if (el._p !== s) { el._p = s; el.style.setProperty('--p', s); }
}
document.addEventListener('input', function (e) { if (e.target && e.target.type === 'range') syncRange(e.target); }, true);
setInterval(function () {
  if (document.hidden) return;
  Array.prototype.forEach.call(document.querySelectorAll('input[type=range]'), function (el) { if (el.offsetParent) syncRange(el); });
}, 120);

/* C11　タブ列の下の「読み進み」の細い線（スクロール量 ÷ 全体） */
(function () {
  var bar = null, last = -1;
  function upd() {
    if (!bar) bar = document.getElementById('tabbar');
    if (!bar) return;
    var de = document.documentElement, max = Math.max(1, de.scrollHeight - de.clientHeight);
    var p = Math.min(1, Math.max(0, (window.scrollY || de.scrollTop) / max));
    p = Math.round(p * 1000) / 1000;
    if (p !== last) { last = p; bar.style.setProperty('--prog', p); }
  }
  window.addEventListener('scroll', upd, { passive: true });
  window.addEventListener('resize', upd);
  setTimeout(upd, 300);
})();

/* A-1 の追加：画面の外にある光の輪は止めておく（見えるところに来たら動きだす）。
   1-2 のように光るボタンが下のカードにたくさんある章でも、何もしていないときの CPU を小さくする。 */
(function () {
  if (!window.IntersectionObserver) return;
  var SEL = 'button.pulse, button.sg-glow, .topacts button.warm.glow, .discview button.warm.glow, .bcard button.openbtn.glow, label.vflash';
  var io = new IntersectionObserver(function (es) {
    es.forEach(function (e) { if (e.isIntersecting) e.target.removeAttribute('data-ringoff'); else e.target.setAttribute('data-ringoff', ''); });
  });
  function scan() {
    Array.prototype.forEach.call(document.querySelectorAll(SEL), function (el) {
      if (el._ringIO) return;
      el._ringIO = 1; io.observe(el);
    });
  }
  setInterval(function () { if (!document.hidden) scan(); }, 500);
  scan();
})();

