/* ===== 45_defs.js ===== */
/* シミュレーションの登録表と、3 つのタブで共通に使う「箱」の描画部品。 */
'use strict';
var DEFS = {};
/* タブは 2 段。上＝モード、下＝そのモードのセクション */
var MODES = [
  { n: 1, name: '①　剛体の性質と力のモーメント', tab: '①　剛体と力のモーメント', tip: '力のモーメント（回転させるはたらき）と、剛体に対する力のはたらきの特徴を知ろう。',
    ids: ['m1s1', 'm1s2'] },
  { n: 2, name: '②　力のモーメントのつりあい', tab: '②　モーメントのつりあい', tip: '剛体がつりあう条件（力の和 0・モーメントの和 0）を使う。',
    ids: ['m2s1', 'm2s2', 'm2s3'] },
  { n: 3, name: '③　重心', tab: '③　重心', tip: '重心は重力の作用点。質点におきかえて重心の位置を求める。', ids: ['m3s2', 'm3s3', 'm3s4', 'm3s5'] },
  { n: 4, name: '④　箱の回転（傾くのが先かすべるのが先か）', tab: '④　箱の回転（傾くかすべるか）', tip: '板の上に置いた箱では、板を傾けていくと、箱が傾く（回転する）かすべるかのどちらかが先に起こる。床の上の箱を引くときも同じ。<br>' +
    'どちらが先かは、箱の形（幅 a・高さ b）と静止摩擦係数 μ、そして力の作用点で決まる。自分で動かして、抗力の作用点が動いていくようすと作用線を見よう。',
    purpose: ['<b>板を傾けていく</b>と、抗力（垂直抗力＋摩擦力）の<b>作用点が回転軸のほうへ動いていく</b>ことを見る。',
      '<b>重力の作用線が回転軸を通った瞬間</b>に傾きはじめることを、作図で確かめる。',
      '「傾く」と「すべる」のどちらが先かは、<b>箱の形（a/b）</b>と<b>静止摩擦係数 μ</b>で決まることを理解する。',
      '床の上の箱を引くときは、<b>3 力の作用線が 1 点で交わる</b>こと、<b>引く力の作用点が高いほど傾きやすい</b>ことを体感する。'],
    ids: ['r1', 'r2', 'r3'] },
  { n: 5, name: '⑤　安定なつりあいと不安定なつりあい', tab: '⑤　安定・不安定なつりあい', tip: '重心と支点の位置関係で、つりあいが「安定」か「不安定」かが決まる。指でつまんだ状態から、手をはなしてみよう。',
    ids: ['st1', 'st2'] },
  { n: 6, name: '⑥　（超上級編）剛体の重心の運動', tab: '⑥　重心の運動', tip: '重心の運動から見ると、すべては 2 つの法則に行きつく。別のページ（読みもの＋アニメーション）で学ぼう。',
    ids: ['m5s1'] }
];
/* モード 4 だけの版（rotation-box_tip-or-slip.html）：ほかのモードは出さない */
if (window.ONLY_MODE) {
  MODES = MODES.filter(function (m) { return m.n === window.ONLY_MODE; });
  document.documentElement.classList.add('onlymode');
}
function modeOf(id) {
  for (var i = 0; i < MODES.length; i++) if (MODES[i].ids.indexOf(id) >= 0) return MODES[i];
  return MODES[0];
}

/* 「$…$」を KaTeX で組む span に変える */
function mathHtml(str) {
  var out = '', i = 0;
  str = String(str);
  while (i < str.length) {
    var a = str.indexOf('$', i);
    if (a === -1) { out += str.slice(i); break; }
    out += str.slice(i, a);
    var b = str.indexOf('$', a + 1);
    if (b === -1) { out += str.slice(a); break; }
    out += '<span class="tex">' + str.slice(a + 1, b) + '</span>';
    i = b + 1;
  }
  return out;
}

/* 図の中の「答えにつながる言葉」を出してよいか。
   このページには再生ボタンがないので、「生徒が何かを動かしたあと」（s.touched）。 */
function hintOn(s) { return !!(s && s.touched); }

/* 視点がそのプリセットと同じか */
function camIs(s, az, el, zoom) {
  return !!s.cam && Math.abs(s.cam.az - az) < 0.5 && Math.abs(s.cam.el - el) < 0.5 &&
    Math.abs(s.cam.zoom - zoom) < 0.02;
}

/* 直方体のブロック（水平な面の上など）。ang＝面の傾き(rad, 反時計まわりが正の見た目) */
function blockShape(ctx, cx, cy, ang, w, h, fill) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(-ang);
  ctx.fillStyle = fill || '#e8eef5';
  ctx.strokeStyle = '#2c3e50';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.rect(-w / 2, -h / 2, w, h);
  ctx.fill(); ctx.stroke();
  ctx.restore();
}

/* 地面（横一直線＋ハッチ） */
function ground(ctx, x1, x2, y) { hatchLine(ctx, x1, y, x2, y, 1); }

/* ===== 箱の色（力・速度の色は使わない） ===== */
var BOXCOL = { fill: '#e9d6c4', fill2: '#d9bfa6', fill3: '#c9a98b', line: '#6b4a2e', grid: 'rgba(107,74,46,.35)',
  plate: '#efe9d8', plate2: '#d8cfb4', plateLine: '#8a7a55', pin: '#2c3e50' };
var FL = 64;                 /* [px] 重力の矢印の長さ（力の矢印はこれで正規化） */

/* ===== 側面図の箱の座標 =====
   pv     … 回転軸（箱の「引かれる側／下側」の下の角）の画面座標 {x, y}
   angDeg … 面の傾き [°]（右上がりが正）
   tipDeg … 傾いてからの回転 [°]（軸のまわりに、上側が下側へ倒れる向き）
   a, b   … 箱の幅・高さ [m]、S … 縮尺 [px/m]
   戻り値： u（面にそって上る向き）、n（面から外向き）、4 つの角 c[0..3]、重心 cm  */
function boxGeom(pv, angDeg, tipDeg, a, b, S) {
  /* 下側の角を軸に「上側が下側へ」倒れる＝反時計まわり＝角が増える */
  var al = (angDeg + (tipDeg || 0)) * DEG;
  var u = { x: Math.cos(al), y: -Math.sin(al) };
  var n = { x: -Math.sin(al), y: -Math.cos(al) };
  var w = a * S, h = b * S;
  function pt(su, sn) { return { x: pv.x + u.x * su + n.x * sn, y: pv.y + u.y * su + n.y * sn }; }
  return {
    pv: pv, u: u, n: n, w: w, h: h, S: S, a: a, b: b, ang: angDeg, tip: tipDeg || 0,
    c: [pt(0, 0), pt(w, 0), pt(w, h), pt(0, h)],
    cm: pt(w / 2, h / 2),
    pt: pt
  };
}

/* 側面図の箱を描く（分割線つき）。opt.grid … 縦横 2 分割の細い線 */
function drawBoxSide(ctx, g, opt) {
  opt = opt || {};
  var c = g.c, i;
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(c[0].x, c[0].y);
  for (i = 1; i < 4; i++) ctx.lineTo(c[i].x, c[i].y);
  ctx.closePath();
  ctx.fillStyle = opt.fill || BOXCOL.fill;
  ctx.fill();
  if (opt.grid) {
    ctx.strokeStyle = BOXCOL.grid; ctx.lineWidth = 0.8;
    for (i = 1; i < 2; i++) {
      var p = g.pt(g.w * i / 2, 0), q = g.pt(g.w * i / 2, g.h);
      ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y); ctx.stroke();
      p = g.pt(0, g.h * i / 2); q = g.pt(g.w, g.h * i / 2);
      ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y); ctx.stroke();
    }
  }
  ctx.strokeStyle = opt.line || BOXCOL.line; ctx.lineWidth = opt.lw || 2;
  ctx.beginPath();
  ctx.moveTo(c[0].x, c[0].y);
  for (i = 1; i < 4; i++) ctx.lineTo(c[i].x, c[i].y);
  ctx.closePath(); ctx.stroke();
  ctx.restore();
  if (typeof noteObj === 'function') {
    var xs = c.map(function (p) { return p.x; }), ys = c.map(function (p) { return p.y; });
    noteObj(Math.min.apply(null, xs), Math.min.apply(null, ys),
      Math.max.apply(null, xs) - Math.min.apply(null, xs), Math.max.apply(null, ys) - Math.min.apply(null, ys));
  }
}

/* 蝶つがい。その点を軸に回る */
function pinMark(ctx, x, y, r) {
  r = r || 4.2;
  ctx.save();
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fillStyle = '#fff'; ctx.strokeStyle = BOXCOL.pin; ctx.lineWidth = 1.8;
  ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.arc(x, y, 1.3, 0, Math.PI * 2); ctx.fillStyle = BOXCOL.pin; ctx.fill();
  ctx.restore();
}

/* 回転軸の印（●）と「回転軸」の字 */
function axisMark(ctx, x, y, text, opt) {
  opt = opt || {};
  ctx.save();
  ctx.beginPath(); ctx.arc(x, y, 3.6, 0, Math.PI * 2);
  ctx.fillStyle = '#1b1f24'; ctx.fill();
  ctx.restore();
  if (text) label(ctx, text, x + (opt.dx === undefined ? -8 : opt.dx), y + (opt.dy === undefined ? 12 : opt.dy),
    { size: 11, color: COL.sub, align: opt.align || 'right' });
}

/* 半直線（作用線）。(x,y) から (dx,dy) の向きへ、枠 box{x0,y0,x1,y1} の外まで伸ばす */
function rayLine(ctx, x, y, dx, dy, color, box, lw, maxLen) {
  var L = Math.hypot(dx, dy) || 1; dx /= L; dy /= L;
  var tmax = maxLen || 1e4, t;
  if (dx > 1e-9) tmax = Math.min(tmax, (box.x1 - x) / dx); else if (dx < -1e-9) tmax = Math.min(tmax, (box.x0 - x) / dx);
  if (dy > 1e-9) tmax = Math.min(tmax, (box.y1 - y) / dy); else if (dy < -1e-9) tmax = Math.min(tmax, (box.y0 - y) / dy);
  if (tmax < 0) tmax = 0;
  t = tmax;
  ctx.save();
  ctx.strokeStyle = color; ctx.lineWidth = lw || 1.3; ctx.setLineDash([6, 4]);
  ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + dx * t, y + dy * t); ctx.stroke();
  ctx.restore();
}

/* ===== r1・r2 の力（側面図）=====
   g … boxGeom、v … { th, mu }、st … P.tilt.state の結果、show … { F, L, Fc }
   box … 作用線を伸ばす範囲（枠）、fs … [px/N] 縮尺
   ・重力 mg は重心から鉛直下向き
   ・抗力（＝垂直抗力＋摩擦力）は接触面の点 s = a/2 − (b/2)tanθ から鉛直上向き
   ・傾いたあと（回転中）は力がつり合わないので、抗力は描かず重力だけ描く          */
function drawTiltForces(ctx, g, v, stt, show, box, fs, opt) {
  opt = opt || {};
  var m = P.box.M, mg = m * G;
  var th = v.th * DEG;
  var Lg = mg * fs;
  var tipped = stt.tip && g.tip > 0.01;
  var cm = g.cm;
  var sR = P.tilt.contact(g.a, g.b, v.th);
  var cp = g.pt(sR * g.S, 0);                                   /* 抗力の作用点 */
  var lab = opt.lab === undefined ? true : opt.lab;
  var sz = opt.size || 12.5;
  var RL = 2 * Math.max(g.w, g.h);                              /* 作用線の長さ＝箱の 2 倍ほど */
  var still = !tipped && !stt.slip;
  /* ★重力は重心から、抗力は本当の作用点から描く。2 本が重ならないようにするための
     「横へのずらし」は、作用点が回転軸からどれだけ離れているかに比例させ、
     傾く瞬間（作用点が回転軸に一致）にはちょうど 0 にする。         */
  var offR = 5.5 * clamp(sR / Math.max(1e-6, g.a / 2), 0, 1);
  if (show.L) {                                                  /* 作用線（半直線） */
    rayLine(ctx, cm.x, cm.y, 0, 1, COL.force, box, 1.3, RL);
    if (still) rayLine(ctx, cp.x + offR, cp.y, 0, -1, COL.norm, box, 1.3, RL);
    else rayLine(ctx, cm.x, cm.y, 0, -1, fade(COL.force, .55), box, 1.3, RL);   /* 傾いたら重力の作用線を上にも */
  }
  var mainOn = show.F && !show.Hide;                             /* 重力・抗力そのもの */
  var compOn = show.Fc && still;                                 /* 分解した力 */
  if (compOn) {
    var u = g.u, n = g.n, cs = sz - 1.5;
    var Lc = Lg * Math.cos(th), Ls = Lg * Math.sin(th);
    arrow(ctx, cm.x, cm.y, cm.x - n.x * Lc, cm.y - n.y * Lc, 'comp', 1, COL.force);
    if (lab) tipLabel(ctx, 'mg cosθ', cm.x - n.x * Lc, cm.y - n.y * Lc, -n.x, -n.y, { size: cs, color: COL.force, dx: -30 * Math.cos(th), dy: -6 * Math.sin(th) });
    if (Ls > 3) {
      arrow(ctx, cm.x, cm.y, cm.x - u.x * Ls, cm.y - u.y * Ls, 'comp', 1, COL.force);
      if (lab && Ls > 8) tipLabel(ctx, 'mg sinθ', cm.x - u.x * Ls, cm.y - u.y * Ls, -u.x, -u.y, { size: cs, color: COL.force });
    }
    arrow(ctx, cp.x, cp.y, cp.x + n.x * Lc, cp.y + n.y * Lc, 'comp', 1, COL.norm);
    if (lab) tipLabel(ctx, 'N', cp.x + n.x * Lc, cp.y + n.y * Lc, n.x, n.y, { size: sz, color: COL.norm, dx: -16 * Math.cos(th) });
    if (Ls > 3) {
      arrow(ctx, cp.x, cp.y, cp.x + u.x * Ls, cp.y + u.y * Ls, 'comp', 1, COL.fric);
      if (lab && Ls > 8) tipLabel(ctx, 'f', cp.x + u.x * Ls, cp.y + u.y * Ls, u.x, u.y, { size: sz, color: COL.fric });
    }
  }
  if (mainOn) {
    NO_SHIFT = true;                                 /* ずらしは自分でやる（自動ずらしは切る） */
    /* 傾く瞬間は 2 本がぴたりと重なる。重力（赤）を上に描いて見えなくならないようにする */
    if (still) {
      arrow(ctx, cp.x + offR, cp.y, cp.x + offR, cp.y - Lg, 'force', 1, COL.norm);
      if (lab) tipLabel(ctx, '抗力', cp.x + offR, cp.y - Lg, 0, -1, { size: sz, color: COL.norm, dx: compOn ? 24 : 0 });
    }
    arrow(ctx, cm.x, cm.y, cm.x, cm.y + Lg, 'force', 1, COL.force);
    if (lab) tipLabel(ctx, 'mg', cm.x, cm.y + Lg, 0, 1, { size: sz, color: COL.force, dx: compOn ? 20 : 0 });
    NO_SHIFT = false;
  }
  if (still && (mainOn || compOn)) actPoint(ctx, cp.x, cp.y, COL.norm);   /* 抗力の作用点の● */
  return { cp: cp };
}

/* ===== r3 の力（側面図）=====
   g … boxGeom（ang=0）、v … { F, mu, bp }、show … { F, L, Fc, Sum }
   ・重力 mg は重心から下、引く力 F′ は左の面の高さ b′ の点から左向き
   ・抗力は接触面の点 x = a/2 − F′b′/(mg) から、(F′, mg) の向き（右上）
   ・「合成」は、重力と F′ の作用線の交点に 2 力を集めて合成したベクトル              */
function drawPullForces(ctx, g, v, stt, show, box, fs, opt) {
  opt = opt || {};
  var _sumOn = false, _normOn = false;      /* 「合力」「抗力」の文字を出すか */
  var m = P.box.M, mg = m * G, F = v.F;
  var Lg = mg * fs, Lf = F * fs;
  var tipped = stt.tip && g.tip > 0.01;
  var still = !tipped && !stt.slip;
  var cm = g.cm;
  var xR = P.pull.contact(m, g.a, F, v.bp);
  var cp = g.pt(xR * g.S, 0);
  var fp = g.pt(0, v.bp * g.S);                                  /* F の作用点（左の面） */
  var sz = opt.size || 12.5;
  var lab = opt.lab === undefined ? true : opt.lab;
  var ix = { x: cm.x, y: fp.y };                                 /* 重力の作用線と F の作用線の交点 */
  var Rx = F * fs, Ry = -mg * fs;                                /* 抗力（画面の向き） */
  var Rl = Math.hypot(Rx, Ry) || 1;
  /* 抗力と合力が重ならないよう、抗力を横へずらす。ずらし量は作用点が回転軸から
     どれだけ離れているかに比例させ、★傾く瞬間（作用点が回転軸）には 0★ にする */
  var offP = 4 * clamp(xR / Math.max(1e-6, g.a / 2), 0, 1);
  var ox = -Ry / Rl * offP, oy = Rx / Rl * offP;
  var RL = 2 * Math.max(g.w, g.h);
  if (show.L || show.Sum) {
    rayLine(ctx, cm.x, cm.y, 0, 1, COL.force, box, 1.3, RL);
    rayLine(ctx, cm.x, cm.y, 0, -1, COL.force, box, 1.3, RL);
    if (F > 1e-6) { rayLine(ctx, fp.x, fp.y, -1, 0, COL.hand, box, 1.3, RL); rayLine(ctx, fp.x, fp.y, 1, 0, COL.hand, box, 1.3, RL); }
    if (still && Rl > 1) {
      rayLine(ctx, cp.x + ox, cp.y + oy, Rx, Ry, COL.norm, box, 1.3, RL);
      rayLine(ctx, cp.x + ox, cp.y + oy, -Rx, -Ry, fade(COL.norm, .5), box, 1.3, RL * 0.5);
    }
  }
  if (show.Sum && F > 1e-6) {                                    /* 2 力を交点に集めて合成 */
    arrow(ctx, ix.x, ix.y, ix.x, ix.y + Lg, 'comp', 1, COL.force);
    arrow(ctx, ix.x, ix.y, ix.x - Lf, ix.y, 'comp', 1, COL.hand);
    arrow(ctx, ix.x, ix.y, ix.x - Lf, ix.y + Lg, 'force', 1, '#8a5a2b');
    ctx.save(); ctx.strokeStyle = 'rgba(138,90,43,.55)'; ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
    ctx.beginPath(); ctx.moveTo(ix.x - Lf, ix.y); ctx.lineTo(ix.x - Lf, ix.y + Lg); ctx.lineTo(ix.x, ix.y + Lg); ctx.stroke();
    ctx.restore();
    if (lab) _sumOn = true;
    rayLine(ctx, ix.x, ix.y, -Lf, Lg, '#8a5a2b', box, 1.6, RL);
    rayLine(ctx, ix.x, ix.y, Lf, -Lg, 'rgba(138,90,43,.5)', box, 1.2, RL * 0.5);
  }
  /* 「引く力と重力を合成」を出しているときは、もとの引く力 F と重力 mg は描かない
     （交点に集めた 2 本（破線）と合力だけにする）。
     「抗力のベクトルを消す」は抗力だけを消す（重力は消さない）。 */
  var baseOn = show.F && !show.Sum;                              /* もとの引く力 F と重力 mg */
  var mainOn = show.F && !show.Hide;                             /* 抗力 */
  var compOn = show.Fc && still;                                 /* 抗力を分解（N と f） */
  if (compOn) {
    arrow(ctx, cp.x, cp.y, cp.x, cp.y - Lg, 'comp', 1, COL.norm);
    if (Lf > 3) arrow(ctx, cp.x, cp.y, cp.x + Lf, cp.y, 'comp', 1, COL.fric);
    if (lab) {
      label(ctx, 'N', cp.x - 10, cp.y - Lg - 2, { size: sz, color: COL.norm });
      if (Lf > 8) label(ctx, 'f', cp.x + Lf + 8, cp.y - 9, { size: sz, color: COL.fric });
    }
  }
  if (baseOn) {                                                  /* 引く力（合成を出したら消える） */
    if (Lf > 2) {
      arrow(ctx, fp.x, fp.y, fp.x - Lf, fp.y, 'force', 1, COL.hand);
      if (lab) label(ctx, 'F', fp.x - Lf - 10, fp.y - 9, { size: sz, color: COL.hand });
    }
  }
  if (baseOn || mainOn) {
    NO_SHIFT = true;                                             /* ずらしは offP で自分でやる */
    if (baseOn) {
      arrow(ctx, cm.x, cm.y, cm.x, cm.y + Lg, 'force', 1, COL.force);
      if (lab) tipLabel(ctx, 'mg', cm.x, cm.y + Lg, 0, 1, { size: sz, color: COL.force });
    }
    if (mainOn && still) {
      arrow(ctx, cp.x + ox, cp.y + oy, cp.x + ox + Rx, cp.y + oy + Ry, 'force', 1, COL.norm);
      if (lab) _normOn = true;
    }
    NO_SHIFT = false;
  }
  /* ★「合力」と「抗力」の文字は、置く場所だけを入れかえる★
     （出す・出さないの条件と色は、それぞれの言葉のまま） */
  var pSum = { x: ix.x - Lf - 4, y: ix.y + Lg + 10 };      /* もとは「合力」を置いていた場所 */
  var pNorm = { x: cp.x + Rx + 6, y: cp.y + Ry - 10 };     /* もとは「抗力」を置いていた場所 */
  if (_normOn) label(ctx, '抗力', pSum.x, pSum.y, { size: sz, color: COL.norm, align: 'right' });
  if (_sumOn) label(ctx, '合力', pNorm.x, pNorm.y, { size: sz, color: '#8a5a2b', align: 'left' });
  if (still && (mainOn || compOn) && show.F) actPoint(ctx, cp.x, cp.y, COL.norm);   /* 抗力の作用点の● */
  return { cp: cp, fp: fp, ix: ix };
}

/* 矢印の先の「その先」に文字を置く。(x2,y2)＝矢じり、(ux,uy)＝矢印の向き。
   文字の幅ぶんだけ向きにそって外へずらすので、矢印と文字が重ならない。 */
var _labClip = null;          /* 枠の外に出る文字は書かない（ズームアップの枠で使う） */
function tipLabel(ctx, text, x2, y2, ux, uy, opt) {
  opt = opt || {};
  if (_labClip && (x2 < _labClip.x0 + 6 || x2 > _labClip.x1 - 6 || y2 < _labClip.y0 + 6 || y2 > _labClip.y1 - 20)) return;
  var size = opt.size || 12.5;
  ctx.save(); ctx.font = (opt.bold ? 'bold ' : '') + size + 'px ' + FONT;
  var tw = ctx.measureText(String(text).replace(/_\{?[^}]*\}?/g, 'x')).width;
  ctx.restore();
  var off = (opt.gap || 6) + Math.abs(ux) * tw / 2 + Math.abs(uy) * size * 0.6;
  label(ctx, text, x2 + ux * off + (opt.dx || 0), y2 + uy * off + (opt.dy || 0), { size: size, color: opt.color, bold: opt.bold });
}

/* 力の作用点の印（小さな●）。矢印を横へずらしても、作用点そのものは正しく見える */
function actPoint(ctx, x, y, col) {
  ctx.save();
  ctx.beginPath(); ctx.arc(x, y, 2.6, 0, Math.PI * 2);
  ctx.fillStyle = col || COL.norm; ctx.fill();
  ctx.strokeStyle = '#fff'; ctx.lineWidth = 0.9; ctx.stroke();
  ctx.restore();
}

/* 判定の吹き出しをまとめて置く。近い箱どうしで重なるときは、あとのものを上へ積む。
   list = [{ kind, x, y }]（x, y はしっぽの先）、size … 文字の大きさ */
function placeVerdicts(ctx, list, size, region, obst) {
  size = size || 14;
  obst = obst || [];
  var placed = [], i, j;
  var sorted = list.slice().sort(function (a, b) { return a.x - b.x; });
  ctx.save(); ctx.font = 'bold ' + size + 'px ' + FONT;
  for (i = 0; i < sorted.length; i++) {
    var it = sorted[i], txt = it.kind === 'tip' ? '傾いた！' : 'すべった！';
    var w = ctx.measureText(txt).width + 18, h = size + 14, T = 8;
    var x0lim = region ? region.x0 + w / 2 + 2 : -1e9, x1lim = region ? region.x0 + region.w - w / 2 - 2 : 1e9;
    var x = region ? clamp(it.x, x0lim, x1lim) : it.x, y = it.y;
    /* ほかの吹き出しにも、物体（箱）にも重ならない置き場所をさがす。
       まず真上へ、それでもだめなら左右へずらす。しっぽの先だけは箱を指してよい */
    var topLim = region ? Math.max(region.y0 - 20, 3) : 3;   /* これより上（キャンバスの外）へは行かない */
    function clear(cx, cy) {
      var bx0 = cx - w / 2, bx1 = cx + w / 2, by0 = cy - h, by1 = cy, k;   /* 吹き出しの枠（しっぽは含めない） */
      for (k = 0; k < placed.length; k++) {
        var q = placed[k];
        if (bx0 < q.x1 + 2 && bx1 > q.x0 - 2 && by0 < q.y1 + 2 && by1 > q.y0 - 2) return false;
      }
      for (k = 0; k < obst.length; k++) {
        var r2 = obst[k];
        if (bx0 < r2.x1 + 3 && bx1 > r2.x0 - 3 && by0 < r2.y1 + 3 && by1 > r2.y0 - 3) return false;
      }
      return true;
    }
    var found = false, dxs = [0, -24, 24, -48, 48, -72, 72, -96, 96, -130, 130], di, yy;
    for (di = 0; di < dxs.length && !found; di++) {
      var cx2 = region ? clamp(it.x + dxs[di], x0lim, x1lim) : it.x + dxs[di];
      for (yy = it.y; yy - h >= topLim; yy -= 6) {
        if (clear(cx2, yy)) { x = cx2; y = yy; found = true; break; }
      }
    }
    if (!found && region) y = Math.max(y, topLim + h);
    placed.push({ x0: x - w / 2, x1: x + w / 2, y0: y - h, y1: y });
    if (window.__vbLog) window.__vbLog.push({ b: placed[placed.length - 1], o: obst });   /* テスト用 */
    verdictBubble(ctx, it.kind, x, y, 'down', size, it.x);
  }
  ctx.restore();
}

/* 点の並び（画面座標）を囲む四角。吹き出しをよけさせるのに使う */
function bboxOf(pts) {
  var x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
  pts.forEach(function (p) {
    if (p.x < x0) x0 = p.x; if (p.x > x1) x1 = p.x;
    if (p.y < y0) y0 = p.y; if (p.y > y1) y1 = p.y;
  });
  return { x0: x0, y0: y0, x1: x1, y1: y1 };
}
/* 箱（drawTiltBox などが返す g）の 4 すみ */
function gCorners(g) { return [g.pt(0, 0), g.pt(g.w, 0), g.pt(0, g.h), g.pt(g.w, g.h)]; }

/* 判定の吹き出し（傾いた！／すべった！）。(x, y) はしっぽの先＝箱を指す点 */
function verdictBubble(ctx, kind, x, y, side, size, tailX) {
  var o = { side: side || 'up', size: size || 14 };
  if (tailX !== undefined) o.dx = 0;
  if (kind === 'tip') { o.bg = '#fde2dc'; o.border = '#d1352b'; o.color = '#9b2418'; bubble(ctx, '傾いた！', x, y, o); }
  else if (kind === 'slip') { o.bg = '#dff2ee'; o.border = '#0f8a8a'; o.color = '#0a5c5c'; bubble(ctx, 'すべった！', x, y, o); }
}

/* 角 θ の印（水平の破線＋弧）。(x,y) は板の回転軸
   opt.fixed … θ が小さくても読めるように、文字を弧の外の決まった場所に置く */
function thetaMark(ctx, x, y, thDeg, r, text, opt) {
  opt = opt || {};
  ctx.save();
  ctx.strokeStyle = COL.sub; ctx.lineWidth = 1; ctx.setLineDash([4, 3]);
  ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + r + 26, y); ctx.stroke();
  ctx.restore();
  if (opt.fixed) {
    if (thDeg > 0.3) {
      ctx.save();
      ctx.strokeStyle = opt.color || '#3d4c5a'; ctx.lineWidth = 1.6;
      ctx.beginPath(); ctx.arc(x, y, r, -thDeg * DEG, 0); ctx.stroke();
      ctx.restore();
    }
    if (text) label(ctx, text, x + r + 10, y + 15, { size: opt.size || 13, bold: true,
      color: opt.color || '#3d4c5a', align: 'left', avoid: false });
    return;
  }
  if (thDeg > 0.5) angArc(ctx, x, y, r, 0, -thDeg * DEG, text, -(thDeg / 2 + 14) * DEG, r + 18);
  else if (text) label(ctx, text, x + r + 16, y - 10, { size: 12.5, color: COL.sub });
}

/* つる巻きばね（横向き）。(x1,y1)→(x2,y2)。opt = { coils, r, color, lw, lead } */
function springShape(ctx, x1, y1, x2, y2, opt) {
  opt = opt || {};
  var coils = opt.coils || 9, r = opt.r || 9, lead = opt.lead || 12;
  var dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy) || 1, ux = dx / L, uy = dy / L, nx = -uy, ny = ux;
  var inner = Math.max(4, L - 2 * lead), seg = inner / (coils * 2);
  ctx.save();
  ctx.strokeStyle = opt.color || '#5a6470'; ctx.lineWidth = opt.lw || 2; ctx.lineJoin = 'round';
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  var px = x1 + ux * lead, py = y1 + uy * lead;
  ctx.lineTo(px, py);
  for (var i = 0; i < coils * 2; i++) {
    var sgn = (i % 2 === 0) ? 1 : -1;
    px += ux * seg; py += uy * seg;
    ctx.lineTo(px + nx * r * sgn, py + ny * r * sgn);
  }
  ctx.lineTo(x2 - ux * lead, y2 - uy * lead);
  ctx.lineTo(x2, y2);
  ctx.stroke();
  ctx.restore();
}

/* ===== 値の表（図の下に出す「各箱の a:b …」） =====
   x0, y0 … 左上、w … 幅、cols … 見出しの列（[{name, sub, hot}]）、
   rows … [{label, sub, cells:[{t, color, bold}]}]、opt = { labelW, rowH, headH } */
function valueTable(ctx, x0, y0, w, cols, rows, opt) {
  opt = opt || {};
  var labelW = opt.labelW || 150, rowH = opt.rowH || 17, headH = opt.headH || 22;
  var n = cols.length, cw = (w - labelW) / n, i, j;
  var totalH = headH + rows.reduce(function (a, r) { return a + (r.sub ? rowH * 1.7 : rowH); }, 0);
  ctx.save();
  /* 地 */
  ctx.fillStyle = '#fff';
  ctx.fillRect(x0, y0, w, totalH);
  /* 見出しの行 */
  ctx.fillStyle = '#eef3f8';
  ctx.fillRect(x0, y0, w, headH);
  /* 操作対象の列を目立たせる */
  for (i = 0; i < n; i++) if (cols[i].hot) {
    ctx.fillStyle = 'rgba(251,234,166,.45)';
    ctx.fillRect(x0 + labelW + cw * i, y0, cw, totalH);
  }
  /* わく線 */
  ctx.strokeStyle = '#cfd8e0'; ctx.lineWidth = 1;
  ctx.strokeRect(x0 + 0.5, y0 + 0.5, w - 1, totalH - 1);
  ctx.beginPath();
  ctx.moveTo(x0, y0 + headH); ctx.lineTo(x0 + w, y0 + headH);
  var yy = y0 + headH;
  for (j = 0; j < rows.length; j++) {
    yy += rows[j].sub ? rowH * 1.7 : rowH;
    ctx.moveTo(x0, yy); ctx.lineTo(x0 + w, yy);
  }
  for (i = 0; i <= n; i++) { ctx.moveTo(x0 + labelW + cw * i, y0); ctx.lineTo(x0 + labelW + cw * i, y0 + totalH); }
  ctx.stroke();
  ctx.restore();
  /* 見出し */
  for (i = 0; i < n; i++) {
    var hx = x0 + labelW + cw * i + cw / 2;
    label(ctx, cols[i].name, hx, y0 + (cols[i].sub ? 8 : headH / 2), { size: 11.5, bold: true, color: cols[i].hot ? '#8a6d00' : COL.ink });
    if (cols[i].sub) label(ctx, cols[i].sub, hx, y0 + 17, { size: 9.5, color: cols[i].hot ? '#8a6d00' : COL.sub });
  }
  if (opt.corner) label(ctx, opt.corner, x0 + 7, y0 + headH / 2, { size: 11, bold: true, color: COL.ink, align: 'left' });   /* 左上：「各箱の 幅a:高さb」 */
  /* 中身 */
  var y = y0 + headH;
  rows.forEach(function (r) {
    var h = r.sub ? rowH * 1.7 : rowH;
    if (r.sub) {
      label(ctx, r.label, x0 + 7, y + h / 2 - 7, { size: 10, color: COL.sub, align: 'left' });
      label(ctx, r.sub, x0 + 7, y + h / 2 + 7, { size: 10, color: COL.sub, align: 'left' });
    } else {
      label(ctx, r.label, x0 + 7, y + h / 2, { size: 10.5, color: COL.sub, align: 'left' });
    }
    r.cells.forEach(function (c, k) {
      label(ctx, c.t, x0 + labelW + cw * k + cw / 2, y + h / 2,
        { size: 11, bold: !!c.bold, color: c.color || COL.ink });
    });
    y += h;
  });
  return totalH;
}

