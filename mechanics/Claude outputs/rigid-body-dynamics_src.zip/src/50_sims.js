/* ===== 50_sims.js ===== */
/* 3 つのシミュレーションの定義（DEFS['r1'] 〜 DEFS['r3']） */
'use strict';

/* ============ 共通：操作対象の箱の絵の縮尺と、力の縮尺 ============ */
var ZS = 480;                        /* [px/m] ズームアップ・側面図の縮尺（0.32 m → 154 px） */
var FS = FL / (P.box.M * G);         /* [px/N] 力の縮尺（mg → FL px） */
var TGT = { fill: '#fbeaa6', line: '#8a6d00' };   /* 操作対象の箱の色（黄。力の色は使わない） */

/* ============ r1  板の角度を変える・箱の左下は板に固定（3 次元） ============ */
var R1 = {
  PL: 1.24, PW: 0.40, PT: 0.03,                   /* 板の長さ・幅・厚み [m] */
  BX0: -0.14, BX1: 1.48, BY: 0.30, BT: 0.05,      /* 下の平面（台）の広さと厚み [m] */
  POS: [0.06, 0.20, 0.42, 0.88],                  /* 操作対象は左の箱から 4:4 の半分ぶん離す */                  /* 各箱の下側の角の位置（板にそって）[m] */
  FIXED: ['2:8', '4:4', '8:2'],                   /* 左の 3 つ（面積は同じ） */
  THMAX: 90,
  BAND: 120                                       /* 「各箱の a:b」の表の高さ [px] */
};

/* 操作対象が大きい箱（1:16・16:1）のときは、板と台をのばして、箱がはみ出さないようにする。
   板の長さが変わるので図の大きさも変わるが、θ を動かしても変わらないことは保たれる。 */
/* ズームアップ枠の縮尺。大きい箱（1:16・16:1）でも枠に入るように小さくする */
function zoomScale(dm, fr) {
  var d = Math.hypot(dm.a, dm.b);
  return Math.min(ZS, (fr.h - 70) / Math.max(1e-6, d), (fr.w - 90) / Math.max(1e-6, d));
}

function plateGeom(R, s) {
  var dmT = P.box.dims(s.ab);
  var PL = Math.max(R.PL, R.POS[3] + dmT.a + 0.04);
  return { PL: PL, BX1: Math.max(R.BX1, PL + 0.24), hMax: Math.max(0.32, dmT.b), dmT: dmT };
}

/* 板の上の箱の一覧（左から 3 つ＋操作対象） */
function r1Boxes(s) {
  var v = V(s);
  var list = R1.FIXED.map(function (k) { return P.box.dims(k); });
  list.push(P.box.dims(s.ab));
  return list.map(function (dm, i) {
    var stt = P.tilt.state(dm.a, dm.b, 0, v.th, true);
    return { dm: dm, s: R1.POS[i], stt: stt, tip: stt.tip ? P.tilt.tipAngle(v.th, stt.th0) : 0, target: i === 3 };
  });
}

/* 3 次元 → 画面。姉妹ページの mk3d と同じ正射影（az・el で見回す）。
   d は「手前ほど大きい」奥行き。visible(normal) で面の表裏が分かる。 */
function mkProj(az, el, S, cx, cy) {
  var ca = Math.cos(az), sa = Math.sin(az), ce = Math.cos(el), se = Math.sin(el);
  return {
    p: function (q) {
      var x1 = q[0] * ca - q[1] * sa, y1 = q[0] * sa + q[1] * ca;
      return { x: cx + x1 * S, y: cy - (q[2] * ce - y1 * se) * S, d: y1 * ce + q[2] * se };
    },
    view: [sa * ce, ca * ce, se],
    S: S
  };
}

/* 板の座標（x：板にそって、y：横、z：板に垂直）→ 世界座標。θ で持ち上げる（回転軸＝y 軸） */
function plateToWorld(th) {
  var c = Math.cos(th), s = Math.sin(th);
  return function (x, y, z) { return [x * c - z * s, y, x * s + z * c]; };
}

/* 直方体の 6 面（外向き法線つき）。o＝原点、U・N・Y＝辺ベクトル（長さつき） */
function boxFaces(o, U, N, Y) {
  function add(p, q) { return [p[0] + q[0], p[1] + q[1], p[2] + q[2]]; }
  function neg(p) { return [-p[0], -p[1], -p[2]]; }
  var c = [];
  for (var i = 0; i < 8; i++) {
    var p = o.slice();
    if (i & 1) p = add(p, U);
    if (i & 2) p = add(p, N);
    if (i & 4) p = add(p, Y);
    c.push(p);
  }
  function unit(p) { var L = Math.hypot(p[0], p[1], p[2]) || 1; return [p[0] / L, p[1] / L, p[2] / L]; }
  var uU = unit(U), uN = unit(N), uY = unit(Y);
  return [
    { idx: [0, 1, 3, 2], n: neg(uY), kind: 'far' },      /* y=0 側 */
    { idx: [4, 5, 7, 6], n: uY, kind: 'near' },          /* y=Y 側 */
    { idx: [0, 1, 5, 4], n: neg(uN), kind: 'bottom' },
    { idx: [2, 3, 7, 6], n: uN, kind: 'top' },
    { idx: [0, 2, 6, 4], n: neg(uU), kind: 'left' },     /* 下側（回転軸の側） */
    { idx: [1, 3, 7, 5], n: uU, kind: 'right' }
  ].map(function (f) { return { pts: f.idx.map(function (k) { return c[k]; }), n: f.n, kind: f.kind }; });
}

/* 面を奥から順に塗る。grid＝2×2 の分割線、fills＝面の種類ごとの色 */
function drawFaces(ctx, pj, faces, fills, line, grid) {
  var list = faces.map(function (f) {
    var sp = f.pts.map(pj.p);
    var d = (sp[0].d + sp[1].d + sp[2].d + sp[3].d) / 4;
    var vis = f.n[0] * pj.view[0] + f.n[1] * pj.view[1] + f.n[2] * pj.view[2] > 1e-6;
    return { f: f, sp: sp, d: d, vis: vis };
  });
  list.sort(function (a, b) { return a.d - b.d; });
  list.forEach(function (it) {
    if (!it.vis) return;
    var sp = it.sp, k = it.f.kind;
    ctx.save();
    ctx.beginPath();
    sp.forEach(function (p, i) { if (i === 0) ctx.moveTo(p.x, p.y); else ctx.lineTo(p.x, p.y); });
    ctx.closePath();
    ctx.fillStyle = fills[k] || fills.top;
    ctx.fill();
    if (grid) {
      ctx.strokeStyle = BOXCOL.grid; ctx.lineWidth = 0.7;
      var i, t;
      for (i = 1; i < 2; i++) {
        t = i / 2;
        var a1 = lerpP(sp[0], sp[1], t), b1 = lerpP(sp[3], sp[2], t);
        ctx.beginPath(); ctx.moveTo(a1.x, a1.y); ctx.lineTo(b1.x, b1.y); ctx.stroke();
        var a2 = lerpP(sp[0], sp[3], t), b2 = lerpP(sp[1], sp[2], t);
        ctx.beginPath(); ctx.moveTo(a2.x, a2.y); ctx.lineTo(b2.x, b2.y); ctx.stroke();
      }
    }
    /* 輪郭（分割線のあとに描くので、面の path を作り直す） */
    ctx.beginPath();
    sp.forEach(function (p, i) { if (i === 0) ctx.moveTo(p.x, p.y); else ctx.lineTo(p.x, p.y); });
    ctx.closePath();
    ctx.strokeStyle = line; ctx.lineWidth = 1.2; ctx.lineJoin = 'round';
    ctx.stroke();
    ctx.restore();
  });
}
function lerpP(p, q, t) { return { x: p.x + (q.x - p.x) * t, y: p.y + (q.y - p.y) * t }; }

/* 蝶つがい（ちょうつがい）：回転軸の辺（奥 a → 手前 b）にそって、筒（ナックル）を並べて描く。
   軸のまわりに回ることが一目で分かるよう、両はしに丸い軸受けも描く。 */
function hinge3d(ctx, a, b, n) {
  var dx = b.x - a.x, dy = b.y - a.y, L = Math.hypot(dx, dy) || 1, ux = dx / L, uy = dy / L;
  var w = Math.max(2.4, Math.min(4.2, L * 0.13));                /* 筒の太さ（見た目） */
  ctx.save();
  ctx.lineCap = 'butt';
  for (var i = 0; i < n; i++) {                                  /* 筒を n 個ならべる */
    var t0 = i / n + 0.06 / n, t1 = (i + 1) / n - 0.06 / n;
    var p0 = { x: a.x + dx * t0, y: a.y + dy * t0 }, p1 = { x: a.x + dx * t1, y: a.y + dy * t1 };
    ctx.strokeStyle = (i % 2 === 0) ? '#5b6b7b' : '#93a3b3';     /* 交互の色で「筒の連なり」に見せる */
    ctx.lineWidth = w;
    ctx.beginPath(); ctx.moveTo(p0.x, p0.y); ctx.lineTo(p1.x, p1.y); ctx.stroke();
  }
  ctx.strokeStyle = 'rgba(255,255,255,.75)'; ctx.lineWidth = 0.9;   /* 上のハイライト */
  ctx.beginPath();
  ctx.moveTo(a.x - uy * w * 0.28, a.y + ux * w * 0.28);
  ctx.lineTo(b.x - uy * w * 0.28, b.y + ux * w * 0.28);
  ctx.stroke();
  [a, b].forEach(function (p) {                                   /* 両はしの軸受け */
    ctx.beginPath(); ctx.arc(p.x, p.y, w * 0.62, 0, Math.PI * 2);
    ctx.fillStyle = '#fff'; ctx.strokeStyle = '#3b4652'; ctx.lineWidth = 1.2;
    ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.arc(p.x, p.y, w * 0.2, 0, Math.PI * 2);
    ctx.fillStyle = '#3b4652'; ctx.fill();
  });
  ctx.restore();
}

/* 点が多角形の中か、ふちから d px 以内か */
function nearPoly(x, y, poly, d) {
  if (inPoly(x, y, poly)) return true;
  for (var i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    var ax = poly[j].x, ay = poly[j].y, bx = poly[i].x, by = poly[i].y;
    var vx = bx - ax, vy = by - ay, L2 = vx * vx + vy * vy || 1;
    var t = clamp(((x - ax) * vx + (y - ay) * vy) / L2, 0, 1);
    if (Math.hypot(x - (ax + vx * t), y - (ay + vy * t)) <= d) return true;
  }
  return false;
}
/* 点が多角形の中にあるか */
function inPoly(x, y, poly) {
  var ins = false, i, j;
  for (i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    var xi = poly[i].x, yi = poly[i].y, xj = poly[j].x, yj = poly[j].y;
    if (((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi)) ins = !ins;
  }
  return ins;
}

/* r1 の 3 次元の場面を描く。region … { x0, y0, w, h } */
function drawR1Scene(ctx, s, region) {
  var v = V(s), th = v.th * DEG;
  var boxes = r1Boxes(s);
  var az = s.cam.az * DEG, el = s.cam.el * DEG;
  var W2P = plateToWorld(th);
  /* --- 縮尺：θ を 0〜90° まで振っても入るように決める（θ を変えても図の大きさが変わらない） --- */
  var pj0 = mkProj(az, el, 1, 0, 0);
  var bx0 = Infinity, bx1 = -Infinity, by0 = Infinity, by1 = -Infinity;
  function take(q) { var p = pj0.p(q); bx0 = Math.min(bx0, p.x); bx1 = Math.max(bx1, p.x); by0 = Math.min(by0, p.y); by1 = Math.max(by1, p.y); }
  var k, i;
  var PG = plateGeom(R1, s), yD = P.box.DEPTH / 2;
  for (k = 0; k <= R1.THMAX; k += 10) {
    var W2 = plateToWorld(k * DEG);
    [[0, -R1.PW / 2, -R1.PT], [0, R1.PW / 2, -R1.PT], [PG.PL, -R1.PW / 2, -R1.PT], [PG.PL, R1.PW / 2, -R1.PT],
      [0, -R1.PW / 2, 0], [0, R1.PW / 2, 0], [PG.PL, -R1.PW / 2, 0], [PG.PL, R1.PW / 2, 0]].forEach(function (q) { take(W2(q[0], q[1], q[2])); });
    boxes.forEach(function (b, bi) {           /* 箱は、それぞれの本当の大きさで振る */
      var sp = R1.POS[bi], aa = b.dm.a, bb = b.dm.b;
      [[sp, -yD, bb], [sp, yD, bb], [sp + aa, -yD, bb], [sp + aa, yD, bb]].forEach(function (q) { take(W2(q[0], q[1], q[2])); });
    });
  }
  [[R1.BX0, -R1.BY, -R1.PT - R1.BT], [PG.BX1, -R1.BY, -R1.PT - R1.BT], [R1.BX0, R1.BY, -R1.PT - R1.BT], [PG.BX1, R1.BY, -R1.PT - R1.BT],
    [R1.BX0, -R1.BY, -R1.PT], [PG.BX1, -R1.BY, -R1.PT], [R1.BX0, R1.BY, -R1.PT], [PG.BX1, R1.BY, -R1.PT]].forEach(take);   /* 下の平面（台） */
  var mg = 14;
  var S = Math.min((region.w - 2 * mg) / Math.max(1e-6, bx1 - bx0), (region.h - 2 * mg) / Math.max(1e-6, by1 - by0)) * s.cam.zoom;
  /* 横は左づめ（右のズームアップ枠を、図のすぐ右に置けるように）。狭い画面では中央 */
  var cx = s._narrow ? (region.x0 + region.w / 2 - S * (bx0 + bx1) / 2) : (region.x0 + mg - S * bx0);
  var cy = region.y0 + region.h / 2 - S * (by0 + by1) / 2;
  var pj = mkProj(az, el, S, cx, cy);
  var PJ = function (q) { return pj.p(q); };

  /* --- 下の平面（水平な台）。板は θ=0 のときこの上にぴったり乗る --- */
  var yN = R1.PW / 2;
  var pv0 = PJ([0, yN, 0]);
  var baseFaces = boxFaces([R1.BX0, -R1.BY, -R1.PT - R1.BT], [PG.BX1 - R1.BX0, 0, 0], [0, 0, R1.BT], [0, 2 * R1.BY, 0]);
  drawFaces(ctx, pj, baseFaces, { top: '#e4e8ec', near: '#c9d0d7', far: '#c9d0d7', left: '#c9d0d7', right: '#c9d0d7', bottom: '#c9d0d7' }, '#8b949e', false);

  /* --- 板（厚みのある直方体） --- */
  var plateFaces = boxFaces(W2P(0, -yN, -R1.PT),
    W2P(PG.PL, 0, 0).map(function (c, j) { return c - W2P(0, 0, 0)[j]; }),
    W2P(0, 0, R1.PT).map(function (c, j) { return c - W2P(0, 0, 0)[j]; }),
    [0, R1.PW, 0]);
  drawFaces(ctx, pj, plateFaces, { top: BOXCOL.plate, near: BOXCOL.plate2, far: BOXCOL.plate2, left: '#cfc4a3', right: '#cfc4a3', bottom: '#cfc4a3' }, BOXCOL.plateLine, false);
  /* 板の上の面（ドラッグの当たり判定用に覚えておく） */
  s._plate = [W2P(0, -yN, 0), W2P(PG.PL, -yN, 0), W2P(PG.PL, yN, 0), W2P(0, yN, 0)].map(PJ);
  /* ドラッグの当たり判定：板の上の面・手前の面・（あとで）箱の面もまとめて */
  s._plateHit = [s._plate, [W2P(0, yN, 0), W2P(PG.PL, yN, 0), W2P(PG.PL, yN, -R1.PT), W2P(0, yN, -R1.PT)].map(PJ)];

  /* --- θ の印（板の手前のはし、回転軸のまわり） --- */
  (function () {
    var r = 0.30;
    var h0 = PJ([0, yN, 0]), h1 = PJ([r + 0.16, yN, 0]);
    ctx.save(); ctx.strokeStyle = COL.sub; ctx.lineWidth = 1; ctx.setLineDash([4, 3]);
    ctx.beginPath(); ctx.moveTo(h0.x, h0.y); ctx.lineTo(h1.x, h1.y); ctx.stroke();
    ctx.setLineDash([]); ctx.lineWidth = 1.3;
    ctx.beginPath();
    for (i = 0; i <= 16; i++) {
      var aa = th * i / 16, q = PJ([r * Math.cos(aa), yN, r * Math.sin(aa)]);
      if (i === 0) ctx.moveTo(q.x, q.y); else ctx.lineTo(q.x, q.y);
    }
    ctx.stroke(); ctx.restore();
    var ql = PJ([0.42, yN, -R1.PT - R1.BT - 0.02]);          /* 台の手前の下（箱や蝶つがいとぶつからない） */
    label(ctx, 'θ = ' + fmt(v.th, 0) + '°', ql.x, ql.y + 10, { size: 12, color: COL.sub, align: 'left', avoid: true });
  })();

  /* --- 箱（奥から順に） --- */
  var items = boxes.map(function (b, idx) {
    var al = th + b.tip * DEG;
    var U = [Math.cos(al) * b.dm.a, 0, Math.sin(al) * b.dm.a];
    var N = [-Math.sin(al) * b.dm.b, 0, Math.cos(al) * b.dm.b];
    var Y = [0, P.box.DEPTH, 0];
    var o = W2P(b.s, -P.box.DEPTH / 2, 0);
    var faces = boxFaces(o, U, N, Y);
    var cw = [o[0] + U[0] / 2 + N[0] / 2, o[1] + P.box.DEPTH / 2, o[2] + U[2] / 2 + N[2] / 2];
    return { b: b, faces: faces, o: o, U: U, N: N, Y: Y, cw: cw, d: PJ(cw).d, idx: idx };
  });
  items.sort(function (a, b) { return a.d - b.d; });
  var fills = { top: BOXCOL.fill, near: BOXCOL.fill2, far: BOXCOL.fill2, left: BOXCOL.fill3, right: BOXCOL.fill3, bottom: BOXCOL.fill3 };
  var tfills = { top: '#fbeaa6', near: '#f1d97a', far: '#f1d97a', left: '#dcc25c', right: '#dcc25c', bottom: '#dcc25c' };
  items.forEach(function (it) {
    drawFaces(ctx, pj, it.faces, it.b.target ? tfills : fills, it.b.target ? '#8a6d00' : BOXCOL.line, s.o.showGrid);
    it.faces.forEach(function (f) { s._plateHit.push(f.pts.map(PJ)); });   /* 箱をつかんでも θ が変わる */
    /* 箱の蝶つがい：下側の辺（回転軸）にそって、箱の外がわへ少しずらして描く */
    var uo = 0.013 / Math.max(1e-6, it.b.dm.a);                 /* 辺の長さに対する割合 */
    var hA = [it.o[0] - it.U[0] * uo, it.o[1], it.o[2] - it.U[2] * uo];
    var hB = [hA[0] + it.Y[0], hA[1] + it.Y[1], hA[2] + it.Y[2]];
    hinge3d(ctx, PJ(hA), PJ(hB), 3);
  });
  /* 板の蝶つがい（左端の辺ぜんたい） */
  hinge3d(ctx, PJ(W2P(-0.012, -yN, 0)), PJ(W2P(-0.012, yN, 0)), 5);

  /* --- 力（操作対象の箱は濃く、ほかの箱は薄く。手前の面の上に描く） --- */
  var tgt = items.filter(function (it) { return it.b.target; })[0];
  if (s.o.showF || s.o.showL) {
    var rbox = { x0: region.x0, y0: region.y0, x1: region.x0 + region.w, y1: region.y0 + region.h };
    var Wb = plateToWorld(th);
    items.forEach(function (it) {
      /* 力は「箱の中心を通るたて線」の上に描く（手前の面ではなく、奥ゆきのまん中 y = 0） */
      var b = it.b, yF = 0;
      var cmW = [it.o[0] + it.U[0] / 2 + it.N[0] / 2, yF, it.o[2] + it.U[2] / 2 + it.N[2] / 2];
      var cmP = PJ(cmW);
      var Lg = P.box.M * G * FS * 0.62;                       /* 3 次元の図では少し短く（ズーム側が本番） */
      var sR = P.tilt.contact(b.dm.a, b.dm.b, v.th);
      var cpP = PJ(Wb(b.s + sR, yF, 0));
      /* 重力と抗力を横へずらす量は、作用点が回転軸からどれだけ離れているかに比例。
         傾く瞬間（作用点が回転軸に一致）には 0 になり、2 本がぴたりと重なる */
      var offR = 5.5 * clamp(sR / Math.max(1e-6, b.dm.a / 2), 0, 1);
      var tipped = b.stt.tip && b.tip > 0.01;
      var downP = PJ([cmW[0], cmW[1], cmW[2] - 1]);           /* 鉛直下向きの画面での向き */
      var ddx = downP.x - cmP.x, ddy = downP.y - cmP.y, dL = Math.hypot(ddx, ddy) || 1;
      ddx /= dL; ddy /= dL;
      var RL = 2 * Math.max(b.dm.a, b.dm.b) * S;
      ctx.save();
      if (!b.target) ctx.globalAlpha = 0.35;
      if (s.o.showL) {
        rayLine(ctx, cmP.x, cmP.y, ddx, ddy, COL.force, rbox, 1.3, RL);
        if (!tipped) rayLine(ctx, cpP.x + offR, cpP.y, -ddx, -ddy, COL.norm, rbox, 1.3, RL);
        else rayLine(ctx, cmP.x, cmP.y, -ddx, -ddy, fade(COL.force, .55), rbox, 1.3, RL);
      }
      if (s.o.showF && !s.o.showHide) {
        NO_SHIFT = true;                 /* ずらしは上の offR で自分でやる */
        arrow(ctx, cmP.x, cmP.y, cmP.x + ddx * Lg, cmP.y + ddy * Lg, 'force', 0.85, COL.force);
        if (b.target) label(ctx, 'mg', cmP.x + ddx * (Lg + 9), cmP.y + ddy * (Lg + 9), { size: 11, color: COL.force });
        if (!tipped) {
          arrow(ctx, cpP.x + offR, cpP.y, cpP.x + offR - ddx * Lg, cpP.y - ddy * Lg, 'force', 0.85, COL.norm);
          if (b.target) label(ctx, '抗力', cpP.x + offR - ddx * (Lg + 10), cpP.y - ddy * (Lg + 10), { size: 11, color: COL.norm });
        }
        NO_SHIFT = false;
      }
      if (!tipped && (s.o.showF || s.o.showL)) actPoint(ctx, cpP.x, cpP.y, COL.norm);
      ctx.restore();
    });
  }

  /* --- 傾いた！（傾いた箱の上に） --- */
  var vl = [];
  items.forEach(function (it) {
    var kind = (it.b.stt.tip && it.b.tip > 0.01) ? 'tip' : null;
    if (!verdictAlive(s, 'b' + it.idx, kind)) return;
    var top = PJ([it.o[0] + it.U[0] / 2 + it.N[0], it.o[1] + it.Y[1] / 2, it.o[2] + it.U[2] / 2 + it.N[2]]);
    vl.push({ kind: 'tip', x: top.x, y: top.y - 4 });
  });
  var obst1 = items.map(function (it) {
    var ps = [];
    it.faces.forEach(function (f) { f.pts.forEach(function (q) { ps.push(PJ(q)); }); });
    return bboxOf(ps);
  });
  placeVerdicts(ctx, vl, 12, region, obst1);

  /* --- 各箱の a:b（図の下の表） --- */
  if (s.o.showAB) {
    var tx0 = 6, tw = CVW - 12, tby = region.y0 + region.h + 12;
    var cols = boxes.map(function (b) {
      return { name: b.dm.key, sub: b.target ? '操作対象' : null, hot: !!b.target };
    });
    var rows = [
      { label: '幅 a［m］', cells: boxes.map(function (b) { return { t: fmt(b.dm.a, 2) }; }) },
      { label: '高さ b［m］', cells: boxes.map(function (b) { return { t: fmt(b.dm.b, 2) }; }) },
      { label: 'a / b', cells: boxes.map(function (b) { return { t: fmt(b.dm.a / b.dm.b, 2), bold: true }; }) },
      { label: 'tanθ₀ = a/b を満たす', sub: '傾く角 θ₀', cells: boxes.map(function (b) {
        return { t: fmt(b.stt.th0, 1) + '°', bold: b.stt.tip, color: b.stt.tip ? '#9b2418' : COL.ink }; }) }
    ];
    /* 箱から表の列へ、うすい引き出し線 */
    var cwid = (tw - 150) / 4;
    boxes.forEach(function (b, j) {
      var it = items.filter(function (q) { return q.idx === j; })[0];
      var base = PJ([it.o[0] + it.U[0] / 2, it.o[1] + it.Y[1] / 2, it.o[2] + it.U[2] / 2]);
      var x = tx0 + 150 + cwid * j + cwid / 2;
      ctx.save(); ctx.strokeStyle = 'rgba(90,100,110,.35)'; ctx.lineWidth = 1; ctx.setLineDash([2, 3]);
      ctx.beginPath(); ctx.moveTo(base.x, base.y + 4); ctx.lineTo(x, tby - 2); ctx.stroke(); ctx.restore();
    });
    valueTable(ctx, tx0, tby, tw, cols, rows, { labelW: 150, rowH: 17, headH: 24, corner: '各箱の 幅a:高さb' });
  }
  s._pj = { cx: cx, cy: cy, S: S };
  return { pj: pj, items: items, tgt: tgt, right: cx + S * bx1, left: cx + S * bx0 };
}

/* 側面図のズームアップ（r1）／本体（r2）で使う「板の上の箱」を描く。
   fr … 枠 { x0, y0, w, h }、pv … 回転軸の画面座標。pinned … r1（蝶つがいで固定）  */
function drawTiltBox(ctx, s, v, dm, stt, tipDeg, pv, fr, pinned, opt) {
  opt = opt || {};
  var S = opt.S || ZS, fs = opt.fs || FS;
  var box = { x0: fr.x0, y0: fr.y0, x1: fr.x0 + fr.w, y1: fr.y0 + fr.h };
  var slipShift = (!pinned && stt.slip) ? clamp((v.th - stt.thSlip) / 6, 0, 1) * 0.10 * S : 0;
  var u0 = { x: Math.cos(v.th * DEG), y: -Math.sin(v.th * DEG) };
  var pvb = { x: pv.x - u0.x * slipShift, y: pv.y - u0.y * slipShift };   /* すべった箱は下へずれる */
  var g = boxGeom(pvb, v.th, tipDeg, dm.a, dm.b, S);
  ctx.save();
  ctx.beginPath(); ctx.rect(box.x0, box.y0, fr.w, fr.h); ctx.clip();
  if (!opt.noPlate) {
    /* 面（板）：回転軸を通る直線。左→右に渡して側=1（ハッチは面の下） */
    var L1 = { x: pv.x - u0.x * 600, y: pv.y - u0.y * 600 }, L2 = { x: pv.x + u0.x * 600, y: pv.y + u0.y * 600 };
    hatchLine(ctx, L1.x, L1.y, L2.x, L2.y, 1);
    thetaMark(ctx, pv.x, pv.y, v.th, 52, 'θ = ' + fmt(v.th, 0) + '°', { fixed: true });
  }
  drawBoxSide(ctx, g, { grid: s.o.showGrid, fill: opt.fill, line: opt.line });
  if (pinned) pinMark(ctx, pv.x, pv.y, opt.pinR || 4.4);
  var r = null;
  if (opt.forces !== false) {
    var show = { F: s.o.showF, L: s.o.showL, Fc: s.o.showFc, Hide: s.o.showHide };
    _labClip = box;
    if (opt.faint) ctx.globalAlpha = 0.35;
    r = drawTiltForces(ctx, g, v, stt, show, box, fs, { size: opt.size || 12.5, lab: opt.lab });
    ctx.globalAlpha = 1;
    _labClip = null;
  }
  ctx.restore();
  return { g: g, r: r, pvb: pvb };
}

DEFS['r1'] = {
  id: 'r1', tab: '④-1　板の角度を変える（箱の左下は板に固定）',
  playRate: 5, playNote: 'スタートを押すと θ が 0° からだんだん大きくなる',
  title: '④-1　板の角度を変える　～箱の左下は板に蝶つがいで固定～',
  sub: '板の左端と、それぞれの箱の左下の角を<b>蝶つがい（○）</b>で板に固定してある（蝶つがいの点を軸に回る）。だから箱はすべらず、<b>傾くかどうか</b>だけが問題になる。' +
    '左の 3 つの箱は面積が同じで形だけがちがう。<b>右端が操作対象の箱</b>（右の枠にズームアップ）。',
  cw: function (v, s) { return (s && s._narrow) ? 480 : ((s && s._short) ? 640 : 780); },
  ch: function (v, s) { return (s && s._narrow ? 290 + 336 : ((s && s._short) ? 268 : 290)) + (s && s.o.showAB ? R1.BAND : 0); },
  cvNote: '<span class="gact">ドラッグ</span>：視点を回す／<span class="gact">板や箱をドラッグ</span>：θ を変える', tick2: false,
  /* 再生：操作対象が傾きはじめて 5° 進んだところで止める */
  playStop: function (v) { var dm = P.box.dims(v.ab); return P.tilt.th0(dm.a, dm.b) + 5; },
  moment: { label: '傾く瞬間をスローで', dur: 4.0, range: function (v) { var dm = P.box.dims(v.ab), th0 = P.tilt.th0(dm.a, dm.b); return { k: 'th', from: Math.max(0, th0 - 5), to: Math.min(R1.THMAX, th0 + 5), hold: 0.8 }; } },
  cam3d: { az: -35, el: 25, zoom: 1 },
  drag3d: true,
  abDef: '4:4',
  vars: [
    { k: 'th', label: '板の角度 $\\theta$', unit: '°', min: 0, max: R1.THMAX, step: 1, dec: 0, def: 0,
      tick: function (v) { var dm = P.box.dims(v.ab), th0 = P.tilt.th0(dm.a, dm.b); return { at: th0, label: '傾く角 $\\theta_0 = ' + fmt(th0, 1) + '^\\circ$' }; } }
  ],
  vis: [
    { k: 'F', label: '力を表示', def: false },
    { k: 'L', label: '重力の作用線を表示', def: false },
    { k: 'Fc', label: '分解した力を表示', def: false },
    { k: 'Hide', label: '重力と抗力のベクトルを消す', def: false },
    { k: 'AB', label: '各箱の 幅a:高さb を表示', def: false },
    { k: 'Grid', label: '箱の分割線を表示', def: true }
  ],
  topActions: [
    { label: '斜め上から', fn: function (s) { s.cam.az = -35; s.cam.el = 25; s.cam.zoom = 1; }, is: function (v, s) { return camIs(s, -35, 25, 1); } },
    { label: '横から', glow: true,      /* 押してほしいので、押されるまで光らせる */
      fn: function (s) { s.cam.az = 0; s.cam.el = 0; s.cam.zoom = 1; }, is: function (v, s) { return camIs(s, 0, 0, 1); } }
  ],
  /* 板の上でドラッグ → θ を変える（それ以外は視点が回る） */
  dragDown: function (s, lx, ly) {                       /* 板や箱の上（と、そのふち 14px 以内）なら θ のドラッグ */
    if (!s._plateHit) return false;
    for (var i = 0; i < s._plateHit.length; i++) if (nearPoly(lx, ly, s._plateHit[i], 14)) return true;
    return false;
  },
  drag: function (s, lx, ly, dx, dy) {
    var cv = document.getElementById('mainCv'), r = cv.getBoundingClientRect();
    var k = (cv._cw || 780) / Math.max(1, r.width);
    s.v.th = clamp(Math.round(s.v.th - dy * k * 0.32), 0, R1.THMAX);
  },
  verdict: function (v) {
    var dm = P.box.dims(v.ab);
    var stt = P.tilt.state(dm.a, dm.b, 0, v.th, true);
    return { th0: +stt.th0.toFixed(3), tip: stt.tip, contact: +P.tilt.contact(dm.a, dm.b, v.th).toFixed(4) };
  },
  result: function (v, s) {
    var dm = P.box.dims(v.ab);
    var stt = P.tilt.state(dm.a, dm.b, 0, v.th, true);
    var items = [
      { k: '操作対象の箱', v: 'a = ' + fmt(dm.a, 2) + ' m，b = ' + fmt(dm.b, 2) + ' m（a/b = ' + fmt(dm.a / dm.b, 2) + '）' },
      { k: '$\\tan\\theta_0 = a/b$ を満たす<br>傾く角度 $\\theta_0$', v: fmt(stt.th0, 1) + '°', kbox: true },
      { k: 'いま', v: stt.tip ? '傾いた！（θ ≧ θ₀）' : 'まだ傾かない（θ < θ₀）', cls: stt.tip ? 'tip' : '' }
    ];
    var note = '';
    if (hintOn(s)) note = '蝶つがいで固定しているので、すべらない。' +
      (v.th > 0.5 && !stt.tip ? '抗力の作用点は回転軸から ' + fmt(P.tilt.contact(dm.a, dm.b, v.th) * 100, 1) + ' cm のところ。' : '');
    return { items: items, note: note };
  },
  draw: function (ctx, s, W, H) {
    var v = V(s);
    var band = s.o.showAB ? R1.BAND : 0;
    var nar = !!s._narrow;
    var region = nar ? { x0: 6, y0: 8, w: W - 12, h: 290 - 16 }
      : { x0: 6, y0: 8, w: s._short ? 300 : 470, h: H - 16 - band };
    var sc = drawR1Scene(ctx, s, region);
    /* ---- ズームアップ枠（操作対象の箱）。3 次元の図のすぐ右（あきを詰める）。狭い画面では下 ---- */
    var fx = clamp(Math.round(sc.right + 14), 240, W - 300);
    var fr = nar ? { x0: (W - 284) / 2, y0: 290 + band + 26, w: 284, h: 236 }
      : { x0: fx, y0: s._short ? 18 : 24, w: Math.min(350, W - fx - 6), h: s._short ? 226 : 236 };
    ctx.save();
    ctx.fillStyle = '#fbfcfd'; ctx.strokeStyle = '#8b949e'; ctx.lineWidth = 1.2; ctx.setLineDash([6, 4]);
    ctx.beginPath(); ctx.rect(fr.x0, fr.y0, fr.w, fr.h); ctx.fill(); ctx.stroke();
    ctx.restore();
    label(ctx, 'ズームアップ（操作対象の箱 幅a:高さb = ' + s.ab + '）', fr.x0 + fr.w / 2, fr.y0 - 11, { size: 12, bold: true, color: COL.ink2 || '#3d4c5a' });
    var b = sc.tgt.b;
    var pv = { x: fr.x0 + 104, y: fr.y0 + fr.h - 62 };
    var zS = zoomScale(b.dm, fr);
    var z = drawTiltBox(ctx, s, v, b.dm, b.stt, b.tip, pv, fr, true, { S: zS, fill: TGT.fill, line: TGT.line });
    label(ctx, '回転軸', pv.x - 26, pv.y + 26, { size: 11, color: COL.sub, align: 'right', avoid: true });
    var zk1 = (b.stt.tip && b.tip > 0.01) ? 'tip' : null;
    if (verdictAlive(s, 'zoom', zk1)) {
      var tp = z.g.pt(z.g.w / 2, z.g.h);
      var zty = bboxOf(gCorners(z.g)).y0;                     /* 箱のいちばん高いところより上に出す */
      verdictBubble(ctx, 'tip', clamp(tp.x, fr.x0 + 50, fr.x0 + fr.w - 50), Math.max(fr.y0 + 34, Math.min(tp.y, zty) - 6), 'down');
    }
    /* 枠の下：見どころ（動かしてから） */
    var ty = fr.y0 + fr.h + 12;
    if (hintOn(s) && !(s._short && s.o.showAB)) {
      if (b.stt.tip) {
        label(ctx, '重力の作用線が回転軸より左（外）に出ると、', fr.x0 + fr.w / 2, ty, { size: 11, color: '#9b2418' });
        label(ctx, '重力のモーメントで箱は回転する', fr.x0 + fr.w / 2, ty + 18, { size: 11, color: '#9b2418' });
      } else if (v.th > 0.5) {
        label(ctx, 'θ が大きいほど、抗力の作用点は', fr.x0 + fr.w / 2, ty, { size: 11, color: COL.ink2 || '#3d4c5a' });
        label(ctx, '回転軸のほうへ動いていく', fr.x0 + fr.w / 2, ty + 18, { size: 11, color: COL.ink2 || '#3d4c5a' });
      }
    } else {
      label(ctx, 'θ を変えて、力の作用点を見よう', fr.x0 + fr.w / 2, ty, { size: 11, color: COL.sub });
    }
    /* 図の左上：見方の説明 */
  }
};

/* ============ r2  板の角度を変える・箱は固定なし（真横から） ============ */
var R2 = { PL: 1.24, PT: 0.03, POS: [0.06, 0.20, 0.42, 0.88], FIXED: ['2:8', '4:4', '8:2'], THMAX: 90, BAND: 168,
  BX0: -0.14, BX1: 1.48, BT: 0.05,
  PADL: 0.24 };   /* いちばん左の箱が倒れても画面から出ないように、左に余裕をとる [m] */

function r2Boxes(s) {
  var v = V(s);
  var list = R2.FIXED.map(function (k) { return P.box.dims(k); });
  list.push(P.box.dims(s.ab));
  return list.map(function (dm, i) {
    var stt = P.tilt.state(dm.a, dm.b, v.mu, v.th, false);
    return { dm: dm, s: R2.POS[i], stt: stt, tip: stt.tip ? P.tilt.tipAngle(v.th, stt.th0) : 0, target: i === 3 };
  });
}

/* 真横から見た板と 4 つの箱。region の中に、θ を 0〜90° まで振っても入る縮尺で描く */
function drawR2Scene(ctx, s, region) {
  var v = V(s), th = v.th * DEG;
  var boxes = r2Boxes(s);
  /* 縮尺：板の長さ＋いちばん高い箱（0.32 m）が、横は 0°、たては 80° で入るように */
  var mg = 12;
  var PG = plateGeom(R2, s);
  var S = Math.min((region.w - 2 * mg) / (PG.BX1 - R2.BX0 + 0.1 + R2.PADL),
    (region.h - 2 * mg - 10) / (PG.PL * Math.sin(R2.THMAX * DEG) + PG.hMax + R2.PT + R2.BT));
  var pv = { x: region.x0 + mg + (R2.PADL - R2.BX0) * S, y: region.y0 + region.h - mg - (R2.PT + R2.BT) * S - 2 };
  var u = { x: Math.cos(th), y: -Math.sin(th) }, n = { x: -Math.sin(th), y: -Math.cos(th) };
  function pt(su, sn) { return { x: pv.x + u.x * su * S + n.x * sn * S, y: pv.y + u.y * su * S + n.y * sn * S }; }
  /* 下の平面（台） */
  ctx.save();
  ctx.fillStyle = '#e4e8ec'; ctx.strokeStyle = '#8b949e'; ctx.lineWidth = 1.2;
  ctx.beginPath(); ctx.rect(pv.x + R2.BX0 * S, pv.y + R2.PT * S, (PG.BX1 - R2.BX0) * S, R2.BT * S); ctx.fill(); ctx.stroke();
  ctx.restore();
  /* 板（厚みのある棒） */
  var c0 = pt(0, 0), c1 = pt(PG.PL, 0), c2 = pt(PG.PL, -R2.PT), c3 = pt(0, -R2.PT);
  ctx.save();
  ctx.fillStyle = BOXCOL.plate2; ctx.strokeStyle = BOXCOL.plateLine; ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.moveTo(c0.x, c0.y); ctx.lineTo(c1.x, c1.y); ctx.lineTo(c2.x, c2.y); ctx.lineTo(c3.x, c3.y); ctx.closePath();
  ctx.fill(); ctx.stroke();
  ctx.restore();
  s._plate = [c0, c1, c2, c3];
  s._pv = pv; s._S = S;
  thetaMark(ctx, pv.x, pv.y, v.th, 34, null);
  label(ctx, 'θ = ' + fmt(v.th, 0) + '°', pv.x + 64, pv.y + (R2.PT + R2.BT) * S + 12, { size: 12, color: COL.sub, align: 'left', avoid: true });
  /* 箱 */
  var fr = { x0: region.x0, y0: region.y0, w: region.w, h: region.h };
  var out = [];
  boxes.forEach(function (b) {
    var p0 = pt(b.s, 0);
    var z = drawTiltBox(ctx, s, v, b.dm, b.stt, b.tip, p0, fr, false,
      { S: S, noPlate: true, fill: b.target ? TGT.fill : null, line: b.target ? TGT.line : null,
        forces: true, faint: !b.target, lab: b.target, fs: FS * 0.6, size: 10.5 });
    out.push({ b: b, z: z, p0: p0 });
  });
  pinMark(ctx, pv.x, pv.y, 4.6);
  /* 判定の吹き出し */
  var vl = [];
  out.forEach(function (o, j) {
    var g = o.z.g, tp = g.pt(g.w / 2, g.h);
    var kind = (o.b.stt.tip && o.b.tip > 0.01) ? 'tip' : (o.b.stt.slip ? 'slip' : null);
    if (verdictAlive(s, 'b' + j, kind)) vl.push({ kind: kind, x: tp.x, y: tp.y - 4 });
  });
  placeVerdicts(ctx, vl, 12, region, out.map(function (o) { return bboxOf(gCorners(o.z.g)); }));
  /* 各箱の a:b と μ（図の下の表） */
  if (s.o.showAB) {
    var tx0 = 6, tw = CVW - 12, tby = region.y0 + region.h + 16;
    var cols2 = out.map(function (o) {
      return { name: o.b.dm.key, sub: o.b.target ? '操作対象' : null, hot: !!o.b.target };
    });
    var rows2 = [
      { label: '幅 a［m］', cells: out.map(function (o) { return { t: fmt(o.b.dm.a, 2) }; }) },
      { label: '高さ b［m］', cells: out.map(function (o) { return { t: fmt(o.b.dm.b, 2) }; }) },
      { label: 'a / b', cells: out.map(function (o) { return { t: fmt(o.b.dm.a / o.b.dm.b, 2), bold: true }; }) },
      { label: 'tanθ₀ = a/b を満たす', sub: '傾く角 θ₀', cells: out.map(function (o) {
        return { t: fmt(o.b.stt.th0, 1) + '°', bold: o.b.stt.tip, color: o.b.stt.tip ? '#9b2418' : COL.ink }; }) },
      { label: '静止摩擦係数 μ', cells: out.map(function () { return { t: fmt(v.mu, 2) }; }) },
      { label: 'μ = tanθ_s を満たす', sub: '摩擦角（すべる角）θ_s', cells: out.map(function (o) {
        return { t: fmt(o.b.stt.thSlip, 1) + '°', bold: o.b.stt.slip, color: o.b.stt.slip ? '#0a5c5c' : COL.ink }; }) }
    ];
    var cwid2 = (tw - 168) / 4;
    out.forEach(function (o, j2) {
      var base = o.z.g.pt(o.z.g.w / 2, 0);
      var x = tx0 + 168 + cwid2 * j2 + cwid2 / 2;
      ctx.save(); ctx.strokeStyle = 'rgba(90,100,110,.35)'; ctx.lineWidth = 1; ctx.setLineDash([2, 3]);
      ctx.beginPath(); ctx.moveTo(base.x, base.y + 3); ctx.lineTo(x, tby - 2); ctx.stroke(); ctx.restore();
    });
    valueTable(ctx, tx0, tby, tw, cols2, rows2, { labelW: 168, rowH: 17, headH: 24, corner: '各箱の 幅a:高さb' });
  }
  return { boxes: boxes, out: out, pv: pv, S: S, right: pv.x + PG.BX1 * S };
}

/* ＜考え方＞ ①床を傾けていく場合（4 コマ）。canvas に描き起こす */
function drawThinkTilt(cv) {
  var cols = (cv.clientWidth || 760) < 560 ? 2 : 4;          /* せまい画面では 2×2 */
  var PW = 190, PH = 236, W = PW * cols, H = PH * (4 / cols), ctx = prep(cv, W, H);
  var dm = P.box.dims('3:4'), th0 = P.tilt.th0(dm.a, dm.b);
  var panels = [
    { th: 0, tip: 0, ttl: '傾きがないとき', t1: '力も、力のモーメントも', t2: 'つりあっている' },
    { th: 18, tip: 0, ttl: '少し傾けたとき', t1: '板からの抗力の作用点は', t2: '中央からずれていく' },
    { th: th0, tip: 0, ttl: '傾く直前', t1: '抗力の作用点が回転軸に一致', t2: '＝重力の作用線が回転軸を通る', hot: true },
    { th: th0 + 6, tip: 22, ttl: '傾いた後', t1: '重力の作用線が底面を超えると', t2: '回転。モーメントはつりあわない' }
  ];
  var pw = PW, S = 300;
  panels.forEach(function (p, i) {
    var x0 = (i % cols) * pw, y0 = Math.floor(i / cols) * PH;
    var box = { x0: x0 + 2, y0: y0, x1: x0 + pw - 2, y1: y0 + PH - 42 };
    var v = { th: p.th, mu: 10 };
    var stt = P.tilt.state(dm.a, dm.b, 10, p.th, false);
    var pv = { x: x0 + 70, y: y0 + 140 };
    ctx.save(); ctx.beginPath(); ctx.rect(box.x0, box.y0, pw - 4, PH); ctx.clip();
    var u0 = { x: Math.cos(p.th * DEG), y: -Math.sin(p.th * DEG) };
    hatchLine(ctx, pv.x - u0.x * 300, pv.y - u0.y * 300, pv.x + u0.x * 300, pv.y + u0.y * 300, 1);
    var g = boxGeom(pv, p.th, p.tip, dm.a, dm.b, S);
    drawBoxSide(ctx, g, { grid: false });
    if (p.th > 0.5) axisMark(ctx, pv.x, pv.y, '回転軸', { dx: -10, dy: 16 });
    drawTiltForces(ctx, g, v, stt, { F: true, L: true, Fc: false }, box, FS * 0.7, { size: 11 });
    ctx.restore();
    label(ctx, p.ttl, x0 + pw / 2, y0 + 14, { size: 13, bold: true, color: p.hot ? '#9b2418' : COL.ink });
    label(ctx, p.t1, x0 + pw / 2, y0 + PH - 26, { size: 10.5, color: p.hot ? '#9b2418' : '#3d4c5a' });
    label(ctx, p.t2, x0 + pw / 2, y0 + PH - 12, { size: 10.5, color: p.hot ? '#9b2418' : '#3d4c5a' });
    ctx.save(); ctx.strokeStyle = '#dde3e8';
    if (i % cols > 0) { ctx.beginPath(); ctx.moveTo(x0, y0 + 6); ctx.lineTo(x0, y0 + PH - 6); ctx.stroke(); }
    if (i >= cols) { ctx.beginPath(); ctx.moveTo(x0 + 6, y0); ctx.lineTo(x0 + pw - 6, y0); ctx.stroke(); }
    ctx.restore();
  });
}

/* ＜解答＞(1) 作図による解法の図（教科書の図：対角線 AC が鉛直になる瞬間） */
function drawAnsFig(cv, thDeg, vis) {
  vis = vis || { F: true, Fc: false };
  var W = 340, H = 258, ctx = prep(cv, W, H);
  var dm = P.box.dims('3:4'), th0 = P.tilt.th0(dm.a, dm.b), S = 620;
  var th = (thDeg === undefined || thDeg === null) ? th0 : thDeg;
  var hit = Math.abs(th - th0) < 0.35;                          /* ちょうど傾く瞬間 */
  var pv = { x: 150, y: 206 };
  var u0 = { x: Math.cos(th * DEG), y: -Math.sin(th * DEG) };
  hatchLine(ctx, pv.x - u0.x * 170, pv.y - u0.y * 170, pv.x + u0.x * 210, pv.y + u0.y * 210, 1);
  var g = boxGeom(pv, th, 0, dm.a, dm.b, S);
  drawBoxSide(ctx, g, { grid: true, fill: hit ? '#fdf0d8' : '#fbf3ea' });
  var A = g.c[0], B = g.c[1], C = g.c[2], D = g.c[3];
  /* 対角線 AC（傾く瞬間に鉛直になる） */
  ctx.save();
  ctx.strokeStyle = hit ? '#9b2418' : '#3d4c5a'; ctx.lineWidth = hit ? 2 : 1.2; ctx.setLineDash([5, 4]);
  ctx.beginPath(); ctx.moveTo(A.x, A.y); ctx.lineTo(C.x, C.y); ctx.stroke();
  ctx.restore();
  /* A から下ろした鉛直の線（AC とくらべるための目印） */
  ctx.save();
  ctx.strokeStyle = 'rgba(120,132,145,.8)'; ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
  ctx.beginPath(); ctx.moveTo(A.x, A.y); ctx.lineTo(A.x, A.y - 150); ctx.stroke();
  ctx.restore();
  label(ctx, '鉛直線', A.x, A.y - 158, { size: 11, color: COL.sub, avoid: false });
  thetaMark(ctx, pv.x, pv.y, th, 86, 'θ');
  label(ctx, '水平線', pv.x + 116, pv.y + 12, { size: 11, color: COL.sub, align: 'left', avoid: false });
  if (hit) angArc(ctx, A.x, A.y, 42, -Math.PI / 2, -Math.PI / 2 - th * DEG, 'θ₀', -Math.PI / 2 - th * DEG / 2, 56);
  /* 重力 */
  /* 先に A・B・C・D を置いてから重力を描く（重力の文字が自動でよけてくれる） */
  label(ctx, 'A', A.x - 12, A.y + 8, { size: 13, bold: true });
  label(ctx, 'B', B.x + 10, B.y + 4, { size: 13, bold: true });
  label(ctx, 'C', C.x + 2, C.y - 10, { size: 13, bold: true });
  label(ctx, 'D', D.x - 10, D.y - 2, { size: 13, bold: true });
  if (vis.Fc) {                                  /* 分解した力（斜面に垂直・平行） */
    var uu = g.u, nn = g.n, Lg1 = 46;
    var Lc1 = Lg1 * Math.cos(th * DEG), Ls1 = Lg1 * Math.sin(th * DEG);
    arrow(ctx, g.cm.x, g.cm.y, g.cm.x - nn.x * Lc1, g.cm.y - nn.y * Lc1, 'comp', 1, COL.force);
    tipLabel(ctx, 'mg cosθ', g.cm.x - nn.x * Lc1, g.cm.y - nn.y * Lc1, -nn.x, -nn.y, { size: 11, color: COL.force, dx: 26, dy: -4 });
    if (Ls1 > 6) {
      arrow(ctx, g.cm.x, g.cm.y, g.cm.x - uu.x * Ls1, g.cm.y - uu.y * Ls1, 'comp', 1, COL.force);
      tipLabel(ctx, 'mg sinθ', g.cm.x - uu.x * Ls1, g.cm.y - uu.y * Ls1, -uu.x, -uu.y, { size: 11, color: COL.force, dy: -8 });
    }
  }
  if (vis.F) {
    arrow(ctx, g.cm.x, g.cm.y, g.cm.x, g.cm.y + 46, 'force', 1, COL.force);
    tipLabel(ctx, '重力 mg', g.cm.x, g.cm.y + 46, 0, 1, { size: 12, color: COL.force, dx: -44 });
  }
  /* 寸法 */
  var md = { x: (C.x + D.x) / 2, y: (C.y + D.y) / 2 }, ma = { x: (A.x + D.x) / 2, y: (A.y + D.y) / 2 };
  label(ctx, '0.12 m', md.x + g.n.x * 16, md.y + g.n.y * 16, { size: 11.5, color: COL.dim });
  label(ctx, '0.16 m', ma.x - g.u.x * 22, ma.y - g.u.y * 22, { size: 11.5, color: COL.dim });
  label(ctx, 'θ = ' + fmt(th, 1) + '°', W - 8, 16, { size: 12, color: COL.sub, align: 'right' });
  label(ctx, hit ? '対角線 AC が鉛直になった ＝ 傾く瞬間' : '対角線 AC が鉛直になったとき傾く',
    W / 2 - 24, 16, { size: 11.5, bold: hit, color: hit ? '#9b2418' : '#3d4c5a' });
}

/* ＜別解＞(1) 力のモーメントのつりあい：A の蝶つがい、重力の分解、うでの長さ a/2・b/2 */
function drawAnsFig2(cv, thDeg, vis) {
  vis = vis || { F: true, Fc: false };
  var W = 340, H = 290, ctx = prep(cv, W, H);
  var dm = P.box.dims('3:4'), th0 = P.tilt.th0(dm.a, dm.b), S = 780;
  var th = (thDeg === undefined || thDeg === null) ? th0 : thDeg;
  var hit = Math.abs(th - th0) < 0.35;
  var pv = { x: 168, y: 226 };
  var u0 = { x: Math.cos(th * DEG), y: -Math.sin(th * DEG) };
  hatchLine(ctx, pv.x - u0.x * 170, pv.y - u0.y * 170, pv.x + u0.x * 200, pv.y + u0.y * 200, 1);
  var g = boxGeom(pv, th, 0, dm.a, dm.b, S);
  drawBoxSide(ctx, g, { grid: true, fill: hit ? '#fdf0d8' : '#fbf3ea' });
  var A = g.c[0], u = g.u, n = g.n, cm = g.cm;
  thetaMark(ctx, pv.x, pv.y, th, 86, hit ? 'θ₀' : 'θ');
  var Lg = 46, Lc = Lg * Math.cos(th * DEG), Ls = Lg * Math.sin(th * DEG);
  if (vis.Fc) {
    /* うでの長さ：A から mg cosθ の作用線までの a/2、mg sinθ の作用線までの b/2（破線＋両矢印） */
    var fa = g.pt(g.w / 2, 0), fb = g.pt(0, g.h / 2);
    ctx.save(); ctx.strokeStyle = COL.dim; ctx.lineWidth = 1; ctx.setLineDash([4, 3]);
    ctx.beginPath(); ctx.moveTo(fa.x, fa.y); ctx.lineTo(cm.x, cm.y); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(fb.x, fb.y); ctx.lineTo(cm.x, cm.y); ctx.stroke();
    ctx.restore();
    var o1 = g.pt(0, -22), o2 = g.pt(g.w / 2, -22);           /* a/2：面の下がわ */
    arrow(ctx, o1.x, o1.y, o2.x, o2.y, 'dim', 1); arrow(ctx, o2.x, o2.y, o1.x, o1.y, 'dim', 1);
    label(ctx, 'a/2', g.pt(g.w / 4, -36).x, g.pt(g.w / 4, -36).y, { size: 11.5, color: COL.dim });
    var p1 = g.pt(-24, 0), p2 = g.pt(-24, g.h / 2);           /* b/2：箱の左（下側の面の外） */
    arrow(ctx, p1.x, p1.y, p2.x, p2.y, 'dim', 1); arrow(ctx, p2.x, p2.y, p1.x, p1.y, 'dim', 1);
    label(ctx, 'b/2', g.pt(-40, g.h / 4).x, g.pt(-40, g.h / 4).y, { size: 11.5, color: COL.dim });
    /* 重力の分解（矢印は短めにして A の印と重ねない） */
    arrow(ctx, cm.x, cm.y, cm.x - n.x * Lc, cm.y - n.y * Lc, 'comp', 1, COL.force);
    tipLabel(ctx, (hit ? 'mg cosθ₀' : 'mg cosθ'), cm.x - n.x * Lc, cm.y - n.y * Lc, -n.x, -n.y, { size: 11, color: COL.force, dx: 26, dy: -6 });
    if (Ls > 6) {
      arrow(ctx, cm.x, cm.y, cm.x - u.x * Ls, cm.y - u.y * Ls, 'comp', 1, COL.force);
      tipLabel(ctx, (hit ? 'mg sinθ₀' : 'mg sinθ'), cm.x - u.x * Ls, cm.y - u.y * Ls, -u.x, -u.y, { size: 11, color: COL.force, dy: -8 });
    }
  }
  if (vis.F) {
    /* 抗力（垂直抗力と摩擦力の合力）の作用点は、上のシミュレーションと同じで
       A から s = a/2 − (b/2)tanθ のところ。θ が大きくなるほど A に近づき、
       ★傾く瞬間（θ = θ₀）にちょうど A に一致する★ */
    var sR = P.tilt.contact(dm.a, dm.b, th);
    var cp = g.pt(sR * S, 0);
    arrow(ctx, cp.x, cp.y, cp.x, cp.y - Lg, 'force', 1, COL.norm);
    actPoint(ctx, cp.x, cp.y, COL.norm);
    tipLabel(ctx, hit ? '抗力（作用点が A に一致）' : '抗力', cp.x, cp.y - Lg, 0, -1,
      { size: 11.5, color: COL.norm, dx: hit ? 44 : 16, dy: -2 });
    arrow(ctx, cm.x, cm.y, cm.x, cm.y + Lg, 'force', 1, COL.force);
    tipLabel(ctx, 'mg', cm.x, cm.y + Lg, 0, 1, { size: 12, color: COL.force, dx: -14 });
  }
  axisMark(ctx, A.x, A.y, null);
  label(ctx, hit ? 'A（回転軸）' : 'A（回転軸になる点）', A.x + 4, A.y + 26, { size: 12, bold: true, align: 'left', avoid: true });
  label(ctx, hit ? 'A のまわりのモーメントがつりあう ＝ 傾く瞬間' : 'A のまわりのモーメントのつりあい',
    W / 2 - 22, 16, { size: 11.5, bold: hit, color: hit ? '#9b2418' : '#3d4c5a' });
  label(ctx, 'θ = ' + fmt(th, 1) + '°', W - 8, 16, { size: 12, color: COL.sub, align: 'right' });
}

/* 摩擦力のグラフ（r2：横軸 θ、r3：横軸 F）。チェックボックスの下に小さく出す */
function drawFricGraph(cv, kind, v, s) {
  var W = 300, H = 164, ctx = prep(cv, W, H);
  var m = P.box.M, mg = m * G;
  var pad = { l: 40, r: 14, t: 22, b: 38 };
  var gw = W - pad.l - pad.r, gh = H - pad.t - pad.b;
  var xmax = kind === 'tilt' ? R2.THMAX : R3.FMAX;
  /* たて軸は「そのとき使う範囲」に合わせる（線が下のほうに寄って見えないのを防ぐ） */
  var need = (kind === 'tilt')
    ? Math.max(v.mu * mg, mg * Math.sin(Math.min(xmax, P.tilt.thSlip(v.mu)) * DEG))
    : Math.max(v.mu * mg, Math.min(xmax, v.F));
  var ymax = niceRange(0, Math.max(1, need) * 1.18).hi;
  function X(x) { return pad.l + gw * x / xmax; }
  function Y(y) { return pad.t + gh * (1 - y / ymax); }
  /* C9（第 55 回）：描く面を白（角丸 6 px）、目盛り線を淡く（外枠の線は CSS で消した） */
  ctx.save(); ctx.fillStyle = '#fff';
  ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(pad.l, pad.t - 4, gw + 4, gh + 4, 6); else ctx.rect(pad.l, pad.t - 4, gw + 4, gh + 4); ctx.fill();
  ctx.strokeStyle = '#f1ede6'; ctx.lineWidth = 1;
  [xmax / 4, xmax / 2, xmax * 3 / 4, xmax].forEach(function (x) { ctx.beginPath(); ctx.moveTo(Math.round(X(x)) + 0.5, pad.t); ctx.lineTo(Math.round(X(x)) + 0.5, pad.t + gh); ctx.stroke(); });
  [ymax / 4, ymax / 2, ymax * 3 / 4, ymax].forEach(function (y) { ctx.beginPath(); ctx.moveTo(pad.l, Math.round(Y(y)) + 0.5); ctx.lineTo(pad.l + gw, Math.round(Y(y)) + 0.5); ctx.stroke(); });
  ctx.restore();
  /* 軸 */
  ctx.save(); ctx.strokeStyle = AX.col; ctx.lineWidth = 1.2;
  ctx.beginPath(); ctx.moveTo(pad.l, pad.t + gh); ctx.lineTo(pad.l + gw + 4, pad.t + gh); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(pad.l, pad.t + gh); ctx.lineTo(pad.l, pad.t - 4); ctx.stroke();
  ctx.restore();
  arrowHead(ctx, pad.l + gw + 8, pad.t + gh, 1, 0, AX.col);
  arrowHead(ctx, pad.l, pad.t - 8, 0, -1, AX.col);
  label(ctx, kind === 'tilt' ? 'θ［°］' : 'F［N］', pad.l + gw + 10, pad.t + gh + 26, { size: 10.5, color: AX.col, align: 'right' });
  label(ctx, '摩擦力［N］', pad.l + 4, pad.t - 12, { size: 10.5, color: AX.col, align: 'left' });
  var i, xs = [0, xmax / 2, xmax];
  xs.forEach(function (x) { label(ctx, fmt(x, 0), X(x), pad.t + gh + 11, { size: 9.5, color: AX.col }); });
  [ymax / 2, ymax].forEach(function (y) { label(ctx, fmt(y, 0), pad.l - 6, Y(y), { size: 9.5, color: AX.col, align: 'right' }); });
  /* 最大摩擦力 μN と、必要な摩擦力 f */
  var dm = P.box.dims(v.ab), xs2 = (kind === 'tilt') ? P.tilt.thSlip(v.mu) : P.pull.Fslip(m, v.mu);
  var xnow = kind === 'tilt' ? v.th : v.F;
  ctx.save();
  ctx.strokeStyle = COL.fric; ctx.lineWidth = 1.6; ctx.setLineDash([5, 3]);
  ctx.beginPath();
  for (i = 0; i <= 60; i++) {
    var x = xmax * i / 60, y = (kind === 'tilt') ? v.mu * mg * Math.cos(x * DEG) : v.mu * mg;
    if (i === 0) ctx.moveTo(X(x), Y(y)); else ctx.lineTo(X(x), Y(y));
  }
  ctx.stroke();
  ctx.setLineDash([]); ctx.lineWidth = 2.2;
  ctx.beginPath();
  var xe = Math.min(xmax, xs2);
  for (i = 0; i <= 60; i++) {
    var x2 = xe * i / 60, y2 = (kind === 'tilt') ? mg * Math.sin(x2 * DEG) : x2;
    if (i === 0) ctx.moveTo(X(x2), Y(y2)); else ctx.lineTo(X(x2), Y(y2));
  }
  ctx.stroke();
  /* すべりはじめ */
  if (xs2 <= xmax) {
    ctx.strokeStyle = COL.fric; ctx.lineWidth = 1; ctx.setLineDash([2, 3]);
    ctx.beginPath(); ctx.moveTo(X(xs2), pad.t + gh); ctx.lineTo(X(xs2), Y((kind === 'tilt') ? mg * Math.sin(xs2 * DEG) : xs2)); ctx.stroke();
  }
  /* いまの点 */
  var ynow = (xnow < xs2) ? ((kind === 'tilt') ? mg * Math.sin(xnow * DEG) : xnow) : ((kind === 'tilt') ? v.mu * mg * Math.cos(xnow * DEG) : v.mu * mg);
  var xn = Math.min(xnow, xmax);
  ctx.strokeStyle = 'rgba(15,138,138,.45)'; ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
  ctx.beginPath(); ctx.moveTo(X(xn), pad.t + gh); ctx.lineTo(X(xn), Y(ynow)); ctx.stroke();
  ctx.setLineDash([]); ctx.fillStyle = COL.fric; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.8;
  ctx.beginPath(); ctx.arc(X(xn), Y(ynow), 5, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.restore();
  label(ctx, '最大摩擦力 μN', X(xmax * 0.55), Y((kind === 'tilt') ? v.mu * mg * Math.cos(xmax * 0.55 * DEG) : v.mu * mg) - 9, { size: 10, color: COL.fric, bold: true });
  label(ctx, '静止摩擦力 f', X(xe * 0.5), Y((kind === 'tilt') ? mg * Math.sin(xe * 0.5 * DEG) : xe * 0.5) + 11, { size: 10, color: COL.fric });
  if (xs2 <= xmax) label(ctx, (kind === 'tilt' ? 'θ_s' : 'F_s'), X(xs2), pad.t + gh + 24, { size: 10, color: COL.fric, bold: true, avoid: true });
  label(ctx, 'いま', X(xn), Y(ynow) - 12, { size: 9.5, color: COL.fric, avoid: true });
}

/* ＜解答＞(2) 摩擦角の図（教科書 図63 の形）。
   斜面の傾きがちょうど θ₀ のとき、重力・垂直抗力・最大摩擦力の 3 力がつりあう。 */
function drawAnsFig3(cv, vis) {
  vis = vis || { F: true, Fc: false };
  var W = 400, H = 300, ctx = prep(cv, W, H);
  var dm = P.box.dims('3:4'), th0 = P.tilt.th0(dm.a, dm.b), S = 620;
  var pv = { x: 116, y: 206 };
  var u = { x: Math.cos(th0 * DEG), y: -Math.sin(th0 * DEG) };     /* 斜面を上る向き */
  var n = { x: -Math.sin(th0 * DEG), y: -Math.cos(th0 * DEG) };    /* 斜面から外向き */
  hatchLine(ctx, pv.x - u.x * 150, pv.y - u.y * 150, pv.x + u.x * 230, pv.y + u.y * 230, 1);
  var g = boxGeom(pv, th0, 0, dm.a, dm.b, S);
  drawBoxSide(ctx, g, { grid: false, fill: '#fbf3ea' });
  /* 抗力の作用点は、上のシミュレーションと同じ式 s = a/2 − (b/2)tanθ。
     θ = θ₀ ではちょうど回転軸 A（左下の角）に一致する */
  var cm = g.cm, cp = g.pt(P.tilt.contact(dm.a, dm.b, th0) * S, 0);
  var mg = P.box.M * G, fs = 62 / mg;                              /* mg を 62 px に */
  var Lg = mg * fs, Lc = Lg * Math.cos(th0 * DEG), Ls = Lg * Math.sin(th0 * DEG);
  var swapLab = null;
  /* 上のシミュレーションと同じ描き分け：
     「力を表示」＝ 重力（赤の実線）と抗力（紫の実線）、
     「分解した力を表示」＝ 重力の分力・垂直抗力 N・最大摩擦力 F₀（分力の矢印） */
  if (vis.Fc) {
    arrow(ctx, cm.x, cm.y, cm.x - n.x * Lc, cm.y - n.y * Lc, 'comp', 1, COL.force);
    arrow(ctx, cm.x, cm.y, cm.x - u.x * Ls, cm.y - u.y * Ls, 'comp', 1, COL.force);
    tipLabel(ctx, 'mg sinθ₀', cm.x - u.x * Ls, cm.y - u.y * Ls, -u.x, -u.y, { size: 11, color: COL.force, dy: -14 });
    arrow(ctx, cp.x, cp.y, cp.x + n.x * Lc, cp.y + n.y * Lc, 'comp', 1, COL.norm);
    tipLabel(ctx, '垂直抗力 N', cp.x + n.x * Lc, cp.y + n.y * Lc, n.x, n.y, { size: 11.5, color: COL.norm, dx: -30, dy: -6 });
    arrow(ctx, cp.x, cp.y, cp.x + u.x * Ls, cp.y + u.y * Ls, 'comp', 1, COL.fric);
    /* 「mg cosθ₀」と「最大摩擦力 F₀」は場所を入れかえて置く（矢印の近くで読みやすいほうへ） */
    swapLab = {
      f0: { x: cm.x - n.x * Lc + (-n.x) * (6 + Math.abs(n.x) * 26) + 34, y: cm.y - n.y * Lc + (-n.y) * (6 + Math.abs(n.y) * 7) + 10 },
      mg: { x: cp.x + u.x * Ls + u.x * (6 + Math.abs(u.x) * 34) + 28, y: cp.y + u.y * Ls + u.y * (6 + Math.abs(u.y) * 7) - 30 }
    };
  }
  if (vis.F) {
    arrow(ctx, cm.x, cm.y, cm.x, cm.y + Lg, 'force', 1, COL.force);
    tipLabel(ctx, '重力 mg', cm.x, cm.y + Lg, 0, 1, { size: 11.5, color: COL.force, dx: -40, dy: 4 });
    arrow(ctx, cp.x + 2.5, cp.y, cp.x + 2.5, cp.y - Lg, 'force', 1, COL.norm);
    tipLabel(ctx, '抗力', cp.x + 2.5, cp.y - Lg, 0, -1, { size: 11.5, color: COL.norm, dx: -16, dy: -2 });
  }
  /* 直角の印（斜面と N） */
  (function () {
    var q = 9, p0 = { x: cp.x + n.x * q, y: cp.y + n.y * q };
    ctx.save(); ctx.strokeStyle = COL.sub; ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(p0.x, p0.y); ctx.lineTo(p0.x + u.x * q, p0.y + u.y * q);
    ctx.moveTo(cp.x + u.x * q, cp.y + u.y * q); ctx.lineTo(p0.x + u.x * q, p0.y + u.y * q);
    ctx.stroke(); ctx.restore();
  })();
  drawEqualTicks(ctx);        /* 同じ大きさの力には同じ「｜」の印（上のシミュレーションと同じ） */
  thetaMark(ctx, pv.x, pv.y, th0, 74, 'θ₀');
  if (swapLab) {              /* θ₀ のあとに描く → ぶつかったら自動でよける */
    label(ctx, '最大摩擦力 F₀', swapLab.f0.x, swapLab.f0.y, { size: 11.5, color: COL.fric, avoid: true });
    label(ctx, 'mg cosθ₀', swapLab.mg.x, swapLab.mg.y, { size: 11, color: COL.force, avoid: true });
  }
  axisMark(ctx, g.c[0].x, g.c[0].y, null);
  label(ctx, 'A', g.c[0].x - 13, g.c[0].y + 9, { size: 12, bold: true, avoid: false });
  label(ctx, '3 つの力がつりあっている（すべり出す直前）', W / 2, 15, { size: 11, color: '#3d4c5a' });
  label(ctx, 'μ = F₀ / N = tanθ₀', W / 2, H - 12, { size: 12.5, bold: true, color: '#0a5c5c' });
}

/* ＜解答＞の図の「力を表示／分解した力を表示」チェックボックス（ブロックごと） */
function ansOpts(s, blk) {
  var a = (s._av && s._av[blk]) || { F: true, Fc: false };
  return '<div class="opts ansopts">' +
    '<label' + (a.F ? '' : ' class="vflash"') + '><input type="checkbox" data-ansv="' + blk + 'F"' + (a.F ? ' checked' : '') + '> 力を表示</label>' +
    '<label' + (a.Fc ? '' : ' class="vflash"') + '><input type="checkbox" data-ansv="' + blk + 'Fc"' + (a.Fc ? ' checked' : '') + '> 分解した力を表示</label>' +
    '</div>';
}

DEFS['r2'] = {
  id: 'r2', tab: '④-2　板の角度を変える（箱は固定なし）',
  cvNote: '<span class="gact">板をドラッグ</span>しても θ を変えられる',
  graph: 'tilt',
  /* 再生：先に起こるほうが起きて 5° 進んだところで止める。
     ★もう片方（すべる／傾く）の条件までは、ぜったいに進めない★ */
  playStop: function (v) {
    var dm = P.box.dims(v.ab);
    var t0 = P.tilt.th0(dm.a, dm.b), ts = P.tilt.thSlip(v.mu);
    var first = Math.min(t0, ts), second = Math.max(t0, ts);
    return Math.min(first + 5, Math.max(first + 0.5, second - 0.5));
  },
  slipFirst: function (v) { var dm = P.box.dims(v.ab); return P.tilt.state(dm.a, dm.b, v.mu, v.th, false).slipFirst; },
  moment2: { label: 'すべる瞬間をスローで', dur: 4.0, range: function (v) { var ths = P.tilt.thSlip(v.mu); return { k: 'th', from: Math.max(0, ths - 5), to: Math.min(R2.THMAX, ths + 5), hold: 0.8 }; } },
  playRate: 5, playNote: 'スタートを押すと θ が 0° からだんだん大きくなる',
  title: '④-2　板の角度を変える　～箱は固定なし。傾くのが先か、すべるのが先か～',
  sub: '板の左端は蝶つがいで固定。箱は固定していないので、θ を上げていくと<b>すべる</b>か<b>傾く</b>かのどちらかが先に起こる。' +
    '傾く角は $\\tan\\theta_0 = a/b$、すべる角は $\\tan\\theta_s = \\mu$。<b>先に来るほうが実際に起こる</b>。' +
    '4 つの箱の μ はすべて同じ（操作対象の μ）。右端が操作対象の箱（右の枠にズームアップ）。',
  cw: function (v, s) { return (s && s._narrow) ? 480 : ((s && s._short) ? 640 : 780); },
  ch: function (v, s) { return (s && s._narrow ? 290 + 336 : ((s && s._short) ? 268 : 290)) + (s && s.o.showAB ? R2.BAND : 0); },
  drag: true,
  abDef: '8:2',                 /* 第 59 回：はじめは 幅a:高さb ＝ 8:2（千葉さんの指定。前は 3:4） */
  vars: [
    { k: 'th', label: '板の角度 $\\theta$', unit: '°', min: 0, max: R2.THMAX, step: 1, dec: 0, def: 0,
      tick: function (v) {
        var dm = P.box.dims(v.ab), th0 = P.tilt.th0(dm.a, dm.b), ths = P.tilt.thSlip(v.mu);
        return { at: th0, label: '傾く角 $\\theta_0 = ' + fmt(th0, 1) + '^\\circ$', at2: ths, label2: 'すべる角 $\\theta_s = ' + fmt(ths, 1) + '^\\circ$' };
      } },
    { k: 'mu', label: '静止摩擦係数 $\\mu$', unit: '', min: 0, max: 1.5, step: 0.05, dec: 2, def: 1.20 }
  ],
  /* 箱の形（a:b）を変えて、先に起こることを入れかえる（μ は既定のまま） */
  presets: [
    { label: 'すべるより先に傾く', fn: function (s) { s.v.mu = 1.20; s.ab = '3:4'; s.anim = null; },
      is: function (v) { var dm = P.box.dims(v.ab); return !P.tilt.state(dm.a, dm.b, v.mu, v.th, false).slipFirst; } },
    { label: '傾くより先にすべる', fn: function (s) { s.v.mu = 1.20; s.ab = '8:2'; s.anim = null; },
      is: function (v) { var dm = P.box.dims(v.ab); return P.tilt.state(dm.a, dm.b, v.mu, v.th, false).slipFirst; } }
  ],
  vis: [
    { k: 'F', label: '力を表示', def: false },
    { k: 'L', label: '重力の作用線を表示', def: false },
    { k: 'Fc', label: '分解した力を表示', def: false },
    { k: 'Hide', label: '重力と抗力のベクトルを消す', def: false },
    { k: 'AB', label: '各箱の 幅a:高さb と $\\mu$ を表示', def: false },
    { k: 'Grid', label: '箱の分割線を表示', def: true }
  ],
  moment: {
    label: '傾く瞬間をスローで',
    dur: 4.0,
    range: function (v) {
      var dm = P.box.dims(v.ab), th0 = P.tilt.th0(dm.a, dm.b);
      return { k: 'th', from: Math.max(0, th0 - 5), to: Math.min(R2.THMAX, th0 + 5), hold: 0.8 };
    }
  },
  dragDown: function (s, lx, ly) {                 /* 板の線から 16px 以内なら板のドラッグ */
    if (!s._plate) return false;
    var a = s._plate[0], b = s._plate[1];
    var vx = b.x - a.x, vy = b.y - a.y, L2 = vx * vx + vy * vy || 1;
    var t = clamp(((lx - a.x) * vx + (ly - a.y) * vy) / L2, 0, 1);
    return Math.hypot(lx - (a.x + vx * t), ly - (a.y + vy * t)) < 16;
  },
  drag: function (s, lx, ly) {
    var pv = s._pv; if (!pv) return;
    var ang = Math.atan2(pv.y - ly, lx - pv.x) / DEG;
    s.v.th = clamp(Math.round(ang), 0, R2.THMAX);
  },
  verdict: function (v) {
    var dm = P.box.dims(v.ab);
    var stt = P.tilt.state(dm.a, dm.b, v.mu, v.th, false);
    return { th0: +stt.th0.toFixed(3), ths: +stt.thSlip.toFixed(3), first: stt.first, slipFirst: stt.slipFirst };
  },
  result: function (v, s) {
    var dm = P.box.dims(v.ab);
    var stt = P.tilt.state(dm.a, dm.b, v.mu, v.th, false);
    var now = stt.tip ? '傾いた！' : (stt.slip ? 'すべった！' : 'まだ動かない');
    var items = [
      { k: '操作対象の箱', v: 'a = ' + fmt(dm.a, 2) + ' m，b = ' + fmt(dm.b, 2) + ' m（a/b = ' + fmt(dm.a / dm.b, 2) + '）' },
      { k: '$\\tan\\theta_0 = a/b$ を満たす<br>傾く角度 $\\theta_0$', v: fmt(stt.th0, 1) + '°', kbox: !stt.slipFirst },
      { k: 'すべる角 $\\theta_s$（$\\tan\\theta_s = \\mu$）', v: fmt(stt.thSlip, 1) + '°', kbox: stt.slipFirst },
      { k: 'いま', v: now, cls: stt.tip ? 'tip' : (stt.slip ? 'slip' : '') }
    ];
    var note = '';
    if (hintOn(s)) note = stt.slipFirst
      ? '$\\mu < a/b$ なので、$\\theta_0$ より先に $\\theta_s$ に達する → 傾く前にすべり出す。'
      : '$\\mu \\geqq a/b$ なので、$\\theta_s$ より先に $\\theta_0$ に達する → すべる前に傾く。';
    return { items: items, note: note };
  },
  draw: function (ctx, s, W, H) {
    var v = V(s);
    var band = s.o.showAB ? R2.BAND : 0;
    var nar = !!s._narrow;
    var region = nar ? { x0: 6, y0: 8, w: W - 12, h: 290 - 16 }
      : { x0: 6, y0: 8, w: s._short ? 300 : 470, h: H - 16 - band };
    var sc = drawR2Scene(ctx, s, region);
    var fx = clamp(Math.round(sc.right + 14), 240, W - 300);
    var fr = nar ? { x0: (W - 284) / 2, y0: 290 + band + 26, w: 284, h: 236 }
      : { x0: fx, y0: s._short ? 18 : 24, w: Math.min(350, W - fx - 6), h: s._short ? 226 : 236 };
    ctx.save();
    ctx.fillStyle = '#fbfcfd'; ctx.strokeStyle = '#8b949e'; ctx.lineWidth = 1.2; ctx.setLineDash([6, 4]);
    ctx.beginPath(); ctx.rect(fr.x0, fr.y0, fr.w, fr.h); ctx.fill(); ctx.stroke();
    ctx.restore();
    label(ctx, 'ズームアップ（操作対象の箱 幅a:高さb = ' + s.ab + '）', fr.x0 + fr.w / 2, fr.y0 - 11, { size: 12, bold: true, color: '#3d4c5a' });
    var b = sc.boxes[3];
    var pv = { x: fr.x0 + 104, y: fr.y0 + fr.h - 62 };
    var zS = zoomScale(b.dm, fr);
    var z = drawTiltBox(ctx, s, v, b.dm, b.stt, b.tip, pv, fr, false, { S: zS, fill: TGT.fill, line: TGT.line });
    axisMark(ctx, z.pvb.x, z.pvb.y, null);
    label(ctx, '回転軸', pv.x - 26, pv.y + 26, { size: 11, color: COL.sub, align: 'right', avoid: true });
    var g = z.g, tp = g.pt(g.w / 2, g.h);
    var zk = (b.stt.tip && b.tip > 0.01) ? 'tip' : (b.stt.slip ? 'slip' : null);
    var zty2 = bboxOf(gCorners(g)).y0;                        /* 箱のいちばん高いところより上に出す */
    if (zk && verdictAlive(s, 'zoom', zk)) verdictBubble(ctx, zk, clamp(tp.x, fr.x0 + 54, fr.x0 + fr.w - 54), Math.max(fr.y0 + 34, Math.min(tp.y, zty2) - 6), 'down');
    else verdictAlive(s, 'zoom', zk);
    var ty = fr.y0 + fr.h + 12;
    if (hintOn(s) && !(s._short && s.o.showAB)) {
      if (b.stt.tip) {
        label(ctx, '重力の作用線が回転軸より左（外）に出ると、', fr.x0 + fr.w / 2, ty, { size: 11, color: '#9b2418' });
        label(ctx, '重力のモーメントで箱は回転する', fr.x0 + fr.w / 2, ty + 18, { size: 11, color: '#9b2418' });
      } else if (b.stt.slip) {
        label(ctx, 'tanθ ≧ μ：斜面方向の力 mg sinθ が', fr.x0 + fr.w / 2, ty, { size: 11, color: '#0a5c5c' });
        label(ctx, '最大摩擦力 μN をこえて、すべり出した', fr.x0 + fr.w / 2, ty + 18, { size: 11, color: '#0a5c5c' });
      } else if (v.th > 0.5) {
        label(ctx, 'θ が大きいほど、抗力の作用点は', fr.x0 + fr.w / 2, ty, { size: 11, color: '#3d4c5a' });
        label(ctx, '回転軸のほうへ動いていく', fr.x0 + fr.w / 2, ty + 18, { size: 11, color: '#3d4c5a' });
      }
    } else {
      label(ctx, 'θ を変えて、傾くか・すべるかを見よう', fr.x0 + fr.w / 2, ty, { size: 11, color: COL.sub });
    }
  },
  below: function (s) {
    return '<div class="bcard"><h3>＜考え方＞　板の角度を変える場合' +
      '<a class="cmplink" href="#4-3" data-goto="r3">比較してみよう　床の上の直方体 →</a></h3>' +
      '<canvas id="r2think"></canvas>' +
      '<p>板を傾けていくと、<b>板からの抗力の作用点</b>（重力と抗力の 2 力がつりあうので、重力の作用線が接触面と交わる点）が中央から回転軸のほうへずれていく。' +
      '<b>作用点が回転軸に一致した瞬間</b>（＝重力の作用線が回転軸を通った瞬間）が傾きはじめる角 $\\theta_0$。それを超えると重力のモーメントがつりあわず、回転する。</p></div>' +
      '<div class="bcard"><h3>＜問題＞</h3>' +
      '<p>幅 $a = 0.12\\ \\mathrm{m}$、高さ $b = 0.16\\ \\mathrm{m}$ の直方体を、板の上に置いて板を傾けていく（教科書の図の設定。a:b = 3:4）。</p>' +
      '<ol class="qlist"><li>直方体が傾きはじめる角度を $\\theta_0$ として、$\\tan\\theta_0$ を求めよ。答えは分数でよい。</li>' +
      '<li>直方体と斜面との間の静止摩擦係数 $\\mu$ がある値 $\\mu_0$ より小さいときは、直方体は (1) の状態になる前に斜面をすべり始める。$\\mu_0$ を求めよ。</li></ol></div>' +
      '<div class="bcard" id="r2ans"><h3>＜解答＞</h3>' +
      '<p class="mini">まず自分で解いてから開こう。</p>' +
      '<button class="openbtn glow" data-open="r2ans" data-open-label="解答を見る" data-close-label="解答をとじる">解答を見る</button>' +
      '<div class="anscol">' +
      /* ---- (1) 作図による解法：左に動く図、右に解説 ---- */
      '<div class="ansblock"><h4>(1)　作図による解法</h4><div class="ansrow">' +
      '<div class="ansfig">' +
      '<div class="ctrl playctrl ansplay"><div class="btnrow">' +
      '<button id="bAnsPlay">▶ スタート</button>' +
      '<button id="bAnsSlow" class="sub">スロー再生</button>' +
      '<button id="bAnsReset" class="sub">↺ リセット</button>' +
      '<span class="playnote">押すと θ が大きくなり、<b>傾く瞬間</b>で止まる</span></div></div>' +
      '<canvas id="r2ansfig"></canvas></div>' +
      '<div class="anstxt">' + ansOpts(s, 'a1') +
      '<p>重心 G は直方体の中心、つまり対角線 AC の上にある。傾きはじめる瞬間は、<b>重心から下ろした重力の作用線が回転軸 A を通る</b>ときだから、<b>対角線 AC が鉛直</b>になる。' +
      'このとき辺 AD と鉛直線のなす角は斜面の傾き $\\theta_0$ に等しい（どちらも斜面に垂直な向きから測った角）。直角三角形 ACD で</p>' +
      '<div class="fmlbox"><span class="tex">\\sin\\theta_0 = \\dfrac{\\mathrm{CD}}{\\mathrm{AC}} = \\dfrac{0.12}{\\sqrt{0.12^2+0.16^2}} = \\dfrac{0.12}{0.20} = 0.60</span></div>' +
      '<div class="fmlbox"><span class="tex">\\tan\\theta_0 = \\dfrac{\\mathrm{CD}}{\\mathrm{AD}} = \\dfrac{0.12}{0.16} = \\dfrac{3}{4}</span></div>' +
      '</div></div></div>' +
      /* ---- ＜別解＞(1) モーメントのつりあい ---- */
      '<div class="ansblock"><h4>＜別解＞(1)　力のモーメントのつりあいによる解法</h4><div class="ansrow">' +
      '<div class="ansfig">' +
      '<div class="ctrl playctrl ansplay"><div class="btnrow">' +
      '<button id="bAns2Play">▶ スタート</button>' +
      '<button id="bAns2Slow" class="sub">スロー再生</button>' +
      '<button id="bAns2Reset" class="sub">↺ リセット</button>' +
      '<span class="playnote">押すと θ が大きくなり、<b>傾く瞬間</b>で止まる</span></div></div>' +
      '<canvas id="r2ansfig2"></canvas></div>' +
      '<div class="anstxt">' + ansOpts(s, 'a2') +
      '<p>回転軸 A のまわりの重力のモーメントを考える。重力 $mg$ を斜面に垂直な成分 $mg\\cos\\theta$ と斜面方向の成分 $mg\\sin\\theta$ に分けると、' +
      '$mg\\cos\\theta$ は A から $\\dfrac{a}{2}$ はなれた点で「もどす向き」に、$mg\\sin\\theta$ は A から $\\dfrac{b}{2}$ はなれた点で「倒す向き」にはたらく。' +
      '傾きはじめるのは、倒す向きのモーメントがもどす向きのモーメントに等しくなるとき：</p>' +
      '<div class="fmlbox"><span class="tex">mg\\sin\\theta_0\\cdot\\dfrac{b}{2} = mg\\cos\\theta_0\\cdot\\dfrac{a}{2}\\quad\\Longrightarrow\\quad \\tan\\theta_0 = \\dfrac{a}{b} = \\dfrac{0.12}{0.16} = \\dfrac{3}{4}</span></div>' +
      '<p>なお箱には<b>抗力（垂直抗力と摩擦力）</b>がはたらいているが、傾く瞬間は左下の回転軸 A が抗力の作用点であり、' +
      '<b>左下の端点を力のモーメントの軸に選べば、抗力のモーメントは 0 である</b>。' +
      'すなわち、回転軸 A のまわりの重力のモーメントを考えるだけでよい。</p>' +
      '</div></div></div>' +
      /* ---- (2) ---- */
      '<div class="ansblock"><h4>(2)</h4><div class="ansrow">' +
      '<div class="ansfig"><canvas id="r2ansfig3"></canvas></div>' +
      '<div class="anstxt">' + ansOpts(s, 'a3') +
      '<p>斜面の傾きが $\\theta_0$ をこえるまで直方体がすべらないでいるためには、ちょうど $\\theta_0$ で<b>すべり出す直前</b>になっていればよい。' +
      'つまり $\\theta_0$ が<b>摩擦角</b>である。このとき物体にはたらく 3 つの力（重力・垂直抗力・最大摩擦力）はつりあっているので</p>' +
      '<div class="fmlbox"><span class="tex">\\text{斜面に平行：}\\; mg\\sin\\theta_0 - F_0 = 0</span></div>' +
      '<div class="fmlbox"><span class="tex">\\text{斜面に垂直：}\\; N - mg\\cos\\theta_0 = 0</span></div>' +
      '<p>この 2 式と $F_0 = \\mu_0 N$ から</p>' +
      '<div class="fmlbox"><span class="tex">\\mu_0 = \\dfrac{F_0}{N} = \\dfrac{mg\\sin\\theta_0}{mg\\cos\\theta_0} = \\tan\\theta_0 = \\dfrac{0.12}{0.16} = 0.75</span></div>' +
      '<p>したがって、<b>$\\mu$ が 0.75 より小さいとき、直方体は斜面の傾きが $\\theta_0$ となる前に斜面をすべり始める。</b>' +
      '（上のシミュレーションで a:b を 3:4 にし、μ を 0.75 より小さくして確かめよう。）</p>' +
      '</div></div></div>' +
      '</div></div>';
  },
  drawBelow: function (s) {
    var c1 = document.getElementById('r2think'); if (c1) drawThinkTilt(c1);
    var c2 = document.getElementById('r2ansfig');
    var av = s._av || { a1: { F: true }, a2: { F: true }, a3: { F: true } };
    LABEL_BOOST = 1.2;                                /* ＜解答＞の図は小さいので、文字を太く大きく */
    if (c2 && c2.clientWidth > 0) drawAnsFig(c2, s._ans ? s._ans.th : undefined, av.a1);
    var c3 = document.getElementById('r2ansfig2');
    if (c3 && c3.clientWidth > 0) drawAnsFig2(c3, s._ans2 ? s._ans2.th : undefined, av.a2);
    LABEL_BOOST = 1.45;                               /* (2) の図は縮小が大きいので、さらに大きく */
    var c4 = document.getElementById('r2ansfig3'); if (c4 && c4.clientWidth > 0) drawAnsFig3(c4, av.a3);
    LABEL_BOOST = 0;
    [c2, c3, c4].forEach(function (c) { if (c) attachLens(c); });   /* マウスを近づけると拡大 */
  }
};

/* ============ r3  床の上の直方体をばねで引く（真横から） ============ */
var R3 = { K: 40, NAT: 0.26, GY: 236, BX: 393, FMAX: 12 };   /* ばね定数 [N/m]・自然長 [m]・床の y・箱の左下の x */

function drawR3Scene(ctx, s, region) {
  var v = V(s), dm = P.box.dims(s.ab), m = P.box.M;
  var bp = dm.b * v.bp;                             /* [m] F の作用点の高さ（v.bp は b に対する割合） */
  v.bp = bp;                                        /* 以下の力の描画には m で渡す */
  var stt = P.pull.state(m, dm.a, v.mu, v.F, bp);
  var tip = stt.tip ? P.pull.tipAngle(v.F, stt.F0) : 0;
  /* 大きい箱（1:16・16:1）でも枠に入る縮尺。倒れると最大 40° 回るので、その高さで見る */
  var c40 = Math.cos(40 * DEG), s40 = Math.sin(40 * DEG);
  var hEff = Math.max(dm.b, dm.a * s40 + dm.b * c40), wEff = Math.max(dm.a, dm.a * c40 + dm.b * s40);
  var S = Math.min(ZS, (region.h - 96) / hEff, (region.w * 0.42) / wEff);
  var nar = !!s._narrow;
  var gy = region.y0 + region.h - 46, bx = region.x0 + (nar ? region.w * 0.66 - 0.16 * S : R3.BX);
  var slipShift = stt.slip ? clamp((v.F - stt.Fslip) / 2.0, 0, 1) * 0.12 * S : 0;
  var pv = { x: bx - slipShift, y: gy };
  var g = boxGeom(pv, 0, tip, dm.a, dm.b, S);
  /* 床 */
  ground(ctx, region.x0 + 2, region.x0 + region.w - 2, gy);
  /* ばねと手（左向きに引く）。ばねの右端は箱の左の面の高さ b′ */
  var fp = g.pt(0, bp * S);
  var ext = v.F / R3.K;                             /* [m] 伸び */
  var sx = fp.x - (R3.NAT + ext) * S;
  springShape(ctx, sx, fp.y, fp.x, fp.y, { coils: 10, r: 8, color: '#5a6470' });
  hand(ctx, sx - 6, fp.y, Math.PI);
  s._handle = { x: sx, y: fp.y };
  /* 自然長の印 */
  var nx0 = fp.x - R3.NAT * S;
  ctx.save(); ctx.strokeStyle = COL.sub; ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
  ctx.beginPath(); ctx.moveTo(nx0, fp.y - 48); ctx.lineTo(nx0, fp.y + 16); ctx.stroke(); ctx.restore();
  label(ctx, '自然長', nx0, fp.y - 58, { size: 10.5, color: COL.sub });
  if (ext > 0.01) {
    arrow(ctx, nx0, fp.y - 36, sx, fp.y - 36, 'dim', 1);
    arrow(ctx, sx, fp.y - 36, nx0, fp.y - 36, 'dim', 1);
    label(ctx, '伸び', (nx0 + sx) / 2, fp.y - 24, { size: 10.5, color: COL.dim });
  }
  /* 箱 */
  drawBoxSide(ctx, g, { grid: s.o.showGrid, fill: TGT.fill, line: TGT.line });
  /* ★回転軸は「回転するとき」だけ出す（止まっているときに出すと、左下が固定されているように見える）★ */
  if (tip > 0) axisMark(ctx, pv.x, pv.y, '回転軸', { dx: -47, dy: 14, align: 'left' });   /* 5 文字分 左へ */
  /* 寸法（チェック） */
  if (s.o.showAB) {
    var rx = g.pt(g.w, 0).x + 16;
    arrow(ctx, rx, gy, rx, gy - g.h, 'dim', 1); arrow(ctx, rx, gy - g.h, rx, gy, 'dim', 1);
    label(ctx, 'b = ' + fmt(dm.b, 2) + ' m', rx + 8, gy - g.h / 2, { size: 11, color: COL.dim, align: 'left' });
    arrow(ctx, pv.x, gy + 22, pv.x + g.w, gy + 22, 'dim', 1); arrow(ctx, pv.x + g.w, gy + 22, pv.x, gy + 22, 'dim', 1);
    label(ctx, 'a = ' + fmt(dm.a, 2) + ' m', pv.x + g.w / 2, gy + 34, { size: 11, color: COL.dim });
    var lx = pv.x - 10;
    if (bp * S > 14) {
      arrow(ctx, lx, gy, lx, gy - bp * S, 'dim', 1); arrow(ctx, lx, gy - bp * S, lx, gy, 'dim', 1);
    }
    label(ctx, "b′ = " + fmt(bp, 2) + ' m', lx - 6, gy - bp * S / 2, { size: 11, color: COL.dim, align: 'right' });
    label(ctx, 'μ = ' + fmt(v.mu, 2), pv.x + g.w + 40, gy + 34, { size: 11, color: COL.ink });
  }
  /* 力 */
  var box = { x0: region.x0, y0: region.y0, x1: region.x0 + region.w, y1: region.y0 + region.h };
  var show = { F: s.o.showF, L: s.o.showSum, Fc: s.o.showFc, Sum: s.o.showSum, Hide: s.o.showHide };
  var r = drawPullForces(ctx, g, v, stt, show, box, FS, { size: 12.5 });
  /* 判定 */
  var tp = g.pt(g.w / 2, g.h);
  var vk = (stt.tip && tip > 0.01) ? 'tip' : (stt.slip ? 'slip' : null);
  if (verdictAlive(s, 'b3', vk)) placeVerdicts(ctx, [{ kind: vk, x: tp.x, y: tp.y - 6 }], 14, region, [bboxOf(gCorners(g))]);
  return { g: g, stt: stt, r: r };
}

/* ＜考え方＞ ②平らな床で引く場合（4 コマ） */
function drawThinkPull(cv) {
  var cols = (cv.clientWidth || 760) < 560 ? 2 : 4;
  var PW = 190, PH = 236, W = PW * cols, H = PH * (4 / cols), ctx = prep(cv, W, H);
  var dm = P.box.dims('3:4'), m = P.box.M, F0 = P.pull.F0(m, dm.a, dm.b);
  var panels = [
    { F: 0, tip: 0, ttl: '引く力がないとき', t1: '力も、力のモーメントも', t2: 'つりあっている' },
    { F: F0 * 0.5, tip: 0, ttl: '少し引くとき', t1: '床からの抗力の作用点は', t2: '中央からずれていく' },
    { F: F0, tip: 0, ttl: '傾く直前', t1: '抗力の作用点が回転軸に一致＝', t2: '重力と引く力の合力の作用線が回転軸を通る', hot: true },
    { F: F0 * 1.15, tip: 20, ttl: '傾いた後', t1: '合力の作用線が底面を超えると', t2: '回転。モーメントはつりあわない' }
  ];
  var S = 300;
  panels.forEach(function (p, i) {
    var x0 = (i % cols) * PW, y0 = Math.floor(i / cols) * PH;
    var box = { x0: x0 + 2, y0: y0, x1: x0 + PW - 2, y1: y0 + PH - 42 };
    var v = { F: p.F, mu: 10, bp: dm.b };
    var stt = P.pull.state(m, dm.a, 10, p.F, dm.b);
    var pv = { x: x0 + 96, y: y0 + 156 };
    ctx.save(); ctx.beginPath(); ctx.rect(box.x0, box.y0, PW - 4, PH); ctx.clip();
    ground(ctx, x0 + 4, x0 + PW - 4, pv.y);
    var g = boxGeom(pv, 0, p.tip, dm.a, dm.b, S);
    drawBoxSide(ctx, g, { grid: false });
    if (p.F > 0) axisMark(ctx, pv.x, pv.y, '回転軸', { dx: 12, dy: 20, align: 'left' });
    drawPullForces(ctx, g, v, stt, { F: true, L: true, Fc: false, Sum: i >= 1 }, box, FS * 0.7, { size: 10 });
    ctx.restore();
    label(ctx, p.ttl, x0 + PW / 2, y0 + 14, { size: 13, bold: true, color: p.hot ? '#9b2418' : COL.ink });
    label(ctx, p.t1, x0 + PW / 2, y0 + PH - 26, { size: 10, color: p.hot ? '#9b2418' : '#3d4c5a' });
    label(ctx, p.t2, x0 + PW / 2, y0 + PH - 12, { size: 10, color: p.hot ? '#9b2418' : '#3d4c5a' });
    ctx.save(); ctx.strokeStyle = '#dde3e8';
    if (i % cols > 0) { ctx.beginPath(); ctx.moveTo(x0, y0 + 6); ctx.lineTo(x0, y0 + PH - 6); ctx.stroke(); }
    if (i >= cols) { ctx.beginPath(); ctx.moveTo(x0 + 6, y0); ctx.lineTo(x0 + PW - 6, y0); ctx.stroke(); }
    ctx.restore();
  });
}

DEFS['r3'] = {
  id: 'r3', tab: '④-3　床の上の直方体をばねで引く',
  title: '④-3　床の上の直方体をばねで引く　～傾くのが先か、すべるのが先か～',
  playRate: 1.5, playNote: 'スタートを押すと F が 0 からだんだん大きくなる', noProblemTag: true,
  cvNote: '<span class="gact">ばねをドラッグ</span>しても F を変えられる',
  graph: 'pull',
  /* 再生：傾くか すべるかが起きて 0.8 N 進んだところで止める */
  /* 再生：先に起こるほうが起きて 0.8 N 進んだところで止める。もう片方の条件までは進めない */
  playStop: function (v) {
    var dm = P.box.dims(v.ab);
    var f0 = P.pull.F0(P.box.M, dm.a, dm.b * v.bp), fs = P.pull.Fslip(P.box.M, v.mu);
    var first = Math.min(f0, fs), second = Math.max(f0, fs);
    return Math.min(first + 0.8, Math.max(first + 0.1, second - 0.1));
  },
  slipFirst: function (v) { var dm = P.box.dims(v.ab); return P.pull.state(P.box.M, dm.a, v.mu, v.F, dm.b * v.bp).slipFirst; },
  moment2: { label: 'すべる瞬間をスローで', dur: 4.0, range: function (v) { var Fs = P.pull.Fslip(P.box.M, v.mu); return { k: 'F', from: Math.max(0, Fs - 0.8), to: Math.min(R3.FMAX, Fs + 0.8), hold: 0.8 }; } },
  sub: '床の上の箱を、<b>ばねから受ける力 $F$ で左向きに</b>引く（ばねの左端をドラッグしても伸ばせる）。' +
    '傾く力は $F_0 = \\dfrac{mga}{2b\\prime}$（回転軸のまわりのモーメントのつりあい）、すべる力は $F_s = \\mu mg$。<b>先に来るほうが実際に起こる</b>。' +
    '箱の質量は $m = 1.0\\ \\mathrm{kg}$（$mg = 9.8\\ \\mathrm{N}$）。',
  cw: function (v, s) { return (s && s._narrow) ? 480 : 780; },
  ch: function (v, s) { return (s && s._short) ? 250 : 300; },
  drag: true,
  abDef: '4:4', bpDef: 1,
  abLabel: '箱の 幅a:高さb',
  bpLabel: '$F$ の作用点の高さ $b\\prime$',
  bpKeys: [{ v: 1, label: '$b\\prime = b$' }, { v: 0.75, label: '$b\\prime = \\tfrac{3}{4}b$' }, { v: 0.5, label: '$b\\prime = \\tfrac{1}{2}b$' }, { v: 0.25, label: '$b\\prime = \\tfrac{1}{4}b$' }],
  vars: [
    { k: 'F', label: 'ばねから受ける力 $F$', unit: ' N', min: 0, max: R3.FMAX, step: 0.1, dec: 1, def: 0,
      tick: function (v) {
        var dm = P.box.dims(v.ab), m = P.box.M, F0 = P.pull.F0(m, dm.a, dm.b * v.bp), Fs = P.pull.Fslip(m, v.mu);
        return { at: F0, label: '傾く力 $F_0 = ' + fmt(F0, 2) + '\\ \\mathrm{N}$' + (F0 > R3.FMAX ? '（範囲外）' : ''),
          at2: Fs, label2: 'すべる力 $F_s = \\mu mg = ' + fmt(Fs, 2) + '\\ \\mathrm{N}$' };
      } },
    { k: 'mu', label: '静止摩擦係数 $\\mu$', unit: '', min: 0, max: 1.5, step: 0.05, dec: 2, def: 0.60 }
  ],
  /* 箱の形（a:b）を変えて、先に起こることを入れかえる（μ・b′ は既定のまま） */
  presets: [
    { label: 'すべるより先に傾く', fn: function (s) { s.v.mu = 0.60; s.ab = '4:4'; s.bp = 1; s.anim = null; },
      is: function (v) { var dm = P.box.dims(v.ab); return !P.pull.state(P.box.M, dm.a, v.mu, v.F, dm.b * v.bp).slipFirst; } },
    { label: '傾くより先にすべる', fn: function (s) { s.v.mu = 0.60; s.ab = '8:2'; s.bp = 1; s.anim = null; },
      is: function (v) { var dm = P.box.dims(v.ab); return P.pull.state(P.box.M, dm.a, v.mu, v.F, dm.b * v.bp).slipFirst; } }
  ],
  vis: [
    { k: 'F', label: '力を表示', def: false },
    { k: 'Sum', label: '引く力と重力を合成（＝作用線を表示）', def: false },
    { k: 'Fc', label: '抗力を分解', def: false },
    { k: 'Hide', label: '抗力のベクトルを消す', def: false },
    { k: 'AB', label: '箱の $a$・$b$・$b\\prime$ と $\\mu$ を表示', def: false },
    { k: 'Grid', label: '箱の分割線を表示', def: true }
  ],
  moment: {
    label: '傾く瞬間をスローで', dur: 4.0,
    range: function (v) {
      var dm = P.box.dims(v.ab), F0 = P.pull.F0(P.box.M, dm.a, dm.b * v.bp);
      return { k: 'F', from: Math.max(0, F0 - 0.8), to: Math.min(R3.FMAX, F0 + 0.8), hold: 0.8 };
    }
  },
  dragDown: function (s, lx, ly) {
    var h = s._handle; if (!h) return false;
    return Math.abs(lx - h.x) < 40 && Math.abs(ly - h.y) < 28;
  },
  drag: function (s, lx, ly) {
    var v = V(s), dm = P.box.dims(s.ab);
    /* 箱の左の面 → ばねの左端までの長さから伸びを出す（箱は動かさない） */
    var nar = !!s._narrow, cv = document.getElementById('mainCv');
    var bx = 6 + (nar ? ((cv._cw || 480) - 12) * 0.66 : R3.BX);
    var len = (bx - lx) / ZS;
    s.v.F = clamp(Math.round((len - R3.NAT) * R3.K * 10) / 10, 0, R3.FMAX);
  },
  onVis: function (s, key, on) { if (key === 'showSum') s.o.showL = on; },
  verdict: function (v) {
    var dm = P.box.dims(v.ab), stt = P.pull.state(P.box.M, dm.a, v.mu, v.F, dm.b * v.bp);
    return { F0: +stt.F0.toFixed(4), Fs: +stt.Fslip.toFixed(4), first: stt.first, slipFirst: stt.slipFirst,
      contact: +P.pull.contact(P.box.M, dm.a, v.F, dm.b * v.bp).toFixed(4) };
  },
  result: function (v, s) {
    var dm = P.box.dims(v.ab), bp = dm.b * v.bp, stt = P.pull.state(P.box.M, dm.a, v.mu, v.F, bp);
    var now = stt.tip ? '傾いた！' : (stt.slip ? 'すべった！' : 'まだ動かない');
    var items = [
      { k: '箱', v: 'a = ' + fmt(dm.a, 2) + ' m，b = ' + fmt(dm.b, 2) + ' m，b′ = ' + fmt(bp, 2) + ' m' },
      { k: "傾く力 $F_0 = \\dfrac{mga}{2b\\prime}$", v: fmt(stt.F0, 2) + ' N', kbox: !stt.slipFirst },
      { k: "すべる力 $F_s = \\mu mg$", v: fmt(stt.Fslip, 2) + ' N', kbox: stt.slipFirst },
      { k: 'いま', v: now, cls: stt.tip ? 'tip' : (stt.slip ? 'slip' : '') }
    ];
    var note = '';
    if (hintOn(s)) note = (stt.slipFirst ? '$\\mu mg < \\dfrac{mga}{2b\\prime}$ なので、傾く前にすべり出す。' : '$\\dfrac{mga}{2b\\prime} \\leqq \\mu mg$ なので、すべる前に傾く。') +
      '　作用点 $b\\prime$ を低くすると $F_0$ が大きくなる（傾きにくい）。';
    return { items: items, note: note };
  },
  draw: function (ctx, s, W, H) {
    var region = { x0: 6, y0: 8, w: W - 12, h: H - 16 };
    var sc = drawR3Scene(ctx, s, region);
    var v = V(s);
    if (hintOn(s)) {
      var tx = region.x0 + region.w - 8, ty = region.y0 + 14;
      if (sc.stt.tip) {
        label(ctx, '重力と引く力の合力の作用線が回転軸より左（外）に出ると回転する', tx, ty, { size: 11, color: '#9b2418', align: 'right' });
      } else if (sc.stt.slip) {
        label(ctx, "F ≧ μmg：引く力が最大摩擦力をこえて、すべり出した", tx, ty, { size: 11, color: '#0a5c5c', align: 'right' });
      } else if (v.F > 0.05) {
        label(ctx, '3 力（重力・引く力・抗力）の作用線は 1 点で交わる', tx, ty, { size: 11, color: '#3d4c5a', align: 'right' });
        label(ctx, 'F が大きいほど、抗力の作用点は回転軸のほうへ動いていく', tx, ty + 18, { size: 11, color: '#3d4c5a', align: 'right' });
      }
    } else {
      label(ctx, "F を変えて、傾くか・すべるかを見よう", region.x0 + region.w - 8, region.y0 + 14, { size: 11, color: COL.sub, align: 'right' });
    }

  },
  below: function (s) {
    return '<div class="bcard"><h3>＜考え方＞　床の上の直方体を引く場合' +
      '<a class="cmplink" href="#4-2" data-goto="r2">比較してみよう　板の角度を変える →</a></h3>' +
      '<canvas id="r3think"></canvas>' +
      '<p>引く力を大きくしていくと、<b>床からの抗力の作用点</b>が中央から回転軸のほうへずれていく。重力と引く力を合成した<b>合力の作用線</b>と、抗力の作用線は同じ直線上にある（3 力の作用線は 1 点で交わる）。' +
      '<b>抗力の作用点が回転軸に一致した瞬間</b>（＝合力の作用線が回転軸を通った瞬間）に傾きはじめる。回転軸のまわりのモーメントのつりあいから $F_0 \\cdot b\\prime = mg\\cdot\\dfrac{a}{2}$、つまり $F_0 = \\dfrac{mga}{2b\\prime}$。' +
      '<b>作用点 $b\\prime$ が高いほど小さな力で傾く</b>。一方すべり出す力 $F_s = \\mu mg$ は $b\\prime$ によらないので、$b\\prime$ を低くしていくと「傾く」から「すべる」に変わる。</p></div>';
  },
  drawBelow: function (s) {
    var c = document.getElementById('r3think'); if (c) drawThinkPull(c);
  }
};

