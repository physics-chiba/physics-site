/* ===== 55_momfx.js ===== */
/* ================================================================
   ②-2・②-3 の右の列「それぞれの力のモーメントの効果」（第 66 回）
   test/202611-2-review-exam.html の大問3 と同じしくみ：
   ・4 つの力それぞれに「○ のモーメント」と「仮に ○ がもっと大きかったら？」（1.5 倍。もう一度押すと、もとにもどす）。
   ・軸は「点 A／棒の重心／点 B」。えらんだ力だけ、矢印・作用線（破線）・うで（緑の太線と直角の印）を描き、
     下に「力 × うで」の計算と、4 つの力のモーメントの一覧、つりあうかどうか。
   ・つりあいがくずれると、棒が軸のまわりに回り出す（うすい棒がもとの位置、赤い曲がった矢印）。
   ・力の大きさは W（棒の重さ）を 1、長さは L（棒の長さ）を 1 として、モーメントは WL の何倍かで書く。
   ・座標は L を 1 とし、x は右、y は上が正。モーメントは反時計回りを正。
   ================================================================ */
var MF_ARM = '#0f7b3e', MF_PHI = 50 * Math.PI / 180, MF_TFALL = 1.6;

var MF = {
  /* ②-2 糸でつるした棒：A（壁がわ）・O（中点）・B。T_B は B から C へ（水平と θ） */
  m2s2: {
    keys: ['W', 'TA', 'TB', 'NA'], defAx: 'A',
    html: { W: '<i>W</i>', TA: '<i>T</i><sub>A</sub>', TB: '<i>T</i><sub>B</sub>', NA: '<i>N</i><sub>A</sub>' },
    nm: { W: 'W', TA: 'T_A', TB: 'T_B', NA: 'N_A' },
    col: { W: COL.force, TA: COL.hand, TB: COL.hand, NA: COL.norm },
    axes: [['A', '点 A を軸'], ['G', '棒の重心 O を軸'], ['B', '点 B を軸']],
    gName: 'O',
    geom: function (v) { return { A: [0, 0], B: [1, 0], G: [0.5, 0] }; },
    force: function (v, k) {
      var th = v.th * DEG, s = Math.sin(th), c = Math.cos(th);
      if (k === 'W') return { p: [0.5, 0], d: [0, -1], f: 1 };
      if (k === 'TA') return { p: [0, 0], d: [0, 1], f: 0.5 };
      if (k === 'TB') return { p: [1, 0], d: [-c, s], f: 1 / (2 * s) };
      return { p: [0, 0], d: [1, 0], f: c / (2 * s) };                 /* N_A：壁から水平に */
    },
    arm: {
      A: { W: 'L/2', TA: '0', TB: 'L sinθ', NA: '0' },
      G: { W: '0', TA: 'L/2', TB: '(L/2) sinθ', NA: '0' },
      B: { W: 'L/2', TA: 'L', TB: '0', NA: '0' }
    }
  },
  /* ②-3 壁に立てかけた棒：A（壁がわ・上）・G（中点）・B（床がわ）。f は B で壁の向き */
  m2s3: {
    keys: ['W', 'N1', 'N2', 'f'], defAx: 'B', labL: { W: 1 },
    html: { W: '<i>W</i>', N1: '<i>N</i><sub>1</sub>', N2: '<i>N</i><sub>2</sub>', f: '<i>f</i>' },
    nm: { W: 'W', N1: 'N₁', N2: 'N₂', f: 'f' },
    col: { W: COL.force, N1: COL.norm, N2: COL.norm, f: COL.fric },
    axes: [['A', '点 A を軸'], ['G', '棒の重心 G を軸'], ['B', '点 B を軸']],
    gName: 'G',
    geom: function (v) { var th = v.th * DEG, s = Math.sin(th), c = Math.cos(th); return { A: [0, s], B: [c, 0], G: [c / 2, s / 2] }; },
    force: function (v, k) {
      var th = v.th * DEG, s = Math.sin(th), c = Math.cos(th), n = c / (2 * s);   /* すべらないとしたときの N₁ = f = W/(2tanθ) */
      if (k === 'W') return { p: [c / 2, s / 2], d: [0, -1], f: 1 };
      if (k === 'N1') return { p: [0, s], d: [1, 0], f: n };
      if (k === 'N2') return { p: [c, 0], d: [0, 1], f: 1 };
      return { p: [c, 0], d: [-1, 0], f: n };
    },
    arm: {
      A: { W: '(L/2) cosθ', N1: '0', N2: 'L cosθ', f: 'L sinθ' },
      G: { W: '0', N1: '(L/2) sinθ', N2: '(L/2) cosθ', f: '(L/2) sinθ' },
      B: { W: '(L/2) cosθ', N1: 'L sinθ', N2: '0', f: '0' }
    },
    note: function (v) { return v.th < DEFS['m2s3'].thc(v) - 1e-9 ? '（いまはすべっている。すべらないとしたときの力で考える）' : ''; }
  }
};

function mfState(s, id) {
  if (!s._mf) s._mf = { k: null, ax: MF[id].defAx, mult: {}, t: 0, axT: -1e9, vkey: '' };
  return s._mf;
}
function mfMul(m, k) { return m.mult[k] || 1; }
/* 軸 P のまわりのモーメント（反時計回りを正、WL を 1）とうでの長さ（L を 1） */
function mfMom(sp, v, ax, k, mult) {
  var g = sp.geom(v), P = g[ax], F = sp.force(v, k);
  var rx = F.p[0] - P[0], ry = F.p[1] - P[1], cr = rx * F.d[1] - ry * F.d[0];
  var arm = Math.abs(cr) < 1e-9 ? 0 : Math.abs(cr);
  return { arm: arm, tau: cr * F.f * (mult || 1), f: F.f * (mult || 1), F: F, P: P };
}
function mfNet(sp, v, m) {
  var sum = 0;
  sp.keys.forEach(function (k) { sum += mfMom(sp, v, m.ax, k, mfMul(m, k)).tau; });
  return sum;
}
function mfPhi(sp, v, m) {
  var tau = mfNet(sp, v, m);
  if (Math.abs(tau) < 1e-6 || m.t <= 0) return 0;
  return (tau > 0 ? 1 : -1) * Math.min(MF_PHI, 1.6 * Math.abs(tau) * m.t * m.t);
}

/* ---------- 右の列の HTML（ボタン）---------- */
function mfHtml(id) {
  var sp = MF[id];
  return '<div class="mfbox pulse" id="mfbox"><div class="mfhead"><p class="mft">それぞれの力のモーメントの効果</p>' +
    '<button type="button" class="resetall mfreset">最初の設定に戻す</button></div>' +
    sp.keys.map(function (k) {
      return '<div class="mfrow"><button type="button" class="sub mfk" data-mfk="' + k + '"><span class="mfcb" aria-hidden="true"></span>' + sp.html[k] + ' のモーメント</button>' +
        '<button type="button" class="sub mfsz" data-mfsz="' + k + '">仮に ' + sp.html[k] + ' がもっと大きかったら？</button></div>';
    }).join('') +
    '<div class="mfrow mfax"><span class="mfl">軸：</span><span class="mfseg" role="group" aria-label="回転の軸">' +
    sp.axes.map(function (a) { return '<button type="button" class="sub" data-mfax="' + a[0] + '">' + a[1] + '</button>'; }).join('') +
    '</span></div></div>';
}
function mfSync(s, id) {
  var box = document.getElementById('mfbox'); if (!box) return;
  var sp = MF[id], m = mfState(s, id);
  Array.prototype.forEach.call(box.querySelectorAll('[data-mfk]'), function (b) {
    var on = m.k === b.getAttribute('data-mfk');
    b.classList.toggle('on', on); b.setAttribute('aria-pressed', on ? 'true' : 'false');
    b.classList.toggle('mfglow', !m.k);                        /* 何もえらんでいないときは、モーメントのボタンを光らせる */
  });
  Array.prototype.forEach.call(box.querySelectorAll('[data-mfsz]'), function (b) {
    var k = b.getAttribute('data-mfsz'), big = mfMul(m, k) > 1;
    b.classList.toggle('on', big);
    b.innerHTML = big ? 'もとの ' + sp.html[k] + ' にもどす' : '仮に ' + sp.html[k] + ' がもっと大きかったら？';
    b.classList.toggle('mfglow', m.k === k && !big);           /* えらんだ力の「もっと大きかったら？」を光らせる */
  });
  Array.prototype.forEach.call(box.querySelectorAll('[data-mfax]'), function (b) {
    var on = m.ax === b.getAttribute('data-mfax');
    b.classList.toggle('on', on); b.setAttribute('aria-pressed', on ? 'true' : 'false');
  });
}
function mfReset(m) { m.mult = {}; m.t = 0; }
function mfWire(id) {
  return function (s, host) {
    var box = host.querySelector('#mfbox'); if (!box) return;
    var m = mfState(s, id);
    function go() { mfSync(s, id); renderActive(); }
    Array.prototype.forEach.call(box.querySelectorAll('[data-mfk]'), function (b) {
      b.addEventListener('click', function () {
        var k = b.getAttribute('data-mfk');
        mfReset(m); m.k = (m.k === k) ? null : k;
        if (m.k) m.axT = performance.now();
        go();
      });
    });
    Array.prototype.forEach.call(box.querySelectorAll('[data-mfsz]'), function (b) {
      b.addEventListener('click', function () {
        var k = b.getAttribute('data-mfsz'), big = mfMul(m, k) > 1;
        if (m.k !== k) { mfReset(m); m.k = k; m.axT = performance.now(); }
        m.mult = {}; if (!big) m.mult[k] = 1.5;
        m.t = 0;
        go();
      });
    });
    Array.prototype.forEach.call(box.querySelectorAll('[data-mfax]'), function (b) {
      b.addEventListener('click', function () {
        mfReset(m); m.ax = b.getAttribute('data-mfax');
        if (!m.k) m.k = MF[id].keys[0];
        m.axT = performance.now();
        go();
      });
    });
    box.querySelector('.mfreset').addEventListener('click', function () {
      mfReset(m); m.k = null; m.ax = MF[id].defAx; m.axT = -1e9; go();
    });
    mfSync(s, id);
  };
}
/* 毎フレーム：回り出すアニメと「ここが軸」の吹き出し。描き直すときは true */
function mfTick(id) {
  return function (s, dt) {
    var m = mfState(s, id), v = V(s), key = v.th + '|' + v.W + '|' + v.mu, re = false;
    if (key !== m.vkey) {                                   /* 角度などを変えたら、大きくした力はもとにもどす */
      if (m.vkey && (m.t > 0 || Object.keys(m.mult).length)) { mfReset(m); mfSync(s, id); re = true; }
      m.vkey = key;
    }
    if (m.k && Object.keys(m.mult).length && Math.abs(mfNet(MF[id], v, m)) > 1e-6 && m.t < MF_TFALL) { m.t = Math.min(MF_TFALL, m.t + dt); re = true; }
    var age = performance.now() - m.axT;
    if (age < 3000 + 100) re = true;                       /* 吹き出しを出している間と、消した直後 */
    return re;
  };
}

/* ---------- 右の列の図 ---------- */
function mfRod(ctx, a, b, alpha) {
  ctx.save(); if (alpha != null) ctx.globalAlpha = alpha;
  ctx.strokeStyle = '#8a5a2b'; ctx.lineWidth = 7; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); ctx.restore();
}
function mfAxisBubble(ctx, x, y, up) {
  var t = 'ここが軸', w, h = 24;
  ctx.save(); ctx.font = 'bold 13px ' + FONT; w = ctx.measureText(t).width + 16;
  var bx = x + 14, by = up ? y - 34 : y - h / 2;
  ctx.fillStyle = '#1b1f24';
  ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(bx, by, w, h, 8); else ctx.rect(bx, by, w, h); ctx.fill();
  ctx.beginPath();
  if (up) { ctx.moveTo(bx + 6, by + h); ctx.lineTo(bx + 16, by + h); ctx.lineTo(x + 6, y - 6); }
  else { ctx.moveTo(bx, by + 7); ctx.lineTo(bx, by + h - 7); ctx.lineTo(x + 8, y); }
  ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#fff'; ctx.textBaseline = 'middle'; ctx.fillText(t, bx + 8, by + h / 2 + 1);
  ctx.restore();
}
var MF_W = 400, MF_FH = 250, MF_H = 510;
function mfDraw(id) {
  return function (ctx, s, W, H) {
    var sp = MF[id], v = V(s), m = mfState(s, id), th = v.th * DEG, g = sp.geom(v);
    var S, ox, oy;                                           /* 図の座標（L を 1、y は上）→ 画面 */
    ctx.save(); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H); ctx.restore();
    if (id === 'm2s2') { S = 190; ox = 80; oy = 196; }
    else { S = Math.min(215, 170 / Math.sin(th), 230 / Math.cos(th)); ox = 70; oy = 222; }
    function P(p) { return [ox + p[0] * S, oy - p[1] * S]; }
    var A = P(g.A), B = P(g.B), Gp = P(g.G), fpx = 46;     /* 力 W ＝ 46 px */
    var LB = [];                                             /* 描いた文字の箱（うでの文字がよける） */
    function lb(txt, x, y, o) {
      label(ctx, txt, x, y, o);
      ctx.save(); ctx.font = 'bold ' + (o.size || 13) + 'px ' + FONT; var w = ctx.measureText(txt.replace(/_/g, '')).width; ctx.restore();
      var x0 = o.align === 'right' ? x - w : (o.align === 'left' ? x : x - w / 2);
      LB.push([x0 - 2, y - 9, x0 + w + 2, y + 9]);
    }
    NO_SHIFT = true;
    /* 背景：壁・床・糸 */
    ctx.save(); ctx.fillStyle = '#e4e8ec'; ctx.strokeStyle = '#8b949e'; ctx.lineWidth = 1.1;
    if (id === 'm2s2') { ctx.beginPath(); ctx.rect(ox - 20, 22, 16, oy + 30 - 22); ctx.fill(); ctx.stroke(); }
    else { ctx.beginPath(); ctx.rect(ox - 20, 18, 16, oy - 18); ctx.fill(); ctx.stroke(); }
    ctx.restore();
    if (id === 'm2s2') hatchLine(ctx, ox - 4, 22, ox - 4, oy + 30, 1);
    else { hatchLine(ctx, ox - 4, 18, ox - 4, oy, 1); ground(ctx, ox - 20, W - 12, oy); }
    if (id === 'm2s2') {
      var C = [ox, oy - S * Math.tan(th)];
      ctx.save(); ctx.strokeStyle = '#9aa5b0'; ctx.lineWidth = 1.4;
      ctx.beginPath(); ctx.moveTo(A[0], A[1]); ctx.lineTo(C[0], C[1]); ctx.moveTo(B[0], B[1]); ctx.lineTo(C[0], C[1]); ctx.stroke(); ctx.restore();
      lb('C', C[0] + 12, C[1] - 6, { size: 12.5, bold: true, avoid: false });
    }
    var phi = m.k ? mfPhi(sp, v, m) : 0;
    mfRod(ctx, A, B, Math.abs(phi) > 1e-4 ? 0.28 : null);
    actPoint(ctx, Gp[0], Gp[1], '#1b1f24');
    if (id === 'm2s2') {
      lb('A', A[0] + 2, A[1] + 18, { size: 13, bold: true, avoid: false });
      lb('B', B[0] + 4, B[1] + 18, { size: 13, bold: true, avoid: false });
      lb('O', Gp[0] - 2, Gp[1] + 18, { size: 13, bold: true, avoid: false });
    } else {
      lb('A', A[0] + 16, A[1] - 6, { size: 13, bold: true, avoid: false });
      lb('B', B[0] + 10, B[1] + 16, { size: 13, bold: true, avoid: false });
      lb('G', Gp[0] + 12, Gp[1] - 8, { size: 13, bold: true, avoid: false });
      angArc(ctx, B[0], B[1], 26, Math.PI, Math.PI + th, '', 0, 0);
      lb('θ', B[0] - 38 * Math.cos(th / 2), B[1] - 38 * Math.sin(th / 2), { size: 12, color: '#3d4c5a', avoid: false });
    }
    function fArrow(k, mult, withLab, only) {
      var F = sp.force(v, k), p = P(F.p), L = F.f * (mult || 1) * fpx;
      var q = [p[0] + F.d[0] * L, p[1] - F.d[1] * L];
      if (!only) arrow(ctx, p[0], p[1], q[0], q[1], 'force', 0.85, sp.col[k]);
      var lf = F.d[0] < -0.3 || (sp.labL && sp.labL[k]);       /* 文字を矢印の左に置くか */
      var txt = sp.nm[k] + ((mult || 1) > 1 ? '×1.5' : ''), lx = q[0] + (lf ? -10 : 12), ly = q[1] + (F.d[1] < -0.3 ? 4 : -8);
      if (only) { ctx.save(); ctx.font = 'bold 13px ' + FONT; var w = ctx.measureText(txt.replace(/_/g, '')).width; ctx.restore();
        return lf ? [lx - w - 2, ly - 9, lx + 2, ly + 9] : [lx - 2, ly - 9, lx + w + 2, ly + 9]; }
      if (withLab) label(ctx, txt, lx, ly, { size: 13, bold: true, color: sp.col[k], align: lf ? 'right' : 'left', avoid: false });
      return { p: p, q: q, F: F };
    }
    var ty = MF_FH + 8;                                     /* 下の文字の始まり */
    if (!m.k) {                                             /* 何もえらんでいないとき：4 つの力を全部 */
      sp.keys.forEach(function (k) { fArrow(k, 1, true); });
      NO_SHIFT = false;
      label(ctx, '上のボタンで力をえらぶと、', 16, ty + 18, { size: 14, bold: true, color: '#1f3b57', align: 'left', avoid: false });
      label(ctx, 'その力のうでとモーメントが出る', 16, ty + 42, { size: 14, bold: true, color: '#1f3b57', align: 'left', avoid: false });
      if (sp.note && sp.note(v)) label(ctx, sp.note(v), 16, ty + 74, { size: 12, bold: true, color: '#9b2418', align: 'left', avoid: false });
      return;
    }
    var k = m.k, mk = mfMul(m, k), R = mfMom(sp, v, m.ax, k, mk), Pa = P(R.P);
    /* 図の部分だけに描く（作用線が下の文字にかからないように） */
    ctx.save(); ctx.beginPath(); ctx.rect(0, 0, W, MF_FH); ctx.clip();
    var F = R.F, p = P(F.p), dx = F.d[0], dy = -F.d[1];
    var t0 = (Pa[0] - p[0]) * dx + (Pa[1] - p[1]) * dy, H0 = [p[0] + dx * t0, p[1] + dy * t0];
    /* 棒の半分ずつに「L/2」（棒の長さ L、重心は中点）。うでと反対がわに置く */
    var rl = Math.hypot(B[0] - A[0], B[1] - A[1]), ux = (B[0] - A[0]) / rl, uy = (B[1] - A[1]) / rl, nx = uy, ny = -ux;
    if (id === 'm2s2') { nx = 0; ny = 1; }
    else {
      if (ny > 0) { nx = -nx; ny = -ny; }                    /* ふだんは右上がわ */
      if ((H0[0] - Gp[0]) * nx + (H0[1] - Gp[1]) * ny > 4) { nx = -nx; ny = -ny; }
    }
    var off = id === 'm2s2' ? 36 : 16, boxes = LB.slice();
    boxes.push(fArrow(k, mk, true, true));                   /* 力の名前の文字 */
    [[A, Gp], [Gp, B]].forEach(function (q) {
      var lx, ly;
      [0.5, 0.35, 0.65, 0.22, 0.78].some(function (fr) {      /* ほかの文字に重なるときは、棒にそって少しずらす */
        lx = q[0][0] + (q[1][0] - q[0][0]) * fr + nx * off; ly = q[0][1] + (q[1][1] - q[0][1]) * fr + ny * off;
        return !boxes.some(function (bb) { return Math.min(lx + 14, bb[2]) - Math.max(lx - 14, bb[0]) > 0 && Math.min(ly + 8, bb[3]) - Math.max(ly - 8, bb[1]) > 0; });
      });
      label(ctx, 'L/2', lx, ly, { size: 12, bold: true, color: '#5b6672', avoid: false });
      boxes.push([lx - 14, ly - 8, lx + 14, ly + 8]);
    });
    /* 文字（A・B・G など）と力の矢印も、うでの文字がよける相手にする */
    [A, B, Gp].forEach(function (q) { boxes.push([q[0] - 8, q[1] - 8, q[0] + 8, q[1] + 8]); });
    var fF = sp.force(v, k), fp = P(fF.p), fq = [fp[0] + fF.d[0] * fF.f * mk * fpx, fp[1] - fF.d[1] * fF.f * mk * fpx];
    /* 作用線（破線） */
    ctx.save(); ctx.strokeStyle = '#9aa3ac'; ctx.lineWidth = 1.2; ctx.setLineDash([6, 5]);
    ctx.beginPath(); ctx.moveTo(p[0] - dx * 600, p[1] - dy * 600); ctx.lineTo(p[0] + dx * 600, p[1] + dy * 600); ctx.stroke(); ctx.restore();
    /* うで：軸から作用線へ垂線 */
    var t = (Pa[0] - p[0]) * dx + (Pa[1] - p[1]) * dy, Hh = [p[0] + dx * t, p[1] + dy * t];
    var al = Math.hypot(Pa[0] - Hh[0], Pa[1] - Hh[1]);
    if (al > 2) {
      ctx.save(); ctx.strokeStyle = MF_ARM; ctx.lineWidth = 3.2; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(Pa[0], Pa[1]); ctx.lineTo(Hh[0], Hh[1]); ctx.stroke(); ctx.restore();
      var ax_ = (Hh[0] - Pa[0]) / al, ay_ = (Hh[1] - Pa[1]) / al, rs = 8, sg = t >= 0 ? -1 : 1;   /* 直角の印 */
      ctx.save(); ctx.strokeStyle = MF_ARM; ctx.lineWidth = 1.2; ctx.beginPath();
      ctx.moveTo(Hh[0] - ax_ * rs, Hh[1] - ay_ * rs); ctx.lineTo(Hh[0] - ax_ * rs + dx * rs * sg, Hh[1] - ay_ * rs + dy * rs * sg);
      ctx.lineTo(Hh[0] + dx * rs * sg, Hh[1] + dy * rs * sg); ctx.stroke(); ctx.restore();
      /* うでの文字：棒・矢印・ほかの文字に重ならない場所を、うでのまわりからさがす */
      var txt = 'うで ' + sp.arm[m.ax][k];
      ctx.save(); ctx.font = 'bold 13px ' + FONT; var tw = ctx.measureText(txt).width; ctx.restore();
      var segs = [[A, B, 9], [fp, fq, 8], [Pa, Hh, 6]], best = null;
      if (id === 'm2s3') segs.push([[ox, oy], [W, oy], 7]);   /* 床 */
      else segs.push([B, [ox, oy - S * Math.tan(th)], 5]);    /* 糸 BC */
      var near = function (q, a, b) { var vx = b[0] - a[0], vy = b[1] - a[1], L2 = vx * vx + vy * vy || 1, u = clamp(((q[0] - a[0]) * vx + (q[1] - a[1]) * vy) / L2, 0, 1);
        return Math.hypot(q[0] - a[0] - u * vx, q[1] - a[1] - u * vy); };
      [0.5, 0.25, 0.75, 1].forEach(function (fr) {
        var cx0 = Pa[0] + (Hh[0] - Pa[0]) * fr, cy0 = Pa[1] + (Hh[1] - Pa[1]) * fr;
        for (var ai = 0; ai < 16; ai++) for (var rr = 18; rr <= 54; rr += 12) {
          var an = ai * Math.PI / 8, cx = cx0 + Math.cos(an) * (rr + tw / 2 * Math.abs(Math.cos(an))), cy = cy0 + Math.sin(an) * rr;
          var bx = [cx - tw / 2 - 3, cy - 9, cx + tw / 2 + 3, cy + 9], pen = rr * 0.6 + fr * 4;
          if (bx[0] < ox - 2 || bx[2] > W - 4 || bx[1] < 4 || bx[3] > MF_FH - 4) pen += 1000;
          boxes.forEach(function (q) { var ix = Math.min(bx[2], q[2]) - Math.max(bx[0], q[0]), iy = Math.min(bx[3], q[3]) - Math.max(bx[1], q[1]); if (ix > 0 && iy > 0) pen += 300 + ix * iy; });
          segs.forEach(function (sg2) {
            for (var j = 0; j <= 4; j++) { var qx = bx[0] + (bx[2] - bx[0]) * j / 4;
              [bx[1], cy, bx[3]].forEach(function (qy) { var dd = near([qx, qy], sg2[0], sg2[1]); if (dd < sg2[2]) pen += (sg2[2] - dd) * 25; }); }
          });
          if (!best || pen < best.p) best = { p: pen, x: cx, y: cy };
        }
      });
      label(ctx, txt, best.x, best.y, { size: 13, bold: true, color: MF_ARM, align: 'center', avoid: false, clamp: false });
    }
    fArrow(k, mk, true);
    NO_SHIFT = false;
    ctx.restore();
    axisDot(ctx, Pa[0], Pa[1]);
    if (performance.now() - m.axT < 3000) mfAxisBubble(ctx, Pa[0], Pa[1], m.ax !== 'A' || id === 'm2s2');
    /* つりあわないとき：軸のまわりに回る棒 */
    if (Math.abs(phi) > 1e-4) {
      var rot = function (q) { var c = Math.cos(-phi), sn = Math.sin(-phi), ddx = q[0] - Pa[0], ddy = q[1] - Pa[1]; return [Pa[0] + ddx * c - ddy * sn, Pa[1] + ddx * sn + ddy * c]; };
      var A2 = rot(A), B2 = rot(B), G2 = rot(Gp);
      mfRod(ctx, A2, B2); actPoint(ctx, G2[0], G2[1], '#1b1f24');
      var rr = 34, a0 = -Math.PI / 2, a1 = a0 - phi * 1.6, ccw = phi > 0;
      ctx.save(); ctx.strokeStyle = '#c0392b'; ctx.lineWidth = 2.6; ctx.beginPath(); ctx.arc(Pa[0], Pa[1], rr, a0, a1, ccw); ctx.stroke();
      var ex = Pa[0] + rr * Math.cos(a1), ey = Pa[1] + rr * Math.sin(a1), tx = ccw ? Math.sin(a1) : -Math.sin(a1), tyy = ccw ? -Math.cos(a1) : Math.cos(a1);
      ctx.fillStyle = '#c0392b'; ctx.beginPath(); ctx.moveTo(ex + tx * 9, ey + tyy * 9); ctx.lineTo(ex - tyy * 6, ey + tx * 6); ctx.lineTo(ex + tyy * 6, ey - tx * 6); ctx.closePath(); ctx.fill(); ctx.restore();
      axisDot(ctx, Pa[0], Pa[1]);
    }
    /* 下：計算と一覧 */
    ctx.save(); ctx.strokeStyle = '#e3ddd2'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(10, MF_FH); ctx.lineTo(W - 10, MF_FH); ctx.stroke(); ctx.restore();
    var axName = { A: '点 A', G: '棒の重心 ' + sp.gName, B: '点 B' }[m.ax], x0 = 14, y = ty + 12;
    var L1 = function (txt, yy, o) { o = o || {}; label(ctx, txt, o.x || x0, yy, { size: o.size || 13, bold: o.bold !== false, color: o.color || '#1b1f24', align: 'left', avoid: false }); };
    L1(axName + ' を軸としたモーメント', y, { size: 13.5 });
    var fstr = function (f) { return Math.abs(f - 1) < 1e-9 ? 'W' : fmt(f, 2) + 'W'; };
    if (R.arm < 1e-6) {
      L1(sp.nm[k] + ' の作用線が軸を通る → うで 0、モーメント 0', y + 24, { color: MF_ARM });
      if (mk > 1) L1('大きくしても、そもそもモーメントは 0', y + 46, { color: '#c0392b' });
    } else {
      L1(sp.nm[k] + (mk > 1 ? '（×1.5）' : '') + ' × ' + sp.arm[m.ax][k] + ' ＝ ' + fstr(R.f) + ' × ' + fmt(R.arm, 2) + 'L', y + 24, { color: MF_ARM });
      L1('＝ ' + fmt(Math.abs(R.tau), 2) + ' WL（' + (R.tau > 0 ? '反時計回り' : '時計回り') + '）', y + 46, { color: MF_ARM });
    }
    var yl = y + 74, ccwS = 0, cwS = 0;
    L1('4 つの力（θ ＝ ' + fmt(v.th, 0) + '° のとき）', yl, { size: 11.5, bold: false, color: '#5b6672' });
    sp.keys.forEach(function (kk, i) {
      var r2 = mfMom(sp, v, m.ax, kk, mfMul(m, kk)), yy = yl + 22 + i * 21, on = kk === k;
      if (r2.tau > 1e-9) ccwS += r2.tau; else if (r2.tau < -1e-9) cwS -= r2.tau;
      if (on) { ctx.save(); ctx.fillStyle = '#e6f3ea'; ctx.fillRect(x0 - 4, yy - 10, W - 2 * x0 + 8, 20); ctx.restore(); }
      L1(sp.nm[kk] + (mfMul(m, kk) > 1 ? '×1.5' : ''), yy, { size: 12.5, color: on ? MF_ARM : '#1b1f24', x: x0 + 4 });
      L1(r2.arm < 1e-6 ? '0（作用線が軸を通る）' : fmt(Math.abs(r2.tau), 2) + ' WL　' + (r2.tau > 0 ? '反時計回り' : '時計回り'), yy,
        { size: 12.5, bold: false, color: on ? MF_ARM : '#1b1f24', x: x0 + 70 });
    });
    var yS = yl + 22 + 4 * 21 + 6;
    if (Math.abs(ccwS - cwS) < 0.005) {
      L1('反時計回り ' + fmt(ccwS, 2) + ' ＝ 時計回り ' + fmt(cwS, 2) + '　→ つりあうので、回らない', yS, { color: '#0a7a3a' });
    } else {
      L1('反時計回り ' + fmt(ccwS, 2) + (ccwS > cwS ? ' ＞ ' : ' ＜ ') + '時計回り ' + fmt(cwS, 2), yS, { color: '#c0392b' });
      L1('→ つりあわない！' + (ccwS > cwS ? '反時計回り' : '時計回り') + 'に回る', yS + 21, { color: '#c0392b' });
    }
    if (sp.note && sp.note(v)) L1(sp.note(v), H - 12, { size: 11.5, color: '#9b2418' });
  };
}
