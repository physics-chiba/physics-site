/* ===== 54_mode2.js ===== */
/* ============================================================
   モード 2　力のモーメントのつりあい
     m2s1 … 剛体のつりあいの条件（指の上のペン）
     m2s2 … 糸でつられた棒（教科書の例題を題材にしたシミュレーション）
     m2s3 … 壁に立てかけた棒（θ をたおしていく）
   ============================================================ */
'use strict';

/* ===== 指の上にのせた細長い物体（ペン・バット・軽い棒と球）の共通部品 =====
   spec = {
     L    … 物体の長さ [m]、thick … 太さ [px]、xG … 重心の位置 [m]（左端から）
     body(ctx, x0, Lpx, thick) … 物体の絵（指との接点を原点、下面が y = 0、左端が x0）
     gName … 重心の字（既定「重心 G」）
   }
   s._fx … 指の位置 [m]（左端から）、s._snap … 重心の真下に吸いついているか */
function drawOnFinger(ctx, s, W, H, spec, opt) {
  opt = opt || {};
  var v = V(s);
  var S = (W - (opt.padX || 230)) / spec.L;
  var L = spec.L * S, th = spec.thick;
  var x0 = (W - L) / 2, yc = opt.yc || H * 0.56;              /* 物体の左端・指が触れる高さ（物体の下面） */
  var xg = x0 + spec.xG / spec.L * L;
  var fx = x0 + s._fx / spec.L * L;
  var off = (s._fx - spec.xG) / spec.L;                         /* 重心からのずれ（長さに対する割合。＋ … 指が重心より右） */
  var bal = Math.abs(off) < 1e-6;
  /* 重心が指より左 → 左が下がる（画面では負の回転）。傾きは「回りはじめ」を見せるだけの小さな角度 */
  var tipAng = bal ? 0 : -Math.sign(off) * (0.07 + Math.min(0.12, Math.abs(off) * 0.9));
  var ca = Math.cos(tipAng), sa = Math.sin(tipAng);
  function pp(X, Y) { return { x: fx + X * ca - Y * sa, y: yc + X * sa + Y * ca }; }
  ctx.save();
  ctx.translate(fx, yc); ctx.rotate(tipAng);
  spec.body(ctx, x0 - fx, L, th);
  ctx.restore();
  var G = pp(xg - fx, -(spec.cy ? spec.cy(s._fx / spec.L) : th / 2));   /* 重心（太さのまん中） */
  if (spec.name) { var np = pp(x0 - fx + L * 0.12, -th - 16); label(ctx, spec.name, np.x, np.y, { size: 14, bold: true, color: '#3d4c5a' }); }   /* ものの名前（ペン） */
  pointHand(ctx, fx, yc + 1, 0, opt.handSc || 0.78);             /* 下から指で支える */
  if (!bal) {                                                    /* 回る向きの矢印（落ち着いた色） */
    var dir = -Math.sign(off), rr = 52;
    ctx.save(); ctx.strokeStyle = 'rgba(80,100,125,.8)'; ctx.fillStyle = 'rgba(80,100,125,.8)'; ctx.lineWidth = 2.4;
    var a0 = dir < 0 ? -Math.PI * 0.62 : -Math.PI * 0.38, a1 = dir < 0 ? -Math.PI * 0.88 : -Math.PI * 0.12;
    ctx.beginPath(); ctx.arc(fx, yc, rr, a0, a1, dir < 0); ctx.stroke();
    var ex = fx + rr * Math.cos(a1), ey = yc + rr * Math.sin(a1), tg = a1 + (dir < 0 ? -Math.PI / 2 : Math.PI / 2);
    ctx.beginPath(); ctx.moveTo(ex + 10 * Math.cos(tg), ey + 10 * Math.sin(tg));
    ctx.lineTo(ex + 6 * Math.cos(tg + 2.2), ey + 6 * Math.sin(tg + 2.2));
    ctx.lineTo(ex + 6 * Math.cos(tg - 2.2), ey + 6 * Math.sin(tg - 2.2)); ctx.closePath(); ctx.fill();
    ctx.restore();
  }
  /* 力：重力は重心から真下へ。指が押す力は接点から真上へ（真下に来たら同じ直線上で重なる） */
  var showF = v.showF || v.showL;
  if (v.showL) {                                 /* 作用線（鉛直な点線）：指の力と、それぞれの重力 */
    var xsL = [{ x: fx, c: 'rgba(123,63,212,.55)' }];
    if (spec.forces) spec.forces.forEach(function (fo) { xsL.push({ x: pp(x0 + fo.X / spec.L * L - fx, fo.y || -th / 2).x, c: 'rgba(209,53,43,.5)' }); });
    else xsL.push({ x: G.x, c: 'rgba(209,53,43,.5)' });
    ctx.save(); ctx.lineWidth = 1.3; ctx.setLineDash([7, 5]);
    xsL.forEach(function (q) { ctx.strokeStyle = q.c; ctx.beginPath(); ctx.moveTo(q.x, yc - 140); ctx.lineTo(q.x, yc + 120); ctx.stroke(); });
    ctx.restore();
    label(ctx, '作用線', fx + 8, yc + 110, { size: 12.5, color: '#6b4fb0', align: 'left' });
  }
  var balRes = bal && opt.balRes && spec.forces;   /* モード 3：つりあった瞬間は、質点の重力を薄く、その合力をこく */
  var showRes = opt.balRes && spec.forces && (bal || v.showR);   /* 「質点にはたらく重力の合力を表示」 */
  if ((showF || balRes || showRes) && spec.forces) {     /* 質点ごとの重力（長さは質量に比例）＋ 指が押す力（全体の重さ） */
    NO_SHIFT = true;
    var FT = spec.FT || 92;
    if (showF) arrow(ctx, fx, yc, fx, yc - FT, 'force', 1.05, COL.norm);
    ctx.save(); if (balRes || showRes) ctx.globalAlpha = 0.35;     /* 合力を出すときは、各重力は薄く */
    if (showF || balRes) spec.forces.forEach(function (fo) {
      var q = pp(x0 + fo.X / spec.L * L - fx, fo.y || -th / 2);
      arrow(ctx, q.x, q.y, q.x, q.y + FT * fo.k, 'force', 1.05, COL.force);
      label(ctx, fo.name, q.x + 10, q.y + Math.max(22, FT * fo.k * 0.6), { size: 14, bold: true, color: COL.force, align: 'left' });
    });
    ctx.restore();
    if (showRes) {                               /* 合力（指が押す力とつりあう力） */
      arrow(ctx, G.x, G.y, G.x, G.y + FT, 'force', 1.1, COL.force);
      label(ctx, opt.balRes, G.x - 12, G.y + FT * 0.6, { size: 14, bold: true, color: COL.force, align: 'right' });
    }
    NO_SHIFT = false;
    if (showF) label(ctx, '指が押す力', fx + 12, yc - FT + 6, { size: 14, bold: true, color: COL.norm, align: 'left' });
  } else if (showF) {
    NO_SHIFT = true;
    var FLn = 66;
    arrow(ctx, fx, yc, fx, yc - FLn, 'force', 1.05, COL.norm);
    arrow(ctx, G.x, G.y, G.x, G.y + FLn, 'force', 1.05, COL.force);
    NO_SHIFT = false;
    label(ctx, '指が押す力', fx + 12, yc - FLn + 6, { size: 14, bold: true, color: COL.norm, align: 'left' });
    label(ctx, '重力', G.x - 12, G.y + FLn - 4, { size: 14, bold: true, color: COL.force, align: 'right' });
  }
  if (!opt.hideG || bal) {                   /* 重心をさがすシミュレーション（モード 3）では、見つけるまで出さない（力を表示しても出さない） */
    actPoint(ctx, G.x, G.y, '#1b1f24');
    var gl = spec.gLab ? spec.gLab(G, off) : { x: G.x + (off > 0 ? -40 : 40), y: G.y - th / 2 - 16, align: 'center' };
    label(ctx, spec.gName || '重心 G', gl.x, gl.y, { size: 14, bold: true, color: '#1b1f24', align: gl.align });
    dotLine(ctx, G.x, G.y, G.x, yc + 96, 'rgba(120,132,145,.7)', 1.2, [4, 4]);   /* 重心の真下 */
  }
  if (s._snap) snapGlow(ctx, fx, yc, 18, '#e07b18', 1);
  var bx = fx + (fx < W - 280 ? 190 : -190), by = yc - th - 58;
  /* つりあった瞬間：質点（重さのかかる所）から重心までの距離の比を ↔ で（spec.ratio） */
  if (bal && spec.ratio) {
    var rt = spec.ratio(), ry = yc - th - Math.max(spec.ratioDy || 84, showF && spec.forces ? (spec.FT || 92) + 18 : 0);   /* 力の矢印とぶつからない高さ */
    var P0 = pp(x0 + rt.x[0] / spec.L * L - fx, 0).x, P1 = pp(x0 + rt.x[1] / spec.L * L - fx, 0).x, P2 = pp(x0 + rt.x[2] / spec.L * L - fx, 0).x;
    if (showF) rt.above = true;                   /* 力の矢印を出しているときは、比の札を ↔ の上に */
    ratioDims(ctx, P0, P1, P2, ry, rt);
    by = ry - (rt.above ? 76 : 44);
  }
  if (bal) okBubble(ctx, 'つりあった！', G.x, by, 15);                /* 重心の真上 */
  else calmBubble(ctx, '回ってしまう', bx, by, 15);
  s._geo = { x0: x0, L: L, yc: yc, fx: fx, S: S, len: spec.L };
  return { G: G, bal: bal, fx: fx, yc: yc, pp: pp, x0: x0, L: L };
}
/* 距離の比の ↔（教科書の図と同じ：l₁・l₂ と「l₁ : l₂ = m₂ : m₁」）。x0・xG・x2 … 画面の x、y … 高さ */
function ratioDims(ctx, xa, xg, xb, y, rt) {
  ctx.save(); ctx.strokeStyle = 'rgba(27,31,36,.55)'; ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
  [xa, xg, xb].forEach(function (x) { ctx.beginPath(); ctx.moveTo(x, y - 8); ctx.lineTo(x, y + 30); ctx.stroke(); });
  ctx.restore();
  [[xa, xg], [xg, xb]].forEach(function (q) {
    if (Math.abs(q[1] - q[0]) < 6) return;
    arrow(ctx, (q[0] + q[1]) / 2, y, q[0], y, 'dim', 1.1); arrow(ctx, (q[0] + q[1]) / 2, y, q[1], y, 'dim', 1.1);
  });
  label(ctx, rt.n1 || 'l_1', (xa + xg) / 2, y - 13, { size: 16, bold: true, color: '#1b1f24' });
  label(ctx, rt.n2 || 'l_2', (xg + xb) / 2, y - 13, { size: 16, bold: true, color: '#1b1f24' });
  if (rt.d1) {                                  /* ↔ の下に「○ cm」。となりとぶつかるときは短いほうをもう 1 段下に */
    /* 短い区間の文字は、区間の外がわ（となりと反対がわ）に出す */
    var w1 = Math.abs(xg - xa), w2 = Math.abs(xb - xg), s1 = xa < xg ? -1 : 1;   /* s1 … xa がわの外向き */
    if (w1 < 64) label(ctx, rt.d1, xa + s1 * 8, y, { size: 13, bold: true, color: '#1b1f24', align: s1 < 0 ? 'right' : 'left' });
    else label(ctx, rt.d1, (xa + xg) / 2, y + 14, { size: 13, bold: true, color: '#1b1f24' });
    if (w2 < 64) label(ctx, rt.d2, xb - s1 * 8, y, { size: 13, bold: true, color: '#1b1f24', align: s1 < 0 ? 'left' : 'right' });
    else label(ctx, rt.d2, (xg + xb) / 2, y + 14, { size: 13, bold: true, color: '#1b1f24' });
  }
  /* 比の札 */
  var tx = (Math.min(xa, xb) + Math.max(xa, xb)) / 2, tw;
  ctx.save(); ctx.font = 'bold 15px ' + FONT; tw = ctx.measureText(rt.text.replace(/_/g, '')).width + 22;
  var bx0 = clamp(tx - tw / 2, 6, CVW - tw - 6), ty = rt.above ? y - 62 : y + 34;   /* above … 札を ↔ の上に */
  ctx.fillStyle = '#fbe3d6'; ctx.strokeStyle = '#d98a6a'; ctx.lineWidth = 1.2;
  ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(bx0, ty, tw, 28, 6); else ctx.rect(bx0, ty, tw, 28); ctx.fill(); ctx.stroke(); ctx.restore();
  label(ctx, rt.text, bx0 + tw / 2, ty + 14, { size: 15, bold: true, color: '#5a2a12', halo: false });
}
function fingerDragDown(s, lx, ly) {
  var g = s._geo; if (!g) return false;
  return Math.abs(lx - g.fx) < 60 && ly > g.yc - 60 && ly < g.yc + 110;
}
function fingerDrag(s, lx, xG) {
  var g = s._geo; if (!g) return;
  var x = clamp((lx - g.x0) / g.L * g.len, g.len * 0.04, g.len * 0.96);
  var sn = snapTo(x, xG, s._snap ? g.len * 0.05 : g.len * 0.032);
  s._fx = sn.v; s._snap = sn.on;
}

/* ============ m2s1　指の上のペン ============ */
var Q1 = { PL: 0.34, XG: 0.56 };   /* ペンの長さ [m]・重心の位置（ペン先から見た割合） */
/* ペン（黒いボールペン。左がペン先、右上にクリップ） */
function penBody(ctx, x0, L, th) {
  var tip = L * 0.07;
  ctx.save();
  ctx.lineJoin = 'round';
  /* ペン先（金属） */
  ctx.fillStyle = '#b8c0c8'; ctx.strokeStyle = '#1b1f24'; ctx.lineWidth = 1.4;
  ctx.beginPath(); ctx.moveTo(x0 + 2, -th / 2); ctx.lineTo(x0 + tip, -th * 0.9); ctx.lineTo(x0 + tip, -th * 0.1); ctx.closePath(); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.arc(x0 + 2, -th / 2, 2, 0, Math.PI * 2); ctx.fillStyle = '#1b1f24'; ctx.fill();
  /* 胴（黒） */
  ctx.fillStyle = '#23272b';
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(x0 + tip, -th, L - tip, th, 4); else ctx.rect(x0 + tip, -th, L - tip, th);
  ctx.fill(); ctx.stroke();
  /* にぎりの溝 */
  ctx.strokeStyle = '#5b636b'; ctx.lineWidth = 1.2;
  for (var i = 0; i < 5; i++) { var xx = x0 + tip + 6 + i * 5; ctx.beginPath(); ctx.moveTo(xx, -th + 2); ctx.lineTo(xx, -2); ctx.stroke(); }
  /* 白い帯（つや） */
  ctx.fillStyle = 'rgba(255,255,255,.85)';
  ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x0 + L * 0.22, -th * 0.72, L * 0.40, th * 0.22, 2); else ctx.rect(x0 + L * 0.22, -th * 0.72, L * 0.40, th * 0.22); ctx.fill();
  /* キャップの境目 */
  ctx.strokeStyle = '#8b949e'; ctx.lineWidth = 1.4;
  ctx.beginPath(); ctx.moveTo(x0 + L * 0.66, -th); ctx.lineTo(x0 + L * 0.66, 0); ctx.stroke();
  /* クリップ */
  ctx.fillStyle = '#23272b'; ctx.strokeStyle = '#1b1f24'; ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.moveTo(x0 + L * 0.70, -th - 3); ctx.lineTo(x0 + L * 0.985, -th - 5); ctx.lineTo(x0 + L * 0.985, -th + 1); ctx.lineTo(x0 + L * 0.70, -th); ctx.closePath();
  ctx.fill(); ctx.stroke();
  ctx.restore();
}

DEFS['m2s1'] = {
  id: 'm2s1', tab: '②-1　剛体のつりあいの条件', noAB: true, noPlay: true, noResetAll: true,
  guides: [{ key: 'm2s1', x: 0 }],
  title: '②-1　剛体のつりあいの条件<br><span class="subttl">2 力の場合　～指の上のペン～</span>',
  sub: '動かない（並進しない）だけでなく、<b>回転もしない</b>ように支えるには、どこに指を置けばよいだろう。指をドラッグして動かそう。',
  cw: function (v, s) { return (s && s._narrow) ? 470 : 600; },
  ch: function () { return 400; },
  stageSide: function (s) {
    return simLinkBox(3, '2 力の場合は、2 力が<b>一直線上</b>で<b>逆向き</b>に<b>同じ大きさ</b>ならよい');
  },
  vars: [],
  vis: [{ k: 'L', label: '力と作用線を表示', def: false }],
  reset: function (s) { s._fx = 0.26; s._snap = false; },
  draw: function (ctx, s, W, H) {
    if (s._fx === undefined) DEFS['m2s1'].reset(s);
    var r = drawOnFinger(ctx, s, W, H, { L: Q1.PL, thick: 20, xG: Q1.XG * Q1.PL, body: penBody, name: 'ペン' });
    label(ctx, r.bal ? '重心の真下で支えている　→　力の和 0・モーメントの和 0（つりあう）'
      : '重心の真下からずれている　→　指のまわりのモーメントが 0 でない（回る）',
      W / 2, H - 14, { size: 15, bold: true, color: r.bal ? '#0a5c5c' : '#3d4c5a' });
  },
  dragDown: fingerDragDown,
  drag: function (s, lx) { fingerDrag(s, lx, Q1.XG * Q1.PL); },
  below: function (s) {
    return '<div class="bcard"><h3>＜考え方＞　剛体のつりあいの条件</h3>' +
      '<p>剛体には<b>並進運動</b>と<b>回転運動</b>が起こる。<b>どちらも起こらない</b>とき、つりあいの関係が成り立つ。</p>' +
      '<div class="condrow"><div class="condfig"><canvas id="m2cond"></canvas></div>' +
      '<div class="condside">' + simLinkBox(4, '3 力の場合は、3 力のモーメントがつり合えばよい') + '</div></div>' +
      '<div class="fmlbox"><span class="tex">\\text{①（並進運動を始めない条件）　力のベクトルの和が } \\vec 0 \\qquad \\vec{F_1} + \\vec{F_2} + \\vec{F_3} + \\cdots = \\vec{0}</span></div>' +
      '<div class="fmlbox"><span class="tex">\\text{②（回転運動を始めない条件）　任意の点のまわりのモーメントの和が } 0 \\qquad M_1 + M_2 + M_3 + \\cdots = 0</span></div>' +
      '<p>②の「任意の点」は<b>どこにとってもよい</b>。①が成り立っていれば、どの点のまわりで考えてもモーメントの和は 0 になる。' +
      'ふつうは<b>わからない力が集まっている点</b>を選ぶと計算が楽になる。</p>' +
      '<p class="mini">力のモーメントの求め方（2 通り）は　' +
      '<a class="cmplink" href="#1-1" data-goto="m1s1">①-1　力のモーメント →</a></p></div>';
  },
  drawBelow: function (s) {
    var cv = document.getElementById('m2cond');
    if (cv && cv.clientWidth > 0) drawCondFig(cv);
    drawThumb(3); drawThumb(4);
  }
};

/* 1-2 ②④ へのリンク（文＋「シミュレーションしてみよう」ボタン＋小さな画面の絵。絵を押しても飛ぶ） */
function simLinkBox(no, text) {
  var nm = '①-2-(' + no + ')';                  /* 第 57 回：①-2 のカードの番号 ①-2-(2)〜(4) */
  return '<div class="simlink"><p class="sltext">' + text + '</p>' +
    '<a class="slbtn" href="#1-2-' + no + '" data-goto="m1s2:' + no + '">シミュレーションしてみよう →</a>' +
    '<a class="slthumb" href="#1-2-' + no + '" data-goto="m1s2:' + no + '" title="' + nm + ' へ">' +
    '<canvas id="thumb' + no + '"></canvas><span>' + nm + '　力 ' + (no - 1) + ' つで回転しない加え方</span></a></div>';
}
function drawThumb(no) {
  var cv = document.getElementById('thumb' + no);
  if (!cv || cv.clientWidth <= 0) return;
  var W = 440, H = 320, ctx = prep(cv, W, H);            /* 円盤のまわりだけ切りぬいた、小さな画面の絵 */
  ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H);
  var stt = discFresh(no); stt.noText = true;
  ctx.save(); ctx.translate(-90, -64); discScene(ctx, stt, 620, 400, no - 1); ctx.restore();
}

/* ＜図＞ 剛体のつりあいの条件（左：回転軸のある円板にはたらく 3 力とうで／右：棒にはたらく 3 力と任意の点 P） */
function drawCondFig(cv) {
  var W = 360, H = 345, ctx = prep(cv, W, H);
  NO_SHIFT = true;
  /* --- 左：円板（斜め上から） --- */
  var cx = 175, cy = 150, rx = 140, ry = 62, th = 12;
  ctx.save();
  ctx.strokeStyle = '#8b949e'; ctx.lineWidth = 7; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx, cy + 118); ctx.stroke();       /* 軸（下） */
  ctx.fillStyle = '#d8bf97'; ctx.strokeStyle = '#8a6d45'; ctx.lineWidth = 1.4;
  ctx.beginPath(); ctx.ellipse(cx, cy + th, rx, ry, 0, 0, Math.PI); ctx.lineTo(cx - rx, cy); ctx.ellipse(cx, cy, rx, ry, 0, Math.PI, 0, true); ctx.closePath(); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#f0dfc3';
  ctx.beginPath(); ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.restore();
  /* 板の上の点（x 右、y 奥）→ 画面 */
  function P(x, y) { return { x: cx + x * rx, y: cy - y * ry }; }
  var O = P(0, 0);
  var forces = [
    { p: [0.62, 0.18], d: [0.2, 1.0], n: 'F_1', col: COL.force },       /* O のまわりに左まわり（＋） */
    { p: [-0.62, 0.10], d: [-0.3, -1.0], n: 'F_2', col: COL.force },    /* 左まわり（＋） */
    { p: [0.22, -0.62], d: [-1.0, 0.1], n: 'F_3', col: COL.force }      /* 右まわり（−） */
  ];
  forces.forEach(function (f, k) {
    var A = P(f.p[0], f.p[1]);
    var dl = Math.hypot(f.d[0] * rx, f.d[1] * ry), ux = f.d[0] * rx / dl, uy = -f.d[1] * ry / dl;
    var len = 62;
    /* 作用線の延長（点線）と、O からの垂線（うで） */
    var t = (O.x - A.x) * ux + (O.y - A.y) * uy;
    var Fo = { x: A.x + ux * t, y: A.y + uy * t };
    dotLine(ctx, A.x, A.y, Fo.x, Fo.y, 'rgba(120,132,145,.8)', 1.1, [3, 3]);
    dotLine(ctx, O.x, O.y, Fo.x, Fo.y, '#1c8f4a', 2, [3, 3]);
    label(ctx, 'l_' + (k + 1), (O.x + Fo.x) / 2 + 9, (O.y + Fo.y) / 2 - 8, { size: 13, bold: true, color: '#1c8f4a' });
    arrow(ctx, A.x, A.y, A.x + ux * len, A.y + uy * len, 'force', 1, f.col);
    tipLabel(ctx, f.n, A.x + ux * len, A.y + uy * len, ux, uy, { size: 14, bold: true, color: f.col });
  });
  ctx.save(); ctx.strokeStyle = '#6b7885'; ctx.lineWidth = 7; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx, cy - 98); ctx.stroke(); ctx.restore();   /* 軸（上） */
  axisMark(ctx, O.x, O.y, null);
  label(ctx, 'O', O.x - 14, O.y + 12, { size: 14, bold: true });
  /* モーメントの札 */
  [['M_1 = F_1 l_1', 300, 40], ['M_2 = F_2 l_2', 62, 250], ['M_3 = −F_3 l_3', 292, 262]].forEach(function (q) {
    ctx.save(); ctx.font = 'bold 13px ' + FONT;
    var w = ctx.measureText(q[0].replace(/_/g, '')).width + 16;
    ctx.fillStyle = '#f7d9d6'; ctx.strokeStyle = '#d1352b'; ctx.lineWidth = 1;
    ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(q[1] - w / 2, q[2] - 12, w, 24, 5); else ctx.rect(q[1] - w / 2, q[2] - 12, w, 24);
    ctx.fill(); ctx.stroke(); ctx.restore();
    label(ctx, q[0], q[1], q[2], { size: 13, bold: true, color: '#7a1710', halo: false });
  });
  label(ctx, 'F₁〜F₃ はそれぞれの力の大きさ', 20, 18, { size: 12, color: COL.sub, align: 'left' });
  /* 円板の下に、O のまわりのモーメントのつりあいの式 */
  label(ctx, 'O のまわりのモーメントのつりあい', cx, 300, { size: 14, bold: true, color: '#3d4c5a' });
  label(ctx, 'M_1 + M_2 + M_3 = F_1 l_1 + F_2 l_2 − F_3 l_3 = 0', cx, 328, { size: 16, bold: true, color: '#7a1710' });
  NO_SHIFT = false;
}

/* ============ m2s2　糸でつられた棒 ============ */
DEFS['m2s2'] = {
  id: 'm2s2', tab: '②-2　糸でつるした棒', noAB: true, noPlay: true,
  guides: [{ key: 'm2s2', x: 0 }],
  title: '②-2　糸でつるした棒　～3 つの力のつりあい～',
  sub: '一様な棒 AB の両端に軽い糸を結び、壁の点 C につないで棒を水平にする。AC は鉛直、BC は水平と $\\theta$ の角をなす。' +
    'θ や棒の重さを変えて、3 つの力（糸 AC・糸 BC・壁）がどう変わるかを見よう。',
  cw: function (v, s) { return (s && s._narrow) ? 470 : 600; },
  ch: function () { return 460; },
  drawSide: function (ctx, s, W, H) { drawSideString(ctx, V(s), W, H); },
  vars: [
    { k: 'th', label: '糸 BC と水平のなす角 $\\theta$', unit: '°', min: 15, max: 45, step: 1, dec: 0, def: 30 },
    { k: 'W', label: '棒の重さ $W$', unit: ' N', min: 2, max: 10, step: 0.5, dec: 1, def: 6.0 }
  ],
  vis: [{ k: 'F', label: '力を表示', def: false }, { k: 'L', label: '力と作用線を表示', def: false }],
  draw: function (ctx, s, W, H) {
    var v = V(s), th = v.th * DEG;
    /* ★壁と棒は動かさない。θ を変えると点 C の高さだけが変わる★ */
    var bot = H - 96, L = Math.min(W - 300, (bot - 70) / Math.tan(45 * DEG));
    var A = { x: (W - L) / 2 - 20, y: bot }, B = { x: A.x + L, y: bot };
    var C = { x: A.x, y: bot - L * Math.tan(th) };
    var topWall = bot - L * Math.tan(45 * DEG) - 26;
    var wallX = A.x - 5;
    ctx.save();
    ctx.fillStyle = '#e4e8ec'; ctx.strokeStyle = '#8b949e'; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.rect(wallX - 22, topWall, 22, bot + 50 - topWall); ctx.fill(); ctx.stroke();
    ctx.restore();
    hatchLine(ctx, wallX, topWall, wallX, bot + 50, 1);
    /* 糸 */
    ctx.save(); ctx.strokeStyle = '#6b7885'; ctx.lineWidth = 1.8;
    ctx.beginPath(); ctx.moveTo(A.x, A.y); ctx.lineTo(C.x, C.y); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(B.x, B.y); ctx.lineTo(C.x, C.y); ctx.stroke();
    ctx.restore();
    /* 糸止め（壁に打ったフックと輪）：糸が壁に止まっているように見せる */
    ctx.save();
    ctx.fillStyle = '#9aa5b0'; ctx.strokeStyle = '#3a444e'; ctx.lineWidth = 1.2;
    ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(wallX - 1, C.y - 9, 6, 18, 2); else ctx.rect(wallX - 1, C.y - 9, 6, 18); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(wallX + 5, C.y); ctx.lineTo(C.x - 4, C.y); ctx.lineWidth = 2; ctx.stroke();
    ctx.beginPath(); ctx.arc(C.x, C.y, 5, 0, Math.PI * 2); ctx.fillStyle = '#fff'; ctx.fill(); ctx.lineWidth = 2.2; ctx.strokeStyle = '#3a444e'; ctx.stroke();
    ctx.restore();
    /* 棒 */
    ctx.save();
    ctx.strokeStyle = '#8a5a2b'; ctx.lineWidth = 10; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(A.x, A.y); ctx.lineTo(B.x, B.y); ctx.stroke();
    ctx.restore();
    var O = { x: (A.x + B.x) / 2, y: A.y };
    label(ctx, 'A', A.x - 24, A.y + 20, { size: 15, bold: true });
    label(ctx, 'B', B.x + 18, B.y + 18, { size: 15, bold: true });
    label(ctx, 'C', C.x + 18, C.y - 10, { size: 15, bold: true });
    label(ctx, 'O', O.x - 16, O.y + 20, { size: 14, bold: true });
    /* ものの名前：糸 1（AC）・糸 2（BC）・棒 */
    label(ctx, '糸 1', A.x + 12, (A.y + C.y) / 2 + 30, { size: 14, bold: true, color: '#4e5a66', align: 'left' });
    var m2x = C.x + (B.x - C.x) * 0.25, m2y = C.y + (B.y - C.y) * 0.25, bl = Math.hypot(B.x - C.x, B.y - C.y) || 1;
    label(ctx, '糸 2', m2x + (C.y - B.y) / bl * -16, m2y + (B.x - C.x) / bl * -16, { size: 14, bold: true, color: '#4e5a66' });
    label(ctx, '棒', A.x + (B.x - A.x) * 0.25, A.y + 22, { size: 14, bold: true, color: '#8a5a2b' });
    angArc(ctx, B.x, B.y, 44, Math.PI, Math.PI + th, '', 0, 0);
    label(ctx, 'θ', B.x + 60 * Math.cos(Math.PI + th / 2), B.y + 60 * Math.sin(Math.PI + th / 2), { size: 15, bold: true, color: '#3d4c5a' });
    label(ctx, 'θ = ' + fmt(v.th, 0) + '°', B.x + 18, B.y - 22, { size: 15, bold: true, color: '#1f3b57', align: 'left' });   /* いまの角度 */
    var TB = v.W / (2 * Math.sin(th)), TA = v.W - TB * Math.sin(th), NA = TB * Math.cos(th);
    var fs = 60 / 6;                                /* 6 N ＝ 60 px（重さを変えると長さも変わる） */
    var ub = { x: (C.x - B.x), y: (C.y - B.y) }, ul = Math.hypot(ub.x, ub.y) || 1; ub.x /= ul; ub.y /= ul;
    /* 3 力の作用線は 1 点で交わる（重力の作用線と糸 BC の交点 Q。壁からの力の合力もここを通る） */
    var Q = { x: O.x, y: A.y - (L / 2) * Math.tan(th) };
    if (v.showL) {
      ctx.save(); ctx.lineWidth = 1.4; ctx.setLineDash([7, 5]);
      ctx.strokeStyle = fade(COL.force, .75); ctx.beginPath(); ctx.moveTo(O.x, O.y + 70); ctx.lineTo(O.x, Q.y - 40); ctx.stroke();
      ctx.strokeStyle = fade(COL.hand, .75); ctx.beginPath(); ctx.moveTo(B.x + ub.x * -20, B.y + ub.y * -20); ctx.lineTo(Q.x - ub.x * 40 * -1, Q.y - ub.y * -40); ctx.stroke();
      ctx.strokeStyle = 'rgba(90,70,160,.75)'; ctx.beginPath(); ctx.moveTo(A.x, A.y); ctx.lineTo(Q.x + (Q.x - A.x) * 0.25, Q.y + (Q.y - A.y) * 0.25); ctx.stroke();
      ctx.restore();
      ctx.save(); ctx.beginPath(); ctx.arc(Q.x, Q.y, 5, 0, Math.PI * 2); ctx.fillStyle = '#fff'; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = '#1b1f24'; ctx.stroke(); ctx.restore();
      label(ctx, '3 つの力の作用線は 1 点で交わる', Q.x + 14, Q.y - 16, { size: 13.5, bold: true, color: '#3d4c5a', align: 'left' });
    }
    if (v.showF || v.showL) {
      NO_SHIFT = true;
      arrow(ctx, O.x, O.y, O.x, O.y + v.W * fs, 'force', 1.05, COL.force);
      label(ctx, '重力 W', O.x + 12, O.y + v.W * fs - 4, { size: 14, bold: true, color: COL.force, align: 'left' });
      arrow(ctx, A.x + 5, A.y, A.x + 5, A.y - TA * fs, 'force', 1.05, COL.hand);
      label(ctx, 'T_A', A.x + 16, A.y - TA * fs - 2, { size: 15, bold: true, color: COL.hand, align: 'left' });
      arrow(ctx, B.x, B.y, B.x + ub.x * TB * fs, B.y + ub.y * TB * fs, 'force', 1.05, COL.hand);
      label(ctx, 'T_B', B.x + ub.x * TB * fs + 14, B.y + ub.y * TB * fs - 10, { size: 15, bold: true, color: COL.hand, align: 'left' });
      arrow(ctx, A.x, A.y, A.x + NA * fs, A.y, 'force', 1.05, COL.norm);
      label(ctx, 'N_A', A.x + NA * fs + 4, A.y + 20, { size: 15, bold: true, color: COL.norm, align: 'left' });
      if (v.showL) {                                   /* A にはたらく 2 力（T_A と N_A）の合力 */
        var RA = Math.hypot(NA, TA);
        arrow(ctx, A.x, A.y, A.x + NA * fs, A.y - TA * fs, 'comp', 1, 'rgba(90,70,160,1)');
        label(ctx, '合力', A.x + NA * fs + 8, A.y - TA * fs - 6, { size: 13, bold: true, color: 'rgb(90,70,160)', align: 'left' });
      }
      NO_SHIFT = false;
    }
  },
  result: function (v) {
    var th = v.th * DEG, TB = v.W / (2 * Math.sin(th));
    return { items: [
      { k: '$T_B$（糸 BC）', v: fmt(TB, 2) + ' N', kbox: true },
      { k: '$T_A$（糸 AC）', v: fmt(v.W - TB * Math.sin(th), 2) + ' N' },
      { k: '$N_A$（壁から棒へ）', v: fmt(TB * Math.cos(th), 2) + ' N' }
    ], note: '' };
  },
  below: function (s) {
    return '<div class="bcard"><h3>＜考え方＞　糸でつるした棒</h3>' +
      '<p>棒にはたらく力は、重力 $W$（中点 O）、糸 AC の張力 $T_A$、糸 BC の張力 $T_B$、壁からの垂直抗力 $N_A$（壁はなめらかなので水平）。</p>' +
      '<p>わからない力（$T_A$ と $N_A$）が集まっている <b>A のまわり</b>でモーメントのつりあいを考えると、その 2 力のモーメントは 0 になって消える。棒の長さを $L$ とすると</p>' +
      '<div class="fmlbox"><span class="tex">W\\cdot\\dfrac{L}{2} = T_B\\sin\\theta \\cdot L \\quad\\Longrightarrow\\quad T_B = \\dfrac{W}{2\\sin\\theta}</span></div>' +
      '<div class="fmlbox"><span class="tex">\\text{鉛直：}\\ T_A + T_B\\sin\\theta = W \\qquad \\text{水平：}\\ N_A = T_B\\cos\\theta</span></div>' +
      '<p>$\\theta$ を小さくすると $\\sin\\theta$ が小さくなり、<b>$T_B$ と $N_A$ が大きくなる</b>（$T_A$ はいつも $W/2$）。' +
      '「力と作用線を表示」で、<b>3 つの力（重力・$T_B$・A にはたらく力の合力）の作用線が 1 点で交わる</b>ことも確かめよう。</p></div>';
  }
};

/* ============ m2s3　壁に立てかけた棒 ============ */
var Q3 = { L: 1.0, W: 20 };     /* 棒の長さ [m]・重さ [N] */

DEFS['m2s3'] = {
  id: 'm2s3', tab: '②-3　壁に立てかけた棒', noAB: true,
  guides: [{ key: 'm2s3', x: 0 }],
  title: '②-3　壁に立てかけた棒　～いつすべり出す？～',
  sub: '<b>壁はなめらか（摩擦なし）</b>、床には摩擦がある。棒を<b>たおしていく</b>（θ を小さくしていく）と、' +
    'ある角度ですべり出す。',
  playNote: 'スタートを押すと θ が小さくなっていき、すべり出す角で止まる',
  playRate: -9,
  zone2: ['すべる', 'すべらない'], zone2Rev: true,
  momentInPlay: true, tickInline: true, plainSide: true,   /* 操作パネルをたてに短く */
  moment: { label: 'すべる瞬間をスローで', dur: 4.2, range: function (v) { var c = DEFS['m2s3'].thc(v); return { k: 'th', from: Math.min(85, c + 4), to: Math.max(15, c - 3), hold: 0.8 }; } },
  cw: function (v, s) { return (s && s._narrow) ? 470 : 600; },
  ch: function () { return 440; },
  drawSide: function (ctx, s, W, H) { drawSideWall(ctx, V(s), W, H); },
  vars: [
    { k: 'th', label: '棒の角度 $\\theta$', unit: '°', min: 15, max: 85, step: 1, dec: 0, def: 80,
      tick: function (v) { var c = DEFS['m2s3'].thc(v); return { at: null, at2: c, label2: 'すべる角 $\\theta_c = ' + fmt(c, 1) + '^\\circ$' }; } },
    { k: 'mu', label: '床の静止摩擦係数 $\\mu$', unit: '', min: 0.10, max: 1.00, step: 0.05, dec: 2, def: 0.60 }
  ],
  vis: [{ k: 'F', label: '力を表示', def: false }, { k: 'L', label: '力と作用線を表示', def: false }],
  /* すべり出す角：tanθ_c = 1/(2μ) */
  thc: function (v) { return Math.atan(1 / (2 * v.mu)) / DEG; },
  playStop: function (v) { return Math.max(15, DEFS['m2s3'].thc(v) - 2); },
  draw: function (ctx, s, W, H) {
    var v = V(s), th = v.th * DEG;
    var thc = DEFS['m2s3'].thc(v);
    var slip = v.th < thc - 1e-9;
    var S = Math.min((W - 330) / Q3.L, (H - 110) / Q3.L);
    var gy = H - 52, wx = 110;
    /* すべり出したら、棒は壁と床に沿ったまま少したおれる（見た目の角 thd） */
    var thd = slip ? th - clamp((thc - v.th) / 4, 0, 1) * 7 * DEG : th;
    var Bp = { x: wx + Q3.L * Math.cos(thd) * S, y: gy };                 /* 床がわの端 B */
    var Ap = { x: wx, y: gy - Q3.L * Math.sin(thd) * S };                 /* 壁がわの端 A */
    ctx.save(); ctx.fillStyle = '#e4e8ec'; ctx.strokeStyle = '#8b949e'; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.rect(wx - 24, 34, 22, gy - 34); ctx.fill(); ctx.stroke(); ctx.restore();
    hatchLine(ctx, wx - 2, 34, wx - 2, gy, 1);
    ground(ctx, wx - 24, W - 16, gy);
    label(ctx, '壁：なめらか', wx - 26, gy + 26, { size: 13, color: COL.sub, align: 'right' });
    label(ctx, '床：μ = ' + fmt(v.mu, 2), W - 20, gy + 26, { size: 13, color: COL.sub, align: 'right' });
    ctx.save();
    ctx.strokeStyle = '#8a5a2b'; ctx.lineWidth = 10; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(Ap.x, Ap.y); ctx.lineTo(Bp.x, Bp.y); ctx.stroke();
    ctx.restore();
    label(ctx, 'A', wx - 40, Ap.y, { size: 15, bold: true });
    label(ctx, 'B', Bp.x + 16, Bp.y + 18, { size: 15, bold: true });
    var rl3 = Math.hypot(Bp.x - Ap.x, Bp.y - Ap.y) || 1;             /* 「棒」：棒の右上がわ */
    label(ctx, '棒', Ap.x + (Bp.x - Ap.x) * 0.3 + (Bp.y - Ap.y) / rl3 * 24, Ap.y + (Bp.y - Ap.y) * 0.3 - (Bp.x - Ap.x) / rl3 * 24, { size: 14, bold: true, color: '#8a5a2b' });
    var G = { x: (Ap.x + Bp.x) / 2, y: (Ap.y + Bp.y) / 2 };
    angArc(ctx, Bp.x, Bp.y, 40, Math.PI, Math.PI + thd, '', 0, 0);
    label(ctx, 'θ', Bp.x + 56 * Math.cos(Math.PI + thd / 2), Bp.y + 56 * Math.sin(Math.PI + thd / 2), { size: 15, bold: true, color: '#3d4c5a' });
    label(ctx, 'θ = ' + fmt(v.th, 0) + '°', Bp.x + 22, Bp.y - 18, { size: 15, bold: true, color: '#1f3b57', align: 'left' });   /* いまの角度 */
    var N1 = Q3.W / (2 * Math.tan(th));
    var fr = Math.min(N1, v.mu * Q3.W);
    var fs = 84 / Q3.W;
    if (v.showL) {                                   /* 作用線：重力（鉛直）・N₁（水平）・床からの力の合力 → 1 点 Q で交わる */
      var Qp = { x: G.x, y: Ap.y };
      ctx.save(); ctx.lineWidth = 1.4; ctx.setLineDash([7, 5]);
      ctx.strokeStyle = fade(COL.force, .7); ctx.beginPath(); ctx.moveTo(G.x, Qp.y - 30); ctx.lineTo(G.x, gy + 10); ctx.stroke();
      ctx.strokeStyle = fade(COL.norm, .7); ctx.beginPath(); ctx.moveTo(Ap.x, Ap.y); ctx.lineTo(Qp.x + 60, Qp.y); ctx.stroke();
      ctx.strokeStyle = 'rgba(15,110,110,.75)'; ctx.beginPath(); ctx.moveTo(Bp.x, Bp.y); ctx.lineTo(Qp.x + (Qp.x - Bp.x) * 0.3, Qp.y + (Qp.y - Bp.y) * 0.3); ctx.stroke();
      ctx.restore();
      ctx.save(); ctx.beginPath(); ctx.arc(Qp.x, Qp.y, 5, 0, Math.PI * 2); ctx.fillStyle = '#fff'; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = '#1b1f24'; ctx.stroke(); ctx.restore();
      label(ctx, '3 つの力の作用線は 1 点で交わる', Qp.x + 12, Qp.y + (Qp.y > gy - 150 ? -40 : 22), { size: 13.5, bold: true, color: '#3d4c5a', align: 'left' });
      /* 床からの力（N₂ と f）の合力：N₂ と f でつくる長方形の対角線 */
      ctx.save(); ctx.strokeStyle = 'rgba(15,110,110,.6)'; ctx.lineWidth = 1.2; ctx.setLineDash([4, 3]);
      ctx.strokeRect(Bp.x - fr * fs, Bp.y - Q3.W * fs, fr * fs, Q3.W * fs);
      ctx.restore();
      NO_SHIFT = true;
      arrow(ctx, Bp.x, Bp.y, Bp.x - fr * fs, Bp.y - Q3.W * fs, 'comp', 1, '#0f6e6e');
      NO_SHIFT = false;
      label(ctx, '← 床からの力の合力（抗力）', Bp.x + 16, Bp.y - Q3.W * fs * 0.45, { size: 13, bold: true, color: '#0f6e6e', align: 'left' });   /* N₂ の右（棒・重力とかさならない） */
    }
    if (v.showF || v.showL) {
      NO_SHIFT = true;
      arrow(ctx, G.x, G.y, G.x, G.y + Q3.W * fs, 'force', 1.05, COL.force);
      label(ctx, '重力 W', G.x, G.y + Q3.W * fs + 14, { size: 14, bold: true, color: COL.force });
      if (N1 * fs > 3) arrow(ctx, Ap.x, Ap.y, Ap.x + Math.min(N1, 60) * fs, Ap.y, 'force', 1.05, COL.norm);
      label(ctx, slip ? '壁の垂直抗力 N₁' : '壁の垂直抗力 N₁ = ' + fmt(N1, 1) + ' N', Ap.x + Math.max(Math.min(N1, 60) * fs, 0) + 12, Ap.y - 18, { size: 14, bold: true, color: COL.norm, align: 'left' });
      arrow(ctx, Bp.x + 5, Bp.y, Bp.x + 5, Bp.y - Q3.W * fs, 'force', 1.05, COL.norm);
      label(ctx, '床の垂直抗力 N₂ = W', Bp.x + 16, Bp.y - Q3.W * fs + 4, { size: 14, bold: true, color: COL.norm, align: 'left' });
      if (fr * fs > 3) arrow(ctx, Bp.x, Bp.y, Bp.x - fr * fs, Bp.y, 'force', 1.05, COL.fric);
      label(ctx, '摩擦力 f = ' + fmt(fr, 1) + ' N', Bp.x - fr * fs / 2, Bp.y + 26, { size: 14, bold: true, color: COL.fric });
      NO_SHIFT = false;
    }
    actPoint(ctx, G.x, G.y, '#1b1f24');
    label(ctx, '重心', G.x + 14, G.y - 10, { size: 13, color: COL.sub, align: 'left', avoid: true });
    var rx = W - 20;
    label(ctx, '必要な摩擦力　f = ' + fmt(N1, 1) + ' N', rx, 88, { size: 15, bold: true, color: '#3d4c5a', align: 'right' });
    label(ctx, '最大摩擦力　μN₂ = ' + fmt(v.mu * Q3.W, 1) + ' N', rx, 114, { size: 15, bold: true, color: '#3d4c5a', align: 'right' });
    var bx = Math.min(W - 120, Math.max(G.x + 170, 230)), by = 150;
    if (slip) verdictBubble(ctx, 'slip', G.x + 78, G.y - 26, 'down', 15);      /* 棒のすぐ近く */
    else calmBubble(ctx, 'まだすべらない', G.x + 92, G.y - 26, 15);   /* 「すべった！」と同じく棒の近く */
  },
  result: function (v) {
    var thc = DEFS['m2s3'].thc(v), th = v.th * DEG, N1 = Q3.W / (2 * Math.tan(th));
    return { items: [
      { k: 'すべり出す角　$\\tan\\theta_c = \\dfrac{1}{2\\mu}$', v: fmt(thc, 1) + '°', kbox: true },
      { k: '必要な摩擦力 $f = \\dfrac{W}{2\\tan\\theta}$', v: fmt(N1, 1) + ' N' },
      { k: 'いま', v: v.th < thc ? 'すべっている' : 'すべらない', cls: v.th < thc ? 'slip' : '' }
    ], note: '' };
  },
  below: function (s) {
    return '<div class="bcard"><h3>＜考え方＞　壁に立てかけた棒</h3>' +
      '<p>棒の長さを $L$、重さを $W$ とする。壁はなめらかなので、壁からの力は<b>水平な垂直抗力 $N_1$ だけ</b>。' +
      '床からは、垂直抗力 $N_2$ と摩擦力 $f$ がはたらく。</p>' +
      '<div class="fmlbox"><span class="tex">\\text{鉛直：}\\ N_2 = W \\qquad \\text{水平：}\\ f = N_1</span></div>' +
      '<p>床がわの端 B のまわりのモーメントのつりあい（重心は中点）：</p>' +
      '<div class="fmlbox"><span class="tex">W\\cdot\\dfrac{L}{2}\\cos\\theta = N_1\\cdot L\\sin\\theta \\quad\\Longrightarrow\\quad N_1 = \\dfrac{W}{2\\tan\\theta}</span></div>' +
      '<p>棒をたおしていく（$\\theta$ を小さくする）ほど $\\tan\\theta$ が小さくなり、<b>必要な摩擦力 $f$ が大きくなる</b>。' +
      '$f$ が最大摩擦力 $\\mu N_2 = \\mu W$ をこえるとすべり出すので</p>' +
      '<div class="fmlbox"><span class="tex">\\dfrac{W}{2\\tan\\theta} > \\mu W \\quad\\Longrightarrow\\quad \\tan\\theta < \\dfrac{1}{2\\mu}</span></div>' +
      '<p>すべり出す角は $\\tan\\theta_c = \\dfrac{1}{2\\mu}$。<b>μ が大きいほど、深くたおしてもすべらない</b>。</p></div>';
  }
};


/* ================================================================
   モード 2 の右の 3 つの図（左の図の 40 % の幅）
   ・2-1 … 傾く 2 つ（指が重心の右／左）とつりあう 1 つ
   ・2-2、2-3 … A のまわり／重心のまわり／B のまわり のモーメントのつりあいの式。
     軸として考えている点を大きな黒丸 ● で強調する
   ================================================================ */
function sidePanels(ctx, W, H, fn, top) {
  top = top || 0;                                  /* 上に見出しの帯をとるとき */
  if (top) label(ctx, '＜力のモーメントのつりあいの式＞', W / 2, top / 2 + 2, { size: 14, bold: true, color: '#1f3b57' });
  for (var i = 0; i < 3; i++) {
    var R = { x0: 0, y0: top + i * (H - top) / 3, w: W, h: (H - top) / 3 };
    if (i) { ctx.save(); ctx.strokeStyle = '#d5dde5'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(8, R.y0); ctx.lineTo(W - 8, R.y0); ctx.stroke(); ctx.restore(); }
    fn(i, R);
  }
}
/* 軸として考えている点（大きな黒丸 ●） */
function axisDot(ctx, x, y) {
  ctx.save();
  ctx.beginPath(); ctx.arc(x, y, 12, 0, Math.PI * 2); ctx.fillStyle = 'rgba(224,123,24,.22)'; ctx.fill();
  ctx.beginPath(); ctx.arc(x, y, 7, 0, Math.PI * 2); ctx.fillStyle = '#111'; ctx.fill();
  ctx.lineWidth = 1.6; ctx.strokeStyle = '#fff'; ctx.stroke();
  ctx.restore();
}
/* 「A のまわり　… − … = 0」を 1 行で（入りきらないときは字を小さく） */
function sideEq(ctx, R, t1, eq) {
  var txt = t1 + '　' + eq, sz = 13.5;
  ctx.save();
  for (; sz > 9.5; sz -= 0.5) { ctx.font = 'bold ' + sz + 'px ' + FONT; if (ctx.measureText(txt.replace(/_/g, '')).width < R.w - 20) break; }
  ctx.restore();
  label(ctx, t1, R.x0 + 10, R.y0 + 16, { size: sz, bold: true, color: '#1f3b57', align: 'left' });
  ctx.save(); ctx.font = 'bold ' + sz + 'px ' + FONT; var w1 = ctx.measureText(t1 + '　').width; ctx.restore();
  label(ctx, eq, R.x0 + 10 + w1, R.y0 + 16, { size: sz, bold: true, color: '#7a1710', align: 'left' });
}
function sideTitle(ctx, R, t1, lines, col) {
  label(ctx, t1, R.x0 + R.w - 12, R.y0 + 18, { size: 14, bold: true, color: col || '#1f3b57', align: 'right' });
  (lines || []).forEach(function (ln, k) {
    label(ctx, ln, R.x0 + R.w - 12, R.y0 + 42 + k * 21, { size: 13, bold: true, color: '#7a1710', align: 'right' });
  });
}

/* 2-1：指の上のペン（3 つ） */
function drawSidePen(ctx, W, H) {
  var cases = [
    { off: 0.16, t: '指が重心より右', r: '→ 左に傾く（回る）', col: '#3d4c5a' },
    { off: -0.16, t: '指が重心より左', r: '→ 右に傾く（回る）', col: '#3d4c5a' },
    { off: 0, t: '指が重心の真下', r: '→ つりあう', col: '#0a5c5c' }
  ];
  NO_SHIFT = true;
  sidePanels(ctx, W, H, function (i, R) {
    var c = cases[i], L = R.w * 0.7, th = 11;
    var x0 = R.x0 + (R.w - L) / 2, yc = R.y0 + R.h * 0.62;
    var xg = x0 + 0.56 * L, fx = xg + c.off * L;
    var tip = c.off === 0 ? 0 : -Math.sign(c.off) * 0.14;
    ctx.save(); ctx.translate(fx, yc); ctx.rotate(tip); penBody(ctx, x0 - fx, L, th); ctx.restore();
    var ca = Math.cos(tip), sa = Math.sin(tip);
    var G = { x: fx + (xg - fx) * ca + th / 2 * sa, y: yc + (xg - fx) * sa - th / 2 * ca };
    pointHand(ctx, fx, yc + 1, 0, 0.36);
    arrow(ctx, fx, yc, fx, yc - 40, 'force', 0.8, COL.norm);
    arrow(ctx, G.x, G.y, G.x, G.y + 40, 'force', 0.8, COL.force);
    actPoint(ctx, G.x, G.y, '#1b1f24');
    if (c.off) {                                   /* 回る向き */
      var dir = -Math.sign(c.off), rr = 30;
      ctx.save(); ctx.strokeStyle = 'rgba(80,100,125,.85)'; ctx.lineWidth = 2;
      var a0 = dir < 0 ? -Math.PI * 0.62 : -Math.PI * 0.38, a1 = dir < 0 ? -Math.PI * 0.9 : -Math.PI * 0.1;
      ctx.beginPath(); ctx.arc(fx, yc, rr, a0, a1, dir < 0); ctx.stroke(); ctx.restore();
    }
    label(ctx, (i + 1) + '　' + c.t, R.x0 + 12, R.y0 + 16, { size: 14, bold: true, color: '#1f3b57', align: 'left' });
    label(ctx, c.r, R.x0 + 30, R.y0 + 36, { size: 13.5, bold: true, color: c.col, align: 'left' });
  });
  NO_SHIFT = false;
}

/* 2-2：糸でつられた棒（A／重心 O／B のまわり）。θ・W を変えると、力の矢印の長さ・向きと数値が変わる */
function drawSideString(ctx, v, W, H) {
  var th = v.th * DEG, TB = v.W / (2 * Math.sin(th)), TA = v.W - TB * Math.sin(th), NA = TB * Math.cos(th);
  /* 反時計回りを正として「足して 0」の形で 1 行に */
  var eqs = [
    { t: 'A のまわり', e: 'T_B sinθ × L − W × L/2 = 0', ax: 'A' },
    { t: '重心 O のまわり', e: 'T_B sinθ × L/2 − T_A × L/2 = 0', ax: 'O' },
    { t: 'B のまわり', e: 'W × L/2 − T_A × L = 0', ax: 'B' }
  ];
  var fs = 5;                                     /* 1 N ＝ 5 px */
  NO_SHIFT = true;
  sidePanels(ctx, W, H, function (i, R) {
    var e = eqs[i], L = 150, yb = R.y0 + R.h * 0.6;
    var A = { x: R.x0 + 26, y: yb }, B = { x: A.x + L, y: yb }, O = { x: A.x + L / 2, y: yb };
    ctx.save(); ctx.strokeStyle = '#8a5a2b'; ctx.lineWidth = 7; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(A.x, A.y); ctx.lineTo(B.x, B.y); ctx.stroke(); ctx.restore();
    var ub = { x: -Math.cos(th), y: -Math.sin(th) };
    arrow(ctx, O.x, O.y, O.x, O.y + v.W * fs, 'force', 0.8, COL.force);
    arrow(ctx, A.x + 3, A.y, A.x + 3, A.y - TA * fs, 'force', 0.8, COL.hand);
    arrow(ctx, A.x, A.y, A.x + NA * fs, A.y, 'force', 0.8, COL.norm);
    arrow(ctx, B.x, B.y, B.x + ub.x * TB * fs, B.y + ub.y * TB * fs, 'force', 0.8, COL.hand);
    angArc(ctx, B.x, B.y, 18, Math.PI, Math.PI + th, '', 0, 0);
    label(ctx, 'θ', B.x - 26 * Math.cos(th / 2), B.y - 26 * Math.sin(th / 2) + 2, { size: 11, color: '#3d4c5a' });
    label(ctx, 'W', O.x + 10, O.y + v.W * fs - 4, { size: 12, bold: true, color: COL.force, align: 'left' });
    label(ctx, 'T_A', A.x + 8, A.y - TA * fs - 4, { size: 12, bold: true, color: COL.hand, align: 'left' });
    label(ctx, 'N_A', A.x + Math.min(NA * fs, 44) / 2 + 6, A.y + 15, { size: 12, bold: true, color: COL.norm });
    label(ctx, 'T_B', B.x + ub.x * TB * fs - 4, B.y + ub.y * TB * fs - 10, { size: 12, bold: true, color: COL.hand });
    label(ctx, 'A', A.x - 12, A.y + 14, { size: 12.5, bold: true });
    label(ctx, 'O', O.x - 10, O.y + 14, { size: 12.5, bold: true });
    label(ctx, 'B', B.x + 10, B.y + 14, { size: 12.5, bold: true });
    axisDot(ctx, e.ax === 'A' ? A.x : (e.ax === 'O' ? O.x : B.x), yb);
    sideEq(ctx, R, e.t, e.e);
  }, 30);
  NO_SHIFT = false;
}

/* 2-3：壁に立てかけた棒（A／重心 G／B のまわり）。θ・μ を変えると、力の矢印と数値が変わる */
function drawSideWall(ctx, v, W, H) {
  var th = v.th * DEG, Wt = Q3.W, N1 = Wt / (2 * Math.tan(th)), f = Math.min(N1, v.mu * Wt), N2 = Wt;
  var slip = N1 > v.mu * Wt + 1e-9;
  /* 反時計回りを正として「足して 0」の形で 1 行に */
  var eqs = [
    { t: 'A のまわり', e: 'N₂ × L cosθ − W × (L/2) cosθ − f × L sinθ = 0', ax: 'A' },
    { t: '重心 G のまわり', e: 'N₂ × (L/2) cosθ − N₁ × (L/2) sinθ − f × (L/2) sinθ = 0', ax: 'G' },
    { t: 'B のまわり', e: 'W × (L/2) cosθ − N₁ × L sinθ = 0', ax: 'B' }
  ];
  var fs = 1.6;                                   /* 1 N ＝ 1.6 px */
  NO_SHIFT = true;
  eqs = [eqs[2], eqs[1], eqs[0]];                 /* 順番は B のまわり → 重心 G のまわり → A のまわり */
  sidePanels(ctx, W, H, function (i, R) {
    var e = eqs[i], gy = R.y0 + R.h - 14, wx = R.x0 + 26;
    var L = Math.min(118, (R.h - 66) / Math.sin(th), 120 / Math.cos(th));
    var Bp = { x: wx + L * Math.cos(th), y: gy }, Ap = { x: wx, y: gy - L * Math.sin(th) };
    var G = { x: (Ap.x + Bp.x) / 2, y: (Ap.y + Bp.y) / 2 };
    ctx.save(); ctx.fillStyle = '#e4e8ec'; ctx.fillRect(wx - 12, Ap.y - 10, 10, gy - Ap.y + 10); ctx.restore();
    hatchLine(ctx, wx - 2, Ap.y - 10, wx - 2, gy, 1);
    ground(ctx, wx - 12, R.x0 + 165, gy);
    ctx.save(); ctx.strokeStyle = '#8a5a2b'; ctx.lineWidth = 6; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(Ap.x, Ap.y); ctx.lineTo(Bp.x, Bp.y); ctx.stroke(); ctx.restore();
    arrow(ctx, G.x, G.y, G.x, G.y + Wt * fs, 'force', 0.8, COL.force);
    arrow(ctx, Ap.x, Ap.y, Ap.x + N1 * fs, Ap.y, 'force', 0.8, COL.norm);
    arrow(ctx, Bp.x + 3, Bp.y, Bp.x + 3, Bp.y - N2 * fs, 'force', 0.8, COL.norm);
    arrow(ctx, Bp.x, Bp.y, Bp.x - f * fs, Bp.y, 'force', 0.8, COL.fric);
    label(ctx, 'W', G.x - 10, G.y + Wt * fs - 4, { size: 12, bold: true, color: COL.force, align: 'right' });
    label(ctx, 'N₁', Ap.x + N1 * fs + 4, Ap.y - 10, { size: 12, bold: true, color: COL.norm, align: 'left' });
    label(ctx, 'N₂', Bp.x + 9, Bp.y - N2 * fs + 4, { size: 12, bold: true, color: COL.norm, align: 'left' });
    label(ctx, 'f', Bp.x - f * fs - 6, Bp.y - 9, { size: 12, bold: true, color: COL.fric });
    label(ctx, 'A', Ap.x + 12, Ap.y + 10, { size: 12.5, bold: true, align: 'left' });
    label(ctx, 'B', Bp.x + 12, Bp.y + 6, { size: 12.5, bold: true, align: 'left' });
    label(ctx, 'G', G.x + 10, G.y - 6, { size: 12.5, bold: true, align: 'left' });
    axisDot(ctx, e.ax === 'A' ? Ap.x : (e.ax === 'G' ? G.x : Bp.x), e.ax === 'A' ? Ap.y : (e.ax === 'G' ? G.y : Bp.y));
    sideEq(ctx, R, e.t, e.e);
    if (slip) label(ctx, '（すべっているので成り立たない）', R.x0 + R.w - 12, R.y0 + 36, { size: 12, bold: true, color: '#9b2418', align: 'right' });
  }, 30);
  NO_SHIFT = false;
}

