/* ===== 90_boot.js ===== */
/* 起動とテスト用フック */
'use strict';
(function () {
  initState();
  drawLegend();
  renderMath(document.body);

  var hp = parseHash(location.hash);
  var okId = MODES.some(function (m) { return m.ids.indexOf(hp.id) >= 0; });
  if (!DEFS[hp.id] || !okId) hp.id = MODES[0].ids[0];   /* はじめて開いたときは 1-1（モード 4 だけの版は 4-1） */
  st.cur = hp.id; st.sub = hp.sub || 0;
  buildToc();
  buildTabs();
  buildStack(modeOf(st.cur), st.cur);   /* 第 64 回：モードのセクションを縦に並べる */
  if (location.hash && location.hash !== '#' + hashOf() && window.history && history.replaceState) history.replaceState(null, '', '#' + hashOf());   /* 古い書き方のアドレスは #1-1 の形に直す */
  if (st.sub > 1) scrollToSub(st.sub);             /* #1-2-3 などで開いたら、そのカードへ */
  else if (okId && location.hash.length > 1) scrollToSub(1);   /* 第 58 回：#4-2 などで開いたら、ヒーローの下のそのセクションを固定タブの下に */

  window.addEventListener('hashchange', function () {
    if (st._skipHash) { st._skipHash = false; return; }
    var q = parseHash(location.hash);
    if (!DEFS[q.id] || !MODES.some(function (m) { return m.ids.indexOf(q.id) >= 0; })) return;
    gotoSim(q.id, q.sub); scrollToSub(q.sub || 1);   /* 第 64 回：縦に並んだそのセクションへ（いま生きているセクションでも） */
  });
  /* たて置きのスマホ・タブレットには「横置きをおすすめします」と出す（×で閉じられる） */
  var rotHidden = false;
  function updateRotNote() {
    var el = document.getElementById('rotnote');
    if (!el) return;
    var w = window.innerWidth, h = window.innerHeight;
    el.hidden = rotHidden || !(h > w && Math.min(w, h) < 900);
  }
  var rx = document.getElementById('rotx');
  if (rx) rx.addEventListener('click', function () { rotHidden = true; updateRotNote(); });
  updateRotNote();
  window.addEventListener('orientationchange', function () { setTimeout(updateRotNote, 250); });
  window.addEventListener('resize', function () {
    updateRotNote();
    renderActive();
    var d = DEFS[st.cur];
    if (d.drawBelow) d.drawBelow(st.sims[st.cur]);          /* 図の下のカードの canvas も描き直す */
  });
  requestAnimationFrame(tick);
  /* 第 58 回：ヒーロー（数式・ステージ・要点カード）・フッターの章の目次・タブ列の影 */
  Array.prototype.forEach.call(document.querySelectorAll('#hero .sct, #hero .ie'), function (el) { el.innerHTML = mathHtml(el.innerHTML); });
  renderMath(document.getElementById('hero'));
  if (window.initHeroStage) window.initHeroStage();
  if (window.initHeroIdeas) window.initHeroIdeas();
  buildFooterNav();
  initStuck();

  /* ===== 物理の検算（閉じた式で出す） ===== */
  function check() {
    var out = {};
    var d34 = P.box.dims('3:4');
    out.tan_th0_34 = +(Math.tan(P.tilt.th0(d34.a, d34.b) * DEG)).toFixed(4);         /* 0.75 */
    out.th0_34 = +P.tilt.th0(d34.a, d34.b).toFixed(3);                                  /* 36.870 */
    out.sin_th0_34 = +Math.sin(P.tilt.th0(d34.a, d34.b) * DEG).toFixed(3);              /* 0.60 */
    out.mu0_34 = +(d34.a / d34.b).toFixed(4);                                           /* 0.75 */
    out.th0_list = ['2:8', '4:4', '8:2'].map(function (k) { var q = P.box.dims(k); return +P.tilt.th0(q.a, q.b).toFixed(2); });
    out.th0_sorted = out.th0_list.slice().sort(function (a, b) { return a - b; }).join(',') === out.th0_list.join(',');
    /* r3：F′₀ = mg·a/(2b′)、b′ を半分にすると 2 倍 */
    var d28 = P.box.dims('2:8'), m = P.box.M;
    out.F0_28_full = +P.pull.F0(m, d28.a, d28.b).toFixed(4);
    out.F0_28_half = +P.pull.F0(m, d28.a, d28.b / 2).toFixed(4);
    out.F0_ratio = +(out.F0_28_half / out.F0_28_full).toFixed(4);                     /* 2 */
    /* 判定が μ をまたいで入れかわる */
    var s1 = P.tilt.state(d34.a, d34.b, 0.70, 40, false), s2 = P.tilt.state(d34.a, d34.b, 0.80, 40, false);
    out.tilt_mu_low_first = s1.first; out.tilt_mu_high_first = s2.first;                /* slip / tip */
    var p1 = P.pull.state(m, d28.a, 0.10, 3, d28.b), p2 = P.pull.state(m, d28.a, 0.50, 3, d28.b);
    out.pull_mu_low_first = p1.first; out.pull_mu_high_first = p2.first;                /* slip / tip */
    /* 抗力の作用点：θ=0 で a/2、θ=θ₀ で 0 */
    out.contact_0 = +P.tilt.contact(d34.a, d34.b, 0).toFixed(4);
    out.contact_th0 = +P.tilt.contact(d34.a, d34.b, out.th0_34).toFixed(4);
    out.pull_contact_F0 = +P.pull.contact(m, d28.a, out.F0_28_full, d28.b).toFixed(4);
    out.r1_pinned_never_slips = P.tilt.state(d34.a, d34.b, 0.1, 30, true).first === null;
    return out;
  }

  /* ===== 自動テスト用のフック ===== */
  window.TEST = {
    sims: function () { return Object.keys(DEFS); },
    state: function () {
      var s = st.sims[st.cur];
      return { sim: st.cur, v: JSON.parse(JSON.stringify(s.v)), o: JSON.parse(JSON.stringify(s.o)), ab: s.ab, bp: s.bp,
        cam: s.cam ? { az: +s.cam.az.toFixed(2), el: +s.cam.el.toFixed(2), zoom: +s.cam.zoom.toFixed(2) } : null,
        av: JSON.parse(JSON.stringify(s._av || {})) };
    },
    goto: function (id) { gotoSim(id); return st.cur; },
    set: function (k, val) { setVar(k, val); return st.sims[st.cur].v[k]; },
    ab: function (key) { setAB(key); return st.sims[st.cur].ab; },
    bp: function (val) { setBP(val); return st.sims[st.cur].bp; },
    vis: function (key, on) {
      var el = document.querySelector('#simhost [data-vis="show' + key + '"]');
      if (el && el.checked !== !!on) el.click();
      return st.sims[st.cur].o['show' + key];
    },
    cam: function (az, el, zoom) {
      var s = st.sims[st.cur];
      if (!s.cam) return null;
      s.cam.az = az; s.cam.el = el; s.cam.zoom = zoom || 1;
      refreshActs(); renderActive();
      return { az: s.cam.az, el: s.cam.el, zoom: s.cam.zoom };
    },
    moment: function () { var d = DEFS[st.cur], s = st.sims[st.cur]; if (d.moment) startMoment(d, s); return !!s.anim; },
    animOn: function () { return !!st.sims[st.cur].anim; },
    finishAnim: function () { var s = st.sims[st.cur]; if (s.anim) { s.v[s.anim.k] = s.anim.to; s.anim = null; syncVarVals(); refreshActs(); renderActive(); } return s.v; },
    verdict: function () { var d = DEFS[st.cur], s = st.sims[st.cur]; return d.verdict ? d.verdict(V(s)) : null; },
    acts: function () {
      return Array.prototype.map.call(document.querySelectorAll('#simhost .warm'), function (b) { return { t: b.textContent, on: /\bon\b/.test(b.className) }; });
    },
    resbar: function () { var e = document.getElementById('resbar'); return e ? e.textContent : ''; },
    render: function () { renderActive(); return true; },
    /* 吹き出し（傾いた！／すべった！）が箱に重なっていないか */
    bubbleOverlap: function () {
      window.__vbLog = [];
      renderActive();
      var L = window.__vbLog, out = [];
      L.forEach(function (e) {
        (e.o || []).forEach(function (r) {
          var ox = Math.min(e.b.x1, r.x1) - Math.max(e.b.x0, r.x0);
          var oy = Math.min(e.b.y1, r.y1) - Math.max(e.b.y0, r.y0);
          if (ox > 1 && oy > 1) out.push([+ox.toFixed(1), +oy.toFixed(1)]);
        });
      });
      window.__vbLog = null;
      return out;
    },
    /* 図の文字の重なり（sweep 用）。__labelLog を空にしてから描き直し、重なる組を返す */
    labelOverlap: function () {
      window.__labelLog = [];
      renderActive();
      var L = window.__labelLog, out = [], i, j;
      for (i = 0; i < L.length; i++) for (j = i + 1; j < L.length; j++) {
        var a = L[i], b = L[j];
        if (a.cv !== b.cv) continue;
        var ax0 = a.x, ax1 = a.x + a.w, ay0 = a.y - a.h / 2, ay1 = a.y + a.h / 2;
        var bx0 = b.x, bx1 = b.x + b.w, by0 = b.y - b.h / 2, by1 = b.y + b.h / 2;
        var ox = Math.min(ax1, bx1) - Math.max(ax0, bx0), oy = Math.min(ay1, by1) - Math.max(ay0, by0);
        if (ox > 1.5 && oy > 1.5) out.push([a.text, b.text, +ox.toFixed(1), +oy.toFixed(1)]);
      }
      window.__labelLog = null;
      return out;
    },
    /* 図の下のカード（考え方・解答）の canvas の文字の重なり */
    belowOverlap: function () {
      var d = DEFS[st.cur], s2 = st.sims[st.cur];
      if (!d.drawBelow) return [];
      var box = document.getElementById('r2ans');
      if (box) box.classList.add('open');
      window.__labelLog = [];
      d.drawBelow(s2);
      var L = window.__labelLog, out = [], i, j;
      for (i = 0; i < L.length; i++) for (j = i + 1; j < L.length; j++) {
        var a2 = L[i], b2 = L[j];
        if (a2.cv !== b2.cv) continue;
        var ox = Math.min(a2.x + a2.w, b2.x + b2.w) - Math.max(a2.x, b2.x);
        var oy = Math.min(a2.y + a2.h / 2, b2.y + b2.h / 2) - Math.max(a2.y - a2.h / 2, b2.y - b2.h / 2);
        if (ox > 1.5 && oy > 1.5) out.push([a2.cv, a2.text, b2.text, +ox.toFixed(1), +oy.toFixed(1)]);
      }
      window.__labelLog = null;
      return out;
    },
    check: check
  };
})();

