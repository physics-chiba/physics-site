/* ===== 87_hero.js ===== */
/* =========================================================================
   ヒーローのステージ（第 60 回：「スパナでボルトを回す」に作りかえ。作り方は momentum-and-collision.html の initStage() と同じ）
   ・同じ大きさの力 F（10 N）で、①押す位置を 柄の先 → 中ほど → 根もと、②向きを 垂直 → 斜め 45° → 柄に沿う と変えてくり返す。
   ・回転軸 O から力の作用線までの距離（うで l）が短いほど、ボルトがゆっくり回る（回る速さ ∝ M = Fl）。柄に沿って引くと l = 0 で回らない。
   ・図の約束は ①-1「力のモーメントの 2 通りの求め方」と同じ：スパナ（spanner）・θ は OP の延長から反時計まわり・F は P から外向き・
     作用線は破線・うでは緑・回ると反時計まわり。暗い地の上では力の赤・うでの緑を同じ色相の明るい版にする。
   ・止める：画面の外・タブ非表示・「動きを減らす」設定（1 枚絵）・下の図（#simhost）を押したりドラッグしたとき・一時停止。
     ヒーローを動かしたら下のシミュレーションは止める（同時に動くのは 1 つ）。輪はページ共通の tick（heroTick）。
   ・テスト用：window.__hero.frame(ケースの番号, 時刻[s])
   ========================================================================= */
(function () {
  'use strict';
  if (window.ONLY_MODE) return;                  /* モード 4 だけの版はステージなし */
  var RM = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var C = { F: '#ff6b5b', arm: '#4cd38a', T: '#f6f2e9', dim: 'rgba(243,239,230,.45)', brand: '#e07b18' };
  var SER = '"KaTeX_Main","Times New Roman",serif', MATH = '"KaTeX_Math","KaTeX_Main",serif',
      JP = '"Hiragino Sans","Hiragino Kaku Gothic ProN","Yu Gothic",YuGothic,"Noto Sans JP",Meiryo,sans-serif';
  var FN = 10, LEN = 0.30;                       /* 力の大きさ［N］、O から柄の先まで［m］ */
  /* ケース：d … O から作用点 P まで（柄の長さに対する割合）、th … OP の延長から測った力の向き［°］ */
  var CASES = [
    { d: 1.0, th: 90, name: '柄の先・垂直' },
    { d: 0.6, th: 90, name: '中ほど・垂直' },
    { d: 0.3, th: 90, name: '根もと・垂直' },
    { d: 1.0, th: 45, name: '柄の先・斜め 45°' },
    { d: 1.0, th: 0, name: '柄の先・柄に沿う' }
  ];
  var SEQ = { auto: [0, 1, 2, 3, 4], pos: [0, 1, 2], dir: [0, 3, 4] };
  function armOf(c) { return LEN * c.d * Math.sin(c.th * Math.PI / 180); }       /* うで l［m］ */
  var MMAX = FN * LEN;                            /* いちばん大きい M（柄の先・垂直）［N·m］ */
  var ANG0 = -14 * Math.PI / 180, TURN = 38 * Math.PI / 180;   /* はじめの柄の向き（①-1 と同じ少し右上がり）・M が最大のときに回る角 */
  var T_WAIT = 0.45, T_PUSH = 1.5, T_HOLD = 1.0, FADE = 0.4;

  function initStage() {
    var cv = document.getElementById('heroCv'); if (!cv) return;
    var ctx = cv.getContext('2d');
    var W = 0, H = 0, dpr = 1, run = false, last = 0, L = null;
    var seq = 'auto', k = 0, tt = 0, paused = false, rate = 1;

    function setup() {
      var r = cv.getBoundingClientRect(); dpr = Math.min(2, window.devicePixelRatio || 1);
      W = Math.max(280, r.width); H = Math.max(170, r.height);
      cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var narrow = W < 620, s = Math.max(0.8, Math.min(1.12, H / 270));
      var P = narrow ? { x: 14, y: 10, w: W - 28, h: 64 * s } : { x: W * 0.56, y: 18, w: W * 0.44 - 22, h: H - 36 };
      var top = narrow ? P.y + P.h + 6 : 14, bot = H - 14;
      var sw = narrow ? W : W * 0.54;
      /* 柄が回っても、柄の先の力の矢印と F の文字まで枠からはみ出さない長さ（はじめ −14°、いちばん回って −52°：柄の先の高さ＋矢印の高さ ≒ 1.1 × 長さ） */
      var Ox = narrow ? sw * 0.2 : sw * 0.2, Oy = top + (bot - top) * 0.84;
      var len = Math.min(sw - Ox - 50 * s, (Oy - top - 22 * s) / 1.1, 330);
      var k2 = Math.max(0.62, Math.min(1.15, len / 230));   /* スパナの頭・ナットの大きさ（①-1 の 190 px を基準に） */
      L = { narrow: narrow, s: s, P: P, O: { x: Ox, y: Oy }, len: len, k: k2, sw: sw };
    }
    function arrow(x1, y1, x2, y2, col, lw, head) {
      var dx = x2 - x1, dy = y2 - y1, Ln = Math.hypot(dx, dy); if (Ln < 2) return;
      var ux = dx / Ln, uy = dy / Ln, h = Math.min(head || 12, Ln * 0.6);
      ctx.save(); ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = lw || 3; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2 - ux * h * 0.7, y2 - uy * h * 0.7); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(x2, y2); ctx.lineTo(x2 - ux * h - uy * h * 0.48, y2 - uy * h + ux * h * 0.48); ctx.lineTo(x2 - ux * h + uy * h * 0.48, y2 - uy * h - ux * h * 0.48); ctx.closePath(); ctx.fill();
      ctx.restore();
    }
    function txt(tx, x, y, o) {
      o = o || {}; ctx.save(); ctx.fillStyle = o.col || C.T; ctx.textAlign = o.align || 'left'; ctx.textBaseline = o.base || 'alphabetic';
      ctx.font = (o.it ? 'italic ' : '') + (o.w || 700) + ' ' + Math.round(o.size || 13) + 'px ' + (o.font || JP); ctx.fillText(tx, x, y); var w = ctx.measureText(tx).width; ctx.restore(); return w;
    }
    function rr(x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }
    function fm(v, n) { return v.toFixed(n); }

    /* ci … ケース、rot … いままでに回った角、showF … 力を出すか、fade … 不透明度 */
    function draw(ci, rot, showF, fade) {
      var c = CASES[ci], s = L.s, O = L.O, len = L.len;
      ctx.clearRect(0, 0, W, H);
      ctx.save(); ctx.globalAlpha = fade;
      var ang = ANG0 - rot, u = { x: Math.cos(ang), y: Math.sin(ang) };
      var Pp = { x: O.x + u.x * len * c.d, y: O.y + u.y * len * c.d };
      var th = c.th * Math.PI / 180, fu = { x: Math.cos(ang - th), y: Math.sin(ang - th) };
      var FL = len * 0.42;
      /* 回った向き（反時計まわり）の弧の矢印：ナットのまわりに薄く */
      if (rot > 0.03) {
        ctx.save(); ctx.strokeStyle = 'rgba(243,239,230,.35)'; ctx.lineWidth = 2; ctx.setLineDash([4, 4]);
        ctx.beginPath(); ctx.arc(O.x, O.y, 46 * L.k, ANG0, ANG0 - rot, true); ctx.stroke(); ctx.restore();
      }
      /* スパナとナット（①-1 と同じ形・色） */
      ctx.save(); ctx.translate(O.x, O.y); ctx.scale(L.k, L.k);
      spanner(ctx, { x: 0, y: 0 }, ang, (len + 22 * L.k) / L.k);
      ctx.restore();
      ctx.save(); ctx.fillStyle = '#0e1115'; ctx.strokeStyle = C.T; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(O.x, O.y, 3.6, 0, 7); ctx.fill(); ctx.stroke(); ctx.restore();
      txt('O', O.x - 36 * L.k - 4, O.y + 5, { size: 15 * s, font: MATH, w: 400, it: true });
      txt('回転軸', O.x, O.y + 40 * L.k + 12 * s, { size: 11 * s, col: C.dim, w: 600, align: 'center' });
      if (showF) {
        /* 作用線（破線）と、うで（O から作用線に下ろした垂線・緑） … 説明の線・矢印はスパナよりあとに描く */
        ctx.save(); ctx.strokeStyle = 'rgba(255,107,91,.55)'; ctx.lineWidth = 1.4; ctx.setLineDash([7, 5]);
        ctx.beginPath(); ctx.moveTo(Pp.x - fu.x * len * 1.6, Pp.y - fu.y * len * 1.6); ctx.lineTo(Pp.x + fu.x * len * 0.9, Pp.y + fu.y * len * 0.9); ctx.stroke(); ctx.restore();
        var tq = (Pp.x - O.x) * fu.x + (Pp.y - O.y) * fu.y, Fo = { x: Pp.x - fu.x * tq, y: Pp.y - fu.y * tq };
        var al = Math.hypot(Fo.x - O.x, Fo.y - O.y);
        if (al > 3) {
          ctx.save(); ctx.strokeStyle = C.arm; ctx.lineWidth = 2.8; ctx.beginPath(); ctx.moveTo(O.x, O.y); ctx.lineTo(Fo.x, Fo.y); ctx.stroke();
          var nn = { x: (O.x - Fo.x) / al, y: (O.y - Fo.y) / al }, sg = tq > 1 ? 1 : -1;   /* 第 62 回：垂直に押すとき（tq ≒ 0）は直角の印を力の矢印と反対がわに固定（誤差で左右に入れかわってチカチカしていた） */
          ctx.lineWidth = 1.3; ctx.beginPath(); ctx.moveTo(Fo.x + nn.x * 9, Fo.y + nn.y * 9); ctx.lineTo(Fo.x + nn.x * 9 + sg * fu.x * 9, Fo.y + nn.y * 9 + sg * fu.y * 9); ctx.lineTo(Fo.x + sg * fu.x * 9, Fo.y + sg * fu.y * 9); ctx.stroke(); ctx.restore();
          /* 「うで l」は、うでの左がわ（スパナと反対がわ）に */
          var pn = { x: -(Fo.y - O.y) / al, y: (Fo.x - O.x) / al };
          /* 第 61 回：置く側は「力の矢印と反対がわ」に決める（うでと柄が重なる垂直のとき、柄の向きで決めると毎フレーム左右に入れかわってチカチカしていた） */
          if (pn.x * fu.x + pn.y * fu.y > 0) { pn.x = -pn.x; pn.y = -pn.y; }
          var off = (al < 70 * s ? 34 : 18) * s, lx = (O.x + Fo.x) / 2 + pn.x * off, ly = (O.y + Fo.y) / 2 + pn.y * off;   /* うでが短いときは P・ナットと重ならないよう少し離す */
          txt('うで', lx, ly + 4, { size: 13 * s, col: C.arm, align: pn.x < 0 ? 'right' : 'left' });
        } else {
          txt('作用線が O を通る', O.x + 6, O.y - 52 * L.k - 6, { size: 12 * s, col: C.F });
        }
        arrow(Pp.x, Pp.y, Pp.x + fu.x * FL, Pp.y + fu.y * FL, C.F, 3.2, 13);
        txt('F', Pp.x + fu.x * (FL + 16 * s) - 5, Pp.y + fu.y * (FL + 16 * s) + 6, { size: 18 * s, col: C.F, font: MATH, w: 400, it: true });
        ctx.save(); ctx.fillStyle = C.T; ctx.beginPath(); ctx.arc(Pp.x, Pp.y, 3.4, 0, 7); ctx.fill(); ctx.restore();
        txt('P', Pp.x + 7, Pp.y + 18 * s, { size: 14 * s, font: MATH, w: 400, it: true, col: 'rgba(243,239,230,.8)' });
      }
      /* 右（スマホは上）：M = F × l の計算と、M の棒 */
      var Pn = L.P, l = armOf(c), M = FN * l;
      var ltx = (l < 1e-9 ? '0' : fm(l, 2)), mtx = (M < 1e-9 ? '0' : fm(M, 1));
      if (!L.narrow) {
        txt('回転軸 O のまわりの力のモーメント', Pn.x, Pn.y + 14 * s, { size: 11 * s, col: C.dim });
        var x = Pn.x, y = Pn.y + 50 * s;
        x += txt('M', x, y, { size: 28 * s, font: MATH, w: 400, it: true });
        x += txt(' = ', x, y, { size: 26 * s, font: SER, w: 400 });
        x += txt('F', x, y, { size: 28 * s, font: MATH, w: 400, it: true, col: C.F });
        x += txt(' × ', x, y, { size: 26 * s, font: SER, w: 400 });
        txt('l', x, y, { size: 28 * s, font: MATH, w: 400, it: true, col: C.arm });
        var y2 = y + 34 * s; x = Pn.x;
        x += txt('= ', x, y2, { size: 18 * s, font: SER, w: 400 });
        x += txt('10 N', x, y2, { size: 18 * s, font: SER, w: 400, col: C.F });
        x += txt(' × ', x, y2, { size: 18 * s, font: SER, w: 400 });
        x += txt(ltx + ' m', x, y2, { size: 18 * s, font: SER, w: 400, col: C.arm });
        x += txt(' = ', x, y2, { size: 18 * s, font: SER, w: 400 });
        txt(mtx + ' N·m', x, y2, { size: 18 * s, font: SER, w: 400 });
        /* M の棒（いちばん大きいとき＝柄の先・垂直を 1 として） */
        var by = y2 + 24 * s, bw = Pn.w - 6;
        ctx.save(); ctx.fillStyle = 'rgba(255,255,255,.07)'; rr(Pn.x, by, bw, 8, 4); ctx.fill();
        ctx.fillStyle = C.brand; rr(Pn.x, by, Math.max(M > 0 ? 6 : 0, bw * M / MMAX), 8, 4); ctx.fill(); ctx.restore();
        txt(M > 0 ? '回る速さは M に比例' : '作用線が回転軸 O を通る → l = 0 → 回らない', Pn.x, by + 30 * s, { size: 12.5 * s, col: C.brand });
        txt('力の大きさはいつも同じ（10 N）。柄の長さ 0.30 m', Pn.x, by + 52 * s, { size: 11 * s, col: C.dim, w: 600 });
        txt(c.name, Pn.x + Pn.w - 4, Pn.y + 14 * s, { size: 12 * s, col: C.brand, align: 'right' });
        var lst = SEQ[seq];
        for (var q = 0; q < lst.length; q++) { ctx.beginPath(); ctx.arc(Pn.x + Pn.w - 6 - (lst.length - 1 - q) * 13, Pn.y + 30 * s, 3, 0, 7); ctx.fillStyle = (lst[q] === ci ? C.brand : 'rgba(243,239,230,.2)'); ctx.fill(); }
      } else {
        var xx = Pn.x, yy = Pn.y + 18 * s;
        xx += txt('M', xx, yy, { size: 18 * s, font: MATH, w: 400, it: true });
        xx += txt(' = ', xx, yy, { size: 16 * s, font: SER, w: 400 });
        xx += txt('10 N', xx, yy, { size: 16 * s, font: SER, w: 400, col: C.F });
        xx += txt(' × ', xx, yy, { size: 16 * s, font: SER, w: 400 });
        xx += txt(ltx + ' m', xx, yy, { size: 16 * s, font: SER, w: 400, col: C.arm });
        xx += txt(' = ', xx, yy, { size: 16 * s, font: SER, w: 400 });
        txt(mtx + ' N·m', xx, yy, { size: 16 * s, font: SER, w: 400 });
        var by2 = yy + 12 * s, bw2 = Pn.w;
        ctx.save(); ctx.fillStyle = 'rgba(255,255,255,.07)'; rr(Pn.x, by2, bw2, 7, 4); ctx.fill();
        ctx.fillStyle = C.brand; rr(Pn.x, by2, Math.max(M > 0 ? 6 : 0, bw2 * M / MMAX), 7, 4); ctx.fill(); ctx.restore();
        txt(c.name + (M > 0 ? '' : '　→ 回らない（l = 0）'), Pn.x, by2 + 26 * s, { size: 12 * s, col: C.brand });
      }
      ctx.restore();
    }

    function curCase() { return SEQ[seq][k % SEQ[seq].length]; }
    function rotAt(ci, t) {                          /* 押しはじめてからの時間 t で回った角（一定の速さ ∝ M） */
      var M = FN * armOf(CASES[ci]);
      return TURN * (M / MMAX) * Math.max(0, Math.min(1, (t - T_WAIT) / T_PUSH));
    }
    function frame(ts) {
      var dt = last ? Math.min(0.05, (ts - last) / 1000) : 0; last = ts;
      tt += dt * rate;
      var ci = curCase(), tot = T_WAIT + T_PUSH + T_HOLD;
      var fade = 1; if (tt < FADE * 0.6) fade = tt / (FADE * 0.6); else if (tt > tot - FADE) fade = Math.max(0, (tot - tt) / FADE);
      draw(ci, rotAt(ci, tt), tt < T_WAIT + T_PUSH + 0.15, fade);
      if (tt >= tot) { tt = 0; k = (k + 1) % SEQ[seq].length; }
    }
    /* 再生の輪は 1 本だけ（A-2）：自分の requestAnimationFrame は回さず、ページの共通の輪（tick）から呼んでもらう */
    window.heroTick = function (ts) { if (run) frame(ts); };
    function start() { if (run || RM || paused) return; run = true; last = 0; }
    function stop() { run = false; }
    function still(ci) {                             /* 1 枚絵：押して少し回ったところ（力・作用線・うで・計算が全部見える） */
      ci = (ci === undefined ? curCase() : ci); draw(ci, rotAt(ci, T_WAIT + T_PUSH * 0.5), true, 1);
    }
    function at(ci, t) { draw(ci, rotAt(ci, t), t < T_WAIT + T_PUSH + 0.15, 1); return { rot: rotAt(ci, t), l: armOf(CASES[ci]) }; }
    setup(); if (RM) still(0); else draw(0, 0, false, 0);
    window.__hero = { frame: function (i, t) { stop(); return at(i, t); }, start: start, stop: stop, running: function () { return run; } };
    var rz = 0; window.addEventListener('resize', function () { clearTimeout(rz); rz = setTimeout(function () { setup(); if (RM || paused || !run) still(); }, 120); });
    var vis = true;
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (es) { es.forEach(function (en) { vis = en.isIntersecting; (vis && !document.hidden) ? start() : stop(); }); }, { threshold: 0.05 }).observe(cv);
    } else start();
    document.addEventListener('visibilitychange', function () { if (document.hidden) stop(); else if (vis) start(); });
    /* 操作：自動（位置 → 向き）／位置を変える／向きを変える・スロー・一時停止 */
    var ctl = document.querySelector('#hero .stagectl');
    if (ctl) {
      var eb = ctl.querySelectorAll('button[data-hc]'), pp = ctl.querySelector('.pp'), sl = ctl.querySelector('.slow');
      if (sl) { if (RM) sl.hidden = true;
        sl.addEventListener('click', function () { rate = (rate === 1 ? 0.35 : 1); sl.setAttribute('aria-pressed', rate < 1 ? 'true' : 'false'); }); }
      Array.prototype.forEach.call(eb, function (b) {
        b.addEventListener('click', function () {
          seq = b.getAttribute('data-hc'); k = 0; tt = 0;
          Array.prototype.forEach.call(eb, function (x) { x.setAttribute('aria-pressed', x === b ? 'true' : 'false'); });
          if (RM || paused) still(); else { soloQuiet(); start(); }
        });
      });
      if (pp) { if (RM) pp.hidden = true;
        pp.addEventListener('click', function () {
          paused = !paused; pp.classList.toggle('paused', paused); pp.setAttribute('aria-label', paused ? '再生' : '一時停止');
          if (paused) { stop(); still(); } else { tt = 0; soloQuiet(); start(); }
        }); }
    }
    function soloQuiet() { if (typeof soloList === 'function') soloList().forEach(function (x) { x.stop(); }); }   /* ヒーローを動かしたら、下のシミュレーションは止める */
    /* 下の図（#simhost）を押したりドラッグしたら止める（再生ボタンがないシミュレーションもあるので、押したらいつでも） */
    document.addEventListener('pointerdown', function (ev) {
      var tg = ev.target; if (!tg || !tg.closest) return;
      if (tg.closest('#simhost, .secbox')) { stop(); if (!RM && !paused) still(); }
    }, true);
  }

  /* ヒーローの 3 つの要点：その章を開いて、本文の頭までスクロール */
  function initIdeas() {
    Array.prototype.forEach.call(document.querySelectorAll('#hero .ideas a[data-goto]'), function (a) {
      a.addEventListener('click', function (ev) {
        ev.preventDefault();
        gotoSim(a.getAttribute('data-goto'));
        window.scrollTo({ top: contentTop(), behavior: 'auto' });
      });
    });
  }
  window.initHeroStage = initStage;
  window.initHeroIdeas = initIdeas;
})();

/* フッター：章の目次（MODES から作る。押すとその章の本文の頭へ） */
function buildFooterNav() {
  var ul = document.getElementById('ftnav'); if (!ul) return;
  ul.innerHTML = MODES.map(function (m) {
    var id = m.ids.filter(function (q) { return !!DEFS[q]; })[0];
    return '<li><a href="#' + m.n + '-1" data-ftgo="' + id + '"><b>' + String(m.name).charAt(0) + '</b>' + String(m.name).slice(1).replace(/^　/, '') + '</a></li>';
  }).join('');
  Array.prototype.forEach.call(ul.querySelectorAll('[data-ftgo]'), function (a) {
    a.addEventListener('click', function (ev) { ev.preventDefault(); gotoSim(a.getAttribute('data-ftgo')); window.scrollTo({ top: contentTop(), behavior: 'auto' }); });
  });
}
/* タブ列：ヒーローを過ぎたら .stuck（影を少し濃く） */
function initStuck() {
  var hero = document.getElementById('hero'), nav = document.getElementById('tabbar'); if (!hero || !nav || !('IntersectionObserver' in window)) return;
  new IntersectionObserver(function (es) { es.forEach(function (en) { nav.classList.toggle('stuck', !en.isIntersecting); }); }, { threshold: 0 }).observe(hero);
}

