/* ===== 85_solo.js ===== */
/* ===== 同時に動くシムは 1 つだけ／画面の外に出たシムは止まる（第 55 回） =====
   ・どれかのスタートを押すと、ほかに動いているもの（同じセクションの別の図）は一時停止する。
   ・動いている図が画面の外に出たら、一時停止する（もう一度スタートで続きから）。
   ・5-1 の左右（角で立てた箱・つま先立ち）は 1 つの図の左右なので、いっしょに動いてよい。 */
function soloCanvas(el) {
  if (!el) return null;
  var box = el.closest('.ansfig, .bcard, .discwrap, .cvstage, .card');
  return box ? box.querySelector('canvas') : null;
}
function soloList() {                    /* いま動いているもの { key, el, stop } */
  var s = st.sims[st.cur], d = DEFS[st.cur], L = [];
  if (!s || !d) return L;
  if (s.playing && $('bPlay')) L.push({ key: 'main', el: $('mainCv'), stop: function () { s.playing = false; setPlayLabel(); } });
  [['ans', s._ans, 'bAnsPlay'], ['ans2', s._ans2, 'bAns2Play']].forEach(function (q) {
    if (q[1] && q[1].playing) L.push({ key: q[0], el: soloCanvas($(q[2])), stop: function () { q[1].playing = false; setAnsLabel(s); } });
  });
  if (s._rn) ['L', 'R'].forEach(function (side) {
    var r = s._rn[side];
    if (!r || r.paused || r.done) return;
    var el = (st.cur === 'st2' && side === 'R') ? $('st2p') : $('mainCv');
    L.push({ key: st.cur === 'st2' ? 'st' + side : 'st', el: el, stop: function () { r.paused = true; stSync(s); } });
  });
  if (st.cur === 'm1s2') [2, 3, 4].forEach(function (no) {
    var dd = s['_d' + no];
    if (!dd || !dd.play) return;
    L.push({ key: 'disc' + no, el: $('m1disc' + no), stop: function () {
      dd.play = false;
      Array.prototype.forEach.call(document.querySelectorAll('[data-dplay="' + no + '"]'), function (x) { x.textContent = '▶ スタート'; x.classList.add('pulse'); });
    } });
  });
  return L;
}
function soloKeyOf(b) {                  /* 押されたボタン → どのシムのスタートか */
  if (!b) return null;
  if (b.id === 'bPlay') return 'main';
  if (b.id === 'bAnsPlay') return 'ans';
  if (b.id === 'bAns2Play') return 'ans2';
  var v = b.getAttribute('data-stplay');
  if (v) return st.cur === 'st2' ? 'st' + v : 'st';
  v = b.getAttribute('data-dplay');
  if (v) return 'disc' + v;
  if (b.hasAttribute('data-mwplay')) return 'mw';
  return null;
}
document.addEventListener('click', function (ev) {      /* 先に（capture で）ほかを止めてから、ボタン自身の処理が動く */
  var b = ev.target && ev.target.closest ? ev.target.closest('button') : null;
  var key = soloKeyOf(b);
  if (!key) return;
  soloList().forEach(function (x) { if (x.key !== key) x.stop(); });
}, true);
var _soloT = 0;
function soloWatch(ts) {                 /* 0.5 秒ごとに見回る（動いているものがあるときだけ） */
  if (ts - _soloT < 500) return;
  _soloT = ts;
  var vh = window.innerHeight || 0;
  soloList().forEach(function (x) {
    var el = x.el;
    if (!el || !el.offsetParent) { x.stop(); return; }
    var r = el.getBoundingClientRect();
    if (r.bottom < 0 || r.top > vh) x.stop();
  });
}

