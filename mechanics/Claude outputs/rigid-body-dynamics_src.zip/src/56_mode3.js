/* ===== 56_mode3.js ===== */
/* ============================================================
   モード 3　重心
     m3s1 … バットの重心（指の上のペンと同じ）
     m3s2 … 質点 2 つと軽い棒
     m3s3 … 2 つの正方形をつないだ板（＝質点 2 つ）… 3 次元
     m3s4 … 穴のあいた円板（＝質点 2 つ）… 3 次元
   ============================================================ */
'use strict';

/* 立体に見せる球（左上から光） */
function ball3d(ctx, x, y, r, base, dark) {
  ctx.save();
  var g = ctx.createRadialGradient(x - r * 0.35, y - r * 0.4, r * 0.1, x, y, r);
  g.addColorStop(0, '#ffffff'); g.addColorStop(0.35, base); g.addColorStop(1, dark);
  ctx.fillStyle = g; ctx.strokeStyle = dark; ctx.lineWidth = 1.3;
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.restore();
}

/* （バットの重心は第 23 回でカット） */

/* ============ m3s2　質点 2 つと軽い棒 ============ */
var B2 = { D: 0.40 };
function m3s2xG(v) { return v.mB * B2.D / (v.mA + v.mB); }
DEFS['m3s2'] = {
  id: 'm3s2', tab: '③-1　質点 2 つと軽い棒', noAB: true, noPlay: true,
  guides: [{ key: 'm3s2', x: 0 }],
  title: '③-1　質点 2 つと軽い棒　～重心の座標～',
  sub: '質量 $m_A$ の球 A と $m_B$ の球 B を、軽い棒でつなぐ（中心間の距離 40 cm）。A の位置を原点 O として x 軸をとり、全体の重心 G の座標 $x_G$ をさがそう。',
  cw: function (v, s) { return (s && s._narrow) ? 470 : 780; },
  ch: function () { return 460; },
  vars: [
    { k: 'mA', label: '球 A の質量 $m_A$', unit: ' kg', min: 0.5, max: 5, step: 0.5, dec: 1, def: 2.0 },
    { k: 'mB', label: '球 B の質量 $m_B$', unit: ' kg', min: 0.5, max: 5, step: 0.5, dec: 1, def: 4.0 }
  ],
  vis: [{ k: 'F', label: '力を表示', def: false }, { k: 'L', label: '力と作用線を表示', def: false },
    { k: 'R', label: '質点にはたらく重力の合力を表示', def: false }],
  ctrlCompact: true,
  reset: function (s) { s._fx = 0.12; s._snap = false; },
  draw: function (ctx, s, W, H) {
    if (s._fx === undefined) DEFS['m3s2'].reset(s);
    var v = V(s), xG = m3s2xG(v);
    function rad(m) { return 12 + 7 * Math.cbrt(m); }
    var rA = rad(v.mA), rB = rad(v.mB);
    var rodY = -4;
    function body(ctx2, x0, L) {
      ctx2.save(); ctx2.strokeStyle = '#8a7a55'; ctx2.lineWidth = 5; ctx2.lineCap = 'round';
      ctx2.beginPath(); ctx2.moveTo(x0, rodY); ctx2.lineTo(x0 + L, rodY); ctx2.stroke(); ctx2.restore();
      ctx2.save(); if (Math.abs(s._fx - xG) < 1e-6) ctx2.globalAlpha = 0.5;   /* つりあったら質点は薄く */
      ball3d(ctx2, x0, rodY, rA, '#7fb3e6', '#1f4f86');
      ball3d(ctx2, x0 + L, rodY, rB, '#f1a08f', '#8e2a1c');
      ctx2.restore();
    }
    var r = drawOnFinger(ctx, s, W, H, { L: B2.D, thick: 8, xG: xG, body: body, gName: '重心 G',
      gLab: function (G) { return { x: G.x - 30, y: G.y + 28, align: 'right' }; },
      forces: [{ X: 0, k: v.mA / (v.mA + v.mB), name: 'm_A g', y: rodY }, { X: B2.D, k: v.mB / (v.mA + v.mB), name: 'm_B g', y: rodY }],
      FT: 105,                                   /* 重力の矢印は長め（前の 1.5 倍） */
      ratio: function () { return { x: [0, xG, B2.D], text: 'l_1 : l_2 = m_B : m_A = ' + fmt(v.mB, 1) + ' : ' + fmt(v.mA, 1) }; }, ratioDy: 74 },
      { padX: 300, yc: H * 0.56, hideG: true, balRes: 'm_A g と m_B g の合力' });
    var g = s._geo;
    /* 球の名前・質量 */
    var pA = r.pp(r.x0 - r.fx, rodY), pB = r.pp(r.x0 + r.L - r.fx, rodY);
    label(ctx, 'A　' + fmt(v.mA, 1) + ' kg', pA.x, pA.y - rA - 18, { size: 15, bold: true, color: '#1f4f86' });
    label(ctx, 'B　' + fmt(v.mB, 1) + ' kg', pB.x, pB.y - rB - 18, { size: 15, bold: true, color: '#8e2a1c' });
    /* x 軸（cm） */
    var ay = H - 62;
    ctx.save(); ctx.strokeStyle = '#1b1f24'; ctx.fillStyle = '#1b1f24'; ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.moveTo(g.x0 - 40, ay); ctx.lineTo(g.x0 + g.L + 70, ay); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(g.x0 + g.L + 78, ay); ctx.lineTo(g.x0 + g.L + 66, ay - 5); ctx.lineTo(g.x0 + g.L + 66, ay + 5); ctx.closePath(); ctx.fill();
    for (var c = 0; c <= 40; c += 10) {
      var xx = g.x0 + c / 40 * g.L;
      ctx.beginPath(); ctx.moveTo(xx, ay - 5); ctx.lineTo(xx, ay + 5); ctx.stroke();
    }
    ctx.restore();
    label(ctx, 'O', g.x0, ay + 18, { size: 14, bold: true });
    label(ctx, '40', g.x0 + g.L, ay + 18, { size: 14, bold: true });
    label(ctx, 'x［cm］', g.x0 + g.L + 92, ay + 18, { size: 14, bold: true });
    if (r.bal) {
      var gx = g.x0 + xG / B2.D * g.L;
      ctx.save(); ctx.strokeStyle = '#e07b18'; ctx.lineWidth = 2.4; ctx.beginPath(); ctx.moveTo(gx, ay - 8); ctx.lineTo(gx, ay + 8); ctx.stroke(); ctx.restore();
      label(ctx, 'x_G = ' + fmt(xG * 100, 0) + ' cm', gx, ay + 38, { size: 15, bold: true, color: '#a85c0c' });
    }
  },
  dragDown: fingerDragDown,
  drag: function (s, lx) {
    var v = V(s); fingerDrag(s, lx, m3s2xG(v));
    s._fx = clamp(s._fx, 0.05, B2.D - 0.05);
  },
  result: function (v, s) {
    var xG = m3s2xG(v);
    if (!s || !s._snap) return { items: [{ k: '重心の座標 $x_G$', v: '？（指で支えられる場所をさがそう）' }], note: '' };
    return { items: [
      { k: '重心の座標　$x_G = \\dfrac{m_A x_A + m_B x_B}{m_A + m_B}$', v: fmt(xG * 100, 1) + ' cm', kbox: true, stack: true },
      { k: 'G のまわり　$m_A g\\,x_G$', v: fmt(v.mA * 9.8 * xG, 2) + ' N・m' },
      { k: '$m_B g\\,(40 - x_G)$', v: fmt(v.mB * 9.8 * (B2.D - xG), 2) + ' N・m' }
    ], note: '' };
  },
  below: function (s) {
    return '<div class="bcard"><h3>＜考え方＞　質点の重心</h3>' +
      '<p>重心 G を支えると回転しない。つまり <b>G のまわりのモーメントの和が 0</b>。A は G の左 $x_G$、B は G の右 $(x_B - x_G)$ の位置にあるので</p>' +
      '<div class="fmlbox"><span class="tex">m_A g \\cdot x_G = m_B g \\cdot (x_B - x_G) \\quad\\Longrightarrow\\quad x_G = \\dfrac{m_A x_A + m_B x_B}{m_A + m_B}\\quad (x_A = 0)</span></div>' +
      '<p>重心は<b>重いほうに近い</b>。距離の比は質量の逆比 $\\;x_G : (x_B - x_G) = m_B : m_A$ になる。</p>' +
      '<p class="mini" id="m3ex1"></p></div>';
  },
  drawBelow: function (s) {
    var ex = document.getElementById('m3ex1'); if (!ex) return;
    var v = V(s), a = fmt(v.mA, 1), b = fmt(v.mB, 1);
    var h = 'いまの $m_A = ' + a + '$ kg、$m_B = ' + b + '$ kg のとき：$x_G = \\dfrac{' + a + '\\times 0 + ' + b + '\\times 40}{' + a + ' + ' + b + '} = ' + fmt(m3s2xG(v) * 100, 1) + '$ cm。';
    if (ex._h !== h) { ex._h = h; ex.innerHTML = mathHtml(h); renderMath(ex); }
  }
};

/* 比を見やすい数で（1 : 3、1 : 4 など。割り切れないときは小数 2 けた） */
function ratioStr(a, b) {
  var r = a / b;
  if (r >= 1) { var k = Math.round(r * 100) / 100; return (Math.abs(k - Math.round(k)) < 1e-6 ? Math.round(k) : fmt(k, 2)) + ' : 1'; }
  var q = Math.round(b / a * 100) / 100; return '1 : ' + (Math.abs(q - Math.round(q)) < 1e-6 ? Math.round(q) : fmt(q, 2));
}
/* ===== 3 次元の板（2 つの正方形／穴あき円板）の共通部品 ===== */
var P3 = { AZ: -18, EL: 32, T: 0.012 };
/* 板のかたち（上から見た多角形、[m]）。parts … 色分けする部分、holes … 穴 */
function plateScene(ctx, s, W, H, shape, opt) {
  opt = opt || {};
  var v = V(s);
  var size = shape.xmax - shape.xmin;
  var S = Math.min((W - 300) / size, (H - 210) / (shape.ydep * Math.sin(P3.EL * DEG) + 0.04));
  if (shape.two2d) S = Math.min(S, (H - 200) / shape.ydep);          /* 平面上の板：上から見ても入る大きさ */
  if (shape.dims) S = Math.min(S, Math.max(W - 390, W * 0.62) / size, (H - 150) / shape.ydep);   /* 3-2：右上の「元の図形」・寸法線とかさならない大きさ */
  var yc0 = shape.yc || 0;                                           /* 奥行き方向のまん中（平面上の板） */
  var cx = W / 2 - (shape.xmin + shape.xmax) / 2 * S * Math.cos(P3.AZ * DEG), cy = H * 0.62;
  var top = s._view === 'top';
  var az0 = top ? 0 : P3.AZ * DEG, el0 = top ? 89.9 * DEG : P3.EL * DEG;
  var cx0 = top ? W / 2 - (shape.xmin + shape.xmax) / 2 * S : cx, cy0 = top ? H * (shape.two2d ? 0.56 : 0.54) : cy;
  var pjRaw = mkProj(az0, el0, S, cx0, cy0);
  var pj = { p: function (q) { return pjRaw.p([q[0], q[1] - yc0, q[2]]); }, S: S };
  var xs = s._xs, xG = shape.xG, ys = shape.two2d ? (s._ys || 0) : 0, yG = shape.yG || 0;
  var ddx = xs - xG, ddy = ys - yG, dist = Math.hypot(ddx, ddy), bal = dist < 1e-9;
  /* 指が重心からずれた向き e（重心 → 指）。板は重心がわが下がるように、e に垂直な軸のまわりに少し傾く */
  var ex = bal ? 1 : ddx / dist, ey = bal ? 0 : ddy / dist;
  var ph = bal ? 0 : (0.06 + Math.min(0.12, dist / size * 0.9));
  var c = Math.cos(ph), sn = Math.sin(ph), T = P3.T;
  function wp(x, y, zp) {
    var px = x - xs, py = y - ys, u = px * ex + py * ey, w = -px * ey + py * ex;
    var u2 = u * c - zp * sn, z2 = u * sn + zp * c;
    return pj.p([xs + u2 * ex - w * ey, ys + u2 * ey + w * ex, z2]);
  }
  function path(poly, zp) { poly.forEach(function (q, k) { var p = wp(q[0], q[1], zp); k ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y); }); ctx.closePath(); }
  /* x 軸（板の下に見えかくれ）… 先に描く */
  var a0 = pj.p([shape.xmin - 0.05, 0, 0]), a1 = pj.p([shape.xmax + 0.07, 0, 0]);
  /* 支える指（板の下）。★板より先に描いて、指先が板にかくれるようにする★ */
  var Sp = wp(xs, ys, -T);
  pointHand(ctx, Sp.x, Sp.y + 1, 0, 0.78);
  /* 下の面（厚み） */
  ctx.save();
  ctx.beginPath(); shape.outer.forEach(function (poly) { path(poly, -T); }); (shape.holes || []).forEach(function (poly) { path(poly, -T); });
  ctx.fillStyle = fade(shape.side || '#9aa7b3', 0.45); ctx.fill('evenodd'); ctx.strokeStyle = '#5b6672'; ctx.lineWidth = 1; ctx.stroke();
  ctx.restore();
  /* 側面の縦線（輪郭の角だけ） */
  ctx.save(); ctx.strokeStyle = '#5b6672'; ctx.lineWidth = 1;
  shape.outer.forEach(function (poly) {
    if (poly.length > 12) return;
    poly.forEach(function (q) { var p1 = wp(q[0], q[1], 0), p2 = wp(q[0], q[1], -T); ctx.beginPath(); ctx.moveTo(p1.x, p1.y); ctx.lineTo(p2.x, p2.y); ctx.stroke(); });
  });
  ctx.restore();
  /* 上の面（部分ごとに色分け） */
  shape.parts.forEach(function (pt) {
    ctx.save();
    ctx.beginPath(); pt.polys.forEach(function (poly) { path(poly, 0); });
    (pt.holes || []).forEach(function (poly) { path(poly, 0); });
    ctx.fillStyle = fade(pt.col, 0.55); ctx.fill('evenodd');          /* 半とうめい：下の指が見える */
    ctx.strokeStyle = pt.line || '#3f4a54'; ctx.lineWidth = 1.4; ctx.stroke();
    ctx.restore();
  });
  if (shape.seam) { ctx.save(); ctx.setLineDash([4, 3]); ctx.strokeStyle = 'rgba(40,50,60,.55)'; ctx.lineWidth = 1.2; ctx.beginPath(); path(shape.seam, 0); ctx.stroke(); ctx.restore(); }
  /* x 軸（点線）と O */
  ctx.save(); ctx.strokeStyle = 'rgba(27,31,36,.55)'; ctx.lineWidth = 1.2; ctx.setLineDash([5, 4]);
  var b0 = wp(shape.xmin - 0.04, 0, 0.001), b1 = wp(shape.xmax + 0.05, 0, 0.001);
  ctx.beginPath(); ctx.moveTo(b0.x, b0.y); ctx.lineTo(b1.x, b1.y); ctx.stroke(); ctx.restore();
  label(ctx, 'x', b1.x + 12, b1.y, { size: 14, bold: true });
  if (shape.two2d) {                             /* 平面上の板：y 軸と目盛り（1 目盛り ＝ shape.U） */
    var y0p = wp(0, 0.04, 0.001), y1p = wp(0, shape.ymin - 0.05, 0.001);
    ctx.save(); ctx.strokeStyle = 'rgba(27,31,36,.55)'; ctx.lineWidth = 1.2; ctx.setLineDash([5, 4]);
    ctx.beginPath(); ctx.moveTo(y0p.x, y0p.y); ctx.lineTo(y1p.x, y1p.y); ctx.stroke(); ctx.restore();
    label(ctx, 'y', y1p.x - 12, y1p.y, { size: 14, bold: true });
    [1, 2].forEach(function (k) {
      var tx = wp(k * shape.U, 0.012, 0.001), ty = wp(-0.012, -k * shape.U, 0.001);
      label(ctx, String(k), tx.x, tx.y + 12, { size: 13, bold: true, color: '#3d4c5a' });
      label(ctx, String(k), ty.x - 8, ty.y, { size: 13, bold: true, color: '#3d4c5a', align: 'right' });
    });
  }
  var Op = wp(0, 0, 0.001);
  actPoint(ctx, Op.x, Op.y, '#1b1f24');
  label(ctx, 'O', Op.x + (shape.oDx || -14), Op.y - 14, { size: 15, bold: true });
  /* 指で支えている点（板の上の面に印） */
  var St = wp(xs, ys, 0.001);
  ctx.save(); ctx.beginPath(); ctx.arc(St.x, St.y, 6, 0, Math.PI * 2); ctx.fillStyle = 'rgba(224,123,24,.35)'; ctx.fill();
  ctx.lineWidth = 2; ctx.strokeStyle = '#e07b18'; ctx.stroke(); ctx.restore();
  var Gq = wp(xG, yG, 0.001);
  var showF = v.showF || v.showL;
  if (!showF && !bal) label(ctx, '指で支える点', St.x, St.y + 20, { size: 12.5, bold: true, color: '#a85c0c' });
  /* 重心 */
  var Gp = wp(xG, yG, 0.001), Gm = wp(xG, yG, -T / 2);
  if (v.showL && !top) {                      /* 作用線（鉛直な点線）：指の力と、それぞれの重力 */
    var lx = [{ p: Sp, c: 'rgba(123,63,212,.55)' }];
    (shape.forces || []).forEach(function (fo) { lx.push({ p: wp(fo.x, fo.y || 0, -T / 2), c: 'rgba(209,53,43,.5)' }); });
    ctx.save(); ctx.lineWidth = 1.3; ctx.setLineDash([7, 5]);
    lx.forEach(function (q) { ctx.strokeStyle = q.c; ctx.beginPath(); ctx.moveTo(q.p.x, q.p.y - 130); ctx.lineTo(q.p.x, q.p.y + 120); ctx.stroke(); });
    ctx.restore();
  }
  /* 質点（ドラッグ中・「常に質点を表示」・つりあったとき）。つりあったときは薄く */
  var FT = 92;
  var resMode = bal || (v.showR && shape.forcesIsRes);          /* 3-3：合力を出すときは、質点（負の質量も）の重力を薄く見せる */
  var pmOn = shape.pm && (v.showP || s._dragging || resMode);
  if (pmOn && shape.pmLink && shape.pm.length > 1) {   /* 2 つの質点をつなぐ点線 */
    var q0 = wp(shape.pm[0].x, shape.pm[0].y || 0, 0.001), q1 = wp(shape.pm[1].x, shape.pm[1].y || 0, 0.001);
    dotLine(ctx, q0.x, q0.y, q1.x, q1.y, bal ? 'rgba(138,90,43,.4)' : 'rgba(138,90,43,.85)', 2, [5, 4]);
  }
  if (pmOn) {
    ctx.save(); if (bal) ctx.globalAlpha = 0.45;
    shape.pm.forEach(function (p) {
      var q = wp(p.x, p.y || 0, 0.001); ball3d(ctx, q.x, q.y, p.r, p.c, p.d);
      if (p.lab) label(ctx, p.lab, q.x + (p.ldx || 0), q.y + (p.ldy || -p.r - 12), { size: 13.5, bold: true, color: p.d });
    });
    ctx.restore();
  }
  NO_SHIFT = true;
  if (showF) arrow(ctx, Sp.x, Sp.y, Sp.x, Sp.y - FT, 'force', 1.05, COL.norm);   /* 指が押す力（全体の重さと同じ大きさ） */
  if (resMode && shape.pmF) {
    /* つりあった瞬間：質点にはたらく重力は薄く、その合力（指が押す力とつりあう力）をこく */
    ctx.save(); ctx.globalAlpha = 0.35;
    shape.pmF.forEach(function (fo) {
      var q = wp(fo.x, fo.y || 0, -T / 2);
      arrow(ctx, q.x, q.y, q.x, q.y + FT * fo.k, 'force', 1.05, COL.force);
      label(ctx, fo.name, q.x + 10, q.y + FT * fo.k + (fo.k < 0 ? 10 : -4), { size: 14, bold: true, color: COL.force, align: 'left' });
    });
    ctx.restore();
  } else if (showF) {
    /* それぞれの部分にはたらく重力（長さは質量に比例）。合力も出すときは薄く */
    ctx.save(); if (v.showR && !shape.forcesIsRes) ctx.globalAlpha = 0.35;
    (shape.forces || [{ x: xG, k: 1, name: '重力' }]).forEach(function (fo) {
      var q = wp(fo.x, fo.y || 0, -T / 2);
      arrow(ctx, q.x, q.y, q.x, q.y + FT * fo.k, 'force', 1.05, COL.force);
      label(ctx, fo.name, q.x + 10, q.y + FT * fo.k - 4, { size: 14, bold: true, color: COL.force, align: 'left' });
    });
    ctx.restore();
  }
  if ((bal || v.showR) && shape.resName) {
    arrow(ctx, Gm.x, Gm.y, Gm.x, Gm.y + FT, 'force', 1.1, COL.force);             /* 合力 */
    label(ctx, shape.resName, Gm.x - 12, Gm.y + FT - 6, { size: 14, bold: true, color: COL.force, align: 'right' });
  }
  NO_SHIFT = false;
  if (showF) label(ctx, '指が押す力', Sp.x + 12, Sp.y - FT + 6, { size: 14, bold: true, color: COL.norm, align: 'left' });
  if (bal || showF) {                         /* 重心は、見つけるまで（つりあうまで）出さない */
    ctx.save(); ctx.beginPath(); ctx.arc(Gp.x, Gp.y, 5, 0, Math.PI * 2); ctx.fillStyle = '#1b1f24'; ctx.fill();
    ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.stroke(); ctx.restore();
    var gnb = shape.gName && bal;                      /* つりあったら座標つきの名前（右にずらす） */
    label(ctx, gnb ? shape.gName : '重心 G', Gp.x + (gnb ? shape.gDxBal : (shape.gDx || 0)), Gp.y + (shape.gDy || -22), { size: 14, bold: true, color: '#1b1f24' });
  }
  if (shape.dimR && !s._dragging && !bal) {           /* 3-3：半径 R（と r）を ↔ で（ドラッグしていないとき） */
    var dimSeg = function (P0, P1, t, col) {
      var mx = (P0.x + P1.x) / 2, my = (P0.y + P1.y) / 2, dx = P1.x - P0.x, dy = P1.y - P0.y, dl = Math.hypot(dx, dy) || 1;
      ctx.save(); ctx.globalAlpha = 0.9;
      arrow(ctx, mx, my, P0.x, P0.y, 'dim', 1); arrow(ctx, mx, my, P1.x, P1.y, 'dim', 1);
      ctx.restore();
      label(ctx, t, mx - dy / dl * 13, my + dx / dl * 13, { size: 15, bold: true, color: col });
    };
    dimSeg(wp(0, 0, 0.001), wp(0, -shape.R, 0.001), 'R', '#1b1f24');
    if (shape.rh > 0) dimSeg(wp(shape.ch, 0, 0.001), wp(shape.ch, -shape.rh, 0.001), 'r', '#0b3c7a');
  }
  if (shape.dims && !s._dragging && !bal) {           /* 3-2：正方形の 1 辺を ↔ で（板の奥がわ。ドラッグ中・つりあい時は出さない） */
    var dOff = 0.03, sg = top ? -1 : 1;                /* 上からの図では手前（下）がわ、斜めの図では奥がわ */
    var yD = sg * (Math.min.apply(null, shape.dims.map(function (d) { return d.ye; })) - dOff);
    shape.dims.forEach(function (d) {
      var P0 = wp(d.x0, yD, 0.001), P1 = wp(d.x1, yD, 0.001);
      ctx.save(); ctx.strokeStyle = 'rgba(27,31,36,.45)'; ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
      [[d.x0, d.ye0 !== undefined ? d.ye0 : d.ye], [d.x1, d.ye]].forEach(function (e) {
        var E0 = wp(e[0], sg * (e[1] - 0.004), 0.001), E1 = wp(e[0], yD - sg * 0.008, 0.001);
        ctx.beginPath(); ctx.moveTo(E0.x, E0.y); ctx.lineTo(E1.x, E1.y); ctx.stroke();
      });
      ctx.restore();
      var mx = (P0.x + P1.x) / 2, my = (P0.y + P1.y) / 2;
      arrow(ctx, mx, my, P0.x, P0.y, 'dim', 1); arrow(ctx, mx, my, P1.x, P1.y, 'dim', 1);
      label(ctx, d.t, mx, my + (top ? 15 : -13), { size: 14, bold: true, color: d.col || '#1b1f24' });
    });
  }
  if (s._snap) snapGlow(ctx, St.x, St.y, 18, '#e07b18', 1);
  /* 右上：色分けする前の「元の図形」（白と黒） */
  var inset = !opt.noInset;
  if (inset) {
    var bxw = 170, bxh = 150, X0 = W - bxw - 10, Y0 = 10;
    ctx.save(); ctx.fillStyle = '#fff'; ctx.strokeStyle = '#c9d2db'; ctx.lineWidth = 1;
    ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(X0, Y0, bxw, bxh, 8); else ctx.rect(X0, Y0, bxw, bxh); ctx.fill(); ctx.stroke(); ctx.restore();
    label(ctx, '元の図形', X0 + bxw / 2, Y0 + 14, { size: 13, bold: true, color: '#1b1f24' });
    var ys2 = [], xs2 = [];
    shape.outer.forEach(function (poly) { poly.forEach(function (q) { xs2.push(q[0]); ys2.push(q[1]); }); });
    var mnx = Math.min.apply(null, xs2), mxx = Math.max.apply(null, xs2), mny = Math.min.apply(null, ys2), mxy = Math.max.apply(null, ys2);
    var ks2 = Math.min((bxw - 30) / (mxx - mnx), (bxh - 44) / (mxy - mny));
    var ocx = X0 + bxw / 2 - (mnx + mxx) / 2 * ks2, ocy = Y0 + 28 + (bxh - 36) / 2 - (mny + mxy) / 2 * ks2;
    ctx.save(); ctx.strokeStyle = '#1b1f24'; ctx.lineWidth = 2; ctx.fillStyle = '#fff';
    ctx.beginPath();
    shape.outer.concat(shape.holes || []).forEach(function (poly) {
      poly.forEach(function (q, kk) { var px = ocx + q[0] * ks2, py = ocy + q[1] * ks2; kk ? ctx.lineTo(px, py) : ctx.moveTo(px, py); });
      ctx.closePath();
    });
    ctx.fill('evenodd'); ctx.stroke(); ctx.restore();
  }
  var bx = inset ? W - 290 : W - 110, by = 76;
  if (bal && shape.ratio) {                   /* つりあった瞬間：質点から重心（つりあいの点）までの距離の比 */
    var rt = shape.ratio, oy = (top ? -70 : -62) - (showF ? (top ? 60 : 40) : 0);   /* 力の矢印（指が押す力）とかさならない高さ */
    function ax(x) { var q = pj.p([x, 0, 0]); return { x: q.x, y: q.y }; }
    var A0 = ax(rt.x[0]), A1 = ax(rt.x[1]), A2 = ax(rt.x[2]);
    if (!shape.pm) rt.dots.forEach(function (dd) { var q = wp(dd.x, 0, 0.001); ball3d(ctx, q.x, q.y, dd.r, dd.c, dd.d); });
    ratioDims(ctx, A0.x, A1.x, A2.x, Math.min(A0.y, A1.y, A2.y) + oy, rt);
    bx = A1.x; by = Math.max(40, Math.min(A0.y, A1.y, A2.y) + oy - (rt.above ? 76 : 44));
  }
  if (bal) okBubble(ctx, 'つりあった！', bal && shape.ratio ? bx : Gp.x, bal && shape.ratio ? by : Gp.y - 40, 15);   /* 重心の真上 */
  else calmBubble(ctx, '傾いてしまう', bx, by, 15);
  s._pgeo = { p0: pj.p([0, 0, 0]), p1: pj.p([1, 0, 0]), sp: Sp, xmin: shape.xmin, xmax: shape.xmax, size: size,
    inv: { az: az0, el: el0, S: S, cx: cx0, cy: cy0, yc: yc0 },
    lo: shape.xsMin !== undefined ? shape.xsMin : shape.xmin + size * 0.04, hi: shape.xsMax !== undefined ? shape.xsMax : shape.xmax - size * 0.04 };
  return { bal: bal, wp: wp };
}
function plateDragDown(s, lx, ly) {
  var g = s._pgeo; if (!g) return false;
  return Math.abs(lx - g.sp.x) < 60 && ly > g.sp.y - 70 && ly < g.sp.y + 110;
}
function plateDrag(s, lx, ly, xG) {
  var g = s._pgeo; if (!g) return;
  var dx = g.p1.x - g.p0.x, dy = g.p1.y - g.p0.y;
  /* 画面のたて方向のずれは使わない（横の位置だけで決める） */
  var x = (lx - g.p0.x) / dx;
  x = clamp(x, g.lo, g.hi);                        /* 板がある所だけ（穴の中では支えられない） */
  var sn = snapTo(x, xG, s._snap ? g.size * 0.05 : g.size * 0.032);
  s._xs = sn.v; s._snap = sn.on;
}
/* 平面上の板：指を前後左右に動かす（画面の点 → 板の面 z = 0 の点）。板の外には出さない */
function inPoly(x, y, poly) {
  var inside = false, i, j;
  for (i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    var xi = poly[i][0], yi = poly[i][1], xj = poly[j][0], yj = poly[j][1];
    if ((yi > y) !== (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}
function plateDrag2(s, lx, ly, shape) {
  var g = s._pgeo; if (!g || !g.inv) return;
  var I = g.inv, ca = Math.cos(I.az), sa = Math.sin(I.az), se = Math.sin(I.el);
  var x1 = (lx - I.cx) / I.S, y1 = (ly - I.cy) / I.S / se;
  var x = x1 * ca + y1 * sa, y = -x1 * sa + y1 * ca + I.yc;
  var dd = Math.hypot(x - shape.xG, y - shape.yG), r = shape.xmax * (s._snap ? 0.07 : 0.045);
  if (dd <= r) { s._xs = shape.xG; s._ys = shape.yG; s._snap = true; return; }   /* 重心に吸いつく */
  s._snap = false;
  var m = 0.008;                                     /* 板のふちから少し内がわだけ */
  if (inPoly(x, y, shape.outer[0]) && inPoly(x + m, y, shape.outer[0]) && inPoly(x - m, y, shape.outer[0]) && inPoly(x, y + m, shape.outer[0]) && inPoly(x, y - m, shape.outer[0])) { s._xs = x; s._ys = y; }
}
function sqPoly(x0, x1, y0, y1) { return [[x0, y0], [x1, y0], [x1, y1], [x0, y1]]; }
function circPoly(cx, cy, r, n) { var a = [], i; n = n || 64; for (i = 0; i < n; i++) { var t = i / n * Math.PI * 2; a.push([cx + r * Math.cos(t), cy + r * Math.sin(t)]); } return a; }

/* ============ m3s3　2 つの正方形をつないだ板 ============ */
var M3S3_A = [5, 8, 10, 15, 20];                         /* 小さい正方形の 1 辺 a［cm］の選べる値 */
/* 質量の比 m1 : m2 = a² : 20² を整数の比 p : q に。m2 = (q/p) m1 の係数の書き方も */
function m3k(sh) {
  var A = Math.round(sh.a * 100), x = A * A, y = 400;
  function g(u, w) { return w ? g(w, u % w) : u; }
  var d = g(x, y), p = x / d, q = y / d;
  return { p: p, q: q, tex: p === 1 ? (q === 1 ? '' : String(q)) : '\\tfrac{' + q + '}{' + p + '}', txt: p === 1 ? (q === 1 ? '' : String(q)) : q + '/' + p };
}
function m3s3shape(v) {
  var a = M3S3_A[Math.round(v.ai)] / 100, B = 0.20;
  var m1 = a * a, m2 = B * B, x1 = a / 2, x2 = a + B / 2;
  var xG = (m1 * x1 + m2 * x2) / (m1 + m2);
  return {
    a: a, B: B, m1: m1, m2: m2, x1: x1, x2: x2, xG: xG,
    xmin: 0, xmax: a + B, ydep: B,
    outer: [[[0, -a / 2], [a, -a / 2], [a, -B / 2], [a + B, -B / 2], [a + B, B / 2], [a, B / 2], [a, a / 2], [0, a / 2]]],
    parts: [{ polys: [sqPoly(0, a, -a / 2, a / 2)], col: '#ffd9a8', line: '#8a5a2b' },
            { polys: [sqPoly(a, a + B, -B / 2, B / 2)], col: '#b9dcf5', line: '#1f4f86' }],
    seam: [[a, -a / 2], [a, a / 2]], side: '#9aa7b3', oDx: -16, gDx: 0,
    dims: [{ x0: 0, x1: a, ye: -a / 2, t: fmt(a * 100, 0) + ' cm', col: '#8a5a2b' }, { x0: a, x1: a + B, ye: -B / 2, ye0: -Math.max(a, B) / 2, t: '20 cm', col: '#1f4f86' }],
    forces: [{ x: x1, k: m1 / (m1 + m2), name: 'm_1 g' }, { x: x2, k: m2 / (m1 + m2), name: 'm_2 g' }],
    pm: [{ x: x1, r: 6 + 4 * Math.sqrt(m1 / m2), c: '#ffb45e', d: '#8a5a2b', lab: 'm_1', ldx: -18, ldy: 16 }, { x: x2, r: 10, c: '#6fb1e8', d: '#1f4f86', lab: 'm_2', ldx: 22, ldy: 18 }],   /* 名前は球の右下（上の「重心 G」とかさならない） */
    pmF: [{ x: x1, k: m1 / (m1 + m2), name: 'm_1 g' }, { x: x2, k: m2 / (m1 + m2), name: 'm_2 g' }],
    resName: 'm_1 g と m_2 g の合力',
    ratio: { above: true, x: [x1, xG, x2], text: 'l_1 : l_2 = m_2 : m_1 = ' + ratioStr(m2, m1),
      d1: fmt((xG - x1) * 100, 1) + ' cm', d2: fmt((x2 - xG) * 100, 1) + ' cm',
      dots: [{ x: x1, r: 6, c: '#ffb45e', d: '#8a5a2b' }, { x: x2, r: 9, c: '#6fb1e8', d: '#1f4f86' }] }
  };
}
DEFS['m3s3'] = {
  id: 'm3s3', tab: '③-2　2 つの正方形をつないだ板', noAB: true, noPlay: true,
  guides: [{ key: 'm3s3', inCv: true }],
  topActions: [
    { label: '上から', glow: true, fn: function (s) { s._view = 'top'; }, is: function (v, s) { return s._view === 'top'; } },
    { label: '斜め上から', fn: function (s) { s._view = 'obl'; }, is: function (v, s) { return s._view !== 'top'; } }
  ],

  title: '③-2　2 つの正方形をつないだ板　～2 つの質点におきかえる～',
  sub: '一様な厚さの板。小さい正方形（1 辺 $a$）と大きい正方形（1 辺 20 cm）をつないである。点 O から重心までの距離をさがそう。' +
    '図の下には、それぞれの正方形を<b>中心に全質量が集まった質点</b>におきかえた図をかいた。',
  cw: function (v, s) { return (s && s._narrow) ? 470 : 780; },
  ch: function () { return 420; },
  vars: [{ k: 'ai', label: '小さい正方形の 1 辺 $a$', unit: '', min: 0, max: 4, step: 1, dec: 0, def: 2, fmtv: M3S3_A.map(function (x) { return x + ' cm'; }) }],
  vis: [{ k: 'F', label: '力を表示', def: false }, { k: 'L', label: '力と作用線を表示', def: false },
    { k: 'P', label: '常に質点を表示', def: false }, { k: 'R', label: '質点にはたらく重力の合力を表示', def: false }],
  ctrlCompact: true,
  reset: function (s) { s._xs = 0.08; s._snap = false; },
  draw: function (ctx, s, W, H) {
    if (s._xs === undefined) DEFS['m3s3'].reset(s);
    var sh = m3s3shape(V(s));
    if (!s._snap && Math.abs(s._xs - sh.xG) < 1e-9) s._snap = true;
    var r = plateScene(ctx, s, W, H, sh);
    if (r.bal) label(ctx, 'つりあった！　O から重心までの距離 ' + fmt(sh.xG * 100, 1) + ' cm', W / 2, H - 14, { size: 15, bold: true, color: '#0a5c5c' });
  },
  dragDown: plateDragDown,
  drag: function (s, lx, ly) { plateDrag(s, lx, ly, m3s3shape(V(s)).xG); },
  result: function (v, s) {
    var sh = m3s3shape(v);
    if (!s || !s._snap) return { items: [{ k: 'O から重心までの距離', v: '？（指で支えられる場所をさがそう）' }], note: '' };
    return { items: [
      { k: 'O から重心まで　$x_G = \\dfrac{m_1 x_1 + m_2 x_2}{m_1 + m_2}$', v: fmt(sh.xG * 100, 1) + ' cm', kbox: true, stack: true },
      { k: '質量の比　$m_1 : m_2$（面積の比）', v: m3k(sh).p + ' : ' + m3k(sh).q }
    ], note: '' };
  },
  below: function (s) {
    return '<div class="bcard"><h3>＜解答　～質点におきかえることが重要～＞</h3><div class="pmwrap"><canvas id="m3pm"></canvas><div class="pmtex" id="m3pmtex"></div></div>' +
      '<p>一様な厚さの板なので、<b>質量は面積に比例</b>する。それぞれの正方形の重心は中心。' +
      '小さい正方形を質量 $m_1$（中心 $x_1 = a/2$）、大きい正方形を質量 $m_2$（中心 $x_2 = a + 10$ cm）の<b>質点</b>とみなすと、2 つの質点の重心を求める問題になる。</p>' +
      '<div class="fmlbox"><span class="tex">x_G = \\dfrac{m_1 x_1 + m_2 x_2}{m_1 + m_2}</span></div>' +
      '<p class="mini" id="m3ex"></p></div>';
  },
  drawBelow: function (s) {
    var cv = document.getElementById('m3pm');
    if (cv && cv.clientWidth > 0) drawPointMassFig(cv, 'sq', m3s3shape(V(s)));
    var ex = document.getElementById('m3ex'), sh = m3s3shape(V(s));
    if (ex) {
      var tr = function (x) { return String(+x.toFixed(2)); }, A = tr(sh.a * 100), K = m3k(sh), P = K.p, Q = K.q;
      var h = 'いまの $a = ' + A + '$ cm のとき：$m_1 : m_2 = ' + A + '^2 : 20^2 = ' + P + ' : ' + Q + '$、$x_1 = ' + tr(sh.x1 * 100) + '$ cm、$x_2 = ' + tr(sh.x2 * 100) + '$ cm より ' +
        '$x_G = \\dfrac{' + P + '\\times ' + tr(sh.x1 * 100) + ' + ' + Q + '\\times ' + tr(sh.x2 * 100) + '}{' + P + ' + ' + Q + '} = ' + fmt(sh.xG * 100, 1) + '$ cm。';
      if (ex._h !== h) { ex._h = h; ex.innerHTML = mathHtml(h); renderMath(ex); }
    }
  }
};

/* ============ m3s5　2 つの正方形をつないだ板（平面上）… xy 座標で重心を求める ============ */
function m3s5shape() {
  var U = 0.10;                                          /* 1 目盛り ＝ 10 cm */
  var P = [[0, 0], [2 * U, 0], [2 * U, -U], [U, -U], [U, -2 * U], [0, -2 * U]];   /* 板の面の座標（y は奥が −。画面の上向きが xy の y） */
  var f = [{ x: 0.5 * U, y: -U, k: 2 / 3, name: '2mg' }, { x: 1.5 * U, y: -0.5 * U, k: 1 / 3, name: 'mg' }];
  return {
    U: U, two2d: true, xG: 5 / 6 * U, yG: -5 / 6 * U, ymin: -2 * U, yc: -U,
    xmin: 0, xmax: 2 * U, ydep: 2 * U,
    outer: [P],
    parts: [{ polys: [sqPoly(0, U, -2 * U, 0)], col: '#ffd9a8', line: '#8a5a2b' },
            { polys: [sqPoly(U, 2 * U, -U, 0)], col: '#b9dcf5', line: '#1f4f86' }],
    seam: [[U, 0], [U, -U]], side: '#9aa7b3', oDx: -16, gDx: 0, gDxBal: 78, gDy: -18,
    gName: '重心 G（5/6, 5/6）',
    forces: f, pmF: f,
    pm: [{ x: 0.5 * U, y: -U, r: 11, c: '#ffb45e', d: '#8a5a2b', lab: '2m', ldx: -26, ldy: -12 },
         { x: 1.5 * U, y: -0.5 * U, r: 8, c: '#6fb1e8', d: '#1f4f86', lab: 'm', ldx: -20, ldy: -12 }],
    resName: '2mg と mg の合力', pmLink: true
  };
}
DEFS['m3s5'] = {
  id: 'm3s5', tab: '③-4　長方形と正方形をつないだ板（平面上）', noAB: true, noPlay: true,
  guides: [{ key: 'm3s5', inCv: true }],
  topActions: [
    { label: '上から', glow: true, fn: function (s) { s._view = 'top'; }, is: function (v, s) { return s._view === 'top'; } },
    { label: '斜め上から', fn: function (s) { s._view = 'obl'; }, is: function (v, s) { return s._view !== 'top'; } }
  ],
  title: '③-4　長方形と正方形をつないだ板（平面上）　～xy 座標で重心を求める～',
  sub: '縦 2・横 1 の長方形と、1 辺 1 の正方形をつないだ一様な板（1 目盛り ＝ 10 cm）。左下を原点 O として x 軸・y 軸をとり、重心 G の座標 $(x_G,\\ y_G)$ をさがそう。' +
    '指は<b>前後左右</b>に動かせる。',
  cw: function (v, s) { return (s && s._narrow) ? 470 : 780; },
  ch: function () { return 460; },
  vars: [],
  vis: [{ k: 'F', label: '力を表示', def: false }, { k: 'L', label: '力と作用線を表示', def: false },
    { k: 'P', label: '常に質点を表示', def: false }, { k: 'R', label: '質点にはたらく重力の合力を表示', def: false }],
  ctrlCompact: true,
  reset: function (s) { s._xs = 0.15; s._ys = -0.05; s._snap = false; },
  draw: function (ctx, s, W, H) {
    if (s._xs === undefined || s._ys === undefined) DEFS['m3s5'].reset(s);
    var r = plateScene(ctx, s, W, H, m3s5shape());
    if (r.bal) label(ctx, 'つりあった！　重心 G の座標は（5/6, 5/6）… 1 目盛り 10 cm なら 約（8.3 cm, 8.3 cm）', W / 2, H - 14, { size: 15, bold: true, color: '#0a5c5c' });
  },
  dragDown: plateDragDown,
  drag: function (s, lx, ly) { plateDrag2(s, lx, ly, m3s5shape()); },
  result: function (v, s) {
    if (!s || !s._snap) return { items: [{ k: '重心の座標 $(x_G,\\ y_G)$', v: '？（指で支えられる場所をさがそう）' }], note: '' };
    return { items: [
      { k: '$x_G = \\dfrac{2m \\times 0.5 + m \\times 1.5}{2m + m}$', v: '5/6', kbox: true, stack: true },
      { k: '$y_G = \\dfrac{2m \\times 1 + m \\times 0.5}{2m + m}$', v: '5/6', kbox: true, stack: true }
    ], note: '' };
  },
  below: function (s) {
    return '<div class="bcard"><h3>＜解答　～質点におきかえることが重要～＞</h3><div class="pmwrap"><canvas id="m3pm"></canvas><div class="pmtex" id="m3pmtex"></div></div>' +
      '<p>板を<b>長方形</b>と<b>正方形</b>に分け、それぞれの中心に全質量が集まった<b>質点</b>とみなす。一様な板なので質量は面積に比例し、長方形は $2m$、正方形は $m$。' +
      '重心の公式を <b>$x$ と $y$ それぞれ</b>で使えばよい。</p>' +
      '<div class="fmlbox"><span class="tex">x_G = \\dfrac{m_1 x_1 + m_2 x_2}{m_1 + m_2},\\qquad y_G = \\dfrac{m_1 y_1 + m_2 y_2}{m_1 + m_2}</span></div></div>';
  },
  drawBelow: function (s) {
    var cv = document.getElementById('m3pm');
    if (cv && cv.clientWidth > 0) drawLFig(cv);
  }
};
/* ＜解答＞の図（平面上の板）：左に xy 座標の板、右に質点と重心。右上に x・y それぞれの式 */
function drawLFig(cv) {
  var el = document.getElementById('m3pmtex');
  if (el && !el._h) {
    el._h = 1;
    el.innerHTML = '<span class="pmcap">① それぞれの質量（面積に比例）：長方形 2m、正方形 m</span><br>' +
      '<span class="pmcap">② 長方形の質点 (0.5, 1) と正方形の質点 (1.5, 0.5) の重心を、x と y それぞれで</span><br>' +
      '<span class="tex">x_G = \\dfrac{2m \\cdot 0.5 + m \\cdot 1.5}{2m + m} = \\dfrac{2.5m}{3m} = \\dfrac{5}{6}</span><br>' +
      '<span class="tex">y_G = \\dfrac{2m \\cdot 1 + m \\cdot 0.5}{2m + m} = \\dfrac{2.5m}{3m} = \\dfrac{5}{6}</span><br>' +
      '<span class="tex">\\text{G}\\left(\\dfrac{5}{6},\\ \\dfrac{5}{6}\\right)</span>';
    renderMath(el);
  }
  var W = 760, H = 420, ctx = prep(cv, W, H);
  NO_SHIFT = true;
  function axes(ox, oy, k) {
    ctx.save(); ctx.strokeStyle = '#1b1f24'; ctx.fillStyle = '#1b1f24'; ctx.lineWidth = 1.3;
    ctx.beginPath(); ctx.moveTo(ox - 8, oy); ctx.lineTo(ox + 2.4 * k, oy); ctx.moveTo(ox, oy + 8); ctx.lineTo(ox, oy - 2.4 * k); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(ox + 2.4 * k + 8, oy); ctx.lineTo(ox + 2.4 * k - 2, oy - 5); ctx.lineTo(ox + 2.4 * k - 2, oy + 5); ctx.fill();
    ctx.beginPath(); ctx.moveTo(ox, oy - 2.4 * k - 8); ctx.lineTo(ox - 5, oy - 2.4 * k + 2); ctx.lineTo(ox + 5, oy - 2.4 * k + 2); ctx.fill();
    [1, 2].forEach(function (n) {
      ctx.beginPath(); ctx.moveTo(ox + n * k, oy - 4); ctx.lineTo(ox + n * k, oy + 4); ctx.moveTo(ox - 4, oy - n * k); ctx.lineTo(ox + 4, oy - n * k); ctx.stroke();
    });
    ctx.restore();
    [1, 2].forEach(function (n) {
      label(ctx, String(n), ox + n * k, oy + 16, { size: 13, bold: true });
      label(ctx, String(n), ox - 14, oy - n * k, { size: 13, bold: true });
    });
    label(ctx, 'x', ox + 2.4 * k + 16, oy, { size: 14, bold: true });
    label(ctx, 'y', ox, oy - 2.4 * k - 16, { size: 14, bold: true });
    label(ctx, 'O', ox - 12, oy + 14, { size: 13, bold: true });
  }
  /* 左：板 */
  var k1 = 100, o1 = { x: 70, y: 350 };
  axes(o1.x, o1.y, k1);
  ctx.save(); ctx.lineWidth = 1.6;
  ctx.fillStyle = '#ffd9a8'; ctx.strokeStyle = '#8a5a2b'; ctx.fillRect(o1.x, o1.y - 2 * k1, k1, 2 * k1); ctx.strokeRect(o1.x, o1.y - 2 * k1, k1, 2 * k1);
  ctx.fillStyle = '#b9dcf5'; ctx.strokeStyle = '#1f4f86'; ctx.fillRect(o1.x + k1, o1.y - k1, k1, k1); ctx.strokeRect(o1.x + k1, o1.y - k1, k1, k1);
  ctx.restore();
  ball3d(ctx, o1.x + 0.5 * k1, o1.y - k1, 6, '#ffb45e', '#8a5a2b');
  ball3d(ctx, o1.x + 1.5 * k1, o1.y - 0.5 * k1, 6, '#6fb1e8', '#1f4f86');
  /* まん中の矢印 */
  var mx = 300, my = 240;
  ctx.save(); ctx.fillStyle = '#c0141c';
  ctx.beginPath(); ctx.moveTo(mx, my - 16); ctx.lineTo(mx + 36, my - 16); ctx.lineTo(mx + 36, my - 30); ctx.lineTo(mx + 66, my);
  ctx.lineTo(mx + 36, my + 30); ctx.lineTo(mx + 36, my + 16); ctx.lineTo(mx, my + 16); ctx.closePath(); ctx.fill(); ctx.restore();
  /* 右：質点と重心 */
  var k2 = 85, o2 = { x: 440, y: 352 };
  axes(o2.x, o2.y, k2);
  ctx.save(); ctx.setLineDash([4, 3]); ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(138,90,43,.45)'; ctx.strokeRect(o2.x, o2.y - 2 * k2, k2, 2 * k2);
  ctx.strokeStyle = 'rgba(31,79,134,.45)'; ctx.strokeRect(o2.x + k2, o2.y - k2, k2, k2); ctx.restore();
  var A = { x: o2.x + 0.5 * k2, y: o2.y - k2 }, B = { x: o2.x + 1.5 * k2, y: o2.y - 0.5 * k2 }, Gp = { x: o2.x + 5 / 6 * k2, y: o2.y - 5 / 6 * k2 };
  ctx.save(); ctx.strokeStyle = '#8a5a2b'; ctx.lineWidth = 2.4; ctx.beginPath(); ctx.moveTo(A.x, A.y); ctx.lineTo(B.x, B.y); ctx.stroke(); ctx.restore();
  ball3d(ctx, A.x, A.y, 11, '#ffb45e', '#8a5a2b');
  ball3d(ctx, B.x, B.y, 8, '#6fb1e8', '#1f4f86');
  label(ctx, '2m　(0.5, 1)', A.x - 14, A.y - 20, { size: 13.5, bold: true, color: '#8a5a2b' });
  label(ctx, 'm　(1.5, 0.5)', B.x + 10, B.y - 20, { size: 13.5, bold: true, color: '#1f4f86', align: 'left' });
  dotLine(ctx, Gp.x, Gp.y, Gp.x, o2.y, 'rgba(168,92,12,.8)', 1.2, [3, 3]);
  dotLine(ctx, Gp.x, Gp.y, o2.x, Gp.y, 'rgba(168,92,12,.8)', 1.2, [3, 3]);
  ctx.save(); ctx.beginPath(); ctx.arc(Gp.x, Gp.y, 6, 0, Math.PI * 2); ctx.fillStyle = '#e07b18'; ctx.fill(); ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.stroke(); ctx.restore();
  label(ctx, 'G', Gp.x + 12, Gp.y + 12, { size: 14, bold: true, color: '#a85c0c', align: 'left' });
  label(ctx, '5/6', Gp.x - 8, o2.y + 34, { size: 13, bold: true, color: '#a85c0c' });
  label(ctx, '5/6', o2.x - 34, Gp.y, { size: 13, bold: true, color: '#a85c0c' });
  NO_SHIFT = false;
  label(ctx, '長方形と正方形を、それぞれの中心に全質量が集まった「質点」とみなす！', W / 2, H - 12, { size: 13.5, bold: true, color: '#3d4c5a' });
}

/* ============ m3s4　穴のあいた円板 ============ */
/* 切り抜く円板の半径 r は R の 0・1/4・1/2・3/4 倍（v.rh = 0〜3）。文字式の答えの表 */
var HOLE_TXT = {
  1: { xgp: 'R/20', dp: '3R/4', rp: 'R/4', r: '\\dfrac{R}{4}', k2: '\\dfrac{1}{16}', mc: '\\dfrac{1}{16}m', mr: '\\dfrac{15}{16}m', d: '\\dfrac{3}{4}R', q: '\\dfrac{1}{15}', xg: '\\dfrac{R}{20}' },
  2: { xgp: 'R/6', dp: 'R/2', rp: 'R/2', r: '\\dfrac{R}{2}', k2: '\\dfrac{1}{4}', mc: '\\dfrac{1}{4}m', mr: '\\dfrac{3}{4}m', d: '\\dfrac{1}{2}R', q: '\\dfrac{1}{3}', xg: '\\dfrac{R}{6}' },
  3: { xgp: '9R/28', dp: 'R/4', rp: '3R/4', r: '\\dfrac{3}{4}R', k2: '\\dfrac{9}{16}', mc: '\\dfrac{9}{16}m', mr: '\\dfrac{7}{16}m', d: '\\dfrac{1}{4}R', q: '\\dfrac{9}{7}', xg: '\\dfrac{9R}{28}' }
};
function m3s4shape(v) {
  var R = 0.20, kq = Math.round(v.rh), rh = kq * R / 4, ch = R - rh;   /* 穴は右端で内接する */
  var mh = rh * rh, mr = R * R - rh * rh;               /* 質量（面積に比例） */
  var xG = rh > 0 ? -mh * ch / mr : 0;
  var holes = rh > 0 ? [circPoly(ch, 0, rh, 56)] : [];
  var xsMax = rh > 0 ? ch - rh - 0.006 : R - 0.012;     /* 指は板のある所だけ（穴の中では支えられない） */
  var sh = {
    R: R, rh: rh, kq: kq, ch: ch, mh: mh, mr: mr, xG: xG,
    xmin: -R, xmax: R, ydep: 2 * R,
    outer: [circPoly(0, 0, R, 72)], holes: holes,
    parts: [{ polys: [circPoly(0, 0, R, 72)], holes: holes, col: '#8fd3f7', line: '#1f6f9a' }],
    side: '#5fa9cf', oDx: -14, gDx: -34, gDy: 20, xsMin: -R + 0.012, xsMax: xsMax,
    inHole: rh > 0 && xG > xsMax,                        /* 重心が穴の中（r = 3R/4） */
    dimR: true,                                          /* 図の中に R・r の ↔ */
    forces: [{ x: xG, k: 1, name: rh > 0 ? '残りの部分の重力' : '重力' }], forcesIsRes: true,
    resName: '合力（残りの部分の重力）'
  };
  if (rh > 0) {
    /* 質点：穴のない円板（質量 m、中心 O）と、切り抜いたぶん（−m_切、穴の中心）。合力 ＝ 残りの部分の重力 */
    sh.pm = [{ x: 0, r: 10, c: '#8fd3f7', d: '#1f6f9a', lab: 'm（穴なし）', ldx: 44, ldy: 22 }, { x: ch, r: 7, c: '#6fa4e8', d: '#0b3c7a', lab: '−m_切', ldx: -30, ldy: -16 }];
    sh.pmF = [{ x: 0, k: (mr + mh) / mr, name: 'mg' }, { x: ch, k: -mh / mr, name: '−m_切 g' }];
    sh.ratio = { above: true, x: [xG, 0, ch], text: 'l_1 : l_2 = m_切 : m_残 = ' + ratioStr(mh, mr),
      d1: HOLE_TXT[kq].xgp, d2: HOLE_TXT[kq].dp, dots: [{ x: ch, r: 7, c: '#6fa4e8', d: '#0b3c7a' }] };
  }
  return sh;
}
DEFS['m3s4'] = {
  id: 'm3s4', tab: '③-3　穴のあいた円板', noAB: true, noPlay: true,
  guides: [{ key: 'm3s4', inCv: true }],
  topActions: [
    { label: '上から', glow: true, fn: function (s) { s._view = 'top'; }, is: function (v, s) { return s._view === 'top'; } },
    { label: '斜め上から', fn: function (s) { s._view = 'obl'; }, is: function (v, s) { return s._view !== 'top'; } }
  ],

  title: '③-3　穴のあいた円板　～切り抜いた円板も質点～',
  sub: '半径 $R$ の一様な円板から、半径 $r$ の円板を右端で内接するように切り抜いた。残りの部分の重心をさがそう。' +
    '$r$ は $R$ の何倍かをスライダーで選べる。図の下には、<b>残りの部分と切り抜く円板それぞれを、重心に全質量が集まった質点</b>とみなした解答をかいた。',
  cw: function (v, s) { return (s && s._narrow) ? 470 : 780; },
  ch: function () { return 440; },
  vars: [{ k: 'rh', label: '切り抜く円板の半径 $r$', unit: '', min: 0, max: 3, step: 1, dec: 0, def: 2, fmtv: ['0', 'R/4', 'R/2', '3R/4'] }],
  vis: [{ k: 'F', label: '力を表示', def: false }, { k: 'L', label: '力と作用線を表示', def: false },
    { k: 'P', label: '常に質点を表示', def: false }, { k: 'R', label: '質点にはたらく重力の合力を表示', def: false }],
  ctrlCompact: true,
  reset: function (s) { s._xs = -0.15; s._snap = false; },
  draw: function (ctx, s, W, H) {
    if (s._xs === undefined) DEFS['m3s4'].reset(s);
    var sh = m3s4shape(V(s));
    s._xs = clamp(s._xs, sh.xsMin, sh.xsMax);             /* r を変えて穴の中に入ったら、板のある所へ */
    var r = plateScene(ctx, s, W, H, sh);
    if (r.bal) label(ctx, 'つりあった！　重心は ' + (sh.rh > 0 ? 'O から左へ ' + HOLE_TXT[sh.kq].xgp : '中心 O'), W / 2, H - 14, { size: 15, bold: true, color: '#0a5c5c' });
    else if (sh.inHole) {                                 /* r = 3R/4：重心が穴の中 */
      var Gq = r.wp(sh.xG, 0, 0.001);
      ctx.save(); ctx.beginPath(); ctx.arc(Gq.x, Gq.y, 5, 0, Math.PI * 2); ctx.fillStyle = 'rgba(27,31,36,.55)'; ctx.fill(); ctx.restore();
      label(ctx, '重心 G（穴の中）', Gq.x - 10, Gq.y - 18, { size: 13.5, bold: true, color: '#3d4c5a', align: 'right' });
      label(ctx, '重心が穴の中（板のない所）にあるので、1 本の指では支えられない', W / 2, 128, { size: 14, bold: true, color: '#9b2418' });
    }
  },
  dragDown: plateDragDown,
  drag: function (s, lx, ly) { plateDrag(s, lx, ly, m3s4shape(V(s)).xG); },
  result: function (v, s) {
    var sh = m3s4shape(v);
    if (sh.rh === 0) return { items: [{ k: '切り抜かないとき', v: '重心は中心 O', kbox: true }], note: '' };
    if (sh.inHole) return { items: [{ k: '残りの部分の重心（O から左へ）', v: HOLE_TXT[sh.kq].xgp + '（穴の中）', kbox: true }], note: '' };
    if (!s || !s._snap) return { items: [{ k: '残りの部分の重心', v: '？（指で支えられる場所をさがそう）' }], note: '' };
    return { items: [
      { k: '残りの部分の重心（O から左へ）　$x_G = \\dfrac{m_{\\text{切}}}{m_{\\text{残}}}(R - r)$', v: HOLE_TXT[sh.kq].xgp, kbox: true, stack: true },
      { k: '質量の比　残り : 切り抜く円板', v: fmt(sh.mr / sh.mh, 2) + ' : 1' }
    ], note: '' };
  },
  below: function (s) {
    return '<div class="bcard"><h3>＜解答　～質点におきかえることが重要～＞</h3><div class="pmwrap"><canvas id="m3pm"></canvas><div class="pmtex" id="m3pmtex"></div></div>' +
      '<div id="m3ans23"></div></div>';
  },
  drawBelow: function (s) {
    var sh = m3s4shape(V(s));
    var cv = document.getElementById('m3pm');
    if (cv && cv.clientWidth > 0) drawPointMassFig(cv, 'hole', sh);
    holeAns23(sh);
  }
};
/* 3-3 の解答 ②・③（図の下）。① は図の右上（pmTex） */
function holeAns23(sh) {
  var el = document.getElementById('m3ans23'); if (!el) return;
  var h, T = HOLE_TXT[sh.kq], cm = fmt(-sh.xG * 100, 2);
  if (!T) h = '<p>切り抜かないとき（$r = 0$）は、円板は一様なので、<b>重心は中心 O</b>（$x_G = 0$）。</p>';
  else h = '<div class="ansblk"><h4>解法②　今求める円板の質点と、切り取られた円板の質点の重心が、円板の中心 O に一致することを用いる方法</h4>' +
      '<p>まず、それぞれの質量を求める。質量は面積に比例するので（もとの円板の質量を $m$）</p>' +
      '<div class="fmlbox"><span class="tex">m_{\\text{切}} = \\left(\\dfrac{r}{R}\\right)^2 m = ' + T.mc + ',\\qquad m_{\\text{残}} = m - m_{\\text{切}} = ' + T.mr + '</span></div>' +
      '<p>残りの部分の質点（$x = x_G$）と、切り取られた円板の質点（$x = R - r = ' + T.d + '$）を合わせると、もとの円板になる。その重心は中心 O（$x = 0$）だから</p>' +
      '<div class="fmlbox"><span class="tex">\\dfrac{m_{\\text{残}}\\, x_G + m_{\\text{切}}\\,(R - r)}{m_{\\text{残}} + m_{\\text{切}}} = 0 \\quad\\Longrightarrow\\quad x_G = -\\dfrac{m_{\\text{切}}}{m_{\\text{残}}}(R - r) = -' + T.q + ' \\times ' + T.d + ' = -' + T.xg + '</span></div>' +
      '<p>重心は <b>O の左 $' + T.xg + '$</b>。</p></div>' +
      '<div class="ansblk"><h4>解法③　円板の中心 O のまわりで、今求める円板の質点にはたらく重力と、切り取られた円板の質点にはたらく重力のモーメントが一致することを用いる方法</h4>' +
      '<p class="mini">（それぞれの質量の求め方は解法②と同じなので省略）</p>' +
      '<p>O を支点とする天秤と考える。O の左 $|x_G|$ に $m_{\\text{残}}$、右 $R - r$ に $m_{\\text{切}}$ があって、O のまわりのモーメントがつりあう（一致する）から</p>' +
      '<div class="fmlbox"><span class="tex">m_{\\text{残}}\\, g \\cdot |x_G| = m_{\\text{切}}\\, g \\cdot (R - r) \\quad\\Longrightarrow\\quad |x_G| = \\dfrac{m_{\\text{切}}}{m_{\\text{残}}}(R - r) = ' + T.q + ' \\times ' + T.d + ' = ' + T.xg + '</span></div>' +
      '<p>重心は <b>O の左 $' + T.xg + '$</b>。' + (sh.inHole ? '（この重心は<b>穴の中</b>にある。）' : '') + '</p></div>';
  if (el._h === h) return;
  el._h = h; el.innerHTML = mathHtml(h); renderMath(el);
}

/* ＜図＞ もとの図（上から見た板） ⇒ 質点におきかえた図 */
/* 図の右上の式（TeX）→ 改行 →「= 値」 */
function pmTex(kind, sh) {
  var el = document.getElementById('m3pmtex'); if (!el) return;
  function tr(v) { return String(+v.toFixed(2)); }        /* 4.00 → 4、6.25 → 6.25 */
  var h;
  if (kind === 'sq') {
    /* まずそれぞれの質量（面積の比）→ 左の正方形の質点と右の正方形の質点の重心 */
    var ks = m3k(sh).tex, aa = tr(sh.a * 100);
    h = '<span class="pmcap">① それぞれの質量（質量は面積に比例）</span><br>' +
      '<span class="tex">m_1 : m_2 = ' + aa + '^2 : 20^2 \\quad\\Rightarrow\\quad m_2 = ' + ks + (ks ? '\\,' : '') + 'm_1</span><br>' +
      '<span class="pmcap">② 左の正方形の質点と右の正方形の質点の重心</span><br>' +
      '<span class="tex">x_G = \\dfrac{m_1 x_1 + m_2 x_2}{m_1 + m_2} = \\dfrac{m_1 \\times ' + tr(sh.x1 * 100) + ' + ' + ks + 'm_1 \\times ' + tr(sh.x2 * 100) + '}{m_1 + ' + ks + 'm_1}</span><br>= ' + fmt(sh.xG * 100, 1) + ' cm';
  } else {
    /* ① 切り抜いた円板を負の質量とする方法（R … 円板の半径、r … 切り抜く円板の半径） */
    var T = HOLE_TXT[sh.kq];
    if (!T) h = '<span class="pmcap">切り抜かないとき（r = 0）</span><br>重心は中心 O（x<sub>G</sub> = 0）';
    else h = '<span class="pmcap">解法①　切り取られた円板の質量を「負の質量」とする方法</span><br>' +
      '<span class="pmcap">まず質量（面積に比例）</span>　<span class="tex">m_{\\text{切}} = \\left(\\dfrac{r}{R}\\right)^2 m = ' + T.mc + ',\\ \\ m_{\\text{残}} = ' + T.mr + '</span><br>' +
      '<span class="pmcap">穴のない円板 m（x = 0）と、負の質量 −m<sub>切</sub>（x = R − r）の重心</span><br>' +
      '<span class="tex">x_G = \\dfrac{m \\cdot 0 + (-m_{\\text{切}})(R - r)}{m + (-m_{\\text{切}})} = -\\dfrac{m_{\\text{切}}}{m_{\\text{残}}}(R - r) = -' + T.q + ' \\times ' + T.d + ' = -' + T.xg + '</span><br>' +
      '（O の左 ' + T.xgp + '）';
  }
  if (el._h === h) return;
  el._h = h; el.innerHTML = h; renderMath(el);
}
/* 横の寸法線（↔ と文字） */
function dimH(ctx, x1, x2, y, text, col) {
  if (Math.abs(x2 - x1) < 4) return;
  var m = (x1 + x2) / 2;
  arrow(ctx, m, y, x1, y, 'dim', 1); arrow(ctx, m, y, x2, y, 'dim', 1);
  ctx.save(); ctx.strokeStyle = 'rgba(27,31,36,.45)'; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(x1, y - 6); ctx.lineTo(x1, y + 6); ctx.moveTo(x2, y - 6); ctx.lineTo(x2, y + 6); ctx.stroke(); ctx.restore();
  if (text) label(ctx, text, m, y - 11, { size: 12.5, bold: true, color: col || '#1b1f24' });
}
function drawPointMassFig(cv, kind, sh) {
  pmTex(kind, sh);
  var W = 760, H = kind === 'sq' ? 380 : 450, ctx = prep(cv, W, H);   /* 穴あき円板は右上の解答が長いので、図を下げる */
  var i;
  /* 左：上から見た板 */
  var LS = kind === 'sq' ? 190 / (sh.a + sh.B) * 1.0 : 250 / (2 * sh.R);
  var lx0 = kind === 'sq' ? 40 : 170, ly = kind === 'sq' ? 140 : 205;
  function L(x, y) { return { x: lx0 + (kind === 'sq' ? x : x) * LS, y: ly - y * LS }; }
  NO_SHIFT = true;
  if (kind === 'sq') {
    var p;
    ctx.save();
    ctx.fillStyle = '#ffd9a8'; ctx.strokeStyle = '#8a5a2b'; ctx.lineWidth = 1.6;
    p = L(0, sh.a / 2); ctx.beginPath(); ctx.rect(p.x, p.y, sh.a * LS, sh.a * LS); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#b9dcf5'; ctx.strokeStyle = '#1f4f86';
    p = L(sh.a, sh.B / 2); ctx.beginPath(); ctx.rect(p.x, p.y, sh.B * LS, sh.B * LS); ctx.fill(); ctx.stroke();
    ctx.restore();
    dotLine(ctx, L(-0.02, 0).x, ly, L(sh.a + sh.B + 0.03, 0).x, ly, 'rgba(27,31,36,.55)', 1.2, [5, 4]);
    ball3d(ctx, L(sh.x1, 0).x, ly, 6, '#ffb45e', '#8a5a2b');
    ball3d(ctx, L(sh.x2, 0).x, ly, 9, '#6fb1e8', '#1f4f86');
    actPoint(ctx, L(0, 0).x, ly, '#1b1f24'); label(ctx, 'O', L(0, 0).x - 14, ly, { size: 14, bold: true });
    label(ctx, 'm_1', L(sh.x1, 0).x, ly - 18, { size: 14, bold: true, color: '#8a5a2b' });
    label(ctx, 'm_2', L(sh.x2, 0).x, ly - 20, { size: 14, bold: true, color: '#1f4f86' });
    dimH(ctx, L(0, 0).x, L(sh.a, 0).x, L(0, sh.a / 2).y - 12, fmt(sh.a * 100, 0) + ' cm');
    dimH(ctx, L(sh.a, 0).x, L(sh.a + sh.B, 0).x, L(0, sh.B / 2).y - 12, '20 cm');
  } else {
    ctx.save();
    ctx.fillStyle = '#8fd3f7'; ctx.strokeStyle = '#1f6f9a'; ctx.lineWidth = 1.6;
    ctx.beginPath(); ctx.arc(lx0, ly, sh.R * LS, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#1565c0';
    ctx.beginPath(); ctx.arc(L(sh.ch, 0).x, ly, sh.rh * LS, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.restore();
    dotLine(ctx, lx0 - sh.R * LS - 8, ly, lx0 + sh.R * LS + 10, ly, 'rgba(27,31,36,.7)', 1.2, [5, 4]);
    actPoint(ctx, lx0, ly, '#1b1f24'); label(ctx, 'O', lx0 + 2, ly - 16, { size: 14, bold: true });
    ball3d(ctx, L(sh.xG, 0).x, ly, 5, '#29b6f6', '#0d5f8a');
    if (sh.rh > 0) ball3d(ctx, L(sh.ch, 0).x, ly, 5, '#6fa4e8', '#0b3c7a');
    label(ctx, 'x_G', (L(sh.xG, 0).x + lx0) / 2, ly + 18, { size: 13, bold: true });
    dimH(ctx, lx0 - sh.R * LS, lx0, ly + sh.R * LS + 18, 'R');
    if (sh.rh > 0) {
      dimH(ctx, L(sh.ch - sh.rh, 0).x, L(sh.ch + sh.rh, 0).x, ly - sh.rh * LS - 36, '直径 2r（r = ' + HOLE_TXT[sh.kq].rp + '）', '#0b3c7a');
      label(ctx, '切り抜く円板', L(sh.ch, 0).x, ly - sh.rh * LS - 12, { size: 12.5, bold: true, color: '#0b3c7a' });
    }
    /* 重力（もとの円板＝O） */
    arrow(ctx, lx0, ly, lx0, ly + 110, 'force', 1, '#1b1f24');
  }
  /* まん中の矢印 */
  var mx = kind === 'sq' ? 300 : 360;
  ctx.save(); ctx.fillStyle = '#c0141c';
  ctx.beginPath(); ctx.moveTo(mx, ly - 16); ctx.lineTo(mx + 36, ly - 16); ctx.lineTo(mx + 36, ly - 30); ctx.lineTo(mx + 66, ly);
  ctx.lineTo(mx + 36, ly + 30); ctx.lineTo(mx + 36, ly + 16); ctx.lineTo(mx, ly + 16); ctx.closePath(); ctx.fill(); ctx.restore();
  /* 右：質点におきかえた図 */
  var rx0 = kind === 'sq' ? 430 : 520, RS = kind === 'sq' ? 250 / (sh.a + sh.B) : 190 / sh.R;
  function Rp(x) { return rx0 + x * RS; }
  var yb = ly;
  ctx.save(); ctx.fillStyle = '#fbe7d0'; ctx.strokeStyle = '#6b4a2e'; ctx.lineWidth = 1;
  ctx.restore();
  if (kind === 'sq') {
    ctx.save(); ctx.strokeStyle = '#8a5a2b'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(Rp(sh.x1), yb); ctx.lineTo(Rp(sh.x2), yb); ctx.stroke(); ctx.restore();
    var r1 = 7 + 5 * Math.sqrt(sh.m1 / sh.m2), r2 = 12;
    arrow(ctx, Rp(sh.x1), yb, Rp(sh.x1), yb + 30 + 60 * sh.m1 / (sh.m1 + sh.m2), 'force', 0.9, COL.force);
    arrow(ctx, Rp(sh.x2), yb, Rp(sh.x2), yb + 30 + 60 * sh.m2 / (sh.m1 + sh.m2), 'force', 0.9, COL.force);
    ball3d(ctx, Rp(sh.x1), yb, r1, '#ffb45e', '#8a5a2b');
    ball3d(ctx, Rp(sh.x2), yb, r2, '#6fb1e8', '#1f4f86');
    label(ctx, 'm_1', Rp(sh.x1), yb - r1 - 12, { size: 14, bold: true, color: '#8a5a2b' });
    label(ctx, 'm_2 = ' + m3k(sh).txt + (m3k(sh).p > 1 ? ' ' : '') + 'm_1', Rp(sh.x2) + r2 + 8, yb - r2 - 6, { size: 14, bold: true, color: '#1f4f86', align: 'left' });   /* 球の右上（右上の式とかさならない） */
    /* 支点（重心） */
    var gx = Rp(sh.xG);
    var gt = Math.abs(gx - Rp(sh.x2)) < r2 + 9 ? yb + r2 + 1 : yb + 3;    /* a が小さく G が球に近いときは、球の下に */
    ctx.save(); ctx.fillStyle = '#e07b18'; ctx.beginPath(); ctx.moveTo(gx, gt); ctx.lineTo(gx - 9, gt + 15); ctx.lineTo(gx + 9, gt + 15); ctx.closePath(); ctx.fill(); ctx.restore();
    label(ctx, 'G', gx - (gt > yb + 3 ? 14 : 0), gt + 27, { size: 14, bold: true, color: '#a85c0c' });
    /* x 軸と距離 */
    var ay = yb + 104;
    ctx.save(); ctx.strokeStyle = '#1b1f24'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(Rp(0) - 10, ay); ctx.lineTo(Rp(sh.a + sh.B) + 20, ay); ctx.stroke(); ctx.restore();
    var cl2 = Rp(sh.x2) - Rp(sh.xG) < 28;                  /* x_G と x_2 が近いときは文字を左右にずらす */
    [[0, 'O', 0], [sh.x1, 'x_1', 0], [sh.xG, 'x_G', cl2 ? -11 : 0], [sh.x2, 'x_2', cl2 ? 10 : 0]].forEach(function (q) {
      ctx.save(); ctx.strokeStyle = '#1b1f24'; ctx.beginPath(); ctx.moveTo(Rp(q[0]), ay - 5); ctx.lineTo(Rp(q[0]), ay + 5); ctx.stroke(); ctx.restore();
      label(ctx, q[1], Rp(q[0]) + q[2], ay + 17, { size: 13, bold: true, color: q[1] === 'x_G' ? '#a85c0c' : '#1b1f24' });
    });
    /* O からの距離（↔ と cm） */
    dimH(ctx, Rp(0), Rp(sh.x1), ay + 44, fmt(sh.x1 * 100, 1) + ' cm');
    dimH(ctx, Rp(0), Rp(sh.xG), ay + 72, fmt(sh.xG * 100, 1) + ' cm', '#a85c0c');
    dimH(ctx, Rp(0), Rp(sh.x2), ay + 100, fmt(sh.x2 * 100, 1) + ' cm');
  } else if (sh.rh === 0) {
    label(ctx, '切り抜かないときは、重心は中心 O', rx0 + 90, yb, { size: 15, bold: true, color: '#0a5c5c' });
  } else {
    /* 3-1・3-2 と同じ形：棒でつないだ 2 つの質点、支点（O）、数直線と距離 */
    ctx.save(); ctx.strokeStyle = '#8a5a2b'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(Rp(sh.xG), yb); ctx.lineTo(Rp(sh.ch), yb); ctx.stroke(); ctx.restore();
    var ox = Rp(0);
    var kR = sh.mr / (sh.mr + sh.mh), kH = sh.mh / (sh.mr + sh.mh);
    var rR = 7 + 7 * Math.sqrt(kR), rH = 7 + 7 * Math.sqrt(kH);
    arrow(ctx, Rp(sh.xG), yb, Rp(sh.xG), yb + 20 + 70 * kR, 'force', 0.9, COL.force);
    arrow(ctx, Rp(sh.ch), yb, Rp(sh.ch), yb + 20 + 70 * kH, 'force', 0.9, COL.force);
    label(ctx, 'm_残 g', Rp(sh.xG) - 10, yb + 20 + 70 * kR - 4, { size: 13, bold: true, color: COL.force, align: 'right' });
    label(ctx, 'm_切 g', Rp(sh.ch) + 10, yb + 20 + 70 * kH - 4, { size: 13, bold: true, color: COL.force, align: 'left' });
    ball3d(ctx, Rp(sh.xG), yb, rR, '#29b6f6', '#0d5f8a');
    ball3d(ctx, Rp(sh.ch), yb, rH, '#6fa4e8', '#0b3c7a');
    label(ctx, '残り m_残', Rp(sh.xG), yb - rR - 12, { size: 13, bold: true, color: '#0d5f8a' });
    label(ctx, '切り抜く円板 m_切', Rp(sh.ch), yb - rH - 12, { size: 13, bold: true, color: '#0b3c7a' });
    /* 支点（もとの円板の重心 O） */
    ctx.save(); ctx.fillStyle = '#e07b18'; ctx.beginPath(); ctx.moveTo(ox, yb + 3); ctx.lineTo(ox - 9, yb + 18); ctx.lineTo(ox + 9, yb + 18); ctx.closePath(); ctx.fill(); ctx.restore();
    label(ctx, 'O', ox, yb + 30, { size: 14, bold: true, color: '#a85c0c' });
    /* x 軸と距離 */
    var ay = yb + 104;
    ctx.save(); ctx.strokeStyle = '#1b1f24'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(Rp(sh.xG) - 30, ay); ctx.lineTo(Rp(sh.ch) + 30, ay); ctx.stroke(); ctx.restore();
    var close = (Rp(0) - Rp(sh.xG)) < 26;                /* x_G が O に近いときは文字を左右にずらす */
    [[sh.xG, 'x_G', close ? -12 : 0], [0, 'O', close ? 8 : 0], [sh.ch, 'R − r', 0]].forEach(function (q) {
      ctx.save(); ctx.strokeStyle = '#1b1f24'; ctx.beginPath(); ctx.moveTo(Rp(q[0]), ay - 5); ctx.lineTo(Rp(q[0]), ay + 5); ctx.stroke(); ctx.restore();
      label(ctx, q[1], Rp(q[0]) + q[2], ay + 17, { size: 13, bold: true, color: q[1] === 'x_G' ? '#a85c0c' : '#1b1f24' });
    });
    dimH(ctx, Rp(sh.xG), ox, ay + 46, HOLE_TXT[sh.kq].xgp, '#a85c0c');
    dimH(ctx, ox, Rp(sh.ch), ay + 74, HOLE_TXT[sh.kq].dp);
    label(ctx, 'm_切 : m_残 = r² : (R² − r²) = ' + ratioStr(sh.mh, sh.mr), (Rp(sh.xG) + Rp(sh.ch)) / 2, ay + 100, { size: 12.5, bold: true, color: '#3d4c5a' });
  }
  NO_SHIFT = false;
  if (kind !== 'sq') label(ctx, 'x 軸の原点は円板の中心 O（右向きが正）', 14, 20, { size: 14, bold: true, color: '#1f3b57', align: 'left' });
  label(ctx, kind === 'sq' ? 'それぞれの正方形を、中心に全質量が集まった「質点」とみなす！' : '残りの部分と切り抜く円板それぞれを、重心に全質量が集まった「質点」とみなす！',
    W / 2, H - 14, { size: 13.5, bold: true, color: '#3d4c5a' });
}

