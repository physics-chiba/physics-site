/* ===== 30_physics.js ===== */
/* 純粋な物理計算だけ（描画を混ぜない）。同じ入力 → 同じ出力。
   ─ どの P.xx がどのタブか ─
     P.box   … 箱の寸法（全タブ共通。1 マス = 0.04 m）
     P.tilt  … r1・r2（板を θ 傾ける）
     P.pull  … r3（床の上の箱を F′ で引く）                                     */
'use strict';
var G = 9.8;
var DEG = Math.PI / 180;

function clamp(x, a, b) { return x < a ? a : (x > b ? b : x); }
function fmt(x, d) {
  if (d === undefined) d = 1;
  var s = x.toFixed(d);
  if (s === '-' + (0).toFixed(d)) s = (0).toFixed(d);   /* −0.0 を出さない */
  return s;
}

var P = {};

/* ===== 箱の寸法 =====
   1 マス = 0.04 m。a:b = 3:4 が 0.12 m × 0.16 m（＝教科書の問題の設定）。 */
P.box = {
  CELL: 0.04,                     /* [m] 1 マス */
  M: 1.0,                         /* [kg] 箱の質量（どの箱も同じにしておく） */
  DEPTH: 0.16,                    /* [m] 奥行き（絵のためだけ。物理には効かない） */
  KEYS: ['1:16', '2:8', '3:4', '4:4', '8:2', '16:1'],   /* 左ほど細長く、右ほど平たい（面積はどれも 16 マス） */
  /* 'a:b' → { na, nb, a, b }（na・nb はマス数、a・b は m） */
  dims: function (key) {
    var p = String(key).split(':');
    var na = +p[0], nb = +p[1];
    return { key: key, na: na, nb: nb, a: na * P.box.CELL, b: nb * P.box.CELL };
  },
  isProblem: function (key) { return key === '3:4'; }
};

/* ===== r1・r2：板を θ だけ傾ける =====
   板の左端が蝶つがい。箱の「下側（左）の角」が回転軸。
   ・傾く（回転する）条件 … tanθ ≧ a/b   → θ₀ = arctan(a/b)
   ・すべる条件         … tanθ ≧ μ     → θ_s = arctan μ
   先に起こるほうが実際に起こる。 */
P.tilt = {
  th0: function (a, b) { return Math.atan2(a, b) / DEG; },            /* [°] 傾く角 */
  thSlip: function (mu) { return Math.atan(mu) / DEG; },             /* [°] すべる角 */
  /* 抗力（垂直抗力＋摩擦力）の作用点。回転軸（下側の角）から斜面にそって測った距離 [m]。
     3 力ではなく 2 力（重力と抗力）のつり合いなので、抗力は重力の作用線が
     接触面と交わる点にはたらく：  s = a/2 − (b/2) tanθ  */
  contact: function (a, b, thDeg) {
    var s = a / 2 - (b / 2) * Math.tan(thDeg * DEG);
    return s < 0 ? 0 : s;
  },
  /* 判定。pinned=true（r1）はすべりを考えない。 */
  state: function (a, b, mu, thDeg, pinned) {
    var th0 = P.tilt.th0(a, b), ths = P.tilt.thSlip(mu);
    var tipAt = thDeg >= th0 - 1e-9;
    var slipAt = !pinned && thDeg >= ths - 1e-9;
    var first = null;                                  /* 実際に起こること */
    if (pinned) first = tipAt ? 'tip' : null;
    else if (tipAt || slipAt) first = (ths < th0 - 1e-9) ? 'slip' : 'tip';
    return { th0: th0, thSlip: ths, tip: first === 'tip', slip: first === 'slip', first: first,
      slipFirst: !pinned && ths < th0 - 1e-9 };
  },
  /* 傾いたあとの見た目の回転角 [°]（θ₀ を超えた分だけ倒れていき、最大 40°） */
  tipAngle: function (thDeg, th0) {
    return clamp((thDeg - th0) / 8, 0, 1) * 40;
  },
  /* 力の大きさ [N]（つり合っているとき） */
  forces: function (m, thDeg) {
    var mg = m * G, th = thDeg * DEG;
    return { mg: mg, N: mg * Math.cos(th), f: mg * Math.sin(th), R: mg };
  }
};

/* ===== r3：床の上の箱を、高さ b′ の点で水平に F′ で引く =====
   ・傾く条件 … F′·b′ ≧ mg·a/2  → F′₀ = mg·a/(2b′)
   ・すべる条件 … F′ ≧ μmg       → F′_s = μmg  */
P.pull = {
  F0: function (m, a, bp) { return m * G * a / (2 * bp); },
  Fslip: function (m, mu) { return mu * m * G; },
  /* 抗力の作用点：引く側（左）の下の角から測った距離 [m]。 x = a/2 − F′b′/(mg) */
  contact: function (m, a, F, bp) {
    var x = a / 2 - F * bp / (m * G);
    return x < 0 ? 0 : x;
  },
  state: function (m, a, mu, F, bp) {
    var F0 = P.pull.F0(m, a, bp), Fs = P.pull.Fslip(m, mu);
    var tipAt = F >= F0 - 1e-9, slipAt = F >= Fs - 1e-9;
    var first = null;
    if (tipAt || slipAt) first = (Fs < F0 - 1e-9) ? 'slip' : 'tip';
    return { F0: F0, Fslip: Fs, tip: first === 'tip', slip: first === 'slip', first: first,
      slipFirst: Fs < F0 - 1e-9 };
  },
  tipAngle: function (F, F0) { return clamp((F - F0) / 2.0, 0, 1) * 40; },
  forces: function (m, F) { return { mg: m * G, N: m * G, f: F, R: Math.hypot(m * G, F) }; }
};

