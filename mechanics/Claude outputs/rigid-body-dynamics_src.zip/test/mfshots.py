from playwright.sync_api import sync_playwright
from PIL import Image
import sys
errs=[]
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1440,'height':1000})
    pg.on('pageerror',lambda e:errs.append(str(e)))
    for sid,h,keys,ths in [('m2s2','2-2',['W','TA','TB','NA'],[30,15,45]),('m2s3','2-3',['W','N1','N2','f'],[80,45,20])]:
        pg.goto('file:///home/claude/rotbox/dist/publish/rigid-body-dynamics.html#'+h); pg.wait_for_timeout(800)
        tiles=[]
        for th in ths:
            pg.evaluate(f"TEST.set('th',{th})"); pg.wait_for_timeout(100)
            for ax in ['A','G','B']:
                pg.click(f'#simhost [data-mfax="{ax}"]')
                for k in keys:
                    pg.evaluate(f"var m=st.sims.{sid}._mf; m.k='{k}'; m.mult={{}}; m.t=0; m.axT=-1e9; mfSync(st.sims.{sid},'{sid}'); renderActive()")
                    fn=f'work/mf_{h}_{th}_{ax}_{k}.png'; pg.query_selector('#sideCv').screenshot(path=fn); tiles.append(fn)
        ims=[Image.open(f) for f in tiles]; w,hh=ims[0].size; cols=12
        sheet=Image.new('RGB',(w*cols//2, hh*((len(ims)+cols-1)//cols)//2),'white')
        for i,im in enumerate(ims): sheet.paste(im.resize((w//2,hh//2)),((i%cols)*w//2,(i//cols)*hh//2))
        sheet.save(f'work/sheet_{h}.png')
    b.close()
print(errs)
