from playwright.sync_api import sync_playwright
B='file:///home/claude/rotbox/dist/publish/rigid-body-dynamics.html'
JS=r"""(()=>{var host=document.getElementById('simhost'),out=[];
host.querySelectorAll('.guide,.cvnote,.cvsub,.cvsub p,.playnote,.sidehtml,.discnote,.dcard p,.bcard > p,.mini,.gnote,.areattl,.cvtitle,.simtitle').forEach(function(e){
 if(!e.offsetParent) return; var t=e.innerText.trim(); if(!t) return;
 var lh=parseFloat(getComputedStyle(e).lineHeight)||20; var lines=Math.round(e.getBoundingClientRect().height/lh);
 out.push([e.className.split(' ')[0], lines, t.replace(/\n/g,' / ').slice(0,400)]);});return out})()"""
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1440,'height':900}); pg.goto(B); pg.wait_for_timeout(600)
    ids=pg.evaluate("MODES.flatMap(m=>m.ids.filter(i=>DEFS[i]))")
    for id in ids:
        pg.evaluate(f"gotoSim('{id}')"); pg.wait_for_timeout(150)
        print('=====',id)
        for c,l,t in pg.evaluate(JS): print(f'  [{c}] {l}行: {t}')
    b.close()
