import json,sys
from playwright.sync_api import sync_playwright
B='file:///home/claude/rotbox/dist/publish/rigid-body-dynamics.html'
COLLECT=r"""(()=>{window.__fu=window.__fu||{};var roots=[document];
 document.querySelectorAll('.secfz').forEach(f=>roots.push(f.shadowRoot));
 roots.forEach(R=>{var w=document.createTreeWalker(R,NodeFilter.SHOW_TEXT);var n;
 while(n=w.nextNode()){var e=n.parentElement;if(!e||!e.closest('.katex'))continue;var cs=getComputedStyle(e);
  var fam=cs.fontFamily.split(',')[0].replace(/["']/g,'').trim();var key=fam+'|'+cs.fontWeight+'|'+cs.fontStyle;
  var s=window.__fu[key]||'';for(var ch of n.data){if(s.indexOf(ch)<0)s+=ch}window.__fu[key]=s;}});
 return Object.keys(window.__fu).length})()"""
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1440,'height':900}); pg.goto(B); pg.wait_for_timeout(700)
    ids=pg.evaluate("MODES.flatMap(m=>m.ids.filter(i=>DEFS[i]))")
    pg.evaluate("document.getElementById('bToc').click()"); pg.evaluate(COLLECT)
    for id in ids:
        pg.evaluate(f"gotoSim('{id}')"); pg.wait_for_timeout(150)
        for rnd in range(3):
            pg.evaluate("document.querySelectorAll('#simhost [data-open],#simhost [data-dans]').forEach(e=>e.click())")
            pg.evaluate("document.querySelectorAll('#simhost [data-vis]').forEach(e=>e.click())")
            pg.evaluate("document.querySelectorAll('#simhost [data-ab],#simhost [data-bp],#simhost [data-pre],#simhost [data-act]').forEach((e,i)=>{if(i%2==RND%2)e.click()})".replace("RND",str(rnd)))
            pg.evaluate("document.querySelectorAll('#simhost [data-var]').forEach(e=>{for(var k=0;k<3;k++)e.click()})")
            b2=pg.query_selector('#bPlay')
            if b2: pg.evaluate("var q=document.getElementById('bPlay'); if(q) q.click()"); pg.wait_for_timeout(700)
            pg.evaluate(COLLECT)
    fu=pg.evaluate("window.__fu")
    b.close()
for k,v in sorted(fu.items()): print(k, ''.join(sorted(v)))
json.dump(fu,open(sys.argv[1],'w'),ensure_ascii=False)
