from playwright.sync_api import sync_playwright
B='file:///home/claude/rotbox/dist/publish/rigid-body-dynamics.html'
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    for vw in [(1440,900),(1024,768),(390,844),(844,390)]:
        pg=b.new_page(viewport={'width':vw[0],'height':vw[1]}); pg.on('pageerror',lambda e:errs.append(str(vw)+str(e)))
        pg.goto(B); pg.wait_for_timeout(600)
        ids=pg.evaluate("MODES.flatMap(m=>m.ids.filter(i=>DEFS[i]))")
        for id in ids:
            pg.evaluate(f"gotoSim('{id}');scrollToSub(1)"); pg.wait_for_timeout(150)
            pg.evaluate("var b=document.getElementById('bPlay'); if(b) b.click()"); pg.wait_for_timeout(250)
            pg.evaluate("document.querySelectorAll('#simhost [data-vis]').forEach(e=>e.click())"); pg.wait_for_timeout(80)
            pg.evaluate("document.querySelectorAll('#simhost [data-open]').forEach(e=>e.click())"); pg.wait_for_timeout(80)
            lo=pg.evaluate("TEST.labelOverlap().length")
            sw=pg.evaluate("document.documentElement.scrollWidth")
            if sw>vw[0]: print('overflow',vw,id,sw)
        # scroll whole page in steps
        for y in range(0,pg.evaluate("document.body.scrollHeight"),400):
            pg.evaluate(f"scrollTo(0,{y})"); pg.wait_for_timeout(30)
        pg.close()
    print('errs',errs[:10])
    b.close()
