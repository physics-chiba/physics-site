import sys,json
from playwright.sync_api import sync_playwright
F='file:///home/claude/rotbox/dist/publish/'+(sys.argv[1] if len(sys.argv)>1 else 'rigid-body-dynamics.html')
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1440,'height':900})
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('console',lambda m: errs.append(m.text) if m.type=='error' else None)
    pg.goto(F); pg.wait_for_timeout(800)
    print('cur',pg.evaluate('st.cur'),'arts',pg.evaluate("[...document.querySelectorAll('#secstack .secbox')].map(a=>a.dataset.sim+':'+Math.round(a.getBoundingClientRect().height))"))
    print('simhost count',pg.evaluate("document.querySelectorAll('#simhost').length"),'mainCv',pg.evaluate("document.querySelectorAll('#mainCv').length"))
    # mode build time
    for m in ['m2s1','m3s2','r1','st1','m5s1','m1s1']:
        t=pg.evaluate("(id)=>{var t=performance.now();gotoSim(id);return performance.now()-t}",m)
        print('goto',m,round(t),'ms arts',pg.evaluate("document.querySelectorAll('#secstack .secbox').length"))
    pg.evaluate("window.scrollTo(0,0)"); pg.wait_for_timeout(200)
    # scroll through mode 1 / 2
    pg.evaluate("gotoSim('m2s1')"); pg.wait_for_timeout(900)
    for y in range(0,9000,700):
        pg.evaluate(f"window.scrollTo(0,{y})"); pg.wait_for_timeout(120)
        print(y, pg.evaluate("st.cur"), pg.evaluate("location.hash"), pg.evaluate("Math.round(scrollY)"))
    pg.screenshot(path='test/s_m2.png',full_page=True)
    print('errs',errs[:10])
    b.close()
