from playwright.sync_api import sync_playwright
from PIL import Image, ImageChops
EX=[r'M = Fl',r'\sum \vec{F} = \vec{0},\ \sum M = 0',r'x_G = \dfrac{m_1x_1 + m_2x_2}{m_1 + m_2}',r'\tan\theta_0 = a/b,\ \tan\theta_s=\mu',r'F_0 = \dfrac{mga}{2b\prime}',r'mg \times 60\ \text{cm} \neq 3mg \times 20\ \text{cm}',r'\Longrightarrow \Rightarrow \cdot \cdots 30^\circ \leqq \geqq',r'\sqrt{\dfrac{g}{L}}\ \left(\dfrac{a}{b}\right) \tfrac{1}{2}',r'm = 1.0\ \mathrm{kg}\quad 9.8\ \mathrm{N}',r'T_A,\ N_B,\ f \le \mu N_2',r'\theta\mu\alpha\omega\pi ABCxyz 0123456789']
def shot(f,out):
    with sync_playwright() as p:
        b=p.chromium.launch(); pg=b.new_page(viewport={'width':900,'height':700}); pg.goto('file://'+f); pg.wait_for_timeout(500)
        pg.evaluate("""(ex)=>{document.body.innerHTML='<div id=t style="background:#fff;padding:10px;font-size:22px"></div>';var t=document.getElementById('t');ex.forEach(e=>{var d=document.createElement('div');t.appendChild(d);katex.render(e,d)});}""",EX)
        pg.evaluate("document.fonts.ready"); pg.wait_for_timeout(500)
        pg.locator('#t').screenshot(path=out); b.close()
shot('/home/claude/rotbox/ref/rigid-body-dynamics.html','work/f_old.png')
shot('/home/claude/rotbox/dist/publish/rigid-body-dynamics.html','work/f_new.png')
a=Image.open('work/f_old.png').convert('RGB'); b=Image.open('work/f_new.png').convert('RGB')
print(a.size,b.size, ImageChops.difference(a,b).getbbox())
