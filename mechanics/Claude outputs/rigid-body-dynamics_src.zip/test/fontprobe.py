import json,sys
from playwright.sync_api import sync_playwright
B='file:///home/claude/rotbox/dist/publish/rigid-body-dynamics.html'
asc=''.join(chr(c) for c in range(0x21,0x7f)).replace('\\','').replace('$','').replace('%','').replace('#','').replace('&','').replace('{','').replace('}','').replace('^','').replace('_','').replace('~','')
greek='αβγδεζηθικλμνξοπρστυφχψωΓΔΘΛΞΠΣΥΦΨΩ'
cmds=['\\Longrightarrow','\\Rightarrow','\\cdot','\\cdots','\\circ','\\cos x','\\sin x','\\tan x','\\dfrac{a}{b}','\\tfrac{a}{b}','\\geqq','\\leqq','\\neq','\\mu','\\theta','\\times','\\prime',"x'",'b\\prime','\\quad','\\qquad','\\sqrt{x}','\\sqrt{\\dfrac{a}{b}}','\\sum M','\\vec{F}','\\vec{0}','\\left(\\dfrac{a}{b}\\right)','\\left(x\\right)','\\left[\\dfrac{a}{b}\\right]','\\left|\\dfrac{a}{b}\\right|','x^{2}','x_{G}','\\theta_0','-1','\\ ','\\,',
 '\\mathrm{'+asc+'}','\\text{'+asc+'}', asc, greek, '\\mathrm{'+greek+'}','\\text{'+greek+'}','°','−','·','×','…','≦','≧','≠','→','⇒','∑']
JS=r"""(probes)=>{var fu={};var d=document.createElement('div');document.body.appendChild(d);
probes.forEach(function(p){[false,true].forEach(function(disp){d.innerHTML='';try{katex.render(p,d,{throwOnError:false,displayMode:disp})}catch(e){}
 var w=document.createTreeWalker(d,NodeFilter.SHOW_TEXT),n;while(n=w.nextNode()){var e=n.parentElement;var cs=getComputedStyle(e);
 var fam=cs.fontFamily.split(',')[0].replace(/["']/g,'').trim();var key=fam+'|'+cs.fontWeight+'|'+cs.fontStyle;var s=fu[key]||'';for(var ch of n.data){if(s.indexOf(ch)<0)s+=ch}fu[key]=s;}})});
 d.remove();return fu}"""
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(); pg.goto(B); pg.wait_for_timeout(500)
    fu=pg.evaluate(JS,cmds); b.close()
old=json.load(open('work/fontuse.json',encoding='utf-8'))
for k,v in old.items():
    fu[k]=''.join(sorted(set(fu.get(k,''))|set(v)))
for k,v in sorted(fu.items()): print(k,len(v),''.join(sorted(v))[:200])
json.dump(fu,open('work/fontneed.json','w'),ensure_ascii=False)
