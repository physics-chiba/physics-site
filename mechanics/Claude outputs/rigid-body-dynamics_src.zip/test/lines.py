import sys,json
from playwright.sync_api import sync_playwright
B='file:///home/claude/rotbox/dist/publish/rigid-body-dynamics.html'
JS=r"""(()=>{var host=document.getElementById('simhost'),out=[];
function lines(e){var lh=parseFloat(getComputedStyle(e).lineHeight)||20;var cs=getComputedStyle(e);var h=e.getBoundingClientRect().height-parseFloat(cs.paddingTop)-parseFloat(cs.paddingBottom);return Math.max(1,Math.round(h/lh-0.15))}
host.querySelectorAll('p.cvsub, .cvsub.split2 > p, .bcard[id^=m1card] > p, .st2pcard .cvsub p').forEach(function(e){
 if(!e.offsetParent) return; if(e.closest('.bcard') && !e.closest('.st2pcard') && !e.closest('[id^=m1card]')) return;
 out.push([lines(e), e.innerText.trim().replace(/\s+/g,' ').slice(0,60)]);});return out})()"""
out={}
with sync_playwright() as p:
    b=p.chromium.launch()
    for w in [1440,1024]:
        pg=b.new_page(viewport={'width':w,'height':900}); pg.goto(B); pg.wait_for_timeout(600)
        ids=pg.evaluate("MODES.flatMap(m=>m.ids.filter(i=>DEFS[i]))")
        for id in ids:
            pg.evaluate(f"gotoSim('{id}')"); pg.wait_for_timeout(120)
            for l,t in pg.evaluate(JS): out.setdefault(id+'|'+t[:20],{})[w]=l
        pg.close()
    b.close()
for k,v in out.items(): print(v.get(1440),v.get(1024),k)
json.dump(out,open(sys.argv[1],'w'),ensure_ascii=False)
