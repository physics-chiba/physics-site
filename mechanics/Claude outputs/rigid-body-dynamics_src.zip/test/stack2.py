from playwright.sync_api import sync_playwright
B='file:///home/claude/rotbox/dist/publish/'
with sync_playwright() as p:
    b=p.chromium.launch()
    errs=[]
    def page(url,w=1440,h=900):
        pg=b.new_page(viewport={'width':w,'height':h}); pg.on('pageerror',lambda e:errs.append(url+' '+str(e)))
        pg.goto(url); pg.wait_for_timeout(700); return pg
    # heights live vs frozen
    pg=page(B+'rigid-body-dynamics.html#2-1')
    H=lambda: pg.evaluate("[...document.querySelectorAll('.secbox')].map(a=>Math.round(a.getBoundingClientRect().height))")
    h1=H(); 
    for id in ['m2s2','m2s3','m2s1']:
        pg.evaluate(f"stkActivate('{id}')"); print(id,H())
    print('first',h1)
    # hash routes
    for hs in ['#4-2','#r2','#1-2-3','#m3s3','#2-3','#6-1']:
        pg2=page(B+'rigid-body-dynamics.html'+hs)
        top=pg2.evaluate("(()=>{var e=document.getElementById('simhost');return Math.round(e.getBoundingClientRect().top)})()")
        c3=pg2.evaluate("(()=>{var e=document.getElementById('m1card3');return e?Math.round(e.getBoundingClientRect().top):null})()")
        print(hs,pg2.evaluate('st.cur'),pg2.evaluate('location.hash'),'simhostTop',top,'card3',c3,'tabbarH',pg2.evaluate("Math.round(document.getElementById('tabbar').getBoundingClientRect().height)"))
        pg2.close()
    # click forward on frozen section: 2-3 frozen, click its 'すべて最初の設定に戻す'? click bPlay inside frozen 2-3
    pg.evaluate("gotoSim('m2s1')"); pg.wait_for_timeout(800)
    # find frozen 2-3 bPlay position via shadow
    pos=pg.evaluate("""(()=>{var fz=document.querySelector('#sec_m2s3 .secfz');var b=fz.shadowRoot.querySelector('#bPlay');b.scrollIntoView({block:'center'});var r=b.getBoundingClientRect();return [r.x+r.width/2,r.y+r.height/2]})()""")
    pg.wait_for_timeout(50)
    print('before',pg.evaluate('st.cur'))
    pg.mouse.click(pos[0],pos[1]); pg.wait_for_timeout(300)
    print('after',pg.evaluate('st.cur'),pg.evaluate("document.getElementById('bPlay').textContent"),pg.evaluate("st.sims.m2s3.playing"))
    # scroll so 2-1 at focus... check seclinks on
    print('seclinks on',pg.evaluate("[...document.querySelectorAll('#seclinks a.on')].map(a=>a.textContent)"))
    # m4 page
    pg3=page(B+'rotation-box_tip-or-slip.html')
    print('m4',pg3.evaluate("[...document.querySelectorAll('.secbox')].map(a=>a.dataset.sim)"),pg3.evaluate('st.cur'),pg3.evaluate("document.querySelectorAll('#modetabs .tab').length"))
    # mobile
    pg4=page(B+'rigid-body-dynamics.html#1-2',390,844)
    print('mobile',pg4.evaluate('st.cur'),pg4.evaluate("document.documentElement.scrollWidth"))
    pg4.screenshot(path='test/mob.png')
    print('errs',errs)
    b.close()
