import re,json
L=open('ref/rigid-body-dynamics.html',encoding='utf-8').read().split('\n')
starts=[(1,'00_head.html'),(17,'10_style.css'),(1085,'11_glue.html'),(1087,'12_overlay.css'),(1303,'12_glue.html'),(1305,'13_design.css'),(1634,'20_body.html'),(1714,'21_katex.html')]
for i,l in enumerate(L,1):
    m=re.match(r'^/\* ===== (\d\d_[a-z0-9_]+\.js) =====',l)
    if m: starts.append((i,m.group(1)))
starts.append((10371,'95_footer.html'))
man=[]
for k,(s,n) in enumerate(starts):
    e=starts[k+1][0]-1 if k+1<len(starts) else len(L)
    open('src/'+n,'w',encoding='utf-8').write('\n'.join(L[s-1:e])+('\n' if k+1<len(starts) else ''))
    man.append(n)
json.dump(man,open('src/manifest.json','w'),indent=0)
print(man)
