/* =========================================================================
   モード④ 熱サイクルと熱機関（4-1・4-2）、モード⑤ カルノーサイクル（5-1）
   ========================================================================= */
/* サイクルの定義。単位：p ×10⁵ Pa、V ×10⁻² m³（pV は ×10³ J）、単原子分子 1 mol */
var CYC = {
  rect:{ name:"長方形のサイクル", pts:{A:[2,1],B:[2,2],C:[4,2],D:[4,1]},
    seg:[{f:"A",t:"B",k:"V",nm:"定積加圧"},{f:"B",t:"C",k:"P",nm:"定圧膨張"},{f:"C",t:"D",k:"V",nm:"定積減圧"},{f:"D",t:"A",k:"P",nm:"定圧圧縮"}] },
  carnot:(function(){ var g=5/3, TH=500, TL=300, VA=1.0, VB=2.0, r=Math.pow(TH/TL,1/(g-1)), VC=VB*r, VD=VA*r, k=RGAS/1e3;
    return { name:"カルノーサイクル", TH:TH, TL:TL, pts:{A:[VA,k*TH/VA],B:[VB,k*TH/VB],C:[VC,k*TL/VC],D:[VD,k*TL/VD]},
      seg:[{f:"A",t:"B",k:"T",nm:"等温膨張",Tc:TH},{f:"B",t:"C",k:"A",nm:"断熱膨張"},{f:"C",t:"D",k:"T",nm:"等温圧縮",Tc:TL},{f:"D",t:"A",k:"A",nm:"断熱圧縮"}] }; })()
};
/* 区間 s の途中（u）の [V, p] と、そこまでのエネルギー [Q, W_した, ΔU]（×10³ J） */
function cycSt(C, s, u){ var a=C.pts[s.f], b=C.pts[s.t], g=5/3, V, p;
  if(s.k==="V"){ V=a[0]; p=a[1]+(b[1]-a[1])*u; }
  else { V=a[0]+(b[0]-a[0])*u; p=(s.k==="P")? a[1] : (s.k==="T")? a[0]*a[1]/V : a[1]*Math.pow(a[0]/V,g); }
  var A=a[0]*a[1], Ws=(s.k==="V")? 0 : (s.k==="P")? a[1]*(V-a[0]) : (s.k==="T")? A*Math.log(V/a[0]) : (A-p*V)/(g-1), dU=1.5*(p*V-A);
  return {V:V, p:p, Q:dU+Ws, W:Ws, dU:dU}; }

/* ---------------- ④-1 熱サイクル ----------------
   4 つの変化を 4 s ずつ。変化が終わるごとに、下に模式図（教科書のサイクルの模式図の形）を残す */
var S41 = {
  SD:4,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.cyc="rect"; this.clk=0;
    this.run=new Runner({ again:true, step:function(dt){ self.clk+=dt; self.tb.sync(); return self.run.t>=4*self.SD; }, draw:function(){ self.draw(); }, reset:function(){} });
    this.run.bind(sec);
    this.tb=wireTimeBar(sec, this.run, function(){ return 4*self.SD; }, function(){});
    this.sc=wireSeg(sec,"cyc",function(v){ self.cyc=v; self.run.reset(); self.tb.sync(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.cyc="rect"; self.sc.set("rect"); resetSlow(sec,self.run); self.run.reset(); self.tb.sync(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    idleLoop(sec, function(dt){ if(self.run.state!=="run"){ self.clk+=dt; self.draw(); } });
    this.draw();
  },
  /* 模式図 1 こま。i …区間、x,y,w,h …枠、live …いま変化中（矢印の帯を流す）、u …進み具合 */
  frame:function(c, C, i, x, y, w, h, live, u){
    var s=C.seg[i], st=cycSt(C,s,live? u : 1), Q=st.Q, Wd=st.W, carnot=(this.cyc==="carnot");
    var hot = carnot? (i===0) : (i<2), cold = carnot? (i===2) : (i>=2), ad=(s.k==="A");
    c.save(); c.fillStyle=live? "#fffaf1" : "#fff"; c.strokeStyle=live? "#e07b18" : "#e6e1d7"; c.lineWidth=live? 2 : 1; rrect(c,x,y,w,h,10); c.fill(); c.stroke(); c.restore();
    T(c, CIRC[i]+" "+s.f+"→"+s.t+(w>230? "　" : " ")+s.nm, x+8, y+13, {size:w>230? 11.5 : 10.5, bold:true});
    /* 装置：等温＝恒温槽、断熱＝断熱材（手で動かす）、定積＝ピストン固定、定圧＝ピストン自由（おもり）。熱はヒーター（冷却器）で */
    var by=y+h-14, cw=w*0.30, cx=x+w*0.42, Tk=st.p*st.V*1e3/RGAS, iso=(s.k==="T"), hot=(Q>5e-3), cold=(Q<-5e-3);
    if(!this.gs) this.gs=[0,1,2,3].map(function(j){ return new Gas(12, 41+j); });
    var VV=st.V, ch=h-70, L=ch*0.62*VV/4.6, cyB=by-14, F=new CylFrame(cx, cyB, "up");
    ground(c, cx-cw/2-22, cx+cw/2+22, by-2);
    var gC=drawCylinder(c, F, {L:L, Lmax:ch*0.80, h:cw, T:Tk, gas:this.gs[i], r:2.6, pt:8, wall:6, lock:(s.k==="V"), hand:(s.k==="T"||s.k==="A"), rod:16,
      cont:(iso? "bath" : "ins"), bathT:Tk, noInsLab:true, heater:!ad, heat:(live && !ad && !iso? (hot? 1 : cold? -1 : 0) : 0), clk:this.clk+i, thermo:true, thLen:18});
    T(c, iso? (hot? "高温の恒温槽" : "低温の恒温槽") : "断熱材", x+w-8, y+h-8, {size:9.5, bold:true, col:iso? (hot? "#9b2b21" : "#1f5f99") : "#7a6635", align:"right"});
    var hasW=(s.k==="P");
    if(hasW){ var wy=cyB-L-8; c.save(); c.fillStyle="#6d747d"; rrect(c, cx-cw*0.30, wy-12, cw*0.60, 12, 3); c.fill(); c.restore(); }
    by=cyB-ch*0.3;
    /* 熱の矢印（流れる帯は、変化中だけ動かす） */
    var ph=live? (this.clk*0.9)%1 : 0.3;
    var hx=cx+cw/2+30;
    if(Q>5e-3 && !ad) heatFlow(c, hx, by+18, hx-14, by-14, 9, ph, {k:0.7});
    if(Q<-5e-3 && !ad) heatFlow(c, hx-14, by-14, hx, by+18, 9, ph, {k:0.7});
    if(Math.abs(Q)>5e-3 && !ad){ var qw=SYM(c,"Q",s.f+s.t,hx+4,by-20,{size:12.5,bold:true,col:COL.heat,halo:true}); }
    /* 仕事 */
    if(s.k!=="V"){ var up=(Wd>0), ax=cx-cw/2-24, ay=cyB-L-4; blockArrow(c, ax, up? ay+6 : ay-22, ax, up? ay-22 : ay+6, 7, "#5cc47a");
      symW(c, up? "した" : "された", ax-6, ay-28, {size:12, bold:true, col:COL.work, align:"right", halo:true}); }
    if(w>230) T(c, (Q>=0? "+" : "−")+Math.abs(Q*1e3).toFixed(0)+" J", x+w-8, y+13, {size:10.5, bold:true, col:COL.heat, align:"right"});
  },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return W<700? clamp(W*1.75, 640, 820) : clamp(W*0.56, 520, 620); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var narrow=W<700, C=CYC[this.cyc], t=this.run.t, k=Math.min(3, Math.floor(t/this.SD)), u=clamp((t-k*this.SD)/this.SD,0,1), done=t>=4*this.SD-1e-6;
    var gh=narrow? H*0.42 : H*0.50;
    /* p-V 図 */
    var P=plotFrame(c, 50, gh-30, narrow? W-14 : W*0.60, 22, [0,5], [0,4.5], {xl:"V〔×10⁻² m³〕", yl:"p〔×10⁵ Pa〕", xstep:1, ystep:1});
    var path=function(upto, uu){ var pts=[]; for(var i=0;i<4;i++){ if(i>upto) break; var n=(i<upto)? 30 : Math.max(1,Math.round(30*uu)); for(var j=0;j<=n;j++){ var s=cycSt(C,C.seg[i],(i<upto)? j/30 : uu*j/n); pts.push([s.V,s.p]); } } return pts; };
    var full=path(4,1);
    c.save(); c.fillStyle="rgba(92,196,122,"+(done? 0.30 : 0.10)+")"; c.beginPath(); full.forEach(function(q,i){ if(i) c.lineTo(P.X(q[0]),P.Y(q[1])); else c.moveTo(P.X(q[0]),P.Y(q[1])); }); c.closePath(); c.fill();
    c.strokeStyle="#c9c3b8"; c.lineWidth=1.3; c.setLineDash([5,4]); c.stroke(); c.restore();
    var cur=path(k,u); c.save(); c.strokeStyle="#c0392b"; c.lineWidth=2.8; c.beginPath(); cur.forEach(function(q,i){ if(i) c.lineTo(P.X(q[0]),P.Y(q[1])); else c.moveTo(P.X(q[0]),P.Y(q[1])); }); c.stroke(); c.restore();
    /* 向きの矢印（区間のまん中） */
    for(var i=0;i<4;i++){ var a=cycSt(C,C.seg[i],0.48), b=cycSt(C,C.seg[i],0.55); arrow(c, P.X(a.V), P.Y(a.p), P.X(b.V), P.Y(b.p), "#3a414c", 1.4, 9); }
    ["A","B","C","D"].forEach(function(n){ var q=C.pts[n], dx=(n==="A"||n==="B")? -9 : 9, dy=(n==="B"||n==="C")? -10 : 12; if(self.cyc==="carnot"){ dx=(n==="A"||n==="D")? -9 : 9; dy=(n==="A"||n==="B")? -8 : 12; }
      dot(c, P.X(q[0]), P.Y(q[1]), 4, "#3a414c"); T(c, n, P.X(q[0])+dx, P.Y(q[1])+dy, {size:13, bold:true, serif:true, align:dx<0? "right" : "left", halo:true}); });
    if(this.cyc==="carnot"){ T(c, "500 K の等温線", P.X(1.6), P.Y(C.pts.A[0]*C.pts.A[1]/1.6)-12, {size:10, col:"#c0392b", halo:true}); T(c, "300 K", P.X(3.6), P.Y(C.pts.D[0]*C.pts.D[1]/3.6)+14, {size:10, col:"#1f6fb2", halo:true}); }
    var now=cycSt(C,C.seg[k],u); dot(c, P.X(now.V), P.Y(now.p), 6.5, "#c0392b");
    if(done){ var cxm=(C.pts.A[0]+C.pts.C[0])/2; T(c, "囲まれた面積 ＝ 1 周で気体がした仕事", P.X(cxm), P.Y(this.cyc==="rect"? 1.5 : 1.25), {size:11, bold:true, col:"#1c6b3a", align:"center", halo:true}); }
    /* 表（広い画面：右） */
    var tot={qi:0, qo:0, w:0};
    var rows=C.seg.map(function(s,i){ var e=(i<k || done)? cycSt(C,s,1) : (i===k? cycSt(C,s,u) : null); if(e){ if(e.Q>0) tot.qi+=e.Q; else tot.qo-=e.Q; tot.w+=e.W; } return [s,e]; });
    if(!narrow){ var tx=W*0.64, ty=34, lh=24;
      T(c, "熱と仕事〔J〕", tx, ty-12, {size:12, bold:true});
      SYM(c,"Q",null,tx+90+64,ty+8,{size:12.5,bold:true,col:COL.heat,align:"right"}); symW(c,"した",tx+90+128,ty+8,{size:12.5,bold:true,col:COL.work,align:"right"}); T(c,"ΔU",tx+90+192,ty+8,{size:12,bold:true,col:COL.dU,align:"right"});
      rows.forEach(function(r,i){ var y=ty+8+lh*(i+1); T(c, r[0].f+"→"+r[0].t, tx, y, {size:11.5, bold:true}); if(!r[1]) return;
        [r[1].Q, r[1].W, r[1].dU].forEach(function(v,j){ T(c, (v*1e3>=0.5? "+" : v*1e3<=-0.5? "−" : "")+Math.abs(v*1e3).toFixed(0), tx+90+(j+1)*64, y, {size:11.5, col:[COL.heat,COL.work,COL.dU][j], align:"right"}); }); });
      var yt=ty+8+lh*5+6; c.save(); c.strokeStyle="#d5cfc3"; c.beginPath(); c.moveTo(tx,yt-14); c.lineTo(W-14,yt-14); c.stroke(); c.restore();
      if(done){ SYM(c,"Q","in",tx,yt,{size:12,bold:true,col:COL.heat}); T(c," = "+(tot.qi*1e3).toFixed(0)+" J", tx+24, yt, {size:12, bold:true, col:COL.heat});
        SYM(c,"Q","out",tx,yt+lh,{size:12,bold:true,col:COL.heat}); T(c," = "+(tot.qo*1e3).toFixed(0)+" J", tx+30, yt+lh, {size:12, bold:true, col:COL.heat});
        var ww=symW(c,"した",tx,yt+2*lh,{size:12,bold:true,col:COL.work}); T(c," = "+(tot.w*1e3).toFixed(0)+" J", tx+ww, yt+2*lh, {size:12, bold:true, col:COL.work});
        SYM(c,"e",null,tx,yt+3*lh,{size:13,bold:true}); T(c," = "+(tot.w/tot.qi).toFixed(3)+(this.cyc==="rect"? "（＝ 2/13）" : "（＝ 1 − 300/500）"), tx+10, yt+3*lh, {size:12.5, bold:true});
        T(c, "1 周で ΔU の和 ＝ 0", tx, yt+4*lh, {size:11.5, col:COL.dU}); }
    }
    /* 模式図（終わった変化と、いまの変化） */
    var fy=gh+8, fh=narrow? (H-fy-8)/2-6 : H-fy-8, fw=narrow? (W-24)/2 : (W-34)/4;
    for(var j=0;j<4;j++){ if(j>k && !done) break; var fx=narrow? 8+(j%2)*(fw+8) : 8+j*(fw+6), fyy=narrow? fy+Math.floor(j/2)*(fh+8) : fy;
      this.frame(c, C, j, fx, fyy, fw, fh, (j===k && !done && t>0), u); }
    if(t<=0) T(c, "スタートを押すと、変化が 1 つ終わるごとに、ここに模式図が残る", W/2, fy+40, {size:12, col:COL.sub, align:"center"});
    notebook(c,W,H);
    var mh='<b>'+C.name+'</b>：いまは '+CIRC[k]+' '+C.seg[k].f+'→'+C.seg[k].t+'（'+C.seg[k].nm+'）'+
      (done? '<br>'+tex("Q_\\mathrm{in}")+' = '+(tot.qi*1e3).toFixed(0)+' J、'+tex("Q_\\mathrm{out}")+' = '+(tot.qo*1e3).toFixed(0)+' J、'+tex(WS+"=Q_\\mathrm{in}-Q_\\mathrm{out}")+' = '+(tot.w*1e3).toFixed(0)+' J、熱効率 '+tex("e")+' = <span class="num">'+(tot.w/tot.qi).toFixed(3)+'</span>' : '');
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};

/* ---------------- ④-2 熱機関（エンジン） ----------------
   オットーサイクル（30_gas.js の OTTO）。1 サイクル 8 s、2 サイクルで止まる */
var S42 = {
  CT:8, NC:2,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox"); this.clk=0;
    this.run=new Runner({ again:true, step:function(dt){ self.clk+=dt; self.tb.sync(); return self.run.t>=self.CT*self.NC; }, draw:function(){ self.draw(); }, reset:function(){} });
    this.run.bind(sec);
    this.tb=wireTimeBar(sec, this.run, function(){ return self.CT*self.NC; }, function(){});
    sec.querySelector(".resetall").addEventListener("click", function(){ resetSlow(sec,self.run); self.run.reset(); self.tb.sync(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    this.draw();
  },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return W<700? clamp(W*1.45, 520, 680) : clamp(W*0.42, 380, 470); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var narrow=W<700, t=this.run.t, u=t/this.CT, st=ottoState(Math.min(u, this.NC-1e-6)), running=this.run.state==="run";
    var ew=narrow? 90 : 104, Hs=narrow? H*0.12 : H*0.22, ex=narrow? W*0.30 : W*0.18, ey=narrow? 84 : 96;
    var g=drawEngine(c, ex, ey, ew, Hs, st, this.clk, false);
    T(c, "吸気弁", ex-ew*0.30-6, ey-34, {size:10.5, bold:true, col:"#1f6fb2", align:"right"}); T(c, "排気弁", ex+ew*0.30+6, ey-34, {size:10.5, bold:true, col:"#b5462e"});
    T(c, "点火プラグ", ex, ey-44, {size:10.5, bold:true, col:COL.sub, align:"center"});
    if(st.kind==="burn"){ heatFlow(c, ex+ew/2+60, ey+14, ex+ew/2+16, ey+14, 12, (this.clk*1.2)%1, {k:0.9}); SYM(c,"Q","in",ex+ew/2+64,ey-2,{size:13,bold:true,col:COL.heat,halo:true}); }
    if(st.kind==="blow"){ heatFlow(c, ex+ew*0.30, ey-20, ex+ew*0.30+52, ey-48, 12, (this.clk*1.2)%1, {k:0.9}); SYM(c,"Q","out",ex+ew*0.30+58,ey-52,{size:13,bold:true,col:COL.heat,halo:true}); }
    /* 行程の名前 */
    var bx=narrow? W*0.58 : ex+ew+70, by=ey+10;
    OTTO.SEG.forEach(function(s,i){ var on=(i===st.k); T(c, (on? "▶ " : "　")+s[2], bx, by+i*22, {size:on? 13 : 12, bold:on, col:on? "#c0392b" : COL.sub}); });
    /* p-V 図 */
    var gx0=narrow? 52 : W*0.50, gy0=H-38, gx1=W-14, gy1=narrow? H*0.50 : 24;
    var P=plotFrame(c, gx0, gy0, gx1, gy1, [0,4.5], [0,50], {xl:"V〔×10⁻⁴ m³〕", yl:"p〔×10⁵ Pa〕", xstep:1, ystep:10});
    var pts=[]; for(var k=0;k<=400;k++) pts.push(ottoState(k/400));
    c.save(); c.fillStyle="rgba(92,196,122,.18)"; c.beginPath();
    pts.filter(function(q){ return q.kind!=="in" && q.kind!=="out"; }).forEach(function(q,i){ if(i) c.lineTo(P.X(q.V),P.Y(q.p)); else c.moveTo(P.X(q.V),P.Y(q.p)); }); c.closePath(); c.fill();
    c.strokeStyle="#c9c3b8"; c.lineWidth=1.3; c.setLineDash([5,4]); c.beginPath(); pts.forEach(function(q,i){ if(i) c.lineTo(P.X(q.V),P.Y(q.p)); else c.moveTo(P.X(q.V),P.Y(q.p)); }); c.stroke(); c.restore();
    var uu=u%1, cyc=Math.floor(u); if(t>=this.CT*this.NC-1e-6){ uu=1; }
    c.save(); c.strokeStyle="#c0392b"; c.lineWidth=2.6; c.beginPath(); var n=Math.round(400*uu); for(var j=0;j<=n;j++){ var q=ottoState(Math.min(j/400,0.99999)); if(j) c.lineTo(P.X(q.V),P.Y(q.p)); else c.moveTo(P.X(q.V),P.Y(q.p)); } c.stroke(); c.restore();
    dot(c, P.X(st.V), P.Y(st.p), 6.5, "#c0392b");
    T(c, "圧縮（断熱）", P.X(1.05)+6, P.Y(Math.pow(OTTO.Vm/1.05,OTTO.g))+6, {size:10.5, col:COL.sub, halo:true});
    T(c, "膨張（断熱）", P.X(1.6), P.Y(OTTO.p3*Math.pow(OTTO.Vc/1.6,OTTO.g))-12, {size:10.5, col:COL.sub, halo:true});
    T(c, "吸気・排気（大気圧）", P.X(2.6), P.Y(1)+12, {size:10.5, col:COL.sub, halo:true});
    T(c, "点火", P.X(OTTO.Vc)+8, P.Y((OTTO.p2+OTTO.p3)/2), {size:10.5, col:COL.heat, halo:true});
    notebook(c,W,H);
    var e=1-Math.pow(OTTO.Vc/OTTO.Vm, OTTO.g-1);
    var mh='いまの行程：<b>'+st.name+'</b>　体積 '+tex("V")+' = <span class="num">'+st.V.toFixed(2)+'</span> ×10⁻⁴ m³　圧力 '+tex("p")+' = <span class="num">'+st.p.toFixed(1)+'</span> ×10⁵ Pa'+
      '<br>圧縮比 '+(OTTO.Vm/OTTO.Vc).toFixed(0)+' のオットーサイクルの熱効率は '+tex("e")+' ≒ <span class="num">'+e.toFixed(2)+'</span>（理想化した値。実際のガソリン機関は 0.2〜0.3）';
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};

/* ---------------- ⑤-1 カルノーサイクル ----------------
   T_H・T_L をスライダーで。V_A＝1.0、V_B＝2.0（×10⁻² m³）、単原子分子 1 mol */
var S51 = {
  SD:2.5,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.TH=600; this.TL=300; this.clk=0;
    this.run=new Runner({ again:true, step:function(dt){ self.clk+=dt; self.tb.sync(); return self.run.t>=4*self.SD; }, draw:function(){ self.draw(); }, reset:function(){} });
    this.run.bind(sec);
    this.tb=wireTimeBar(sec, this.run, function(){ return 4*self.SD; }, function(){});
    this.sH=wireSlider(sec,"TH",function(v){ return v.toFixed(0)+" K"; },function(v){ self.TH=v; self.run.reset(); self.tb.sync(); });
    this.sL=wireSlider(sec,"TL",function(v){ return v.toFixed(0)+" K"; },function(v){ self.TL=v; self.run.reset(); self.tb.sync(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.TH=600; self.TL=300; self.sH.set(600); self.sL.set(300); resetSlow(sec,self.run); self.run.reset(); self.tb.sync(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    idleLoop(sec, function(dt){ if(self.run.state!=="run"){ self.clk+=dt; } });
    this.draw();
  },
  C:function(){ var g=5/3, VA=1.0, VB=2.0, r=Math.pow(this.TH/this.TL,1/(g-1)), k=RGAS/1e3;
    return {pts:{A:[VA,k*this.TH/VA],B:[VB,k*this.TH/VB],C:[VB*r,k*this.TL/(VB*r)],D:[VA*r,k*this.TL/(VA*r)]},
      seg:[{f:"A",t:"B",k:"T",nm:"等温膨張"},{f:"B",t:"C",k:"A",nm:"断熱膨張"},{f:"C",t:"D",k:"T",nm:"等温圧縮"},{f:"D",t:"A",k:"A",nm:"断熱圧縮"}]}; },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return W<620? clamp(W*1.1, 430, 520) : clamp(W*0.46, 330, 400); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var narrow=W<620, C=this.C(), t=this.run.t, k=Math.min(3,Math.floor(t/this.SD)), u=clamp((t-k*this.SD)/this.SD,0,1), done=t>=4*this.SD-1e-6;
    var vmax=C.pts.C[0]*1.08, pmax=C.pts.A[1]*1.12;
    var gx1=narrow? W-14 : W*0.62, gy0=narrow? H*0.62 : H-36;
    var P=plotFrame(c, 52, gy0, gx1, 22, [0,vmax], [0,pmax], {xl:"V〔×10⁻² m³〕", yl:"p〔×10⁵ Pa〕"});
    var all=[]; C.seg.forEach(function(s){ for(var j=0;j<=40;j++){ var q=cycSt(C,s,j/40); all.push([q.V,q.p]); } });
    c.save(); c.fillStyle="rgba(92,196,122,"+(done? 0.32 : 0.12)+")"; c.beginPath(); all.forEach(function(q,i){ if(i) c.lineTo(P.X(q[0]),P.Y(q[1])); else c.moveTo(P.X(q[0]),P.Y(q[1])); }); c.closePath(); c.fill(); c.restore();
    var CC=["#c0392b","#7a6635","#1f6fb2","#7a6635"];
    C.seg.forEach(function(s,i){ c.save(); c.strokeStyle=CC[i]; c.lineWidth=(i<k || done)? 2.6 : (i===k? 2.6 : 1.2); c.globalAlpha=(i<=k || done)? 1 : 0.45; c.beginPath();
      var n=(i===k && !done)? Math.max(1,Math.round(40*u)) : 40, top=(i===k && !done)? u : 1;
      for(var j=0;j<=n;j++){ var q=cycSt(C,s,(i>k && !done)? j/40 : top*j/n); if(j) c.lineTo(P.X(q.V),P.Y(q.p)); else c.moveTo(P.X(q.V),P.Y(q.p)); } c.stroke(); c.restore(); });
    ["A","B","C","D"].forEach(function(n){ var q=C.pts[n], dx=(n==="A"||n==="D")? -9 : 9, dy=(n==="A"||n==="B")? -9 : 13; dot(c, P.X(q[0]), P.Y(q[1]), 4, "#3a414c"); T(c, n, P.X(q[0])+dx, P.Y(q[1])+dy, {size:13, bold:true, serif:true, align:dx<0? "right" : "left", halo:true}); });
    var now=cycSt(C,C.seg[k],u); dot(c, P.X(now.V), P.Y(now.p), 6.5, CC[k]);
    var lab=function(sub, val, x, y, col){ var w=SYM(c,"T",sub,x,y,{size:13,bold:true,col:col,halo:true}); T(c," = "+val+" K", x+w, y, {size:11.5, bold:true, col:col, halo:true}); };
    lab("H", this.TH, P.X((C.pts.A[0]+C.pts.B[0])/2)+8, P.Y((C.pts.A[1]+C.pts.B[1])/2)-6, "#c0392b");
    lab("L", this.TL, P.X((C.pts.C[0]+C.pts.D[0])/2)-30, P.Y((C.pts.C[1]+C.pts.D[1])/2)+18, "#1f6fb2");
    /* 熱と仕事の棒 */
    var Qin=RGAS*this.TH*Math.log(2), Qout=RGAS*this.TL*Math.log(2), Wn=Qin-Qout;
    var bx0=narrow? 50 : W*0.68, bx1=W-14, by0=narrow? H*0.70 : 40, by1=H-40;
    var B=plotFrame(c, bx0, by1, bx1, by0, [0,3], [0,6000], {noXt:true, yl:"熱・仕事〔J〕", ystep:2000, xl:""});
    var bw=(B.x1-B.x0)/4.2, vals=[[Qin,COL.heat,"Q","in"],[Wn,"#5cc47a","W","した"],[Qout,COL.heat,"Q","out"]];
    vals.forEach(function(v,i){ var x=B.x0+bw*(0.4+i*1.35), on=done || (i===0? k>0 || u>0.99 : i===2? k>2 : done);
      c.save(); c.globalAlpha=on? 0.88 : 0.25; c.fillStyle=v[1]; c.fillRect(x, B.Y(v[0]), bw, B.Y(0)-B.Y(v[0])); c.restore();
      SYM(c, v[2], v[3], x+bw/2, B.y0+12, {size:12.5, bold:true, col:v[1]==="#5cc47a"? COL.work : v[1], align:"center"});
      if(on) T(c, Math.round(v[0])+"", x+bw/2, B.Y(v[0])-10, {size:11, bold:true, col:v[1]==="#5cc47a"? COL.work : v[1], align:"center", halo:true}); });
    notebook(c,W,H);
    var e1=Wn/Qin, e2=1-this.TL/this.TH;
    var mh='いまは '+CIRC[k]+' '+C.seg[k].f+'→'+C.seg[k].t+'（'+C.seg[k].nm+'）<br>'+tex("e=\\dfrac{"+WS+"}{Q_\\mathrm{in}}")+' = '+Math.round(Wn)+' / '+Math.round(Qin)+' = <span class="num">'+e1.toFixed(3)+'</span>　'+tex("1-\\dfrac{T_\\mathrm{L}}{T_\\mathrm{H}}")+' = 1 − '+this.TL+'/'+this.TH+' = <span class="num">'+e2.toFixed(3)+'</span>';
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};
