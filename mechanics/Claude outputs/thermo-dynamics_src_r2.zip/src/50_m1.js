/* =========================================================================
   モード① 気体の法則（1-1〜1-5）
   ========================================================================= */
/* 節が見えているあいだだけ、毎フレーム fn を呼ぶ（分子を動かす） */
function idleLoop(sec, fn){ var last=0; var go=function(ts){ var dt=last? Math.min(0.05,(ts-last)/1000) : 0; last=ts; if(secVisible(sec)) fn(dt); requestAnimationFrame(go); }; requestAnimationFrame(go); }
/* V〔m³〕を「×10⁻² m³」の数で */
function v2s(V){ return (V*100).toFixed(2); }

/* ①-1 は 51_m11.js（第2回で作り直し） */

/* ---------------- ①-2 ピストンの力のつり合い ----------------
   n＝0.20 mol、T＝300 K。S＝4.9×10⁻³ m²、m＝M＝10 kg、mg/S＝2.0×10⁴ Pa。
   目的は力のつり合いだけ（p-V 図は出さない）。水平は台の上、鉛直上向きは床の上、下向きは天井からつるす */
var S12 = {
  n:0.20, T:300, S:4.9e-3, m:10, M:10,
  DIRS:{h:{lab:"水平", dp:0}, u:{lab:"鉛直上向き", dp:0.2}, uw:{lab:"鉛直上向き（おもりあり）", dp:0.4}, d:{lab:"下向き", dp:-0.2}},
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.dir="h"; this.show=true; this.p=1.0; this.gas=new Gas(26, 12); this.clk=0;
    var rs=sec.querySelector(".rsrow"); sec.querySelector(".row1b").appendChild(rs.querySelector(".resetall")); rs.remove();
    this.sd=wireSeg(sec,"dir",function(v){ self.dir=v; self.draw(); });
    this.sc=wireChk(sec,"force",function(on){ self.show=on; self.draw(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.dir="h"; self.sd.set("h"); self.show=true; self.sc.set(true); self.p=1.0; self.draw(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    idleLoop(sec, function(dt){ var pt=1+self.DIRS[self.dir].dp; self.p+=(pt-self.p)*(1-Math.exp(-dt*3)); if(Math.abs(pt-self.p)<0.001) self.p=pt; self.clk+=dt;
      if(self.g) self.gas.step(dt, self.g.L, self.g.h, 55, 4); self.draw(); });
    this.draw();
  },
  Vof:function(p){ return this.n*RGAS*this.T/(p*1e5); },     /* m³ */
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return clamp(W*0.62, 360, 430); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var narrow=W<560, dir=this.dir, p=this.p, V=this.Vof(p);
    var h=narrow? 80 : 96, VM=8.0e-3, pt=20, Lmax=(dir==="h")? Math.min(W-150, 380) : Math.min(H-150, 300), L=Lmax*V/VM;
    var ox, oy, d2=(dir==="h")? "right" : (dir==="d")? "down" : "up";
    if(dir==="h"){ ox=Math.max(40,(W-Lmax)/2-40); oy=H*0.42; } else if(dir==="d"){ ox=W*0.42; oy=48; } else { ox=W*0.42; oy=H-44; }
    var F=new CylFrame(ox, oy, d2), wt=9;
    this.g={L:Math.max(L,8), h:h};
    /* 台・床・天井（シリンダーを支える） */
    c.save(); c.strokeStyle="#5b636e"; c.fillStyle="#cdbfa6";
    if(dir==="h"){ var fy=oy+h/2+wt+40; ground(c, 10, W-10, fy); c.fillRect(ox+20, oy+h/2+wt, 14, fy-oy-h/2-wt); c.fillRect(ox+Lmax-50, oy+h/2+wt, 14, fy-oy-h/2-wt); }
    else if(dir==="d"){ var cy0=oy-wt-12; c.fillStyle="#e8e2d6"; c.fillRect(ox-h/2-40, cy0-14, h+80, 14); c.beginPath(); c.moveTo(ox-h/2-40,cy0); c.lineTo(ox+h/2+40,cy0); c.stroke();
      c.save(); c.beginPath(); c.rect(ox-h/2-40, cy0-14, h+80, 14); c.clip(); c.strokeStyle="#a9a193"; for(var k=ox-h/2-60;k<ox+h/2+50;k+=8){ c.beginPath(); c.moveTo(k,cy0-14); c.lineTo(k+10,cy0); c.stroke(); } c.restore();
      c.fillStyle="#cdbfa6"; c.fillRect(ox-h/2+6, cy0, 10, 12); c.fillRect(ox+h/2-16, cy0, 10, 12); T(c,"天井", ox+h/2+46, cy0-6, {size:10.5, col:COL.sub}); }
    else ground(c, 10, W-10, oy+wt);
    c.restore();
    var pr=clamp((p-0.6)/1.0,0,1);
    drawCylinder(c, F, {L:L, Lmax:Lmax, h:h, T:this.T, gas:this.gas, r:4, pt:pt, mcol:heatCol(gasLv(300)), pr:pr});
    /* おもり */
    if(dir==="uw"){ var w0=F.to(L+pt,-h*0.36), w1=F.to(L+pt+30,h*0.36); c.save(); c.fillStyle="#6d747d"; c.strokeStyle="#2b323c"; c.lineWidth=1.2;
      rrect(c, Math.min(w0[0],w1[0]), Math.min(w0[1],w1[1]), Math.abs(w1[0]-w0[0]), Math.abs(w1[1]-w0[1]), 4); c.fill(); c.stroke(); c.restore();
      var wc=F.to(L+pt+15,0); T(c,"おもり", wc[0], wc[1], {size:11, bold:true, col:"#fff", align:"center"}); }
    var at=(dir==="h")? [Math.min(W-50, ox+Lmax+30), oy-h/2-24] : F.to(Math.min(L+pt+(dir==="uw"? 70 : 50), Lmax+24), h*0.5+34);
    T(c, "大気（圧力 p₀）", at[0], at[1], {size:11, bold:true, col:COLG.atm, align:"center", halo:true});
    /* 力の矢印（作用点に ・）。長さは力の大きさに比例。水平：軸の向きの力は上半分、重力と垂直抗力は下半分に分けて重ねない */
    if(this.show){
      var kF=(dir==="h")? (narrow? 0.20 : 0.24) : (narrow? 0.13 : 0.16), ax=Math.cos(F.ang), ay=Math.sin(F.ang);
      var arr=function(lx, ly, fx, fy, N, col, lab, sub){ var s=F.to(lx,ly), e=[s[0]+fx*N*kF, s[1]+fy*N*kF];
        fArrow(c, s[0], s[1], e[0], e[1], col, 3, 10);
        var lxp=e[0]+(Math.abs(fx)>0.5? fx*8 : 10), lyp=e[1]+(Math.abs(fy)>0.5? fy*12 : 0), al=(fx<-0.5? "right" : "left");
        if(sub==="0S"){
          c.save(); c.font="italic 700 14px "+MATHF; var w1=c.measureText("p").width, w3=c.measureText("S").width; c.font="10px "+SERIF; var w2=c.measureText("0").width; c.restore();
          var x0=(al==="right")? lxp-(w1+w2+w3+3) : lxp, a=SYM(c,"p","0",x0,lyp,{size:14,bold:true,col:col,halo:true}); SYM(c,"S",null,x0+a+1,lyp,{size:14,bold:true,col:col,halo:true}); }
        else SYM(c, lab, sub, lxp, lyp, {size:14, bold:true, col:col, halo:true, align:al}); };
      var pS=p*1e5*this.S, p0S=1e5*this.S, mg=this.m*9.8, Mg=this.M*9.8;
      var ly1=(dir==="h")? -h*0.12 : -h*0.28, ly2=(dir==="h")? -h*0.36 : h*0.28;
      arr(L, ly1, ax, ay, pS, COLG.gasF, "pS", null);
      arr(L+pt, ly2, -ax, -ay, p0S, COLG.atm, "p", "0S");
      var cen=F.to(L+pt/2, 0);
      if(dir==="h"){ fArrow(c, cen[0]-5, cen[1], cen[0]-5, cen[1]+mg*kF, COLG.grav, 3, 9); SYM(c,"mg",null,cen[0]-10,cen[1]+mg*kF+6,{size:13,bold:true,col:COLG.grav,halo:true,align:"right"});
        var bt=F.to(L+pt/2, h/2); fArrow(c, bt[0]+5, bt[1], bt[0]+5, bt[1]-mg*kF, COLG.norm, 3, 9); SYM(c,"N",null,bt[0]+10,bt[1]+12,{size:13,bold:true,col:COLG.norm,halo:true}); }
      else { fArrow(c, cen[0], cen[1], cen[0], cen[1]+mg*kF, COLG.grav, 3, 9); SYM(c,"mg",null,cen[0]+(dir==="d"? 6 : -6),cen[1]+mg*kF+10,{size:13,bold:true,col:COLG.grav,halo:true,align:(dir==="d"? "left" : "right")}); }
      if(dir==="uw"){ var tp=F.to(L+pt, -h*0.06); fArrow(c, tp[0], tp[1], tp[0], tp[1]+Mg*kF, COLG.norm, 3, 9); SYM(c,"Mg",null,tp[0]-6,tp[1]-8,{size:13,bold:true,col:COLG.norm,halo:true,align:"right"}); }
    }
    notebook(c,W,H);
    /* 右の列：いまの向きの式を光らせる */
    this.sec.querySelectorAll(".eqtab tr[data-dir]").forEach(function(tr){ tr.classList.toggle("hl", tr.dataset.dir===dir); });
    var mh='気体の圧力 '+tex("p")+' = <span class="num">'+p.toFixed(2)+'</span> ×10⁵ Pa（大気圧 '+tex("p_0")+' = 1.00 ×10⁵ Pa）'+
      '<br>'+(dir==="h"? '水平のとき、軸の向きの力は '+tex("pS")+' と '+tex("p_0S")+' だけ。ピストンの重力 '+tex("mg")+' は、壁からの垂直抗力 '+tex("N")+' とつり合う。' :
                 dir==="d"? '下向きでは、ピストンの重力の分だけ、気体の圧力は大気圧より小さい。' :
                 '上向きでは、ピストン'+(dir==="uw"? 'とおもり' : '')+'の重さの分だけ、気体の圧力は大気圧より大きい。');
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};

/* ---------------- ①-3 ボイルの法則 ----------------
   n＝1.0 mol。押す：V＝4.0 → 1.0（×10⁻² m³）、引く：1.0 → 4.0。8 秒。0.5 ごとに点を打つ */
var S13 = {
  DUR:8, n:1.0,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.dirb="push"; this.Tb=300; this.gas=new Gas(36, 13); this.clk=0; this.flash=0;
    this.run=new Runner({ again:true,
      startText:function(){ return self.dirb==="push"? "▶ スタート（押す）" : "▶ スタート（引く）"; },
      step:function(dt){ self.clk+=dt; self.move(dt); return self.run.t>=self.DUR; },
      draw:function(){ self.draw(); }, reset:function(){},
      info:function(){ return ''; } });
    this.run.bind(sec);
    this.tb={sync:function(){}};                 /* 第2回：時間バー・スローはなし */
    sec.querySelector(".ctrls").insertAdjacentHTML("afterend", panelHTML(["p","V","T"]));
    this.sa=wireSeg(sec,"dirb",function(v){ self.dirb=v; self.run.reset(); self.tb.sync(); });
    this.st=wireSeg(sec,"tb",function(v){ self.Tb=parseFloat(v); self.run.reset(); self.tb.sync(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.dirb="push"; self.sa.set("push"); self.Tb=300; self.st.set("300"); resetSlow(sec,self.run); self.run.reset(); self.tb.sync(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    idleLoop(sec, function(dt){ if(self.run.state!=="run"){ self.clk+=dt; self.move(dt); self.draw(); } });
    this.draw();
  },
  Vt:function(t){ var u=clamp(t/this.DUR,0,1); return this.dirb==="push"? 4.0-3.0*u : 1.0+3.0*u; },   /* ×10⁻² m³ */
  move:function(dt){ var g=this.g; if(!g) return; var h0=this.gas.hits; this.gas.step(dt, g.L, g.h, 52*Math.sqrt(this.Tb/300), 4); if(this.gas.hits>h0) this.flash=0.18; this.flash=Math.max(0,this.flash-dt); },
  rate:function(L){ var s=0, vs=52*Math.sqrt(this.Tb/300); this.gas.m.forEach(function(q){ s+=Math.abs(q.vx); }); return s*vs/(2*Math.max(L-8,1)); },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return W<620? clamp(W*1.15, 440, 520) : clamp(W*0.45, 300, 380); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var narrow=W<620, aw=narrow? W : W*0.52, ah=narrow? H*0.40 : H;
    var V=this.Vt(this.run.t), p=this.n*RGAS*this.Tb/(V*1e-2)/1e5;
    var ox=40, h=narrow? 72 : 92, Lmax=aw-ox-110, L=Lmax*V/4.6, cy=narrow? ah*0.52 : ah*0.44;
    this.g={L:L, h:h};
    var F=new CylFrame(ox, cy, "right");
    /* 恒温槽に入れて温度一定。手はピストンの棒の先をにぎり、ピストンと一緒に動く */
    var g=drawCylinder(c, F, {L:L, Lmax:Lmax, h:h, T:this.Tb, gas:this.gas, r:4, pt:14, rod:46, hand:true, cont:"bath", bathT:this.Tb, heater:true, thermo:true, thLen:40, pr:clamp(p/5.0,0,1)});
    if(this.flash>0){ c.save(); c.fillStyle="rgba(224,123,24,"+(this.flash/0.18*0.45)+")"; c.fillRect(ox+L, cy-h/2, 14, h); c.restore(); }
    T(c, this.dirb==="push"? "押す" : "引く", g.rodEnd[0]+20, g.rodEnd[1]-22, {size:11.5, bold:true, col:COL.sub, align:"center", halo:true});
    var rt=this.rate(L);
    T(c, "ピストンに分子が当たる回数　1 秒あたり 約 "+rt.toFixed(1)+" 回", 12, cy+h/2+44, {size:narrow? 11 : 12, bold:true, col:"#9c4e06", halo:true});
    /* p-V 図 */
    var gx0=narrow? 52 : aw+40, gy0=H-38, gx1=W-14, gy1=narrow? ah+30 : 24;
    var P=plotFrame(c, gx0, gy0, gx1, gy1, [0,5], [0,5.6], {xl:"V〔×10⁻² m³〕", yl:"p〔×10⁵ Pa〕", xstep:1, ystep:1});
    var kk=function(Tb){ return self.n*RGAS*Tb*1e-3; };      /* pV（×10⁵ Pa・×10⁻² m³） */
    [300,600].forEach(function(Tb){ curve(c, P, function(v){ return kk(Tb)/v; }, 0.42, 4.9, Tb===self.Tb? "#e0457b" : "#c9c3b8", 1.3, [5,4], [0,5.6]);
      T(c, Tb+" K", P.X(4.75), P.Y(kk(Tb)/4.75)-10, {size:10.5, bold:true, col:Tb===self.Tb? "#e0457b" : COL.sub, align:"center", halo:true}); });
    var v0=this.dirb==="push"? 4.0 : 1.0;
    for(var k=0;k<=6;k++){ var vv=this.dirb==="push"? 4.0-0.5*k : 1.0+0.5*k; if(this.dirb==="push"? vv<V-1e-6 : vv>V+1e-6) break; dot(c, P.X(vv), P.Y(kk(this.Tb)/vv), 4.2, "#1f6fb2"); }
    dot(c, P.X(V), P.Y(p), 6, "#c0392b");
    notebook(c,W,H);
    setPanel(this.sec, {p:[p.toFixed(2),0], V:[V.toFixed(2),0], T:[String(this.Tb),0]});
    var mh=tex("V")+' = <span class="num">'+V.toFixed(2)+'</span> ×10⁻² m³　'+tex("p")+' = <span class="num">'+p.toFixed(2)+'</span> ×10⁵ Pa　'+tex("pV")+' = <span class="num">'+(p*V*1e3).toFixed(0)+'</span> J'+
      '<br>当たる回数は、体積が '+v0.toFixed(1)+' ×10⁻² m³ のときの <span class="num">'+(v0/V).toFixed(2)+'</span> 倍、圧力も <span class="num">'+(v0/V).toFixed(2)+'</span> 倍。';
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};

/* ---------------- ①-4 シャルルの法則 ----------------
   n＝1.0 mol、p＝1.0×10⁵ Pa（おもりで一定）。温める：200 → 400 K、冷やす：400 → 200 K。8 秒。50 K ごとに点 */
var S14 = {
  DUR:8, n:1.0,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.hc="heat"; this.gas=new Gas(32, 14); this.clk=0;
    this.run=new Runner({ again:true,
      startText:function(){ return self.hc==="heat"? "▶ スタート（温める）" : "▶ スタート（冷やす）"; },
      step:function(dt){ self.clk+=dt; self.move(dt); return self.run.t>=self.DUR; },
      draw:function(){ self.draw(); }, reset:function(){} });
    this.run.bind(sec);
    this.tb={sync:function(){}};                 /* 第2回：時間バー・スローはなし */
    sec.querySelector(".ctrls").insertAdjacentHTML("afterend", panelHTML(["p","V","T"]));
    this.sh=wireSeg(sec,"hc",function(v){ self.hc=v; self.run.reset(); self.tb.sync(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.hc="heat"; self.sh.set("heat"); resetSlow(sec,self.run); self.run.reset(); self.tb.sync(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    idleLoop(sec, function(dt){ if(self.run.state!=="run"){ self.clk+=dt; self.move(dt); self.draw(); } });
    this.draw();
  },
  Tt:function(t){ var u=clamp(t/this.DUR,0,1); return this.hc==="heat"? 200+200*u : 400-200*u; },
  move:function(dt){ var g=this.g; if(g) this.gas.step(dt, g.w, g.L, 52*Math.sqrt(this.Tt(this.run.t)/300), 4); },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return W<620? clamp(W*1.2, 470, 540) : clamp(W*0.46, 320, 390); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var narrow=W<620, aw=narrow? W : W*0.44, ah=narrow? H*0.47 : H, Tk=this.Tt(this.run.t), V=this.n*RGAS*Tk/1e5*100;   /* ×10⁻² m³ */
    var w=narrow? 92 : 104, baseY=ah-40, Lmax=Math.min(ah-120, 260), L=Lmax*V/3.8, ox=aw*0.5, running=(this.run.state==="run");
    this.g={w:L, L:w};     /* 縦向き：気体の部分の「幅」は L、高さは w（回した座標） */
    var F=new CylFrame(ox, baseY, "up");
    /* 断熱材で囲み、中のヒーター（冷却器）で加熱・冷却する。ピストンは自由（おもりで圧力一定） */
    ground(c, 8, aw-8, baseY+22);
    var gC=drawCylinder(c, F, {L:L, Lmax:Lmax, h:w, T:Tk, gas:this.gas, r:4, pt:14, cont:"ins", heater:true, heat:(running? (this.hc==="heat"? 1 : -1) : 0), clk:this.clk, thermo:true, thLen:40, pr:0.33});
    /* おもり */
    var wy=baseY-L-14; c.save(); c.fillStyle="#6d747d"; c.strokeStyle="#2b323c"; rrect(c, ox-w*0.34, wy-26, w*0.68, 26, 4); c.fill(); c.stroke(); c.restore();
    T(c,"おもり", ox, wy-13, {size:11, bold:true, col:"#fff", align:"center"});
    T(c, "（"+Math.round(Tk-273)+" ℃）", gC.thermoLab[0]+46, gC.thermoLab[1], {size:11, bold:true, col:"#a03028", halo:true});
    T(c, "圧力 1.0×10⁵ Pa（一定）", ox, 16, {size:11, bold:true, col:COLG.p, align:"center", halo:true});
    /* V–T 図（下に ℃ の目盛り） */
    var gx0=narrow? 54 : aw+44, gy0=H-50, gx1=W-14, gy1=narrow? ah+26 : 24;
    var P=plotFrame(c, gx0, gy0, gx1, gy1, [0,450], [0,4], {xl:"T〔K〕", yl:"V〔×10⁻² m³〕", xstep:100, ystep:1, xz:false});
    T(c, "0", P.X(0), gy0+11, {size:10.5, col:COL.sub, align:"center"});
    [[-273,0],[0,273],[100,373]].forEach(function(q){ T(c, q[0]+" ℃", P.X(q[1]), gy0+34, {size:10, col:"#a03028", align:"center", halo:true}); });
    var kv=this.n*RGAS/1e5*100;
    c.save(); c.setLineDash([5,4]); c.strokeStyle="#9aa1ab"; c.lineWidth=1.3; c.beginPath(); c.moveTo(P.X(0),P.Y(0)); c.lineTo(P.X(200),P.Y(kv*200)); c.stroke(); c.restore();
    T(c, "のばすと 0 K で V＝0", P.X(60), P.Y(kv*60)-16, {size:10.5, col:COL.sub, halo:true});
    var t0=this.hc==="heat"? 200 : 400;
    c.save(); c.strokeStyle="#1f6fb2"; c.lineWidth=2.2; c.beginPath(); c.moveTo(P.X(t0),P.Y(kv*t0)); c.lineTo(P.X(Tk),P.Y(kv*Tk)); c.stroke(); c.restore();
    for(var k=0;k<=4;k++){ var tt=this.hc==="heat"? 200+50*k : 400-50*k; if(this.hc==="heat"? tt>Tk+1e-6 : tt<Tk-1e-6) break; dot(c, P.X(tt), P.Y(kv*tt), 4.2, "#1f6fb2"); }
    dot(c, P.X(Tk), P.Y(V), 6, "#c0392b");
    notebook(c,W,H);
    setPanel(this.sec, {p:["1.00",0], V:[V.toFixed(2),0], T:[String(Math.round(Tk)),0]});
    var mh=tex("T")+' = <span class="num">'+Math.round(Tk)+'</span> K　'+tex("V")+' = <span class="num">'+V.toFixed(2)+'</span> ×10⁻² m³　'+tex("\\dfrac{V}{T}")+' = <span class="num">'+(V/Tk*100).toFixed(2)+'</span> ×10⁻⁴ m³/K（一定）';
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};

/* ①-5 は 51_m11.js（第2回でボイル・シャルルの法則に作り直し） */
