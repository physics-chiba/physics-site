/* =========================================================================
   サイト全体へのナビ（デザイン統一キット 6 章のまま。here の行と一覧の写しだけ直す）
   ========================================================================= */
var SITE_HOME = "https://physics-chiba.github.io/physics-site/";
var SITE_FORM = "https://docs.google.com/forms/d/e/1FAIpQLScU1DzFTmUDGSvP3UE5Lr7RY8NvjukkzBHmQYtmOac44twPwQ/viewform";
var SITE_SNAPSHOT = [
  { g:"シミュレーション", id:"mechanics", name:"力学", color:"#1663b5", items:[
    { t:"一次元と平面の運動　～v-tグラフで理解する～", u:"mechanics/basics-of-motion-on-plane.html" },
    { t:"力学的エネルギーと非保存力の仕事の関係", u:"mechanics/mechanical-energy.html" },
    { t:"剛体と力のモーメント", u:"mechanics/rigid-body-dynamics.html" },
    { t:"箱の回転　～傾くのが先か滑るのが先か～", u:"mechanics/rotation-box_tip-or-slip.html" },
    { t:"運動量と力積、2物体の衝突と反発係数", u:"mechanics/momentum-and-collision.html" },
    { t:"保存則クイズ　基本編", u:"mechanics/conservation-quiz-basic.html" },
    { t:"保存則クイズ　難関大受験編", u:"mechanics/conservation-quiz-advanced.html" },
    { t:"円運動", u:"mechanics/circular-motion.html" },
    { t:"慣性力", u:"mechanics/inertia-force.html" },
    { t:"単振動", u:"mechanics/simple-harmonic-motion.html" },
    { t:"流体から受ける力", u:"mechanics/fluid-force.html" },
    { t:"熱とエネルギー", u:"mechanics/thermal-energy.html" },
    { t:"気体と熱力学", u:"mechanics/thermo-dynamics.html" },
    { t:"万有引力とケプラーの法則", u:"mechanics/celestial-mechanics.html" } ]},
  { g:"シミュレーション", id:"wave", name:"波動", color:"#3ea0e0", items:[
    { t:"光の干渉①　ヤングの実験", u:"wave/youngs-experiment.html" },
    { t:"光の干渉②　回折格子", u:"wave/diffraction_grating.html" },
    { t:"光の干渉③　薄膜の干渉", u:"wave/Light-interference-thin-film.html" } ]},
  { g:"シミュレーション", id:"elemag", name:"電磁気", color:"#7b5bd6", items:[
    { t:"電気回路３次元シミュレーター", u:"elemag/circuit-water-model-3d.html" } ]},
  { g:"実験", id:"movie", name:"動画をつかう", color:"#0e7490", items:[
    { t:"動画解析・トラッキングツール", u:"experiment/motion-analysis.html" } ]},
  { g:"作成後記", id:"note", name:"作成後記", color:"#1c8f4a", items:[
    { t:"動画解析アプリができるまで　AIとの共同作業の記録", u:"AI_log/motion-analysis_AI-collaboration.html" },
    { t:"薄膜の干渉ができるまで　AIとの共同作業の記録", u:"AI_log/Light-interference-thin-film_AI-collaboration.html" } ]}
];
function parseSiteIndex(txt){
  try{
    var grab=function(name){ var i=txt.indexOf("const "+name+" = ["); if(i<0) return ""; var j=txt.indexOf("\nconst ", i+10); return txt.slice(i, j<0? undefined : j); };
    var out=[];
    [["SITE","シミュレーション"],["EXPSITE","実験"]].forEach(function(pr){
      var src=grab(pr[0]); if(!src) return;
      src.split(/\{\s*\n\s*id:"/).slice(1).forEach(function(chunk){
        var id=(chunk.match(/^([\w-]+)"/)||[])[1], name=(chunk.match(/name:"([^"]+)"/)||[])[1], color=(chunk.match(/color:"(#[0-9a-fA-F]{3,8})"/)||[])[1];
        var items=[], re=/\bt:"([^"]+)"[\s\S]*?\bu:BASE\+"([^"]+)"/g, m;
        while((m=re.exec(chunk))) items.push({t:m[1], u:m[2]});
        if(id && name && items.length) out.push({g:(id==="note"? "作成後記" : pr[1]), id:id, name:name, color:color||"#5b6672", items:items});
      });
    });
    var ORD={"シミュレーション":0,"実験":1,"作成後記":2};
    out.sort(function(a,b){ return (ORD[a.g]||0)-(ORD[b.g]||0); });
    var n=out.reduce(function(a,s){ return a+s.items.length; },0);
    return (n>=5)? out : null;
  }catch(e){ return null; }
}
function buildSiteDrawer(){
  var nav=document.getElementById("tabs"); if(!nav) return;
  var dr=document.createElement("aside");
  dr.id="siteDrawer"; dr.className="drawer"; dr.setAttribute("role","dialog"); dr.setAttribute("aria-modal","true");
  dr.setAttribute("aria-label","楽楽（らくらく）高校物理のページ一覧"); dr.hidden=true;
  var scrim=document.createElement("div"); scrim.className="drawer-scrim"; scrim.hidden=true;
  document.body.appendChild(scrim); document.body.appendChild(dr);
  var here=(location.pathname.match(/physics-site\/(.+)$/)||[])[1] || "mechanics/thermo-dynamics.html";
  var esc=function(s){ return String(s).replace(/[&<>"']/g, function(c){ return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]; }); };
  var render=function(data){
    var h='<div class="dr-head"><a class="dr-brand" href="'+SITE_HOME+'">'+(document.querySelector("#hero .atom")? document.querySelector("#hero .atom").outerHTML : "")+
      '<span>楽楽（らくらく）高校物理</span></a><button type="button" class="dr-x" aria-label="閉じる">×</button></div>'+
      '<a class="dr-home" href="'+SITE_HOME+'"><span class="dr-hi" aria-hidden="true">'+(nav.querySelector(".navhome svg")||{outerHTML:""}).outerHTML+'</span>'+
      '<span><b>ホーム</b><small>トップページ（分野ごとの一覧・検索・更新履歴）</small></span><span class="dr-go" aria-hidden="true">→</span></a>';
    var lastG="";
    data.forEach(function(sec){
      if(sec.g!==lastG){ h+='<p class="dr-g">'+esc(sec.g)+'</p>'; lastG=sec.g; }
      h+='<section class="dr-sec" style="--c:'+esc(sec.color)+'"><h3><i></i>'+esc(sec.name)+'</h3><ul>';
      sec.items.forEach(function(it){ var cur=(it.u===here);
        h+='<li><a href="'+esc(SITE_HOME+it.u)+'"'+(cur? ' aria-current="page" class="cur"' : '')+'>'+esc(it.t)+(cur? '<em>いま見ているページ</em>' : '')+'</a></li>'; });
      h+='</ul></section>';
    });
    h+='<a class="dr-form" href="'+SITE_FORM+'" target="_blank" rel="noopener">感想・励ましの言葉・要望・バグ報告はこちら<span aria-hidden="true">↗</span></a>';
    dr.innerHTML=h;
    dr.querySelector(".dr-x").addEventListener("click", function(){ close(); });
  };
  render(SITE_SNAPSHOT);
  var btn=document.getElementById("bPages"), lastFocus=null;
  function open(){ lastFocus=document.activeElement; dr.hidden=false; scrim.hidden=false;
    requestAnimationFrame(function(){ dr.classList.add("on"); scrim.classList.add("on"); });
    document.documentElement.classList.add("drawer-open"); if(btn) btn.setAttribute("aria-expanded","true");
    var cur=dr.querySelector("a.cur")||dr.querySelector("a"); if(cur) setTimeout(function(){ cur.focus({preventScroll:true}); cur.scrollIntoView({block:"center"}); }, 60); }
  function close(){ if(dr.hidden) return; dr.classList.remove("on"); scrim.classList.remove("on");
    document.documentElement.classList.remove("drawer-open"); if(btn) btn.setAttribute("aria-expanded","false");
    setTimeout(function(){ dr.hidden=true; scrim.hidden=true; }, 260); if(lastFocus && lastFocus.focus) lastFocus.focus({preventScroll:true}); }
  if(btn) btn.addEventListener("click", function(){ dr.hidden? open() : close(); });
  scrim.addEventListener("click", close);
  document.addEventListener("keydown", function(ev){
    if(dr.hidden) return;
    if(ev.key==="Escape"){ ev.preventDefault(); close(); return; }
    if(ev.key==="Tab"){ var f=dr.querySelectorAll("a[href],button"); if(!f.length) return; var a=f[0], z=f[f.length-1];
      if(ev.shiftKey && document.activeElement===a){ ev.preventDefault(); z.focus(); }
      else if(!ev.shiftKey && document.activeElement===z){ ev.preventDefault(); a.focus(); } }
  });
  window.SITENAV={open:open, close:close, render:render};
  if(location.protocol==="https:" && /physics-chiba\.github\.io$/.test(location.hostname) && window.fetch){
    fetch(SITE_HOME+"index.html",{cache:"no-cache"}).then(function(r){ return r.ok? r.text() : ""; }).then(function(txt){ var d=txt && parseSiteIndex(txt); if(d) render(d); }).catch(function(){});
  }
}
document.addEventListener("DOMContentLoaded", function(){ buildSiteDrawer(); });
