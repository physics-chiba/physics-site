/* =========================================================================
   デザインの動き（キット 5 章）＋ ヒーローのアニメ（このページ専用）
   ヒーロー：左はエンジン（オットーサイクル）の断面、右は p-V 図の上を状態の点が回り、囲まれた面積（気体がした仕事）を塗る。
   ========================================================================= */
(function(){
  var RM = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var C = { acc:"#4fa8ff", acc2:"#9fd0ff", deep:"#2f7fd6", T:"#f4f7fb", dim:"rgba(222,232,245,.6)", wall:"rgba(222,232,245,.38)",
            heat:"#ffb26b", work:"#5fd38a" };
  var JP = '"Hiragino Sans","Hiragino Kaku Gothic ProN","Yu Gothic",YuGothic,"Noto Sans JP",Meiryo,sans-serif';
  var MATH = '"KaTeX_Math","KaTeX_Main",serif', SER = '"KaTeX_Main","Times New Roman",serif';

  function initStage(){
    var cv=document.getElementById("heroCv"); if(!cv) return;
    var ctx=cv.getContext("2d");
    var W=0,H=0,dpr=1,run=false,raf=0,last=0,paused=false,rate=1, u=0, clk=0, CT=7.0;
    function setup(){ var r=cv.getBoundingClientRect(); dpr=Math.min(2,window.devicePixelRatio||1);
      W=Math.max(280,r.width); H=Math.max(160,r.height); cv.width=Math.round(W*dpr); cv.height=Math.round(H*dpr); ctx.setTransform(dpr,0,0,dpr,0,0); }
    function sym(x,y,b,sub,col,size){ ctx.save(); ctx.fillStyle=col; ctx.textBaseline="alphabetic"; ctx.font="italic "+size+"px "+MATH; ctx.fillText(b,x,y); var w=ctx.measureText(b).width;
      if(sub){ ctx.font=Math.round(size*0.68)+"px "+SER; ctx.fillText(sub,x+w+1,y+size*0.22); w+=ctx.measureText(sub).width+1; } ctx.restore(); return w; }
    function draw(){
      ctx.clearRect(0,0,W,H);
      var st=ottoState(u), wide=(W>=560);
      /* エンジン */
      var ew=Math.min(92, W*(wide? 0.09 : 0.20)), Hs=Math.min(H*0.30, 80), ex=wide? W*0.20 : W*0.24, ey=Math.max(34, H*0.17);
      drawEngine(ctx, ex, ey, ew, Hs, st, clk, true);
      ctx.save(); ctx.font="700 12.5px "+JP; ctx.fillStyle=C.acc2; ctx.textAlign="center"; ctx.textBaseline="middle"; ctx.fillText(st.name, ex, H-14); ctx.restore();
      if(st.kind==="burn" && wide){ heatFlow(ctx, ex+ew/2+58, ey+16, ex+ew/2+14, ey+16, 12, (clk*1.2)%1, {k:0.9}); sym(ex+ew/2+62, ey+8, "Q","in", C.heat, 15); }
      if(st.kind==="blow" && wide){ heatFlow(ctx, ex+ew*0.3, ey-14, ex+ew*0.3+56, ey-30, 12, (clk*1.2)%1, {k:0.9}); sym(ex+ew*0.3+62, ey-22, "Q","out", C.heat, 15); }
      /* p-V 図 */
      var gx0=wide? W*0.46 : W*0.52, gy0=H-26, gx1=W-18, gy1=18;
      var X=function(v){ return gx0+(gx1-gx0-12)*v/4.4; }, Y=function(p){ return gy0-(gy0-gy1-12)*p/50; };
      ctx.save(); ctx.strokeStyle="rgba(222,232,245,.08)"; ctx.lineWidth=1; for(var k=10;k<=40;k+=10){ ctx.beginPath(); ctx.moveTo(gx0,Y(k)); ctx.lineTo(gx1-12,Y(k)); ctx.stroke(); } ctx.restore();
      ctx.save(); ctx.strokeStyle=C.wall; ctx.fillStyle=C.wall; ctx.lineWidth=1.4; ctx.beginPath(); ctx.moveTo(gx0,gy0); ctx.lineTo(gx1,gy0); ctx.moveTo(gx0,gy0); ctx.lineTo(gx0,gy1); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(gx1,gy0); ctx.lineTo(gx1-8,gy0-4); ctx.lineTo(gx1-8,gy0+4); ctx.closePath(); ctx.fill();
      ctx.beginPath(); ctx.moveTo(gx0,gy1); ctx.lineTo(gx0-4,gy1+8); ctx.lineTo(gx0+4,gy1+8); ctx.closePath(); ctx.fill(); ctx.restore();
      sym(gx1-14, gy0+16, "V", null, C.dim, 14); sym(gx0+8, gy1+10, "p", null, C.dim, 14);
      var pts=[]; for(var j=0;j<=300;j++) pts.push(ottoState(j/300));
      var loop=pts.filter(function(q){ return q.kind!=="in" && q.kind!=="out"; });
      var done=(u>0.76);
      ctx.save(); ctx.fillStyle="rgba(79,168,255,"+(done? 0.30 : 0.10)+")"; ctx.beginPath(); loop.forEach(function(q,i){ if(i) ctx.lineTo(X(q.V),Y(q.p)); else ctx.moveTo(X(q.V),Y(q.p)); }); ctx.closePath(); ctx.fill();
      ctx.strokeStyle="rgba(159,208,255,.25)"; ctx.lineWidth=1.2; ctx.setLineDash([4,4]); ctx.beginPath(); pts.forEach(function(q,i){ if(i) ctx.lineTo(X(q.V),Y(q.p)); else ctx.moveTo(X(q.V),Y(q.p)); }); ctx.stroke(); ctx.restore();
      ctx.save(); ctx.strokeStyle=C.acc; ctx.lineWidth=2.6; ctx.lineJoin="round"; ctx.beginPath(); var n=Math.round(300*u); for(var i=0;i<=n;i++){ var q=pts[i]; if(i) ctx.lineTo(X(q.V),Y(q.p)); else ctx.moveTo(X(q.V),Y(q.p)); } ctx.stroke(); ctx.restore();
      ctx.save(); ctx.fillStyle="#fff"; ctx.shadowColor=C.acc; ctx.shadowBlur=14; ctx.beginPath(); ctx.arc(X(st.V),Y(st.p),5.5,0,7); ctx.fill(); ctx.restore();
      if(done){ ctx.save(); ctx.font="700 13px "+JP; ctx.fillStyle=C.acc2; ctx.textAlign="center"; var w=sym(X(1.9)-46, Y(9), "W","した", C.acc2, 15); ctx.fillText("＝ 囲まれた面積", X(1.9)+30, Y(9)-4); ctx.restore(); }
    }
    function frame(ts){
      if(!run) return;
      var dt=last? Math.min(0.05,(ts-last)/1000) : 0; last=ts; dt*=rate;
      u=(u+dt/CT)%1; clk+=dt; draw();
      raf=requestAnimationFrame(frame);
    }
    function start(){ if(run||RM||paused) return; run=true; last=0; raf=requestAnimationFrame(frame); }
    function stop(){ run=false; cancelAnimationFrame(raf); }
    setup(); if(RM){ u=0.58; } draw();
    window.__hero={ frame:function(tt){ stop(); u=((tt/CT)%1+1)%1; clk=tt; draw(); }, start:start, stop:stop };
    var rz=0; window.addEventListener("resize", function(){ clearTimeout(rz); rz=setTimeout(function(){ setup(); draw(); }, 120); });
    if("IntersectionObserver" in window){ new IntersectionObserver(function(es){ es.forEach(function(en){ (en.isIntersecting && !document.hidden)? start() : stop(); }); },{threshold:0.05}).observe(cv); }
    else start();
    document.addEventListener("visibilitychange", function(){ if(document.hidden) stop(); else { var r=cv.getBoundingClientRect(); if(r.bottom>0 && r.top<innerHeight) start(); } });
    var ctl=document.querySelector("#hero .stagectl");
    if(ctl){ var pp=ctl.querySelector(".pp"), sl=ctl.querySelector(".slow");
      if(sl){ if(RM) sl.hidden=true; sl.addEventListener("click", function(){ rate=(rate===1?0.3:1); sl.setAttribute("aria-pressed", rate<1?"true":"false"); }); }
      if(pp){ if(RM) pp.hidden=true; pp.addEventListener("click", function(){ paused=!paused; pp.classList.toggle("paused",paused); pp.setAttribute("aria-label", paused?"再生":"一時停止"); if(paused){ stop(); draw(); } else start(); }); }
    }
    document.addEventListener("click", function(ev){ if(ev.target.closest && ev.target.closest("button.b.play")) stop(); }, true);
  }
  function syncRange(el){ var mn=parseFloat(el.min)||0, mx=parseFloat(el.max), v=parseFloat(el.value);
    var p=(isFinite(mx)&&mx>mn)? (v-mn)/(mx-mn)*100 : 0, s=p.toFixed(1)+"%"; if(el._p!==s){ el._p=s; el.style.setProperty("--p",s); } }
  function initRanges(){
    document.addEventListener("input", function(ev){ if(ev.target && ev.target.type==="range") syncRange(ev.target); }, true);
    setInterval(function(){ if(document.hidden) return; document.querySelectorAll(".mode.on input[type=range]").forEach(syncRange); }, 150);
  }
  function initProgress(){
    var nav=document.getElementById("tabs"); if(!nav) return; var pend=false;
    var upd=function(){ pend=false; var h=document.documentElement, max=h.scrollHeight-innerHeight; nav.style.setProperty("--prog", max>0? Math.min(1,Math.max(0,scrollY/max)).toFixed(4) : 0); };
    window.addEventListener("scroll", function(){ if(!pend){ pend=true; requestAnimationFrame(upd); } }, {passive:true});
    window.addEventListener("resize", upd); upd();
  }
  function initIdeas(){
    document.querySelectorAll("#hero .ideas a").forEach(function(a){
      a.addEventListener("click", function(ev){ ev.preventDefault(); var id=a.getAttribute("href").slice(1);
        var mm=id.match(/^(\d)-(\d)$/), sid=null;
        Object.keys(DEFS).forEach(function(k){ if(mm && DEFS[k].mode===parseInt(mm[1],10)-1 && DEFS[k].num===parseInt(mm[2],10)) sid=k; });
        if(sid) gotoSec(sid); });
    });
  }
  function initDecorate(){
    var orig=activateMode;
    var showTab=function(){ var row=document.querySelector("#tabs .tabs-in"), on=row&&row.querySelector(".tab.on"); if(!on||row.scrollWidth<=row.clientWidth) return;
      var l=on.offsetLeft-24, r=on.offsetLeft+on.offsetWidth+24; if(l<row.scrollLeft) row.scrollLeft=l; else if(r>row.scrollLeft+row.clientWidth) row.scrollLeft=r-row.clientWidth; };
    var cur=function(){ document.querySelectorAll("#tabs .tab").forEach(function(b){ if(b.classList.contains("on")) b.setAttribute("aria-current","page"); else b.removeAttribute("aria-current"); }); };
    activateMode=function(id){ var r=orig.apply(this,arguments); showTab(); cur(); return r; };
    showTab(); cur();
  }
  function initStuck(){
    var hero=document.getElementById("hero"), nav=document.getElementById("tabs"); if(!hero||!nav||!("IntersectionObserver" in window)) return;
    new IntersectionObserver(function(es){ es.forEach(function(en){ nav.classList.toggle("stuck", !en.isIntersecting); }); },{threshold:0}).observe(hero);
  }
  function initFooter(){
    var f=document.querySelector("#wrap footer"); if(!f) return;
    document.body.appendChild(f);
    var items=MODES.map(function(m,i){ return '<li><a href="#'+m.id+'" data-mode="'+m.id+'"><b>'+CIRC[i]+'</b>'+m.name+'</a></li>'; }).join("");
    f.innerHTML='<div class="ft-in"><p class="ft-mark">Gases and Thermodynamics<span>気体と熱力学 〜 気体分子の運動から熱機関まで 〜</span></p><ul class="ft-nav">'+items+'</ul>'+
      '<div class="ft-base"><span><a class="ft-home" href="'+SITE_HOME+'">⌂ 楽楽（らくらく）高校物理 トップページ</a>　／　高校物理 ・ 力学</span><span class="ft-r"><button type="button" class="ft-pages">ほかのページ一覧</button><a href="#top" class="ft-top">▲ ページの一番上へ</a></span></div></div>';
    f.querySelectorAll("a[data-mode]").forEach(function(a){ a.addEventListener("click", function(ev){ ev.preventDefault(); var id=a.dataset.mode;
      activateMode(id); history.replaceState(null,"","#"+id); window.scrollTo({top:contentTop(), behavior:"auto"}); }); });
    var fp=f.querySelector(".ft-pages"); if(fp) fp.addEventListener("click", function(){ if(window.SITENAV) window.SITENAV.open(); });
    var tp=f.querySelector(".ft-top"); if(tp) tp.addEventListener("click", function(ev){ ev.preventDefault(); window.scrollTo({top:0, behavior:"auto"}); });
  }
  document.addEventListener("DOMContentLoaded", function(){ initFooter(); initDecorate(); initStage(); initRanges(); initProgress(); initIdeas(); initStuck(); });
})();
