/* =========================================================================
   ①-1 シリンダーに閉じ込められた気体（第2回で作り直し）と ①-5 ボイル・シャルルの法則
   装置の表し方は shin-phys.github.io/thermo_dynamics を参考に（① 準備 ② 操作）。
   ========================================================================= */
/* 準備と操作のボタン（①-1・①-5 で共通）。アイコンは小さな SVG */
var ICON = {
  lock:'<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M6 9V6.5a4 4 0 0 1 8 0V9" fill="none" stroke="currentColor" stroke-width="2"/><rect x="4" y="9" width="12" height="9" rx="2" fill="#e0a526" stroke="#7a5a10"/></svg>',
  unlock:'<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M10 9V6.5a4 4 0 0 1 8 0" fill="none" stroke="currentColor" stroke-width="2"/><rect x="2" y="9" width="12" height="9" rx="2" fill="#e0a526" stroke="#7a5a10"/></svg>',
  hand:'<svg viewBox="0 0 20 20" aria-hidden="true"><ellipse cx="7" cy="10" rx="5.5" ry="5" fill="#f6d9bd" stroke="#a97b4c"/><path d="M11 7h7v6h-7" fill="#f6d9bd" stroke="#a97b4c"/></svg>',
  ins:'<svg viewBox="0 0 20 20" aria-hidden="true"><rect x="2" y="2" width="16" height="16" rx="2" fill="#d9b98c" stroke="#7a5230"/><path d="M2 12 12 2M2 18 18 2M8 18 18 8" stroke="#8a5a2b" stroke-width="1.4"/></svg>',
  bath:'<svg viewBox="0 0 20 20" aria-hidden="true"><rect x="2" y="5" width="16" height="13" rx="2" fill="#bcd8f2" stroke="#3f7fc0"/><path d="M2 8q2-2 4 0t4 0 4 0 4 0" fill="none" stroke="#2f6fb0" stroke-width="1.6"/></svg>',
  fire:'<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M10 1c1 4 6 6 6 11a6 6 0 0 1-12 0c0-3 2-4 3-6 0 2 1 3 2 3 0-3-1-5 1-8z" fill="#ff6a2a"/><path d="M10 10c1 2 3 3 3 5a3 3 0 0 1-6 0c0-2 2-3 3-5z" fill="#ffd25a"/></svg>',
  ice:'<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M5 6l5-3 5 3v8l-5 3-5-3z" fill="#d6ecfb" stroke="#2f8fe8" stroke-width="1.4"/><path d="M5 6l5 3 5-3M10 9v8" fill="none" stroke="#2f8fe8" stroke-width="1.2"/></svg>'
};
function H_prep(withHand){
  return '<div class="prepbox"><div class="pgrp"><span class="ph">① 準備</span>'+
    '<span class="pl2">ピストン</span><span class="seg2" data-g="pis"><button type="button" class="b pb" data-v="lock">'+ICON.lock+'固定</button><button type="button" class="b pb" data-v="free">'+ICON.unlock+'自由</button>'+
      (withHand? '<button type="button" class="b pb" data-v="hand">'+ICON.hand+'手で自由に動かす</button>' : '')+'</span>'+
    '<span class="pl2">容器</span><span class="seg2" data-g="cont"><button type="button" class="b pb" data-v="ins">'+ICON.ins+'断熱材</button><button type="button" class="b pb" data-v="bath">'+ICON.bath+'恒温槽</button></span></div>'+
    '<div class="pgrp"><span class="ph">② 操作</span><button type="button" class="b hbtn" data-h="1">'+ICON.fire+'加熱する</button><button type="button" class="b hbtn cold" data-h="-1">'+ICON.ice+'冷却する</button></div></div>';
}
/* 準備のボタンの選択を表示に反映 */
function syncPrep(sec, pis, cont){
  sec.querySelectorAll('.seg2[data-g="pis"] .pb').forEach(function(b){ var on=(b.dataset.v===pis); b.classList.toggle("on",on); b.setAttribute("aria-pressed",on); });
  sec.querySelectorAll('.seg2[data-g="cont"] .pb').forEach(function(b){ var on=(b.dataset.v===cont); b.classList.toggle("on",on); b.setAttribute("aria-pressed",on); });
}

/* ---------------- 3 次元の縦のシリンダー（①-1 の「３次元表示」） ----------------
   cx …軸の画面上の x、yB …閉じた端（底）の内側の面の y、R …内側の半径、L …気体の高さ、Lm …シリンダーの高さ */
function drawCyl3D(c, o){
  var cx=o.cx, yB=o.yB, R=o.R, L=o.L, Lm=o.Lm, k=0.32, ry=R*k, wt=(o.cont==="ins")? 13 : 8, pt=o.pt||14, yP=yB-L, yT=yB-Lm;
  var ell=function(y, r, fill, stroke, half){ c.beginPath(); if(half===1) c.ellipse(cx,y,r,r*k,0,0,Math.PI); else if(half===-1) c.ellipse(cx,y,r,r*k,0,Math.PI,2*Math.PI); else c.ellipse(cx,y,r,r*k,0,0,7);
    if(fill){ c.fillStyle=fill; c.fill(); } if(stroke){ c.strokeStyle=stroke; c.stroke(); } };
  c.save(); c.lineWidth=1.3;
  /* 恒温槽（うしろの水） */
  if(o.cont==="bath"){ var Rb=R+wt+22, yW=yB-Lm*0.80;
    c.fillStyle="rgba(84,156,224,.20)"; c.fillRect(cx-Rb, yW, 2*Rb, yB+wt+14-yW); ell(yB+wt+14, Rb, "rgba(84,156,224,.20)", "#3f7fc0", 1);
    c.strokeStyle="#3f7fc0"; c.beginPath(); c.moveTo(cx-Rb,yW); c.lineTo(cx-Rb,yB+wt+14); c.moveTo(cx+Rb,yW); c.lineTo(cx+Rb,yB+wt+14); c.stroke();
    ell(yW, Rb, "rgba(84,156,224,.30)", "#2f6fb0"); }
  /* うしろの壁（内側） */
  var wallF=(o.cont==="ins")? "#ead2ac" : "#e3e7ec";
  c.fillStyle=wallF; c.fillRect(cx-R, yT, 2*R, yB-yT); ell(yT, R, null, "#5b636e", -1);
  /* 底 */
  ell(yB, R, (o.cont==="ins")? "#d9b98c" : "#cfd5dc", "#5b636e");
  /* 気体の色 */
  if(L>2){ c.fillStyle=gasTint(o.T, 0.30); c.fillRect(cx-R, yP, 2*R, L); ell(yB, R, gasTint(o.T,0.30)); }
  /* ヒーター（底の上の輪） */
  if(o.heater){ var hc=(o.heat>0)? "#ff5a2a" : (o.heat<0)? "#2f8fe8" : "#7a828c"; c.save(); if(o.heat){ c.shadowColor=hc; c.shadowBlur=12; }
    c.strokeStyle=hc; c.lineWidth=2.6; c.beginPath(); for(var a=0;a<=60;a++){ var th=a/60*Math.PI*2*3, rr=R*0.62, x=cx+rr*Math.cos(a/60*Math.PI*2), y=yB-6-ry*0.62*Math.sin(a/60*Math.PI*2)-3*Math.sin(th*2); if(a) c.lineTo(x,y); else c.moveTo(x,y); } c.stroke(); c.restore();
    if(o.heat && L>60){ var ph=((o.clk||0)*0.9)%1; if(o.heat>0) heatFlow(c, cx+R*0.75, yB-14, cx+R*0.75, Math.max(yP+8, yB-58), 10, ph, {k:0.75}); else heatFlow(c, cx+R*0.75, Math.max(yP+8, yB-58), cx+R*0.75, yB-14, 10, ph, {k:0.75}); } }
  /* 分子（奥から順に） */
  if(o.gas && L>6){ var r=o.r||4.2, ms=o.gas.m.map(function(q){ var u=2*q.y-1, w=2*(q.z===undefined? 0.5 : q.z)-1, d=Math.hypot(u,w); if(d>0.92){ u*=0.92/d; w*=0.92/d; }
      return {X:cx+u*R, Y:yB-r-(L-2*r)*q.x-w*ry, w:w}; }).sort(function(a,b){ return b.w-a.w; });
    ms.forEach(function(m){ ball(c, m.X, m.Y, r*(1-0.12*m.w), 0, heatCol(gasLv(o.T))); }); }
  /* ピストン（円板） */
  var pc=pistonCols(o.pr);
  c.fillStyle=pc[1]; c.fillRect(cx-R, yP-pt, 2*R, pt); ell(yP, R, pc[1], "#3a4654", 1);
  var pg=c.createLinearGradient(cx-R,0,cx+R,0); pg.addColorStop(0,pc[1]); pg.addColorStop(0.45,pc[0]); pg.addColorStop(1,pc[1]);
  c.fillStyle=pg; c.fillRect(cx-R, yP-pt, 2*R, pt); ell(yP, R, null, "#3a4654", 1); ell(yP-pt, R, pc[0], "#3a4654");
  c.strokeStyle="#3a4654"; c.beginPath(); c.moveTo(cx-R,yP-pt); c.lineTo(cx-R,yP); c.moveTo(cx+R,yP-pt); c.lineTo(cx+R,yP); c.stroke();
  if(o.rod){ c.fillStyle="#d8d2c4"; c.strokeStyle="#8b8172"; rrect(c, cx-4, yP-pt-o.rod, 8, o.rod, 3); c.fill(); c.stroke(); }
  /* 前の壁（断熱材なら厚い茶色、ふつうは透明の筒） */
  if(o.cont==="ins"){ c.save(); c.globalAlpha=0.55; c.fillStyle="#d9b98c"; c.beginPath(); c.ellipse(cx,yB,R+wt,(R+wt)*k,0,0,Math.PI); c.lineTo(cx-R-wt,yT); c.ellipse(cx,yT,R+wt,(R+wt)*k,0,Math.PI,0,true); c.closePath(); c.fill(); c.restore();
    c.save(); c.beginPath(); c.rect(cx-R-wt,yT,wt,yB-yT+ry); c.rect(cx+R,yT,wt,yB-yT+ry); c.clip(); c.strokeStyle="#8a5a2b"; c.lineWidth=1; for(var y2=yT-30;y2<yB+30;y2+=7){ c.beginPath(); c.moveTo(cx-R-wt,y2+wt); c.lineTo(cx-R,y2); c.moveTo(cx+R,y2+wt); c.lineTo(cx+R+wt,y2); c.stroke(); } c.restore();
    c.strokeStyle="#7a5230"; c.beginPath(); c.moveTo(cx-R-wt,yT); c.lineTo(cx-R-wt,yB); c.moveTo(cx+R+wt,yT); c.lineTo(cx+R+wt,yB); c.stroke(); ell(yB, R+wt, null, "#7a5230", 1); ell(yT, R+wt, null, "#7a5230"); }
  c.strokeStyle="#5b636e"; c.lineWidth=1.4; c.beginPath(); c.moveTo(cx-R,yT); c.lineTo(cx-R,yB); c.moveTo(cx+R,yT); c.lineTo(cx+R,yB); c.stroke();
  ell(yB, R, null, "#5b636e", 1); ell(yT, R, null, "#5b636e", 1);
  c.restore();
  return {rodEnd:[cx, yP-pt-(o.rod||0)], yP:yP};
}

/* ---------------- ①-1 シリンダーに閉じ込められた気体 ----------------
   縦のシリンダー（開いた端が上）。準備：ピストン 固定／自由、容器 断熱材／恒温槽。操作：加熱・冷却、ポンプ、弁。
   状態：n〔mol〕、T〔K〕、V〔×10⁻² m³〕。p＝nRT/V。自由のとき p＝1.0×10⁵ Pa（下の止め具に乗っているときを除く） */
var S11 = {
  VMAX:6.0, VMIN:0.5, PF:1.0, MPM:20, G:5/3,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    var ctr=sec.querySelector(".ctrls");
    ctr.insertAdjacentHTML("afterbegin", H_prep(false).replace('<div class="pgrp"><span class="ph">② 操作</span>',
      '<div class="pgrp"><span class="ph">② 操作</span><span class="pumpcol"><button class="b play" type="button" id="bPlay">▶ ポンプを押す</button><button class="b valve" type="button">弁を開く</button></span>')+
      panelHTML(["p","V","T","n"]));
    var rs=sec.querySelector(".rsrow"); sec.querySelector(".prepbox .pgrp:last-child").appendChild(rs.querySelector(".resetall")); rs.remove();
    this.cv.parentElement.insertAdjacentHTML("beforeend", '<button type="button" class="b v3d glow">３次元表示</button>');
    this.b3=this.cv.parentElement.querySelector(".v3d");
    this.b3.addEventListener("click", function(){ self.d3=!self.d3; self.b3.classList.remove("glow"); self.b3.classList.toggle("on", self.d3); self.b3.textContent=self.d3? "２次元表示" : "３次元表示"; self.draw(); });
    this.gas=new Gas(0, 11); this.clk=0;
    this.reset0();
    sec.querySelector("#bPlay").addEventListener("click", function(){ self.pump(1); });
    sec.querySelector(".valve").addEventListener("click", function(){ self.pump(-1); });
    sec.querySelectorAll(".hbtn").forEach(function(b){ b.addEventListener("click", function(){ self.heat(parseFloat(b.dataset.h)); }); });
    sec.querySelectorAll('.seg2 .pb').forEach(function(b){ b.addEventListener("click", function(){ var g=b.parentElement.dataset.g; if(g==="pis") self.setPis(b.dataset.v); else { self.cont=b.dataset.v; self.note=(self.cont==="bath")? "恒温槽に入れた。気体の温度は恒温槽の温度（"+Math.round(self.T)+" K）に保たれる。" : "断熱材で囲んだ。外との熱の出入りはない。"; } syncPrep(sec, self.pis, self.cont); self.draw(); }); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.reset0(); self.d3=false; self.b3.classList.add("glow"); self.b3.classList.remove("on"); self.b3.textContent="３次元表示"; self.draw(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    idleLoop(sec, function(dt){ self.tick(dt); self.draw(); });
    this.draw();
  },
  reset0:function(){ this.n=0; this.T=300; this.V=2.5; this.pis="lock"; this.cont="ins"; this.fr={n:0,T:300,V:2.5}; this.tg={n:0,T:300,V:2.5}; this.tau=1;
    this.gas.setN(0); this.pumpT=-1; this.valveT=-1; this.heatDir=0; this.hT=0; this.note="まだ分子が入っていない。「ポンプを押す」で分子を入れよう。"; syncPrep(this.sec, this.pis, this.cont); this.updCard(); },
  p:function(n,T,V){ return (n>0 && V>0)? n*RGAS*T/(V*1e-2)/1e5 : 0; },
  Vfree:function(n,T){ return Math.max(this.VMIN, n*RGAS*T/(this.PF*1e5)*100); },
  busy:function(){ return this.tau<1; },
  go:function(n,T,V,why){ if(this.busy()) return false;
    if(V>this.VMAX*0.98 || this.p(n,T,V)>4.0 || T<150 || T>600){ this.note="これ以上は変えられない（シリンダーに収まらない、または範囲の外）。"; this.draw(); return false; }
    this.fr={n:this.n,T:this.T,V:this.V}; this.tg={n:n,T:T,V:V}; this.tau=0; this.note=why; return true; },
  pump:function(d){ var g=this.tg, n=Math.round((g.n+0.2*d)*10)/10;
    if(n<0 || n>2.0){ this.note=(d>0)? "これ以上は入れられない（2.0 mol まで）。" : "もう分子は残っていない。"; this.draw(); return; }
    var V=(this.pis==="free")? this.Vfree(n,g.T) : g.V;
    var why=(d>0? "ポンプで分子を入れた（"+tex("n")+" が増える）。" : "弁を開いて分子を出した（"+tex("n")+" が減る）。")+(this.pis==="free"? "ピストンが自由に動くので、圧力はそのまま、体積が変わる。" : "ピストンは固定なので、体積はそのまま、圧力が変わる。");
    if(this.go(n, g.T, V, why)){ if(d>0) this.pumpT=0; else this.valveT=0; } },
  heat:function(d){ var g=this.tg;
    if(g.n<=0){ this.note="まず、ポンプで分子を入れよう。"; this.draw(); return; }
    if(this.cont==="bath"){ this.note="恒温槽に入れているので、ヒーターの熱は恒温槽に逃げ（冷却しても恒温槽から熱が入り）、温度は変わらない。「断熱材」にしてから試そう。"; this.heatDir=d; this.hT=0; this.draw(); return; }
    var T=g.T+50*d, V=(this.pis==="free")? this.Vfree(g.n,T) : g.V;
    var why=(d>0? "加熱した。" : "冷却した。")+(this.pis==="free"? "ピストンが自由に動くので圧力は変わらず、温度と体積が"+(d>0? "増える（定圧変化）。" : "減る（定圧変化）。") : "ピストンが固定なので体積は変わらず、温度と圧力が"+(d>0? "上がる（定積変化）。" : "下がる（定積変化）。"));
    if(this.go(g.n, T, V, why)){ this.heatDir=d; this.hT=0; } },
  setPis:function(v){ if(this.busy()) return; var g=this.tg; this.pis=v;
    if(v==="lock"){ this.note="ピストンを固定した。体積は変わらない。"; return; }
    if(g.n<=0){ this.go(0, g.T, this.VMIN, "ピストンを自由にした。中に気体がないので、ピストンは下の止め具まで下がる。"); return; }
    var p1=this.p(g.n,g.T,g.V), V2, T2=g.T;
    if(this.cont==="ins"){ V2=g.V*Math.pow(p1/this.PF, 1/this.G); T2=this.PF*1e5*V2*1e-2/(g.n*RGAS); if(V2<this.VMIN){ V2=this.VMIN; T2=g.T*Math.pow(g.V/V2, this.G-1); } }
    else V2=this.Vfree(g.n, g.T);
    this.go(g.n, Math.round(T2), V2, "ピストンを自由にした。ピストンは、気体の圧力が大気圧（1.0×10⁵ Pa）になる位置までゆっくり動いて止まる"+(this.cont==="ins"? "（断熱材で囲んでいるので温度も変わる）。" : "（恒温槽で温度は一定）。")); },
  tick:function(dt){
    var g=this.tg, a=this.fr, run=this.tau<1;
    this.tau=Math.min(1,this.tau+dt/0.9); var e=this.tau*this.tau*(3-2*this.tau);
    this.n=a.n+(g.n-a.n)*e; this.T=a.T+(g.T-a.T)*e; this.V=a.V+(g.V-a.V)*e;
    var sg=function(d,eps){ return run && Math.abs(d)>eps? Math.sign(d) : 0; };
    this.dir={n:sg(g.n-a.n,1e-4), T:sg(g.T-a.T,0.1), V:sg(g.V-a.V,1e-4), p:sg(this.p(g.n,g.T,g.V)-this.p(a.n,a.T,a.V),1e-4)};
    var cnt=Math.round(this.n*this.MPM), old=this.gas.m.length; this.gas.setN(cnt);
    for(var i=old;i<cnt;i++){ var q=this.gas.m[i]; q.x=0.05; q.y=0.04; q.vx=Math.abs(q.vx)+0.3; }
    if(this.pumpT>=0){ this.pumpT+=dt; if(this.pumpT>1.0) this.pumpT=-1; }
    if(this.valveT>=0){ this.valveT+=dt; if(this.valveT>1.0) this.valveT=-1; }
    if(this.heatDir){ this.hT+=dt; if(this.hT>1.4 && !this.busy()) this.heatDir=0; }
    this.clk+=dt;
    var gg=this.geo; if(gg) this.gas.step(dt, Math.max(1,gg.L), gg.h, 55*Math.sqrt(this.T/300), 4.2);
    this.updCard();
  },
  /* 右の列のカード：状態方程式に、いまの値を入れて見せる */
  updCard:function(){ var el=this.sec.querySelector(".eqlive"); if(!el) return;
    var p=this.p(this.n,this.T,this.V), pv=p*1e5*this.V*1e-2, nrt=this.n*RGAS*this.T;
    var h='<div class="eqrow"><span class="el">'+tex("pV")+'</span>＝ <b>'+p.toFixed(2)+'</b>×10⁵ Pa × <b>'+this.V.toFixed(2)+'</b>×10⁻² m³ ＝ <b class="ev">'+Math.round(pv)+'</b> J</div>'+
          '<div class="eqrow"><span class="el">'+tex("nRT")+'</span>＝ <b>'+this.n.toFixed(2)+'</b> mol × 8.31 × <b>'+Math.round(this.T)+'</b> K ＝ <b class="ev">'+Math.round(nrt)+'</b> J</div>';
    if(this._ch!==h){ el.innerHTML=h; this._ch=h; } },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return clamp(W*0.62, 360, 440); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var narrow=W<560, h=narrow? 96 : 116, cx=narrow? W*0.56 : W*0.50, yB=H-46, Lmax=H-150, L=Lmax*this.V/this.VMAX, rod=46;
    var p=this.p(this.n,this.T,this.V), pr=clamp(p/3.0,0,1), lock=(this.pis==="lock"), bath=(this.cont==="bath");
    this.geo={L:L, h:h};
    /* 床 */
    ground(c, 8, W-8, yB+(bath? 40 : 22));
    var hx=cx-h/2-(bath? 40 : 20), px=Math.max(36, hx-(narrow? 52 : 78));
    /* ポンプ（左）：中に分子。押すと取っ手が下がり、分子がホースを通ってシリンダーへ */
    var pd=(this.pumpT>=0)? Math.sin(Math.PI*clamp(this.pumpT/0.9,0,1)) : 0, pt0=yB-170, pb0=yB+6, bw=24;
    c.save(); c.fillStyle="#eef2f6"; c.strokeStyle="#5b636e"; c.lineWidth=1.3; rrect(c, px-bw/2, pt0+14, bw, pb0-pt0-14, 4); c.fill(); c.stroke();
    var py=pt0+18+pd*60; c.fillStyle="#7f95ab"; c.fillRect(px-bw/2+2, py, bw-4, 7);
    c.fillStyle="#7a828c"; c.fillRect(px-2, pt0-16+pd*60, 4, py-(pt0-16+pd*60)); c.fillStyle="#3a414c"; rrect(c, px-22, pt0-22+pd*60, 44, 8, 3); c.fill();
    var R0=rng(5); for(var k=0;k<7;k++){ var mx=px-bw/2+5+(bw-10)*((R0()+this.clk*0.13*(k+1))%1), my=py+12+(pb0-py-18)*((R0()+this.clk*0.07*(k+2))%1); ball(c, mx, my, 3.2, 0, heatCol(gasLv(300))); }
    /* ホース：ポンプの下 → シリンダーの底の横 */
    var hy=yB-10, hs=[[px,pb0],[px,pb0+10],[hx-6,pb0+10],[hx-6,hy],[cx-h/2,hy]];
    c.strokeStyle="#5b636e"; c.lineWidth=7; c.lineJoin="round"; c.beginPath(); hs.forEach(function(q,i){ if(i) c.lineTo(q[0],q[1]); else c.moveTo(q[0],q[1]); }); c.stroke();
    c.strokeStyle="#dfe3e8"; c.lineWidth=4; c.stroke(); c.restore();
    if(this.pumpT>=0){ var tt=clamp(this.pumpT/0.9,0,1); for(var j=0;j<4;j++){ var u=clamp(tt*1.4-j*0.12,0,1), seg=[0.0,0.08,0.55,0.80,1.0], m=0; while(m<3 && u>seg[m+1]) m++; var ff=(u-seg[m])/(seg[m+1]-seg[m]||1);
      ball(c, hs[m][0]+(hs[m+1][0]-hs[m][0])*ff, hs[m][1]+(hs[m+1][1]-hs[m][1])*ff, 3.2, 0, heatCol(gasLv(300))); } }
    T(c, "ポンプ", px, pt0-34, {size:11.5, bold:true, col:COL.sub, align:"center"});
    /* 弁（右の壁の下） */
    var vx=cx+h/2+(this.cont==="ins"? 13 : 8);
    c.save(); c.strokeStyle="#5b636e"; c.lineWidth=6; c.beginPath(); c.moveTo(vx, yB-12); c.lineTo(vx+26, yB-12); c.stroke(); c.strokeStyle="#dfe3e8"; c.lineWidth=3; c.stroke();
    c.fillStyle=(this.valveT>=0)? "#1c8f4a" : "#c0392b"; c.beginPath(); c.arc(vx+14, yB-12, 5.5, 0, 7); c.fill(); c.restore();
    T(c, "弁", vx+14, yB+4, {size:10.5, bold:true, col:COL.sub, align:"center"});
    if(this.valveT>=0){ var tv=clamp(this.valveT/0.9,0,1); for(var j2=0;j2<4;j2++){ var u2=clamp(tv*1.5-j2*0.15,0,1); ball(c, vx+28+u2*40, yB-12-u2*16*Math.sin(j2), 3.2, 0, heatCol(gasLv(this.T))); } }
    /* シリンダー本体 */
    var g;
    if(this.d3) g=drawCyl3D(c, {cx:cx, yB:yB, R:h/2, L:L, Lm:Lmax, T:this.T, gas:this.gas, r:4.2, cont:this.cont, heater:true, heat:this.heatDir, clk:this.clk, pr:pr, rod:rod});
    else g=drawCylinder(c, new CylFrame(cx, yB, "up"), {L:L, Lmax:Lmax, h:h, T:this.T, gas:this.gas, r:4.2, pt:14, rod:rod, cont:this.cont, heater:true, heat:this.heatDir, clk:this.clk, lock:lock, pr:pr, thermo:true, thLen:50, noGas:this.n<=0.004, bathT:this.T});
    if(this.d3){ /* 3 次元でも温度計（左の壁から） */
      c.save(); c.translate(cx-h/2-6, yB-26); c.rotate(-Math.PI/2); thermometer(c, 0, 26, -58, this.T, 100, 700, {noVal:true, noNum:true, tw:8, br:6}); c.restore();
      T(c, Math.round(this.T)+" K", cx-h/2-70, yB-40, {size:12, bold:true, col:"#a03028", align:"right", halo:true});
      if(lock) padlock(c, cx+h/2+18, g.yP-20, true, 0.85);
      if(bath) T(c, "恒温槽 "+Math.round(this.T)+" K", cx-h/2-14, yB+30, {size:11, bold:true, col:"#1f5f99", halo:true});
      if(this.cont==="ins") T(c, "断熱材", cx, yB+26, {size:10.5, bold:true, col:"#7a5230", align:"center", halo:true}); }
    /* ヒーターの名前 */
    var hlx=Math.min(cx+h/2+30, W-118);
    T(c, "ヒーター（冷却器）", hlx, yB-34+(hlx<cx+h/2+30? 16 : 0), {size:10.5, bold:true, col:(this.heatDir>0? "#d2401a" : this.heatDir<0? "#1f6fb2" : COL.sub), halo:true});
    c.save(); c.strokeStyle="rgba(90,99,110,.55)"; c.lineWidth=1; c.beginPath(); c.moveTo(cx+h/2+28, yB-34); c.lineTo(cx+h*0.1, yB-12); c.stroke(); c.restore();
    /* 押す前：名前を書いておく */
    if(this.n<=0.004){ var yp=yB-L-7;
      T(c, "シリンダー", cx-h/2-14, yB-Lmax*0.70, {size:13, bold:true, col:"#3a414c", align:"right", halo:true});
      c.save(); c.strokeStyle="#3a414c"; c.lineWidth=1.2; c.beginPath(); c.moveTo(cx-h/2-12, yB-Lmax*0.70); c.lineTo(cx-h/2-2, yB-Lmax*0.66); c.stroke(); c.restore();
      T(c, "ピストン", cx+h/2+24, yp, {size:13, bold:true, col:"#3a4654", halo:true});
      c.save(); c.strokeStyle="#3a4654"; c.lineWidth=1.2; c.beginPath(); c.moveTo(cx+h/2+22, yp); c.lineTo(cx+h/2-6, yp); c.stroke(); c.restore(); }
    if(this.pis==="free") T(c, "大気（1.0×10⁵ Pa）", cx+h/2+24, yB-Lmax+8, {size:11, bold:true, col:COLG.atm, halo:true});
    notebook(c,W,H);
    var nz=this.n>0.004, d=this.dir||{};
    setPanel(this.sec, { p:[nz? p.toFixed(2) : "0.00", d.p||0], V:[this.V.toFixed(2), d.V||0], T:[String(Math.round(this.T)), d.T||0], n:[this.n.toFixed(2), d.n||0] });
    var mh='<span>'+this.note+'</span>';
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};

/* ---------------- ①-5 ボイル・シャルルの法則 ----------------
   1.0 mol の単原子分子。変化：温度一定（ボイル）・圧力一定（シャルル）・自由に動かす。
   ピストン 固定／自由／手で自由に動かす（ドラッグ）、容器 断熱材／恒温槽。右に p-V 図（通った点を線で残す） */
var S15 = {
  n:1.0, PF:1.0, G:5/3, VMAX:6.0,
  MODES:{boyle:{pis:"hand", cont:"bath"}, charles:{pis:"free", cont:"ins"}, free:{pis:"hand", cont:"ins"}},
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    var ctr=sec.querySelector(".ctrls"); ctr.insertAdjacentHTML("beforeend", H_prep(true)+panelHTML(["p","V","T"]));
    var rs=sec.querySelector(".rsrow"); sec.querySelector(".prepbox .pgrp:last-child").appendChild(rs.querySelector(".resetall")); rs.remove();
    this.gas=new Gas(20, 15); this.clk=0;
    this.sm=wireSeg(sec,"chg",function(v){ self.setMode(v); });
    sec.querySelectorAll('.seg2 .pb').forEach(function(b){ b.addEventListener("click", function(){ var g=b.parentElement.dataset.g; if(g==="pis") self.setPis(b.dataset.v); else { self.cont=b.dataset.v; self.note=(self.cont==="bath")? "恒温槽に入れた。温度は一定に保たれる。" : "断熱材で囲んだ。熱の出入りはない。"; } syncPrep(sec,self.pis,self.cont); self.draw(); }); });
    sec.querySelectorAll(".hbtn").forEach(function(b){ b.addEventListener("click", function(){ self.heat(parseFloat(b.dataset.h)); }); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.sm.set("free"); self.reset0("free"); self.draw(); });
    /* ピストンのドラッグ（手で自由に動かすときだけ。当たり判定はピストン・棒・手） */
    var drag=false, pos=function(ev){ var r=self.cv.getBoundingClientRect(), e=ev.touches? ev.touches[0] : ev; return [e.clientX-r.left, e.clientY-r.top]; };
    var down=function(ev){ if(self.pis!=="hand" || !self.g) return; var q=pos(ev), g=self.g; if(Math.abs(q[0]-g.cx)<g.hw+30 && q[1]>g.yTop-g.rod-30 && q[1]<g.yTop+22){ drag=true; self.dy=q[1]-g.yTop; ev.preventDefault(); } };
    var move=function(ev){ var q=pos(ev), g=self.g; if(!g) return; if(!drag){ self.cv.style.cursor=(self.pis==="hand" && Math.abs(q[0]-g.cx)<g.hw+30 && q[1]>g.yTop-g.rod-30 && q[1]<g.yTop+22)? "ns-resize" : ""; return; }
      ev.preventDefault(); var L=g.yB-(q[1]-self.dy), V=clamp(L/g.Lmax*self.VMAX, 0.8, self.VMAX*0.95); self.dragTo(V); };
    var up=function(){ drag=false; };
    this.cv.addEventListener("mousedown", down); window.addEventListener("mousemove", move); window.addEventListener("mouseup", up);
    this.cv.addEventListener("touchstart", down, {passive:false}); window.addEventListener("touchmove", function(ev){ if(drag) move(ev); }, {passive:false}); window.addEventListener("touchend", up);
    this.reset0("free");
    onResize(this.cv.parentElement, function(){ self.draw(); });
    idleLoop(sec, function(dt){ self.tick(dt); self.draw(); });
    this.draw();
  },
  reset0:function(mode){ this.V=2.5; this.T=300.8; this.tgT=this.T; this.tgV=this.V; this.heatDir=0; this.trail=[[this.V,this.p()]]; this.setMode(mode||"free", true); },
  p:function(V,T){ V=(V===undefined)? this.V : V; T=(T===undefined)? this.T : T; return this.n*RGAS*T/(V*1e-2)/1e5; },
  setMode:function(m, quiet){ var o=this.MODES[m]; this.mode=m; this.pis=o.pis; this.cont=o.cont; syncPrep(this.sec, this.pis, this.cont);
    if(this.pis==="free") this.toFree();
    this.note={boyle:"恒温槽に入れて、ピストンを手で動かす。<b>ピストンをドラッグ</b>して体積を変えよう（温度一定）。", charles:"ピストンは自由（圧力一定）。断熱材で囲み、中のヒーターで<b>加熱・冷却</b>しよう。", free:"ピストンを手で動かす（断熱材で囲んでいる）。<b>ピストンをドラッグ</b>したり、加熱・冷却したりしてみよう。"}[m];
    this.trail=[[this.V,this.p()]]; this.draw(); },
  setPis:function(v){ this.pis=v; if(v==="free") this.toFree(); this.note={lock:"ピストンを固定した。", free:"ピストンを自由にした。気体の圧力は大気圧と同じになる。", hand:"ピストンを手で動かす。ピストンをドラッグしよう。"}[v]; },
  toFree:function(){ var p1=this.p(); if(Math.abs(p1-this.PF)<1e-3) return;
    var V2=(this.cont==="ins")? this.V*Math.pow(p1/this.PF,1/this.G) : this.V*p1/this.PF; V2=clamp(V2,0.8,this.VMAX*0.95);
    this.tgV=V2; this.tgT=(this.cont==="ins")? this.PF*1e5*V2*1e-2/(this.n*RGAS) : this.T; },
  dragTo:function(V){ var V0=this.V;
    if(this.cont==="bath"){ this.V=V; }
    else { this.T=clamp(this.T*Math.pow(V0/V, this.G-1), 80, 900); this.V=V; }
    this.tgV=this.V; this.tgT=this.T; this.addTrail();
    this.note=(this.cont==="bath")? "恒温槽の中なので温度は一定（ボイルの法則：圧力は体積に反比例）。" : "断熱材で囲んでいるので、圧縮すると温度が上がり、膨張させると下がる（断熱変化）。"; },
  heat:function(d){
    if(this.cont==="bath"){ this.note="恒温槽に入れているので、ヒーターの熱は恒温槽に逃げ、温度は変わらない。「断熱材」にしてから試そう。"; this.heatDir=d; this.hT=0; return; }
    var T2=clamp(this.tgT+50*d, 150, 700), V2=(this.pis==="free")? this.n*RGAS*T2/(this.PF*1e5)*100 : this.tgV;
    if(V2>this.VMAX*0.95){ this.note="これ以上は加熱できない（シリンダーに収まらない）。"; return; }
    this.tgT=T2; this.tgV=V2; this.heatDir=d; this.hT=0;
    this.note=(this.pis==="free")? "ピストンは自由に動くので圧力は一定。温度が上がると体積が増える（シャルルの法則）。" : (this.pis==="lock"? "ピストンは固定なので体積は一定。温度が上がると圧力が上がる。" : "手でピストンを押さえているので体積は一定。温度が上がると圧力が上がる。");
    if(d<0) this.note=this.note.replace("上がると","下がると").replace("上がる。","下がる。").replace("増える","減る"); },
  addTrail:function(){ var a=this.trail[this.trail.length-1], q=[this.V,this.p()]; if(!a || Math.hypot(a[0]-q[0],a[1]-q[1])>0.03){ this.trail.push(q); if(this.trail.length>600) this.trail.shift(); } },
  tick:function(dt){ var k=1-Math.exp(-dt*3.2), dv=this.tgV-this.V, dT=this.tgT-this.T;
    if(Math.abs(dv)>1e-4 || Math.abs(dT)>0.05){ this.V+=dv*k; this.T+=dT*k; this.addTrail(); }
    if(this.heatDir){ this.hT+=dt; if(this.hT>1.6 && Math.abs(dT)<0.5) this.heatDir=0; }
    this.clk+=dt; if(this.g) this.gas.step(dt, Math.max(1,this.g.L), this.g.hw*2, 52*Math.sqrt(this.T/300), 4); },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return W<620? clamp(W*1.25, 480, 580) : clamp(W*0.55, 360, 430); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var narrow=W<620, aw=narrow? W : W*0.42, ah=narrow? H*0.52 : H, h=narrow? 90 : 104, cx=aw*0.46, yB=ah-40, Lmax=ah-110, L=Lmax*this.V/this.VMAX, p=this.p(), rod=40;
    this.g={cx:cx, yB:yB, Lmax:Lmax, L:L, hw:h/2, yTop:yB-L-14, rod:rod};
    ground(c, 8, aw-8, yB+(this.cont==="bath"? 40 : 22));
    var g=drawCylinder(c, new CylFrame(cx, yB, "up"), {L:L, Lmax:Lmax, h:h, T:this.T, gas:this.gas, r:4, pt:14, rod:rod, cont:this.cont, heater:true, heat:this.heatDir, clk:this.clk,
      lock:(this.pis==="lock"), hand:(this.pis==="hand"), pr:clamp(p/3.0,0,1), thermo:true, thLen:44, bathT:this.T});
    if(this.pis==="hand") T(c, "↕ ドラッグ", g.rodEnd[0]+28, g.rodEnd[1]+4, {size:11.5, bold:true, col:"#9c4e06", halo:true});
    if(this.pis==="free") T(c, "大気", cx+h/2+22, yB-Lmax+8, {size:11, bold:true, col:COLG.atm, halo:true});
    /* p-V 図 */
    var gx0=narrow? 50 : aw+40, gy0=H-38, gx1=W-14, gy1=narrow? ah+18 : 24;
    var P=plotFrame(c, gx0, gy0, gx1, gy1, [0,6], [0,3.5], {xl:"V〔×10⁻² m³〕", yl:"p〔×10⁵ Pa〕", xstep:1, ystep:1});
    var kk=this.n*RGAS/1e3;
    [300, 600].forEach(function(Tt){ curve(c, P, function(v){ return kk*Tt/v; }, 0.5, 5.9, "#d5cfc3", 1.2, [5,4], [0,3.5]); T(c, Tt+" K", P.X(5.75), P.Y(kk*Tt/5.75)-9, {size:10, col:COL.sub, align:"center", halo:true}); });
    curve(c, P, function(v){ return kk*self.T/v; }, 0.5, 5.9, "#e0457b", 1.4, [4,3], [0,3.5]);
    c.save(); c.strokeStyle="#1f6fb2"; c.lineWidth=2.2; c.lineJoin="round"; c.beginPath(); this.trail.forEach(function(q,i){ var x=P.X(q[0]), y=P.Y(Math.min(q[1],3.48)); if(i) c.lineTo(x,y); else c.moveTo(x,y); }); c.stroke(); c.restore();
    dot(c, P.X(this.V), P.Y(Math.min(p,3.48)), 6.5, "#c0392b");
    T(c, "点線（赤）：いまの温度の等温線", P.x1, P.y1+4, {size:10.5, col:"#e0457b", align:"right", halo:true});
    notebook(c,W,H);
    setPanel(this.sec, {p:[p.toFixed(2),0], V:[this.V.toFixed(2),0], T:[String(Math.round(this.T)),0]});
    var mh='<span>'+this.note+'</span><br>'+tex("\\dfrac{pV}{T}")+' = <span class="num">'+(p*1e5*this.V*1e-2/this.T).toFixed(2)+'</span> J/K（いつも一定）';
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};
