/* =========================================================================
   モード③ 熱力学第一法則と p-V 図（3-1〜3-3）
   単位：p は ×10⁵ Pa、V は ×10⁻² m³ → pV は ×10³ J
   ========================================================================= */
/* 棒グラフ：Q ＋ W_された ＝ ΔU（物理基礎 ②-1 と同じ形）。vals …[Q, Wされた, ΔU]［J］、vmax …目盛りの最大 */
function barsQWU(c, x0, y0, x1, y1, vals, vmax, title){
  var base=(y0+y1)/2+8, sc=(y1-y0-34)/2/vmax, bw=(x1-x0)/5.4;
  T(c, title||"エネルギーの出入り〔J〕", (x0+x1)/2, y0+6, {size:12, bold:true, align:"center"});
  c.save(); c.strokeStyle="#3a414c"; c.lineWidth=1.2; c.beginPath(); c.moveTo(x0,base); c.lineTo(x1,base); c.stroke(); c.restore();
  var L=[[vals[0],"Q",null,COL.heat],[vals[1],"W","された",COL.work],[vals[2],"ΔU",null,COL.dU]];
  L.forEach(function(v,i){ var x=x0+bw*(0.4+i*1.75), hgt=clamp(v[0],-vmax,vmax)*sc;
    c.save(); c.fillStyle=v[3]; c.globalAlpha=0.88; c.fillRect(x, base-Math.max(hgt,0), bw, Math.abs(hgt)); c.restore();
    SYM(c, v[1], v[2], x+bw/2, y0+26, {size:14, bold:true, col:v[3], align:"center"});
    T(c, (v[0]>=0.5? "+" : v[0]<=-0.5? "−" : "")+Math.abs(Math.round(v[0])), x+bw/2, (hgt>=0? base-hgt-9 : base-hgt+10), {size:11, bold:true, col:v[3], align:"center", halo:true}); });
  T(c, "＋", x0+bw*1.8, y0+26, {size:15, bold:true, align:"center"}); T(c, "＝", x0+bw*3.55, y0+26, {size:15, bold:true, align:"center"});
}
/* 符号つきの整数（マイナスは −） */
function sgn(v){ var r=Math.round(v); return (r>0? "+" : r<0? "−" : "")+Math.abs(r); }
/* 熱の出入りの表し方：Q＞0 はバーナー、Q＜0 は冷たい物体。断熱のときは何も置かない */
function heatUnder(c, x, yb, q, clk, running, wide){
  if(q>0){ burner(c, x, yb+44, running, clk, 0.72); if(running) heatFlow(c, x+(wide||28), yb+34, x+(wide||28), yb+4, 12, (clk*0.9)%1, {k:0.8}); }
  else if(q<0){ c.save(); c.fillStyle="#cfe4f6"; c.strokeStyle="#1f6fb2"; c.lineWidth=1.2; rrect(c, x-34, yb+12, 68, 15, 4); c.fill(); c.stroke(); c.restore();
    T(c,"冷たい物体", x, yb+38, {size:10.5, bold:true, col:"#1f6fb2", align:"center", halo:true});
    if(running) heatFlow(c, x+(wide||44), yb+2, x+(wide||44), yb+32, 12, (clk*0.9)%1, {k:0.8}); }
}

/* ---------------- ③-1 気体がする仕事と p-V 図 ----------------
   1 mol。定圧：p＝1.0、V 2.5 ⇄ 4.0。等温：T≒301 K、V 2.5 ⇄ 4.0 */
var S31 = {
  DUR:6, pA:1.0,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.path="isoP"; this.ex="exp"; this.gas=new Gas(28, 31); this.clk=0;
    this.run=new Runner({ again:true, step:function(dt){ self.clk+=dt; self.mv(dt); self.tb.sync(); return self.run.t>=self.DUR; }, draw:function(){ self.draw(); }, reset:function(){} });
    this.run.bind(sec);
    this.tb=wireTimeBar(sec, this.run, function(){ return self.DUR; }, function(){});
    this.s1=wireSeg(sec,"path",function(v){ self.path=v; self.run.reset(); self.tb.sync(); });
    this.s2=wireSeg(sec,"ex",function(v){ self.ex=v; self.run.reset(); self.tb.sync(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.path="isoP"; self.ex="exp"; self.s1.set("isoP"); self.s2.set("exp"); resetSlow(sec,self.run); self.run.reset(); self.tb.sync(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    idleLoop(sec, function(dt){ if(self.run.state!=="run"){ self.clk+=dt; self.mv(dt); self.draw(); } });
    this.draw();
  },
  ends:function(){ return this.ex==="exp"? [2.5,4.0] : [4.0,2.5]; },
  k:function(){ return this.pA*2.5; },                 /* 等温の pV（×10³ J） */
  pOf:function(V){ return this.path==="isoP"? this.pA : this.k()/V; },
  Vt:function(t){ var e=this.ends(); return e[0]+(e[1]-e[0])*clamp(t/this.DUR,0,1); },
  Wof:function(V){ var V0=this.ends()[0]; return (this.path==="isoP"? this.pA*(V-V0) : this.k()*Math.log(V/V0))*1e3; },
  mv:function(dt){ if(this.g) this.gas.step(dt, this.g.L, this.g.h, 55*Math.sqrt(this.Tof(this.Vt(this.run.t))/300), 4); },
  Tof:function(V){ return this.pOf(V)*V*1e3/RGAS; },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return W<620? clamp(W*1.1, 430, 520) : clamp(W*0.44, 300, 370); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var narrow=W<620, aw=narrow? W : W*0.48, ah=narrow? H*0.42 : H, t=this.run.t, V=this.Vt(t), p=this.pOf(V), Tk=this.Tof(V), running=this.run.state==="run";
    var ox=26, h=narrow? 74 : 92, Lmax=aw-ox-56, L=Lmax*V/4.6, cy=narrow? 18+h/2+14 : ah*0.36;
    this.g={L:L, h:h};
    var F=new CylFrame(ox, cy, "right");
    var q=this.ex==="exp"? 1 : -1;
    heatUnder(c, ox+Lmax*0.28, cy+h/2+8, q, this.clk, running);
    drawCylinder(c, F, {L:L, Lmax:Lmax, h:h, T:Tk, gas:this.gas, r:4, pt:13, rod:Lmax-L+22});
    var W1=this.Wof(V);
    if(running || t>0){ var dir=(this.ex==="exp")? 1 : -1, yb=cy-h/2-24; blockArrow(c, ox+L+30, yb, ox+L+30+dir*56, yb, 10, "#5cc47a");
      T(c, (dir>0? "気体が押し出す" : "外から押しこまれる"), ox+L+30+dir*28, yb-16, {size:11, bold:true, col:COL.work, align:"center", halo:true}); }
    /* p-V 図と面積 */
    var gx0=narrow? 50 : aw+38, gy0=H-38, gx1=W-14, gy1=narrow? ah+26 : 24;
    var P=plotFrame(c, gx0, gy0, gx1, gy1, [0,5], [0,1.5], {xl:"V〔×10⁻² m³〕", yl:"p〔×10⁵ Pa〕", xstep:1, ystep:0.5});
    var e=this.ends(), a=Math.min(e[0],V), b=Math.max(e[0],V);
    c.save(); c.fillStyle=(this.ex==="exp")? "rgba(92,196,122,.35)" : "rgba(231,76,60,.22)"; c.beginPath(); c.moveTo(P.X(a),P.Y(0));
    for(var i=0;i<=40;i++){ var v=a+(b-a)*i/40; c.lineTo(P.X(v),P.Y(this.pOf(v))); } c.lineTo(P.X(b),P.Y(0)); c.closePath(); c.fill();
    c.strokeStyle="rgba(28,143,74,.6)"; c.lineWidth=1; c.beginPath(); c.rect(P.X(a),P.Y(1.45),P.X(b)-P.X(a),P.Y(0)-P.Y(1.45)); c.clip();
    for(var k=-300;k<300;k+=9){ c.beginPath(); c.moveTo(P.X(a)+k,P.Y(0)); c.lineTo(P.X(a)+k+60,P.Y(0)-60); c.stroke(); } c.restore();
    curve(c, P, function(v){ return self.pOf(v); }, Math.min(e[0],e[1]), Math.max(e[0],e[1]), "#9aa1ab", 1.3, [5,4]);
    curve(c, P, function(v){ return self.pOf(v); }, a, b, "#c0392b", 2.6);
    dot(c, P.X(e[0]), P.Y(this.pOf(e[0])), 4.5, "#3a414c"); T(c, "初め", P.X(e[0]), P.Y(this.pOf(e[0]))-14, {size:10.5, col:COL.sub, align:"center", halo:true});
    dot(c, P.X(V), P.Y(p), 6, "#c0392b");
    var mid=(a+b)/2; if(b-a>0.35){ var lw=T(c, "面積 ＝ ", P.X(mid)-18, P.Y(this.pOf(mid)*0.45), {size:12, bold:true, col:"#1c6b3a", align:"center", halo:true}); symW(c, this.ex==="exp"? "した" : "した", P.X(mid)-18+lw/2+2, P.Y(this.pOf(mid)*0.45), {size:13, bold:true, col:"#1c6b3a", halo:true}); if(this.ex==="cmp") T(c, "（負）", P.X(mid), P.Y(this.pOf(mid)*0.45)+18, {size:11, bold:true, col:"#1c6b3a", align:"center", halo:true}); }
    notebook(c,W,H);
    var mh='気体がした仕事 '+tex(WS)+' = <span class="num">'+(W1>=0? "+" : "−")+Math.abs(Math.round(W1))+'</span> J（気体がされた仕事 '+tex(WD)+' = <span class="num">'+(W1>0? "−" : W1<0? "+" : "")+Math.abs(Math.round(W1))+'</span> J）'+
      '<br>'+(this.path==="isoP"? tex(WS+"=p\\Delta V")+' = 1.0×10⁵ Pa × ('+(V-e[0]>=0? "" : "−")+Math.abs(V-e[0]).toFixed(2)+'×10⁻² m³)' : '等温変化：温度 '+Math.round(Tk)+' K のまま。グラフは反比例の曲線')+(this.ex==="cmp"? '。圧縮では、面積に負の符号をつける。' : '');
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};

/* ---------------- ③-2 4 つの変化 ----------------
   単原子分子の理想気体 1 mol、状態 A：p＝1.0、V＝2.5（T≒301 K）。膨張は V→5.0、圧縮は V→1.25。定積は p→2.0／0.5 */
var S32 = {
  DUR:6, pA:1.0, VA:2.5, g:5/3, NM:{V:"定積変化", P:"定圧変化", T:"等温変化", A:"断熱変化"},
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.kind="P"; this.ex="exp"; this.gas=new Gas(30, 32); this.clk=0;
    this.run=new Runner({ again:true, step:function(dt){ self.clk+=dt; self.mv(dt); self.tb.sync(); return self.run.t>=self.DUR; }, draw:function(){ self.draw(); }, reset:function(){},
      startText:function(){ return "▶ スタート"; } });
    this.run.bind(sec);
    this.tb=wireTimeBar(sec, this.run, function(){ return self.DUR; }, function(){});
    this.s1=wireSeg(sec,"kind",function(v){ self.kind=v; self.run.reset(); self.tb.sync(); });
    this.s2=wireSeg(sec,"ex",function(v){ self.ex=v; self.run.reset(); self.tb.sync(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.kind="P"; self.ex="exp"; self.s1.set("P"); self.s2.set("exp"); resetSlow(sec,self.run); self.run.reset(); self.tb.sync(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    idleLoop(sec, function(dt){ if(self.run.state!=="run"){ self.clk+=dt; self.mv(dt); self.draw(); } });
    this.draw();
  },
  /* 変化の途中（u＝0〜1）の状態 [V, p] */
  st:function(kind, ex, u){ var A=this.pA*this.VA, VA=this.VA;
    if(kind==="V"){ var p1=(ex==="exp")? 2.0 : 0.5; return [VA, this.pA+(p1-this.pA)*u]; }
    var V1=(ex==="exp")? 5.0 : 1.25, V=VA+(V1-VA)*u;
    if(kind==="P") return [V, this.pA]; if(kind==="T") return [V, A/V]; return [V, this.pA*Math.pow(VA/V, this.g)]; },
  /* エネルギー［J］：Q・W_された・ΔU */
  en:function(kind, ex, u){ var s=this.st(kind, ex, u), V=s[0], p=s[1], A=this.pA*this.VA, VA=this.VA, Ws;
    if(kind==="V") Ws=0; else if(kind==="P") Ws=this.pA*(V-VA); else if(kind==="T") Ws=A*Math.log(V/VA); else Ws=(A-p*V)/(this.g-1);
    var dU=1.5*(p*V-A); return [(dU+Ws)*1e3, -Ws*1e3, dU*1e3]; },
  Tof:function(V,p){ return p*V*1e3/RGAS; },
  mv:function(dt){ var s=this.st(this.kind,this.ex,clamp(this.run.t/this.DUR,0,1)); if(this.gg) this.gas.step(dt, this.gg.L, this.gg.h, 52*Math.sqrt(this.Tof(s[0],s[1])/300), 4); },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return W<700? clamp(W*1.9, 700, 860) : clamp(W*0.50, 470, 560); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var narrow=W<700, t=this.run.t, u=clamp(t/this.DUR,0,1), kind=this.kind, ex=this.ex, s=this.st(kind,ex,u), V=s[0], p=s[1], Tk=this.Tof(V,p), E=this.en(kind,ex,u), running=this.run.state==="run";
    var TA=this.Tof(this.VA,this.pA);
    /* 区画 */
    var top=narrow? [0,0,W,H*0.25] : [0,0,W*0.42,H*0.56], pv=narrow? [0,H*0.25,W,H*0.52] : [W*0.42,0,W,H*0.56];
    var b1=narrow? [0,H*0.52,W,H*0.76] : [0,H*0.56,W*0.40,H], b2=narrow? [0,H*0.76,W*0.36,H] : [W*0.40,H*0.56,W*0.62,H], b3=narrow? [W*0.36,H*0.76,W,H] : [W*0.62,H*0.56,W,H];
    /* シリンダー */
    var ox=top[0]+26, h=Math.min(84,(top[3]-top[1])*0.42), Lmax=top[2]-top[0]-ox-50, L=Lmax*V/5.4, cy=top[1]+(top[3]-top[1])*0.38;
    this.gg={L:L, h:h};
    var q=(kind==="A")? 0 : (E[0]>=0? 1 : -1);
    if(kind!=="A") heatUnder(c, ox+Math.min(L*0.5, Lmax*0.3)+10, cy+h/2+6, (ex==="exp"? 1 : -1), this.clk, running);
    drawCylinder(c, new CylFrame(ox, cy, "right"), {L:L, Lmax:Lmax, h:h, T:Tk, gas:this.gas, r:3.8, pt:12, rod:Lmax-L+20, stop:(kind==="V"), insul:(kind==="A")});
    if(kind==="T"||kind==="A"){ var rodE=ox+L+12+Lmax-L+20; hand(c, rodE-6, cy+3, 0); }
    T(c, this.NM[kind]+(kind==="V"? "（ピストン固定）" : kind==="A"? "（断熱材で囲む）" : kind==="P"? "（ピストンは自由）" : "（温度一定）"), ox-12, top[1]+14, {size:12, bold:true});
    T(c, Math.round(Tk)+" K", ox+Lmax-4, cy-h/2-22, {size:12.5, bold:true, col:"#a03028", align:"right", halo:true});
    /* p-V 図：4 つの変化の曲線を重ねる */
    var P=plotFrame(c, pv[0]+46, pv[3]-34, pv[2]-12, pv[1]+22, [0,5.5], [0,3.5], {xl:"V〔×10⁻² m³〕", yl:"p〔×10⁵ Pa〕", xstep:1, ystep:1});
    var CC={V:"#7b3fd4", P:"#1f6fb2", T:"#1c8f4a", A:"#c0392b"};
    ["V","P","T","A"].forEach(function(k){ ["exp","cmp"].forEach(function(e){ var on=(k===kind && e===ex);
      c.save(); c.strokeStyle=CC[k]; c.globalAlpha=on? 0.35 : 0.55; c.lineWidth=on? 1.2 : 1.6; c.setLineDash(on? [5,4] : []); c.beginPath();
      for(var i=0;i<=60;i++){ var q2=self.st(k,e,i/60), x=P.X(q2[0]), y=P.Y(Math.min(q2[1],3.45)); if(i) c.lineTo(x,y); else c.moveTo(x,y); } c.stroke(); c.restore(); });
      var en=self.st(k,"exp",1); T(c, self.NM[k].replace("変化",""), P.X(en[0])+(k==="V"? 6 : -4), P.Y(Math.min(en[1],3.4))+(k==="V"? 0 : k==="A"? 12 : -10), {size:10.5, bold:true, col:CC[k], align:(k==="V"? "left" : "right"), halo:true}); });
    c.save(); c.strokeStyle=CC[kind]; c.lineWidth=3; c.beginPath(); for(var i=0;i<=60;i++){ var q3=this.st(kind,ex,u*i/60), x=P.X(q3[0]), y=P.Y(Math.min(q3[1],3.45)); if(i) c.lineTo(x,y); else c.moveTo(x,y); } c.stroke(); c.restore();
    dot(c, P.X(this.VA), P.Y(this.pA), 5, "#3a414c"); T(c, "A", P.X(this.VA)-8, P.Y(this.pA)+12, {size:13, bold:true, serif:true, align:"right", halo:true});
    dot(c, P.X(V), P.Y(Math.min(p,3.45)), 6.5, CC[kind]);
    /* 棒グラフ Q ＋ W_された ＝ ΔU */
    barsQWU(c, b1[0]+14, b1[1]+8, b1[2]-10, b1[3]-6, E, 7000);
    /* U と v² の平均（初めを点線） */
    var bx0=b2[0]+16, bx1=b2[2]-6, by0=b2[1]+30, by1=b2[3]-26, UA=1.5*this.pA*this.VA*1e3, U=1.5*p*V*1e3, umax=UA*2.6;
    T(c, "内部エネルギー と v̄²", (bx0+bx1)/2, b2[1]+12, {size:12, bold:true, align:"center"});
    var hb=function(val, ref, i, col, lab){ var x=bx0+(bx1-bx0)*(0.12+i*0.48), w=(bx1-bx0)*0.30, sc=(by1-by0)/umax, hh=Math.min(val,umax)*sc;
      c.save(); c.fillStyle=col; c.globalAlpha=0.85; c.fillRect(x, by1-hh, w, hh); c.restore();
      c.save(); c.setLineDash([4,3]); c.strokeStyle="#3a414c"; c.beginPath(); c.moveTo(x-4, by1-ref*sc); c.lineTo(x+w+4, by1-ref*sc); c.stroke(); c.restore();
      T(c, lab, x+w/2, by1+12, {size:11, bold:true, col:col, align:"center"}); };
    c.save(); c.strokeStyle="#3a414c"; c.beginPath(); c.moveTo(bx0,by1); c.lineTo(bx1,by1); c.stroke(); c.restore();
    hb(U, UA, 0, "#7b3fd4", "U"); hb(U, UA, 1, "#e0457b", "v̄²");
    T(c, "点線＝状態 A", bx1, by0-8, {size:10, col:COL.sub, align:"right"});
    /* 速さの分布（初め：点線、いま：実線）ヘリウム */
    var D=plotFrame(c, b3[0]+28, b3[3]-30, b3[2]-12, b3[1]+26, [0,3000], [0,1], {noYt:true, xl:"v〔m/s〕", yl:"分子の数の割合", xstep:1000});
    var fv=function(Tt,v){ var a=4e-3/(2*RGAS*Tt); return v*v*Math.exp(-a*v*v)*Math.pow(a,1.5); }, mx=0;
    [TA, Tk].forEach(function(Tt){ for(var v=0; v<=3000; v+=25) mx=Math.max(mx, fv(Tt,v)); });
    [[TA,"#9aa1ab",[5,4]],[Tk,"#e0457b",null]].forEach(function(o){ c.save(); c.strokeStyle=o[1]; c.lineWidth=2.2; if(o[2]) c.setLineDash(o[2]); c.beginPath();
      for(var v=0; v<=2990; v+=25){ var y=fv(o[0],v)/mx*0.9; if(v) c.lineTo(D.X(v),D.Y(y)); else c.moveTo(D.X(v),D.Y(y)); } c.stroke(); c.restore(); });
    T(c, "速さの分布（点線＝状態 A）", D.x1, D.y1+2, {size:10, col:COL.sub, align:"right", halo:true});
    notebook(c,W,H);
    var mh='<b>'+this.NM[kind]+'</b>（'+(ex==="exp"? (kind==="V"? "加熱" : "膨張") : (kind==="V"? "冷却" : "圧縮"))+'）　'+tex("Q")+' = <span class="num">'+sgn(E[0])+'</span> J　'+tex(WD)+' = <span class="num">'+sgn(E[1])+'</span> J　'+tex("\\Delta U")+' = <span class="num">'+sgn(E[2])+'</span> J　温度 <span class="num">'+Math.round(Tk)+'</span> K'+
      '<br>'+({V:"体積が変わらないので仕事はしない。受け取った熱が全て内部エネルギーになる。", P:"受け取った熱の一部が、外にする仕事になる。", T:"温度が変わらないので内部エネルギーは変わらない。受け取った熱が全て仕事になる。", A:"熱の出入りがないので、気体がした仕事の分だけ内部エネルギーが減る（圧縮では増える）。"}[kind]);
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};

/* ---------------- ③-3 モル比熱 ----------------
   1 mol、300 K → 400 K（ΔT＝100 K）。左：定積（ピストン固定）、右：定圧（p＝1.0×10⁵ Pa） */
var S33 = {
  DUR:6,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.mol="mono"; this.A=new Gas(20, 331); this.B=new Gas(20, 332); this.clk=0;
    this.run=new Runner({ step:function(dt){ self.clk+=dt; self.mv(dt); self.tb.sync(); return self.run.t>=self.DUR; }, draw:function(){ self.draw(); }, reset:function(){} });
    this.run.bind(sec);
    this.tb=wireTimeBar(sec, this.run, function(){ return self.DUR; }, function(){});
    this.sm=wireSeg(sec,"mol",function(v){ self.mol=v; self.run.reset(); self.tb.sync(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.mol="mono"; self.sm.set("mono"); resetSlow(sec,self.run); self.run.reset(); self.tb.sync(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    idleLoop(sec, function(dt){ if(self.run.state!=="run"){ self.clk+=dt; self.mv(dt); self.draw(); } });
    this.draw();
  },
  Tt:function(t){ return 300+100*clamp(t/this.DUR,0,1); },
  mv:function(dt){ var vs=50*Math.sqrt(this.Tt(this.run.t)/300); if(this.ga) this.A.step(dt, this.ga.L, this.ga.h, vs, 5); if(this.gb) this.B.step(dt, this.gb.L, this.gb.h, vs, 5); },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return W<640? clamp(W*1.35, 500, 620) : clamp(W*0.50, 360, 430); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var narrow=W<640, t=this.run.t, Tk=this.Tt(t), dT=Tk-300, di=(this.mol==="di"), CV=(di? 2.5 : 1.5)*RGAS, running=this.run.state==="run";
    var dU=CV*dT, Wk=RGAS*dT, QV=dU, Qp=dU+Wk;
    var colW=narrow? W/2 : W*0.30, h=narrow? 70 : 84, baseY=narrow? H*0.50 : H-62, Lmax=narrow? H*0.36 : H*0.62;
    var V0=RGAS*300/1e5*100, Vp=RGAS*Tk/1e5*100;        /* ×10⁻² m³ */
    var cols=[[colW*0.5, V0, true, "定積（ピストン固定）", this.A, QV],[colW*1.5, Vp, false, "定圧（ピストンは自由）", this.B, Qp]];
    cols.forEach(function(o,i){ var ox=o[0], L=Lmax*o[1]/4.2, F=new CylFrame(ox, baseY, "up");
      if(i===0) self.ga={L:L, h:h}; else self.gb={L:L, h:h};
      c.save(); c.fillStyle="#d9d2c2"; c.fillRect(ox-h/2-20, baseY+9, h+40, 7); c.restore();
      burner(c, ox, baseY+60, running, self.clk+i, 0.7);
      if(running) heatFlow(c, ox+h*0.30, baseY+40, ox+h*0.30, baseY+12, 6+9*o[5]/(3.5*RGAS*100), (self.clk*(0.6+0.4*o[5]/(2.5*RGAS*100)))%1, {k:o[5]/(3.5*RGAS*100)});
      drawCylinder(c, F, {L:L, Lmax:Lmax, h:h, T:Tk, gas:o[4], r:5, pt:12, stop:o[2], rotDi:di, clk:self.clk});
      T(c, o[3], ox, 14, {size:12, bold:true, align:"center"});
      T(c, Math.round(Tk)+" K", ox, 32, {size:12, bold:true, col:"#a03028", align:"center"});
      if(!o[2] && (running || t>0)){ var yb=baseY-L-24; blockArrow(c, ox+h/2+18, yb+10, ox+h/2+18, yb-30, 9, "#5cc47a"); T(c, "仕事", ox+h/2+34, yb-12, {size:11, bold:true, col:COL.work, halo:true}); }
    });
    /* 棒グラフ：Q_V ＝ ΔU、Q_p ＝ ΔU ＋ W_した */
    var gx0=narrow? 50 : W*0.64, gx1=W-14, gy0=H-38, gy1=narrow? baseY+90 : 40, qmax=3.5*RGAS*100*1.1;
    var P=plotFrame(c, gx0, gy0, gx1, gy1, [0,2], [0,qmax], {noXt:true, yl:"熱量〔J〕", ystep:1000, xl:""});
    var bw=(P.x1-P.x0)*0.22, xs=[P.x0+(P.x1-P.x0)*0.18, P.x0+(P.x1-P.x0)*0.60];
    c.save(); c.globalAlpha=0.88; c.fillStyle=COL.dU; c.fillRect(xs[0], P.Y(dU), bw, P.Y(0)-P.Y(dU)); c.fillRect(xs[1], P.Y(dU), bw, P.Y(0)-P.Y(dU));
    c.fillStyle="#5cc47a"; c.fillRect(xs[1], P.Y(dU+Wk), bw, P.Y(dU)-P.Y(dU+Wk)); c.restore();
    c.save(); c.strokeStyle=COL.heat; c.lineWidth=2; c.strokeRect(xs[0]-3, P.Y(QV)-3, bw+6, P.Y(0)-P.Y(QV)+3); c.strokeRect(xs[1]-3, P.Y(Qp)-3, bw+6, P.Y(0)-P.Y(Qp)+3); c.restore();
    T(c, "定積", xs[0]+bw/2, P.y0+12, {size:11.5, bold:true, align:"center"}); T(c, "定圧", xs[1]+bw/2, P.y0+12, {size:11.5, bold:true, align:"center"});
    if(dT>2){ T(c, "ΔU", xs[0]+bw/2, (P.Y(dU)+P.Y(0))/2, {size:12, bold:true, col:"#fff", align:"center"}); T(c, "ΔU", xs[1]+bw/2, (P.Y(dU)+P.Y(0))/2, {size:12, bold:true, col:"#fff", align:"center"});
      symW(c, "した", xs[1]+bw/2, (P.Y(dU)+P.Y(dU+Wk))/2, {size:12, bold:true, col:"#14532d", align:"center"});
      T(c, Math.round(QV)+" J", xs[0]+bw/2, P.Y(QV)-12, {size:11, bold:true, col:COL.heat, align:"center", halo:true}); T(c, Math.round(Qp)+" J", xs[1]+bw/2, P.Y(Qp)-12, {size:11, bold:true, col:COL.heat, align:"center", halo:true}); }
    T(c, "外わく＝必要な熱", P.x1, P.y1-2, {size:10, col:COL.heat, align:"right"});
    notebook(c,W,H);
    var mh=(di? '二原子分子' : '単原子分子')+'：'+tex("\\Delta T")+' = <span class="num">'+Math.round(dT)+'</span> K　定積 '+tex("Q_V=\\Delta U")+' = <span class="num">'+Math.round(QV)+'</span> J　定圧 '+tex("Q_p=\\Delta U+"+WS)+' = <span class="num">'+Math.round(Qp)+'</span> J'+
      (dT>99? '<br>'+tex("C_V")+' = '+(QV/100).toFixed(1)+' J/(mol·K)（'+(di? '5/2' : '3/2')+' R）、'+tex("C_p")+' = '+(Qp/100).toFixed(1)+' J/(mol·K)（'+(di? '7/2' : '5/2')+' R）。差はちょうど '+tex("R")+' = 8.31 J/(mol·K)。' : '');
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};
