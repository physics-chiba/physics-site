/* =========================================================================
   気体のページの共通部品（どの節でも使いまわす）
   ・定数（R・k・N_A）と記号（W_された・W_した・v² の平均）
   ・気体の分子（たがいにはぶつからず、壁で弾性衝突する。位置は 0〜1 の割合で持つ）
   ・シリンダーとピストン（向きを変えられる）・パネル表示（1-1 の見本の形）
   ・グラフの枠（軸に矢印・きりのいい目盛り）・オットーサイクル（ヒーローと 4-2）
   ========================================================================= */
var RGAS = 8.31, NAV = 6.02e23, KB = 1.38e-23, PATM = 1.0e5;
/* 記号（KaTeX）：仕事は W_された／W_した、速さの 2 乗の平均は v² の上に横線 */
var WD = "W_{\\text{された}}", WS = "W_{\\text{した}}", V2B = "\\overline{v^2}", VX2B = "\\overline{{v_x}^2}";
var COLG = { p:"#e0457b", V:"#1f7fd6", T:"#d99a00", n:"#1c8f4a", U:"#7b3fd4",
  gasF:"#1c8f4a", atm:"#b58900", grav:"#d1352b", norm:"#7b3fd4", imp:"#c0158a", vel:"#1663b5" };

/* 決まった乱数（毎回同じ並び） */
function rng(seed){ var a=seed>>>0; return function(){ a|=0; a=a+0x6D2B79F5|0; var t=Math.imul(a^a>>>15,1|a); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }
/* 標準正規分布 */
function gauss(R){ var u=Math.max(1e-9,R()), v=R(); return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v); }

/* ---------------- 気体の分子 ----------------
   x・y は気体の部分の中での割合（0〜1）。体積が変わっても分子は同じ割合の位置のまま。
   速さ：3 方向の成分を正規分布で選ぶ（マクスウェル分布）。f2 の平均がおよそ 1 になるようにそろえる。
   画面の速さ［px/s］＝ 成分 × vs（vs は温度の平方根に比例させて呼ぶ側が決める） */
function Gas(n, seed){
  this.R = rng(seed||7); this.m = []; this.hits = 0;
  this.setN(n);
}
Gas.prototype.one = function(){ var R=this.R;
  var vx=gauss(R), vy=gauss(R), vz=gauss(R);
  return {x:0.08+0.84*R(), y:0.08+0.84*R(), vx:vx, vy:vy, vz:vz, ph:R()*6.283}; };
Gas.prototype.setN = function(n){
  n=Math.max(0,Math.round(n));
  while(this.m.length<n) this.m.push(this.one());
  if(this.m.length>n) this.m.length=n;
  /* 2 乗の平均を 3 にそろえる（1 方向あたり 1） */
  if(n>=3 && !this._norm){ var s=0; this.m.forEach(function(q){ s+=q.vx*q.vx+q.vy*q.vy+q.vz*q.vz; }); var k=Math.sqrt(3*n/s);
    this.m.forEach(function(q){ q.vx*=k; q.vy*=k; q.vz*=k; }); this._norm=true; }
};
/* 1 コマ進める。w・h …気体の部分の大きさ［px］、vs …速さの目安［px/s］、r …分子の半径［px］。
   右の壁（x＝1：ピストンや壁 S）に当たった回数を hits に足す */
Gas.prototype.step = function(dt, w, h, vs, r){
  if(w<2*r+2 || h<2*r+2) return;
  var self=this, rx=r/w, ry=r/h, n=Math.max(1,Math.ceil(dt*vs*3/Math.min(w,h)*4)), hh=dt/n;
  for(var s=0;s<n;s++) this.m.forEach(function(q){
    q.x+=q.vx*vs*hh/w; q.y+=q.vy*vs*hh/h;
    if(q.x<rx){ q.x=2*rx-q.x; q.vx=Math.abs(q.vx); }
    if(q.x>1-rx){ q.x=2*(1-rx)-q.x; q.vx=-Math.abs(q.vx); self.hits++; }
    if(q.y<ry){ q.y=2*ry-q.y; q.vy=Math.abs(q.vy); }
    if(q.y>1-ry){ q.y=2*(1-ry)-q.y; q.vy=-Math.abs(q.vy); }
    q.x=clamp(q.x,rx,1-rx); q.y=clamp(q.y,ry,1-ry);
  });
};
/* 気体の部分にとじこめる（体積が急に小さくなったとき） */
Gas.prototype.keep = function(w,h,r){ var rx=Math.min(0.49,r/Math.max(w,1)), ry=Math.min(0.49,r/Math.max(h,1));
  this.m.forEach(function(q){ q.x=clamp(q.x,rx,1-rx); q.y=clamp(q.y,ry,1-ry); }); };
/* 分子の速さの 2 乗の平均（成分のまま。1 方向あたり 1 くらい） */
Gas.prototype.v2 = function(){ var s=0; this.m.forEach(function(q){ s+=q.vx*q.vx+q.vy*q.vy+q.vz*q.vz; }); return this.m.length? s/this.m.length : 0; };

/* 温度 T［K］→ 分子と気体の色 */
function gasLv(T){ return clamp((T-150)/500,0,1); }
function gasTint(T, a){ var lv=gasLv(T);
  return (lv<0.5)? 'rgba('+Math.round(170+170*lv)+','+Math.round(215-20*lv)+','+Math.round(240-60*lv)+','+(a||0.55)+')'
                 : 'rgba(255,'+Math.round(205-150*(lv-0.5))+','+Math.round(190-150*(lv-0.5))+','+(a||0.55)+')'; }

/* ---------------- シリンダー ----------------
   局所の座標：x …閉じた端の内側の面から開いた端へ［px］、y …軸からの横のずれ（−h/2〜h/2）。
   dir：シリンダーの開いた端が向く方向 "right"・"up"・"down"。(ox,oy) …閉じた端の内側の面のまん中（画面）。
   to(x,y) で局所 → 画面に変える。描くときは c を回して局所のまま描く */
function CylFrame(ox, oy, dir){
  this.ox=ox; this.oy=oy; this.dir=dir||"right";
  this.ang = (dir==="up")? -Math.PI/2 : (dir==="down")? Math.PI/2 : (dir==="left")? Math.PI : 0;
}
CylFrame.prototype.to = function(x,y){ var a=this.ang, ca=Math.cos(a), sa=Math.sin(a);
  return [this.ox + x*ca - y*sa, this.oy + x*sa + y*ca]; };
CylFrame.prototype.begin = function(c){ c.save(); c.translate(this.ox,this.oy); c.rotate(this.ang); };
CylFrame.prototype.end = function(c){ c.restore(); };
/* o：L …ピストンの内側の面の位置、Lmax …シリンダーの長さ、h …内径、T …温度、gas …Gas、r …分子の半径、
       pt …ピストンの厚さ、rod …ピストンの棒の長さ（0 で棒なし）、stop …ストッパー（ピストン固定）、
       insul …断熱材（壁を斜線で）、noGas、tint …気体の色を付けるか、mcol …分子の色（関数でも可） */
function drawCylinder(c, F, o){
  var L=o.L, Lm=o.Lmax, h=o.h, wt=o.wall||9, pt=o.pt||14, hh=h/2;
  F.begin(c);
  /* 気体 */
  if(!o.noGas){ c.fillStyle=(o.tint===false)? "rgba(236,244,250,.7)" : gasTint(o.T||300, 0.42); c.fillRect(0,-hh,L,h); }
  /* 分子 */
  if(o.gas && L>4){ var r=o.r||4.2, w=L, mc=o.mcol;
    o.gas.m.forEach(function(q,i){ var x=r+(w-2*r)*q.x, y=-hh+r+(h-2*r)*q.y;
      if(o.rotDi){ /* 二原子分子（亜鈴の形で回転） */
        var a=q.ph+(o.clk||0)*(2.5+1.5*Math.abs(q.vz)), dx=Math.cos(a)*r*0.95, dy=Math.sin(a)*r*0.95;
        var col=(typeof mc==="function")? mc(q,i) : (mc||heatCol(gasLv(o.T||300)));
        c.strokeStyle="#33414f"; c.lineWidth=1.6; c.beginPath(); c.moveTo(x-dx,y-dy); c.lineTo(x+dx,y+dy); c.stroke();
        ball(c,x-dx,y-dy,r*0.78,0,col); ball(c,x+dx,y+dy,r*0.78,0,col);
      } else ball(c, x, y, r, 0, (typeof mc==="function")? mc(q,i) : (mc||heatCol(gasLv(o.T||300)))); });
  }
  /* 壁（閉じた端・上下）。断熱のときは斜線を入れた厚い壁 */
  var wc=o.insul? "#efe3c6" : "#c9ced6";
  c.fillStyle=wc; c.strokeStyle="#5b636e"; c.lineWidth=1.3;
  c.fillRect(-wt,-hh-wt,Lm+wt,wt); c.fillRect(-wt,hh,Lm+wt,wt); c.fillRect(-wt,-hh,wt,h);
  c.beginPath(); c.moveTo(Lm,-hh-wt); c.lineTo(-wt,-hh-wt); c.lineTo(-wt,hh+wt); c.lineTo(Lm,hh+wt); c.stroke();
  c.beginPath(); c.moveTo(Lm,-hh); c.lineTo(0,-hh); c.lineTo(0,hh); c.lineTo(Lm,hh); c.stroke();
  if(o.insul){ c.save(); c.beginPath(); c.rect(-wt,-hh-wt,Lm+wt,wt); c.rect(-wt,hh,Lm+wt,wt); c.rect(-wt,-hh,wt,h); c.clip();
    c.strokeStyle="#b39a62"; c.lineWidth=1; for(var k=-wt-h; k<Lm+h; k+=6){ c.beginPath(); c.moveTo(k,hh+wt); c.lineTo(k+h+2*wt,-hh-wt); c.stroke(); } c.restore(); }
  /* ストッパー（ピストンを固定） */
  if(o.stop){ c.fillStyle="#7a6a55"; [[-hh,1],[hh,-1]].forEach(function(s){ c.fillRect(L+pt+1, s[0]-(s[1]<0?6:0), 7, 6); c.fillRect(L-8, s[0]-(s[1]<0?6:0), 7, 6); }); }
  /* ピストン */
  if(!o.noPiston){
    var pg=c.createLinearGradient(L,0,L+pt,0); pg.addColorStop(0,"#9aa1ab"); pg.addColorStop(1,"#dfe2e6");
    c.fillStyle=pg; c.strokeStyle="#4b535e"; c.lineWidth=1.2; c.fillRect(L,-hh,pt,h); c.strokeRect(L,-hh,pt,h);
    if(o.rod){ c.fillStyle="#d8d2c4"; c.strokeStyle="#8b8172"; rrect(c,L+pt,-4,o.rod,8,3); c.fill(); c.stroke(); }
  }
  F.end(c);
}

/* ---------------- パネル表示（1-1 の見本：暗い地のカード） ---------------- */
var PANEL_DEF = {
  p:{lab:"圧力 <i>p</i>", unit:"×10<sup>5</sup> Pa", cls:"pp"},
  V:{lab:"体積 <i>V</i>", unit:"×10<sup>−2</sup> m<sup>3</sup>", cls:"pv"},
  T:{lab:"温度 <i>T</i>", unit:"K", cls:"pt"},
  n:{lab:"物質量 <i>n</i>", unit:"mol", cls:"pn"},
  U:{lab:"内部エネルギー <i>U</i>", unit:"J", cls:"pu"}
};
/* pm …{p:"温度一定", …}：カードの下に − ＋ のボタンと、そのとき一定にする量を添える */
function panelHTML(keys, pm){
  return '<div class="gpanel g'+keys.length+'">'+keys.map(function(k){ var d=PANEL_DEF[k];
    return '<div class="gcard '+d.cls+'" data-k="'+k+'"><span class="gl">'+d.lab+'</span><span class="gvrow"><span class="gv">—</span><span class="gu">'+d.unit+'</span></span><span class="gd"></span>'+
      (pm && pm[k]? '<span class="gpm"><button type="button" class="gpb" data-pm="'+k+'" data-d="-1" aria-label="'+d.lab.replace(/<[^>]*>/g,"")+'を減らす">−</button><button type="button" class="gpb" data-pm="'+k+'" data-d="1" aria-label="'+d.lab.replace(/<[^>]*>/g,"")+'を増やす">＋</button><small>'+pm[k]+'</small></span>' : '')+'</div>'; }).join("")+'</div>';
}
/* vals：{p:[値の文字, 変化の向き(+1/-1/0)], …} */
function setPanel(root, vals){
  Object.keys(vals).forEach(function(k){ var el=root.querySelector('.gcard[data-k="'+k+'"]'); if(!el) return;
    var v=vals[k], gv=el.querySelector(".gv"), gd=el.querySelector(".gd");
    if(gv.textContent!==v[0]) gv.textContent=v[0];
    var dtx=(v[1]>0? "▲ 増加" : v[1]<0? "▼ 減少" : v[2]||"");
    if(gd.textContent!==dtx) gd.textContent=dtx;
    el.classList.toggle("up", v[1]>0); el.classList.toggle("dn", v[1]<0); });
}

/* ---------------- グラフの枠 ----------------
   (x0,y0) …原点の画面上の位置（左下）、(x1,y1) …右上。xr・yr …[最小, 最大]。o.xl・o.yl …軸の名前。
   目盛りはきりのいい値（1・2・5×10ⁿ）、0 を含める。軸の先に矢印。返り値は値 → 画面の関数 */
function plotFrame(c, x0, y0, x1, y1, xr, yr, o){
  o=o||{};
  var X=function(v){ return x0+(x1-x0-14)*(v-xr[0])/(xr[1]-xr[0]); }, Y=function(v){ return y0-(y0-y1-14)*(v-yr[0])/(yr[1]-yr[0]); };
  var xs=o.xstep||niceStep(xr[1]-xr[0],o.nx||5), ys=o.ystep||niceStep(yr[1]-yr[0],o.ny||4);
  c.save(); c.fillStyle="#fff"; rrect(c,x0-2,y1-2,x1-x0+4,y0-y1+4,6); c.fill();
  c.strokeStyle="#efebe4"; c.lineWidth=1;
  for(var v=Math.ceil(xr[0]/xs-1e-9)*xs; v<=xr[1]+1e-9; v+=xs){ if(Math.abs(v-xr[0])<1e-9) continue; var X1=Math.round(X(v))+0.5; c.beginPath(); c.moveTo(X1,y0); c.lineTo(X1,y1+14); c.stroke(); }
  for(var w=Math.ceil(yr[0]/ys-1e-9)*ys; w<=yr[1]+1e-9; w+=ys){ if(Math.abs(w-yr[0])<1e-9) continue; var Y1=Math.round(Y(w))+0.5; c.beginPath(); c.moveTo(x0,Y1); c.lineTo(x1-14,Y1); c.stroke(); }
  c.restore();
  axes(c, x0, y0, x1, y1);
  var fs=o.fs||10.5, dec=function(s){ var d=0; while(d<4 && Math.abs(Math.round(s*Math.pow(10,d))-s*Math.pow(10,d))>1e-6) d++; return d; };
  var dx=dec(xs), dy=dec(ys);
  if(!o.noXt) for(var a=Math.ceil(xr[0]/xs-1e-9)*xs; a<=xr[1]-xs*0.3+1e-9; a+=xs){ if(Math.abs(a-xr[0])<1e-9 && !o.xz) continue; T(c, (o.xfmt? o.xfmt(a) : a.toFixed(dx)), X(a), y0+11, {size:fs, col:COL.sub, align:"center"}); }
  if(!o.noYt) for(var b=Math.ceil(yr[0]/ys-1e-9)*ys; b<=yr[1]-ys*0.3+1e-9; b+=ys){ if(Math.abs(b-yr[0])<1e-9) continue; T(c, b.toFixed(dy), x0-5, Y(b), {size:fs, col:COL.sub, align:"right"}); }
  if(!o.noO) T(c, "O", x0-5, y0+10, {size:fs+0.5, col:COL.sub, align:"right", it:true});
  if(o.xl) axisLabel(c, o.xl, x1, y0+(o.xlDy||26), "right");
  if(o.yl) axisLabel(c, o.yl, x0+4, y1-2, "left");
  return {X:X, Y:Y, x0:x0, y0:y0, x1:x1-14, y1:y1+14};
}
/* 軸の名前：先頭の 1 文字（p・V・T・t など）を斜体、残りを普通の字で（例 "V〔×10⁻² m³〕"） */
function axisLabel(c, s, x, y, align){
  if(!/^[A-Za-z][^A-Za-z]/.test(s)){ T(c, s, x, y, {size:11, col:COL.sub, halo:true, align:(align==="right"? "right" : "left")}); return; }
  var sym=s.charAt(0), rest=s.slice(1);
  c.save(); c.font="italic 13px "+MATHF; var w1=c.measureText(sym).width; c.font="11px "+FONT; var w2=c.measureText(rest).width; c.restore();
  var X0=(align==="right")? x-w1-w2 : x;
  T(c, sym, X0, y, {size:13, it:true, col:COL.ink, halo:true}); T(c, rest, X0+w1+1, y, {size:11, col:COL.sub, halo:true});
}
/* 点線の曲線（等温線など）：f(V)→p、範囲 [a,b] */
function curve(c, P, f, a, b, col, lw, dash, yr){
  c.save(); c.strokeStyle=col; c.lineWidth=lw||1.4; if(dash) c.setLineDash(dash);
  c.beginPath(); var first=true;
  for(var i=0;i<=120;i++){ var v=a+(b-a)*i/120, p=f(v); if(yr && (p>yr[1]*1.02 || p<yr[0])){ first=true; continue; }
    var x=P.X(v), y=P.Y(p); if(first){ c.moveTo(x,y); first=false; } else c.lineTo(x,y); }
  c.stroke(); c.restore();
}
function dot(c,x,y,r,col){ c.save(); c.fillStyle=col; c.beginPath(); c.arc(x,y,r,0,7); c.fill(); c.strokeStyle="#fff"; c.lineWidth=1.5; c.stroke(); c.restore(); }

/* ---------------- 「W_した」「W_された」を canvas に書く ---------------- */
function symW(c, which, x, y, o){ return SYM(c, "W", which, x, y, o); }

/* ---------------- オットーサイクル（ヒーローと 4-2） ----------------
   u …1 サイクルの中の位置 0〜1（クランク 2 回転）。体積の単位 ×10⁻⁴ m³、圧力の単位 ×10⁵ Pa。
   一瞬で起こる変化（点火・排気弁を開く）は、見えるように少し時間をとって表す（そのあいだクランクは止める）。 */
var OTTO = { Vc:0.5, Vm:4.0, g:1.4, a:2.5,
  /* 区間：[始め, 終わり, 名前, 種類] */
  SEG:[[0,0.20,"吸気","in"],[0.20,0.40,"圧縮","cmp"],[0.40,0.48,"点火（燃焼）","burn"],[0.48,0.68,"膨張","exp"],[0.68,0.76,"排気弁を開く","blow"],[0.76,1.0,"排気","out"]] };
OTTO.p2 = Math.pow(OTTO.Vm/OTTO.Vc, OTTO.g); OTTO.p3 = OTTO.p2*OTTO.a; OTTO.p4 = OTTO.p3/OTTO.p2;
function ottoState(u){
  u=((u%1)+1)%1;
  var S=OTTO.SEG, k=0; while(k<S.length-1 && u>=S[k][1]) k++;
  var s=S[k], f=(u-s[0])/(s[1]-s[0]), th;
  if(s[3]==="in") th=f*Math.PI; else if(s[3]==="cmp") th=Math.PI+f*Math.PI; else if(s[3]==="burn") th=2*Math.PI;
  else if(s[3]==="exp") th=2*Math.PI+f*Math.PI; else if(s[3]==="blow") th=3*Math.PI; else th=3*Math.PI+f*Math.PI;
  var lam=0.30, sx=(1-Math.cos(th))/2 + (1-Math.sqrt(1-lam*lam*Math.sin(th)*Math.sin(th)))/(2*lam);   /* 0〜1 の行程（連接棒の長さを考える） */
  var V=OTTO.Vc+(OTTO.Vm-OTTO.Vc)*sx, p;
  if(s[3]==="in" || s[3]==="out") p=1;
  else if(s[3]==="cmp") p=Math.pow(OTTO.Vm/V, OTTO.g);
  else if(s[3]==="burn") p=OTTO.p2+(OTTO.p3-OTTO.p2)*f;
  else if(s[3]==="exp") p=OTTO.p3*Math.pow(OTTO.Vc/V, OTTO.g);
  else p=OTTO.p4+(1-OTTO.p4)*f;
  return {u:u, k:k, f:f, name:s[2], kind:s[3], th:th, sx:sx, V:V, p:p,
          inOpen:(s[3]==="in"), exOpen:(s[3]==="blow"||s[3]==="out"), spark:(s[3]==="burn" && f<0.6)};
}
/* エンジンの断面：(cx, yTop) …シリンダーの上（燃焼室の天井）のまん中、w …内径、Hs …行程の長さ［px］。dark …ヒーロー（暗い地）用の色 */
function drawEngine(c, cx, yTop, w, Hs, st, clk, dark){
  var hc=Hs*OTTO.Vc/(OTTO.Vm-OTTO.Vc), yp=yTop+hc+Hs*st.sx, pt=w*0.32;
  var wallC=dark? "rgba(222,232,245,.55)" : "#5b636e", wallF=dark? "rgba(159,208,255,.10)" : "#d3d8de";
  var T=300*st.p*st.V/(OTTO.Vm*1);             /* 温度の目安（初めを 300 K） */
  c.save();
  /* 燃焼室の中の気体 */
  c.fillStyle=dark? ("rgba(255,"+Math.round(clamp(230-T/12,60,230))+","+Math.round(clamp(200-T/8,30,200))+","+(0.10+0.35*clamp((T-300)/2200,0,1))+")") : gasTint(Math.min(T,650),0.5);
  c.fillRect(cx-w/2, yTop, w, yp-yTop);
  if(st.spark){ var g=c.createRadialGradient(cx,yTop+6,1,cx,yTop+6,w*0.55); g.addColorStop(0,"rgba(255,240,170,.95)"); g.addColorStop(1,"rgba(255,140,40,0)"); c.fillStyle=g; c.fillRect(cx-w/2,yTop,w,yp-yTop); }
  /* シリンダーの壁と天井 */
  c.fillStyle=wallF; c.strokeStyle=wallC; c.lineWidth=1.4;
  var wt=10; c.fillRect(cx-w/2-wt, yTop-wt, wt, Hs+hc+wt+12); c.fillRect(cx+w/2, yTop-wt, wt, Hs+hc+wt+12);
  c.fillRect(cx-w/2-wt, yTop-wt-2, w+2*wt, wt);
  c.strokeRect(cx-w/2-wt, yTop-wt-2, w+2*wt, wt);
  c.beginPath(); c.moveTo(cx-w/2,yTop); c.lineTo(cx-w/2,yTop+Hs+hc+12); c.moveTo(cx+w/2,yTop); c.lineTo(cx+w/2,yTop+Hs+hc+12); c.stroke();
  /* 弁（左＝吸気、右＝排気）と点火プラグ */
  var vlv=function(x, open, col){ var d=open? 8 : 0; c.strokeStyle=col; c.lineWidth=3; c.beginPath(); c.moveTo(x, yTop-wt-14); c.lineTo(x, yTop+d-1); c.stroke();
    c.fillStyle=col; c.beginPath(); c.moveTo(x-9,yTop+d); c.lineTo(x+9,yTop+d); c.lineTo(x+4,yTop+d-4); c.lineTo(x-4,yTop+d-4); c.closePath(); c.fill(); };
  vlv(cx-w*0.30, st.inOpen, dark? "#9fd0ff" : "#1f6fb2"); vlv(cx+w*0.30, st.exOpen, dark? "#ffa48f" : "#b5462e");
  c.fillStyle=dark? "#e6edf5" : "#3a414c"; c.fillRect(cx-3, yTop-wt-16, 6, 14);
  if(st.spark){ c.strokeStyle="#fff3a0"; c.lineWidth=2; c.beginPath(); c.moveTo(cx,yTop+1); c.lineTo(cx-4,yTop+6); c.lineTo(cx+3,yTop+8); c.lineTo(cx-2,yTop+13); c.stroke(); }
  /* ピストン・連接棒・クランク */
  var cyc=yTop+hc+Hs+Hs*0.95, rc=Hs/2, ang=st.th, kx=cx+rc*Math.sin(ang), ky=cyc-rc*Math.cos(ang);
  var pc=c.createLinearGradient(cx-w/2,0,cx+w/2,0); pc.addColorStop(0,dark? "#5d6b7c" : "#9aa1ab"); pc.addColorStop(0.5,dark? "#9fb0c3" : "#e3e6ea"); pc.addColorStop(1,dark? "#5d6b7c" : "#9aa1ab");
  c.fillStyle=pc; c.strokeStyle=dark? "rgba(222,232,245,.7)" : "#4b535e"; c.lineWidth=1.2; c.fillRect(cx-w/2+1, yp, w-2, pt); c.strokeRect(cx-w/2+1, yp, w-2, pt);
  c.strokeStyle=dark? "rgba(222,232,245,.75)" : "#5b636e"; c.lineWidth=5; c.lineCap="round"; c.beginPath(); c.moveTo(cx, yp+pt*0.6); c.lineTo(kx,ky); c.stroke();
  c.lineWidth=1.3; c.beginPath(); c.arc(cx,cyc,rc+7,0,7); c.stroke();
  c.lineWidth=6; c.beginPath(); c.moveTo(cx,cyc); c.lineTo(kx,ky); c.stroke();
  c.fillStyle=dark? "#4fa8ff" : "#3a414c"; c.beginPath(); c.arc(cx,cyc,4.5,0,7); c.fill(); c.beginPath(); c.arc(kx,ky,4,0,7); c.fill();
  c.restore();
  return {yp:yp, cyc:cyc, rc:rc, hc:hc, T:T};
}
