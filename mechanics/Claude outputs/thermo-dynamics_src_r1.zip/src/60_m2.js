/* =========================================================================
   モード② 気体分子運動論（2-1〜2-4）
   ========================================================================= */
/* 壁で弾性衝突をくり返す 1 方向の動き：展開した座標 u → 0〜1 の位置（三角波） */
function tri(u){ u=((u%2)+2)%2; return u<1? u : 2-u; }

/* ---------------- ②-1 分子 1 個が壁に与える力積 ----------------
   立方体（一辺 L＝1）。x：右、y：奥、z：上（教科書の図と同じ）。壁 S は x＝L の面。
   0〜4 s：斜め上から見る → 4〜6 s：横から（y 方向に）見た図へ回る → 6〜16 s：横から見た図。
   下に x 方向だけの動き（一定の時間ごとの位置を残す）と、壁 S が受ける力の時間変化 */
var S21 = {
  DUR:16, T1:4, T2:6, vx:0.70, vy:0.31, vz:0.22, x0:0.22, y0:0.35, z0:0.30,
  STEPS:[
    ['1 回の衝突で、分子の運動量の '+'$x$'+' 成分は $mv_x$ から $-mv_x$ に変わる（$y$・$z$ 成分は変わらない）。分子が壁 S から受ける力積は','$-mv_x-mv_x=-2mv_x$','作用・反作用の法則より、壁 S が分子から受ける力積は、大きさ $2mv_x$、$x$ 軸の正の向き。'],
    ['$x$ 方向だけを見ると、分子は距離 $2L$ を速さ $v_x$ で進むと、再び壁 S に衝突する。衝突の周期は','$\\dfrac{2L}{v_x}$',''],
    ['時間 $t$ の間に壁 S に衝突する回数は','$t\\div\\dfrac{2L}{v_x}=\\dfrac{v_xt}{2L}$',''],
    ['時間 $t$ の間に、壁 S が 1 個の分子から受ける力積の合計は','$2mv_x\\times\\dfrac{v_xt}{2L}=\\dfrac{m{v_x}^2}{L}t$',''],
    ['この力積を、一定の力 $\\overline{f}$ が時間 $t$ の間はたらいたものと考えると $\\overline{f}t=\\dfrac{m{v_x}^2}{L}t$ より','$\\overline{f}=\\dfrac{m{v_x}^2}{L}$','これが、壁 S が 1 個の分子から受ける平均の力。下のグラフでは、とがった山の面積（1 回の力積）と、点線の長方形の面積が等しい。']],
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.step=1;
    this.run=new Runner({
      step:function(dt){ self.tb.sync(); return self.run.t>=self.DUR; },
      draw:function(){ self.draw(); }, reset:function(){} });
    this.run.bind(sec);
    this.tb=wireTimeBar(sec, this.run, function(){ return self.DUR; }, function(){});
    sec.querySelectorAll(".stp21").forEach(function(b){ b.addEventListener("click", function(){ self.step=(b.dataset.d==="1")? Math.min(self.STEPS.length, self.step+1) : 1; self.steps(); }); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.step=1; self.steps(); resetSlow(sec,self.run); self.run.reset(); self.tb.sync(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    this.steps(); this.draw();
  },
  steps:function(){ var h="", self=this;
    this.STEPS.slice(0,this.step).forEach(function(s,i){ h+='<div class="st21'+(i===self.step-1? ' now' : '')+'"><span class="sn">'+(i+1)+'</span><p>'+TX(s[0])+'</p><div class="qeq">'+TX("$$"+s[1].slice(1,-1)+"$$")+'</div>'+(s[2]? '<p>'+TX(s[2])+'</p>' : '')+'</div>'; });
    this.sec.querySelector(".steps21").innerHTML=h;
    this.sec.querySelectorAll(".stp21")[0].disabled=(this.step>=this.STEPS.length); },
  pos:function(t){ return [tri(this.x0+this.vx*t), tri(this.y0+this.vy*t), tri(this.z0+this.vz*t)]; },
  /* 壁 S に当たった時刻（t 以下） */
  hits:function(t){ var a=[], u0=this.x0; for(var k=0;k<40;k++){ var th=(2*k+1-u0)/this.vx; if(th>t) break; a.push(th); } return a; },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return W<680? clamp(W*1.45, 560, 680) : clamp(W*0.62, 440, 560); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var t=this.run.t, narrow=W<680;
    /* 視点：θ＝1 斜め上から、θ＝0 横から（y の向きに見る） */
    var th = t<this.T1? 1 : t<this.T2? 1-(t-this.T1)/(this.T2-this.T1) : 0; th=th*th*(3-2*th);
    var yaw=-0.62*th, pitch=0.40*th;
    var bw=narrow? W*0.62 : W*0.40, s=Math.min(bw*0.74, (narrow? H*0.36 : H*0.52)), cx=narrow? W*0.50 : W*0.27, cy=narrow? H*0.27 : H*0.38;
    var pr=function(x,y,z){ var X=x-0.5, Y=y-0.5, Z=z-0.5;
      var x1=X*Math.cos(yaw)+Y*Math.sin(yaw), y1=-X*Math.sin(yaw)+Y*Math.cos(yaw);
      var z2=Z*Math.cos(pitch)+y1*Math.sin(pitch), d=y1*Math.cos(pitch)-Z*Math.sin(pitch);
      return [cx+x1*s, cy-z2*s, d]; };
    /* 立方体：面 S（x＝1）を色で */
    var V8=[[0,0,0],[1,0,0],[1,1,0],[0,1,0],[0,0,1],[1,0,1],[1,1,1],[0,1,1]].map(function(q){ return pr(q[0],q[1],q[2]); });
    c.save(); c.fillStyle="rgba(150,160,175,.30)"; c.beginPath(); [1,2,6,5].forEach(function(i,k){ var q=V8[i]; if(k) c.lineTo(q[0],q[1]); else c.moveTo(q[0],q[1]); }); c.closePath(); c.fill(); c.restore();
    c.save(); c.fillStyle="rgba(190,225,250,.25)"; c.beginPath(); [0,1,5,4].forEach(function(i,k){ var q=V8[i]; if(k) c.lineTo(q[0],q[1]); else c.moveTo(q[0],q[1]); }); c.closePath(); c.fill(); c.restore();
    var E=[[0,1],[1,2],[2,3],[3,0],[4,5],[5,6],[6,7],[7,4],[0,4],[1,5],[2,6],[3,7]];
    c.save(); c.strokeStyle="#5b636e"; c.lineWidth=1.4; E.forEach(function(e){ var a=V8[e[0]], b=V8[e[1]]; c.beginPath(); c.moveTo(a[0],a[1]); c.lineTo(b[0],b[1]); c.stroke(); }); c.restore();
    var sS=pr(1,0.5,0.82); T(c, "S", sS[0]+(th>0.3? 10 : 9), sS[1], {size:15, bold:true, serif:true, col:"#3a414c", halo:true});
    /* 軸 */
    var O=pr(0,0,0); T(c,"O",O[0]-6,O[1]+10,{size:12,it:true,col:COL.sub,align:"right"});
    var ax=pr(1.22,0,0), az=pr(0,0,1.2), ay=pr(0,1.25,0);
    arrow(c,O[0],O[1],ax[0],ax[1],"#3a414c",1.3,8); SYM(c,"x",null,ax[0]+5,ax[1]+2,{size:14,col:"#3a414c"});
    arrow(c,O[0],O[1],az[0],az[1],"#3a414c",1.3,8); SYM(c,"z",null,az[0]+5,az[1],{size:14,col:"#3a414c"});
    if(th>0.15){ c.save(); c.globalAlpha=th; arrow(c,O[0],O[1],ay[0],ay[1],"#3a414c",1.3,8); SYM(c,"y",null,ay[0]+5,ay[1],{size:14,col:"#3a414c"}); c.restore(); }
    var lb=pr(0.5,0,0); T(c,"L",lb[0],lb[1]+14,{size:13,it:true,col:COL.sub,align:"center"});
    /* 分子の通り道（最近の 2 秒）と分子 */
    c.save(); c.setLineDash([3,3]); c.strokeStyle="rgba(31,111,178,.45)"; c.lineWidth=1.2; c.beginPath();
    for(var k=0;k<=60;k++){ var tt=Math.max(0,t-2.2+2.2*k/60), q=this.pos(tt), P=pr(q[0],q[1],q[2]); if(k) c.lineTo(P[0],P[1]); else c.moveTo(P[0],P[1]); } c.stroke(); c.restore();
    var q=this.pos(t), M=pr(q[0],q[1],q[2]);
    ball(c, M[0], M[1], 9, 0, "#f0b429");
    /* 速度（分子の上に少しはなして）：斜めのときは速度 v、横からのときは x 成分 */
    var u=this.x0+this.vx*t, sx=(((u%2)+2)%2)<1? 1 : -1, sz=(((this.z0+this.vz*t)%2)<1)? 1 : -1, sy=(((this.y0+this.vy*t)%2)<1)? 1 : -1;
    var vk=s*0.55, P1=pr(q[0]+sx*this.vx*0.55, q[1]+sy*this.vy*0.55, q[2]+sz*this.vz*0.55), d0=[P1[0]-M[0], P1[1]-M[1]];
    arrow(c, M[0], M[1]-24, M[0]+d0[0], M[1]-24+d0[1], COLG.vel, 2.4, 9);
    SYM(c, "v", null, M[0]+d0[0]+(d0[0]>=0? 6 : -6), M[1]-24+d0[1]-6, {size:14, bold:true, col:COLG.vel, halo:true, align:d0[0]>=0? "left" : "right"});
    /* 壁 S が受ける力積（当たってから 0.5 s） */
    var hs=this.hits(t), lastH=hs.length? hs[hs.length-1] : -9;
    if(t-lastH<0.6){ var a=1-(t-lastH)/0.6, Sp=pr(1,q[1],q[2]); c.save(); c.globalAlpha=a; fArrow(c, Sp[0], Sp[1]+14, Sp[0]+s*0.26, Sp[1]+14, COLG.imp, 3.2, 11);
      T(c, "壁 S が受ける力積 2mvₓ", Sp[0]+6, Sp[1]+34, {size:11.5, bold:true, col:COLG.imp, halo:true}); c.restore(); }
    /* x 方向だけの動き（横から見た図になってから）：一定の時間ごとの位置を残す */
    var sy0=narrow? cy+s*0.62+46 : cy+s*0.62+52, xl=pr(0,0.5,0)[0], xr=pr(1,0.5,0)[0];
    if(t>this.T2-0.6){ var al=clamp((t-this.T2+0.6)/0.6,0,1);
      c.save(); c.globalAlpha=al;
      c.strokeStyle="#3a414c"; c.lineWidth=1.3; c.beginPath(); c.moveTo(xl, sy0); c.lineTo(xr, sy0); c.stroke();
      c.fillStyle="#c9ced6"; c.fillRect(xr, sy0-16, 6, 32); c.fillRect(xl-6, sy0-16, 6, 32); T(c,"S",xr+12,sy0-10,{size:13,bold:true,serif:true,col:"#3a414c"});
      T(c, "x 方向だけを見た動き（0.4 秒ごとの位置）", xl, sy0-30, {size:11.5, bold:true, col:COL.ink});
      for(var tt=this.T2; tt<=t+1e-6; tt+=0.4){ var gx=xl+(xr-xl)*tri(this.x0+this.vx*tt); c.beginPath(); c.arc(gx, sy0, 3.2, 0, 7); c.fillStyle="rgba(31,111,178,.35)"; c.fill(); }
      var gx2=xl+(xr-xl)*q[0]; ball(c, gx2, sy0, 7, 0, "#f0b429");
      arrow(c, gx2, sy0-18, gx2+sx*42, sy0-18, COLG.vel, 2.4, 9); SYM(c, "v", "x", gx2+sx*42+(sx>0? 5 : -5), sy0-22, {size:13, bold:true, col:COLG.vel, halo:true, align:sx>0? "left" : "right"});
      T(c, "点の間隔はいつも同じ → 一定の速さ "+"vₓ"+" で往復", xl, sy0+26, {size:11, bold:true, col:"#1f6fb2"});
      c.restore(); }
    /* 力の時間変化（横から見た図になってから） */
    var gx0=narrow? 50 : W*0.58, gy0=narrow? H-34 : H*0.56, gx1=W-14, gy1=narrow? sy0+50 : 28;
    if(t>this.T2-0.6){
      var P=plotFrame(c, gx0, gy0, gx1, gy1, [0,this.DUR-this.T2], [0,1.25], {noYt:true, noXt:true, xl:"t（時間）", yl:"f（壁 S が受ける力）"});
      var per=2/this.vx, wpk=0.6, hp=1.1, fb=hp*wpk/2/per;   /* 山（三角形）の面積 hp×wpk/2 ＝ 平均の力 × 周期 */
      var hh1=hs.filter(function(x){ return x>=self.T2; });
      if(hh1.length>=1){ var r0=hh1[0]-this.T2; c.save(); c.fillStyle="rgba(28,143,74,.16)"; c.strokeStyle="rgba(28,143,74,.7)"; c.setLineDash([4,3]);
        c.fillRect(P.X(Math.max(0,r0)), P.Y(fb), P.X(r0+per)-P.X(Math.max(0,r0)), P.Y(0)-P.Y(fb)); c.strokeRect(P.X(Math.max(0,r0)), P.Y(fb), P.X(r0+per)-P.X(Math.max(0,r0)), P.Y(0)-P.Y(fb)); c.restore(); }
      c.save(); c.setLineDash([5,4]); c.strokeStyle="#1c8f4a"; c.lineWidth=1.6; c.beginPath(); c.moveTo(P.X(0),P.Y(fb)); c.lineTo(P.X(this.DUR-this.T2),P.Y(fb)); c.stroke(); c.restore();
      SYM(c, "f", null, P.X(this.DUR-this.T2)-30, P.Y(fb)-10, {size:13, bold:true, col:"#1c8f4a"}); c.save(); c.strokeStyle="#1c8f4a"; c.lineWidth=1.2; c.beginPath(); c.moveTo(P.X(this.DUR-this.T2)-31,P.Y(fb)-19); c.lineTo(P.X(this.DUR-this.T2)-24,P.Y(fb)-19); c.stroke(); c.restore();
      hs.forEach(function(h0){ var hh=h0-self.T2; if(hh<-wpk) return; c.save(); c.fillStyle="rgba(192,21,138,.55)"; c.strokeStyle=COLG.imp; c.beginPath();
        c.moveTo(P.X(Math.max(0,hh-wpk/2)),P.Y(0)); c.lineTo(P.X(Math.max(0,hh)),P.Y(hp)); c.lineTo(P.X(Math.max(0,hh+wpk/2)),P.Y(0)); c.closePath(); c.fill(); c.stroke(); c.restore(); });
      /* 周期 */
      var hh2=hs.filter(function(x){ return x>=self.T2; });
      if(hh2.length>=2){ var a1=P.X(hh2[0]-this.T2), a2=P.X(hh2[1]-this.T2), yy=P.Y(hp)-10; dimArrow(c,a1,yy,a2,yy,"#3a414c"); T(c,"衝突の周期 2L/vₓ",(a1+a2)/2,yy-11,{size:11,bold:true,col:"#3a414c",align:"center",halo:true}); }
      T(c, "1 回の山の面積 ＝ 力積 2mvₓ", P.x0+6, P.y1+6, {size:11, bold:true, col:COLG.imp, halo:true});
      var ct=P.X(Math.max(0,t-this.T2)); c.save(); c.strokeStyle="rgba(192,57,43,.6)"; c.lineWidth=1; c.beginPath(); c.moveTo(ct,P.Y(0)); c.lineTo(ct,P.y1); c.stroke(); c.restore();
    }
    notebook(c,W,H);
    var nh=hs.length, mh= t<this.T1? '斜め上から見た図。分子は 3 つの方向の速度成分 '+tex("v_x")+'・'+tex("v_y")+'・'+tex("v_z")+' をもち、壁に当たるとその壁に垂直な成分だけ向きが変わる。' :
      t<this.T2? '横から（'+tex("y")+' 軸の向きに）見た図に変わっていく。' :
      '壁 S に当たった回数：<span class="num">'+nh+'</span> 回。'+tex("x")+' 方向の速さは、いつも '+tex("v_x")+' のまま。';
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};

/* ---------------- ②-2 N 個の分子と圧力 ----------------
   横から見た箱（x：右、z：上）。壁 S は右。分子どうしは当たらない（位置は三角波で決まる）。
   壁 S が受ける力：0.05 s ごとの力積の合計（ぎざぎざ）と、時間平均（だんだん一定に近づく） */
var S22 = {
  DUR:12, BIN:0.2,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.N=30; this.T=300; this.make();
    this.run=new Runner({ step:function(dt){ self.tb.sync(); return self.run.t>=self.DUR; }, draw:function(){ self.draw(); }, reset:function(){} });
    this.run.bind(sec);
    this.tb=wireTimeBar(sec, this.run, function(){ return self.DUR; }, function(){});
    this.sN=wireSlider(sec,"N",function(v){ return v.toFixed(0)+" 個"; },function(v){ self.N=v; self.make(); self.run.touch(); self.run.reset(); self.tb.sync(); });
    this.sT=wireSlider(sec,"T",function(v){ return v.toFixed(0)+" K"; },function(v){ self.T=v; self.run.reset(); self.tb.sync(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.N=30; self.T=300; self.sN.set(30); self.sT.set(300); self.make(); resetSlow(sec,self.run); self.run.reset(); self.tb.sync(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    this.draw();
  },
  make:function(){ var R=rng(22), a=[]; for(var i=0;i<80;i++){ a.push({x0:R(), z0:R(), vx:gauss(R), vy:gauss(R), vz:gauss(R)}); }
    var s=0; a.forEach(function(q){ s+=q.vx*q.vx+q.vy*q.vy+q.vz*q.vz; }); var k=Math.sqrt(3*a.length/s); a.forEach(function(q){ q.vx*=k; q.vy*=k; q.vz*=k; });
    this.all=a; },
  mols:function(){ return this.all.slice(0,this.N); },
  sp:function(){ return 0.16*Math.sqrt(this.T/300); },          /* 箱の幅 1 あたりの速さ（1 方向の 2 乗平均の平方根） */
  /* 壁 S に当たる時刻の一覧（展開した座標で） */
  hitTimes:function(q, t){ var v=Math.abs(q.vx)*this.sp(); if(v<1e-6) return []; var u0=(q.vx>=0)? q.x0 : 2-q.x0, a=[];
    for(var k=0;k<400;k++){ var th=(2*k+1-u0)/v; if(th>t) break; if(th>=0) a.push(th); } return a; },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return W<640? clamp(W*1.2, 460, 560) : clamp(W*0.50, 340, 420); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var t=this.run.t, narrow=W<640, M=this.mols(), sp=this.sp();
    var bw=narrow? W-120 : W*0.34, bh=narrow? H*0.34 : H*0.56, bx=narrow? 40 : 34, by=24;
    /* 箱（横から見た図） */
    c.save(); c.fillStyle="rgba(190,225,250,.22)"; c.fillRect(bx,by,bw,bh); c.strokeStyle="#5b636e"; c.lineWidth=1.6; c.strokeRect(bx,by,bw,bh);
    c.fillStyle="#c9ced6"; c.fillRect(bx+bw, by, 8, bh); c.restore(); T(c,"S",bx+bw+14,by+bh/2,{size:15,bold:true,serif:true,col:"#3a414c"});
    var flash=0;
    M.forEach(function(q){ var x=tri(((q.vx>=0)? q.x0 : 2-q.x0)+Math.abs(q.vx)*sp*t), z=tri(q.z0+q.vz*sp*t);
      ball(c, bx+5+(bw-10)*x, by+bh-5-(bh-10)*z, 4.5, 0, "#f0b429"); });
    /* 力のグラフ：ビンごとの力積 */
    var gx0=narrow? 46 : W*0.44, gy0=narrow? H-34 : H*0.56+by-8, gx1=W-14, gy1=narrow? by+bh+46 : 24;
    var nb=Math.round(this.DUR/this.BIN), bins=new Array(nb).fill(0), tot=0, self2=this;
    M.forEach(function(q){ self2.hitTimes(q, t).forEach(function(th){ var b=Math.min(nb-1, Math.floor(th/self2.BIN)); bins[b]+=2*Math.abs(q.vx)*sp; tot+=2*Math.abs(q.vx)*sp; }); });
    var Fth=0; M.forEach(function(q){ Fth+=q.vx*q.vx*sp*sp; });           /* Σ m vₓ²/L（m＝1、L＝1） */
    var Fref=30*0.0256*Math.max(1,this.T/300)*1.0, ymax=Math.max(Fth*3.2, 0.0256*3*10*this.T/300);
    var P=plotFrame(c, gx0, gy0, gx1, gy1, [0,this.DUR], [0,ymax], {noYt:true, xl:"t〔s〕", yl:"F（壁 S が受ける力）", xstep:2});
    c.save(); c.beginPath(); c.rect(P.x0,P.y1-14,P.x1-P.x0+14,P.y0-P.y1+14); c.clip();
    c.fillStyle="rgba(192,21,138,.5)"; var nn=Math.floor(t/this.BIN);
    for(var i=0;i<nn && i<nb;i++){ var F=bins[i]/this.BIN; if(F>0) c.fillRect(P.X(i*this.BIN), P.Y(Math.min(F,ymax*1.2)), Math.max(1,P.X(this.BIN)-P.X(0)-0.5), P.Y(0)-P.Y(Math.min(F,ymax*1.2))); }
    /* 時間平均 */
    c.strokeStyle="#c0392b"; c.lineWidth=2.4; c.beginPath(); var cum=0, st=false;
    for(var j=0;j<nn && j<nb;j++){ cum+=bins[j]; var tt=(j+1)*this.BIN; if(tt<0.4) continue; var av=cum/tt; if(!st){ c.moveTo(P.X(tt),P.Y(av)); st=true; } else c.lineTo(P.X(tt),P.Y(av)); }
    c.stroke();
    c.setLineDash([6,4]); c.strokeStyle="#1c8f4a"; c.lineWidth=1.6; c.beginPath(); c.moveTo(P.X(0),P.Y(Fth)); c.lineTo(P.X(this.DUR),P.Y(Fth)); c.stroke(); c.restore();
    T(c,"時間で平均した力", P.X(this.DUR)-4, P.Y(Fth)-26, {size:11, bold:true, col:"#c0392b", align:"right", halo:true});
    T(c,"Nm v̄ₓ²/L（点線）", P.X(this.DUR)-4, P.Y(Fth)+14, {size:11, bold:true, col:"#1c8f4a", align:"right", halo:true});
    /* v̄ₓ²・v̄ᵧ²・v̄z² の棒（箱の下） */
    var sx=0, sy=0, sz=0; M.forEach(function(q){ sx+=q.vx*q.vx; sy+=q.vy*q.vy; sz+=q.vz*q.vz; }); var n=Math.max(1,M.length); sx/=n; sy/=n; sz/=n;
    var b0=by+bh+(narrow? 16 : 30), bb=narrow? 0 : 0, bwid=narrow? (bw)/3.2 : bw/3.4, bmax=narrow? 0 : 0;
    if(!narrow){ var base=H-30, top=b0+20, sc=(base-top)/2.4;
      T(c, "速度成分の 2 乗の平均（N 個の分子）", bx, b0+4, {size:11.5, bold:true});
      [[sx,"x","#c0392b"],[sy,"y","#1f6fb2"],[sz,"z","#1c8f4a"]].forEach(function(o,i){ var x=bx+14+i*bwid*1.1, h=Math.min(o[0],2.4)*sc;
        c.save(); c.fillStyle=o[2]; c.globalAlpha=0.8; c.fillRect(x, base-h, bwid*0.7, h); c.restore();
        T(c, "v̄"+o[1]+"²", x+bwid*0.35, base+11, {size:11, bold:true, col:o[2], align:"center"}); });
      c.save(); c.setLineDash([4,3]); c.strokeStyle="#69717d"; c.beginPath(); c.moveTo(bx+6, base-sc); c.lineTo(bx+14+3*bwid*1.1, base-sc); c.stroke(); c.restore();
      T(c, "v̄²の 1/3", bx+18+3*bwid*1.1, base-sc, {size:10.5, col:COL.sub}); }
    notebook(c,W,H);
    var av2=tot/Math.max(t,0.4), mh='分子の数 '+tex("N")+' = <span class="num">'+M.length+'</span>　時間で平均した力は、点線の値に近づいていく'+(t>3? '（いま <span class="num">'+(av2/Fth*100).toFixed(0)+'</span> %）' : '')+'。<br>'+
      '分子の数が多いほど、ぎざぎざは細かくなり、力はほぼ一定とみなせる。速度成分の 2 乗の平均：'+tex(VX2B)+' : '+tex("\\overline{{v_y}^2}")+' : '+tex("\\overline{{v_z}^2}")+' = '+sx.toFixed(2)+' : '+sy.toFixed(2)+' : '+sz.toFixed(2);
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};

/* ---------------- ②-3 温度と分子の運動エネルギー ----------------
   左：ヘリウム、右：選んだ気体。分子の速さは √(RT/M)（1 方向）に比例させて描く。下に速さの分布（参考） */
var GASES = { He:{name:"ヘリウム He", M:4.0e-3, r:3.6, col:"#f0b429"}, N2:{name:"窒素 N₂", M:28e-3, r:5.6, col:"#4f8fd6"}, O2:{name:"酸素 O₂", M:32e-3, r:5.9, col:"#d9534f"}, CO2:{name:"二酸化炭素 CO₂", M:44e-3, r:6.6, col:"#6b7f3a"} };
var S23 = {
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.g="N2"; this.T=300; this.A=new Gas(18, 31); this.B=new Gas(18, 32);
    this.sg=wireSeg(sec,"gas",function(v){ self.g=v; self.draw(); });
    this.sT=wireSlider(sec,"T",function(v){ return v.toFixed(0)+" K"; },function(v){ self.T=v; self.draw(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.g="N2"; self.sg.set("N2"); self.T=300; self.sT.set(300); self.draw(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    idleLoop(sec, function(dt){ var b=self.bx; if(b){ self.A.step(dt, b.w, b.h, self.vpx("He"), GASES.He.r); self.B.step(dt, b.w, b.h, self.vpx(self.g), GASES[self.g].r); } self.draw(); });
    this.draw();
  },
  vrms:function(k){ return Math.sqrt(3*RGAS*this.T/GASES[k].M); },
  vpx:function(k){ return this.vrms(k)/Math.sqrt(3)*0.055; },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return W<600? clamp(W*1.2, 430, 520) : clamp(W*0.55, 360, 440); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var narrow=W<600, gap=16, bw=(W-3*gap)/2, bh=narrow? H*0.36 : H*0.42, by=28;
    this.bx={w:bw, h:bh};
    var KE=1.5*KB*this.T;
    [["He",this.A],[this.g,this.B]].forEach(function(o,i){ var g=GASES[o[0]], x0=gap+i*(bw+gap);
      c.save(); c.fillStyle="rgba(190,225,250,.20)"; c.fillRect(x0,by,bw,bh); c.strokeStyle="#5b636e"; c.lineWidth=1.4; c.strokeRect(x0,by,bw,bh); c.restore();
      o[1].m.forEach(function(q){ ball(c, x0+g.r+(bw-2*g.r)*q.x, by+g.r+(bh-2*g.r)*q.y, g.r, 0, g.col); });
      T(c, g.name+"（分子量 "+Math.round(g.M*1000)+"）", x0+bw/2, by-12, {size:12.5, bold:true, align:"center"});
      var y1=by+bh+18;
      T(c, "½mv̄² = "+(KE*1e21).toFixed(2)+"×10⁻²¹ J", x0+bw/2, y1, {size:narrow? 11 : 12, bold:true, col:"#7b3fd4", align:"center"});
      T(c, "√v̄² = "+Math.round(self.vrms(o[0]))+" m/s", x0+bw/2, y1+19, {size:narrow? 11 : 12, bold:true, col:g.col==="#f0b429"? "#9c6b00" : g.col, align:"center"});
    });
    /* 速さの分布（参考） */
    var gx0=40, gy0=H-34, gx1=W-14, gy1=by+bh+58;
    var P=plotFrame(c, gx0, gy0, gx1, gy1, [0,4000], [0,1], {noYt:true, xl:"v〔m/s〕", yl:"分子の数の割合", xstep:1000});
    var fv=function(k,v){ var a=GASES[k].M/(2*RGAS*self.T); return v*v*Math.exp(-a*v*v)*Math.pow(a,1.5); };
    var mx=0; ["He",this.g].forEach(function(k){ for(var v=0; v<=4000; v+=20) mx=Math.max(mx, fv(k,v)); });
    [["He","#c7930a"],[this.g,GASES[this.g].col]].forEach(function(o){
      c.save(); c.strokeStyle=o[1]; c.lineWidth=2.4; c.beginPath(); for(var v=0; v<=3990; v+=20){ var y=fv(o[0],v)/mx*0.92; if(v) c.lineTo(P.X(v),P.Y(y)); else c.moveTo(P.X(v),P.Y(y)); } c.stroke();
      var vr=self.vrms(o[0]); if(vr<3990){ c.setLineDash([4,3]); c.lineWidth=1.2; c.beginPath(); c.moveTo(P.X(vr),P.Y(0)); c.lineTo(P.X(vr),P.Y(fv(o[0],vr)/mx*0.92)); c.stroke(); } c.restore(); });
    T(c, "参考：速さの分布（点線の位置が √v̄²）", P.x1, P.y1+2, {size:10.5, col:COL.sub, align:"right", halo:true});
    notebook(c,W,H);
    var r=this.vrms("He")/this.vrms(this.g), mh='温度 '+tex("T")+' = <span class="num">'+this.T+'</span> K のとき、分子 1 個の平均の運動エネルギー '+tex("\\frac{1}{2}m"+V2B+"=\\frac{3}{2}kT")+' は、どちらの気体も <span class="num">'+(KE*1e21).toFixed(2)+'</span>×10⁻²¹ J。<br>'+
      'ヘリウムの '+tex("\\sqrt{"+V2B+"}")+' は '+GASES[this.g].name+' の <span class="num">'+r.toFixed(2)+'</span> 倍（分子量の比の平方根 '+tex("\\sqrt{"+Math.round(GASES[this.g].M*1000)+"/4}")+'）。';
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};

/* ---------------- ②-4 内部エネルギー ----------------
   分子 1 個ずつの運動エネルギーの棒と、その和 U＝3/2 nRT。体積を変えても U は同じ */
var S24 = {
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.T=300; this.n=1.0; this.V=2.5; this.gas=new Gas(20, 41);
    this.sT=wireSlider(sec,"T",function(v){ return v.toFixed(0)+" K"; },function(v){ self.T=v; self.draw(); });
    this.sn=wireSlider(sec,"n",function(v){ return v.toFixed(1)+" mol"; },function(v){ self.n=v; self.gas.setN(Math.round(v*20)); self.draw(); });
    this.sV=wireSlider(sec,"V",function(v){ return v.toFixed(1)+" ×10⁻² m³"; },function(v){ self.V=v; self.draw(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.T=300; self.n=1.0; self.V=2.5; self.sT.set(300); self.sn.set(1); self.sV.set(2.5); self.gas.setN(20); self.draw(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    idleLoop(sec, function(dt){ if(self.bx) self.gas.step(dt, self.bx.w, self.bx.h, 55*Math.sqrt(self.T/300), 4.2); self.draw(); });
    this.draw();
  },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return W<600? clamp(W*1.05, 400, 480) : clamp(W*0.42, 300, 360); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var narrow=W<600, aw=narrow? W : W*0.46, h=narrow? 90 : 120, Lm=aw-70, L=Lm*this.V/5.0, ox=26, cy=narrow? 30+h/2 : H*0.45;
    this.bx={w:L, h:h};
    var F=new CylFrame(ox, cy, "right");
    drawCylinder(c, F, {L:L, Lmax:Lm, h:h, T:this.T, gas:this.gas, r:4.2, pt:12, rod:Lm-L+20});
    /* 1 個ずつの運動エネルギーの棒 */
    var m=this.gas.m, v2=this.gas.v2()||3, e1=1.5*KB*this.T;
    var gx0=narrow? 48 : aw+30, gy0=H-40, gx1=W-14, gy1=narrow? cy+h/2+40 : 30;
    var emax=e1*4, P=plotFrame(c, gx0, gy0, gx1-70, gy1, [0,1], [0,emax*1e21], {noXt:true, noO:false, xl:"", yl:"½mv²〔×10⁻²¹ J〕", ystep:niceStep(emax*1e21,4)});
    var nb=m.length, bw=(P.x1-P.x0-8)/Math.max(nb,1);
    m.forEach(function(q,i){ var e=(q.vx*q.vx+q.vy*q.vy+q.vz*q.vz)/v2*e1; c.save(); c.fillStyle=heatCol(clamp(e/emax*1.6,0,1)); c.fillRect(P.x0+4+i*bw, P.Y(Math.min(e,emax)*1e21), Math.max(1,bw-1.5), P.Y(0)-P.Y(Math.min(e,emax)*1e21)); c.restore(); });
    c.save(); c.setLineDash([5,4]); c.strokeStyle="#7b3fd4"; c.lineWidth=1.5; c.beginPath(); c.moveTo(P.x0,P.Y(e1*1e21)); c.lineTo(P.x1,P.Y(e1*1e21)); c.stroke(); c.restore();
    T(c, "平均 3/2 kT", P.x1+4, P.Y(e1*1e21), {size:10.5, bold:true, col:"#7b3fd4"});
    T(c, "分子 1 個ずつ（絵の分子の数だけ）", P.x0+4, P.y0+12, {size:10.5, col:COL.sub});
    /* U の値 */
    var U=1.5*this.n*RGAS*this.T, ux=narrow? W-14 : W-14;
    T(c, "U = "+Math.round(U)+" J", narrow? W-14 : W-14, narrow? cy+h/2+20 : 16, {size:15, bold:true, col:"#7b3fd4", align:"right", halo:true});
    notebook(c,W,H);
    var mh='内部エネルギー '+tex("U=\\dfrac{3}{2}nRT")+' = 3/2 × '+this.n.toFixed(1)+' × 8.31 × '+this.T+' = <span class="num">'+Math.round(U)+'</span> J'+
      '<br>体積 '+tex("V")+' = '+this.V.toFixed(1)+' ×10⁻² m³（体積を変えても、分子の速さは変わらないので '+tex("U")+' は同じ）';
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};
