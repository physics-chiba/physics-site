/* =========================================================================
   ページの骨組み：ヒーロー・タブ列・章の扉・節のカード・目次・アドレス（#1-2）
   骨組みは兄弟ページ thermal-energy.html の 80_page.js と同じ
   ========================================================================= */
var MODES = [
  {id:"mode1", name:"気体の法則", en:"Gas Laws",
   lead:"気体の状態は、物質量 "+tex("n")+"・圧力 "+tex("p")+"・体積 "+tex("V")+"・温度 "+tex("T")+" の 4 つの量で表せる。これらの間には、ボイルの法則・シャルルの法則、まとめると<b>理想気体の状態方程式</b> "+tex("pV=nRT")+" が成り立つ。",
   secs:["s11","s12","s13","s14","s15"]},
  {id:"mode2", name:"気体分子運動論", en:"Kinetic Theory of Gases",
   lead:"気体の圧力は、たくさんの分子が壁に衝突して与える力積から生まれる。分子の運動から圧力を求めると、<b>温度は分子の平均の運動エネルギー</b>を表していることが分かる。",
   secs:["s21","s22","s23","s24"]},
  {id:"mode3", name:"熱力学第一法則と p-V 図", en:"The First Law and p-V Diagrams",
   lead:"気体の内部エネルギーは、熱と仕事で変わる（"+tex("\\Delta U=Q+"+WD)+"）。気体がした仕事は p-V 図の面積で表せる。4 つの変化とモル比熱を、p-V 図とエネルギーの棒グラフで比べる。",
   secs:["s31","s32","s33"]},
  {id:"mode4", name:"熱サイクルと熱機関", en:"Heat Cycles and Heat Engines",
   lead:"状態を変化させて元に戻すことをくり返すと、熱を仕事に変え続けられる（<b>熱機関</b>）。p-V 図で囲まれた面積が、1 サイクルで取り出せる仕事になる。",
   secs:["s41","s42"]},
  {id:"mode5", name:"大学の内容", en:"Beyond High School",
   lead:"<b>カルノーサイクル</b>は、2 つの温度の間ではたらく熱機関の中で、熱効率が最も大きい理想的なサイクル。熱力学第二法則と深く結びついている。",
   secs:["s51"]}
];
var DEFS = {
  s11:{num:1, mode:0, title:"シリンダーに閉じ込められた気体 〜 <i>n</i>, <i>p</i>, <i>V</i>, <i>T</i> とは何か 〜", short:"n, p, V, T とは", sim:S11, noplay:true,
    desc:'シリンダーに閉じ込めた気体の状態は、物質量 '+tex("n")+'・圧力 '+tex("p")+'・体積 '+tex("V")+'・温度 '+tex("T")+' で表せる。<span class="todo">ポンプを押して分子を入れ、「熱を加える」「熱を奪う」を押してみよう。下の ± でも、それぞれの量を変えられる。</span><br>注目点：ピストンが自由に動くとき、熱を加えても圧力は大気圧のまま。温度が上がった分だけ体積が増える。',
    right:function(){ return '<div class="qcard"><p class="qt">4 つの量</p><table class="nstab">'+
      '<tr><td>物質量 '+tex("n")+'〔mol〕</td><td>分子の数の目安。'+tex("6.02\\times10^{23}")+' 個で 1 mol（アボガドロ定数 '+tex("N_\\mathrm{A}")+'）。分子の数は '+tex("N=nN_\\mathrm{A}")+'</td></tr>'+
      '<tr><td>圧力 '+tex("p")+'〔Pa〕</td><td>気体が面を押す、単位面積あたりの力。分子が壁に次々に衝突して生まれる（→ <a href="#2-2">②-2</a>）。'+tex("1\\,\\mathrm{Pa}=1\\,\\mathrm{N/m^2}")+'</td></tr>'+
      '<tr><td>体積 '+tex("V")+'〔m³〕</td><td>気体が占める空間の大きさ。気体は容器いっぱいに広がる</td></tr>'+
      '<tr><td>温度 '+tex("T")+'〔K〕</td><td>絶対温度。分子の熱運動の激しさを表す（→ <a href="#2-3">②-3</a>）。'+tex("T=t+273")+'</td></tr></table></div>'+
      '<div class="qcard"><p class="qt">ピストンが自由に動くとき</p><p>ピストンは、気体が押す力と大気が押す力がつり合う位置で止まる。だから気体の圧力は大気圧 '+tex("p_0=1.0\\times10^5\\,\\mathrm{Pa}")+' と同じになる（→ <a href="#1-2">①-2</a>）。</p>'+
      '<p>この状態で熱を加えると、圧力は変わらずに体積が増える（<b>定圧変化</b>）。</p></div>'; }},
  s12:{num:2, mode:0, title:"ピストンの力のつり合い", short:"力のつり合い", sim:S12, noplay:true,
    desc:'質量のあるピストンは、気体から押される力・大気から押される力・重力などがつり合って止まっている。<span class="todo">シリンダーの向きを切りかえて、ピストンにはたらく力と p-V 図の点の動きを見よう。</span><br>注目点：温度は変わらないので、点は同じ等温線（点線）の上を動く。',
    opts: H_seg("dir","シリンダーの向き",[["h","横"],["u","鉛直上向き"],["uw","鉛直上向き（おもりあり）"],["d","下向き"]],"h")+H_chk("force","力を表示",true),
    right:function(){ var e=function(s){ return '<div class="qeq">'+tex(s,true)+'</div>'; };
      return '<div class="qcard"><p class="qt">向きごとのつり合いの式</p>'+
      '<p>ピストンの質量 '+tex("m")+'、断面積 '+tex("S")+'、おもりの質量 '+tex("M")+'、大気圧 '+tex("p_0")+'、気体の圧力 '+tex("p")+'。</p>'+
      '<table class="nstab eqtab">'+
      '<tr><td>横</td><td>'+tex("pS=p_0S")+'<br>'+tex("p=p_0")+'</td></tr>'+
      '<tr><td>鉛直上向き</td><td>'+tex("pS=p_0S+mg")+'<br>'+tex("p=p_0+\\dfrac{mg}{S}")+'</td></tr>'+
      '<tr><td>鉛直上向き<br>（おもりあり）</td><td>'+tex("pS=p_0S+mg+Mg")+'<br>'+tex("p=p_0+\\dfrac{(m+M)g}{S}")+'</td></tr>'+
      '<tr><td>下向き</td><td>'+tex("pS+mg=p_0S")+'<br>'+tex("p=p_0-\\dfrac{mg}{S}")+'</td></tr></table>'+
      '<p>おもりがピストンを押す力の大きさは '+tex("Mg")+'（おもりにはたらく重力とつり合う垂直抗力の反作用）。</p></div>'+
      '<div class="qcard"><p class="qt">数値</p><p>'+tex("p_0=1.0\\times10^5\\,\\mathrm{Pa}")+'、'+tex("S=4.9\\times10^{-3}\\,\\mathrm{m^2}")+'、'+tex("m=10\\,\\mathrm{kg}")+'、'+tex("M=10\\,\\mathrm{kg}")+'、'+tex("g=9.8\\,\\mathrm{m/s^2}")+' とすると '+tex("\\dfrac{mg}{S}=2.0\\times10^4\\,\\mathrm{Pa}")+'。温度は 300 K のまま変わらないとする。</p></div>'+
      '<div class="qcard"><p class="qt">参考</p><p>大気が面を押す力と圧力の関係は、<a href="fluid-force.html#1-1">流体から受ける力 ①-1（吸盤と大気圧）</a> で確かめられる。</p></div>'; }},
  s13:{num:3, mode:0, title:"ボイルの法則", short:"ボイルの法則", sim:S13, mid:H_timebar(),
    desc:'温度を一定に保ったまま、ピストンをゆっくり動かして気体の体積を変える。<span class="todo">「押す｜引く」を選んでスタートを押し、p-V 図に打たれていく点と、ピストンに分子が当たる回数を見よう。</span><br>注目点：体積が半分になると、1 秒あたりにピストンに当たる回数は 2 倍になり、圧力も 2 倍になる。',
    opts: H_seg("dirb","手の動き",[["push","押す（圧縮）"],["pull","引く（膨張）"]],"push")+H_seg("tb","温度",[["300","300 K"],["600","600 K"]],"300"),
    right:function(){ return '<div class="qcard"><p class="qt">ボイルの法則</p><p>温度が一定のとき、一定質量の気体の体積 '+tex("V")+' は圧力 '+tex("p")+' に反比例する。</p>'+
      '<div class="qeq">'+tex("pV=\\text{一定}",true)+'</div><p>p-V 図のグラフは反比例のグラフ（双曲線）。温度が高いほど、グラフは右上にある。</p></div>'+
      '<div class="qcard"><p class="qt">分子で考えると</p><p>体積が半分になると、分子が壁の間を往復する距離が短くなり、同じ時間に壁に当たる回数が 2 倍になる。1 回あたりの力積は変わらないので（温度が同じ）、圧力が 2 倍になる。</p></div>'; }},
  s14:{num:4, mode:0, title:"シャルルの法則", short:"シャルルの法則", sim:S14, mid:H_timebar(),
    desc:'ピストンの上におもりをのせ、圧力を一定に保ったまま気体の温度を変える。<span class="todo">「温める｜冷やす」を選んでスタートを押そう。</span><br>注目点：V–T グラフは原点を通る直線。直線をのばすと、0 K（−273 ℃）で体積が 0 になる。',
    opts: H_seg("hc","操作",[["heat","温める"],["cool","冷やす"]],"heat"),
    right:function(){ return '<div class="qcard"><p class="qt">シャルルの法則</p><p>圧力が一定のとき、一定質量の気体の体積 '+tex("V")+' は絶対温度 '+tex("T")+' に比例する。</p>'+
      '<div class="qeq">'+tex("\\dfrac{V}{T}=\\text{一定}",true)+'</div>'+
      '<p>セルシウス温度 '+tex("t")+'〔℃〕で表すと、温度が 1 K 上がるごとに、0 ℃ のときの体積 '+tex("V_0")+' の '+tex("\\dfrac{1}{273}")+' ずつ増える。</p>'+
      '<div class="qeq">'+tex("V=V_0+\\dfrac{t}{273}V_0=\\dfrac{273+t}{273}V_0",true)+'</div><p>'+tex("T=t+273")+' を使うと '+tex("\\dfrac{V}{T}=\\dfrac{V_0}{273}")+' となる。</p></div>'; }},
  s15:{num:5, mode:0, title:"ボイル・シャルルの法則と状態方程式", short:"状態方程式", sim:S15, noplay:true,
    desc:'物質量 '+tex("n")+' と、'+tex("p")+'・'+tex("V")+'・'+tex("T")+' のうち 2 つを決めると、残りの 1 つは状態方程式 '+tex("pV=nRT")+' で決まる。<span class="todo">決める量を選んで、スライダーを動かそう。</span><br>注目点：'+tex("n")+' が同じなら、'+tex("\\dfrac{pV}{T}")+' の値はいつも同じ（ボイル・シャルルの法則）。',
    opts: H_seg("pick","決める量",[["pV",tex("p")+" と "+tex("V")],["VT",tex("V")+" と "+tex("T")],["pT",tex("p")+" と "+tex("T")]],"pV"),
    sliders: '<div class="pair4">'+H_slider("p","圧力 $p$",0.5,3.0,0.1,1.0)+H_slider("V","体積 $V$",0.5,5.0,0.1,2.5)+H_slider("T","温度 $T$",100,600,10,300)+H_slider("n","物質量 $n$",0.2,2.0,0.1,1.0)+'</div>',
    right:function(){ return '<div class="qcard"><p class="qt">ボイル・シャルルの法則</p><p>一定質量の気体の体積 '+tex("V")+' は、圧力 '+tex("p")+' に反比例し、絶対温度 '+tex("T")+' に比例する。</p>'+
      '<div class="qeq">'+tex("\\dfrac{pV}{T}=\\text{一定}",true)+'</div></div>'+
      '<div class="qcard"><p class="qt">理想気体の状態方程式</p><p>標準状態（273 K、'+tex("1.013\\times10^5\\,\\mathrm{Pa}")+'）で 1 mol の理想気体の体積は、気体の種類によらず '+tex("2.24\\times10^{-2}\\,\\mathrm{m^3}")+'。これを使うと '+tex("\\dfrac{pV}{T}=nR")+' と表せる。</p>'+
      '<div class="qeq">'+tex("pV=nRT",true)+'</div><p>'+tex("R=8.31\\,\\mathrm{J/(mol\\cdot K)}")+'：気体定数</p></div>'; }},

  s21:{num:1, mode:1, title:"分子 1 個が壁に与える力積", short:"分子 1 個の力積", sim:S21, mid:H_timebar(),
    desc:'一辺 '+tex("L")+' の立方体の容器の中を、質量 '+tex("m")+' の分子 1 個が、壁に弾性衝突しながら飛び回る。<span class="todo">スタートを押そう。途中で、横から見た図に変わる。</span><br>注目点：'+tex("x")+' 方向だけを見ると、分子は速さ '+tex("v_x")+' のまま、壁 S と反対側の壁の間を一定の速さで往復している。',
    right:function(){ return '<div class="qcard"><p class="qt">式を 1 段ずつ</p><div class="steps21"></div>'+
      '<p class="stepbtns"><button class="b tiny stp21" type="button" data-d="1">次の式へ ▶</button><button class="b tiny stp21" type="button" data-d="0">最初の式に戻す</button></p></div>'; }},
  s22:{num:2, mode:1, title:"N 個の分子と圧力", short:"N 個の分子と圧力", sim:S22, mid:H_timebar(),
    desc:tex("N")+' 個の分子が、壁 S に次々に衝突する。<span class="todo">分子の数 '+tex("N")+' と温度を変えて、スタートを押そう。</span><br>注目点：壁 S が受ける力はぎざぎざだが、時間で平均すると一定の値に近づく。これが気体の圧力。',
    sliders: '<div class="pair2">'+H_slider("N","分子の数 $N$",1,80,1,30)+H_slider("T","温度 $T$",100,900,50,300)+'</div>',
    right:function(){ return '<div class="qcard"><p class="qt">壁 S が受ける圧力</p><p>1 個の分子が壁 S に及ぼす平均の力は '+tex("\\overline{f}=\\dfrac{m{v_x}^2}{L}")+'（→ <a href="#2-1">②-1</a>）。'+tex("N")+' 個では、'+tex("{v_x}^2")+' を平均の '+tex(VX2B)+' にして</p>'+
      '<div class="qeq">'+tex("F=\\dfrac{Nm"+VX2B+"}{L},\\qquad p=\\dfrac{F}{L^2}=\\dfrac{Nm"+VX2B+"}{V}",true)+'</div></div>'+
      '<div class="qcard"><p class="qt">向きがばらばら</p><p>'+tex("v^2={v_x}^2+{v_y}^2+{v_z}^2")+'。分子は特定の方向にかたよらずに動くので、3 方向の平均は等しい。</p>'+
      '<div class="qeq">'+tex(VX2B+"=\\overline{{v_y}^2}=\\overline{{v_z}^2}=\\dfrac{1}{3}"+V2B,true)+'</div><p>よって</p>'+
      '<div class="qeq">'+tex("p=\\dfrac{Nm"+V2B+"}{3V}",true)+'</div></div>'; }},
  s23:{num:3, mode:1, title:"温度と分子の運動エネルギー", short:"温度と運動エネルギー", sim:S23, noplay:true,
    desc:'同じ温度のヘリウムと、もう 1 つの気体の分子の動きを比べる。<span class="todo">右の気体の種類と温度を変えてみよう。</span><br>注目点：分子 1 個の平均の運動エネルギーは、気体の種類によらず温度だけで決まる。そのため、質量の大きい分子ほど遅い。',
    opts: H_seg("gas","右の気体",[["N2","窒素 N₂"],["O2","酸素 O₂"],["CO2","二酸化炭素 CO₂"]],"N2"),
    sliders: H_slider("T","温度 $T$",100,1000,10,300),
    right:function(){ return '<div class="qcard"><p class="qt">平均の運動エネルギーと温度</p><p>'+tex("p=\\dfrac{Nm"+V2B+"}{3V}")+' を '+tex("pV=\\dfrac{Nm"+V2B+"}{3}")+' と変形し、状態方程式 '+tex("pV=nRT")+'（'+tex("N=nN_\\mathrm{A}")+'）と比べると</p>'+
      '<div class="qeq">'+tex("\\dfrac{1}{2}m"+V2B+"=\\dfrac{3}{2}\\dfrac{R}{N_\\mathrm{A}}T=\\dfrac{3}{2}kT",true)+'</div>'+
      '<p>'+tex("k=\\dfrac{R}{N_\\mathrm{A}}=1.38\\times10^{-23}\\,\\mathrm{J/K}")+'：ボルツマン定数</p></div>'+
      '<div class="qcard"><p class="qt">二乗平均速度</p><p>モル質量を '+tex("M")+'〔kg/mol〕とすると '+tex("mN_\\mathrm{A}=M")+' なので</p>'+
      '<div class="qeq">'+tex("\\sqrt{"+V2B+"}=\\sqrt{\\dfrac{3RT}{M}}",true)+'</div><p>分子の速さの目安になる。</p></div>'+
      '<div class="qcard"><p class="qt">参考：分子の速さの分布</p><p>分子はいろいろな速さで飛び回っている。速さの分布は気体の種類と温度で決まり、温度が高いほど、山は低く、速い方へ広がる。</p></div>'; }},
  s24:{num:4, mode:1, title:"内部エネルギー", short:"内部エネルギー", sim:S24, noplay:true,
    desc:'単原子分子の理想気体の<b>内部エネルギー</b> '+tex("U")+' は、全ての分子の運動エネルギーの和。<span class="todo">温度・物質量・体積を変えてみよう。</span><br>注目点：体積を変えても '+tex("U")+' は変わらない。'+tex("U")+' は温度と物質量だけで決まる。',
    sliders: '<div class="pair3">'+H_slider("T","温度 $T$",100,600,10,300)+H_slider("n","物質量 $n$",0.5,2.0,0.1,1.0)+H_slider("V","体積 $V$",1.0,5.0,0.1,2.5)+'</div>',
    right:function(){ return '<div class="qcard"><p class="qt">単原子分子の理想気体の内部エネルギー</p><p>理想気体では分子間の力が無視できるので、内部エネルギーは分子の運動エネルギーの和。1 mol では '+tex("N_\\mathrm{A}\\times\\dfrac{1}{2}m"+V2B+"=\\dfrac{3}{2}RT")+'。</p>'+
      '<div class="qeq">'+tex("U=\\dfrac{3}{2}nRT",true)+'</div><p>温度が '+tex("\\Delta T")+' 変わると '+tex("\\Delta U=\\dfrac{3}{2}nR\\Delta T")+'。</p></div>'+
      '<div class="qcard"><p class="qt">二原子分子</p><p>酸素 '+tex("\\mathrm{O_2}")+' のような二原子分子では、回転の運動エネルギーも加わる（→ <a href="#3-3">③-3</a>）。</p></div>'; }},

  s31:{num:1, mode:2, title:"気体がする仕事と p-V 図", short:"仕事と p-V 図", sim:S31, mid:H_timebar(),
    desc:'気体が膨張すると、ピストンを押して外に仕事をする。<span class="todo">経路と「膨張｜圧縮」を選んで、スタートを押そう。</span><br>注目点：気体がした仕事 '+tex(WS)+' は、p-V 図のグラフと '+tex("V")+' 軸の間の面積に等しい（圧縮のときは負）。',
    opts: H_seg("path","経路",[["isoP","定圧"],["isoT","等温"]],"isoP")+H_seg("ex","向き",[["exp","膨張"],["cmp","圧縮"]],"exp"),
    right:function(){ return '<div class="qcard"><p class="qt">圧力が一定のとき</p><p>断面積 '+tex("S")+' のピストンを、気体が力 '+tex("pS")+' で押して '+tex("\\Delta l")+' 動かすと、体積の変化は '+tex("\\Delta V=S\\Delta l")+'。</p>'+
      '<div class="qeq">'+tex(WS+"=pS\\Delta l=p\\Delta V",true)+'</div></div>'+
      '<div class="qcard"><p class="qt">仕事＝p-V 図の面積</p><p>どんな変化でも、気体がした仕事 '+tex(WS)+' は、p-V 図のグラフと '+tex("V")+' 軸の間の面積に等しい。圧縮（左向きの変化）のときは、面積に負の符号をつける。</p>'+
      '<p>気体がされた仕事は '+tex(WD+"=-"+WS)+'。</p></div>'; }},
  s32:{num:2, mode:2, title:"4 つの変化", short:"4 つの変化", sim:S32, mid:H_timebar(), full:true,
    desc:'同じ状態 A から、4 つの変化をさせて比べる（単原子分子の理想気体 1 mol）。<span class="todo">変化の種類と「膨張｜圧縮」を選んでスタートを押そう。</span><br>注目点：定積では '+tex(WD+"=0")+'、等温では '+tex("\\Delta U=0")+'、断熱では '+tex("Q=0")+'。p-V 図の断熱の曲線は、等温の曲線より傾きが急。',
    opts: H_seg("kind","変化",[["V","定積"],["P","定圧"],["T","等温"],["A","断熱"]],"P")+H_seg("ex","向き",[["exp","膨張（加熱）"],["cmp","圧縮（冷却）"]],"exp"),
    right:function(){ return '<div class="qcard"><p class="qt">熱力学第一法則</p><div class="qeq">'+tex("\\Delta U=Q+"+WD,true)+'</div>'+
      '<p>'+tex("Q")+'：気体が受け取った熱（放出すると負）、'+tex(WD)+'：気体がされた仕事（'+tex(WD+"=-"+WS)+'）。</p></div>'+
      '<div class="qcard"><p class="qt">4 つの変化（膨張・加熱のとき）</p><table class="nstab"><tr><td></td><td>'+tex("\\Delta U")+'</td><td>'+tex("Q")+'</td><td>'+tex(WD)+'</td></tr>'+
      '<tr><td>定積</td><td>正</td><td>正</td><td>0</td></tr><tr><td>定圧</td><td>正</td><td>正</td><td>負</td></tr><tr><td>等温</td><td>0</td><td>正</td><td>負</td></tr><tr><td>断熱</td><td>負</td><td>0</td><td>負</td></tr></table>'+
      '<p>圧縮（冷却）のときは、どれも符号が逆になる。</p>'+
      '<p>断熱変化では '+tex("pV^\\gamma=\\text{一定}")+'（ポアソンの法則、'+tex("\\gamma")+'：比熱比、単原子分子では '+tex("\\gamma=\\dfrac{5}{3}")+'）。</p></div>'; }},
  s33:{num:3, mode:2, title:"モル比熱", short:"モル比熱", sim:S33, mid:H_timebar(),
    desc:'1 mol の気体の温度を同じだけ（100 K）上げるのに必要な熱を、定積と定圧で比べる。<span class="todo">「単原子分子｜二原子分子」を選んでスタートを押そう。</span><br>注目点：定圧では、気体が外に仕事をする分だけ多くの熱が必要になる（'+tex("C_p=C_V+R")+'）。',
    opts: H_seg("mol","分子",[["mono","単原子分子"],["di","二原子分子"]],"mono"),
    right:function(){ return '<div class="qcard"><p class="qt">モル比熱</p><p>1 mol の温度を 1 K 上げるのに必要な熱量。'+tex("Q=nC\\Delta T")+'。</p>'+
      '<p><b>定積モル比熱</b> '+tex("C_V")+'：体積一定。熱は全て内部エネルギーになる。'+tex("\\Delta U=nC_V\\Delta T")+'</p>'+
      '<p><b>定圧モル比熱</b> '+tex("C_p")+'：圧力一定。気体が外に仕事 '+tex(WS+"=p\\Delta V=nR\\Delta T")+' をする。</p>'+
      '<div class="qeq">'+tex("C_p=C_V+R",true)+'</div><p>（マイヤーの関係）</p><p>比熱比 '+tex("\\gamma=\\dfrac{C_p}{C_V}")+'</p></div>'+
      '<div class="qcard"><p class="qt">単原子分子と二原子分子</p><table class="nstab"><tr><td></td><td>'+tex("C_V")+'</td><td>'+tex("C_p")+'</td><td>'+tex("\\gamma")+'</td></tr>'+
      '<tr><td>単原子分子</td><td>'+tex("\\frac{3}{2}R")+'</td><td>'+tex("\\frac{5}{2}R")+'</td><td>'+tex("\\frac{5}{3}")+'</td></tr>'+
      '<tr><td>二原子分子</td><td>'+tex("\\frac{5}{2}R")+'</td><td>'+tex("\\frac{7}{2}R")+'</td><td>'+tex("\\frac{7}{5}")+'</td></tr></table>'+
      '<p>二原子分子は、並進運動（3 方向）に加えて、2 つの軸のまわりの回転にも 1 方向あたり '+tex("\\frac{1}{2}RT")+' ずつエネルギーをもつので、'+tex("U=\\frac{5}{2}nRT")+'。</p></div>'; }},

  s41:{num:1, mode:3, title:"熱サイクル", short:"熱サイクル", sim:S41, mid:H_timebar(), full:true,
    desc:'気体を A → B → C → D → A と変化させて元に戻す（<b>サイクル</b>）。<span class="todo">サイクルを選んでスタートを押そう。変化が 1 つ終わるごとに、下に模式図が残る。</span><br>注目点：1 周すると '+tex("\\Delta U=0")+'。1 周で気体がした仕事は、p-V 図で囲まれた面積に等しい。',
    opts: H_seg("cyc","サイクル",[["rect","定積＋定圧（長方形のサイクル）"],["carnot","カルノーサイクル（等温＋断熱）"]],"rect"),
    right:function(){ return '<div class="qcard"><p class="qt">熱効率</p><p>1 サイクルで、高温の物体から受け取る熱を '+tex("Q_\\mathrm{in}")+'、低温の物体へ放出する熱を '+tex("Q_\\mathrm{out}")+' とする。1 周すると '+tex("\\Delta U=0")+' なので、気体がした仕事は</p>'+
      '<div class="qeq">'+tex(WS+"=Q_\\mathrm{in}-Q_\\mathrm{out}",true)+'</div>'+
      '<div class="qeq">'+tex("e=\\dfrac{"+WS+"}{Q_\\mathrm{in}}=\\dfrac{Q_\\mathrm{in}-Q_\\mathrm{out}}{Q_\\mathrm{in}}",true)+'</div>'+
      '<p>熱機関は必ず '+tex("Q_\\mathrm{out}")+' を放出するので、'+tex("e<1")+'。</p></div>'+
      '<div class="qcard"><p class="qt">長方形のサイクル</p><p>① 定積で圧力を上げ、② 定圧で膨張、③ 定積で圧力を下げ、④ 定圧で圧縮して元に戻る。熱を受け取るのは ①・②、放出するのは ③・④。</p></div>'; }},
  s42:{num:2, mode:3, title:"熱機関（エンジン）", short:"熱機関", sim:S42, mid:H_timebar(), full:true,
    desc:'ガソリンエンジンは、吸気・圧縮・膨張・排気の 4 つの行程をくり返す。理想化したものが<b>オットーサイクル</b>。<span class="todo">スタートを押して、ピストンの動きと p-V 図の点を見比べよう。</span><br>注目点：圧縮の曲線と膨張の曲線で囲まれた面積が、1 サイクルで気体がした仕事。',
    right:function(){ return '<div class="qcard"><p class="qt">4 つの行程とオットーサイクル</p><table class="nstab">'+
      '<tr><td>① 吸気</td><td>吸気弁が開き、ピストンが下がって混合気を吸いこむ</td></tr>'+
      '<tr><td>② 圧縮</td><td>弁を閉じてピストンが上がり、気体を急に圧縮する（断熱圧縮）</td></tr>'+
      '<tr><td>点火</td><td>点火プラグで燃やすと、体積がほぼ一定のまま圧力と温度が上がる（定積で '+tex("Q_\\mathrm{in}")+' を受け取る）</td></tr>'+
      '<tr><td>③ 膨張</td><td>高温・高圧の気体がピストンを押し下げて仕事をする（断熱膨張）</td></tr>'+
      '<tr><td>排気弁を開く</td><td>体積がほぼ一定のまま圧力が下がる（定積で '+tex("Q_\\mathrm{out}")+' を放出する）</td></tr>'+
      '<tr><td>④ 排気</td><td>ピストンが上がって、燃えたあとの気体を押し出す</td></tr></table>'+
      '<p>吸気と排気は、ほぼ大気圧のまま行き来するだけなので、p-V 図では同じ線の上を往復し、仕事には効かない。</p></div>'+
      '<div class="qcard"><p class="qt">表し方について</p><p>点火と排気弁を開くときの変化は、実際は一瞬で起こる。図では見えるように、そのあいだクランクを止めて、ゆっくり見せている。</p></div>'; }},

  s51:{num:1, mode:4, title:"カルノーサイクル", short:"カルノーサイクル", sim:S51, mid:H_timebar(),
    desc:'カルノーサイクルは、2 つの等温変化と 2 つの断熱変化からなる。<span class="todo">高温の温度 '+tex("T_\\mathrm{H}")+' と低温の温度 '+tex("T_\\mathrm{L}")+' を変えて、スタートを押そう。</span><br>注目点：熱効率は '+tex("e=1-\\dfrac{T_\\mathrm{L}}{T_\\mathrm{H}}")+' になり、温度の差が大きいほど大きい。',
    sliders: '<div class="pair2">'+H_slider("TH","高温の物体の温度 $T_\\mathrm{H}$",400,900,50,600)+H_slider("TL","低温の物体の温度 $T_\\mathrm{L}$",200,350,10,300)+'</div>',
    right:function(){ return '<div class="qcard"><p class="qt">カルノーサイクルの熱効率</p>'+
      '<p>A→B（温度 '+tex("T_\\mathrm{H}")+' で等温膨張）で受け取る熱、C→D（温度 '+tex("T_\\mathrm{L}")+' で等温圧縮）で放出する熱は</p>'+
      '<div class="qeq">'+tex("Q_\\mathrm{in}=nRT_\\mathrm{H}\\log_e\\dfrac{V_\\mathrm{B}}{V_\\mathrm{A}},\\quad Q_\\mathrm{out}=nRT_\\mathrm{L}\\log_e\\dfrac{V_\\mathrm{C}}{V_\\mathrm{D}}",true)+'</div>'+
      '<p>断熱変化の式 '+tex("TV^{\\gamma-1}=\\text{一定}")+' から '+tex("\\dfrac{V_\\mathrm{B}}{V_\\mathrm{A}}=\\dfrac{V_\\mathrm{C}}{V_\\mathrm{D}}")+' となるので</p>'+
      '<div class="qeq">'+tex("e=1-\\dfrac{Q_\\mathrm{out}}{Q_\\mathrm{in}}=1-\\dfrac{T_\\mathrm{L}}{T_\\mathrm{H}}",true)+'</div>'+
      '<p>（等温変化で気体がする仕事を求めるには積分を使う。）</p></div>'+
      '<div class="qcard"><p class="qt">熱力学第二法則とのつながり</p><p>同じ 2 つの温度の間ではたらく熱機関で、カルノーサイクルより熱効率の大きいものは作れない。'+tex("T_\\mathrm{L}>0")+' なので、'+tex("e=1")+'（熱を全て仕事に変える熱機関）にはならない。</p>'+
      '<p>→ <a href="thermal-energy.html#3-3">熱とエネルギー ③-3 熱力学第二法則</a></p></div>'; }}
};
var CIRC = "①②③④⑤⑥⑦⑧⑨";
var GLOBAL = {hideEq:false};

function secAddr(sid){ var d=DEFS[sid]; return (d.mode+1)+"-"+d.num; }
function secHTML(sid, first){
  var d=DEFS[sid], num=CIRC[d.mode]+"-"+d.num;
  var head='<div class="sechead"><span class="secnum">'+num+'</span><h2>'+d.title+'</h2>'+(d.headBtn||'')+'</div><div class="secdesc">'+d.desc+'</div>';
  return '<article class="sec'+(d.full? ' full' : '')+'" id="'+sid+'"><div class="sL">'+head+
    '<div class="ctrls">'+(d.opts? '<div class="row1 row1b">'+d.opts+'</div>' : '')+(d.sliders? '<div class="row2 sliders">'+d.sliders+'</div>' : '')+
    (d.noplay? '<div class="rsrow">'+H_reset()+'</div>' : H_play(first, d.mid, H_reset()))+'</div>'+
    (d.above? d.above : '')+
    '<div class="cvwrap"><canvas class="main"></canvas></div><div class="msgbox"></div>'+(d.leftBelow? d.leftBelow() : '')+'</div>'+
    (d.right()? '<div class="sR">'+d.right()+'</div>' : '')+'</article>';
}

function buildPage(){
  var EN = "Gases and Thermodynamics";
  var atom='<svg class="atom" viewBox="0 0 32 32" aria-hidden="true"><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#3ea0e0" stroke-width="2"/><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#7b5bd6" stroke-width="2" transform="rotate(60 16 16)"/><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#e07b18" stroke-width="2" transform="rotate(120 16 16)"/><circle cx="16" cy="16" r="3.6" fill="#5aa7ff"/></svg>';
  document.getElementById("hero").innerHTML =
    '<div class="hero-in"><div class="hero-top"><nav class="crumbs" aria-label="現在地"><a class="crumb-home" href="'+SITE_HOME+'" title="楽楽（らくらく）高校物理のトップページへ">'+atom+'<span>楽楽（らくらく）高校物理</span></a><span class="cs" aria-hidden="true">/</span><a class="crumb" href="'+SITE_HOME+'#sec-mechanics">力学</a><span class="cs" aria-hidden="true">/</span><span class="crumb now" aria-current="page">気体と熱力学</span><span class="kdot"></span><span class="en">'+EN+'</span></nav>'+
    '<div class="topbtns" role="group" aria-label="ページ全体の表示"><button id="btnEq" type="button"></button></div></div>'+
    '<h1 class="hero-title"><span class="t1"><span class="nb">気体と</span><span class="nb">熱力学</span></span><span class="t2">〜 気体分子の運動から熱機関まで 〜</span></h1>'+
    '<div class="introrow"><p class="lead2">気体の圧力や温度は、目に見えない無数の分子の運動から生まれる。分子の運動、熱と仕事、p-V 図を手がかりに、熱を仕事に変える熱機関のしくみまでをたどる。</p>'+
    '<button id="bToc" class="tocbtn" type="button" aria-haspopup="true" aria-expanded="false"><span class="ti" aria-hidden="true"></span>コンテンツ一覧</button></div>'+
    '<div id="tocpanel" class="tocpanel" hidden></div>'+
    '<figure class="stage" aria-label="エンジンのピストンの動きと、p-V 図の上を回る状態の点"><canvas id="heroCv"></canvas>'+
    '<figcaption class="stagecap"><span class="live" aria-hidden="true"></span><span class="sct">気体は、熱を受け取って膨張し、仕事をする。1 周で気体がした仕事 '+tex(WS)+' は、p-V 図で囲まれた面積になる。</span>'+
    '<span class="stagectl" role="group" aria-label="アニメの操作"><button type="button" class="slow" aria-pressed="false" title="ゆっくり再生">🐢 スロー</button><button type="button" class="pp" aria-label="一時停止"><i></i></button></span></figcaption></figure>'+
    '<ol class="ideas">'+
    '<li><a href="#1-5"><span class="in" aria-label="①"><b>1</b></span><span class="ie">'+tex("pV=nRT")+'</span><span class="ij">気体の状態は p・V・T・n で決まる</span><span class="ia" aria-hidden="true">→</span></a></li>'+
    '<li><a href="#2-3"><span class="in" aria-label="②"><b>2</b></span><span class="ie">'+tex("\\frac{1}{2}m"+V2B+"=\\frac{3}{2}kT")+'</span><span class="ij">温度は分子の平均の運動エネルギー</span><span class="ia" aria-hidden="true">→</span></a></li>'+
    '<li><a href="#3-1"><span class="in" aria-label="③"><b>3</b></span><span class="ie ietxt">'+tex(WS)+' ＝ <i>p</i>-<i>V</i> 図の面積</span><span class="ij">気体がした仕事は面積で表せる</span><span class="ia" aria-hidden="true">→</span></a></li></ol></div>';

  document.getElementById("tabs").innerHTML='<div class="tabs-in"><div class="navsite"><a class="navhome" href="'+SITE_HOME+'" aria-label="ホーム（楽楽高校物理のトップページ）" title="ホーム（楽楽高校物理のトップページ）"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3.5 10.8 12 4l8.5 6.8" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M6 9.5V20h4.5v-5.5h3V20H18V9.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg></a><button class="navpages" id="bPages" type="button" aria-haspopup="dialog" aria-expanded="false" aria-controls="siteDrawer"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="3.5" width="7" height="7" rx="1.6" fill="currentColor"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.6" fill="currentColor" opacity=".55"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.6" fill="currentColor" opacity=".55"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.6" fill="currentColor"/></svg><span>ページ一覧</span></button></div>'+
    MODES.map(function(m,i){ return '<button class="tab" type="button" data-mode="'+m.id+'"><span class="tn">'+CIRC[i]+'</span><span class="tl">'+m.name+'</span></button>'; }).join("")+'</div><span class="tprog" aria-hidden="true"></span>';

  var h="", first=true;
  MODES.forEach(function(m,i){
    h+='<section class="mode" id="'+m.id+'"><header class="modehead"><div class="mh-num" aria-hidden="true"><span>'+(i+1)+'</span></div><div class="mh-body"><p class="mh-en">Chapter '+String(i+1).padStart(2,"0")+' — '+m.en+'</p><h2><span class="mh-c">'+CIRC[i]+'</span>'+m.name+'</h2><p class="mh-lead">'+m.lead+'</p></div></header>'+
       (m.secs.length>1? '<div class="seclinks">'+m.secs.map(function(s){ return '<a href="#'+secAddr(s)+'" data-toc="'+s+'">'+CIRC[i]+'-'+DEFS[s].num+'　'+DEFS[s].short+'</a>'; }).join("")+'</div>' : '');
    m.secs.forEach(function(s){ h+=secHTML(s, first); first=false; });
    h+='</section>';
  });
  h+='<div class="card purpose"><p class="lead">このページの目的</p><ol>'+
     '<li>ボイル・シャルルの法則と理想気体の状態方程式 '+tex("pV=nRT")+' を、ピストンと分子の動きで納得する。</li>'+
     '<li>気体分子運動論で、圧力は分子の衝突、温度は分子の平均の運動エネルギーだと分かる（'+tex("\\frac{1}{2}m"+V2B+"=\\frac{3}{2}kT")+'）。そこから内部エネルギー '+tex("U=\\frac{3}{2}nRT")+' を導く。</li>'+
     '<li>定積・定圧・等温・断熱の 4 つの変化を、p-V 図と '+tex("Q")+'・'+tex(WD)+'・'+tex("\\Delta U")+' の棒グラフで比べる（'+tex(WS)+'＝p-V 図の面積）。</li>'+
     '<li>熱サイクルを p-V 図で 1 周し、熱効率 '+tex("e=\\frac{"+WS+"}{Q_\\mathrm{in}}")+' を求める。エンジンの動きと p-V 図を対応させる。</li></ol></div>';
  h+='<footer></footer>';
  document.getElementById("wrap").innerHTML=h;

  /* 目次 */
  var tp=document.getElementById("tocpanel");
  tp.innerHTML='<div class="tochead"><b>コンテンツ一覧</b><button type="button" class="tocx" aria-label="閉じる">×</button></div>'+
    MODES.map(function(m,i){ return '<div class="tocmode">'+CIRC[i]+' '+m.name+'</div><ul>'+m.secs.map(function(s){ return '<li><a href="#'+secAddr(s)+'" data-toc="'+s+'">'+CIRC[i]+'-'+DEFS[s].num+' '+DEFS[s].title+'</a></li>'; }).join("")+'</ul>'; }).join("");
  var bT=document.getElementById("bToc");
  var closeToc=function(){ tp.hidden=true; bT.setAttribute("aria-expanded","false"); };
  bT.addEventListener("click", function(ev){ ev.stopPropagation(); tp.hidden=!tp.hidden; bT.setAttribute("aria-expanded", tp.hidden?"false":"true"); });
  tp.querySelector(".tocx").addEventListener("click", closeToc);
  document.addEventListener("click", function(ev){ if(!tp.hidden && !tp.contains(ev.target) && ev.target!==bT) closeToc(); });
  document.addEventListener("keydown", function(ev){ if(ev.key==="Escape") closeToc(); });
  document.querySelectorAll("a[data-toc]").forEach(function(a){ a.addEventListener("click", function(ev){ ev.preventDefault(); closeToc(); gotoSec(a.dataset.toc); }); });
  /* 本文の中の「#1-2」のリンク */
  document.getElementById("wrap").addEventListener("click", function(ev){ var a=ev.target.closest && ev.target.closest('a[href^="#"]'); if(!a || a.dataset.toc || a.dataset.mode) return;
    var hs=a.getAttribute("href").slice(1); if(/^\d-\d$/.test(hs)){ ev.preventDefault(); history.replaceState(null,"","#"+hs); gotoHash(); } });

  /* タブ */
  document.querySelectorAll("#tabs .tab").forEach(function(b){
    b.addEventListener("click", function(){ activateMode(b.dataset.mode); history.replaceState(null,"","#"+b.dataset.mode);
      window.scrollTo({top:Math.min(window.pageYOffset, contentTop()), behavior:"auto"}); });
  });
  window.addEventListener("hashchange", function(){ gotoHash(); });

  /* 式・考え方エリアを閉じる */
  var bE=document.getElementById("btnEq");
  var sync=function(){ var on=GLOBAL.hideEq; bE.innerHTML='<span class="sw" aria-hidden="true"><i></i></span><span class="swl">式・考え方エリアを閉じる</span><span class="swv">'+(on?"ON":"OFF")+'</span>';
    bE.setAttribute("aria-pressed",on?"true":"false"); bE.classList.toggle("off",!on); document.body.classList.toggle("hideeq",on); };
  bE.addEventListener("click", function(){ GLOBAL.hideEq=!GLOBAL.hideEq; sync(); setTimeout(redrawAll,30); });
  sync();
}
var BUILT = {};
function activateMode(id){
  document.querySelectorAll(".mode").forEach(function(s){ s.classList.toggle("on", s.id===id); });
  document.querySelectorAll("#tabs .tab").forEach(function(b){ b.classList.toggle("on", b.dataset.mode===id); });
  var m=MODES.filter(function(x){ return x.id===id; })[0];
  if(m && !BUILT[id]){ BUILT[id]=true; m.secs.forEach(function(s){ DEFS[s].sim.init(document.getElementById(s)); }); }
  else if(m) setTimeout(function(){ m.secs.forEach(function(s){ DEFS[s].sim.draw(); }); }, 0);
}
function redrawAll(){ MODES.forEach(function(m){ if(BUILT[m.id]) m.secs.forEach(function(s){ DEFS[s].sim.draw(); }); }); }
function contentTop(){ var h=document.getElementById("hero"); return h? h.offsetTop+h.offsetHeight : 0; }
function tabbarH(){ var tb=document.getElementById("tabs"); return (tb && getComputedStyle(tb).position==="sticky")? tb.getBoundingClientRect().height : 0; }
function gotoSec(sid){
  var d=DEFS[sid]; if(!d) return;
  activateMode(MODES[d.mode].id); history.replaceState(null,"","#"+secAddr(sid));
  var go=function(){ var el=document.getElementById(sid); if(!el) return; window.scrollTo({top: el.getBoundingClientRect().top + window.pageYOffset - tabbarH() - 10, behavior:"auto"}); };
  requestAnimationFrame(function(){ requestAnimationFrame(go); }); setTimeout(go, 220);
}
function gotoHash(){
  var hs=(location.hash||"").slice(1);
  var mm=hs.match(/^(\d)-(\d)$/);
  if(mm){ var sid=null; Object.keys(DEFS).forEach(function(k){ if(DEFS[k].mode===parseInt(mm[1],10)-1 && DEFS[k].num===parseInt(mm[2],10)) sid=k; }); if(sid){ gotoSec(sid); return true; } }
  if(MODES.some(function(m){ return m.id===hs; })){ activateMode(hs); return true; }
  return false;
}
/* 節の共通：「全て最初の設定に戻す」とスローのボタンを戻す */
function resetSlow(sec, run){ if(run) run.rate=1; var sb=sec.querySelector(".slowb"); if(sb) sb.classList.remove("on"); }
/* 節が画面に見えているか（見えていないときは止めておく） */
function secVisible(sec){ if(sec.offsetParent===null) return false; var r=sec.getBoundingClientRect(); return r.bottom>0 && r.top<innerHeight; }
document.addEventListener("DOMContentLoaded", function(){
  buildPage();
  if(!gotoHash()) activateMode("mode1");
  watchTicks(document);
  if(document.fonts){ document.fonts.load('italic 14px "KaTeX_Math"').then(function(){ redrawAll(); }); document.fonts.ready.then(function(){ redrawAll(); }); }
});
