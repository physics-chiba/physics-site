/* =========================================================================
   モード① 気体の法則（1-1〜1-5）
   ========================================================================= */
/* 節が見えているあいだだけ、毎フレーム fn を呼ぶ（分子を動かす） */
function idleLoop(sec, fn){ var last=0; var go=function(ts){ var dt=last? Math.min(0.05,(ts-last)/1000) : 0; last=ts; if(secVisible(sec)) fn(dt); requestAnimationFrame(go); }; requestAnimationFrame(go); }
/* V〔m³〕を「×10⁻² m³」の数で */
function v2s(V){ return (V*100).toFixed(2); }

/* ---------------- ①-1 シリンダーに閉じ込められた気体 ----------------
   ポンプで分子を入れる（n を増やす）。ピストンは自由（大気圧）なので、熱を加える・奪うと定圧変化。
   パネルの ± ：p・V は温度一定、T は圧力一定、n は圧力・温度一定（ポンプ） */
var S11 = {
  VMAX:8.0e-2, MPM:20,                /* 図の端の体積、1 mol あたりの分子の絵の数 */
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    var row=sec.querySelector(".ctrls");
    row.insertAdjacentHTML("afterbegin", '<div class="row1 row1b op11"><button class="b play" type="button" id="bPlay">▶ ポンプを押す</button>'+
      '<button class="b hbtn" type="button" data-h="1">🔥 熱を加える</button><button class="b hbtn cold" type="button" data-h="-1">❄ 熱を奪う</button></div>'+
      panelHTML(["p","V","T","n"],{p:"温度一定", V:"温度一定", T:"圧力一定", n:"圧力・温度一定"}));
    this.gas=new Gas(0, 11); this.clk=0;
    this.reset0();
    var rs=sec.querySelector(".rsrow"); sec.querySelector(".op11").appendChild(rs.querySelector(".resetall")); rs.remove();
    this.bP=sec.querySelector("#bPlay");
    this.bP.addEventListener("click", function(){ self.pump(1); });
    sec.querySelectorAll(".hbtn").forEach(function(b){ b.addEventListener("click", function(){ self.heat(parseFloat(b.dataset.h)); }); });
    sec.querySelectorAll(".gpb").forEach(function(b){ b.addEventListener("click", function(){ self.pm(b.dataset.pm, parseFloat(b.dataset.d)); }); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.reset0(); self.draw(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    idleLoop(sec, function(dt){ self.tick(dt); self.draw(); });
    this.draw();
  },
  reset0:function(){ this.n=0; this.T=300; this.p=1.0; this.tg={n:0,T:300,p:1.0}; this.fr={n:0,T:300,p:1.0}; this.tau=1; this.gas.setN(0); this.pumpT=-1; this.heatDir=0; this.hT=0; this.last="";
    this.note="まだ分子が入っていない。ポンプを押して、分子を入れよう。"; },
  V:function(n,T,p){ return n>0? n*RGAS*T/(p*1e5) : 0; },
  ok:function(n,T,p){ var V=this.V(n,T,p); return V<=this.VMAX*0.97 && T>=150 && T<=600 && p>=0.5-1e-9 && p<=3.0+1e-9 && n>=-1e-9 && n<=2.0+1e-9; },
  busy:function(){ return this.tau<1; },   /* 変化のアニメ（0.9 秒）の途中 */
  set:function(n,T,p,why){
    if(this.busy()) return false;
    n=Math.round(n*10)/10; p=Math.round(p*10)/10; T=Math.round(T);
    if(!this.ok(n,T,p)){ this.note="これ以上は変えられない（体積がシリンダーに収まらない、または範囲の外）。"; this.draw(); return false; }
    this.fr={n:this.n,T:this.T,p:this.p}; this.tg={n:n,T:T,p:p}; this.tau=0; this.note=why; return true;
  },
  pump:function(d){ if(this.set(this.tg.n+0.2*d, this.tg.T, this.tg.p, d>0? "ポンプで分子を入れた（"+tex("n")+" が増える）。圧力と温度は変わらず、体積が増える。" : "弁から分子を出した（"+tex("n")+" が減る）。圧力と温度は変わらず、体積が減る。")){ if(d>0) this.pumpT=0; } },
  heat:function(d){ if(this.tg.n<=0){ this.note="まず、ポンプで分子を入れよう。"; this.draw(); return; }
    if(this.set(this.tg.n, this.tg.T+50*d, this.tg.p, d>0? "熱を加えた。ピストンは自由に動くので圧力はそのまま。温度が上がり、体積が増える（定圧変化）。" : "熱を奪った。圧力はそのまま。温度が下がり、体積が減る（定圧変化）。")){ this.heatDir=d; this.hT=0; } },
  pm:function(k, d){
    var g=this.tg;
    if(k==="n") return this.pump(d);
    if(g.n<=0){ this.note="まず、ポンプで分子を入れよう。"; this.draw(); return; }
    if(k==="T") return this.heat(d);
    if(k==="p") return this.set(g.n, g.T, g.p+0.2*d, d>0? "手でピストンを押して圧力を上げた。温度は一定のまま、体積が減る。" : "手でピストンを引いて圧力を下げた。温度は一定のまま、体積が増える。");
    if(k==="V"){ var V=this.V(g.n,g.T,g.p)+0.5e-2*d; if(V<=0.2e-2){ this.note="これ以上は小さくできない。"; this.draw(); return; }
      var p=g.n*RGAS*g.T/V/1e5; p=Math.round(p*100)/100;
      if(!this.ok(g.n,g.T,p)){ this.note="これ以上は変えられない（範囲の外）。"; this.draw(); return; }
      if(this.busy()) return; this.fr={n:this.n,T:this.T,p:this.p}; this.tg={n:g.n,T:g.T,p:p}; this.tau=0; this.note=d>0? "手でピストンを引いて体積を増やした。温度は一定のまま、圧力が下がる。" : "手でピストンを押して体積を減らした。温度は一定のまま、圧力が上がる。"; }
  },
  tick:function(dt){
    var g=this.tg, a=this.fr, run=this.tau<1;
    this.tau=Math.min(1,this.tau+dt/0.9); var e=this.tau*this.tau*(3-2*this.tau);
    this.n=a.n+(g.n-a.n)*e; this.T=a.T+(g.T-a.T)*e; this.p=a.p+(g.p-a.p)*e;
    var sg=function(d,eps){ return run && Math.abs(d)>eps? Math.sign(d) : 0; };
    this.dir={n:sg(g.n-a.n,1e-4), T:sg(g.T-a.T,0.1), p:sg(g.p-a.p,1e-4)};
    this.dir.V=sg(this.V(g.n,g.T,g.p)-this.V(a.n,a.T,a.p),1e-6);
    var cnt=Math.round(this.n*this.MPM), old=this.gas.m.length; this.gas.setN(cnt);
    for(var i=old;i<cnt;i++){ this.gas.m[i].x=0.02; this.gas.m[i].y=0.5+0.1*(this.gas.R()-0.5); this.gas.m[i].vx=Math.abs(this.gas.m[i].vx)+0.4; }
    if(this.pumpT>=0){ this.pumpT+=dt; if(this.pumpT>1.0) this.pumpT=-1; }
    if(this.heatDir){ this.hT+=dt; if(this.hT>1.3 && !this.busy()) this.heatDir=0; }
    this.clk+=dt;
    var gg=this.geo; if(gg){ this.gas.step(dt, Math.max(1,gg.L), gg.h, 55*Math.sqrt(this.T/300), 4.2); }
  },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return clamp(W*0.40, 250, 320); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var narrow=W<560, px=narrow? 64 : 112, ox=px+26, h=narrow? 84 : 104, cy=H*0.46, Lmax=W-ox-(narrow? 50 : 92);
    var V=this.V(this.n,this.T,this.p), L=Lmax*V/this.VMAX;
    this.geo={L:L, h:h};
    var F=new CylFrame(ox, cy, "right"), held=Math.abs(this.p-1)>0.004;
    /* 机 */
    ground(c, 8, W-8, cy+h/2+44);
    c.save(); c.fillStyle="#cdbfa6"; c.fillRect(ox+20, cy+h/2+9, 14, 35); c.fillRect(ox+Lmax-40, cy+h/2+9, 14, 35); c.restore();
    /* 熱（バーナー・冷やす板）とその矢印 */
    var hx=ox+Math.max(60, Math.min(L*0.5, Lmax*0.35)), yb=cy+h/2+9;
    if(this.heatDir>0){ burner(c, hx, cy+h/2+44, true, this.clk, 0.75); heatFlow(c, hx+26, yb+30, hx+26, yb+2, 13, (this.clk*0.9)%1, {k:0.8}); T(c,"熱", hx+40, yb+20, {size:12, bold:true, col:COL.heat, halo:true}); }
    if(this.heatDir<0){ c.save(); c.fillStyle="#cfe4f6"; c.strokeStyle="#1f6fb2"; c.lineWidth=1.2; rrect(c, hx-34, yb+14, 68, 16, 4); c.fill(); c.stroke(); c.restore();
      T(c,"冷たい物体", hx, yb+40, {size:10.5, bold:true, col:"#1f6fb2", align:"center", halo:true});
      heatFlow(c, hx+44, yb+2, hx+44, yb+30, 13, (this.clk*0.9)%1, {k:0.8}); T(c,"熱", hx+58, yb+16, {size:12, bold:true, col:COL.heat, halo:true}); }
    /* ポンプ（左）：押すと取っ手が下がる */
    var pd=(this.pumpT>=0)? Math.sin(Math.PI*clamp(this.pumpT/0.9,0,1)) : 0, pxc=px-28, pt0=cy-62, pb0=cy+h/2+40;
    c.save(); c.fillStyle="#e9edf1"; c.strokeStyle="#5b636e"; c.lineWidth=1.3; rrect(c, pxc-11, pt0+10, 22, pb0-pt0-10, 4); c.fill(); c.stroke();
    c.fillStyle="#7a828c"; c.fillRect(pxc-2, pt0-14+pd*26, 4, 26); c.fillStyle="#3a414c"; rrect(c, pxc-20, pt0-18+pd*26, 40, 7, 3); c.fill();
    c.strokeStyle="#5b636e"; c.lineWidth=5; c.beginPath(); c.moveTo(pxc, pb0); c.lineTo(pxc, pb0+2); c.quadraticCurveTo(pxc+40, pb0+4, ox-16, cy+10); c.lineTo(ox-9, cy+10); c.stroke();
    c.lineWidth=3; c.strokeStyle="#c9ced6"; c.beginPath(); c.moveTo(pxc, pb0+2); c.quadraticCurveTo(pxc+40, pb0+4, ox-16, cy+10); c.stroke(); c.restore();
    T(c, "ポンプ", pxc, pt0-28, {size:11.5, bold:true, col:COL.sub, align:"center"});
    /* 温度計（上から縦に刺す） */
    var tx=ox+18;
    /* シリンダー */
    drawCylinder(c, F, {L:L, Lmax:Lmax, h:h, T:this.T, gas:this.gas, r:4.2, rod:Math.max(26, Lmax-L+30), pt:13, noGas:this.n<=0});
    thermometer(c, tx, cy+h*0.18, cy-h/2-58, this.T, 100, 600, {noVal:true, noNum:true, ticks:[]});
    T(c, Math.round(this.T)+" K", tx+12, cy-h/2-60, {size:12.5, bold:true, col:"#a03028", halo:true});
    /* 大気圧と手 */
    var rodE=ox+L+13+Math.max(26, Lmax-L+30);
    if(held){ hand(c, rodE-6, cy+3, 0); T(c, this.p>1? "手で押す" : "手で引く", rodE+12, cy-26, {size:11, bold:true, col:COL.sub, align:"center", halo:true}); }
    else T(c, "大気", Math.min(W-30, ox+Lmax+24), cy-h/2-18, {size:11.5, bold:true, col:COLG.atm, align:"center", halo:true});
    notebook(c,W,H);
    /* パネル */
    var nz=this.n>0.004, d=this.dir||{};
    setPanel(this.sec, { p:[nz? this.p.toFixed(2) : "—", nz? d.p||0 : 0], V:[nz? v2s(V) : "0.00", nz? d.V||0 : 0], T:[String(Math.round(this.T)), d.T||0], n:[this.n.toFixed(2), d.n||0] });
    var mh='<span>'+this.note+'</span>';
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};

/* ---------------- ①-2 ピストンの力のつり合い ----------------
   n＝0.20 mol、T＝300 K（向きを変えても温度は変わらない）。S＝4.9×10⁻³ m²、m＝M＝10 kg、mg/S＝2.0×10⁴ Pa */
var S12 = {
  n:0.20, T:300, S:4.9e-3, m:10, M:10,
  DIRS:{h:{lab:"横", dp:0}, u:{lab:"鉛直上向き", dp:0.2}, uw:{lab:"上向き（おもり）", dp:0.4}, d:{lab:"下向き", dp:-0.2}},
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.dir="h"; this.show=true; this.p=1.0; this.seen={h:true}; this.gas=new Gas(26, 12); this.clk=0;
    this.sd=wireSeg(sec,"dir",function(v){ self.dir=v; self.seen[v]=true; self.draw(); });
    this.sc=wireChk(sec,"force",function(on){ self.show=on; self.draw(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.dir="h"; self.sd.set("h"); self.show=true; self.sc.set(true); self.seen={h:true}; self.p=1.0; self.draw(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    idleLoop(sec, function(dt){ var pt=1+self.DIRS[self.dir].dp; self.p+=(pt-self.p)*(1-Math.exp(-dt*3)); if(Math.abs(pt-self.p)<0.001) self.p=pt; self.clk+=dt;
      if(self.g) self.gas.step(dt, self.g.L, self.g.h, 55, 4); self.draw(); });
    this.draw();
  },
  Vof:function(p){ return this.n*RGAS*this.T/(p*1e5); },     /* m³ */
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return W<620? clamp(W*1.25, 470, 560) : clamp(W*0.48, 330, 420); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var narrow=W<620, dir=this.dir, p=this.p, V=this.Vof(p);
    var aw=narrow? W : W*0.56, ah=narrow? H*0.56 : H;
    var h=narrow? 74 : 90, VM=8.0e-3, Lmax=Math.min((dir==="h")? aw-96 : ah-170, 330), L=Lmax*V/VM, pt=14;
    var ox, oy, d2=(dir==="h")? "right" : (dir==="d")? "down" : "up";
    if(dir==="h"){ ox=36; oy=ah*0.46; }
    else if(dir==="d"){ ox=aw*0.40; oy=40; }
    else { ox=aw*0.40; oy=ah-28; }
    var F=new CylFrame(ox, oy, d2);
    this.g={L:Math.max(L,8), h:h};
    /* 支え（閉じた端を固定） */
    c.save(); var sp=F.to(-9-12,0), wv=h+40; c.translate(sp[0],sp[1]); c.rotate(F.ang);
    c.fillStyle="#e8e2d6"; c.fillRect(-12,-wv/2,12,wv); c.strokeStyle="#5b636e"; c.lineWidth=1.4; c.beginPath(); c.moveTo(0,-wv/2); c.lineTo(0,wv/2); c.stroke();
    c.beginPath(); c.rect(-12,-wv/2,12,wv); c.clip(); c.strokeStyle="#a9a193"; c.lineWidth=1; for(var k=-wv/2-12;k<wv/2;k+=8){ c.beginPath(); c.moveTo(0,k); c.lineTo(-12,k+10); c.stroke(); } c.restore();
    drawCylinder(c, F, {L:L, Lmax:Lmax, h:h, T:this.T, gas:this.gas, r:4, pt:pt, mcol:heatCol(gasLv(300))});
    /* おもり */
    if(dir==="uw"){ var w0=F.to(L+pt,-h*0.36), w1=F.to(L+pt+30,h*0.36); c.save(); c.fillStyle="#6d747d"; c.strokeStyle="#2b323c"; c.lineWidth=1.2;
      rrect(c, Math.min(w0[0],w1[0]), Math.min(w0[1],w1[1]), Math.abs(w1[0]-w0[0]), Math.abs(w1[1]-w0[1]), 4); c.fill(); c.stroke(); c.restore();
      var wc=F.to(L+pt+15,0); T(c,"おもり", wc[0], wc[1], {size:11, bold:true, col:"#fff", align:"center"}); }
    /* 大気 */
    var at=F.to(Math.min(L+pt+(dir==="uw"? 70 : 46), Lmax+30), h*0.5+30);
    T(c, "大気（"+"圧力 p₀）", at[0], at[1], {size:11, bold:true, col:COLG.atm, align:"center", halo:true});
    /* 力の矢印（作用点に ・）。長さは力の大きさに比例 */
    if(this.show){
      var kF=(dir==="h")? (narrow? 0.22 : 0.26) : (narrow? 0.13 : 0.16), ax=Math.cos(F.ang), ay=Math.sin(F.ang);
      var arr=function(lx, ly, fx, fy, N, col, lab, sub, side){ var s=F.to(lx,ly), e=[s[0]+fx*N*kF, s[1]+fy*N*kF];
        fArrow(c, s[0], s[1], e[0], e[1], col, 3, 10);
        var lxp=e[0]+(Math.abs(fx)>0.5? fx*8 : 10), lyp=e[1]+(Math.abs(fy)>0.5? fy*12 : 0), al=(fx<-0.5? "right" : "left");
        if(sub==="0S"){ /* p₀S：p の右下に 0、そのあとに S */
          c.save(); c.font="italic 700 14px "+MATHF; var w1=c.measureText("p").width, w3=c.measureText("S").width; c.font="10px "+SERIF; var w2=c.measureText("0").width; c.restore();
          var x0=(al==="right")? lxp-(w1+w2+w3+3) : lxp, a=SYM(c,"p","0",x0,lyp,{size:14,bold:true,col:col,halo:true}); SYM(c,"S",null,x0+a+1,lyp,{size:14,bold:true,col:col,halo:true}); }
        else SYM(c, lab, sub, lxp, lyp, {size:14, bold:true, col:col, halo:true, align:al}); };
      var pS=p*1e5*this.S, p0S=1e5*this.S, mg=this.m*9.8, Mg=this.M*9.8;
      arr(L, -h*0.28, ax, ay, pS, COLG.gasF, "pS", null, 0);
      arr(L+pt, h*0.28, -ax, -ay, p0S, COLG.atm, "p", "0S", 0);
      var cen=F.to(L+pt/2, 0);
      if(dir!=="h"){ fArrow(c, cen[0], cen[1], cen[0], cen[1]+mg*kF, COLG.grav, 3, 9); SYM(c,"mg",null,cen[0]+(dir==="d"? 6 : -6),cen[1]+mg*kF+10,{size:13,bold:true,col:COLG.grav,halo:true,align:(dir==="d"? "left" : "right")}); }
      if(dir==="uw"){ var tp=F.to(L+pt, -h*0.06); fArrow(c, tp[0], tp[1], tp[0], tp[1]+Mg*kF, COLG.norm, 3, 9); SYM(c,"Mg",null,tp[0]-6,tp[1]-8,{size:13,bold:true,col:COLG.norm,halo:true,align:"right"}); }
    }
    /* p-V 図（右） */
    var gx0=narrow? 54 : aw+40, gy0=narrow? H-34 : H-40, gx1=W-14, gy1=narrow? ah+24 : 26;
    var P=plotFrame(c, gx0, gy0, gx1, gy1, [0,8], [0,1.6], {xl:"V〔×10⁻³ m³〕", yl:"p〔×10⁵ Pa〕", xstep:2, ystep:0.4});
    var k0=this.n*RGAS*this.T/1e5*1e3;      /* pV の値（×10⁵ Pa・×10⁻³ m³） */
    curve(c, P, function(v){ return k0/v; }, 2.6, 7.9, "#9aa1ab", 1.3, [5,4], [0,1.6]);
    var tq=P.X(7.4), tqy=P.Y(k0/7.4); T(c,"300 K の等温線", tq, tqy-12, {size:10.5, col:COL.sub, align:"right", halo:true});
    var self2=this;
    Object.keys(this.DIRS).forEach(function(k){ if(!self2.seen[k] || k===dir) return; var pp=1+self2.DIRS[k].dp, vv=self2.Vof(pp)*1e3;
      dot(c, P.X(vv), P.Y(pp), 4, "#b9b2a6"); T(c, self2.DIRS[k].lab, P.X(vv)+7, P.Y(pp)+(k==="uw"? -10 : 10), {size:10, col:COL.sub, halo:true}); });
    var vv=V*1e3; dot(c, P.X(vv), P.Y(p), 6, "#c0392b");
    c.save(); c.setLineDash([3,3]); c.strokeStyle="rgba(192,57,43,.5)"; c.beginPath(); c.moveTo(P.X(vv),P.Y(p)); c.lineTo(P.X(vv),P.y0); c.moveTo(P.X(vv),P.Y(p)); c.lineTo(P.x0,P.Y(p)); c.stroke(); c.restore();
    T(c, this.DIRS[dir].lab, P.X(vv)+9, P.Y(p)-12, {size:11.5, bold:true, col:"#c0392b", halo:true});
    notebook(c,W,H);
    var sgn=this.DIRS[dir].dp, mh='気体の圧力 '+tex("p")+' = <span class="num">'+p.toFixed(2)+'</span> ×10⁵ Pa　体積 '+tex("V")+' = <span class="num">'+(vv).toFixed(2)+'</span> ×10⁻³ m³'+
      '<br>'+(dir==="h"? '横向きでは、軸の方向の力は '+tex("pS")+' と '+tex("p_0S")+' だけ（ピストンの重力は、筒の壁からの垂直抗力とつり合う。図では省略）。' :
                 dir==="d"? '下向きでは、ピストンの重力の分だけ、気体の圧力は大気圧より小さい。' :
                 '上向きでは、ピストン'+(dir==="uw"? 'とおもり' : '')+'の重さの分だけ、気体の圧力は大気圧より大きい。');
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};

/* ---------------- ①-3 ボイルの法則 ----------------
   n＝1.0 mol。押す：V＝4.0 → 1.0（×10⁻² m³）、引く：1.0 → 4.0。8 秒。0.5 ごとに点を打つ */
var S13 = {
  DUR:8, n:1.0,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.dirb="push"; this.Tb=300; this.gas=new Gas(36, 13); this.clk=0; this.flash=0;
    this.run=new Runner({ again:true,
      startText:function(){ return self.dirb==="push"? "▶ スタート（押す）" : "▶ スタート（引く）"; },
      step:function(dt){ self.clk+=dt; self.move(dt); self.tb.sync(); return self.run.t>=self.DUR; },
      draw:function(){ self.draw(); }, reset:function(){},
      info:function(){ return ''; } });
    this.run.bind(sec);
    this.tb=wireTimeBar(sec, this.run, function(){ return self.DUR; }, function(){});
    this.sa=wireSeg(sec,"dirb",function(v){ self.dirb=v; self.run.reset(); self.tb.sync(); });
    this.st=wireSeg(sec,"tb",function(v){ self.Tb=parseFloat(v); self.run.reset(); self.tb.sync(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.dirb="push"; self.sa.set("push"); self.Tb=300; self.st.set("300"); resetSlow(sec,self.run); self.run.reset(); self.tb.sync(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    idleLoop(sec, function(dt){ if(self.run.state!=="run"){ self.clk+=dt; self.move(dt); self.draw(); } });
    this.draw();
  },
  Vt:function(t){ var u=clamp(t/this.DUR,0,1); return this.dirb==="push"? 4.0-3.0*u : 1.0+3.0*u; },   /* ×10⁻² m³ */
  move:function(dt){ var g=this.g; if(!g) return; var h0=this.gas.hits; this.gas.step(dt, g.L, g.h, 52*Math.sqrt(this.Tb/300), 4); if(this.gas.hits>h0) this.flash=0.18; this.flash=Math.max(0,this.flash-dt); },
  rate:function(L){ var s=0, vs=52*Math.sqrt(this.Tb/300); this.gas.m.forEach(function(q){ s+=Math.abs(q.vx); }); return s*vs/(2*Math.max(L-8,1)); },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return W<620? clamp(W*1.15, 440, 520) : clamp(W*0.45, 300, 380); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var narrow=W<620, aw=narrow? W : W*0.52, ah=narrow? H*0.40 : H;
    var V=this.Vt(this.run.t), p=this.n*RGAS*this.Tb/(V*1e-2)/1e5;
    var ox=26, h=narrow? 72 : 92, Lmax=aw-ox-70, L=Lmax*V/4.6, cy=narrow? ah*0.50 : ah*0.42;
    this.g={L:L, h:h};
    var F=new CylFrame(ox, cy, "right");
    drawCylinder(c, F, {L:L, Lmax:Lmax, h:h, T:this.Tb, gas:this.gas, r:4, pt:13, rod:Lmax-L+26});
    if(this.flash>0){ c.save(); c.fillStyle="rgba(224,123,24,"+(this.flash/0.18*0.55)+")"; c.fillRect(ox+L, cy-h/2, 13, h); c.restore(); }
    var rodE=ox+L+13+Lmax-L+26; hand(c, rodE-6, cy+3, 0);
    T(c, this.dirb==="push"? "押す" : "引く", rodE+14, cy-24, {size:11.5, bold:true, col:COL.sub, align:"center", halo:true});
    var rt=this.rate(L);
    T(c, "ピストンに分子が当たる回数　1 秒あたり 約 "+rt.toFixed(1)+" 回", ox, cy+h/2+26, {size:narrow? 11 : 12, bold:true, col:"#9c4e06", halo:true});
    T(c, "温度 "+this.Tb+" K（一定）", ox, cy-h/2-22, {size:11.5, bold:true, col:"#a03028", halo:true});
    /* p-V 図 */
    var gx0=narrow? 52 : aw+40, gy0=H-38, gx1=W-14, gy1=narrow? ah+30 : 24;
    var P=plotFrame(c, gx0, gy0, gx1, gy1, [0,5], [0,5.6], {xl:"V〔×10⁻² m³〕", yl:"p〔×10⁵ Pa〕", xstep:1, ystep:1});
    var kk=function(Tb){ return self.n*RGAS*Tb*1e-3; };      /* pV（×10⁵ Pa・×10⁻² m³） */
    [300,600].forEach(function(Tb){ curve(c, P, function(v){ return kk(Tb)/v; }, 0.42, 4.9, Tb===self.Tb? "#e0457b" : "#c9c3b8", 1.3, [5,4], [0,5.6]);
      T(c, Tb+" K", P.X(4.75), P.Y(kk(Tb)/4.75)-10, {size:10.5, bold:true, col:Tb===self.Tb? "#e0457b" : COL.sub, align:"center", halo:true}); });
    var v0=this.dirb==="push"? 4.0 : 1.0;
    for(var k=0;k<=6;k++){ var vv=this.dirb==="push"? 4.0-0.5*k : 1.0+0.5*k; if(this.dirb==="push"? vv<V-1e-6 : vv>V+1e-6) break; dot(c, P.X(vv), P.Y(kk(this.Tb)/vv), 4.2, "#1f6fb2"); }
    dot(c, P.X(V), P.Y(p), 6, "#c0392b");
    notebook(c,W,H);
    var mh=tex("V")+' = <span class="num">'+V.toFixed(2)+'</span> ×10⁻² m³　'+tex("p")+' = <span class="num">'+p.toFixed(2)+'</span> ×10⁵ Pa　'+tex("pV")+' = <span class="num">'+(p*V*1e3).toFixed(0)+'</span> J'+
      '<br>当たる回数は、体積が '+v0.toFixed(1)+' ×10⁻² m³ のときの <span class="num">'+(v0/V).toFixed(2)+'</span> 倍、圧力も <span class="num">'+(v0/V).toFixed(2)+'</span> 倍。';
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};

/* ---------------- ①-4 シャルルの法則 ----------------
   n＝1.0 mol、p＝1.0×10⁵ Pa（おもりで一定）。温める：200 → 400 K、冷やす：400 → 200 K。8 秒。50 K ごとに点 */
var S14 = {
  DUR:8, n:1.0,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.hc="heat"; this.gas=new Gas(32, 14); this.clk=0;
    this.run=new Runner({ again:true,
      startText:function(){ return self.hc==="heat"? "▶ スタート（温める）" : "▶ スタート（冷やす）"; },
      step:function(dt){ self.clk+=dt; self.move(dt); self.tb.sync(); return self.run.t>=self.DUR; },
      draw:function(){ self.draw(); }, reset:function(){} });
    this.run.bind(sec);
    this.tb=wireTimeBar(sec, this.run, function(){ return self.DUR; }, function(){});
    this.sh=wireSeg(sec,"hc",function(v){ self.hc=v; self.run.reset(); self.tb.sync(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.hc="heat"; self.sh.set("heat"); resetSlow(sec,self.run); self.run.reset(); self.tb.sync(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    idleLoop(sec, function(dt){ if(self.run.state!=="run"){ self.clk+=dt; self.move(dt); self.draw(); } });
    this.draw();
  },
  Tt:function(t){ var u=clamp(t/this.DUR,0,1); return this.hc==="heat"? 200+200*u : 400-200*u; },
  move:function(dt){ var g=this.g; if(g) this.gas.step(dt, g.w, g.L, 52*Math.sqrt(this.Tt(this.run.t)/300), 4); },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return W<620? clamp(W*1.2, 470, 540) : clamp(W*0.46, 320, 390); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var narrow=W<620, aw=narrow? W : W*0.44, ah=narrow? H*0.47 : H, Tk=this.Tt(this.run.t), V=this.n*RGAS*Tk/1e5*100;   /* ×10⁻² m³ */
    var w=narrow? 92 : 104, baseY=ah-58, Lmax=Math.min(ah-120, 260), L=Lmax*V/3.8, ox=aw*0.5, running=(this.run.state==="run");
    this.g={w:L, L:w};     /* 縦向き：気体の部分の「幅」は L、高さは w（回した座標） */
    var F=new CylFrame(ox, baseY, "up");
    /* 台（熱を伝える板）とバーナー・冷たい物体 */
    c.save(); c.fillStyle="#d9d2c2"; c.fillRect(ox-w/2-24, baseY+9, w+48, 8); c.restore();
    if(this.hc==="heat"){ burner(c, ox, ah-4, running, this.clk, 0.8); if(running) heatFlow(c, ox+w*0.32, ah-30, ox+w*0.32, baseY+12, 12, (this.clk*0.9)%1, {k:0.8}); }
    else { c.save(); c.fillStyle="#cfe4f6"; c.strokeStyle="#1f6fb2"; rrect(c, ox-w/2-10, baseY+19, w+20, 16, 4); c.fill(); c.stroke(); c.restore(); T(c,"冷たい物体", ox, baseY+44, {size:10.5, bold:true, col:"#1f6fb2", align:"center"});
      if(running) heatFlow(c, ox+w/2+22, baseY-6, ox+w/2+22, baseY+30, 12, (this.clk*0.9)%1, {k:0.8}); }
    drawCylinder(c, F, {L:L, Lmax:Lmax, h:w, T:Tk, gas:this.gas, r:4, pt:13});
    /* おもり */
    var wy=baseY-L-13; c.save(); c.fillStyle="#6d747d"; c.strokeStyle="#2b323c"; rrect(c, ox-w*0.34, wy-26, w*0.68, 26, 4); c.fill(); c.stroke(); c.restore();
    T(c,"おもり", ox, wy-13, {size:11, bold:true, col:"#fff", align:"center"});
    /* 温度計（横から刺す） */
    c.save(); c.translate(ox-w/2-9, baseY-16); c.rotate(-Math.PI/2); thermometer(c, 0, 18, -62, Tk, 100, 450, {noVal:true, noNum:true, tw:8, br:6}); c.restore();
    T(c, Math.round(Tk)+" K", ox-w/2-44, baseY-48, {size:12.5, bold:true, col:"#a03028", align:"center", halo:true});
    T(c, "（"+Math.round(Tk-273)+" ℃）", ox-w/2-44, baseY-32, {size:11, bold:true, col:"#a03028", align:"center", halo:true});
    T(c, "圧力 1.0×10⁵ Pa（一定）", ox, 16, {size:11, bold:true, col:COLG.p, align:"center", halo:true});
    /* V–T 図（下に ℃ の目盛り） */
    var gx0=narrow? 54 : aw+44, gy0=H-50, gx1=W-14, gy1=narrow? ah+26 : 24;
    var P=plotFrame(c, gx0, gy0, gx1, gy1, [0,450], [0,4], {xl:"T〔K〕", yl:"V〔×10⁻² m³〕", xstep:100, ystep:1, xz:false});
    T(c, "0", P.X(0), gy0+11, {size:10.5, col:COL.sub, align:"center"});
    [[-273,0],[0,273],[100,373]].forEach(function(q){ T(c, q[0]+" ℃", P.X(q[1]), gy0+34, {size:10, col:"#a03028", align:"center", halo:true}); });
    var kv=this.n*RGAS/1e5*100;
    c.save(); c.setLineDash([5,4]); c.strokeStyle="#9aa1ab"; c.lineWidth=1.3; c.beginPath(); c.moveTo(P.X(0),P.Y(0)); c.lineTo(P.X(200),P.Y(kv*200)); c.stroke(); c.restore();
    T(c, "のばすと 0 K で V＝0", P.X(60), P.Y(kv*60)-16, {size:10.5, col:COL.sub, halo:true});
    var t0=this.hc==="heat"? 200 : 400;
    c.save(); c.strokeStyle="#1f6fb2"; c.lineWidth=2.2; c.beginPath(); c.moveTo(P.X(t0),P.Y(kv*t0)); c.lineTo(P.X(Tk),P.Y(kv*Tk)); c.stroke(); c.restore();
    for(var k=0;k<=4;k++){ var tt=this.hc==="heat"? 200+50*k : 400-50*k; if(this.hc==="heat"? tt>Tk+1e-6 : tt<Tk-1e-6) break; dot(c, P.X(tt), P.Y(kv*tt), 4.2, "#1f6fb2"); }
    dot(c, P.X(Tk), P.Y(V), 6, "#c0392b");
    notebook(c,W,H);
    var mh=tex("T")+' = <span class="num">'+Math.round(Tk)+'</span> K　'+tex("V")+' = <span class="num">'+V.toFixed(2)+'</span> ×10⁻² m³　'+tex("\\dfrac{V}{T}")+' = <span class="num">'+(V/Tk*100).toFixed(2)+'</span> ×10⁻⁴ m³/K（一定）';
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};

/* ---------------- ①-5 状態方程式 ----------------
   決める 2 つの量と n をスライダーで。残りの 1 つを pV＝nRT で求める */
var S15 = {
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    sec.querySelector(".ctrls").insertAdjacentHTML("afterend", panelHTML(["p","V","T","n"]));
    this.pick="pV"; this.v={p:1.0, V:2.5, T:300, n:1.0}; this.gas=new Gas(20, 15); this.clk=0;
    var fm={p:function(v){ return v.toFixed(1)+" ×10⁵ Pa"; }, V:function(v){ return v.toFixed(1)+" ×10⁻² m³"; }, T:function(v){ return v.toFixed(0)+" K"; }, n:function(v){ return v.toFixed(1)+" mol"; }};
    this.sl={};
    ["p","V","T","n"].forEach(function(k){ self.sl[k]=wireSlider(sec,k,fm[k],function(v){ self.v[k]=v; self.calc(); self.draw(); }); });
    this.sp=wireSeg(sec,"pick",function(v){ self.pick=v; self.lock(); self.calc(); self.draw(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.pick="pV"; self.sp.set("pV"); self.v={p:1.0, V:2.5, T:300, n:1.0};
      ["p","V","T","n"].forEach(function(k){ self.sl[k].set(self.v[k]); }); self.lock(); self.calc(); self.draw(); });
    this.lock(); this.calc();
    onResize(this.cv.parentElement, function(){ self.draw(); });
    idleLoop(sec, function(dt){ self.clk+=dt; if(self.g) self.gas.step(dt, self.g.L, self.g.h, 52*Math.sqrt(self.v.T/300), 4); self.draw(); });
    this.draw();
  },
  free:function(){ return {pV:"T", VT:"p", pT:"V"}[this.pick]; },
  lock:function(){ var fr=this.free(), sec=this.sec;
    ["p","V","T"].forEach(function(k){ var row=sec.querySelector('.vrow[data-k="'+k+'"]'); var on=(k===fr); row.classList.toggle("calc", on);
      row.querySelectorAll("input,button").forEach(function(e){ e.disabled=on; }); });
    sec.querySelectorAll('.gcard').forEach(function(e){ e.classList.toggle("calc", e.dataset.k===fr); }); },
  calc:function(){ var v=this.v, fr=this.free(), nR=v.n*RGAS;
    if(fr==="T") v.T=v.p*1e5*v.V*1e-2/nR; if(fr==="p") v.p=nR*v.T/(v.V*1e-2)/1e5; if(fr==="V") v.V=nR*v.T/(v.p*1e5)*100;
    this.sl[fr].set(clamp(v[fr], parseFloat(this.sec.querySelector('.vrow[data-k="'+fr+'"] input').min), parseFloat(this.sec.querySelector('.vrow[data-k="'+fr+'"] input').max)));
    var vv=this.sec.querySelector('.vrow[data-k="'+fr+'"] .vv'); vv.innerHTML=(fr==="T"? v.T.toFixed(0)+" K" : fr==="p"? v.p.toFixed(2)+" ×10⁵ Pa" : v.V.toFixed(2)+" ×10⁻² m³")+'<small>（計算）</small>';
    this.gas.setN(Math.round(v.n*20)); },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return clamp(W*0.36, 230, 300); }), c=f.c, W=f.W, H=f.H, v=this.v;
    c.clearRect(0,0,W,H);
    var ox=40, h=W<560? 80 : 100, cy=H*0.48, Lmax=W-ox-110, Vd=Math.min(v.V, 7.6), L=Lmax*Vd/8.0;
    this.g={L:L, h:h};
    var F=new CylFrame(ox, cy, "right");
    drawCylinder(c, F, {L:L, Lmax:Lmax, h:h, T:clamp(v.T,100,650), gas:this.gas, r:4, pt:13, rod:Lmax-L+26});
    thermometer(c, ox+18, cy+h*0.18, cy-h/2-52, clamp(v.T,100,650), 100, 650, {noVal:true, noNum:true});
    T(c, Math.round(v.T)+" K", ox+30, cy-h/2-54, {size:12.5, bold:true, col:"#a03028", halo:true});
    var rodE=ox+L+13+Lmax-L+26;
    if(Math.abs(v.p-1)>0.005){ hand(c, rodE-6, cy+3, 0); T(c, v.p>1? "手で押さえる" : "手で引く", rodE+12, cy-26, {size:11, bold:true, col:COL.sub, align:"center", halo:true}); }
    else T(c, "大気（1.0×10⁵ Pa）", Math.min(W-60, rodE-10), cy-h/2-18, {size:11, bold:true, col:COLG.atm, align:"center", halo:true});
    if(v.V>7.6) T(c, "（体積が大きすぎて、図に入りきらない）", ox+10, cy+h/2+26, {size:11, bold:true, col:"#c0392b"});
    notebook(c,W,H);
    var fr=this.free();
    setPanel(this.sec, {p:[v.p.toFixed(2),0], V:[v.V.toFixed(2),0], T:[v.T.toFixed(0),0], n:[v.n.toFixed(1),0]});
    var pvt=v.p*1e5*v.V*1e-2/v.T;
    var mh=tex("\\dfrac{pV}{T}")+' = <span class="num">'+pvt.toFixed(2)+'</span> J/K　＝　'+tex("nR")+' = '+v.n.toFixed(1)+' × 8.31 = <span class="num">'+(v.n*RGAS).toFixed(2)+'</span> J/K';
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};
