// thermo-dynamics.html を src/ から 1 枚にまとめる（node build.js）
// KaTeX（katex.css・katex.js）と共通の見た目（site.css・15_page.css）、10_core.js・20_thermo.js・84_sitenav.js・99_footer.html は
// 兄弟ページ thermal-energy.html のソースから取ったもの。
const fs = require('fs'), path = require('path');
const D = path.join(__dirname, 'src');
const r = (n) => fs.readFileSync(path.join(D, n), 'utf8');
const JS = ['10_core.js', '20_thermo.js', '30_gas.js', '50_m1.js', '60_m2.js', '70_m3.js', '75_m4.js', '80_page.js', '84_sitenav.js', '85_design.js'];
const html =
  r('00_head.html') +
  '<style>' + r('katex.css') + '</style>\n' +
  '<style>' + r('site.css') + r('15_page.css') + r('16_td.css') + '</style>\n' +
  '</head>\n<body id="top">\n' +
  '<header class="hero" id="hero"></header><nav class="tabs" id="tabs" aria-label="章の切りかえ"></nav><div class="wrap" id="wrap"></div>\n' +
  '<script>' + r('katex.js') + '</script>\n' +
  '<script>\n' + JS.map(r).join('\n') + '</script>\n' +
  r('99_footer.html') + '\n</body>\n</html>\n';
const out = path.join(__dirname, 'thermo-dynamics.html');
fs.writeFileSync(out, html);
console.log(out, Buffer.byteLength(html));
