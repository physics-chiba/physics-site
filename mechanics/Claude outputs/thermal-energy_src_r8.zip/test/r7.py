import asyncio, json
from playwright.async_api import async_playwright
URL='file:///home/claude/te/thermal-energy.html'; OUT='/home/claude/te/test/'
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        res={}
        for w,h in [(1440,900),(390,844)]:
            pg=await b.new_page(viewport={'width':w,'height':h}); errs=[]
            pg.on('pageerror', lambda e: errs.append(str(e)))
            await pg.goto(URL); await pg.wait_for_timeout(800)
            for sid in ['s11','s12','s14','s15','s21','s30','s23']:
                await pg.evaluate(f'gotoSec("{sid}")'); await pg.wait_for_timeout(350)
                await (await pg.query_selector('#'+sid)).screenshot(path=OUT+f'r7_{sid}_{w}.png')
            await pg.evaluate('gotoSec("s15")'); await pg.click('#s15 button[data-v="sl"]'); await pg.wait_for_timeout(300)
            await pg.click('#s15 button.b.play'); await pg.wait_for_timeout(1500)
            await (await pg.query_selector('#s15 .sL')).screenshot(path=OUT+f'r7_s15sl_{w}.png')
            await pg.evaluate('gotoSec("s14")'); await pg.click('#s14 button.b.play'); await pg.wait_for_timeout(2500)
            await (await pg.query_selector('#s14 .sL')).screenshot(path=OUT+f'r7_s14run_{w}.png')
            await pg.evaluate('gotoSec("s13")'); await pg.click('#s13 button.b.play'); await pg.wait_for_timeout(5000)
            await (await pg.query_selector('#s13 canvas.main')).screenshot(path=OUT+f'r7_s13a_{w}.png')
            await pg.wait_for_timeout(4000)
            await (await pg.query_selector('#s13 canvas.main')).screenshot(path=OUT+f'r7_s13b_{w}.png')
            await pg.evaluate('gotoSec("s30")'); await pg.click('#s30 button.b.play'); await pg.evaluate("(()=>{const i=document.querySelector('#s30 .tsl input'); i.value=0; i.dispatchEvent(new Event('input'));})()"); await pg.wait_for_timeout(500)
            await (await pg.query_selector('#s30 canvas.main')).screenshot(path=OUT+f'r7_s30z_{w}.png')
            sw=await pg.evaluate('document.documentElement.scrollWidth')
            res[w]={'errs':errs,'sw':sw}
            await pg.close()
        print(json.dumps(res))
        await b.close()
asyncio.run(main())
