// thermal-energy.html を src/ から 1 枚にまとめる（node build.js）
// KaTeX（katex.css・katex.js）と共通の見た目（site.css）は simple-harmonic-motion.html から取り出したもの。
const fs = require('fs'), path = require('path');
const D = path.join(__dirname, 'src');
const r = (n) => fs.readFileSync(path.join(D, n), 'utf8');
const JS = ['10_core.js', '20_thermo.js', '50_m1.js', '51_m13.js', '52_m1b.js', '53_m15.js', '60_m2.js', '62_m23.js', '80_page.js', '84_sitenav.js', '85_design.js'];
const html =
  r('00_head.html') +
  '<style>' + r('katex.css') + '</style>\n' +
  '<style>' + r('site.css') + r('15_page.css') + '</style>\n' +
  '</head>\n<body id="top">\n' +
  '<header class="hero" id="hero"></header><nav class="tabs" id="tabs" aria-label="モードの切りかえ"></nav><div class="wrap" id="wrap"></div>\n' +
  '<script>' + r('katex.js') + '</script>\n' +
  '<script>\n' + JS.map(r).join('\n') + '</script>\n' +
  r('99_footer.html') + '\n</body>\n</html>\n';
const out = path.join(__dirname, 'thermal-energy.html');
fs.writeFileSync(out, html);
console.log(out, Buffer.byteLength(html));
