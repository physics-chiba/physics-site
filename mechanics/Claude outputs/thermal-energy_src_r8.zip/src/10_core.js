"use strict";
/* =========================================================================
   熱とエネルギー（thermal-energy.html）。骨組みは兄弟ページ fluid-force.html と同じ
   共通：定数・数式（KaTeX）・canvas の部品
   ========================================================================= */
var G = 9.8, RHO_W = 1.0e3, RHO_A0 = 1.2, P0 = 1.013e5, HSC = 8000;   // HSC：大気の高さのめやす（温度一定のモデル）
var FONT = '"Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
var MATHF = '"KaTeX_Math","Times New Roman",serif';
var SERIF = '"KaTeX_Main","Times New Roman",serif';
/* 色：力の種類ごと（力のベクトルの描き方ルール ④・⑥）。
   重力＝赤、垂直抗力＝むらさき、浮力＝緑（空いている色から）、
   圧力の矢印＝金（力・速度・加速度の色を使わない）、上下の面が受ける力 F1・F2＝茶 */
var COL = {
  water:"#d4ebf9", water2:"#bfe0f5", surf:"#4f8fc0", wall:"#3a414c", ink:"#14171c", sub:"#69717d", dim:"#9aa1ab",
  press:"#b58900", faceF:"#8a5a2b", force:"#d1352b", grav:"#d1352b", buoy:"#1c8f4a", norm:"#7b3fd4",
  vel:"#1663b5", gray:"#a6abb2", dashed:"#2f6f9f",
  heat:"#e8731a", work:"#1c8f4a", dU:"#c0392b", hot:"#c0392b", cold:"#1f6fb2"
};
/* 液体（①-4） */
var LIQS = [
  {key:"oil",  name:"油",      rho:800,   fill:"#f6eab8", surf:"#c9a227"},
  {key:"water",name:"水",      rho:1000,  fill:"#d4ebf9", surf:"#4f8fc0"},
  {key:"salt", name:"食塩水",  rho:1200,  fill:"#c6e3f2", surf:"#3f7fae"},
  {key:"hg",   name:"水銀",    rho:13600, fill:"#d9dde2", surf:"#7d8590"}
];
var DENS = [
  {name:"木", rho:500, fill:"#e6c07a", line:"#8a6424"},
  {name:"氷", rho:920, fill:"#eef9ff", line:"#6aa6c9"},
  {name:"水と同じ", rho:1000, fill:"#9fd0f0", line:"#2f6f9f"},
  {name:"アルミニウム", rho:2700, fill:"#cfd4db", line:"#6b7480"},
  {name:"鉄", rho:7900, fill:"#7f868f", line:"#3a414c"}
];

function clamp(x,a,b){ return x<a?a:(x>b?b:x); }
function tex(s, disp){ try{ return katex.renderToString(s,{throwOnError:false, displayMode:!!disp}); }catch(e){ return s; } }
/* 文字列の中の $…$ と $$…$$ を KaTeX にする */
function TX(s){
  return String(s).replace(/\$\$([^$]+)\$\$/g, function(_,a){ return tex(a,true); })
                  .replace(/\$([^$]+)\$/g, function(_,a){ return tex(a,false); });
}
/* 10 のべき乗の表記（2 けた） */
function sci(x, d){
  if(d===undefined) d = 2;
  if(x===0) return "0";
  var e = Math.floor(Math.log10(Math.abs(x))), m = x/Math.pow(10,e);
  if(Math.abs(m) >= 9.995 && d===2){ m/=10; e+=1; }
  var ms = m.toFixed(d-1);
  if(e===0) return ms;
  return ms + "×10" + sup(e);
}
function sup(n){ var map={"-":"⁻","0":"⁰","1":"¹","2":"²","3":"³","4":"⁴","5":"⁵","6":"⁶","7":"⁷","8":"⁸","9":"⁹"};
  return String(n).split("").map(function(c){ return map[c]||c; }).join(""); }
function fx(x, d){ return (Math.abs(x) < 0.5*Math.pow(10,-d)? 0 : x).toFixed(d); }

/* ---------------- canvas ---------------- */
function fitCanvas(cv, hOf){
  var host = cv.parentElement, r = host.getBoundingClientRect();
  var W = Math.max(150, Math.floor(r.width - (parseFloat(getComputedStyle(host).paddingLeft)||0) - (parseFloat(getComputedStyle(host).paddingRight)||0)));
  var H = Math.round(hOf(W));
  var dpr = Math.min(2, window.devicePixelRatio || 1);
  if(cv._W !== W || cv._H !== H || cv._d !== dpr){
    cv.width = Math.round(W*dpr); cv.height = Math.round(H*dpr); cv.style.height = H+"px";
    cv._W = W; cv._H = H; cv._d = dpr;
  }
  var c = cv.getContext("2d"); c.setTransform(dpr,0,0,dpr,0,0);
  return {c:c, W:W, H:H};
}
/* 矢印（ピクセル）。力＝太い実線 */
function arrow(c,x1,y1,x2,y2,col,lw,head){
  var dx=x2-x1, dy=y2-y1, L=Math.hypot(dx,dy); if(L<1.5) return;
  var ux=dx/L, uy=dy/L, h=Math.min(head||10, L*0.62), w=h*0.5;
  c.save(); c.strokeStyle=col; c.fillStyle=col; c.lineWidth=lw||2.4; c.lineCap="round";
  c.beginPath(); c.moveTo(x1,y1); c.lineTo(x2-ux*h*0.75,y2-uy*h*0.75); c.stroke();
  c.beginPath(); c.moveTo(x2,y2); c.lineTo(x2-ux*h-uy*w,y2-uy*h+ux*w); c.lineTo(x2-ux*h+uy*w,y2-uy*h-ux*w); c.closePath(); c.fill();
  c.restore();
}
/* 力の矢印：始点（作用点）に「・」 */
function fArrow(c,x1,y1,x2,y2,col,lw,head){
  if(Math.hypot(x2-x1,y2-y1) < 1.5) return;
  arrow(c,x1,y1,x2,y2,col,lw||3,head||11);
  c.save(); c.fillStyle=col; c.beginPath(); c.arc(x1,y1,3.4,0,7); c.fill(); c.strokeStyle="#fff"; c.lineWidth=1; c.stroke(); c.restore();
}
/* 同じ大きさの印（｜を n 本）。矢印の 42 % の位置 */
function eqTicks(c,x1,y1,x2,y2,n,col){
  var L=Math.hypot(x2-x1,y2-y1); if(L<19) return;
  var ux=(x2-x1)/L, uy=(y2-y1)/L, f=Math.min(0.42*L, L-13), px=-uy, py=ux;
  c.save(); c.strokeStyle=col; c.lineWidth=1.8;
  for(var i=0;i<n;i++){ var o=(i-(n-1)/2)*4, x=x1+ux*(f+o), y=y1+uy*(f+o);
    c.beginPath(); c.moveTo(x-px*6,y-py*6); c.lineTo(x+px*6,y+py*6); c.stroke(); }
  c.restore();
}
/* ---- 共通部品カタログの手・人（basics-of-motion-on-plane の 40_draw.js・45_defs.js から） ---- */
/* つかむ手：こぶしが (hx,hy)、腕が ang の向きへのびる */
function hand(ctx, hx, hy, ang) {
  ctx.save();
  ctx.translate(hx, hy);
  ctx.rotate(ang);
  ctx.fillStyle = '#f6d9bd'; ctx.strokeStyle = '#a97b4c'; ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.moveTo(10, -6); ctx.lineTo(40, -7); ctx.lineTo(40, 7); ctx.lineTo(10, 6);
  ctx.closePath(); ctx.fill(); ctx.stroke();
  ctx.beginPath();
  ctx.ellipse(2, 0, 13, 11, 0, 0, Math.PI * 2);
  ctx.fill(); ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-8, -5); ctx.lineTo(4, -5);
  ctx.moveTo(-9, 0); ctx.lineTo(5, 0);
  ctx.moveTo(-8, 5); ctx.lineTo(4, 5);
  ctx.stroke();
  ctx.restore();
}
/* 手をはなす：(x,y)＝物体の上のはしのまん中、open 0→1、alpha 濃さ */
function dropHand(ctx, x, y, sc, open, alpha) {
  sc = sc || 1;
  var o = Math.max(0, Math.min(1, open || 0));
  var INK = '#3f4a54', SKIN = '#ffffff';
  ctx.save();
  ctx.translate(x, y); ctx.scale(sc, sc);
  ctx.globalAlpha = (alpha === undefined) ? 1 : alpha;
  ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  function limb(x0, y0, cx, cy, x1, y1, w) {
    ctx.beginPath();
    ctx.moveTo(x0, y0); ctx.quadraticCurveTo(cx, cy, x1, y1);
    ctx.lineWidth = w + 3.4; ctx.strokeStyle = INK; ctx.stroke();
    ctx.lineWidth = w; ctx.strokeStyle = SKIN; ctx.stroke();
  }
  limb(-28, -66, -58, -54, -66, -28, 12);
  limb(-14, -72, -46, -58, -52, -21, 13);
  limb(2, -74, -30, -60, -33, -16, 14);
  limb(16, -72, -10 - 9 * o, -58, -13 - 21 * o, -15 - 9 * o, 14);
  ctx.beginPath();
  ctx.moveTo(-32, -62);
  ctx.bezierCurveTo(-8, -94, 42, -98, 64, -74);
  ctx.bezierCurveTo(80, -58, 62, -40, 34, -40);
  ctx.bezierCurveTo(10, -40, -12, -46, -32, -62);
  ctx.closePath();
  ctx.fillStyle = SKIN; ctx.fill();
  ctx.lineWidth = 3.2; ctx.strokeStyle = INK; ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(56, -84); ctx.lineTo(96, -78);
  ctx.lineTo(96, -50); ctx.lineTo(58, -46);
  ctx.closePath();
  ctx.fillStyle = SKIN; ctx.fill(); ctx.lineWidth = 3.2; ctx.strokeStyle = INK; ctx.stroke();
  limb(42, -48, 40 + 10 * o, -25, 17 + 24 * o, -12 - 8 * o, 15);
  ctx.lineWidth = 1.3; ctx.strokeStyle = INK; ctx.globalAlpha *= 0.75;
  ctx.beginPath(); ctx.moveTo(-46, -47); ctx.lineTo(-38, -44); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(-26, -47); ctx.lineTo(-18, -45); ctx.stroke();
  ctx.restore();
}
/* 棒人間（腕はひじで曲げる・頭にかからない高さから出す）。(x,y)＝足もと、s＝身長［px］ */
function stickPerson(ctx, x, y, s, color){
  ctx.save(); ctx.strokeStyle=color||"#3f4a54"; ctx.lineWidth=2; ctx.lineCap="round"; ctx.lineJoin="round";
  var hip=y-s*0.42, sh=y-s*0.70, hd=y-s*0.86, r=s*0.12;
  ctx.beginPath(); ctx.arc(x,hd,r,0,7); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(x,hd+r); ctx.lineTo(x,hip); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(x-s*0.16,y); ctx.lineTo(x,hip); ctx.lineTo(x+s*0.16,y); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(x,sh); ctx.lineTo(x-s*0.15,sh+s*0.13); ctx.lineTo(x-s*0.08,sh+s*0.27); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(x,sh); ctx.lineTo(x+s*0.15,sh+s*0.12); ctx.lineTo(x+s*0.22,sh+s*0.24); ctx.stroke();
  ctx.restore();
}
/* 家 */
function houseShape(ctx, x, y, w){
  var h=w*0.62;
  ctx.save(); ctx.lineWidth=1.4; ctx.strokeStyle="#5f4b3a";
  ctx.fillStyle="#f3e6d3"; ctx.fillRect(x-w/2,y-h,w,h); ctx.strokeRect(x-w/2,y-h,w,h);
  ctx.fillStyle="#b5523b"; ctx.beginPath(); ctx.moveTo(x-w*0.6,y-h); ctx.lineTo(x,y-h-w*0.45); ctx.lineTo(x+w*0.6,y-h); ctx.closePath(); ctx.fill(); ctx.stroke();
  ctx.fillStyle="#8d6e4a"; ctx.fillRect(x-w*0.1,y-h*0.55,w*0.2,h*0.55); ctx.strokeRect(x-w*0.1,y-h*0.55,w*0.2,h*0.55);
  ctx.fillStyle="#cfe6f7"; ctx.fillRect(x+w*0.2,y-h*0.75,w*0.18,w*0.16); ctx.strokeRect(x+w*0.2,y-h*0.75,w*0.18,w*0.16);
  ctx.restore();
}
/* 木（カタログの tree を小さくしたもの） */
function treeShape(ctx, x, yBase, h){
  ctx.save(); ctx.fillStyle="#8d6e4a"; ctx.strokeStyle="#6b5236"; ctx.lineWidth=1.2;
  ctx.beginPath(); ctx.rect(x-h*0.08,yBase-h*0.5,h*0.16,h*0.5); ctx.fill(); ctx.stroke();
  ctx.fillStyle="#4e9c56"; ctx.strokeStyle="#37753e";
  [[0,-h*0.78,h*0.32],[-h*0.24,-h*0.55,h*0.24],[h*0.24,-h*0.55,h*0.24]].forEach(function(q){ ctx.beginPath(); ctx.arc(x+q[0],yBase+q[1],q[2],0,7); ctx.fill(); ctx.stroke(); });
  ctx.restore();
}
/* 糸 */
function stringLine(ctx,x1,y1,x2,y2){ ctx.save(); ctx.strokeStyle="#6b5442"; ctx.lineWidth=1.6; ctx.lineCap="round"; ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(x2,y2); ctx.stroke(); ctx.restore(); }

/* 両向きの寸法矢印 */
function dimArrow(c,x1,y1,x2,y2,col){
  c.save(); c.strokeStyle=col||COL.sub; c.lineWidth=1; c.setLineDash([]);
  c.beginPath(); c.moveTo(x1,y1); c.lineTo(x2,y2); c.stroke();
  var L=Math.hypot(x2-x1,y2-y1); if(L>12){ arrow(c,(x1+x2)/2,(y1+y2)/2,x1,y1,col||COL.sub,1,6); arrow(c,(x1+x2)/2,(y1+y2)/2,x2,y2,col||COL.sub,1,6); }
  c.restore();
}
/* 文字。o: size, col, align, base, bold, it(数式の斜体), halo(白いふち) */
function T(c,s,x,y,o){
  o = o||{};
  c.save();
  c.font = (o.it? "italic ":"") + (o.bold? "700 ":"") + (o.size||13) + "px " + (o.it? MATHF : (o.serif? SERIF : FONT));
  c.textAlign = o.align||"left"; c.textBaseline = o.base||"middle";
  if(o.halo){ c.lineWidth = o.halo===true? 3.5 : o.halo; c.strokeStyle = o.haloCol||"rgba(255,255,255,.92)"; c.lineJoin="round"; c.strokeText(s,x,y); }
  c.fillStyle = o.col||COL.ink; c.fillText(s,x,y);
  var w = c.measureText(s).width; c.restore(); return w;
}
/* 記号＋添え字（例：F と "1"）を斜体で */
function SYM(c,b,sub,x,y,o){
  o = o||{}; var size=o.size||14;
  c.save(); c.textBaseline="middle"; c.font="italic "+(o.bold?"700 ":"")+size+"px "+MATHF; var wb=c.measureText(b).width;
  c.font=Math.round(size*0.7)+"px "+SERIF; var ws=sub? c.measureText(sub).width : 0;
  var X=x; if(o.align==="center") X-= (wb+ws)/2; else if(o.align==="right") X-= wb+ws;
  if(o.halo){ c.lineWidth=3.5; c.strokeStyle="rgba(255,255,255,.92)"; c.lineJoin="round";
    c.font="italic "+(o.bold?"700 ":"")+size+"px "+MATHF; c.strokeText(b,X,y);
    if(sub){ c.font=Math.round(size*0.7)+"px "+SERIF; c.strokeText(sub,X+wb+1,y+size*0.25); } }
  c.fillStyle=o.col||COL.ink;
  c.font="italic "+(o.bold?"700 ":"")+size+"px "+MATHF; c.fillText(b,X,y);
  if(sub){ c.font=Math.round(size*0.7)+"px "+SERIF; c.fillText(sub,X+wb+1,y+size*0.25); }
  c.restore(); return wb+ws+1;
}
function rrect(c,x,y,w,h,r){ c.beginPath(); if(c.roundRect) c.roundRect(x,y,w,h,r); else c.rect(x,y,w,h); }
/* 床（ハッチングは線分の内側だけ） */
function ground(c,x0,x1,y,col){
  c.save(); c.strokeStyle=col||"#2b323c"; c.lineWidth=1.6;
  c.beginPath(); c.moveTo(x0,y); c.lineTo(x1,y); c.stroke();
  c.beginPath(); c.rect(x0,y,x1-x0,12); c.clip();
  c.strokeStyle="#a9a193"; c.lineWidth=1;
  for(var X=x0+8; X<x1+9; X+=9){ c.beginPath(); c.moveTo(X,y); c.lineTo(X-7,y+8); c.stroke(); }
  c.restore();
}
/* 方眼ノートの地（うしろに敷く） */
function notebook(c,W,H,step){
  step = step||20;
  c.save(); c.globalCompositeOperation="destination-over"; c.lineWidth=1;
  for(var x=0.5; x<W; x+=step){ c.strokeStyle="#f3efe8"; c.beginPath(); c.moveTo(x,0); c.lineTo(x,H); c.stroke(); }
  for(var y=0.5; y<H; y+=step){ c.strokeStyle="#f3efe8"; c.beginPath(); c.moveTo(0,y); c.lineTo(W,y); c.stroke(); }
  c.fillStyle="#fff"; c.fillRect(0,0,W,H);
  c.restore();
}

/* ---------------- 物体の形と、表面の点（外向きの法線つき） ---------------- */
/* 形は中心 (0,0)、y は下向き。単位 m */
function shapePoly(kind, sz){
  if(kind==="circle"){ var pts=[], n=48; for(var i=0;i<n;i++){ var a=i/n*Math.PI*2; pts.push([sz.r*Math.cos(a), sz.r*Math.sin(a)]); } return pts; }
  if(kind==="trap"){ var b=sz.wb/2, t=sz.wt/2, h=sz.h/2; return [[-t,-h],[t,-h],[b,h],[-b,h]]; }
  var w=sz.w/2, hh=sz.h/2; return [[-w,-hh],[w,-hh],[w,hh],[-w,hh]];
}
/* 表面にそって間かく ds で点をとる。返り値：{x,y,nx,ny} */
function surfPoints(kind, sz, ds){
  var out=[];
  if(kind==="circle"){
    var n=Math.max(8, Math.round(2*Math.PI*sz.r/ds));
    for(var i=0;i<n;i++){ var a=(i+0.5)/n*Math.PI*2; out.push({x:sz.r*Math.cos(a), y:sz.r*Math.sin(a), nx:Math.cos(a), ny:Math.sin(a)}); }
    return out;
  }
  var P = shapePoly(kind, sz);
  for(var k=0;k<P.length;k++){
    var A=P[k], B=P[(k+1)%P.length], L=Math.hypot(B[0]-A[0],B[1]-A[1]);
    var m=Math.max(1, Math.round(L/ds)), ex=(B[0]-A[0])/L, ey=(B[1]-A[1])/L;
    var nx=ey, ny=-ex;                    // 時計回り（y 下向き）の外向き法線
    for(var j=0;j<m;j++){ var f=(j+0.5)/m; out.push({x:A[0]+(B[0]-A[0])*f, y:A[1]+(B[1]-A[1])*f, nx:nx, ny:ny}); }
  }
  return out;
}
function drawPoly(c, P, X, Y, fill, line, lw, dash){
  c.save(); c.beginPath();
  P.forEach(function(p,i){ var x=X(p[0]), y=Y(p[1]); if(i) c.lineTo(x,y); else c.moveTo(x,y); });
  c.closePath();
  if(fill){ c.fillStyle=fill; c.fill(); }
  if(line){ c.strokeStyle=line; c.lineWidth=lw||1.6; if(dash) c.setLineDash(dash); c.stroke(); }
  c.restore();
}

/* ---------------- 再生のしくみ（同時に動くのは 1 つだけ） ---------------- */
var RUNNERS = [];
function Runner(opt){
  this.opt = opt; this.state = "idle"; this.t = 0; this.rate = 1; this.raf = 0; this.last = 0;
  RUNNERS.push(this);
}
Runner.prototype.bind = function(root){
  var self = this;
  this.bPlay = root.querySelector("button.b.play");
  this.bSlow = root.querySelector("button.slowb");
  this.bRst = root.querySelector("button.rst");
  this.tinfo = root.querySelector(".tinfo");
  if(this.bPlay) this.bPlay.addEventListener("click", function(){ self.toggle(); });
  if(this.bSlow) this.bSlow.addEventListener("click", function(){ self.rate = (self.rate===1? 0.3 : 1); self.bSlow.classList.toggle("on", self.rate<1); });
  if(this.bRst) this.bRst.addEventListener("click", function(){ self.reset(); });
  this.label();
};
Runner.prototype.label = function(){
  if(!this.bPlay) return;
  var s = this.state;
  var st = (typeof this.opt.startText==="function")? this.opt.startText(this) : (this.opt.startText||"▶ スタート");
  this.bPlay.innerHTML = (s==="run"? "❚❚ 一時停止" : s==="pause"? "▶ 再開" : (s==="done" && !this.opt.again)? "▶ 最初から" : st);
  /* 第5回：ボタンの文字が変わっても横幅を変えない（まわりの並びや図が動かないように） */
  if(s==="idle" && this.bPlay.offsetWidth>0){ this.bPlay.style.minWidth=""; this.bPlay.style.minWidth=Math.ceil(this.bPlay.getBoundingClientRect().width)+"px"; }
  this.bPlay.classList.toggle("pglow", s!=="run");          /* 押せるスタートボタンは、全部光らせておく */
  if(this.tinfo && this.opt.info) this.tinfo.innerHTML = this.opt.info(this);
};
Runner.prototype.toggle = function(){
  if(this.bPlay && !this.bPlay.style.minWidth && this.state==="idle" && this.bPlay.offsetWidth>0) this.bPlay.style.minWidth=Math.ceil(this.bPlay.getBoundingClientRect().width)+"px";
  if(this.state==="run"){ this.pause(); return; }
  if(this.state==="done"){ if(this.opt.again){ this.state="idle"; this.t=0; } else this.reset(true); }
  if(this.state==="idle" && this.opt.begin) this.opt.begin(this);
  var self=this;
  RUNNERS.forEach(function(r){ if(r!==self && r.state==="run") r.pause(); });
  this.state = "run"; this.last = 0; this.label();
  var loop = function(ts){
    if(self.state!=="run") return;
    var dt = self.last? Math.min(0.05,(ts-self.last)/1000) : 0; self.last = ts;
    self.t += dt*self.rate;
    var fin = self.opt.step(dt*self.rate, self);
    self.opt.draw();
    if(self.tinfo && self.opt.info) self.tinfo.innerHTML = self.opt.info(self);
    if(fin){ self.state = "done"; self.label(); return; }
    self.raf = requestAnimationFrame(loop);
  };
  this.raf = requestAnimationFrame(loop);
};
Runner.prototype.pause = function(){ cancelAnimationFrame(this.raf); this.state="pause"; this.label(); };
Runner.prototype.reset = function(keep){
  cancelAnimationFrame(this.raf); this.state="idle"; this.t=0;
  if(this.opt.reset) this.opt.reset(this);
  this.opt.draw(); this.label();
};
/* 値を変えたら「▶ スタート」にもどす */
Runner.prototype.touch = function(){ if(this.state==="done" || this.state==="pause"){ cancelAnimationFrame(this.raf); this.state="idle"; this.t=0; }
  this.label(); };                                            /* ドラッグ中も、高さ・深さの表示をその場で変える */

/* ---------------- 操作の HTML ---------------- */
function H_reset(){ return '<button class="b resetall" type="button">全て最初の<br>設定に戻す</button>'; }
function H_play(first, mid, tail){
  return '<div class="playbar"><div class="row1"><div class="btns"><button class="b play" type="button"'+(first? ' id="bPlay"':'')+'>▶ スタート</button>'+
         '<button class="b slowb" type="button">🐢 スロー</button><button class="b gapL rst" type="button">↺ リセット</button></div></div>'+
         '<div class="trow">'+(mid||'')+'<span class="tinfo"></span></div>'+(tail||'')+'</div>';
}
/* 再生バーの中のスライダー（↺ リセットと数値の表示のあいだ） */
function H_tslider(k,label,min,max,step,val){
  return '<div class="tbox tsl" data-k="'+k+'"><span class="vl">'+TX(label)+'</span><input type="range" min="'+min+'" max="'+max+'" step="'+step+'" value="'+val+'" aria-label="'+label.replace(/\$[^$]*\$/g,"").trim()+'"></div>';
}
function wireTSlider(root,k,onchg){
  var inp=root.querySelector('.tsl[data-k="'+k+'"] input');
  var upd=function(){ var mn=parseFloat(inp.min), mx=parseFloat(inp.max); inp.style.setProperty("--p", ((inp.value-mn)/(mx-mn)*100).toFixed(1)+"%"); };
  inp.addEventListener("input", function(){ upd(); onchg(parseFloat(inp.value)); });
  upd();
  return { set:function(v){ inp.value=v; upd(); }, get:function(){ return parseFloat(inp.value); }, el:inp };
}
function H_slider(k,label,min,max,step,val){
  return '<div class="varbox"><div class="vrow cell" data-k="'+k+'"><div class="vhead"><span class="vl">'+TX(label)+'</span><span class="vsp"></span><span class="vv"></span></div>'+
    '<div class="vbar"><button class="tiny nudge" type="button" data-d="-1" title="1 目盛り小さく">−</button>'+
    '<input type="range" min="'+min+'" max="'+max+'" step="'+step+'" value="'+val+'" aria-label="'+label.replace(/\$[^$]*\$/g,"").replace(/<[^>]*>/g,"").replace(/&nbsp;/g," ").trim()+'">'+
    '<button class="tiny nudge" type="button" data-d="1" title="1 目盛り大きく">＋</button></div></div></div>';
}
function H_seg(group,label,items,on){
  return '<span class="segl">'+label+'</span>'+items.map(function(it){ return '<button class="b seg'+(it[0]===on?' on':'')+'" type="button" data-g="'+group+'" data-v="'+it[0]+'" aria-pressed="'+(it[0]===on)+'">'+it[1]+'</button>'; }).join("");
}
function H_chk(k,label,on){ return '<button class="b chkb'+(on?' on':'')+'" type="button" data-chk="'+k+'" aria-pressed="'+(!!on)+'">'+label+'</button>'; }
/* スライダーと ± ボタンをつなぐ */
function wireSlider(root,k,fmt,onchg){
  var row = root.querySelector('.vrow[data-k="'+k+'"]'), inp=row.querySelector("input"), vv=row.querySelector(".vv");
  var upd=function(){ vv.innerHTML = fmt(parseFloat(inp.value)); var mn=parseFloat(inp.min), mx=parseFloat(inp.max); inp.style.setProperty("--p", ((inp.value-mn)/(mx-mn)*100).toFixed(1)+"%"); };
  inp.addEventListener("input", function(){ upd(); onchg(parseFloat(inp.value)); });
  row.querySelectorAll(".nudge").forEach(function(b){ b.addEventListener("click", function(){
    var st=parseFloat(inp.step), v=clamp(parseFloat(inp.value)+st*parseFloat(b.dataset.d), parseFloat(inp.min), parseFloat(inp.max));
    inp.value = v; upd(); onchg(v); }); });
  upd();
  return { set:function(v){ inp.value=v; upd(); }, get:function(){ return parseFloat(inp.value); } };
}
function wireSeg(root,group,fn){
  var bs = root.querySelectorAll('button.seg[data-g="'+group+'"]');
  bs.forEach(function(b){ b.addEventListener("click", function(){ bs.forEach(function(x){ x.classList.toggle("on", x===b); x.setAttribute("aria-pressed", x===b); }); fn(b.dataset.v); }); });
  return { set:function(v){ bs.forEach(function(x){ x.classList.toggle("on", x.dataset.v===v); x.setAttribute("aria-pressed", x.dataset.v===v); }); } };
}
function wireChk(root,k,fn){
  var b = root.querySelector('button[data-chk="'+k+'"]');
  b.addEventListener("click", function(){ var on=!b.classList.contains("on"); b.classList.toggle("on",on); b.setAttribute("aria-pressed",on); fn(on); });
  return { set:function(on){ b.classList.toggle("on",on); b.setAttribute("aria-pressed",on); } };
}
/* 縦方向のドラッグ（当たり判定は hit(x,y) が true のときだけ） */
function bindDrag(cv, hit, move, end, can){
  var on=false;
  var pos=function(ev){ var r=cv.getBoundingClientRect(); return {x:ev.clientX-r.left, y:ev.clientY-r.top}; };
  cv.addEventListener("pointerdown", function(ev){ if(can && !can()) return; var p=pos(ev); if(!hit(p.x,p.y)) return;
    on=true; cv.setPointerCapture(ev.pointerId); cv.classList.add("dragging"); ev.preventDefault(); move(p.x,p.y,true); });
  cv.addEventListener("pointermove", function(ev){ var p=pos(ev);
    if(on){ move(p.x,p.y,false); ev.preventDefault(); }
    else cv.classList.toggle("dragok", (!can || can()) && hit(p.x,p.y)); });
  var up=function(ev){ if(!on) return; on=false; cv.classList.remove("dragging"); if(end) end(); };
  cv.addEventListener("pointerup", up); cv.addEventListener("pointercancel", up);
}
function onResize(el, fn){
  if("ResizeObserver" in window){ var w=0; new ResizeObserver(function(es){ var nw=Math.round(es[0].contentRect.width); if(nw!==w){ w=nw; fn(); } }).observe(el); }
  else window.addEventListener("resize", fn);
}
/* 第10回：スライダーの下の名前の目盛りを、つまみの止まる位置にぴったり合わせる（つまみの直径 18 px） */
function alignTicks(tk){
  var row=tk.previousElementSibling, inp=row && row.querySelector('input[type=range]'); if(!inp) return;
  var tr=tk.getBoundingClientRect(), ir=inp.getBoundingClientRect(); if(!ir.width || !tr.width) return;
  var th=9, sp=tk.querySelectorAll('span'), n=sp.length;
  for(var i=0;i<n;i++){ sp[i].style.left=(ir.left-tr.left+th+(n>1? i/(n-1) : 0.5)*(ir.width-2*th)).toFixed(1)+"px"; }
}
function watchTicks(root){
  (root||document).querySelectorAll('.cticks').forEach(function(tk){
    alignTicks(tk);
    if(window.ResizeObserver && !tk._ro){ tk._ro=new ResizeObserver(function(){ alignTicks(tk); }); tk._ro.observe(tk); }
    /* 第7回：名前が書きかわったとき（物質の種類を変えたときなど）も合わせ直す */
    if(window.MutationObserver && !tk._mo){ tk._mo=new MutationObserver(function(){ alignTicks(tk); }); tk._mo.observe(tk,{childList:true}); }
  });
}
