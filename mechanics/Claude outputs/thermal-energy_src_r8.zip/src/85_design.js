/* =========================================================================
   デザインの動き（キット 5 章）＋ ヒーローのアニメ（このページ専用）
   ヒーロー：高温の物体 A と低温の物体 B を触れさせ、熱が移って熱平衡になるまで。
   ========================================================================= */
(function(){
  var RM = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var C = { acc:"#4fa8ff", acc2:"#9fd0ff", deep:"#2f7fd6", T:"#f4f7fb", dim:"rgba(222,232,245,.6)", press:"#f2c14e", F:"#5fd38a", Wt:"#ff6b5b",
            water:"rgba(79,168,255,.17)", wall:"rgba(222,232,245,.38)" };
  var JP = '"Hiragino Sans","Hiragino Kaku Gothic ProN","Yu Gothic",YuGothic,"Noto Sans JP",Meiryo,sans-serif';

  function initStage(){
    var cv=document.getElementById("heroCv"); if(!cv) return;
    var ctx=cv.getContext("2d");
    var W=0,H=0,dpr=1,run=false,raf=0,last=0,paused=false,rate=1;
    var TA=0, TB=0, t=0, hold=0, phase=0, clk=0;   // phase 0：熱が移動中、1：熱平衡で止まって見せる
    var TA0=80, TB0=10, flowPh=0;
    var hist=[], ht=0;            /* 第6回：右の T-t グラフ用の記録 [時刻, TA, TB] */
    function resetPhys(){ TA=TA0; TB=TB0; t=0; ht=0; hist=[[0,TA0,TB0]]; }
    resetPhys();
    function setup(){ var r=cv.getBoundingClientRect(); dpr=Math.min(2,window.devicePixelRatio||1);
      W=Math.max(280,r.width); H=Math.max(160,r.height); cv.width=Math.round(W*dpr); cv.height=Math.round(H*dpr); ctx.setTransform(dpr,0,0,dpr,0,0); }
    function stepPhys(dt){ var k=0.30; var P=k*(TA-TB); TA-=P*dt; TB+=P*dt; clk+=dt; ht+=dt;
      if(ht-hist[hist.length-1][0]>=0.05) hist.push([ht,TA,TB]); }
    var TMAX=12;
    /* 第6回：ヒーローの右に、2 つの物体の温度と時間のグラフ */
    function drawGraph(gx0,gy0,gx1,gy1){
      var X=function(tt){ return gx0+(gx1-gx0-12)*Math.min(tt,TMAX)/TMAX; }, Y=function(T){ return gy0-(gy0-gy1-12)*T/90; };
      ctx.save(); ctx.strokeStyle="rgba(222,232,245,.10)"; ctx.lineWidth=1;
      ctx.font="500 11px "+JP; ctx.fillStyle=C.dim; ctx.textAlign="right"; ctx.textBaseline="middle";
      for(var v=20; v<=80; v+=20){ ctx.beginPath(); ctx.moveTo(gx0,Y(v)); ctx.lineTo(gx1-12,Y(v)); ctx.stroke(); ctx.fillText(String(v),gx0-6,Y(v)); }
      ctx.fillText("0",gx0-6,gy0);
      /* 軸と矢印 */
      ctx.strokeStyle=C.wall; ctx.fillStyle=C.wall; ctx.lineWidth=1.4;
      ctx.beginPath(); ctx.moveTo(gx0,gy0); ctx.lineTo(gx1,gy0); ctx.moveTo(gx0,gy0); ctx.lineTo(gx0,gy1); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(gx1,gy0); ctx.lineTo(gx1-8,gy0-4); ctx.lineTo(gx1-8,gy0+4); ctx.closePath(); ctx.fill();
      ctx.beginPath(); ctx.moveTo(gx0,gy1); ctx.lineTo(gx0-4,gy1+8); ctx.lineTo(gx0+4,gy1+8); ctx.closePath(); ctx.fill();
      ctx.fillStyle=C.dim; ctx.textAlign="left"; ctx.fillText("温度〔℃〕", gx0+6, gy1+2); ctx.textAlign="right"; ctx.fillText("時間", gx1, gy0+14);
      /* 熱平衡の温度 */
      var Tf=(TA0+TB0)/2; ctx.setLineDash([4,4]); ctx.strokeStyle="rgba(159,208,255,.5)"; ctx.beginPath(); ctx.moveTo(gx0,Y(Tf)); ctx.lineTo(gx1-12,Y(Tf)); ctx.stroke(); ctx.setLineDash([]);
      [[1,"#ff7a66","A"],[2,C.acc,"B"]].forEach(function(o){
        ctx.strokeStyle=o[1]; ctx.lineWidth=2.6; ctx.lineJoin="round"; ctx.beginPath();
        hist.forEach(function(h,i){ var x=X(h[0]), y=Y(h[o[0]]); if(i) ctx.lineTo(x,y); else ctx.moveTo(x,y); }); ctx.stroke();
        var L=hist[hist.length-1]; ctx.fillStyle=o[1]; ctx.beginPath(); ctx.arc(X(L[0]),Y(L[o[0]]),4,0,7); ctx.fill();
        ctx.font="700 12px "+JP; ctx.textAlign="left"; ctx.fillText(o[2], gx0+6, Y(hist[0][o[0]])+(o[0]===1? -10 : 12)); });
      ctx.restore();
    }
    function hc(lv){ lv=Math.max(0,Math.min(1,lv)); return "rgb("+Math.round(90+165*lv)+","+Math.round(160-70*lv)+","+Math.round(255-180*lv)+")"; }
    function draw(fade){
      ctx.clearRect(0,0,W,H); ctx.save(); ctx.globalAlpha=fade;
      var gw=(W>=560), bw=Math.min(190, W*(gw? 0.21 : 0.30)), bh=Math.min(H-64, bw*0.82), y0=(H-bh)/2+8, xm=gw? W*0.33 : W/2, ax=xm-bw, bx=xm;
      if(gw) drawGraph(W*0.62+30, H-30, W-16, 22);
      [[ax,TA,"A（高温）"],[bx,TB,"B（低温）"]].forEach(function(o,k){
        var x=o[0], Tn=o[1], lv=(Tn-TB0)/(TA0-TB0);
        ctx.fillStyle="rgba(159,208,255,.07)"; ctx.fillRect(x,y0,bw,bh);
        ctx.strokeStyle="rgba(222,232,245,.55)"; ctx.lineWidth=1.5; ctx.strokeRect(x,y0,bw,bh);
        var nx=4, ny=3, dx=bw/nx, dy=bh/ny, amp=1+8*lv, r=Math.min(10,dx*0.22);
        for(var j=0;j<ny;j++) for(var i=0;i<nx;i++){ var p=PH[k*20+j*nx+i], ex=x+dx*(i+0.5), ey=y0+dy*(j+0.5);
          var ox=amp*Math.sin(clk*(7.5+5*lv)*p[2]+p[0]), oy=amp*Math.sin(clk*(7+5*lv)*p[2]+p[1]);
          ctx.fillStyle=hc(lv); ctx.beginPath(); ctx.arc(ex+ox,ey+oy,r,0,7); ctx.fill();
          ctx.strokeStyle="rgba(222,232,245,.35)"; ctx.lineWidth=1; ctx.beginPath(); ctx.moveTo(ex-4,ey); ctx.lineTo(ex+4,ey); ctx.moveTo(ex,ey-4); ctx.lineTo(ex,ey+4); ctx.stroke(); }
        ctx.font="700 13px "+JP; ctx.fillStyle=C.T; ctx.textAlign="center"; ctx.textBaseline="middle"; ctx.fillText(o[2], x+bw/2, y0-14);
        ctx.font="700 14px "+JP; ctx.fillStyle=C.acc2; ctx.fillText(Tn.toFixed(1)+" ℃", x+bw/2, y0+bh+16);
      });
      var dT=TA-TB;
      if(dT>0.4){ var lw=4+14*dT/(TA0-TB0), cy=y0+bh/2, rr=dT/(TA0-TB0), sc=0.45+0.55*rr, HL=74*sc, x1=xm-HL, x2=xm+HL, hl=(lw*0.9+9)*(0.6+0.4*sc), hw=(lw*0.95+7)*(0.6+0.4*sc);   /* 熱の移る速さで、太さ・長さ・矢じりの大きさが変わる */
        /* 第3回（試作）：矢印は動かさず、矢印の中の色の濃淡（明るい帯）が A から B へ流れる。
           帯が流れる速さ＝熱の移る速さ。粒のような「もの」は描かない（熱は物質ではないため） */
        flowPh=(flowPh+0.016*(0.15+0.9*dT/(TA0-TB0)))%1;
        var gr=ctx.createLinearGradient(x1,0,x2,0), stops=[], NB=2, bw2=0.22;
        for(var j=0;j<NB;j++){ var cpos=((j/NB)+flowPh)%1; stops.push([cpos-bw2,0],[cpos,1],[cpos+bw2,0]); }
        var sample=function(u){ var v=0; for(var j2=0;j2<NB;j2++){ var cpos2=((j2/NB)+flowPh)%1; [cpos2-1,cpos2,cpos2+1].forEach(function(cc){ var d=Math.abs(u-cc); if(d<bw2) v=Math.max(v,1-d/bw2); }); } return v; };
        for(var k2=0;k2<=40;k2++){ var u2=k2/40, v2=sample(u2); var r=Math.round(200+(255-200)*v2), g2=Math.round(86+(232-86)*v2), b2=Math.round(15+(184-15)*v2);   /* 濃いだいだい → 明るいクリーム色 */ gr.addColorStop(u2,"rgb("+r+","+g2+","+b2+")"); }
        ctx.globalAlpha=fade; ctx.fillStyle=gr;
        ctx.beginPath(); ctx.moveTo(x1,cy-lw/2); ctx.lineTo(x2-hl,cy-lw/2); ctx.lineTo(x2-hl,cy-hw); ctx.lineTo(x2,cy); ctx.lineTo(x2-hl,cy+hw); ctx.lineTo(x2-hl,cy+lw/2); ctx.lineTo(x1,cy+lw/2); ctx.closePath(); ctx.fill();
        ctx.strokeStyle="rgba(255,200,140,.55)"; ctx.lineWidth=1; ctx.stroke();
        ctx.globalAlpha=fade; ctx.font="700 14px "+JP; ctx.fillStyle="#ffc58a"; ctx.textAlign="center"; ctx.fillText("熱 Q", xm, cy-lw/2-20); }
      else { ctx.font="700 14px "+JP; ctx.fillStyle=C.acc2; ctx.textAlign="center"; ctx.fillText("熱平衡（熱の移動が止まった）", xm, y0+bh/2-0); }
      ctx.restore();
    }
    var HOLD=2.4, FADE=0.45;
    function frame(ts){
      if(!run) return;
      var dt=last? Math.min(0.05,(ts-last)/1000) : 0; last=ts; dt*=rate;
      t+=dt; var fade=1;
      if(phase===0){ stepPhys(dt); if(TA-TB<0.4 || t>12){ phase=1; hold=0; } }
      else { clk+=dt; hold+=dt; if(hold>HOLD-FADE) fade=Math.max(0,(HOLD-hold)/FADE); if(hold>=HOLD){ phase=0; resetPhys(); } }
      if(phase===0 && t<0.3) fade=t/0.3;
      draw(fade);
      raf=requestAnimationFrame(frame);
    }
    function start(){ if(run||RM||paused) return; run=true; last=0; raf=requestAnimationFrame(frame); }
    function stop(){ run=false; cancelAnimationFrame(raf); }
    function still(){ TA=55; TB=35; draw(1); }
    setup(); if(RM) still(); else draw(0);
    window.__hero={ frame:function(tt){ stop(); resetPhys(); var k=Math.round(tt/0.01); for(var i=0;i<k;i++) stepPhys(0.01); draw(1); }, start:start, stop:stop };
    var rz=0; window.addEventListener("resize", function(){ clearTimeout(rz); rz=setTimeout(function(){ setup(); if(RM||paused) draw(1); }, 120); });
    if("IntersectionObserver" in window){ new IntersectionObserver(function(es){ es.forEach(function(en){ (en.isIntersecting && !document.hidden)? start() : stop(); }); },{threshold:0.05}).observe(cv); }
    else start();
    document.addEventListener("visibilitychange", function(){ if(document.hidden) stop(); else { var r=cv.getBoundingClientRect(); if(r.bottom>0 && r.top<innerHeight) start(); } });
    var ctl=document.querySelector("#hero .stagectl");
    if(ctl){ var pp=ctl.querySelector(".pp"), sl=ctl.querySelector(".slow");
      if(sl){ if(RM) sl.hidden=true; sl.addEventListener("click", function(){ rate=(rate===1?0.3:1); sl.setAttribute("aria-pressed", rate<1?"true":"false"); }); }
      if(pp){ if(RM) pp.hidden=true; pp.addEventListener("click", function(){ paused=!paused; pp.classList.toggle("paused",paused); pp.setAttribute("aria-label", paused?"再生":"一時停止"); if(paused){ stop(); draw(1); } else start(); }); }
    }
    document.addEventListener("click", function(ev){ if(ev.target.closest && ev.target.closest("button.b.play")) stop(); }, true);
  }

  function syncRange(el){ var mn=parseFloat(el.min)||0, mx=parseFloat(el.max), v=parseFloat(el.value);
    var p=(isFinite(mx)&&mx>mn)? (v-mn)/(mx-mn)*100 : 0, s=p.toFixed(1)+"%"; if(el._p!==s){ el._p=s; el.style.setProperty("--p",s); } }
  function initRanges(){
    document.addEventListener("input", function(ev){ if(ev.target && ev.target.type==="range") syncRange(ev.target); }, true);
    setInterval(function(){ if(document.hidden) return; document.querySelectorAll(".mode.on input[type=range]").forEach(syncRange); }, 150);
  }
  function initProgress(){
    var nav=document.getElementById("tabs"); if(!nav) return; var pend=false;
    var upd=function(){ pend=false; var h=document.documentElement, max=h.scrollHeight-innerHeight; nav.style.setProperty("--prog", max>0? Math.min(1,Math.max(0,scrollY/max)).toFixed(4) : 0); };
    window.addEventListener("scroll", function(){ if(!pend){ pend=true; requestAnimationFrame(upd); } }, {passive:true});
    window.addEventListener("resize", upd); upd();
  }
  function initIdeas(){
    document.querySelectorAll("#hero .ideas a").forEach(function(a){
      a.addEventListener("click", function(ev){ ev.preventDefault(); var id=a.getAttribute("href").slice(1);
        var mm=id.match(/^(\d)-(\d)$/), sid=null;
        Object.keys(DEFS).forEach(function(k){ if(mm && DEFS[k].mode===parseInt(mm[1],10)-1 && DEFS[k].num===parseInt(mm[2],10)) sid=k; });
        if(sid) gotoSec(sid); });
    });
  }
  function initDecorate(){
    var orig=activateMode;
    var showTab=function(){ var row=document.querySelector("#tabs .tabs-in"), on=row&&row.querySelector(".tab.on"); if(!on||row.scrollWidth<=row.clientWidth) return;
      var l=on.offsetLeft-24, r=on.offsetLeft+on.offsetWidth+24; if(l<row.scrollLeft) row.scrollLeft=l; else if(r>row.scrollLeft+row.clientWidth) row.scrollLeft=r-row.clientWidth; };
    var cur=function(){ document.querySelectorAll("#tabs .tab").forEach(function(b){ if(b.classList.contains("on")) b.setAttribute("aria-current","page"); else b.removeAttribute("aria-current"); }); };
    activateMode=function(id){ var r=orig.apply(this,arguments); showTab(); cur(); return r; };
    showTab(); cur();
  }
  function initStuck(){
    var hero=document.getElementById("hero"), nav=document.getElementById("tabs"); if(!hero||!nav||!("IntersectionObserver" in window)) return;
    new IntersectionObserver(function(es){ es.forEach(function(en){ nav.classList.toggle("stuck", !en.isIntersecting); }); },{threshold:0}).observe(hero);
  }
  function initFooter(){
    var f=document.querySelector("#wrap footer"); if(!f) return;
    document.body.appendChild(f);
    var items=MODES.map(function(m,i){ return '<li><a href="#'+m.id+'" data-mode="'+m.id+'"><b>'+CIRC[i]+'</b>'+m.name+'</a></li>'; }).join("");
    f.innerHTML='<div class="ft-in"><p class="ft-mark">Heat and Energy<span>熱とエネルギー 〜熱運動・比熱・熱力学第一法則〜</span></p><ul class="ft-nav">'+items+'</ul>'+
      '<div class="ft-base"><span><a class="ft-home" href="'+SITE_HOME+'">⌂ 楽楽（らくらく）高校物理 トップページ</a>　／　高校物理 ・ 力学</span><span class="ft-r"><button type="button" class="ft-pages">ほかのページ一覧</button><a href="#top" class="ft-top">▲ ページの一番上へ</a></span></div></div>';
    f.querySelectorAll("a[data-mode]").forEach(function(a){ a.addEventListener("click", function(ev){ ev.preventDefault(); var id=a.dataset.mode;
      activateMode(id); history.replaceState(null,"","#"+id); window.scrollTo({top:contentTop(), behavior:"auto"}); }); });
    var fp=f.querySelector(".ft-pages"); if(fp) fp.addEventListener("click", function(){ if(window.SITENAV) window.SITENAV.open(); });
    var tp=f.querySelector(".ft-top"); if(tp) tp.addEventListener("click", function(ev){ ev.preventDefault(); window.scrollTo({top:0, behavior:"auto"}); });
  }
  document.addEventListener("DOMContentLoaded", function(){ initFooter(); initDecorate(); initStage(); initRanges(); initProgress(); initIdeas(); initStuck(); });
})();
