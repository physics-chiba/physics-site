/* =========================================================================
   モード② 熱と仕事（2-1・2-2）
   ========================================================================= */

/* ---------------- ②-1 熱力学第一法則 ----------------
   ピストンのついたシリンダーに気体。4 つの操作（熱を与える・熱を奪う・正の仕事をする・負の仕事をする）を選んでスタート。
   内部エネルギー U＝分子の運動エネルギーの和。Q と W は、分子がかべ・ピストンにぶつかったときの
   運動エネルギーの変化をそのまま足し合わせているので、いつでも ΔU＝Q＋W が成り立つ。 */
var S21 = {
  N:42, R:4.2, DUR:3.0,
  ACTS:{heat:{t:"気体に熱を与える（ピストン固定）", s:"熱 Q > 0　→　U が増える"}, cool:{t:"気体の熱を奪う（ピストン固定）", s:"熱 Q < 0　→　U が減る"},
        push:{t:"気体に正の仕事をする（ピストンを押す）", s:"仕事 W > 0　→　U が増える"}, pull:{t:"気体に負の仕事をする（ピストンを引く）", s:"仕事 W < 0　→　U が減る"},
        free:{t:"気体に熱を与える（ピストンは自由）", s:"熱 Q > 0。気体は膨らんで、外に仕事をする（W < 0、W′ > 0）"},
        freecool:{t:"気体の熱を奪う（ピストンは自由）", s:"熱 Q < 0。気体は縮んで、外から仕事をされる（W > 0、W′ < 0）"}},
  START:{heat:"熱を与える",cool:"熱を奪う",push:"ピストンを押す",pull:"ピストンを引く",free:"熱を与える",freecool:"熱を奪う"},
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.act="heat"; this.clk=0; this.mols=null; this.Q=0; this.W=0; this.U0=1; this.fr=0.62; this.u=0; this.at=0;
    /* 第6回：上下 2 つの図。上＝気体がされた仕事 W（ΔU＝Q＋W）、下＝同じ変化を気体がした仕事 W′（Q＝ΔU＋W′）で。
       2 つは同じ状態（同じ分子・同じピストン）を描くので、操作の選択で必ず連動する */
    var w1=this.cv.parentElement, cap1=document.createElement("p"); cap1.className="cvcap";
    cap1.innerHTML='<b>上の図</b>：気体が<b>された</b>仕事 '+tex("W")+' で表す　'+tex("\\Delta U=Q+W");
    w1.parentNode.insertBefore(cap1, w1);
    var cap2=document.createElement("p"); cap2.className="cvcap";
    cap2.innerHTML='<b>下の図</b>：同じ変化を、気体が<b>した</b>仕事 '+tex("W'")+'（'+tex("W'=-W")+'）で表す　'+tex("Q=\\Delta U+W'");
    var w2=document.createElement("div"); w2.className="cvwrap"; w2.innerHTML='<canvas class="sub21cv"></canvas>';
    w1.parentNode.insertBefore(cap2, w1.nextSibling); w1.parentNode.insertBefore(w2, cap2.nextSibling);
    this.cv2=w2.querySelector("canvas");
    /* 第6回：説明（数値）の箱は右の列へ */
    var sR=sec.querySelector(".sR"); if(sR) sR.insertBefore(this.msg, sR.firstChild);
    this.run=new Runner({
      startText:function(){ return "▶ スタート（"+self.START[self.act]+"）"; },
      begin:function(){ self.at=0; },
      step:function(dt){ self.clk+=dt; self.at+=dt; self.step(dt); if(self.at>=self.DUR){ self.u=0; return true; } return false; },
      draw:function(){ self.draw(); },
      reset:function(){ self.mols=null; self.Q=0; self.W=0; self.fr=0.62; self.u=0; self.at=0; },
      info:function(){ return '内部エネルギー '+tex("U")+' = <b>'+(self.Unow()).toFixed(0)+'</b>（初め 100）'; }
    });
    this.run.bind(sec);
    /* 操作を選ぶと、初めの状態に戻してそのままスタートする */
    this.sa=wireSeg(sec,"act",function(v){ self.act=v; self.run.reset(); self.run.toggle(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.act="heat"; self.sa.set("heat"); self.run.rate=1;
      var sb=sec.querySelector(".slowb"); if(sb) sb.classList.remove("on"); self.run.reset(); });
    var anim=function(){ if(self.sec.offsetParent!==null && self.run.state!=="run" && self.mols){ self.clk+=0.016; self.step(0.016, true); self.draw(); } requestAnimationFrame(anim); };
    onResize(this.cv.parentElement, function(){ self.mols=null; self.Q=0; self.W=0; self.draw(); });
    this.draw(); requestAnimationFrame(anim);
  },
  KE:function(){ var s=0; this.mols.forEach(function(m){ s+=0.5*(m.vx*m.vx+m.vy*m.vy); }); return s; },
  Unow:function(){ return this.mols? 100*this.KE()/this.U0 : 100; },
  hOf:function(W){ return clamp(W*0.36, 240, 280); },
  geo:function(W,H){ var gx0=40, gx1=Math.round(W*0.64), cy0=40, cy1=40+Math.min(120, H*0.42);
    return {x0:gx0, x1:gx1, y0:cy0, y1:cy1, xp:gx0+(gx1-gx0)*this.fr}; },
  make:function(g){
    var a=[], n=this.N;
    for(var i=0;i<n;i++){ var th=Math.random()*6.283, sp=95*(0.6+Math.random()*0.8);
      a.push({x:g.x0+8+Math.random()*(g.xp-g.x0-16), y:g.y0+8+Math.random()*(g.y1-g.y0-16), vx:sp*Math.cos(th), vy:sp*Math.sin(th)}); }
    this.mols=a; this.U0=this.KE();
  },
  /* idle … 操作をしていないとき（分子は動くが、Q・W は 0 のまま） */
  step:function(dt, idle){
    var g=this.g; if(!g || !this.mols) return;
    var act=idle? null : this.act, r=this.R, self=this;
    /* ピストンの速さ：押す・引く・自由に動く（熱を与えてふくらむ）のあいだだけ動かす */
    var L=g.x1-g.x0, u=0;
    if(act==="push") u=-(L*0.20)/this.DUR; if(act==="pull") u=(L*0.20)/this.DUR; if(act==="free") u=(L*0.14)/this.DUR; if(act==="freecool") u=-(L*0.10)/this.DUR;
    var frNew=clamp(this.fr+u*dt/L, 0.32, 0.92); u=(frNew-this.fr)*L/Math.max(dt,1e-6); this.fr=frNew; this.u=u;
    var xp=g.x0+L*this.fr; g.xp=xp;
    var heat=(act==="heat"||act==="free"), n=Math.max(1,Math.ceil(dt/0.006)), h=dt/n;
    for(var s=0;s<n;s++){
      this.mols.forEach(function(m){
        m.x+=m.vx*h; m.y+=m.vy*h;
        if(m.x<g.x0+r){ m.x=2*(g.x0+r)-m.x; m.vx=-m.vx; }
        if(m.x>xp-r && m.vx>u){ var e0=0.5*(m.vx*m.vx+m.vy*m.vy); m.vx=2*u-m.vx; m.x=xp-r-0.01;
          var e1=0.5*(m.vx*m.vx+m.vy*m.vy); if(!idle) self.W+=(e1-e0)/self.U0*100; }
        if(m.x>xp-r) m.x=xp-r-0.01;
        if(m.y<g.y0+r){ m.y=2*(g.y0+r)-m.y; m.vy=-m.vy; }
        if(m.y>g.y1-r){ m.y=2*(g.y1-r)-m.y; m.vy=-m.vy;
          if(heat || act==="cool" || act==="freecool"){ var e2=0.5*(m.vx*m.vx+m.vy*m.vy), k=heat? (act==="free"? 1.16 : 1.12) : (act==="freecool"? 0.87 : 0.90);
            m.vx*=k; m.vy*=k; self.Q+=(0.5*(m.vx*m.vx+m.vy*m.vy)-e2)/self.U0*100; } }
      });
    }
  },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return self.hOf(W); });
    var g=this.geo(f.W,f.H); this.g=g;
    if(!this.mols || this._W!==f.W){ this._W=f.W; this.make(g); }
    this.drawOne(f, false);
    if(this.cv2){ var f2=fitCanvas(this.cv2, function(W){ return self.hOf(W); }); this.drawOne(f2, true); }
    var A=this.ACTS[this.act], U=this.Unow();
    this.msg.innerHTML='<b>'+A.t+'</b>：'+A.s+'<br>'+tex("Q")+' = <span class="num">'+this.Q.toFixed(0)+'</span>　'+tex("W")+' = <span class="num">'+this.W.toFixed(0)+'</span>　'+
      tex("W'")+' = <span class="num">'+(-this.W).toFixed(0)+'</span>　'+tex("\\Delta U")+' = <span class="num">'+(U-100).toFixed(0)+'</span><br>（エネルギーの大きさは、初めの '+tex("U")+' を 100 とした目安）';
  },
  /* 1 枚の図。dash … false：上の図（W）、true：下の図（W′）。気体・ピストン・バーナーなどは上下で同じに描く */
  drawOne:function(f, dash){
    var self=this, c=f.c, W=f.W, H=f.H, g=this.geo(W,H); g.xp=g.x0+(g.x1-g.x0)*this.fr;
    c.clearRect(0,0,W,H);
    var U=this.Unow(), lv=clamp((U-40)/120,0,1), running=(this.run.state==="run"), act=this.act;
    var ry=(g.y1-g.y0)/2, ex=ry*0.22, cyM=(g.y0+g.y1)/2, xEnd=g.x1+16;
    var col=(lv<0.5)? 'rgba('+Math.round(150+210*lv)+','+Math.round(225-40*lv)+','+Math.round(235-60*lv)+',.85)' : 'rgba(255,'+Math.round(205-170*(lv-0.5))+','+Math.round(205-170*(lv-0.5))+',.85)';
    var gr=c.createLinearGradient(0,g.y0,0,g.y1); gr.addColorStop(0,col); gr.addColorStop(0.45,"rgba(255,255,255,.85)"); gr.addColorStop(1,col);
    c.save(); c.fillStyle=gr; c.beginPath(); c.moveTo(g.x0,g.y0); c.lineTo(g.xp,g.y0); c.lineTo(g.xp,g.y1); c.lineTo(g.x0,g.y1); c.ellipse(g.x0,cyM,ex,ry,0,Math.PI/2,Math.PI*1.5); c.closePath(); c.fill(); c.restore();
    c.save(); this.mols.forEach(function(m){ ball(c,m.x,m.y,self.R,0,heatCol(lv)); }); c.restore();
    c.save(); c.strokeStyle="#6f7b86"; c.lineWidth=1.6;
    c.beginPath(); c.moveTo(g.x0,g.y0); c.lineTo(xEnd,g.y0); c.moveTo(g.x0,g.y1); c.lineTo(xEnd,g.y1); c.stroke();
    c.beginPath(); c.ellipse(g.x0,cyM,ex,ry,0,Math.PI/2,Math.PI*1.5); c.stroke();
    c.setLineDash([4,3]); c.beginPath(); c.ellipse(g.x0,cyM,ex,ry,0,-Math.PI/2,Math.PI/2); c.stroke(); c.setLineDash([]);
    c.beginPath(); c.ellipse(xEnd,cyM,ex,ry,0,0,7); c.stroke(); c.restore();
    /* ピストンと棒。手は押す・引く・止めておくとき（自由に動くときは手を放す） */
    c.save(); var pg=c.createLinearGradient(g.xp,0,g.xp+14,0); pg.addColorStop(0,"#9aa1ab"); pg.addColorStop(1,"#d7dbe0");
    c.fillStyle=pg; c.strokeStyle="#5b636e"; c.lineWidth=1.2; c.beginPath(); c.ellipse(g.xp+7,cyM,ex,ry,0,0,7); c.fill(); c.stroke();
    var rodL=W*0.80-(g.x0+(g.x1-g.x0)*0.62), rodE=g.xp+rodL;
    c.fillStyle="#d8d2c4"; c.strokeStyle="#8b8172"; rrect(c,g.xp+10,cyM-5,rodE-g.xp-10,10,4); c.fill(); c.stroke(); c.restore();
    if(act!=="free" && act!=="freecool") hand(c, rodE-24, cyM+4, 0);
    T(c,"内部エネルギー U", g.x0+18, g.y0+16, {size:12.5, bold:true, halo:true});
    var Tg=300*U/100-273;
    thermometer(c, g.x0+(g.xp-g.x0)*0.72, cyM+6, Math.max(18, g.y0-26), Tg, -100, 300, {ticks:[0,100,200], noNum:true, dec:0});
    /* 下：バーナー（熱を与える）／氷（熱を奪う） */
    var yb=g.y1+92, xm=(g.x0+g.x0+(g.x1-g.x0)*0.62)/2, heat=(act==="heat"||act==="free");
    if(heat) burner(c, xm, yb, running, this.clk, 1.1);
    if(running && heat){ heatArrow(c, xm+44, g.y1+64, xm+44, g.y1+8, 12); T(c,"熱 Q", xm+62, g.y1+40, {size:13, bold:true, col:COL.heat}); }
    var cool=(act==="cool"||act==="freecool");
    if(cool){ var ys=g.y1+(running? 4 : 34), sz=26;
      for(var q=0;q<3;q++) iceCube(c, xm-48+q*30, ys+6, sz);
      T(c,"氷で冷やす", xm-6, ys+sz+20, {size:12, bold:true, col:"#1f6fb2", align:"center"}); }
    if(running && cool){ heatArrow(c, xm+80, g.y1+8, xm+80, g.y1+62, 12); T(c,"熱 Q", xm+98, g.y1+36, {size:13, bold:true, col:COL.heat}); }
    /* 仕事の矢印：ピストンの動く向き。上は W、下は W′（符号が逆） */
    var yw=cyM+ry+30;
    if(running && (act==="push" || act==="pull" || act==="free" || act==="freecool")){ var neg=(act==="push"||act==="freecool"), dir=neg? -1 : 1;
      blockArrow(c, g.xp+60, yw, g.xp+60+dir*70, yw, 12, "#5cc47a");
      var lab=dash? ("気体がした仕事 W′ "+(neg? "< 0" : "> 0")) : (act==="push"? "仕事 W > 0（気体に正の仕事）" : act==="pull"? "仕事 W < 0（気体に負の仕事）" : act==="free"? "仕事 W < 0（気体が押し出す）" : "仕事 W > 0（外が押しこむ）");
      T(c, lab, g.xp+60+dir*35, yw+22, {size:12, bold:true, col:COL.work, align:"center", halo:true}); }
    if(running && (act==="heat" || act==="cool")){ var pt="ピストンは動かない（"+(dash? "W′" : "W")+" = 0）";   /* せまい画面でもはみ出さないように */
      T(c, pt, Math.min(g.xp+60, W-8-pt.length*11.5), yw+6, {size:11.5, bold:true, col:COL.work, halo:true}); }
    /* 右：棒グラフ。上 Q ＋ W ＝ ΔU、下 Q ＝ ΔU ＋ W′ */
    var bx0=Math.round(W*0.70), bx1=W-14, by0=g.y0+34, by1=H-16, base=(by0+by1)/2, sc=(by1-by0)/2/60;
    c.save(); c.strokeStyle="#3a414c"; c.lineWidth=1.2; c.beginPath(); c.moveTo(bx0,base); c.lineTo(bx1,base); c.stroke(); c.restore();
    T(c, "エネルギーの出入り", (bx0+bx1)/2, g.y0-22, {size:12.5, bold:true, align:"center"});
    var bw=(bx1-bx0)/5, vals=dash? [[this.Q,"Q",COL.heat],[U-100,"ΔU",COL.dU],[-this.W,"W′",COL.work]] : [[this.Q,"Q",COL.heat],[this.W,"W",COL.work],[U-100,"ΔU",COL.dU]];
    vals.forEach(function(v,i){ var x=bx0+bw*(0.5+i*1.75), hgt=clamp(v[0],-60,60)*sc;
      c.save(); c.fillStyle=v[2]; c.fillRect(x, base-Math.max(hgt,0), bw, Math.abs(hgt)); c.restore();
      SYM(c, v[1], null, x+bw/2, g.y0+4, {size:15, bold:true, col:v[2], align:"center"});
      T(c, (v[0]>=0?"+":"")+v[0].toFixed(0), x+bw/2, (hgt>=0? base-hgt-9 : base-hgt+10), {size:11.5, bold:true, col:v[2], align:"center", halo:true}); });
    T(c, dash? "＝" : "＋", bx0+bw*1.875, g.y0+4, {size:16, bold:true, align:"center"}); T(c, dash? "＋" : "＝", bx0+bw*3.625, g.y0+4, {size:16, bold:true, align:"center"});
    notebook(c,W,H);
  }
};

/* ---------------- ②-2 熱機関と熱効率 ----------------
   アルコールランプを載せた車を 4 台並べ、熱効率 e だけを変える。
   熱機関がした仕事 W′＝eQin を車の速さで表す（W′ に比例した一定の速さで走る）。 */
var S22 = {
  ES:[0,0.1,0.3,1], NOTE:["","蒸気機関くらい","ガソリン機関くらい","あり得ない"],
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.Qin=5; this.x=[0,0,0,0]; this.clk=0;
    this.run=new Runner({
      step:function(dt){ self.clk+=dt; var done=true; for(var i=0;i<4;i++){ self.x[i]+=self.speed(i)*dt; if(self.x[i]<1) done=false; else self.x[i]=Math.min(self.x[i],1); }
        return done || self.run.t>12; },
      draw:function(){ self.draw(); },
      reset:function(){ self.x=[0,0,0,0]; },
      info:function(r){ return '時間 <b>'+r.t.toFixed(1)+'</b> s'; }
    });
    this.run.bind(sec);
    this.sl=wireSlider(sec,"qin",function(v){ return v.toFixed(0)+" kJ"; },function(v){ self.Qin=v; self.run.reset(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.Qin=5; self.sl.set(5); self.run.rate=1;
      var sb=sec.querySelector(".slowb"); if(sb) sb.classList.remove("on"); self.run.reset(); });
    var anim=function(){ if(self.sec.offsetParent!==null && self.run.state!=="run"){ self.clk+=0.016; self.draw(); } requestAnimationFrame(anim); };
    onResize(this.cv.parentElement, function(){ self.draw(); });
    this.draw(); requestAnimationFrame(anim);
  },
  speed:function(i){ return this.ES[i]*this.Qin*0.032; },      /* トラック 1 本を 1 とした速さ（W′ に比例） */
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return clamp(W*0.72, 380, 500); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var rowH=(H-30)/4, tx0=150, tx1=Math.round(W*0.62), fx0=tx1+30;
    var w1=T(c,"同じ熱量 ", 12, 12, {size:12, col:COL.sub}); var w2=SYM(c,"Q","in",12+w1,12,{size:13,col:COL.sub}); T(c," を受け取る 4 台の車。熱効率 e だけが違う", 12+w1+w2, 12, {size:12, col:COL.sub});
    for(var i=0;i<4;i++){
      var e=this.ES[i], y=26+rowH*(i+0.62), ghost=(e===1);
      /* 道 */
      c.save(); c.strokeStyle="#b9b1a5"; c.lineWidth=3; c.beginPath(); c.moveTo(tx0-8,y+2); c.lineTo(tx1,y+2); c.stroke(); c.restore();
      var we=SYM(c,"e",null,12,y-22,{size:16, bold:true, col:(ghost?"#c0392b":COL.ink)}); T(c," = "+e, 12+we, y-22, {size:15, bold:true, col:(ghost?"#c0392b":COL.ink)});
      if(this.NOTE[i]) T(c,this.NOTE[i], 12, y-3, {size:10.5, col:(ghost?"#c0392b":COL.sub)});
      /* 車＋アルコールランプ */
      var cw=58, ch=18, cx=tx0+(tx1-tx0-cw-6)*this.x[i];
      c.save(); if(ghost){ c.setLineDash([4,3]); c.globalAlpha=0.75; }
      c.fillStyle=ghost? "rgba(255,255,255,.6)" : "#4d7ea8"; c.strokeStyle="#2c4a63"; c.lineWidth=1.6; rrect(c,cx,y-ch-6,cw,ch,4); c.fill(); c.stroke();
      c.fillStyle="#2b323c"; [cx+12,cx+cw-12].forEach(function(wx){ c.beginPath(); c.arc(wx,y-5,6,0,7); if(ghost) c.stroke(); else c.fill(); });
      /* ランプ */
      var lx=cx+cw/2, ly=y-ch-6;
      c.fillStyle=ghost? "rgba(255,255,255,.6)":"#eef4f8"; c.strokeStyle="#6f7b86"; c.lineWidth=1.2; c.beginPath(); c.moveTo(lx-9,ly); c.lineTo(lx-7,ly-12); c.lineTo(lx+7,ly-12); c.lineTo(lx+9,ly); c.closePath(); c.fill(); c.stroke();
      c.fillStyle="#7f8c8d"; c.fillRect(lx-2,ly-16,4,4);
      var fh=10+2*Math.sin(this.clk*20+i); c.fillStyle="rgba(240,140,40,.9)"; c.beginPath(); c.moveTo(lx-4,ly-16); c.quadraticCurveTo(lx,ly-16-fh*1.4,lx+4,ly-16); c.closePath(); c.fill();
      c.restore();
      /* 速度の矢印（青）：車の上に、少しはなして */
      var v=this.speed(i);
      if(v>0 && !ghost) arrow(c, cx+cw/2-10, y-ch-38, cx+cw/2-10+v*700, y-ch-38, COL.vel, 2.2, 8);
      if(e===0) T(c,"動かない", cx+cw+10, y-14, {size:11.5, bold:true, col:COL.sub});
      if(ghost) T(c,"✕ 熱を全て仕事に変える熱機関は作れない", Math.min(cx+cw+8, tx1-250), y-ch-36, {size:11, bold:true, col:"#c0392b", halo:true});
      /* エネルギーの流れ（右）：Qin → 熱機関 → W′、Qout は下へ */
      var ex=fx0+44, ey=y-26, ew=50, eh=26, sc=1.6;
      var wIn=3+this.Qin*sc, wW=e*this.Qin*sc, wO=(1-e)*this.Qin*sc;
      c.save(); if(ghost){ c.setLineDash([4,3]); c.globalAlpha=0.7; }
      heatArrow(c, fx0, ey+eh/2, ex, ey+eh/2, wIn*0.7, ghost?0.6:0.9);
      c.fillStyle="#fff4e5"; c.strokeStyle=COL.heat; c.lineWidth=1.3; rrect(c,ex,ey,ew,eh,4); c.fill(); c.stroke();
      T(c,"熱機関", ex+ew/2, ey+eh/2, {size:10.5, bold:true, align:"center", col:"#9c4e06"});
      if(wW>0.3) blockArrow(c, ex+ew, ey+eh/2, ex+ew+54, ey+eh/2, Math.max(3,wW*0.7), "#5cc47a", ghost?0.6:0.95);
      if(wO>0.3) heatArrow(c, ex+ew/2, ey+eh, ex+ew/2, ey+eh+26, Math.max(3,wO*0.7), ghost?0.6:0.9);
      c.restore();
      /* 量の名前は、記号＋添え字（Q の右下に小さく in・out）で */
      var lab=function(sym,sub,val,x,y,col){ var w=SYM(c,sym,sub,x,y,{size:13,bold:true,col:col,halo:true}); T(c," = "+val,x+w,y,{size:11.5,bold:true,col:col,halo:true}); };
      lab("Q","in",this.Qin.toFixed(0), fx0-6, ey-8, COL.heat);
      lab("W′",null,(e*this.Qin).toFixed(1), ex+ew+8, ey-8, COL.work);
      lab("Q","out",((1-e)*this.Qin).toFixed(1), ex+ew/2+10, ey+eh+22, COL.heat);
    }
    T(c,"単位：kJ　矢印の太さ＝エネルギーの大きさ", W-8, 12, {size:10, col:COL.sub, align:"right"});
    notebook(c,W,H);
    this.msg.innerHTML='ランプから受け取る熱量 '+tex("Q_\\mathrm{in}")+' = <span class="num">'+this.Qin.toFixed(0)+'</span> kJ。'+
      '車の速さは、熱機関がした仕事 '+tex("W'=eQ_\\mathrm{in}")+' に比例させている。<br>'+tex("e=1")+' の車（破線）は、熱力学第二法則によって<b>作ることができない</b>（→ ②-3）。';
  }
};
