/* ---------------- ③-1 絶対零度でも、粒子は完全には止まらない（ゼロ点振動） ----------------
   第7回。①-1 の＜発展＞をここへ移した。
   左：結晶の中の原子（ばねでつながった列）の振動。中：ばねにつながれた粒子のエネルギーの階段（イラスト）。右：振動のエネルギーと温度のグラフ。
   量子力学：1 つの振動の平均エネルギー E = (hν/2)・coth(hν/2kT)（hν/k = 120 K とした）。古典的な考え：E = kT。
   振動の大きさ（振幅）は √E に比例させる（見やすいように誇張している）。 */
var S30 = {
  TH:120, TMAX:300,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.T=300; this.classic=false; this.clk=0;
    this.run=new Runner({
      step:function(dt){ self.clk+=dt; return self.run.t>600; },
      draw:function(){ self.draw(); },
      reset:function(){ self.clk=0; },
      info:function(r){ return '温度 <b>'+self.T.toFixed(0)+'</b> K（'+(self.T-273).toFixed(0)+' ℃）'; }
    });
    this.run.bind(sec);
    this.sl=wireTSlider(sec,"T",function(v){ self.T=v; self.draw(); self.run.label(); });
    this.cc=wireChk(sec,"classic",function(on){ self.classic=on; self.draw(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.T=300; self.sl.set(300); self.classic=false; self.cc.set(false);
      self.run.rate=1; var sb=sec.querySelector(".slowb"); if(sb) sb.classList.remove("on"); self.run.reset(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    this.draw();
  },
  Eq:function(T){ var x=this.TH/(2*Math.max(T,1e-3)); return x>30? 0.5 : 0.5*(Math.exp(2*x)+1)/(Math.exp(2*x)-1); },   /* hν を単位に */
  Ec:function(T){ return T/this.TH; },
  draw:function(){
    var self=this, wide=(this.cv.parentElement.clientWidth>=700);
    var f=fitCanvas(this.cv, function(W){ return wide? clamp(W*0.36, 280, 340) : clamp(W*1.2, 440, 560); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var Eq=this.Eq(this.T), Ec=this.Ec(this.T), E=this.classic? Ec : Eq;
    var A1, A2, A3;
    if(wide){ A1={x:10,y:10,w:W*0.40,h:H-20}; A2={x:W*0.42,y:10,w:W*0.20,h:H-20}; A3={x:W*0.65,y:10,w:W*0.35-12,h:H-20}; }
    else { A1={x:10,y:10,w:W-20,h:H*0.42}; A2={x:10,y:H*0.46,w:W*0.36,h:H*0.52}; A3={x:W*0.40,y:H*0.46,w:W*0.60-12,h:H*0.52}; }
    this.drawLattice(c, A1, E);
    this.drawWell(c, A2);
    this.drawGraph(c, A3, Eq, Ec);
    notebook(c,W,H);
    var z=(this.T<=0.5);
    this.msg.innerHTML=(this.classic? '<b>古典的な考え</b>（量子力学を考えない）：振動のエネルギーは温度に比例し、絶対零度では 0（粒子は止まる）' :
      '<b>量子力学</b>：絶対零度に近づいても、振動のエネルギーは <span class="num">'+tex("\\tfrac{1}{2}h\\nu")+'</span> より小さくならない（<b>ゼロ点振動</b>）')+
      '<br>'+(z? '絶対零度：' : '')+'振動のエネルギー（'+tex("h\\nu")+' を 1 とする）　量子力学 <span class="num">'+Eq.toFixed(2)+'</span>　／　古典的な考え <span class="num">'+Ec.toFixed(2)+'</span>';
  },
  /* 左：結晶の中の原子。ばねでつながり、つりあいの位置（＋）の周りで震える */
  drawLattice:function(c, A, E){
    var nx=6, ny=3, sx=A.w/(nx+0.6), sy=Math.min(A.h/(ny+1.2), sx), x0=A.x+sx*0.8, y0=A.y+30+sy*0.5, r=Math.min(13, sx*0.22);
    var amp=Math.min(sx*0.30, 26)*Math.sqrt(E/2.6), clk=this.clk, P=[];
    T(c, this.classic? "古典的な考えの原子の振動" : "結晶の中の原子の振動（量子力学）", A.x+4, A.y+8, {size:12.5, bold:true});
    for(var j=0;j<ny;j++){ P.push([]); for(var i=0;i<nx;i++){ var p=PH[(j*nx+i)%PH.length];
      var dx=amp*(0.6*Math.sin(clk*(5+3*p[2])+p[0])+0.4*Math.sin(clk*(8.3+2*p[1]/6.3)+p[1])), dy=amp*(0.6*Math.sin(clk*(6+3*p[2])+p[1]*1.7)+0.4*Math.sin(clk*(9.1+p[0]/3)+p[0]*2.3));
      P[j].push([x0+i*sx, y0+j*sy, dx, dy]); } }
    /* ばね */
    c.save(); c.strokeStyle="rgba(105,113,125,.55)"; c.lineWidth=1.2;
    function spring(a,b){ var ax=a[0]+a[2], ay=a[1]+a[3], bx=b[0]+b[2], by=b[1]+b[3], n=8, L=Math.hypot(bx-ax,by-ay), ux=(bx-ax)/L, uy=(by-ay)/L;
      c.beginPath(); c.moveTo(ax,ay); for(var k=1;k<n;k++){ var t=k/n, s=(k%2? 1:-1)*3.5; c.lineTo(ax+(bx-ax)*t-uy*s, ay+(by-ay)*t+ux*s); } c.lineTo(bx,by); c.stroke(); }
    for(var j2=0;j2<ny;j2++) for(var i2=0;i2<nx;i2++){ if(i2<nx-1) spring(P[j2][i2],P[j2][i2+1]); if(j2<ny-1) spring(P[j2][i2],P[j2+1][i2]); }
    c.restore();
    var lv=clamp(Math.sqrt(E/2.6),0,1);
    for(var j3=0;j3<ny;j3++) for(var i3=0;i3<nx;i3++){ var q=P[j3][i3];
      c.save(); c.strokeStyle="rgba(58,65,76,.45)"; c.lineWidth=1; c.beginPath(); c.moveTo(q[0]-4,q[1]); c.lineTo(q[0]+4,q[1]); c.moveTo(q[0],q[1]-4); c.lineTo(q[0],q[1]+4); c.stroke(); c.restore();
      ball(c, q[0]+q[2], q[1]+q[3], r, 0, heatCol(lv)); }
    var yb=y0+(ny-1)*sy+sy*0.7;
    if(this.T<=0.5) T(c, this.classic? "絶対零度：粒子は止まる（古典的な考え）" : "絶対零度でも、粒子は震え続けている", A.x+A.w/2, Math.min(yb, A.y+A.h-8), {size:12.5, bold:true, col:this.classic? "#3a414c" : "#c0392b", align:"center", halo:true});
    else T(c,"＋：つりあいの位置　（振動は大きく描いています）", A.x+A.w/2, Math.min(yb, A.y+A.h-8), {size:10.5, col:COL.sub, align:"center"});
  },
  /* 中：ばねにつながれた粒子のエネルギーの階段（量子力学では、とびとびの値しかとれず、一番下も 0 ではない） */
  drawWell:function(c, A){
    var cx=A.x+A.w/2, yb=A.y+A.h-34, top=A.y+40, hw=A.w*0.44, hU=yb-top, nL=4;
    T(c,"エネルギーの階段", cx, A.y+8, {size:12.5, bold:true, align:"center"});
    c.save(); c.strokeStyle="#3a414c"; c.lineWidth=1.6; c.beginPath();
    for(var k=0;k<=40;k++){ var u=-1+2*k/40, x=cx+u*hw, y=yb-hU*u*u; if(k) c.lineTo(x,y); else c.moveTo(x,y); } c.stroke(); c.restore();
    var dE=hU/(nL+0.2);
    for(var n=0;n<nL;n++){ var e=(n+0.5)*dE, y=yb-e, half=hw*Math.sqrt(e/hU);
      c.save(); c.strokeStyle=(n===0)? "#c0392b" : "#1f6fb2"; c.lineWidth=(n===0)? 2.6 : 1.6; c.beginPath(); c.moveTo(cx-half,y); c.lineTo(cx+half,y); c.stroke(); c.restore(); }
    /* 0 の高さ（谷の底）と、一番下の段 */
    c.save(); c.setLineDash([3,3]); c.strokeStyle="rgba(58,65,76,.5)"; c.beginPath(); c.moveTo(cx-hw*0.5,yb); c.lineTo(cx+hw,yb); c.stroke(); c.restore();
    T(c,"0", cx+hw+4, yb, {size:11, col:COL.sub});
    var y0=yb-0.5*dE;
    arrow(c, cx+hw*0.62, yb, cx+hw*0.62, y0, "#c0392b", 1.4, 6);
    T(c,"一番下の段も 0 ではない", cx, yb+14, {size:10.5, bold:true, col:"#c0392b", align:"center"});
    T(c,"（ゼロ点エネルギー "+"½hν）", cx, yb+28, {size:10.5, col:"#c0392b", align:"center"});
  },
  /* 右：振動のエネルギーと温度のグラフ */
  drawGraph:function(c, A, Eq, Ec){
    var gx0=A.x+34, gx1=A.x+A.w, gy0=A.y+A.h-22, gy1=A.y+22, Em=3;
    var X=function(T){ return gx0+(gx1-gx0-14)*T/300; }, Y=function(E){ return gy0-(gy0-gy1-12)*E/Em; }, self=this;
    T(c,"振動のエネルギー", gx0+6, gy1-12, {size:11.5, bold:true});
    c.save(); c.strokeStyle="rgba(58,65,76,.10)"; c.lineWidth=1;
    for(var e=1;e<=Em;e++){ c.beginPath(); c.moveTo(gx0,Y(e)); c.lineTo(gx1-14,Y(e)); c.stroke(); T(c, String(e), gx0-6, Y(e), {size:10, col:COL.sub, align:"right"}); }
    for(var t=100;t<=200;t+=100){ T(c, String(t), X(t), gy0+11, {size:10, col:COL.sub, align:"center"}); }
    c.restore();
    T(c,"0", gx0-6, gy0+2, {size:10, col:COL.sub, align:"right"});
    axes(c, gx0, gy0, gx1, gy1);
    T(c,"温度〔K〕", gx1, gy0+11, {size:10.5, col:COL.sub, align:"right"});
    /* ゼロ点エネルギー */
    c.save(); c.setLineDash([4,4]); c.strokeStyle="rgba(192,57,43,.6)"; c.beginPath(); c.moveTo(gx0,Y(0.5)); c.lineTo(gx1-14,Y(0.5)); c.stroke(); c.restore();
    T(c,"½hν", gx1-16, Y(0.5)-9, {size:11, bold:true, col:"#c0392b", align:"right"});
    /* 古典的な考え（破線）と量子力学（実線） */
    c.save(); c.strokeStyle="#69717d"; c.lineWidth=2; c.setLineDash([6,4]); c.beginPath(); c.moveTo(X(0),Y(0)); c.lineTo(X(300),Y(this.Ec(300))); c.stroke(); c.restore();
    c.save(); c.strokeStyle="#1f6fb2"; c.lineWidth=2.6; c.beginPath();
    for(var k=0;k<=150;k++){ var T2=300*k/150; if(k) c.lineTo(X(T2),Y(this.Eq(T2))); else c.moveTo(X(T2),Y(this.Eq(T2))); } c.stroke(); c.restore();
    T(c,"量子力学", X(70), Y(this.Eq(70))-16, {size:11, bold:true, col:"#1f6fb2", align:"center", halo:true});
    T(c,"古典的な考え", X(205), Y(this.Ec(205))+16, {size:11, bold:true, col:"#69717d", align:"center", halo:true});
    /* いまの温度 */
    var E=this.classic? Ec : Eq; c.save(); c.fillStyle=this.classic? "#69717d" : "#1f6fb2"; c.beginPath(); c.arc(X(this.T),Y(E),5.5,0,7); c.fill(); c.restore();
  }
};

/* ---------------- ②-3 熱力学第二法則（大学の内容）：2 つのアニメ ----------------
   左：室温の部屋に置いた氷がとける。右：振り子が空気の抵抗などで止まる（力学的エネルギー → 熱）。
   「逆向きに再生する」を ON にすると、時間を逆にした映像になる。エネルギー保存則には反しないのに、自然には決して起こらない。 */
var S23 = {
  TEND:14, GAP:1.4,
  /* 第5回：ふつうのスタートでは、最後まで進んだら少し止めて、続けて逆再生する。チェックを ON にすると、はじめから逆再生だけ */
  total:function(){ return this.rev? this.TEND : 2*this.TEND+this.GAP; },
  phase:function(){ var t=Math.min(this.run.t, this.total());
    if(this.rev) return {u:this.TEND-t, back:t>0, wait:false};
    if(t<=this.TEND) return {u:t, back:false, wait:false};
    if(t<=this.TEND+this.GAP) return {u:this.TEND, back:false, wait:true};
    return {u:this.TEND-(t-this.TEND-this.GAP), back:true, wait:false}; },
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.rev=false;
    this.run=new Runner({
      step:function(dt){ return self.run.t>=self.total(); },
      draw:function(){ self.draw(); },
      reset:function(){},
      info:function(r){ var p=self.phase(); return (p.back? '<b style="color:#c0392b">逆再生中</b>　' : '')+'映像の中の時間 <b>'+p.u.toFixed(1)+'</b> s'; }
    });
    this.run.bind(sec);
    this.cr=wireChk(sec,"rev",function(on){ self.rev=on; self.run.reset(); });
    /* 第7回：時間バー（①章と同じ）。つまみで好きな時刻へ */
    this.tb=wireTimeBar(sec, this.run, function(){ return self.total(); }, function(){});
    sec.querySelector(".resetall").addEventListener("click", function(){ self.rev=false; self.cr.set(false); self.run.rate=1; var sb=sec.querySelector(".slowb"); if(sb) sb.classList.remove("on"); self.run.reset(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    this.draw();
  },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return clamp(W*0.52, 280, 380); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H); if(this.tb) this.tb.sync();
    var P=this.phase(), u=P.u, x=u/this.TEND, back=P.back, fin=(this.run.state==="done" && back);   /* u … 映像の中の時刻 */
    var pw=W/2;
    /* ===== 左：氷がとける ===== */
    T(c, back? "① 室温（25 ℃）に置いた水" : "① 室温（25 ℃）に置いた氷", 12, 14, {size:13, bold:true});
    var yD=H-40, cx=pw/2;
    c.save(); c.fillStyle="#c9bfb4"; c.fillRect(14,yD+14,pw-28,6); c.restore();
    c.save(); c.fillStyle="#f4f6f8"; c.strokeStyle="#8b949d"; c.lineWidth=1.5; c.beginPath(); c.ellipse(cx,yD+6,pw*0.36,14,0,0,7); c.fill(); c.stroke(); c.restore();
    var melt=clamp(x*1.1,0,1), pud=Math.sqrt(melt);
    if(pud>0.01){ c.save(); c.fillStyle="rgba(120,180,235,.55)"; c.beginPath(); c.ellipse(cx,yD+4,pw*0.31*pud+8,9*pud+2,0,0,7); c.fill(); c.restore(); }
    if(melt<1){ var s=58*Math.cbrt(1-melt); iceCube(c, cx-s/2-s*0.15, yD+2-s, s); }
    /* 文字も、逆再生に合わせる */
    var iceLab=back? (melt>=1? "水" : (melt>0? "氷ができていく" : "すっかり氷になった")) : (melt>=1? "すっかり水になった" : (melt>0? "とけていく" : "氷"));
    T(c, iceLab, cx, yD+34, {size:11.5, col:back? "#c0392b" : COL.sub, align:"center", bold:back});
    var moving=(this.run.state==="run" && !P.wait);
    if(moving && melt<1 && (u>0 || back)){ for(var i=0;i<2;i++){ var ax=cx+(i? 62:-62);
        if(back) heatFlow(c, ax, yD-26, ax+(i?24:-24), yD-58, 5, ((this.run.t*0.8)+i*0.5)%1);
        else heatFlow(c, ax+(i?24:-24), yD-58, ax, yD-26, 5, ((this.run.t*0.8)+i*0.5)%1); }
      T(c, back? "周りの空気へ熱を出す" : "周りの空気から熱", cx, yD-76, {size:11, col:COL.heat, align:"center", bold:true}); }
    /* ===== 右：振り子が止まる ===== */
    var ox=pw+pw/2, oy=34, L=Math.min(H-110, pw*0.55), th0=0.62, tau=8, om=2.6;
    T(c, back? "② 止まっていた振り子" : "② 揺れている振り子", pw+12, 14, {size:13, bold:true});
    var amp=th0*Math.exp(-u/tau), th=amp*Math.cos(om*u);
    c.save(); c.fillStyle="#7f8c8d"; c.fillRect(ox-30,oy-6,60,6); c.restore();
    var bx=ox+L*Math.sin(th), by=oy+L*Math.cos(th);
    c.save(); c.strokeStyle="#3a414c"; c.lineWidth=1.5; c.beginPath(); c.moveTo(ox,oy); c.lineTo(bx,by); c.stroke(); c.restore();
    c.save(); var g=c.createRadialGradient(bx-4,by-5,2,bx,by,13); g.addColorStop(0,"#fff"); g.addColorStop(1,"#4d7ea8"); c.fillStyle=g; c.strokeStyle="#2c4a63"; c.lineWidth=1.4; c.beginPath(); c.arc(bx,by,13,0,7); c.fill(); c.stroke(); c.restore();
    /* エネルギーの棒：力学的エネルギー（青）＋熱（オレンジ）＝一定 */
    var Em=Math.exp(-2*u/tau), bxL=pw+20, byB=H-18, bw=pw-40, bh=14;
    c.save(); c.fillStyle="#1663b5"; c.fillRect(bxL, byB-bh, bw*Em, bh); c.fillStyle=COL.heat; c.fillRect(bxL+bw*Em, byB-bh, bw*(1-Em), bh);
    c.strokeStyle="#3a414c"; c.lineWidth=1; c.strokeRect(bxL, byB-bh, bw, bh); c.restore();
    T(c,"力学的エネルギー", bxL, byB-bh-9, {size:10.5, col:"#1663b5", bold:true}); T(c,"熱（空気・支点）", bxL+bw, byB-bh-9, {size:10.5, col:COL.heat, bold:true, align:"right"});
    T(c, back? "周りの熱が、揺れのエネルギーに戻っていく" : "揺れのエネルギーが、少しずつ熱に変わる", ox, byB-bh-28, {size:10.5, col:back? "#c0392b" : COL.sub, align:"center", bold:back});
    c.save(); c.strokeStyle="#d5cfc3"; c.lineWidth=1; c.beginPath(); c.moveTo(pw,24); c.lineTo(pw,H-8); c.stroke(); c.restore();
    if(P.wait) T(c,"このあと、逆再生します", W/2, H*0.40, {size:15, bold:true, col:"#9c4e06", align:"center", halo:5});
    /* 第6回：逆再生中は、2 つのアニメに ✕ 印と「実際には決して起こらない」（アニメは透けて見えるように） */
    if(back){ c.save(); c.fillStyle="rgba(255,255,255,.35)"; c.fillRect(0,0,W,H); c.restore();
      c.save(); c.strokeStyle="rgba(192,57,43,.75)"; c.lineWidth=8; c.lineCap="round"; var m=Math.min(W,H)*0.28;
      [[W*0.25,H*0.5],[W*0.75,H*0.5]].forEach(function(p){ c.beginPath(); c.moveTo(p[0]-m*0.55,p[1]-m*0.55); c.lineTo(p[0]+m*0.55,p[1]+m*0.55); c.moveTo(p[0]+m*0.55,p[1]-m*0.55); c.lineTo(p[0]-m*0.55,p[1]+m*0.55); c.stroke(); }); c.restore();
      T(c,"実際には決して起こらない", W/2, H/2-10, {size:19, bold:true, col:"#c0392b", align:"center", halo:5});
      T(c,"（逆再生中のアニメ。エネルギー保存則には反していない）", W/2, H/2+16, {size:11.5, bold:true, col:"#c0392b", align:"center", halo:4}); }
    notebook(c,W,H);
    this.msg.innerHTML=back?
      '逆再生中のアニメ：水がひとりでに凍り（周りへ熱を出し）、止まっていた振り子がひとりでに揺れ始める（周りの熱が力学的エネルギーに戻る）。<b>エネルギー保存則には反していないのに、自然には起こらない。</b>' :
      '氷は周りの空気から熱を受け取ってとける。振り子の力学的エネルギーは、空気の抵抗などで少しずつ熱に変わり、振り子は止まる。どちらも、<b>ひとりでには逆向きに起こらない</b>（不可逆変化）。';
  }
};
