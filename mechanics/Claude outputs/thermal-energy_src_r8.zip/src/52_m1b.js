/* =========================================================================
   モード① 物質と比熱（1-4・1-5）
   ========================================================================= */

/* ---------------- ①-4 比熱 ----------------
   左：水 1.0 kg、右：えらんだ物質。同じバーナーで同じ熱量 Q を加える。 */
/* 比熱の小さい順（スライダーの左が小さく、右が大きい）。いちばん右は水（左と同じ物質で比べられる） */
var SUBS = [
  {name:"銀", sh:"銀", c:0.235, fill:"#e3e6ea"}, {name:"銅", sh:"銅", c:0.384, fill:"#e8b48a"}, {name:"鉄", sh:"鉄", c:0.448, fill:"#c9ccd1"},
  {name:"コンクリート", sh:"コン", c:0.8, fill:"#d8d4cc"}, {name:"アルミニウム", sh:"アルミ", c:0.902, fill:"#e6e9ee"}, {name:"木材", sh:"木材", c:1.3, fill:"#ecd2a4"},
  {name:"菜種油", sh:"油", c:2.04, fill:"#f6e7a8"}, {name:"海水", sh:"海水", c:3.93, fill:"#cfe6f5"}, {name:"水", sh:"水", c:4.18, fill:"#d4ebf9"}
];
/* 比熱のスライダーの下の目盛り（物質の名前） */
function cTicks(list){ return '<div class="cticks">'+list.map(function(d){ return '<span'+(d.name==="水"?' class="w"':'')+'>'+d.sh+'</span>'; }).join('')+'</div>'; }
var S14 = {
  CW:4.18, T0:20, RATE:2000, QMAX:60000,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.si=2; this.m=1.0; this.Q=0; this.clk=0;
    this.run=new Runner({
      startText:"▶ スタート（加熱する）",
      step:function(dt){ self.clk+=dt; self.Q=Math.min(self.Qstop(), self.RATE*self.run.t); return self.Q>=self.Qstop(); },
      draw:function(){ self.draw(); },
      reset:function(){ self.Q=0; },
      info:function(){ return ''; }
    });
    this.run.bind(sec);
    this.sg=wireSlider(sec,"sub",function(v){ var d=SUBS[Math.round(v)]; return d.name+"　"+d.c+" J/(g·K)"; },function(v){ self.si=Math.round(v); self.run.reset(); });
    this.mg=wireSlider(sec,"mass",function(v){ return v.toFixed(1)+" kg"+(Math.abs(v-1)<1e-6? "（水と同じ）" : ""); },function(v){ self.m=v; self.run.reset(); });
    this.tb=wireTimeBar(sec, this.run, function(){ return self.Qstop()/self.RATE; }, function(t){ self.Q=Math.min(self.Qstop(), self.RATE*t); });
    this.cg=colGrid(sec, {lc:"ref", rc:"sub"});
    sec.querySelector(".resetall").addEventListener("click", function(){ self.si=2; self.m=1.0; self.sg.set(2); self.mg.set(1); self.run.rate=1;
      var sb=sec.querySelector(".slowb"); if(sb) sb.classList.remove("on"); self.run.reset(); });
    var anim=function(){ if(self.sec.offsetParent!==null && self.run.state!=="run"){ self.clk+=0.016; self.draw(); } requestAnimationFrame(anim); };
    onResize(this.cv.parentElement, function(){ self.draw(); });
    this.draw(); requestAnimationFrame(anim);
  },
  sub:function(){ return SUBS[this.si]; },
  /* その物質の温度と時間のグラフ。もう一方の物質の線も薄く重ねて、比べられるようにする */
  drawTT:function(c, gx0, gy0, gx1, gy1, i, tEnd, tNow, C){
    var self=this, X=function(t){ return gx0+(gx1-gx0-12)*t/tEnd; }, Y=function(T){ return gy0-(gy0-gy1-10)*T/100; };
    c.save(); c.strokeStyle="rgba(58,65,76,.10)"; c.lineWidth=1;
    for(var v=20; v<=100; v+=20){ c.beginPath(); c.moveTo(gx0,Y(v)); c.lineTo(gx1-12,Y(v)); c.stroke(); T(c,String(v),gx0-5,Y(v),{size:9.5,col:COL.sub,align:"right"}); }
    c.restore();
    axes(c, gx0, gy0, gx1, gy1);
    T(c,"温度〔℃〕", gx0+6, gy1-4, {size:10.5, col:COL.sub});
    T(c,"時間", gx1, gy0+12, {size:10.5, col:COL.sub, align:"right"});
    var j=1-i, Tj=function(t){ return self.T0+self.RATE*t/C[j]; }, Ti=function(t){ return self.T0+self.RATE*t/C[i]; };
    c.save(); c.strokeStyle=this.COLS[j]; c.globalAlpha=0.35; c.lineWidth=1.6; c.setLineDash([5,4]); c.beginPath(); c.moveTo(X(0),Y(Tj(0))); c.lineTo(X(tNow),Y(Tj(tNow))); c.stroke(); c.restore();
    c.save(); c.strokeStyle=this.COLS[i]; c.lineWidth=2.8; c.beginPath(); c.moveTo(X(0),Y(Ti(0))); c.lineTo(X(tNow),Y(Ti(tNow))); c.stroke();
    c.fillStyle=this.COLS[i]; c.beginPath(); c.arc(X(tNow),Y(Ti(tNow)),4.5,0,7); c.fill(); c.restore();
    if(tNow>0) T(c,(j? this.sub().sh : "水")+"（比較）", X(tNow)+4, Y(Tj(tNow))+(Tj(tNow)>Ti(tNow)? -9 : 11), {size:9.5, col:this.COLS[j], halo:true});
  },
  Cs:function(){ return [1000*this.CW, this.m*1000*this.sub().c]; },        /* 熱容量 C＝mc［J/K］ */
  Qstop:function(){ var C=this.Cs(); return Math.min(this.QMAX, 80*Math.min(C[0],C[1])); },   /* 熱い方が 100 ℃ になったら止める */
  /* 第7回：左右の列をひとつにした図。左半分＝水とその T-t グラフ、右半分＝選んだ物質とその T-t グラフ。
     操作（左の説明・右のスライダー）は、それぞれの物質の真上にそろえる（colGrid）。色：水＝青、右の物質＝茶 */
  COLS:["#1f6fb2","#b5651d"],
  draw:function(){
    var self=this, wide=(this.cv.parentElement.clientWidth>=760);
    var f=fitCanvas(this.cv, function(W){ return wide? clamp(W*0.30, 300, 360) : clamp(W*1.5, 540, 640); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H); if(this.tb) this.tb.sync();
    var C=this.Cs(), names=["水", this.sub().name], ms=[1.0,this.m], cs=[this.CW,this.sub().c], fills=["#d4ebf9",this.sub().fill];
    var on=(this.run.state==="run"), tEnd=this.Qstop()/this.RATE, tNow=this.Q/this.RATE;
    for(var i=0;i<2;i++){
      var R = wide? {x:i*W/2, y:0, w:W/2, h:H} : {x:0, y:i*H/2, w:W, h:H/2};
      var ow=R.w*0.44, cx=R.x+ow/2+4, yDesk=R.y+R.h-12;
      var bw0=Math.min(130, ow*0.66), sc=(i? Math.cbrt(this.m) : 1), bw=bw0*sc, bh=bw0*0.72*sc, bx=cx-bw/2, by=yDesk-62-bh;
      var Tn=this.T0+this.Q/C[i], lv=clamp((Tn-this.T0)/80,0,1);
      burner(c, cx, yDesk, on, this.clk+i*0.37, 0.85);
      c.save(); c.fillStyle="#95a5a6"; c.fillRect(cx-bw0*0.7, yDesk-62, bw0*1.4, 6); c.restore();
      c.save(); c.strokeStyle="#7f8a8a"; c.lineWidth=3.5; c.beginPath(); c.moveTo(cx-bw0*0.62,yDesk-56); c.lineTo(cx-bw0*0.72,yDesk); c.moveTo(cx+bw0*0.62,yDesk-56); c.lineTo(cx+bw0*0.72,yDesk); c.stroke(); c.restore();
      c.save(); c.fillStyle=fills[i]; c.strokeStyle=this.COLS[i]; c.lineWidth=2.2; c.fillRect(bx,by,bw,bh); c.strokeRect(bx,by,bw,bh); c.restore();
      latticeParticles(c, bx+6, by+6, bw-34, bh-12, lv, this.clk+i*0.7, {nx:(sc>1.1? 4 : 3), ny:(sc>1.1? 3 : 2), r:Math.min(8, bw/16), a0:1.0, a1:6, k0:i*20});
      thermometer(c, bx+bw-14, by+bh-14, by-54, Tn, 0, 100, {ticks:[0,50,100], noNum:true, dec:1});
      T(c, names[i]+"　"+ms[i].toFixed(1)+" kg", cx-8, by-40, {size:13.5, bold:true, col:this.COLS[i], align:"center", halo:true});
      T(c, "比熱 "+cs[i]+" J/(g·K)", cx-8, by-22, {size:11, col:COL.sub, align:"center", halo:true});
      T(c, Tn.toFixed(1)+" ℃", bx+bw-14, by-64, {size:12, bold:true, col:"#c0392b", align:"center", halo:true});
      this.drawTT(c, R.x+ow+30, R.y+R.h-26, R.x+R.w-12, R.y+30, i, tEnd, tNow, C);
    }
    if(wide){ c.save(); c.strokeStyle="rgba(58,65,76,.18)"; c.setLineDash([4,4]); c.beginPath(); c.moveTo(W/2,8); c.lineTo(W/2,H-8); c.stroke(); c.restore(); }
    T(c,"同じバーナーで、同じ熱量を加える　（粒子は大きく描いています）", W/2, 10, {size:10.5, col:COL.sub, align:"center", halo:true});
    notebook(c,W,H);
    if(this.cg) this.cg.set(this.cv, [W/2], wide);
    var dT=[this.Q/C[0], this.Q/C[1]];
    this.msg.innerHTML='加えた熱量 '+tex("Q")+' = <span class="num">'+(this.Q/1000).toFixed(1)+'</span> kJ　'+
      '水：'+tex("\\Delta T")+' = <span class="num">'+dT[0].toFixed(1)+'</span> K　／　'+this.sub().name+'：'+tex("\\Delta T")+' = <span class="num">'+dT[1].toFixed(1)+'</span> K'+
      '<br>熱容量 '+tex("C=mc")+'：水 <span class="num">'+(C[0]/1000).toFixed(2)+'</span> kJ/K　／　'+this.sub().name+' <span class="num">'+(C[1]/1000).toFixed(2)+'</span> kJ/K';
  }
};

