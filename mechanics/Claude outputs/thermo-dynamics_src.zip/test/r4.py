import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--no-sandbox']); errs=[]
        for W in [390,1440]:
            pg=await b.new_page(viewport={'width':W,'height':900}); pg.on('pageerror', lambda e: errs.append(str(e)))
            await pg.goto('file:///home/claude/work/td/thermo-dynamics.html'); await pg.wait_for_timeout(500)
            await (await pg.query_selector('#hero')).screenshot(path=f'test/t4h_{W}.png')
            await pg.evaluate('gotoSec("s11")'); await pg.wait_for_timeout(300)
            await pg.click('#s11 #bPlay'); await pg.wait_for_timeout(1200)
            await (await pg.query_selector('#s11 canvas.main')).screenshot(path=f'test/t4v_{W}.png')
            sw=await pg.evaluate('document.documentElement.scrollWidth'); print(W, sw)
            await pg.close()
        print(errs); await b.close()
asyncio.run(main())
