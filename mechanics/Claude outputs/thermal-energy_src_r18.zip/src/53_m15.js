/* ---------------- 熱平衡（熱量の保存）［今の番号 ①-3・id s15］ ----------------
   第2回：比熱（s14）とレイアウトをそろえる。A は鉄 1.0 kg に固定。B の物質（比熱）と質量を選ぶ。
   熱容量 C＝mc は結果として計算して表示する。質量を変えると、B の物体の大きさ（液体なら量）が変わる。
   「固体と固体」：鉄のブロックと、えらんだ固体のブロックをくっつける。
   「固体と液体」：鉄の球を、えらんだ液体に入れる。境目を拡大した窓で、粒子がエネルギーを渡すようす。
   第18回「固体と液体・容器」：熱量計（銅の容器とかき混ぜ棒）に液体を入れ、鉄球を入れる。物体は 3 つ（鉄球・液体・銅の容器）。
     容器は初め液体と同じ温度。鉄球と液体、液体と容器の間で熱が移る（容器は液体とすぐ同じ温度になる）。
   第18回：A・B（・容器）の初めの温度はスライダーで決める。スタート後は、そのスライダーのつまみが今の温度まで動く（初めの位置に印）。
   熱の矢印は、熱が移動している間だけ。矢印そのものは動かさず、中の色の帯が流れる（流れる速さ＝熱の移る速さ）。高温の側から低温の側へ向ける。
   状態は時刻だけで決まる（初めに最後まで計算しておく）ので、時間バーで戻したり進めたりできる。 */
var SOL15 = [
  {name:"銀", sh:"銀", c:0.235}, {name:"銅", sh:"銅", c:0.384}, {name:"鉄", sh:"鉄", c:0.448},
  {name:"コンクリート", sh:"コン", c:0.8}, {name:"アルミニウム", sh:"アルミ", c:0.902}, {name:"木材", sh:"木材", c:1.3}
];
var LIQ15 = [
  {name:"菜種油", sh:"油", c:2.04}, {name:"エタノール", sh:"エタノール", c:2.42}, {name:"海水", sh:"海水", c:3.93}, {name:"水", sh:"水", c:4.18}
];
var S15 = {
  K:20, KBC:80, KOUT:5, TR:20, CL:0.448, CCU:0.384, ML:1.0, RUNSEC:25,
  COLA:"#c0392b", COLB:"#1f6fb2", COLC:"#a8582a",
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.kind="ss"; this.si=4; this.m=1.0; this.mc=0.5; this.TA0=80; this.TB0=20; this.lid=false; this.clk=0; this.ph=0; this.ph2=0; this.zw=null; this.anc=[];
    this.compute();
    this.run=new Runner({
      step:function(dt){ var s=self.at(self.ts()); self.clk+=dt; self.ph=(self.ph+dt*(0.12+0.9*Math.abs(s.P)/self.Pmax))%1; self.ph2=(self.ph2+dt*(0.12+0.9*Math.abs(s.P2)/self.Pmax))%1;
        return self.run.t>self.T0 && self.ts()>=self.tEnd; },
      draw:function(){ self.draw(); },
      reset:function(){},
      info:function(){ return ''; }
    });
    this.run.bind(sec);
    this.tb=wireTimeBar(sec, this.run, function(){ return self.T0+self.tEnd/self.spd; }, function(){});
    this.og=objGrid(sec);
    this.boxes=[].slice.call(sec.querySelectorAll(".ogbox"));
    var inp=sec.querySelector('.vrow[data-k="sub"] input'), tk=sec.querySelector('.cticks');
    this.sg=wireSlider(sec,"sub",function(v){ var d=self.list()[Math.round(v)]; return d? d.name+"　比熱 "+d.c+" J/(g·K)" : ""; },function(v){ self.si=Math.round(v); self.changed(); });
    this.mg=wireSlider(sec,"mass",function(v){ return "質量　"+v.toFixed(1)+" kg"+(Math.abs(v-1)<1e-6? "（鉄と同じ）" : ""); },function(v){ self.m=v; self.changed(); });
    this.cm=wireSlider(sec,"mc",function(v){ return "質量　"+v.toFixed(1)+" kg"; },function(v){ self.mc=v; self.changed(); });
    this.wa=wireTemp(sec,"ta",function(v){ self.TA0=v; self.changed(); });
    this.wb=wireTemp(sec,"tb",function(v){ self.TB0=v; self.wc.set(v); self.changed(); });
    this.wc=wireTemp(sec,"tc",function(v){ self.TB0=v; self.wb.set(v); self.changed(); });   /* 容器は初め液体と同じ温度 */
    var setList=function(){ var L=self.list(); inp.max=L.length-1; tk.innerHTML=L.map(function(d){ return '<span'+(d.name==="水"?' class="w"':'')+'>'+d.sh+'</span>'; }).join(''); self.sg.set(self.si); };
    this.setList=setList;
    this.sk=wireSeg(sec,"kind",function(v){ self.kind=v; self.si=(v==="ss")? 4 : 3; setList(); self.changed(); });
    /* 組み合わせのボタンは、物体の箱の上（箱の列のまん中）に大きく置く */
    var kb=document.createElement("div"); kb.className="subbtns"; kb.innerHTML='<span class="subcap">組み合わせ</span>';
    sec.querySelectorAll('button.seg[data-g="kind"]').forEach(function(b){ kb.appendChild(b); });
    var sl0=sec.querySelector(".segl"); if(sl0 && /組み合わせ/.test(sl0.textContent)) sl0.remove();
    this.og.top.appendChild(kb);
    this.cl=wireChk(sec,"lid",function(on){ self.lid=on; self.changed(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.kind="ss"; self.sk.set("ss"); self.si=4; self.m=1.0; self.mg.set(1); self.mc=0.5; self.cm.set(0.5);
      self.TA0=80; self.wa.set(80); self.TB0=20; self.wb.set(20); self.wc.set(20); setList();
      self.lid=false; self.cl.set(false); self.run.rate=1; var s2=sec.querySelector(".slowb"); if(s2) s2.classList.remove("on"); self.changed(); });
    setList();
    var anim=function(){ if(self.sec.offsetParent!==null && self.run.state!=="run"){ self.clk+=0.016; self.draw(); } requestAnimationFrame(anim); };
    onResize(this.cv.parentElement, function(){ self.draw(); });
    this.draw(); requestAnimationFrame(anim);
  },
  list:function(){ return this.kind==="ss"? SOL15 : LIQ15; },
  sub:function(){ var L=this.list(); return L[clamp(this.si,0,L.length-1)]; },
  hasC:function(){ return this.kind==="slc"; },
  CA:function(){ return this.ML*1000*this.CL; }, CB:function(){ return this.m*1000*this.sub().c; }, CC:function(){ return this.hasC()? this.mc*1000*this.CCU : 0; },
  Tf:function(){ var A=this.CA(), B=this.CB(), C=this.CC(); return (A*this.TA0+(B+C)*this.TB0)/(A+B+C); },
  changed:function(){ this.compute(); this.run.reset(); },
  /* 最後まで計算しておく（0.05 s きざみ）。H の 1 行＝[時刻, TA, TB, TC, A→B の熱の流れ P, B→容器 P2] */
  compute:function(){
    this.T0=(this.kind==="ss")? 0.6 : 3.0;     /* 第9回：ふれるまでの時間。鉄球はゆっくり等速で入れる */
    var CA=this.CA(), CB=this.CB(), CC=this.CC(), hc=this.hasC(), TA=this.TA0, TB=this.TB0, TC=this.TB0, t=0, h=0.05, H=[];
    for(var i=0;i<40000;i++){
      var P=this.K*(TA-TB), P2=hc? this.KBC*(TB-TC) : 0, La=this.lid? this.KOUT*(TA-this.TR) : 0, Lb=this.lid? this.KOUT*(TB-this.TR) : 0, Lc=(this.lid&&hc)? this.KOUT*(TC-this.TR) : 0;
      H.push([t,TA,TB,TC,P,P2]);
      var hi=Math.max(TA,TB,hc?TC:TB), lo=Math.min(TA,TB,hc?TC:TB);
      var done=this.lid? (Math.abs(TA-this.TR)<0.3 && Math.abs(TB-this.TR)<0.3 && (!hc || Math.abs(TC-this.TR)<0.3)) : (hi-lo<0.05);
      if(done || t>900) break;
      TA-=(P+La)*h/CA; TB+=(P-P2-Lb)*h/CB; if(hc) TC+=(P2-Lc)*h/CC; else TC=TB; t+=h;
    }
    this.H=H; this.tEnd=t; this.spd=Math.max(1, t/this.RUNSEC); this.Pmax=Math.max(1e-9, this.K*Math.abs(this.TA0-this.TB0));
  },
  T0:0.5,
  ts:function(){ return Math.min(this.tEnd, Math.max(0, this.run.t-this.T0)*this.spd); },     /* 実験の中の時刻［s］ */
  at:function(t){ var i=Math.min(this.H.length-1, Math.floor(t/0.05)), a=this.H[i]; return {t:a[0], TA:a[1], TB:a[2], TC:a[3], P:a[4], P2:a[5]}; },
  /* 第5回：スタート前は、2 つの物体をふれさせない（固体どうしはすき間、鉄球は液体の外）。スタートで T0 秒かけてふれさせる */
  touchU:function(){ if(this.run.state==="idle" && this.run.t<=0) return 0; return clamp(this.run.t/this.T0,0,1); },
  /* 箱の見出し */
  heads:function(){ var A=(this.kind==="ss")? "鉄のブロック" : "鉄球";
    return [A+' 1.0 kg<small>比熱 0.448 J/(g·K)</small>', this.sub().name+(this.kind==="ss"? "のブロック" : ""), '銅の容器<small>かき混ぜ棒も含む</small><small>比熱 '+this.CCU+' J/(g·K)</small>']; },
  draw:function(){
    var self=this, wide=(this.cv.parentElement.clientWidth>=760);
    var f=fitCanvas(this.cv, function(W){ return wide? clamp(W*0.28, 270, 330) : clamp(W*0.98, 470, 660); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H); if(this.tb) this.tb.sync();
    var st=this.at(this.ts()), u=this.touchU(), hc=this.hasC();
    var moving=(this.run.state==="run" && u>=1 && Math.abs(st.P)>this.Pmax*0.01);   /* 熱が移動している間だけ、熱の矢印を出す */
    var c1=W*0.31, c2=W*0.62;
    this.anc=[];
    if(wide){
      if(this.kind==="ss") this.drawSS(c,0,c2,H-6,st,moving,u); else this.drawSL(c,0,c1,c1+14,c2-c1-28,H-6,st,moving,u);
      this.drawGraph(c, c2+34, H-26, W-14, 34, st);
    } else {
      var figH=Math.round(H*0.54);
      if(this.kind==="ss") this.drawSS(c,0,W,figH,st,moving,u); else if(hc) this.drawSL(c,0,W*0.92,0,0,figH,st,moving,u);   /* 容器ありは図を広く（拡大の窓は出さない） */
      else this.drawSL(c,0,W*0.42,W*0.42+28,W*0.58-40,figH,st,moving,u);
      this.drawGraph(c, 46, H-26, W-16, figH+34, st);
    }
    notebook(c,W,H);
    /* 箱：見出し・容器の箱の出し入れ・温度のスライダーのつまみ */
    var hd=this.heads(); this.boxes.forEach(function(b,i){ var hide=(i===2 && !hc); if(b.hidden!==hide) b.hidden=hide; var e=b.querySelector(".oghead"); if(e._h!==hd[i]){ e._h=hd[i]; e.innerHTML=hd[i]; } });
    var live=!(this.run.state==="idle" && this.run.t<=0);
    this.wa.show(live? st.TA : this.TA0, live); this.wb.show(live? st.TB : this.TB0, live); this.wc.show(live? st.TC : this.TB0, live);
    /* 箱の並べ方：2 つなら図の 1・2 列。3 つなら図の幅の 4 分の 3 を 3 等分（再生バーはのこりの 4 分の 1）。せまくなるときは縦に並べる */
    var og3=hc && (W*0.25>=240);
    if(this.og) this.og.set(this.cv, hc? [W*0.25, W*0.5, W*0.75] : [c1,c2], wide && (!hc || og3));
    if(this.og) this.og.links(this.cv, this.anc, wide && (!hc || og3));
    var Ca=this.CA(), Cb=this.CB(), Cc=this.CC(), nB=this.sub().name;
    var Qa=Ca*(this.TA0-st.TA), Qb=Cb*(st.TB-this.TB0), Qc=Cc*(st.TC-this.TB0);
    var lost=function(n,q){ return n+'が'+(q>=-1e-9? '失った' : '得た')+'熱量 <span class="num">'+(Math.abs(q)/1000).toFixed(2)+'</span> kJ'; };
    var got=function(n,q){ return n+'が'+(q>=-1e-9? '得た' : '失った')+'熱量 <span class="num">'+(Math.abs(q)/1000).toFixed(2)+'</span> kJ'; };
    var h='熱容量 '+tex("C=mc")+'：鉄 <span class="num">'+Ca.toFixed(0)+'</span> J/K　／　'+nB+' <span class="num">'+Cb.toFixed(0)+'</span> J/K'+(hc? '　／　銅の容器 <span class="num">'+Cc.toFixed(0)+'</span> J/K' : '')+'<br>'+
      lost("鉄",Qa)+'　／　'+(hc? got(nB+'と容器',Qb+Qc)+'（'+nB+' <span class="num">'+(Math.abs(Qb)/1000).toFixed(2)+'</span>・容器 <span class="num">'+(Math.abs(Qc)/1000).toFixed(2)+'</span>）' : got(nB,Qb))+
      (this.lid? '（ふたが開いているので、熱が外へ逃げる）' : '（等しい：熱量の保存）')+
      '<br>熱平衡の温度（計算）：'+(hc? tex("t=\\dfrac{C_\\mathrm{A}t_\\mathrm{A}+C_\\mathrm{B}t_\\mathrm{B}+C_\\mathrm{C}t_\\mathrm{C}}{C_\\mathrm{A}+C_\\mathrm{B}+C_\\mathrm{C}}") : tex("t=\\dfrac{C_\\mathrm{A}t_\\mathrm{A}+C_\\mathrm{B}t_\\mathrm{B}}{C_\\mathrm{A}+C_\\mathrm{B}}"))+' = <span class="num">'+this.Tf().toFixed(1)+'</span> ℃';
    if(this._mh!==h){ this._mh=h; this.msg.innerHTML=h; }
  },
  /* 断熱容器とふた（ふたは左はしを軸に少しだけ開ける）。中の容器は (x, y, w, h)。壁の厚さ TW は外側に描く */
  TW:12,
  vessel:function(c, x, y, w, h, open){
    var t=this.TW;
    var hatch=function(px,py,pw,ph){ c.save(); c.fillStyle="#e2dccf"; c.fillRect(px,py,pw,ph); c.beginPath(); c.rect(px,py,pw,ph); c.clip();
      c.strokeStyle="rgba(120,108,88,.45)"; c.lineWidth=1; c.beginPath(); for(var k=-ph; k<pw+ph; k+=7){ c.moveTo(px+k,py+ph); c.lineTo(px+k+ph,py); } c.stroke(); c.restore();
      c.save(); c.strokeStyle="#3a414c"; c.lineWidth=1.6; c.strokeRect(px,py,pw,ph); c.restore(); };
    hatch(x-t, y, t, h+t); hatch(x+w, y, t, h+t); hatch(x, y+h, w, t);       /* 左右の壁と底 */
    c.save(); c.fillStyle="#f7f9fb"; c.fillRect(x,y,w,h); if(!this.hasC()){ c.strokeStyle="rgba(58,65,76,.45)"; c.lineWidth=1.2; c.strokeRect(x+4,y+4,w-8,h-6); } c.restore();
    if(open){ T(c,"断熱容器", x+w/2, y-8, {size:11, col:COL.sub, align:"center"}); return; }
    if(this.lid){ var ang=0.24, L=w+2*t; c.save(); c.translate(x-t, y); c.rotate(-ang); hatch(0, -t, L, t); c.restore();
      T(c,"ふたが開いている", x+w-6, y-L*Math.sin(ang)-t+2, {size:11.5, bold:true, col:"#c0392b", align:"right", halo:true});
      if(this.run.state==="run") for(var i=0;i<2;i++){ var xx=x+w*(0.70+0.18*i); heatFlow(c, xx, y+18, xx, y-16, 5, (this.clk*0.5+i*0.3)%1, {k:0.6}); } }
    else { hatch(x-t, y-t, w+2*t, t);
      T(c, (this.hasC() && w<300)? "断熱容器" : "断熱容器（ふたを閉じている）", x-t, y-t-9, {size:11, col:COL.sub}); }   /* 容器ありのせまい図は短く（鉄球の温度計と重ねない） */
  },
  lvOf:function(T){ return clamp((T-10)/80,0,1); },
  /* 熱の矢印：P の向き（正なら A → B）に合わせて向きを変える */
  flow:function(c, xa, ya, xb, yb, P, ph, lwMax, lab){ var k=clamp(Math.abs(P)/this.Pmax,0,1), lw=3+lwMax*k;
    if(P>=0) heatFlow(c, xa, ya, xb, yb, lw, ph, {k:k}); else heatFlow(c, xb, yb, xa, ya, lw, ph, {k:k});
    if(lab) T(c,"熱 Q", (xa+xb)/2, (ya+yb)/2-lw/2-16, {size:13, bold:true, col:COL.heat, align:"center", halo:true}); },
  drawSS:function(c,X0,AW,Hf,st,moving,u){
    var self=this, vw=Math.min(460, AW*0.86), vx=X0+(AW-vw)/2, vy=60, vh=Hf-vy-this.TW;
    this.vessel(c, vx, vy, vw, vh);
    var base=Math.min(vw*0.28, vh*0.62), sA=base, sB=base*Math.cbrt(this.m)*0.92, floor=vy+vh-10, gap=40*(1-u), xm=vx+vw/2;
    var blk=function(x, s, T, k0, col){ var y=floor-s; c.save(); c.fillStyle=col; c.strokeStyle="#3a414c"; c.lineWidth=2; c.fillRect(x,y,s,s); c.strokeRect(x,y,s,s); c.restore();
      var n=Math.max(2,Math.round(s/34)); latticeParticles(c, x+6, y+6, s-12, s-12, self.lvOf(T), self.clk+k0, {nx:n, ny:n, r:Math.min(8, s/(n*3.2)), a0:0.8, a1:6, k0:k0*10}); return y; };
    var xa=xm-gap/2, xb=xm+gap/2;
    var yA=blk(xa-sA, sA, st.TA, 0, "#eceef1"), yB=blk(xb, sB, st.TB, 1, "#fdfdfd");
    thermometer(c, xa-sA+16, floor-sA*0.45, yA-46, st.TA, 0, 100, {ticks:[0,100], noNum:true, dec:1});
    thermometer(c, xb+sB-16, floor-sB*0.45, yB-46, st.TB, 0, 100, {ticks:[0,100], noNum:true, dec:1});
    if(vw<330){   /* せまい画面：名前は容器の下に書く（温度計と重ねない） */
      T(c,"鉄 1.0 kg", xa-sA/2, vy+vh+14, {size:11.5, bold:true, align:"center"});
      T(c, this.sub().sh+" "+this.m.toFixed(1)+" kg", xb+sB/2, vy+vh+14, {size:11.5, bold:true, align:"center"});
      this.anc=[{x:xa-sA/2, y:yA, col:this.COLA}, {x:xb+sB/2, y:yB, col:this.COLB}];
    } else {
      var wA=T(c,"鉄 1.0 kg", xa-8, floor-sA-14, {size:12.5, bold:true, align:"right", halo:true});
      var wB=T(c, this.sub().name+" "+this.m.toFixed(1)+" kg", xb+8, floor-sB-14, {size:12.5, bold:true, halo:true});
      this.anc=[{x:xa-8-wA/2, y:floor-sA-24, col:this.COLA}, {x:xb+8+wB/2, y:floor-sB-24, col:this.COLB}];
    }
    if(u<=0) T(c,"スタートで、2 つを触れさせる", xm, vy+26, {size:12, bold:true, col:"#9c4e06", align:"center", halo:true});
    if(moving){ var cy=floor-Math.min(sA,sB)/2; this.flow(c, xm-56, cy, xm+56, cy, st.P, this.ph, 13, true); }
    else if(this.ts()>=this.tEnd-1e-6 && !this.lid && u>=1) T(c,"熱平衡（熱の移動が止まった）", xm, vy+26, {size:13, bold:true, col:"#1c8f4a", align:"center", halo:true});
  },
  drawSL:function(c,X0,AW,ZX,ZW,Hf,st,moving,u){
    var self=this, hc=this.hasC(), vw=Math.min(250, AW-24), vx=X0+16, r=Math.min(30, vw*0.13), vy=Math.max(40, 2*r+74), vh=Hf-vy-this.TW;
    this.vessel(c, vx, vy, vw, vh, u<1);
    /* 第18回：熱量計の銅の容器（中に液体）。台の上にのせ、断熱容器の壁から少しはなす */
    var ix=vx+6, iw=vw-12, ib=vy+vh-1, itop=vy+2;
    if(hc){ ix=vx+10; iw=vw-20; ib=vy+vh-10; itop=vy+12; }
    var lvl=(ib-itop-8)*clamp(0.30+0.30*this.m,0,0.92), wl=ib-lvl;      /* 液体の量で液面の高さが変わる */
    c.save(); c.fillStyle="rgba(90,160,225,.42)"; c.fillRect(ix+(hc?4:0), wl, iw-(hc?8:0), ib-wl-(hc?4:0)); c.strokeStyle="#2f6f9f"; c.lineWidth=1.5; c.beginPath(); c.moveTo(ix+(hc?4:0),wl); c.lineTo(ix+iw-(hc?4:0),wl); c.stroke(); c.restore();
    if(hc){
      var lvC=this.lvOf(st.TC);
      c.save(); c.strokeStyle="#a8582a"; c.lineWidth=4.5; c.lineJoin="round"; c.beginPath(); c.moveTo(ix+2,itop); c.lineTo(ix+2,ib-2); c.lineTo(ix+iw-2,ib-2); c.lineTo(ix+iw-2,itop); c.stroke();
      c.strokeStyle=heatCol(lvC); c.globalAlpha=0.55; c.lineWidth=1.8; c.stroke(); c.restore();
      c.save(); c.fillStyle="#3a414c"; [0.25,0.75].forEach(function(q){ var px=ix+iw*q; c.beginPath(); c.moveTo(px,ib); c.lineTo(px-6,ib+8); c.lineTo(px+6,ib+8); c.closePath(); c.fill(); }); c.restore();
      /* かき混ぜ棒（銅）：上から入れて、底の近くで横に曲げる */
      var rx=ix+iw*0.86; c.save(); c.strokeStyle="#a8582a"; c.lineWidth=3; c.lineCap="round"; c.beginPath(); c.moveTo(rx, vy-30); c.lineTo(rx, ib-12); c.lineTo(rx-24, ib-12); c.stroke();
      c.lineWidth=2; c.beginPath(); c.arc(rx, vy-36, 6, 0, 7); c.stroke(); c.restore();
      T(c,"銅の容器", ix+iw*0.50, ib-11, {size:10.5, bold:true, col:"#8a4220", halo:true});
      if(moving && Math.abs(st.P2)>this.Pmax*0.01){ var yy=(wl+ib)/2+6; this.flow(c, ix+iw-40, yy, ix+iw-6, yy, st.P2, this.ph2, 6, false); }
    }
    /* スタート前は、鉄球を糸でつるして液体の外に。スタートで沈める */
    var bxc=ix+iw*0.30, byIn=ib-r-(hc?16:8), byOut=vy-r-16, byc=byOut+(byIn-byOut)*u;     /* 第9回：落とさずに、等速でそっと入れる */
    if(u<1){ c.save(); c.strokeStyle="#69717d"; c.lineWidth=1.2; c.beginPath(); c.moveTo(bxc,0); c.lineTo(bxc,byc-r); c.stroke(); c.restore(); }
    var lvA=this.lvOf(st.TA), gr=c.createRadialGradient(bxc-r*0.3,byc-r*0.35,2,bxc,byc,r);
    gr.addColorStop(0,"#fff"); gr.addColorStop(1, heatCol(lvA));
    c.save(); c.fillStyle=gr; c.strokeStyle="#3a414c"; c.lineWidth=1.8; c.beginPath(); c.arc(bxc,byc,r,0,7); c.fill(); c.stroke(); c.restore();
    var wA=T(c,"鉄球 1.0 kg", bxc+r+6, byc+4, {size:11.5, bold:true, halo:true});
    thermometer(c, bxc+r*0.45, byc+r*0.2, byc-r-34, st.TA, 0, 100, {ticks:[0,100], noNum:true, dec:1, br:6});
    if(u<=0) T(c,"スタートで鉄球を液体に入れる", bxc+r+8, byc-r+2, {size:11.5, bold:true, col:"#9c4e06", halo:true});
    var tx=ix+iw-(hc?20:18);
    thermometer(c, tx, ib-(hc?18:23), vy-26, st.TB, 0, 100, {ticks:[0,100], noNum:true, dec:1, br:6});
    var wB=T(c, this.sub().name+" "+this.m.toFixed(1)+" kg", tx-(hc?28:14), wl+(hc?-10:16), {size:12, bold:true, col:"#2f6f9f", align:"right", halo:hc});
    this.anc=[{x:bxc+r+6+wA/2, y:byc-8, col:this.COLA}, {x:tx-(hc?28:14)-wB/2, y:wl+(hc?-20:6), col:this.COLB}];
    if(hc) this.anc.push({x:ix+iw-2, y:itop+14, col:this.COLC});
    /* 拡大の窓：鉄球の表面と液体の境目 */
    var zx=ZX, zy=Math.max(26, vy-30), zw=ZW, zh=Hf-zy;
    if(zw>150 && u<1){
      c.save(); c.fillStyle="#fff"; c.strokeStyle="rgba(224,123,24,.55)"; c.setLineDash([5,4]); c.lineWidth=1.6; rrect(c,zx,zy,zw,zh,8); c.fill(); c.stroke(); c.restore();
      T(c,"鉄球が液体に入ると、", zx+zw/2, zy+zh/2-10, {size:11.5, col:COL.sub, align:"center"});
      T(c,"ここに境目を拡大して表示", zx+zw/2, zy+zh/2+10, {size:11.5, col:COL.sub, align:"center"});
    } else if(zw>150){
      c.save(); c.strokeStyle="rgba(224,123,24,.7)"; c.setLineDash([3,3]); c.lineWidth=1; c.beginPath(); c.moveTo(bxc+r*0.95, byc-r*0.3); c.lineTo(zx, zy+zh*0.5); c.stroke(); c.restore();
      c.save(); c.fillStyle="#fff"; c.strokeStyle="#e07b18"; c.lineWidth=2; rrect(c,zx,zy,zw,zh,8); c.fill(); c.stroke(); c.clip();
      var mx=zx+zw*0.42;
      /* 第11回：鉄球の表面は少しカーブさせる（球のふくらみ） */
      var bg=Math.min(16, zw*0.05), yc0=zy+zh/2, bx=function(y){ var q=(y-yc0)/(zh*0.62); return mx+bg*(1-q*q); };
      var edge=function(){ for(var k=0;k<=24;k++){ var y=zy+zh*k/24; c.lineTo(bx(y),y); } };
      c.fillStyle="rgba(90,160,225,.22)"; c.fillRect(zx,zy,zw,zh);
      c.fillStyle="#eceff3"; c.beginPath(); c.moveTo(zx,zy); edge(); c.lineTo(zx,zy+zh); c.closePath(); c.fill();
      latticeParticles(c, zx+4, zy+8, mx-zx-8, zh-16, lvA, this.clk, {nx:3, ny:4, r:9, a0:0.8, a1:7});
      var lvB=this.lvOf(st.TB), ww=zx+zw-mx;
      if(!this.zw){ this.zw=[]; for(var i=0;i<10;i++){ var th=Math.random()*6.283; this.zw.push({x:Math.random(), y:Math.random(), vx:Math.cos(th), vy:Math.sin(th)}); } }
      var sp=0.12+0.35*lvB, dt=0.016;
      this.zw.forEach(function(p){ p.x+=p.vx*sp*dt; p.y+=p.vy*sp*dt;
        if(p.x<0.12){ p.x=0.12; p.vx=Math.abs(p.vx); } if(p.x>0.94){ p.x=0.94; p.vx=-Math.abs(p.vx); } if(p.y<0.06){ p.y=0.06; p.vy=Math.abs(p.vy); } if(p.y>0.94){ p.y=0.94; p.vy=-Math.abs(p.vy); }
        ball(c, mx+p.x*ww, zy+p.y*zh, 8, 0, heatCol(lvB)); });
      c.strokeStyle="#3a414c"; c.lineWidth=2; c.beginPath(); c.moveTo(bx(zy),zy); edge(); c.stroke();
      if(moving) this.flow(c, mx-50, zy+zh/2, mx+56, zy+zh/2, st.P, this.ph, 11, true);
      c.restore();
      T(c,"境目を拡大（鉄の粒子 ｜ 液体の分子）", zx+4, zy-9, {size:10.5, col:COL.sub});
    }
    if(u>=1 && this.ts()>=this.tEnd-1e-6 && !this.lid) T(c,"熱平衡", vx+vw/2, vy+(hc?28:16), {size:13, bold:true, col:"#1c8f4a", align:"center", halo:true});
  },
  drawGraph:function(c, gx0, gy0, gx1, gy1, st){
    var self=this, Tmax=100, Tmin=0, tmax=Math.max(1e-6,this.tEnd)*1.03, hc=this.hasC();
    var X=function(t){ return gx0+(gx1-gx0-14)*t/tmax; }, Y=function(T){ return gy0-(gy0-gy1-14)*(T-Tmin)/(Tmax-Tmin); };
    c.save(); c.strokeStyle="#e6e1d7"; c.lineWidth=1; for(var v=20; v<=Tmax+1e-6; v+=20){ c.beginPath(); c.moveTo(gx0,Y(v)); c.lineTo(gx1-14,Y(v)); c.stroke(); T(c,String(v),gx0-5,Y(v),{size:10,col:COL.sub,align:"right"}); } c.restore();
    var xs=niceStep(tmax,5); if(this.tEnd>0) for(var tt=xs; tt<tmax-xs*0.75; tt+=xs) T(c, String(Math.round(tt)), X(tt), gy0+10, {size:10, col:COL.sub, align:"center"});
    axes(c, gx0, gy0, gx1, gy1, "時間〔s〕", "温度〔℃〕");
    if(!this.lid){ var tf=this.Tf(); c.save(); c.setLineDash([5,4]); c.strokeStyle="#1c8f4a"; c.lineWidth=1.3; c.beginPath(); c.moveTo(gx0,Y(tf)); c.lineTo(gx1-14,Y(tf)); c.stroke(); c.restore();
      T(c,"熱平衡の温度 "+tf.toFixed(1)+" ℃", gx1-16, Y(tf)-9, {size:10.5, col:"#1c8f4a", align:"right", halo:true}); }
    else { c.save(); c.setLineDash([2,4]); c.strokeStyle="#8b949d"; c.beginPath(); c.moveTo(gx0,Y(this.TR)); c.lineTo(gx1-14,Y(this.TR)); c.stroke(); c.restore(); T(c,"室温 "+this.TR+" ℃", gx1-16, Y(this.TR)+10, {size:10.5, col:COL.sub, align:"right"}); }
    var n=Math.min(this.H.length-1, Math.floor(st.t/0.05)), step=Math.max(1,Math.floor(this.H.length/400));
    var line=function(k,col,w){ c.save(); c.strokeStyle=col; c.lineWidth=w||2.6; c.beginPath(); for(var i=0;i<=n;i+=step){ var p=self.H[i]; if(i) c.lineTo(X(p[0]),Y(p[k])); else c.moveTo(X(p[0]),Y(p[k])); } var q=self.H[n]; c.lineTo(X(q[0]),Y(q[k])); c.stroke(); c.restore(); };
    if(hc) line(3,this.COLC,2.2);
    line(1,this.COLA); line(2,this.COLB);
    var up=(this.TA0>=this.TB0);
    T(c,"鉄", X(0)+6, Y(this.TA0)+(up? -10 : 12), {size:12, bold:true, col:this.COLA});
    T(c,this.sub().name, X(0)+6, Y(this.TB0)+(up? 12 : -10), {size:12, bold:true, col:this.COLB});
    if(hc) T(c,"銅の容器", X(0)+6, Y(this.TB0)+(up? 26 : -24), {size:11.5, bold:true, col:this.COLC});
  }
};
