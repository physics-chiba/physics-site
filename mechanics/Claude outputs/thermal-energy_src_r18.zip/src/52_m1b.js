/* =========================================================================
   モード① 物質と比熱（1-4・1-5）
   ========================================================================= */

/* ---------------- ①-4 比熱 ----------------
   左：水 1.0 kg、右：えらんだ物質。同じバーナーで同じ熱量 Q を加える。 */
/* 比熱の小さい順（スライダーの左が小さく、右が大きい）。いちばん右は水（左と同じ物質で比べられる） */
var SUBS = [
  {name:"銀", sh:"銀", c:0.235, fill:"#e3e6ea"}, {name:"銅", sh:"銅", c:0.384, fill:"#e8b48a"}, {name:"鉄", sh:"鉄", c:0.448, fill:"#c9ccd1"},
  {name:"コンクリート", sh:"コン", c:0.8, fill:"#d8d4cc"}, {name:"アルミニウム", sh:"アルミ", c:0.902, fill:"#e6e9ee"}, {name:"木材", sh:"木材", c:1.3, fill:"#ecd2a4"},
  {name:"菜種油", sh:"油", c:2.04, fill:"#f6e7a8", liq:1}, {name:"海水", sh:"海水", c:3.93, fill:"#cfe6f5", liq:1}, {name:"水", sh:"水", c:4.18, fill:"#d4ebf9", liq:1}
];
/* 比熱のスライダーの下の目盛り（物質の名前） */
function cTicks(list){ return '<div class="cticks">'+list.map(function(d){ return '<span'+(d.name==="水"?' class="w"':'')+'>'+d.sh+'</span>'; }).join('')+'</div>'; }
var S14 = {
  CW:4.18, T0:20, RATE:2000, QMAX:60000,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.si=2; this.m=1.0; this.Q=0; this.clk=0;
    this.run=new Runner({
      startText:"▶ スタート（加熱する）",
      step:function(dt){ self.clk+=dt; self.Q=Math.min(self.Qstop(), self.RATE*self.run.t); return self.Q>=self.Qstop(); },
      draw:function(){ self.draw(); },
      reset:function(){ self.Q=0; },
      info:function(){ return ''; }
    });
    this.run.bind(sec);
    this.sg=wireSlider(sec,"sub",function(v){ var d=SUBS[Math.round(v)]; return d.name+"　比熱 "+d.c+" J/(g·K)"; },function(v){ self.si=Math.round(v); self.run.reset(); });
    this.mg=wireSlider(sec,"mass",function(v){ return "質量　"+v.toFixed(1)+" kg"+(Math.abs(v-1)<1e-6? "（水と同じ）" : ""); },function(v){ self.m=v; self.run.reset(); });
    this.tb=wireTimeBar(sec, this.run, function(){ return self.Qstop()/self.RATE; }, function(t){ self.Q=Math.min(self.Qstop(), self.RATE*t); });
    this.og=objGrid(sec);   /* 第18回：熱平衡（s15）と同じ並べ方。物体ごとの箱から図の物体へ点線 */
    this.boxes=[].slice.call(sec.querySelectorAll(".ogbox"));
    /* 第18回：初めの温度のスライダー。2 つは「同じ温度からスタート」なので、どちらを動かしても両方が同じ温度になる（0〜60 ℃） */
    var setT=function(v){ v=clamp(v,0,60); self.T0=v; self.wa.set(v); self.wb.set(v); self.run.reset(); };
    this.wa=wireTemp(sec,"ta",setT); this.wb=wireTemp(sec,"tb",setT);
    sec.querySelector(".resetall").addEventListener("click", function(){ self.si=2; self.m=1.0; self.sg.set(2); self.mg.set(1); setT(20); self.run.rate=1;
      var sb=sec.querySelector(".slowb"); if(sb) sb.classList.remove("on"); self.run.reset(); });
    var anim=function(){ if(self.sec.offsetParent!==null && self.run.state!=="run"){ self.clk+=0.016; self.draw(); } requestAnimationFrame(anim); };
    onResize(this.cv.parentElement, function(){ self.draw(); });
    this.draw(); requestAnimationFrame(anim);
  },
  sub:function(){ return SUBS[this.si]; },
  /* 2 つの物質の温度と時間のグラフ（1 つにまとめる。色は物体のわくと同じ） */
  drawTT:function(c, gx0, gy0, gx1, gy1, tEnd, tNow, C){
    var self=this, X=function(t){ return gx0+(gx1-gx0-12)*t/tEnd; }, Y=function(T){ return gy0-(gy0-gy1-10)*T/100; };
    c.save(); c.strokeStyle="rgba(58,65,76,.10)"; c.lineWidth=1;
    for(var v=20; v<=100; v+=20){ c.beginPath(); c.moveTo(gx0,Y(v)); c.lineTo(gx1-12,Y(v)); c.stroke(); T(c,String(v),gx0-5,Y(v),{size:9.5,col:COL.sub,align:"right"}); }
    c.restore();
    axes(c, gx0, gy0, gx1, gy1);
    T(c,"温度〔℃〕", gx0+6, gy1-4, {size:10.5, col:COL.sub});
    T(c,"時間", gx1, gy0+12, {size:10.5, col:COL.sub, align:"right"});
    for(var i=0;i<2;i++){ var Ti=function(t){ return self.T0+self.RATE*t/C[i]; };
      c.save(); c.strokeStyle=this.COLS[i]; c.lineWidth=2.8; c.beginPath(); c.moveTo(X(0),Y(Ti(0))); c.lineTo(X(tNow),Y(Ti(tNow))); c.stroke();
      c.fillStyle=this.COLS[i]; c.beginPath(); c.arc(X(tNow),Y(Ti(tNow)),4.5,0,7); c.fill(); c.restore();
      if(tNow>0){ var other=self.T0+self.RATE*tNow/C[1-i], up=(Ti(tNow)>=other);
        T(c, i? this.sub().sh : "水", X(tNow)+7, Y(Ti(tNow))+(up? -9 : 11), {size:11, bold:true, col:this.COLS[i], halo:true}); } }
  },

  Cs:function(){ return [1000*this.CW, this.m*1000*this.sub().c]; },        /* 熱容量 C＝mc［J/K］ */
  Qstop:function(){ var C=this.Cs(); return Math.max(1, Math.min(this.QMAX, (100-this.T0)*Math.min(C[0],C[1]))); },   /* 熱い方が 100 ℃ になったら止める */
  /* 第9回：1-5 と同じ 3 列。左＝水（青）｜まん中＝比べる物質（茶）｜右＝2 つの物質の T-t グラフ（1 つにまとめる）。
     操作は、それぞれの物質の真上（左の説明・右のスライダー）と、グラフの真上（スタート類・時間バー）に置く（colGrid） */
  COLS:["#1f6fb2","#b5651d"],
  draw:function(){
    var self=this, wide=(this.cv.parentElement.clientWidth>=760);
    var f=fitCanvas(this.cv, function(W){ return wide? clamp(W*0.24, 280, 320) : clamp(W*1.25, 470, 560);   /* 第10回：上の空白をなくす */ }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H); if(this.tb) this.tb.sync();
    var C=this.Cs(), names=["水", this.sub().name], ms=[1.0,this.m], cs=[this.CW,this.sub().c], fills=["#d4ebf9",this.sub().fill];
    var on=(this.run.state==="run"), tEnd=this.Qstop()/this.RATE, tNow=this.Q/this.RATE;
    var c1=W*0.31, c2=W*0.62, figH=wide? H : H*0.52;
    var E=[]; this.anc=[];   /* 第17回：2 つの物体の左右のはし（スタート前の「同じ温度」の位置に使う） */
    for(var i=0;i<2;i++){
      var R = wide? {x:(i? c1 : 0), w:(i? c2-c1 : c1)} : {x:i*W/2, w:W/2};
      var cx=R.x+R.w/2-6, yDesk=figH-12;
      var bw0=Math.min(130, R.w*0.52), sc=(i? Math.cbrt(this.m) : 1), bw=bw0*sc, bh=bw0*0.72*sc, bx=cx-bw/2, by=yDesk-62-bh;
      E.push({l:bx, r:bx+bw, y:by+bh/2});
      var Tn=this.T0+this.Q/C[i], lv=clamp((Tn-10)/80,0,1);
      burner(c, cx, yDesk, on, this.clk+i*0.37, 0.85);
      c.save(); c.fillStyle="#95a5a6"; c.fillRect(cx-bw0*0.7, yDesk-62, bw0*1.4, 6); c.restore();
      c.save(); c.strokeStyle="#7f8a8a"; c.lineWidth=3.5; c.beginPath(); c.moveTo(cx-bw0*0.62,yDesk-56); c.lineTo(cx-bw0*0.72,yDesk); c.moveTo(cx+bw0*0.62,yDesk-56); c.lineTo(cx+bw0*0.72,yDesk); c.stroke(); c.restore();
      var isL=(i===0 || this.sub().liq);
      /* 第15回：液体（水・油・海水）はビーカーに入れ、粒子は格子にならべず動きまわらせる */
      if(isL){ c.save(); c.fillStyle=fills[i]; c.fillRect(bx+1,by+8,bw-2,bh-9); c.strokeStyle=this.COLS[i]; c.lineWidth=1.5; c.beginPath(); c.moveTo(bx+1,by+8); c.lineTo(bx+bw-1,by+8); c.stroke(); c.restore();
        beakerGlass(c, bx, by-6, bw, bh+6);
        if(!this.lq) this.lq=[{},{}];
        liquidParticles(c, this.lq[i], bx+5, by+11, bw-32, bh-15, lv, this.clk, {n:(sc>1.1? 12 : (sc<0.85? 5 : 8)), r:Math.min(8, bw/16), k0:i*20}); }
      else { c.save(); c.fillStyle=fills[i]; c.strokeStyle=this.COLS[i]; c.lineWidth=2.2; c.fillRect(bx,by,bw,bh); c.strokeRect(bx,by,bw,bh); c.restore(); }
      if(!isL) latticeParticles(c, bx+6, by+6, bw-34, bh-12, lv, this.clk+i*0.7, {nx:(sc>1.1? 4 : 3), ny:(sc>1.1? 3 : 2), r:Math.min(8, bw/16), a0:1.0, a1:6, k0:i*20});
      thermometer(c, bx+bw-14, by+bh-14, by-54, Tn, 0, 100, {ticks:[0,50,100], noNum:true, dec:1});
      var wn=T(c, names[i]+"　"+ms[i].toFixed(1)+" kg", cx-8, by-40, {size:13.5, bold:true, col:this.COLS[i], align:"center", halo:true});
      this.anc[i]={x:cx-8, y:by-50, col:this.COLS[i]};
      T(c, "比熱 "+cs[i]+" J/(g·K)", cx-8, by-22, {size:11, col:COL.sub, align:"center", halo:true});
      T(c, Tn.toFixed(1)+" ℃", bx+bw-14, by-64, {size:12, bold:true, col:"#c0392b", align:"center", halo:true});
    }
    /* 第17回：スタート前は、2 つの物体の真ん中に「同じ温度／20.0 ℃からスタート」 */
    if(this.run.state==="idle" && this.Q<=0){
      var mx=(E[0].r+E[1].l)/2-6, my=E[0].y, gap=E[1].l-E[0].r;
      var L3=["同じ温度", this.T0.toFixed(1)+" ℃からスタート"];
      if(gap<170){ mx=W/2; my=29; L3=["同じ温度　"+this.T0.toFixed(1)+" ℃からスタート"]; }   /* せまい画面：2 つの物体の間に入らないので、2 つの真ん中の上に 1 行で */
      L3.forEach(function(s,k){ T(c, s, mx, my+(k-(L3.length-1)/2)*19, {size:13.5, bold:true, col:"#c0392b", align:"center", halo:true}); });
    }
    if(wide) this.drawTT(c, c2+34, H-26, W-14, 30, tEnd, tNow, C);
    else this.drawTT(c, 40, H-26, W-14, figH+30, tEnd, tNow, C);
    T(c,"同じバーナーで、同じ熱量を加える", wide? c2/2 : W/2, 10, {size:10.5, col:COL.sub, align:"center", halo:true});
    notebook(c,W,H);
    /* 第18回：箱の見出し・温度のスライダーのつまみ・点線 */
    var hb=this.sub().name+(this.sub().liq? "" : "")+"<small>比べる物質</small>"; var e=this.boxes[1].querySelector(".oghead"); if(e._h!==hb){ e._h=hb; e.innerHTML=hb; }
    var live=(this.Q>0);
    this.wa.show(this.T0+this.Q/C[0], live); this.wb.show(this.T0+this.Q/C[1], live);
    if(this.og){ this.og.set(this.cv, [c1,c2], wide); this.og.links(this.cv, this.anc, wide); }
    var dT=[this.Q/C[0], this.Q/C[1]];
    var mh='加えた熱量 '+tex("Q")+' = <span class="num">'+(this.Q/1000).toFixed(1)+'</span> kJ　'+
      '水：'+tex("\\Delta T")+' = <span class="num">'+dT[0].toFixed(1)+'</span> K　／　'+this.sub().name+'：'+tex("\\Delta T")+' = <span class="num">'+dT[1].toFixed(1)+'</span> K'+
      '<br>熱容量 '+tex("C=mc")+'：水 <span class="num">'+(C[0]/1000).toFixed(2)+'</span> kJ/K　／　'+this.sub().name+' <span class="num">'+(C[1]/1000).toFixed(2)+'</span> kJ/K';
    if(this._mh!==mh){ this._mh=mh; this.msg.innerHTML=mh; }
  }
};

