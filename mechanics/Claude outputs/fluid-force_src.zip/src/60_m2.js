/* =========================================================================
   モード② 気体から受ける力
   ========================================================================= */
function pAir(z){ return P0*Math.exp(-z/HSC); }
function rhoAir(z){ return RHO_A0*Math.exp(-z/HSC); }
function skyFill(c, x0, x1, Yf, z0, z1){
  var n=24;
  for(var i=0;i<n;i++){ var za=z0+(z1-z0)*i/n, zb=z0+(z1-z0)*(i+1)/n, r=rhoAir((za+zb)/2)/RHO_A0;
    var lt=Math.round(250-95*r), g2=Math.round(252-60*r);
    c.fillStyle="rgb("+lt+","+g2+",255)"; c.fillRect(x0, Yf(zb), x1-x0, Yf(za)-Yf(zb)+0.6); }
}
function heightRuler(c, x, Yf, zmax){
  c.save(); c.strokeStyle="#69717d"; c.lineWidth=1; c.beginPath(); c.moveTo(x,Yf(0)); c.lineTo(x,Yf(zmax)); c.stroke();
  for(var k=0;k<=10;k++){ var y=Yf(k*1000); c.beginPath(); c.moveTo(x-(k%5===0?7:4),y); c.lineTo(x,y); c.stroke();
    if(k%5===0) T(c, k+" km", x-9, y, {size:10.5,col:COL.sub,align:"right"}); }
  arrow(c, x, Yf(0), x, Yf(zmax)-4, "#69717d", 1, 7);
  T(c,"高さ", x+4, Yf(zmax)+4, {size:10.5,col:COL.sub});
  c.restore();
}
function mountain(c, x, Yf, w){
  var top=Yf(3776), b=Yf(0);
  c.save(); c.fillStyle="#9aa69a"; c.beginPath(); c.moveTo(x-w,b); c.lineTo(x-w*0.12,top); c.lineTo(x+w*0.12,top); c.lineTo(x+w,b); c.closePath(); c.fill();
  c.fillStyle="#f6f8fa"; c.beginPath(); c.moveTo(x-w*0.12,top); c.lineTo(x+w*0.12,top); c.lineTo(x+w*0.3,top+(b-top)*0.18); c.lineTo(x-w*0.3,top+(b-top)*0.18); c.closePath(); c.fill(); c.restore();
  T(c,"富士山の山頂（約 3.8 km・約 630 hPa）", x, top-9, {size:10,col:COL.sub,align:"center",halo:true});
}
function plane(c, x, y){
  c.save(); c.fillStyle="#69717d"; c.translate(x,y);
  c.beginPath(); c.ellipse(0,0,16,3,0,0,7); c.fill();
  c.beginPath(); c.moveTo(-2,0); c.lineTo(-9,-10); c.lineTo(-5,-10); c.lineTo(5,0); c.closePath(); c.fill();
  c.beginPath(); c.moveTo(-12,0); c.lineTo(-16,-6); c.lineTo(-13,-6); c.lineTo(-9,0); c.closePath(); c.fill();
  c.restore();
}

/* ---------------- ②-1 大気圧 ---------------- */
var S21 = {
  ZM:10600,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.z=0; this.col=false; this.mol=false; this.mols=[]; this.shape="box";
    for(var i=0;i<420;i++){ var z; do{ z=-HSC*Math.log(1-Math.random()); }while(z>this.ZM); this.mols.push({u:Math.random(), z:z, ph:Math.random()*7}); }
    this.run = new Runner({
      step:function(dt,r){ self.z=Math.min(10000, r.t*1250); self.sl.set(self.z/1000); return self.z>=10000; },
      draw:function(){ self.draw(); },
      reset:function(){ self.z=0; self.sl.set(0); },
      info:function(){ return '高さ <b>'+(self.z/1000).toFixed(1)+'</b> km'; }
    });
    this.run.bind(sec);
    this.sl = wireTSlider(sec,"z",function(v){ self.z=v*1000; self.run.touch(); self.draw(); self.run.label(); });
    this.cc=wireChk(sec,"col",function(on){ self.col=on; self.draw(); });
    this.cm=wireChk(sec,"mol",function(on){ self.mol=on; self.anim(); self.draw(); });
    this.sg=wireSeg(sec,"shape",function(v){ self.shape=v; self.draw(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.col=false; self.mol=false; self.cc.set(false); self.cm.set(false); self.shape="box"; self.sg.set("box"); self.run.reset(); self.sl.set(0); });
    bindDrag(this.cv, function(x,y){ var g=self.g; return g && Math.abs(x-g.xo)<36 && Math.abs(y-g.yc)<g.bh/2+14; },
      function(x,y){ var g=self.g; self.z=clamp(g.Z(y+g.bh/2+g.lift), 0, 10000); self.sl.set(self.z/1000); self.run.touch(); self.draw(); self.run.label(); }, null, function(){ return self.run.state!=="run"; });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    this.draw();
  },
  anim:function(){
    var self=this; if(this._raf) return;
    var loop=function(){ if(!self.mol || self.sec.offsetParent===null){ self._raf=0; return; }
      self.mols.forEach(function(m){ m.ph+=0.25; }); if(self.run.state!=="run") self.draw(); self._raf=requestAnimationFrame(loop); };
    this._raf=requestAnimationFrame(loop);
  },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return clamp(W*0.78, 320, 430); }), c=f.c, W=f.W, H=f.H;
    var x0=52, x1=W-8, yB=H-16, yT=10, s=(yB-yT)/this.ZM;
    var Y=function(z){ return yB-z*s; };
    var ball=(this.shape==="ball"), bw=36, bh=ball? 64 : 84, xo=x0+(x1-x0)*0.36;
    /* 物体の中心は、高さ 0〜10 km を「地面の少し上〜図の上はしの少し下」に割りふって置く（矢印と手が図からはみ出さない） */
    var ycMax=Y(0)-bh/2-58, ycMin=yT+bh/2+58, lift=0;
    var ycOf=function(z){ return ycMax-(ycMax-ycMin)*z/10000; };
    this.g={Y:Y, Z:function(yy){ return (ycMax-(yy-bh/2))/(ycMax-ycMin)*10000; }, xo:xo, bh:bh, lift:lift};
    c.clearRect(0,0,W,H);
    skyFill(c, x0, x1, Y, 0, this.ZM);
    mountain(c, x0+(x1-x0)*0.80, Y, Math.min(90,(x1-x0)*0.17));
    plane(c, x0+(x1-x0)*0.80, Y(10000));
    T(c,"旅客機（約 10 km・約 260 hPa）", x0+(x1-x0)*0.80-22, Y(10000)+14, {size:10,col:COL.sub,align:"center",halo:true});
    if(this.mol){ c.save(); c.fillStyle="rgba(31,78,121,.55)";
      this.mols.forEach(function(m){ var x=x0+4+(x1-x0-8)*((m.u+0.004*Math.sin(m.ph*1.7))%1), y=Y(m.z)+2.2*Math.sin(m.ph); c.beginPath(); c.arc(x,y,1.5,0,7); c.fill(); }); c.restore(); }
    ground(c, x0, x1, Y(0));
    heightRuler(c, x0-6, Y, this.ZM);
    var yc=ycOf(this.z); this.g.yc=yc;
    /* 目盛りの上に、いまの高さの印（▶） */
    c.save(); c.fillStyle="#e07b18"; c.beginPath(); c.moveTo(x0-6,Y(this.z)); c.lineTo(x0-14,Y(this.z)-5); c.lineTo(x0-14,Y(this.z)+5); c.closePath(); c.fill(); c.restore();
    if(this.col){ c.save(); c.fillStyle="rgba(47,111,159,.14)"; c.fillRect(xo-bw/2, yT, bw, yc-bh/2-yT);
      c.setLineDash([5,4]); c.strokeStyle=COL.dashed; c.lineWidth=1.4; c.strokeRect(xo-bw/2, yT, bw, yc-bh/2-yT); c.restore();
      if(yc-bh/2-yT>60) T(c,"上にのっている空気の柱", xo+bw/2+6, yT+18, {size:11.5,col:COL.dashed,bold:true,halo:true}); }
    /* 第7回：矢印の長さは、その矢印の位置の高さ（物体を目盛りどおりの大きさとみなす）の気圧に比例させる。
       こうすると、上の面と下の面の差が目に見える。物体の中心の高さを this.z とする */
    var zAt=function(y){ return self.z + (yc-y)/s; }, LB=46, LEN=function(y){ return LB*pAir(zAt(y))/P0; };
    var gp=3, withHand=(this.run.state!=="idle"), r=bh/2;
    c.save(); c.fillStyle="#fff"; c.strokeStyle="#2b323c"; c.lineWidth=1.6;
    if(ball){ c.beginPath(); c.arc(xo,yc,r,0,7); c.fill(); c.stroke(); }
    else { c.fillRect(xo-bw/2,yc-bh/2,bw,bh); c.strokeRect(xo-bw/2,yc-bh/2,bw,bh); }
    c.restore();
    /* スタート後：手が物体の右下をつかんで、上へ運ぶ（矢印はこのあと上書き） */
    if(withHand){ if(ball) pullHand(c, xo+r*0.71, yc+r*0.71); else pullHand(c, xo+bw/2, yc+bh/2); }
    var Ltop, Lbot;
    if(ball){
      for(var k=0;k<12;k++){ var th=k*Math.PI/6, nx=Math.cos(th), ny=Math.sin(th), px=xo+r*nx, py=yc+r*ny, L=LEN(py);
        arrow(c, px+nx*(gp+L), py+ny*(gp+L), px+nx*gp, py+ny*gp, COL.press, 1.9, 7); }
      Ltop=LEN(yc-r); Lbot=LEN(yc+r);
    } else {
      Ltop=LEN(yc-bh/2); Lbot=LEN(yc+bh/2);
      [-0.25,0.25].forEach(function(o){ var x=xo+o*bw;
        arrow(c, x, yc-bh/2-gp-Ltop, x, yc-bh/2-gp, COL.press, 1.9, 7);
        arrow(c, x, yc+bh/2+gp+Lbot, x, yc+bh/2+gp, COL.press, 1.9, 7); });
      [-3/8,-1/8,1/8,3/8].forEach(function(o){ var y=yc+o*bh, L=LEN(y);
        arrow(c, xo-bw/2-gp-L, y, xo-bw/2-gp, y, COL.press, 1.9, 7);
        arrow(c, xo+bw/2+gp+L, y, xo+bw/2+gp, y, COL.press, 1.9, 7); });
    }
    var L=LEN(yc), half=ball? r : bw/2;
    var hpa=pAir(this.z)/100;
    T(c, Math.round(hpa)+" hPa", xo-half-L-12, yc, {size:13,bold:true,col:COL.press,halo:true,align:"right"});
    if(!withHand) dragHint(c,"ドラッグ", xo+half+L+10, yc-bh/2-4, {size:11});
    T(c,"物体は大きく描いています", x1-4, Y(0)-10, {size:10,col:COL.sub,align:"right",halo:true});
    notebook(c,W,H);
    var top=(ball? yc-r : yc-bh/2), bot=(ball? yc+r : yc+bh/2);
    this.msg.innerHTML='高さ <span class="num">'+(this.z/1000).toFixed(1)+'</span> km の大気圧：<span class="num">'+sci(pAir(this.z),3)+'</span> Pa（<span class="num">'+Math.round(hpa)+'</span> hPa）　地上の <span class="num">'+Math.round(pAir(this.z)/P0*100)+'</span> %<br>'+
      '上の面 <span class="num">'+Math.round(pAir(zAt(top))/100)+'</span> hPa　＜　下の面 <span class="num">'+Math.round(pAir(zAt(bot))/100)+'</span> hPa（物体を目盛りどおりの大きさとみなした値）';
  }
};

/* ---------------- ②-2 大気による浮力 ---------------- */
var S22 = {
  ZM:10600, V:0.014, R:0.15, TS:600,
  GAS:{he:{name:"ヘリウム風船", m:0.0075, fill:"#ffffff", line:"#5a7fa6"}, air:{name:"空気を入れた風船", m:0.005+RHO_A0*0.014, fill:"#dfe3e8", line:"#69717d"}},
  init:function(sec){
    var self=this; this.sec=sec;
    this.cvA=sec.querySelector('canvas[data-v="a"]'); this.cvB=sec.querySelector('canvas[data-v="b"]'); this.cvC=sec.querySelector('canvas[data-v="c"]');
    this.cv=sec.querySelector("canvas.main"); this.tab=sec.querySelector(".forcetab"); this.msg=sec.querySelector(".msgbox");
    this.gas="he"; this.view="a"; this.z0=0; this.z=0;
    this.run = new Runner({
      begin:function(){ self.z0=self.z; },
      step:function(dt,r){ return self.step(dt,r); },
      draw:function(){ self.drawAll(); },
      reset:function(){ self.z=self.z0; },
      info:function(r){ return '高さ <b>'+(self.z/1000).toFixed(2)+'</b> km'; }
    });
    this.run.bind(sec.querySelector(".fcell.live"));
    sec.querySelectorAll(".fcell.pick").forEach(function(el){
      var go=function(){ self.view=el.dataset.v; sec.querySelectorAll(".fcell.pick").forEach(function(x){ x.classList.toggle("on", x===el); x.setAttribute("aria-pressed", x===el); }); self.drawAll(); };
      el.addEventListener("click", go); el.addEventListener("keydown", function(ev){ if(ev.key==="Enter"||ev.key===" "){ ev.preventDefault(); go(); } });
    });
    /* 第9回：中身はスライダーで選ぶ（左ほど密度が小さい） */
    this.seg=wireSlider(sec,"gas",function(v){ return Math.round(v)? "空気　1.2 kg/m³" : "ヘリウム　0.17 kg/m³"; },function(v){ self.gas=Math.round(v)? "air" : "he"; self.run.touch(); if(self.run.state==="idle") self.z=self.z0; self.drawAll(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.gas="he"; self.seg.set(0); self.view="a";
      sec.querySelectorAll(".fcell.pick").forEach(function(x){ x.classList.toggle("on", x.dataset.v==="a"); });
      self.run.rate=1; var sb=sec.querySelector(".slowb"); if(sb) sb.classList.remove("on"); self.z0=0; self.run.reset(); });
    bindDrag(this.cv, function(x,y){ var g=self.g; return g && Math.hypot(x-g.xo, y-g.yc)<g.r+14; },
      function(x,y){ var g=self.g; self.z=clamp(g.Z(y+g.r+2), 0, 10000); self.z0=self.z; self.run.touch(); self.drawAll(); }, null,
      function(){ return self.run.state!=="run"; });
    [this.cvA,this.cvB,this.cvC,this.cv].forEach(function(cv){ onResize(cv.parentElement, function(){ self.drawAll(); }); });
    this.drawAll();
  },
  m:function(){ return this.GAS[this.gas].m; },
  /* 力の縮尺：中身を変えても変わらない（いちばん大きくなる力で決める） */
  Fref:function(){ return Math.max(this.GAS.air.m*G, this.GAS.he.m*G, RHO_A0*this.V*G); },
  forces:function(){ var W=this.m()*G, F=rhoAir(this.z)*this.V*G, N=(this.z<=0.5)? Math.max(0,W-F):0; return {W:W,F:F,N:N,net:F+N-W}; },
  step:function(dt,r){
    var n=20, h=dt*this.TS/n;
    for(var k=0;k<n;k++){
      var net=rhoAir(this.z)*this.V*G - this.m()*G, cd=0.5*0.47*rhoAir(this.z)*Math.PI*this.R*this.R;
      var v=(net>=0?1:-1)*Math.sqrt(Math.abs(net)/cd);
      this.z=clamp(this.z+v*h, 0, 10400);
    }
    var fo=this.forces();
    if(r.t>0.3 && (Math.abs(fo.net)<4e-4 || (this.z<=0 && fo.net<=1e-6))) return true;
    return r.t>25;
  },
  drawAll:function(){ this.drawSmall(this.cvA,"a"); this.drawSmall(this.cvB,"b"); this.drawSmall(this.cvC,"c"); this.drawD(); },
  balloon:function(c, x, y, r, dash){
    var gs=this.GAS[this.gas];
    c.save();
    if(dash){ c.fillStyle="rgba(47,111,159,.16)"; c.beginPath(); c.arc(x,y,r,0,7); c.fill(); c.setLineDash([5,4]); c.strokeStyle=COL.dashed; c.lineWidth=1.6; c.stroke(); c.restore(); return; }
    c.strokeStyle="#555"; c.lineWidth=1; c.beginPath(); c.moveTo(x,y+r); c.quadraticCurveTo(x+r*0.25,y+r*1.5,x,y+r*1.95); c.stroke();
    var gr=c.createRadialGradient(x-r*0.35,y-r*0.4,r*0.1,x,y,r); gr.addColorStop(0,"#fff"); gr.addColorStop(0.25,gs.fill); gr.addColorStop(1,gs.line);
    c.fillStyle=gr; c.beginPath(); c.arc(x,y,r,0,7); c.fill(); c.strokeStyle=gs.line; c.lineWidth=1.2; c.stroke();
    c.restore();
  },
  drawSmall:function(cv, v){
    var f=fitCanvas(cv, function(W){ return clamp(W*0.92,130,250); }), c=f.c, W=f.W, H=f.H, self=this;
    c.clearRect(0,0,W,H);
    var rr=rhoAir(this.z)/RHO_A0, lt=Math.round(250-95*rr), g2=Math.round(252-60*rr);
    c.fillStyle="rgb("+lt+","+g2+",255)"; c.fillRect(0,0,W,H);
    var x=W/2, y=H*0.46, r=W*0.2, fo=this.forces();
    T(c,"高さ "+(this.z/1000).toFixed(1)+" km", 6, 11, {size:10.5,col:COL.sub});
    if(v==="a"){
      this.balloon(c,x,y,r);
      var X=20000, n=12, L0=W*0.1;
      for(var i=0;i<n;i++){ var a=(i+0.5)/n*Math.PI*2, ny=Math.sin(a), dp=rhoAir(this.z)*G*this.R*ny, L=L0*(1+X*dp/P0);   // 下ほど大きい（y は下向き）
        arrow(c, x+(r+3+L)*Math.cos(a), y+(r+3+L)*ny, x+(r+3)*Math.cos(a), y+(r+3)*ny, COL.press, 1.8, 7); }
      T(c,"上下の差を 2 万倍に強調", W/2, H-8, {size:10,align:"center",col:COL.sub,halo:true});
    } else if(v==="b"){
      this.balloon(c,x,y,r);
      var k=(H*0.3)/this.Fref();
      fArrow(c, x-5, y, x-5, y-fo.F*k, COL.buoy, 3, 11); SYM(c,"F",null,x-9,y-fo.F*k+4,{size:14,col:COL.buoy,bold:true,align:"right",halo:true});
      fArrow(c, x+5, y, x+5, y+fo.W*k, COL.grav, 3, 11); SYM(c,"mg",null,x+5,y+fo.W*k+11,{size:14,col:COL.grav,bold:true,align:"center",halo:true});
    } else {
      this.balloon(c,x,y,r,true);
      T(c,"同じ体積の空気", x, y, {size:10.5,align:"center",col:"#1f4e79",bold:true});
      var k2=(H*0.3)/this.Fref();
      fArrow(c, x-r-8, y, x-r-8, y-fo.F*k2, COL.buoy, 2.6, 10); SYM(c,"F",null,x-r-12,y-fo.F*k2+4,{size:14,col:COL.buoy,bold:true,align:"right",halo:true});
      fArrow(c, x+r+8, y, x+r+8, y+fo.F*k2, COL.grav, 2.6, 10); T(c,"ρ空気Vg", x+r+8, y+fo.F*k2+11, {size:11,col:COL.grav,bold:true,halo:true,align:"center"});
      eqTicks(c, x-r-8, y, x-r-8, y-fo.F*k2, 1, COL.buoy); eqTicks(c, x+r+8, y, x+r+8, y+fo.F*k2, 1, COL.grav);
    }
  },
  drawD:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return clamp(W*0.95, 280, 430); }), c=f.c, W=f.W, H=f.H;
    var x0=48, x1=W-8, yB=H-16, yT=10, s=(yB-yT)/this.ZM, Y=function(z){ return yB-z*s; };
    /* 風船は大きく描いているので、地面の近くでは地面から少し浮かせて描く（手と mg が地面に重ならない）。
       3 km より上では、風船の中心がちょうど高さの目盛りの位置に来る（つりあう高さの破線とも一致） */
    var r=clamp(W*0.045,13,20), xo=x0+(x1-x0)*0.42, OFF=r*2.2+34, Z1=3000;
    var yOf=function(z){ return Y(z) - OFF*(1-Math.min(1, Math.max(0,z)/Z1)); };
    var yc=yOf(this.z);
    this.g={xo:xo, yc:yc, r:r};
    this.g.Z=function(yp){ var y=yp-r-2, lo=0, hi=self.ZM;   /* yOf の逆（二分法）。yp＝つかんだ点＋半径 */
      if(y>=yOf(0)) return 0;
      for(var i=0;i<40;i++){ var m=(lo+hi)/2; if(yOf(m)>y) lo=m; else hi=m; } return (lo+hi)/2; };
    c.clearRect(0,0,W,H);
    skyFill(c, x0, x1, Y, 0, this.ZM);
    /* 地上の家・木・人（ここが空の中だと分かるように） */
    var gw=x1-x0;
    houseShape(c, x0+gw*0.78, Y(0), clamp(gw*0.12,30,52));
    treeShape(c, x0+gw*0.92, Y(0), clamp(gw*0.08,22,36));
    treeShape(c, x0+gw*0.12, Y(0), clamp(gw*0.07,20,32));
    stickPerson(c, x0+gw*0.27, Y(0), clamp(gw*0.075,22,34));
    ground(c, x0, x1, Y(0));
    heightRuler(c, x0-6, Y, this.ZM);
    var fo=this.forces();
    if(this.gas==="he"){ var ze=HSC*Math.log(RHO_A0*this.V/this.m()); c.save(); c.setLineDash([4,4]); c.strokeStyle="rgba(20,23,28,.45)"; c.beginPath(); c.moveTo(x0,yOf(ze)); c.lineTo(x1,yOf(ze)); c.stroke(); c.restore();
      T(c,"浮力と重力がつりあう高さ（約 "+(ze/1000).toFixed(1)+" km）", x1-4, yOf(ze)-9, {size:10.5,col:COL.sub,align:"right",halo:true}); }
    this.balloon(c,xo,yc,r);   /* 右の図は (b)(c) で同じ図 */
    /* 第9回：何が「物体」で何が「気体」かを図に書きこむ */
    T(c,"物体（風船）", xo+r+10, yc-r*0.7, {size:13,bold:true,col:"#3a414c",halo:true});
    T(c,"気体（空気）", x0+8, yT+30, {size:13,bold:true,col:"#1f4e79",halo:true});
    /* スタート前：風船の糸を手が持っている → スタートを押すと消える（手をはなした）。矢印はこのあと上書き */
    if(this.run.state==="idle") hand(c, xo+3, yc+r*1.95+6, Math.PI*0.25);
    var k=(H*0.16)/this.Fref(), bal=(Math.abs(fo.net)<5e-4 && fo.N<1e-4 && this.run.state!=="run");
    if(this.view==="a"){ var n=10, L0=16;
      for(var i=0;i<n;i++){ var a=(i+0.5)/n*Math.PI*2, ny=Math.sin(a), L=L0*(pAir(this.z)/P0)*(1+20000*rhoAir(this.z)*G*this.R*ny/P0);
        arrow(c, xo+(r+2+L)*Math.cos(a), yc+(r+2+L)*ny, xo+(r+2)*Math.cos(a), yc+(r+2)*ny, COL.press, 1.7, 6); } }
    fArrow(c, xo+5, yc, xo+5, yc+fo.W*k, COL.grav, 3, 11);
    SYM(c,"mg",null,xo+5,yc+fo.W*k+12,{size:14,col:COL.grav,bold:true,halo:true,align:"center"});
    if(bal) eqTicks(c, xo+5, yc, xo+5, yc+fo.W*k, 1, COL.grav);
    if(this.view!=="a"){ fArrow(c, xo-5, yc, xo-5, yc-fo.F*k, COL.buoy, 3, 11);
      SYM(c,"F",null,xo-9,yc-fo.F*k+4,{size:14,col:COL.buoy,bold:true,halo:true,align:"right"});
      if(bal) eqTicks(c, xo-5, yc, xo-5, yc-fo.F*k, 1, COL.buoy); }
    if(this.view!=="a" && fo.N>1e-4){ var xn=xo+r*0.9; fArrow(c, xn, Y(0), xn, Y(0)-fo.N*k, COL.norm, 3, 11); SYM(c,"N",null,xn+4,Y(0)-fo.N*k,{size:14,col:COL.norm,bold:true,halo:true}); }
    T(c,"風船・人・家は大きく描いています　時間は 600 倍の早送り", x1-4, yT+10, {size:10,col:COL.sub,align:"right",halo:true});
    /* 第7回：空気を入れた風船は、スタートしても地面から動かない */
    if(this.gas==="air" && this.z<=0.5 && this.run.state!=="idle")
      T(c,"動かない", xo+r+46, yc-r*0.6, {size:22,bold:true,col:"#c0392b",halo:4});
    notebook(c,W,H);
    var row=function(kk,v,cl){ return '<tr'+(cl?' class="'+cl+'"':'')+'><td class="k">'+kk+'</td><td class="v">'+v+'</td></tr>'; };
    var dir = Math.abs(fo.net)<5e-4? "つりあい（0 N）" : (fo.net>0? "上向き "+fo.net.toFixed(3)+" N" : "下向き "+(-fo.net).toFixed(3)+" N");
    this.tab.innerHTML = row('<span style="color:'+COL.grav+'">重力 '+tex("mg")+'</span>', fo.W.toFixed(3)+" N") + row('<span style="color:'+COL.buoy+'">浮力 '+tex("F=\\rho_{\\text{空気}}Vg")+'</span>', fo.F.toFixed(3)+" N") +
      (fo.N>1e-4? row('<span style="color:'+COL.norm+'">垂直抗力 '+tex("N")+'</span>', fo.N.toFixed(3)+" N"):"") + row("合力", dir, "sum");
    this.msg.innerHTML = '高さ <span class="num">'+(this.z/1000).toFixed(2)+'</span> km の空気の密度：<span class="num">'+rhoAir(this.z).toFixed(2)+'</span> kg/m³（地上の <span class="num">'+Math.round(rhoAir(this.z)/RHO_A0*100)+'</span> %）。'+
      '<br>風船の体積 0.014 m³、'+this.GAS[this.gas].name+'の質量 <span class="num">'+(this.m()*1000).toFixed(1)+'</span> g（ゴム＋中の気体）';
  }
};
