/* =========================================================================
   ページの骨組み：ヒーロー・タブ列・章の扉・節のカード・目次・アドレス（#1-2）
   ========================================================================= */
var MODES = [
  {id:"mode1", name:"水から受ける力", en:"Forces from Water",
   lead:"水の中の物体は、周りの水から押される。その 1 m² あたりの力が<b>水圧</b>。水圧は面に垂直にはたらき、深いほど大きい。物体の上の面と下の面の水圧の差が、<b>浮力</b>になる。",
   secs:["s10","s11","s12","s13","s14"]},
  {id:"mode2", name:"気体から受ける力", en:"Forces from Air",
   lead:"空気にも重さがあるので、空気の中の物体も、周りの空気から押される（<b>大気圧</b>）。空気の中でも、水の中と同じ仕組みで浮力がはたらく。",
   secs:["s21","s22"]},
  {id:"mode3", name:"流体からの抵抗力（速度に起因）※物理本編の内容", en:"Drag Forces",
   lead:"空気や水の中を動く物体は、動きを妨げる向きに<b>抵抗力</b>を受ける。抵抗力は、速さが大きいほど大きい。",
   secs:["s31","s32","s33"]}
];
var DEFS = {
  s10:{num:1, mode:0, title:"圧力と力の違い", short:"圧力と力", sim:S10,
    headBtn: '<button class="b v3btn pglow" type="button" aria-pressed="false">３次元表示</button>',
    desc:'テーブルに吸盤を押しつけると、中の空気が押し出される。外の空気の分子は吸盤にぶつかり続け、吸盤をテーブルに押しつける。面積 1 m² あたりが受ける力が<b>圧力</b> '+tex("p")+'、面全体が受ける力が<b>力</b> '+tex("F")+'。<span class="todo">スタートで分子を動かし、スライダーで吸盤の直径を変えてみよう。</span><br>注目点：吸盤を大きくしても圧力 '+tex("p")+' は変わらないが、力 '+tex("F")+' は面積に比例して大きくなる。',
    opts: '',
    sliders: H_slider("d","吸盤の直径 $d$",2,10,2,6),
    right:function(){ return '<div class="qcard"><p class="qt">圧力と力の関係</p>'+
      '<p>面積 '+tex("S")+'［m²］の面が、面全体で大きさ '+tex("F")+'［N］の力を垂直に受けるとき、圧力 '+tex("p")+'［Pa］は</p>'+
      '<div class="qeq">'+tex("p=\\dfrac{F}{S}",true)+'</div>'+
      '<p>圧力は「1 m² あたりの力」。単位は Pa（パスカル）＝ N/m²。逆に、圧力 '+tex("p")+' の空気が面積 '+tex("S")+' の面を押す力は</p>'+
      '<div class="qeq">'+tex("F=pS",true)+'</div></div>'+
      '<div class="qcard"><p class="qt">圧力と力を区別しよう</p>'+
      '<ol class="pts"><li><b>圧力</b>は面積によらない。吸盤が大きくても小さくても、大気圧は '+tex("1.0\\times10^5")+' Pa。</li><li><b>力</b>は面積に比例する。吸盤が大きいほど、大きな力でテーブルに押しつけられる。</li></ol>'+
      '<p><b>力 '+tex("F")+' は 1 本の矢印で描く。</b>圧力の矢印は面のあちこちに描けるが、それらを全て合わせたもの（合力）が力 '+tex("F")+'。図の中に力の矢印を何本も描かないように注意しよう。</p>'+
      '<p>直径 6 cm の吸盤（'+tex("S\\fallingdotseq 28")+' cm² ＝ '+tex("2.8\\times10^{-3}")+' m²）なら、'+tex("F=pS\\fallingdotseq 2.8\\times10^2")+' N。約 29 kg の物体にはたらく重力と同じくらいの大きさになる。実際に引っ張る実験では、約 19 kg 分の力まで耐えたという（中の空気を完全には追い出せないため）。</p>'+
      '<div class="stp"><p class="sh"><b>参考</b></p><ul class="links"><li><a href="https://www.jsme-fed.org/experiment/2015_10/002.html" target="_blank" rel="noopener">吸盤と大気圧（日本機械学会 流体工学部門）↗</a></li></ul></div></div>'+
      '<div class="qcard hatten"><p class="qt">＜発展＞ 圧力が場所によって違うとき</p>'+
      '<p>水そうの側面のように、面の場所によって圧力が違うときは、面を小さな面積 '+tex("dS")+' に分けて、それぞれが受ける力 '+tex("p\\,dS")+' を足し合わせる。</p>'+
      '<div class="qeq">'+tex("F=\\int_S p\\,dS",true)+'</div>'+
      '<p>圧力 '+tex("p")+' がどこでも同じなら、'+tex("F=p\\int_S dS=pS")+' に戻る。</p></div>'; }},
  s11:{num:2, mode:0, title:"水圧と深さの関係", short:"水圧と深さ", sim:S11,
    desc:'水そうの側面に、深さの違う 3 つの穴がある。<span class="todo">スタートで栓を抜いて、3 つの穴からの水の噴き出し方を比べよう。</span>',
    opts: '',
    note:'',
    right:function(){ return '<div class="qcard"><p class="qt">水圧の性質</p>'+
      '<ol class="pts"><li>同じ深さでは、水圧は<b>どの向きにも同じ大きさ</b></li><li><span class="red">深いほど水圧は大きい</span></li></ol></div>'+
      '<div class="qcard"><p class="qt">見るポイント</p><p>深い穴ほど、水が勢いよく噴き出す。深いところほど、水が強く押しているから。</p>'+
      '<p>水面が下がるにつれて、どの穴の水も弱くなる。水圧は<b>水面からの深さ</b>で決まる。</p></div>'; }},
  s12:{num:3, mode:0, title:"水圧（水の重さによる圧力）", short:"水圧 ρhg", sim:S12,
    desc:'水の中の物体の表面が受ける水圧を、矢印で表した。<span class="todo">物体を上下にドラッグするか、スタートを押して水の深いところへ運んでみよう。</span><br>注目点：矢印はどこでも面に垂直。球や台形柱、3 次元表示でも確かめよう。',
    opts: H_seg("shape","形",[["rect","直方体"],["circle","球"],["trap","台形柱"]],"rect") + H_chk("col","水の柱を表示",false) + H_chk("mol","水分子を表示",false),
    mid: H_tslider("h","上の面の深さ $h$",0.06,1.5,0.01,0.51),
    headBtn: '<button class="b v3btn pglow" type="button" aria-pressed="false">３次元表示</button>',
    right:function(){ return '<div class="qcard"><p class="qt">水分子をイメージしよう</p>'+molKunSVG()+
      '<p>深いところの水分子ほど、上に載っている仲間が多いので、強く押されている。押し合う力は、どの向きにもはたらく。</p>'+
      '<div class="stp"><p class="sh"><b>水の中に物体を入れてみると…</b></p>'+molKun2SVG()+
      '<p>物体の上の面（深さ '+tex("h_1")+'）を押す水分子より、下の面（深さ '+tex("h_2")+'）を押す水分子の方が、強く押している。面積を '+tex("S")+' とすると</p>'+
      '<div class="qeq">'+tex("\\begin{aligned}&\\text{下の面全体にはたらく力（上向き）}\\ \\rho Sh_2g\\\\&\\text{上の面全体にはたらく力（下向き）}\\ \\rho Sh_1g\\end{aligned}",true)+'</div>'+
      '<p>その差が、物体にはたらく浮力（→ ①-5）：</p>'+
      '<div class="qeq">'+tex("\\rho Sh_2g-\\rho Sh_1g=\\rho S(h_2-h_1)g=\\rho Vg",true)+'</div>'+
      '<p>水が押し合っているところに物体が入りこむから、浮力が生じる。</p></div></div>'; },
    leftBelow:function(){ return '<div class="qcard leftcard"><p class="qt">水圧の大きさ</p>'+
      '<p>水の密度を '+tex("\\rho")+'［kg/m³］とすると、深さ '+tex("h")+'［m］での水圧 '+tex("p")+'［Pa］は</p>'+
      '<div class="qeq">'+tex("p=\\rho hg",true)+'</div>'+
      '<div class="stp"><p class="sh"><b>導き方</b>真上の水の柱の重さを考える</p>'+
      '<p>面積 '+tex("S")+' の面の真上には、高さ '+tex("h")+' の水の柱が載っている。水の柱の質量は '+tex("m=\\rho\\times Sh")+'、重さは</p>'+
      '<div class="qeq">'+tex("F=mg=\\rho Shg",true)+'</div>'+
      '<p>これを面積 '+tex("S")+' で割ると、'+tex("p=\\dfrac{F}{S}=\\dfrac{\\rho Shg}{S}=\\rho hg")+'</p></div>'+
      '<div class="stp"><p class="sh"><b>見るポイント</b></p><p>矢印はどこでも<b>面に垂直</b>。球や台形柱にすると、斜めの面でも面に垂直に押していることが分かる。同じ深さの左右の矢印は同じ長さで、打ち消しあう。上の面より<b>下の面の矢印の方が長い</b>（→ ①-5 の浮力）。</p></div></div>'; }},
  s13:{num:4, mode:0, title:"実際の水圧（大気圧＋水圧）", short:"大気圧＋水圧", sim:S13,
    desc:'実際の水面には大気圧がかかっているので、水の中の物体は「大気圧＋水圧」で押される。<span class="todo">スタートで物体を沈めて、矢印と棒グラフの変わり方を見よう。</span><br>注目点：上の面と下の面の圧力の差は、深さを変えても同じ。',
    opts: H_seg("air","表示",[["on","大気圧もふくめる"],["off","水圧だけ"]],"on") + H_chk("col","水と空気の柱を表示",false),
    mid: H_tslider("h","上の面の深さ $h$",0,40,0.5,20),
    right:function(){ return '<div class="qcard"><p class="qt">水中の圧力</p>'+
      '<p>水面での大気圧を '+tex("p_0")+'［Pa］とすると、深さ '+tex("h")+'［m］の面が受ける圧力 '+tex("p'")+'［Pa］は</p>'+
      '<div class="qeq">'+tex("p'=p_0+\\rho hg",true)+'</div>'+
      '<p>大気圧 ＋ 上に載っている水の重さの分。</p>'+
      '<div class="stp"><p class="sh"><b>見るポイント</b></p><p>深さ 0 でも矢印は消えない。水面にも大気圧 '+tex("p_0\\fallingdotseq 1.0\\times10^5")+' Pa がかかっているから。</p>'+
      '<p>水深 10 m の水圧 '+tex("\\rho hg=1.0\\times10^3\\times10\\times9.8\\fallingdotseq 1.0\\times10^5")+' Pa は、大気圧とほぼ同じ。深さ 10 m ごとに、大気圧 1 つ分ずつ増える。</p>'+
      '<p>下の面と上の面の圧力の差は、大気圧 '+tex("p_0")+' の分が打ち消しあって、物体の高さ分の水圧だけが残る（→ ①-5 の浮力）。</p></div></div>'; }},
  s14:{num:5, mode:0, title:"液体による浮力", short:"浮力", sim:S14, wide:true, kind:"water",
    desc:'液体の中の物体は、上向きの力（浮力）を受ける。<span class="todo">(a)〜(c) の図をクリックして表示を選び、物体の深さをドラッグで決めてからスタート。</span><br>注目点：全部沈んでいる間は、深さを変えても浮力は変わらない。',
    opts: '',
    live: '<div class="liverow lsl">'+H_slider("dens","物体&nbsp;&nbsp;<span class=\"lnote\">（右にいくほど密度が大きい）</span>",0,DENS.length-1,1,0)+'<div class="cticks" data-lo="密度 小"><span>木</span><span>氷</span><span>水と同じ</span><span>アルミ</span><span>鉄</span></div>'+'</div>'+
          '<div class="liverow lsl">'+H_slider("liq","液体&nbsp;&nbsp;<span class=\"lnote\">（右にいくほど密度が大きい）</span>",0,LIQS.length-1,1,1)+'<div class="cticks" data-lo="密度 小"><span>油</span><span>水</span><span>食塩水</span><span>水銀</span></div>'+'</div>',
    cells:[["a","水圧による説明","上下左右から押される"],["b","浮力（水圧の合力）による説明","上下の力の差が浮力"],["c","アルキメデスの原理","同じ体積の液体が受ける重力に等しいだけの浮力を受ける"]],
    below:function(){ return '<div class="sRb eq"><div class="qcard"><p class="qt">浮力の大きさ</p>'+
      '<p>水中にある物体の上の面（深さ '+tex("h_1")+'）と下の面（深さ '+tex("h_2")+'）の面積を '+tex("S")+' とする。上の面は下向きに '+tex("F_1")+'、下の面は上向きに '+tex("F_2")+' の力を受ける（横向きの力は打ち消しあう）。</p>'+
      '<div class="qeq">'+tex("\\begin{aligned}F&=F_2-F_1=(p_0+\\rho gh_2)S-(p_0+\\rho gh_1)S\\\\&=\\rho(h_2-h_1)Sg=\\rho Vg\\end{aligned}",true)+'</div>'+
      '<p>大気圧 '+tex("p_0")+' の分は上下で打ち消しあう。'+tex("V")+' は物体が押しのけた水の体積。</p>'+
      '<p class="red">アルキメデスの原理：流体中の物体は、それが押しのけた流体の重さに等しい大きさの浮力を受ける。</p></div></div>'+
      '<div class="sRb"><div class="qcard"><p class="qt">見るポイント</p><ol class="pts">'+
      '<li>全部沈んでいる間は、深さを変えても浮力は変わらない（上下の水圧の差は同じ）。</li>'+
      '<li>水面から出ると、水の中の体積 '+tex("V'")+' が小さくなり、浮力も小さくなる。</li>'+
      '<li>浮いて止まるとき、浮力と重力がつりあう：'+tex("\\rho V'g=mg")+'。氷なら、水面の上に出るのは約 8 %。</li>'+
      '<li>水より密度が大きい物体は沈み、底から垂直抗力 '+tex("N")+' を受けて止まる（'+tex("F+N=mg")+'）。</li></ol>'+
      '<p class="cvnote">物体は、幅と奥行きが 0.12 m、高さが 0.30 m の縦長の直方体。力の矢印は、液体を変えても同じ縮尺。長すぎる矢印は途中を省略している（≈ の印）。</p></div></div>'; }},
  s21:{num:1, mode:1, title:"大気圧（大気による圧力）", short:"大気圧", sim:S21,
    desc:'空気の中の物体の表面が受ける大気圧を、矢印で表した。<span class="todo">物体を上下にドラッグするか、スタートを押して高いところへ運んでみよう。</span>',
    opts: H_seg("shape","形",[["box","直方体"],["ball","球"]],"box") + H_chk("col","空気の柱を表示",false) + H_chk("mol","気体分子を表示",false),
    mid: H_tslider("z","高さ",0,10,0.1,0),
    right:function(){ return '<div class="qcard"><p class="qt">空気の分子をイメージしよう</p>'+airKunSVG()+
      '<p>地上に近いほど、上に載っている空気の重さで押しつめられ、分子が多い。その分、物体にたくさんぶつかって強く押す。</p></div>'+
      '<div class="qcard"><p class="qt">大気圧</p>'+
      '<p>空気（気体）の分子が物体の表面に次々とぶつかることで、圧力が生じる。大気による圧力が<b>大気圧</b>。大気圧は、上に載っている空気の重さによって生じる。</p>'+
      '<div class="qeq">'+tex("1\\,\\text{気圧}=1.013\\times10^5\\,\\text{Pa}=1013\\,\\text{hPa}",true)+'</div>'+
      '<p>海面の高さでは、1 m² の地面の上に約 '+tex("1.0\\times10^4")+' kg の空気が載っていることになる。</p>'+
      '<div class="stp"><p class="sh"><b>見るポイント</b></p><p>高いところほど、上に載っている空気が少ないので、大気圧は小さい。高さ約 5.5 km で地上の約半分。</p>'+
      '<p>水圧と同じく、大気圧も面に垂直にはたらく。下の面を押す大気圧の方が、上の面を押す大気圧より大きい。この差が、空気の中の浮力（→ ②-2）になる。</p>'+
      '<p>図では、物体を目盛り通りの大きさ（高さ約 2 km）とみなして矢印を描いたので、上下の差が大きく見える。普通の大きさの物体では、1 m の高さの差で約 12 Pa しか違わない。</p></div></div>'; }},
  s22:{num:2, mode:1, title:"大気による浮力", short:"空気の浮力", sim:S22, wide:true, kind:"air",
    desc:'空気の中の物体にも、水の中と同じ仕組みで浮力がはたらく。<span class="todo">(a)〜(c) の図をクリックして表示を選び、風船の高さをドラッグで決めてからスタート。</span><br>注目点：高いところほど空気が薄く、浮力が小さくなる。',
    opts: '',
    live: '<div class="liverow lsl">'+H_slider("gas","風船の中身&nbsp;&nbsp;<span class=\"lnote\">（右にいくほど密度が大きい）</span>",0,1,1,0)+'<div class="cticks" data-lo="密度 小"><span>ヘリウム</span><span>空気</span></div>'+'</div>',
    cells:[["a","大気圧による説明","下の方が少し強く押される"],["b","浮力（大気圧の合力）による説明","大気圧の合力が浮力"],["c","アルキメデスの原理","同じ体積の空気が受ける重力に等しいだけの浮力を受ける"]],
    below:function(){ return '<div class="sRb eq"><div class="qcard"><p class="qt">空気による浮力</p>'+
      '<p>空気の密度を '+tex("\\rho_{\\text{空気}}")+'、物体の体積を '+tex("V")+' とすると、浮力の大きさは水のときと同じ式で</p>'+
      '<div class="qeq">'+tex("F=\\rho_{\\text{空気}}Vg",true)+'</div>'+
      '<p>空気の密度（地上で約 1.2 kg/m³）は水の約 1/800 なので、同じ体積なら浮力も水の約 1/800。</p></div></div>'+
      '<div class="sRb"><div class="qcard"><p class="qt">見るポイント</p><ol class="pts">'+
      '<li>ヘリウムは空気より軽いので、風船全体の重さより浮力が大きく、浮き上がる。</li>'+
      '<li>高いところほど空気が薄く（密度が小さく）、浮力が小さくなる。浮力と重力がつりあう高さで止まる。</li>'+
      '<li>普通に空気を入れた風船は、ゴムの重さの分重力が大きく、落ちる。</li></ol>'+
      '<p class="cvnote">風船の体積は変わらないとしている（実際の風船は、高いところで膨らんで割れることがある）。</p></div></div>'; }}
};
DEFS.s31={num:1, mode:2, title:"空気の抵抗（雨粒の落下）", short:"空気の抵抗", sim:S31,
    desc:'雲から落ち始めた雨粒。空気の抵抗力は、速さに比例して大きくなる。<span class="todo">スタートを押して、雨粒の速さと v–t グラフを見よう。質量 m や比例定数 k も変えてみよう。</span>',
    opts:'',
    sliders: H_slider("m","質量 $m$",1.0,4.0,0.5,2.0) + H_slider("k","比例定数 $k$",2.0,8.0,0.5,4.0), sliderCls:"pair",
    right:function(){ return '<div class="qcard"><p class="qt">運動方程式と終端速度</p>'+
      '<p>雨粒には、下向きに重力 '+tex("mg")+'、上向きに空気の抵抗力 '+tex("kv")+'（'+tex("k")+' は比例定数）がはたらく。下向きを正とすると、運動方程式は</p>'+
      '<div class="qeq">'+tex("ma=mg-kv",true)+'</div>'+
      '<p>速さ '+tex("v")+' が大きくなるほど抵抗力 '+tex("kv")+' が大きくなり、加速度 '+tex("a")+' は小さくなる。やがて '+tex("mg=kv")+' となって '+tex("a=0")+'。そのあとは一定の速さ（<b>終端速度</b>）で落ちる。</p>'+
      '<div class="qeq">'+tex("0=mg-kv_f\\quad\\Longrightarrow\\quad v_f=\\dfrac{mg}{k}",true)+'</div>'+
      '<div class="stp"><p class="sh"><b>抵抗力の大きさについて</b></p>'+
      '<p>空気の抵抗力には、速さに比例する部分と、速さの 2 乗に比例する部分がある。ここでは<b>十分小さい物体</b>がゆっくり動く場合を考えているので、速さの 2 乗に比例する部分は無視して、抵抗力を '+tex("kv")+' としている。</p>'+
      '<p>高校物理の範囲では、この考え方（抵抗力は速さに比例する）で扱ってよい。</p></div>'+
      '<div class="stp"><p class="sh"><b>発展</b>速さの時間変化</p><p>運動方程式を解くと '+tex("v=v_f\\left(1-e^{-\\frac{k}{m}t}\\right)")+'。グラフの曲線はこの式で描いている。</p></div></div>'; }};
DEFS.s32={num:2, mode:2, title:"水から受ける抵抗（船）", short:"水の抵抗", sim:S32,
    desc:'水の上の船。水は、船の動きを妨げる向きに抵抗力をはたらかせる。<span class="todo">船をつかんで左右に速く・ゆっくり走らせて、抵抗力の矢印の長さを比べよう。</span>',
    opts:'',
    right:function(){ return '<div class="qcard"><p class="qt">水の抵抗力</p>'+
      '<p>水の中や水面を動く物体は、速さが大きいほど大きな抵抗力を受ける。手を放すと、抵抗力のために船はだんだん遅くなって止まる。</p>'+
      '<div class="stp"><p class="sh"><b>このシミュレーションのモデル</b></p>'+
      '<p>水の動きをきちんと計算するのはとても難しい（③-3）。ここでは、抵抗力の大きさを</p>'+
      '<div class="qeq">'+tex("R=bv+cv^2",true)+'</div>'+
      '<p>と近似している（'+tex("b,\\ c")+' は定数）。実際の船の抵抗は、波を作ることによる抵抗なども加わって、もっと複雑になる。右上のグラフは、このモデルの '+tex("R")+' と '+tex("v")+' の関係。</p></div></div>'; }};
DEFS.s33={num:3, mode:2, title:"流体から受ける力（大学の内容）", short:"大学の内容", sim:S33, static:true,
    desc:'このページで見てきた水圧・浮力・抵抗力は、全て 1 つの方程式にまとめられる。大学で学ぶ内容なので、雰囲気だけ紹介する。',
    body:function(){ return '<div class="qcard"><p class="qt">ナビエ–ストークス方程式</p>'+
      '<p>水や空気などの流体の動きは、<b>ナビエ–ストークス方程式</b>で表される。流体を小さなかたまりに分けて、そのかたまりについて運動方程式（'+tex("ma=F")+'）を立てたものにあたる。密度が変わらない流体では</p>'+
      '<div class="qeq">'+tex("\\rho\\left(\\frac{\\partial\\vec{v}}{\\partial t}+(\\vec{v}\\cdot\\nabla)\\vec{v}\\right)=-\\nabla p+\\mu\\nabla^{2}\\vec{v}+\\rho\\vec{g}",true)+'</div>'+
      '<table class="nstab"><tr><td>'+tex("\\rho\\left(\\frac{\\partial\\vec{v}}{\\partial t}+(\\vec{v}\\cdot\\nabla)\\vec{v}\\right)")+'</td><td>小さなかたまりの「質量×加速度」（1 m³ あたり）</td></tr>'+
      '<tr><td>'+tex("-\\nabla p")+'</td><td>周りの圧力の差から受ける力（→ ①・② の水圧・大気圧・浮力）</td></tr>'+
      '<tr><td>'+tex("\\mu\\nabla^{2}\\vec{v}")+'</td><td>粘り気（粘性）による力（→ ③-1・③-2 の抵抗力のもと）。'+tex("\\mu")+' は粘性係数</td></tr>'+
      '<tr><td>'+tex("\\rho\\vec{g}")+'</td><td>重力（1 m³ あたり）</td></tr></table></div>'; },
    right:function(){ return '<div class="qcard"><p class="qt">高校物理とのつながり</p>'+
      '<p>流体が静止しているとき（'+tex("\\vec{v}=\\vec{0}")+'）は、左辺と粘性の項が 0 になり、圧力の差と重力がつりあう。これを解くと、①-4 の '+tex("p'=p_0+\\rho hg")+' が出てくる。</p>'+
      '<p>とても小さな球がゆっくり動くときは、抵抗力が速さに比例する（'+tex("6\\pi\\mu rv")+'、ストークスの法則）ことが、この方程式から導かれる。③-1 の '+tex("kv")+' はこれにあたる。</p>'+
      '<p>この方程式は一般には手で解けないので、コンピュータで計算する（数値流体力学）。</p>'+
      '<div class="stp"><p class="sh"><b>勉強したい人は、詳しくはこちら</b></p><ul class="links">'+
      '<li><a href="https://ja.wikipedia.org/wiki/%E3%83%8A%E3%83%93%E3%82%A8%E2%80%93%E3%82%B9%E3%83%88%E3%83%BC%E3%82%AF%E3%82%B9%E6%96%B9%E7%A8%8B%E5%BC%8F" target="_blank" rel="noopener">ナビエ–ストークス方程式（ウィキペディア）↗</a></li>'+
      '<li><a href="https://www.kurims.kyoto-u.ac.jp/~kenkyubu/kokai-koza/R4-ishimoto.pdf" target="_blank" rel="noopener">京都大学 数理解析研究所 公開講座の資料（流体力学の入門・PDF）↗</a></li></ul></div></div>'; }};
var CIRC = "①②③④⑤⑥⑦⑧⑨";
var GLOBAL = {hideEq:false};

function secAddr(sid){ var d=DEFS[sid]; return (d.mode+1)+"-"+d.num; }
function secHTML(sid, first){
  var d=DEFS[sid], num=CIRC[d.mode]+"-"+d.num;
  var head='<div class="sechead"><span class="secnum">'+num+'</span><h2>'+d.title+'</h2>'+(d.headBtn||'')+'</div><div class="secdesc">'+d.desc+'</div>';
  if(d.static){
    return '<article class="sec" id="'+sid+'"><div class="sL">'+head+d.body()+'</div><div class="sR">'+d.right()+'</div></article>';
  }
  if(!d.wide){
    return '<article class="sec" id="'+sid+'"><div class="sL">'+head+
      '<div class="ctrls">'+(d.opts? '<div class="row1 row1b">'+H_reset()+d.opts+'</div>' : '')+(d.sliders? '<div class="row2 sliders'+(d.sliderCls? ' '+d.sliderCls : '')+'">'+d.sliders+'</div>' : '')+(d.noplay? '' : H_play(first, d.mid, d.opts? '' : H_reset()))+'</div>'+
      (d.nocanvas? '' : '<div class="cvwrap"><canvas class="main"></canvas></div>')+'<div class="msgbox"'+(d.nocanvas?' hidden':'')+'></div>'+(d.leftBelow? d.leftBelow() : '')+'</div>'+
      '<div class="sR">'+d.right()+'</div></article>';
  }
  var cells=d.cells.map(function(cc,i){ return '<div class="fcell pick'+(i===0?' on':'')+'" data-v="'+cc[0]+'" tabindex="0" role="button" aria-pressed="'+(i===0)+'"><p class="fcap">('+"abc"[i]+') '+cc[1]+'<small>'+cc[2]+'</small></p><canvas data-v="'+cc[0]+'"></canvas></div>'; }).join("");
  /* 第10回：左の列（見出し・説明・(a)〜(c)）と右の列（いちばん右の図）を横に並べる。説明文は左の列の中で折り返す */
  return '<article class="sec wide" id="'+sid+'"><div class="sL"><div class="wgrid"><div class="wleft">'+head+
    (d.opts? '<div class="ctrls"><div class="row1 row1b">'+d.opts+'</div></div>' : '')+
    '<div class="threegrid">'+cells+'</div></div><div class="fcell live"><div class="livehead">'+H_reset()+'</div>'+(d.live? '<div class="ctrls liveopts">'+d.live+'</div>' : '')+H_play(first)+
    '<div class="cvwrap"><canvas class="main"></canvas></div><p class="flegend"><span style="color:'+COL.grav+'">● 重力 <i>mg</i></span><span style="color:'+COL.buoy+'">● 浮力 <i>F</i></span><span style="color:'+COL.norm+'">● 垂直抗力 <i>N</i></span><span style="color:'+COL.press+'">→ '+(d.kind==="air"? "大気圧":"液体の圧力")+'</span></p><table class="forcetab"></table></div></div>'+
    '<p class="pickhint">👆 (a)〜(c) をクリックすると、一番右の図の表示が変わる（重力はいつも表示）。</p>'+
    '<div class="msgbox"></div><div class="widebelow">'+d.below()+'</div></div></article>';
}

function buildPage(){
  var EN = "Forces from Fluids";
  var atom='<svg class="atom" viewBox="0 0 32 32" aria-hidden="true"><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#3ea0e0" stroke-width="2"/><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#7b5bd6" stroke-width="2" transform="rotate(60 16 16)"/><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#e07b18" stroke-width="2" transform="rotate(120 16 16)"/><circle cx="16" cy="16" r="3.6" fill="#5aa7ff"/></svg>';
  document.getElementById("hero").innerHTML =
    '<div class="hero-in"><div class="hero-top"><nav class="crumbs" aria-label="現在地"><a class="crumb-home" href="'+SITE_HOME+'" title="楽楽（らくらく）高校物理のトップページへ">'+atom+'<span>楽楽（らくらく）高校物理</span></a><span class="cs" aria-hidden="true">/</span><a class="crumb" href="'+SITE_HOME+'#sec-mechanics">力学</a><span class="cs" aria-hidden="true">/</span><span class="crumb now" aria-current="page">流体から受ける力</span><span class="kdot"></span><span class="en">'+EN+'</span></nav>'+
    '<div class="topbtns" role="group" aria-label="ページ全体の表示"><button id="btnEq" type="button"></button></div></div>'+
    '<h1 class="hero-title"><span class="t1"><span class="nb">流体から</span><span class="nb">受ける力</span></span><span class="t2">〜水圧・大気圧・浮力〜</span></h1>'+
    '<div class="introrow"><p class="lead2">水や空気（流体）の中の物体は、周りから押されている。その押し方は深さ（高さ）によって違う。その違いが、物体を浮かせる力＝浮力になる。</p>'+
    '<button id="bToc" class="tocbtn" type="button" aria-haspopup="true" aria-expanded="false"><span class="ti" aria-hidden="true"></span>コンテンツ一覧</button></div>'+
    '<div id="tocpanel" class="tocpanel" hidden></div>'+
    '<figure class="stage" aria-label="水の中で手を放した木の物体が、周りの水圧に押されて浮き上がり、水面で上下に揺れて止まる"><canvas id="heroCv"></canvas>'+
    '<figcaption class="stagecap"><span class="live" aria-hidden="true"></span><span class="sct">水の中で手を放した木の物体。周りの水圧は深いほど大きいので、下の面を押す力の方が大きい。その差が浮力 '+tex("F")+'。浮力が重力 '+tex("mg")+' より大きいので浮き上がり、水面で揺れて止まる。</span>'+
    '<span class="stagectl" role="group" aria-label="アニメの操作"><button type="button" class="slow" aria-pressed="false" title="ゆっくり再生">🐢 スロー</button><button type="button" class="pp" aria-label="一時停止"><i></i></button></span></figcaption></figure>'+
    '<ol class="ideas">'+
    '<li><a href="#1-3"><span class="in" aria-label="①"><b>1</b></span><span class="ie">'+tex("p=\\rho hg")+'</span><span class="ij">水圧は面に垂直に、深いほど大きく</span><span class="ia" aria-hidden="true">→</span></a></li>'+
    '<li><a href="#1-4"><span class="in" aria-label="②"><b>2</b></span><span class="ie">'+tex("p'=p_0+\\rho hg")+'</span><span class="ij">実際の水圧は、大気圧＋水圧</span><span class="ia" aria-hidden="true">→</span></a></li>'+
    '<li><a href="#1-5"><span class="in" aria-label="③"><b>3</b></span><span class="ie">'+tex("F=\\rho Vg")+'</span><span class="ij">浮力＝押しのけた流体の重さ</span><span class="ia" aria-hidden="true">→</span></a></li></ol></div>';

  document.getElementById("tabs").innerHTML='<div class="tabs-in"><div class="navsite"><a class="navhome" href="'+SITE_HOME+'" aria-label="ホーム（楽楽高校物理のトップページ）" title="ホーム（楽楽高校物理のトップページ）"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3.5 10.8 12 4l8.5 6.8" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M6 9.5V20h4.5v-5.5h3V20H18V9.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg></a><button class="navpages" id="bPages" type="button" aria-haspopup="dialog" aria-expanded="false" aria-controls="siteDrawer"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="3.5" width="7" height="7" rx="1.6" fill="currentColor"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.6" fill="currentColor" opacity=".55"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.6" fill="currentColor" opacity=".55"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.6" fill="currentColor"/></svg><span>ページ一覧</span></button></div>'+
    MODES.map(function(m,i){ return '<button class="tab" type="button" data-mode="'+m.id+'"><span class="tn">'+CIRC[i]+'</span><span class="tl">'+m.name+'</span></button>'; }).join("")+'</div><span class="tprog" aria-hidden="true"></span>';

  var h="", first=true;
  MODES.forEach(function(m,i){
    h+='<section class="mode" id="'+m.id+'"><header class="modehead"><div class="mh-num" aria-hidden="true"><span>'+(i+1)+'</span></div><div class="mh-body"><p class="mh-en">Chapter '+String(i+1).padStart(2,"0")+' — '+m.en+'</p><h2><span class="mh-c">'+CIRC[i]+'</span>'+m.name+'</h2><p class="mh-lead">'+m.lead+'</p></div></header>'+
       '<div class="seclinks">'+m.secs.map(function(s){ return '<a href="#'+secAddr(s)+'" data-toc="'+s+'">'+CIRC[i]+'-'+DEFS[s].num+'　'+DEFS[s].short+'</a>'; }).join("")+'</div>';
    m.secs.forEach(function(s){ h+=secHTML(s, first); first=false; });
    h+='</section>';
  });
  h+='<div class="card purpose"><p class="lead">このページの目的</p><ol>'+
     '<li>水圧は面に垂直にはたらき、深いほど大きいこと（'+tex("p=\\rho hg")+'）を、矢印の長さで見る。</li>'+
     '<li>実際に水中の点が受ける圧力は、大気圧＋水圧（'+tex("p'=p_0+\\rho hg")+'）であることを知る。</li>'+
     '<li>浮力は、上下の面の圧力の差から生まれ、押しのけた流体の重さに等しい（'+tex("F=\\rho Vg")+'）ことを確かめる。</li>'+
     '<li>空気の中でも、大気圧と浮力が水の中と同じ仕組みではたらくことを確かめる。</li></ol></div>';
  h+='<footer></footer>';
  document.getElementById("wrap").innerHTML=h;

  /* 目次 */
  var tp=document.getElementById("tocpanel");
  tp.innerHTML='<div class="tochead"><b>コンテンツ一覧</b><button type="button" class="tocx" aria-label="閉じる">×</button></div>'+
    MODES.map(function(m,i){ return '<div class="tocmode">'+CIRC[i]+' '+m.name+'</div><ul>'+m.secs.map(function(s){ return '<li><a href="#'+secAddr(s)+'" data-toc="'+s+'">'+CIRC[i]+'-'+DEFS[s].num+' '+DEFS[s].title+'</a></li>'; }).join("")+'</ul>'; }).join("");
  var bT=document.getElementById("bToc");
  var closeToc=function(){ tp.hidden=true; bT.setAttribute("aria-expanded","false"); };
  bT.addEventListener("click", function(ev){ ev.stopPropagation(); tp.hidden=!tp.hidden; bT.setAttribute("aria-expanded", tp.hidden?"false":"true"); });
  tp.querySelector(".tocx").addEventListener("click", closeToc);
  document.addEventListener("click", function(ev){ if(!tp.hidden && !tp.contains(ev.target) && ev.target!==bT) closeToc(); });
  document.addEventListener("keydown", function(ev){ if(ev.key==="Escape") closeToc(); });
  document.querySelectorAll("a[data-toc]").forEach(function(a){ a.addEventListener("click", function(ev){ ev.preventDefault(); closeToc(); gotoSec(a.dataset.toc); }); });

  /* タブ */
  document.querySelectorAll("#tabs .tab").forEach(function(b){
    b.addEventListener("click", function(){ activateMode(b.dataset.mode); history.replaceState(null,"","#"+b.dataset.mode);
      window.scrollTo({top:Math.min(window.pageYOffset, contentTop()), behavior:"auto"}); });
  });
  window.addEventListener("hashchange", function(){ gotoHash(); });

  /* 式・考え方エリアを閉じる */
  var bE=document.getElementById("btnEq");
  var sync=function(){ var on=GLOBAL.hideEq; bE.innerHTML='<span class="sw" aria-hidden="true"><i></i></span><span class="swl">式・考え方エリアを閉じる</span><span class="swv">'+(on?"ON":"OFF")+'</span>';
    bE.setAttribute("aria-pressed",on?"true":"false"); bE.classList.toggle("off",!on); document.body.classList.toggle("hideeq",on); };
  bE.addEventListener("click", function(){ GLOBAL.hideEq=!GLOBAL.hideEq; sync(); setTimeout(redrawAll,30); });
  sync();
}
var BUILT = {};
function activateMode(id){
  document.querySelectorAll(".mode").forEach(function(s){ s.classList.toggle("on", s.id===id); });
  document.querySelectorAll("#tabs .tab").forEach(function(b){ b.classList.toggle("on", b.dataset.mode===id); });
  var m=MODES.filter(function(x){ return x.id===id; })[0];
  if(m && !BUILT[id]){ BUILT[id]=true; m.secs.forEach(function(s){ DEFS[s].sim.init(document.getElementById(s)); }); }
  else if(m) setTimeout(function(){ m.secs.forEach(function(s){ var sim=DEFS[s].sim; if(sim.drawAll) sim.drawAll(); else sim.draw(); }); }, 0);
}
function redrawAll(){ MODES.forEach(function(m){ if(BUILT[m.id]) m.secs.forEach(function(s){ var sim=DEFS[s].sim; if(sim.drawAll) sim.drawAll(); else sim.draw(); }); }); }
function contentTop(){ var h=document.getElementById("hero"); return h? h.offsetTop+h.offsetHeight : 0; }
function tabbarH(){ var tb=document.getElementById("tabs"); return (tb && getComputedStyle(tb).position==="sticky")? tb.getBoundingClientRect().height : 0; }
function gotoSec(sid){
  var d=DEFS[sid]; if(!d) return;
  activateMode(MODES[d.mode].id); history.replaceState(null,"","#"+secAddr(sid));
  var go=function(){ var el=document.getElementById(sid); if(!el) return; window.scrollTo({top: el.getBoundingClientRect().top + window.pageYOffset - tabbarH() - 10, behavior:"auto"}); };
  requestAnimationFrame(function(){ requestAnimationFrame(go); }); setTimeout(go, 220);
}
function gotoHash(){
  var hs=(location.hash||"").slice(1);
  var mm=hs.match(/^(\d)-(\d)$/);
  if(mm){ var sid=null; Object.keys(DEFS).forEach(function(k){ if(DEFS[k].mode===parseInt(mm[1],10)-1 && DEFS[k].num===parseInt(mm[2],10)) sid=k; }); if(sid){ gotoSec(sid); return true; } }
  if(MODES.some(function(m){ return m.id===hs; })){ activateMode(hs); return true; }
  return false;
}
document.addEventListener("DOMContentLoaded", function(){
  buildPage();
  if(!gotoHash()) activateMode("mode1");
  watchTicks(document);
  if(document.fonts){ document.fonts.load('italic 14px "KaTeX_Math"').then(function(){ redrawAll(); }); document.fonts.ready.then(function(){ redrawAll(); }); }
});
