/* =========================================================================
   デザインの動き（キット 5 章）＋ ヒーローのアニメ（このページ専用）
   ヒーロー：水の中で手をはなした木の物体が、水圧に押されて浮き上がり、水面でゆれて止まる。
   ========================================================================= */
(function(){
  var RM = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var C = { acc:"#4fa8ff", acc2:"#9fd0ff", deep:"#2f7fd6", T:"#f4f7fb", dim:"rgba(222,232,245,.6)", press:"#f2c14e", F:"#5fd38a", Wt:"#ff6b5b",
            water:"rgba(79,168,255,.17)", wall:"rgba(222,232,245,.38)" };
  var JP = '"Hiragino Sans","Hiragino Kaku Gothic ProN","Yu Gothic",YuGothic,"Noto Sans JP",Meiryo,sans-serif';

  function initStage(){
    var cv=document.getElementById("heroCv"); if(!cv) return;
    var ctx=cv.getContext("2d");
    var W=0,H=0,dpr=1,run=false,raf=0,last=0,paused=false,rate=1;
    var A=0.12, AH=0.30, D=1.0, rho=500, m=rho*A*A*AH, z=0.72, v=0, t=0, hold=0, phase=0;   // phase 0：動く、1：止まって見せる
    function setup(){ var r=cv.getBoundingClientRect(); dpr=Math.min(2,window.devicePixelRatio||1);
      W=Math.max(280,r.width); H=Math.max(160,r.height); cv.width=Math.round(W*dpr); cv.height=Math.round(H*dpr); ctx.setTransform(dpr,0,0,dpr,0,0); }
    function sub(zz){ return Math.max(0, Math.min(AH, zz+AH/2)); }
    function stepPhys(dt){
      var n=12, h=dt/n;
      for(var k=0;k<n;k++){ var sb=sub(z), Fb=RHO_W*G*A*A*sb, me=m+0.5*RHO_W*A*A*sb, Fd=0.5*1.05*RHO_W*A*A*(sb/AH)*v*Math.abs(v)+3*(sb/AH)*v;
        v+=((m*G-Fb-Fd)/me)*h; z+=v*h; if(z>D-AH/2){ z=D-AH/2; if(v>0) v=0; } }
    }
    function draw(fade){
      var air=0.30, s=Math.min((H-26)/(D+air), (W-40)/3.0), yS=12+air*s, xc=W*0.5;
      var X=function(x){ return xc+x*s; }, Y=function(zz){ return yS+zz*s; };
      ctx.clearRect(0,0,W,H); ctx.save(); ctx.globalAlpha=fade;
      var hw=Math.min(1.45,(W-30)/(2*s));
      ctx.fillStyle=C.water; ctx.fillRect(X(-hw),Y(0),2*hw*s,D*s);
      ctx.strokeStyle=C.acc; ctx.lineWidth=2; ctx.beginPath(); ctx.moveTo(X(-hw),Y(0)); ctx.lineTo(X(hw),Y(0)); ctx.stroke();
      ctx.strokeStyle=C.wall; ctx.lineWidth=1.5; ctx.beginPath(); ctx.moveTo(X(-hw),Y(-0.12)); ctx.lineTo(X(-hw),Y(D)); ctx.lineTo(X(hw),Y(D)); ctx.lineTo(X(hw),Y(-0.12)); ctx.stroke();
      /* 深さの目盛り */
      ctx.font="11px "+JP; ctx.fillStyle=C.dim; ctx.textAlign="right"; ctx.textBaseline="middle";
      for(var q=0.25;q<=D+1e-6;q+=0.25){ ctx.strokeStyle="rgba(159,208,255,.25)"; ctx.beginPath(); ctx.moveTo(X(-hw),Y(q)); ctx.lineTo(X(-hw)+8,Y(q)); ctx.stroke(); }
      /* 物体 */
      ctx.fillStyle="#e6c07a"; ctx.strokeStyle="#f6dfae"; ctx.lineWidth=1.5; ctx.fillRect(X(-A/2),Y(z-AH/2),A*s,AH*s); ctx.strokeRect(X(-A/2),Y(z-AH/2),A*s,AH*s);
      /* 水圧の矢印 */
      var pts=surfPoints("rect",{w:A,h:AH},0.1), kL=3.0e-5;
      pts.forEach(function(p){ var d=z+p.y; if(d<=0.001) return; var L=RHO_W*G*d*kL, gp=0.008;
        arrow(ctx, X(p.x+p.nx*(gp+L)), Y(z+p.y+p.ny*(gp+L)), X(p.x+p.nx*gp), Y(z+p.y+p.ny*gp), C.press, 1.8, 7); });
      /* 浮力と重力（左右に少しずらす） */
      var sb=sub(z), F=RHO_W*G*A*A*sb, Wt=m*G, kF=0.40/(RHO_W*G*A*A*AH), yb=z+AH/2-sb/2;
      var bx=X(A/2)+Math.max(110, 0.85*s);
      ctx.save(); ctx.setLineDash([4,3]); ctx.strokeStyle="rgba(230,192,122,.8)"; ctx.lineWidth=1.3; ctx.strokeRect(bx-A/2*s, Y(z-AH/2), A*s, AH*s); ctx.restore();
      var dot=function(x,y,col){ ctx.fillStyle=col; ctx.beginPath(); ctx.arc(x,y,3.4,0,7); ctx.fill(); };
      if(F>0.01){ arrow(ctx, bx-6, Y(yb), bx-6, Y(yb-F*kF), C.F, 3, 11); dot(bx-6,Y(yb),C.F); }
      arrow(ctx, bx+6, Y(z), bx+6, Y(z+Wt*kF), C.Wt, 3, 11); dot(bx+6,Y(z),C.Wt);
      ctx.font="italic 700 15px "+'"KaTeX_Math",serif'; ctx.textAlign="right"; ctx.fillStyle=C.F; ctx.fillText("F", bx-11, Y(yb-F*kF)+4);
      ctx.textAlign="center"; ctx.fillStyle=C.Wt; ctx.fillText("mg", bx+6, Y(z+Wt*kF)+15);
      ctx.strokeStyle="rgba(222,232,245,.35)"; ctx.setLineDash([3,3]); ctx.lineWidth=1; ctx.beginPath(); ctx.moveTo(X(A/2)+4,Y(z)); ctx.lineTo(bx-A/2*s-4,Y(z)); ctx.stroke(); ctx.setLineDash([]);
      ctx.textAlign="left"; ctx.font="11px "+JP; ctx.fillStyle=C.dim; ctx.fillText("物体にはたらく力", bx+A/2*s+8, Y(z-AH/2)+4);
      /* 左上の説明 */
      if(W>=640){ ctx.textAlign="left"; ctx.font="700 12px "+JP; ctx.fillStyle=C.T; ctx.fillText("水圧の矢印（金色）", X(-hw)+12, Y(0)+16);
      ctx.font="11.5px "+JP; ctx.fillStyle=C.dim; ctx.fillText("深いほど長い → 下の面を押す力の方が大きい", X(-hw)+12, Y(0)+33); }
      ctx.restore();
    }
    var HOLD=1.6, FADE=0.45;
    function frame(ts){
      if(!run) return;
      var dt=last? Math.min(0.05,(ts-last)/1000) : 0; last=ts; dt*=rate;
      t+=dt; var fade=1;
      if(phase===0){ stepPhys(dt); if(t>0.5 && Math.abs(v)<0.004 && Math.abs(z-(rho/RHO_W*AH-AH/2))<0.003) { phase=1; hold=0; } if(t>9){ phase=1; hold=0; } }
      else { hold+=dt; if(hold>HOLD-FADE) fade=Math.max(0,(HOLD-hold)/FADE); if(hold>=HOLD){ phase=0; t=0; z=0.72; v=0; } }
      if(phase===0 && t<0.3) fade=t/0.3;
      draw(fade);
      raf=requestAnimationFrame(frame);
    }
    function start(){ if(run||RM||paused) return; run=true; last=0; raf=requestAnimationFrame(frame); }
    function stop(){ run=false; cancelAnimationFrame(raf); }
    function still(){ z=0.30; v=0; draw(1); }
    setup(); if(RM) still(); else draw(0);
    window.__hero={ frame:function(tt){ stop(); z=0.72; v=0; var k=Math.round(tt/0.01); for(var i=0;i<k;i++) stepPhys(0.01); draw(1); }, start:start, stop:stop };
    var rz=0; window.addEventListener("resize", function(){ clearTimeout(rz); rz=setTimeout(function(){ setup(); if(RM||paused) draw(1); }, 120); });
    if("IntersectionObserver" in window){ new IntersectionObserver(function(es){ es.forEach(function(en){ (en.isIntersecting && !document.hidden)? start() : stop(); }); },{threshold:0.05}).observe(cv); }
    else start();
    document.addEventListener("visibilitychange", function(){ if(document.hidden) stop(); else { var r=cv.getBoundingClientRect(); if(r.bottom>0 && r.top<innerHeight) start(); } });
    var ctl=document.querySelector("#hero .stagectl");
    if(ctl){ var pp=ctl.querySelector(".pp"), sl=ctl.querySelector(".slow");
      if(sl){ if(RM) sl.hidden=true; sl.addEventListener("click", function(){ rate=(rate===1?0.3:1); sl.setAttribute("aria-pressed", rate<1?"true":"false"); }); }
      if(pp){ if(RM) pp.hidden=true; pp.addEventListener("click", function(){ paused=!paused; pp.classList.toggle("paused",paused); pp.setAttribute("aria-label", paused?"再生":"一時停止"); if(paused){ stop(); draw(1); } else start(); }); }
    }
    document.addEventListener("click", function(ev){ if(ev.target.closest && ev.target.closest("button.b.play")) stop(); }, true);
  }

  function syncRange(el){ var mn=parseFloat(el.min)||0, mx=parseFloat(el.max), v=parseFloat(el.value);
    var p=(isFinite(mx)&&mx>mn)? (v-mn)/(mx-mn)*100 : 0, s=p.toFixed(1)+"%"; if(el._p!==s){ el._p=s; el.style.setProperty("--p",s); } }
  function initRanges(){
    document.addEventListener("input", function(ev){ if(ev.target && ev.target.type==="range") syncRange(ev.target); }, true);
    setInterval(function(){ if(document.hidden) return; document.querySelectorAll(".mode.on input[type=range]").forEach(syncRange); }, 150);
  }
  function initProgress(){
    var nav=document.getElementById("tabs"); if(!nav) return; var pend=false;
    var upd=function(){ pend=false; var h=document.documentElement, max=h.scrollHeight-innerHeight; nav.style.setProperty("--prog", max>0? Math.min(1,Math.max(0,scrollY/max)).toFixed(4) : 0); };
    window.addEventListener("scroll", function(){ if(!pend){ pend=true; requestAnimationFrame(upd); } }, {passive:true});
    window.addEventListener("resize", upd); upd();
  }
  function initIdeas(){
    document.querySelectorAll("#hero .ideas a").forEach(function(a){
      a.addEventListener("click", function(ev){ ev.preventDefault(); var id=a.getAttribute("href").slice(1);
        var mm=id.match(/^(\d)-(\d)$/), sid=null;
        Object.keys(DEFS).forEach(function(k){ if(mm && DEFS[k].mode===parseInt(mm[1],10)-1 && DEFS[k].num===parseInt(mm[2],10)) sid=k; });
        if(sid) gotoSec(sid); });
    });
  }
  function initDecorate(){
    var orig=activateMode;
    var showTab=function(){ var row=document.querySelector("#tabs .tabs-in"), on=row&&row.querySelector(".tab.on"); if(!on||row.scrollWidth<=row.clientWidth) return;
      var l=on.offsetLeft-24, r=on.offsetLeft+on.offsetWidth+24; if(l<row.scrollLeft) row.scrollLeft=l; else if(r>row.scrollLeft+row.clientWidth) row.scrollLeft=r-row.clientWidth; };
    var cur=function(){ document.querySelectorAll("#tabs .tab").forEach(function(b){ if(b.classList.contains("on")) b.setAttribute("aria-current","page"); else b.removeAttribute("aria-current"); }); };
    activateMode=function(id){ var r=orig.apply(this,arguments); showTab(); cur(); return r; };
    showTab(); cur();
  }
  function initStuck(){
    var hero=document.getElementById("hero"), nav=document.getElementById("tabs"); if(!hero||!nav||!("IntersectionObserver" in window)) return;
    new IntersectionObserver(function(es){ es.forEach(function(en){ nav.classList.toggle("stuck", !en.isIntersecting); }); },{threshold:0}).observe(hero);
  }
  function initFooter(){
    var f=document.querySelector("#wrap footer"); if(!f) return;
    document.body.appendChild(f);
    var items=MODES.map(function(m,i){ return '<li><a href="#'+m.id+'" data-mode="'+m.id+'"><b>'+CIRC[i]+'</b>'+m.name+'</a></li>'; }).join("");
    f.innerHTML='<div class="ft-in"><p class="ft-mark">Forces from Fluids<span>流体から受ける力 〜水圧・大気圧・浮力〜</span></p><ul class="ft-nav">'+items+'</ul>'+
      '<div class="ft-base"><span><a class="ft-home" href="'+SITE_HOME+'">⌂ 楽楽（らくらく）高校物理 トップページ</a>　／　高校物理 ・ 力学</span><span class="ft-r"><button type="button" class="ft-pages">ほかのページ一覧</button><a href="#top" class="ft-top">▲ ページの一番上へ</a></span></div></div>';
    f.querySelectorAll("a[data-mode]").forEach(function(a){ a.addEventListener("click", function(ev){ ev.preventDefault(); var id=a.dataset.mode;
      activateMode(id); history.replaceState(null,"","#"+id); window.scrollTo({top:contentTop(), behavior:"auto"}); }); });
    var fp=f.querySelector(".ft-pages"); if(fp) fp.addEventListener("click", function(){ if(window.SITENAV) window.SITENAV.open(); });
    var tp=f.querySelector(".ft-top"); if(tp) tp.addEventListener("click", function(ev){ ev.preventDefault(); window.scrollTo({top:0, behavior:"auto"}); });
  }
  document.addEventListener("DOMContentLoaded", function(){ initFooter(); initDecorate(); initStage(); initRanges(); initProgress(); initIdeas(); initStuck(); });
})();
