/* ---------------- ①-2 の３次元表示 ----------------
   rotation-box_tip-or-slip と同じ作り（skill canvas-3d-view-drag）：正射影・面を奥から塗る・縮尺を固定・ドラッグで視点。
   世界座標：x 右、y 奥ゆき、z 上。水面 z = 0、物体の中心 (0, 0, −zc)。 */
function mkProj3(azDeg, elDeg, S, cx, cy){
  var az=azDeg*Math.PI/180, el=elDeg*Math.PI/180, ca=Math.cos(az), sa=Math.sin(az), ce=Math.cos(el), se=Math.sin(el);
  return { p:function(q){ var x1=q[0]*ca-q[1]*sa, y1=q[0]*sa+q[1]*ca; return {x:cx+x1*S, y:cy-(q[2]*ce-y1*se)*S, d:y1*ce+q[2]*se}; },
           view:[sa*ce, ca*ce, se], S:S };
}
function v3sub(a,b){ return [a[0]-b[0],a[1]-b[1],a[2]-b[2]]; }
function v3add(a,b){ return [a[0]+b[0],a[1]+b[1],a[2]+b[2]]; }
function v3mul(a,k){ return [a[0]*k,a[1]*k,a[2]*k]; }
function v3dot(a,b){ return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]; }
function v3cross(a,b){ return [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]; }
function v3unit(a){ var L=Math.hypot(a[0],a[1],a[2])||1; return [a[0]/L,a[1]/L,a[2]/L]; }

/* 物体の面（4 頂点の多角形）。中心は原点。外向き法線つき */
function S12_faces3(kind, sz){
  var P=[];
  if(kind==="rect"){ var a=sz.w/2, b=sz.w/2, c=sz.h/2;
    P=[[[-a,-b,-c],[a,-b,-c],[a,b,-c],[-a,b,-c]], [[-a,-b,c],[a,-b,c],[a,b,c],[-a,b,c]],
       [[-a,-b,-c],[a,-b,-c],[a,-b,c],[-a,-b,c]], [[-a,b,-c],[a,b,-c],[a,b,c],[-a,b,c]],
       [[-a,-b,-c],[-a,b,-c],[-a,b,c],[-a,-b,c]], [[a,-b,-c],[a,b,-c],[a,b,c],[a,-b,c]]];
  } else if(kind==="trap"){ var t=sz.wt/2, w=sz.wb/2, h=sz.h/2, d=0.15;
    var F=function(y){ return [[-w,y,-h],[w,y,-h],[t,y,h],[-t,y,h]]; };
    P=[F(-d), F(d), [[-w,-d,-h],[w,-d,-h],[w,d,-h],[-w,d,-h]], [[-t,-d,h],[t,-d,h],[t,d,h],[-t,d,h]],
       [[-w,-d,-h],[-w,d,-h],[-t,d,h],[-t,-d,h]], [[w,-d,-h],[w,d,-h],[t,d,h],[t,-d,h]]];
  }
  return P.map(function(f){
    var n=v3unit(v3cross(v3sub(f[1],f[0]), v3sub(f[2],f[0]))), cen=v3mul(f.reduce(function(s,p){ return v3add(s,p); },[0,0,0]),0.25);
    if(v3dot(n,cen)<0) n=v3mul(n,-1);
    return {pts:f, n:n};
  });
}
/* 表面の点（矢印の根もと）と外向き法線 */
function S12_points3(kind, sz){
  var out=[];
  if(kind==="circle"){
    [-60,-25,0,25,60].forEach(function(lat){ var nl=lat===0? 10 : 8;
      for(var i=0;i<nl;i++){ var lo=(i+0.5)/nl*Math.PI*2, la=lat*Math.PI/180, n=[Math.cos(la)*Math.cos(lo), Math.cos(la)*Math.sin(lo), Math.sin(la)];
        out.push({p:v3mul(n,sz.r), n:n}); } });
    out.push({p:[0,0,sz.r], n:[0,0,1]}); out.push({p:[0,0,-sz.r], n:[0,0,-1]});
    return out;
  }
  S12_faces3(kind, sz).forEach(function(f){
    [[0.25,0.25],[0.75,0.25],[0.25,0.75],[0.75,0.75]].forEach(function(uv){
      var u=uv[0], v=uv[1], q=f.pts;
      var p=v3add(v3add(v3mul(q[0],(1-u)*(1-v)), v3mul(q[1],u*(1-v))), v3add(v3mul(q[2],u*v), v3mul(q[3],(1-u)*v)));
      out.push({p:p, n:f.n}); }); });
  return out;
}
function S12_attach3d(sim){
  var cv=sim.cv, last=null, mode=null;
  cv.addEventListener("pointerdown", function(ev){
    if(!sim.v3) return;
    var r=cv.getBoundingClientRect(), x=ev.clientX-r.left, y=ev.clientY-r.top, g=sim.g3;
    mode = (g && sim.run.state!=="run" && Math.hypot(x-g.ox, y-g.oy) < g.or+12)? "obj" : "cam";
    last={x:ev.clientX, y:ev.clientY}; cv.setPointerCapture(ev.pointerId); ev.preventDefault();
  });
  cv.addEventListener("pointermove", function(ev){
    if(!sim.v3 || !last) return;
    var dx=ev.clientX-last.x, dy=ev.clientY-last.y; last={x:ev.clientX, y:ev.clientY};
    if(mode==="obj"){ var g=sim.g3; sim.zc=clamp(sim.zc + dy/(g.S*Math.max(0.35,Math.cos(sim.cam.el*Math.PI/180))), 0.06+sim.half(), sim.zmaxC()); sim.run.touch(); sim.run.label(); sim.sl.set(sim.zc-sim.half()); }
    else { sim.cam.az=((sim.cam.az - dx*0.32 + 540)%360)-180; sim.cam.el=clamp(sim.cam.el - dy*0.26, 0, 88); }
    sim.draw(); ev.preventDefault();
  });
  var end=function(){ last=null; mode=null; };
  cv.addEventListener("pointerup", end); cv.addEventListener("pointercancel", end);
}
function S12_draw3d(sim){
  var f=fitCanvas(sim.cv, function(W){ return clamp(W*0.66, 280, 400); }), c=f.c, W=f.W, H=f.H;
  var az=sim.cam.az, el=sim.cam.el, D=sim.D, BX=0.55;
  /* 縮尺の固定：物体のまわり（幅 ±0.5 m・高さ ±0.55 m）がいつも同じ大きさで入るように。物体の深さに合わせて見る位置だけ動かす */
  var ctr0=[0,0,-sim.zc], pj0=mkProj3(az,el,1,0,0), x0=1e9,x1=-1e9,y0=1e9,y1=-1e9;
  [-0.5,0.5].forEach(function(x){ [-0.5,0.5].forEach(function(y){ [-0.55,0.55].forEach(function(z){ var p=pj0.p([x,y,z]); x0=Math.min(x0,p.x); x1=Math.max(x1,p.x); y0=Math.min(y0,p.y); y1=Math.max(y1,p.y); }); }); });
  var mg=10, S=Math.min((W-2*mg)/(x1-x0), (H-2*mg)/(y1-y0)), pc=pj0.p(ctr0), cx=W/2-S*pc.x, cy=H/2-S*pc.y;
  var pj=mkProj3(az,el,S,cx,cy), P=function(q){ return pj.p(q); };
  c.clearRect(0,0,W,H); c.fillStyle="#f8f7f3"; c.fillRect(0,0,W,H); c.save(); c.beginPath(); c.rect(0,0,W,H); c.clip();
  /* 水そう：奥の面（こちらを向いていない面）を水色でぬる */
  var wf=[{pts:[[-BX,-BX,-D],[BX,-BX,-D],[BX,BX,-D],[-BX,BX,-D]], n:[0,0,-1]},
          {pts:[[-BX,-BX,0],[BX,-BX,0],[BX,-BX,-D],[-BX,-BX,-D]], n:[0,-1,0]}, {pts:[[-BX,BX,0],[BX,BX,0],[BX,BX,-D],[-BX,BX,-D]], n:[0,1,0]},
          {pts:[[-BX,-BX,0],[-BX,BX,0],[-BX,BX,-D],[-BX,-BX,-D]], n:[-1,0,0]}, {pts:[[BX,-BX,0],[BX,BX,0],[BX,BX,-D],[BX,-BX,-D]], n:[1,0,0]}];
  var poly=function(pts,fill,stroke,lw){ c.beginPath(); pts.forEach(function(q,i){ var p=P(q); if(i) c.lineTo(p.x,p.y); else c.moveTo(p.x,p.y); }); c.closePath();
    if(fill){ c.fillStyle=fill; c.fill(); } if(stroke){ c.strokeStyle=stroke; c.lineWidth=lw||1; c.stroke(); } };
  wf.forEach(function(fc){ if(v3dot(fc.n,pj.view)<=0) poly(fc.pts,"rgba(160,205,235,.55)","rgba(47,111,159,.35)",1); });
  poly([[-BX,-BX,0],[BX,-BX,0],[BX,BX,0],[-BX,BX,0]], el>2? "rgba(120,180,225,.20)" : null, COL.surf, 1.6);
  /* 深さの目盛り（左の手前の縦の辺） */
  var corners=[[-BX,-BX],[BX,-BX],[BX,BX],[-BX,BX]], best=null;
  corners.forEach(function(q){ var p=P([q[0],q[1],0]); if(!best || p.x<best.p.x-1 || (Math.abs(p.x-best.p.x)<=1 && p.d>best.p.d)) best={q:q,p:p}; });
  [0.5,1.0,1.5,2.0].forEach(function(z){ var p=P([best.q[0],best.q[1],-z]); c.save(); c.strokeStyle="rgba(47,111,159,.6)"; c.beginPath(); c.moveTo(p.x-5,p.y); c.lineTo(p.x,p.y); c.stroke(); c.restore();
    T(c, z.toFixed(1)+" m", p.x-7, p.y, {size:10,col:"#2f6f9f",align:"right"}); });
  var ps=P([best.q[0],best.q[1],0]); T(c,"水面", ps.x-7, ps.y, {size:11,col:"#2f6f9f",bold:true,align:"right"});
  /* 物体と矢印 */
  var sz=sim.SZ[sim.kind], ctr=[0,0,-sim.zc], kL=2.4e-5, gap=0.012;
  var pts=S12_points3(sim.kind, sz), back=[], front=[];
  pts.forEach(function(q){ var wp=v3add(ctr,q.p), d=-wp[2]; if(d<=0) return;
    var L=Math.max(0.012, RHO_W*G*d*kL), a=P(v3add(wp, v3mul(q.n,gap+L))), b=P(v3add(wp, v3mul(q.n,gap)));
    (v3dot(q.n,pj.view)>0? front : back).push({a:a,b:b}); });
  back.forEach(function(r){ arrow(c, r.a.x, r.a.y, r.b.x, r.b.y, "rgba(181,137,0,.55)", 1.6, 7); });
  var oc=P(ctr), orad=0;
  /* 第12回：３次元表示でも「水分子を表示」。水そうの中に小さな粒を散らす（物体の中には描かない）。物体より奥の粒は先に、手前の粒はあとで描く */
  var molFront=[];
  if(sim.mol){
    if(!sim.m3){ sim.m3=[]; var rs=7; var rnd=function(){ rs=(rs*16807)%2147483647; return rs/2147483647; };
      for(var i=0;i<520;i++) sim.m3.push({x:-BX+0.03+rnd()*(2*BX-0.06), y:-BX+0.03+rnd()*(2*BX-0.06), z:-0.03-rnd()*(D-0.06), ph:rnd()*6.28, sp:0.7+rnd()*0.6}); }
    var inside=function(m){ var lx=m.x, ly=m.y, lz=m.z+sim.zc, pad=0.04;
      if(sim.kind==="circle") return Math.hypot(lx,ly,lz) < sz.r+pad;
      if(sim.kind==="trap"){ if(Math.abs(lz)>sz.h/2+pad || Math.abs(ly)>0.15+pad) return false; var hw=(sz.wt+(sz.wb-sz.wt)*clamp((-lz+sz.h/2)/sz.h,0,1))/2; return Math.abs(lx)<hw+pad; }
      return Math.abs(lx)<sz.w/2+pad && Math.abs(ly)<sz.w/2+pad && Math.abs(lz)<sz.h/2+pad; };
    var rr=Math.max(2.2, Math.min(4.0, S*0.028)), dc=oc.d, molP=[];
    sim.m3.forEach(function(m){ if(inside(m)) return; var p=P([m.x+0.006*Math.sin(sim.tm*6*m.sp+m.ph), m.y, m.z+0.006*Math.sin(sim.tm*5*m.sp+m.ph*1.3)]); molP.push(p); });
    molP.sort(function(a,b){ return a.d-b.d; });
    var dot=function(p){ c.beginPath(); c.arc(p.x,p.y,rr,0,7); c.fill(); c.stroke(); };
    c.save(); c.fillStyle="rgba(63,127,180,.30)"; c.strokeStyle="rgba(47,111,159,.55)"; c.lineWidth=0.8;
    molP.forEach(function(p){ if(p.d<dc) dot(p); else molFront.push(p); }); c.restore();
  }
  if(sim.kind==="circle"){
    orad=sz.r*S; var gr=c.createRadialGradient(oc.x-orad*0.35,oc.y-orad*0.4,orad*0.1,oc.x,oc.y,orad);
    gr.addColorStop(0,"#ffffff"); gr.addColorStop(1,"#c3ccd6"); c.fillStyle=gr; c.beginPath(); c.arc(oc.x,oc.y,orad,0,7); c.fill(); c.strokeStyle="#2b323c"; c.lineWidth=1.6; c.stroke();
  } else {
    var LG=v3unit([-0.4,-0.6,0.8]), faces=S12_faces3(sim.kind, sz).map(function(fc){
      var wpts=fc.pts.map(function(q){ return v3add(ctr,q); }), sp=wpts.map(P);
      return {sp:sp, d:(sp[0].d+sp[1].d+sp[2].d+sp[3].d)/4, vis:v3dot(fc.n,pj.view)>1e-6, br:0.80+0.20*v3dot(fc.n,LG)}; });
    faces.sort(function(a,b){ return a.d-b.d; });
    faces.forEach(function(fc){ if(!fc.vis) return; var k=Math.round(255*clamp(fc.br,0.55,1));
      c.beginPath(); fc.sp.forEach(function(p,i){ if(i) c.lineTo(p.x,p.y); else c.moveTo(p.x,p.y); }); c.closePath();
      c.fillStyle="rgb("+k+","+k+","+Math.min(255,k+6)+")"; c.fill();
      c.beginPath(); fc.sp.forEach(function(p,i){ if(i) c.lineTo(p.x,p.y); else c.moveTo(p.x,p.y); }); c.closePath();
      c.strokeStyle="#2b323c"; c.lineWidth=1.4; c.lineJoin="round"; c.stroke();
      fc.sp.forEach(function(p){ orad=Math.max(orad, Math.hypot(p.x-oc.x,p.y-oc.y)); }); });
  }
  sim.g3={S:S, ox:oc.x, oy:oc.y, or:orad};
  /* 第12回：３次元表示でも「水の柱を表示」：物体の上の面から水面までの柱（半透明の面と点線の辺） */
  if(sim.col){ var hh2=sim.half(), zt=-(sim.zc-hh2), ax=(sim.kind==="rect")? sz.w/2 : (sim.kind==="trap")? sz.wt/2 : 0.06, ay=(sim.kind==="rect")? sz.w/2 : (sim.kind==="trap")? 0.15 : 0.06;
    if(zt<-0.005){
      var cf=[{pts:[[-ax,-ay,zt],[ax,-ay,zt],[ax,-ay,0],[-ax,-ay,0]], n:[0,-1,0]}, {pts:[[-ax,ay,zt],[ax,ay,zt],[ax,ay,0],[-ax,ay,0]], n:[0,1,0]},
              {pts:[[-ax,-ay,zt],[-ax,ay,zt],[-ax,ay,0],[-ax,-ay,0]], n:[-1,0,0]}, {pts:[[ax,-ay,zt],[ax,ay,zt],[ax,ay,0],[ax,-ay,0]], n:[1,0,0]},
              {pts:[[-ax,-ay,0],[ax,-ay,0],[ax,ay,0],[-ax,ay,0]], n:[0,0,1]}];
      c.save(); c.setLineDash([5,4]);
      cf.forEach(function(fc){ poly(fc.pts, v3dot(fc.n,pj.view)>0? "rgba(47,111,159,.14)" : "rgba(47,111,159,.08)", COL.dashed, 1.2); });
      c.restore();
      var lp=P([ax, -ay, zt*0.5]);
      if(Math.abs(zt)*S>36){ T(c,"水の柱", lp.x+8, lp.y-8, {size:12,bold:true,col:COL.dashed,halo:true}); T(c,"重さ ρShg", lp.x+8, lp.y+9, {size:12,col:COL.dashed,halo:true}); }
    }
  }
  if(molFront.length){ c.save(); c.fillStyle="rgba(63,127,180,.30)"; c.strokeStyle="rgba(47,111,159,.55)"; c.lineWidth=0.8;
    molFront.forEach(function(p){ c.beginPath(); c.arc(p.x,p.y,Math.max(2.2, Math.min(4.0, S*0.028)),0,7); c.fill(); c.stroke(); }); c.restore(); }
  /* スタート後：物体の右下を手でつかんで下へ引く（矢印はこのあと上書き） */
  if(sim.run.state!=="idle"){ var hh=sim.half(), cr=sim.corner(), hp=P([cr[0], -(sim.kind==="trap"? 0.15 : sim.kind==="rect"? sz.w/2 : 0), -sim.zc-cr[1]]); pullHand(c, hp.x, hp.y); }
  front.forEach(function(r){ arrow(c, r.a.x, r.a.y, r.b.x, r.b.y, COL.press, 1.9, 7); });
  /* 手前の辺（水そう） */
  wf.forEach(function(fc){ if(v3dot(fc.n,pj.view)>0) poly(fc.pts,null,"rgba(47,111,159,.35)",1); });
  c.restore();
  if(sim.run.state==="idle") T(c,"物体をドラッグ：深さ ／ ほかをドラッグ：見る向き", W-10, H-12, {size:11,col:COL.sub,align:"right",halo:true});
  sim.vb.querySelectorAll("button").forEach(function(b){ b.classList.toggle("on", Math.abs(sim.cam.az-parseFloat(b.dataset.az))<0.5 && Math.abs(sim.cam.el-parseFloat(b.dataset.el))<0.5); });
  var ztop=sim.zc-sim.half(), pt=RHO_W*G*ztop, pb=RHO_W*G*(sim.zc+sim.half());
  sim.msg.innerHTML = '上の面：深さ <span class="num">'+ztop.toFixed(2)+'</span> m、水圧 '+tex("\\rho hg")+' ＝ <span class="num">'+sci(pt)+'</span> Pa<br>'+
    '下の面：深さ <span class="num">'+(sim.zc+sim.half()).toFixed(2)+'</span> m、水圧 ＝ <span class="num">'+sci(pb)+'</span> Pa　（矢印の長さ＝水圧の大きさ）';
}
