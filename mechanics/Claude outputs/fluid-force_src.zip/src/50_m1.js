/* =========================================================================
   モード① 水から受ける力
   ========================================================================= */

/* 水分子（①-2）：すき間なくつまった粒。画面全体をおおうように、画面の大きさごとに作り直す */
function makeMolecules(x0,x1,z0,z1,step){
  /* 第6回：行の数を決めてから、水面から水底までを等しい間隔でうめる（いちばん下の行が床に食いこんだり、
     床の近くだけすき間があいたりしない）。ゆれの位相は粒ごとにばらばら */
  var a=[], dzN=step*0.87, nz=Math.max(1, Math.round((z1-z0)/dzN)), dz=(z1-z0)/nz;
  var nx=Math.max(1, Math.round((x1-x0)/step)), dx=(x1-x0)/nx;
  for(var i=0; i<nz; i++){ var z=z0+dz*(i+0.5), off=(i%2)? 0.25*dx : -0.25*dx;
    for(var j=0; j<nx; j++){ var x=x0+dx*(j+0.5)+off, k=i*977+j*131;
      a.push({x:x, z:z, ph:(k*0.618034%1)*6.283, sp:0.8+((k*0.414214)%1)*0.6, ph2:((k*0.732051)%1)*6.283}); } }
  return a;
}
function drawMolecules(c, mols, X, Y, s, skip, t, clip){
  var r=Math.max(2.4, Math.min(4.0, s*0.026));
  c.save();
  if(clip){ c.beginPath(); c.rect(clip[0],clip[1],clip[2],clip[3]); c.clip(); }   /* 水の外（水面の上・床の下）には描かない */
  c.fillStyle="rgba(63,127,180,.22)"; c.strokeStyle="rgba(47,111,159,.45)"; c.lineWidth=0.8;
  mols.forEach(function(m){ var bx=X(m.x), by=Y(m.z);
    if(skip && skip(bx,by,r+3)) return;   /* 消すかどうかは、ゆれる前の位置で決める（境目でちらつかない） */
    var x=bx+1.2*Math.sin(t*6*m.sp+m.ph), y=by+1.2*Math.sin(t*5*m.sp+m.ph2);
    c.beginPath(); c.arc(x,y,r,0,7); c.fill(); c.stroke(); });
  c.restore();
}
/* 水の中の深さの目盛り線（①-2・①-3 で同じ見た目） */
function depthLines(c, x0, x1, Yd, list, unit){
  list.forEach(function(d){ var y=Yd(d);
    c.save(); c.strokeStyle="rgba(47,111,159,.38)"; c.setLineDash([2,4]); c.lineWidth=1; c.beginPath(); c.moveTo(x0,y); c.lineTo(x1,y); c.stroke(); c.restore();
    T(c, (unit==="m1"? d.toFixed(1) : d)+" m", x0+5, y-7, {size:9.5,col:"#2f6f9f"}); });
}
/* 手で引く（押す）：物体の右下の角にこぶし、腕は右下へ。矢印はこのあとに描いて上書きする */
function pullHand(c, x, y){ hand(c, x+7, y+7, Math.PI/4); }

/* ---------------- ①-1 水圧と深さの関係 ---------------- */
var S11 = {
  TW:0.24, TH:0.72, SH:1.0, H0:0.60, HOLES:[{hb:0.50,name:"浅い"},{hb:0.30,name:"中くらい"},{hb:0.10,name:"深い"}],
  init:function(sec){
    var self=this; this.sec=sec;
    this.cv = sec.querySelector("canvas.main"); this.msg = sec.querySelector(".msgbox");
    this.run = new Runner({
      startText:"▶ スタート（栓を抜く）",
      begin:function(){ self.surf=self.H0; self.drops=[]; self.emit=0; },
      step:function(dt){ return self.step(dt); },
      draw:function(){ self.draw(); },
      reset:function(){ self.surf=self.H0; self.drops=[]; },
      info:function(r){ return '時間 <b>'+r.t.toFixed(1)+'</b> s'; }
    });
    this.run.bind(sec);
    this.surf=this.H0; this.drops=[];
    sec.querySelector(".resetall").addEventListener("click", function(){ self.run.rate=1;
      var sb=sec.querySelector(".slowb"); if(sb) sb.classList.remove("on"); self.run.reset(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    this.draw();
  },
  depth:function(i){ return this.surf - this.HOLES[i].hb; },
  speed:function(i){ var d=this.depth(i); return d>0.002? Math.sqrt(2*G*d) : 0; },
  step:function(dt){
    var n=8, h=dt/n;
    for(var k=0;k<n;k++){
      var q=0; for(var i=0;i<3;i++) q+=this.speed(i);
      this.surf=Math.max(this.HOLES[2].hb, this.surf - 0.0043*q*h);
      for(var j=this.drops.length-1;j>=0;j--){ var d=this.drops[j]; d.x+=d.vx*h; d.vy-=G*h; d.y+=d.vy*h; if(d.y<=0) this.drops.splice(j,1); }
    }
    this.emit += dt;
    while(this.emit > 0.035){ this.emit -= 0.035;
      for(var i2=0;i2<3;i2++){ var v=this.speed(i2); if(v>0) this.drops.push({x:this.TW, y:this.SH+this.HOLES[i2].hb, vx:v*(0.97+Math.random()*0.06), vy:0}); } }
    return (this.depth(2) <= 0.002 && this.drops.length===0) || this.run.t > 40;
  },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return clamp(W*0.66, 300, 420); }), c=f.c, W=f.W, H=f.H;
    var s = Math.min((W-20)/2.45, (H-26)/1.80), x0 = 10 + 0.62*s, y0 = H-18;
    var X=function(x){ return x0+x*s; }, Y=function(y){ return y0-y*s; };
    c.clearRect(0,0,W,H);
    ground(c, 8, W-8, Y(0));
    /* 机：茶色の柱の上に天板（左へ長く伸ばす） */
    var TT=0.05;
    c.save(); c.fillStyle="#b9a596"; c.strokeStyle="#6d5a4c"; c.lineWidth=1.2;
    c.fillRect(X(0.03),Y(this.SH-TT),(this.TW-0.06)*s,(this.SH-TT)*s); c.strokeRect(X(0.03),Y(this.SH-TT),(this.TW-0.06)*s,(this.SH-TT)*s);
    c.fillRect(X(-0.52),Y(this.SH-TT),0.06*s,(this.SH-TT)*s); c.strokeRect(X(-0.52),Y(this.SH-TT),0.06*s,(this.SH-TT)*s);
    c.fillStyle="#a68a72"; c.fillRect(X(-0.58),Y(this.SH),(0.58+this.TW+0.08)*s,TT*s); c.strokeRect(X(-0.58),Y(this.SH),(0.58+this.TW+0.08)*s,TT*s);
    c.restore();
    c.save(); c.fillStyle=COL.water; c.fillRect(X(0),Y(this.SH+this.surf),this.TW*s,this.surf*s);
    c.strokeStyle=COL.surf; c.lineWidth=2; c.beginPath(); c.moveTo(X(0),Y(this.SH+this.surf)); c.lineTo(X(this.TW),Y(this.SH+this.surf)); c.stroke(); c.restore();
    c.save(); c.strokeStyle=COL.wall; c.lineWidth=2.2; c.beginPath();
    c.moveTo(X(0),Y(this.SH+this.TH)); c.lineTo(X(0),Y(this.SH)); c.lineTo(X(this.TW),Y(this.SH)); c.lineTo(X(this.TW),Y(this.SH+this.TH)); c.stroke(); c.restore();
    var opened = this.run.state!=="idle";
    this.HOLES.forEach(function(ho,i){
      var v=self.speed(i), hy=self.SH+ho.hb;
      if(opened && v>0){
        var tf=Math.sqrt(2*hy/G), tt=Math.min(tf, self.run.t);
        c.save(); c.strokeStyle="rgba(74,144,217,.85)"; c.lineWidth=Math.max(2.5, s*0.012); c.lineCap="round"; c.beginPath();
        for(var k=0;k<=30;k++){ var u=tt*k/30, x=self.TW+v*u, y=hy-0.5*G*u*u; if(k) c.lineTo(X(x),Y(y)); else c.moveTo(X(x),Y(y)); }
        c.stroke(); c.restore();
      }
    });
    c.save(); c.fillStyle="rgba(74,144,217,.9)";
    this.drops.forEach(function(d){ c.beginPath(); c.arc(X(d.x),Y(d.y),2.2,0,7); c.fill(); }); c.restore();
    this.HOLES.forEach(function(ho,i){
      var hy=self.SH+ho.hb;
      /* 栓は半分くらい壁の中に入れる */
      if(!opened){ c.save(); c.fillStyle="#c0392b"; c.strokeStyle="#7a1710"; c.lineWidth=1; rrect(c, X(self.TW)-5, Y(hy)-4.5, 11, 9, 2); c.fill(); c.stroke(); c.restore(); }
      else { c.save(); c.fillStyle="#2b323c"; c.fillRect(X(self.TW)-1.5, Y(hy)-2.5, 3, 5); c.restore(); }
      T(c, ho.name, X(0)-6, Y(hy), {size:12, align:"right", bold:true, col:COL.ink});
      c.save(); c.strokeStyle="rgba(47,111,159,.45)"; c.setLineDash([3,3]); c.lineWidth=1; c.beginPath(); c.moveTo(X(0)+2,Y(hy)); c.lineTo(X(self.TW)-6,Y(hy)); c.stroke(); c.restore();
    });
    if(!opened){ var ym=Y(this.SH+this.HOLES[1].hb);
      T(c,"← 栓をしている", X(this.TW)+12, ym, {size:12,bold:true,col:"#c0392b",halo:true}); }
    var yS=Y(this.SH+this.surf), yD=Y(this.SH+this.HOLES[2].hb);
    notebook(c,W,H);
    this.msg.innerHTML = ""; this.msg.hidden = true;   /* 第7回：穴ごとの深さの記述は出さない */
  }
};

/* ---------------- ①-2 水圧（水の重さによる圧力） ---------------- */
var S12 = {
  D:2.0, SZ:{rect:{w:0.33,h:0.44}, circle:{r:0.22}, trap:{wb:0.42,wt:0.22,h:0.44}},
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.kind="rect"; this.zc=0.70; this.col=false; this.mol=false; this.tm=0;
    this.run = new Runner({
      step:function(dt,r){ var hh=self.half(); self.zc = clamp(0.06+hh + r.t*0.32, 0.06+hh, self.zmaxC()); self.sl.set(self.zc-hh); return self.zc >= self.zmaxC()-1e-9; },
      draw:function(){ self.draw(); },
      reset:function(){ self.zc = 0.06+self.half(); self.sl.set(0.06); },
      info:function(r){ return '上の面の深さ <b>'+(self.zc-self.half()).toFixed(2)+'</b> m'; }
    });
    this.run.bind(sec);
    this.sl = wireTSlider(sec,"h",function(v){ self.zc=clamp(v+self.half(), 0.06+self.half(), self.zmaxC()); self.run.touch(); self.draw(); self.run.label(); });
    this.seg = wireSeg(sec,"shape",function(v){ self.kind=v; self.zc=clamp(self.zc, 0.06+self.half(), self.zmaxC()); self.run.touch(); self.draw(); });
    this.cc = wireChk(sec,"col",function(on){ self.col=on; self.draw(); });
    this.cm = wireChk(sec,"mol",function(on){ self.mol=on; self.anim(); self.draw(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.kind="rect"; self.seg.set("rect"); self.col=false; self.cc.set(false); self.mol=false; self.cm.set(false);
      self.run.reset(); self.zc=0.70; self.draw(); self.run.label(); });
    bindDrag(this.cv, function(x,y){ return !self.v3 && self.hit(x,y); }, function(x,y){ self.zc = clamp(self.zFromY(y), 0.06+self.half(), self.zmaxC()); self.sl.set(self.zc-self.half()); self.run.touch(); self.draw(); }, null,
             function(){ return self.run.state!=="run"; });
    /* ３次元表示（rotation-box_tip-or-slip と同じ：物体をつかむと深さ、ほかをドラッグすると視点） */
    this.v3=false; this.cam={az:-35, el:25};
    var b3=sec.querySelector(".v3btn"), vb=document.createElement("div"); vb.className="viewbtns3"; vb.hidden=true;
    vb.innerHTML='<button class="b tiny3" type="button" data-az="-35" data-el="25">斜め上から</button><button class="b tiny3" type="button" data-az="0" data-el="0">横から</button>';
    this.cv.parentElement.style.position="relative"; this.cv.parentElement.appendChild(vb); this.vb=vb;
    b3.addEventListener("click", function(){ b3.classList.remove("pglow"); self.v3=!self.v3; b3.classList.toggle("on", self.v3); b3.setAttribute("aria-pressed", self.v3); b3.textContent=self.v3? "２次元表示にもどす" : "３次元表示"; vb.hidden=!self.v3; self.draw(); });
    vb.querySelectorAll("button").forEach(function(b){ b.addEventListener("click", function(){ self.cam.az=parseFloat(b.dataset.az); self.cam.el=parseFloat(b.dataset.el); self.draw(); }); });
    S12_attach3d(this);
    onResize(this.cv.parentElement, function(){ self.draw(); });
    this.draw(); this.run.label();
  },
  zmaxC:function(){ return this.D-this.half()-0.04; },
  anim:function(){
    var self=this; if(this._raf) return; var last=0;
    var loop=function(ts){ if(!self.mol || self.sec.offsetParent===null){ self._raf=0; return; }
      self.tm += last? Math.min(0.05,(ts-last)/1000) : 0; last=ts; if(self.run.state!=="run") self.draw(); self._raf=requestAnimationFrame(loop); };
    this._raf=requestAnimationFrame(loop);
  },
  half:function(){ var z=this.SZ[this.kind]; return this.kind==="circle"? z.r : z.h/2; },
  hit:function(x,y){ var g=this.g; if(!g) return false; var hh=this.half(); return Math.abs(y-g.Y(this.zc)) < hh*g.s+10 && Math.abs(x-g.X(0)) < 0.34*g.s; },
  zFromY:function(y){ return (y - this.g.Y(0))/this.g.s; },
  /* 物体の右下の角（手でつかむところ） */
  corner:function(){ var sz=this.SZ[this.kind];
    if(this.kind==="circle") return [sz.r*0.72, sz.r*0.72];
    if(this.kind==="trap") return [sz.wb/2, sz.h/2];
    return [sz.w/2, sz.h/2]; },
  draw:function(){
    if(this.v3){ S12_draw3d(this); return; }
    var self=this, f=fitCanvas(this.cv, function(W){ return clamp(W*0.66, 280, 400); }), c=f.c, W=f.W, H=f.H;
    var air=0.42, s=Math.min((H-26)/(this.D+air), (W-20)/2.7), yS=8+air*s, xc=W*0.5;
    var X=function(x){ return xc+x*s; }, Y=function(z){ return yS+z*s; };
    this.g={X:X,Y:Y,s:s};
    c.clearRect(0,0,W,H);
    c.fillStyle=COL.water; c.fillRect(8,yS,W-16,this.D*s);
    var sz=this.SZ[this.kind], hh=this.half(), P=shapePoly(this.kind,sz), ztop=this.zc-hh;
    if(this.mol){
      if(this._mW!==W || this._mS!==s){ this._mW=W; this.mols=makeMolecules((8-xc)/s,(W-8-xc)/s,0,this.D,0.11); this._mS=s; }
      var ins=function(x,y,pad){ var lx=(x-xc)/s, lz=(y-Y(self.zc))/s, p=pad/s;
        if(self.kind==="circle") return Math.hypot(lx,lz) < sz.r+p;
        if(self.kind==="trap"){ if(Math.abs(lz)>sz.h/2+p) return false; var hw=(sz.wt+(sz.wb-sz.wt)*clamp((lz+sz.h/2)/sz.h,0,1))/2; return Math.abs(lx)<hw+p; }
        return Math.abs(lx)<sz.w/2+p && Math.abs(lz)<sz.h/2+p; };
      drawMolecules(c, this.mols, X, Y, s, function(x,y,pad){ return ins(x,y,pad); }, this.tm, [8, yS+1, W-16, this.D*s-1]);
    }
    c.strokeStyle=COL.surf; c.lineWidth=2; c.beginPath(); c.moveTo(8,yS); c.lineTo(W-8,yS); c.stroke();
    ground(c,8,W-8,Y(this.D)+0.5);
    T(c,"水面",14,yS-11,{size:11,col:"#2f6f9f",bold:true});
    depthLines(c, 8, W-8, Y, [0.5,1.0,1.5], "m1");
    var cw = this.kind==="rect"? sz.w/2 : this.kind==="trap"? sz.wt/2 : 0.06;
    if(this.col){
      c.save(); c.fillStyle="rgba(47,111,159,.12)"; c.fillRect(X(-cw),yS,2*cw*s,ztop*s);
      c.strokeStyle=COL.dashed; c.setLineDash([5,4]); c.lineWidth=1.4; c.strokeRect(X(-cw),yS,2*cw*s,ztop*s); c.restore();
      if(ztop*s > 40){ T(c,"水の柱", X(cw)+8, yS+ztop*s*0.35, {size:12,bold:true,col:COL.dashed,halo:true});
        T(c,"重さ ρShg", X(cw)+8, yS+ztop*s*0.35+17, {size:12,col:COL.dashed,halo:true}); }
    }
    drawPoly(c, P, function(x){ return X(x); }, function(y){ return Y(self.zc+y); }, "#ffffff", "#2b323c", 1.8);
    /* スタート後：物体の右下を手でつかんで、下へ引っぱる（矢印はこのあと上書き） */
    if(this.run.state!=="idle"){ var cr=this.corner(); pullHand(c, X(cr[0]), Y(this.zc+cr[1])); }
    var pts = surfPoints(this.kind, sz, 0.085), kL = 1.6e-5;
    pts.forEach(function(p){
      var d = self.zc + p.y; if(d<=0) return;
      var L = Math.max(0.012, RHO_W*G*d*kL), gap=0.012;
      arrow(c, X(p.x+p.nx*(gap+L)), Y(self.zc+p.y+p.ny*(gap+L)), X(p.x+p.nx*gap), Y(self.zc+p.y+p.ny*gap), COL.press, 1.7, 7);
    });
    var xd = X(-0.62);
    dimArrow(c, xd, yS+1, xd, Y(ztop)-1, "#2f6f9f");
    SYM(c,"h",null,xd+5,(yS+Y(ztop))/2,{size:15,col:"#2f6f9f",halo:true});
    c.save(); c.strokeStyle="rgba(47,111,159,.55)"; c.setLineDash([3,3]); c.beginPath(); c.moveTo(xd-4,Y(ztop)); c.lineTo(X(-cw-0.02),Y(ztop)); c.stroke(); c.restore();
    if(this.run.state==="idle") dragHint(c,"物体をドラッグ", X(-0.64), Y(this.zc)+20, {size:11.5,align:"right"});
    notebook(c,W,H);
    var pt=RHO_W*G*ztop, pb=RHO_W*G*(this.zc+hh);
    this.msg.innerHTML = '上の面：深さ <span class="num">'+ztop.toFixed(2)+'</span> m、水圧 '+tex("\\rho hg")+' ＝ <span class="num">'+sci(pt)+'</span> Pa<br>'+
      '下の面：深さ <span class="num">'+(this.zc+hh).toFixed(2)+'</span> m、水圧 ＝ <span class="num">'+sci(pb)+'</span> Pa　（矢印の長さ＝水圧の大きさ）';
  }
};

/* ---------------- ①-3 実際の水圧（大気圧＋水圧） ---------------- */
var S13 = {
  HM:52, HMAX:40, BH:9,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.h=20; this.withAir=true; this.col=false;
    this.run = new Runner({
      step:function(dt,r){ self.h = Math.min(self.HMAX, r.t*5); self.sl.set(self.h); return self.h>=self.HMAX; },
      draw:function(){ self.draw(); },
      reset:function(){ self.h=0; self.sl.set(0); },
      info:function(r){ return '上の面の深さ <b>'+self.h.toFixed(1)+'</b> m'; }
    });
    this.run.bind(sec);
    this.sl = wireTSlider(sec,"h",function(v){ self.h=v; self.run.touch(); self.draw(); self.run.label(); });
    this.seg = wireSeg(sec,"air",function(v){ self.withAir=(v==="on"); self.draw(); });
    this.cc = wireChk(sec,"col",function(on){ self.col=on; self.draw(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.withAir=true; self.seg.set("on"); self.col=false; self.cc.set(false); self.run.reset(); self.h=20; self.sl.set(20); self.draw(); self.run.label(); });
    bindDrag(this.cv, function(x,y){ var g=self.g; return g && Math.abs(x-g.xc)<g.bw/2+12 && y>g.yT-10 && y<g.yB+10; },
      function(x,y,first){ var g=self.g; if(first){ self._gy=y-g.yT; } self.h=clamp(Math.round(((y-self._gy)-g.top)/g.pxm*2)/2, 0, self.HMAX); self.sl.set(self.h); self.run.touch(); self.draw(); self.run.label(); }, null,
      function(){ return self.run.state!=="run"; });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    this.draw(); this.run.label();
  },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return clamp(W*0.66, 320, 410); }), c=f.c, W=f.W, H=f.H;
    var tx0=10, tx1=W*0.58, top=66, bot=H-22;
    var yOf=function(h){ return top+(bot-top)*h/self.HM; };
    var u = clamp(W*0.026, 9, 15);
    var LEN=function(P){ return u*P/1.0e5; };
    var base=(this.withAir? P0:0), pAt=function(d){ return base+RHO_W*G*d; };
    c.clearRect(0,0,W,H);
    c.fillStyle=COL.water; c.fillRect(tx0,top,tx1-tx0,bot-top);
    var xc=(tx0+tx1)/2+18, bw=Math.max(24, (tx1-tx0)*0.1125), yT=yOf(this.h), yB=yOf(this.h+this.BH);
    this.g={top:top, bot:bot, xc:xc, bw:bw, yT:yT, yB:yB, pxm:(bot-top)/this.HM};
    /* 水と空気の柱 */
    if(this.col){
      c.save(); c.fillStyle="rgba(47,111,159,.14)"; c.fillRect(xc-bw/2,top,bw,yT-top);
      c.setLineDash([5,4]); c.strokeStyle=COL.dashed; c.lineWidth=1.3; c.strokeRect(xc-bw/2,top,bw,yT-top);
      if(this.withAir){ c.fillStyle="rgba(160,190,220,.16)"; c.fillRect(xc-bw/2,2,bw,top-2); c.strokeStyle="rgba(47,111,159,.55)"; c.strokeRect(xc-bw/2,2,bw,top-2); }
      c.restore();
      if(this.withAir) T(c,"空気の柱（大気圧のもと）", xc+bw/2+6, 14, {size:11,col:COL.dashed,bold:true,halo:true});
      if(yT-top>26) T(c,"水の柱", xc+bw/2+6, top+Math.min(40,(yT-top)/2), {size:11,col:COL.dashed,bold:true,halo:true});
    }
    c.save(); c.strokeStyle=COL.wall; c.lineWidth=2; c.beginPath(); c.moveTo(tx0,top-18); c.lineTo(tx0,bot); c.lineTo(tx1,bot); c.lineTo(tx1,top-18); c.stroke(); c.restore();
    c.strokeStyle=COL.surf; c.lineWidth=2; c.beginPath(); c.moveTo(tx0,top); c.lineTo(tx1,top); c.stroke();
    T(c,"水面", tx0+(tx1-tx0)*0.30, top-10, {size:11,col:"#2f6f9f",bold:true,halo:true});
    depthLines(c, tx0, tx1, yOf, [10,20,30,40], "int");
    if(this.withAir){
      var L0=LEN(P0);
      var xa=tx0+(tx1-tx0)*0.10; arrow(c,xa,top-4-L0,xa,top-3,COL.press,2,8);   /* 第7回：右はしの矢印は出さない */
      T(c,"大気圧 p₀", tx0+(tx1-tx0)*0.10+10, top-L0*0.5-2, {size:11.5,col:COL.press,bold:true,halo:true});
    }
    c.save(); c.fillStyle="#e9edf2"; c.strokeStyle="#2b323c"; c.lineWidth=1.8; c.fillRect(xc-bw/2,yT,bw,yB-yT); c.strokeRect(xc-bw/2,yT,bw,yB-yT); c.restore();
    if(this.run.state!=="idle") pullHand(c, xc+bw/2, yB);
    var gp=3, Lt=LEN(pAt(this.h)), Lb=LEN(pAt(this.h+this.BH));
    [-0.25,0.25].forEach(function(o){ var x=xc+o*bw;
      if(Lt>1) arrow(c,x,yT-gp-Lt,x,yT-gp,COL.press,2,8);
      arrow(c,x,yB+gp+Lb,x,yB+gp,COL.press,2,8); });
    [0.2,0.5,0.8].forEach(function(fz){ var d=self.h+self.BH*fz, y=yT+(yB-yT)*fz, L=LEN(pAt(d));
      if(L>1){ arrow(c,xc-bw/2-gp-L,y,xc-bw/2-gp,y,COL.press,2,8); arrow(c,xc+bw/2+gp+L,y,xc+bw/2+gp,y,COL.press,2,8); } });
    if(this.run.state==="idle") dragHint(c,"物体は上下にドラッグできる", tx1-6, bot-14, {size:11,align:"right"});
    var xd=tx0+30; if(this.h>0.8){ dimArrow(c,xd,top+1,xd,yT-1,"#2f6f9f"); T(c,"h = "+this.h.toFixed(1)+" m", xd+6, (top+yT)/2, {size:12,col:"#2f6f9f",halo:true,bold:true}); }
    c.save(); c.strokeStyle="rgba(47,111,159,.55)"; c.setLineDash([3,3]); c.beginPath(); c.moveTo(xd-4,yT); c.lineTo(xc-bw/2-4,yT); c.stroke(); c.restore();
    /* 右：式と、上の面・下の面の棒グラフ */
    c.save(); c.fillStyle="#fff"; c.strokeStyle="#c0392b"; c.lineWidth=2; rrect(c, tx1+12, 8, W-tx1-20, 34, 10); c.fill(); c.stroke(); c.restore();
    T(c, this.withAir? "p′ = p₀ + ρhg" : "p = ρhg", (tx1+12+W-8)/2, 25, {size:clamp(W*0.034,14,20), bold:true, col:"#c0392b", align:"center", it:true});
    /* 第8回：上の面・下の面の圧力を横向きの棒で。物体の面と同じ高さに置き、物体といっしょに上下する */
    var gx0=tx1+16, gw=W-gx0-12, sc=gw*0.94/(P0+RHO_W*G*(this.HMAX+this.BH)), bh=14;
    [["上の面",this.h,yT,-1],["下の面",this.h+this.BH,yB,1]].forEach(function(b){
      var y=b[2], pw=RHO_W*G*b[1], y0=y-bh/2;
      c.save(); c.strokeStyle="rgba(43,50,60,.35)"; c.setLineDash([3,3]); c.lineWidth=1; c.beginPath(); c.moveTo(xc+bw/2+4,y); c.lineTo(gx0,y); c.stroke(); c.restore();
      if(self.withAir){ c.fillStyle="#d7dee6"; c.fillRect(gx0,y0,P0*sc,bh); c.strokeStyle="#2b323c"; c.lineWidth=1.1; c.strokeRect(gx0,y0,P0*sc,bh); }
      if(pw>0){ c.fillStyle="#7f9db8"; c.fillRect(gx0+base*sc,y0,pw*sc,bh); c.strokeStyle="#2b323c"; c.lineWidth=1.1; c.strokeRect(gx0+base*sc,y0,pw*sc,bh); }
      var ly=(b[3]<0)? y0-9 : y0+bh+10;
      T(c, b[0]+"　"+sci(base+pw)+" Pa", gx0+4, ly, {size:11,bold:true,halo:true});
    });
    if(this.withAir) T(c,"うすい色：大気圧　こい色：水圧", gx0+gw/2, 56, {size:10,col:COL.sub,align:"center"});
    notebook(c,W,H);
    var pt=pAt(this.h), pb=pAt(this.h+this.BH);
    this.msg.innerHTML = '上の面（深さ <span class="num">'+this.h.toFixed(1)+'</span> m）：<span class="num">'+sci(pt,3)+'</span> Pa　／　下の面（深さ <span class="num">'+(this.h+this.BH).toFixed(1)+'</span> m）：<span class="num">'+sci(pb,3)+'</span> Pa<br>'+
      '下の面と上の面の差：<span class="num">'+sci(pb-pt)+'</span> Pa（物体の高さ '+this.BH+' m ぶんの水圧。深さを変えても同じ）';
  }
};
