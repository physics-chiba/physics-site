/* =========================================================================
   モード⑤ 入試物理（第3回で追加）
   5-1 ばね付きピストン（東北学院大 2018 改）
   5-2 ピストンの上の液体が広い部分へ流れ出すピストン（東大 2011 をもとに）
   5-3 熱気球（大阪工大 2016）〔B〕以降
   5-4 浮沈子（東大 2015）Ⅲ
   問題文はそのまま写さず、設定と考え方だけを書く。数値はこのページで決めたもの。
   ========================================================================= */

/* 横向きのばね（コイルの輪を斜めから見た形）。x0 → x1、中心の高さ y、輪の半径 r、巻き数 n */
function coilH(c, x0, x1, y, r, n, col){
  var L=x1-x0; c.save(); c.strokeStyle=col||"#3a414c"; c.lineWidth=1.6; c.lineJoin="round"; c.beginPath();
  var N=Math.round(n*24), e=6;
  c.moveTo(x0, y); c.lineTo(x0+e, y);
  for(var i=0;i<=N;i++){ var s=i/N, th=2*Math.PI*n*s, x=x0+e+(L-2*e)*s-r*0.42*Math.sin(th), yy=y-r*Math.cos(th);
    c.lineTo(x, yy); }
  c.lineTo(x1, y); c.stroke(); c.restore();
}
/* 問題のカードの共通部分 */
function H_exam(src, body){ return '<div class="qcard exam"><p class="qt">問題の設定<span class="src">'+src+'</span></p>'+body+'</div>'; }

/* ---------------- ⑤-1 ばね付きピストン ----------------
   水平な容器。左の壁に温度調節器（ヒーター）。断面積 S のピストンは、ばね定数 k のばねで右の壁とつながる。
   右の部屋は大気（圧力 P₀）に通じている。容器とピストンは断熱材。1 mol の単原子分子。
   初め：ばねは自然の長さ、気体の長さ L。ゆっくり温めて、ばねが 2L 縮むまで。
   数値：S＝0.10 m²、L＝0.25 m、P₀＝1.0×10⁵ Pa、k＝1.0×10⁴ N/m → P₁＝1.5×10⁵ Pa */
var S51 = {
  DUR:10, S:0.10, L:0.25, P0:1.0e5, k:1.0e4,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.gas=new Gas(24, 51); this.clk=0; this.show=true;
    this.run=new Runner({ startText:"▶ スタート（ゆっくり温める）", step:function(dt){ self.clk+=dt; self.mv(dt); self.tb.sync(); return self.run.t>=self.DUR; }, draw:function(){ self.draw(); }, reset:function(){} });
    this.run.bind(sec);
    this.tb=wireTimeBar(sec, this.run, function(){ return self.DUR; }, function(){});
    sec.querySelector(".ctrls").insertAdjacentHTML("afterend", panelHTML(["p","V","T"]));
    this.sc=wireChk(sec,"force",function(on){ self.show=on; self.draw(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.show=true; self.sc.set(true); resetSlow(sec,self.run); self.run.reset(); self.tb.sync(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    idleLoop(sec, function(dt){ if(self.run.state!=="run"){ self.clk+=dt; self.mv(dt); self.draw(); } });
    this.draw();
  },
  dx:function(){ return 2*this.L*clamp(this.run.t/this.DUR,0,1); },        /* ばねの縮み［m］ */
  st:function(d){ var p=this.P0+this.k*d/this.S, V=this.S*(this.L+d); return {p:p, V:V, T:p*V/RGAS}; },
  mv:function(dt){ var s=this.st(this.dx()); if(this.g) this.gas.step(dt, this.g.L, this.g.h, 52*Math.sqrt(s.T/300), 4); },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return W<640? clamp(W*1.30, 500, 600) : clamp(W*0.46, 340, 420); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var narrow=W<640, d=this.dx(), s=this.st(d), s0=this.st(0), s1=this.st(2*this.L), running=this.run.state==="run";
    var aw=narrow? W : W*0.50, ah=narrow? H*0.46 : H;
    /* 容器：気体の長さ 0〜3L を Lmax に。ばねの自然の長さは L（右の部屋の長さ 2L＋ピストン） */
    var ox=46, h=narrow? 80 : 92, pt=16, unit=(aw-ox-70)/(4*this.L), Lg=(this.L+d)*unit, xr=ox+(3*this.L)*unit+pt+this.L*0.9*unit, cy=narrow? ah*0.50 : ah*0.42;
    this.g={L:Lg, h:h};
    var F=new CylFrame(ox, cy, "right");
    drawCylinder(c, F, {L:Lg, Lmax:xr-ox, h:h, T:s.T, gas:this.gas, r:4, pt:pt, cont:"ins", noInsLab:true, heater:true, heat:(running? 1 : 0), clk:this.clk, thermo:true, thLen:28, p0:false, pvt:false});
    if(Lg>50) T(c, "p, V, T", ox+Lg*0.42, cy+2, {size:14, bold:true, it:true, serif:true, col:"#1f3b57", align:"center", halo:true});
    /* 右の壁（上にすき間：大気に通じる） */
    var wt=13; c.save(); c.fillStyle="#d9b98c"; c.strokeStyle="#7a5230"; c.lineWidth=1.3; c.fillRect(xr, cy-h/2+18, wt, h+wt-18); c.strokeRect(xr, cy-h/2+18, wt, h+wt-18); c.restore();
    var px0=narrow? xr-70 : xr+wt+6, py0=narrow? cy-h/2-wt-14 : cy-h/2-2, wp=SYM(c,"P","0",px0,py0,{size:13,bold:true,col:COLG.atm,halo:true}); T(c, "（大気）", px0+wp+2, py0, {size:11, bold:true, col:COLG.atm, halo:true});
    c.save(); c.strokeStyle=COLG.atm; c.setLineDash([3,3]); c.beginPath(); c.moveTo(xr+wt/2, cy-h/2-wt+2); c.lineTo(xr+wt/2, cy-h/2+16); c.stroke(); c.restore();
    /* ばね：ピストンの右の面 → 右の壁 */
    var xp=ox+Lg+pt; coilH(c, xp, xr, cy, h*0.26, 10, "#3a414c");
    T(c, "温度調節器", ox-8, cy+h/2+58, {size:11, bold:true, col:"#7a5230"});
    T(c, "断熱材", (ox+xr)/2+40, cy+h/2+58, {size:11, bold:true, col:"#7a5230", align:"center"});
    /* 長さの目盛り */
    var yd=cy+h/2+30; dimArrow(c, ox, yd, xp-pt, yd, "#3a414c"); T(c, d<1e-6? "L" : (d>2*this.L-1e-6? "3L" : "L + "+(d/this.L).toFixed(2)+"L"), (ox+xp-pt)/2, yd-11, {size:12, bold:true, it:true, serif:true, col:"#3a414c", align:"center", halo:true});
    if(d>0.002){ var x0n=ox+this.L*unit+pt; c.save(); c.setLineDash([4,3]); c.strokeStyle="#9aa1ab"; c.beginPath(); c.moveTo(x0n, cy-h/2); c.lineTo(x0n, cy+h/2); c.stroke(); c.restore();
      T(c, "ばねの縮み "+(d/this.L).toFixed(2)+"L", (x0n+xp)/2+30, cy-h/2-24, {size:11, bold:true, col:"#9c4e06", align:"center", halo:true}); }
    /* 力（作用点に ・）：気体が押す力 pS（右向き）、大気の力 P₀S と ばねの力 kx（左向き）。ピストンの面から */
    if(this.show){ var kF=narrow? 0.0042 : 0.005, fp=s.p*this.S*kF/1000, f0=this.P0*this.S*kF/1000, fk=this.k*d*kF/1000;
      var xa=ox+Lg, xb=ox+Lg+pt;
      fArrow(c, xa, cy-h*0.30, xa+fp*1000, cy-h*0.30, COLG.gasF, 3, 10); SYM(c,"pS",null,xa+fp*1000+6,cy-h*0.30-12,{size:13,bold:true,col:COLG.gasF,halo:true});
      fArrow(c, xb, cy+h*0.30, xb-f0*1000, cy+h*0.30, COLG.atm, 3, 10); var aw0=SYM(c,"P","0",xb-f0*1000-34,cy+h*0.30+14,{size:13,bold:true,col:COLG.atm,halo:true}); SYM(c,"S",null,xb-f0*1000-34+aw0,cy+h*0.30+14,{size:13,bold:true,col:COLG.atm,halo:true});
      if(fk>0.0005) { fArrow(c, xb, cy, xb-fk*1000, cy, "#7b3fd4", 3, 10); SYM(c,"kx",null,xb-fk*1000-6,cy-12,{size:13,bold:true,col:"#7b3fd4",halo:true,align:"right"}); } }
    /* p-V 図 */
    var gx0=narrow? 56 : aw+44, gy0=H-40, gx1=W-14, gy1=narrow? ah+44 : 44;
    graphTitle(c, "p-V 図（面積＝気体がした仕事）", gx0-34, gy1-24);
    var P=plotFrame(c, gx0, gy0, gx1, gy1, [0,9], [0,2], {xl:"V〔×10⁻² m³〕", yl:"p〔×10⁵ Pa〕", xstep:1, ystep:0.5});
    var pv=function(dd){ var q=self.st(dd); return [q.V*100, q.p/1e5]; }, a=pv(0), b=pv(d);
    if(d>0.002){ c.save(); c.fillStyle="rgba(31,111,178,.16)"; c.fillRect(P.X(a[0]), P.Y(1), P.X(b[0])-P.X(a[0]), P.Y(0)-P.Y(1));
      c.fillStyle="rgba(123,63,212,.22)"; c.beginPath(); c.moveTo(P.X(a[0]),P.Y(1)); c.lineTo(P.X(b[0]),P.Y(b[1])); c.lineTo(P.X(b[0]),P.Y(1)); c.closePath(); c.fill(); c.restore(); }
    var e=pv(2*this.L); c.save(); c.setLineDash([5,4]); c.strokeStyle="#9aa1ab"; c.lineWidth=1.3; c.beginPath(); c.moveTo(P.X(a[0]),P.Y(a[1])); c.lineTo(P.X(e[0]),P.Y(e[1])); c.stroke(); c.restore();
    c.save(); c.strokeStyle="#c0392b"; c.lineWidth=2.6; c.beginPath(); c.moveTo(P.X(a[0]),P.Y(a[1])); c.lineTo(P.X(b[0]),P.Y(b[1])); c.stroke(); c.restore();
    dot(c, P.X(a[0]), P.Y(a[1]), 4.5, "#3a414c"); T(c, "初め", P.X(a[0]), P.Y(a[1])-14, {size:11, col:COL.sub, align:"center", halo:true});
    dot(c, P.X(b[0]), P.Y(b[1]), 6, "#c0392b");
    if(d>this.L*0.6){ T(c, "大気を押す仕事 P₀ΔV", P.X((a[0]+b[0])/2), P.Y(0.45), {size:11, bold:true, col:"#1f5f99", align:"center", halo:true});
      T(c, "ばねのエネルギー ½kx²", P.X(b[0])+4, P.Y(b[1])-16, {size:11, bold:true, col:"#5b2aa8", align:"right", halo:true}); }
    T(c, "グラフは直線（p は V の 1 次関数）", P.x1, P.y1+4, {size:11, col:COL.sub, align:"right", halo:true});
    notebook(c,W,H);
    var Ws=(s0.p+s.p)/2*(s.V-s0.V), dU=1.5*(s.p*s.V-s0.p*s0.V);
    setPanel(this.sec, {p:[(s.p/1e5).toFixed(2), running? 1 : 0], V:[(s.V*100).toFixed(2), running? 1 : 0], T:[String(Math.round(s.T)), running? 1 : 0]});
    var mh='気体がした仕事 '+tex(WS)+' = <span class="num">'+Math.round(Ws)+'</span> J（大気へ '+Math.round(this.P0*this.S*d)+' J ＋ ばねへ '+Math.round(0.5*this.k*d*d)+' J）　'+tex("\\Delta U")+' = <span class="num">'+Math.round(dU)+'</span> J　'+tex("Q=\\Delta U+"+WS)+' = <span class="num">'+Math.round(dU+Ws)+'</span> J';
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};

/* ---------------- ⑤-2 液体が広い部分へ流れ出すピストン（東大 2011 をもとに） ----------------
   鉛直な容器。下は断面積 S、高さ 2h より上は断面積 2S。質量の無視できるピストンの上に、一様な密度 ρ の液体。液体の上は真空。
   気体（単原子分子）を下のヒーターで加熱する。気体の高さ x（単位 h）、圧力 p（単位 p₁＝ρgh：液体の高さ h の圧力）。
   Ⅰ：x＝0.5 → 1 は、液体が細い部分だけにあり、定圧（p＝p₁）。
   Ⅱ：x＞1 では液体が広い部分へ流れ出し、液体の柱が低くなる → p＝p₁(1.5−0.5x)。
   加える熱 Q(x) は x＝X＝1.875 で最大。それより熱を加えると、つり合いの位置がなくなり、ピストンは急に上がる */
var S52 = {
  DUR:12, X:1.875, x0:0.5,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.gas=new Gas(22, 52); this.clk=0; this.jump=0;
    this.run=new Runner({ startText:"▶ スタート（加熱する）", step:function(dt){ self.clk+=dt; self.mv(dt); self.tb.sync(); return self.run.t>=self.DUR; }, draw:function(){ self.draw(); }, reset:function(){} });
    this.run.bind(sec);
    this.tb=wireTimeBar(sec, this.run, function(){ return self.DUR; }, function(){});
    sec.querySelector(".ctrls").insertAdjacentHTML("afterend", panelHTML(["p","V","T"]));
    [["p","×ρgh"],["V","×Sh"],["T","×ρgSh²/R"]].forEach(function(q){ sec.querySelector('.gcard[data-k="'+q[0]+'"] .gu').textContent=q[1]; });
    sec.querySelector(".resetall").addEventListener("click", function(){ resetSlow(sec,self.run); self.run.reset(); self.tb.sync(); });
    this.Qmax=this.Q(this.X);
    onResize(this.cv.parentElement, function(){ self.draw(); });
    idleLoop(sec, function(dt){ if(self.run.state!=="run"){ self.clk+=dt; self.mv(dt); self.draw(); } });
    this.draw();
  },
  p:function(x){ return x<=1? 1 : 1.5-0.5*x; },
  Wto:function(x){ var w=1*(Math.min(x,1)-this.x0); if(x>1) w+=1.5*(x-1)-0.25*(x*x-1); return w; },          /* 気体がした仕事（単位 p₁Sh） */
  Q:function(x){ return 1.5*(this.p(x)*x-1*this.x0)+this.Wto(x); },
  /* 時間 → 気体の高さ。0〜9 s：Q を一定の割合で増やす（x≦X）。9 s 以後：急に上がる（X → 2） */
  xOf:function(t){ var T1=9; if(t<=T1){ var Qt=this.Qmax*t/T1, a=this.x0, b=this.X; for(var i=0;i<40;i++){ var m=(a+b)/2; if(this.Q(m)<Qt) a=m; else b=m; } return (a+b)/2; }
    var u=clamp((t-T1)/0.9,0,1); return this.X+(2-this.X)*u*u; },
  mv:function(dt){ var x=this.xOf(this.run.t), Tn=this.p(x)*x; if(this.g) this.gas.step(dt, this.g.L, this.g.h, 50*Math.sqrt(Tn/0.5), 4); },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return W<640? clamp(W*1.75, 640, 760) : clamp(W*0.52, 400, 470); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var narrow=W<640, t=this.run.t, x=this.xOf(t), p=this.p(x), Tn=p*x, running=this.run.state==="run", Qn=(t<=9)? this.Qmax*t/9 : this.Qmax;
    var aw=narrow? W : W*0.44, ah=narrow? H*0.46 : H;
    /* 容器（縦）：底 yB、1 h あたり u px。細い部分 0〜2h（幅 w）、広い部分 2h〜3h（幅 2w） */
    var u=(ah-70)/3.05, yB=ah-30, w=narrow? 64 : 72, cx=aw*0.46, Y=function(z){ return yB-z*u; }, wt=9, pt=10;
    ground(c, cx-w-60, cx+w+60, yB+wt+2);
    /* 液体：細い部分 x+pt' 〜 2h、広い部分 2h 〜 2h+(x−1)/2（x＞1） */
    var lnTop=2, lwTop=2+Math.max(0,x-1)*0.5;
    c.save(); c.fillStyle="rgba(84,156,224,.42)";
    c.fillRect(cx-w/2, Y(lnTop), w, Y(x)-Y(lnTop));
    if(x>1) c.fillRect(cx-w, Y(lwTop), 2*w, Y(2)-Y(lwTop));
    c.restore();
    /* 気体 */
    this.g={L:(x)*u, h:w};
    drawCylinder(c, new CylFrame(cx, yB, "up"), {L:x*u-pt, Lmax:2*u, h:w, T:150+300*Tn, gas:this.gas, r:3.6, pt:pt, cont:null, heater:true, heat:(running && t<9? 1 : 0), clk:this.clk, thermo:false, p0:false, pvt:false, wall:wt});
    if(x*u>60) T(c, "p, V, T", cx, Y(x*0.45), {size:14, bold:true, it:true, serif:true, col:"#1f3b57", align:"center", halo:true});
    /* 広い部分の壁 */
    c.save(); c.fillStyle="#c9ced6"; c.strokeStyle="#5b636e"; c.lineWidth=1.3;
    c.fillRect(cx-w-wt, Y(3), wt, Y(2)-Y(3)+wt); c.fillRect(cx+w, Y(3), wt, Y(2)-Y(3)+wt);
    c.fillRect(cx-w-wt, Y(2), w/2+wt, wt); c.fillRect(cx+w/2, Y(2), w/2+wt, wt);
    c.fillRect(cx-w-wt, Y(3)-wt, 2*w+2*wt, wt); c.restore();
    T(c, "真空", cx, Y(2.75), {size:12, bold:true, col:COL.sub, align:"center"});
    T(c, "液体", cx-w/2-10, Y(1.75), {size:11.5, bold:true, col:"#1f5f99", align:"right", halo:true});
    T(c, "断面積 2S", cx, Y(2.32), {size:11, bold:true, col:"#3a414c", align:"center", halo:true});
    T(c, "断面積 S", cx-w/2-16, Y(0.6), {size:11, bold:true, col:"#3a414c", align:"right"});
    T(c, "ヒーター", cx+w/2+16, yB-8, {size:10.5, bold:true, col:running? "#d2401a" : COL.sub});
    /* 高さの目盛り */
    var xs=cx-w-34; [0,1,2].forEach(function(z){ c.save(); c.strokeStyle="#9aa1ab"; c.beginPath(); c.moveTo(xs-4,Y(z)); c.lineTo(xs+4,Y(z)); c.stroke(); c.restore(); T(c, z? z+"h" : "0", xs-8, Y(z), {size:11, it:true, serif:true, col:COL.sub, align:"right"}); });
    c.save(); c.strokeStyle="#9aa1ab"; c.beginPath(); c.moveTo(xs, Y(0)); c.lineTo(xs, Y(2)); c.stroke(); c.restore();
    var xl=cx+w/2+12; c.save(); c.strokeStyle="#c0392b"; c.lineWidth=1.3; c.beginPath(); c.moveTo(xl, Y(0)); c.lineTo(xl, Y(x)); c.stroke(); c.restore(); T(c, "x = "+x.toFixed(2)+"h", xl+6, Y(x/2)+16, {size:11.5, bold:true, col:"#c0392b", halo:true});
    if(t>9) T(c, "つり合いの位置がなくなり、ピストンが急に上がる！", aw/2, 18, {size:12.5, bold:true, col:"#c0392b", align:"center", halo:true});
    /* 右：p-V 図と Q-x のグラフ */
    var gx0=narrow? 56 : aw+46, gx1=W-14, mid=narrow? ah+(H-ah)*0.52 : H*0.52;
    graphTitle(c, "p-V 図", gx0-34, (narrow? ah+20 : 18));
    var P=plotFrame(c, gx0, mid-34, gx1, narrow? ah+40 : 40, [0,2.2], [0,1.4], {xl:"V（単位 Sh）", yl:"p（単位 ρgh）", xstep:0.5, ystep:0.5});
    c.save(); c.setLineDash([5,4]); c.strokeStyle="#9aa1ab"; c.lineWidth=1.2; c.beginPath(); for(var i=0;i<=60;i++){ var xv=this.x0+(2-this.x0)*i/60; if(i) c.lineTo(P.X(xv),P.Y(this.p(xv))); else c.moveTo(P.X(xv),P.Y(this.p(xv))); } c.stroke(); c.restore();
    c.save(); c.fillStyle="rgba(92,196,122,.25)"; c.beginPath(); c.moveTo(P.X(this.x0),P.Y(0)); for(var j=0;j<=60;j++){ var xv2=this.x0+(x-this.x0)*j/60; c.lineTo(P.X(xv2),P.Y(this.p(xv2))); } c.lineTo(P.X(x),P.Y(0)); c.closePath(); c.fill(); c.restore();
    c.save(); c.strokeStyle="#c0392b"; c.lineWidth=2.6; c.beginPath(); for(var k=0;k<=60;k++){ var xv3=this.x0+(x-this.x0)*k/60; if(k) c.lineTo(P.X(xv3),P.Y(this.p(xv3))); else c.moveTo(P.X(xv3),P.Y(this.p(xv3))); } c.stroke(); c.restore();
    dot(c, P.X(x), P.Y(p), 6, "#c0392b");
    T(c, "Ⅰ 定圧", P.X(0.75), P.Y(1)-12, {size:11, bold:true, col:"#1f6fb2", align:"center", halo:true}); T(c, "Ⅱ 直線で下がる", P.X(1.55), P.Y(this.p(1.55))-14, {size:11, bold:true, col:"#1f6fb2", align:"center", halo:true});
    var gy2=narrow? H-36 : H-40;
    graphTitle(c, "加えた熱 Q と気体の高さ x", gx0-34, mid+4);
    var R=plotFrame(c, gx0, gy2, gx1, mid+26, [0,2.2], [0,3.0], {xl:"x（単位 h）", yl:"Q（単位 ρgSh²）", xstep:0.5, ystep:1});
    c.save(); c.strokeStyle="#9aa1ab"; c.setLineDash([5,4]); c.lineWidth=1.2; c.beginPath(); for(var q=0;q<=60;q++){ var xq=this.x0+(2-this.x0)*q/60; if(q) c.lineTo(R.X(xq),R.Y(this.Q(xq))); else c.moveTo(R.X(xq),R.Y(this.Q(xq))); } c.stroke(); c.restore();
    c.save(); c.strokeStyle="#e07b18"; c.lineWidth=2.4; c.beginPath(); for(var q2=0;q2<=60;q2++){ var xq2=this.x0+(Math.min(x,this.X)-this.x0)*q2/60; if(q2) c.lineTo(R.X(xq2),R.Y(this.Q(xq2))); else c.moveTo(R.X(xq2),R.Y(this.Q(xq2))); } c.stroke(); c.restore();
    c.save(); c.setLineDash([3,3]); c.strokeStyle="#c0392b"; c.beginPath(); c.moveTo(R.X(this.X),R.Y(0)); c.lineTo(R.X(this.X),R.Y(this.Qmax)); c.stroke(); c.restore();
    SYM(c,"X",null,R.X(this.X)+4,R.Y(0.25),{size:13,bold:true,col:"#c0392b"}); T(c, "Q が最大", R.X(this.X)-6, R.Y(this.Qmax)-12, {size:11, bold:true, col:"#c0392b", align:"right", halo:true});
    dot(c, R.X(x), R.Y(Math.min(Qn,this.Q(x))), 5.5, "#e07b18");
    notebook(c,W,H);
    setPanel(this.sec, {p:[p.toFixed(2), 0, "（1 mol）"], V:[x.toFixed(2), 0], T:[Tn.toFixed(2), 0]});
    var mh='気体の高さ '+tex("x")+' = <span class="num">'+x.toFixed(2)+'</span>'+tex("h")+'　圧力 '+tex("p")+' = <span class="num">'+p.toFixed(2)+'</span>'+tex("\\rho gh")+'　加えた熱 '+tex("Q")+' = <span class="num">'+Math.min(Qn,this.Q(x)).toFixed(2)+'</span>'+tex("\\rho gSh^2")+
      (x>1.5 && t<=9? '<br>加熱しているのに、温度（'+tex("px")+' に比例）は下がりはじめている。気体がする仕事が、受けとる熱より大きいから。' : x>1? '<br>液体が広い部分へ流れ出して液体の柱が低くなり、圧力が下がる。' : '<br>液体はまだ細い部分だけ。圧力は一定（定圧変化）。');
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};

/* ---------------- ⑤-3 熱気球（大阪工大 2016）〔B〕以降 ----------------
   球体の体積 V（変形しない、断熱性の高い素材）。開口部で外とつながり、中の空気の圧力は外と同じ。
   球体と空気以外の全質量 M。球体内の空気の温度 T。外の空気は温度 T₀、密度 ρ₀。
   中の空気の密度 ρ＝ρ₀T₀/T。気球にはたらく重力 F＝(M＋ρV)g、浮力 f＝ρ₀Vg。F＜f で浮き上がる。
   数値：V＝2000 m³、ρ₀＝1.2 kg/m³、T₀＝300 K、M＝500 kg → T_r＝ρ₀VT₀/(ρ₀V−M)≒379 K */
var S53 = {
  V:2000, r0:1.2, T0:300, TMAX:440,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.M=500; this.T=300; this.heat=0; this.alt=0; this.clk=0; this.out=[];
    var R=rng(53); this.mol=[]; for(var i=0;i<60;i++) this.mol.push([R(),R(),R()*Math.PI*2,0.06+0.08*R()]);
    sec.querySelector(".ctrls").insertAdjacentHTML("afterbegin", '<div class="prepbox"><div class="pgrp"><span class="ph">操作</span><button type="button" class="b hbtn" data-h="1">'+ICON.fire+'加熱する</button><button type="button" class="b hbtn cold" data-h="-1">'+ICON.ice+'冷やす</button><button type="button" class="b hstop">止める</button></div></div>');
    var rs=sec.querySelector(".rsrow"); if(rs){ sec.querySelector(".prepbox .pgrp").appendChild(rs.querySelector(".resetall")); rs.remove(); }
    sec.querySelectorAll(".hbtn").forEach(function(b){ b.addEventListener("click", function(){ self.heat=parseFloat(b.dataset.h); }); });
    sec.querySelector(".hstop").addEventListener("click", function(){ self.heat=0; });
    this.sM=wireSlider(sec,"M",function(v){ return v.toFixed(0)+" kg"; },function(v){ self.M=v; self.draw(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.M=500; self.sM.set(500); self.T=300; self.heat=0; self.alt=0; self.draw(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    idleLoop(sec, function(dt){ self.clk+=dt; self.T=clamp(self.T+self.heat*12*dt, self.T0, self.TMAX); if((self.T>=self.TMAX && self.heat>0) || (self.T<=self.T0 && self.heat<0)) self.heat=0;
      var net=self.lift(); self.alt=clamp(self.alt+(net>0? 0.35 : (self.alt>0? -0.35 : 0))*dt*Math.min(1,Math.abs(net)/200+0.3), 0, 1); self.draw(); });
    this.draw();
  },
  rho:function(T){ return this.r0*this.T0/T; },
  Tr:function(){ return this.r0*this.V*this.T0/(this.r0*this.V-this.M); },
  lift:function(){ return (this.r0*this.V - (this.M+this.rho(this.T)*this.V))*9.8; },     /* f − F［N］ */
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return W<640? clamp(W*1.55, 560, 680) : clamp(W*0.46, 340, 420); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var narrow=W<640, aw=narrow? W : W*0.44, ah=narrow? H*0.50 : H, Tk=this.T, rho=this.rho(Tk), F=(this.M+rho*this.V)*9.8, fb=this.r0*this.V*9.8, Tr=this.Tr();
    /* 地面と気球（浮くと上がる） */
    var gy=ah-24, R=Math.min(aw*0.26, (ah-110)*0.36), cx=aw*0.46, rise=this.alt*(ah*0.30), cy=gy-46-R-12-rise;
    ground(c, 8, aw-8, gy);
    c.save(); var gr=c.createRadialGradient(cx-R*0.3, cy-R*0.3, R*0.2, cx, cy, R); gr.addColorStop(0, "rgba(255,255,255,.9)"); gr.addColorStop(1, mixCol("#e8eef5","#ffd2b8",(Tk-300)/140));
    c.fillStyle=gr; c.strokeStyle="#5b636e"; c.lineWidth=2; c.beginPath(); c.arc(cx, cy, R, 0.42*Math.PI, 2.58*Math.PI); c.lineTo(cx+R*0.16, cy+R+12); c.lineTo(cx-R*0.16, cy+R+12); c.closePath(); c.fill(); c.stroke(); c.restore();
    T(c, "開口部", cx+R*0.22, cy+R+18, {size:10.5, bold:true, col:COL.sub});
    /* ゴンドラとつり糸 */
    var gyT=cy+R+30; c.save(); c.strokeStyle="#7a828c"; c.lineWidth=1.2; c.beginPath(); c.moveTo(cx-R*0.45, cy+R*0.85); c.lineTo(cx-18, gyT); c.moveTo(cx+R*0.45, cy+R*0.85); c.lineTo(cx+18, gyT); c.stroke();
    c.fillStyle="#b88a55"; c.strokeStyle="#6b4a24"; rrect(c, cx-22, gyT, 44, 18, 3); c.fill(); c.stroke(); c.restore();
    /* 温度調節器（球体の中の小さなヒーター） */
    c.save(); c.fillStyle=this.heat>0? "#ff6a2a" : this.heat<0? "#2f8fe8" : "#7a828c"; if(this.heat){ c.shadowColor=c.fillStyle; c.shadowBlur=12; } rrect(c, cx-10, cy+R*0.62, 20, 8, 3); c.fill(); c.restore();
    T(c, "温度調節器", cx+16, cy+R*0.66, {size:10, col:COL.sub});
    /* 中の空気の分子：温度が高いほど少なくなる（開口部から出ていく）。数は ρ に比例 */
    var nIn=Math.round(60*rho/this.r0);
    this.mol.forEach(function(m,i){ if(i>=nIn) return; var a=m[2]+self.clk*m[3]*Math.sqrt(Tk/300)*6, rr=R*0.80*Math.sqrt(m[0]);
      var x=cx+rr*Math.cos(a+m[1]*7), y=cy+rr*Math.sin(a*1.3+m[1]*5)*0.9; ball(c, x, y, 3.2, 0, heatCol(clamp((Tk-280)/160,0,1))); });
    /* 外へ出ていく分子（加熱中） */
    if(this.heat>0) for(var j=0;j<3;j++){ var ph=(this.clk*0.8+j/3)%1; ball(c, cx+(j-1)*6, cy+R+10+ph*30, 3, 0, heatCol(0.7)); }
    /* 温度計 */
    thermometer(c, cx-R-30, cy+R*0.4, cy-R*0.6, Tk-273, 0, 200, {noVal:true, noNum:true, tw:8, br:6}); T(c, Math.round(Tk)+" K", cx-R-30, cy-R*0.6-12, {size:12, bold:true, col:"#a03028", align:"center", halo:true});
    /* 力（作用点に ・）：重力 F は重心（球の中心）から下、浮力 f は球の中心から上（重ならないよう左右にずらす） */
    var kF=narrow? 0.0024 : 0.0030;
    fArrow(c, cx-8, cy, cx-8, cy+F*kF, COLG.grav, 3.2, 11); SYM(c,"F",null,cx-14,cy+F*kF-4,{size:14,bold:true,col:COLG.grav,halo:true,align:"right"});
    fArrow(c, cx+8, cy, cx+8, cy-fb*kF, "#1f6fb2", 3.2, 11); SYM(c,"f",null,cx+14,cy-fb*kF+8,{size:14,bold:true,col:"#1f6fb2",halo:true});
    if(this.alt>0.02) T(c, "浮き上がった！", cx, 18, {size:14, bold:true, col:"#c0392b", align:"center", halo:true});
    /* グラフ：横軸 T、縦軸 F と f */
    var gx0=narrow? 60 : aw+56, gy0=H-40, gx1=W-14, gy1=narrow? ah+46 : 46;
    graphTitle(c, "気球にはたらく重力 F と浮力 f", gx0-40, gy1-24);
    var Fmin=(this.M+this.rho(this.TMAX)*this.V)*9.8, ymax=Math.ceil(((this.M+this.r0*this.V)*9.8)/5000)*5000/1000, ymin=Math.floor(Math.min(Fmin,fb)*0.92/5000)*5000/1000;
    var P=plotFrame(c, gx0, gy0, gx1, gy1, [this.T0,this.TMAX], [ymin,ymax], {xl:"T〔K〕", yl:"力〔×10³ N〕", xstep:20, ystep:5, noO:true, xz:true});
    c.save(); c.strokeStyle="#1f6fb2"; c.lineWidth=2.2; c.beginPath(); c.moveTo(P.X(this.T0),P.Y(fb/1000)); c.lineTo(P.X(this.TMAX),P.Y(fb/1000)); c.stroke(); c.restore();
    SYM(c,"f",null,P.X(this.TMAX)-8,P.Y(fb/1000)-12,{size:14,bold:true,col:"#1f6fb2",align:"right"});
    c.save(); c.strokeStyle=COLG.grav; c.lineWidth=2.2; c.beginPath(); for(var i=0;i<=50;i++){ var Tq=this.T0+(this.TMAX-this.T0)*i/50, Fq=(this.M+this.rho(Tq)*this.V)*9.8/1000; if(i) c.lineTo(P.X(Tq),P.Y(Fq)); else c.moveTo(P.X(Tq),P.Y(Fq)); } c.stroke(); c.restore();
    SYM(c,"F",null,P.X(this.T0)+8,P.Y((this.M+this.r0*this.V)*9.8/1000)+14,{size:14,bold:true,col:COLG.grav});
    if(Tr>this.T0 && Tr<this.TMAX){ c.save(); c.setLineDash([4,3]); c.strokeStyle="#c0392b"; c.beginPath(); c.moveTo(P.X(Tr),P.Y(ymin)); c.lineTo(P.X(Tr),P.Y(fb/1000)); c.stroke(); c.restore();
      var w0=SYM(c,"T","r",P.X(Tr)+4,P.Y(ymin)-12,{size:13,bold:true,col:"#c0392b"}); T(c, " = "+Math.round(Tr)+" K", P.X(Tr)+4+w0, P.Y(ymin)-12, {size:11.5, bold:true, col:"#c0392b"}); }
    dot(c, P.X(Tk), P.Y(F/1000), 6, COLG.grav);
    notebook(c,W,H);
    var mh='球体内の空気の温度 '+tex("T")+' = <span class="num">'+Math.round(Tk)+'</span> K　密度 '+tex("\\rho=\\rho_0\\dfrac{T_0}{T}")+' = <span class="num">'+rho.toFixed(3)+'</span> kg/m³'+
      '<br>重力 '+tex("F=(M+\\rho V)g")+' = <span class="num">'+(F/1000).toFixed(2)+'</span>×10³ N　浮力 '+tex("f=\\rho_0Vg")+' = <span class="num">'+(fb/1000).toFixed(2)+'</span>×10³ N'+(F<fb? '　→ '+tex("F<f")+' なので浮き上がる' : '　→ まだ '+tex("F>f")+'（浮き上がるのは '+tex("T_r")+' = '+Math.round(Tr)+' K から）');
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};

/* ---------------- ⑤-4 浮沈子（東大 2015 Ⅲ） ----------------
   下が開いた容器（質量 m）に空気が閉じこめられ、水中に浮かぶ。空気の温度は T のまま（ボイルの法則）。
   中の水面の深さ z の圧力：p＝P＋ρgz。空気の体積 V＝nRT/(P＋ρgz)。浮力 ρVg、重力 mg。
   つり合いの深さ h＝nRT/(mg)−P/(ρg)。ここは不安定：少し沈めると浮力が減ってさらに沈み、少し上げると浮力が増えて浮き上がる。
   水面を押す圧力 P を大きくすると h が浅くなり、いた位置より下になる → 沈む（浮沈子のしくみ）。
   数値：m＝10 g、つり合いの深さ 1.00 m（P＝1.00×10⁵ Pa のとき）、水槽の深さ 2.0 m */
var S54 = {
  m:0.010, rho:1000, g:9.8, DEP:2.0,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.nRT=(1.0e5+this.rho*this.g*1.0)*this.m/this.rho;       /* h＝1.00 m になるように */
    this.P=1.0e5; this.z=this.h(); this.v=0; this.clk=0;
    sec.querySelector(".ctrls").insertAdjacentHTML("afterbegin", '<div class="prepbox"><div class="pgrp"><span class="ph">操作</span><button type="button" class="b nud" data-d="1">↓ 少し沈める</button><button type="button" class="b nud" data-d="-1">↑ 少し持ち上げる</button><button type="button" class="b back">つり合いの深さに置く</button></div></div>');
    var rs=sec.querySelector(".rsrow"); if(rs){ sec.querySelector(".prepbox .pgrp").appendChild(rs.querySelector(".resetall")); rs.remove(); }
    sec.querySelectorAll(".nud").forEach(function(b){ b.addEventListener("click", function(){ self.z=clamp(self.z+0.06*parseFloat(b.dataset.d), 0.05, self.DEP-0.05); self.v=0; }); });
    sec.querySelector(".back").addEventListener("click", function(){ self.z=clamp(self.h(), 0.05, self.DEP-0.05); self.v=0; });
    this.sP=wireSlider(sec,"P",function(v){ return v.toFixed(3)+" ×10⁵ Pa"; },function(v){ self.P=v*1e5; });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.P=1.0e5; self.sP.set(1.0); self.z=self.h(); self.v=0; });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    idleLoop(sec, function(dt){ self.clk+=dt; var Fn=self.net(self.z); if(Math.abs(Fn)<2e-7) Fn=0;
      self.v=Fn===0? 0 : clamp(self.v+(-Fn*60-self.v*2.2)*dt, -0.8, 0.8); self.z=clamp(self.z+self.v*dt, 0.05, self.DEP-0.05); if(self.z<=0.05 || self.z>=self.DEP-0.05) self.v=0; self.draw(); });
    this.draw();
  },
  Vof:function(z){ return this.nRT/(this.P+this.rho*this.g*z); },
  net:function(z){ return this.rho*this.Vof(z)*this.g-this.m*this.g; },     /* 浮力 − 重力［N］（上向き正） */
  h:function(){ return this.nRT/(this.m*this.g)-this.P/(this.rho*this.g); },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return W<640? clamp(W*1.55, 560, 680) : clamp(W*0.46, 340, 420); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var narrow=W<640, aw=narrow? W : W*0.42, ah=narrow? H*0.52 : H, z=this.z, V=this.Vof(z), Fb=this.rho*V*this.g, mg=this.m*this.g, hq=this.h();
    /* 水槽 */
    var tx=aw*0.22, tw=aw*0.56, ty=46, th=ah-ty-26, Y=function(d){ return ty+14+(th-14)*d/self.DEP; };
    c.save(); c.fillStyle="rgba(84,156,224,.22)"; c.fillRect(tx, ty+14, tw, th-14); c.strokeStyle="#5b636e"; c.lineWidth=2; c.beginPath(); c.moveTo(tx,ty); c.lineTo(tx,ty+th); c.lineTo(tx+tw,ty+th); c.lineTo(tx+tw,ty); c.stroke();
    c.strokeStyle="#2f6fb0"; c.lineWidth=1.4; c.beginPath(); c.moveTo(tx,ty+14); c.lineTo(tx+tw,ty+14); c.stroke(); c.restore();
    /* 水面を押す圧力 P（ふたのピストン） */
    c.save(); c.fillStyle="#c9d6e3"; c.strokeStyle="#3a4654"; c.fillRect(tx+2, ty+2, tw-4, 12); c.strokeRect(tx+2, ty+2, tw-4, 12); c.restore();
    var dp=(this.P-1e5)/1e5; fArrow(c, tx+tw/2, ty-34-dp*400, tx+tw/2, ty+2, COLG.atm, 3, 10); T(c, "水面を押す圧力 P", tx+tw/2+10, ty-22, {size:11.5, bold:true, col:COLG.atm, halo:true});
    /* 深さの目盛り */
    for(var d=0; d<=this.DEP+1e-6; d+=0.5){ c.save(); c.strokeStyle="#7a828c"; c.beginPath(); c.moveTo(tx-6,Y(d)); c.lineTo(tx,Y(d)); c.stroke(); c.restore(); T(c, d.toFixed(1)+" m", tx-9, Y(d), {size:10.5, col:COL.sub, align:"right"}); }
    /* つり合いの深さ（点線） */
    if(hq>0 && hq<this.DEP){ c.save(); c.setLineDash([5,4]); c.strokeStyle="#c0392b"; c.beginPath(); c.moveTo(tx,Y(hq)); c.lineTo(tx+tw,Y(hq)); c.stroke(); c.restore();
      var wh=SYM(c,"h",null,tx+tw+6,Y(hq),{size:13,bold:true,col:"#c0392b"}); T(c, "（つり合い）", tx+tw+8+wh, Y(hq), {size:10.5, col:"#c0392b"}); }
    /* 浮沈子：下が開いた円筒。空気の柱の高さは V に比例（見やすく拡大） */
    var cw=Math.min(46, tw*0.30), cx=tx+tw/2, air=V/1.0e-5*46, yb=Y(z), top=yb-air;
    c.save(); c.fillStyle="rgba(255,255,255,.75)"; c.fillRect(cx-cw/2, yb-air, cw, air); c.restore();
    c.save(); c.strokeStyle="#3a414c"; c.lineWidth=2.4; c.beginPath(); c.moveTo(cx-cw/2, yb+18); c.lineTo(cx-cw/2, top-6); c.lineTo(cx+cw/2, top-6); c.lineTo(cx+cw/2, yb+18); c.stroke(); c.restore();
    c.save(); c.strokeStyle="#2f6fb0"; c.lineWidth=1.4; c.beginPath(); c.moveTo(cx-cw/2+2, yb); c.lineTo(cx+cw/2-2, yb); c.stroke(); c.restore();
    var R0=rng(54); for(var i=0;i<12;i++){ var a=R0(), b=R0(); ball(c, cx-cw/2+6+(cw-12)*tri(a+this.clk*0.45*(0.5+b)), top+2+Math.max(2,air-8)*tri(b+this.clk*0.38*(0.6+a)), 2.6, 0, heatCol(0.25)); }
    T(c, "空気", cx+cw/2+8, top+air*0.4, {size:11, bold:true, col:COL.sub, halo:true});
    /* 力（作用点に ・。左右にずらす） */
    var kF=narrow? 900 : 1100;
    fArrow(c, cx+5, top+air*0.5, cx+5, top+air*0.5-Fb*kF, "#1f6fb2", 3, 10); SYM(c,"ρVg",null,cx+12,top+air*0.5-Fb*kF+6,{size:13,bold:true,col:"#1f6fb2",halo:true});
    fArrow(c, cx-5, top+air*0.5, cx-5, top+air*0.5+mg*kF, COLG.grav, 3, 10); SYM(c,"mg",null,cx-12,top+air*0.5+mg*kF-4,{size:13,bold:true,col:COLG.grav,halo:true,align:"right"});
    var st=(Math.abs(this.v)<0.002)? (z<=0.051? "水面まで浮き上がった" : z>=this.DEP-0.051? "底まで沈んだ" : "止まっている") : (this.v>0? "沈んでいく" : "浮き上がっていく");
    T(c, st, tx+tw/2, ah-8, {size:13, bold:true, col:"#c0392b", align:"center", halo:true});
    /* グラフ：横軸 深さ z、縦軸 浮力と重力 */
    var gx0=narrow? 62 : aw+60, gy0=H-40, gx1=W-14, gy1=narrow? ah+46 : 46;
    graphTitle(c, "深さと浮力・重力（P はいまの値）", gx0-44, gy1-24);
    var P=plotFrame(c, gx0, gy0, gx1, gy1, [0,this.DEP], [8.5,11], {xl:"z〔m〕", yl:"力〔×10⁻² N〕", xstep:0.5, ystep:0.5, noO:true, xz:true});
    c.save(); c.strokeStyle=COLG.grav; c.lineWidth=2; c.beginPath(); c.moveTo(P.X(0),P.Y(mg*100)); c.lineTo(P.X(this.DEP),P.Y(mg*100)); c.stroke(); c.restore();
    SYM(c,"mg",null,P.X(this.DEP)-6,P.Y(mg*100)+14,{size:13,bold:true,col:COLG.grav,align:"right"});
    c.save(); c.strokeStyle="#1f6fb2"; c.lineWidth=2.4; c.beginPath(); for(var k=0;k<=60;k++){ var zz=this.DEP*k/60, fq=this.rho*this.Vof(zz)*this.g*100; if(k) c.lineTo(P.X(zz),P.Y(fq)); else c.moveTo(P.X(zz),P.Y(fq)); } c.stroke(); c.restore();
    T(c, "浮力 ρVg", P.X(1.55), P.Y(this.rho*this.Vof(1.55)*this.g*100)-14, {size:11.5, bold:true, col:"#1f6fb2", halo:true});
    T(c, "浅いほど浮力が大きい → 浮く", P.X(0.08), P.Y(10.8), {size:11, bold:true, col:"#1f6fb2", halo:true});
    T(c, "深いほど浮力が小さい → 沈む", P.X(this.DEP)-4, P.Y(8.75), {size:11, bold:true, col:COLG.grav, align:"right", halo:true});
    dot(c, P.X(z), P.Y(Fb*100), 6, "#c0392b");
    notebook(c,W,H);
    var mh='深さ '+tex("z")+' = <span class="num">'+z.toFixed(2)+'</span> m　空気の圧力 '+tex("P+\\rho gz")+' = <span class="num">'+((this.P+this.rho*this.g*z)/1e5).toFixed(4)+'</span>×10⁵ Pa　空気の体積 = <span class="num">'+(V*1e6).toFixed(2)+'</span> cm³'+
      '<br>つり合いの深さ '+tex("h=\\dfrac{nRT}{mg}-\\dfrac{P}{\\rho g}")+' = <span class="num">'+hq.toFixed(2)+'</span> m（不安定なつり合い）';
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};
