/* =========================================================================
   ページの骨組み：ヒーロー・タブ列・章の扉・節のカード・目次・アドレス（#1-2）
   骨組みは兄弟ページ thermal-energy.html の 80_page.js と同じ
   ========================================================================= */
var MODES = [
  {id:"mode1", name:"気体の法則", en:"Gas Laws",
   lead:"気体の状態は、物質量 "+tex("n")+"・圧力 "+tex("p")+"・体積 "+tex("V")+"・温度 "+tex("T")+" の 4 つの量で表せる。これらの間には、ボイルの法則・シャルルの法則、まとめると<b>理想気体の状態方程式</b> "+tex("pV=nRT")+" が成り立つ。",
   secs:["s11","s12","s13","s14","s15"]},
  {id:"mode2", name:"気体分子運動論", en:"Kinetic Theory of Gases",
   lead:"気体の圧力は、たくさんの分子が壁に衝突して与える力積から生まれる。分子の運動から圧力を求めると、<b>温度は分子の平均の運動エネルギー</b>を表していることが分かる。",
   secs:["s21","s22","s23","s24"]},
  {id:"mode3", name:"熱力学第一法則と p-V 図", en:"The First Law and p-V Diagrams",
   lead:"気体の内部エネルギーは、熱と仕事で変わる（"+tex("\\Delta U=Q+"+WD)+"）。気体がした仕事は p-V 図の面積で表せる。4 つの変化とモル比熱を、p-V 図とエネルギーの棒グラフで比べる。",
   secs:["s31","s32","s33"]},
  {id:"mode4", name:"熱サイクルと熱機関", en:"Heat Cycles and Heat Engines",
   lead:"状態を変化させて元に戻すことをくり返すと、熱を仕事に変え続けられる（<b>熱機関</b>）。p-V 図で囲まれた面積が、1 サイクルで取り出せる仕事になる。",
   secs:["s41","s42","s43"]},
  {id:"mode5", name:"入試物理", en:"Entrance Exam Problems",
   lead:"大学入試の問題を、動かして確かめる。ばね付きのピストン、水がもれていくピストン、熱気球、浮沈子。どれも、ここまでの <b>状態方程式・力のつり合い・熱力学第一法則・p-V 図</b> で読み解ける。",
   secs:["s51","s52","s53","s54"]},
  {id:"mode6", name:"大学の内容", en:"Beyond High School",
   lead:"<b>カルノーサイクル</b>は、2 つの温度の間ではたらく熱機関の中で、熱効率が最も大きい理想的なサイクル。熱力学第二法則と深く結びついている。",
   secs:["s61"]}
];
var DEFS = {
  s11:{num:1, mode:0, title:"シリンダーに閉じ込められた気体 〜 <i>n</i>, <i>p</i>, <i>V</i>, <i>T</i> とは何か、状態方程式とは何か 〜", short:"n, p, V, T と状態方程式", sim:S11, noplay:true,
    desc:'シリンダーに閉じ込めた気体の状態は、物質量 '+tex("n")+'・圧力 '+tex("p")+'・体積 '+tex("V")+'・温度 '+tex("T")+' で表せる。<span class="todo">ポンプを押して分子を入れ、① 準備を選んでから ② 加熱・冷却をしてみよう。</span><br>注目点：どんな操作をしても、'+tex("pV")+' と '+tex("nRT")+' はいつも等しい（右の列）。',
    right:function(){ return '<div class="qcard"><p class="qt">理想気体の状態方程式</p><div class="qeq">'+tex("pV=nRT",true)+'</div><p>'+tex("R=8.31\\,\\mathrm{J/(mol\\cdot K)}")+'：気体定数</p>'+
      '<p>いまの値を入れると</p><div class="eqlive"></div><p>どんな操作をしても、両辺はいつも等しい。</p></div>'+
      '<div class="qcard"><p class="qt">4 つの量</p><table class="nstab">'+
      '<tr><td>物質量 '+tex("n")+'〔mol〕</td><td>分子の数の目安。'+tex("6.02\\times10^{23}")+' 個で 1 mol（アボガドロ定数 '+tex("N_\\mathrm{A}")+'）。分子の数は '+tex("N=nN_\\mathrm{A}")+'</td></tr>'+
      '<tr><td>圧力 '+tex("p")+'〔Pa〕</td><td>気体が面を押す、単位面積あたりの力。分子が壁に次々に衝突して生まれる（→ <a href="#2-2">②-2</a>）。'+tex("1\\,\\mathrm{Pa}=1\\,\\mathrm{N/m^2}")+'</td></tr>'+
      '<tr><td>体積 '+tex("V")+'〔m³〕</td><td>気体が占める空間の大きさ。気体は容器いっぱいに広がる</td></tr>'+
      '<tr><td>温度 '+tex("T")+'〔K〕</td><td>絶対温度。分子の熱運動の激しさを表す（→ <a href="#2-3">②-3</a>）。'+tex("T=t+273")+'</td></tr></table></div>'+
      '<div class="qcard"><p class="qt">準備の意味</p><table class="nstab">'+
      '<tr><td>ピストン 固定</td><td>体積が変わらない</td></tr><tr><td>ピストン 自由</td><td>気体の圧力が大気圧と同じになる位置で止まる（圧力が変わらない）</td></tr>'+
      '<tr><td>断熱材</td><td>外との熱の出入りがない（ヒーターの熱だけが出入りする）</td></tr><tr><td>恒温槽</td><td>温度が一定に保たれる</td></tr></table></div>'; }},
  s12:{num:2, mode:0, title:"ピストンの力のつり合い", short:"力のつり合い", sim:S12, noplay:true, resetInRow:true,
    desc:'質量 '+tex("m")+' のピストンが、ピストン内の気体から押される力・大気から押される力・重力などがつり合って止まっている。<span class="todo">シリンダーの向きを切りかえて、ピストンにはたらく力を見よう。</span><br>注目点：向きによって、気体の圧力 '+tex("p")+' は大気圧 '+tex("p_0")+' より大きくなったり小さくなったりする。',
    opts: H_seg("dir","シリンダーの向き",[["h","水平"],["u","鉛直上向き"],["uw","鉛直上向き（おもりあり）"],["d","鉛直下向き"]],"h")+H_chk("force","力を表示",true),
    right:function(){
      return '<div class="qcard"><p class="qt">向きごとのつり合いの式</p>'+
      '<p>ピストンの質量 '+tex("m")+'、断面積 '+tex("S")+'、おもりの質量 '+tex("M")+'、大気圧 '+tex("p_0")+'、気体の圧力 '+tex("p")+'。</p>'+
      '<table class="nstab eqtab">'+
      '<tr data-dir="h"><td>水平</td><td>'+tex("pS=p_0S")+'<br>'+tex("p=p_0")+'</td></tr>'+
      '<tr data-dir="u"><td>鉛直上向き</td><td>'+tex("pS=p_0S+mg")+'<br>'+tex("p=p_0+\\dfrac{mg}{S}")+'</td></tr>'+
      '<tr data-dir="uw"><td>鉛直上向き<br>（おもりあり）</td><td>'+tex("pS=p_0S+mg+Mg")+'<br>'+tex("p=p_0+\\dfrac{(m+M)g}{S}")+'</td></tr>'+
      '<tr data-dir="d"><td>鉛直下向き</td><td>'+tex("pS+mg=p_0S")+'<br>'+tex("p=p_0-\\dfrac{mg}{S}")+'</td></tr></table>'+
      '<p>水平のとき、ピストンにはたらく重力 '+tex("mg")+' は、シリンダーの壁からの垂直抗力 '+tex("N")+' とつり合う。</p>'+
      '<p>おもりがピストンを押す力の大きさは '+tex("Mg")+'（おもりにはたらく重力とつり合う垂直抗力の反作用）。</p>'+
      '<p>問題によっては、ピストンの質量を無視することもある（そのときは '+tex("m=0")+' として考える）。</p></div>'+
      '<div class="qcard"><p class="qt">参考</p><p>大気が面を押す力と圧力の関係は、<a href="fluid-force.html#1-1">流体から受ける力 ①-1（吸盤と大気圧）</a> で確かめられる。</p></div>'; }},
  s13:{num:3, mode:0, title:"ボイルの法則", short:"ボイルの法則", sim:S13, noplay:true,
    desc:'温度を一定に保ったまま、ピストンをゆっくり動かして気体の体積を変える。<span class="todo">② 操作の「押す（圧縮）」か「引く（膨張）」を押し、p-V 図に打たれていく点と、ピストンに分子が当たる回数を見よう。</span><br>注目点：体積が半分になると、1 秒あたりにピストンに当たる回数は 2 倍になり、圧力も 2 倍になる。',
    opts: H_seg("tb","温度",[["300","300 K"],["600","600 K"]],"300"),
    right:function(){ return '<div class="qcard"><p class="qt">ボイルの法則</p><p>温度が一定のとき、一定質量の気体の体積 '+tex("V")+' は圧力 '+tex("p")+' に反比例する。</p>'+
      '<div class="qeq">'+tex("pV=\\text{一定}",true)+'</div><p>p-V 図のグラフは反比例のグラフ（双曲線）。温度が高いほど、グラフは右上にある。</p></div>'+
      '<div class="qcard"><p class="qt">分子で考えると</p><p>体積が半分になると、分子が壁の間を往復する距離が短くなり、同じ時間に壁に当たる回数が 2 倍になる。1 回あたりの力積は変わらないので（温度が同じ）、圧力が 2 倍になる。</p></div>'; }},
  s14:{num:4, mode:0, title:"シャルルの法則", short:"シャルルの法則", sim:S14, noplay:true,
    desc:'ピストンが自由に動くので、気体の圧力は大気圧と同じで一定。その中で気体の温度を変える。<span class="todo">② 操作の「加熱する」か「冷却する」を押そう。</span><br>注目点：V–T グラフは原点を通る直線。直線をのばすと、0 K（−273 ℃）で体積が 0 になる。',
    opts: '',
    right:function(){ return '<div class="qcard"><p class="qt">シャルルの法則</p><p>圧力が一定のとき、一定質量の気体の体積 '+tex("V")+' は絶対温度 '+tex("T")+' に比例する。</p>'+
      '<div class="qeq">'+tex("\\dfrac{V}{T}=\\text{一定}",true)+'</div>'+
      '<p>セルシウス温度 '+tex("t")+'〔℃〕で表すと、温度が 1 K 上がるごとに、0 ℃ のときの体積 '+tex("V_0")+' の '+tex("\\dfrac{1}{273}")+' ずつ増える。</p>'+
      '<div class="qeq">'+tex("V=V_0+\\dfrac{t}{273}V_0=\\dfrac{273+t}{273}V_0",true)+'</div><p>'+tex("T=t+273")+' を使うと '+tex("\\dfrac{V}{T}=\\dfrac{V_0}{273}")+' となる。</p></div>'; }},
  s15:{num:5, mode:0, title:"ボイル・シャルルの法則", short:"ボイル・シャルルの法則", sim:S15, noplay:true,
    desc:'一定量の気体の圧力・体積・温度の関係を、まとめて確かめる。<span class="todo">「変化」を選ぶと、準備のボタンが自動で切りかわる。ピストンをドラッグしたり、加熱・冷却したりしよう。</span><br>注目点：どう変化させても、'+tex("\\dfrac{pV}{T}")+' の値はいつも同じ。',
    opts: H_seg("chg","変化",[["boyle","温度一定＝ボイルの法則"],["charles","圧力一定＝シャルルの法則"],["free","自由に動かす"]],"free"),
    right:function(){ return '<div class="qcard"><p class="qt">ボイル・シャルルの法則</p><p>一定質量の気体の体積 '+tex("V")+' は、圧力 '+tex("p")+' に反比例し、絶対温度 '+tex("T")+' に比例する。</p>'+
      '<div class="qeq">'+tex("\\dfrac{pV}{T}=\\text{一定}",true)+'</div>'+
      '<p>温度一定なら '+tex("pV=\\text{一定}")+'（ボイルの法則、<a href="#1-3">①-3</a>）、圧力一定なら '+tex("\\dfrac{V}{T}=\\text{一定}")+'（シャルルの法則、<a href="#1-4">①-4</a>）。</p>'+
      '<p>一定の値は '+tex("nR")+' に等しく、これが状態方程式 '+tex("pV=nRT")+'（<a href="#1-1">①-1</a>）。</p></div>'+
      '<div class="qcard"><p class="qt">「自由に動かす」で断熱材のとき</p><p>熱の出入りがないので、ピストンを押しこむと温度が上がり、引き出すと温度が下がる（断熱変化、→ <a href="#3-2">③-2</a>）。それでも '+tex("\\dfrac{pV}{T}")+' は一定。</p></div>'; }},

  s21:{num:1, mode:1, title:"分子 1 個が壁に与える力積", short:"分子 1 個の力積", sim:S21, noplay:true,
    above:'<div class="parts21"><div class="pt21" data-p="1"><span class="ptl">式① 1 回の衝突</span><button class="b play" type="button">▶ スタート</button><button class="b slowb" type="button">🐢 スロー</button></div>'+
      '<div class="pt21 locked" data-p="2"><span class="ptl">式②〜⑤ 何回も衝突する</span><button class="b play" type="button">▶ スタート</button><button class="b slowb" type="button">🐢 スロー</button><span class="lk">式①を最後まで見ると押せる</span></div></div>',
    desc:'一辺 '+tex("L")+' の立方体の容器の中を、質量 '+tex("m")+' の分子 1 個が、壁に弾性衝突しながら飛び回る。<span class="todo">まず「式①」のスタートを押そう。壁 S に当たる前後の速度と運動量の変化を見る。最後まで見たら「式②〜⑤」のスタートで、横から見た図に進む。</span><br>注目点：'+tex("x")+' 方向だけを見ると、分子は速さ '+tex("v_x")+' のまま、壁 S と反対側の壁の間を一定の速さで往復している。',
    right:function(){ return '<div class="qcard"><p class="qt">式を 1 段ずつ</p><div class="steps21"></div>'+
      '</div>'; }},
  s22:{num:2, mode:1, title:"N 個の分子と圧力", short:"N 個の分子と圧力", sim:S22, mid:H_timebar(),
    desc:tex("N")+' 個の分子が、壁 S に次々に衝突する。<span class="todo">分子の数 '+tex("N")+' と温度を変えて、スタートを押そう。</span><br>注目点：壁 S が受ける力はぎざぎざだが、時間で平均すると一定の値に近づく。これが気体の圧力。',
    opts: H_seg("N","分子の数 N",[["1","1 個"],["10","10 個"],["20","20 個"],["100","100 個"]],"20"),
    sliders: '<div class="pair2">'+H_slider("T","温度 $T$",100,900,50,300)+'</div>',
    right:function(){ return '<div class="qcard"><p class="qt">壁 S が受ける圧力</p><p>1 個の分子が壁 S に及ぼす平均の力は '+tex("\\overline{f}=\\dfrac{m{v_x}^2}{L}")+'（→ <a href="#2-1">②-1</a>）。'+tex("N")+' 個では、'+tex("{v_x}^2")+' を平均の '+tex(VX2B)+' にして</p>'+
      '<div class="qeq">'+tex("F=\\dfrac{Nm"+VX2B+"}{L},\\qquad p=\\dfrac{F}{L^2}=\\dfrac{Nm"+VX2B+"}{V}",true)+'</div></div>'+
      '<div class="qcard"><p class="qt">向きがばらばら</p><p>'+tex("v^2={v_x}^2+{v_y}^2+{v_z}^2")+'。分子は特定の方向にかたよらずに動くので、3 方向の平均は等しい。</p>'+
      '<div class="qeq">'+tex(VX2B+"=\\overline{{v_y}^2}=\\overline{{v_z}^2}=\\dfrac{1}{3}"+V2B,true)+'</div><p>よって</p>'+
      '<div class="qeq">'+tex("p=\\dfrac{Nm"+V2B+"}{3V}",true)+'</div></div>'; }},
  s23:{num:3, mode:1, title:"温度と分子の運動エネルギー", short:"温度と運動エネルギー", sim:S23, noplay:true,
    desc:'同じ温度のヘリウムと、もう 1 つの気体の分子の動きを比べる。<span class="todo">右の気体の種類と温度を変えてみよう。</span><br>注目点：分子 1 個の平均の運動エネルギーは、気体の種類によらず温度だけで決まる。そのため、質量の大きい分子ほど遅い。',
    opts: H_seg("gas","右の気体",[["N2","窒素 N₂"],["O2","酸素 O₂"],["CO2","二酸化炭素 CO₂"]],"N2"),
    sliders: H_slider("T","温度 $T$",100,1000,10,300),
    right:function(){ return '<div class="qcard"><p class="qt">平均の運動エネルギーと温度</p><p>'+tex("p=\\dfrac{Nm"+V2B+"}{3V}")+' を '+tex("pV=\\dfrac{Nm"+V2B+"}{3}")+' と変形し、状態方程式 '+tex("pV=nRT")+'（'+tex("N=nN_\\mathrm{A}")+'）と比べると</p>'+
      '<div class="qeq">'+tex("\\dfrac{1}{2}m"+V2B+"=\\dfrac{3}{2}\\dfrac{R}{N_\\mathrm{A}}T=\\dfrac{3}{2}kT",true)+'</div>'+
      '<p>'+tex("k=\\dfrac{R}{N_\\mathrm{A}}=1.38\\times10^{-23}\\,\\mathrm{J/K}")+'：ボルツマン定数</p></div>'+
      '<div class="qcard"><p class="qt">二乗平均速度</p><p>モル質量を '+tex("M")+'〔kg/mol〕とすると '+tex("mN_\\mathrm{A}=M")+' なので</p>'+
      '<div class="qeq">'+tex("\\sqrt{"+V2B+"}=\\sqrt{\\dfrac{3RT}{M}}",true)+'</div><p>分子の速さの目安になる。</p></div>'+
      '<div class="qcard"><p class="qt">参考：分子の速さの分布</p><p>分子はいろいろな速さで飛び回っている。速さの分布は気体の種類と温度で決まり、温度が高いほど、山は低く、速い方へ広がる。</p></div>'; }},
  s24:{num:4, mode:1, title:"内部エネルギー", short:"内部エネルギー", sim:S24, noplay:true,
    desc:'単原子分子の理想気体の<b>内部エネルギー</b> '+tex("U")+' は、全ての分子の運動エネルギーの和。<span class="todo">温度・物質量・体積を変えてみよう。</span><br>注目点：体積を変えても '+tex("U")+' は変わらない。'+tex("U")+' は温度と物質量だけで決まる。',
    sliders: '<div class="pair3">'+H_slider("T","温度 $T$",100,600,10,300)+H_slider("n","物質量 $n$",0.5,2.0,0.1,1.0)+H_slider("V","体積 $V$",1.0,5.0,0.1,2.5)+'</div>',
    right:function(){ return '<div class="qcard"><p class="qt">単原子分子の理想気体の内部エネルギー</p><p>理想気体では分子間の力が無視できるので、内部エネルギーは分子の運動エネルギーの和。1 mol では '+tex("N_\\mathrm{A}\\times\\dfrac{1}{2}m"+V2B+"=\\dfrac{3}{2}RT")+'。</p>'+
      '<div class="qeq">'+tex("U=\\dfrac{3}{2}nRT",true)+'</div></div>'+
      '<div class="qcard"><p class="qt">二原子分子</p><p>酸素 '+tex("\\mathrm{O_2}")+' のような二原子分子では、回転の運動エネルギーも加わる（→ <a href="#3-3">③-3</a>）。</p></div>'; }},

  s31:{num:1, mode:2, title:"気体がする仕事と p-V 図", short:"仕事と p-V 図", sim:S31, mid:H_timebar(),
    desc:'気体が膨張すると、ピストンを押して外に仕事をする。<span class="todo">「変化」を選び、② 操作のボタン（加熱・冷却、または 押す・引く）を押そう。</span><br>注目点：気体がした仕事 '+tex(WS)+' は、p-V 図のグラフと '+tex("V")+' 軸の間の面積に等しい（圧縮のときは負）。',
    opts: H_seg("path","変化",[["V","定積"],["P","定圧"],["T","等温"],["A","断熱"]],"P"),
    right:function(){ return '<div class="qcard"><p class="qt">圧力が一定のとき</p><p>断面積 '+tex("S")+' のピストンを、気体が力 '+tex("pS")+' で押して '+tex("\\Delta l")+' 動かすと、体積の変化は '+tex("\\Delta V=S\\Delta l")+'。</p>'+
      '<div class="qeq">'+tex(WS+"=pS\\Delta l=p\\Delta V",true)+'</div></div>'+
      '<div class="qcard"><p class="qt">仕事＝p-V 図の面積</p><p>どんな変化でも、気体がした仕事 '+tex(WS)+' は、p-V 図のグラフと '+tex("V")+' 軸の間の面積に等しい。圧縮（左向きの変化）のときは、面積に負の符号をつける。</p>'+
      '<p>気体がされた仕事は '+tex(WD+"=-"+WS)+'。</p></div>'; }},
  s32:{num:2, mode:2, title:"4 つの変化", short:"4 つの変化", sim:S32, mid:H_timebar(), full:true,
    desc:'同じ状態 A から、4 つの変化をさせて比べる（単原子分子の理想気体 1 mol）。<span class="todo">「変化」を選び、② 操作のボタン（加熱・冷却、または 押す・引く）を押そう。</span><br>注目点：定積では '+tex(WD+"=0")+'、等温では '+tex("\\Delta U=0")+'、断熱では '+tex("Q=0")+'。p-V 図の断熱の曲線は、等温の曲線より傾きが急。',
    opts: H_seg("kind","変化",[["V","定積"],["P","定圧"],["T","等温"],["A","断熱"]],"P"),
    right:function(){ return '<div class="qcard"><p class="qt">熱力学第一法則</p><div class="qeq">'+tex("\\Delta U=Q+"+WD,true)+'</div>'+
      '<p>'+tex("Q")+'：気体が受け取った熱（放出すると負）、'+tex(WD)+'：気体がされた仕事（'+tex(WD+"=-"+WS)+'）。</p></div>'+
      '<div class="qcard"><p class="qt">4 つの変化（膨張・加熱のとき）</p><table class="nstab"><tr><td></td><td>'+tex("\\Delta U")+'</td><td>'+tex("Q")+'</td><td>'+tex(WD)+'</td></tr>'+
      '<tr><td>定積</td><td>正</td><td>正</td><td>0</td></tr><tr><td>定圧</td><td>正</td><td>正</td><td>負</td></tr><tr><td>等温</td><td>0</td><td>正</td><td>負</td></tr><tr><td>断熱</td><td>負</td><td>0</td><td>負</td></tr></table>'+
      '<p>圧縮（冷却）のときは、どれも符号が逆になる。</p>'+
      '<p>断熱変化では '+tex("pV^\\gamma=\\text{一定}")+'（ポアソンの法則、'+tex("\\gamma")+'：比熱比、単原子分子では '+tex("\\gamma=\\dfrac{5}{3}")+'）。</p></div>'; }},
  s33:{num:3, mode:2, title:"モル比熱", short:"モル比熱", sim:S33, full:true, playFirst:true,
    desc:'1 mol の気体を、定積（ピストン固定）と定圧（ピストンは自由）で、同じヒーターで同じ熱量を加えて温める。<span class="todo">「単原子分子｜二原子分子」を選んでスタートを押そう。</span><br>注目点：定圧のほうが温度が上がりにくい。気体が外に仕事をする分だけ、多くの熱が必要になる（'+tex("C_p=C_V+R")+'）。',
    opts: H_seg("mol","分子",[["mono","単原子分子"],["di","二原子分子"]],"mono"),
    sliders: '<div class="duo"><div class="duoL"><span>左</span><b>定積（ピストン固定）</b><span>1 mol・断熱材・ヒーター</span></div><div class="duoR"><span>まん中</span><b>定圧（ピストンは自由）</b><span>1 mol・断熱材・ヒーター（同じ熱量）</span></div></div>',
    mid: H_timebar(),
    right:function(){ return '<div class="qcard"><p class="qt">モル比熱</p><p>1 mol の温度を 1 K 上げるのに必要な熱量。'+tex("Q=nC\\Delta T")+'。</p>'+
      '<p><b>定積モル比熱</b> '+tex("C_V")+'：体積一定。熱は全て内部エネルギーになる。'+tex("\\Delta U=nC_V\\Delta T")+'</p>'+
      '<p><b>定圧モル比熱</b> '+tex("C_p")+'：圧力一定。気体が外に仕事 '+tex(WS+"=p\\Delta V=nR\\Delta T")+' をする。</p>'+
      '<div class="qeq">'+tex("C_p=C_V+R",true)+'</div><p>（マイヤーの関係）</p><p>比熱比 '+tex("\\gamma=\\dfrac{C_p}{C_V}")+'</p></div>'+
      '<div class="qcard"><p class="qt">単原子分子と二原子分子</p><table class="nstab"><tr><td></td><td>'+tex("C_V")+'</td><td>'+tex("C_p")+'</td><td>'+tex("\\gamma")+'</td></tr>'+
      '<tr><td>単原子分子</td><td>'+tex("\\frac{3}{2}R")+'</td><td>'+tex("\\frac{5}{2}R")+'</td><td>'+tex("\\frac{5}{3}")+'</td></tr>'+
      '<tr><td>二原子分子</td><td>'+tex("\\frac{5}{2}R")+'</td><td>'+tex("\\frac{7}{2}R")+'</td><td>'+tex("\\frac{7}{5}")+'</td></tr></table>'+
      '<p>二原子分子は、並進運動（3 方向）に加えて、2 つの軸のまわりの回転にも 1 方向あたり '+tex("\\frac{1}{2}RT")+' ずつエネルギーをもつので、'+tex("U=\\frac{5}{2}nRT")+'。</p></div>'; }},

  s41:{num:1, mode:3, title:"熱サイクル", short:"熱サイクル", sim:S41, mid:H_timebar(), full:true,
    desc:'気体を A → B → C → D → A と変化させて元に戻す（<b>サイクル</b>）。<span class="todo">サイクルを選んでスタートを押そう。変化が 1 つ終わるごとに、下に模式図が残る。</span><br>注目点：1 周すると '+tex("\\Delta U=0")+'。1 周で気体がした仕事は、p-V 図で囲まれた面積に等しい。',
    opts: H_seg("cyc","サイクル",[["rect","定積＋定圧（長方形のサイクル）"],["carnot","カルノーサイクル（等温＋断熱）"]],"rect"),
    right:function(){ return '<div class="qcard"><p class="qt">熱効率</p><p>1 サイクルで、高温の物体から受け取る熱を '+tex("Q_\\mathrm{in}")+'、低温の物体へ放出する熱を '+tex("Q_\\mathrm{out}")+' とする。1 周すると '+tex("\\Delta U=0")+' なので、気体がした仕事は</p>'+
      '<div class="qeq">'+tex(WS+"=Q_\\mathrm{in}-Q_\\mathrm{out}",true)+'</div>'+
      '<div class="qeq">'+tex("e=\\dfrac{"+WS+"}{Q_\\mathrm{in}}=\\dfrac{Q_\\mathrm{in}-Q_\\mathrm{out}}{Q_\\mathrm{in}}",true)+'</div>'+
      '<p>熱機関は必ず '+tex("Q_\\mathrm{out}")+' を放出するので、'+tex("e<1")+'。</p></div>'+
      '<div class="qcard"><p class="qt">長方形のサイクル</p><p>① 定積で圧力を上げ、② 定圧で膨張、③ 定積で圧力を下げ、④ 定圧で圧縮して元に戻る。熱を受け取るのは ①・②、放出するのは ③・④。</p></div>'; }},
  s42:{num:2, mode:3, title:"熱機関（エンジン）", short:"熱機関", sim:S42, mid:H_timebar(), full:true,
    desc:'ガソリンエンジンは、吸気・圧縮・膨張・排気の 4 つの行程をくり返す。理想化したものが<b>オットーサイクル</b>。<span class="todo">スタートを押して、ピストンの動きと p-V 図の点を見比べよう。</span><br>注目点：圧縮の曲線と膨張の曲線で囲まれた面積が、1 サイクルで気体がした仕事。',
    right:function(){ return '<div class="qcard"><p class="qt">4 つの行程とオットーサイクル</p><table class="nstab">'+
      '<tr><td>① 吸気</td><td>吸気弁が開き、ピストンが下がって混合気を吸いこむ</td></tr>'+
      '<tr><td>② 圧縮</td><td>弁を閉じてピストンが上がり、気体を急に圧縮する（断熱圧縮）</td></tr>'+
      '<tr><td>点火</td><td>点火プラグで燃やすと、体積がほぼ一定のまま圧力と温度が上がる（定積で '+tex("Q_\\mathrm{in}")+' を受け取る）</td></tr>'+
      '<tr><td>③ 膨張</td><td>高温・高圧の気体がピストンを押し下げて仕事をする（断熱膨張）</td></tr>'+
      '<tr><td>排気弁を開く</td><td>体積がほぼ一定のまま圧力が下がる（定積で '+tex("Q_\\mathrm{out}")+' を放出する）</td></tr>'+
      '<tr><td>④ 排気</td><td>ピストンが上がって、燃えたあとの気体を押し出す</td></tr></table>'+
      '<p>吸気と排気は、ほぼ大気圧のまま行き来するだけなので、p-V 図では同じ線の上を往復し、仕事には効かない。</p></div>'+
      ''; }},

  s43:{num:3, mode:3, title:"ヒートポンプ", short:"ヒートポンプ", sim:S43, mid:H_timebar(),
    desc:'熱機関を逆向きに回すと、外から仕事をして、低温の物体から高温の物体へ熱を運べる（エアコンの暖房・冷蔵庫）。<span class="todo">外気の温度を選んで、スタートを押そう。</span><br>注目点：室内へ出す熱 '+tex("Q_\\mathrm{H}")+' は、加えた仕事 '+tex("W")+' より大きい（'+tex("Q_\\mathrm{H}=Q_\\mathrm{L}+W")+'）。外気との温度差が小さいほど、少ない仕事ですむ。',
    sliders: '<div class="pair2">'+H_slider("TL","外気の温度 $T_\\mathrm{L}$",240,300,5,260)+'</div>',
    right:function(){ return '<div class="qcard"><p class="qt">ヒートポンプのしくみ</p>'+
      '<p>カルノーサイクルを逆向き（p-V 図で反時計回り）に回す。</p>'+
      '<table class="nstab"><tr><td>A→D</td><td>断熱膨張。温度が外気より低くなる</td></tr><tr><td>D→C</td><td>外気の中で等温膨張。外気から熱 '+tex("Q_\\mathrm{L}")+' を吸う</td></tr>'+
      '<tr><td>C→B</td><td>断熱圧縮。温度が室内より高くなる</td></tr><tr><td>B→A</td><td>室内で等温圧縮。室内へ熱 '+tex("Q_\\mathrm{H}")+' を出す</td></tr></table>'+
      '<p>1 サイクルで '+tex("\\Delta U=0")+' なので、熱力学第一法則から</p><div class="qeq">'+tex("Q_\\mathrm{H}=Q_\\mathrm{L}+W",true)+'</div>'+
      '<p>'+tex("W")+' は外から気体にした仕事（p-V 図で囲まれた面積）。</p></div>'+
      '<div class="qcard"><p class="qt">成績係数（COP）</p><p>運んだ熱と加えた仕事の比。理想的な（カルノーの）ヒートポンプでは</p>'+
      '<div class="qeq">'+tex("\\dfrac{Q_\\mathrm{H}}{W}=\\dfrac{T_\\mathrm{H}}{T_\\mathrm{H}-T_\\mathrm{L}}",true)+'</div><p>熱は自然には低温から高温へ移らない（熱力学第二法則）。仕事を加えることで、はじめて運べる。</p></div>'; }},

  s51:{num:1, mode:4, title:"ばね付きピストン", short:"ばね付きピストン", sim:S51, mid:H_timebar(),
    desc:'水平な容器の中の気体（単原子分子 1 mol）を、温度調節器でゆっくり温める。ピストンはばねで右の壁とつながっている。<span class="todo">スタートを押して、ばねが 2'+tex("L")+' 縮むまで温めよう。</span><br>注目点：ばねの力が加わるので、圧力は体積の 1 次関数。p-V 図は右上がりの直線になり、仕事は台形の面積。',
    opts: H_chk("force","力を表示",true),
    right:function(){ return H_exam("東北学院大 2018 改",'<p>断面積 '+tex("S")+' のピストンが、ばね定数 '+tex("k")+' のばねで容器とつながっている。容器とピストンは断熱材。大気圧 '+tex("P_0")+'。初めはばねが自然の長さで、気体の長さは '+tex("L")+'。温めてばねが '+tex("2L")+' 縮むまで。</p>'+
      '<p class="mini">このページの数値：'+tex("S=0.10\\,\\mathrm{m^2}")+'、'+tex("L=0.25\\,\\mathrm{m}")+'、'+tex("P_0=1.0\\times10^5\\,\\mathrm{Pa}")+'、'+tex("k=1.0\\times10^4\\,\\mathrm{N/m}")+'</p>')+
      '<div class="qcard"><p class="qt">考え方</p>'+
      '<p><b>初め</b>：ばねは自然の長さなので '+tex("P_0\\cdot SL=RT_0")+' より '+tex("T_0=\\dfrac{P_0SL}{R}")+'</p>'+
      '<p><b>ピストンのつり合い</b>：ばねの縮みが '+tex("x")+' のとき '+tex("pS=P_0S+kx")+'。縮み '+tex("2L")+' では</p><div class="qeq">'+tex("P_1=P_0+\\dfrac{2kL}{S}",true)+'</div>'+
      '<p>状態方程式 '+tex("P_1\\cdot 3SL=RT_1")+' より '+tex("T_1=\\dfrac{3P_1SL}{R}")+'</p>'+
      '<p><b>p-V 図</b>：'+tex("V=S(L+x)")+' より '+tex("p=P_0+\\dfrac{k}{S^2}(V-SL)")+'。右上がりの直線。</p>'+
      '<p><b>仕事</b>：台形の面積</p><div class="qeq">'+tex(WS+"=\\dfrac{(P_0+P_1)\\cdot 2SL}{2}=2P_0SL+2kL^2",true)+'</div><p>大気を押す仕事 '+tex("P_0\\cdot2SL")+' と、ばねにたくわえられるエネルギー '+tex("\\frac{1}{2}k(2L)^2")+' の和。</p>'+
      '<p><b>熱</b>：'+tex("Q=\\Delta U+"+WS)+'、'+tex("\\Delta U=\\dfrac{3}{2}R(T_1-T_0)")+'</p></div>'; }},
  s52:{num:2, mode:4, title:"液体が広い部分へ流れ出すピストン", short:"液体ののったピストン", sim:S52, mid:H_timebar(),
    desc:'質量の無視できるピストンの上に液体がのっている（液体の上は真空）。気体を加熱すると、ピストンが上がり、液体は上の広い部分へ流れ出していく。<span class="todo">スタートを押して、p-V 図と、加えた熱 '+tex("Q")+' のグラフを見よう。</span><br>注目点：液体が広い部分へ流れ出すと、液体の柱が低くなって圧力が下がる。'+tex("Q")+' が最大になる高さ '+tex("X")+' をこえると、つり合いが保てず、ピストンが急に上がる。',
    right:function(){ return H_exam("東大 2011 をもとに",'<p>鉛直な容器。下の部分は断面積 '+tex("S")+'、高さ '+tex("2h")+' より上は断面積 '+tex("2S")+'。ピストンの上には密度 '+tex("\\rho")+' の液体があり、気体の高さが '+tex("h")+' のとき、液体の表面はちょうど広い部分との境目にある。気体は単原子分子。</p>'+
      '<p class="mini">元の問題の数値は図の中にあり読みとれないので、断面積の比（'+tex("1:2")+'）などはこのページで決めた。</p>')+
      '<div class="qcard"><p class="qt">考え方</p>'+
      '<p><b>Ⅰ 液体が細い部分だけ</b>：液体の柱の高さは '+tex("h")+' のまま。ピストンのつり合い '+tex("pS=\\rho g h\\cdot S")+' より、圧力は一定 '+tex("p=\\rho gh")+'（定圧変化）。</p>'+
      '<p><b>Ⅱ 広い部分へ流れ出す</b>（'+tex("x>h")+'）：細い部分の液体は '+tex("2h-x")+'、広い部分には体積 '+tex("S(x-h)")+' が移り、高さは '+tex("\\dfrac{x-h}{2}")+'。</p>'+
      '<div class="qeq">'+tex("p=\\rho g\\left\\{(2h-x)+\\dfrac{x-h}{2}\\right\\}=\\rho g\\left(\\dfrac{3h}{2}-\\dfrac{x}{2}\\right)",true)+'</div>'+
      '<p>'+tex("V=Sx")+' なので、p-V 図は右下がりの直線。仕事は台形の面積。</p>'+
      '<p><b>熱</b>：'+tex("Q=\\Delta U+"+WS)+'、'+tex("U=\\dfrac{3}{2}pV")+'。これを '+tex("x")+' の関数で表すと上に凸の 2 次関数になり、'+tex("\\dfrac{dQ}{dx}=0")+' となる '+tex("x=X")+' で最大。</p>'+
      '<div class="qeq">'+tex("X=\\dfrac{15}{8}h",true)+'</div><p>これより多くの熱を加えると、つり合いの位置がなくなり、ピストンは急に上がる。</p></div>'; }},
  s53:{num:3, mode:4, title:"熱気球", short:"熱気球", sim:S53, noplay:true,
    desc:'熱気球の球体内の空気を温めると、空気がふくらんで開口部から出ていき、球体内の空気が軽くなる。<span class="todo">「加熱する」を押して、重力 '+tex("F")+' と浮力 '+tex("f")+' のグラフを見よう。質量 '+tex("M")+' も変えてみよう。</span><br>注目点：浮力 '+tex("f")+' は温度によらず一定。重力 '+tex("F")+' は温度が上がると小さくなり、'+tex("F<f")+' になると浮き上がる。',
    sliders: '<div class="pair2">'+H_slider("M","球体内の空気を除いた質量 $M$",300,800,10,500)+'</div>',
    right:function(){ return H_exam("大阪工大 2016〔B〕以降",'<p>体積 '+tex("V")+' の球体（変形しない、断熱性の高い素材）の下に開口部があり、中の空気の圧力は外と同じ。球体内の空気を除いた全質量は '+tex("M")+'。外の空気の温度は '+tex("T_0")+'、密度は '+tex("\\rho_0")+'。球体内の空気の温度 '+tex("T")+' を温度調節器で変えられる。</p>'+
      '<p class="mini">このページの数値：'+tex("V=2000\\,\\mathrm{m^3}")+'、'+tex("\\rho_0=1.2\\,\\mathrm{kg/m^3}")+'、'+tex("T_0=300\\,\\mathrm{K}")+'</p>')+
      '<div class="qcard"><p class="qt">考え方</p>'+
      '<p><b>密度と温度</b>：圧力が一定なら、状態方程式から '+tex("\\rho T=\\text{一定}")+'。</p><div class="qeq">'+tex("\\rho=\\rho_0\\dfrac{T_0}{T}",true)+'</div>'+
      '<p><b>重力</b>：'+tex("F=(M+\\rho V)g=\\left(M+\\dfrac{\\rho_0T_0V}{T}\\right)g")+'（温度が上がると小さくなる）</p>'+
      '<p><b>浮力</b>：球体と同じ体積の外の空気の重さ '+tex("f=\\rho_0Vg")+'（温度によらない）</p>'+
      '<p><b>浮き上がる温度</b>：'+tex("F=f")+' より</p><div class="qeq">'+tex("T_r=\\dfrac{\\rho_0VT_0}{\\rho_0V-M}",true)+'</div></div>'; }},
  s54:{num:4, mode:4, title:"浮沈子", short:"浮沈子", sim:S54, noplay:true,
    desc:'下が開いた容器に空気を閉じこめて水に沈めた「浮沈子」。空気の体積は水圧で変わる。<span class="todo">「少し沈める」「少し持ち上げる」を押したり、水面を押す圧力 '+tex("P")+' を変えたりしよう。</span><br>注目点：つり合いの深さ '+tex("h")+' は不安定。少しでも深くなると浮力が減って沈み続け、浅くなると浮力が増えて浮き上がる。',
    sliders: '<div class="pair2">'+H_slider("P","水面を押す圧力 $P$",0.990,1.020,0.001,1.0)+'</div>',
    right:function(){ return H_exam("東大 2015 第 3 問 Ⅲ",'<p>質量 '+tex("m")+' の容器に、温度 '+tex("T")+' の空気（物質量 '+tex("n")+'）が閉じこめられ、水（密度 '+tex("\\rho")+'）の中で静止している。水面の圧力は '+tex("P")+'。空気の温度は変わらないとする。</p>'+
      '<p class="mini">このページの数値：'+tex("m=10\\,\\mathrm{g}")+'、'+tex("P=1.00\\times10^5\\,\\mathrm{Pa}")+' のときのつり合いの深さが '+tex("1.00\\,\\mathrm{m}")+' になるように '+tex("nRT")+' を決めた。</p>')+
      '<div class="qcard"><p class="qt">考え方</p>'+
      '<p><b>力のつり合い</b>：空気の体積を '+tex("V")+' とすると '+tex("mg=\\rho Vg")+'</p>'+
      '<p><b>圧力</b>：容器内の水面の深さ '+tex("h")+' の水圧と、空気の圧力は等しい。'+tex("p=P+\\rho gh")+'</p>'+
      '<p><b>状態方程式</b>：'+tex("pV=nRT")+'。3 つの式から</p><div class="qeq">'+tex("h=\\dfrac{nRT}{mg}-\\dfrac{P}{\\rho g}",true)+'</div>'+
      '<p><b>安定か</b>：少し深くなると水圧が増えて空気が縮み、浮力が減る → さらに沈む。少し浅くなると浮力が増える → 浮き上がる。<b>不安定なつり合い</b>。</p>'+
      '<p><b>浮沈子のしくみ</b>：ペットボトルをにぎって '+tex("P")+' を大きくすると '+tex("h")+' が浅くなる。浮沈子はつり合いの深さより深い所にいることになり、沈む。</p></div>'; }},

  s61:{num:1, mode:5, title:"カルノーサイクル", short:"カルノーサイクル", sim:S61, mid:H_timebar(),
    desc:'カルノーサイクルは、2 つの等温変化と 2 つの断熱変化からなる。<span class="todo">高温の温度 '+tex("T_\\mathrm{H}")+' と低温の温度 '+tex("T_\\mathrm{L}")+' を変えて、スタートを押そう。</span><br>注目点：熱効率は '+tex("e=1-\\dfrac{T_\\mathrm{L}}{T_\\mathrm{H}}")+' になり、温度の差が大きいほど大きい。',
    sliders: '<div class="pair2">'+H_slider("TH","高温の物体の温度 $T_\\mathrm{H}$",400,900,50,600)+H_slider("TL","低温の物体の温度 $T_\\mathrm{L}$",200,350,10,300)+'</div>',
    right:function(){ return '<div class="qcard"><p class="qt">カルノーサイクルの熱効率</p>'+
      '<p>A→B（温度 '+tex("T_\\mathrm{H}")+' で等温膨張）で受け取る熱、C→D（温度 '+tex("T_\\mathrm{L}")+' で等温圧縮）で放出する熱は</p>'+
      '<div class="qeq">'+tex("Q_\\mathrm{in}=nRT_\\mathrm{H}\\log_e\\dfrac{V_\\mathrm{B}}{V_\\mathrm{A}},\\quad Q_\\mathrm{out}=nRT_\\mathrm{L}\\log_e\\dfrac{V_\\mathrm{C}}{V_\\mathrm{D}}",true)+'</div>'+
      '<p>断熱変化の式 '+tex("TV^{\\gamma-1}=\\text{一定}")+' から '+tex("\\dfrac{V_\\mathrm{B}}{V_\\mathrm{A}}=\\dfrac{V_\\mathrm{C}}{V_\\mathrm{D}}")+' となるので</p>'+
      '<div class="qeq">'+tex("e=1-\\dfrac{Q_\\mathrm{out}}{Q_\\mathrm{in}}=1-\\dfrac{T_\\mathrm{L}}{T_\\mathrm{H}}",true)+'</div>'+
      '<p>（等温変化で気体がする仕事を求めるには積分を使う。）</p></div>'+
      '<div class="qcard"><p class="qt">熱力学第二法則とのつながり</p><p>同じ 2 つの温度の間ではたらく熱機関で、カルノーサイクルより熱効率の大きいものは作れない。'+tex("T_\\mathrm{L}>0")+' なので、'+tex("e=1")+'（熱を全て仕事に変える熱機関）にはならない。</p>'+
      '<p>→ <a href="thermal-energy.html#3-3">熱とエネルギー ③-3 熱力学第二法則</a></p></div>'; }}
};
var CIRC = "①②③④⑤⑥⑦⑧⑨";
var GLOBAL = {hideEq:false};

function secAddr(sid){ var d=DEFS[sid]; return (d.mode+1)+"-"+d.num; }
function secHTML(sid, first){
  var d=DEFS[sid], num=CIRC[d.mode]+"-"+d.num;
  var head='<div class="sechead"><span class="secnum">'+num+'</span><h2>'+d.title+'</h2>'+(d.headBtn||'')+'</div><div class="secdesc">'+d.desc+'</div>';
  return '<article class="sec'+(d.full? ' full' : '')+'" id="'+sid+'"><div class="sL">'+head+
    '<div class="ctrls">'+(d.opts? '<div class="row1 row1b">'+d.opts+'</div>' : '')+(d.sliders? '<div class="row2 sliders">'+d.sliders+'</div>' : '')+
    (d.playOnly? '<div class="row1 playrow"><button class="b play" type="button">▶ スタート</button>'+H_reset()+'</div>' : d.noplay? '<div class="rsrow">'+H_reset()+'</div>' : H_play(first, d.mid, H_reset()))+'</div>'+
    (d.above? d.above : '')+
    '<div class="cvwrap"><canvas class="main"></canvas></div><div class="msgbox"></div>'+(d.leftBelow? d.leftBelow() : '')+'</div>'+
    (d.right()? '<div class="sR">'+d.right()+'</div>' : '')+'</article>';
}

function buildPage(){
  var EN = "Gases and Thermodynamics";
  var atom='<svg class="atom" viewBox="0 0 32 32" aria-hidden="true"><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#3ea0e0" stroke-width="2"/><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#7b5bd6" stroke-width="2" transform="rotate(60 16 16)"/><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#e07b18" stroke-width="2" transform="rotate(120 16 16)"/><circle cx="16" cy="16" r="3.6" fill="#5aa7ff"/></svg>';
  document.getElementById("hero").innerHTML =
    '<div class="hero-in"><div class="hero-top"><nav class="crumbs" aria-label="現在地"><a class="crumb-home" href="'+SITE_HOME+'" title="楽楽（らくらく）高校物理のトップページへ">'+atom+'<span>楽楽（らくらく）高校物理</span></a><span class="cs" aria-hidden="true">/</span><a class="crumb" href="'+SITE_HOME+'#sec-mechanics">力学</a><span class="cs" aria-hidden="true">/</span><span class="crumb now" aria-current="page">気体と熱力学</span><span class="kdot"></span><span class="en">'+EN+'</span></nav>'+
    '<div class="topbtns" role="group" aria-label="ページ全体の表示"><button id="btnEq" type="button"></button></div></div>'+
    '<h1 class="hero-title"><span class="t1"><span class="nb">気体と</span><span class="nb">熱力学</span></span><span class="t2">〜 気体分子の運動から熱機関まで 〜</span></h1>'+
    '<div class="introrow"><p class="lead2">気体の圧力や温度は、目に見えない無数の分子の運動から生まれる。分子の運動、熱と仕事、p-V 図を手がかりに、熱を仕事に変える熱機関のしくみまでをたどる。</p>'+
    '<button id="bToc" class="tocbtn" type="button" aria-haspopup="true" aria-expanded="false"><span class="ti" aria-hidden="true"></span>コンテンツ一覧</button></div>'+
    '<div id="tocpanel" class="tocpanel" hidden></div>'+
    '<figure class="stage" aria-label="エンジンのピストンの動きと、p-V 図の上を回る状態の点"><canvas id="heroCv"></canvas>'+
    '<figcaption class="stagecap"><span class="live" aria-hidden="true"></span><span class="sct">気体は、熱を受け取って膨張し、仕事をする。1 周で気体がした仕事 '+tex(WS)+' は、p-V 図で囲まれた面積になる。</span>'+
    '<span class="stagectl" role="group" aria-label="アニメの操作"><button type="button" class="slow" aria-pressed="false" title="ゆっくり再生">🐢 スロー</button><button type="button" class="pp" aria-label="一時停止"><i></i></button></span></figcaption></figure>'+
    '<ol class="ideas">'+
    '<li><a href="#1-5"><span class="in" aria-label="①"><b>1</b></span><span class="ie">'+tex("pV=nRT")+'</span><span class="ij">気体の状態は p・V・T・n で決まる</span><span class="ia" aria-hidden="true">→</span></a></li>'+
    '<li><a href="#2-3"><span class="in" aria-label="②"><b>2</b></span><span class="ie">'+tex("\\frac{1}{2}m"+V2B+"=\\frac{3}{2}kT")+'</span><span class="ij">温度は分子の平均の運動エネルギー</span><span class="ia" aria-hidden="true">→</span></a></li>'+
    '<li><a href="#3-1"><span class="in" aria-label="③"><b>3</b></span><span class="ie ietxt">'+tex(WS)+' ＝ <i>p</i>-<i>V</i> 図の面積</span><span class="ij">気体がした仕事は面積で表せる</span><span class="ia" aria-hidden="true">→</span></a></li></ol></div>';

  document.getElementById("tabs").innerHTML='<div class="tabs-in"><div class="navsite"><a class="navhome" href="'+SITE_HOME+'" aria-label="ホーム（楽楽高校物理のトップページ）" title="ホーム（楽楽高校物理のトップページ）"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3.5 10.8 12 4l8.5 6.8" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M6 9.5V20h4.5v-5.5h3V20H18V9.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg></a><button class="navpages" id="bPages" type="button" aria-haspopup="dialog" aria-expanded="false" aria-controls="siteDrawer"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="3.5" width="7" height="7" rx="1.6" fill="currentColor"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.6" fill="currentColor" opacity=".55"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.6" fill="currentColor" opacity=".55"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.6" fill="currentColor"/></svg><span>ページ一覧</span></button></div>'+
    MODES.map(function(m,i){ return '<button class="tab" type="button" data-mode="'+m.id+'"><span class="tn">'+CIRC[i]+'</span><span class="tl">'+m.name+'</span></button>'; }).join("")+'</div><span class="tprog" aria-hidden="true"></span>';

  var h="", first=true;
  MODES.forEach(function(m,i){
    h+='<section class="mode" id="'+m.id+'"><header class="modehead"><div class="mh-num" aria-hidden="true"><span>'+(i+1)+'</span></div><div class="mh-body"><p class="mh-en">Chapter '+String(i+1).padStart(2,"0")+' — '+m.en+'</p><h2><span class="mh-c">'+CIRC[i]+'</span>'+m.name+'</h2><p class="mh-lead">'+m.lead+'</p></div></header>'+
       (m.secs.length>1? '<div class="seclinks">'+m.secs.map(function(s){ return '<a href="#'+secAddr(s)+'" data-toc="'+s+'">'+CIRC[i]+'-'+DEFS[s].num+'　'+DEFS[s].short+'</a>'; }).join("")+'</div>' : '');
    m.secs.forEach(function(s){ h+=secHTML(s, first); first=false; });
    h+='</section>';
  });
  h+='<div class="card purpose"><p class="lead">このページの目的</p><ol>'+
     '<li>ボイル・シャルルの法則と理想気体の状態方程式 '+tex("pV=nRT")+' を、ピストンと分子の動きで納得する。</li>'+
     '<li>気体分子運動論で、圧力は分子の衝突、温度は分子の平均の運動エネルギーだと分かる（'+tex("\\frac{1}{2}m"+V2B+"=\\frac{3}{2}kT")+'）。そこから内部エネルギー '+tex("U=\\frac{3}{2}nRT")+' を導く。</li>'+
     '<li>定積・定圧・等温・断熱の 4 つの変化を、p-V 図と '+tex("Q")+'・'+tex(WD)+'・'+tex("\\Delta U")+' の棒グラフで比べる（'+tex(WS)+'＝p-V 図の面積）。</li>'+
     '<li>熱サイクルを p-V 図で 1 周し、熱効率 '+tex("e=\\frac{"+WS+"}{Q_\\mathrm{in}}")+' を求める。エンジンの動きと p-V 図を対応させる。</li></ol></div>';
  h+='<footer></footer>';
  document.getElementById("wrap").innerHTML=h;

  /* 目次 */
  var tp=document.getElementById("tocpanel");
  tp.innerHTML='<div class="tochead"><b>コンテンツ一覧</b><button type="button" class="tocx" aria-label="閉じる">×</button></div>'+
    MODES.map(function(m,i){ return '<div class="tocmode">'+CIRC[i]+' '+m.name+'</div><ul>'+m.secs.map(function(s){ return '<li><a href="#'+secAddr(s)+'" data-toc="'+s+'">'+CIRC[i]+'-'+DEFS[s].num+' '+DEFS[s].title+'</a></li>'; }).join("")+'</ul>'; }).join("");
  var bT=document.getElementById("bToc");
  var closeToc=function(){ tp.hidden=true; bT.setAttribute("aria-expanded","false"); };
  bT.addEventListener("click", function(ev){ ev.stopPropagation(); tp.hidden=!tp.hidden; bT.setAttribute("aria-expanded", tp.hidden?"false":"true"); });
  tp.querySelector(".tocx").addEventListener("click", closeToc);
  document.addEventListener("click", function(ev){ if(!tp.hidden && !tp.contains(ev.target) && ev.target!==bT) closeToc(); });
  document.addEventListener("keydown", function(ev){ if(ev.key==="Escape") closeToc(); });
  document.querySelectorAll("a[data-toc]").forEach(function(a){ a.addEventListener("click", function(ev){ ev.preventDefault(); closeToc(); gotoSec(a.dataset.toc); }); });
  /* 本文の中の「#1-2」のリンク */
  document.getElementById("wrap").addEventListener("click", function(ev){ var a=ev.target.closest && ev.target.closest('a[href^="#"]'); if(!a || a.dataset.toc || a.dataset.mode) return;
    var hs=a.getAttribute("href").slice(1); if(/^\d-\d$/.test(hs)){ ev.preventDefault(); history.replaceState(null,"","#"+hs); gotoHash(); } });

  /* タブ */
  document.querySelectorAll("#tabs .tab").forEach(function(b){
    b.addEventListener("click", function(){ activateMode(b.dataset.mode); history.replaceState(null,"","#"+b.dataset.mode);
      window.scrollTo({top:Math.min(window.pageYOffset, contentTop()), behavior:"auto"}); });
  });
  window.addEventListener("hashchange", function(){ gotoHash(); });

  /* 式・考え方エリアを閉じる */
  var bE=document.getElementById("btnEq");
  var sync=function(){ var on=GLOBAL.hideEq; bE.innerHTML='<span class="sw" aria-hidden="true"><i></i></span><span class="swl">式・考え方エリアを閉じる</span><span class="swv">'+(on?"ON":"OFF")+'</span>';
    bE.setAttribute("aria-pressed",on?"true":"false"); bE.classList.toggle("off",!on); document.body.classList.toggle("hideeq",on); };
  bE.addEventListener("click", function(){ GLOBAL.hideEq=!GLOBAL.hideEq; sync(); setTimeout(redrawAll,30); });
  sync();
}
var BUILT = {};
function activateMode(id){
  document.querySelectorAll(".mode").forEach(function(s){ s.classList.toggle("on", s.id===id); });
  document.querySelectorAll("#tabs .tab").forEach(function(b){ b.classList.toggle("on", b.dataset.mode===id); });
  var m=MODES.filter(function(x){ return x.id===id; })[0];
  if(m && !BUILT[id]){ BUILT[id]=true; m.secs.forEach(function(s){ DEFS[s].sim.init(document.getElementById(s)); }); }
  else if(m) setTimeout(function(){ m.secs.forEach(function(s){ DEFS[s].sim.draw(); }); }, 0);
}
function redrawAll(){ MODES.forEach(function(m){ if(BUILT[m.id]) m.secs.forEach(function(s){ DEFS[s].sim.draw(); }); }); }
function contentTop(){ var h=document.getElementById("hero"); return h? h.offsetTop+h.offsetHeight : 0; }
function tabbarH(){ var tb=document.getElementById("tabs"); return (tb && getComputedStyle(tb).position==="sticky")? tb.getBoundingClientRect().height : 0; }
function gotoSec(sid){
  var d=DEFS[sid]; if(!d) return;
  activateMode(MODES[d.mode].id); history.replaceState(null,"","#"+secAddr(sid));
  var go=function(){ var el=document.getElementById(sid); if(!el) return; window.scrollTo({top: el.getBoundingClientRect().top + window.pageYOffset - tabbarH() - 10, behavior:"auto"}); };
  requestAnimationFrame(function(){ requestAnimationFrame(go); }); setTimeout(go, 220);
}
function gotoHash(){
  var hs=(location.hash||"").slice(1);
  var mm=hs.match(/^(\d)-(\d)$/);
  if(mm){ var sid=null; Object.keys(DEFS).forEach(function(k){ if(DEFS[k].mode===parseInt(mm[1],10)-1 && DEFS[k].num===parseInt(mm[2],10)) sid=k; }); if(sid){ gotoSec(sid); return true; } }
  if(MODES.some(function(m){ return m.id===hs; })){ activateMode(hs); return true; }
  return false;
}
/* 節の共通：「全て最初の設定に戻す」とスローのボタンを戻す */
function resetSlow(sec, run){ if(run) run.rate=1; var sb=sec.querySelector(".slowb"); if(sb) sb.classList.remove("on"); }
/* 節が画面に見えているか（見えていないときは止めておく） */
function secVisible(sec){ if(sec.offsetParent===null) return false; var r=sec.getBoundingClientRect(); return r.bottom>0 && r.top<innerHeight; }
document.addEventListener("DOMContentLoaded", function(){
  buildPage();
  if(!gotoHash()) activateMode("mode1");
  watchTicks(document);
  if(document.fonts){ document.fonts.load('italic 14px "KaTeX_Math"').then(function(){ redrawAll(); }); document.fonts.ready.then(function(){ redrawAll(); }); }
});
