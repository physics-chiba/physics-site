/* =========================================================================
   気体のページの共通部品（どの節でも使いまわす）
   ・定数（R・k・N_A）と記号（W_された・W_した・v² の平均）
   ・気体の分子（たがいにはぶつからず、壁で弾性衝突する。位置は 0〜1 の割合で持つ）
   ・シリンダーとピストン（向きを変えられる）・パネル表示（1-1 の見本の形）
   ・グラフの枠（軸に矢印・きりのいい目盛り）・オットーサイクル（ヒーローと 4-2）
   ========================================================================= */
var RGAS = 8.31, NAV = 6.02e23, KB = 1.38e-23, PATM = 1.0e5;
/* 記号（KaTeX）：仕事は W_された／W_した、速さの 2 乗の平均は v² の上に横線 */
var WD = "W_{\\text{された}}", WS = "W_{\\text{した}}", V2B = "\\overline{v^2}", VX2B = "\\overline{{v_x}^2}";
var COLG = { p:"#e0457b", V:"#1f7fd6", T:"#d99a00", n:"#1c8f4a", U:"#7b3fd4",
  gasF:"#1c8f4a", atm:"#b58900", grav:"#d1352b", norm:"#7b3fd4", imp:"#c0158a", vel:"#1663b5" };

/* 決まった乱数（毎回同じ並び） */
function rng(seed){ var a=seed>>>0; return function(){ a|=0; a=a+0x6D2B79F5|0; var t=Math.imul(a^a>>>15,1|a); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }
/* 標準正規分布 */
function gauss(R){ var u=Math.max(1e-9,R()), v=R(); return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v); }

/* ---------------- 気体の分子 ----------------
   x・y は気体の部分の中での割合（0〜1）。体積が変わっても分子は同じ割合の位置のまま。
   速さ：3 方向の成分を正規分布で選ぶ（マクスウェル分布）。f2 の平均がおよそ 1 になるようにそろえる。
   画面の速さ［px/s］＝ 成分 × vs（vs は温度の平方根に比例させて呼ぶ側が決める） */
function Gas(n, seed){
  this.R = rng(seed||7); this.m = []; this.hits = 0;
  this.setN(n);
}
Gas.prototype.one = function(){ var R=this.R;
  var vx=gauss(R), vy=gauss(R), vz=gauss(R);
  return {x:0.08+0.84*R(), y:0.08+0.84*R(), z:0.08+0.84*R(), vx:vx, vy:vy, vz:vz, ph:R()*6.283}; };
Gas.prototype.setN = function(n){
  n=Math.max(0,Math.round(n));
  while(this.m.length<n) this.m.push(this.one());
  if(this.m.length>n) this.m.length=n;
  /* 2 乗の平均を 3 にそろえる（1 方向あたり 1） */
  if(n>=3 && !this._norm){ var s=0; this.m.forEach(function(q){ s+=q.vx*q.vx+q.vy*q.vy+q.vz*q.vz; }); var k=Math.sqrt(3*n/s);
    this.m.forEach(function(q){ q.vx*=k; q.vy*=k; q.vz*=k; }); this._norm=true; }
};
/* 1 コマ進める。w・h …気体の部分の大きさ［px］、vs …速さの目安［px/s］、r …分子の半径［px］。
   右の壁（x＝1：ピストンや壁 S）に当たった回数を hits に足す */
Gas.prototype.step = function(dt, w, h, vs, r){
  if(w<2*r+2 || h<2*r+2) return;
  var self=this, rx=r/w, ry=r/h, n=Math.max(1,Math.ceil(dt*vs*3/Math.min(w,h)*4)), hh=dt/n;
  for(var s=0;s<n;s++) this.m.forEach(function(q){
    q.x+=q.vx*vs*hh/w; q.y+=q.vy*vs*hh/h;
    if(q.x<rx){ q.x=2*rx-q.x; q.vx=Math.abs(q.vx); }
    if(q.x>1-rx){ q.x=2*(1-rx)-q.x; q.vx=-Math.abs(q.vx); self.hits++; }
    if(q.y<ry){ q.y=2*ry-q.y; q.vy=Math.abs(q.vy); }
    if(q.y>1-ry){ q.y=2*(1-ry)-q.y; q.vy=-Math.abs(q.vy); }
    q.z+=q.vz*vs*hh/h; if(q.z<ry){ q.z=2*ry-q.z; q.vz=Math.abs(q.vz); } if(q.z>1-ry){ q.z=2*(1-ry)-q.z; q.vz=-Math.abs(q.vz); }
    q.x=clamp(q.x,rx,1-rx); q.y=clamp(q.y,ry,1-ry);
  });
};
/* 気体の部分にとじこめる（体積が急に小さくなったとき） */
Gas.prototype.keep = function(w,h,r){ var rx=Math.min(0.49,r/Math.max(w,1)), ry=Math.min(0.49,r/Math.max(h,1));
  this.m.forEach(function(q){ q.x=clamp(q.x,rx,1-rx); q.y=clamp(q.y,ry,1-ry); }); };
/* 分子の速さの 2 乗の平均（成分のまま。1 方向あたり 1 くらい） */
Gas.prototype.v2 = function(){ var s=0; this.m.forEach(function(q){ s+=q.vx*q.vx+q.vy*q.vy+q.vz*q.vz; }); return this.m.length? s/this.m.length : 0; };

/* 温度 T［K］→ 分子と気体の色 */
function gasLv(T){ return clamp((T-150)/500,0,1); }
function gasTint(T, a){ var lv=gasLv(T);
  return (lv<0.5)? 'rgba('+Math.round(170+170*lv)+','+Math.round(215-20*lv)+','+Math.round(240-60*lv)+','+(a||0.55)+')'
                 : 'rgba(255,'+Math.round(205-150*(lv-0.5))+','+Math.round(190-150*(lv-0.5))+','+(a||0.55)+')'; }

/* ---------------- シリンダー ----------------
   局所の座標：x …閉じた端の内側の面から開いた端へ［px］、y …軸からの横のずれ（−h/2〜h/2）。
   dir：シリンダーの開いた端が向く方向 "right"・"up"・"down"。(ox,oy) …閉じた端の内側の面のまん中（画面）。
   to(x,y) で局所 → 画面に変える。描くときは c を回して局所のまま描く */
function CylFrame(ox, oy, dir){
  this.ox=ox; this.oy=oy; this.dir=dir||"right";
  this.ang = (dir==="up")? -Math.PI/2 : (dir==="down")? Math.PI/2 : (dir==="left")? Math.PI : 0;
}
CylFrame.prototype.to = function(x,y){ var a=this.ang, ca=Math.cos(a), sa=Math.sin(a);
  return [this.ox + x*ca - y*sa, this.oy + x*sa + y*ca]; };
CylFrame.prototype.begin = function(c){ c.save(); c.translate(this.ox,this.oy); c.rotate(this.ang); };
CylFrame.prototype.end = function(c){ c.restore(); };
/* 色を混ぜる（a・b は #rrggbb、t は 0〜1） */
function mixCol(a,b,t){ t=clamp(t,0,1); var A=parseInt(a.slice(1),16), B=parseInt(b.slice(1),16), f=function(s){ return Math.round(((A>>s)&255)*(1-t)+((B>>s)&255)*t); };
  return "rgb("+f(16)+","+f(8)+","+f(0)+")"; }
/* ピストンの色：シリンダーの灰色と少し変えて、青みのある金属の色（第3回：圧力で色を変える機能はやめた） */
function pistonCols(){ return ["#c9d6e3","#7f95ab"]; }

/* ---------------- 装置（シリンダー・ピストン・断熱材・恒温槽・ヒーター・固定具・手・温度計）----------------
   shin-phys.github.io/thermo_dynamics を参考に：
   ・断熱材 … 壁を茶色の斜線の厚い板で囲む      ・恒温槽 … 水の入った槽にシリンダーをひたす
   ・ヒーター（冷却器）… 閉じた端の内側に最初から入れておく。加熱は赤く、冷却は青く光り、熱の矢印を出す
   ・固定具 … ピストンの両側のストッパーと鍵       ・手 … ピストンの棒の先をにぎる（棒の長さは一定なので、手はいつもピストンと一緒に動く）
   o：L …ピストンの内側の面の位置、Lmax …シリンダーの長さ、h …内径、T …温度、gas …Gas、r …分子の半径、
      pt …ピストンの厚さ、rod …ピストンの棒の長さ（一定）、stop/lock …固定具、cont …"ins"（断熱材）／"bath"（恒温槽）、
      insul …（古い書き方）断熱材、heater …ヒーター、heat …+1 加熱中・−1 冷却中、clk …時刻（熱の矢印を流す）、
      hand …手でにぎる、pr …ピストンの色（圧力の目安）、thermo …温度計、noGas、tint、mcol、rotDi、noPiston
   返り値：rodEnd（棒の先・画面）、thermoTop（温度計の上の端・画面）、bathLab（恒温槽の文字の位置） */
function drawCylinder(c, F, o){
  var L=o.L, Lm=o.Lmax, h=o.h, wt=o.wall||9, pt=o.pt||14, hh=h/2, cont=o.cont||(o.insul? "ins" : null), out={};
  var lock=o.stop||o.lock;
  if(cont==="ins") wt=Math.max(wt,13);
  F.begin(c);
  /* 恒温槽（いちばんうしろ） */
  /* 水面はいつもピストンの上面より下にする（ピストンが水の下に入ると、ピストンを押す圧力が変わってしまうため） */
  if(cont==="bath"){ var bx0=-wt-20, bx1=o.noPiston? Lm*0.80 : Math.max(Math.min(Lm*0.80, L+pt-3), 12), by=hh+wt+18;
    c.save(); c.fillStyle="rgba(84,156,224,.26)"; c.strokeStyle="#3f7fc0"; c.lineWidth=1.4; c.fillRect(bx0,-by,bx1-bx0,2*by);
    c.beginPath(); c.moveTo(bx1,-by); c.lineTo(bx0,-by); c.lineTo(bx0,by); c.lineTo(bx1,by); c.stroke();
    c.strokeStyle="#2f6fb0"; c.lineWidth=1.6; c.beginPath(); for(var k=0;k<=24;k++){ var yy=-by+2*by*k/24, xx=bx1+Math.sin(k*1.3+(o.clk||0)*2)*2.2; if(k) c.lineTo(xx,yy); else c.moveTo(xx,yy); } c.stroke();
    c.restore(); out.bathLab=F.to(bx0+18, by-10); }
  /* 気体 */
  if(!o.noGas){ c.fillStyle=(o.tint===false)? "rgba(236,244,250,.7)" : gasTint(o.T||300, 0.42); c.fillRect(0,-hh,L,h); }
  /* ヒーター（冷却器）：閉じた端の内側 */
  if(o.heater){ var hc=(o.heat>0)? "#ff5a2a" : (o.heat<0)? "#2f8fe8" : "#7a828c";
    c.save(); c.strokeStyle="#5b636e"; c.lineWidth=1.6; c.beginPath(); c.moveTo(-wt-12,-hh+9); c.lineTo(7,-hh+9); c.moveTo(-wt-12,hh-9); c.lineTo(7,hh-9); c.stroke();
    if(o.heat){ c.shadowColor=hc; c.shadowBlur=12; }
    c.strokeStyle=hc; c.lineWidth=2.6; c.lineJoin="round"; c.beginPath(); var n=Math.max(4,Math.round((h-18)/9));
    for(var k=0;k<=n;k++){ var y=-hh+9+(h-18)*k/n, x=(k%2)? 13 : 5; if(k) c.lineTo(x,y); else c.moveTo(x,y); } c.stroke(); c.restore();
    var ph=((o.clk||0)*0.9)%1;
    if(o.heat>0 && L>52) heatFlow(c, 18, 0, Math.min(46,L-6), 0, 10, ph, {k:0.75});
    /* 冷却：気体の中から外へ、壁をまたいで出ていく青い矢印 */
    if(o.heat<0){ var cxh=clamp(L*0.5, 22, Math.max(22, L-10)); heatFlow(c, cxh, hh*0.15, cxh, hh+wt+30, 10, ph, {k:0.8, cool:true}); }
  }
  /* 分子 */
  if(o.gas && L>4){ var r=o.r||4.2, w=L, mc=o.mcol;
    o.gas.m.forEach(function(q,i){ var x=r+(w-2*r)*q.x, y=-hh+r+(h-2*r)*q.y;
      if(o.rotDi){ /* 二原子分子（亜鈴の形で回転） */
        var a=q.ph+(o.clk||0)*(2.5+1.5*Math.abs(q.vz)), dx=Math.cos(a)*r*0.95, dy=Math.sin(a)*r*0.95;
        var col=(typeof mc==="function")? mc(q,i) : (mc||heatCol(gasLv(o.T||300)));
        c.strokeStyle="#33414f"; c.lineWidth=1.6; c.beginPath(); c.moveTo(x-dx,y-dy); c.lineTo(x+dx,y+dy); c.stroke();
        ball(c,x-dx,y-dy,r*0.78,0,col); ball(c,x+dx,y+dy,r*0.78,0,col);
      } else ball(c, x, y, r, 0, (typeof mc==="function")? mc(q,i) : (mc||heatCol(gasLv(o.T||300)))); });
  }
  /* 壁（閉じた端・上下）。断熱材のときは茶色の斜線の厚い板 */
  c.fillStyle=(cont==="ins")? "#d9b98c" : "#c9ced6"; c.strokeStyle=(cont==="ins")? "#7a5230" : "#5b636e"; c.lineWidth=1.3;
  c.fillRect(-wt,-hh-wt,Lm+wt,wt); c.fillRect(-wt,hh,Lm+wt,wt); c.fillRect(-wt,-hh,wt,h);
  c.beginPath(); c.moveTo(Lm,-hh-wt); c.lineTo(-wt,-hh-wt); c.lineTo(-wt,hh+wt); c.lineTo(Lm,hh+wt); c.stroke();
  c.beginPath(); c.moveTo(Lm,-hh); c.lineTo(0,-hh); c.lineTo(0,hh); c.lineTo(Lm,hh); c.stroke();
  if(cont==="ins"){ c.save(); c.beginPath(); c.rect(-wt,-hh-wt,Lm+wt,wt); c.rect(-wt,hh,Lm+wt,wt); c.rect(-wt,-hh,wt,h); c.clip();
    c.strokeStyle="#8a5a2b"; c.lineWidth=1; for(var k2=-wt-h; k2<Lm+h; k2+=6){ c.beginPath(); c.moveTo(k2,hh+wt); c.lineTo(k2+h+2*wt,-hh-wt); c.stroke(); } c.restore(); }
  /* 固定具（ストッパー） */
  if(lock && !o.noPiston){ c.fillStyle="#3a414c"; [-1,1].forEach(function(sd){ var y0=(sd<0)? -hh : hh-7; c.fillRect(L-9, y0, 8, 7); c.fillRect(L+pt+1, y0, 8, 7); }); }
  /* ピストン（シリンダーと色を変える。圧力が高いほど明るく赤っぽく） */
  if(!o.noPiston){
    var pc=pistonCols(o.pr), pg=c.createLinearGradient(L,0,L+pt,0); pg.addColorStop(0,pc[1]); pg.addColorStop(0.55,pc[0]); pg.addColorStop(1,pc[1]);
    c.fillStyle=pg; c.strokeStyle="#3a4654"; c.lineWidth=1.3; c.fillRect(L,-hh,pt,h); c.strokeRect(L,-hh,pt,h);
    if(o.rod){ c.fillStyle="#d8d2c4"; c.strokeStyle="#8b8172"; rrect(c,L+pt,-4,o.rod,8,3); c.fill(); c.stroke(); }
  }
  /* 温度計：閉じた端の近く、横の壁から気体の中へさしこむ */
  if(o.thermo){ var tx=o.thx||(o.heater? 30 : 18), tl=o.thLen||58;
    thermometer(c, tx, -hh+Math.min(h*0.42, 26), -hh-wt-tl, clamp(o.T||300,100,700), 100, 700, {noVal:true, noNum:true, tw:8, br:6});
    out.thermoTop=F.to(tx, -hh-wt-tl); }
  F.end(c);
  out.rodEnd=F.to(L+pt+(o.rod||0), 0);
  /* 手：棒の先をにぎる（腕は外向き） */
  if(o.hand && o.rod){ var e=F.to(L+pt+o.rod-6, 0); hand(c, e[0], e[1], F.ang); }
  /* 固定具の鍵 */
  if(lock && !o.noPiston){ var kp=F.to(L+pt/2, -hh-wt-16); T(c, "固定", kp[0], kp[1], {size:12, bold:true, col:"#3a414c", align:"center", halo:true}); }
  /* 気体の部分に p, V, T、ピストンの外に p₀（大気圧） */
  if(o.pvt!==false && !o.noGas && L>44){ var gq=F.to(L*0.56, 0); T(c, "p, V, T", gq[0], gq[1], {size:15, bold:true, it:true, serif:true, col:"#1f3b57", align:"center", halo:true}); }
  if(o.p0!==false && !o.noPiston){ var free=Lm-(L+pt), q0=(free>38)? F.to(L+pt+free*0.5, hh*0.55) : F.to(Lm+22, hh*0.55);
    T(c, "p₀", q0[0], q0[1]-6, {size:14, bold:true, it:true, serif:true, col:COLG.atm, align:"center", halo:true});
    T(c, "（大気圧）", q0[0], q0[1]+9, {size:9.5, bold:true, col:COLG.atm, align:"center", halo:true}); }
  if(cont==="bath" && out.bathLab) T(c, "恒温槽"+(o.bathT? " "+Math.round(o.bathT)+" K" : ""), out.bathLab[0], out.bathLab[1], {size:11, bold:true, col:"#1f5f99", halo:true});
  if(cont==="ins" && !o.noInsLab){ var il=F.to(Lm*0.93, -hh-wt-22); T(c, "断熱材", il[0], il[1], {size:10.5, bold:true, col:"#7a5230", align:"center", halo:true}); }
  if(o.thermo && o.thermoLab!==false){ var tt=out.thermoTop, side=(F.dir==="right");     /* 縦のシリンダーでは温度計は横向き：文字はその上に置く */
    out.thermoLab=side? [tt[0], tt[1]-10] : [Math.max(tt[0]+2, 4), tt[1]-16];
    T(c, Math.round(o.T||300)+" K", out.thermoLab[0], out.thermoLab[1], {size:12, bold:true, col:"#a03028", align:(side? "center" : "left"), halo:true}); }
  return out;
}
/* 鍵のマーク（closed＝閉じている・固定、false＝開いている・自由） */
function padlock(c, x, y, closed, s){
  s=s||1; c.save(); c.translate(x,y); c.scale(s,s);
  c.strokeStyle="#3a414c"; c.lineWidth=2.2; c.beginPath();
  if(closed) c.arc(0,-4,5,Math.PI,0); else c.arc(4,-6,5,Math.PI*1.05,0.05);
  c.stroke(); if(closed){ c.beginPath(); c.moveTo(-5,-4); c.lineTo(-5,0); c.moveTo(5,-4); c.lineTo(5,0); c.stroke(); }
  c.fillStyle="#e0a526"; c.strokeStyle="#7a5a10"; c.lineWidth=1; rrect(c,-7,-1,14,11,2); c.fill(); c.stroke();
  c.fillStyle="#5a420c"; c.beginPath(); c.arc(0,4,1.6,0,7); c.fill();
  c.restore();
}

/* ---------------- パネル表示（1-1 の見本：暗い地のカード） ---------------- */
var PANEL_DEF = {
  p:{lab:"圧力 <i>p</i>", unit:"×10<sup>5</sup> Pa", cls:"pp"},
  V:{lab:"体積 <i>V</i>", unit:"×10<sup>−2</sup> m<sup>3</sup>", cls:"pv"},
  T:{lab:"温度 <i>T</i>", unit:"K", cls:"pt"},
  n:{lab:"物質量 <i>n</i>", unit:"mol", cls:"pn"},
  U:{lab:"内部エネルギー <i>U</i>", unit:"J", cls:"pu"}
};
/* pm …{p:"温度一定", …}：カードの下に − ＋ のボタンと、そのとき一定にする量を添える */
function panelHTML(keys, pm){
  return '<div class="gpanel g'+keys.length+'">'+keys.map(function(k){ var d=PANEL_DEF[k];
    return '<div class="gcard '+d.cls+'" data-k="'+k+'"><span class="gl">'+d.lab+'</span><span class="gvrow"><span class="gv">—</span><span class="gu">'+d.unit+'</span></span><span class="gd"></span>'+
      (pm && pm[k]? '<span class="gpm"><button type="button" class="gpb" data-pm="'+k+'" data-d="-1" aria-label="'+d.lab.replace(/<[^>]*>/g,"")+'を減らす">−</button><button type="button" class="gpb" data-pm="'+k+'" data-d="1" aria-label="'+d.lab.replace(/<[^>]*>/g,"")+'を増やす">＋</button><small>'+pm[k]+'</small></span>' : '')+'</div>'; }).join("")+'</div>';
}
/* vals：{p:[値の文字, 変化の向き(+1/-1/0)], …} */
function setPanel(root, vals){
  Object.keys(vals).forEach(function(k){ var el=root.querySelector('.gcard[data-k="'+k+'"]'); if(!el) return;
    var v=vals[k], gv=el.querySelector(".gv"), gd=el.querySelector(".gd");
    if(gv.textContent!==v[0]) gv.textContent=v[0];
    var dtx=(v[1]>0? "▲ 増加" : v[1]<0? "▼ 減少" : v[2]||"");
    if(gd.textContent!==dtx) gd.textContent=dtx;
    el.classList.toggle("up", v[1]>0); el.classList.toggle("dn", v[1]<0); });
}

/* ---------------- グラフの枠 ----------------
   (x0,y0) …原点の画面上の位置（左下）、(x1,y1) …右上。xr・yr …[最小, 最大]。o.xl・o.yl …軸の名前。
   目盛りはきりのいい値（1・2・5×10ⁿ）、0 を含める。軸の先に矢印。返り値は値 → 画面の関数 */
function plotFrame(c, x0, y0, x1, y1, xr, yr, o){
  o=o||{};
  var X=function(v){ return x0+(x1-x0-14)*(v-xr[0])/(xr[1]-xr[0]); }, Y=function(v){ return y0-(y0-y1-14)*(v-yr[0])/(yr[1]-yr[0]); };
  var xs=o.xstep||niceStep(xr[1]-xr[0],o.nx||5), ys=o.ystep||niceStep(yr[1]-yr[0],o.ny||4);
  c.save(); c.fillStyle="#fff"; rrect(c,x0-2,y1-2,x1-x0+4,y0-y1+4,6); c.fill();
  c.strokeStyle="#efebe4"; c.lineWidth=1;
  for(var v=Math.ceil(xr[0]/xs-1e-9)*xs; v<=xr[1]+1e-9; v+=xs){ if(Math.abs(v-xr[0])<1e-9) continue; var X1=Math.round(X(v))+0.5; c.beginPath(); c.moveTo(X1,y0); c.lineTo(X1,y1+14); c.stroke(); }
  for(var w=Math.ceil(yr[0]/ys-1e-9)*ys; w<=yr[1]+1e-9; w+=ys){ if(Math.abs(w-yr[0])<1e-9) continue; var Y1=Math.round(Y(w))+0.5; c.beginPath(); c.moveTo(x0,Y1); c.lineTo(x1-14,Y1); c.stroke(); }
  c.restore();
  axes(c, x0, y0, x1, y1);
  var fs=o.fs||12, dec=function(s){ var d=0; while(d<4 && Math.abs(Math.round(s*Math.pow(10,d))-s*Math.pow(10,d))>1e-6) d++; return d; };
  var dx=dec(xs), dy=dec(ys);
  if(!o.noXt) for(var a=Math.ceil(xr[0]/xs-1e-9)*xs; a<=xr[1]-xs*0.3+1e-9; a+=xs){ if(Math.abs(a-xr[0])<1e-9 && !o.xz) continue; T(c, (o.xfmt? o.xfmt(a) : a.toFixed(dx)), X(a), y0+12, {size:fs, col:"#3a414c", align:"center"}); }
  if(!o.noYt) for(var b=Math.ceil(yr[0]/ys-1e-9)*ys; b<=yr[1]-ys*0.3+1e-9; b+=ys){ if(Math.abs(b-yr[0])<1e-9) continue; T(c, b.toFixed(dy), x0-6, Y(b), {size:fs, col:"#3a414c", align:"right"}); }
  if(!o.noO) T(c, "O", x0-5, y0+10, {size:fs+0.5, col:COL.sub, align:"right", it:true});
  if(o.xl) axisLabel(c, o.xl, x1, y0+(o.xlDy||28), "right");
  if(o.yl) axisLabel(c, o.yl, x0+4, y1-2, "left");
  return {X:X, Y:Y, x0:x0, y0:y0, x1:x1-14, y1:y1+14};
}
/* 軸の名前：先頭の 1 文字（p・V・T・t など）を斜体、残りを普通の字で（例 "V〔×10⁻² m³〕"） */
function axisLabel(c, s, x, y, align){
  /* 第3回：字を大きく、濃くして読みやすく */
  if(!/^[A-Za-z][^A-Za-z]/.test(s)){ T(c, s, x, y, {size:12.5, bold:true, col:"#3a414c", halo:true, align:(align==="right"? "right" : "left")}); return; }
  var sym=s.charAt(0), rest=s.slice(1);
  c.save(); c.font="italic 700 15px "+MATHF; var w1=c.measureText(sym).width; c.font="700 12.5px "+FONT; var w2=c.measureText(rest).width; c.restore();
  var X0=(align==="right")? x-w1-w2-1 : x;
  T(c, sym, X0, y, {size:15, it:true, bold:true, col:COL.ink, halo:true}); T(c, rest, X0+w1+1, y, {size:12.5, bold:true, col:"#3a414c", halo:true});
}
/* グラフの上に置く題 */
function graphTitle(c, s, x, y, o){ o=o||{}; T(c, s, x, y, {size:o.size||13, bold:true, col:o.col||"#14171c", align:o.align||"left", halo:true}); }
/* 点線の曲線（等温線など）：f(V)→p、範囲 [a,b] */
function curve(c, P, f, a, b, col, lw, dash, yr){
  c.save(); c.strokeStyle=col; c.lineWidth=lw||1.4; if(dash) c.setLineDash(dash);
  c.beginPath(); var first=true;
  for(var i=0;i<=120;i++){ var v=a+(b-a)*i/120, p=f(v); if(yr && (p>yr[1]*1.02 || p<yr[0])){ first=true; continue; }
    var x=P.X(v), y=P.Y(p); if(first){ c.moveTo(x,y); first=false; } else c.lineTo(x,y); }
  c.stroke(); c.restore();
}
function dot(c,x,y,r,col){ c.save(); c.fillStyle=col; c.beginPath(); c.arc(x,y,r,0,7); c.fill(); c.strokeStyle="#fff"; c.lineWidth=1.5; c.stroke(); c.restore(); }

/* ---------------- 「W_した」「W_された」を canvas に書く ---------------- */
function symW(c, which, x, y, o){ return SYM(c, "W", which, x, y, o); }

/* ---------------- オットーサイクル（ヒーローと 4-2） ----------------
   u …1 サイクルの中の位置 0〜1（クランク 2 回転）。体積の単位 ×10⁻⁴ m³、圧力の単位 ×10⁵ Pa。
   一瞬で起こる変化（点火・排気弁を開く）は、見えるように少し時間をとって表す（そのあいだクランクは止める）。 */
var OTTO = { Vc:0.5, Vm:4.0, g:1.4, a:2.5,
  /* 区間：[始め, 終わり, 名前, 種類] */
  SEG:[[0,0.20,"吸気","in"],[0.20,0.40,"圧縮","cmp"],[0.40,0.48,"点火（燃焼）","burn"],[0.48,0.68,"膨張","exp"],[0.68,0.76,"排気弁を開く","blow"],[0.76,1.0,"排気","out"]] };
OTTO.p2 = Math.pow(OTTO.Vm/OTTO.Vc, OTTO.g); OTTO.p3 = OTTO.p2*OTTO.a; OTTO.p4 = OTTO.p3/OTTO.p2;
function ottoState(u){
  u=((u%1)+1)%1;
  var S=OTTO.SEG, k=0; while(k<S.length-1 && u>=S[k][1]) k++;
  var s=S[k], f=(u-s[0])/(s[1]-s[0]), th;
  if(s[3]==="in") th=f*Math.PI; else if(s[3]==="cmp") th=Math.PI+f*Math.PI; else if(s[3]==="burn") th=2*Math.PI;
  else if(s[3]==="exp") th=2*Math.PI+f*Math.PI; else if(s[3]==="blow") th=3*Math.PI; else th=3*Math.PI+f*Math.PI;
  var lam=0.30, sx=(1-Math.cos(th))/2 + (1-Math.sqrt(1-lam*lam*Math.sin(th)*Math.sin(th)))/(2*lam);   /* 0〜1 の行程（連接棒の長さを考える） */
  var V=OTTO.Vc+(OTTO.Vm-OTTO.Vc)*sx, p;
  if(s[3]==="in" || s[3]==="out") p=1;
  else if(s[3]==="cmp") p=Math.pow(OTTO.Vm/V, OTTO.g);
  else if(s[3]==="burn") p=OTTO.p2+(OTTO.p3-OTTO.p2)*f;
  else if(s[3]==="exp") p=OTTO.p3*Math.pow(OTTO.Vc/V, OTTO.g);
  else p=OTTO.p4+(1-OTTO.p4)*f;
  return {u:u, k:k, f:f, name:s[2], kind:s[3], th:th, sx:sx, V:V, p:p,
          inOpen:(s[3]==="in"), exOpen:(s[3]==="blow"||s[3]==="out"), spark:(s[3]==="burn" && f<0.6)};
}
/* エンジンの断面：(cx, yTop) …シリンダーの上（燃焼室の天井）のまん中、w …内径、Hs …行程の長さ［px］。dark …ヒーロー（暗い地）用の色 */
function drawEngine(c, cx, yTop, w, Hs, st, clk, dark){
  var txt=window.T;
  var hc=Hs*OTTO.Vc/(OTTO.Vm-OTTO.Vc), yp=yTop+hc+Hs*st.sx, pt=w*0.32;
  var wallC=dark? "rgba(222,232,245,.55)" : "#5b636e", wallF=dark? "rgba(159,208,255,.10)" : "#d3d8de";
  var T=300*st.p*st.V/(OTTO.Vm*1);             /* 温度の目安（初めを 300 K） */
  c.save();
  /* 燃焼室の中の気体 */
  c.fillStyle=dark? ("rgba(255,"+Math.round(clamp(230-T/12,60,230))+","+Math.round(clamp(200-T/8,30,200))+","+(0.10+0.35*clamp((T-300)/2200,0,1))+")") : gasTint(Math.min(T,650),0.5);
  c.fillRect(cx-w/2, yTop, w, yp-yTop);
  if(st.spark){ var g=c.createRadialGradient(cx,yTop+6,1,cx,yTop+6,w*0.55); g.addColorStop(0,"rgba(255,240,170,.95)"); g.addColorStop(1,"rgba(255,140,40,0)"); c.fillStyle=g; c.fillRect(cx-w/2,yTop,w,yp-yTop); }
  /* シリンダーの壁と天井 */
  c.fillStyle=wallF; c.strokeStyle=wallC; c.lineWidth=1.4;
  var wt=10; c.fillRect(cx-w/2-wt, yTop-wt, wt, Hs+hc+wt+12); c.fillRect(cx+w/2, yTop-wt, wt, Hs+hc+wt+12);
  c.fillRect(cx-w/2-wt, yTop-wt-2, w+2*wt, wt);
  c.strokeRect(cx-w/2-wt, yTop-wt-2, w+2*wt, wt);
  c.beginPath(); c.moveTo(cx-w/2,yTop); c.lineTo(cx-w/2,yTop+Hs+hc+12); c.moveTo(cx+w/2,yTop); c.lineTo(cx+w/2,yTop+Hs+hc+12); c.stroke();
  /* 吸気管・排気管と、外から入ってくる／外へ出ていく気体の分子 */
  var vxI=cx-w*0.30, vxE=cx+w*0.30, yv=yTop-wt-2, yp2=yTop-wt-26, pl=Math.min(70, w*0.75);
  var pI=[[vxI,yv],[vxI,yp2],[vxI-pl,yp2]], pE=[[vxE,yv],[vxE,yp2],[vxE+pl,yp2]];
  var tube=function(P){ c.lineJoin="round"; c.lineCap="butt"; c.strokeStyle=dark? "rgba(222,232,245,.45)" : "#7a828c"; c.lineWidth=14; c.beginPath(); P.forEach(function(q,i){ if(i) c.lineTo(q[0],q[1]); else c.moveTo(q[0],q[1]); }); c.stroke();
    c.strokeStyle=dark? "#141b26" : "#eef2f6"; c.lineWidth=10; c.stroke(); };
  tube(pI); tube(pE);
  var along=function(P,u){ var a=P[0], b=P[1], d=P[2], L1=Math.abs(b[1]-a[1]), L2=Math.abs(d[0]-b[0]), s=u*(L1+L2); return (s<L1)? [a[0], a[1]+(b[1]-a[1])*s/L1] : [b[0]+(d[0]-b[0])*(s-L1)/L2, b[1]]; };
  var colFresh=dark? "#7fc4ff" : "#3a7bd5", colBurn=dark? "#ffb070" : "#e0702a";
  var k=st.kind, f=st.f, n=14, show, burned=(k==="exp"||k==="blow"||k==="out"||(k==="burn" && f>0.3));
  show=(k==="in")? f : (k==="blow")? 1-0.35*f : (k==="out")? 0.65*(1-f) : 1;
  var nIn=Math.round(n*show), r=dark? 3.4 : 3.8, sp=0.35+0.9*Math.sqrt(clamp(T,250,2500)/300)*0.5;
  for(var i=0;i<n;i++){
    if(i<nIn){ var ax=tri(0.13*i+0.37+(clk||0)*sp*(0.6+0.07*(i%5))), ay=tri(0.29*i+0.11+(clk||0)*sp*(0.5+0.05*(i%7)));
      ball(c, cx-w/2+r+2+(w-2*r-4)*ax, yTop+r+1+Math.max(0,yp-yTop-2*r-2)*ay, r, 0, burned? colBurn : colFresh); }
  }
  /* 管の中を流れる分子 */
  if(k==="in"){ for(var j=0;j<4;j++){ var uu=1-((j*0.25+(clk||0)*0.9)%1); var q=along(pI, uu); ball(c, q[0], q[1], r*0.85, 0, colFresh); } }
  if(k==="blow"||k==="out"){ for(var j2=0;j2<4;j2++){ var u3=((j2*0.25+(clk||0)*0.9)%1); var q2=along(pE, u3); ball(c, q2[0], q2[1], r*0.85, 0, colBurn); } }
  if(!dark){ txt(c, "吸気（空気と燃料）", vxI-pl, yp2-30, {size:10.5, bold:true, col:"#1f6fb2"}); txt(c, "排気（大気へ）", vxE+pl, yp2-30, {size:10.5, bold:true, col:"#b5462e", align:"right"}); }
  /* 弁（左＝吸気、右＝排気）と点火プラグ */
  var vlv=function(x, open, col){ var d=open? 8 : 0; c.strokeStyle=col; c.lineWidth=3; c.beginPath(); c.moveTo(x, yTop-wt-14); c.lineTo(x, yTop+d-1); c.stroke();
    c.fillStyle=col; c.beginPath(); c.moveTo(x-9,yTop+d); c.lineTo(x+9,yTop+d); c.lineTo(x+4,yTop+d-4); c.lineTo(x-4,yTop+d-4); c.closePath(); c.fill(); };
  vlv(cx-w*0.30, st.inOpen, dark? "#9fd0ff" : "#1f6fb2"); vlv(cx+w*0.30, st.exOpen, dark? "#ffa48f" : "#b5462e");
  c.fillStyle=dark? "#e6edf5" : "#3a414c"; c.fillRect(cx-3, yTop-wt-16, 6, 14);
  if(st.spark){ c.strokeStyle="#fff3a0"; c.lineWidth=2; c.beginPath(); c.moveTo(cx,yTop+1); c.lineTo(cx-4,yTop+6); c.lineTo(cx+3,yTop+8); c.lineTo(cx-2,yTop+13); c.stroke(); }
  /* ピストン・連接棒・クランク */
  var cyc=yTop+hc+Hs+Hs*0.95, rc=Hs/2, ang=st.th, kx=cx+rc*Math.sin(ang), ky=cyc-rc*Math.cos(ang);
  var pc=c.createLinearGradient(cx-w/2,0,cx+w/2,0); pc.addColorStop(0,dark? "#5d6b7c" : "#9aa1ab"); pc.addColorStop(0.5,dark? "#9fb0c3" : "#e3e6ea"); pc.addColorStop(1,dark? "#5d6b7c" : "#9aa1ab");
  c.fillStyle=pc; c.strokeStyle=dark? "rgba(222,232,245,.7)" : "#4b535e"; c.lineWidth=1.2; c.fillRect(cx-w/2+1, yp, w-2, pt); c.strokeRect(cx-w/2+1, yp, w-2, pt);
  c.strokeStyle=dark? "rgba(222,232,245,.75)" : "#5b636e"; c.lineWidth=5; c.lineCap="round"; c.beginPath(); c.moveTo(cx, yp+pt*0.6); c.lineTo(kx,ky); c.stroke();
  c.lineWidth=1.3; c.beginPath(); c.arc(cx,cyc,rc+7,0,7); c.stroke();
  c.lineWidth=6; c.beginPath(); c.moveTo(cx,cyc); c.lineTo(kx,ky); c.stroke();
  c.fillStyle=dark? "#4fa8ff" : "#3a414c"; c.beginPath(); c.arc(cx,cyc,4.5,0,7); c.fill(); c.beginPath(); c.arc(kx,ky,4,0,7); c.fill();
  c.restore();
  return {yp:yp, cyc:cyc, rc:rc, hc:hc, T:T};
}

/* v の成分の 2 乗の平均（上に横線）を canvas に描く：sub …"x" など（null なら v² の平均）。返り値は幅 */
function vbar2(c, sub, x, y, o){ o=o||{}; var size=o.size||14, col=o.col||COL.ink;
  c.save(); c.font="italic 700 "+size+"px "+MATHF; var wb=c.measureText("v").width; c.font=Math.round(size*0.68)+"px "+SERIF; var ws=sub? c.measureText(sub).width : 0, w2=c.measureText("2").width; c.restore();
  var w=wb+Math.max(ws,w2)+2, X=(o.align==="center")? x-w/2 : (o.align==="right")? x-w : x;
  SYM(c, "v", sub, X, y, {size:size, bold:true, col:col, halo:o.halo});
  c.save(); c.font=Math.round(size*0.68)+"px "+SERIF; c.fillStyle=col; c.textBaseline="middle"; c.fillText("2", X+wb+1, y-size*0.38); c.restore();
  c.save(); c.strokeStyle=col; c.lineWidth=1.3; c.beginPath(); c.moveTo(X, y-size*0.78); c.lineTo(X+w, y-size*0.78); c.stroke(); c.restore();
  return w; }
