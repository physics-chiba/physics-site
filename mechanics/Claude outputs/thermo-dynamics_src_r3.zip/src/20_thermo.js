/* =========================================================================
   熱のページの共通部品（どの節でも同じものを使いまわす）
   ・温度計（物体にさして使う）　・バーナー　・三脚と金網　・ビーカー
   ・粒子（つりあいの位置の＋印の周りで震える）　・熱の矢印　・グラフの軸
   ========================================================================= */
/* 温度の高さ 0〜1 → 粒子の色（低いと青み、高いと赤み）。test/202609-2-review-exam.html と同じ */
function heatCol(lv){ lv=clamp(lv,0,1);
  return 'rgb('+Math.round(150+105*lv)+','+Math.round(180-95*lv)+','+Math.round(215-140*lv)+')'; }
/* ゆれの位相（粒子ごとにばらばら。毎回同じ値） */
var PH = []; (function(){ for(var i=0;i<400;i++) PH.push([(i*2.399)%6.283, (i*1.618+1.1)%6.283, 0.75+((i*0.61803)%1)*0.5]); })();

/* 温度計：球部（下の丸）を物体の中にさしこんで使う。
   x … 管の中心、yB … 球部の中心、yT … 管の上はし。lo・hi … 目盛りの下と上［℃］。
   o.ticks … 目盛りに数字を書く温度、o.side … 数値（〇℃）を置く側 "left"／"right" */
function thermometer(c, x, yB, yT, tc, lo, hi, o){
  o = o||{};
  var tw=o.tw||9, br=o.br||7, y0=yB-br-2, y1=yT+5;
  var yOf=function(tv){ return y0-(y0-y1)*clamp((tv-lo)/(hi-lo),0,1); };
  c.save();
  /* ガラス管と球部 */
  c.fillStyle="rgba(255,255,255,.93)"; c.strokeStyle="#5b636e"; c.lineWidth=1.3;
  rrect(c, x-tw/2, yT, tw, yB-yT, tw/2); c.fill(); c.stroke();
  c.beginPath(); c.arc(x,yB,br,0,7); c.fill(); c.stroke();
  /* 赤い液 */
  c.fillStyle="#d1352b";
  c.beginPath(); c.arc(x,yB,br-2,0,7); c.fill();
  var yl=yOf(tc); c.fillRect(x-2.3, yl, 4.6, yB-yl);
  /* 目盛り */
  var tk=o.ticks||[lo, (lo+hi)/2, hi];
  c.strokeStyle="#7b838d"; c.lineWidth=1;
  for(var k=0;k<=10;k++){ var yy=y0-(y0-y1)*k/10; c.beginPath(); c.moveTo(x+tw/2, yy); c.lineTo(x+tw/2+(k%5===0?6:3.5), yy); c.stroke(); }
  if(!o.noNum) tk.forEach(function(tv){ T(c, String(tv), x+tw/2+8, yOf(tv), {size:9.5, col:"#69717d", halo:true}); });
  c.restore();
  /* いまの温度 */
  if(!o.noVal){
    var side=o.side||"top", txt=(o.fmt? o.fmt(tc) : (Math.abs(tc)<0.05? "0" : tc.toFixed(o.dec===undefined?1:o.dec)))+" ℃";
    if(side==="top") T(c, txt, x, yT-10, {size:o.vsize||13, bold:true, col:"#a03028", align:"center", halo:true});
    else { var tx=(side==="left")? x-tw/2-6 : x+tw/2+(o.noNum?8:30);
      T(c, txt, tx, clamp(yl, yT+8, yB-12), {size:o.vsize||13, bold:true, col:"#a03028", align:(side==="left"?"right":"left"), halo:true}); }
  }
  return {yOf:yOf};
}

/* バーナー（ガスバーナー）。x … 中心、yB … 台の下はし（机の面）、on … 火がついているか、t … 時刻（ゆらぎ） */
function burner(c, x, yB, on, t, sc){
  sc = sc||1;
  var bw=40*sc, bh=14*sc, tw=13*sc, th=34*sc;
  c.save();
  c.fillStyle="#34495e"; c.fillRect(x-bw/2, yB-bh, bw, bh);
  c.fillStyle="#7f8c8d"; c.fillRect(x-tw/2, yB-bh-th, tw, th);
  c.fillStyle="#95a5a6"; c.fillRect(x-tw/2-2*sc, yB-bh-th, tw+4*sc, 4*sc);
  if(on){
    var fh=(30+5*Math.sin(t*23)+3*Math.sin(t*37))*sc, fw=11*sc, y0=yB-bh-th;
    var gr=c.createLinearGradient(0,y0,0,y0-fh); gr.addColorStop(0,"rgba(80,140,255,.95)"); gr.addColorStop(0.45,"rgba(120,170,255,.75)"); gr.addColorStop(1,"rgba(255,160,80,.25)");
    c.fillStyle=gr; c.beginPath(); c.moveTo(x-fw,y0); c.quadraticCurveTo(x-fw*0.9,y0-fh*0.55,x+Math.sin(t*17)*2,y0-fh); c.quadraticCurveTo(x+fw*0.9,y0-fh*0.55,x+fw,y0); c.closePath(); c.fill();
    c.fillStyle="rgba(40,90,230,.85)"; c.beginPath(); c.moveTo(x-fw*0.45,y0); c.quadraticCurveTo(x,y0-fh*0.6,x+fw*0.45,y0); c.closePath(); c.fill();
  }
  c.restore();
  return yB-bh-th;   /* 口の高さ */
}
/* 三脚と金網。xc … 中心、yTop … 金網の上の面、yB … 机の面、w … 金網の幅 */
function tripod(c, xc, yTop, yB, w){
  c.save();
  c.strokeStyle="#7f8a8a"; c.lineWidth=4; c.lineCap="round";
  c.beginPath(); c.moveTo(xc-w*0.40, yTop+5); c.lineTo(xc-w*0.52, yB); c.moveTo(xc+w*0.40, yTop+5); c.lineTo(xc+w*0.52, yB); c.stroke();
  c.fillStyle="#95a5a6"; c.fillRect(xc-w/2, yTop, w, 6);
  c.strokeStyle="#7f8c8d"; c.lineWidth=1; c.strokeRect(xc-w/2, yTop, w, 6);
  c.restore();
}
/* ビーカー（口が開いた容器）。中身は呼ぶ側が描く。x0,y0 … 左上、w,h … 大きさ */
function beakerGlass(c, x0, y0, w, h){
  c.save(); c.strokeStyle="#6f7b86"; c.lineWidth=2; c.lineJoin="round";
  c.beginPath(); c.moveTo(x0-5, y0); c.lineTo(x0, y0+4); c.lineTo(x0, y0+h); c.lineTo(x0+w, y0+h); c.lineTo(x0+w, y0); c.stroke();
  c.fillStyle="rgba(230,240,248,.35)"; c.fillRect(x0+1, y0+4, w-2, h-5);
  c.restore();
}

/* 格子にならんだ粒子（固体）。lv … 温度の高さ 0〜1（ふるえの大きさと色）。nx×ny 個 */
function latticeParticles(c, x, y, w, h, lv, clk, o){
  o = o||{};
  var nx=o.nx||4, ny=o.ny||4, r=o.r||8, a=(o.a0===undefined?1.0:o.a0)+(o.a1===undefined?7.5:o.a1)*lv, k=o.k0||0;
  var dx=w/nx, dy=h/ny;
  c.save();
  for(var j=0;j<ny;j++) for(var i=0;i<nx;i++){
    var p=PH[(k++)%PH.length], ex=x+dx*(i+0.5), ey=y+dy*(j+0.5);
    var ox=a*Math.sin(clk*(7.5+5*lv)*p[2]+p[0]), oy=a*Math.sin(clk*(7.0+5*lv)*p[2]+p[1]);
    c.beginPath(); c.arc(ex+ox, ey+oy, r, 0, 7); c.fillStyle=o.col||heatCol(lv); c.strokeStyle="#33414f"; c.lineWidth=1.1; c.fill(); c.stroke();
    if(!o.noMark){ c.strokeStyle="#6d7480"; c.lineWidth=1.1; c.beginPath();
      c.moveTo(ex-4,ey); c.lineTo(ex+4,ey); c.moveTo(ex,ey-4); c.lineTo(ex,ey+4); c.stroke(); }
  }
  c.restore();
}
/* 第15回：液体の粒子。格子にならばず、近くの粒子と押し合いながら動きまわる（①-2 の液体と同じ動き）。
   st … 粒子の状態を入れておくオブジェクト（図ごとに 1 つ）。箱の大きさが変わったら位置を伸び縮みさせる */
function liquidParticles(c, st, x, y, w, h, lv, clk, o){
  o=o||{}; var r=o.r||8, n=o.n||9;
  if(!st.p || st.p.length!==n){ st.p=[]; var nx=Math.max(2,Math.round(Math.sqrt(n*w/h))), ny=Math.ceil(n/nx);
    for(var i=0;i<n;i++){ var p=PH[(i*3+(o.k0||0))%PH.length], ix=i%nx, iy=Math.floor(i/nx);
      st.p.push({x:w*(ix+0.5+0.3*Math.sin(p[0]))/nx, y:h*(iy+0.5+0.3*Math.sin(p[1]))/ny, vx:30*Math.cos(p[0]*3), vy:30*Math.sin(p[1]*3)}); }
    st.w=w; st.h=h; st.t=clk; }
  if(st.w!==w || st.h!==h){ var fx=w/st.w, fy=h/st.h; st.p.forEach(function(q){ q.x*=fx; q.y*=fy; }); st.w=w; st.h=h; }
  var dt=clk-st.t; st.t=clk; if(!(dt>0)) dt=0; dt=Math.min(dt,0.05);
  var L=st.p, sp=22+70*lv, m=Math.max(1,Math.ceil(dt/0.01)), hh=dt/m;
  for(var k=0;k<m;k++){
    L.forEach(function(q,i){ var p=PH[(i*7)%PH.length], tt=clk+k*hh;
      q.vx+=Math.sin(tt*9.1*p[2]+p[0]*5)*sp*4*hh; q.vy+=Math.cos(tt*8.3*p[2]+p[1]*5)*sp*4*hh;
      var v=Math.hypot(q.vx,q.vy); if(v>sp){ q.vx*=sp/v; q.vy*=sp/v; } });
    for(var i=0;i<L.length;i++) for(var j=i+1;j<L.length;j++){ var A=L[i], B=L[j], dx=B.x-A.x, dy=B.y-A.y, d=Math.hypot(dx,dy)||1;
      if(d<2*r+1){ var ov=(2*r+1-d)/2, ux=dx/d, uy=dy/d; A.x-=ux*ov; A.y-=uy*ov; B.x+=ux*ov; B.y+=uy*ov;
        var rv=(B.vx-A.vx)*ux+(B.vy-A.vy)*uy; if(rv<0){ A.vx+=rv*ux; A.vy+=rv*uy; B.vx-=rv*ux; B.vy-=rv*uy; } }
      else if(d<2*r+9){ var k2=6*hh; A.vx+=dx/d*k2; A.vy+=dy/d*k2; B.vx-=dx/d*k2; B.vy-=dy/d*k2; } }
    L.forEach(function(q){ q.x+=q.vx*hh; q.y+=q.vy*hh;
      if(q.x<r){ q.x=r; q.vx=Math.abs(q.vx); } if(q.x>w-r){ q.x=w-r; q.vx=-Math.abs(q.vx); }
      if(q.y<r){ q.y=r; q.vy=Math.abs(q.vy); } if(q.y>h-r){ q.y=h-r; q.vy=-Math.abs(q.vy); } });
  }
  c.save(); L.forEach(function(q){ ball(c, x+q.x, y+q.y, r, lv, o.col); }); c.restore();
}
/* 1 個の粒子（液体・気体用） */
function ball(c, x, y, r, lv, col){
  c.beginPath(); c.arc(x,y,r,0,7); c.fillStyle=col||heatCol(lv); c.strokeStyle="#33414f"; c.lineWidth=1.1; c.fill(); c.stroke();
}

/* 熱（熱量 Q）の矢印：オレンジの太い矢印。太さ＝流れる熱の大きさ */
function heatArrow(c, x1, y1, x2, y2, lw, a){
  var L=Math.hypot(x2-x1,y2-y1); if(L<4) return;
  var ux=(x2-x1)/L, uy=(y2-y1)/L, hl=Math.min(L*0.55, lw*0.9+8), hw=lw*0.95+7;
  c.save(); c.globalAlpha=(a===undefined?0.92:a); c.fillStyle=COL.heat; c.strokeStyle=COL.heat; c.lineWidth=lw; c.lineCap="butt";
  c.beginPath(); c.moveTo(x1,y1); c.lineTo(x2-ux*hl, y2-uy*hl); c.stroke();
  c.beginPath(); c.moveTo(x2,y2); c.lineTo(x2-ux*hl-uy*hw, y2-uy*hl+ux*hw); c.lineTo(x2-ux*hl+uy*hw, y2-uy*hl-ux*hw); c.closePath(); c.fill();
  c.restore();
}
/* 太い白抜きの矢印（仕事 W など）。col … 色 */
function blockArrow(c, x1, y1, x2, y2, lw, col, a){
  var L=Math.hypot(x2-x1,y2-y1); if(L<4) return;
  var ux=(x2-x1)/L, uy=(y2-y1)/L, hl=Math.min(L*0.55, lw*0.9+8), hw=lw*0.95+7, px=-uy, py=ux, h=lw/2;
  c.save(); c.globalAlpha=(a===undefined?0.95:a);
  c.beginPath(); c.moveTo(x1+px*h, y1+py*h); c.lineTo(x2-ux*hl+px*h, y2-uy*hl+py*h); c.lineTo(x2-ux*hl+px*hw, y2-uy*hl+py*hw); c.lineTo(x2,y2);
  c.lineTo(x2-ux*hl-px*hw, y2-uy*hl-py*hw); c.lineTo(x2-ux*hl-px*h, y2-uy*hl-py*h); c.lineTo(x1-px*h, y1-py*h); c.closePath();
  c.fillStyle=col; c.fill(); c.strokeStyle="rgba(0,0,0,.25)"; c.lineWidth=1; c.stroke();
  c.restore();
}

/* グラフの軸（矢印つき）。x0,y0 … 原点、x1 … 横軸の右はし、y1 … 縦軸の上はし */
function axes(c, x0, y0, x1, y1, xl, yl){
  c.save(); c.strokeStyle="#3a414c"; c.lineWidth=1.3;
  c.beginPath(); c.moveTo(x0,y0); c.lineTo(x1-6,y0); c.moveTo(x0,y0); c.lineTo(x0,y1+6); c.stroke(); c.restore();
  arrow(c, x1-10, y0, x1, y0, "#3a414c", 1.3, 8); arrow(c, x0, y1+10, x0, y1, "#3a414c", 1.3, 8);
  if(xl) T(c, xl, x1, y0+16, {size:11, col:COL.sub, align:"right"});
  if(yl) T(c, yl, x0+6, y1+2, {size:11, col:COL.sub});
}
/* きりのいい目盛り幅（1・2・5×10ⁿ） */
function niceStep(span, n){ var raw=span/(n||5), e=Math.pow(10,Math.floor(Math.log10(raw))), m=raw/e; return (m<1.5?1:m<3.5?2:m<7.5?5:10)*e; }

/* ---------------- 第2回で追加 ---------------- */
/* 熱が移動していることの表し方（第4回）：「熱の粒」は描かない（熱は物質ではない）。
   矢印そのものは動かさず、矢印の中の色の濃淡（濃いだいだい → 明るいクリーム色の帯）が根もとから先へ流れる。
   o.k … 熱の移る速さの割合 0〜1。矢印の太さだけでなく、長さ・矢じりの大きさも k で変える（中心はそのまま）。
   ph … 帯の位置（0〜1）。呼ぶ側で、熱の移る速さに比例して増やす */
function heatFlow(c, x1, y1, x2, y2, lw, ph, o){
  o=o||{};
  var k=(o.k===undefined)? 1 : clamp(o.k,0,1), sc=0.45+0.55*k;
  var mx=(x1+x2)/2, my=(y1+y2)/2, L0=Math.hypot(x2-x1,y2-y1); if(L0<8) return;
  var ux=(x2-x1)/L0, uy=(y2-y1)/L0, L=L0*sc;
  x1=mx-ux*L/2; y1=my-uy*L/2; x2=mx+ux*L/2; y2=my+uy*L/2;
  var px=-uy, py=ux, h=lw/2, hl=Math.min(L*0.45, (lw*0.9+9)*(0.6+0.4*sc)), hw=(lw*0.95+7)*(0.6+0.4*sc);
  var gr=c.createLinearGradient(x1,y1,x2,y2), NB=2, bw=0.22;
  var band=function(u){ var v=0; for(var j=0;j<NB;j++){ var cp=((j/NB)+ph)%1; [cp-1,cp,cp+1].forEach(function(cc){ var d=Math.abs(u-cc); if(d<bw) v=Math.max(v,1-d/bw); }); } return v; };
  for(var i=0;i<=40;i++){ var u=i/40, v=band(u);
    gr.addColorStop(u, o.cool? "rgb("+Math.round(32+150*v)+","+Math.round(110+120*v)+","+Math.round(210+45*v)+")" : "rgb("+Math.round(200+55*v)+","+Math.round(86+146*v)+","+Math.round(15+169*v)+")"); }
  c.save(); if(o.a!==undefined) c.globalAlpha=o.a;
  c.beginPath(); c.moveTo(x1+px*h,y1+py*h); c.lineTo(x2-ux*hl+px*h,y2-uy*hl+py*h); c.lineTo(x2-ux*hl+px*hw,y2-uy*hl+py*hw); c.lineTo(x2,y2);
  c.lineTo(x2-ux*hl-px*hw,y2-uy*hl-py*hw); c.lineTo(x2-ux*hl-px*h,y2-uy*hl-py*h); c.lineTo(x1-px*h,y1-py*h); c.closePath();
  c.fillStyle=gr; c.fill(); c.strokeStyle=o.cool? "rgba(20,70,150,.5)" : "rgba(150,60,0,.45)"; c.lineWidth=1; c.stroke();
  c.restore();
}
/* 氷のかたまり（立方体を斜め上から見た形）。x,y … 正面の左上、s … 1 辺 */
function iceCube(c, x, y, s, a){
  var dx=s*0.30, dy=s*0.24, r=s*0.10;
  c.save(); if(a!==undefined) c.globalAlpha=a; c.lineJoin="round";
  /* 上の面 */
  c.beginPath(); c.moveTo(x+r,y); c.lineTo(x+dx+r*0.6,y-dy); c.lineTo(x+s+dx-r*0.4,y-dy); c.lineTo(x+s,y); c.closePath();
  c.fillStyle="#eef7fe"; c.fill();
  /* 右の面 */
  c.beginPath(); c.moveTo(x+s,y); c.lineTo(x+s+dx-r*0.4,y-dy); c.lineTo(x+s+dx,y+s-dy-r); c.lineTo(x+s,y+s-r*0.4); c.closePath();
  c.fillStyle="#b4d5ee"; c.fill();
  /* 正面 */
  var g=c.createLinearGradient(x,y,x+s,y+s); g.addColorStop(0,"#e3f1fc"); g.addColorStop(1,"#b9d9f2");
  rrect(c,x,y,s,s,r); c.fillStyle=g; c.fill();
  /* 輪郭 */
  c.strokeStyle="#4d7fb3"; c.lineWidth=1.4;
  rrect(c,x,y,s,s,r); c.stroke();
  c.beginPath(); c.moveTo(x+r*0.6,y); c.lineTo(x+dx+r*0.6,y-dy); c.lineTo(x+s+dx-r*0.4,y-dy); c.lineTo(x+s+dx,y+s-dy-r); c.lineTo(x+s-r*0.2,y+s-r*0.3); c.stroke();
  c.beginPath(); c.moveTo(x+s+dx-r*0.4,y-dy); c.lineTo(x+s-r*0.3,y+r*0.2); c.stroke();
  /* 光の筋と小さな泡 */
  c.strokeStyle="rgba(255,255,255,.95)"; c.lineWidth=Math.max(1.2,s*0.05); c.lineCap="round";
  c.beginPath(); c.moveTo(x+s*0.18,y+s*0.62); c.lineTo(x+s*0.42,y+s*0.30); c.moveTo(x+s*0.30,y+s*0.78); c.lineTo(x+s*0.46,y+s*0.56); c.stroke();
  c.fillStyle="rgba(255,255,255,.9)"; c.beginPath(); c.arc(x+s*0.70,y+s*0.70,Math.max(1.2,s*0.04),0,7); c.fill();
  c.restore();
}
/* 3 個積んだ氷（下に 2 個、上に 1 個）。xc … 中心、yb … 下の面、s … 1 辺 */
function iceStack(c, xc, yb, s, a){
  iceCube(c, xc-s*1.02, yb-s, s, a); iceCube(c, xc+s*0.02, yb-s, s, a); iceCube(c, xc-s*0.55, yb-s*1.95, s*0.98, a);
}

/* 時間バー（simple-harmonic-motion と同じ考え方：つまみを動かすと、その時刻の状態を表示。戻すことも先へ進めることもできる） */
function H_timebar(){
  return '<div class="tbox tsl tbar" data-k="time"><span class="vl">時間</span><input type="range" min="0" max="1000" step="1" value="0" aria-label="時間"></div>';
}
/* run … Runner、tEnd() … 最後の時刻［run.t の単位］、apply(t) … その時刻の状態にする */
function wireTimeBar(sec, run, tEnd, apply){
  var inp=sec.querySelector('.tbar input');
  var upd=function(){ inp.style.setProperty("--p", (inp.value/10).toFixed(1)+"%"); };
  inp.addEventListener("input", function(){
    if(run.state==="run") cancelAnimationFrame(run.raf);
    var te=tEnd(), t=te*inp.value/1000; run.t=t;
    run.state = (inp.value>=1000)? "done" : (t<=0? "idle" : "pause");
    upd(); apply(t); run.opt.draw(); run.label();
  });
  upd();
  return { sync:function(){ var te=tEnd(); inp.value=Math.round(1000*clamp(run.t/te,0,1)); upd(); } };
}

/* ---------------- 第7回：操作を「その物質の真上」に置く（①-4・①-5） ----------------
   .duo の左（duoL）と右（duoR）を、図の列にそろえて並べ直す。
   opt.B … true なら、組み合わせボタンと再生バーを 3 列目（グラフの真上）へ移す。
   opt.lc / opt.rc … 左右の箱の色（"hot" 赤＝高温側、"cold" 青＝低温側、"ref" 青、"sub" 茶）。
   set(cv, [x1, x2]) … 図の中の列の境目（canvas の CSS px）。広い図のときだけ列をそろえ、せまいときは縦に並べる。 */
function colGrid(sec, opt){
  var ctr=sec.querySelector(".ctrls"), duo=ctr.querySelector(".duo"), L=duo.querySelector(".duoL"), R=duo.querySelector(".duoR");
  var g=document.createElement("div"); g.className="colgrid "+(opt.B? "cg3" : "cg2");
  L.classList.add("cgL", opt.lc||"hot"); R.classList.add("cgR", opt.rc||"cold");
  g.appendChild(L); g.appendChild(R);
  if(opt.B){ var B=document.createElement("div"); B.className="cgB";
    var r1=ctr.querySelector(":scope > .row1"), pb=ctr.querySelector(":scope > .playbar");
    if(r1) B.appendChild(r1); if(pb) B.appendChild(pb); g.appendChild(B); }
  var row=duo.closest(".row2"); (row||duo).parentNode.replaceChild(g, row||duo);
  return { el:g, set:function(cv, xs, wide){
    if(!wide){ g.classList.remove("wide"); g.style.gridTemplateColumns=""; return; }
    var cr=cv.getBoundingClientRect(), gr=g.getBoundingClientRect(), off=cr.left-gr.left, b=xs.map(function(x){ return Math.max(40, off+x); });
    g.classList.add("wide");
    var cols = (xs.length===2)? [b[0], b[1]-b[0]] : [b[0]];
    var tpl=cols.map(function(v){ return v.toFixed(1)+"px"; }).join(" ")+" minmax(0,1fr)";
    if(g.style.gridTemplateColumns!==tpl) g.style.gridTemplateColumns=tpl;
  } };
}
