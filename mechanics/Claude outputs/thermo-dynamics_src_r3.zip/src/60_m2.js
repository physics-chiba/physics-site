/* =========================================================================
   モード② 気体分子運動論（2-1〜2-4）
   ========================================================================= */
/* 壁で弾性衝突をくり返す 1 方向の動き：展開した座標 u → 0〜1 の位置（三角波） */
function tri(u){ u=((u%2)+2)%2; return u<1? u : 2-u; }

/* ---------------- ②-1 分子 1 個が壁に与える力積（第2回で作り直し：教科書の動画を参考に） ----------------
   ① 0〜3 s：立方体の容器の中を、たくさんの分子が飛び回る（斜め上から）。
   ② 3〜11 s：左「気体分子の速度の変化」…壁 S に当たると、速度の x 成分だけ向きが変わる（y・z 成分はそのまま）。
              右「x 方向の運動量の変化と力積」…mvₓ → −mvₓ。分子が受ける力積 −2mvₓ、壁 S が受ける力積 2mvₓ。
   ③ 11〜24 s：横から見た図。x 方向は一定の速さ vₓ で往復し、2L/vₓ ごとに壁 S に衝突する。下に力の時間変化 */
var S21 = {
  DUR:24, TA:3, TB:11, TC1:7, vx:0.70, vy:0.31, vz:0.22, x0:0.22, y0:0.35, z0:0.30,
  STEPS:[
    ['1 回の衝突で、分子の運動量の '+'$x$'+' 成分は $mv_x$ から $-mv_x$ に変わる（$y$・$z$ 成分は変わらない）。分子が壁 S から受ける力積は','$-mv_x-mv_x=-2mv_x$','作用・反作用の法則より、壁 S が分子から受ける力積は、大きさ $2mv_x$、$x$ 軸の正の向き。'],
    ['$x$ 方向だけを見ると、分子は距離 $2L$ を速さ $v_x$ で進むと、再び壁 S に衝突する。衝突の周期は','$\\dfrac{2L}{v_x}$',''],
    ['時間 $t$ の間に壁 S に衝突する回数は','$t\\div\\dfrac{2L}{v_x}=\\dfrac{v_xt}{2L}$',''],
    ['時間 $t$ の間に、壁 S が 1 個の分子から受ける力積の合計は','$2mv_x\\times\\dfrac{v_xt}{2L}=\\dfrac{m{v_x}^2}{L}t$',''],
    ['この力積を、一定の力 $\\overline{f}$ が時間 $t$ の間はたらいたものと考えると $\\overline{f}t=\\dfrac{m{v_x}^2}{L}t$ より','$\\overline{f}=\\dfrac{m{v_x}^2}{L}$','これが、壁 S が 1 個の分子から受ける平均の力。下のグラフでは、とがった山の面積（1 回の力積）と、点線の長方形の面積が等しい。']],
  /* 第3回：アニメを 2 つに分ける。式①（1 回の衝突：0〜11 s）と、式②〜⑤（横から見た図：0〜13 s）。
     式①を最後まで見ると、式②〜⑤のスタートが押せるようになる。再生中は右の式が自動で開いて光る */
  DUR1:11, DUR2:13,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.part=1; this.step=0; this.unlocked=false; var R=rng(211); this.many=[]; for(var i=0;i<10;i++) this.many.push({p:[R(),R(),R()], v:[(R()-0.5)*0.5,(R()-0.5)*0.5,(R()-0.5)*0.5]});
    var g1=sec.querySelector('.pt21[data-p="1"]'), g2=sec.querySelector('.pt21[data-p="2"]');
    this.run=new Runner({ begin:function(){ self.part=1; self.run2.reset(); },
      step:function(){ self.syncStep(); return self.run.t>=self.DUR1; },
      draw:function(){ self.draw(); if(self.run.t>=self.DUR1) self.unlock(); }, reset:function(){} });
    this.run.bind(g1);
    this.run2=new Runner({ begin:function(){ self.part=2; },
      step:function(){ self.syncStep(); return self.run2.t>=self.DUR2; },
      draw:function(){ self.draw(); if(self.run2.t>=self.DUR2){ self.step=5; self.steps(); } }, reset:function(){} });
    this.run2.bind(g2);
    this.b2=g2.querySelector("button.play"); this.b2.disabled=true;
    var rs=sec.querySelector(".rsrow"); if(rs){ sec.querySelector(".parts21").appendChild(rs.querySelector(".resetall")); rs.remove(); }
    sec.querySelector(".resetall").addEventListener("click", function(){ self.run.reset(); self.run2.reset(); resetSlow(sec,self.run); resetSlow(sec,self.run2); self.part=1; self.step=0; self.unlocked=false; self.b2.disabled=true; g2.classList.add("locked"); self.steps(); self.draw(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    this.steps(); this.draw();
  },
  unlock:function(){ if(this.unlocked) return; this.unlocked=true; this.b2.disabled=false; this.sec.querySelector('.pt21[data-p="2"]').classList.remove("locked"); },
  syncStep:function(){ var st=(this.part===1)? (this.run.t>=this.TA? 1 : 0) : (this.run2.t<4? 2 : this.run2.t<8? 3 : 4);
    if(st!==this.step){ this.step=st; this.steps(); } },
  steps:function(){ var h="", self=this;
    if(this.step===0) h='<p class="st21none">スタートを押すと、アニメに合わせてここに式が出てくる。</p>';
    this.STEPS.slice(0,this.step).forEach(function(s,i){ h+='<div class="st21'+(i===self.step-1? ' now' : '')+'"><span class="sn">'+(i+1)+'</span><p>'+TX(s[0])+'</p><div class="qeq">'+TX("$$"+s[1].slice(1,-1)+"$$")+'</div>'+(s[2]? '<p>'+TX(s[2])+'</p>' : '')+'</div>'; });
    this.sec.querySelector(".steps21").innerHTML=h; },
  /* 斜め上から見る投影（x：右、y：奥、z：上）。s …1 の長さの画面上の大きさ */
  proj:function(cx,cy,s,yaw,pitch){ return function(x,y,z){ var X=x-0.5, Y=y-0.5, Z=z-0.5;
      var x1=X*Math.cos(yaw)+Y*Math.sin(yaw), y1=-X*Math.sin(yaw)+Y*Math.cos(yaw);
      return [cx+x1*s, cy-(Z*Math.cos(pitch)+y1*Math.sin(pitch))*s]; }; },
  cube:function(c, P, faceS){
    var V8=[[0,0,0],[1,0,0],[1,1,0],[0,1,0],[0,0,1],[1,0,1],[1,1,1],[0,1,1]].map(function(q){ return P(q[0],q[1],q[2]); });
    if(faceS){ c.save(); c.fillStyle="rgba(150,160,175,.32)"; c.beginPath(); [1,2,6,5].forEach(function(i,k){ var q=V8[i]; if(k) c.lineTo(q[0],q[1]); else c.moveTo(q[0],q[1]); }); c.closePath(); c.fill(); c.restore(); }
    c.save(); c.fillStyle="rgba(190,225,250,.25)"; c.beginPath(); [0,1,5,4].forEach(function(i,k){ var q=V8[i]; if(k) c.lineTo(q[0],q[1]); else c.moveTo(q[0],q[1]); }); c.closePath(); c.fill(); c.restore();
    c.save(); c.strokeStyle="#5b636e"; c.lineWidth=1.4; [[0,1],[1,2],[2,3],[3,0],[4,5],[5,6],[6,7],[7,4],[0,4],[1,5],[2,6],[3,7]].forEach(function(e){ var a=V8[e[0]], b=V8[e[1]]; c.beginPath(); c.moveTo(a[0],a[1]); c.lineTo(b[0],b[1]); c.stroke(); }); c.restore();
    var O=P(0,0,0), ax=P(1.22,0,0), az=P(0,0,1.2), ay=P(0,1.25,0);
    T(c,"O",O[0]-6,O[1]+10,{size:12,it:true,col:COL.sub,align:"right"});
    arrow(c,O[0],O[1],ax[0],ax[1],"#3a414c",1.3,8); SYM(c,"x",null,ax[0]+5,ax[1]+2,{size:14,col:"#3a414c"});
    arrow(c,O[0],O[1],az[0],az[1],"#3a414c",1.3,8); SYM(c,"z",null,az[0]+5,az[1],{size:14,col:"#3a414c"});
    arrow(c,O[0],O[1],ay[0],ay[1],"#3a414c",1.3,8); SYM(c,"y",null,ay[0]+5,ay[1],{size:14,col:"#3a414c"});
    var sS=P(1,0.5,0.85); T(c,"S",sS[0]+10,sS[1],{size:15,bold:true,serif:true,col:"#3a414c",halo:true});
    var lb=P(0.5,0,0); T(c,"L",lb[0],lb[1]+14,{size:13,it:true,col:COL.sub,align:"center"});
  },
  pos:function(t){ return [tri(this.x0+this.vx*t), tri(this.y0+this.vy*t), tri(this.z0+this.vz*t)]; },
  hits:function(t){ var a=[]; for(var k=0;k<60;k++){ var th=(2*k+1-this.x0)/this.vx; if(th>t) break; a.push(th); } return a; },
  /* ② 左：気体分子の速度の変化（壁 S の近く、斜め上から） */
  velPanel:function(c, x0, y0, w, h, t){
    T(c, "気体分子の速度の変化", x0+12, y0+16, {size:13.5, bold:true, col:"#1f6fb2"});
    var s=Math.min(w*0.62, h*0.72), P=this.proj(x0+w*0.46, y0+h*0.56, s, -0.62, 0.40);
    /* 壁 S（x＝1 の面） */
    var a=P(1,0,0), b=P(1,1,0), cc=P(1,1,1), d=P(1,0,1);
    c.save(); c.fillStyle="rgba(150,160,175,.38)"; c.strokeStyle="#7a828c"; c.beginPath(); c.moveTo(a[0],a[1]); c.lineTo(b[0],b[1]); c.lineTo(cc[0],cc[1]); c.lineTo(d[0],d[1]); c.closePath(); c.fill(); c.stroke(); c.restore();
    T(c,"S",d[0]+8,d[1]+16,{size:15,bold:true,serif:true,col:"#3a414c"});
    var tc=this.TC1, v=[0.13,0.06,0.07], hit=[1,0.45,0.42], after=(t>=tc), dt=t-tc;
    var vv=after? [-v[0],v[1],v[2]] : v, pp=after? [hit[0]-v[0]*dt, hit[1]+v[1]*dt, hit[2]+v[2]*dt] : [hit[0]+v[0]*dt, hit[1]+v[1]*dt, hit[2]+v[2]*dt];
    /* 通り道 */
    c.save(); c.setLineDash([4,4]); c.strokeStyle="rgba(90,99,110,.6)"; c.lineWidth=1.2; c.beginPath(); var p0=P(hit[0]-v[0]*4,hit[1]-v[1]*4,hit[2]-v[2]*4), ph=P(hit[0],hit[1],hit[2]);
    c.moveTo(p0[0],p0[1]); c.lineTo(ph[0],ph[1]); if(after){ var pa=P(pp[0],pp[1],pp[2]); c.lineTo(pa[0],pa[1]); } c.stroke(); c.restore();
    var M=P(pp[0],pp[1],pp[2]);
    ball(c, M[0], M[1], 9, 0, "#f0b429");
    /* 速度と成分（分子の少し上から。成分の箱は点線） */
    var k=3.6, o=[pp[0],pp[1],pp[2]+0.10], Q=function(dx,dy,dz){ return P(o[0]+dx*k,o[1]+dy*k,o[2]+dz*k); };
    var O0=Q(0,0,0), X=Q(vv[0],0,0), Yp=Q(0,vv[1],0), Zp=Q(0,0,vv[2]), XY=Q(vv[0],vv[1],0), VV=Q(vv[0],vv[1],vv[2]);
    c.save(); c.strokeStyle="rgba(31,111,178,.45)"; c.setLineDash([3,3]); c.lineWidth=1; c.fillStyle="rgba(255,236,150,.35)";
    c.beginPath(); c.moveTo(O0[0],O0[1]); c.lineTo(X[0],X[1]); c.lineTo(XY[0],XY[1]); c.lineTo(Yp[0],Yp[1]); c.closePath(); c.fill(); c.stroke();
    c.beginPath(); c.moveTo(XY[0],XY[1]); c.lineTo(VV[0],VV[1]); c.stroke(); c.restore();
    arrow(c, O0[0],O0[1], X[0],X[1], "#c0392b", 2.2, 8); SYM(c, (after? "−v" : "v"), "x", X[0]+(after? -6 : 4), X[1]+14, {size:12.5, bold:true, col:"#c0392b", halo:true, align:after? "right" : "left"});
    arrow(c, O0[0],O0[1], Yp[0],Yp[1], "#3a7bd5", 2, 8); SYM(c, "v", "y", Yp[0]+4, Yp[1]-4, {size:12.5, bold:true, col:"#3a7bd5", halo:true});
    arrow(c, O0[0],O0[1], Zp[0],Zp[1], "#3a7bd5", 2, 8); SYM(c, "v", "z", Zp[0]-4, Zp[1]-4, {size:12.5, bold:true, col:"#3a7bd5", halo:true, align:"right"});
    arrow(c, O0[0],O0[1], VV[0],VV[1], COLG.vel, 2.8, 10); SYM(c, "v", null, VV[0]+6, VV[1]-4, {size:14, bold:true, col:COLG.vel, halo:true});
    c.save(); c.strokeStyle=COLG.vel; c.lineWidth=1.2; c.beginPath(); c.moveTo(VV[0]+6,VV[1]-15); c.lineTo(VV[0]+13,VV[1]-15); c.stroke(); c.restore();
    if(after) bubbleNote(c, x0+w*0.04, y0+h-58, "壁 S に垂直な成分（x 成分）だけ\n向きが変わる。速さは変わらない", "#9c4e06");
    else T(c, "分子と壁の衝突は弾性衝突（衝突の前後で速さは変わらない）", x0+12, y0+h-14, {size:10.5, col:COL.sub});
  },
  /* ② 右：x 方向の運動量の変化と力積 */
  momPanel:function(c, x0, y0, w, h, t){
    T(c, "x 方向の運動量の変化と力積", x0+14, y0+16, {size:13.5, bold:true, col:"#1f6fb2"});
    var ya=y0+48, wx=x0+w*0.62, yl=y0+h*0.56, u=w*0.10, tc=this.TC1, dt=t-tc;
    arrow(c, x0+14, ya, x0+w-14, ya, "#3a414c", 1.3, 9); SYM(c,"x",null,x0+w-14,ya-8,{size:14,col:"#3a414c",align:"right"});
    c.save(); c.fillStyle="#c9ced6"; c.strokeStyle="#5b636e"; c.fillRect(wx, ya+16, 9, h-90); c.strokeRect(wx, ya+16, 9, h-90); c.restore();
    T(c,"S",wx+4.5,ya+8,{size:14,bold:true,serif:true,col:"#3a414c",align:"center"});
    var r=9, xm=(dt<0)? wx-r+dt*u : wx-r-dt*u;
    c.save(); c.setLineDash([4,4]); c.strokeStyle="rgba(90,99,110,.5)"; c.beginPath(); c.moveTo(x0+20, yl); c.lineTo(wx, yl); c.stroke(); c.restore();
    ball(c, xm, yl, r, 0, "#f0b429");
    var L=w*0.16;
    /* 運動量の x 成分（分子の少し上から） */
    if(dt<0 || dt>1.6){ var sg=(dt<0)? 1 : -1, ym=yl-24;
      fArrow(c, xm, ym, xm+sg*L, ym, "#7b3fd4", 3, 10);
      var lab=(dt<0)? "mvₓ" : "−mvₓ"; T(c, (dt<0? "衝突前の運動量の x 成分 " : "衝突後の運動量の x 成分 ")+lab, xm+(sg>0? 0 : -L-4), ym-16, {size:11, bold:true, col:"#7b3fd4", align:(sg>0? "left" : "left"), halo:true}); }
    /* 衝突の瞬間：力積（作用・反作用。接点から逆向き） */
    if(dt>=0 && dt<=3.2){ var a=(dt<2.6)? 1 : 1-(dt-2.6)/0.6, cxp=wx, I=2*L;
      c.save(); c.globalAlpha=a;
      fArrow(c, cxp, yl, cxp+I, yl, COLG.imp, 3.4, 11); fArrow(c, cxp, yl, cxp-I, yl, "#1c8f4a", 3.4, 11);
      T(c, "壁 S が分子から受ける力積", cxp+I*0.55, yl-34, {size:10.5, bold:true, col:COLG.imp, align:"center", halo:true}); T(c, "2mvₓ", cxp+I*0.55, yl-18, {size:12, bold:true, col:COLG.imp, align:"center", halo:true});
      T(c, "分子が壁 S から受ける力積", cxp-I*0.55, yl+22, {size:10.5, bold:true, col:"#1c8f4a", align:"center", halo:true}); T(c, "−2mvₓ", cxp-I*0.55, yl+38, {size:12, bold:true, col:"#1c8f4a", align:"center", halo:true});
      c.restore(); }
    if(dt>=0) T(c, "1 回の衝突で、壁 S は分子から大きさ 2mvₓ の力積を受ける", x0+14, y0+h-14, {size:11, bold:true, col:"#c0157a"});
    if(dt>1.6) T(c, "（分子の運動量の変化：−mvₓ − mvₓ ＝ −2mvₓ）", x0+14, y0+h-32, {size:10.5, col:COL.sub});
  },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return W<640? clamp(W*1.55, 560, 700) : clamp(W*0.66, 430, 540); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var narrow=W<640, t=(this.part===1)? this.run.t : this.TB+this.run2.t;
    if(t<this.TA){
      /* ① たくさんの分子 */
      var s=Math.min(W*0.42, H*0.55), P=this.proj(W*0.46, H*0.52, s, -0.62, 0.40);
      this.cube(c, P, true);
      var self2=this; this.many.forEach(function(m,i){ var q=[tri(m.p[0]+m.v[0]*t), tri(m.p[1]+m.v[1]*t), tri(m.p[2]+m.v[2]*t)], M=P(q[0],q[1],q[2]); ball(c, M[0], M[1], 7, 0, "#f0b429"); });
      if(narrow) bubbleNote(c, 10, 8, "気体分子は熱運動によって\n壁に衝突し、壁に圧力を及ぼす", "#9c4e06");
      else bubbleNote(c, W*0.46+s*0.62, H*0.30, "気体分子は熱運動によって\n壁に衝突し、壁に圧力を及ぼす", "#9c4e06");
    } else if(t<this.TB){
      var tt=t-this.TA+ (this.TC1-4);   /* ② の中の時刻（衝突は ② が始まって 4 s 後） */
      if(narrow){ this.velPanel(c, 0, 0, W, H*0.5, t-this.TA+3); this.momPanel(c, 0, H*0.5, W, H*0.5, t-this.TA+3);
        c.save(); c.strokeStyle="#1f6fb2"; c.beginPath(); c.moveTo(12,H*0.5); c.lineTo(W-12,H*0.5); c.stroke(); c.restore(); }
      else { this.velPanel(c, 0, 0, W*0.5, H, t-this.TA+3); this.momPanel(c, W*0.5, 0, W*0.5, H, t-this.TA+3);
        c.save(); c.strokeStyle="#1f6fb2"; c.lineWidth=1.5; c.beginPath(); c.moveTo(W*0.5,14); c.lineTo(W*0.5,H-14); c.stroke(); c.restore(); }
    } else {
      /* ③ 横から見た図（x：右、y：上）と x 方向だけの動き、力の時間変化 */
      var t3=t-this.TB, bw=narrow? W*0.62 : W*0.36, bx=narrow? (W-bw)/2 : 40, by=36, bh=bw, done2=(this.run2.t>=this.DUR2);
      if(narrow && bh>H*0.34){ bh=H*0.34; bw=bh; bx=(W-bw)/2; }
      var X=function(v){ return bx+v*bw; }, Y=function(v){ return by+bh-v*bh; };
      c.save(); c.fillStyle="rgba(190,225,250,.22)"; c.fillRect(bx,by,bw,bh); c.strokeStyle="#5b636e"; c.lineWidth=1.6; c.strokeRect(bx,by,bw,bh); c.fillStyle="#c9ced6"; c.fillRect(bx+bw,by,8,bh); c.restore();
      T(c,"S",bx+bw+14,by+12,{size:15,bold:true,serif:true,col:"#3a414c"}); arrow(c,bx,by+bh,bx+bw+40,by+bh,"#3a414c",1.2,8); SYM(c,"x",null,bx+bw+42,by+bh-8,{size:14});
      arrow(c,bx,by+bh,bx,by-20,"#3a414c",1.2,8); SYM(c,"y",null,bx-14,by-14,{size:14}); T(c,"O",bx-6,by+bh+10,{size:12,it:true,col:COL.sub,align:"right"});
      T(c,"L",bx+bw/2,by+bh+14,{size:13,it:true,col:COL.sub,align:"center"});
      T(c, "衝突の前後で、速度の大きさは変わらない", bx+16, by-16, {size:11.5, bold:true, col:"#9c4e06"});
      /* 通り道（壁に当たるごとに色を変える） */
      var COLS=["#e2462f","#2f5fd6","#5fc3e8","#7a828c","#3aa564"], seg=0, prev=null, ux=this.x0, uy=this.y0;
      c.save(); c.lineWidth=2.4; c.lineJoin="round";
      for(var k=0;k<=Math.round(t3*40);k++){ var tk=k/40, q=[tri(ux+this.vx*tk), tri(uy+this.vy*tk)];
        if(prev){ var sx=Math.sign(q[0]-prev[0]), sy2=Math.sign(q[1]-prev[1]); if(prev.sx!==undefined && (sx!==prev.sx || sy2!==prev.sy)) seg++; c.strokeStyle=COLS[seg%5]; c.beginPath(); c.moveTo(X(prev[0]),Y(prev[1])); c.lineTo(X(q[0]),Y(q[1])); c.stroke(); q.sx=sx; q.sy=sy2; }
        prev=q; }
      c.restore();
      var qn=[tri(ux+this.vx*t3), tri(uy+this.vy*t3)], Mx=X(qn[0]), My=Y(qn[1]);
      ball(c, Mx, My, 8, 0, "#f0b429");
      var sgx=(((ux+this.vx*t3)%2)<1)? 1 : -1;
      /* x 方向だけの動き */
      var sy0=by+bh+66;
      c.save(); c.strokeStyle="#3a414c"; c.lineWidth=1.3; c.beginPath(); c.moveTo(X(0),sy0); c.lineTo(X(1),sy0); c.stroke(); c.fillStyle="#c9ced6"; c.fillRect(X(1),sy0-14,6,28); c.fillRect(X(0)-6,sy0-14,6,28); c.restore();
      T(c, "x 方向だけを見た動き", X(0), sy0-38, {size:11.5, bold:true});
      ball(c, X(qn[0]), sy0, 7, 0, "#f0b429");
      arrow(c, X(qn[0]), sy0-16, X(qn[0])+sgx*40, sy0-16, COLG.vel, 2.4, 9); SYM(c,"v","x",X(qn[0])+sgx*40+(sgx>0? 5 : -5), sy0-20, {size:13, bold:true, col:COLG.vel, halo:true, align:sgx>0? "left" : "right"});
      T(c, "一定の速さ vₓ で往復し、2L/vₓ ごとに壁 S に衝突する", X(0), sy0+26, {size:11.5, bold:true, col:"#c0157a"});
      /* 力の時間変化 */
      /* 縦の長さは左の箱と同じ。横軸は残りの幅の 90%（箱との間をあける） */
      var gx0=narrow? 50 : bx+bw+110, gx1=narrow? 50+(W-64)*0.90 : gx0+(W-14-gx0)*0.90, gy1=narrow? sy0+70 : by, gy0=narrow? Math.min(H-36, gy1+bh) : by+bh;
      graphTitle(c, "壁 S が分子から受ける力 f の時間変化", gx0-30, gy1-14);
      var P2=plotFrame(c, gx0, gy0, gx1, gy1+16, [0,this.DUR2], [0,1.25], {noYt:true, noXt:true, xl:"t（時間）", yl:"f（力）"});
      var per=2/this.vx, wpk=0.6, hp=1.1, fb=hp*wpk/2/per, hs=this.hits(t3);
      /* 平均の力（式⑤）は、最後まで見たあとで出す */
      if(done2){ c.save(); c.setLineDash([5,4]); c.strokeStyle="#1c8f4a"; c.lineWidth=1.6; c.beginPath(); c.moveTo(P2.X(0),P2.Y(fb)); c.lineTo(P2.X(this.DUR2),P2.Y(fb)); c.stroke(); c.restore();
        SYM(c,"f",null,P2.X(this.DUR2)-30,P2.Y(fb)-10,{size:13,bold:true,col:"#1c8f4a"}); c.save(); c.strokeStyle="#1c8f4a"; c.beginPath(); c.moveTo(P2.X(this.DUR2)-31,P2.Y(fb)-19); c.lineTo(P2.X(this.DUR2)-24,P2.Y(fb)-19); c.stroke(); c.restore();
        T(c, "平均の力", P2.X(this.DUR2)-36, P2.Y(fb)-10, {size:11, bold:true, col:"#1c8f4a", align:"right", halo:true}); }
      if(hs.length && done2){ var r0=hs[0]; c.save(); c.fillStyle="rgba(28,143,74,.16)"; c.strokeStyle="rgba(28,143,74,.7)"; c.setLineDash([4,3]); c.fillRect(P2.X(r0),P2.Y(fb),P2.X(r0+per)-P2.X(r0),P2.Y(0)-P2.Y(fb)); c.strokeRect(P2.X(r0),P2.Y(fb),P2.X(r0+per)-P2.X(r0),P2.Y(0)-P2.Y(fb)); c.restore(); }
      hs.forEach(function(h0){ c.save(); c.fillStyle="rgba(192,21,138,.55)"; c.strokeStyle=COLG.imp; c.beginPath(); c.moveTo(P2.X(Math.max(0,h0-wpk/2)),P2.Y(0)); c.lineTo(P2.X(h0),P2.Y(hp)); c.lineTo(P2.X(h0+wpk/2),P2.Y(0)); c.closePath(); c.fill(); c.stroke(); c.restore(); });
      if(hs.length>=2){ var a1=P2.X(hs[0]), a2=P2.X(hs[1]), yy=P2.Y(hp)-10; dimArrow(c,a1,yy,a2,yy,"#3a414c"); T(c,"2L/vₓ",(a1+a2)/2,yy-11,{size:11.5,bold:true,col:"#3a414c",align:"center",halo:true}); }
      if(done2) T(c, "山の面積（力積 2mvₓ）＝ 緑の長方形の面積", P2.x1, P2.y1-6, {size:10.5, bold:true, col:COLG.imp, halo:true, align:"right"});
    }
    notebook(c,W,H);
    var mh= (this.part===1 && this.run.state==="idle")? '<b>式①</b>のスタートを押そう。式①を最後まで見ると、<b>式②〜⑤</b>のスタートが押せるようになる。' : t<this.TA? '一辺 '+tex("L")+' の立方体の容器の中を、たくさんの分子が飛び回っている。その中の 1 個に注目する。' :
      t<this.TB? '分子が壁 S に弾性衝突すると、速度の '+tex("x")+' 成分だけが '+tex("v_x\\to-v_x")+' と変わる。運動量の '+tex("x")+' 成分は '+tex("mv_x\\to-mv_x")+'。' :
      '壁 S に当たった回数：<span class="num">'+this.hits(t-this.TB).length+'</span> 回。'+tex("x")+' 方向の速さは、いつも '+tex("v_x")+' のまま。'+(this.run2.t>=this.DUR2? '<br>ぎざぎざの力を時間で平均すると、一定の力 '+tex("\\overline{f}=\\dfrac{m{v_x}^2}{L}")+'（緑の点線）。' : '');
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};
/* 角丸の吹き出し（しっぽなし）。文字は \n で改行 */
function bubbleNote(c, x, y, text, col){
  var L=String(text).split("\n"); c.save(); c.font='700 12px '+FONT; var w=0; L.forEach(function(l){ w=Math.max(w,c.measureText(l).width); }); c.restore();
  var W=w+20, H=L.length*17+12; c.save(); c.fillStyle="rgba(250,228,200,.95)"; c.shadowColor="rgba(20,23,28,.16)"; c.shadowBlur=10; c.shadowOffsetY=3; rrect(c,x,y,W,H,10); c.fill(); c.restore();
  L.forEach(function(l,i){ T(c, l, x+10, y+6+17*i+8, {size:12, bold:true, col:col||"#9c4e06"}); });
}

/* ---------------- ②-2 N 個の分子と圧力 ----------------
   横から見た箱（x：右、z：上）。壁 S は右。分子どうしは当たらない（位置は三角波で決まる）。
   壁 S が受ける力：0.05 s ごとの力積の合計（ぎざぎざ）と、時間平均（だんだん一定に近づく） */
var S22 = {
  DUR:12, BIN:0.2,
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.N=20; this.T=300; this.make();
    this.run=new Runner({ step:function(dt){ self.tb.sync(); return self.run.t>=self.DUR; }, draw:function(){ self.draw(); }, reset:function(){} });
    this.run.bind(sec);
    this.tb=wireTimeBar(sec, this.run, function(){ return self.DUR; }, function(){});
    this.sN=wireSeg(sec,"N",function(v){ self.N=parseInt(v,10); self.run.reset(); self.tb.sync(); });
    this.sT=wireSlider(sec,"T",function(v){ return v.toFixed(0)+" K"; },function(v){ self.T=v; self.run.reset(); self.tb.sync(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.N=20; self.T=300; self.sN.set("20"); self.sT.set(300); self.make(); resetSlow(sec,self.run); self.run.reset(); self.tb.sync(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    this.draw();
  },
  make:function(){ var R=rng(22), a=[]; for(var i=0;i<100;i++){ a.push({x0:R(), z0:R(), vx:gauss(R), vy:gauss(R), vz:gauss(R)}); }
    var s=0; a.forEach(function(q){ s+=q.vx*q.vx+q.vy*q.vy+q.vz*q.vz; }); var k=Math.sqrt(3*a.length/s); a.forEach(function(q){ q.vx*=k; q.vy*=k; q.vz*=k; });
    this.all=a; },
  mols:function(){ return this.all.slice(0,this.N); },
  sp:function(){ return 0.16*Math.sqrt(this.T/300); },          /* 箱の幅 1 あたりの速さ（1 方向の 2 乗平均の平方根） */
  /* 壁 S に当たる時刻の一覧（展開した座標で） */
  hitTimes:function(q, t){ var v=Math.abs(q.vx)*this.sp(); if(v<1e-6) return []; var u0=(q.vx>=0)? q.x0 : 2-q.x0, a=[];
    for(var k=0;k<400;k++){ var th=(2*k+1-u0)/v; if(th>t) break; if(th>=0) a.push(th); } return a; },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return W<640? clamp(W*1.2, 460, 560) : clamp(W*0.50, 340, 420); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var t=this.run.t, narrow=W<640, M=this.mols(), sp=this.sp();
    var bw=narrow? W-120 : W*0.34, bh=narrow? H*0.34 : H*0.56, bx=narrow? 40 : 34, by=24;
    /* 箱（横から見た図） */
    c.save(); c.fillStyle="rgba(190,225,250,.22)"; c.fillRect(bx,by,bw,bh); c.strokeStyle="#5b636e"; c.lineWidth=1.6; c.strokeRect(bx,by,bw,bh);
    c.fillStyle="#c9ced6"; c.fillRect(bx+bw, by, 8, bh); c.restore(); T(c,"S",bx+bw+14,by+bh/2,{size:15,bold:true,serif:true,col:"#3a414c"});
    var flash=0;
    M.forEach(function(q){ var x=tri(((q.vx>=0)? q.x0 : 2-q.x0)+Math.abs(q.vx)*sp*t), z=tri(q.z0+q.vz*sp*t);
      ball(c, bx+5+(bw-10)*x, by+bh-5-(bh-10)*z, M.length>50? 3.6 : 4.5, 0, "#f0b429"); });
    var thX=bx+bw+34; thermometer(c, thX, by+bh, by+bh*0.30, this.T-273, -100, 500, {noVal:true, noNum:true, ticks:0}); T(c, Math.round(this.T)+" K", thX, by+bh*0.30-12, {size:11.5, bold:true, col:"#a03028", align:"center", halo:true});
    /* 力のグラフ：ビンごとの力積 */
    /* 横軸は残りの幅の 90%、箱との間をあける。上に題 */
    var gx0=narrow? 46 : bx+bw+96, gy0=narrow? H-34 : H*0.56+by-8, gx1=narrow? 46+(W-60)*0.9 : gx0+(W-14-gx0)*0.90, gy1=narrow? by+bh+70 : 48;
    graphTitle(c, "壁 S が受ける力 F の時間変化", gx0-30, gy1-24);
    var nb=Math.round(this.DUR/this.BIN), bins=new Array(nb).fill(0), tot=0, self2=this;
    M.forEach(function(q){ self2.hitTimes(q, t).forEach(function(th){ var b=Math.min(nb-1, Math.floor(th/self2.BIN)); bins[b]+=2*Math.abs(q.vx)*sp; tot+=2*Math.abs(q.vx)*sp; }); });
    var Fth=0; M.forEach(function(q){ Fth+=q.vx*q.vx*sp*sp; });           /* Σ m vₓ²/L（m＝1、L＝1） */
    var Fref=30*0.0256*Math.max(1,this.T/300)*1.0, ymax=Math.max(Fth*3.2, 0.0256*3*10*this.T/300);
    var P=plotFrame(c, gx0, gy0, gx1, gy1, [0,this.DUR], [0,ymax], {noYt:true, xl:"t〔s〕", yl:"F（力）", xstep:2});
    c.save(); c.beginPath(); c.rect(P.x0,P.y1-14,P.x1-P.x0+14,P.y0-P.y1+14); c.clip();
    c.fillStyle="rgba(192,21,138,.5)"; var nn=Math.floor(t/this.BIN);
    for(var i=0;i<nn && i<nb;i++){ var F=bins[i]/this.BIN; if(F>0) c.fillRect(P.X(i*this.BIN), P.Y(Math.min(F,ymax*1.2)), Math.max(1,P.X(this.BIN)-P.X(0)-0.5), P.Y(0)-P.Y(Math.min(F,ymax*1.2))); }
    /* 時間平均 */
    c.strokeStyle="#c0392b"; c.lineWidth=2.4; c.beginPath(); var cum=0, st=false;
    for(var j=0;j<nn && j<nb;j++){ cum+=bins[j]; var tt=(j+1)*this.BIN; if(tt<0.4) continue; var av=cum/tt; if(!st){ c.moveTo(P.X(tt),P.Y(av)); st=true; } else c.lineTo(P.X(tt),P.Y(av)); }
    c.stroke();
    c.setLineDash([6,4]); c.strokeStyle="#1c8f4a"; c.lineWidth=1.6; c.beginPath(); c.moveTo(P.X(0),P.Y(Fth)); c.lineTo(P.X(this.DUR),P.Y(Fth)); c.stroke(); c.restore();
    T(c,"時間で平均した力", P.X(this.DUR)-4, P.Y(Fth)-26, {size:11, bold:true, col:"#c0392b", align:"right", halo:true});
    (function(){ var x=P.X(this.DUR)-150, y=P.Y(Fth)+16, gc="#1c8f4a"; x+=SYM(c,"Nm",null,x,y,{size:13,bold:true,col:gc,halo:true}); x+=vbar2(c,"x",x+1,y,{size:13,col:gc})+2;
      x+=SYM(c,"/L",null,x,y,{size:13,bold:true,col:gc,halo:true}); T(c,"（点線）",x+2,y,{size:11,bold:true,col:gc,halo:true}); }).call(this);
    /* v̄ₓ²・v̄ᵧ²・v̄z² の棒（箱の下） */
    var sx=0, sy=0, sz=0; M.forEach(function(q){ sx+=q.vx*q.vx; sy+=q.vy*q.vy; sz+=q.vz*q.vz; }); var n=Math.max(1,M.length); sx/=n; sy/=n; sz/=n;
    var b0=by+bh+(narrow? 16 : 30), bb=narrow? 0 : 0, bwid=narrow? (bw)/3.2 : bw/3.4, bmax=narrow? 0 : 0;
    if(!narrow){ var base=H-30, top=b0+20, sc=(base-top)/2.4;
      graphTitle(c, "速度成分の 2 乗の平均（N 個の分子）", bx, b0+4);
      [[sx,"x","#c0392b"],[sy,"y","#1f6fb2"],[sz,"z","#1c8f4a"]].forEach(function(o,i){ var x=bx+14+i*bwid*1.1, h=Math.min(o[0],2.4)*sc;
        c.save(); c.fillStyle=o[2]; c.globalAlpha=0.8; c.fillRect(x, base-h, bwid*0.7, h); c.restore();
        vbar2(c, o[1], x+bwid*0.35, base+16, {size:13, col:o[2], align:"center"}); });
      c.save(); c.setLineDash([4,3]); c.strokeStyle="#69717d"; c.beginPath(); c.moveTo(bx+6, base-sc); c.lineTo(bx+14+3*bwid*1.1, base-sc); c.stroke(); c.restore();
      var xw=bx+18+3*bwid*1.1; xw+=vbar2(c, null, xw, base-sc+2, {size:12.5, col:"#3a414c"}); T(c, " の 1/3", xw, base-sc, {size:11, bold:true, col:"#3a414c"}); }
    notebook(c,W,H);
    var av2=tot/Math.max(t,0.4), mh='分子の数 '+tex("N")+' = <span class="num">'+M.length+'</span>　時間で平均した力は、点線の値に近づいていく'+(t>3? '（いま <span class="num">'+(av2/Fth*100).toFixed(0)+'</span> %）' : '')+'。<br>'+
      '分子の数が多いほど、ぎざぎざは細かくなり、力はほぼ一定とみなせる。速度成分の 2 乗の平均：'+tex(VX2B)+' : '+tex("\\overline{{v_y}^2}")+' : '+tex("\\overline{{v_z}^2}")+' = '+sx.toFixed(2)+' : '+sy.toFixed(2)+' : '+sz.toFixed(2);
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};

/* ---------------- ②-3 温度と分子の運動エネルギー ----------------
   左：ヘリウム、右：選んだ気体。分子の速さは √(RT/M)（1 方向）に比例させて描く。下に速さの分布（参考） */
var GASES = { He:{name:"ヘリウム He", M:4.0e-3, r:3.6, col:"#f0b429"}, N2:{name:"窒素 N₂", M:28e-3, r:5.6, col:"#4f8fd6"}, O2:{name:"酸素 O₂", M:32e-3, r:5.9, col:"#d9534f"}, CO2:{name:"二酸化炭素 CO₂", M:44e-3, r:6.6, col:"#6b7f3a"} };
var S23 = {
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.g="N2"; this.T=300; this.A=new Gas(18, 31); this.B=new Gas(18, 32);
    this.sg=wireSeg(sec,"gas",function(v){ self.g=v; self.draw(); });
    this.sT=wireSlider(sec,"T",function(v){ return v.toFixed(0)+" K"; },function(v){ self.T=v; self.draw(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.g="N2"; self.sg.set("N2"); self.T=300; self.sT.set(300); self.draw(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    idleLoop(sec, function(dt){ var b=self.bx; if(b){ self.A.step(dt, b.w, b.h, self.vpx("He"), GASES.He.r); self.B.step(dt, b.w, b.h, self.vpx(self.g), GASES[self.g].r); } self.draw(); });
    this.draw();
  },
  vrms:function(k){ return Math.sqrt(3*RGAS*this.T/GASES[k].M); },
  vpx:function(k){ return this.vrms(k)/Math.sqrt(3)*0.055; },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return W<600? clamp(W*1.3, 470, 560) : clamp(W*0.58, 390, 470); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var narrow=W<600, gap=16, bw=(W-3*gap)/2, bh=narrow? H*0.36 : H*0.42, by=28;
    this.bx={w:bw, h:bh};
    var KE=1.5*KB*this.T;
    thermometer(c, gap+bw+gap/2, by+bh, by+22, this.T-273, -100, 500, {tw:7, br:6, noVal:true, noNum:true, ticks:0});
    T(c, Math.round(this.T)+" K", gap+bw+gap/2, by+bh+16, {size:11, bold:true, col:"#a03028", align:"center", halo:true});
    [["He",this.A],[this.g,this.B]].forEach(function(o,i){ var g=GASES[o[0]], x0=gap+i*(bw+gap);
      c.save(); c.fillStyle="rgba(190,225,250,.20)"; c.fillRect(x0,by,bw,bh); c.strokeStyle="#5b636e"; c.lineWidth=1.4; c.strokeRect(x0,by,bw,bh); c.restore();
      o[1].m.forEach(function(q){ ball(c, x0+g.r+(bw-2*g.r)*q.x, by+g.r+(bh-2*g.r)*q.y, g.r, 0, g.col); });
      T(c, g.name+"（分子量 "+Math.round(g.M*1000)+"）", x0+bw/2, by-12, {size:12.5, bold:true, align:"center"});
      var y1=by+bh+18;
      var c1="#7b3fd4", c2=(g.col==="#f0b429")? "#9c6b00" : g.col, fs=narrow? 12 : 13;
      /* ½ m v² の平均 ＝ … */
      var xa=x0+bw/2-(narrow? 78 : 96), ya=y1+2; T(c, "½", xa, ya, {size:fs+1, bold:true, col:c1}); xa+=10; xa+=SYM(c,"m",null,xa,ya,{size:fs+1,bold:true,col:c1}); xa+=vbar2(c,null,xa+1,ya,{size:fs+1,col:c1})+4;
      T(c, "= "+(KE*1e21).toFixed(2)+"×10⁻²¹ J", xa, ya, {size:fs, bold:true, col:c1});
      /* √(v² の平均) ＝ … */
      var xb=x0+bw/2-(narrow? 60 : 70), yb=y1+26; T(c, "√", xb, yb, {size:fs+3, bold:true, col:c2}); var wv=vbar2(c,null,xb+12,yb,{size:fs+1,col:c2});
      c.save(); c.strokeStyle=c2; c.lineWidth=1.2; c.beginPath(); c.moveTo(xb+10, yb-(fs+1)*1.05); c.lineTo(xb+14+wv, yb-(fs+1)*1.05); c.stroke(); c.restore();
      T(c, "= "+Math.round(self.vrms(o[0]))+" m/s", xb+18+wv, yb, {size:fs, bold:true, col:c2});
    });
    /* 速さの分布（参考） */
    var gx0=52, gy0=H-34, gx1=W-14, gy1=by+bh+92;
    graphTitle(c, "速さの分布（参考）", 20, gy1-34);
    var P=plotFrame(c, gx0, gy0, gx1, gy1, [0,4000], [0,1], {noYt:true, xl:"v〔m/s〕", yl:"分子の数の割合", xstep:1000});
    var fv=function(k,v){ var a=GASES[k].M/(2*RGAS*self.T); return v*v*Math.exp(-a*v*v)*Math.pow(a,1.5); };
    var mx=0; ["He",this.g].forEach(function(k){ for(var v=0; v<=4000; v+=20) mx=Math.max(mx, fv(k,v)); });
    [["He","#c7930a"],[this.g,GASES[this.g].col]].forEach(function(o){
      c.save(); c.strokeStyle=o[1]; c.lineWidth=2.4; c.beginPath(); for(var v=0; v<=3990; v+=20){ var y=fv(o[0],v)/mx*0.92; if(v) c.lineTo(P.X(v),P.Y(y)); else c.moveTo(P.X(v),P.Y(y)); } c.stroke();
      var vr=self.vrms(o[0]); if(vr<3990){ c.setLineDash([4,3]); c.lineWidth=1.2; c.beginPath(); c.moveTo(P.X(vr),P.Y(0)); c.lineTo(P.X(vr),P.Y(fv(o[0],vr)/mx*0.92)); c.stroke(); } c.restore(); });
    T(c, "点線の位置が 2 乗平均速度", P.x1, P.y1+4, {size:11, col:COL.sub, align:"right", halo:true});
    notebook(c,W,H);
    var r=this.vrms("He")/this.vrms(this.g), mh='温度 '+tex("T")+' = <span class="num">'+this.T+'</span> K のとき、分子 1 個の平均の運動エネルギー '+tex("\\frac{1}{2}m"+V2B+"=\\frac{3}{2}kT")+' は、どちらの気体も <span class="num">'+(KE*1e21).toFixed(2)+'</span>×10⁻²¹ J。<br>'+
      'ヘリウムの '+tex("\\sqrt{"+V2B+"}")+' は '+GASES[this.g].name+' の <span class="num">'+r.toFixed(2)+'</span> 倍（分子量の比の平方根 '+tex("\\sqrt{"+Math.round(GASES[this.g].M*1000)+"/4}")+'）。';
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};

/* ---------------- ②-4 内部エネルギー ----------------
   分子 1 個ずつの運動エネルギーの棒と、その和 U＝3/2 nRT。体積を変えても U は同じ。
   第3回：目盛りは固定（温度・物質量を変えると棒の長さが変わるのが見える）。③-2 にあった「U と 2 乗平均速度」「速さの分布」をここへ */
var S24 = {
  TMAX:600, init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.T=300; this.n=1.0; this.V=2.5; this.gas=new Gas(20, 41);
    this.sT=wireSlider(sec,"T",function(v){ return v.toFixed(0)+" K"; },function(v){ self.T=v; self.draw(); });
    this.sn=wireSlider(sec,"n",function(v){ return v.toFixed(1)+" mol"; },function(v){ self.n=v; self.gas.setN(Math.round(v*20)); self.draw(); });
    this.sV=wireSlider(sec,"V",function(v){ return v.toFixed(1)+" ×10⁻² m³"; },function(v){ self.V=v; self.draw(); });
    sec.querySelector(".resetall").addEventListener("click", function(){ self.T=300; self.n=1.0; self.V=2.5; self.sT.set(300); self.sn.set(1); self.sV.set(2.5); self.gas.setN(20); self.draw(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    idleLoop(sec, function(dt){ if(self.bx) self.gas.step(dt, self.bx.w, self.bx.h, 55*Math.sqrt(self.T/300), 4.2); self.draw(); });
    this.draw();
  },
  vr:function(T){ return Math.sqrt(3*RGAS*T/4.0e-3); },     /* ヘリウムの 2 乗平均速度 */
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return W<600? clamp(W*2.0, 720, 880) : clamp(W*0.60, 440, 520); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var narrow=W<600;
    var R1=narrow? [0,0,W,H*0.22] : [0,0,W*0.46,H*0.50], R2=narrow? [0,H*0.22,W,H*0.48] : [W*0.46,0,W,H*0.50],
        R3=narrow? [0,H*0.48,W,H*0.72] : [0,H*0.50,W*0.42,H], R4=narrow? [0,H*0.72,W,H] : [W*0.42,H*0.50,W,H];
    /* シリンダー */
    var aw=R1[2]-R1[0], h=Math.min(narrow? 80 : 96, (R1[3]-R1[1])*0.44), Lm=aw-90, L=Lm*this.V/5.0, ox=R1[0]+40, cy=R1[1]+(R1[3]-R1[1])*0.56;
    this.bx={w:L, h:h};
    drawCylinder(c, new CylFrame(ox, cy, "right"), {L:L, Lmax:Lm, h:h, T:this.T, gas:this.gas, r:4.2, pt:12, rod:24, lock:true, thermo:true, thLen:24, p0:false});
    /* 1 個ずつの運動エネルギー（目盛りは固定） */
    var m=this.gas.m, v2=this.gas.v2()||3, e1=1.5*KB*this.T, emax=1.5*KB*this.TMAX*2.4;
    graphTitle(c, "分子 1 個ずつの運動エネルギー", R2[0]+20, R2[1]+18);
    var P=plotFrame(c, R2[0]+56, R2[3]-30, R2[2]-90, R2[1]+44, [0,1], [0,emax*1e21], {noXt:true, xl:"", yl:"½mv²〔×10⁻²¹ J〕", ystep:5});
    var nb=m.length, bw=(P.x1-P.x0-8)/40;
    m.forEach(function(q,i){ var e=(q.vx*q.vx+q.vy*q.vy+q.vz*q.vz)/v2*e1; c.save(); c.fillStyle=heatCol(clamp(e/emax*1.6,0,1)); c.fillRect(P.x0+4+i*bw, P.Y(Math.min(e,emax)*1e21), Math.max(1,bw-1.5), P.Y(0)-P.Y(Math.min(e,emax)*1e21)); c.restore(); });
    c.save(); c.setLineDash([5,4]); c.strokeStyle="#7b3fd4"; c.lineWidth=1.5; c.beginPath(); c.moveTo(P.x0,P.Y(e1*1e21)); c.lineTo(P.x1,P.Y(e1*1e21)); c.stroke(); c.restore();
    T(c, "平均 3/2 kT", P.x1+6, P.Y(e1*1e21), {size:11, bold:true, col:"#7b3fd4"});
    T(c, "分子 1 個ずつ（絵の分子の数だけ）", P.x0+4, P.y0+13, {size:11, col:COL.sub});
    /* U と 2 乗平均速度（ヘリウム）。点線は 300 K・1.0 mol */
    var U=1.5*this.n*RGAS*this.T, U0=1.5*1.0*RGAS*300, Umax=1.5*2.0*RGAS*this.TMAX*1.08, vrN=this.vr(this.T), vr0=this.vr(300), vmax=this.vr(this.TMAX)*1.12;
    graphTitle(c, "内部エネルギーと 2 乗平均速度（ヘリウム）", R3[0]+20, R3[1]+20);
    var bx0=R3[0]+30, bx1=R3[2]-16, by0=R3[1]+60, by1=R3[3]-34;
    c.save(); c.strokeStyle="#3a414c"; c.lineWidth=1.3; c.beginPath(); c.moveTo(bx0,by1); c.lineTo(bx1,by1); c.stroke(); c.restore();
    var bar=function(i, val, ref, mx, col, lab, txt){ var x=bx0+(bx1-bx0)*(0.10+i*0.50), w=(bx1-bx0)*0.30, sc=(by1-by0)/mx, hh=Math.min(val,mx)*sc;
      c.save(); c.fillStyle=col; c.globalAlpha=0.85; c.fillRect(x, by1-hh, w, hh); c.restore();
      c.save(); c.setLineDash([4,3]); c.strokeStyle="#3a414c"; c.lineWidth=1.3; c.beginPath(); c.moveTo(x-6, by1-ref*sc); c.lineTo(x+w+6, by1-ref*sc); c.stroke(); c.restore();
      T(c, txt, x+w/2, by1-hh-10, {size:12, bold:true, col:col, align:"center", halo:true});
      lab(x+w/2, by1+16); };
    bar(0, U, U0, Umax, "#7b3fd4", function(x,y){ SYM(c,"U",null,x,y,{size:15,bold:true,col:"#7b3fd4",align:"center"}); }, Math.round(U)+" J");
    bar(1, vrN, vr0, vmax, "#e0457b", function(x,y){ var w=vbar2(c,null,0,-999,{size:14}); c.save(); c.font="700 15px "+SERIF; c.fillStyle="#e0457b"; c.textBaseline="middle"; c.fillText("√", x-w/2-11, y+1); c.restore();
      vbar2(c, null, x-w/2+1, y, {size:14, col:"#e0457b"}); c.save(); c.strokeStyle="#e0457b"; c.lineWidth=1.2; c.beginPath(); c.moveTo(x-w/2-2, y-15); c.lineTo(x+w/2+2, y-15); c.stroke(); c.restore(); }, Math.round(vrN)+" m/s");
    T(c, "点線＝300 K・1.0 mol", bx1, by0-14, {size:11, col:COL.sub, align:"right"});
    /* 速さの分布（ヘリウム）。目盛りは固定。点線は 300 K */
    graphTitle(c, "速さの分布（ヘリウム）", R4[0]+(narrow? 20 : 30), R4[1]+20);
    var D=plotFrame(c, R4[0]+(narrow? 40 : 52), R4[3]-34, R4[2]-14, R4[1]+42, [0,3500], [0,1], {noYt:true, xl:"v〔m/s〕", yl:"分子の数の割合", xstep:1000});
    var fv=function(Tt,v){ var a=4e-3/(2*RGAS*Tt); return v*v*Math.exp(-a*v*v)*Math.pow(a,1.5); }, mx=0;
    for(var v=0; v<=3500; v+=25) mx=Math.max(mx, fv(100,v));
    [[300,"#9aa1ab",[5,4]],[this.T,"#e0457b",null]].forEach(function(o){ c.save(); c.strokeStyle=o[1]; c.lineWidth=2.2; if(o[2]) c.setLineDash(o[2]); c.beginPath();
      for(var v=0; v<=3490; v+=25){ var y=fv(o[0],v)/mx*0.95; if(v) c.lineTo(D.X(v),D.Y(y)); else c.moveTo(D.X(v),D.Y(y)); } c.stroke(); c.restore(); });
    T(c, "点線＝300 K、実線＝いまの温度", D.x1, D.y1+4, {size:11, col:COL.sub, align:"right", halo:true});
    notebook(c,W,H);
    var mh='内部エネルギー '+tex("U=\\dfrac{3}{2}nRT")+' = 3/2 × '+this.n.toFixed(1)+' × 8.31 × '+this.T+' = <span class="num">'+Math.round(U)+'</span> J'+
      '<br>体積 '+tex("V")+' = '+this.V.toFixed(1)+' ×10⁻² m³（体積を変えても、分子の速さは変わらないので '+tex("U")+' は同じ）';
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};
