/* =========================================================================
   モード③ 熱力学第一法則と p-V 図（3-1〜3-3）
   単位：p は ×10⁵ Pa、V は ×10⁻² m³ → pV は ×10³ J
   ========================================================================= */
/* 棒グラフ：Q ＋ W_された ＝ ΔU（物理基礎 ②-1 と同じ形）。vals …[Q, Wされた, ΔU]［J］、vmax …目盛りの最大 */
function barsQWU(c, x0, y0, x1, y1, vals, vmax, title){
  var base=(y0+y1)/2+8, sc=(y1-y0-34)/2/vmax, bw=(x1-x0)/5.4;
  T(c, title||"エネルギーの出入り〔J〕", (x0+x1)/2, y0+6, {size:13, bold:true, align:"center"});
  c.save(); c.strokeStyle="#3a414c"; c.lineWidth=1.2; c.beginPath(); c.moveTo(x0,base); c.lineTo(x1,base); c.stroke(); c.restore();
  var L=[[vals[0],"Q",null,COL.heat],[vals[1],"W","された",COL.work],[vals[2],"ΔU",null,COL.dU]];
  L.forEach(function(v,i){ var x=x0+bw*(0.4+i*1.75), hgt=clamp(v[0],-vmax,vmax)*sc;
    c.save(); c.fillStyle=v[3]; c.globalAlpha=0.88; c.fillRect(x, base-Math.max(hgt,0), bw, Math.abs(hgt)); c.restore();
    SYM(c, v[1], v[2], x+bw/2, y0+26, {size:14, bold:true, col:v[3], align:"center"});
    T(c, (v[0]>=0.5? "+" : v[0]<=-0.5? "−" : "")+Math.abs(Math.round(v[0])), x+bw/2, (hgt>=0? base-hgt-9 : base-hgt+10), {size:11, bold:true, col:v[3], align:"center", halo:true}); });
  T(c, "＋", x0+bw*1.8, y0+26, {size:15, bold:true, align:"center"}); T(c, "＝", x0+bw*3.55, y0+26, {size:15, bold:true, align:"center"});
}
/* 符号つきの整数（マイナスは −） */
function sgn(v){ var r=Math.round(v); return (r>0? "+" : r<0? "−" : "")+Math.abs(r); }
/* 熱の出入りの表し方：Q＞0 はバーナー、Q＜0 は冷たい物体。断熱のときは何も置かない */
function heatUnder(c, x, yb, q, clk, running, wide){
  if(q>0){ burner(c, x, yb+44, running, clk, 0.72); if(running) heatFlow(c, x+(wide||28), yb+34, x+(wide||28), yb+4, 12, (clk*0.9)%1, {k:0.8}); }
  else if(q<0){ c.save(); c.fillStyle="#cfe4f6"; c.strokeStyle="#1f6fb2"; c.lineWidth=1.2; rrect(c, x-34, yb+12, 68, 15, 4); c.fill(); c.stroke(); c.restore();
    T(c,"冷たい物体", x, yb+38, {size:10.5, bold:true, col:"#1f6fb2", align:"center", halo:true});
    if(running) heatFlow(c, x+(wide||44), yb+2, x+(wide||44), yb+32, 12, (clk*0.9)%1, {k:0.8}); }
}

/* 第3回：変化の種類ごとの装置（③-1・③-2 で共通）。使わないボタンは暗くする */
var KINDCFG = { V:{pis:"lock", cont:"ins", heat:true, move:false}, P:{pis:"free", cont:"ins", heat:true, move:false},
                T:{pis:"hand", cont:"bath", heat:false, move:true}, A:{pis:"hand", cont:"ins", heat:false, move:true} };
function kindPrep(sec, kind){ var k=KINDCFG[kind]; syncPrep(sec, k.pis, k.cont); prepLock(sec, {pis:[k.pis], cont:[k.cont], heat:k.heat, move:k.move}); }
/* 操作のボタン：加熱・引く＝膨張（定積は加熱）、冷却・押す＝圧縮（定積は冷却）。押すとその向きでスタート */
function wireOps(sec, self){
  sec.querySelector(".ctrls .row1b").insertAdjacentHTML("afterend", H_prep(true,true));
  sec.querySelectorAll(".prepbox .hbtn").forEach(function(b){ b.addEventListener("click", function(){ self.ex=(b.dataset.h==="1")? "exp" : "cmp"; self.run.reset(); self.tb.sync(); self.run.toggle(); }); });
  sec.querySelectorAll(".prepbox .mbtn").forEach(function(b){ b.addEventListener("click", function(){ self.ex=(b.dataset.m==="1")? "exp" : "cmp"; self.run.reset(); self.tb.sync(); self.run.toggle(); }); });
}

/* ---------------- ③-1 気体がする仕事と p-V 図 ----------------
   1 mol の単原子分子。初めの状態 p＝1.0、V＝2.5（膨張）、または V＝4.0（圧縮。同じ曲線の上）。
   第3回：変化は 定積・定圧・等温・断熱 の 4 つ。面積の斜線は面積全体に引く */
var S31 = {
  DUR:6, pA:1.0, g:5/3, NM:{V:"定積変化", P:"定圧変化", T:"等温変化", A:"断熱変化"},
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.path="P"; this.ex="exp"; this.gas=new Gas(28, 31); this.clk=0;
    this.run=new Runner({ again:true, step:function(dt){ self.clk+=dt; self.mv(dt); self.tb.sync(); return self.run.t>=self.DUR; }, draw:function(){ self.draw(); }, reset:function(){},
      startText:function(){ return "▶ スタート"; } });
    this.run.bind(sec);
    this.tb=wireTimeBar(sec, this.run, function(){ return self.DUR; }, function(){});
    wireOps(sec, this);
    this.s1=wireSeg(sec,"path",function(v){ self.path=v; kindPrep(sec, v); self.run.reset(); self.tb.sync(); });
    kindPrep(sec, this.path);
    sec.querySelector(".resetall").addEventListener("click", function(){ self.path="P"; self.ex="exp"; self.s1.set("P"); kindPrep(sec,"P"); resetSlow(sec,self.run); self.run.reset(); self.tb.sync(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    idleLoop(sec, function(dt){ if(self.run.state!=="run"){ self.clk+=dt; self.mv(dt); self.draw(); } });
    this.draw();
  },
  /* 初めと終わり：定積は V＝2.5 のまま p が 1.0 → 1.45（加熱）／0.55（冷却） */
  ends:function(){ return this.ex==="exp"? [2.5,4.0] : [4.0,2.5]; },
  pOf:function(V){ var k=this.path; if(k==="P") return this.pA; if(k==="T") return this.pA*2.5/V; return this.pA*Math.pow(2.5/V, this.g); },
  state:function(t){ var u=clamp(t/this.DUR,0,1);
    if(this.path==="V") return [2.5, this.pA+(this.ex==="exp"? 0.45 : -0.45)*u];
    var e=this.ends(), V=e[0]+(e[1]-e[0])*u; return [V, this.pOf(V)]; },
  Wof:function(V){ var V0=this.ends()[0], k=this.path;      /* 気体がした仕事［J］ */
    if(k==="V") return 0; if(k==="P") return this.pA*(V-V0)*1e3; if(k==="T") return this.pA*2.5*Math.log(V/V0)*1e3;
    return (this.pOf(V0)*V0-this.pOf(V)*V)/(this.g-1)*1e3; },
  mv:function(dt){ var s=this.state(this.run.t); if(this.g2) this.gas.step(dt, this.g2.L, this.g2.h, 55*Math.sqrt(s[0]*s[1]*1e3/RGAS/300), 4); },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return W<620? clamp(W*1.1, 430, 520) : clamp(W*0.44, 300, 370); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var narrow=W<620, aw=narrow? W : W*0.48, ah=narrow? H*0.42 : H, t=this.run.t, st=this.state(t), V=st[0], p=st[1], Tk=p*V*1e3/RGAS, running=this.run.state==="run", k=this.path, cfg=KINDCFG[k];
    var ox=40, h=narrow? 74 : 88, Lmax=aw-ox-90, L=Lmax*V/4.6, cy=narrow? 30+h/2+28 : ah*0.42;
    this.g2={L:L, h:h};
    var F=new CylFrame(ox, cy, "right"), q=this.ex==="exp"? 1 : -1;
    drawCylinder(c, F, {L:L, Lmax:Lmax, h:h, T:Tk, gas:this.gas, r:4, pt:14, rod:36, hand:(cfg.pis==="hand"), lock:(cfg.pis==="lock"), cont:cfg.cont, noInsLab:true, bathT:Tk,
      heater:true, heat:(cfg.heat && running? q : 0), clk:this.clk, thermo:true, thLen:36});
    if(cfg.cont==="ins") T(c, "断熱材", ox-14, cy+h/2+30, {size:11, bold:true, col:"#7a6635"});
    T(c, this.NM[k], ox+Lmax*0.45, cy+h/2+30, {size:13, bold:true, align:"center"});
    var W1=this.Wof(V);
    if(k!=="V" && (running || t>0)){ var dir=(this.ex==="exp")? 1 : -1, yb=cy-h/2-46; blockArrow(c, ox+L+30, yb, ox+L+30+dir*56, yb, 10, "#5cc47a");
      T(c, (dir>0? "気体が押し出す" : "外から押しこまれる"), ox+L+30+dir*28, yb-16, {size:11, bold:true, col:COL.work, align:"center", halo:true}); }
    /* p-V 図と面積 */
    var gx0=narrow? 50 : aw+40, gy0=H-40, gx1=W-14, gy1=narrow? ah+40 : 40;
    graphTitle(c, "p-V 図（色の面積＝気体がした仕事の大きさ）", gx0-30, gy1-22);
    var P=plotFrame(c, gx0, gy0, gx1, gy1, [0,5], [0,1.5], {xl:"V〔×10⁻² m³〕", yl:"p〔×10⁵ Pa〕", xstep:1, ystep:0.5});
    var e=this.ends();
    if(k==="V"){ c.save(); c.setLineDash([5,4]); c.strokeStyle="#9aa1ab"; c.lineWidth=1.3; c.beginPath(); c.moveTo(P.X(2.5),P.Y(0.55)); c.lineTo(P.X(2.5),P.Y(1.45)); c.stroke(); c.restore();
      c.save(); c.strokeStyle="#c0392b"; c.lineWidth=2.6; c.beginPath(); c.moveTo(P.X(2.5),P.Y(this.pA)); c.lineTo(P.X(2.5),P.Y(p)); c.stroke(); c.restore();
      dot(c, P.X(2.5), P.Y(this.pA), 4.5, "#3a414c"); T(c, "初め", P.X(2.5)+8, P.Y(this.pA), {size:11, col:COL.sub, halo:true});
      T(c, "体積が変わらない → 面積は 0（仕事をしない）", P.X(2.5)+12, P.Y(1.3), {size:11.5, bold:true, col:"#1c6b3a", halo:true}); }
    else {
      var a=Math.min(e[0],V), b=Math.max(e[0],V);
      if(b-a>1e-3){ var area=function(){ c.beginPath(); c.moveTo(P.X(a),P.Y(0)); for(var i=0;i<=40;i++){ var v=a+(b-a)*i/40; c.lineTo(P.X(v),P.Y(self.pOf(v))); } c.lineTo(P.X(b),P.Y(0)); c.closePath(); };
        c.save(); area(); c.fillStyle=(this.ex==="exp")? "rgba(92,196,122,.35)" : "rgba(231,76,60,.22)"; c.fill(); c.clip();
        var X0=P.X(a), X1=P.X(b), Yt=P.Y(1.5), Yb=P.Y(0), hgt=Yb-Yt;
        c.strokeStyle=(this.ex==="exp")? "rgba(28,143,74,.6)" : "rgba(192,57,43,.5)"; c.lineWidth=1;
        for(var kx=X0-hgt; kx<X1+9; kx+=9){ c.beginPath(); c.moveTo(kx,Yb); c.lineTo(kx+hgt,Yt); c.stroke(); } c.restore(); }
      curve(c, P, function(v){ return self.pOf(v); }, Math.min(e[0],e[1]), Math.max(e[0],e[1]), "#9aa1ab", 1.3, [5,4]);
      curve(c, P, function(v){ return self.pOf(v); }, a, b, "#c0392b", 2.6);
      dot(c, P.X(e[0]), P.Y(this.pOf(e[0])), 4.5, "#3a414c"); T(c, "初め", P.X(e[0]), P.Y(this.pOf(e[0]))-14, {size:11, col:COL.sub, align:"center", halo:true});
      var mid=(a+b)/2; if(b-a>0.35){ var lw=T(c, "面積 ＝ ", P.X(mid)-18, P.Y(this.pOf(mid)*0.45), {size:12, bold:true, col:"#1c6b3a", align:"center", halo:true}); symW(c, "した", P.X(mid)-18+lw/2+2, P.Y(this.pOf(mid)*0.45), {size:13, bold:true, col:"#1c6b3a", halo:true}); if(this.ex==="cmp") T(c, "（負）", P.X(mid), P.Y(this.pOf(mid)*0.45)+18, {size:11, bold:true, col:"#1c6b3a", align:"center", halo:true}); }
    }
    dot(c, P.X(V), P.Y(p), 6, "#c0392b");
    notebook(c,W,H);
    var how={V:"体積が変わらないので、気体は仕事をしない。", P:tex(WS+"=p\\Delta V")+'（グラフは横軸に平行な直線）', T:'等温変化：温度 '+Math.round(Tk)+' K のまま。グラフは反比例の曲線', A:'断熱変化：熱の出入りがない。グラフは等温の曲線より傾きが急'}[k];
    var mh='気体がした仕事 '+tex(WS)+' = <span class="num">'+(W1>0.5? "+" : W1<-0.5? "−" : "")+Math.abs(Math.round(W1))+'</span> J（気体がされた仕事 '+tex(WD)+' = <span class="num">'+(W1>0.5? "−" : W1<-0.5? "+" : "")+Math.abs(Math.round(W1))+'</span> J）<br>'+how;
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};

/* ---------------- ③-2 4 つの変化 ----------------
   単原子分子の理想気体 1 mol、状態 A：p＝1.0、V＝2.5（T≒301 K）。膨張は V→5.0、圧縮は V→1.25。定積は p→2.0／0.5 */
var S32 = {
  DUR:6, pA:1.0, VA:2.5, g:5/3, NM:{V:"定積変化", P:"定圧変化", T:"等温変化", A:"断熱変化"},
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.kind="P"; this.ex="exp"; this.gas=new Gas(30, 32); this.clk=0;
    this.run=new Runner({ again:true, step:function(dt){ self.clk+=dt; self.mv(dt); self.tb.sync(); return self.run.t>=self.DUR; }, draw:function(){ self.draw(); }, reset:function(){},
      startText:function(){ return "▶ スタート"; } });
    this.run.bind(sec);
    this.tb=wireTimeBar(sec, this.run, function(){ return self.DUR; }, function(){});
    wireOps(sec, this);
    this.s1=wireSeg(sec,"kind",function(v){ self.kind=v; kindPrep(sec, v); self.run.reset(); self.tb.sync(); });
    kindPrep(sec, this.kind);
    sec.querySelector(".resetall").addEventListener("click", function(){ self.kind="P"; self.ex="exp"; self.s1.set("P"); kindPrep(sec,"P"); resetSlow(sec,self.run); self.run.reset(); self.tb.sync(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    idleLoop(sec, function(dt){ if(self.run.state!=="run"){ self.clk+=dt; self.mv(dt); self.draw(); } });
    this.draw();
  },
  /* 変化の途中（u＝0〜1）の状態 [V, p] */
  st:function(kind, ex, u){ var A=this.pA*this.VA, VA=this.VA;
    if(kind==="V"){ var p1=(ex==="exp")? 2.0 : 0.5; return [VA, this.pA+(p1-this.pA)*u]; }
    var V1=(ex==="exp")? 5.0 : 1.25, V=VA+(V1-VA)*u;
    if(kind==="P") return [V, this.pA]; if(kind==="T") return [V, A/V]; return [V, this.pA*Math.pow(VA/V, this.g)]; },
  /* エネルギー［J］：Q・W_された・ΔU */
  en:function(kind, ex, u){ var s=this.st(kind, ex, u), V=s[0], p=s[1], A=this.pA*this.VA, VA=this.VA, Ws;
    if(kind==="V") Ws=0; else if(kind==="P") Ws=this.pA*(V-VA); else if(kind==="T") Ws=A*Math.log(V/VA); else Ws=(A-p*V)/(this.g-1);
    var dU=1.5*(p*V-A); return [(dU+Ws)*1e3, -Ws*1e3, dU*1e3]; },
  Tof:function(V,p){ return p*V*1e3/RGAS; },
  mv:function(dt){ var s=this.st(this.kind,this.ex,clamp(this.run.t/this.DUR,0,1)); if(this.gg) this.gas.step(dt, this.gg.L, this.gg.h, 52*Math.sqrt(this.Tof(s[0],s[1])/300), 4); },
  draw:function(){
    var self=this, f=fitCanvas(this.cv, function(W){ return W<700? clamp(W*1.6, 600, 720) : clamp(W*0.44, 420, 500); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H);
    var narrow=W<700, t=this.run.t, u=clamp(t/this.DUR,0,1), kind=this.kind, ex=this.ex, s=this.st(kind,ex,u), V=s[0], p=s[1], Tk=this.Tof(V,p), E=this.en(kind,ex,u), running=this.run.state==="run";
    var TA=this.Tof(this.VA,this.pA);
    /* 区画 */
    /* 第3回：内部エネルギーと速さの分布は ②-4 へ移した */
    var top=narrow? [0,0,W,H*0.30] : [0,0,W*0.42,H*0.62], pv=narrow? [0,H*0.30,W,H*0.66] : [W*0.42,0,W,H*0.62];
    var b1=narrow? [0,H*0.68,W,H] : [W*0.10,H*0.64,W*0.62,H];
    /* シリンダー */
    var ox=top[0]+40, h=Math.min(74,(top[3]-top[1])*0.36), Lmax=top[2]-top[0]-ox-70, L=Lmax*V/5.4, cy=top[1]+(top[3]-top[1])*0.55;
    this.gg={L:L, h:h};
    var q=(kind==="A")? 0 : (E[0]>=0? 1 : -1);
    /* 定積：固定＋断熱材＋ヒーター、定圧：自由＋断熱材＋ヒーター、等温：恒温槽＋手、断熱：断熱材＋手 */
    drawCylinder(c, new CylFrame(ox, cy, "right"), {L:L, Lmax:Lmax, h:h, T:Tk, gas:this.gas, r:3.8, pt:13, rod:30, lock:(kind==="V"), hand:(kind==="T"||kind==="A"),
      cont:(kind==="T"? "bath" : "ins"), bathT:Tk, heater:true, heat:((kind==="V"||kind==="P") && running? (ex==="exp"? 1 : -1) : 0), clk:this.clk, thermo:true, thLen:(narrow? 16 : 30)});
    T(c, this.NM[kind]+(kind==="V"? "（ピストン固定）" : kind==="A"? "（断熱材で囲み、手で動かす）" : kind==="P"? "（ピストンは自由）" : "（恒温槽に入れ、手で動かす）"), ox-12, top[1]+14, {size:12, bold:true});
    /* p-V 図：4 つの変化の曲線を重ねる */
    graphTitle(c, "p-V 図（4 つの変化）", pv[0]+20, pv[1]+18);
    var P=plotFrame(c, pv[0]+50, pv[3]-36, pv[2]-12, pv[1]+40, [0,5.5], [0,3.5], {xl:"V〔×10⁻² m³〕", yl:"p〔×10⁵ Pa〕", xstep:1, ystep:1});
    var CC={V:"#7b3fd4", P:"#1f6fb2", T:"#1c8f4a", A:"#c0392b"};
    ["V","P","T","A"].forEach(function(k){ ["exp","cmp"].forEach(function(e){ var on=(k===kind && e===ex);
      c.save(); c.strokeStyle=CC[k]; c.globalAlpha=on? 0.35 : 0.55; c.lineWidth=on? 1.2 : 1.6; c.setLineDash(on? [5,4] : []); c.beginPath();
      for(var i=0;i<=60;i++){ var q2=self.st(k,e,i/60), x=P.X(q2[0]), y=P.Y(Math.min(q2[1],3.45)); if(i) c.lineTo(x,y); else c.moveTo(x,y); } c.stroke(); c.restore(); });
      var en=self.st(k,"exp",1); T(c, self.NM[k].replace("変化",""), P.X(en[0])+(k==="V"? 6 : -4), P.Y(Math.min(en[1],3.4))+(k==="V"? 0 : k==="A"? 12 : -10), {size:10.5, bold:true, col:CC[k], align:(k==="V"? "left" : "right"), halo:true}); });
    c.save(); c.strokeStyle=CC[kind]; c.lineWidth=3; c.beginPath(); for(var i=0;i<=60;i++){ var q3=this.st(kind,ex,u*i/60), x=P.X(q3[0]), y=P.Y(Math.min(q3[1],3.45)); if(i) c.lineTo(x,y); else c.moveTo(x,y); } c.stroke(); c.restore();
    dot(c, P.X(this.VA), P.Y(this.pA), 5, "#3a414c"); T(c, "A", P.X(this.VA)-8, P.Y(this.pA)+12, {size:13, bold:true, serif:true, align:"right", halo:true});
    dot(c, P.X(V), P.Y(Math.min(p,3.45)), 6.5, CC[kind]);
    /* 棒グラフ Q ＋ W_された ＝ ΔU */
    barsQWU(c, b1[0]+14, b1[1]+8, b1[2]-10, b1[3]-6, E, 7000, "熱力学第一法則：エネルギーの出入り〔J〕");
    notebook(c,W,H);
    var mh='<b>'+this.NM[kind]+'</b>（'+(ex==="exp"? (kind==="V"? "加熱" : "膨張") : (kind==="V"? "冷却" : "圧縮"))+'）　'+tex("Q")+' = <span class="num">'+sgn(E[0])+'</span> J　'+tex(WD)+' = <span class="num">'+sgn(E[1])+'</span> J　'+tex("\\Delta U")+' = <span class="num">'+sgn(E[2])+'</span> J　温度 <span class="num">'+Math.round(Tk)+'</span> K'+
      '<br>'+({V:"体積が変わらないので仕事はしない。受け取った熱が全て内部エネルギーになる。", P:"受け取った熱の一部が、外にする仕事になる。", T:"温度が変わらないので内部エネルギーは変わらない。受け取った熱が全て仕事になる。", A:"熱の出入りがないので、気体がした仕事の分だけ内部エネルギーが減る（圧縮では増える）。"}[kind]);
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};

/* ---------------- ③-3 モル比熱 ----------------
   第3回：thermal-energy.html の ①-4（比熱）と同じ並び。左＝定積、まん中＝定圧、右＝2 つの T-t グラフ。
   同じヒーターで同じ熱量を加え、温度の上がり方の違いでモル比熱の違いを見る（1 mol、300 K から） */
var S33 = {
  DUR:6, T0:300, COLS:["#1f6fb2","#b5651d"],
  init:function(sec){
    var self=this; this.sec=sec; this.cv=sec.querySelector("canvas.main"); this.msg=sec.querySelector(".msgbox");
    this.mol="mono"; this.A=new Gas(20, 331); this.B=new Gas(20, 332); this.clk=0;
    this.run=new Runner({ startText:"▶ スタート（加熱する）", step:function(dt){ self.clk+=dt; self.mv(dt); self.tb.sync(); return self.run.t>=self.DUR; }, draw:function(){ self.draw(); }, reset:function(){}, info:function(){ return ''; } });
    this.run.bind(sec);
    this.tb=wireTimeBar(sec, this.run, function(){ return self.DUR; }, function(){});
    this.sm=wireSeg(sec,"mol",function(v){ self.mol=v; self.run.reset(); self.tb.sync(); });
    this.cg=colGrid(sec, {B:true, lc:"ref", rc:"sub"});
    sec.querySelector(".resetall").addEventListener("click", function(){ self.mol="mono"; self.sm.set("mono"); resetSlow(sec,self.run); self.run.reset(); self.tb.sync(); });
    onResize(this.cv.parentElement, function(){ self.draw(); });
    idleLoop(sec, function(dt){ if(self.run.state!=="run"){ self.clk+=dt; self.mv(dt); self.draw(); } });
    this.draw();
  },
  CV:function(){ return (this.mol==="di"? 2.5 : 1.5)*RGAS; },
  rate:function(){ return this.CV()*100/this.DUR; },                     /* ヒーターの熱［J/s］：定積がちょうど 100 K 上がる */
  Ts:function(t){ var Q=this.rate()*clamp(t,0,this.DUR), cv=this.CV(); return [this.T0+Q/cv, this.T0+Q/(cv+RGAS), Q]; },
  mv:function(dt){ var T2=this.Ts(this.run.t); if(this.ga) this.A.step(dt, this.ga.L, this.ga.h, 50*Math.sqrt(T2[0]/300), 5); if(this.gb) this.B.step(dt, this.gb.L, this.gb.h, 50*Math.sqrt(T2[1]/300), 5); },
  draw:function(){
    var self=this, wide=(this.cv.parentElement.clientWidth>=760);
    var f=fitCanvas(this.cv, function(W){ return wide? clamp(W*0.30, 320, 380) : clamp(W*1.30, 500, 600); }), c=f.c, W=f.W, H=f.H;
    c.clearRect(0,0,W,H); if(this.tb) this.tb.sync();
    var t=this.run.t, T2=this.Ts(t), Q=T2[2], di=(this.mol==="di"), running=this.run.state==="run";
    var c1=W*0.31, c2=W*0.62, figH=wide? H : H*0.54;
    var V0=RGAS*300/1e5*100;
    for(var i=0;i<2;i++){
      var R=wide? {x:(i? c1 : 0), w:(i? c2-c1 : c1)} : {x:i*W/2, w:W/2};
      var ox=R.x+R.w/2, baseY=figH-30, h=Math.min(78, R.w*0.38), Lmax=figH-120, Tk=T2[i], Vv=i? RGAS*Tk/1e5*100 : V0, L=Lmax*Vv/4.6;
      if(i===0) this.ga={L:L, h:h}; else this.gb={L:L, h:h};
      ground(c, ox-h/2-40, ox+h/2+40, baseY+13);
      drawCylinder(c, new CylFrame(ox, baseY, "up"), {L:L, Lmax:Lmax, h:h, T:Tk, gas:i? this.B : this.A, r:4.6, pt:13, lock:(i===0), rotDi:di, clk:this.clk, cont:"ins", noInsLab:true, heater:true, heat:(running? 1 : 0), thermo:true, thLen:22});
      T(c, i? "定圧（ピストンは自由）" : "定積（ピストン固定）", ox, 14, {size:13, bold:true, col:this.COLS[i], align:"center", halo:true});
      if(i===1 && (running || t>0)){ var yb=baseY-L-34; blockArrow(c, ox+h/2+22, yb+10, ox+h/2+22, yb-30, 9, "#5cc47a"); T(c, "仕事", ox+h/2+38, yb-12, {size:11, bold:true, col:COL.work, halo:true}); }
    }
    if(this.run.state==="idle" && t<=0) T(c, "同じ温度 300 K からスタート", wide? c1 : W/2, wide? 34 : figH-8, {size:12.5, bold:true, col:"#c0392b", align:"center", halo:true});
    /* T-t グラフ（2 つを 1 つに） */
    var gx0=wide? c2+52 : 52, gy0=H-34, gx1=W-14, gy1=wide? 46 : figH+44;
    graphTitle(c, "温度の時間変化（同じ熱を加える）", gx0-30, gy1-24);
    var P=plotFrame(c, gx0, gy0, gx1, gy1, [0,this.DUR], [280,420], {xl:"t〔s〕", yl:"T〔K〕", xstep:1, ystep:20, noO:true, xz:true});
    for(var k=0;k<2;k++){ c.save(); c.strokeStyle=this.COLS[k]; c.lineWidth=2.8; c.beginPath();
      for(var j=0;j<=40;j++){ var tt=t*j/40, Tq=this.Ts(tt)[k]; if(j) c.lineTo(P.X(tt),P.Y(Tq)); else c.moveTo(P.X(tt),P.Y(Tq)); } c.stroke();
      c.fillStyle=this.COLS[k]; c.beginPath(); c.arc(P.X(t),P.Y(T2[k]),4.5,0,7); c.fill(); c.restore();
      if(t>0) T(c, k? "定圧" : "定積", P.X(t)+(t>this.DUR*0.8? -8 : 8), P.Y(T2[k])+(k? 12 : -10), {size:11.5, bold:true, col:this.COLS[k], align:(t>this.DUR*0.8? "right" : "left"), halo:true}); }
    notebook(c,W,H);
    if(this.cg) this.cg.set(this.cv, [c1,c2], wide);
    var dV=T2[0]-this.T0, dP=T2[1]-this.T0;
    var mh=(di? '二原子分子' : '単原子分子')+'：加えた熱量 '+tex("Q")+' = <span class="num">'+Math.round(Q)+'</span> J　定積 '+tex("\\Delta T")+' = <span class="num">'+dV.toFixed(1)+'</span> K　／　定圧 '+tex("\\Delta T")+' = <span class="num">'+dP.toFixed(1)+'</span> K'+
      (t>=this.DUR-1e-6? '<br>'+tex("C_V=\\dfrac{Q}{\\Delta T}")+' = <span class="num">'+(Q/dV).toFixed(1)+'</span> J/(mol·K)（'+(di? '5/2' : '3/2')+' R）、'+tex("C_p")+' = <span class="num">'+(Q/dP).toFixed(1)+'</span> J/(mol·K)（'+(di? '7/2' : '5/2')+' R）。定圧では仕事をする分、温度が上がりにくい。' : '');
    if(this._mh!==mh){ this.msg.innerHTML=mh; this._mh=mh; }
  }
};
