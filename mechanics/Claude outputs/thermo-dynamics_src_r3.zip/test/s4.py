import asyncio, sys
from playwright.async_api import async_playwright
async def main():
    W=int(sys.argv[1])
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--no-sandbox']); pg=await b.new_page(viewport={'width':W,'height':900}); errs=[]
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('file:///home/claude/work/td/thermo-dynamics.html'); await pg.wait_for_timeout(400)
        for s,tv in [('s41',0.55),('s42',0.1),('s31',0.6)]:
            await pg.evaluate(f'gotoSec("{s}")'); await pg.wait_for_timeout(300)
            await pg.evaluate(f"(()=>{{const i=document.querySelector('#{s} .tbar input'); if(i){{i.value={int(tv*1000)}; i.dispatchEvent(new Event('input'));}}}})()"); await pg.wait_for_timeout(200)
            await (await pg.query_selector(f'#{s} canvas.main')).screenshot(path=f'test/y_{s}_{W}.png')
        print(errs); await b.close()
asyncio.run(main())
