import asyncio, sys
from playwright.async_api import async_playwright
# usage: one.py W sec "js before shot" out.png
async def main():
    W=int(sys.argv[1]); s=sys.argv[2]; js=sys.argv[3]; out=sys.argv[4]
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--no-sandbox']); pg=await b.new_page(viewport={'width':W,'height':900}, device_scale_factor=1); errs=[]
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('file:///home/claude/work/td/thermo-dynamics.html'); await pg.wait_for_timeout(400)
        await pg.evaluate(f'gotoSec("{s}")'); await pg.wait_for_timeout(300)
        if js: await pg.evaluate(js); await pg.wait_for_timeout(int(sys.argv[5]) if len(sys.argv)>5 else 1500)
        el=await pg.query_selector(f'#{s}'); await el.screenshot(path=out)
        print(errs); await b.close()
asyncio.run(main())
