import asyncio
from playwright.async_api import async_playwright
SECS=["s11","s12","s13","s14","s15","s21","s22","s23","s24","s31","s32","s33","s41","s42","s43","s51","s52","s53","s54","s61"]
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--no-sandbox'])
        for W,Hh in [(360,780),(390,844),(768,1024),(844,390),(1024,768),(1440,900)]:
            pg=await b.new_page(viewport={'width':W,'height':Hh}); errs=[]; ext=[]
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.on('request', lambda r: ext.append(r.url) if not r.url.startswith(('file:','data:')) else None)
            await pg.goto('file:///home/claude/work/td/thermo-dynamics.html'); await pg.wait_for_timeout(400)
            over=[]
            for s in SECS:
                await pg.evaluate(f'gotoSec("{s}")'); await pg.wait_for_timeout(150)
                bp=await pg.query_selector(f'#{s} #bPlay')
                if bp and await bp.is_visible(): await bp.click(); await pg.wait_for_timeout(500)
                sw=await pg.evaluate('document.documentElement.scrollWidth')
                if sw>W: over.append((s,sw))
                if W in (390,):
                    await (await pg.query_selector(f'#{s}')).screenshot(path=f'test/w390_{s}.png')
            print(W, 'errs',errs[:3], 'ext',len(ext), 'over',over)
            await pg.close()
        await b.close()
asyncio.run(main())
