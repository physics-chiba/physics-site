import asyncio, sys
from playwright.async_api import async_playwright
async def main():
    W=int(sys.argv[1])
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--no-sandbox']); pg=await b.new_page(viewport={'width':W,'height':900}); errs=[]
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('file:///home/claude/work/td/thermo-dynamics.html'); await pg.wait_for_timeout(400)
        await pg.evaluate('gotoSec("s21")'); await pg.wait_for_timeout(300)
        for t in [1.5,5,8,19]:
            await pg.evaluate(f"(()=>{{const i=document.querySelector('#s21 .tbar input'); i.value={round(t/24*1000)}; i.dispatchEvent(new Event('input'));}})()"); await pg.wait_for_timeout(150)
            await (await pg.query_selector('#s21 canvas.main')).screenshot(path=f'/home/claude/work/td/test/c21_{t}_{W}.png')
        print(errs); await b.close()
asyncio.run(main())
