import asyncio, json
from playwright.async_api import async_playwright
URL='file:///home/claude/work/td/thermo-dynamics.html'; OUT='/home/claude/work/td/test/'
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--no-sandbox']); errs=[]
        pg=await b.new_page(viewport={'width':1440,'height':900})
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto(URL); await pg.wait_for_timeout(500)
        await pg.evaluate('gotoSec("s11")'); await pg.wait_for_timeout(300)
        for i in range(5):
            await pg.click('#bPlay'); await pg.wait_for_timeout(1700)
        await pg.click('#s11 .hbtn[data-h="1"]'); await pg.wait_for_timeout(700)
        await (await pg.query_selector('#s11 .sL')).screenshot(path=OUT+'a11_heat.png')
        await pg.wait_for_timeout(1500)
        await pg.click('#s11 .gpb[data-pm="p"][data-d="1"]'); await pg.wait_for_timeout(2200)
        await (await pg.query_selector('#s11 .sL')).screenshot(path=OUT+'a11_p.png')
        await pg.evaluate('gotoSec("s12")'); await pg.wait_for_timeout(300)
        for d in ['u','uw','d']:
            await pg.click(f'#s12 button.seg[data-v="{d}"]'); await pg.wait_for_timeout(1800)
            await (await pg.query_selector('#s12 canvas.main')).screenshot(path=OUT+f'a12_{d}.png')
        await pg.evaluate('gotoSec("s33")'); await pg.wait_for_timeout(200)
        await pg.click('#s33 button.seg[data-v="di"]'); await pg.click('#s33 button.b.play'); await pg.wait_for_timeout(6800)
        await (await pg.query_selector('#s33 .sL')).screenshot(path=OUT+'a33_end.png')
        lab=await pg.inner_text('#s33 button.b.play')
        await pg.evaluate('gotoSec("s41")'); await pg.click('#s41 button.seg[data-v="carnot"]')
        await pg.evaluate("(()=>{const i=document.querySelector('#s41 .tbar input'); i.value=1000; i.dispatchEvent(new Event('input'));})()"); await pg.wait_for_timeout(200)
        await (await pg.query_selector('#s41 .sL')).screenshot(path=OUT+'a41_carnot.png')
        print(json.dumps({'errs':errs,'s33label':lab},ensure_ascii=False))
        await b.close()
asyncio.run(main())
