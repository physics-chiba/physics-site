import sys, asyncio, json
from playwright.async_api import async_playwright
URL='file:///home/claude/work/td/thermo-dynamics.html'; OUT='/home/claude/work/td/test/'
SECS=['s11','s12','s13','s14','s15','s21','s22','s23','s24','s31','s32','s33','s41','s42','s51']
async def main():
    widths=[int(x) for x in (sys.argv[1].split(',') if len(sys.argv)>1 else ['1440','390'])]
    shots = (sys.argv[2] if len(sys.argv)>2 else 'all')
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--no-sandbox'])
        res={}
        for w in widths:
            h=900 if w>=1000 else (768 if w==1024 else 844)
            if w==844: h=390
            pg=await b.new_page(viewport={'width':w,'height':h}); errs=[]; ext=[]
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.on('console', lambda m: errs.append('console:'+m.text) if m.type=='error' else None)
            pg.on('request', lambda r: ext.append(r.url) if not r.url.startswith(('file:','data:')) else None)
            await pg.goto(URL); await pg.wait_for_timeout(700)
            await pg.evaluate('window.__hero && window.__hero.frame(5.0)')
            if shots!='none': await (await pg.query_selector('#hero')).screenshot(path=OUT+f'hero_{w}.png')
            for sid in SECS:
                await pg.evaluate(f'gotoSec("{sid}")'); await pg.wait_for_timeout(300)
                # 途中まで再生した状態
                await pg.evaluate(f"""(()=>{{const i=document.querySelector('#{sid} .tbar input'); if(i){{ i.value=600; i.dispatchEvent(new Event('input')); }} }})()""")
                await pg.wait_for_timeout(150)
                if shots!='none': await (await pg.query_selector('#'+sid)).screenshot(path=OUT+f'{sid}_{w}.png')
            sw=await pg.evaluate('document.documentElement.scrollWidth')
            res[w]={'errs':errs[:8],'ext':ext,'scrollW':sw}
            await pg.close()
        print(json.dumps(res,ensure_ascii=False,indent=1))
        await b.close()
asyncio.run(main())
