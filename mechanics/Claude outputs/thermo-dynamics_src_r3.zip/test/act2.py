import asyncio, json, sys
from playwright.async_api import async_playwright
URL='file:///home/claude/work/td/thermo-dynamics.html'; OUT='/home/claude/work/td/test/'
async def main():
    W=int(sys.argv[1]) if len(sys.argv)>1 else 1440
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--no-sandbox']); errs=[]
        pg=await b.new_page(viewport={'width':W,'height':900})
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto(URL); await pg.wait_for_timeout(500)
        await pg.evaluate('gotoSec("s11")'); await pg.wait_for_timeout(300)
        await (await pg.query_selector('#s11 .sL')).screenshot(path=OUT+f'b11_0_{W}.png')
        for i in range(4):
            await pg.click('#bPlay'); await pg.wait_for_timeout(1000)
        await pg.click('#s11 .hbtn[data-h="1"]'); await pg.wait_for_timeout(400)
        await (await pg.query_selector('#s11 .sL')).screenshot(path=OUT+f'b11_1_{W}.png')
        await pg.wait_for_timeout(800)
        await pg.click('#s11 .pb[data-v="free"]'); await pg.wait_for_timeout(1200)
        await pg.click('#s11 .pb[data-v="bath"]'); await pg.click('#s11 .v3d'); await pg.wait_for_timeout(300)
        await (await pg.query_selector('#s11')).screenshot(path=OUT+f'b11_2_{W}.png')
        await pg.evaluate('gotoSec("s12")'); await pg.wait_for_timeout(1500)
        await (await pg.query_selector('#s12')).screenshot(path=OUT+f'b12_h_{W}.png')
        for d in ['u','uw','d']:
            await pg.click(f'#s12 button.seg[data-v="{d}"]'); await pg.wait_for_timeout(1500)
            await (await pg.query_selector('#s12 canvas.main')).screenshot(path=OUT+f'b12_{d}_{W}.png')
        for sid in ['s13','s14']:
            await pg.evaluate(f'gotoSec("{sid}")'); await pg.wait_for_timeout(200)
            await pg.click(f'#{sid} button.b.play'); await pg.wait_for_timeout(4000)
            await (await pg.query_selector(f'#{sid} .sL')).screenshot(path=OUT+f'b{sid[1:]}_{W}.png')
        await pg.evaluate('gotoSec("s15")'); await pg.wait_for_timeout(300)
        bx=await (await pg.query_selector('#s15 canvas.main')).bounding_box()
        g=await pg.evaluate('S15.g')
        x=bx['x']+g['cx']; y=bx['y']+g['yTop']-10
        await pg.mouse.move(x,y); await pg.mouse.down(); await pg.mouse.move(x,y+60,steps=12); await pg.mouse.up(); await pg.wait_for_timeout(300)
        await pg.click('#s15 .hbtn[data-h="1"]'); await pg.wait_for_timeout(1500)
        await (await pg.query_selector('#s15 .sL')).screenshot(path=OUT+f'b15_{W}.png')
        sw=await pg.evaluate('document.documentElement.scrollWidth')
        print(json.dumps({'errs':errs,'sw':sw},ensure_ascii=False))
        await b.close()
asyncio.run(main())
