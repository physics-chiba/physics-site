import asyncio, sys
from playwright.async_api import async_playwright
async def main():
    W=int(sys.argv[1])
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--no-sandbox']); pg=await b.new_page(viewport={'width':W,'height':1000}); errs=[]
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('file:///home/claude/work/td/thermo-dynamics.html'); await pg.wait_for_timeout(400)
        await pg.evaluate('gotoSec("s12")'); await pg.wait_for_timeout(500)
        await (await pg.query_selector('#s12 .sL')).screenshot(path='test/q12h.png')
        await pg.click('#s12 [data-k=dir] [data-v=u], #s12 button[data-v=u]'); await pg.wait_for_timeout(420)
        await (await pg.query_selector('#s12 canvas.main')).screenshot(path='test/q12mid.png')
        await pg.wait_for_timeout(1500); await (await pg.query_selector('#s12 canvas.main')).screenshot(path='test/q12u.png')
        await pg.click('#s12 button[data-v=d]'); await pg.wait_for_timeout(2000); await (await pg.query_selector('#s12 canvas.main')).screenshot(path='test/q12d.png')
        await pg.click('#s12 button[data-v=uw]'); await pg.wait_for_timeout(2000); await (await pg.query_selector('#s12 canvas.main')).screenshot(path='test/q12uw.png')
        for s,sel in [('s13','.mbtn[data-m="-1"]'),('s14','.hbtn[data-h="1"]')]:
            await pg.evaluate(f'gotoSec("{s}")'); await pg.wait_for_timeout(300)
            await pg.click(f'#{s} {sel}'); await pg.wait_for_timeout(3000)
            await (await pg.query_selector(f'#{s} .sL')).screenshot(path=f'test/q{s}.png')
        await pg.evaluate('gotoSec("s15")'); await pg.wait_for_timeout(300)
        await pg.click('#s15 .mbtn[data-m="-1"]'); await pg.wait_for_timeout(1500)
        await (await pg.query_selector('#s15 .sL')).screenshot(path='test/qs15.png')
        print(errs); await b.close()
asyncio.run(main())
