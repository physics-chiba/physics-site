import asyncio, sys
from playwright.async_api import async_playwright
async def main():
    W=int(sys.argv[1])
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--no-sandbox']); pg=await b.new_page(viewport={'width':W,'height':900}); errs=[]
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('file:///home/claude/work/td/thermo-dynamics.html'); await pg.wait_for_timeout(400)
        for s in ['s22','s23','s24']:
            await pg.evaluate(f'gotoSec("{s}")'); await pg.wait_for_timeout(400)
            await (await pg.query_selector(f'#{s} canvas.main')).screenshot(path=f'test/z_{s}_{W}.png')
        print(errs); await b.close()
asyncio.run(main())
