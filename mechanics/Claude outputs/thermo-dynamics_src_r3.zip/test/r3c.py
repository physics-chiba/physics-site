import asyncio, sys
from playwright.async_api import async_playwright
async def main():
    W=int(sys.argv[1])
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--no-sandbox']); pg=await b.new_page(viewport={'width':W,'height':1000}); errs=[]
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('file:///home/claude/work/td/thermo-dynamics.html'); await pg.wait_for_timeout(400)
        await pg.evaluate('gotoSec("s21")'); await pg.wait_for_timeout(300)
        await pg.click('#s21 .pt21[data-p="1"] button.play'); await pg.wait_for_timeout(6000)
        await (await pg.query_selector('#s21')).screenshot(path=f'test/u21a_{W}.png')
        await pg.evaluate('S21.run.t=10.95'); await pg.wait_for_timeout(800)
        await pg.click('#s21 .pt21[data-p="2"] button.play'); await pg.evaluate('S21.run2.t=12.9'); await pg.wait_for_timeout(900)
        await (await pg.query_selector('#s21')).screenshot(path=f'test/u21b_{W}.png')
        for s in ['s22','s23','s24']:
            await pg.evaluate(f'gotoSec("{s}")'); await pg.wait_for_timeout(300)
            if s=='s22':
                await pg.click('#s22 button.play'); await pg.wait_for_timeout(4000)
            await (await pg.query_selector(f'#{s} .sL')).screenshot(path=f'test/u{s}_{W}.png')
        print(errs); await b.close()
asyncio.run(main())
