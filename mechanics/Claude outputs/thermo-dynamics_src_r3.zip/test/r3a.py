import asyncio, sys
from playwright.async_api import async_playwright
async def main():
    W=int(sys.argv[1])
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--no-sandbox']); pg=await b.new_page(viewport={'width':W,'height':1000}); errs=[]
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('file:///home/claude/work/td/thermo-dynamics.html'); await pg.wait_for_timeout(400)
        await pg.evaluate('gotoSec("s11")'); await pg.wait_for_timeout(300)
        s='#s11'
        await pg.click(f'{s} #bPlay'); await pg.wait_for_timeout(1200)
        await pg.click(f'{s} .seg2[data-g=cont] .pb[data-v=ins]'); await pg.wait_for_timeout(200)
        await pg.click(f'{s} .hbtn[data-h="-1"]'); await pg.wait_for_timeout(500)
        await (await pg.query_selector(s)).screenshot(path='test/r3_11a.png')
        await pg.click(f'{s} .seg2[data-g=pis] .pb[data-v=free]'); await pg.click(f'{s} .seg2[data-g=cont] .pb[data-v=bath]'); await pg.wait_for_timeout(1200)
        await pg.click(f'{s} .v3d'); await pg.wait_for_timeout(300)
        await (await pg.query_selector(f'{s} canvas.main')).screenshot(path='test/r3_11b.png')
        await pg.click(f'{s} .seg2[data-g=cont] .pb[data-v=ins]'); await pg.click(f'{s} .hbtn[data-h="1"]'); await pg.wait_for_timeout(500)
        await (await pg.query_selector(f'{s} canvas.main')).screenshot(path='test/r3_11c.png')
        await pg.evaluate('gotoSec("s15")'); await pg.wait_for_timeout(300)
        await (await pg.query_selector('#s15 .prepbox')).screenshot(path='test/r3_15p.png')
        print(errs); await b.close()
asyncio.run(main())
