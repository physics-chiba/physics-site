import asyncio, sys
from playwright.async_api import async_playwright
async def main():
    W=int(sys.argv[1])
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--no-sandbox']); pg=await b.new_page(viewport={'width':W,'height':1000}); errs=[]
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('file:///home/claude/work/td/thermo-dynamics.html'); await pg.wait_for_timeout(400)
        await pg.evaluate('gotoSec("s31")'); await pg.wait_for_timeout(300)
        await pg.click('#s31 button.seg[data-v=A]'); await pg.click('#s31 .mbtn[data-m="1"]'); await pg.wait_for_timeout(3500)
        await (await pg.query_selector('#s31 .sL')).screenshot(path=f'test/w31_{W}.png')
        await pg.evaluate('gotoSec("s32")'); await pg.wait_for_timeout(300)
        await pg.click('#s32 .hbtn[data-h="1"]'); await pg.wait_for_timeout(3500)
        await (await pg.query_selector('#s32')).screenshot(path=f'test/w32_{W}.png')
        await pg.evaluate('gotoSec("s33")'); await pg.wait_for_timeout(300)
        await pg.click('#s33 button.play'); await pg.wait_for_timeout(6500)
        await (await pg.query_selector('#s33')).screenshot(path=f'test/w33_{W}.png')
        await pg.evaluate('gotoSec("s42")'); await pg.wait_for_timeout(300)
        await (await pg.query_selector('#s42 canvas.main')).screenshot(path=f'test/w42_{W}.png')
        print(errs); await b.close()
asyncio.run(main())
