import asyncio, sys
from playwright.async_api import async_playwright
async def main():
    W=int(sys.argv[1])
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--no-sandbox']); pg=await b.new_page(viewport={'width':W,'height':1000}); errs=[]
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('file:///home/claude/work/td/thermo-dynamics.html'); await pg.wait_for_timeout(400)
        for s,act in [('s43','play'),('s51','play'),('s52','play'),('s53','heat'),('s54','nud'),('s61','play')]:
            await pg.evaluate(f'gotoSec("{s}")'); await pg.wait_for_timeout(300)
            if act=='play':
                await pg.click(f'#{s} button.play'); await pg.wait_for_timeout(5500)
            elif act=='heat':
                await pg.click(f'#{s} .hbtn[data-h="1"]'); await pg.wait_for_timeout(8000)
            else:
                await pg.click(f'#{s} .nud[data-d="1"]'); await pg.wait_for_timeout(2500)
            await (await pg.query_selector(f'#{s} .sL')).screenshot(path=f'test/e_{s}_{W}.png')
        print(errs); await b.close()
asyncio.run(main())
