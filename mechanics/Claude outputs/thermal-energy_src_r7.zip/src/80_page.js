/* =========================================================================
   ページの骨組み：ヒーロー・タブ列・章の扉・節のカード・目次・アドレス（#1-2）
   ========================================================================= */
var MODES = [
  {id:"mode1", name:"物質と比熱", en:"Matter and Specific Heat",
   lead:"物質を作る粒子は、絶えず不規則に動いている（<b>熱運動</b>）。温度は、その熱運動の激しさを表す。同じ熱量を加えても、物質によって温度の上がり方が違う（<b>比熱</b>）。",
   secs:["s11","s12","s13","s14","s15"]},
  {id:"mode2", name:"熱と仕事", en:"Heat and Work",
   lead:"気体の内部エネルギーは、熱を加えても、仕事をしても増える（<b>熱力学第一法則</b>）。熱を仕事に変える仕組みが<b>熱機関</b>。",
   secs:["s21","s22"]},
  {id:"mode3", name:"補足 ※大学の内容", en:"Supplement (University Level)",
   lead:"絶対零度でも止まらない粒子の振動、原子が「本当にある」と人類が確信するまでの話、そして熱が関係する変化の向きを決める<b>熱力学第二法則</b>。どれも高校物理の先にある内容。",
   secs:["s30","s31","s23"]}
];
/* 第6回：③-1 は図のない読み物の節 */
var S31 = {init:function(){}, draw:function(){}};
var DEFS = {
  s11:{num:1, mode:0, title:"ブラウン運動（水の中の花粉）", short:"ブラウン運動", sim:S11,
    desc:'水に浮かべた花粉から出た小さな微粒子は、顕微鏡で見ると不規則に動き続ける（ブラウン運動）。<span class="todo">スタートを押して、「水分子を表示」を ON にしたり、温度を変えたりしてみよう。</span><br>注目点：温度が高いほど、微粒子の動きが激しくなる。',
    opts: H_chk("mol","水分子を表示",false) + H_chk("path","動いた道筋を表示",true),
    mid: H_tslider("t","水の温度",-273,100,1,20),
    right:function(){ return '<div class="qcard"><p class="qt">熱運動</p>'+
      '<p>微粒子が不規則に動くのは、周りの<b>水分子</b>がいろいろな向きから微粒子にぶつかるから。水分子のように、物質を作る粒子は、絶えず不規則に動いている。これを<b>熱運動</b>という。</p></div>'+
      '<div class="qcard"><p class="qt">温度と絶対温度</p>'+
      '<p>温度は、物体を構成する粒子の熱運動の激しさを表す。温度を下げていくと熱運動は穏やかになり、約 −273 ℃ で最も穏やかになる。これより低い温度はない（<b>絶対零度</b>）。</p>'+
      '<p>絶対零度を 0 とし、目盛りの間隔をセルシウス温度と同じにした温度が<b>絶対温度</b>（単位 K：ケルビン）。セルシウス温度 '+tex("t")+'［℃］と絶対温度 '+tex("T")+'［K］の関係は</p>'+
      '<div class="qeq">'+tex("T=t+273",true)+'</div>'+tempScaleSVG()+'</div>'+
      '<div class="qcard"><p class="qt">もっと先へ</p>'+
      '<p>本当は、<b>絶対零度でも、粒子は完全には止まらない</b>（<a href="#3-1">③-1</a>）。</p>'+
      '<p>また、このブラウン運動は、人類が初めて「原子が本当にある」ことを確かめた、<b>原子の発見</b>につながった（<a href="#3-2">③-2</a>）。</p></div>'; }},
  s12:{num:2, mode:0, title:"物質の三態", short:"物質の三態", sim:S12,
    desc:'物質は、温度と圧力によって固体・液体・気体のどれかの状態をとる（<b>物質の三態</b>）。<span class="todo">スタートを押して、スライダーで温度を上げてみよう。</span><br>注目点：固体はつりあいの位置（＋印）の周りで震え、液体は粒子同士が触れ合いながら動き回り、気体はばらばらに飛び回る。',
    opts:'',
    mid: H_tslider("u","温度　低い → 高い",0,100,1,30),
    right:function(){ return '<div class="qcard"><p class="qt">三態と粒子の運動</p>'+
      '<ol class="pts"><li><b>固体</b>：粒子は強く結びついていて、決まった位置（つりあいの位置）の周りで震えている。形が変わりにくい。</li>'+
      '<li><b>液体</b>：粒子同士は結びついているが、位置を入れ替えながら動き回る。形は自由に変わるが、体積はほぼ変わらない。</li>'+
      '<li><b>気体</b>：粒子は結びつきを振り切って、空間を自由に飛び回る。</li></ol>'+
      '<p>どの状態になるかは、粒子同士の<b>結びつきの強さ</b>と<b>熱運動の激しさ</b>のどちらが勝るかで決まる。</p></div>'; }},
  s13:{num:3, mode:0, title:"物質に加えた熱と状態変化", short:"状態変化", sim:S13,
    desc:'三脚の上のビーカーに固体 100 g を入れ、バーナーで一定の割合で熱を加える。<span class="todo">右上のボタンで「水」か「エタノール」を選び、スタートを押そう。時間バーで戻したり進めたりもできる。</span><br>注目点：とけている間と、沸騰している間は、熱を加えても温度が上がらない。',
    opts:'',
    mid: H_timebar(),
    right:function(){ return '<div class="qcard"><p class="qt">融解熱と蒸発熱</p>'+
      '<p>とけている間（融解）と、沸騰している間（蒸発）は、加えた熱が<b>粒子の結びつきを切ること</b>に使われるので、温度は上がらない。</p>'+
      '<p>融点で固体 1 g を液体にするのに必要な熱量が<b>融解熱</b>、沸点で液体 1 g を気体にするのに必要な熱量が<b>蒸発熱</b>。</p>'+
      '<table class="nstab"><tr><td></td><td>融点</td><td>沸点</td><td>融解熱</td><td>蒸発熱</td></tr><tr><td>水</td><td>0 ℃</td><td>100 ℃</td><td>334 J/g</td><td>2257 J/g</td></tr><tr><td>エタノール</td><td>−114 ℃</td><td>78 ℃</td><td>109 J/g</td><td>838 J/g</td></tr></table>'+
      '<p>融解熱・蒸発熱を '+tex("L")+'［J/g］とすると、質量 '+tex("m")+'［g］の物質の状態を変えるのに必要な熱量 '+tex("Q")+'［J］は</p>'+
      '<div class="qeq">'+tex("Q=mL",true)+'</div>'+
      '<div class="stp"><p class="sh"><b>見るポイント</b></p><p>グラフの横幅は、実際の熱量の比のまま。水を全部水蒸気にするには、0 ℃ の水を 100 ℃ にするときの 5 倍以上の熱が必要（沸騰の間は早送りしている）。</p>'+
      '<p>拡大の窓では、液面から飛び出した気体の粒子が、窓の外（空気中）へ飛んでいく。湯気（白いもや）は水蒸気が冷えてできた小さな水滴で、水蒸気そのものは目に見えない。</p></div></div>'; }},
  s14:{num:4, mode:0, title:"比熱", short:"比熱", sim:S14, full:true, playFirst:true,
    desc:'水と別の物質に、同じバーナーで同じ熱量を加える。<span class="todo">右の物質（比熱）と質量をスライダーで選んで、スタートを押そう。一番右は水なので、同じ物質同士でも比べられる。</span><br>注目点：水は温度が上がりにくい（比熱が大きい）。',
    opts:'',
    sliders: '<div class="duo"><div class="duoL"><span>左（比べる基準）</span><b>水 1.0 kg（初め 20 ℃）</b><span>比熱 4.18 J/(g·K)</span></div><div class="duoR">'+
      H_slider("sub","右の物質",0,SUBS.length-1,1,2)+cTicks(SUBS)+H_slider("mass","右の質量",0.5,2,0.1,1)+'</div></div>',
    mid: H_timebar(),
    right:function(){ return '<div class="qcard"><p class="qt">熱容量と比熱</p>'+
      '<p>物体の温度を 1 K 上げるのに必要な熱量を、その物体の<b>熱容量</b> '+tex("C")+'［J/K］という。物体に熱量 '+tex("Q")+'［J］を加えて温度が '+tex("\\Delta T")+'［K］上がるとき</p>'+
      '<div class="qeq">'+tex("Q=C\\Delta T",true)+'</div>'+
      '<p>物質 1 g の温度を 1 K 上げるのに必要な熱量を、その物質の<b>比熱</b> '+tex("c")+'［J/(g·K)］という。質量 '+tex("m")+'［g］の物体では '+tex("C=mc")+' なので</p>'+
      '<div class="qeq">'+tex("Q=mc\\Delta T",true)+'</div>'+
      '<div class="stp"><p class="sh"><b>見るポイント</b></p><p>同じ熱量を加えると、比熱が小さい物質ほど温度が大きく上がる。質量を 2 倍にすると熱容量も 2 倍になり、温度の上がり方は半分になる。</p>'+
      '<p>水の比熱はとても大きい。そのため、海の近くでは 1 日の気温の変化が小さい。</p></div></div>'; }},
  s15:{num:5, mode:0, title:"熱平衡（熱量の保存）", short:"熱平衡", sim:S15, full:true,
    desc:'温度の違う 2 つの物体を触れさせると、高温の物体から低温の物体へ熱が移り、やがて同じ温度になる（<b>熱平衡</b>）。<span class="todo">「固体同士」「固体と液体」と、右の物質・質量を選んで、スタートを押そう。</span><br>注目点：熱の矢印の中を流れる点が「移っていく熱」。温度の差が小さくなるほど、流れはゆっくりになる。',
    opts: H_seg("kind","組み合わせ",[["ss","固体同士"],["sl","固体と液体"]],"ss") + H_chk("lid","ふたを開ける",false),
    playFirst:true,     /* 第6回：スタートなどは、スライダーの上に置く */
    sliders: '<div class="duo"><div class="duoL"><span>左（高温・固定）</span><b>鉄 1.0 kg　80 ℃</b><span>比熱 0.448 J/(g·K)</span></div><div class="duoR"><p class="duonote">右は初め 20 ℃</p>'+
      H_slider("sub","右の物質",0,5,1,4)+'<div class="cticks"></div>'+H_slider("mass","右の質量",0.5,2,0.1,1)+'</div></div>',
    mid: H_timebar(),
    right:function(){ return '<div class="qcard"><p class="qt">熱量の保存</p>'+
      '<p>外との間で熱の出入りがなければ</p>'+
      '<div class="qeq">'+tex("\\text{高温の物体が失った熱量}=\\text{低温の物体が得た熱量}",true)+'</div>'+
      '<p>これを<b>熱量の保存</b>という。熱容量 '+tex("C_\\mathrm{A}")+'、温度 '+tex("t_\\mathrm{A}")+' の物体 A と、熱容量 '+tex("C_\\mathrm{B}")+'、温度 '+tex("t_\\mathrm{B}")+' の物体 B（'+tex("t_\\mathrm{A}>t_\\mathrm{B}")+'）が、温度 '+tex("t")+' で熱平衡になったとすると</p>'+
      '<div class="qeq">'+tex("C_\\mathrm{A}(t_\\mathrm{A}-t)=C_\\mathrm{B}(t-t_\\mathrm{B})",true)+'</div>'+
      '<p>質量と比熱で書くと '+tex("m_1c_1(t_1-t)=m_2c_2(t-t_2)")+'。</p>'+
      '<div class="stp"><p class="sh"><b>見るポイント</b></p><p>熱容量の大きい物体の温度の方が変わりにくい。2 つの温度の差が小さくなるほど、熱の移り方はゆっくりになる。</p>'+
      '<p>ふたを開けると、熱が外へ逃げるので、熱量の保存は成り立たない。最後は 2 つとも室温に近づく。</p></div></div>'; }},
  s21:{num:1, mode:1, title:"熱力学第一法則", short:"第一法則", sim:S21,
    desc:'ピストンのついたシリンダーの中の気体。気体の分子の運動エネルギーの和が<b>内部エネルギー</b> '+tex("U")+'。<span class="todo">操作を 1 つ選んでスタート（操作のたびに、初めの状態に戻る）。上下の図は連動する。</span><br>注目点：熱 '+tex("Q")+' でも、仕事 '+tex("W")+' でも、内部エネルギーは変わる。いつでも '+tex("\\Delta U=Q+W")+'。下の図は、同じ変化を気体がした仕事 '+tex("W'")+' で表したもの。',
    opts: H_seg("act","操作",[["heat","気体に熱を与える（ピストン固定）"],["cool","気体の熱を奪う（ピストン固定）"],["free","気体に熱を与える（ピストンは自由）"],["freecool","気体の熱を奪う（ピストンは自由）"],["push","気体に正の仕事をする"],["pull","気体に負の仕事をする"]],"heat"),
    right:function(){ return '<div class="qcard"><p class="qt">熱力学第一法則</p>'+
      '<p>気体が外から熱量 '+tex("Q")+'［J］を得て、外から仕事 '+tex("W")+'［J］をされると、内部エネルギーの変化 '+tex("\\Delta U")+'［J］は</p>'+
      '<div class="qeq">'+tex("\\Delta U=Q+W",true)+'</div>'+
      '<p>これを<b>熱力学第一法則</b>という。熱も含めたエネルギー保存則にあたる。</p>'+
      '<div class="stp"><p class="sh"><b>見るポイント</b>ピストンにぶつかった分子</p><p>ピストンを押しているときは、近づいてくるピストンにぶつかった分子が、跳ね返って速くなる。ピストンを引いているときは、遠ざかるピストンにぶつかった分子が遅くなる。</p></div>'+
      '<div class="stp"><p class="sh"><b>気体がした仕事 '+tex("W'")+'</b></p><p>気体がされた仕事 '+tex("W")+' と、気体がした仕事 '+tex("W'")+' の間には '+tex("W=-W'")+' の関係がある。これを使うと</p>'+
      '<div class="qeq">'+tex("Q=\\Delta U+W'",true)+'</div><p>気体が得た熱は、内部エネルギーの増加と、気体が外にした仕事に使われる。</p></div></div>'; }},
  s22:{num:2, mode:1, title:"熱機関と熱効率", short:"熱機関", sim:S22,
    desc:'熱を受け取って仕事をし、残りの熱を低温の物体に捨てる仕組みが<b>熱機関</b>。<span class="todo">ランプから受け取る熱量 '+tex("Q_\\mathrm{in}")+' を決めて、スタートを押そう。</span><br>注目点：熱効率 '+tex("e")+' が大きいほど、同じ熱から大きな仕事が取り出せる。',
    opts:'',
    sliders: H_slider("qin","熱機関が受け取る熱量 $Q_\\mathrm{in}$",1,10,1,5),
    right:function(){ return '<div class="qcard"><p class="qt">熱効率</p>'+
      '<p>熱機関が高温の物体から受け取った熱量を '+tex("Q_\\mathrm{in}")+'、低温の物体へ放出した熱量を '+tex("Q_\\mathrm{out}")+'、熱機関がした仕事を '+tex("W'")+' とすると、'+tex("W'=Q_\\mathrm{in}-Q_\\mathrm{out}")+'。受け取った熱量のうち仕事に変わった割合が<b>熱効率</b> '+tex("e")+'：</p>'+
      '<div class="qeq">'+tex("e=\\dfrac{W'}{Q_\\mathrm{in}}=\\dfrac{Q_\\mathrm{in}-Q_\\mathrm{out}}{Q_\\mathrm{in}}",true)+'</div>'+
      '<table class="nstab"><tr><td>蒸気機関</td><td>0.10〜0.20</td></tr><tr><td>ガソリン機関</td><td>0.20〜0.40</td></tr><tr><td>ディーゼル機関</td><td>0.30〜0.45</td></tr></table>'+
      '<div class="stp"><p class="sh"><b>見るポイント</b></p><p>熱機関は、必ず熱の一部 '+tex("Q_\\mathrm{out}")+' を低温の物体に捨てる。'+tex("Q_\\mathrm{out}=0")+'（'+tex("e=1")+'）の熱機関は作れない（→ ③-3）。</p></div></div>'; }},
  s30:{num:1, mode:2, title:"絶対零度でも、粒子は完全には止まらない", short:"ゼロ点振動", sim:S30,
    desc:'高校物理では「絶対零度で熱運動が止まる」と考えてよい。しかし、原子や分子のようなミクロの世界を詳しく調べると（量子力学）、絶対零度でも粒子は震え続けている。<span class="todo">スタートを押して、温度を 0 K まで下げてみよう。「量子力学を考えない（古典的な考え）」と比べよう。</span><br>注目点：量子力学では、温度を下げても、振動のエネルギーは '+tex("\\tfrac{1}{2}h\\nu")+' より小さくならない。',
    opts: H_chk("classic","量子力学を考えない（古典的な考え）",false),
    mid: H_tslider("T","温度〔K〕",0,300,1,300),
    right:function(){ return '<div class="qcard"><p class="qt">ゼロ点振動</p>'+
      '<p>高校物理では「絶対零度で熱運動が止まる」と考えてよい。しかし、原子や分子のようなミクロの世界を詳しく調べると（量子力学）、絶対零度でも粒子はわずかに震え続けている。これを<b>ゼロ点振動</b>という。</p>'+
      '<p>ゼロ点振動のエネルギーは、温度を下げても取り去ることができない、一番低いエネルギー。だから絶対零度は「熱運動が一番穏やかになる温度」と言う方が正確。例えばヘリウムは、ゼロ点振動のために、大気圧のもとでは絶対零度近くまで冷やしても固体にならない。</p></div>'+
      '<div class="qcard"><p class="qt">エネルギーの階段</p><p>量子力学では、ばねにつながれた粒子のように振動するもののエネルギーは、とびとびの値 '+tex("\\left(n+\\tfrac{1}{2}\\right)h\\nu")+'（'+tex("n=0,1,2,\\cdots")+'）しかとれない（'+tex("\\nu")+'：振動数、'+tex("h")+'：プランク定数）。一番下の段（'+tex("n=0")+'）でも '+tex("\\tfrac{1}{2}h\\nu")+' のエネルギーが残る。</p>'+
      '<p>温度が高いと、量子力学の曲線は古典的な考え（エネルギーは温度に比例）とほぼ重なる。違いが目立つのは、低温のときだけ。</p></div>'; }},
  s31:{num:2, mode:2, title:"だれが原子を見たか", short:"だれが原子を見たか", sim:S31, static:true,
    desc:'原子は小さすぎて、ふつうの顕微鏡では見えない。それなのに、人類はどうして「原子は本当にある」と確信できたのだろうか。その決め手になったのが、①-1 の<b>ブラウン運動</b>だった。',
    body:function(){ return '<div class="qcard"><p class="qt">原子論の始まり（ドルトン）</p>'+
      '<p>1803 年ごろ、イギリスの<b>ドルトン</b>は「物質は、それ以上分けられない小さな粒＝<b>原子</b>からできている」という<b>原子論</b>を唱えた。化学反応で物質の質量が決まった比で結びつくことなどが、原子を考えるとうまく説明できた。</p>'+
      '<p>しかし、原子は誰も直接見たことがない。19 世紀の終わりになっても、マッハやオストワルドのように「原子は計算に便利な考え方にすぎない。本当にあるとは言えない」と考える科学者も少なくなかった。</p></div>'+
      '<div class="qcard"><p class="qt">花粉の中の微粒子の不思議な動き（ブラウン）</p>'+
      '<p>1827 年、イギリスの植物学者<b>ブラウン</b>は、水に浮かべた花粉から出た小さな微粒子が、顕微鏡の中で止まることなく不規則に動き続けることに気づいた。初めは「生きているから動く」と考えたが、生き物ではない細かい粒（岩石の粉など）でも同じように動くことが分かった。なぜ動くのかは、その後長い間なぞのままだった。</p></div>'+
      '<div class="qcard"><p class="qt">アインシュタインの説明（1905 年）</p>'+
      '<p>1905 年、<b>アインシュタイン</b>は「微粒子が動くのは、目に見えない水分子が、あらゆる向きから微粒子にぶつかっているからだ」と考え、それを数式で表した。水分子の熱運動を考えると、微粒子がある時間にどれくらい移動するかが<b>計算で予想できる</b>。しかも、その移動の大きさを測れば、1 mol の中の分子の数（<b>アボガドロ定数</b>）が求められる。</p>'+
      '<p>つまり、目に見える微粒子の動きを調べることで、目に見えない分子の数を数えられる、という予言だった。</p></div>'+
      '<div class="qcard"><p class="qt">原子の実在が確かめられる（ペラン）</p>'+
      '<p>1908 年ごろから、フランスの<b>ペラン</b>は、大きさのそろった微粒子を作り、顕微鏡でブラウン運動を丁寧に測定した。結果はアインシュタインの予想とぴったり合い、求めたアボガドロ定数は、ほかのまったく違う方法で求めた値ともよく一致した。</p>'+
      '<p>こうして、原子・分子が本当にあることを、ほとんどの科学者が認めるようになった。原子を疑っていたオストワルドも、原子の実在を認めた。ペランはこの研究で 1926 年にノーベル物理学賞を受けた。<b>人類は、ブラウン運動を通して、初めて原子を「見た」</b>といえる。</p></div>'; },
    right:function(){ return '<div class="qcard"><p class="qt">年表</p><table class="nstab">'+
      '<tr><td>1803 年ごろ</td><td>ドルトンが原子論を唱える</td></tr>'+
      '<tr><td>1827 年</td><td>ブラウンが、花粉から出た微粒子の不規則な動きを発見</td></tr>'+
      '<tr><td>1905 年</td><td>アインシュタインが、ブラウン運動を分子の熱運動で説明し、移動の大きさを予想</td></tr>'+
      '<tr><td>1908 年ごろ〜</td><td>ペランの実験で予想が確かめられ、原子・分子の実在が認められる</td></tr>'+
      '<tr><td>1926 年</td><td>ペランがノーベル物理学賞</td></tr></table></div>'+
      '<div class="qcard hatten"><p class="qt">＜発展＞ アインシュタインの関係式</p>'+
      '<p>微粒子が時間 '+tex("t")+' の間に、ある方向へ移動した距離 '+tex("x")+' の 2 乗の平均は、時間に比例する。</p>'+
      '<div class="qeq">'+tex("\\langle x^2\\rangle=2Dt,\\qquad D=\\dfrac{RT}{6\\pi\\eta a N_\\mathrm{A}}",true)+'</div>'+
      '<p>'+tex("D")+'：拡散係数、'+tex("R")+'：気体定数、'+tex("T")+'：絶対温度、'+tex("\\eta")+'：水の粘性率、'+tex("a")+'：微粒子の半径、'+tex("N_\\mathrm{A}")+'：アボガドロ定数。'+tex("\\langle x^2\\rangle")+' を測れば '+tex("N_\\mathrm{A}")+' が求められる。移動の距離は時間に比例せず、時間の平方根に比例して広がる（①-1 の道筋が「行ったり来たり」になる理由）。</p></div>'+
      '<div class="qcard"><p class="qt">もっと知りたい人へ</p><p>江沢洋『だれが原子をみたか』（岩波書店）に、この話が詳しく書かれている。</p></div>'; }},
  s23:{num:3, mode:2, title:"熱力学第二法則", short:"第二法則", sim:S23, mid: H_timebar(),
    desc:'熱が関係する現象には「ひとりでには、逆向きに起こらない」という向きがある（<b>不可逆変化</b>）。その向きを決めるのが熱力学第二法則。<span class="todo">スタートを押そう。最後まで進むと、続けて逆再生が始まる。「逆向きに再生する」を ON にすると、初めから逆再生だけを見られる。</span><br>注目点：逆再生中のアニメも、エネルギー保存則には反していない。',
    opts: H_chk("rev","逆向きに再生する",false),
    right:function(){ return '<div class="qcard"><p class="qt">熱力学第二法則のいろいろな表し方</p>'+
      '<table class="nstab"><tr><td><b>クラウジウスの原理</b></td><td>熱は、低温の物体から高温の物体へ、ひとりでには移らない。</td></tr>'+
      '<tr><td><b>トムソン（ケルビン）の原理</b></td><td>熱を全て仕事に変える熱機関は作れない（②-2 の '+tex("e=1")+' の車）。</td></tr>'+
      '<tr><td><b>オストワルドの表現</b></td><td>第二種永久機関（熱を 100 % 仕事に変え続ける機関）は存在しない。</td></tr>'+
      '<tr><td><b>エントロピー増大の法則</b></td><td>外とエネルギーのやり取りをしない系（孤立系）では、<b>エントロピー</b>（乱雑さの度合い）は増える方向にしか変化しない。</td></tr></table>'+
      '<p>どれも同じ法則を別の言葉で言ったもの。上の 3 つは熱の流れや熱機関の効率について述べ、エントロピー増大の法則は、自然に起こる変化の向きを量で表している。</p></div>'+
      '<div class="qcard"><p class="qt">エントロピー増大の例</p><ol class="pts">'+
      '<li>仕切りを外すと、気体は容器全体に広がる。ひとりでに元の片側に集まることはない。</li>'+
      '<li>熱いコーヒーは、周りの空気に熱を渡して冷めていく。ひとりでに元の温度に戻ることはない（①-5 の熱平衡）。</li>'+
      '<li>コーヒーにミルクを入れると混ざる。ひとりでに分かれることはない。</li></ol>'+
      '<p>「エネルギーは保存されるが、使える形のエネルギーは一方的に減っていく」と言うこともできる。</p></div>'+'<div class="qcard"><p class="qt">高校物理とのつながり</p>'+
      '<p>熱力学第一法則（②-1）はエネルギーの<b>量</b>についての法則、第二法則は変化の<b>向き</b>についての法則。</p>'+
      '<p>熱力学には、ほかに第 0 法則（A と B、B と C がそれぞれ熱平衡なら、A と C も熱平衡）と、第三法則（絶対零度ではエントロピーが 0 になる）もある。</p>'+
      '<div class="stp"><p class="sh"><b>勉強したい人は、詳しくはこちら</b></p><ul class="links">'+
      '<li><a href="https://jp.dreamscope.me/blog/2021/4/entropy" target="_blank" rel="noopener">エントロピー増大の法則とは？（簡単な説明）↗</a></li>'+
      '<li><a href="https://ja.wikipedia.org/wiki/%E7%86%B1%E5%8A%9B%E5%AD%A6%E7%AC%AC%E4%BA%8C%E6%B3%95%E5%89%87" target="_blank" rel="noopener">熱力学第二法則（ウィキペディア）↗</a></li></ul></div></div>'; }}
};
/* 絶対温度とセルシウス温度の目盛り（右の列の小さな図） */
function tempScaleSVG(){
  var row=function(y,c,k,b){ return '<line x1="104" y1="'+y+'" x2="206" y2="'+y+'" stroke="#c9ced6" stroke-dasharray="3 3"/><text x="96" y="'+(y+4)+'" text-anchor="end" font-size="12"'+(b?' font-weight="700"':'')+'>'+c+'</text><text x="214" y="'+(y+4)+'" font-size="12"'+(b?' font-weight="700"':'')+'>'+k+'</text>'; };
  return '<svg class="tscale" viewBox="0 0 340 170" role="img" aria-label="セルシウス温度と絶対温度の目盛りの対応"><text x="96" y="14" text-anchor="end" font-size="11" fill="#69717d">セルシウス温度</text><text x="214" y="14" font-size="11" fill="#69717d">絶対温度</text>'+
    '<rect x="140" y="24" width="40" height="130" rx="6" fill="#fdf4e8" stroke="#e07b18"/>'+row(32,"100 ℃","373 K")+row(70,"0 ℃","273 K")+row(150,"−273 ℃","0 K（絶対零度）",true)+'</svg>';
}
var CIRC = "①②③④⑤⑥⑦⑧⑨";
var GLOBAL = {hideEq:false};

function secAddr(sid){ var d=DEFS[sid]; return (d.mode+1)+"-"+d.num; }
function secHTML(sid, first){
  var d=DEFS[sid], num=CIRC[d.mode]+"-"+d.num;
  var head='<div class="sechead"><span class="secnum">'+num+'</span><h2>'+d.title+'</h2>'+(d.headBtn||'')+'</div><div class="secdesc">'+d.desc+'</div>';
  if(d.static){
    return '<article class="sec" id="'+sid+'"><div class="sL">'+head+d.body()+'</div><div class="sR">'+d.right()+'</div></article>';
  }
  if(!d.wide){
    return '<article class="sec'+(d.full? ' full' : '')+'" id="'+sid+'"><div class="sL">'+head+
      '<div class="ctrls">'+(d.opts? '<div class="row1 row1b">'+H_reset()+d.opts+'</div>' : '')+(d.playFirst? H_play(first, d.mid, d.opts? '' : H_reset()) : '')+(d.sliders? '<div class="row2 sliders'+(d.sliderCls? ' '+d.sliderCls : '')+'">'+d.sliders+'</div>' : '')+(d.noplay||d.playFirst? '' : H_play(first, d.mid, d.opts? '' : H_reset()))+'</div>'+
      (d.nocanvas? '' : '<div class="cvwrap"><canvas class="main"></canvas></div>')+'<div class="msgbox"'+(d.nocanvas?' hidden':'')+'></div>'+(d.leftBelow? d.leftBelow() : '')+'</div>'+
      '<div class="sR">'+d.right()+'</div></article>';
  }
  var cells=d.cells.map(function(cc,i){ return '<div class="fcell pick'+(i===0?' on':'')+'" data-v="'+cc[0]+'" tabindex="0" role="button" aria-pressed="'+(i===0)+'"><p class="fcap">('+"abc"[i]+') '+cc[1]+'<small>'+cc[2]+'</small></p><canvas data-v="'+cc[0]+'"></canvas></div>'; }).join("");
  return '<article class="sec wide" id="'+sid+'"><div class="sL">'+head+
    (d.opts? '<div class="ctrls"><div class="row1 row1b">'+d.opts+'</div></div>' : '')+
    '<div class="fourgrid">'+cells+'<div class="fcell live"><div class="livehead"><p class="fcap">＜実際の動き＞</p>'+H_reset()+'</div>'+(d.live? '<div class="ctrls liveopts">'+d.live+'</div>' : '')+H_play(first)+
    '<div class="cvwrap"><canvas class="main"></canvas></div><p class="flegend"><span style="color:'+COL.grav+'">● 重力 <i>mg</i></span><span style="color:'+COL.buoy+'">● 浮力 <i>F</i></span><span style="color:'+COL.norm+'">● 垂直抗力 <i>N</i></span><span style="color:'+COL.press+'">→ '+(d.kind==="air"? "大気圧":"液体の圧力")+'</span></p><table class="forcetab"></table></div></div>'+
    '<p class="pickhint">👆 (a)〜(c) をクリックすると、＜実際の動き＞の表示が変わる（重力はいつも表示）。</p>'+
    '<div class="msgbox"></div><div class="widebelow">'+d.below()+'</div></div></article>';
}

function buildPage(){
  var EN = "Heat and Energy";
  var atom='<svg class="atom" viewBox="0 0 32 32" aria-hidden="true"><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#3ea0e0" stroke-width="2"/><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#7b5bd6" stroke-width="2" transform="rotate(60 16 16)"/><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#e07b18" stroke-width="2" transform="rotate(120 16 16)"/><circle cx="16" cy="16" r="3.6" fill="#5aa7ff"/></svg>';
  document.getElementById("hero").innerHTML =
    '<div class="hero-in"><div class="hero-top"><nav class="crumbs" aria-label="現在地"><a class="crumb-home" href="'+SITE_HOME+'" title="楽楽（らくらく）高校物理のトップページへ">'+atom+'<span>楽楽（らくらく）高校物理</span></a><span class="cs" aria-hidden="true">/</span><a class="crumb" href="'+SITE_HOME+'#sec-mechanics">力学</a><span class="cs" aria-hidden="true">/</span><span class="crumb now" aria-current="page">熱とエネルギー</span><span class="kdot"></span><span class="en">'+EN+'</span></nav>'+
    '<div class="topbtns" role="group" aria-label="ページ全体の表示"><button id="btnEq" type="button"></button></div></div>'+
    '<h1 class="hero-title"><span class="t1"><span class="nb">熱と</span><span class="nb">エネルギー</span></span><span class="t2">〜熱運動・比熱・熱力学第一法則〜</span></h1>'+
    '<div class="introrow"><p class="lead2">物質を作る粒子は、絶えず動いている。温度はその動きの激しさ。熱はエネルギーの移動で、仕事と同じように物体のエネルギーを変える。</p>'+
    '<button id="bToc" class="tocbtn" type="button" aria-haspopup="true" aria-expanded="false"><span class="ti" aria-hidden="true"></span>コンテンツ一覧</button></div>'+
    '<div id="tocpanel" class="tocpanel" hidden></div>'+
    '<figure class="stage" aria-label="高温の物体と低温の物体を触れさせると、熱が移動し、粒子の震え方が同じになって止まる"><canvas id="heroCv"></canvas>'+
    '<figcaption class="stagecap"><span class="live" aria-hidden="true"></span><span class="sct">高温の物体 A と低温の物体 B を触れさせる。A の粒子の激しい震えが B に伝わり、熱 '+tex("Q")+' が A から B へ移る。2 つの温度が同じになると、熱の移動は止まる（熱平衡）。</span>'+
    '<span class="stagectl" role="group" aria-label="アニメの操作"><button type="button" class="slow" aria-pressed="false" title="ゆっくり再生">🐢 スロー</button><button type="button" class="pp" aria-label="一時停止"><i></i></button></span></figcaption></figure>'+
    '<ol class="ideas">'+
    '<li><a href="#1-1"><span class="in" aria-label="①"><b>1</b></span><span class="ie">'+tex("T=t+273")+'</span><span class="ij">温度は熱運動の激しさ</span><span class="ia" aria-hidden="true">→</span></a></li>'+
    '<li><a href="#1-4"><span class="in" aria-label="②"><b>2</b></span><span class="ie">'+tex("Q=mc\\Delta T")+'</span><span class="ij">比熱が大きいほど温まりにくい</span><span class="ia" aria-hidden="true">→</span></a></li>'+
    '<li><a href="#2-1"><span class="in" aria-label="③"><b>3</b></span><span class="ie">'+tex("\\Delta U=Q+W")+'</span><span class="ij">熱と仕事で内部エネルギーが変わる</span><span class="ia" aria-hidden="true">→</span></a></li></ol></div>';

  document.getElementById("tabs").innerHTML='<div class="tabs-in"><div class="navsite"><a class="navhome" href="'+SITE_HOME+'" aria-label="ホーム（楽楽高校物理のトップページ）" title="ホーム（楽楽高校物理のトップページ）"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3.5 10.8 12 4l8.5 6.8" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M6 9.5V20h4.5v-5.5h3V20H18V9.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg></a><button class="navpages" id="bPages" type="button" aria-haspopup="dialog" aria-expanded="false" aria-controls="siteDrawer"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="3.5" width="7" height="7" rx="1.6" fill="currentColor"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.6" fill="currentColor" opacity=".55"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.6" fill="currentColor" opacity=".55"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.6" fill="currentColor"/></svg><span>ページ一覧</span></button></div>'+
    MODES.map(function(m,i){ return '<button class="tab" type="button" data-mode="'+m.id+'"><span class="tn">'+CIRC[i]+'</span><span class="tl">'+m.name+'</span></button>'; }).join("")+'</div><span class="tprog" aria-hidden="true"></span>';

  var h="", first=true;
  MODES.forEach(function(m,i){
    h+='<section class="mode" id="'+m.id+'"><header class="modehead"><div class="mh-num" aria-hidden="true"><span>'+(i+1)+'</span></div><div class="mh-body"><p class="mh-en">Chapter '+String(i+1).padStart(2,"0")+' — '+m.en+'</p><h2><span class="mh-c">'+CIRC[i]+'</span>'+m.name+'</h2><p class="mh-lead">'+m.lead+'</p></div></header>'+
       '<div class="seclinks">'+m.secs.map(function(s){ return '<a href="#'+secAddr(s)+'" data-toc="'+s+'">'+CIRC[i]+'-'+DEFS[s].num+'　'+DEFS[s].short+'</a>'; }).join("")+'</div>';
    m.secs.forEach(function(s){ h+=secHTML(s, first); first=false; });
    h+='</section>';
  });
  h+='<div class="card purpose"><p class="lead">このページの目的</p><ol>'+
     '<li>温度は粒子の熱運動の激しさを表すこと、絶対温度 '+tex("T=t+273")+' を知る。</li>'+
     '<li>状態変化の間は温度が変わらないこと（融解熱・蒸発熱）を、グラフと粒子のようすで確かめる。</li>'+
     '<li>比熱・熱容量（'+tex("Q=mc\\Delta T")+'）と、熱平衡での熱量の保存を確かめる。</li>'+
     '<li>熱力学第一法則 '+tex("\\Delta U=Q+W")+' と、熱機関の熱効率 '+tex("e=\\dfrac{W'}{Q_\\mathrm{in}}")+' を理解する。</li></ol></div>';
  h+='<footer></footer>';
  document.getElementById("wrap").innerHTML=h;

  /* 目次 */
  var tp=document.getElementById("tocpanel");
  tp.innerHTML='<div class="tochead"><b>コンテンツ一覧</b><button type="button" class="tocx" aria-label="閉じる">×</button></div>'+
    MODES.map(function(m,i){ return '<div class="tocmode">'+CIRC[i]+' '+m.name+'</div><ul>'+m.secs.map(function(s){ return '<li><a href="#'+secAddr(s)+'" data-toc="'+s+'">'+CIRC[i]+'-'+DEFS[s].num+' '+DEFS[s].title+'</a></li>'; }).join("")+'</ul>'; }).join("");
  var bT=document.getElementById("bToc");
  var closeToc=function(){ tp.hidden=true; bT.setAttribute("aria-expanded","false"); };
  bT.addEventListener("click", function(ev){ ev.stopPropagation(); tp.hidden=!tp.hidden; bT.setAttribute("aria-expanded", tp.hidden?"false":"true"); });
  tp.querySelector(".tocx").addEventListener("click", closeToc);
  document.addEventListener("click", function(ev){ if(!tp.hidden && !tp.contains(ev.target) && ev.target!==bT) closeToc(); });
  document.addEventListener("keydown", function(ev){ if(ev.key==="Escape") closeToc(); });
  document.querySelectorAll("a[data-toc]").forEach(function(a){ a.addEventListener("click", function(ev){ ev.preventDefault(); closeToc(); gotoSec(a.dataset.toc); }); });

  /* タブ */
  document.querySelectorAll("#tabs .tab").forEach(function(b){
    b.addEventListener("click", function(){ activateMode(b.dataset.mode); history.replaceState(null,"","#"+b.dataset.mode);
      window.scrollTo({top:Math.min(window.pageYOffset, contentTop()), behavior:"auto"}); });
  });
  window.addEventListener("hashchange", function(){ gotoHash(); });

  /* 式・考え方エリアを閉じる */
  var bE=document.getElementById("btnEq");
  var sync=function(){ var on=GLOBAL.hideEq; bE.innerHTML='<span class="sw" aria-hidden="true"><i></i></span><span class="swl">式・考え方エリアを閉じる</span><span class="swv">'+(on?"ON":"OFF")+'</span>';
    bE.setAttribute("aria-pressed",on?"true":"false"); bE.classList.toggle("off",!on); document.body.classList.toggle("hideeq",on); };
  bE.addEventListener("click", function(){ GLOBAL.hideEq=!GLOBAL.hideEq; sync(); setTimeout(redrawAll,30); });
  sync();
}
var BUILT = {};
function activateMode(id){
  document.querySelectorAll(".mode").forEach(function(s){ s.classList.toggle("on", s.id===id); });
  document.querySelectorAll("#tabs .tab").forEach(function(b){ b.classList.toggle("on", b.dataset.mode===id); });
  var m=MODES.filter(function(x){ return x.id===id; })[0];
  if(m && !BUILT[id]){ BUILT[id]=true; m.secs.forEach(function(s){ DEFS[s].sim.init(document.getElementById(s)); }); }
  else if(m) setTimeout(function(){ m.secs.forEach(function(s){ var sim=DEFS[s].sim; if(sim.drawAll) sim.drawAll(); else sim.draw(); }); }, 0);
}
function redrawAll(){ MODES.forEach(function(m){ if(BUILT[m.id]) m.secs.forEach(function(s){ var sim=DEFS[s].sim; if(sim.drawAll) sim.drawAll(); else sim.draw(); }); }); }
function contentTop(){ var h=document.getElementById("hero"); return h? h.offsetTop+h.offsetHeight : 0; }
function tabbarH(){ var tb=document.getElementById("tabs"); return (tb && getComputedStyle(tb).position==="sticky")? tb.getBoundingClientRect().height : 0; }
function gotoSec(sid){
  var d=DEFS[sid]; if(!d) return;
  activateMode(MODES[d.mode].id); history.replaceState(null,"","#"+secAddr(sid));
  var go=function(){ var el=document.getElementById(sid); if(!el) return; window.scrollTo({top: el.getBoundingClientRect().top + window.pageYOffset - tabbarH() - 10, behavior:"auto"}); };
  requestAnimationFrame(function(){ requestAnimationFrame(go); }); setTimeout(go, 220);
}
function gotoHash(){
  var hs=(location.hash||"").slice(1);
  var mm=hs.match(/^(\d)-(\d)$/);
  if(mm){ var sid=null; Object.keys(DEFS).forEach(function(k){ if(DEFS[k].mode===parseInt(mm[1],10)-1 && DEFS[k].num===parseInt(mm[2],10)) sid=k; }); if(sid){ gotoSec(sid); return true; } }
  if(MODES.some(function(m){ return m.id===hs; })){ activateMode(hs); return true; }
  return false;
}
document.addEventListener("DOMContentLoaded", function(){
  buildPage();
  if(!gotoHash()) activateMode("mode1");
  watchTicks(document);
  if(document.fonts){ document.fonts.load('italic 14px "KaTeX_Math"').then(function(){ redrawAll(); }); document.fonts.ready.then(function(){ redrawAll(); }); }
});
