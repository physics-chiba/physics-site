#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""各シムのスクリーンショットを撮る。"""
import pathlib

from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
PAGE = ROOT / "dist" / "basics-of-motion-on-plane.html"
OUT = ROOT / "shots"
OUT.mkdir(exist_ok=True)

ALL_ON = "window.TEST.set({opts:{showF:true,showFc:true,showV:true,showVc:true}})"

JOBS = [
    ("m1-1", "window.TEST.goto('m1-1');window.TEST.set({t:1.0})"),
    ("m1-1b", "window.TEST.goto('m1-1');window.TEST.set({vars:{th:30},opts:{showF:true,showFc:true,showV:true},t:0.9})"),
    ("m1-2", "window.TEST.goto('m1-2');window.TEST.set({opts:{showF:true,showV:true},t:1.4})"),
    ("m1-3", "window.TEST.goto('m1-3');window.TEST.set({opts:{showF:true,showV:true},t:0.7})"),
    ("m1-3b", "window.TEST.goto('m1-3');window.TEST.set({vars:{H:19.6,y0:5},opts:{showF:true,showV:true},t:1.6,sign:-1})"),
    ("m1-4", "window.TEST.goto('m1-4');window.TEST.set({opts:{showF:true,showV:true},t:0.9})"),
    ("m1-4b", "window.TEST.goto('m1-4');window.TEST.set({vars:{th:30,F:20,F2:5},opts:{showF:true,showFc:true,showV:true},t:0.8})"),
    ("m1-5", "window.TEST.goto('m1-5');window.TEST.set({opts:{showF:true,showV:true},t:0.8})"),
    ("m1-5b", "window.TEST.goto('m1-5');window.TEST.set({vars:{th:20},opts:{showF:true,showV:true},t:0.6})"),
    ("m1-6", "window.TEST.goto('m1-6');window.TEST.set({opts:{showF:true,showV:true},t:1.2})"),
    ("m1-8", "window.TEST.goto('m1-8');window.TEST.set({opts:{showF:true,showV:true},t:2.0})"),
    ("m1-8b", "window.TEST.goto('m1-8');window.TEST.set({vars:{v0:6.6},opts:{showV:true},t:99})"),
    ("m2-1", "window.TEST.goto('m2-1');window.TEST.set({opts:{showF:true,showV:true},t:1.4})"),
    ("m2-1b", "window.TEST.goto('m2-1');window.TEST.set({opts:{pair:'B',showV:true},t:1.6})"),
    ("m2-2", "window.TEST.goto('m2-2');window.TEST.set({opts:{showF:true,showV:true,showVc:true},t:1.4})"),
    ("m2-2b", "window.TEST.goto('m2-2');window.TEST.set({vars:{th:45},opts:{showF:true,showV:true,showVc:true},t:2.2})"),
    ("m2-3", "window.TEST.goto('m2-3');window.TEST.set({opts:{showF:true,showV:true},t:1.5})"),
    ("m2-3b", "window.TEST.goto('m2-3');window.TEST.set({opts:{org:'base',showV:true},t:1.5})"),
    ("m2-4", "window.TEST.goto('m2-4');window.TEST.set({opts:{showV:true},t:1.2})"),
    ("m2-4c", "window.TEST.goto('m2-4');window.TEST.set({vars:{v0:19,th:45,bx:39,by:0},opts:{showV:true},t:99})"),
    ("m4-2", "window.TEST.goto('m4-2');window.TEST.set({opts:{showF:true,showV:true},t:1.2})"),
    ("m3-1", "window.TEST.goto('m3-1');window.TEST.set({opts:{showF:true,showV:true},t:99})"),
    ("m3-1a", "window.TEST.goto('m3-1');window.TEST.set({opts:{showF:true,showV:true},t:0.7})"),
    ("m3-2", "window.TEST.goto('m3-2');window.TEST.set({opts:{showF:true,showV:true,showVc:true},t:1.0})"),
    ("m3-2b", "window.TEST.goto('m3-2');window.TEST.set({opts:{showV:true},t:99})"),
    ("m3-3", "window.TEST.goto('m3-3');window.TEST.set({vars:{th:31},opts:{showV:true},t:99})"),
    ("m3-3b", "window.TEST.goto('m3-3');window.TEST.set({vars:{th:50},opts:{showV:true},t:99})"),
    ("m4-1", "window.TEST.goto('m4-1');window.TEST.set({opts:{showF:true,showFc:true,showV:true,showVc:true},t:0.7})"),
    ("m4-1top", "window.TEST.goto('m4-1');window.TEST.cam(-90,88,1.35);window.TEST.set({opts:{showV:true},t:0.7})"),
    ("m3-3hit", "window.TEST.goto('m3-3');window.TEST.set({vars:{th:31},opts:{showV:true},t:99})"),
    ("m3-2v0", "window.TEST.goto('m3-2');window.TEST.set({opts:{showV:true,showVc:true},t:1.0})"),
    ("q-m4-2", "window.TEST.qmode(true);window.TEST.goto('m4-2');window.TEST.qplayToEnd()"),
    ("q-m1-8", "window.TEST.goto('m1-8')"),
    ("q-off", "window.TEST.qmode(false);window.TEST.goto('m1-1')"),
    ("m4-1yview", "window.TEST.goto('m4-1');window.TEST.cam(0,0,2.2);window.TEST.set({opts:{showF:true,showFc:true},t:0.7})"),
]

with sync_playwright() as pw:
    b = pw.chromium.launch()
    p = b.new_page(viewport={"width": 1300, "height": 1050}, device_scale_factor=1)
    errs = []
    p.on("pageerror", lambda e: errs.append(str(e)))
    p.goto(PAGE.as_uri())
    p.wait_for_timeout(700)
    for name, js in JOBS:
        p.evaluate("(s)=>eval(s)", js)
        p.wait_for_timeout(250)
        p.screenshot(path=str(OUT / (name + ".png")), full_page=False)
    b.close()
print("errors:", errs)
print("saved to", OUT)

