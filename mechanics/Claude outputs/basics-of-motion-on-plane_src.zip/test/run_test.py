#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""自動テスト。

    python3 test/run_test.py 1
    python3 test/run_test.py 2

を続けて実行し、test/result_1.json と result_2.json が **完全一致** することを確かめる。

チェックするもの
  * ページエラー 0 / コンソールエラー 0
  * 外部リクエスト 0（file:// 以外へ 1 本も飛ばない ＝ 完全オフライン）
  * 物理量の検算（自由落下・投げ上げ・斜面・モンキーハンティングなど）
  * 全13シムの既定値・読み出しの文言・グラフの開閉状態
  * 正の向きを反転したときの符号
  * ハッシュ URL で直接開けること
  * レイアウトの安定（変数を変えて戻すと位置が同じ）
  * 横幅 320〜1440 px で横スクロールが出ない
"""
import json
import pathlib
import sys

from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
PAGE = ROOT / "dist" / "basics-of-motion-on-plane.html"
RUN = sys.argv[1] if len(sys.argv) > 1 else "1"
OUT = ROOT / "test" / f"result_{RUN}.json"

results = {}
errors = []
external = []
console_errors = []


def box(page):
    return page.evaluate(
        "()=>[...document.querySelectorAll('h1,h2,canvas,.card,.simtitle')]"
        ".map(e=>{const r=e.getBoundingClientRect();"
        "return [Math.round(r.x),Math.round(r.y),Math.round(r.width)].join(',')})")


def main():
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        page = browser.new_page(viewport={"width": 1280, "height": 950})
        page.on("pageerror", lambda e: errors.append(str(e)))
        # 解析タグ（//gc.zgo.at/count.js）は file:// では読めない。その1件だけ数えない
        def _con(m):
            if m.type != "error":
                return
            if "ERR_INVALID_URL" in m.text or "gc.zgo.at" in m.text:
                return
            console_errors.append(m.text)
        page.on("console", _con)
        page.on("request", lambda r: None if (r.url.startswith("file:") or "gc.zgo.at" in r.url) else external.append(r.url))
        page.goto(PAGE.as_uri())
        page.wait_for_timeout(700)

        # --- 1. 物理の検算（UI によらない） ---
        results["physics"] = page.evaluate("()=>window.TEST.check()")

        # --- 2. 全シムの既定値・読み出し・グラフの開閉 ---
        sims = page.evaluate("()=>window.TEST.sims()")
        results["sim_list"] = sims
        per = {}
        for sid in sims:
            page.evaluate("(id)=>window.TEST.goto(id)", sid)
            page.wait_for_timeout(120)
            per[sid] = {
                "state": page.evaluate("()=>window.TEST.state()"),
                "open": page.evaluate("()=>window.TEST.graphsOpen()"),
                "readout_t0": page.evaluate("()=>window.TEST.readout()"),
            }
            page.evaluate("()=>window.TEST.set({t:0.5})")
            page.wait_for_timeout(80)
            per[sid]["readout_t05"] = page.evaluate("()=>window.TEST.readout()")
            page.evaluate("()=>window.TEST.set({t:0.5,sign:-1})")
            page.wait_for_timeout(80)
            per[sid]["readout_t05_flip"] = page.evaluate("()=>window.TEST.readout()")
            page.evaluate("()=>window.TEST.set({t:0,sign:1})")
            page.wait_for_timeout(60)
        results["per_sim"] = per

        # --- 2b. グラフのドラッグ操作（移動・軸の拡大縮小・ホイール・ダブルクリック） ---
        page.goto(PAGE.as_uri() + "#m1-1")
        page.wait_for_timeout(400)
        gcv = page.query_selector("#gc_v")
        gcv.scroll_into_view_if_needed()
        page.wait_for_timeout(200)
        bb = gcv.bounding_box()
        drag = {}

        def gmap():
            return page.evaluate('()=>window.TEST.graphMap("v")')

        drag["auto"] = gmap()
        page.mouse.move(bb["x"] + bb["width"] * 0.6, bb["y"] + bb["height"] * 0.5)
        page.mouse.down()
        page.mouse.move(bb["x"] + bb["width"] * 0.4, bb["y"] + bb["height"] * 0.6, steps=5)
        page.mouse.up()
        page.wait_for_timeout(180)
        drag["pan"] = gmap()
        page.dblclick("#gc_v"); page.wait_for_timeout(150)
        page.mouse.move(bb["x"] + bb["width"] * 0.5, bb["y"] + bb["height"] * 0.94)
        page.mouse.down()
        page.mouse.move(bb["x"] + bb["width"] * 0.8, bb["y"] + bb["height"] * 0.94, steps=5)
        page.mouse.up()
        page.wait_for_timeout(180)
        drag["scale_x"] = gmap()
        page.dblclick("#gc_v"); page.wait_for_timeout(150)
        page.mouse.move(bb["x"] + bb["width"] * 0.04, bb["y"] + bb["height"] * 0.4)
        page.mouse.down()
        page.mouse.move(bb["x"] + bb["width"] * 0.04, bb["y"] + bb["height"] * 0.75, steps=5)
        page.mouse.up()
        page.wait_for_timeout(180)
        drag["scale_y"] = gmap()
        page.dblclick("#gc_v"); page.wait_for_timeout(150)
        page.mouse.move(bb["x"] + bb["width"] * 0.5, bb["y"] + bb["height"] * 0.5)
        page.mouse.wheel(0, -300)
        page.wait_for_timeout(220)
        drag["wheel"] = gmap()
        page.dblclick("#gc_v"); page.wait_for_timeout(200)
        drag["reset"] = gmap()
        results["graph_drag"] = drag

        # --- 2c. 「x–t 図・a–t 図をひらく」ボタン ---
        page.goto(PAGE.as_uri() + "#m1-1")
        page.wait_for_timeout(400)
        openall = {"before": page.evaluate("()=>window.TEST.graphsOpen()")}
        openall["after"] = page.evaluate("()=>window.TEST.openAll()")
        openall["again"] = page.evaluate("()=>window.TEST.openAll()")
        results["open_all"] = openall

        # --- 2d. 3次元の視点操作（4 入試物理） ---
        page.goto(PAGE.as_uri() + "#m4-3")
        page.wait_for_timeout(500)
        cam = {"init": page.evaluate("()=>window.TEST.cam(-38,24,1)")}
        cv3 = page.query_selector("#mainCv")
        cv3.scroll_into_view_if_needed()
        page.wait_for_timeout(200)
        b3 = cv3.bounding_box()
        page.mouse.move(b3["x"] + b3["width"] * 0.5, b3["y"] + b3["height"] * 0.5)
        page.mouse.down()
        page.mouse.move(b3["x"] + b3["width"] * 0.5 + 150, b3["y"] + b3["height"] * 0.5 - 60, steps=6)
        page.mouse.up()
        page.wait_for_timeout(200)
        cam["after_drag"] = page.evaluate("()=>window.TEST.camGet()")
        page.mouse.wheel(0, -300)
        page.wait_for_timeout(200)
        cam["after_wheel"] = page.evaluate("()=>window.TEST.camGet()")
        results["cam3d"] = cam

        # --- 2e. 問題モードの流れ ---
        qm = {}
        for sid in ["m1-1", "m1-3", "m2-2", "m4-2", "m3-2", "m4-1", "m4-3"]:
            page.goto(PAGE.as_uri() + "#" + sid)
            page.wait_for_timeout(350)
            rec = {"on": page.evaluate("()=>window.TEST.qmode(true)")}
            rec["p0"] = page.evaluate("()=>window.TEST.qstate()")
            rec["p1"] = page.evaluate("()=>window.TEST.qplayToEnd()")
            rec["p2"] = page.evaluate("()=>window.TEST.qpick(0)")
            rec["off"] = page.evaluate("()=>window.TEST.qmode(false)")
            qm[sid] = rec
        results["quiz_mode"] = qm

        # --- 2e-2. ゲーム3種は問題モードでも「問題なし」 ---
        games = {}
        for sid in ["m1-8", "m2-4", "m3-3"]:
            page.goto(PAGE.as_uri() + "#" + sid)
            page.wait_for_timeout(350)
            page.evaluate("()=>window.TEST.qmode(true)")
            page.wait_for_timeout(150)
            games[sid] = page.evaluate(
                "()=>({qphase:window.TEST.qstate().qphase,"
                "gquiz:!!document.getElementById('gquiz'),"
                "graphsHidden:window.TEST.qstate().hidden,"
                "play:document.getElementById('bPlay').textContent})")
            page.evaluate("()=>window.TEST.qmode(false)")
        results["games_no_quiz"] = games

        # --- 2f. 各グラフの3段の式 ---
        fml = {}
        for sid in sims:
            page.goto(PAGE.as_uri() + "#" + sid)
            page.wait_for_timeout(250)
            fml[sid] = page.evaluate("()=>window.TEST.formulas()")
        results["formulas"] = fml

        # --- 3. ハッシュ URL で直接開ける ---
        hashes = {}
        for sid in ["m1-3", "m2-4", "m3-3", "m4-1", "m4-3"]:
            page.goto(PAGE.as_uri() + "#" + sid)
            page.wait_for_timeout(400)
            hashes[sid] = page.evaluate("()=>({sim:window.TEST.state().sim,"
                                        "title:document.querySelector('.simtitle').textContent})")
        results["hash_open"] = hashes

        # --- 3b. 問題モードつきの URL（#…!q） ---
        qh = {}
        for sid in ["m1-1", "m2-2", "m3-3"]:
            page.goto(PAGE.as_uri() + "#" + sid + "!q")
            page.wait_for_timeout(450)
            qh[sid] = page.evaluate("()=>({sim:window.TEST.state().sim,"
                                    "qmode:window.TEST.qstate().qmode,"
                                    "qphase:window.TEST.qstate().qphase,"
                                    "url:location.hash.replace('#','')})")
        results["hash_quiz"] = qh

        # --- 3b-2. 「…!q」で開いたときだけ、大きなお知らせが出る ---
        qn = {}
        page.goto("about:blank")                    # ページごと読み直す（リンクで来た状態にする）
        page.goto(PAGE.as_uri() + "#m1-1!q")
        page.wait_for_timeout(500)
        qn["with_q"] = page.evaluate("()=>!document.getElementById('qnotice').hidden")
        qn["btn_clickable"] = page.evaluate(
            "()=>{var r=document.getElementById('qswitch').getBoundingClientRect();"
            "var e=document.elementFromPoint(r.left+r.width/2, r.top+r.height/2);"
            "return !!(e && e.closest('#qswitch'));}")     # お知らせ中でもボタンは押せる
        page.evaluate("()=>document.getElementById('qnok').click()")
        page.wait_for_timeout(150)
        qn["after_ok"] = page.evaluate("()=>document.getElementById('qnotice').hidden")
        page.goto(PAGE.as_uri() + "#m1-1")
        page.wait_for_timeout(400)
        qn["without_q"] = page.evaluate("()=>document.getElementById('qnotice').hidden")
        page.evaluate("()=>document.getElementById('qmodeChk').click()")
        page.wait_for_timeout(250)
        qn["self_toggle"] = page.evaluate(
            "()=>[document.getElementById('qnotice').hidden, window.TEST.qstate().qmode]")
        sw = page.evaluate("()=>{var r=document.getElementById('qswitch').getBoundingClientRect();"
                           "return [Math.round(r.width), Math.round(r.height)];}")
        qn["switch_size"] = sw
        results["qnotice"] = qn

        # --- 3c. ゲームの成功判定（win）---
        wins = {}
        page.goto(PAGE.as_uri() + "#m2-4")
        page.wait_for_timeout(400)
        wins["m2-4_hit"] = page.evaluate(
            "()=>{window.TEST.set({vars:{v0:19,th:45,bx:37,by:0},t:99});return !!window.TEST.win('m2-4');}")
        wins["m2-4_miss"] = page.evaluate(
            "()=>{window.TEST.set({vars:{v0:10,th:45,bx:39,by:0},t:99});return !!window.TEST.win('m2-4');}")
        page.goto(PAGE.as_uri() + "#m1-8")
        page.wait_for_timeout(400)
        wins["m1-8_hit"] = page.evaluate(
            "()=>{window.TEST.set({vars:{v0:4.65,mud:0.05,tx:22},t:99});return !!window.TEST.win('m1-8');}")
        wins["m1-8_miss"] = page.evaluate(
            "()=>{window.TEST.set({vars:{v0:3,mud:0.05,tx:22},t:99});return !!window.TEST.win('m1-8');}")
        results["game_win"] = wins

        # --- 3d. 1-8：v0 を変えても x 軸の目盛りが動かない ---
        page.goto(PAGE.as_uri() + "#m1-8")
        page.wait_for_timeout(400)
        axis = []
        for v0 in (2, 5, 9, 12):
            page.evaluate("(v)=>window.TEST.set({vars:{v0:v},t:0})", v0)
            page.wait_for_timeout(120)
            axis.append(page.evaluate(
                "()=>{const c=document.getElementById('mainCv');"
                "return c.width+'x'+c.height;}"))
        results["curling_axis_fixed"] = (len(set(axis)) == 1)
        results["curling_play_btn"] = page.evaluate(
            "()=>({text:document.getElementById('bPlay').textContent,"
            "disabled:document.getElementById('bPlay').disabled})")

        # --- 4. レイアウトの安定 ---
        page.goto(PAGE.as_uri() + "#m1-1")
        page.wait_for_timeout(400)
        before = box(page)
        page.evaluate("()=>window.TEST.set({vars:{th:30},t:0.7})")
        page.wait_for_timeout(150)
        page.evaluate("()=>window.TEST.set({vars:{th:0},t:0})")
        page.wait_for_timeout(150)
        results["layout_stable"] = (before == box(page))

        # --- 5. 横スクロールが出ない ---
        widths = {}
        for w in (320, 360, 390, 768, 1024, 1440):
            page.set_viewport_size({"width": w, "height": 800})
            page.wait_for_timeout(260)
            widths[str(w)] = page.evaluate(
                "()=>document.documentElement.scrollWidth>window.innerWidth+1")
        results["h_scroll"] = widths

        browser.close()

    results["errors"] = errors
    results["console_errors"] = console_errors
    results["external"] = external
    OUT.write_text(json.dumps(results, ensure_ascii=False, indent=1), encoding="utf-8")

    print(f"--- run {RUN} ---")
    print("pageerrors:", len(errors), " console errors:", len(console_errors),
          " external requests:", len(external))
    print("layout_stable:", results["layout_stable"])
    print("games_no_quiz:", json.dumps(results["games_no_quiz"], ensure_ascii=False))
    print("hash_quiz:", json.dumps(results["hash_quiz"], ensure_ascii=False))
    print("qnotice:", json.dumps(results["qnotice"], ensure_ascii=False))
    print("game_win:", json.dumps(results["game_win"], ensure_ascii=False))
    print("curling_axis_fixed:", results["curling_axis_fixed"], results["curling_play_btn"])
    print("h_scroll:", results["h_scroll"])
    print("hash_open:", {k: v["sim"] for k, v in results["hash_open"].items()})
    print("physics:", json.dumps(results["physics"], ensure_ascii=False))


if __name__ == "__main__":
    main()
