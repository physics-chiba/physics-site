#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""簡易チェック：全シムを開いてエラーが出ないか見る。"""
import json
import pathlib
import sys

from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
PAGE = ROOT / "dist" / "basics-of-motion-on-plane.html"

errors = []
external = []
console = []

with sync_playwright() as pw:
    b = pw.chromium.launch()
    p = b.new_page(viewport={"width": 1280, "height": 950})
    p.on("pageerror", lambda e: errors.append(str(e)))
    # 解析タグ（//gc.zgo.at/count.js）は file:// では読めない。その1件だけ数えない
    def _con(m):
        if m.type != "error":
            return
        if "ERR_INVALID_URL" in m.text or "gc.zgo.at" in m.text:
            return
        console.append(m.type + ":" + m.text)
    p.on("console", _con)
    p.on("request", lambda r: None if (r.url.startswith("file:") or "gc.zgo.at" in r.url) else external.append(r.url))
    p.goto(PAGE.as_uri())
    p.wait_for_timeout(800)
    sims = p.evaluate("()=>window.TEST.sims()")
    print("sims:", sims)
    print("check:", json.dumps(p.evaluate("()=>window.TEST.check()"), ensure_ascii=False, indent=1))
    for s in sims:
        p.evaluate("(id)=>window.TEST.goto(id)", s)
        p.wait_for_timeout(180)
        # 時間を進めた状態でも描く
        p.evaluate("()=>{const d=window.TEST; d.set({t:0.6});}")
        p.wait_for_timeout(120)
        print(s, "ok, readout rows:", len(p.evaluate("()=>window.TEST.readout()")))
    b.close()

print("pageerrors:", errors)
print("console errors:", console)
print("external:", external)
sys.exit(1 if (errors or external or console) else 0)
