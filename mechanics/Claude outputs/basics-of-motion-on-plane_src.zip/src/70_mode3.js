/* 3　2物体の運動 */
'use strict';

/* ============ 3-1 投げ上げAと自由落下Bの衝突 ============ */
DEFS['m3-1'] = {
  id: 'm3-1', mode: 3, tab: '3-1 衝突（投げ上げ×自由落下）',
  quizKey: 'v', quizName: '球 A（投げ上げ）と 球 B（自由落下）の $v$–$t$ 図（鉛直方向）',
  title: '3-1　鉛直投げ上げA と 自由落下B が一直線上で衝突',
  desc: '初速度をもつ方がA（投げ上げ）、静かに落とす方がB（自由落下）。',
  sub: '左は見やすいように左右に少しずらした図、右は本来の位置関係（同じ一直線の上）。ぶつかるのは2つの y が一致したとき。',
  cw: 540, ch: 380,
  vis: ['F', 'V'],
  signLabels: ['上向きを正', '下向きを正'],
  mainVars: ['v0', 'H'],
  vars: [
    { k: 'v0', label: 'Aの初速度 $v_0$（上向き）', unit: ' m/s', min: 5, max: 30, step: 1, dec: 0, def: 18 },
    { k: 'H', label: 'Bを落とす高さ $H$', unit: ' m', min: 5, max: 45, step: 1, dec: 0, def: 20 }
  ],
  toggles: [],
  tEnd: function (v) { return P.m31.tEnd(v); },
  sample: function (v, t) { return P.m31.sample(v, t); },
  graphs: [
    { key: 'y', short: '$y$–$t$ 図', title: '$y$–$t$ 図（A・B）', ylabel: 'y [m]', open: true, signed: true, legend: true,
      series: [{ name: 'A 投げ上げ', color: COL.A, f: function (m) { return m.yA; } },
        { name: 'B 自由落下', color: COL.B, f: function (m) { return m.yB; } }],
      fml: function (v, sg) {
        return ['y = y_0 + v_0 t + \\tfrac{1}{2}at^2',
          'A: y = v_0t - \\tfrac{1}{2}gt^2 \\qquad B: y = H - \\tfrac{1}{2}gt^2',
          'A: y = ' + fmt(v.v0 * sg, 1) + 't + \\tfrac{1}{2}(' + fmt(-G * sg, 2) + ')t^2 \\quad B: y = ' +
          fmt(v.H * sg, 0) + ' + \\tfrac{1}{2}(' + fmt(-G * sg, 2) + ')t^2'];
      } },
    { key: 'v', short: '$v$–$t$ 図', title: '$v$–$t$ 図（A・B）　たての差＝相対速度', ylabel: 'v [m/s]', open: true, signed: true, legend: true,
      series: [{ name: 'A', color: COL.A, f: function (m) { return m.vA; } },
        { name: 'B', color: COL.B, f: function (m) { return m.vB; } }],
      fml: function (v, sg) {
        return ['v = v_0 + at', 'A: v = v_0 - gt \\qquad B: v = -gt',
          'A: v = ' + fmt(v.v0 * sg, 1) + ' + (' + fmt(-G * sg, 2) + ')t \\quad B: v = (' + fmt(-G * sg, 2) + ')t'];
      } },
    { key: 'a', short: '$a$–$t$ 図', title: '$a$–$t$ 図（A・B とも −g）　※ a の運動方程式による導出', ylabel: 'a [m/s²]', open: false, signed: true, legend: true,
      series: [{ name: 'A', color: COL.A, f: function (m) { return m.aA; } },
        { name: 'B', color: COL.B, f: function (m) { return m.aB; }, dash: [6, 4] }],
      fml: function (v, sg) {
        return [EQM + 'ma = F \\;\\Rightarrow\\; a = \\dfrac{F}{m}', EQM + 'A も B も ma = -mg \\;\\Rightarrow\\; a = -g',
          'a = ' + fmt(-G * sg, 2) + '\\ \\mathrm{m/s^2}\\;(\\text{2つとも同じ})'];
      } }
  ],
  draw: function (ctx, s, t, W, H) {
    var v = V(s), T = P.m31.tEnd(v), tc = P.m31.tCol(v);
    var hi = Math.max(v.H, v.v0 * v.v0 / (2 * G)) + 2;
    var topPx = 56, botPx = H - 44;
    var sc = (botPx - topPx) / hi;
    function Y(y) { return botPx - y * sc; }
    var mainW = W - 110;
    var cx = mainW * 0.56;

    ground(ctx, 24, mainW - 14, Y(0));
    label(ctx, '地面', mainW - 18, Y(0) + 14, { align: 'right', size: 11.5 });
    ctx.save(); ctx.strokeStyle = '#c6ccd4'; ctx.setLineDash([3, 4]);
    ctx.beginPath(); ctx.moveTo(cx, Y(0)); ctx.lineTo(cx, Y(hi)); ctx.stroke(); ctx.restore();
    label(ctx, '見やすいよう左右にずらした図', mainW / 2, H - 14, { size: 10.5, color: COL.sub });

    /* y 軸（共通スタイル） */
    var axX = 46;
    axisY(ctx, Y, axX, 0, hi - 0.6, 'y [m]', s.sign, { target: 5 });
    originMark(ctx, axX, Y(0), -13, 13);

    var m = P.m31.sample(v, t);
    var ax = cx - 20, bx = cx + 20, i;
    for (i = 1; i * 0.2 < t - 1e-9; i++) {
      var q = P.m31.sample(v, i * 0.2);
      ball(ctx, ax, Y(q.yA), 5, 'faint'); ball(ctx, bx, Y(q.yB), 5, 'faint');
    }
    person(ctx, ax - 26, Y(0), 32, false);
    hatchLine(ctx, bx - 26, Y(v.H), bx + 26, Y(v.H), -1);
    label(ctx, 'H = ' + fmt(v.H, 0) + ' m', bx + 30, Y(v.H) - 9, { align: 'left', size: 11, color: COL.sub });

    var yA = Y(m.yA), yB = Y(m.yB);
    ball(ctx, ax, yA, 9, 'A'); label(ctx, 'A', ax - 15, yA, { size: 12, bold: true, color: COL.A });
    ball(ctx, bx, yB, 9, 'B'); label(ctx, 'B', bx + 15, yB, { size: 12, bold: true, color: COL.B });

    var fs = 4.4;
    if (s.o.showF) {
      /* A にはたらく力＝あかるい色、B にはたらく力＝こい色（見分けられるように） */
      arrow(ctx, ax, yA, ax, yA + 9.8 * fs, 'force', 1, fcol('A', COL.force));
      arrow(ctx, bx, yB, bx, yB + 9.8 * fs, 'force', 1, fcol('B', COL.force));
      label(ctx, 'A：mg', ax - 12, yA + 9.8 * fs - 7, { align: 'right', size: 11, color: fcol('A', COL.force) });
      label(ctx, 'B：mg', bx + 12, yB + 9.8 * fs - 7, { align: 'left', size: 11, color: fcol('B', COL.force) });
    }
    if (s.o.showV) {
      if (Math.abs(m.vA) > 0.2) {
        var la = 10 + 34 * Math.min(1, Math.abs(m.vA) / 30);
        arrow(ctx, ax - 26, yA, ax - 26, yA - (m.vA > 0 ? 1 : -1) * la, 'vel');
      }
      if (Math.abs(m.vB) > 0.2) {
        var lb = 10 + 34 * Math.min(1, Math.abs(m.vB) / 30);
        arrow(ctx, bx + 26, yB, bx + 26, yB - (m.vB > 0 ? 1 : -1) * lb, 'vel');
      }
    }

    /* 右：ほんとうの位置関係（同じ一直線の上） */
    var lx = W - 52;
    ctx.save();
    ctx.fillStyle = '#fbfcfd'; ctx.strokeStyle = '#d9dee4'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.rect(lx - 46, 40, 92, H - 78); ctx.fill(); ctx.stroke();
    ctx.restore();
    label(ctx, '本来の配置', lx, 24, { size: 11, bold: true, color: COL.sub });
    label(ctx, '（同じ直線上）', lx, H - 24, { size: 10, color: COL.sub });
    ctx.save();
    ctx.strokeStyle = '#8b949e'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(lx, Y(0)); ctx.lineTo(lx, Y(hi)); ctx.stroke();
    ctx.restore();
    hatchLine(ctx, lx - 28, Y(0), lx + 28, Y(0), 1);
    hatchLine(ctx, lx - 22, Y(v.H), lx + 22, Y(v.H), -1);
    for (i = 1; i * 0.2 < t - 1e-9; i++) {
      var q2 = P.m31.sample(v, i * 0.2);
      ball(ctx, lx, Y(q2.yA), 4.5, 'faint'); ball(ctx, lx, Y(q2.yB), 4.5, 'faint');
    }
    ball(ctx, lx, Y(m.yB), 9, 'B');
    ball(ctx, lx, Y(m.yA), 9, 'A');
    label(ctx, 'A', lx - 15, Y(m.yA), { size: 11, bold: true, color: COL.A });
    label(ctx, 'B', lx + 15, Y(m.yB), { size: 11, bold: true, color: COL.B });

    label(ctx, 't = ' + fmt(t, 2) + ' s', 10, 18, { align: 'left', size: 13.5, bold: true });
    drawPosNote(ctx, DEFS['m3-1'], s, W, 36);
    if (hintOn(s, t)) label(ctx, '相対速度 v_A − v_B = ' + fmt((m.vA - m.vB) * s.sign, 1) + ' m/s（一定）', mainW - 14, 18,
      { align: 'right', size: 11, color: COL.sub });
    if (tc !== null && t >= T - 1e-9) {
      impact(ctx, lx, Y(m.yA), 20, 'ドコッ！');
      bubble(ctx, '衝突！　高さ ' + fmt(m.yA, 1) + ' m', cx, Math.min(yA, yB) - 14,
        { size: 13.5, bg: '#fde8e6', border: '#c0392b', color: '#a52a1e' });
    } else if (tc === null && t >= T - 1e-9) {
      bubble(ctx, '衝突しなかった', cx, 110, { size: 12.5 });
    }
  },
  info: function (s, t) {
    var v = V(s), m = P.m31.sample(v, t), tc = P.m31.tCol(v);
    return [
      ['Aの高さ', fmt(m.yA * s.sign, 2) + ' m'],
      ['Bの高さ', fmt(m.yB * s.sign, 2) + ' m'],
      ['Aの速度 $v_A$', fmt(m.vA * s.sign, 2) + ' m/s'],
      ['Bの速度 $v_B$', fmt(m.vB * s.sign, 2) + ' m/s'],
      ['相対速度 $v_A - v_B$', fmt((m.vA - m.vB) * s.sign, 2) + ' m/s'],
      ['衝突する時刻 $H/v_0$', tc !== null ? fmt(tc, 2) + ' s' : '衝突しない']
    ];
  },
  eq: function (s) {
    return 'y_A - y_B = v_0 t - H \\;\\Rightarrow\\; t = \\dfrac{H}{v_0} \\quad(\\text{}-\\tfrac{1}{2}gt^2 \\text{ は消える})';
  },
  note: 'AもBも加速度は同じ −g。だから<b>相対速度は変わらない（v₀ のまま一定）</b>で、AはBに向かって毎秒 v₀ ずつ近づく。衝突時刻は <span class="tex">t=H/v_0</span> と、なんと g を使わずに出せる。'
};

/* ============ 3-2 台車から真上に発射 ============ */
/* グラフの出し分け：水平面の観測者なら x・y、台車の上の観測者なら x′・y′ */
function gnd2(v) { return v.obs !== 'cart'; }
function crt2(v) { return v.obs === 'cart'; }
/* B の高さ・鉛直速度の式（どちらの観測者でも同じなので共通にする） */
function m32yFml(v, sg) {
  var t0 = P.m32.tLaunch(v);
  var tt = (t0 > 0.005) ? '(t-' + fmt(t0, 2) + ')' : 't';
  return ['y = v_{y0}(t-t_0) + \\tfrac{1}{2}a(t-t_0)^2',
    'y = u(t-t_0) - \\tfrac{1}{2}g(t-t_0)^2',
    'y = ' + fmt(v.u * sg, 1) + tt + ' + \\tfrac{1}{2}(' + fmt(-G * sg, 2) + ')' + tt + '^2'];
}
function m32vyFml(v, sg) {
  var t0 = P.m32.tLaunch(v);
  var tt = (t0 > 0.005) ? '(t-' + fmt(t0, 2) + ')' : 't';
  return ['v_y = v_{y0} + a(t-t_0)', 'v_y = u - g(t-t_0)',
    'v_y = ' + fmt(v.u * sg, 1) + ' + (' + fmt(-G * sg, 2) + ')' + tt];
}

DEFS['m3-2'] = {
  id: 'm3-2', mode: 3, tab: '3-2 台車から発射',
  quizKey: function (v) { return (v.obs === 'cart') ? 'cvy' : 'gvy'; },
  quizName: function (v) {
    return (v.obs === 'cart') ? '小球B の $v_y$–$t$ 図（台車Aから見た鉛直方向）'
      : '小球B の $v_y$–$t$ 図（地上から見た鉛直方向）';
  },
  title: '3-2　等速直線運動する台車Aから、真上に発射される小球B',
  desc: 'まずクイズに答えてから再生しよう。台車Aは等速で進み、<b>x＝5 m のところで</b>小球Bを<b>真上に</b>発射する。Bはどこに落ちる？',
  sub: 'はじめは台車を止めた状態（V＝0）。まっすぐ上がってまっすぐもどることを確かめてから、V を大きくしてみよう。<br><b>「台車Aの上の観測者」</b>に切りかえると、台車は止まって見え、<b>地面のほうが後ろへ流れていく</b>。そのときBは<b>ただの鉛直投げ上げ</b>——ずっと真上にいて、水平方向には少しも動かない。',
  cw: 520, ch: 340,
  vis: ['F', 'V', 'Vc'],
  signLabels: ['右向き・上向きを正', '左向き・下向きを正'],
  mainVars: ['V', 'u'], mainOpts: true,
  selects: [{
    k: 'obs', label: '観測者', def: 'ground',
    options: [{ v: 'ground', label: '水平面の観測者から見る（x・y）' }, { v: 'cart', label: '台車Aの上の観測者から見る（x′・y′）' }]
  }],
  vars: [
    { k: 'V', label: '台車Aの速さ $V$', unit: ' m/s', min: 0, max: 12, step: 1, dec: 0, def: 0 },
    { k: 'u', label: '小球Bの打ち上げ速さ $u$', unit: ' m/s', min: 4, max: 20, step: 0.2, dec: 1, def: 9.8 }
  ],
  toggles: [{ k: 'guide', label: '台車と小球を結ぶ線を表示', def: true }],
  actions: [
    { label: '台車を止める（V＝0）', fn: function (s) { s.v.V = 0; }, is: function (v) { return v.V === 0; } },
    { label: '台車を走らせる（V＝4 m/s）', fn: function (s) { s.v.V = 4; }, is: function (v) { return v.V === 4; },
      /* 止まった台車で一度見終わったら、「次はこれ」と光らせる */
      next: function (s, t, v) { return v.V < 0.05 && t >= P.m32.tEnd(v) - 1e-9; } }
  ],
  quiz: {
    q: 'Aが進んでいる間に真上にBを発射すると、Bはどこに落ちる？',
    choices: ['台車Aの手前（後ろ）', '台車Aの真上（発射口にもどる）', '台車Aの先（前）'],
    answer: 1,
    explain: '水平方向には力がはたらかないので、Bの水平方向の速度は<b>ずっと V のまま</b>（台車と同じ）。だからBはいつも台車の真上にいて、発射口にもどってくる。'
  },
  tEnd: function (v) { return P.m32.tEnd(v); },
  sample: function (v, t) { return P.m32.sample(v, t); },
  graphs: [
    /* ===== 水平面の観測者（x・y） ===== */
    { key: 'gx', when: gnd2, short: '$x$–$t$ 図', title: '$x$–$t$ 図（A・B の水平位置：ぴったり重なる）', ylabel: 'x [m]', open: true, signed: false, legend: true,
      series: [{ name: 'A 台車', color: COL.A, f: function (m) { return m.xA; }, width: 4 },
        { name: 'B 小球', color: COL.B, f: function (m) { return m.xB; }, dash: [6, 5] }],
      fml: function (v) {
        return ['x = v_x t \;(\\text{等速})', 'A: x = Vt \\qquad B: x = Vt',
          'x = ' + fmt(v.V, 0) + 't\;(\\text{A と B は同じ})'];
      } },
    { key: 'gy', when: gnd2, short: '$y$–$t$ 図', title: '$y$–$t$ 図（B の高さ）', ylabel: 'y [m]', open: true, signed: true,
      series: [{ color: COL.B, f: function (m) { return m.yB; } }],
      fml: function (v, sg) { return m32yFml(v, sg); } },
    { key: 'gvx', when: gnd2, short: '$v_x$–$t$ 図', title: '$v_x$–$t$ 図（A・B とも一定）', ylabel: 'vx [m/s]', open: false, signed: false, legend: true,
      series: [{ name: 'A', color: COL.A, f: function (m) { return m.vA; }, width: 4 },
        { name: 'B', color: COL.velx, f: function (m) { return m.vxB; }, dash: [6, 5] }],
      fml: function (v) {
        return ['v_x = \\text{一定}\;(\\text{水平方向に力がない})', 'v_x = V', 'v_x = ' + fmt(v.V, 0) + '\\ \\mathrm{m/s}'];
      } },
    { key: 'gvy', when: gnd2, short: '$v_y$–$t$ 図', title: '$v_y$–$t$ 図（B の鉛直方向の速度）', ylabel: 'vy [m/s]', open: false, signed: true,
      series: [{ color: COL.vely, f: function (m) { return m.vyB; } }],
      fml: function (v, sg) { return m32vyFml(v, sg); } },
    { key: 'gax', when: gnd2, short: '$a_x$–$t$ 図', title: '$a_x$–$t$ 図（水平方向の加速度は 0）　※ a の運動方程式による導出', ylabel: 'ax [m/s²]', open: false, signed: true,
      series: [{ color: COL.acc, f: function () { return 0; } }],
      fml: function () { return [EQM + 'ma_x = 0 \;(\\text{水平の力はない})', 'a_x = 0', 'a_x = 0.00\\ \\mathrm{m/s^2}']; } },
    { key: 'gay', when: gnd2, short: '$a_y$–$t$ 図', title: '$a_y$–$t$ 図（B の鉛直方向の加速度）　※ a の運動方程式による導出', ylabel: 'ay [m/s²]', open: false, signed: true,
      series: [{ color: COL.acc, f: function (m) { return m.flying ? -G : 0; } }],
      fml: function (v, sg) {
        return [EQM + 'ma_y = -mg \;(\\text{重力だけ})', 'a_y = -g',
          'a_y = ' + fmt(-G * sg, 2) + '\\ \\mathrm{m/s^2}\;(\\text{発射後})'];
      } },
    /* ===== 台車Aの上の観測者（x′・y′） ===== */
    { key: 'cx', when: crt2, short: "$x'$–$t$ 図", title: "$x'$–$t$ 図（台車から見たBの水平位置：ずっと 0）", ylabel: "x' [m]", open: true, signed: true,
      series: [{ color: COL.B, f: function (m) { return m.xB - m.xA; } }],
      fml: function () {
        return ["x' = x_B - x_A", "x_B \\text{と} x_A \\text{はいつも同じ}", "x' = 0 \;(\\text{ずっと台車の真上})"];
      } },
    { key: 'cy', when: crt2, short: "$y'$–$t$ 図", title: "$y'$–$t$ 図（B の高さ：地上から見たのと同じ）", ylabel: "y' [m]", open: true, signed: true,
      series: [{ color: COL.B, f: function (m) { return m.yB; } }],
      fml: function (v, sg) { return m32yFml(v, sg); } },
    { key: 'cvx', when: crt2, short: "$v_x'$–$t$ 図", title: "$v_x'$–$t$ 図（台車から見た水平方向の速度：ずっと 0）", ylabel: "vx' [m/s]", open: false, signed: true,
      series: [{ color: COL.velx, f: function (m) { return m.vxB - m.vA; } }],
      fml: function () {
        return ["v_x' = v_{xB} - V", 'v_{xB} = V', "v_x' = 0"];
      } },
    { key: 'cvy', when: crt2, short: "$v_y'$–$t$ 図", title: "$v_y'$–$t$ 図（B の鉛直方向の速度：地上から見たのと同じ）", ylabel: "vy' [m/s]", open: false, signed: true,
      series: [{ color: COL.vely, f: function (m) { return m.vyB; } }],
      fml: function (v, sg) { return m32vyFml(v, sg); } },
    { key: 'cax', when: crt2, short: "$a_x'$–$t$ 図", title: "$a_x'$–$t$ 図（0。台車は等速なので見かけの力もない）　※ a の運動方程式による導出", ylabel: "ax' [m/s²]", open: false, signed: true,
      series: [{ color: COL.acc, f: function () { return 0; } }],
      fml: function () {
        return [EQM + "ma_x' = 0", '\\text{台車は等速}\;(\\text{慣性系})\;\\text{なので見かけの力は出ない}', "a_x' = 0"];
      } },
    { key: 'cay', when: crt2, short: "$a_y'$–$t$ 図", title: "$a_y'$–$t$ 図（−g。どちらの観測者でも同じ）　※ a の運動方程式による導出", ylabel: "ay' [m/s²]", open: false, signed: true,
      series: [{ color: COL.acc, f: function (m) { return m.flying ? -G : 0; } }],
      fml: function (v, sg) {
        return [EQM + "ma_y' = -mg", "a_y' = -g", "a_y' = " + fmt(-G * sg, 2) + '\\ \\mathrm{m/s^2}'];
      } }
  ],
  draw: function (ctx, s, t, W, H) {
    var v = V(s), T = P.m32.tEnd(v), tL = P.m32.tLaunch(v);
    var crt = (v.obs === 'cart');                 /* 台車Aの上の観測者から見るか */
    var m = P.m32.sample(v, t), i;
    var yMax = v.u * v.u / (2 * G) * 1.3 + 1;
    var pad = { l: 46, r: 20, t: 30, b: 44 };
    var MUZZLE = 26;
    /* 見せる横の範囲。台車の観測者では台車を中心にした固定の窓にする */
    var xLo = -3.4;                      /* 水平面の観測者と、その名前を書くぶん、左を空ける */
    var xHi = crt ? 3.4 : Math.max(6, v.V * T * 1.15, (v.V > 0.05 ? P.m32.LAUNCH_X + 2 : 0));
    var sc = Math.min((W - pad.l - pad.r) / (xHi - xLo), (H - pad.t - pad.b - MUZZLE) / yMax);
    /* X() は「その観測者の座標」→画面。XX() は「地面に固定した座標」→画面 */
    var xoff = crt ? -m.xA : 0;
    function X(x) { return pad.l + (x - xLo) * sc; }
    function Y(y) { return H - pad.b - MUZZLE - y * sc; }
    function XX(x) { return X(x + xoff); }
    ground(ctx, 22, W - 16, Y(0) + MUZZLE);
    if (crt) {                             /* 地面のほうが後ろへ流れていくのを見せる目印 */
      var gy0 = Y(0) + MUZZLE;
      for (i = Math.floor(m.xA + xLo); i <= Math.ceil(m.xA + xHi); i++) {
        var gx = XX(i);
        if (gx < 26 || gx > W - 20) continue;
        ctx.save(); ctx.strokeStyle = '#b3941f'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(gx, gy0 + 20); ctx.lineTo(gx, gy0 + 27); ctx.stroke(); ctx.restore();
      }
    }
    axisX(ctx, X, Y(0) + MUZZLE, crt ? xLo * 0.9 : 0, (crt ? xHi : xHi) * 0.94,
      crt ? "x' [m]" : 'x [m]', 1, { target: 5 });
    axisY(ctx, Y, X(0), 0, yMax * 0.94, crt ? "y' [m]" : 'y [m]', s.sign, { target: 4 });
    originMark(ctx, X(0), Y(0) + MUZZLE, -13, 13);
    if (v.V > 0.05) {                      /* 発射する場所（x = 5 m）を示す */
      var lx5 = XX(P.m32.LAUNCH_X);
      if (lx5 > 26 && lx5 < W - 20) {
        ctx.save();
        ctx.strokeStyle = '#9aa3ac'; ctx.setLineDash([4, 4]); ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.moveTo(lx5, Y(0) + MUZZLE); ctx.lineTo(lx5, Y(yMax * 0.55));
        ctx.stroke(); ctx.restore();
        label(ctx, 'x = ' + fmt(P.m32.LAUNCH_X, 0) + ' m で発射', lx5 - 6, Y(yMax * 0.55) - 6,
          { align: 'right', size: 10.5, color: COL.sub });
      }
    }

    ctx.save(); ctx.strokeStyle = '#e07b18'; ctx.lineWidth = 2.2;
    ctx.beginPath();
    var n = Math.max(2, Math.round(80 * t / T));
    for (i = 0; i <= n; i++) {
      var q = P.m32.sample(v, t * i / n);
      /* 台車の観測者から見た「これまでの道すじ」は、いまの台車の位置を基準にする */
      var qx = crt ? XX(q.xB + (m.xA - q.xA)) : XX(q.xB);
      if (i === 0) ctx.moveTo(qx, Y(q.yB)); else ctx.lineTo(qx, Y(q.yB));
    }
    ctx.stroke(); ctx.restore();

    cart(ctx, XX(m.xA), Y(0) + MUZZLE, 58);
    label(ctx, 'A', XX(m.xA), Y(0) + MUZZLE + 15, { size: 12, bold: true, color: COL.A });
    if (s.o.guide) {
      ctx.save(); ctx.strokeStyle = '#9aa3ac'; ctx.setLineDash([4, 4]); ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(XX(m.xB), Y(m.yB)); ctx.lineTo(XX(m.xA), Y(0)); ctx.stroke(); ctx.restore();
    }
    var bpx = XX(m.xB), bpy = Y(m.yB);
    ball(ctx, bpx, bpy, 8, 'B');
    label(ctx, 'B', bpx + 14, bpy - 10, { size: 12, bold: true, color: COL.B });

    if (s.o.showF) {
      arrow(ctx, bpx, bpy, bpx, bpy + 40, 'force', 1, fcol('B', COL.force));
      label(ctx, 'B：mg', bpx - 9, bpy + 34, { align: 'right', size: 11, color: fcol('B', COL.force) });
    }
    /* --- 2人の観測者（棒人間）。いま選んでいるほうを青く --- */
    (function () {
      var gy1 = Y(0) + MUZZLE;
      /* 水平面の観測者：地面のある場所に立っている。
         台車の観測者から見ると、地面といっしょに後ろへ流れて画面から出ていく。 */
      var gox = crt ? XX(P.m32.LAUNCH_X + 1.8) : X(-1.1);
      if (gox > 54 && gox < W - 54) {
        /* 名前は台車から遠いほうへ書く（発射口の「ドコッ！」に隠れないように） */
        /* 水平面の観測者を選んでいるときは、名前を地面の下に書く。
           発射口の真下あたりに立つので、着地の「ドコッ！」に隠れてしまうため。 */
        observer(ctx, gox, gy1, 0, -1, '水平面の観測者', !crt, 26,
          crt ? { dy: 4, dx: 12, align: 'left' } : { dy: 64, dx: -10, align: 'right' });
      }
      /* 台車の上の観測者：台車のうしろに乗っている */
      /* 名前は1段高く書く（水平面の観測者と近づいたときに文字が重ならないように） */
      observer(ctx, XX(m.xA) - 44, gy1 - 13, 0, -1, '台車の上の観測者', crt, 20, { dx: -4, dy: -12, align: 'right' });
    })();

    var vxSee = crt ? 0 : v.V;                    /* その観測者から見たBの水平速度 */
    if (s.o.showV) {
      if (!crt) {
        arrow(ctx, XX(m.xA), Y(0) - 12, XX(m.xA) + Math.max(0, v.V) * 4, Y(0) - 12, 'vel');
        label(ctx, 'V = ' + fmt(v.V, 0) + ' m/s', XX(m.xA) + v.V * 2, Y(0) - 25, { size: 11, color: COL.vel });
      } else if (v.V > 0.05) {
        label(ctx, '台車は止まって見える（V′ = 0）', XX(m.xA), Y(0) - 25, { size: 10.5, color: COL.sub });
      }
      arrow(ctx, bpx, bpy, bpx + vxSee * 4, bpy - m.vyB * 4, 'vel');
    }
    if (s.o.showVc) {
      if (Math.abs(vxSee) > 0.05) {
        arrow(ctx, bpx, bpy, bpx + vxSee * 4, bpy, 'velx');
        label(ctx, hintOn(s, t) ? 'v_x = V（変わらない）' : 'v_x = V', bpx + vxSee * 4 + 5, bpy + 12,
          { align: 'left', size: 11, color: COL.velx, bold: true });
      } else if (crt && v.V > 0.05) {
        label(ctx, "v_x' = 0（真上にしか動かない）", bpx + 12, bpy + 14,
          { align: 'left', size: 11, color: COL.velx, bold: true });
      }
      if (Math.abs(m.vyB) > 0.2) {
        arrow(ctx, bpx, bpy, bpx, bpy - m.vyB * 4, 'vely');
        label(ctx, crt ? "v_y'" : 'v_y', bpx - 8, bpy - m.vyB * 2.2, { align: 'right', size: 11, color: COL.vely, bold: true });
      }
      drawVelAngle(ctx, bpx, bpy, { vx: vxSee, vy: m.vyB }, 4);
    }
    label(ctx, 't = ' + fmt(t, 2) + ' s', 10, 16, { align: 'left', size: 13.5, bold: true });
    drawPosNote(ctx, DEFS['m3-2'], s, W, 34);
    if (v.V > 0.05 && t < tL && hintOn(s, t)) {
      label(ctx, crt ? '地面が後ろへ流れていく（まだ発射しない）' : '等速で進んでいる（まだ発射しない）',
        XX(m.xA), Y(0) - 46, { size: 11, color: COL.sub });
    }
    /* 発射の瞬間は、台車が止まっていても走っていても「発射！」と出す */
    if (t >= tL - 1e-9 && t < tL + 0.34) {
      bubble(ctx, '発射！', XX(m.xA), Y(0) - MUZZLE - 34,
        { size: 13.5, bg: '#fff0e2', border: '#e07b18', color: '#a85a08' });
    }
    if (t >= T - 1e-9) {
      impact(ctx, XX(m.xA), Y(0) - 2, 20, 'ドコッ！');
      bubble(ctx, crt ? '真下にもどってきた！' : 'Aの発射口にもどってきた！', XX(m.xA), Y(0) - 36,
        { size: 12.5, bg: '#e6f7ea', border: '#1c8f4a', color: '#14713a' });
    }
  },
  info: function (s, t) {
    var v = V(s), m = P.m32.sample(v, t);
    return [
      ['Aの位置 $x_A$', fmt(m.xA, 2) + ' m'],
      ['Bの位置 $x_B$', fmt(m.xB, 2) + ' m'],
      ['$x_B - x_A$（ずれ）', fmt(m.xB - m.xA, 3) + ' m'],
      ['Bの高さ $y_B$', fmt(m.yB * s.sign, 2) + ' m'],
      ['Bの鉛直速度 $v_y$', fmt(m.vyB * s.sign, 2) + ' m/s'],
      ['もどってくる時刻 $2u/g$', fmt(P.m32.tEnd(v), 2) + ' s']
    ];
  },
  eq: function (s) {
    return '\\text{水平：} x_B = Vt = x_A \\quad(\\text{ずれは常に }0)\\qquad \\text{鉛直：} y_B = ut - \\tfrac{1}{2}gt^2';
  },
  note: '台車が <b>x＝5 m</b> に来たところで真上に発射する。x–t 図でAとBの線が<b>ぴったり重なる</b>のがポイント。台車から見ると（＝Aといっしょに動く目で見ると）、Bはただの<b>鉛直投げ上げ</b>に見える。'
};

/* ============ 3-3 モンキーハンティング ============ */
DEFS['m3-3'] = {
  id: 'm3-3', mode: 3, tab: '3-3 モンキーハンティングゲーム', game: true, startSfx: 'bang',
  title: '3-3　モンキーハンティングゲーム　〜猿に当てるにはどうしたらいいか？〜',
  desc: '発射と同時に、猿は枝から手をはなして自由落下する。猿をまっすぐねらった向きで撃つと、必ず当たる。',
  sub: '発射角 θ はスライダーで変えられる。弾も猿も、同じ時間だけ ½gt² だけ落ちることがポイント。',
  cw: 520, ch: 360,
  vis: ['F', 'V', 'Vc'],
  signLabels: ['上向きを正', '下向きを正'],
  mainVars: '*',
  vars: [
    { k: 'v0', label: '発射の速さ $v_0$', unit: ' m/s', min: 8, max: 40, step: 1, dec: 0, def: 20 },
    { k: 'th', label: '発射の角 $\\theta$', unit: '°', min: 5, max: 80, step: 1, dec: 0, def: 25 },
    { k: 'mx', label: '猿の位置 $x$', unit: ' m', min: 8, max: 45, step: 1, dec: 0, def: 20 },
    { k: 'my', label: '猿の位置 $y$', unit: ' m', min: 5, max: 30, step: 1, dec: 0, def: 12 }
  ],
  toggles: [{ k: 'aim', label: 'ねらいの線を表示', def: true }],
  tEnd: function (v) { return P.m33.tEnd(v); },
  tGraph: function (v) { return P.m33.tGraph(v); },
  sample: function (v, t) { return P.m33.sample(v, Math.min(t, P.m33.tGraph(v))); },
  graphs: [
    { key: 'y', short: '$y$–$t$ 図', title: '$y$–$t$ 図（弾と猿の高さ）', ylabel: 'y [m]', open: true, signed: true, legend: true,
      series: [{ name: '弾', color: COL.A, f: function (m) { return m.yA; } },
        { name: '猿', color: COL.B, f: function (m) { return m.yB; } }],
      fml: function (v, sg) {
        var vy0 = v.v0 * Math.sin(v.th * DEG);
        return ['y = y_0 + v_{y0}t + \\tfrac{1}{2}at^2',
          '弾: y = v_0\\sin\\theta\\,t - \\tfrac{1}{2}gt^2 \\qquad 猿: y = y_m - \\tfrac{1}{2}gt^2',
          '弾: y = ' + fmt(vy0 * sg, 2) + 't + \\tfrac{1}{2}(' + fmt(-G * sg, 2) + ')t^2 \\quad 猿: y = ' +
          fmt(v.my * sg, 0) + ' + \\tfrac{1}{2}(' + fmt(-G * sg, 2) + ')t^2'];
      } },
    { key: 'x', short: '$x$–$t$ 図', title: '$x$–$t$ 図（弾と猿の水平位置）', ylabel: 'x [m]', open: false, signed: false, legend: true,
      series: [{ name: '弾', color: COL.A, f: function (m) { return m.xA; } },
        { name: '猿', color: COL.B, f: function (m) { return m.xB; } }],
      fml: function (v, sg) {
        var vx = v.v0 * Math.cos(v.th * DEG);
        return ['x = v_x t', '弾: x = v_0\\cos\\theta\\, t \\qquad 猿: x = x_m（動かない）',
          '弾: x = ' + fmt(vx, 2) + 't \\quad 猿: x = ' + fmt(v.mx, 0)];
      } },
    { key: 'v', short: '$v_y$–$t$ 図', title: '$v_y$–$t$ 図（弾と猿：傾きが同じ）', ylabel: 'vy [m/s]', open: true, signed: true, legend: true,
      series: [{ name: '弾', color: COL.A, f: function (m) { return m.vyA; } },
        { name: '猿', color: COL.B, f: function (m) { return m.vyB; }, dash: [6, 4] }],
      fml: function (v, sg) {
        var vy0 = v.v0 * Math.sin(v.th * DEG);
        return ['v_y = v_{y0} + at', '弾: v_y = v_0\\sin\\theta - gt \\qquad 猿: v_y = -gt',
          '弾: v_y = ' + fmt(vy0 * sg, 2) + ' + (' + fmt(-G * sg, 2) + ')t \\quad 猿: v_y = (' + fmt(-G * sg, 2) + ')t'];
      } }
  ],
  draw: function (ctx, s, t, W, H) {
    var v = V(s), T = P.m33.tEnd(v), Tc = P.m33.tGraph(v), aim = P.m33.aimDeg(v), hit = P.m33.hit(v);
    /* 表示範囲は猿の位置だけで決める（θ を変えても図の大きさが変わらないように） */
    var xMax = Math.max(v.mx + 10, 24);
    var yMax = Math.max(v.my + 7, 16);
    var pad = { l: 44, r: 18, t: 30, b: 38 };
    var sc = Math.min((W - pad.l - pad.r) / xMax, (H - pad.t - pad.b) / yMax);
    function X(x) { return pad.l + x * sc; }
    function Y(y) { return H - pad.b - y * sc; }
    s.view = {
      invX: function (px) { return (px - pad.l) / sc; },
      invY: function (py) { return (H - pad.b - py) / sc; }
    };
    ground(ctx, 20, W - 14, Y(0));
    axisX(ctx, X, Y(0), 0, xMax * 0.96, 'x [m]', 1, { target: 5 });
    axisY(ctx, Y, X(0), 0, yMax * 0.94, 'y [m]', s.sign, { target: 4 });
    originMark(ctx, X(0), Y(0), -13, 13);

    tree(ctx, X(v.mx), Y(0), Math.max(36, (v.my + 1.4) * sc));
    if (s.o.aim) {
      ctx.save(); ctx.strokeStyle = '#9aa3ac'; ctx.setLineDash([5, 5]); ctx.lineWidth = 1.3;
      ctx.beginPath(); ctx.moveTo(X(0), Y(0)); ctx.lineTo(X(v.mx), Y(v.my)); ctx.stroke(); ctx.restore();
    }
    /* 猿の位置 x・y を寸法線で示す */
    arrow(ctx, X(0), Y(0) + 18, X(v.mx), Y(0) + 18, 'dim');
    label(ctx, 'x', (X(0) + X(v.mx)) / 2, Y(0) + 32, { size: 13, bold: true });
    arrow(ctx, X(v.mx) + 26, Y(0), X(v.mx) + 26, Y(v.my), 'dim');
    label(ctx, 'y', X(v.mx) + 38, (Y(0) + Y(v.my)) / 2, { size: 13, bold: true });
    ctx.save(); ctx.strokeStyle = '#c0392b'; ctx.setLineDash([4, 4]); ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(X(0), Y(0));
    ctx.lineTo(X(0) + Math.cos(v.th * DEG) * 92, Y(0) - Math.sin(v.th * DEG) * 92); ctx.stroke(); ctx.restore();
    angArc(ctx, X(0), Y(0), 44, -v.th * DEG, 0, 'θ = ' + fmt(v.th, 0) + '°',
      -v.th * DEG * 0.28, 66);

    var i, tb = Math.min(t, Tc), ricT = Math.max(0, t - Tc);
    var pathAt = function (tt) { return hit ? P.m33.bullet(v, tt) : P.m33.path(v, tt); };
    ctx.save(); ctx.strokeStyle = '#e07b18'; ctx.lineWidth = 2.2;
    ctx.beginPath();
    var n = Math.max(2, Math.round(140 * tb / Math.max(1e-6, Tc)));
    for (i = 0; i <= n; i++) { var b = pathAt(tb * i / n); if (i === 0) ctx.moveTo(X(b.x), Y(b.y)); else ctx.lineTo(X(b.x), Y(b.y)); }
    ctx.stroke(); ctx.restore();
    if (ricT > 0) {                                   /* はね返った弾の道すじ */
      ctx.save(); ctx.strokeStyle = '#e07b18'; ctx.lineWidth = 1.6; ctx.setLineDash([5, 4]);
      ctx.beginPath();
      for (i = 0; i <= 24; i++) { var r0 = P.m33.ric(v, Tc + ricT * i / 24); if (i === 0) ctx.moveTo(X(r0.x), Y(r0.y)); else ctx.lineTo(X(r0.x), Y(r0.y)); }
      ctx.stroke(); ctx.restore();
    }

    /* 銃はうすく描く（v₀ の矢印を見やすくするため）。
       銃身の中心線が「原点にある弾」をぴったり通るように、
       ずらすのは銃身にそった向きだけにする（横にずらすと角度で見た目がずれる）。 */
    ctx.save(); ctx.globalAlpha = 0.38;
    corkGun(ctx, X(0) - Math.cos(v.th * DEG) * 12, Y(0) + Math.sin(v.th * DEG) * 12, v.th * DEG);
    ctx.restore();
    /* 初速度 v₀ の矢印は、いま原点にいる小球（弾）を始点にして、銃より前面に描く */
    if (t < 1e-9) {
      var gx0 = X(0), gy0 = Y(0);
      var vL = Math.max(56, v.v0 * 3.2);
      arrow(ctx, gx0, gy0, gx0 + Math.cos(v.th * DEG) * vL, gy0 - Math.sin(v.th * DEG) * vL, 'vel');
      label(ctx, 'v₀ = ' + fmt(v.v0, 0) + ' m/s',
        gx0 + Math.cos(v.th * DEG) * vL + 10, gy0 - Math.sin(v.th * DEG) * vL - 14,
        { align: 'left', size: 12.5, bold: true, color: COL.vel });
    }
    var m = P.m33.sample(v, tb);
    var bx = m.xA, by = m.yA, bvx = m.vxA, bvy = m.vyA;
    if (ricT > 0) { var rr = P.m33.ric(v, t); bx = rr.x; by = rr.y; bvx = rr.vx; bvy = rr.vy; }
    monkeyShape(ctx, X(m.xB), Y(m.yB), Math.max(10, 1.1 * sc));
    ball(ctx, X(bx), Y(by), 6, 'B');
    if (s.o.showF) {
      /* 弾にはたらく力＝あかるい色、猿にはたらく力＝こい色 */
      arrow(ctx, X(bx), Y(by), X(bx), Y(by) + 38, 'force', 1, fcol('A', COL.force));
      label(ctx, '弾：mg', X(bx) - 9, Y(by) + 32, { align: 'right', size: 10.5, color: fcol('A', COL.force) });
      arrow(ctx, X(m.xB), Y(m.yB), X(m.xB), Y(m.yB) + 38, 'force', 1, fcol('B', COL.force));
      label(ctx, '猿：mg', X(m.xB) + 9, Y(m.yB) + 32, { align: 'left', size: 10.5, color: fcol('B', COL.force) });
    }
    if (s.o.showV && t > 0.02) {
      arrow(ctx, X(bx), Y(by), X(bx) + bvx * 2.1, Y(by) - bvy * 2.1, 'vel');
      if (Math.abs(m.vyB) > 0.3) arrow(ctx, X(m.xB), Y(m.yB), X(m.xB), Y(m.yB) - m.vyB * 2.1, 'vel');
    }
    if (s.o.showVc && t > 0.02) {
      arrow(ctx, X(bx), Y(by), X(bx) + bvx * 2.1, Y(by), 'velx');
      arrow(ctx, X(bx), Y(by), X(bx), Y(by) - bvy * 2.1, 'vely');
      drawVelAngle(ctx, X(bx), Y(by), { vx: bvx, vy: bvy }, 2.1);
    }
    label(ctx, 't = ' + fmt(t, 2) + ' s', 10, 16, { align: 'left', size: 13.5, bold: true });
    drawPosNote(ctx, DEFS['m3-3'], s, W, 16);
    if (t > 1e-9 && t < 0.28) impact(ctx, X(0) + 34, Y(0) - 26, 16, 'ばん！');
    /* 発射の音におどろいて、猿はこの瞬間に枝から手を放す */
    if (t < 0.34) {
      bubble(ctx, '銃の音にびっくりして手を放す',
        clamp(X(m.xB) - 6, 96, W - 96), Math.max(46, Y(m.yB) - 40),
        { size: 12, bg: '#fff6e0', border: '#d9a545', color: '#8a5a10' });
    }
    if (hit && ricT > 0) {                            /* 当たった瞬間から：猿が「いて！」 */
      var bc = P.m33.bullet(v, Tc);
      impact(ctx, (X(m.xB) + X(bc.x)) / 2 - 30, (Y(m.yB) + Y(bc.y)) / 2 + 26, 20, 'ドコッ！');
      monkeyShape(ctx, X(m.xB), Y(m.yB), Math.max(10, 1.1 * sc));   /* 星の上に猿を描き直す */
      bubble(ctx, 'いて！', X(m.xB) + 30, Y(m.yB) - 34,
        { size: 14, bg: '#fff0f0', border: '#c0392b', color: '#a52a1a' });
    }
    if (t >= T - 1e-9) {
      if (hit) {
        bubble(ctx, '命中！　猿をねらえば必ず当たる', X(m.xB) - 20, Math.max(52, Y(m.yB) - 76),
          { size: 13, bg: '#e6f7ea', border: '#1c8f4a', color: '#14713a' });
      } else {
        bubble(ctx, 'はずれ… 角度を変えてみよう', X(Math.min(v.mx, xMax * 0.7)), Math.max(60, Y(m.yB) - 60), { size: 12.5 });
      }
    }
    /* 猿より先に弾が地面に落ちたら、猿は助かる */
    if (!hit && P.m33.safe(v) && t >= P.m33.tGround(v) - 1e-9) {
      bubble(ctx, '助かった！', X(m.xB) + 52, Y(m.yB) - 22,
        { size: 13, bg: '#e6f7ea', border: '#1c8f4a', color: '#14713a' });
    }
  },
  info: function (s, t) {
    var v = V(s), m = P.m33.sample(v, Math.min(t, P.m33.tGraph(v))), c = P.m33.closest(v);
    return [
      ['ねらいの角 $\\arctan(y/x)$', fmt(P.m33.aimDeg(v), 2) + '°'],
      ['いまの発射角 $\\theta$', fmt(v.th, 0) + '°'],
      ['弾と猿の最接近距離', fmt(c.d, 3) + ' m'],
      ['最接近の時刻', fmt(c.t, 2) + ' s'],
      ['弾の高さ', fmt(m.yA * s.sign, 2) + ' m'],
      ['猿の高さ', fmt(m.yB * s.sign, 2) + ' m'],
      ['判定', P.m33.hit(v) ? '命中' : 'はずれ']
    ];
  },
  eq: function (s) {
    return '\\text{弾) } y = x\\tan\\theta - \\dfrac{g x^2}{2v_0^2\\cos^2\\theta}, \\quad \\text{猿) } y = y_m - \\tfrac{1}{2}gt^2 \\;\\Rightarrow\\; \\tan\\theta = \\dfrac{y_m}{x_m} \\text{ なら命中}';
  },
  note: '弾も猿も、同じ時間だけ <span class="tex">\\tfrac{1}{2}gt^2</span> だけ「まっすぐ進む場合」より下に落ちる。だから<b>まっすぐねらった線の上で、2つは同じだけ落ちて出会う</b>。'
};
