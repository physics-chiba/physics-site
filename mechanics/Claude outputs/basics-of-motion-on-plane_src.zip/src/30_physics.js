/* 純粋な物理計算だけ（描画を混ぜない）。同じ入力 → 同じ出力。 */
'use strict';
var G = 9.8;
var DEG = Math.PI / 180;

function clamp(x, a, b) { return x < a ? a : (x > b ? b : x); }
function fmt(x, d) {
  if (d === undefined) d = 1;
  var s = x.toFixed(d);
  if (s === '-' + (0).toFixed(d)) s = (0).toFixed(d);   /* −0.0 を出さない */
  return s;
}

var P = {};

/* ============ モード1 ============ */

/* 1-1 なめらかな斜面上の物体（斜面上向きを正） */
P.m11 = {
  /* 1-1 は「θ>0 が下り坂」。x 軸は斜面にそって右向きが正なので a = +g sinθ */
  a: function (v) { return G * Math.sin(v.th * DEG); },
  tEnd: function (v) {
    var a = P.m11.a(v), v0 = v.v0;
    if (Math.abs(a) < 1e-9) return 4.0;                 /* 水平：等速直線運動 */
    if (v0 * a < -1e-9) return Math.max(0.4, -2 * v0 / a);   /* 減速→出発点に戻るまで */
    var A = Math.abs(a), V = Math.abs(v0);              /* 加速していく：6 m すべるまで */
    return Math.max(0.4, (-V + Math.sqrt(V * V + 12 * A)) / A);
  },
  s: function (v, t) { return v.v0 * t + 0.5 * P.m11.a(v) * t * t; },
  vel: function (v, t) { return v.v0 + P.m11.a(v) * t; },
  sample: function (v, t) {
    return { x: P.m11.s(v, t), v: P.m11.vel(v, t), a: P.m11.a(v) };
  }
};

/* 1-2 鉛直落下（下向きを正。v0>0 は下向きに投げおろし） */
P.m12 = {
  tEnd: function (v) { return (-v.v0 + Math.sqrt(v.v0 * v.v0 + 2 * G * v.h)) / G; },
  sample: function (v, t) {
    return { x: v.v0 * t + 0.5 * G * t * t, v: v.v0 + G * t, a: G };
  }
};

/* 1-3 鉛直投げ上げ（上向きを正。y0＝投げ始める点の座標、H＝そこから地面までの高さ） */
P.m13 = {
  tEnd: function (v) { return (v.v0 + Math.sqrt(v.v0 * v.v0 + 2 * G * v.H)) / G; },
  tTop: function (v) { return v.v0 / G; },
  yTop: function (v) { return v.y0 + v.v0 * v.v0 / (2 * G); },
  ground: function (v) { return v.y0 - v.H; },
  sample: function (v, t) {
    return { x: v.y0 + v.v0 * t - 0.5 * G * t * t, v: v.v0 - G * t, a: -G };
  }
};

/* 1-4 手で斜面上向きに引く（斜面上向きを正）。摩擦の静止条件も扱う。
   数値積分の表をつくって、t からは補間で読む（同じ入力 → 同じ表）。 */
P.m14 = {
  SLOPE_LEN: 6,           /* 斜面の長さ [m] */
  DT: 0.004,
  TMAX: 5.0,
  _key: null, _tab: null,
  table: function (v) {
    var LEN = v.LEN || P.m14.SLOPE_LEN, TMAX = v.TMAX || P.m14.TMAX;
    var F = (v.F || 0) - (v.F2 || 0);   /* F2 は逆向き（斜面下向き・左向き）に引く力（1-4） */
    var key = [F, v.m, v.th, v.mu, v.mud, v.v0, LEN, TMAX].join('|');
    if (P.m14._key === key) return P.m14._tab;
    var dt = P.m14.DT, N = Math.round(TMAX / dt);
    var th = v.th * DEG;
    var mg = v.m * G;
    var Nn = mg * Math.cos(th);          /* 垂直抗力 */
    var gs = mg * Math.sin(th);          /* 重力の斜面方向成分（下向き） */
    var s = 0, vel = v.v0, arr = [], i;
    for (i = 0; i <= N; i++) {
      var drive = F - gs;                /* 摩擦以外の斜面方向の合力（上向き正） */
      var a, f, still;
      if (Math.abs(vel) < 1e-9) {
        if (Math.abs(drive) <= v.mu * Nn + 1e-12) { a = 0; f = -drive; still = true; }
        else { var sg = drive > 0 ? 1 : -1; f = -sg * v.mud * Nn; a = (drive + f) / v.m; still = false; }
      } else {
        var sg2 = vel > 0 ? 1 : -1;
        f = -sg2 * v.mud * Nn;
        a = (drive + f) / v.m;
        still = false;
      }
      arr.push({ t: i * dt, x: s, v: vel, a: a, f: f, N: Nn, still: still });
      var vN = vel + a * dt;
      if (vel * vN < 0) vN = 0;          /* 速度が0を横切ったら 0 にして静止判定へ */
      s += (vel + vN) / 2 * dt;
      vel = vN;
      if (s > LEN || s < -LEN) break;
    }
    P.m14._key = key; P.m14._tab = arr;
    return arr;
  },
  tEnd: function (v) {
    var tb = P.m14.table(v);
    return tb[tb.length - 1].t;
  },
  sample: function (v, t) {
    var tb = P.m14.table(v);
    var i = clamp(Math.round(t / P.m14.DT), 0, tb.length - 1);
    return tb[i];
  },
  /* 静止しているか（t=0 での判定） */
  staticAtStart: function (v) {
    var th = v.th * DEG;
    var Nn = v.m * G * Math.cos(th), gs = v.m * G * Math.sin(th);
    return Math.abs(v.v0) < 1e-9 && Math.abs((v.F || 0) - (v.F2 || 0) - gs) <= v.mu * Nn + 1e-12;
  },
  a0: function (v) { return P.m14.sample(v, 0).a; },
  /* 止まる時刻（動き出したあと、静止してそのまま止まる時刻） */
  tStop: function (v) {
    var tb = P.m14.table(v), i;
    for (i = 3; i < tb.length; i++) {
      if (tb[i].still && Math.abs(tb[i].v) < 1e-12) return tb[i].t;
    }
    return tb[tb.length - 1].t;
  },
  xStop: function (v) { return P.m14.sample(v, P.m14.tStop(v)).x; },
  /* 止まる位置を式で正しく出す（表の計算は氷の長さ LEN で打ち切るので、
     100 m 行き過ぎても 50 m としか出ない。それを直すためのもの）。
     外から力を加えず、v0>0 で一定の減速だけがはたらく場合（1-6 カーリング）に使う。 */
  decel: function (v) {
    var th = v.th * DEG;
    return G * (v.mud * Math.cos(th) + Math.sin(th));     /* 減速の大きさ [m/s²] */
  },
  xStopIdeal: function (v) {
    var dec = P.m14.decel(v);
    if (dec < 1e-9) return Infinity;
    return v.v0 * v.v0 / (2 * dec);
  }
};

/* ============ モード2 ============ */

/* 2-1 ストロボ比較（pair 'A'：自由落下と水平投射／pair 'B'：鉛直投げ上げと斜方投射） */
P.m21 = {
  DROP: 20,   /* A のとき落とす高さ [m] */
  tEnd: function (v) {
    if (v.pair === 'A') return Math.sqrt(2 * P.m21.DROP / G);
    return 2 * v.v0 * Math.sin(v.th * DEG) / G;
  },
  /* 左（鉛直だけの運動） */
  left: function (v, t) {
    var vy0 = (v.pair === 'A') ? 0 : v.v0 * Math.sin(v.th * DEG);
    return { x: 0, y: vy0 * t - 0.5 * G * t * t, vy: vy0 - G * t };
  },
  /* 右（水平成分をもつ運動） */
  right: function (v, t) {
    var vx0 = (v.pair === 'A') ? v.v0 : v.v0 * Math.cos(v.th * DEG);
    var vy0 = (v.pair === 'A') ? 0 : v.v0 * Math.sin(v.th * DEG);
    return { x: vx0 * t, y: vy0 * t - 0.5 * G * t * t, vx: vx0, vy: vy0 - G * t };
  },
  sample: function (v, t) {
    var L = P.m21.left(v, t), R = P.m21.right(v, t);
    return { x: R.x, y: R.y, yL: L.y, vy: R.vy, vx: R.vx || 0, a: -G };
  }
};

/* 2-2 原点からの斜方投射（上向き正・地面なし） */
P.m22 = {
  /* アニメーションは「原点と同じ高さ（y=0）にもどったとき」で止める。
     θ=0（水平投射）は y=0 にもどらないので、落ちていく様子を 1.8 s ぶん見せる。 */
  tEnd: function (v) {
    var up = 2 * v.v0 * Math.sin(v.th * DEG) / G;
    return (up > 1e-9) ? up : 1.8;
  },
  /* 左の図の放物線だけは y=0 のあとも描く（そのあとどう落ちるかを見せるため）。
     上がったのと同じ高さぶんだけ下まで描くと、上下が対称に見えて図がつぶれない。
     y = -H になる時刻は t_top(1+√2) ＝ tEnd(1+√2)/2。 */
  tDraw: function (v) {
    var up = 2 * v.v0 * Math.sin(v.th * DEG) / G;
    var sym = up * (1 + Math.SQRT2) / 2;
    return Math.max(P.m22.tEnd(v), sym, Math.min(1.8, up + 1.0));
  },
  /* 最高点までの時間と、最高点の高さ */
  tTop: function (v) { return v.v0 * Math.sin(v.th * DEG) / G; },
  yTop: function (v) { var u = v.v0 * Math.sin(v.th * DEG); return u * u / (2 * G); },
  sample: function (v, t) {
    var vx = v.v0 * Math.cos(v.th * DEG), vy0 = v.v0 * Math.sin(v.th * DEG);
    var vy = vy0 - G * t;
    return {
      x: vx * t, y: vy0 * t - 0.5 * G * t * t,
      vx: vx, vy: vy, v: Math.hypot(vx, vy), ax: 0, ay: -G, t: t
    };
  }
};

/* 2-3 ビルの上からの斜方投射。原点の取り方 org: 'launch'|'base'|'landing' */
P.m23 = {
  tEnd: function (v) {
    var vy0 = v.v0 * Math.sin(v.th * DEG);
    return (vy0 + Math.sqrt(vy0 * vy0 + 2 * G * v.H)) / G;
  },
  /* 投射点を基準にした座標 */
  raw: function (v, t) {
    var vx = v.v0 * Math.cos(v.th * DEG), vy0 = v.v0 * Math.sin(v.th * DEG);
    return { X: vx * t, Y: vy0 * t - 0.5 * G * t * t, vx: vx, vy: vy0 - G * t };
  },
  range: function (v) { return P.m23.raw(v, P.m23.tEnd(v)).X; },
  origin: function (v) {
    if (v.org === 'base') return { ox: 0, oy: -v.H };
    if (v.org === 'landing') return { ox: P.m23.range(v), oy: -v.H };
    return { ox: 0, oy: 0 };
  },
  sample: function (v, t) {
    var r = P.m23.raw(v, t), o = P.m23.origin(v);
    return {
      x: r.X - o.ox, y: r.Y - o.oy, X: r.X, Y: r.Y,
      vx: r.vx, vy: r.vy, v: Math.hypot(r.vx, r.vy), ax: 0, ay: -G
    };
  }
};

/* 2-4 かご入れゲーム（地面 y=0 から投射） */
P.m24 = {
  flight: function (v) { return 2 * v.v0 * Math.sin(v.th * DEG) / G; },
  raw: function (v, t) {
    var vx = v.v0 * Math.cos(v.th * DEG), vy0 = v.v0 * Math.sin(v.th * DEG);
    return { x: vx * t, y: vy0 * t - 0.5 * G * t * t, vx: vx, vy: vy0 - G * t };
  },
  /* かごに入る時刻（入らなければ null）。かごの口＝ y=by, x∈[bx-W/2, bx+W/2] を下向きに通過 */
  W: 3.6,
  catchT: function (v) {
    var T = P.m24.flight(v), n = 800, i, prev = null;
    for (i = 0; i <= n; i++) {
      var t = T * i / n, p = P.m24.raw(v, t);
      if (prev && p.vy < 0 && prev.y >= v.by && p.y <= v.by) {
        var f = (prev.y - v.by) / (prev.y - p.y || 1);
        var xc = prev.x + (p.x - prev.x) * f;
        if (Math.abs(xc - v.bx) <= P.m24.W / 2) return T * (i - 1 + f) / n;
      }
      prev = p;
    }
    return null;
  },
  tEnd: function (v) { var c = P.m24.catchT(v); return c !== null ? c : P.m24.flight(v); },
  sample: function (v, t) {
    var p = P.m24.raw(v, t);
    return { x: p.x, y: p.y, vx: p.vx, vy: p.vy, v: Math.hypot(p.vx, p.vy), ax: 0, ay: -G };
  }
};

/* 2-5 斜面の上からの斜方投射。θ＝斜面の傾き（右下がり）、Φ＝斜面から測った投射角 */
P.m25 = {
  /* θ は「斜面が右上がり（のぼり）」を正とする。斜面は y = x tanθ */
  beta: function (v) { return (v.phi + v.th) * DEG; },   /* 水平から測った投射角 */
  tan: function (v) { return Math.tan(v.th * DEG); },
  tEnd: function (v) {
    var b = P.m25.beta(v), tt = P.m25.tan(v);
    var T = 2 * v.v0 * (Math.sin(b) - Math.cos(b) * tt) / G;
    return Math.max(0.2, T);
  },
  sample: function (v, t) {
    var b = P.m25.beta(v), th = v.th * DEG;
    var ct = Math.cos(th), stn = Math.sin(th);
    var vx = v.v0 * Math.cos(b), vy0 = v.v0 * Math.sin(b);
    var x = vx * t, y = vy0 * t - 0.5 * G * t * t;
    var vy = vy0 - G * t;
    return {
      x: x, y: y, vx: vx, vy: vy, v: Math.hypot(vx, vy), ax: 0, ay: -G,
      /* 斜面にそった座標：X は斜面を上る向き、Y は斜面に垂直（面から離れる向き） */
      X: x * ct + y * stn, Y: -x * stn + y * ct,
      vX: vx * ct + vy * stn, vY: -vx * stn + vy * ct,
      aX: -G * stn, aY: -G * ct
    };
  },
  /* 斜面にそった飛距離 */
  rangeOnSlope: function (v) {
    var T = P.m25.tEnd(v), p = P.m25.sample(v, T);
    return Math.hypot(p.x, p.y);
  }
};

/* 2-6 なめらかな斜面の上を転がる小球（斜面内の2次元運動）
   X：斜面の水平方向（等速）、Y：斜面上向き（等加速度 a = -g sinθ）
   alpha：斜面上向き（Y軸）から測った初速度の向き */
P.m26 = {
  a: function (v) { return -G * Math.sin(v.th * DEG); },
  tEnd: function (v) {
    var a = P.m26.a(v), vy0 = v.v0 * Math.cos(v.al * DEG);
    if (-a < 1e-9) return 4;
    return Math.max(0.3, 2 * vy0 / (-a));
  },
  sample: function (v, t) {
    var a = P.m26.a(v);                                   /* 斜面上向きの加速度 = -g sinθ */
    var th = v.th * DEG, ct = Math.cos(th), stn = Math.sin(th);
    var vx = v.v0 * Math.sin(v.al * DEG);                 /* 斜面の横方向（折り目の向き） */
    var vy0 = v.v0 * Math.cos(v.al * DEG);                /* 斜面上向き */
    var Yu = vy0 * t + 0.5 * a * t * t, vYu = vy0 + a * t;
    var Xt = vx * t;
    return {
      x: Xt, y: Yu, vx: vx, vy: vYu, v: Math.hypot(vx, vYu), ax: 0, ay: a,
      /* 斜面の中の座標：X＝斜面上向き、Y＝斜面の横方向、Z＝斜面に垂直（いつも 0） */
      sX: Yu, sY: Xt, sZ: 0,
      svX: vYu, svY: vx, svZ: 0,
      saX: a, saY: 0, saZ: 0,
      /* もとの水平・鉛直：x＝水平で斜面を上る向き、y＝折り目の向き、z＝鉛直上向き */
      wx: Yu * ct, wy: Xt, wz: Yu * stn,
      wvx: vYu * ct, wvy: vx, wvz: vYu * stn,
      wax: a * ct, way: 0, waz: a * stn
    };
  }
};

/* ============ モード3 ============ */

/* 3-1 自由落下B と 鉛直投げ上げA の衝突（上向き正、地面 y=0） */
P.m31 = {
  tCol: function (v) {
    var t = v.H / v.v0;                                  /* yA = yB となる時刻 */
    var tGround = Math.sqrt(2 * v.H / G);                /* B が地面に着く時刻 */
    var tA = 2 * v.v0 / G;                               /* A が地面に戻る時刻 */
    if (t <= tGround + 1e-12 && t <= tA + 1e-12) return t;
    return null;
  },
  tEnd: function (v) {
    var tc = P.m31.tCol(v);
    if (tc !== null) return tc;
    return Math.min(Math.sqrt(2 * v.H / G), 2 * v.v0 / G);
  },
  A: function (v, t) { return { y: v.v0 * t - 0.5 * G * t * t, v: v.v0 - G * t }; },
  B: function (v, t) { return { y: v.H - 0.5 * G * t * t, v: -G * t }; },
  sample: function (v, t) {
    var A = P.m31.A(v, t), B = P.m31.B(v, t);
    return { yA: A.y, yB: B.y, vA: A.v, vB: B.v, aA: -G, aB: -G, rel: A.v - B.v };
  }
};

/* 3-2 等速直線運動する台車A から真上に発射される小球B */
P.m32 = {
  LAUNCH_X: 5,                                   /* ここまで等速で進んでから発射する */
  tLaunch: function (v) {
    return (v.V > 0.05) ? Math.min(P.m32.LAUNCH_X / v.V, 4) : 0;
  },
  tEnd: function (v) { return P.m32.tLaunch(v) + 2 * v.u / G; },
  sample: function (v, t) {
    var t0 = P.m32.tLaunch(v), tf = Math.max(0, t - t0);
    var flying = t >= t0;
    return {
      xA: v.V * t, yA: 0, vA: v.V,
      xB: v.V * t, yB: flying ? v.u * tf - 0.5 * G * tf * tf : 0,
      vxB: v.V, vyB: flying ? v.u - G * tf : 0,
      t0: t0, flying: flying
    };
  }
};

/* 3-3 モンキーハンティング（銃は原点、猿は (mx, my)） */
P.m33 = {
  /* 重い探索（1200点ループ）は同じ設定なら使いまわす。
     これをしないと、グラフを1枚描くたびに数十万回の計算になり、動きがどんどん重くなる。 */
  _c: { k: null, m: null },
  memo: function (v, name, fn) {
    var k = v.v0 + '|' + v.th + '|' + v.mx + '|' + v.my;
    var c = P.m33._c;
    if (c.k !== k) { c.k = k; c.m = {}; }
    if (!(name in c.m)) c.m[name] = fn(v);
    return c.m[name];
  },
  aimDeg: function (v) { return Math.atan2(v.my, v.mx) / DEG; },
  bullet: function (v, t) {
    var vx = v.v0 * Math.cos(v.th * DEG), vy0 = v.v0 * Math.sin(v.th * DEG);
    return { x: vx * t, y: vy0 * t - 0.5 * G * t * t, vx: vx, vy: vy0 - G * t };
  },
  monkey: function (v, t) { return { x: v.mx, y: v.my - 0.5 * G * t * t, vy: -G * t }; },
  /* 最接近の時刻と距離 */
  closest: function (v) { return P.m33.memo(v, 'closest', P.m33._closest); },
  _closest: function (v) {
    var T = P.m33.limit(v), n = 1200, best = { t: 0, d: 1e9 }, i;
    for (i = 0; i <= n; i++) {
      var t = T * i / n;
      var b = P.m33.bullet(v, t), m = P.m33.monkey(v, t);
      var d = Math.hypot(b.x - m.x, b.y - m.y);
      if (d < best.d) best = { t: t, d: d };
    }
    return best;
  },
  /* 弾が最初に地面にもどる時刻／猿が地面に着く時刻 */
  tGround: function (v) { return 2 * v.v0 * Math.sin(v.th * DEG) / G; },
  tMonkey: function (v) { return Math.sqrt(2 * v.my / G); },
  E: 0.55,          /* 地面ではね返るときの速さの残り */
  /* 地面でバウンドしながら飛ぶ弾（当たらなかったときの見せ方） */
  path: function (v, t) {
    var vx = v.v0 * Math.cos(v.th * DEG), vy = v.v0 * Math.sin(v.th * DEG);
    var x = 0, rem = t, guard = 0;
    while (guard++ < 20) {
      var tf = 2 * vy / G;
      if (rem <= tf || tf < 0.05) break;
      rem -= tf; x += vx * tf; vy *= P.m33.E;
    }
    return { x: x + vx * rem, y: Math.max(0, vy * rem - 0.5 * G * rem * rem), vx: vx, vy: vy - G * rem };
  },
  /* 弾か猿が地面に着くまで（描画・探索の上限） */
  limit: function (v) {
    var tb = P.m33.tGround(v);                            /* 弾が y=0 に戻る時刻 */
    if (v.th <= 0) tb = 0;
    var tm = P.m33.tMonkey(v);                            /* 猿が地面に着く時刻 */
    var tx = v.mx / Math.max(0.1, v.v0 * Math.cos(v.th * DEG));
    return Math.max(0.25, Math.min(Math.max(tb, tx * 1.15), tm));
  },
  HIT: 0.7,
  RC: 1.0,          /* 弾が猿にふれる距離（これ以上は近づけない＝めり込まない） */
  /* 最初にふれる時刻（当たらないときは null） */
  contactT: function (v) { return P.m33.memo(v, 'contactT', P.m33._contactT); },
  _contactT: function (v) {
    var T = P.m33.limit(v), n = 1200, i;
    for (i = 0; i <= n; i++) {
      var t = T * i / n;
      var b = P.m33.bullet(v, t), m = P.m33.monkey(v, t);
      if (Math.hypot(b.x - m.x, b.y - m.y) <= P.m33.RC) return t;
    }
    return null;
  },
  RIC: 0.75,        /* 当たったあと、弾がはね返って飛ぶ時間 */
  /* グラフ・式に使う終わりの時刻（当たったところまで） */
  /* 外したときに見せる長さ（猿が着地するまで。弾のバウンドも少し） */
  tMiss: function (v) {
    return Math.max(P.m33.limit(v), Math.min(P.m33.tMonkey(v), P.m33.tGround(v) + 0.9));
  },
  tGraph: function (v) { return P.m33.memo(v, 'tGraph', P.m33._tGraph); },
  _tGraph: function (v) {
    if (P.m33.hit(v)) {
      var c = P.m33.contactT(v);
      return c !== null ? c : P.m33.closest(v).t;
    }
    return P.m33.tMiss(v);
  },
  tEnd: function (v) {
    if (P.m33.hit(v)) return P.m33.tGraph(v) + P.m33.RIC;
    return P.m33.tMiss(v);
  },
  /* 猿より先に弾が地面に着いたか */
  safe: function (v) { return !P.m33.hit(v) && P.m33.tGround(v) > 0.05 && P.m33.tGround(v) < P.m33.tMonkey(v); },
  /* はね返ったあとの弾（左上へ飛び出す） */
  ric: function (v, t) {
    var tc = P.m33.tGraph(v), b = P.m33.bullet(v, tc);
    var dt = t - tc, sp = Math.max(3, v.v0 * 0.35);
    var rvx = -sp * 0.75, rvy = sp * 0.85;
    return { x: b.x + rvx * dt, y: b.y + rvy * dt - 0.5 * G * dt * dt, vx: rvx, vy: rvy - G * dt };
  },
  hit: function (v) { return P.m33.memo(v, 'hit', function (w) { return P.m33.closest(w).d < P.m33.HIT; }); },
  sample: function (v, t) {
    var b = P.m33.hit(v) ? P.m33.bullet(v, t) : P.m33.path(v, t), m = P.m33.monkey(v, t);
    return {
      xA: b.x, yA: b.y, vxA: b.vx, vyA: b.vy,
      xB: m.x, yB: m.y, vyB: m.vy
    };
  }
};

/* 4-1 気球からの水平投射（防衛大 2024 改）
   気球は一定の速さ V0 で鉛直上向きに上昇している。高さ h に達したとき、
   気球から見て水平向きに速さ v0 で小球を投げ出す。
   ・地上の観測者：初速度は (v0, V0) の「斜方投射」に見える
   ・気球の観測者：初速度は (v0, 0) の「水平投射」に見える（気球は等速＝慣性系）  */
P.m41 = {
  /* 地面（y=0）に落ちるまでの時間 */
  tEnd: function (v) {
    return (v.V0 + Math.sqrt(v.V0 * v.V0 + 2 * G * v.h)) / G;
  },
  balloonY: function (v, t) { return v.h + v.V0 * t; },
  /* 地上から見た「生」の量 */
  raw: function (v, t) {
    return {
      gx: v.v0 * t, gy: v.h + v.V0 * t - 0.5 * G * t * t,
      gvx: v.v0, gvy: v.V0 - G * t,
      by: v.h + v.V0 * t
    };
  },
  sample: function (v, t) {
    var r = P.m41.raw(v, t);
    var rx = r.gx, ry = r.gy - r.by;           /* ＝ -½gt² */
    var rvx = v.v0, rvy = -G * t;
    var b = (v.obs === 'balloon');
    var x = b ? rx : r.gx, y = b ? ry : r.gy;
    var vx = b ? rvx : r.gvx, vy = b ? rvy : r.gvy;
    return {
      x: x, y: y, vx: vx, vy: vy, v: Math.hypot(vx, vy), ax: 0, ay: -G,
      gx: r.gx, gy: r.gy, by: r.by, rx: rx, ry: ry,
      gvy: r.gvy, rvy: rvy,
      /* 気球から見た地面の高さ（気球の観測者の図で使う） */
      groundRel: -r.by
    };
  },
  /* 最高点の高さ（地上から見たとき） */
  yTop: function (v) { return v.h + v.V0 * v.V0 / (2 * G); },
  /* 落下地点までの水平距離 */
  range: function (v) { return v.v0 * P.m41.tEnd(v); }
};

/* ============ 1-8〜1-11 2物体の運動 ============
   1-8〜1-10 は軽い糸でつながっているので、A と B の加速度の大きさ・速さ・進んだ距離は共通。
   1-11 だけは A と B が別々に動くので、それぞれを別に返す。 */

/* 1-8 なめらかな水平面。A(m) ── 糸 ── B(M) を、B に力 f をかけて右へ引く。
   全体：(m+M)a = f ／ A について：ma = T  */
P.m18 = {
  a: function (v) { return v.f / (v.m + v.M); },
  T: function (v) { return v.m * P.m18.a(v); },
  LEN: 9,                                   /* これだけ進んだら終わり [m] */
  tEnd: function (v) {
    var a = P.m18.a(v);
    return (a < 1e-9) ? 3 : Math.min(6, Math.sqrt(2 * P.m18.LEN / a));
  },
  sample: function (v, t) {
    var a = P.m18.a(v);
    return { x: 0.5 * a * t * t, v: a * t, a: a, T: P.m18.T(v) };
  }
};

/* 1-9 なめらかな斜面（角 θ）の上の A(m) を、頂上の滑車を通して B(M) が引く。
   x は「A が斜面を上る向き＝B が下りる向き」を正にとる。
   A：ma = T − mg sinθ ／ B：Ma = Mg − T ／ たすと (m+M)a = Mg − mg sinθ */
P.m19 = {
  a: function (v) { return (v.M - v.m * Math.sin(v.th * DEG)) * G / (v.m + v.M); },
  T: function (v) { return v.M * (G - P.m19.a(v)); },
  LEN: 2.4,
  tEnd: function (v) {
    var a = Math.abs(P.m19.a(v));
    return (a < 1e-9) ? 3 : Math.min(6, Math.sqrt(2 * P.m19.LEN / a));
  },
  sample: function (v, t) {
    var a = P.m19.a(v);
    return { x: 0.5 * a * t * t, v: a * t, a: a, T: P.m19.T(v) };
  }
};

/* 1-10 アトウッドの装置。滑車の両側に A(m) と B(M)、m < M。
   x は「B が下りる向き＝A が上る向き」を正にとる。
   A：ma = T − mg ／ B：Ma = Mg − T ／ たすと (m+M)a = (M−m)g */
P.m110 = {
  a: function (v) { return (v.M - v.m) * G / (v.m + v.M); },
  T: function (v) { return 2 * v.m * v.M * G / (v.m + v.M); },
  LEN: 2.2,
  tEnd: function (v) {
    var a = Math.abs(P.m110.a(v));
    return (a < 1e-9) ? 3 : Math.min(6, Math.sqrt(2 * P.m110.LEN / a));
  },
  sample: function (v, t) {
    var a = P.m110.a(v);
    return { x: 0.5 * a * t * t, v: a * t, a: a, T: P.m110.T(v) };
  }
};

/* 1-11 なめらかな床の上の板 A(mA)、その上にのった物体 B(mB)。
   A と B のあいだだけに動摩擦（係数 μ′）がある。右向きを正。
   すべっているあいだ：B にはたらく摩擦は「A が B に対して動く向き」、A にはその反対。
   速さがそろったあとは、（必要な摩擦が最大静止摩擦をこえなければ）いっしょに動く。 */
P.m111 = {
  LB: 2.0,          /* 板の長さ [m]。B ははじめ、まん中にのっている */
  HB: 0.22,         /* 板の上面の高さ [m]。すべり落ちたらこの高さから水平投射になる */
  /* いまの速度から、A と B の加速度を出す。
     すべっているとき：動摩擦 μ′mg。止まって（同じ速さで）いるとき：静止摩擦は最大 μmg まで。 */
  acc: function (v, vA, vB) {
    var fk = v.mud * v.mB * G;                          /* 動摩擦力の大きさ */
    var fs = (v.mus === undefined ? v.mud : v.mus) * v.mB * G;  /* 最大静止摩擦力 */
    var vr = vA - vB;
    if (Math.abs(vr) > 1e-9) {
      var s = vr > 0 ? 1 : -1;                 /* A が B に対して進む向き */
      return { aA: (v.FA - s * fk) / v.mA, aB: (v.FB + s * fk) / v.mB, slip: true, f: s * fk };
    }
    var ac = (v.FA + v.FB) / (v.mA + v.mB);    /* いっしょに動くと仮定した加速度 */
    var need = v.mB * ac - v.FB;               /* そのとき B に必要な摩擦力 */
    if (Math.abs(need) <= fs + 1e-9) return { aA: ac, aB: ac, slip: false, f: need };
    var s2 = need > 0 ? 1 : -1;
    return { aA: (v.FA - s2 * fk) / v.mA, aB: (v.FB + s2 * fk) / v.mB, slip: true, f: s2 * fk };
  },
  /* すべりが終わる（速さがそろう）時刻。そろわないなら Infinity */
  tStick: function (v) {
    var p = P.m111.acc(v, v.vA0, v.vB0);
    if (!p.slip) return 0;
    var dv = v.vA0 - v.vB0, da = p.aA - p.aB;
    if (Math.abs(da) < 1e-12) return Infinity;
    var t = -dv / da;
    if (!(t > 1e-9)) return Infinity;
    /* 速さがそろったあと、静止摩擦でいっしょに動けるかどうかを確かめる */
    var q = P.m111.acc(v, 0, 0);
    return q.slip ? Infinity : t;
  },
  /* B が板からすべり落ちる時刻（落ちないなら Infinity）。
     A から見た B のずれが板の半分（LB/2）をこえたら落ちる。 */
  tFall: function (v) {
    var p = P.m111.acc(v, v.vA0, v.vB0);
    if (!p.slip) return Infinity;
    var d0 = P.m111.LB / 2;
    var dv = v.vA0 - v.vB0, da = p.aA - p.aB;
    var tf = Infinity, i, sg, A2, B2, C2, D2, r;
    for (i = 0; i < 2; i++) {
      sg = i ? -1 : 1;
      A2 = 0.5 * da; B2 = dv; C2 = -sg * d0;
      if (Math.abs(A2) < 1e-12) {
        if (Math.abs(B2) > 1e-12) { r = -C2 / B2; if (r > 1e-9 && r < tf) tf = r; }
      } else {
        D2 = B2 * B2 - 4 * A2 * C2;
        if (D2 >= 0) {
          r = (-B2 + Math.sqrt(D2)) / (2 * A2); if (r > 1e-9 && r < tf) tf = r;
          r = (-B2 - Math.sqrt(D2)) / (2 * A2); if (r > 1e-9 && r < tf) tf = r;
        }
      }
    }
    var ts = P.m111.tStick(v);
    if (isFinite(ts) && ts <= tf) return Infinity;      /* 落ちる前に速さがそろう */
    return tf;
  },
  tFly: function () { return Math.sqrt(2 * P.m111.HB / G); },
  tEnd: function (v) {
    var ts = P.m111.tStick(v), tf = P.m111.tFall(v);
    if (isFinite(tf)) return Math.max(1.0, Math.min(6, tf + P.m111.tFly() + 0.20));
    return Math.max(1.2, Math.min(5, isFinite(ts) ? ts * 1.7 + 0.4 : 2.4));
  },
  /* B が板の上にいるあいだの運動（すべる→速さがそろう、の2段階） */
  onBoard: function (v, t) {
    var p1 = P.m111.acc(v, v.vA0, v.vB0);
    var ts = P.m111.tStick(v);
    var t1 = Math.min(t, isFinite(ts) ? ts : t);
    var xA = v.vA0 * t1 + 0.5 * p1.aA * t1 * t1, vA = v.vA0 + p1.aA * t1;
    var xB = v.vB0 * t1 + 0.5 * p1.aB * t1 * t1, vB = v.vB0 + p1.aB * t1;
    var aA = p1.aA, aB = p1.aB, slip = p1.slip, f = p1.f;
    if (t > t1 + 1e-12) {
      var p2 = P.m111.acc(v, vA, vB);                  /* 速さがそろったあと */
      var t2 = t - t1;
      xA += vA * t2 + 0.5 * p2.aA * t2 * t2; xB += vB * t2 + 0.5 * p2.aB * t2 * t2;
      vA += p2.aA * t2; vB += p2.aB * t2;
      aA = p2.aA; aB = p2.aB; slip = p2.slip; f = p2.f;
    }
    return { xA: xA, vA: vA, aA: aA, xB: xB, vB: vB, aB: aB, slip: slip, f: f, slid: xA - xB };
  },
  sample: function (v, t) {
    var tf = P.m111.tFall(v), r;
    if (t <= tf + 1e-12) {
      r = P.m111.onBoard(v, t);
      r.yB = P.m111.HB; r.fell = false; r.air = false;
      return r;
    }
    var rf = P.m111.onBoard(v, tf), t2 = t - tf;
    var aA2 = v.FA / v.mA;                     /* B が乗っていないので摩擦はない */
    var aB2 = v.FB / v.mB;                     /* 空中でも、なめらかな床の上でも水平の摩擦は 0 */
    var tfly = P.m111.tFly();
    var xA = rf.xA + rf.vA * t2 + 0.5 * aA2 * t2 * t2, vA = rf.vA + aA2 * t2;
    var xB = rf.xB + rf.vB * t2 + 0.5 * aB2 * t2 * t2, vB = rf.vB + aB2 * t2;
    var yB = (t2 < tfly) ? Math.max(0, P.m111.HB - 0.5 * G * t2 * t2) : 0;
    return {
      xA: xA, vA: vA, aA: aA2, xB: xB, vB: vB, aB: aB2,
      slip: false, f: 0, slid: xA - xB, yB: yB, fell: true, air: t2 < tfly
    };
  }
};
