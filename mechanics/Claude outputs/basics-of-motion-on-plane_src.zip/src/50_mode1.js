/* 1　一次元の等加速度直線運動 */
'use strict';

/* 斜面（水平面もふくむ）の座標系。sLo〜sHi[m] が画面に収まるようにする */
function slopeScene(W, H, thDeg, sLo, sHi) {
  var th = thDeg * DEG;
  var u = { x: Math.cos(th), y: -Math.sin(th) };          /* 斜面上向き */
  var n = { x: u.y, y: -u.x };                            /* 斜面から外向き（上） */
  var span = Math.max(0.8, sHi - sLo);
  var bx = 64, by = (th < -1e-6) ? 92 : H - 58;      /* 下り坂のときは左上から始める */
  var scX = (W - 74 - bx) / (u.x * span);
  var sc = scX;
  if (Math.sin(th) > 1e-6) sc = Math.min(scX, (by - 96) / (Math.sin(th) * span));
  if (Math.sin(th) < -1e-6) sc = Math.min(scX, (H - 58 - by) / (-Math.sin(th) * span));
  return {
    th: th, u: u, n: n, sc: sc, sLo: sLo, span: span, bx: bx, by: by,
    pos: function (s) { return { x: bx + u.x * (s - sLo) * sc, y: by + u.y * (s - sLo) * sc }; }
  };
}

/* 斜面の板・ハッチ・角 θ・斜面にそった x 軸 */
function drawSlopeBase(ctx, sn, W, H, thDeg, sign, labelDeg, labelUp) {
  var e = sn.pos(sn.sLo + sn.span);
  var b = sn.pos(sn.sLo);
  var down = thDeg < -0.5;
  ctx.save();
  ctx.fillStyle = '#eef1f4';
  ctx.beginPath();
  ctx.moveTo(b.x, b.y); ctx.lineTo(e.x, e.y);
  ctx.lineTo(down ? b.x : e.x, down ? e.y : b.y);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
  hatchLine(ctx, b.x, b.y, e.x, e.y, down ? -1 : 1);
  ctx.save();
  ctx.strokeStyle = '#98a0a8'; ctx.lineWidth = 1.2;
  ctx.beginPath(); ctx.moveTo(b.x, b.y); ctx.lineTo(e.x, b.y); ctx.stroke();
  ctx.restore();
  var thShow = (labelDeg === undefined) ? thDeg : labelDeg;
  if (Math.abs(thDeg) > 0.5) angArc(ctx, b.x, b.y, 30, Math.min(0, -sn.th), Math.max(0, -sn.th),
    'θ = ' + fmt(thShow, 0) + '°', -sn.th * 0.42, 78);
  var lside = labelUp ? { x: sn.n.x, y: sn.n.y } : { x: -sn.n.x, y: -sn.n.y };
  axisLine(ctx, sn.pos, sn.sLo + 0.15, sn.sLo + sn.span - 0.15,
    lside, 'x [m]', sign, { target: 5 });
  var o = sn.pos(0);
  originMark(ctx, o.x, o.y, -sn.n.x * 17 - 6, -sn.n.y * 17 + 4);
}

/* ============ 1-1／1-2 なめらかな面をすべる物体 ============
   中身はまったく同じで、最初に出る値（初速度と斜面の角）だけを変えた2つを作る。
   1-1 は水平面から、1-2 は斜面（θ＝30°・静かにはなす）から始まる。 */
function smoothSlideDef(o) {
  return {
    id: o.id, mode: 1, tab: o.tab,
    quizKey: 'v', quizName: 'この物体の $v$–$t$ 図（面にそった向き）',
    title: o.title,
    desc: '斜面に変更可能。斜面なら重力の斜面方向成分が加速度をつくる。',
    sub: 'このシミュレーションでは <b>θ＞0 が下り坂、θ＜0 がのぼりの斜面</b>で、x は斜面にそって右向きが正。<br>' +
      '<b>【水平面（θ＝0）】</b>重力と垂直抗力がつり合い、斜面方向の力が残らない。だから a＝0 で、<b>速度は変わらない（等速直線運動）</b>。<br>' +
      '<b>【下り坂（θ＞0）】</b>重力の斜面方向成分 mg sinθ が<b>進む向き（右）</b>にはたらく。a＝＋g sinθ で、物体は<b>だんだん速くなる</b>。<br>' +
      '<b>【のぼりの斜面（θ＜0）】</b>mg sinθ が<b>進む向きと逆（左）</b>にはたらく。a＝−g sin|θ| で<b>だんだんおそくなり</b>、いったん止まってから引き返す。',
    cw: 520, ch: function (v) { return 176 + 210 * Math.abs(Math.sin(v.th * DEG)); },
    vis: ['F', 'Fc', 'V'],
    signLabels: ['斜面にそって右向きを正', '斜面にそって左向きを正'],
    mainVars: ['v0', 'th'],
    vars: [
      { k: 'th', label: '斜面の角 $\\theta$（下り坂が正）', unit: '°', min: -45, max: 45, step: 5, dec: 0, def: o.th },
      { k: 'v0', label: '初速度 $v_0$（右向きが正）', unit: ' m/s', min: -12, max: 12, step: 0.5, dec: 1, def: o.v0 },
      { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 5, step: 0.5, dec: 1, def: 1.0 }
    ],
    toggles: [],
    actions: [
      { label: '速度0にする（v₀＝0）', fn: function (s) { s.v.v0 = 0; }, is: function (v) { return v.v0 === 0; } },
      { label: '下り坂にする（θ＝30°）', fn: function (s) { s.v.th = 30; }, is: function (v) { return v.th === 30; } },
      { label: '斜面にする（θ＝−30°）', fn: function (s) { s.v.th = -30; }, is: function (v) { return v.th === -30; } },
      { label: '水平にもどす（θ＝0°）', fn: function (s) { s.v.th = 0; }, is: function (v) { return v.th === 0; } }
    ],
    tEnd: function (v) { return P.m11.tEnd(v); },
    sample: function (v, t) { return P.m11.sample(v, t); },
    graphs: [
      { key: 'x', short: '$x$–$t$ 図', title: '$x$–$t$ 図（位置）', ylabel: 'x [m]', open: false, signed: true,
        series: [{ color: COL.ink, f: function (m) { return m.x; } }],
        fml: function (v, sg) {
          var a = P.m11.a(v) * sg, v0 = v.v0 * sg;
          return ['x = v_0 t + \\tfrac{1}{2}a t^2',
            Math.abs(v.th) < 0.5 ? 'x = v_0 t' : 'x = v_0 t + \\tfrac{1}{2}(g\\sin\\theta) t^2',
            'x = ' + fmt(v0, 1) + 't' + (Math.abs(a) < 1e-9 ? '' : ' + \\tfrac{1}{2}(' + fmt(a, 2) + ')t^2')];
        } },
      { key: 'v', short: '$v$–$t$ 図', title: '$v$–$t$ 図（速度）', ylabel: 'v [m/s]', open: true, signed: true,
        series: [{ color: COL.vel, f: function (m) { return m.v; } }],
        fml: function (v, sg) {
          var a = P.m11.a(v) * sg, v0 = v.v0 * sg;
          return ['v = v_0 + at',
            Math.abs(v.th) < 0.5 ? 'v = v_0' : 'v = v_0 + (g\\sin\\theta) t',
            'v = ' + fmt(v0, 1) + (Math.abs(a) < 1e-9 ? '' : ' + (' + fmt(a, 2) + ')t')];
        } },
      { key: 'a', short: '$a$–$t$ 図', title: '$a$–$t$ 図（加速度）　※ a の運動方程式による導出', ylabel: 'a [m/s²]', open: false, signed: true,
        series: [{ color: COL.acc, f: function (m) { return m.a; } }],
        fml: function (v, sg) {
          var a = P.m11.a(v) * sg;
          return [EQM + 'ma = F \\;\\Rightarrow\\; a = \\dfrac{F}{m}\\;(\\text{一定})',
            EQM + (Math.abs(v.th) < 0.5 ? 'ma = 0 \\;\\Rightarrow\\; a = 0' : 'ma = mg\\sin\\theta \\;\\Rightarrow\\; a = g\\sin\\theta'),
            'a = ' + fmt(a, 2) + '\\ \\mathrm{m/s^2}'];
        } }
    ],
    draw: function (ctx, s, t, W, H) {
      var v = V(s), T = P.m11.tEnd(v);
      var sMin = 0, sMax = 0, i;
      for (i = 0; i <= 60; i++) { var q = P.m11.s(v, T * i / 60); sMin = Math.min(sMin, q); sMax = Math.max(sMax, q); }
      var sn = slopeScene(W, H, -v.th, sMin - 0.7, sMax + 1.0);
      drawSlopeBase(ctx, sn, W, H, -v.th, s.sign, v.th);

      var sm = P.m11.sample(v, t);
      var kz = mSize(DEFS[o.id], v);
      var bw = 30 * kz, bh = 22 * kz;
      var c = sn.pos(sm.x);
      var cx = c.x + sn.n.x * bh / 2, cy = c.y + sn.n.y * bh / 2;

      for (i = 0; i * 0.25 < t - 1e-9; i++) {
        var pp = sn.pos(P.m11.s(v, i * 0.25));
        ctx.save(); ctx.globalAlpha = 0.32;
        blockShape(ctx, pp.x + sn.n.x * bh / 2, pp.y + sn.n.y * bh / 2, sn.th, bw, bh, '#f2f4f7');
        ctx.restore();
      }
      blockShape(ctx, cx, cy, sn.th, bw, bh, '#e8eef5');

      /* 初速度は「デコピンではじいた」ものとして見せる（すべり出したら手は消える） */
      if (Math.abs(v.v0) > 0.05 && t < 0.34) {
        var fdir = v.v0 > 0 ? 1 : -1;
        var fk = clamp(t / 0.10, 0, 1);
        var fa = (t <= 0.13) ? 1 : Math.max(0, 1 - (t - 0.13) / 0.18);
        var o0 = sn.pos(0);
        var fcx = o0.x - sn.u.x * fdir * (bw / 2 + 20) + sn.n.x * (bh * 0.5);
        var fcy = o0.y - sn.u.y * fdir * (bw / 2 + 20) + sn.n.y * (bh * 0.5);
        if (fa > 0.02) {
          flickHand(ctx, fcx, fcy, -sn.th, fk, fdir, 0.42, fa);
          ctx.save(); ctx.globalAlpha = fa;
          bubble(ctx, 'デコピン！',
            clamp(fcx - sn.u.x * fdir * 6 + sn.n.x * 46, 60, W - 60),
            Math.max(26, fcy - sn.u.y * fdir * 6 + sn.n.y * 46),
            { size: 12.5, bg: '#fff5e8', border: '#e07b18', color: '#a85c0c' });
          ctx.restore();
        }
      }

      var mg = v.m * G, fs = 52 / mg;
      if (s.o.showF) {
        arrow(ctx, cx, cy, cx, cy + mg * fs, 'force');
        label(ctx, '重力 mg', cx - 11, cy + mg * fs + 4, { align: 'right', size: 12, color: COL.force });
        var Nn = mg * Math.cos(sn.th);
        var ntx = c.x + sn.n.x * Nn * fs, nty = c.y + sn.n.y * Nn * fs;
        arrow(ctx, c.x, c.y, ntx, nty, 'force', 1, COL.norm);
        label(ctx, '垂直抗力 N', ntx - sn.u.x * 18 + sn.n.x * 8, nty - sn.u.y * 18 + sn.n.y * 8,
          { align: 'right', size: 12, color: COL.norm });
      }
      if (s.o.showFc && Math.abs(v.th) > 0.5) {
        var gsn = mg * Math.sin(sn.th), gcs = mg * Math.cos(sn.th);
        arrow(ctx, cx, cy, cx - sn.u.x * gsn * fs, cy - sn.u.y * gsn * fs, 'comp');
        label(ctx, 'mg sinθ', cx - sn.u.x * gsn * fs - 6, cy - sn.u.y * gsn * fs + 14, { align: 'right', size: 11.5, color: COL.force });
        arrow(ctx, cx, cy, cx - sn.n.x * gcs * fs, cy - sn.n.y * gcs * fs, 'comp');
        label(ctx, 'mg cosθ', cx - sn.n.x * gcs * fs + 26, cy - sn.n.y * gcs * fs + 10, { align: 'left', size: 11.5, color: COL.force });
      }
      var vmax = Math.max(1, Math.abs(v.v0), Math.abs(P.m11.vel(v, T)));
      if (s.o.showV) {
        if (Math.abs(sm.v) > 0.05) {
          var vl = 14 + 44 * Math.abs(sm.v) / vmax, sg = sm.v > 0 ? 1 : -1;
          var vx0 = cx + sn.n.x * 36, vy0 = cy + sn.n.y * 36;
          arrow(ctx, vx0, vy0, vx0 + sn.u.x * vl * sg, vy0 + sn.u.y * vl * sg, 'vel');
          label(ctx, 'v = ' + fmt(sm.v * s.sign, 1) + ' m/s',
            vx0 + sn.u.x * (vl * sg + 28 * sg), vy0 + sn.u.y * (vl * sg + 28 * sg) - 2,
            { size: 12, color: COL.vel });
        } else {
          label(ctx, 'v = 0', cx + sn.n.x * 38, cy + sn.n.y * 38, { size: 12, bold: true, color: COL.vel });
        }
      }
      if (hintOn(s, t)) {                   /* どんな運動になるかは、スタートしてから見せる */
        if (Math.abs(sm.a) > 0.02) {
          var ax0 = W * 0.70, ay0 = H - 46, asg1 = sm.a >= 0 ? 1 : -1;
          arrow(ctx, ax0, ay0, ax0 + sn.u.x * 44 * asg1, ay0 + sn.u.y * 44 * asg1, 'acc');
          label(ctx, '加速度 a = ' + fmt(sm.a * s.sign, 2) + ' m/s²', ax0 + 8, ay0 + 14, { size: 12, color: COL.acc, align: 'right' });
        } else {
          label(ctx, 'a = 0（力がつり合っている）→ 等速直線運動', W - 10, H - 12,
            { size: 12, color: COL.acc, align: 'right' });
        }
      }
      label(ctx, 't = ' + fmt(t, 2) + ' s', W - 10, 18, { align: 'right', size: 13.5, bold: true });
      drawPosNote(ctx, DEFS[o.id], s, W, 36, dirWord(-v.th, s.sign));
    },
    info: function (s, t) {
      var v = V(s), m = P.m11.sample(v, t);
      return [
        ['加速度 $a$', fmt(m.a * s.sign, 2) + ' m/s²'],
        ['速度 $v$', fmt(m.v * s.sign, 2) + ' m/s'],
        ['位置 $x$', fmt(m.x * s.sign, 2) + ' m'],
        ['運動の続く時間', fmt(P.m11.tEnd(v), 2) + ' s']
      ];
    },
    eq: function (s) {
      var v = V(s);
      if (Math.abs(v.th) < 0.5) return EQM + 'ma = 0 \\quad\\Rightarrow\\quad a = 0 \\;(\\text{等速直線運動})';
      return EQM + 'ma = mg\\sin\\theta \\quad\\Rightarrow\\quad a = g\\sin\\theta = ' + fmt(P.m11.a(v), 2) + '\\ \\mathrm{m/s^2}';
    },
    note: '力は<b>重力と垂直抗力の2本だけ</b>（「動く向きの力」はない）。θ＝0° では2本がつり合って a＝0。θ を大きくすると、重力の<b>斜面方向の分力 mg sinθ</b> だけが残り、これが加速度の原因になる。のぼりでもくだりでも加速度はずっと<b>斜面下向きに g sinθ</b>。'
  };
}

DEFS['m1-1'] = smoothSlideDef({
  id: 'm1-1', tab: '1-1 なめらかな水平面',
  title: '1-1　なめらかな水平面をすべる物体', th: 0, v0: 6.0
});

DEFS['m1-2'] = smoothSlideDef({
  id: 'm1-2', tab: '1-2 なめらかな斜面',
  title: '1-2　なめらかな斜面をすべる物体', th: 30, v0: 0.0
});


/* ============ 1-2 鉛直落下 ============ */
DEFS['m1-3'] = {
  id: 'm1-3', mode: 1, tab: '1-3 鉛直落下',
  quizKey: 'v', quizName: '落下する物体の $v$–$t$ 図（鉛直方向）',
  title: '1-3　鉛直落下（自由落下）',
  desc: '下向きを正にとる。v₀＝0 が自由落下、v₀ を大きくすると「投げ下ろし」。',
  sub: '0.2 s ごとの残像の間隔が広がるのが、速くなっている証拠。h＝19.6 m なら t＝2.0 s、v＝19.6 m/s。',
  cw: 420,
  /* 縮尺を 8 px/m に固定して、h を変えたら「絵の高さ」が変わるようにする
     （topY=76、地面は下から 46 px なので ch = 122 + 8h でちょうど 8 px/m になる） */
  ch: function (v) { return Math.round(Math.max(196, 122 + 8 * v.h)); },
  vis: ['F', 'V'],
  signLabels: ['下向きを正', '上向きを正'],
  mainVars: ['h', 'v0'],
  vars: [
    { k: 'h', label: '落とす高さ $h$', unit: ' m', min: 4.9, max: 45, step: 0.1, dec: 1, def: 19.6 },
    { k: 'v0', label: '初速度 $v_0$（下向き）', unit: ' m/s', min: 0, max: 15, step: 0.5, dec: 1, def: 0.0 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 5, step: 0.5, dec: 1, def: 1.0 }
  ],
  toggles: [],
  actions: [
    { label: 'h＝19.6 m（自由落下でちょうど2.0 s）', fn: function (s) { s.v.h = 19.6; s.v.v0 = 0; },
      is: function (v) { return Math.abs(v.h - 19.6) < 1e-6 && Math.abs(v.v0) < 1e-6; } }
  ],
  tEnd: function (v) { return P.m12.tEnd(v); },
  sample: function (v, t) { return P.m12.sample(v, t); },
  graphs: [
    { key: 'x', short: '$y$–$t$ 図', title: '$y$–$t$ 図（位置）', ylabel: 'y [m]', open: false, signed: true,
      series: [{ color: COL.ink, f: function (m) { return m.x; } }],
      fml: function (v, sg) {
        return ['y = v_0 t + \\tfrac{1}{2}a t^2', 'y = v_0 t + \\tfrac{1}{2}g t^2',
          'y = ' + fmt(v.v0 * sg, 1) + 't + \\tfrac{1}{2}(' + fmt(G * sg, 2) + ')t^2'];
      } },
    { key: 'v', short: '$v$–$t$ 図', title: '$v$–$t$ 図（速度）', ylabel: 'v [m/s]', open: true, signed: true,
      series: [{ color: COL.vel, f: function (m) { return m.v; } }],
      fml: function (v, sg) {
        return ['v = v_0 + at', 'v = v_0 + gt',
          'v = ' + fmt(v.v0 * sg, 1) + ' + (' + fmt(G * sg, 2) + ')t'];
      } },
    { key: 'a', short: '$a$–$t$ 図', title: '$a$–$t$ 図（加速度）　※ a の運動方程式による導出', ylabel: 'a [m/s²]', open: false, signed: true,
      series: [{ color: COL.acc, f: function (m) { return m.a; } }],
      fml: function (v, sg) {
        return [EQM + 'ma = F \\;\\Rightarrow\\; a = \\dfrac{F}{m}', EQM + 'ma = mg \\;\\Rightarrow\\; a = g',
          'a = ' + fmt(G * sg, 2) + '\\ \\mathrm{m/s^2}'];
      } }
  ],
  draw: function (ctx, s, t, W, H) {
    var v = V(s), T = P.m12.tEnd(v);
    var sc = 8;                                   /* 8 px = 1 m（h を変えると絵の高さが変わる） */
    var gndY = H - 46, topY = gndY - v.h * sc, bx = W * 0.60;
    function Y(val) { return topY + val * sc; }
    hatchLine(ctx, bx - 70, topY, bx + 60, topY, -1);
    label(ctx, '手をはなす位置', bx - 76, topY - 15, { align: 'right', size: 11.5 });
    /* 手のうごき：v0＝0 なら「はなす瞬間に親指と人差し指をひらく」、
       v0≠0 なら「手で下に押してから、はなす」 */
    var push = Math.abs(v.v0) > 0.05, tPush = 0.22, hOpen, hY;
    if (!push) {
      hY = topY;
      hOpen = clamp(t / 0.16, 0, 1);
    } else {
      /* 押しながら下がっていく途中で、指をひらいて手をはなす */
      hY = Y(P.m12.sample(v, Math.min(t, tPush)).x);
      hOpen = clamp((t - tPush * 0.45) / (tPush * 0.55), 0, 1);
    }
    var tRel = push ? tPush : 0.16;                 /* 手をはなし終わる時刻 */
    var hA = (t <= tRel) ? 1 : 1 - (t - tRel) / 0.20;
    if (hA > 0.02) dropHand(ctx, bx, hY, 0.62, hOpen, hA);
    if (push && t > 1e-9 && t < tPush) {
      label(ctx, '手で押し下げている', bx - 92, hY - 34, { align: 'right', size: 10.5, color: COL.sub });
    }
    ground(ctx, 26, W - 20, gndY);
    label(ctx, '地面', W - 24, gndY + 15, { align: 'right', size: 11.5 });

    var axX = W * 0.26;
    axisY(ctx, Y, axX, 0, v.h * 0.97, 'y [m]', s.sign,
      { target: clamp(Math.round(v.h * sc / 40), 2, 5) });
    originMark(ctx, axX, Y(0), -13, 13);
    drawPosNote(ctx, DEFS['m1-3'], s, W, 36);

    arrow(ctx, bx + 92, topY, bx + 92, gndY, 'dim');
    label(ctx, 'h = ' + fmt(v.h, 1) + ' m', bx + 98, (topY + gndY) / 2, { align: 'left', size: 11.5 });

    var kz = mSize(DEFS['m1-3'], v);
    for (var i = 1; i * 0.2 < t - 1e-9; i++) ball(ctx, bx, Y(P.m12.sample(v, i * 0.2).x), 7 * kz, 'faint');

    var m = P.m12.sample(v, t);
    var y = Y(m.x);
    ball(ctx, bx, y, 9 * kz);

    var mg = v.m * G, fs = 48 / mg;
    if (s.o.showF) {
      arrow(ctx, bx, y, bx, y + mg * fs, 'force');
      label(ctx, '重力 mg = ' + fmt(mg, 1) + ' N', bx - 12, y + mg * fs - 8, { align: 'right', size: 11.5, color: COL.force });
    }
    var vEnd = P.m12.sample(v, T).v;
    if (s.o.showV && m.v > 0.05) {
      var vl = 14 + 52 * m.v / Math.max(1, vEnd);
      arrow(ctx, bx + 26, y, bx + 26, y + vl, 'vel');
      label(ctx, 'v = ' + fmt(m.v, 1) + ' m/s', bx + 34, y + vl / 2, { align: 'left', size: 11.5, color: COL.vel });
    }
    if (hintOn(s, t)) {                   /* 答えにつながる言葉は、スタートしてから */
      arrow(ctx, 42, H - 118, 42, H - 72, 'acc');
      label(ctx, '加速度 g（一定）', 42, H - 56, { size: 11.5, color: COL.acc });
    }
    label(ctx, 't = ' + fmt(t, 2) + ' s', W - 10, 18, { align: 'right', size: 13.5, bold: true });
    if (t >= T - 1e-9) label(ctx, '着地！', bx, gndY - 22, { size: 14, bold: true, color: COL.ng });
  },
  info: function (s, t) {
    var v = V(s), m = P.m12.sample(v, t), T = P.m12.tEnd(v);
    return [
      ['落ちた距離 $y$', fmt(m.x * s.sign, 2) + ' m'],
      ['速さ $v$', fmt(m.v * s.sign, 2) + ' m/s'],
      ['地面に着く時刻', fmt(T, 2) + ' s'],
      ['着地直前の速さ', fmt(P.m12.sample(v, T).v * s.sign, 2) + ' m/s']
    ];
  },
  eq: function (s) { return EQM + 'ma = mg \\quad\\Rightarrow\\quad a = g = 9.8\\ \\mathrm{m/s^2}\\ (\\text{下向き})'; },
  note: '下向きを正にとると、加速度も速度も位置もぜんぶ正。v–t 図は<b>原点（v₀＝0のとき）を通る右上がりの直線</b>、傾きは 9.8。h＝19.6 m なら t＝2.0 s、v＝19.6 m/s。'
};

/* 1-3 の v–t 図の下に出す解説。
   「グラフの面積 ＝ そのあいだの y の変化」を、上りと下りでくらべさせる。
   ビルの上から投げると下りのほうが大きくなり、その差が地面までの変位になる。 */
function m13AreaNote(v, s2) {
  var sg = s2 ? s2.sign : 1;
  var t1 = P.m13.tTop(v), T = P.m13.tEnd(v);
  var up = v.v0 * v.v0 / (2 * G);          /* 上がった高さ */
  var dn = up + v.H;                       /* 最高点から地面まで下りた距離 */
  var out = '<b>この図の面積 ＝ そのあいだの y の変化（動いた高さ）。</b>（正＝青／負＝グレー）<br>' +
    '上り（0 〜 ' + fmt(t1, 2) + ' s）の<b>' + areaSignWord(sg, true) + 'の面積</b>　' +
    '<span class="tex">\\tfrac{1}{2}t_1 v_0 = \\dfrac{v_0^{\\,2}}{2g} = ' + fmt(up, 2) +
    '\\,\\mathrm{m}</span>　← 最高点までの高さ<br>' +
    '下り（' + fmt(t1, 2) + ' 〜 ' + fmt(T, 2) + ' s）の<b>' + areaSignWord(sg, false) + 'の面積</b>　' +
    '<span class="tex">' + fmt(dn, 2) + '\\,\\mathrm{m}</span>　← 最高点から地面まで下りた距離<br>';
  if (v.H < 0.05) {
    out += '底辺（時間）も高さ（速さ）も同じ三角形なので、<b>2つの面積は必ず等しい</b>。' +
      '符号がちがうのでたすと 0 になり、<b>投げた高さにもどってくる</b>。' +
      '上りにかかる時間と下りにかかる時間も等しい。';
  } else {
    out += '<b>2つの面積の差が、投げた点から見た変位</b>。いまは下りのほうが ' + fmt(v.H, 1) +
      ' m ぶん大きく、たし合わせると <span class="tex">-' + fmt(v.H, 1) +
      '\\,\\mathrm{m}</span>（＝ビルの高さぶん下）になる。<br>' +
      '「地面から（H＝0）」にすると2つの面積がぴたりと等しくなり、和が 0 になる。';
  }
  return out;
}

/* ============ 1-3 鉛直投げ上げ ============ */
DEFS['m1-4'] = {
  id: 'm1-4', mode: 1, tab: '1-4 鉛直投げ上げ',
  quizKey: 'v', quizName: '投げ上げた物体の $v$–$t$ 図（鉛直方向）',
  title: '1-4　鉛直投げ上げ',
  desc: '上向きを正。原点の取り方（$y_0$）を変えると $y$–$t$ 図は上下にずれるが、$v$–$t$ 図・$a$–$t$ 図は変わらない。',
  sub: '「投げ始める点の座標 y₀」を動かすと原点の取り方が変わる。「ビルの上から」に切りかえると、地面まで落ちる運動になる。',
  cw: 470, ch: 390,
  vis: ['F', 'V'],
  signLabels: ['上向きを正', '下向きを正'],
  mainVars: ['v0', 'H'],
  vars: [
    { k: 'v0', label: '初速度 $v_0$（上向き）', unit: ' m/s', min: 2, max: 25, step: 0.2, dec: 1, def: 9.8 },
    { k: 'y0', label: '投げ始める点の座標 $y_0$', unit: ' m', min: -10, max: 10, step: 1, dec: 0, def: 0 },
    { k: 'H', label: '投げた点から地面まで $H$', unit: ' m', min: 0, max: 25, step: 0.1, dec: 1, def: 0 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 5, step: 0.5, dec: 1, def: 1.0 }
  ],
  toggles: [],
  actions: [
    { label: 'ビルの上から（H＝19.6 m）', fn: function (s) { s.v.H = 19.6; }, is: function (v) { return Math.abs(v.H - 19.6) < 1e-6; } },
    { label: '地面から（H＝0）', fn: function (s) { s.v.H = 0; }, is: function (v) { return v.H === 0; } }
  ],
  tEnd: function (v) { return P.m13.tEnd(v); },
  sample: function (v, t) { return P.m13.sample(v, t); },
  graphs: [
    { key: 'x', short: '$y$–$t$ 図', title: '$y$–$t$ 図（位置）', ylabel: 'y [m]', open: false, signed: true,
      series: [{ color: COL.ink, f: function (m) { return m.x; } }],
      fml: function (v, sg) {
        return ['y = y_0 + v_0 t + \\tfrac{1}{2}a t^2', 'y = y_0 + v_0 t - \\tfrac{1}{2}g t^2',
          'y = ' + fmt(v.y0 * sg, 0) + ' + ' + fmt(v.v0 * sg, 1) + 't + \\tfrac{1}{2}(' + fmt(-G * sg, 2) + ')t^2'];
      } },
    { key: 'v', short: '$v$–$t$ 図', title: '$v$–$t$ 図（速度）', ylabel: 'v [m/s]', open: true, signed: true,
      series: [{ color: COL.vel, area: true, f: function (m) { return m.v; } }],
      fml: function (v, sg) {
        return ['v = v_0 + at', 'v = v_0 - gt',
          'v = ' + fmt(v.v0 * sg, 1) + ' + (' + fmt(-G * sg, 2) + ')t'];
      },
      fnote: function (v, s2) { return m13AreaNote(v, s2); } },
    { key: 'a', short: '$a$–$t$ 図', title: '$a$–$t$ 図（加速度）　※ a の運動方程式による導出', ylabel: 'a [m/s²]', open: false, signed: true,
      series: [{ color: COL.acc, f: function (m) { return m.a; } }],
      fml: function (v, sg) {
        return [EQM + 'ma = F \\;\\Rightarrow\\; a = \\dfrac{F}{m}', EQM + 'ma = -mg \\;\\Rightarrow\\; a = -g',
          'a = ' + fmt(-G * sg, 2) + '\\ \\mathrm{m/s^2}'];
      } }
  ],
  draw: function (ctx, s, t, W, H) {
    var v = V(s);
    var yG = P.m13.ground(v), yT = P.m13.yTop(v);
    var lo = Math.min(yG, 0) - 1.2, hi = Math.max(yT, 0) + 2.2;
    var topPx = 48, botPx = H - 42;
    var sc = (botPx - topPx) / (hi - lo);
    function Y(yc) { return botPx - (yc - lo) * sc; }
    var bx = W * 0.66;

    ground(ctx, 26, W - 16, Y(yG));
    label(ctx, '地面', W - 20, Y(yG) + 15, { align: 'right', size: 11.5 });
    if (v.H > 0.05) {
      ctx.save();
      ctx.fillStyle = '#eef1f4'; ctx.strokeStyle = '#8b949e'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.rect(bx - 74, Y(v.y0), 62, Y(yG) - Y(v.y0)); ctx.fill(); ctx.stroke();
      for (var wy = Y(v.y0) + 14; wy < Y(yG) - 18; wy += 26) {
        ctx.strokeRect(bx - 66, wy, 15, 11); ctx.strokeRect(bx - 40, wy, 15, 11);
      }
      ctx.restore();
      label(ctx, 'ビル ' + fmt(v.H, 1) + ' m', bx - 78, (Y(v.y0) + Y(yG)) / 2, { align: 'right', size: 11, color: COL.sub });
      person(ctx, bx - 18, Y(v.y0), 34, false);
    } else {
      person(ctx, bx - 24, Y(yG), 38, false);
    }

    var axX = W * 0.20;
    axisY(ctx, Y, axX, lo + 0.4, hi - 0.4, 'y [m]', s.sign, { target: 5 });
    originMark(ctx, axX, Y(0), -14, 13);
    drawPosNote(ctx, DEFS['m1-4'], s, W, 36);

    var T = P.m13.tEnd(v), i;
    ctx.save(); ctx.strokeStyle = '#c6ccd4'; ctx.setLineDash([3, 4]);
    ctx.beginPath(); ctx.moveTo(bx, Y(v.y0)); ctx.lineTo(bx, Y(yT)); ctx.stroke(); ctx.restore();
    var kz = mSize(DEFS['m1-4'], v);
    for (i = 1; i * 0.2 < t - 1e-9; i++) ball(ctx, bx, Y(P.m13.sample(v, i * 0.2).x), 6.5 * kz, 'faint');

    var m = P.m13.sample(v, t);
    var yy = Y(m.x);
    ball(ctx, bx, yy, 9 * kz);
    var mg = v.m * G, fs = 48 / mg;
    if (s.o.showF) {
      arrow(ctx, bx, yy, bx, yy + mg * fs, 'force');
      label(ctx, '重力 mg', bx - 12, yy + mg * fs - 8, { align: 'right', size: 11.5, color: COL.force });
    }
    if (s.o.showV) {
      if (Math.abs(m.v) > 0.15) {
        var vl = 12 + 44 * Math.min(1, Math.abs(m.v) / 22), sg = m.v > 0 ? -1 : 1;
        arrow(ctx, bx + 26, yy, bx + 26, yy + sg * vl, 'vel');
        label(ctx, 'v = ' + fmt(m.v * s.sign, 1), bx + 34, yy + sg * vl / 2, { align: 'left', size: 11.5, color: COL.vel });
      } else {
        label(ctx, '最高点 v = 0', bx + 30, yy - 4, { align: 'left', size: 11.5, bold: true, color: COL.ng });
      }
    }
    if (hintOn(s, t)) {                   /* 答えにつながる言葉は、スタートしてから */
      arrow(ctx, W - 34, 76, W - 34, 118, 'acc');
      label(ctx, '加速度 −g', W - 34, 134, { size: 11.5, color: COL.acc });
      /* 「正の向き：…」（y=36）とぶつからないよう、1行下げる */
      label(ctx, '負の加速度の原因＝下向きの力（重力）', W - 10, 54, { align: 'right', size: 11, color: COL.force });
    }
    label(ctx, 't = ' + fmt(t, 2) + ' s', W - 10, 18, { align: 'right', size: 13.5, bold: true });
    if (t >= T - 1e-9) label(ctx, '着地！', bx, Y(yG) - 22, { size: 14, bold: true, color: COL.ng });
  },
  info: function (s, t) {
    var v = V(s), m = P.m13.sample(v, t), T = P.m13.tEnd(v);
    return [
      ['位置 $y$', fmt(m.x * s.sign, 2) + ' m'],
      ['速度 $v$', fmt(m.v * s.sign, 2) + ' m/s'],
      ['最高点の時刻 $v_0/g$', fmt(P.m13.tTop(v), 2) + ' s'],
      ['最高点の座標', fmt(P.m13.yTop(v) * s.sign, 2) + ' m'],
      ['地面に着く時刻', fmt(T, 2) + ' s'],
      ['着地直前の速度', fmt(P.m13.sample(v, T).v * s.sign, 2) + ' m/s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return EQM + 'ma = -mg \\quad\\Rightarrow\\quad a = -g = -9.8\\ \\mathrm{m/s^2},\\quad y = ' +
      (Math.abs(v.y0) < 1e-9 ? '' : fmt(v.y0, 0) + ' + ') + 'v_0 t - \\tfrac{1}{2}gt^2';
  },
  note: '上向きに動いていても、はたらく力は<b>下向きの重力だけ</b>。だから加速度は<b>ずっと −g のまま</b>で、v–t 図は傾き −9.8 の直線。最高点で v＝0 になっても傾きは変わらない。'
};

/* ============ 1-4 水平面で引く（なめらか・糸で引く） ============ */
DEFS['m1-5'] = {
  id: 'm1-5', mode: 1, tab: '1-5 水平面で引く',
  quizKey: 'v', quizName: 'この物体の $v$–$t$ 図（面にそった向き）',
  title: '1-5　水平面で引く（なめらかな面）',
  sub: '糸をつけて右へ引く。面はなめらかで摩擦は 0。オレンジのボタンで、左へ引く力 $F_2$ も出せる。',
  cw: 520, ch: function (v) { return 196 + 210 * Math.abs(Math.sin(v.th * DEG)); },
  vis: ['F', 'Fc', 'V'],
  signLabels: ['面にそって右向き（斜面上向き）を正', '面にそって左向き（斜面下向き）を正'],
  mainVars: ['F', 'F2', 'th', 'v0'],
  consts: { mu: 0, mud: 0, LEN: 9, TMAX: 6 },
  vars: [
    { k: 'F', label: '右へ引く $F_1$', unit: ' N', min: 0, max: 40, step: 1, dec: 0, def: 10 },
    { k: 'F2', label: '左へ引く $F_2$', unit: ' N', min: 0, max: 40, step: 1, dec: 0, def: 0 },
    { k: 'th', label: '面の傾き $\\theta$', unit: '°', min: 0, max: 40, step: 5, dec: 0, def: 0 },
    { k: 'v0', label: '初速度 $v_0$', unit: ' m/s', min: -4, max: 6, step: 0.5, dec: 1, def: 0.0 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 6, step: 0.5, dec: 1, def: 2.0 }
  ],
  toggles: [],
  actions: [
    { label: '左に 5 N、右に 8 N にする', fn: function (s) { s.v.F = 8; s.v.F2 = 5; },
      is: function (v) { return v.F === 8 && v.F2 === 5; } },
    { label: '斜面にする（θ＝30°）', fn: function (s) { s.v.th = 30; }, is: function (v) { return v.th === 30; } },
    { label: '水平にもどす（θ＝0°）', fn: function (s) { s.v.th = 0; }, is: function (v) { return v.th === 0; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.F = 10; s.v.F2 = 0; s.v.th = 0; s.v.m = 2; s.v.v0 = 0; },
      is: function (v) { return v.F === 10 && v.F2 === 0 && v.th === 0 && v.m === 2 && v.v0 === 0; } }
  ],
  tEnd: function (v) { return P.m14.tEnd(v); },
  sample: function (v, t) { return P.m14.sample(v, t); },
  graphs: [
    { key: 'x', short: '$x$–$t$ 図', title: '$x$–$t$ 図（位置）', ylabel: 'x [m]', open: false, signed: true,
      series: [{ color: COL.ink, f: function (m) { return m.x; } }],
      fml: function (v, sg) {
        var a = P.m14.a0(v) * sg;
        return ['x = v_0 t + \\tfrac{1}{2}a t^2',
          'x = v_0 t + \\tfrac{1}{2}\\dfrac{F_1 - F_2 - mg\\sin\\theta}{m} t^2',
          'x = ' + fmt(v.v0 * sg, 1) + 't + \\tfrac{1}{2}(' + fmt(a, 2) + ')t^2'];
      } },
    { key: 'v', short: '$v$–$t$ 図', title: '$v$–$t$ 図（速度）', ylabel: 'v [m/s]', open: true, signed: true,
      series: [{ color: COL.vel, f: function (m) { return m.v; } }],
      fml: function (v, sg) {
        var a = P.m14.a0(v) * sg;
        return ['v = v_0 + at', 'v = v_0 + \\dfrac{F_1 - F_2 - mg\\sin\\theta}{m} t',
          'v = ' + fmt(v.v0 * sg, 1) + ' + (' + fmt(a, 2) + ')t'];
      } },
    { key: 'a', short: '$a$–$t$ 図', title: '$a$–$t$ 図（加速度）　※ a の運動方程式による導出', ylabel: 'a [m/s²]', open: false, signed: true,
      series: [{ color: COL.acc, f: function (m) { return m.a; } }],
      fml: function (v, sg) {
        var a = P.m14.a0(v) * sg, th = v.th * DEG;
        return [EQM + 'ma = F_{\\text{合力}}', EQM + 'ma = F_1 - F_2 - mg\\sin\\theta',
          '(' + fmt(v.m, 1) + ')a = ' + fmt(v.F, 0) + ' - ' + fmt(v.F2, 0) +
          (v.th > 0.5 ? ' - ' + fmt(v.m * G * Math.sin(th), 1) : '') +
          ' \\;\\Rightarrow\\; a = ' + fmt(a, 2)];
      } }
  ],
  draw: function (ctx, s, t, W, H) {
    var v = V(s), tb = P.m14.table(v);
    var sMin = 0, sMax = 0, i;
    for (i = 0; i < tb.length; i += 5) { sMin = Math.min(sMin, tb[i].x); sMax = Math.max(sMax, tb[i].x); }
    var sn = slopeScene(W, H, v.th, sMin - 2.6, sMax + 2.2);
    drawSlopeBase(ctx, sn, W, H, v.th, s.sign);

    var m = P.m14.sample(v, t);
    var kz = mSize(DEFS['m1-5'], v);
    var bw = 34 * kz, bh = 25 * kz;
    var c = sn.pos(m.x);
    var cx = c.x + sn.n.x * bh / 2, cy = c.y + sn.n.y * bh / 2;
    blockShape(ctx, cx, cy, sn.th, bw, bh, '#e8eef5');

    var mg = v.m * G, fs = 46 / mg;
    /* 右の糸と手（物体 → 糸 → 手 の並び） */
    var rx = cx + sn.u.x * (bw / 2 + 3), ry = cy + sn.u.y * (bw / 2 + 3);
    var rfx = rx + sn.u.x * 30, rfy = ry + sn.u.y * 30;
    string(ctx, rx, ry, rfx, rfy);
    hand(ctx, rfx, rfy, -sn.th);
    /* 左の糸と手（F2 を出したときだけ） */
    var lx = cx - sn.u.x * (bw / 2 + 3), ly = cy - sn.u.y * (bw / 2 + 3);
    var lfx = lx - sn.u.x * 30, lfy = ly - sn.u.y * 30;
    if (v.F2 > 0.5) {
      string(ctx, lx, ly, lfx, lfy);
      hand(ctx, lfx, lfy, -sn.th + Math.PI);
    }
    if (s.o.showF) {
      if (v.F > 0.5) {
        var f1x = rx + sn.u.x * v.F * fs, f1y = ry + sn.u.y * v.F * fs;
        arrow(ctx, rx, ry, f1x, f1y, 'force', 1, COL.hand);
        label(ctx, '糸が引く力 F₁ = ' + fmt(v.F, 0) + ' N',
          f1x + sn.u.x * 6 + sn.n.x * 20, f1y + sn.u.y * 6 + sn.n.y * 20,
          { size: 11.5, color: COL.hand, align: 'left' });
      }
      if (v.F2 > 0.5) {
        var f2x = lx - sn.u.x * v.F2 * fs, f2y = ly - sn.u.y * v.F2 * fs;
        arrow(ctx, lx, ly, f2x, f2y, 'force', 1, COL.hand);
        label(ctx, '糸が引く力 F₂ = ' + fmt(v.F2, 0) + ' N',
          f2x - sn.u.x * 24 - sn.n.x * 26, f2y - sn.u.y * 24 - sn.n.y * 26,
          { size: 11.5, color: COL.hand, align: 'right' });
      }
      arrow(ctx, cx, cy, cx, cy + mg * fs, 'force');
      label(ctx, '重力 mg = ' + fmt(mg, 1) + ' N', cx + 10, cy + mg * fs - 6, { align: 'left', size: 11.5, color: COL.force });
      var Nn = mg * Math.cos(sn.th);
      var ntx = c.x + sn.n.x * Nn * fs, nty = c.y + sn.n.y * Nn * fs;
      arrow(ctx, c.x, c.y, ntx, nty, 'force', 1, COL.norm);
      label(ctx, '垂直抗力 N', ntx, nty - 11, { align: 'center', size: 11.5, color: COL.norm });
      label(ctx, 'なめらかな面：摩擦力は 0', 12, H - 12, { align: 'left', size: 11, color: COL.fric });
    }
    if (s.o.showFc && v.th > 0.5) {
      var gsn = mg * Math.sin(sn.th), gcs = mg * Math.cos(sn.th);
      arrow(ctx, cx, cy, cx - sn.u.x * gsn * fs, cy - sn.u.y * gsn * fs, 'comp');
      label(ctx, 'mg sinθ', cx - sn.u.x * gsn * fs - 4, cy - sn.u.y * gsn * fs + 15, { align: 'right', size: 11, color: COL.force });
      arrow(ctx, cx, cy, cx - sn.n.x * gcs * fs, cy - sn.n.y * gcs * fs, 'comp');
    } else if (s.o.showFc) {
      label(ctx, '水平面では重力はもともと鉛直だけ（分ける必要なし）', 12, H - 28, { align: 'left', size: 11, color: COL.sub });
    }
    var vAbs = Math.abs(m.v);
    if (s.o.showV && vAbs > 0.05) {
      var vl = 14 + 40 * Math.min(1, vAbs / 6), sg2 = m.v > 0 ? 1 : -1;
      var vx0 = cx + sn.u.x * 26 + sn.n.x * 52, vy0 = cy + sn.u.y * 26 + sn.n.y * 52;
      arrow(ctx, vx0, vy0, vx0 + sn.u.x * vl * sg2, vy0 + sn.u.y * vl * sg2, 'vel');
      label(ctx, 'v = ' + fmt(m.v * s.sign, 2) + ' m/s',
        vx0 + sn.u.x * vl * sg2 * 0.5 + sn.n.x * 16, vy0 + sn.u.y * vl * sg2 * 0.5 + sn.n.y * 16,
        { size: 11.5, color: COL.vel });
    }
    /* 加速度の矢印は、速度の矢印とぶつからないよう図の左上に固定して置く */
    var ax0 = W * 0.30, ay0 = 64;
    if (hintOn(s, t)) {
      if (Math.abs(m.a) > 0.02) {
        var asg = m.a > 0 ? 1 : -1;
        arrow(ctx, ax0, ay0, ax0 + sn.u.x * 46 * asg, ay0 + sn.u.y * 46 * asg, 'acc');
        label(ctx, '加速度 a = ' + fmt(m.a * s.sign, 2) + ' m/s²', ax0 - 12, ay0 - 18, { size: 12, color: COL.acc, align: 'right' });
      } else {
        label(ctx, 'F₁ と F₂ がつり合っている　a = 0', W * 0.26, 56, { size: 12.5, bold: true, color: COL.acc, align: 'left' });
      }
    }
    label(ctx, 't = ' + fmt(t, 2) + ' s', W - 10, 18, { align: 'right', size: 13.5, bold: true });
    drawPosNote(ctx, DEFS['m1-5'], s, W, 36, dirWord(v.th, s.sign));
  },
  info: function (s, t) {
    var v = V(s), m = P.m14.sample(v, t), th = v.th * DEG;
    return [
      ['垂直抗力 $N = mg\\cos\\theta$', fmt(v.m * G * Math.cos(th), 1) + ' N'],
      ['重力の面にそった成分 $mg\\sin\\theta$', fmt(v.m * G * Math.sin(th), 1) + ' N'],
      ['面にそった合力 $F_1 - F_2 - mg\\sin\\theta$', fmt((v.F - v.F2 - v.m * G * Math.sin(th)) * s.sign, 1) + ' N'],
      ['加速度 $a$', fmt(m.a * s.sign, 2) + ' m/s²'],
      ['速度 $v$', fmt(m.v * s.sign, 2) + ' m/s'],
      ['位置 $x$', fmt(m.x * s.sign, 2) + ' m']
    ];
  },
  eq: function (s) {
    var v = V(s), m = P.m14.sample(v, s.t), th = v.th * DEG;
    return EQM + 'ma = F_1 - F_2 - mg\\sin\\theta \\;\\Rightarrow\\; a = \\dfrac{' + fmt(v.F, 0) + ' - ' +
      fmt(v.F2, 0) + ' - ' + fmt(v.m * G * Math.sin(th), 1) + '}{' + fmt(v.m, 1) + '} = ' +
      fmt(m.a, 2) + '\\ \\mathrm{m/s^2}';
  },
  note: '糸が引く力（<b>張力</b>）は、<b>糸にそった向き</b>に物体を引く。面はなめらかなので摩擦力は 0。水平面（θ＝0）なら面にそった力は <span class="tex">F_1 - F_2</span> だけで、<span class="tex">a = \\dfrac{F_1-F_2}{m}</span>。左に 5 N・右に 8 N なら合力は右向きに 3 N。<b>左右を同じ大きさ</b>にすると合力が 0 になり、<b>止まったまま</b>（または<b>同じ速さで動きつづける</b>）。'
};

/* ============ 1-5 摩擦のある水平面・斜面をすべる物体 ============ */
DEFS['m1-6'] = {
  id: 'm1-6', mode: 1, tab: '1-6 摩擦のある水平面・斜面',
  quizKey: 'v', quizName: 'この物体の $v$–$t$ 図（面にそった向き）',
  title: '1-6　摩擦のある水平面・斜面をすべる物体',
  desc: '力は加えず、初速度だけをあたえてすべらせる。動摩擦力 μ′N が運動と逆向きにはたらき、一定の割合で減速する。',
  sub: '止まったあとに動き出すかどうかは、静止摩擦（最大 μN）と重力の斜面成分 mg sinθ の大小で決まる。',
  cw: 520, ch: function (v) { return 182 + 210 * Math.abs(Math.sin(v.th * DEG)); },
  vis: ['F', 'Fc', 'V'],
  signLabels: ['進む向きを正', '逆向きを正'],
  consts: { F: 0, LEN: 9, TMAX: 6 },
  mainVars: ['v0', 'mud'],
  vars: [
    { k: 'v0', label: '初速度 $v_0$', unit: ' m/s', min: 1, max: 10, step: 0.5, dec: 1, def: 6.0 },
    { k: 'mud', label: '動摩擦係数 $\\mu\'$', unit: '', min: 0.05, max: 0.8, step: 0.05, dec: 2, def: 0.30 },
    { k: 'th', label: '斜面の角 $\\theta$', unit: '°', min: 0, max: 40, step: 5, dec: 0, def: 0 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 6, step: 0.5, dec: 1, def: 2.0 },
    { k: 'mu', label: '静止摩擦係数 $\\mu$', unit: '', min: 0.05, max: 1, step: 0.05, dec: 2, def: 0.50 }
  ],
  toggles: [],
  actions: [
    { label: '斜面にする（θ＝30°）', fn: function (s) { s.v.th = 30; }, is: function (v) { return v.th === 30; } },
    { label: '水平にもどす（θ＝0°）', fn: function (s) { s.v.th = 0; }, is: function (v) { return v.th === 0; } }
  ],
  tEnd: function (v) { return Math.min(P.m14.tStop(v) + 0.6, P.m14.tEnd(v)); },
  sample: function (v, t) { return P.m14.sample(v, t); },
  graphs: [
    { key: 'x', short: '$x$–$t$ 図', title: '$x$–$t$ 図（位置）', ylabel: 'x [m]', open: false, signed: true,
      series: [{ color: COL.ink, f: function (m) { return m.x; } }],
      fml: function (v, sg) {
        var a = P.m14.a0(v) * sg;
        return ['x = v_0 t + \\tfrac{1}{2}a t^2', 'x = v_0 t + \\tfrac{1}{2}\\dfrac{-mg\\sin\\theta - \\mu\' N}{m} t^2',
          'x = ' + fmt(v.v0 * sg, 1) + 't + \\tfrac{1}{2}(' + fmt(a, 2) + ')t^2'];
      } },
    { key: 'v', short: '$v$–$t$ 図', title: '$v$–$t$ 図（速度）', ylabel: 'v [m/s]', open: true, signed: true,
      series: [{ color: COL.vel, f: function (m) { return m.v; } }],
      fml: function (v, sg) {
        var a = P.m14.a0(v) * sg;
        return ['v = v_0 + at', 'v = v_0 - (g\\sin\\theta + \\mu\' g\\cos\\theta) t',
          'v = ' + fmt(v.v0 * sg, 1) + ' + (' + fmt(a, 2) + ')t'];
      } },
    { key: 'a', short: '$a$–$t$ 図', title: '$a$–$t$ 図（加速度）　※ a の運動方程式による導出', ylabel: 'a [m/s²]', open: false, signed: true,
      series: [{ color: COL.acc, f: function (m) { return m.a; } }],
      fml: function (v, sg) {
        var a = P.m14.a0(v) * sg, th = v.th * DEG;
        return [EQM + 'ma = F_{\\text{合力}}', EQM + 'ma = -mg\\sin\\theta - \\mu\' N',
          '(' + fmt(v.m, 1) + ')a = -' + fmt(v.m * G * Math.sin(th), 1) + ' - ' +
          fmt(v.mud * v.m * G * Math.cos(th), 1) + ' \\;\\Rightarrow\\; a = ' + fmt(a, 2)];
      } }
  ],
  draw: function (ctx, s, t, W, H) {
    var v = V(s), tb = P.m14.table(v);
    var sMin = 0, sMax = 0, i;
    for (i = 0; i < tb.length; i += 5) { sMin = Math.min(sMin, tb[i].x); sMax = Math.max(sMax, tb[i].x); }
    var sn = slopeScene(W, H, v.th, sMin - 0.5, sMax + 1.2);
    drawSlopeBase(ctx, sn, W, H, v.th, s.sign);

    var m = P.m14.sample(v, t);
    var kz = mSize(DEFS['m1-6'], v);
    var bw = 34 * kz, bh = 25 * kz;
    var c = sn.pos(m.x);
    var cx = c.x + sn.n.x * bh / 2, cy = c.y + sn.n.y * bh / 2;
    for (i = 0; i * 0.25 < t - 1e-9; i++) {
      var pp = sn.pos(P.m14.sample(v, i * 0.25).x);
      ctx.save(); ctx.globalAlpha = 0.3;
      blockShape(ctx, pp.x + sn.n.x * bh / 2, pp.y + sn.n.y * bh / 2, sn.th, bw, bh, '#f2f4f7');
      ctx.restore();
    }
    blockShape(ctx, cx, cy, sn.th, bw, bh, '#e8eef5');

    /* 初速度は「デコピンではじいた」ものとして見せる（すべり出したら手は消える） */
    if (Math.abs(v.v0) > 0.05 && t < 0.34) {
      var fdir = v.v0 > 0 ? 1 : -1;
      var fk = clamp(t / 0.10, 0, 1);
      var fa = (t <= 0.13) ? 1 : Math.max(0, 1 - (t - 0.13) / 0.18);
      var o0 = sn.pos(0);
      var fcx = o0.x - sn.u.x * fdir * (bw / 2 + 20) + sn.n.x * (bh * 0.5);
      var fcy = o0.y - sn.u.y * fdir * (bw / 2 + 20) + sn.n.y * (bh * 0.5);
      if (fa > 0.02) {
        flickHand(ctx, fcx, fcy, -sn.th, fk, fdir, 0.42, fa);
        ctx.save(); ctx.globalAlpha = fa;
        bubble(ctx, 'デコピン！',
          clamp(fcx - sn.u.x * fdir * 6 + sn.n.x * 46, 60, W - 60),
          Math.max(26, fcy - sn.u.y * fdir * 6 + sn.n.y * 46),
          { size: 12.5, bg: '#fff5e8', border: '#e07b18', color: '#a85c0c' });
        ctx.restore();
      }
    }

    var mg = v.m * G, fs = 46 / mg;
    if (s.o.showF) {
      arrow(ctx, cx, cy, cx, cy + mg * fs, 'force');
      label(ctx, '重力 mg = ' + fmt(mg, 1) + ' N', cx + 10, cy + mg * fs - 6, { align: 'left', size: 11.5, color: COL.force });
      var Nn = mg * Math.cos(sn.th);
      var ntx = c.x + sn.n.x * Nn * fs, nty = c.y + sn.n.y * Nn * fs;
      arrow(ctx, c.x, c.y, ntx, nty, 'force', 1, COL.norm);
      label(ctx, '垂直抗力 N', ntx - sn.u.x * 16 + sn.n.x * 6, nty - sn.u.y * 16 + sn.n.y * 6,
        { align: 'right', size: 11.5, color: COL.norm });
      var fx = c.x - sn.u.x * bw * 0.28, fy = c.y - sn.u.y * bw * 0.28;
      if (Math.abs(m.f) > 0.3) {
        arrow(ctx, fx, fy, fx + sn.u.x * m.f * fs, fy + sn.u.y * m.f * fs, 'force', 1, COL.fric);
        label(ctx, (m.still ? '静止摩擦 f' : '動摩擦 f') + ' = ' + fmt(Math.abs(m.f), 1) + ' N',
          fx + sn.u.x * (m.f * fs - 34) - sn.n.x * 16, fy + sn.u.y * (m.f * fs - 34) - sn.n.y * 16,
          { size: 11.5, color: COL.fric, align: 'right' });
      }
    }
    if (s.o.showFc && v.th > 0.5) {
      var gsn = mg * Math.sin(sn.th), gcs = mg * Math.cos(sn.th);
      arrow(ctx, cx, cy, cx - sn.u.x * gsn * fs, cy - sn.u.y * gsn * fs, 'comp');
      label(ctx, 'mg sinθ', cx - sn.u.x * gsn * fs - 4, cy - sn.u.y * gsn * fs + 27, { align: 'right', size: 11, color: COL.force });
      arrow(ctx, cx, cy, cx - sn.n.x * gcs * fs, cy - sn.n.y * gcs * fs, 'comp');
    }
    if (s.o.showV && Math.abs(m.v) > 0.05) {
      var vl = 14 + 40 * Math.min(1, Math.abs(m.v) / 10), sg2 = m.v > 0 ? 1 : -1;
      var vx0 = cx + sn.n.x * 40, vy0 = cy + sn.n.y * 40;
      arrow(ctx, vx0, vy0, vx0 + sn.u.x * vl * sg2, vy0 + sn.u.y * vl * sg2, 'vel');
      label(ctx, 'v = ' + fmt(m.v * s.sign, 2) + ' m/s',
        vx0 + sn.u.x * vl * sg2 * 0.5 + sn.n.x * 14, vy0 + sn.u.y * vl * sg2 * 0.5 + sn.n.y * 14,
        { size: 11.5, color: COL.vel });
    }
    /* 加速度の矢印は、速度の矢印とぶつからないよう図の左上に固定して置く */
    var ax0 = W * 0.30, ay0 = 64;
    if (hintOn(s, t)) {
      if (Math.abs(m.a) > 0.02) {
        var asg = m.a > 0 ? 1 : -1;
        arrow(ctx, ax0, ay0, ax0 + sn.u.x * 46 * asg, ay0 + sn.u.y * 46 * asg, 'acc');
        label(ctx, '加速度 a = ' + fmt(m.a * s.sign, 2) + ' m/s²', ax0 - 12, ay0 - 18, { size: 12, color: COL.acc, align: 'right' });
      } else {
        label(ctx, m.still ? '止まった（静止摩擦でつり合い）' : 'a = 0', W * 0.3, 56, { size: 12.5, bold: true, color: COL.acc, align: 'left' });
      }
    }
    label(ctx, 't = ' + fmt(t, 2) + ' s', W - 10, 18, { align: 'right', size: 13.5, bold: true });
    drawPosNote(ctx, DEFS['m1-6'], s, W, 36, dirWord(v.th, s.sign));
  },
  info: function (s, t) {
    var v = V(s), m = P.m14.sample(v, t), th = v.th * DEG;
    return [
      ['垂直抗力 $N = mg\\cos\\theta$', fmt(v.m * G * Math.cos(th), 1) + ' N'],
      ['動摩擦力 $\\mu\' N$', fmt(v.mud * v.m * G * Math.cos(th), 1) + ' N'],
      ['加速度 $a$', fmt(P.m14.a0(v) * s.sign, 2) + ' m/s²'],
      ['速度 $v$', fmt(m.v * s.sign, 2) + ' m/s'],
      ['止まるまでの時間', fmt(P.m14.tStop(v), 2) + ' s'],
      ['すべった距離', fmt(P.m14.xStop(v) * s.sign, 2) + ' m']
    ];
  },
  eq: function (s) {
    var v = V(s), th = v.th * DEG;
    return EQM + 'ma = -mg\\sin\\theta - \\mu\' N \\;\\Rightarrow\\; a = -(g\\sin\\theta + \\mu\' g\\cos\\theta) = ' +
      fmt(P.m14.a0(v), 2) + '\\ \\mathrm{m/s^2}';
  },
  note: '動いているあいだ、動摩擦力は<b>いつも運動と逆向き</b>で大きさ μ′N の一定値。だから <b>a は一定</b>（v–t 図は直線）。水平面（θ＝0）なら a＝−μ′g。すべった距離は <span class="tex">x = \\dfrac{v_0^2}{2|a|}</span> で出せる。'
};

/* ============ 1-6 力を加えながらの斜面上の運動 ============ */
DEFS['m1-7'] = {
  id: 'm1-7', mode: 1, tab: '1-7 斜面で押す',
  quizKey: 'v', quizName: 'この物体の $v$–$t$ 図（斜面にそった向き）',
  title: '1-7　斜面で押す（摩擦あり）',
  desc: '手で斜面の下側から、斜面上向きに力 F で押す。運動方程式から加速度が決まる。',
  sub: 'F が小さいと静止摩擦とつり合って動かない（|F − mg sinθ| ≦ μN）。動き出すと動摩擦 μ′N がはたらく。',
  cw: 520, ch: function (v) { return 196 + 210 * Math.abs(Math.sin(v.th * DEG)); },
  vis: ['F', 'Fc', 'V'],
  signLabels: ['斜面上向きを正', '斜面下向きを正'],
  mainVars: ['F', 'th', 'v0', 'mu', 'mud'],
  vars: [
    { k: 'F', label: '押す力 $F$（斜面上向き）', unit: ' N', min: 0, max: 60, step: 1, dec: 0, def: 20 },
    { k: 'th', label: '斜面の角 $\\theta$', unit: '°', min: 0, max: 50, step: 5, dec: 0, def: 30 },
    { k: 'v0', label: '初速度 $v_0$', unit: ' m/s', min: -4, max: 6, step: 0.5, dec: 1, def: 0.0 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 6, step: 0.5, dec: 1, def: 2.0 },
    { k: 'mu', label: '静止摩擦係数 $\\mu$', unit: '', min: 0, max: 1, step: 0.05, dec: 2, def: 0.50 },
    { k: 'mud', label: '動摩擦係数 $\\mu\'$', unit: '', min: 0, max: 1, step: 0.05, dec: 2, def: 0.30 }
  ],
  toggles: [],
  actions: [
    { label: '斜面にする（θ＝30°）', fn: function (s) { s.v.th = 30; }, is: function (v) { return v.th === 30; } },
    { label: '水平にもどす（θ＝0°）', fn: function (s) { s.v.th = 0; }, is: function (v) { return v.th === 0; } },
    { label: 'F を小さくして動かなくする（F＝5 N）', fn: function (s) { s.v.F = 5; }, is: function (v) { return v.F === 5; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.F = 20; s.v.th = 30; s.v.m = 2; s.v.mu = 0.5; s.v.mud = 0.3; s.v.v0 = 0; },
      is: function (v) { return v.F === 20 && v.th === 30 && v.m === 2 && v.mu === 0.5 && v.mud === 0.3 && v.v0 === 0; } }
  ],
  tEnd: function (v) { return P.m14.tEnd(v); },
  sample: function (v, t) { return P.m14.sample(v, t); },
  graphs: [
    { key: 'x', short: '$x$–$t$ 図', title: '$x$–$t$ 図（位置）', ylabel: 'x [m]', open: false, signed: true,
      series: [{ color: COL.ink, f: function (m) { return m.x; } }],
      fml: function (v, sg) {
        var a = P.m14.a0(v) * sg;
        return ['x = v_0 t + \\tfrac{1}{2}a t^2', 'x = v_0 t + \\tfrac{1}{2}\\dfrac{F - mg\\sin\\theta - \\mu\' N}{m} t^2',
          'x = ' + fmt(v.v0 * sg, 1) + 't + \\tfrac{1}{2}(' + fmt(a, 2) + ')t^2'];
      } },
    { key: 'v', short: '$v$–$t$ 図', title: '$v$–$t$ 図（速度）', ylabel: 'v [m/s]', open: true, signed: true,
      series: [{ color: COL.vel, f: function (m) { return m.v; } }],
      fml: function (v, sg) {
        var a = P.m14.a0(v) * sg;
        return ['v = v_0 + at', 'v = v_0 + \\dfrac{F - mg\\sin\\theta - \\mu\' N}{m} t',
          'v = ' + fmt(v.v0 * sg, 1) + ' + (' + fmt(a, 2) + ')t'];
      } },
    { key: 'a', short: '$a$–$t$ 図', title: '$a$–$t$ 図（加速度）　※ a の運動方程式による導出', ylabel: 'a [m/s²]', open: false, signed: true,
      series: [{ color: COL.acc, f: function (m) { return m.a; } }],
      fml: function (v, sg) {
        var a = P.m14.a0(v) * sg, th = v.th * DEG;
        return [EQM + 'ma = F_{\\text{合力}}', EQM + 'ma = F - mg\\sin\\theta - \\mu\' N',
          '(' + fmt(v.m, 1) + ')a = ' + fmt(v.F, 0) + ' - ' + fmt(v.m * G * Math.sin(th), 1) +
          ' - ' + fmt(v.mud * v.m * G * Math.cos(th), 1) + ' \\;\\Rightarrow\\; a = ' + fmt(a, 2)];
      } }
  ],
  draw: function (ctx, s, t, W, H) {
    var v = V(s), tb = P.m14.table(v);
    var sMin = 0, sMax = 0, i;
    for (i = 0; i < tb.length; i += 5) { sMin = Math.min(sMin, tb[i].x); sMax = Math.max(sMax, tb[i].x); }
    /* 左を広めに空ける（せまいと θ の文字が原点マーク O と重なる） */
    var sn = slopeScene(W, H, v.th, sMin - 3.8, sMax + 1.2);
    drawSlopeBase(ctx, sn, W, H, v.th, s.sign);

    var m = P.m14.sample(v, t);
    var kz = mSize(DEFS['m1-7'], v);
    var bw = 34 * kz, bh = 25 * kz;
    var c = sn.pos(m.x);
    var cx = c.x + sn.n.x * bh / 2, cy = c.y + sn.n.y * bh / 2;
    blockShape(ctx, cx, cy, sn.th, bw, bh, '#e8eef5');

    var mg = v.m * G, fs = 46 / mg;
    var hx = cx - sn.u.x * (bw / 2 + 3), hy = cy - sn.u.y * (bw / 2 + 3);
    hand(ctx, hx - sn.u.x * 5, hy - sn.u.y * 5, -sn.th + Math.PI);   /* 斜面の下側から、物体に接して押す */
    if (s.o.showF) {
      if (v.F > 0.5) {
        arrow(ctx, hx, hy, hx + sn.u.x * v.F * fs, hy + sn.u.y * v.F * fs, 'force', 1, COL.hand);
        label(ctx, '押す力 F = ' + fmt(v.F, 0) + ' N',
          hx - sn.u.x * 14 + sn.n.x * 22, hy - sn.u.y * 14 + sn.n.y * 22,
          { size: 11.5, color: COL.hand, align: 'right' });
      }
      arrow(ctx, cx, cy, cx, cy + mg * fs, 'force');
      label(ctx, '重力 mg = ' + fmt(mg, 1) + ' N', cx + 10, cy + mg * fs - 6, { align: 'left', size: 11.5, color: COL.force });
      var Nn = mg * Math.cos(sn.th);
      var nt2x = c.x + sn.n.x * Nn * fs, nt2y = c.y + sn.n.y * Nn * fs;
      arrow(ctx, c.x, c.y, nt2x, nt2y, 'force', 1, COL.norm);
      label(ctx, '垂直抗力 N', nt2x + sn.u.x * 20 + sn.n.x * 4, nt2y + sn.u.y * 20 + sn.n.y * 4,
        { align: 'left', size: 11.5, color: COL.norm });
      var fx = c.x - sn.u.x * bw * 0.28, fy = c.y - sn.u.y * bw * 0.28;
      if (Math.abs(m.f) > 0.3) {
        arrow(ctx, fx, fy, fx + sn.u.x * m.f * fs, fy + sn.u.y * m.f * fs, 'force', 1, COL.fric);
        label(ctx, (m.still ? '静止摩擦 f' : '動摩擦 f') + ' = ' + fmt(Math.abs(m.f), 1) + ' N',
          fx - sn.u.x * 14 + sn.n.x * 48, fy - sn.u.y * 14 + sn.n.y * 48,
          { size: 11.5, color: COL.fric, align: 'right' });
      }
    }
    if (s.o.showFc && v.th > 0.5) {
      var gsn = mg * Math.sin(sn.th), gcs = mg * Math.cos(sn.th);
      arrow(ctx, cx, cy, cx - sn.u.x * gsn * fs, cy - sn.u.y * gsn * fs, 'comp');
      label(ctx, 'mg sinθ', cx - sn.u.x * gsn * fs - 4, cy - sn.u.y * gsn * fs + 15, { align: 'right', size: 11, color: COL.force });
      arrow(ctx, cx, cy, cx - sn.n.x * gcs * fs, cy - sn.n.y * gcs * fs, 'comp');
    }
    var vAbs = Math.abs(m.v);
    if (s.o.showV && vAbs > 0.05) {
      var vl = 14 + 40 * Math.min(1, vAbs / 6), sg2 = m.v > 0 ? 1 : -1;
      var vx0 = cx + sn.u.x * 26 + sn.n.x * 50, vy0 = cy + sn.u.y * 26 + sn.n.y * 50;
      arrow(ctx, vx0, vy0, vx0 + sn.u.x * vl * sg2, vy0 + sn.u.y * vl * sg2, 'vel');
      label(ctx, 'v = ' + fmt(m.v * s.sign, 2) + ' m/s',
        vx0 + sn.u.x * vl * sg2 * 0.5 + sn.n.x * 16, vy0 + sn.u.y * vl * sg2 * 0.5 + sn.n.y * 16,
        { size: 11.5, color: COL.vel });
    }
    /* 加速度の矢印は、速度の矢印とぶつからないよう図の左上に固定して置く */
    var ax0 = W * 0.30, ay0 = 64;
    if (hintOn(s, t)) {
      if (Math.abs(m.a) > 0.02) {
        var asg = m.a > 0 ? 1 : -1;
        arrow(ctx, ax0, ay0, ax0 + sn.u.x * 46 * asg, ay0 + sn.u.y * 46 * asg, 'acc');
        label(ctx, '加速度 a = ' + fmt(m.a * s.sign, 2) + ' m/s²', ax0 - 12, ay0 - 18, { size: 12, color: COL.acc, align: 'right' });
      } else {
        label(ctx, m.still ? '静止（つり合い）　a = 0' : 'a = 0', W * 0.28, 56, { size: 12.5, bold: true, color: COL.acc, align: 'left' });
      }
      if (m.still) label(ctx, '|F − mg sinθ| ≦ μN なので動かない', W * 0.28, 74, { size: 11, color: COL.sub, align: 'left' });
    }
    label(ctx, 't = ' + fmt(t, 2) + ' s', W - 10, 18, { align: 'right', size: 13.5, bold: true });
    drawPosNote(ctx, DEFS['m1-7'], s, W, 36, dirWord(v.th, s.sign));
  },
  info: function (s, t) {
    var v = V(s), m = P.m14.sample(v, t), th = v.th * DEG;
    return [
      ['垂直抗力 $N = mg\\cos\\theta$', fmt(v.m * G * Math.cos(th), 1) + ' N'],
      ['重力の斜面成分 $mg\\sin\\theta$', fmt(v.m * G * Math.sin(th), 1) + ' N'],
      ['最大静止摩擦 $\\mu N$', fmt(v.mu * v.m * G * Math.cos(th), 1) + ' N'],
      ['いまの摩擦力 $f$', fmt(m.f * s.sign, 1) + ' N'],
      ['加速度 $a$', fmt(m.a * s.sign, 2) + ' m/s²'],
      ['速度 $v$', fmt(m.v * s.sign, 2) + ' m/s']
    ];
  },
  eq: function (s) {
    var v = V(s), m = P.m14.sample(v, s.t), th = v.th * DEG;
    if (m.still) {
      return EQBAL + 'F - mg\\sin\\theta + f = 0,\\quad |f| \\le \\mu N \\;\\Rightarrow\\; a = 0';
    }
    return EQM + 'ma = F - mg\\sin\\theta - \\mu\' N \\;\\Rightarrow\\; a = \\dfrac{' + fmt(v.F, 0) + ' - ' +
      fmt(v.m * G * Math.sin(th), 1) + ' - ' + fmt(v.mud * v.m * G * Math.cos(th), 1) + '}{' + fmt(v.m, 1) + '} = ' +
      fmt(m.a, 2) + '\\ \\mathrm{m/s^2}';
  },
  note: '<b>作用点</b>に注目：重力は<b>物体の中心</b>から、垂直抗力と摩擦力は<b>斜面と触れている面</b>から、押す力は<b>手が触れているところ</b>から。F を小さくすると <span class="tex">|F-mg\\sin\\theta| \\le \\mu N</span> になり、静止摩擦がつり合って<b>動かない</b>。'
};

/* ============ 1-7 カーリングゲーム ============ */
DEFS['m1-8'] = {
  id: 'm1-8', mode: 1, tab: '1-8 氷の上のカーリングゲーム', game: true, hintFlash: true,
  title: '1-8　氷の上のカーリングゲーム 〜的にピタリと止めよう！〜',
  desc: 'ストーンを初速度 v₀ ですべらせて、的にちょうど止められるかな？',
  sub: '動摩擦力だけで減速するので、止まるまでの距離は v₀²/(2|a|)。<b>ストーンを右へドラッグ（スワイプ）して放すと、その勢いで v₀ が決まり、そのまま動き出す。</b>「スライダーで v₀ を決める」に切りかえると、v₀ をスライダーで決めてからドラッグで放つこともできる。的もドラッグで動かせる。',
  cw: 520, ch: 186,
  vis: ['F', 'V'],
  signLabels: ['進む向きを正', '逆向きを正'],
  consts: { F: 0, LEN: 50, TMAX: 20, m: 18, mu: 0.6 },
  mainVars: ['v0', 'mud'],
  vars: [
    { k: 'v0', label: '投げ出す速さ $v_0$', unit: ' m/s', min: 1, max: 12, step: 0.2, dec: 1, def: 5.0 },
    { k: 'mud', label: '氷の動摩擦係数 $\\mu\'$', unit: '', min: 0.005, max: 0.20, step: 0.005, dec: 3, def: 0.050 },
    { k: 'th', label: '面の傾き $\\theta$（のぼり）', unit: '°', min: 0, max: 8, step: 1, dec: 0, def: 0 },
    { k: 'tx', label: '的の位置', unit: ' m', min: 5, max: 45, step: 1, dec: 0, def: 40 }
  ],
  toggles: [{ k: 'useSlider', label: 'スライダーで $v_0$ を決める', def: false }],
  mainOpts: true,
  optSlider: { when: 'useSlider', k: 'v0' },
  actions: [
    { label: 'もっとつるつるにする', fn: function (s) { s.v.mud = +Math.max(0.005, s.v.mud * 0.6).toFixed(3); },
      is: function (v) { return v.mud <= 0.005 + 1e-9; } },
    { label: '氷をもとにもどす（μ′＝0.050）', fn: function (s) { s.v.mud = 0.050; }, is: function (v) { return Math.abs(v.mud - 0.05) < 1e-9; } },
    { label: '斜面にする（θ＝3°ののぼり）', fn: function (s) { s.v.th = 3; }, is: function (v) { return v.th === 3; } },
    { label: '水平にもどす（θ＝0°）', fn: function (s) { s.v.th = 0; }, is: function (v) { return v.th === 0; } }
  ],
  dragStart: true,                            /* スタートはボタンではなくドラッグで */
  HOUSE: 1.6,
  RINK: 52,                                   /* 図に見せる氷の長さ [m] */
  tEnd: function (v) { return Math.min(P.m14.tStop(v) + 0.8, P.m14.tEnd(v)); },
  sample: function (v, t) { return P.m14.sample(v, t); },
  PULL: 4.0,                                  /* いっぱいに引いた長さ [m] */
  PULL_PX: 130,                               /* 画面で「いっぱいに引く」長さ（キャンバス座標） */
  dragDown: function (s, wx, wy, lx) {
    /* ストーンの近くを押したら「右へスワイプして放つ」、的の近くなら的を動かす */
    if (Math.abs(wx - s.v.tx) < 2.6) { s._m = 'tx'; return true; }
    if (wx < 6) { s._m = 'aim'; s._pull = 0; s._px0 = lx; s._hi = null; return true; }
    s._m = 'tx'; return true;
  },
  drag: function (s, wx, wy, lx) {
    if (s._m === 'aim') {
      var px = clamp(lx - (s._px0 || 0), 0, DEFS['m1-8'].PULL_PX);   /* 右へすべらせた長さ（画面） */
      if (px < 3) return;                                            /* 押しただけでは値を変えない */
      s._pull = px / DEFS['m1-8'].PULL_PX;                           /* 0〜1 */
      if (!s.o.useSlider) s.v.v0 = +clamp(1 + s._pull * 11, 1, 12).toFixed(1);
    } else {
      s.v.tx = clamp(Math.round(wx), 5, 45);
    }
  },
  dragUp: function (s) {
    var go = (s._m === 'aim' && s._pull > 0.02);
    s._m = null; s._pull = 0;
    return go;                                             /* 放したらすべり出す */
  },
  win: function (s, t) {
    var v = V(s);
    return Math.abs(P.m14.xStopIdeal(v) - v.tx) <= DEFS['m1-8'].HOUSE;
  },
  graphs: [
    { key: 'x', short: '$x$–$t$ 図', title: '$x$–$t$ 図（位置）', ylabel: 'x [m]', open: true, signed: true,
      series: [{ color: COL.ink, f: function (m) { return m.x; } }],
      fml: function (v, sg) {
        var a = P.m14.a0(v) * sg;
        return ['x = v_0 t + \\tfrac{1}{2}a t^2', 'x = v_0 t - \\tfrac{1}{2}(\\mu\' g\\cos\\theta + g\\sin\\theta) t^2',
          'x = ' + fmt(v.v0 * sg, 1) + 't + \\tfrac{1}{2}(' + fmt(a, 2) + ')t^2'];
      } },
    { key: 'v', short: '$v$–$t$ 図', title: '$v$–$t$ 図（速度）', ylabel: 'v [m/s]', open: true, signed: true,
      series: [{ color: COL.vel, f: function (m) { return m.v; } }],
      fml: function (v, sg) {
        var a = P.m14.a0(v) * sg;
        return ['v^2 - v_0^2 = 2ax \\;\\Rightarrow\\; x = \\dfrac{v_0^2}{2|a|}',
          'v = v_0 - (\\mu\' g\\cos\\theta + g\\sin\\theta) t',
          'v = ' + fmt(v.v0 * sg, 1) + ' + (' + fmt(a, 2) + ')t'];
      } },
    { key: 'a', short: '$a$–$t$ 図', title: '$a$–$t$ 図（加速度）　※ a の運動方程式による導出', ylabel: 'a [m/s²]', open: false, signed: true,
      series: [{ color: COL.acc, f: function (m) { return m.a; } }],
      fml: function (v, sg) {
        var a = P.m14.a0(v) * sg;
        return [EQM + 'ma = F_{\\text{合力}}', EQM + 'ma = -\\mu\' N - mg\\sin\\theta',
          'a = ' + fmt(a, 2) + '\\ \\mathrm{m/s^2}'];
      } }
  ],
  draw: function (ctx, s, t, W, H) {
    var v = V(s);
    var xs = P.m14.xStop(v);
    var hi = DEFS['m1-8'].RINK;              /* いつも同じ目盛り（リンクの長さ） */
    var sn = slopeScene(W, H, v.th, -2.0, hi);
    /* 氷の面 */
    var e = sn.pos(sn.sLo + sn.span), b = sn.pos(sn.sLo);
    ctx.save();
    ctx.fillStyle = '#e8f2f8';
    ctx.beginPath(); ctx.moveTo(b.x, b.y); ctx.lineTo(e.x, e.y); ctx.lineTo(e.x, b.y); ctx.closePath();
    ctx.fill(); ctx.restore();
    hatchLine(ctx, b.x, b.y, e.x, e.y, 1);
    if (v.th > 0.5) angArc(ctx, b.x, b.y, 26, -sn.th, 0, 'θ = ' + fmt(v.th, 0) + '°');
    axisLine(ctx, sn.pos, sn.sLo + 0.5, sn.sLo + sn.span - 0.5,
      { x: sn.n.x, y: sn.n.y }, 'x [m]', s.sign, { target: 5 });   /* 目盛りは上側（かごとぶつからない） */
    var o = sn.pos(0);
    originMark(ctx, o.x, o.y, -sn.n.x * 16 - 5, -sn.n.y * 16 + 4);
    s.view = { invX: function (px) { return sn.sLo + (px - sn.bx) / (sn.u.x * sn.sc); }, invY: function () { return 0; } };

    /* 的 */
    var hp = sn.pos(v.tx);
    var hr = DEFS['m1-8'].HOUSE * sn.sc;
    var bw2 = Math.max(22, hr * 1.7), bh2 = Math.max(16, hr * 1.25);
    ctx.save();                                            /* かごを入れる「穴」を白くぬく */
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(hp.x - bw2 / 2 - 1, hp.y + 1, bw2 + 2, bh2 + 3);
    ctx.restore();
    basketShape(ctx, hp.x, hp.y, bw2, bh2);                /* 的のかごは地面にうめる（上端＝地面） */
    if (t < 1e-9 && s._m !== 'aim') label(ctx, '的のかご（ドラッグで動かせる）', hp.x, hp.y - 30, { size: 10, color: '#2c5f8f' });

    /* ストーン */
    var m = P.m14.sample(v, t);
    var c = sn.pos(m.x);
    var sr = 9;
    var i;
    for (i = 1; i * 0.3 < t - 1e-9; i++) {
      var pp = sn.pos(P.m14.sample(v, i * 0.3).x);
      ball(ctx, pp.x + sn.n.x * sr * 0.5, pp.y + sn.n.y * sr * 0.5, 4, 'faint');
    }
    stone(ctx, c.x + sn.n.x * sr * 0.6, c.y + sn.n.y * sr * 0.6, sr);

    var mg = v.m * G, fs = 44 / mg;
    if (s.o.showF) {
      arrow(ctx, c.x + sn.n.x * sr * 0.6, c.y + sn.n.y * sr * 0.6, c.x + sn.n.x * sr * 0.6, c.y + sn.n.y * sr * 0.6 + mg * fs, 'force');
      var Nn = mg * Math.cos(sn.th);
      arrow(ctx, c.x, c.y, c.x + sn.n.x * Nn * fs, c.y + sn.n.y * Nn * fs, 'force', 1, COL.norm);
      if (Math.abs(m.f) > 0.3) {
        arrow(ctx, c.x, c.y, c.x + sn.u.x * m.f * fs, c.y + sn.u.y * m.f * fs, 'force', 1, COL.fric);
        label(ctx, '動摩擦 μ′N', c.x + sn.u.x * (m.f * fs - 20) - sn.n.x * 14, c.y + sn.u.y * (m.f * fs - 20) - sn.n.y * 14,
          { size: 11, color: COL.fric, align: 'right' });
      }
    }
    /* まだ放っていない（t=0）ときは、速度の矢印を出さない */
    if (s.o.showV && Math.abs(m.v) > 0.05 && s._m !== 'aim' && (t > 1e-9 || s.o.useSlider)) {
      var vl = 12 + 42 * Math.min(1, Math.abs(m.v) / 12);
      var vx0 = c.x + sn.n.x * 30, vy0 = c.y + sn.n.y * 30;
      arrow(ctx, vx0, vy0, vx0 + sn.u.x * vl, vy0 + sn.u.y * vl, 'vel');
      label(ctx, 'v = ' + fmt(m.v * s.sign, 1) + ' m/s', vx0 + sn.u.x * vl * 0.5 + sn.n.x * 13, vy0 + sn.u.y * vl * 0.5 + sn.n.y * 13,
        { size: 11.5, color: COL.vel });
    }
    if (s._m === 'aim') {                                   /* 右へすべらせているようす */
      var st0 = sn.pos(0);
      var swp = (s._pull || 0) * DEFS['m1-8'].PULL_PX;
      ctx.save(); ctx.strokeStyle = '#8a949e'; ctx.setLineDash([5, 4]); ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.moveTo(st0.x + sn.n.x * 10, st0.y + sn.n.y * 10);
      ctx.lineTo(st0.x + sn.n.x * 10 + sn.u.x * swp, st0.y + sn.n.y * 10 + sn.u.y * swp);
      ctx.stroke(); ctx.restore();
      arrow(ctx, st0.x + sn.n.x * 20, st0.y + sn.n.y * 20,
        st0.x + sn.n.x * 20 + sn.u.x * (16 + (s._pull || 0) * 60),
        st0.y + sn.n.y * 20 + sn.u.y * (16 + (s._pull || 0) * 60), 'vel');
      /* まだスワイプしていないうちは v₀ ＝ 0（初期値をそのまま出さない） */
      var v0shown = (s.o.useSlider || (s._pull || 0) > 0) ? v.v0 : 0;
      label(ctx, (s.o.useSlider ? '放すとスタート！　v₀ = ' : '右へスワイプして放つ！　v₀ = ') + fmt(v0shown, 1) + ' m/s',
        st0.x + sn.n.x * 52 + 4, st0.y + sn.n.y * 52, { size: 12.5, bold: true, color: COL.vel, align: 'left' });
    } else if (t < 1e-9) {
      /* ★遊び方はいちばん大事な案内★ 光る帯にして、選んだ直後は数秒ピカピカさせる。
         右上の「正の向き：…」（y=34）とぶつからないよう、1行下げて左に置く。 */
      hintChip(ctx, s.o.useSlider ? 'v₀ はスライダーで決める。ストーンを放すとスタート'
        : 'ストーンを右へスワイプして放すと、その勢いで v₀ が決まってスタート',
        12, 60, flashK());
    }
    var done = t >= DEFS['m1-8'].tEnd(v) - 1e-9;
    label(ctx, 't = ' + fmt(t, 2) + ' s', W - 10, 16, { align: 'right', size: 13, bold: true });
    drawPosNote(ctx, DEFS['m1-8'], s, W, 34);


    if (done) {
      /* 「行き過ぎ」の距離は、氷の外まで行った場合もふくめて式で正しく出す */
      var xIdeal = P.m14.xStopIdeal(v);
      var dd = xIdeal - v.tx, ad = Math.abs(dd);
      var over = !isFinite(xIdeal) || xIdeal > DEFS['m1-8'].RINK;   /* 氷の外まで行った */
      var msg, col;
      if (ad <= 0.4) { msg = 'ど真ん中！ ピタリ賞'; col = { bg: '#e6f7ea', border: '#1c8f4a', color: '#14713a' }; }
      else if (ad <= DEFS['m1-8'].HOUSE) { msg = '的に入った！（ずれ ' + fmt(ad, 1) + ' m）'; col = { bg: '#e6f7ea', border: '#1c8f4a', color: '#14713a' }; }
      else if (over) {
        msg = '氷の外まで行き過ぎた（' + (isFinite(xIdeal) ? fmt(ad, 1) + ' m' : 'ほぼ止まらない') + '）';
        col = { bg: '#fff5d6', border: '#d9a545', color: '#8a5000' };
      } else { msg = (dd < 0 ? '手前で止まった' : '行き過ぎた') + '（' + fmt(ad, 1) + ' m）'; col = { bg: '#fff5d6', border: '#d9a545', color: '#8a5000' }; }
      var bxs = Math.min(v.tx + 6, xIdeal);
      bubble(ctx, msg, Math.min(W - 100, Math.max(100, sn.pos(bxs).x)), sn.pos(bxs).y - 34,
        { size: 13, bg: col.bg, border: col.border, color: col.color });
    }
  },
  info: function (s, t) {
    var v = V(s), m = P.m14.sample(v, t);
    var xs = P.m14.xStopIdeal(v);
    var done = t >= DEFS['m1-8'].tEnd(v) - 1e-9;
    return [
      ['加速度 $a$', fmt(P.m14.a0(v) * s.sign, 2) + ' m/s²'],
      ['的の位置', fmt(v.tx, 0) + ' m'],
      ['いまの位置 $x$', fmt(m.x * s.sign, 2) + ' m'],
      ['いまの速さ $v$', fmt(m.v * s.sign, 2) + ' m/s'],
      ['止まる位置 $v_0^2/(2|a|)$', done ? (isFinite(xs) ? fmt(xs, 2) + ' m' : '∞') : '？'],
      ['ずれ', done ? (isFinite(xs) ? fmt(xs - v.tx, 2) + ' m' : '∞') : '？']
    ];
  },
  eq: function (s) {
    var v = V(s);
    var done = s.t >= DEFS['m1-8'].tEnd(v) - 1e-9;
    return EQM + 'ma = -\\mu\' N - mg\\sin\\theta \\;\\Rightarrow\\; a = ' + fmt(P.m14.a0(v), 2) +
      ',\\quad x_{\\text{止}} = \\dfrac{v_0^{\\,2}}{2|a|} = ' +
      (done ? (isFinite(P.m14.xStopIdeal(v)) ? fmt(P.m14.xStopIdeal(v), 2) + '\\ \\mathrm{m}' : '\\infty') : '?');
  },
  note: '止まる位置は <span class="tex">x=\\dfrac{v_0^2}{2|a|}</span>。<b>v₀ を2倍にすると距離は4倍</b>になるので、少しの速さのちがいが大きく効く。μ′ を変えると氷のすべりやすさが変わり、θ を上げると「のぼり」になってすぐ止まる。'
};
