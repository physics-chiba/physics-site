/* 4　入試物理 */
'use strict';

/* 視点がそのプリセットと同じか */
function camIs(s, az, el, zoom) {
  return !!s.cam && Math.abs(s.cam.az - az) < 0.5 && Math.abs(s.cam.el - el) < 0.5 &&
    Math.abs(s.cam.zoom - zoom) < 0.02;
}

/* ============ 4-1 気球からの水平投射（防衛大2024） ============ */
DEFS['m4-1'] = {
  long: '<h3>4-1 気球からの水平投射（防衛大学校 2024 改）— くわしい解説</h3>' +
    '<h4>1. どんな設定か</h4>' +
    '<p>気球が一定の速さ <span class="tex">V_0</span> で<b>まっすぐ上に上がっている</b>。' +
    '高さ <span class="tex">h</span> に達した瞬間、気球に乗った人が小球を<b>気球から見て水平向きに</b>速さ <span class="tex">v_0</span> で投げ出す。' +
    '小球はやがて地面に落ちる。空気の抵抗は考えない。</p>' +
    '<h4>2. 「投げ出す瞬間の速度」をまちがえない</h4>' +
    '<p>この問題の山場はここ。<b>小球は投げ出される直前、気球といっしょに速さ <span class="tex">V_0</span> で上に動いていた</b>。' +
    'だから地上の人から見た小球の初速度は、水平成分 <span class="tex">v_0</span> と鉛直成分 <span class="tex">V_0</span> を合わせた</p>' +
    '<div class="fmlbox"><span class="tex">\\vec{v}(0) = (v_0,\\; V_0) \\quad\\Rightarrow\\quad \\text{斜め上向きの「斜方投射」}</span></div>' +
    '<p>「水平投射」と書いてあるからといって <span class="tex">v_y(0)=0</span> としてはいけない。' +
    '<b>水平なのは「気球から見たとき」だけ</b>である。</p>' +
    '<h4>3. 2人の観測者で式を書く</h4>' +
    '<p>地面（投げ出した点の真下）を原点にとり、上向きを正とすると、<b>地上の観測者</b>から見て</p>' +
    '<div class="fmlbox"><span class="tex">x = v_0 t,\\qquad y = h + V_0 t - \\tfrac{1}{2}gt^2</span><br>' +
    '<span class="tex">v_x = v_0\\;(\\text{一定}),\\qquad v_y = V_0 - gt</span></div>' +
    '<p>いっぽう<b>気球に乗った観測者</b>は、自分が等速で動いている（＝<b>慣性系</b>）ので、' +
    'いつもの運動方程式がそのまま使える。気球を原点にとると</p>' +
    '<div class="fmlbox"><span class="tex">x\' = v_0 t,\\qquad y\' = -\\tfrac{1}{2}gt^2</span><br>' +
    '<span class="tex">v_x\' = v_0,\\qquad v_y\' = -gt</span></div>' +
    '<p>つまり気球の人には、これは<b>ただの水平投射</b>に見える。' +
    '地面のほうが速さ <span class="tex">V_0</span> で下がってくるように見えるのが違いだ。' +
    '<b>2つの見方は「一定の速度だけずれている」</b>ので、加速度はどちらも <span class="tex">-g</span> で同じ。</p>' +
    '<h4>4. よく問われる量</h4>' +
    '<ul>' +
    '<li><b>最高点の時刻と高さ</b>（地上から見て）：<span class="tex">v_y=0</span> より ' +
    '<span class="tex">t_1 = \\dfrac{V_0}{g}</span>、<span class="tex">y_{\\max} = h + \\dfrac{V_0^{\\,2}}{2g}</span></li>' +
    '<li><b>地面に落ちる時刻</b>：<span class="tex">h + V_0 T - \\tfrac{1}{2}gT^2 = 0</span> を解いて ' +
    '<span class="tex">T = \\dfrac{V_0 + \\sqrt{V_0^{\\,2}+2gh}}{g}</span>（正の解をとる）</li>' +
    '<li><b>落下点までの水平距離</b>：<span class="tex">x = v_0 T</span></li>' +
    '<li><b>落ちた瞬間の速さ</b>：<span class="tex">\\sqrt{v_0^{\\,2} + V_0^{\\,2} + 2gh}</span>' +
    '（力学的エネルギー保存からも同じ式が出る）</li>' +
    '<li><b>そのとき気球はどこにいるか</b>：<span class="tex">y_{\\text{気球}} = h + V_0 T</span>。' +
    '「小球は気球の真下に落ちるか？」と問われたら、気球から見れば水平投射なので<b>真下ではない</b>と即答できる。</li>' +
    '</ul>' +
    '<div class="exam"><b>入試のポイント</b><ol>' +
    '<li><b>「動いている乗り物から投げる」問題は、まず初速度に乗り物の速度を足す。</b>' +
    'これを落とすと以降が全部ずれる。電車・エレベーター・船でも同じ。</li>' +
    '<li><b>等速で動く観測者から見ても物理法則は同じ（慣性系）。</b>' +
    'だから「気球から見る」に切りかえると式が最短になることが多い。答えを最後に地上の座標へ戻せばよい。</li>' +
    '<li><b>落下時刻は2次方程式</b>。解の公式で出た2つの解のうち <span class="tex">t&gt;0</span> を選ぶ。' +
    '<span class="tex">V_0</span> の符号（上昇か下降か）を変えるだけで「下降する気球から投げた」問題にもなる。</li>' +
    '<li><b>速さはエネルギー保存で検算</b>：<span class="tex">\\tfrac{1}{2}mv_0^{\\,2}+\\tfrac{1}{2}mV_0^{\\,2}+mgh = \\tfrac{1}{2}mv^2</span>。' +
    '運動方程式で出した答えと合うか必ず確かめる。</li>' +
    '<li><b>グラフで確認</b>：<span class="tex">v_y</span>–<span class="tex">t</span> 図は観測者を変えると<b>上下にずれるだけ</b>で傾き（＝加速度）は同じ。' +
    'このページで観測者を切りかえて見くらべよう。</li>' +
    '</ol></div>' +
    '<p class="src">※ 防衛大学校 2024 年の問題を教材用に単純化しています。数値・設問は入試そのものではありません。</p>',
  id: 'm4-1', mode: 4, tab: '4-1 気球からの水平投射',
  quizKey: 'vy', quizName: '小球の $v_y$–$t$ 図（鉛直方向・いま選んでいる観測者から見たもの）',
  title: '4-1　気球からの水平投射（出典：防衛大2024）',
  desc: '一定の速さ $V_0$ で上昇する気球が高さ $h$ に来たとき、気球から見て水平に速さ $v_0$ で小球を投げ出す。<b>地上の観測者</b>と<b>気球に乗った観測者</b>を切りかえて見くらべよう。',
  sub: '地上から見ると、小球は最初 $V_0$ で上に動いているので<b>斜方投射</b>になる。気球から見ると、気球は等速（慣性系）なので<b>ただの水平投射</b>で、かわりに地面が $V_0$ で下がってくる。<b>どちらの見方でも加速度は下向きに $g$ で同じ</b>。',
  cw: 520, ch: 380,
  vis: ['F', 'V', 'Vc'],
  signLabels: ['上向きを正', '下向きを正'],
  mainVars: ['v0', 'V0', 'h'], mainOpts: true,
  vars: [
    { k: 'v0', label: '投げ出す速さ $v_0$（気球から見て水平）', unit: ' m/s', min: 2, max: 24, step: 1, dec: 0, def: 10 },
    { k: 'V0', label: '気球の上昇の速さ $V_0$', unit: ' m/s', min: 0, max: 12, step: 1, dec: 0, def: 5 },
    { k: 'h', label: '投げ出す高さ $h$', unit: ' m', min: 5, max: 60, step: 5, dec: 0, def: 30 }
  ],
  toggles: [{ k: 'gline', label: '気球の高さの線を表示', def: true }],
  selects: [{
    k: 'obs', label: '観測者', def: 'ground',
    options: [{ v: 'ground', label: '地上の観測者から見る' }, { v: 'balloon', label: '気球に乗った観測者から見る' }]
  }],
  actions: [
    { label: '気球を止める（V₀＝0）', fn: function (s) { s.v.V0 = 0; }, is: function (v) { return v.V0 === 0; } },
    { label: '気球を上げる（V₀＝5 m/s）', fn: function (s) { s.v.V0 = 5; }, is: function (v) { return v.V0 === 5; } }
  ],
  tEnd: function (v) { return P.m41.tEnd(v); },
  sample: function (v, t) { return P.m41.sample(v, t); },
  graphs: [
    { key: 'y', short: '$y$–$t$ 図', title: '$y$–$t$ 図（高さ）', ylabel: 'y [m]', open: true, signed: true,
      series: [{ color: COL.ink, f: function (m) { return m.y; } }],
      fml: function (v, sg) {
        if (v.obs === 'balloon') return ['y\' = -\\tfrac{1}{2}gt^2', 'y\' = \\tfrac{1}{2}(-g)t^2',
          'y\' = \\tfrac{1}{2}(' + fmt(-G * sg, 2) + ')t^2'];
        return ['y = h + v_{y0}t + \\tfrac{1}{2}at^2', 'y = h + V_0 t - \\tfrac{1}{2}gt^2',
          'y = ' + fmt(v.h * sg, 0) + ' + ' + fmt(v.V0 * sg, 2) + 't + \\tfrac{1}{2}(' + fmt(-G * sg, 2) + ')t^2'];
      } },
    { key: 'vy', short: '$v_y$–$t$ 図', title: '$v_y$–$t$ 図（鉛直方向の速度）', ylabel: 'vy [m/s]', open: true, signed: true,
      series: [{ color: COL.vely, f: function (m) { return m.vy; } }],
      fml: function (v, sg) {
        if (v.obs === 'balloon') return ['v_y\' = -gt', 'v_y\' = (-g)t', 'v_y\' = (' + fmt(-G * sg, 2) + ')t'];
        return ['v_y = v_{y0} + at', 'v_y = V_0 - gt',
          'v_y = ' + fmt(v.V0 * sg, 2) + ' + (' + fmt(-G * sg, 2) + ')t'];
      } },
    { key: 'x', short: '$x$–$t$ 図', title: '$x$–$t$ 図（水平位置・観測者によらず同じ）', ylabel: 'x [m]', open: false, signed: false,
      series: [{ color: COL.ink, f: function (m) { return m.x; } }],
      fml: function (v) { return ['x = v_x t', 'x = v_0 t', 'x = ' + fmt(v.v0, 2) + 't']; } },
    { key: 'vx', short: '$v_x$–$t$ 図', title: '$v_x$–$t$ 図（水平方向の速度は一定）', ylabel: 'vx [m/s]', open: false, signed: false,
      series: [{ color: COL.velx, f: function (m) { return m.vx; } }],
      fml: function (v) { return ['v_x = v_{x0} \\;(\\text{一定})', 'v_x = v_0', 'v_x = ' + fmt(v.v0, 2)]; } },
    { key: 'a', short: '$a$–$t$ 図', title: '$a$–$t$ 図（どちらの観測者でも同じ）　※ a の運動方程式による導出', ylabel: 'ay [m/s²]', open: false, signed: true,
      series: [{ color: COL.acc, f: function (m) { return m.ay; } }],
      fml: function (v, sg) {
        return [EQM + 'ma = -mg \\;(\\text{重力だけ})', 'a = -g', 'a = ' + fmt(-G * sg, 2) + '\\ \\mathrm{m/s^2}'];
      } }
  ],
  draw: function (ctx, s, t, W, H) {
    var v = V(s), T = P.m41.tEnd(v);
    var bal = (v.obs === 'balloon');
    var m = P.m41.sample(v, t);
    var R = P.m41.range(v);
    var box;
    if (bal) {
      var yLo = -0.5 * G * T * T, gLo = -(v.h + v.V0 * T);
      var drop = 0 - Math.min(yLo, gLo);
      box = { x0: -0.16 * R - 2, x1: R + 0.16 * R + 2,
        y0: Math.min(yLo, gLo) - drop * 0.06 - 2, y1: Math.max(6, 0.34 * drop) };
    } else {
      var yHi = Math.max(P.m41.yTop(v), v.h + v.V0 * T);
      box = { x0: -0.16 * R - 2, x1: R + 0.16 * R + 2, y0: -0.10 * yHi - 1, y1: yHi * 1.26 + 3 };
    }
    var pad41 = { l: 46, r: 22, t: 28, b: 34 };
    var vw = mkView(W, H, pad41, box);
    if (bal) {                       /* 原点にいる気球が y 軸の名前と重ならないように */
      var need = 86 / vw.s;
      if (box.y1 < need) { box.y1 = need; vw = mkView(W, H, pad41, box); }
    }
    s.view = vw;

    /* 地面 */
    var gy = bal ? m.groundRel : 0;
    ground(ctx, vw.X(box.x0), vw.X(box.x1), vw.Y(gy));
    worldAxes(ctx, vw, box, bal ? "x' [m]" : 'x [m]', bal ? "y' [m]" : 'y [m]', s.sign);

    /* 気球 */
    var bx = vw.X(0), by = vw.Y(bal ? 0 : m.by);
    var rr = Math.max(13, Math.min(26, 1.30 * vw.s));
    if (s.o.gline) {
      ctx.save(); ctx.strokeStyle = '#c3ccd5'; ctx.setLineDash([5, 4]); ctx.lineWidth = 1.1;
      ctx.beginPath(); ctx.moveTo(vw.X(box.x0), by); ctx.lineTo(vw.X(box.x1), by); ctx.stroke();
      ctx.restore();
    }
    balloonShape(ctx, bx, by, rr);

    /* 気球の速度（地上から見たときだけ意味がある） */
    if (!bal && s.o.showV && v.V0 > 0.01) {
      var vax = bx + rr * 1.5, vlen = Math.min(54, v.V0 * 7);
      arrow(ctx, vax, by, vax, by - vlen, 'vel');
      label(ctx, 'V₀ = ' + fmt(v.V0, 0) + ' m/s', vax + 6, by + 13,
        { align: 'left', size: 11.5, color: COL.vel });
    }
    /* 2人の観測者を棒人間で描く（いま選んでいるほうを青く） */
    (function () {
      var gObsX = vw.X(box.x1 * 0.62);                 /* 地上の観測者の立ち位置 */
      var gObsY = vw.Y(gy);
      observer(ctx, gObsX, gObsY, 0, -1, '地上の観測者', !bal, 30);
      /* 気球に乗った観測者：ゴンドラのすぐ左に立つ */
      observer(ctx, bx - rr * 1.8, by, 0, -1, '気球の観測者', bal, 24, { dx: -2, dy: 6, align: 'right' });
    })();
    if (bal) {
      label(ctx, '気球はいつも原点（自分は止まって見えて、地面が下がっていく）', 10, H - 8,
        { align: 'left', size: 10.5, color: COL.sub });
      if (v.V0 > 0.01 && t > 1e-9) {
        var gpy = vw.Y(gy);
        arrow(ctx, vw.X(box.x1) - 34, gpy - 46, vw.X(box.x1) - 34, gpy - 8, 'vel');
        label(ctx, '地面が ' + fmt(v.V0, 0) + ' m/s で下がって見える', vw.X(box.x1) - 40, gpy - 30,
          { align: 'right', size: 10.5, color: COL.vel });
      }
    }

    drawTraj(ctx, vw, v, P.m41.sample, T, t, 0.2);
    var px = vw.X(m.x), py = vw.Y(m.y);
    ball(ctx, px, py, 8);
    if (s.o.showF) {
      arrow(ctx, px, py, px, py + 46, 'force');
      label(ctx, 'mg', px - 8, py + 40, { align: 'right', size: 11.5, color: COL.force });
    }
    drawVel(ctx, px, py, m, s.o.showV, s.o.showVc, Math.max(6, Math.hypot(v.v0, v.V0) * 1.5));

    /* 高さ h の寸法 */
    if (!bal) {
      var hx = vw.X(box.x0) + 16;
      arrow(ctx, hx, vw.Y(0), hx, vw.Y(v.h), 'dim');
      label(ctx, 'h = ' + fmt(v.h, 0) + ' m', hx - 5, (vw.Y(0) + vw.Y(v.h)) / 2,
        { align: 'right', size: 11, color: COL.sub });
    }
    label(ctx, 't = ' + fmt(t, 2) + ' s', 10, 16, { align: 'left', size: 13.5, bold: true });
    drawPosNote(ctx, DEFS['m4-1'], s, W, 34);
    label(ctx, bal ? '気球に乗った観測者' : '地上の観測者', W - 10, 16,
      { align: 'right', size: 12, bold: true, color: COL.sub });
    if (t >= T - 1e-9) bubble(ctx, '地面に落下', px, py - 18, { size: 12.5 });
  },
  info: function (s, t) {
    var v = V(s), m = P.m41.sample(v, t), T = P.m41.tEnd(v);
    return [
      ['いまの $x$', fmt(m.x, 2) + ' m'],
      ['いまの $y$', fmt(m.y * s.sign, 2) + ' m'],
      ['いまの $v_y$', fmt(m.vy * s.sign, 2) + ' m/s'],
      ['いまの速さ $v$', fmt(m.v, 2) + ' m/s'],
      ['地面に落ちる時刻 $T$', fmt(T, 2) + ' s'],
      ['落下点までの水平距離', fmt(P.m41.range(v), 2) + ' m']
    ];
  },
  eq: function (s) {
    var v = V(s);
    if (v.obs === 'balloon') return "x' = v_0 t,\\qquad y' = -\\tfrac{1}{2}gt^2 \\;\\text{（気球から見ればただの水平投射）}";
    return 'x = v_0 t,\\qquad y = h + V_0 t - \\tfrac{1}{2}gt^2 \\;\\text{（初速度の鉛直成分は }V_0\\text{）}';
  },
  note: '観測者を切りかえて <b>v<sub>y</sub>–t 図</b>を見くらべよう。<b>直線が上下にずれるだけで傾きは同じ</b>（＝加速度は同じ −g）。これが「等速で動く観測者から見ても物理法則は同じ」ということ。'
};

/* グラフの出し分け：水平面の観測者なら x・y・z、斜面の観測者なら X・Y・Z */
function gnd3(v) { return v.obs !== 'slope'; }
function slp3(v) { return v.obs === 'slope'; }

DEFS['m4-3'] = {
  long: '<h3>4-3 斜面上を転がる小球（東京大学 2012 改）— くわしい解説</h3>' +
    '<h4>1. どんな設定か</h4>' +
    '<p>水平な地面に、折り目（図の y 軸）を軸にして角 <span class="tex">\\theta</span> だけ持ち上げた「なめらかな板」を置く。' +
    '板の上で小球を、斜面を上る向き（<b>X 軸</b>）から角 <span class="tex">\\alpha</span> だけ傾けて、速さ <span class="tex">v_0</span> で打ち出す。' +
    '板はなめらか（摩擦なし）なので、小球は板から離れない限り <b>板の面内だけで運動</b>する。</p>' +
    '<h4>2. まず力を分解する（ここが出発点）</h4>' +
    '<p>小球にはたらく力は<b>重力 <span class="tex">mg</span>（下向き）と垂直抗力 <span class="tex">N</span>（板に垂直）の2つだけ</b>。' +
    '重力を「板に垂直な向き」と「板に沿った向き」に分けると、</p>' +
    '<div class="fmlbox"><span class="tex">板に垂直：\\;N = mg\\cos\\theta \\quad(\\text{つり合い、板から離れない})</span><br>' +
    '<span class="tex">板に沿って：\\; ma = -mg\\sin\\theta \\;\\Rightarrow\\; a = -g\\sin\\theta \\quad(\\text{斜面を上る向きが正})</span></div>' +
    '<p>つまり板の上では、<b>重力加速度が <span class="tex">g</span> から <span class="tex">g\\sin\\theta</span> に「弱められた」</b>のと同じ状況になる。' +
    '加速度は<b>つねに斜面を下る向き（−X 向き）</b>で一定、Y 方向（斜面の横方向）には力がはたらかない。</p>' +
    '<h4>3. 運動を X・Y に分けて式にする</h4>' +
    '<div class="fmlbox"><span class="tex">X（斜面上向き）：\\; X = v_0\\cos\\alpha\\, t - \\tfrac{1}{2}(g\\sin\\theta)t^2,\\quad v_X = v_0\\cos\\alpha - (g\\sin\\theta)t</span><br>' +
    '<span class="tex">Y（斜面の横方向）：\\; Y = v_0\\sin\\alpha\\, t,\\quad v_Y = v_0\\sin\\alpha\\;(\\text{一定})</span></div>' +
    '<p>これは<b>「重力が <span class="tex">g\\sin\\theta</span> の平面上の斜方投射」</b>そのもの。' +
    'したがって軌道は板の上の<b>放物線</b>になり、鉛直投げ上げ・水平投射で覚えた式がそのまま使える。</p>' +
    '<h4>4. よく問われる量</h4>' +
    '<ul>' +
    '<li><b>最も高く上がる（X が最大の）時刻</b>：<span class="tex">v_X=0</span> より <span class="tex">t_1 = \\dfrac{v_0\\cos\\alpha}{g\\sin\\theta}</span>、' +
    'そのときの <span class="tex">X_{\\max} = \\dfrac{(v_0\\cos\\alpha)^2}{2g\\sin\\theta}</span></li>' +
    '<li><b>もとの高さ（X＝0）にもどる時刻</b>：<span class="tex">t_2 = 2t_1 = \\dfrac{2v_0\\cos\\alpha}{g\\sin\\theta}</span></li>' +
    '<li><b>そのときの横のずれ</b>：<span class="tex">Y = v_0\\sin\\alpha\\cdot t_2 = \\dfrac{2v_0^{\\,2}\\sin\\alpha\\cos\\alpha}{g\\sin\\theta} = \\dfrac{v_0^{\\,2}\\sin 2\\alpha}{g\\sin\\theta}</span>' +
    '（<span class="tex">\\alpha = 45^\\circ</span> で最大：斜方投射の到達距離と同じ形）</li>' +
    '<li><b>速さの最小値</b>：<span class="tex">v_X=0</span> の瞬間で <span class="tex">v_{\\min}=v_0\\sin\\alpha</span></li>' +
    '</ul>' +
    '<div class="exam"><b>入試のポイント</b><ol>' +
    '<li><b>座標軸は「斜面にそって」取る。</b>水平・鉛直のまま解くと式が2倍やっかいになる。' +
    '「なめらかな斜面上の運動＝重力が <span class="tex">g\\sin\\theta</span> の平面運動」と読みかえるのが定石。</li>' +
    '<li><b>垂直抗力は運動に効かない</b>（板に垂直な向きでつり合うだけ）。' +
    'ただし「板から離れないか」を問う問題では <span class="tex">N \\ge 0</span> の確認が必要。</li>' +
    '<li><b>Y 方向は等速</b>。ここに気づけば「時間 t を Y の式から出して X に代入」で軌道の式 <span class="tex">X = f(Y)</span> がすぐ出る。</li>' +
    '<li>数値が出たら<b>極限で検算</b>：<span class="tex">\\theta \\to 90^\\circ</span> なら普通の斜方投射、<span class="tex">\\theta \\to 0</span> なら等速直線運動に近づく。</li>' +
    '<li>3次元の図に惑わされない。<b>板の上だけを見れば2次元の問題</b>。「板を真上から見る」に切りかえて確かめよう。</li>' +
    '<li><b>観測者を切りかえて見くらべる。</b>水平面の観測者には <span class="tex">a_x = -g\\sin\\theta\\cos\\theta</span>、' +
    '<span class="tex">a_z = -g\\sin^2\\theta</span> と<b>ややこしい値</b>に見えるが、斜面の観測者には ' +
    '<span class="tex">a_X = -g\\sin\\theta</span>、<span class="tex">a_Z = 0</span> と<b>とても簡単</b>になる。' +
    '<b>鉛直方向の加速度が −g ではない</b>のは、垂直抗力が重力の一部を支えているから。</li>' +
    '</ol></div>' +
    '<p class="src">※ 東京大学 2012 年の問題を教材用に単純化しています。数値・設問は入試そのものではありません。</p>',
  id: 'm4-3', mode: 4, tab: '4-3 斜面上を転がる小球',
  quizKey: function (v) { return (v.obs === 'slope') ? 'pgvX' : 'wgvz'; },
  quizName: function (v) {
    return (v.obs === 'slope') ? '小球の $v_X$–$t$ 図（斜面を上る向きが $X$）'
      : '小球の $v_z$–$t$ 図（鉛直方向）';
  },
  title: '4-3　斜面上を転がる小球（出典：東京大学2012）',
  desc: '水平な地面に、折り目を軸にして角 θ だけ持ち上げた「なめらかな板」を置く。板の上を斜めに打ち出した小球は、板の上に放物線をえがく。',
  sub: '斜面の中の座標は、<b>X：斜面を上る向き</b>、<b>Y：斜面の横方向（折り目の向き）</b>、<b>Z：斜面に垂直</b>。$\\alpha$ は X 軸から測った打ち出しの向き。<br><b>「水平面の観測者」</b>は x–z 平面（真横）から見る。<b>「斜面の上の観測者」</b>に切りかえると<b>絵全体が −θ 回って板が水平になり</b>、X–Z 平面で見ることになる。<b>板から離れないので Z はずっと 0</b>——ここがこの問題のポイント。キャンバスをドラッグすると視点が回り、ホイールで拡大縮小できる。',
  cw: 560, ch: 420,
  vis: ['F', 'Fc', 'V', 'Vc'],
  signLabels: ['図の右向き・上向きを正', '図の左向き・下向きを正'],
  cam3d: { az: 0, el: 10, zoom: 1.15 },      /* 既定は「水平面の観測者」の x–z 平面の眺め */
  mainVars: ['v0', 'al'], mainOpts: true,
  drag3d: true,
  selects: [{
    k: 'obs', label: '観測者', def: 'ground',
    options: [{ v: 'ground', label: '水平面の観測者から見る（x・z）' }, { v: 'slope', label: '斜面の上の観測者から見る（X・Z）' }]
  }],
  /* 観測者を切りかえたら、その平面を正面から見る視点にジャンプする */
  onSelect: function (s, k, val) {
    if (k !== 'obs' || !s.cam) return;
    s.cam.az = 0; s.cam.el = 10; s.cam.zoom = 1.15;
  },
  vars: [
    { k: 'th', label: '斜面の傾き $\\theta$', unit: '°', min: 5, max: 60, step: 5, dec: 0, def: 30 },
    { k: 'v0', label: '初速度 $v_0$', unit: ' m/s', min: 2, max: 12, step: 0.5, dec: 1, def: 6.0 },
    { k: 'al', label: '打ち出す向き $\\alpha$', unit: '°', min: 10, max: 80, step: 5, dec: 0, def: 55 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 5, step: 0.5, dec: 1, def: 1.0 }
  ],
  toggles: [{ k: 'flat', label: '斜面を正面から見た図もならべる', def: false }],
  actions: [
    { label: '観測者の正面にもどす', fn: function (s) { s.cam.az = 0; s.cam.el = 10; s.cam.zoom = 1.15; },
      is: function (v, s) { return camIs(s, 0, 10, 1.15); } },
    { label: '板を真上から見る', fn: function (s) { s.cam.az = -90; s.cam.el = 88; s.cam.zoom = 1.35; },
      is: function (v, s) { return camIs(s, -90, 88, 1.35); } },
    { label: 'ななめから見る（3次元）', fn: function (s) { s.cam.az = -38; s.cam.el = 22; s.cam.zoom = 1; },
      is: function (v, s) { return camIs(s, -38, 22, 1); } }
  ],
  tEnd: function (v) { return P.m26.tEnd(v); },
  sample: function (v, t) { return P.m26.sample(v, t); },
  graphs: [
    /* ===== 水平面の観測者（x–z 平面で見る） ===== */
    { key: 'wgx', when: gnd3, short: '$x$–$t$ 図', title: '$x$–$t$ 図（水平方向・斜面を上る向き）', ylabel: 'x [m]', open: true, signed: true,
      series: [{ color: COL.ink, f: function (m) { return m.wx; } }],
      fml: function (v, sg) {
        var ct = Math.cos(v.th * DEG);
        var vx0 = v.v0 * Math.cos(v.al * DEG) * ct, ax = P.m26.a(v) * ct;
        return ['x = v_{x0}t + \\tfrac{1}{2}a_x t^2', 'x = (v_0\\cos\\alpha\\cos\\theta)t - \\tfrac{1}{2}(g\\sin\\theta\\cos\\theta)t^2',
          'x = ' + fmt(vx0 * sg, 2) + 't + \\tfrac{1}{2}(' + fmt(ax * sg, 2) + ')t^2'];
      } },
    { key: 'wgz', when: gnd3, short: '$z$–$t$ 図', title: '$z$–$t$ 図（鉛直方向の高さ）', ylabel: 'z [m]', open: true, signed: true,
      series: [{ color: COL.vely, f: function (m) { return m.wz; } }],
      fml: function (v, sg) {
        var stn = Math.sin(v.th * DEG);
        var vz0 = v.v0 * Math.cos(v.al * DEG) * stn, az = P.m26.a(v) * stn;
        return ['z = v_{z0}t + \\tfrac{1}{2}a_z t^2', 'z = (v_0\\cos\\alpha\\sin\\theta)t - \\tfrac{1}{2}(g\\sin^2\\theta)t^2',
          'z = ' + fmt(vz0 * sg, 2) + 't + \\tfrac{1}{2}(' + fmt(az * sg, 2) + ')t^2'];
      } },
    { key: 'wgy', when: gnd3, short: '$y$–$t$ 図', title: '$y$–$t$ 図（折り目の向き・等速。どちらの観測者でも同じ）', ylabel: 'y [m]', open: false, signed: false,
      series: [{ color: COL.velx, f: function (m) { return m.wy; } }],
      fml: function (v) {
        var vy = v.v0 * Math.sin(v.al * DEG);
        return ['y = v_y t \;(\\text{等速})', 'y = v_0\\sin\\alpha\\, t', 'y = ' + fmt(vy, 2) + 't'];
      } },
    { key: 'wgvx', when: gnd3, short: '$v_x$–$t$ 図', title: '$v_x$–$t$ 図（水平方向の速度）', ylabel: 'vx [m/s]', open: false, signed: true,
      series: [{ color: COL.velx, f: function (m) { return m.wvx; } }],
      fml: function (v, sg) {
        var ct = Math.cos(v.th * DEG);
        var vx0 = v.v0 * Math.cos(v.al * DEG) * ct, ax = P.m26.a(v) * ct;
        return ['v_x = v_{x0} + a_x t', 'v_x = v_0\\cos\\alpha\\cos\\theta - (g\\sin\\theta\\cos\\theta)t',
          'v_x = ' + fmt(vx0 * sg, 2) + ' + (' + fmt(ax * sg, 2) + ')t'];
      } },
    { key: 'wgvz', when: gnd3, short: '$v_z$–$t$ 図', title: '$v_z$–$t$ 図（鉛直方向の速度）', ylabel: 'vz [m/s]', open: false, signed: true,
      series: [{ color: COL.vely, f: function (m) { return m.wvz; } }],
      fml: function (v, sg) {
        var stn = Math.sin(v.th * DEG);
        var vz0 = v.v0 * Math.cos(v.al * DEG) * stn, az = P.m26.a(v) * stn;
        return ['v_z = v_{z0} + a_z t', 'v_z = v_0\\cos\\alpha\\sin\\theta - (g\\sin^2\\theta)t',
          'v_z = ' + fmt(vz0 * sg, 2) + ' + (' + fmt(az * sg, 2) + ')t'];
      } },
    { key: 'wgax', when: gnd3, short: '$a_x$–$t$ 図', title: '$a_x$–$t$ 図（水平方向の加速度）　※ a の運動方程式による導出', ylabel: 'ax [m/s²]', open: false, signed: true,
      series: [{ color: COL.acc, f: function (m) { return m.wax; } }],
      fml: function (v, sg) {
        var ax = P.m26.a(v) * Math.cos(v.th * DEG);
        return [EQM + 'ma_x = -mg\\sin\\theta\\cos\\theta \;(\\text{重力と垂直抗力の合力})',
          'a_x = -g\\sin\\theta\\cos\\theta', 'a_x = ' + fmt(ax * sg, 2) + '\\ \\mathrm{m/s^2}'];
      } },
    { key: 'wgaz', when: gnd3, short: '$a_z$–$t$ 図', title: '$a_z$–$t$ 図（鉛直方向の加速度：$-g$ ではない！）　※ a の運動方程式による導出', ylabel: 'az [m/s²]', open: false, signed: true,
      series: [{ color: COL.acc, f: function (m) { return m.waz; } }],
      fml: function (v, sg) {
        var az = P.m26.a(v) * Math.sin(v.th * DEG);
        return [EQM + 'ma_z = N\\cos\\theta - mg', 'a_z = -g\\sin^2\\theta \;(\\text{垂直抗力が重力の一部を支える})',
          'a_z = ' + fmt(az * sg, 2) + '\\ \\mathrm{m/s^2}'];
      } },
    /* ===== 斜面の上の観測者（X–Z 平面で見る。Z は斜面に垂直） ===== */
    { key: 'pgX', when: slp3, short: '$X$–$t$ 図', title: '$X$–$t$ 図（斜面を上る向きの位置）', ylabel: 'X [m]', open: true, signed: true,
      series: [{ color: COL.ink, f: function (m) { return m.sX; } }],
      fml: function (v, sg) {
        var a = P.m26.a(v) * sg, vX0 = v.v0 * Math.cos(v.al * DEG) * sg;
        return ['X = v_{X0} t + \\tfrac{1}{2}a_X t^2', 'X = v_0\\cos\\alpha\\, t - \\tfrac{1}{2}(g\\sin\\theta) t^2',
          'X = ' + fmt(vX0, 2) + 't + \\tfrac{1}{2}(' + fmt(a, 2) + ')t^2'];
      } },
    { key: 'pgZ', when: slp3, short: '$Z$–$t$ 図', title: '$Z$–$t$ 図（斜面に垂直な向き：ずっと 0）', ylabel: 'Z [m]', open: true, signed: true,
      series: [{ color: COL.vely, f: function (m) { return m.sZ; } }],
      fml: function () {
        return ['Z = v_{Z0}t + \\tfrac{1}{2}a_Z t^2',
          'N = mg\\cos\\theta \;\\text{でつり合うので}\; a_Z = 0,\; v_{Z0} = 0',
          'Z = 0 \;(\\text{板から離れない})'];
      } },
    { key: 'pgY', when: slp3, short: '$Y$–$t$ 図', title: '$Y$–$t$ 図（斜面の横方向・等速。どちらの観測者でも同じ）', ylabel: 'Y [m]', open: false, signed: false,
      series: [{ color: COL.velx, f: function (m) { return m.sY; } }],
      fml: function (v) {
        var vY = v.v0 * Math.sin(v.al * DEG);
        return ['Y = v_Y t \;(\\text{等速})', 'Y = v_0\\sin\\alpha\\, t', 'Y = ' + fmt(vY, 2) + 't'];
      } },
    { key: 'pgvX', when: slp3, short: '$v_X$–$t$ 図', title: '$v_X$–$t$ 図（斜面を上る向きの速度）', ylabel: 'vX [m/s]', open: false, signed: true,
      series: [{ color: COL.velx, f: function (m) { return m.svX; } }],
      fml: function (v, sg) {
        var a = P.m26.a(v) * sg, vX0 = v.v0 * Math.cos(v.al * DEG) * sg;
        return ['v_X = v_{X0} + a_X t', 'v_X = v_0\\cos\\alpha - (g\\sin\\theta)t',
          'v_X = ' + fmt(vX0, 2) + ' + (' + fmt(a, 2) + ')t'];
      } },
    { key: 'pgvZ', when: slp3, short: '$v_Z$–$t$ 図', title: '$v_Z$–$t$ 図（斜面に垂直な向きの速度：ずっと 0）', ylabel: 'vZ [m/s]', open: false, signed: true,
      series: [{ color: COL.vely, f: function (m) { return m.svZ; } }],
      fml: function () { return ['v_Z = v_{Z0} + a_Z t', 'v_{Z0} = 0,\; a_Z = 0', 'v_Z = 0']; } },
    { key: 'pgaX', when: slp3, short: '$a_X$–$t$ 図', title: '$a_X$–$t$ 図（斜面を上る向きの加速度）　※ a の運動方程式による導出', ylabel: 'aX [m/s²]', open: false, signed: true,
      series: [{ color: COL.acc, f: function (m) { return m.saX; } }],
      fml: function (v, sg) {
        var a = P.m26.a(v) * sg;
        return [EQM + 'ma_X = -mg\\sin\\theta', 'a_X = -g\\sin\\theta',
          'a_X = ' + fmt(a, 2) + '\\ \\mathrm{m/s^2}'];
      } },
    { key: 'pgaZ', when: slp3, short: '$a_Z$–$t$ 図', title: '$a_Z$–$t$ 図（斜面に垂直な向きの加速度：0）　※ a の運動方程式による導出', ylabel: 'aZ [m/s²]', open: false, signed: true,
      series: [{ color: COL.acc, f: function (m) { return m.saZ; } }],
      fml: function () {
        return [EQM + 'ma_Z = N - mg\\cos\\theta', 'N = mg\\cos\\theta \;\\text{でつり合う}', 'a_Z = 0'];
      } }
  ],
  draw: function (ctx, s, t, W, H) {
    var v = V(s), T = P.m26.tEnd(v), i, j;
    var th = v.th * DEG, ct = Math.cos(th), stn = Math.sin(th);
    /* 斜面の中の座標 (X: 横, Y: 斜面上向き) → 3次元。y 軸を折り目にして持ち上げた板 */
    var uY = [ct, 0, stn];      /* 斜面上向き */
    var uX = [0, 1, 0];         /* 斜面の横方向 */
    var uN = [-stn, 0, ct];     /* 斜面に垂直（外向き） */
    function P3(X, Y) { return [Y * ct, X, Y * stn]; }

    /* 軌道の広がりから板と地面の大きさを決める */
    var Xmax = 0, Ymax = 0, Xmin = 0;
    for (i = 0; i <= 60; i++) {
      var q = P.m26.sample(v, T * i / 60);
      Xmax = Math.max(Xmax, q.x); Xmin = Math.min(Xmin, q.x); Ymax = Math.max(Ymax, q.y);
    }
    var PX0 = Math.min(-1, Xmin - 1), PX1 = Math.max(2.5, Xmax) + 1, PY1 = Math.max(1.2, Ymax) + 1;
    var GX0 = -1.6, GX1 = PY1 * ct + 1.6, GY0 = PX0 - 1.6, GY1 = PX1 + 1.6;

    /* --- 視点 ---
       拡大率は「方位角によらない」大きさ（水平方向の半径 Rxy と高さ Rz）から決めるので、
       ぐるぐる回しても大きさが変わらず、操作しやすい。 */
    var flat = s.o.flat;
    var wArea = flat ? W - 172 : W;
    var zTop = PY1 * stn;
    var cx0 = PY1 * ct / 2, cy0 = (PX0 + PX1) / 2, cz0 = zTop / 2;
    /* 軸の長さ（見当をつけるための目印なので、板より少し短めでよい） */
    var Lx = Math.max(2.5, PY1 * ct + 1), Ly = Math.max(3, (PX1 + 1) * 0.6), Lz = Math.max(2, zTop + 1);
    var Rxy = 0, Rz = 0;
    [P3(PX0, 0), P3(PX1, 0), P3(PX0, PY1), P3(PX1, PY1),
      [Lx, 0, 0], [0, Ly, 0], [0, 0, Lz], [0, 0, 0]].forEach(function (p) {
      Rxy = Math.max(Rxy, Math.hypot(p[0] - cx0, p[1] - cy0));
      Rz = Math.max(Rz, Math.abs(p[2] - cz0));
    });
    var az = s.cam.az * DEG, el = s.cam.el * DEG;
    var Sh = (wArea / 2 - 22) / Math.max(0.5, Rxy);
    var Sv = (H / 2 - 26) / Math.max(0.4, Rxy * Math.sin(el) + Rz * Math.cos(el));
    var S = Math.min(Sh, Sv) * s.cam.zoom;
    var SCX = wArea / 2, SCY = H / 2 + 10;
    var ca = Math.cos(az), sa = Math.sin(az), ce = Math.cos(el), se = Math.sin(el);
    /* 斜面の観測者のときは、絵全体を θ だけ回して板を水平に見せる（4-2 と同じ考え方） */
    var sl3 = (v.obs === 'slope');
    var kz3 = mSize(DEFS['m4-3'], v);
    var roll = sl3 ? th : 0, cr = Math.cos(roll), sr = Math.sin(roll);
    function PJ(p) {
      var X = p[0] - cx0, Y = p[1] - cy0, Z = p[2] - cz0;
      var x1 = X * ca - Y * sa, y1 = X * sa + Y * ca;
      var dx = x1 * S, dy = -(Z * ce - y1 * se) * S;
      return { x: SCX + (dx * cr - dy * sr), y: SCY + (dx * sr + dy * cr) };
    }
    function seg(a, b, style, lw, dash) {
      var p = PJ(a), q = PJ(b);
      ctx.save(); ctx.strokeStyle = style; ctx.lineWidth = lw || 1;
      if (dash) ctx.setLineDash(dash);
      ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y); ctx.stroke(); ctx.restore();
    }
    function quad(list, fill, stroke, lw) {
      ctx.save(); ctx.beginPath();
      list.forEach(function (p, k) { var q = PJ(p); if (k === 0) ctx.moveTo(q.x, q.y); else ctx.lineTo(q.x, q.y); });
      ctx.closePath();
      if (fill) { ctx.fillStyle = fill; ctx.fill(); }
      if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = lw || 1.3; ctx.stroke(); }
      ctx.restore();
    }
    /* 3次元の矢印。ラベルは矢印の途中から垂直にずらして置く（重なりにくい） */
    function arr3(from, dir, len, kind, text, color, side) {
      var to = [from[0] + dir[0] * len, from[1] + dir[1] * len, from[2] + dir[2] * len];
      var p = PJ(from), q = PJ(to);
      arrow(ctx, p.x, p.y, q.x, q.y, kind, 1,
        (kind === 'force' || kind === 'comp') ? color : undefined);
      if (text) {
        var dx = q.x - p.x, dy = q.y - p.y, LL = Math.hypot(dx, dy) || 1;
        var nx = -dy / LL, ny = dx / LL, sd = side || 1;
        var mx = p.x + dx * 0.72 + nx * 15 * sd, my = p.y + dy * 0.72 + ny * 15 * sd;
        label(ctx, text, mx, my, { size: 11.5, color: color, bold: kind === 'velx' || kind === 'vely' });
      }
      return q;
    }

    /* --- 広い地面（水平面） --- */
    quad([[GX0, GY0, 0], [GX1, GY0, 0], [GX1, GY1, 0], [GX0, GY1, 0]], 'rgba(196,214,196,.34)', '#9db39d', 1.3);
    for (j = Math.ceil(GX0); j <= GX1; j++) seg([j, GY0, 0], [j, GY1, 0], 'rgba(120,150,120,.35)', 1);
    for (j = Math.ceil(GY0); j <= GY1; j++) seg([GX0, j, 0], [GX1, j, 0], 'rgba(120,150,120,.35)', 1);
    var gl = PJ([GX1 - 1.2, GY1 - 0.6, 0]);
    label(ctx, '水平な地面', gl.x, gl.y, { size: 11, color: '#4d6b4d' });

    /* --- 斜面（板） --- */
    quad([P3(PX0, 0), P3(PX1, 0), P3(PX1, PY1), P3(PX0, PY1)], 'rgba(248,242,222,.92)', '#b09a63', 1.8);
    for (j = Math.ceil(PX0); j <= PX1; j++) seg(P3(j, 0), P3(j, PY1), 'rgba(176,154,99,.6)', 0.9);
    for (j = 1; j <= PY1; j++) seg(P3(PX0, j), P3(PX1, j), 'rgba(176,154,99,.6)', 0.9);
    /* 板の厚みを感じさせる、折り目（y 軸）の線 */
    seg(P3(PX0, 0), P3(PX1, 0), '#8a763f', 2.2);

    /* --- 傾き θ の弧（x-z 面内。板の向こう側の端で。X・Y 軸のラベルと重ならない位置） --- */
    var thY = PX1 + 0.4;
    ctx.save();
    ctx.strokeStyle = AX.col; ctx.lineWidth = 1.4;
    ctx.beginPath();
    for (i = 0; i <= 18; i++) {
      var aa = th * i / 18, rr = 1.6;
      var q0 = PJ([Math.cos(aa) * rr, thY, Math.sin(aa) * rr]);
      if (i === 0) ctx.moveTo(q0.x, q0.y); else ctx.lineTo(q0.x, q0.y);
    }
    ctx.stroke(); ctx.restore();
    seg([0, thY, 0], [1.9, thY, 0], AX.col, 1.1, [4, 3]);
    seg([0, thY, 0], [Math.cos(th) * 1.9, thY, Math.sin(th) * 1.9], AX.col, 1.1, [4, 3]);
    var qth = PJ([Math.cos(th / 2) * 2.2, thY, Math.sin(th / 2) * 2.2]);
    label(ctx, 'θ = ' + fmt(v.th, 0) + '°', qth.x, qth.y, { size: 12, color: AX.col });

    /* --- xyz 軸 --- */
    function axis3(dir, L, name) {
      var o = PJ([0, 0, 0]);
      var e = PJ([dir[0] * L, dir[1] * L, dir[2] * L]);
      ctx.save(); ctx.strokeStyle = '#33404d'; ctx.lineWidth = 1.6;
      ctx.beginPath(); ctx.moveTo(o.x, o.y); ctx.lineTo(e.x, e.y); ctx.stroke(); ctx.restore();
      var dx = e.x - o.x, dy = e.y - o.y, LL = Math.hypot(dx, dy) || 1;
      arrowHead(ctx, e.x + dx / LL * 11, e.y + dy / LL * 11, dx / LL, dy / LL, '#33404d');
      label(ctx, name, e.x + dx / LL * 24, e.y + dy / LL * 24, { size: 14, bold: true, color: '#33404d' });
      /* 1 m ごとの目盛り */
      for (var k = 1; k <= Math.floor(L); k++) {
        var tp = PJ([dir[0] * k, dir[1] * k, dir[2] * k]);
        ctx.save(); ctx.fillStyle = '#33404d';
        ctx.beginPath(); ctx.arc(tp.x, tp.y, 2, 0, Math.PI * 2); ctx.fill(); ctx.restore();
      }
    }
    axis3([1, 0, 0], Lx, 'x');
    axis3([0, 1, 0], Ly, 'y');
    axis3([0, 0, 1], Lz, 'z');
    var o0 = PJ([0, 0, 0]);
    originMark(ctx, o0.x, o0.y, -14, 14);

    /* --- 板の上の X 軸・Y 軸（斜面内の座標の定義を図の中に示す） --- */
    var PLC = '#a2571f';
    function plateAxis(dirX, dirY, L, name, sub) {
      var o = PJ(P3(0, 0));
      var e = PJ(P3(dirX * L, dirY * L));
      ctx.save(); ctx.strokeStyle = PLC; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(o.x, o.y); ctx.lineTo(e.x, e.y); ctx.stroke(); ctx.restore();
      var dx = e.x - o.x, dy = e.y - o.y, LL = Math.hypot(dx, dy) || 1;
      arrowHead(ctx, e.x + dx / LL * 10, e.y + dy / LL * 10, dx / LL, dy / LL, PLC);
      label(ctx, name, e.x + dx / LL * 26, e.y + dy / LL * 26, { size: 14, bold: true, color: PLC });
      label(ctx, sub, e.x + dx / LL * 26, e.y + dy / LL * 26 + 14, { size: 10, color: PLC });
      for (var k = 1; k <= Math.floor(L); k++) {
        var tp = PJ(P3(dirX * k, dirY * k));
        ctx.save(); ctx.fillStyle = PLC;
        ctx.beginPath(); ctx.arc(tp.x, tp.y, 2, 0, Math.PI * 2); ctx.fill(); ctx.restore();
      }
    }
    plateAxis(1, 0, Math.max(1.5, Math.min(PX1 - 0.6, 4)), 'Y', '斜面の横方向');
    plateAxis(0, 1, Math.max(1, PY1 - 0.4), 'X', '斜面上向き');
    /* Z 軸（斜面に垂直・板から離れる向き）。この向きには動かないことを図でも示す */
    (function () {
      var LZ = Math.max(1.4, Math.min(PY1 * 0.55, 2.6));
      var o = PJ(P3(0, 0));
      var e = PJ([uN[0] * LZ, uN[1] * LZ, uN[2] * LZ]);
      ctx.save(); ctx.strokeStyle = PLC; ctx.lineWidth = 2; ctx.setLineDash([6, 4]);
      ctx.beginPath(); ctx.moveTo(o.x, o.y); ctx.lineTo(e.x, e.y); ctx.stroke(); ctx.restore();
      var dx = e.x - o.x, dy = e.y - o.y, LL = Math.hypot(dx, dy) || 1;
      arrowHead(ctx, e.x + dx / LL * 10, e.y + dy / LL * 10, dx / LL, dy / LL, PLC);
      label(ctx, 'Z', e.x + dx / LL * 26, e.y + dy / LL * 26, { size: 14, bold: true, color: PLC });
      label(ctx, '斜面に垂直', e.x + dx / LL * 26, e.y + dy / LL * 26 + 14, { size: 10, color: PLC });
      for (var k = 1; k <= Math.floor(LZ); k++) {
        var tp = PJ([uN[0] * k, uN[1] * k, uN[2] * k]);
        ctx.save(); ctx.fillStyle = PLC;
        ctx.beginPath(); ctx.arc(tp.x, tp.y, 2, 0, Math.PI * 2); ctx.fill(); ctx.restore();
      }
    })();

    /* --- 2人の観測者（棒人間）。いま選んでいるほうを青く --- */
    (function () {
      function scrUp(p3, dir) {
        var a0 = PJ(p3), a1 = PJ([p3[0] + dir[0], p3[1] + dir[1], p3[2] + dir[2]]);
        var dx = a1.x - a0.x, dy = a1.y - a0.y, LL = Math.hypot(dx, dy) || 1;
        return { p: a0, ux: dx / LL, uy: dy / LL };
      }
      var gp = scrUp([Math.max(2.2, Lx * 0.9), GY1 - 1.0, 0], [0, 0, 1]);
      observer(ctx, gp.p.x, gp.p.y, gp.ux, gp.uy, '水平面の観測者', !sl3, 26, { dy: 6 });
      var pp = scrUp(P3(PX1 - 0.7, Math.max(1.2, PY1 * 0.62)), uN);
      observer(ctx, pp.p.x, pp.p.y, pp.ux, pp.uy, '斜面の観測者', sl3, 24, { dy: 6 });
    })();

    /* --- 軌道 --- */
    ctx.save();
    ctx.strokeStyle = '#b9c1c9'; ctx.setLineDash([4, 4]); ctx.lineWidth = 1.3;
    ctx.beginPath();
    for (i = 0; i <= 90; i++) {
      var g1 = P.m26.sample(v, T * i / 90), r1 = PJ(P3(g1.x, g1.y));
      if (i === 0) ctx.moveTo(r1.x, r1.y); else ctx.lineTo(r1.x, r1.y);
    }
    ctx.stroke(); ctx.restore();
    ctx.save();
    ctx.strokeStyle = '#e07b18'; ctx.lineWidth = 2.6;
    ctx.beginPath();
    var n = Math.max(2, Math.round(90 * t / Math.max(1e-6, T)));
    for (i = 0; i <= n; i++) {
      var g2 = P.m26.sample(v, t * i / n), r2 = PJ(P3(g2.x, g2.y));
      if (i === 0) ctx.moveTo(r2.x, r2.y); else ctx.lineTo(r2.x, r2.y);
    }
    ctx.stroke(); ctx.restore();
    for (i = 1; i * 0.15 < t - 1e-9; i++) {
      var g3 = P.m26.sample(v, i * 0.15), b3 = P3(g3.x, g3.y);
      var r3 = PJ([b3[0] + uN[0] * 0.13, b3[1] + uN[1] * 0.13, b3[2] + uN[2] * 0.13]);
      ball(ctx, r3.x, r3.y, 4 * kz3, 'faint');
    }

    /* --- 小球と矢印 --- */
    var m = P.m26.sample(v, t);
    /* 小球は板にめり込まないよう、板の面から少し浮かせて描く */
    var RB = 0.13;                                   /* 小球の半径ぶん（板に垂直な向き） */
    var Pb = P3(m.x, m.y);
    Pb = [Pb[0] + uN[0] * RB, Pb[1] + uN[1] * RB, Pb[2] + uN[2] * RB];
    var pb = PJ(Pb);
    ball(ctx, pb.x, pb.y, 8 * kz3);

    var mg = v.m * G, FL = 1.25;             /* mg を 1.25 m の長さでかく */
    if (s.o.showF) {
      arr3(Pb, [0, 0, -1], FL, 'force', 'mg', COL.force, -1);
      arr3(Pb, uN, FL * ct, 'force', 'N', COL.norm, 1);
    }
    /* 分解した力：重力を X（斜面を上る向き）と Z（斜面に垂直）に分ける */
    if (s.o.showFc) {
      arr3(Pb, [-uY[0], -uY[1], -uY[2]], FL * stn, 'comp', 'mg sinθ（−X 向き）', COL.force, 1);
      arr3(Pb, [-uN[0], -uN[1], -uN[2]], FL * ct, 'comp', 'mg cosθ（−Z 向き）', COL.force, -1);
      label(ctx, 'Z 方向：N と mg cosθ がつり合う → 動かない', 12, 56,
        { align: 'left', size: 10.5, color: COL.sub });
    }
    var VL = 0.2;
    /* 分解した速度：X（斜面を上る向き）と Y（斜面の横方向）。Z 成分はいつも 0 */
    if (s.o.showVc) {
      arr3(Pb, uX, m.vx * VL, 'vely', 'v_Y', COL.vely, 1);
      if (Math.abs(m.vy) > 0.05) arr3(Pb, uY, m.vy * VL, 'velx', 'v_X', COL.velx, -1);
      label(ctx, 'v_Z = 0（板から離れない）', 12, 40,
        { align: 'left', size: 11, bold: true, color: COL.vely });
    }
    if (s.o.showV) {
      var sp = Math.hypot(m.vx, m.vy);
      var dv = [uY[0] * m.vy + uX[0] * m.vx, uY[1] * m.vy + uX[1] * m.vx, uY[2] * m.vy + uX[2] * m.vx];
      arr3(Pb, [dv[0] / sp, dv[1] / sp, dv[2] / sp], sp * VL, 'vel', 'v = ' + fmt(sp, 1) + ' m/s', COL.vel, -1);
    }

    /* --- 右：斜面を正面から見た図（オプション） --- */
    if (flat) {
      var ix = W - 164, iy = 40, iw = 154, ih = H - 78;
      ctx.save();
      ctx.fillStyle = '#fbfcfd'; ctx.strokeStyle = '#d9dee4'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.rect(ix, iy, iw, ih); ctx.fill(); ctx.stroke();
      ctx.restore();
      label(ctx, '斜面を正面から見た図', ix + iw / 2, iy - 11, { size: 11, color: COL.sub });
      var fs2 = Math.min((iw - 34) / (PX1 - PX0), (ih - 34) / (PY1 + 0.6));
      var fcx = ix + iw / 2, fcy = iy + ih / 2;
      function FX(X) { return fcx + (X - (PX0 + PX1) / 2) * fs2; }
      function FY(Y) { return fcy - (Y - PY1 / 2) * fs2; }
      axisX(ctx, FX, FY(0), PX0 + 0.3, PX1 - 0.3, 'Y [m]', 1, { target: 3 });
      axisY(ctx, FY, FX(0), -0.3, PY1 - 0.2, 'X [m]', s.sign, { target: 3 });
      originMark(ctx, FX(0), FY(0), -11, 11);
      ctx.save();
      ctx.strokeStyle = '#e07b18'; ctx.lineWidth = 2.2;
      ctx.beginPath();
      for (i = 0; i <= 90; i++) {
        var g4 = P.m26.sample(v, T * i / 90);
        if (i === 0) ctx.moveTo(FX(g4.x), FY(g4.y)); else ctx.lineTo(FX(g4.x), FY(g4.y));
      }
      ctx.stroke(); ctx.restore();
      ball(ctx, FX(m.x), FY(m.y), 6);
    }

    label(ctx, 't = ' + fmt(t, 2) + ' s', 10, 16, { align: 'left', size: 13.5, bold: true });
    drawPosNote(ctx, DEFS['m4-3'], s, W, 34);
    label(ctx, '方位 ' + fmt(s.cam.az, 0) + '°　仰角 ' + fmt(s.cam.el, 0) + '°　（ドラッグで回転／ホイールで拡大縮小）',
      flat ? W - 172 : W - 10, 16, { align: 'right', size: 10.5, color: COL.sub });
  },
  info: function (s, t) {
    var v = V(s), m = P.m26.sample(v, t);
    return [
      ['斜面方向の加速度 $g\\sin\\theta$', fmt(G * Math.sin(v.th * DEG), 2) + ' m/s²'],
      ['$Y$（横方向・等速）', fmt(m.x, 2) + ' m'],
      ['$X$（斜面上向き・等加速度）', fmt(m.y * s.sign, 2) + ' m'],
      ['$v_Y$（一定）', fmt(m.vx, 2) + ' m/s'],
      ['$v_X$', fmt(m.vy * s.sign, 2) + ' m/s'],
      ['最高到達点 $X$', fmt(Math.pow(v.v0 * Math.cos(v.al * DEG), 2) / (2 * G * Math.sin(v.th * DEG)), 2) + ' m'],
      ['もどってくるまでの時間', fmt(P.m26.tEnd(v), 2) + ' s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return 'Y = v_0\\sin\\alpha\\, t,\\qquad X = v_0\\cos\\alpha\\, t - \\tfrac{1}{2}(g\\sin\\theta)t^2,\\qquad g\\sin\\theta = ' +
      fmt(G * Math.sin(v.th * DEG), 2) + '\\ \\mathrm{m/s^2}';
  },
  note: '<b>観測者を切りかえて、グラフを見くらべよう。</b>水平面から見ると x も z も放物線でややこしいが、斜面の上から見ると <b>X だけが放物線・Z はずっと 0</b>（板から離れない）。斜面に垂直な向きでは <span class="tex">N = mg\\cos\\theta</span> でつり合うので動かないからだ。斜面の中では <b>g のかわりに g sinθ</b> がはたらく「ゆっくりした投げ上げ」になる。'
};

/* ============ 4-2 斜面上の斜方投射（横浜市大2018） ============ */
/* グラフの出し分け：水平面の観測者なら x・y、斜面の観測者なら X・Y */
function gnd(v) { return v.obs !== 'slope'; }
function slp(v) { return v.obs === 'slope'; }
DEFS['m4-2'] = {
  long: '<h3>4-2 斜面上の斜方投射（横浜市立大学 2018 改） — くわしい解説</h3>' +
    '<h4>1. どんな設定か</h4>' +
    '<p>傾き <span class="tex">\\theta</span> の斜面の上の点から、<b>斜面から測って角 <span class="tex">\\Phi</span></b>、速さ <span class="tex">v_0</span> でボールを打ち出す。' +
    'ボールは空中を飛び、やがて斜面にもどってくる。水平から測った投射角は <span class="tex">\\Phi + \\theta</span>。' +
    'この教材では <b><span class="tex">\\theta &gt; 0</span> がのぼり坂、<span class="tex">\\theta &lt; 0</span> が下り坂</b>。</p>' +
    '<h4>2. 座標の取り方で難しさが変わる</h4>' +
    '<p>空中なので力は<b>重力だけ</b>。水平・鉛直で解いてもよいが、<b>「斜面にそって X、斜面に垂直に Y」</b>と取ると、' +
    '<b>着地の条件がただの <span class="tex">Y = 0</span></b> になって一気に簡単になる。重力を X・Y に分けると</p>' +
    '<div class="fmlbox"><span class="tex">a_X = -g\\sin\\theta,\\qquad a_Y = -g\\cos\\theta</span></div>' +
    '<p>初速度の成分は <span class="tex">v_{X0} = v_0\\cos\\Phi</span>、<span class="tex">v_{Y0} = v_0\\sin\\Phi</span>。したがって</p>' +
    '<div class="fmlbox"><span class="tex">X = v_0\\cos\\Phi\\, t - \\tfrac{1}{2}(g\\sin\\theta)t^2, \\qquad Y = v_0\\sin\\Phi\\, t - \\tfrac{1}{2}(g\\cos\\theta)t^2</span></div>' +
    '<p><b>Y 方向はただの鉛直投げ上げ</b>（重力加速度が <span class="tex">g\\cos\\theta</span> になっただけ）、' +
    '<b>X 方向は等加速度直線運動</b>（水平投射の「等速」ではないことに注意）。</p>' +
    '<h4>3. 着地までの時間と斜面にそった飛距離</h4>' +
    '<div class="fmlbox"><span class="tex">Y = 0 \\;\\Rightarrow\\; T = \\dfrac{2v_0\\sin\\Phi}{g\\cos\\theta}</span><br>' +
    '<span class="tex">L = X(T) = \\dfrac{2v_0^{\\,2}\\sin\\Phi\\,\\cos(\\Phi+\\theta)}{g\\cos^2\\theta}</span></div>' +
    '<p>飛距離 <span class="tex">L</span> が最大になる角は、和積の公式で <span class="tex">\\sin\\Phi\\cos(\\Phi+\\theta) = \\tfrac{1}{2}\\{\\sin(2\\Phi+\\theta) - \\sin\\theta\\}</span> と直すと、</p>' +
    '<div class="fmlbox"><span class="tex">2\\Phi + \\theta = 90^\\circ \\;\\Rightarrow\\; \\Phi = 45^\\circ - \\dfrac{\\theta}{2}\\quad(\\text{このとき } L_{\\max} = \\dfrac{v_0^{\\,2}(1-\\sin\\theta)}{g\\cos^2\\theta})</span></div>' +
    '<p>のぼり坂（<span class="tex">\\theta&gt;0</span>）では 45° より<b>浅く</b>、下り坂（<span class="tex">\\theta&lt;0</span>）では 45° より<b>深く</b>打つのが最適。' +
    '水平（<span class="tex">\\theta = 0</span>）なら <span class="tex">\\Phi = 45^\\circ</span> で、いつもの斜方投射にもどる。' +
    'シミュレーションで <span class="tex">\\Phi</span> を変えて確かめよう（θ＝30° なら 30°、θ＝−30° なら 60° 付近が最大）。</p>' +
    '<div class="exam"><b>入試のポイント</b><ol>' +
    '<li><b>「斜面に落ちる」＝斜面座標で <span class="tex">Y=0</span></b>。水平・鉛直で解くと「<span class="tex">y = -x\\tan\\theta</span> を代入」という連立になり、計算量が増える。' +
    '<b>着地条件が簡単になる向きに軸を取る</b>のが鉄則。</li>' +
    '<li>斜面座標では <b>X 方向にも加速度がある</b>（<span class="tex">-g\\sin\\theta</span>）。「水平投射だから等速」と早合点しない。</li>' +
    '<li>最大飛距離は<b>三角関数の合成（和積）</b>で <span class="tex">\\Phi = 45^\\circ - \\theta/2</span>。頻出なので導出ごと覚える。</li>' +
    '<li><b>斜面に当たる直前の速度</b>を聞かれたら、<span class="tex">v_Y(T) = -v_0\\sin\\Phi</span>（打ち出しと同じ大きさ・逆向き）を使うと速い。' +
    'エネルギー保存（同じ高さにもどる）からも確認できる。</li>' +
    '<li>下り坂は <span class="tex">\\theta &lt; 0</span> として同じ式で扱える。<b>符号を場合分けせず一本の式で書く</b>と検算がラク。</li>' +
    '<li><b>観測者を切りかえて確かめる。</b>「斜面の上の観測者」の絵にすると斜面が水平になり、' +
    '<b>重力だけが θ 傾いた「ふつうの斜方投射」</b>に見える。同じ運動でも、' +
    '<span class="tex">(x,y)</span> で書くか <span class="tex">(X,Y)</span> で書くかで式の見た目が変わるだけ、' +
    'ということが目で分かる。<b>座標の取り方は自由</b>で、ラクなほうを選んでよい。</li>' +
    '</ol></div>' +
    '<p class="src">※ 横浜市立大学 2018 年の問題を教材用に単純化しています。数値・設問は入試そのものではありません。</p>',
  id: 'm4-2', mode: 4, tab: '4-2 斜面上の斜方投射',
  /* 問題に使うグラフは、いま選んでいる観測者に合わせる */
  quizKey: function (v) { return (v.obs === 'slope') ? 'svY' : 'gvy'; },
  quizName: function (v) {
    return (v.obs === 'slope') ? 'このボールの $v_Y$–$t$ 図（斜面に垂直な向き）'
      : 'このボールの $v_y$–$t$ 図（鉛直方向）';
  },
  title: '4-2　斜面上の斜方投射（出典：横浜市大2018）',
  desc: '斜面の傾きを $\\theta$（のぼりが正）、斜面から測った投射角を $\\Phi$ とする。<b>座標は斜面にそって $X$、斜面に垂直に $Y$</b> をとる。<b>水平面の観測者</b>と<b>斜面の上の観測者</b>を切りかえて見くらべよう。'
    ,
  sub: '斜面にそった軸 X・斜面に垂直な軸 Y で考えると、<b>Y 方向はただの投げ上げ（加速度 −g cosθ）、X 方向は等加速度（加速度 −g sinθ）</b>になる。斜面に落ちるのは Y＝0 にもどったとき。Φ を変えると飛距離が最大になる角が見つかる。θ を負にすると下り坂。<br><b>「斜面の上の観測者から見る」に切りかえると、絵全体が −θ だけ回って斜面が水平になる</b>。斜面が「地面」に見えるかわりに、重力の矢印が θ だけ傾く。うすい x・y 軸がもとの水平・鉛直の向きを示している。',
  cw: 520, ch: 360,
  vis: ['F', 'Fc', 'V', 'Vc'],
  signLabels: ['図の右向き・上向きを正', '図の左向き・下向きを正'],
  mainVars: ['v0', 'phi', 'th'], mainOpts: true,
  vars: [
    { k: 'v0', label: '初速度 $v_0$', unit: ' m/s', min: 5, max: 28, step: 1, dec: 0, def: 14 },
    { k: 'th', label: '斜面の傾き $\\theta$（のぼりが正）', unit: '°', min: -45, max: 45, step: 5, dec: 0, def: 30 },
    { k: 'phi', label: '斜面から測った投射角 $\\Phi$', unit: '°', min: 5, max: 85, step: 5, dec: 0, def: 45 }
  ],
  toggles: [],
  selects: [{
    k: 'obs', label: '観測者', def: 'ground',
    options: [{ v: 'ground', label: '水平面の観測者から見る（x・y）' }, { v: 'slope', label: '斜面の上の観測者から見る（X・Y）' }]
  }],
  tEnd: function (v) { return P.m25.tEnd(v); },
  sample: function (v, t) { return P.m25.sample(v, t); },
  graphs: [
    /* ===== 水平面の観測者（x・y） ===== */
    { key: 'gx', when: gnd, short: '$x$–$t$ 図', title: '$x$–$t$ 図（水平位置）', ylabel: 'x [m]', open: false, signed: false,
      series: [{ color: COL.ink, f: function (m) { return m.x; } }],
      fml: function (v) {
        var vx0 = v.v0 * Math.cos((v.phi + v.th) * DEG);
        return ['x = v_{x0}t', 'x = v_0\\cos(\\Phi+\\theta)\\,t', 'x = ' + fmt(vx0, 2) + 't'];
      } },
    { key: 'gy', when: gnd, short: '$y$–$t$ 図', title: '$y$–$t$ 図（高さ）', ylabel: 'y [m]', open: true, signed: true,
      series: [{ color: COL.ink, f: function (m) { return m.y; } }],
      fml: function (v, sg) {
        var vy0 = v.v0 * Math.sin((v.phi + v.th) * DEG);
        return ['y = v_{y0}t - \\tfrac{1}{2}gt^2', 'y = v_0\\sin(\\Phi+\\theta)\\,t - \\tfrac{1}{2}gt^2',
          'y = ' + fmt(vy0 * sg, 2) + 't + \\tfrac{1}{2}(' + fmt(-G * sg, 2) + ')t^2'];
      } },
    { key: 'gvx', when: gnd, short: '$v_x$–$t$ 図', title: '$v_x$–$t$ 図（水平方向の速度は一定）', ylabel: 'vx [m/s]', open: false, signed: false,
      series: [{ color: COL.velx, f: function (m) { return m.vx; } }],
      fml: function (v) {
        var vx0 = v.v0 * Math.cos((v.phi + v.th) * DEG);
        return ['v_x = v_{x0} \;(\\text{一定})', 'v_x = v_0\\cos(\\Phi+\\theta)', 'v_x = ' + fmt(vx0, 2)];
      } },
    { key: 'gvy', when: gnd, short: '$v_y$–$t$ 図', title: '$v_y$–$t$ 図（鉛直方向の速度）', ylabel: 'vy [m/s]', open: true, signed: true,
      series: [{ color: COL.vely, f: function (m) { return m.vy; } }],
      fml: function (v, sg) {
        var vy0 = v.v0 * Math.sin((v.phi + v.th) * DEG);
        return ['v_y = v_{y0} - gt', 'v_y = v_0\\sin(\\Phi+\\theta) - gt',
          'v_y = ' + fmt(vy0 * sg, 2) + ' + (' + fmt(-G * sg, 2) + ')t'];
      } },
    { key: 'gax', when: gnd, short: '$a_x$–$t$ 図', title: '$a_x$–$t$ 図（水平方向の加速度は 0）　※ a の運動方程式による導出', ylabel: 'ax [m/s²]', open: false, signed: true,
      series: [{ color: COL.acc, f: function () { return 0; } }],
      fml: function () {
        return [EQM + 'ma_x = 0 \;(\\text{水平の力はない})', 'a_x = 0', 'a_x = 0.00\\ \\mathrm{m/s^2}'];
      } },
    { key: 'gay', when: gnd, short: '$a_y$–$t$ 図', title: '$a_y$–$t$ 図（鉛直方向の加速度）　※ a の運動方程式による導出', ylabel: 'ay [m/s²]', open: false, signed: true,
      series: [{ color: COL.acc, f: function () { return -G; } }],
      fml: function (v, sg) {
        return [EQM + 'ma_y = -mg \;(\\text{重力だけ})', 'a_y = -g',
          'a_y = ' + fmt(-G * sg, 2) + '\\ \\mathrm{m/s^2}'];
      } },
    /* ===== 斜面の上の観測者（X・Y） ===== */
    { key: 'sX', when: slp, short: '$X$–$t$ 図', title: '$X$–$t$ 図（斜面にそった位置）', ylabel: 'X [m]', open: false, signed: true,
      series: [{ color: COL.ink, f: function (m) { return m.X; } }],
      fml: function (v, sg) {
        var vX0 = v.v0 * Math.cos(v.phi * DEG), aX = -G * Math.sin(v.th * DEG);
        return ['X = v_{X0}t + \\tfrac{1}{2}a_X t^2', 'X = v_0\\cos\\Phi\\, t - \\tfrac{1}{2}(g\\sin\\theta)t^2',
          'X = ' + fmt(vX0 * sg, 2) + 't + \\tfrac{1}{2}(' + fmt(aX * sg, 2) + ')t^2'];
      } },
    { key: 'sY', when: slp, short: '$Y$–$t$ 図', title: '$Y$–$t$ 図（斜面からの高さ）', ylabel: 'Y [m]', open: true, signed: true,
      series: [{ color: COL.vely, f: function (m) { return m.Y; } }],
      fml: function (v, sg) {
        var vY0 = v.v0 * Math.sin(v.phi * DEG), aY = -G * Math.cos(v.th * DEG);
        return ['Y = v_{Y0}t + \\tfrac{1}{2}a_Y t^2', 'Y = v_0\\sin\\Phi\\, t - \\tfrac{1}{2}(g\\cos\\theta)t^2',
          'Y = ' + fmt(vY0 * sg, 2) + 't + \\tfrac{1}{2}(' + fmt(aY * sg, 2) + ')t^2'];
      } },
    { key: 'svX', when: slp, short: '$v_X$–$t$ 図', title: '$v_X$–$t$ 図（斜面にそった速度）', ylabel: 'vX [m/s]', open: false, signed: true,
      series: [{ color: COL.velx, f: function (m) { return m.vX; } }],
      fml: function (v, sg) {
        var vX0 = v.v0 * Math.cos(v.phi * DEG), aX = -G * Math.sin(v.th * DEG);
        return ['v_X = v_{X0} + a_X t', 'v_X = v_0\\cos\\Phi - (g\\sin\\theta)t',
          'v_X = ' + fmt(vX0 * sg, 2) + ' + (' + fmt(aX * sg, 2) + ')t'];
      } },
    { key: 'svY', when: slp, short: '$v_Y$–$t$ 図', title: '$v_Y$–$t$ 図（斜面に垂直な向きの速度）', ylabel: 'vY [m/s]', open: true, signed: true,
      series: [{ color: COL.vely, f: function (m) { return m.vY; } }],
      fml: function (v, sg) {
        var vY0 = v.v0 * Math.sin(v.phi * DEG), aY = -G * Math.cos(v.th * DEG);
        return ['v_Y = v_{Y0} + a_Y t', 'v_Y = v_0\\sin\\Phi - (g\\cos\\theta)t',
          'v_Y = ' + fmt(vY0 * sg, 2) + ' + (' + fmt(aY * sg, 2) + ')t'];
      } },
    { key: 'saX', when: slp, short: '$a_X$–$t$ 図', title: '$a_X$–$t$ 図（斜面にそった加速度）　※ a の運動方程式による導出', ylabel: 'aX [m/s²]', open: false, signed: true,
      series: [{ color: COL.acc, f: function (m) { return m.aX; } }],
      fml: function (v, sg) {
        var aX = -G * Math.sin(v.th * DEG);
        return [EQM + 'ma_X = -mg\\sin\\theta', 'a_X = -g\\sin\\theta',
          'a_X = ' + fmt(aX * sg, 2) + '\\ \\mathrm{m/s^2}'];
      } },
    { key: 'saY', when: slp, short: '$a_Y$–$t$ 図', title: '$a_Y$–$t$ 図（斜面に垂直な加速度）　※ a の運動方程式による導出', ylabel: 'aY [m/s²]', open: false, signed: true,
      series: [{ color: COL.acc, f: function (m) { return m.aY; } }],
      fml: function (v, sg) {
        var aY = -G * Math.cos(v.th * DEG);
        return [EQM + 'ma_Y = -mg\\cos\\theta', 'a_Y = -g\\cos\\theta',
          'a_Y = ' + fmt(aY * sg, 2) + '\\ \\mathrm{m/s^2}'];
      } }
  ],
  draw: function (ctx, s, t, W, H) {
    var v = V(s), T = P.m25.tEnd(v);
    var sl = (v.obs === 'slope');                 /* 斜面の上に立った観測者から見るか */
    var thR = v.th * DEG, ctS = Math.cos(thR), stS = Math.sin(thR);
    /* 画面にえがく座標。斜面の観測者のときは、絵全体を −θ 回して斜面を水平にする */
    function dsam(vv, tt) {
      var q = P.m25.sample(vv, tt);
      return sl ? { x: q.X, y: q.Y, vx: q.vX, vy: q.vY } : q;
    }
    var land = dsam(v, T);
    var box = sl
      ? trajBox(v, T, dsam, [{ x: -3, y: -1.2 }, { x: land.x + 3, y: 1.2 }])
      : trajBox(v, T, dsam, [{ x: -3, y: -3 * P.m25.tan(v) },
        { x: land.x + 3, y: land.y + (v.th >= 0 ? 1 : -1) }]);
    var vw = mkView(W, H, { l: 44, r: 22, t: 30, b: 34 }, box);
    var tt = P.m25.tan(v);
    s.view = vw;
    /* 斜面 */
    if (sl) hatchLine(ctx, vw.X(box.x0), vw.Y(0), vw.X(box.x1), vw.Y(0), 1);
    else hatchLine(ctx, vw.X(box.x0), vw.Y(box.x0 * tt), vw.X(box.x1), vw.Y(box.x1 * tt), v.th > 0 ? -1 : 1);

    /* 「いま主役でないほうの軸」をうすく表示する */
    (function () {
      var FA = '#c3ccd5', sg = s.sign >= 0 ? 1 : -1;
      /* うすく出すのは、いつも「もとの水平・鉛直の x 軸・y 軸」。
         斜面の観測者の絵では、絵全体が −θ 回っているので x・y も傾いて見える */
      var e1 = sl ? { x: ctS, y: -stS } : { x: 1, y: 0 };         /* x 軸の向き（画面の座標） */
      var e2 = sl ? { x: stS, y: ctS } : { x: 0, y: 1 };          /* y 軸の向き */
      var n1 = 'x', n2 = 'y';
      /* 図の枠の中におさまる長さを求める */
      function fitLen(e) {
        var f = 1e9;
        if (e.x > 1e-6) f = Math.min(f, box.x1 / e.x);
        if (e.x < -1e-6) f = Math.min(f, box.x0 / e.x);
        if (e.y > 1e-6) f = Math.min(f, box.y1 / e.y);
        if (e.y < -1e-6) f = Math.min(f, box.y0 / e.y);
        return Math.max(0.5, f * 0.94);
      }
      ctx.save(); ctx.strokeStyle = FA; ctx.lineWidth = 1.1;
      [e1, e2].forEach(function (e) {
        var lp = fitLen(e), lm = fitLen({ x: -e.x, y: -e.y });
        ctx.beginPath();
        ctx.moveTo(vw.X(-e.x * lm), vw.Y(-e.y * lm));
        ctx.lineTo(vw.X(e.x * lp), vw.Y(e.y * lp));
        ctx.stroke();
      });
      ctx.restore();
      [[e1, n1], [e2, n2]].forEach(function (p) {
        var e = { x: p[0].x * sg, y: p[0].y * sg };
        var L2 = fitLen(e);
        var px2 = vw.X(e.x * L2), py2 = vw.Y(e.y * L2);
        var ux = e.x, uy = -e.y;                                  /* 画面での向き（y は下が正） */
        arrowHead(ctx, px2, py2, ux, uy, FA);
        label(ctx, p[1], px2 - ux * 6 - uy * 13, py2 - uy * 6 + ux * 13,
          { size: 11, color: FA, align: 'center' });
      });
    })();

    /* 主役の軸 */
    var Xlo, Xhi, Ymax, posX, posY;
    if (sl) {
      Xlo = Math.min(-1.5, box.x0 * 0.92); Xhi = Math.max(2, box.x1 - 0.5);
      Ymax = Math.max(2, box.y1 - 0.4);
      posX = function (u2) { return { x: vw.X(u2), y: vw.Y(0) }; };
      posY = function (u2) { return { x: vw.X(0), y: vw.Y(u2) }; };
      axisLine(ctx, posX, Xlo, Xhi, { x: 0, y: 1 }, 'X [m]', s.sign, { target: 5 });
      axisLine(ctx, posY, -0.6, Ymax, { x: -1, y: 0 }, 'Y [m]', s.sign, { target: 4 });
    } else {
      Xlo = Math.min(-1.5, box.x0 * 0.9); Xhi = Math.max(2, (box.x1 - 0.6) / Math.max(0.2, ctS));
      Ymax = Math.max(2, (box.y1 - 0.4));
      posX = function (u2) { return { x: vw.X(u2 * ctS), y: vw.Y(u2 * stS) }; };
      posY = function (u2) { return { x: vw.X(-u2 * stS), y: vw.Y(u2 * ctS) }; };
      axisLine(ctx, posX, Xlo, Xhi, { x: stS, y: ctS }, 'X [m]', s.sign, { target: 5 });
      axisLine(ctx, posY, -0.6, Ymax, { x: ctS, y: -stS }, 'Y [m]', s.sign, { target: 4 });
    }
    originMark(ctx, vw.X(0), vw.Y(0), -14, 14);

    /* θ（斜面の向きと水平の間の角） */
    var slopeScr = sl ? 0 : thR;                  /* 斜面の向き（数学の角・反時計まわりが正） */
    var horizScr = sl ? -thR : 0;                 /* ほんとうの水平の向き */
    ctx.save();
    ctx.strokeStyle = '#b6bfc8'; ctx.setLineDash([5, 4]); ctx.lineWidth = 1.1;
    ctx.beginPath(); ctx.moveTo(vw.X(0), vw.Y(0));
    ctx.lineTo(vw.X(0) + Math.cos(horizScr) * 96, vw.Y(0) - Math.sin(horizScr) * 96); ctx.stroke();
    ctx.restore();
    angArc(ctx, vw.X(0), vw.Y(0), 34, -slopeScr, -horizScr,
      'θ = ' + fmt(v.th, 0) + '°', -(slopeScr + horizScr) / 2, 50);

    /* Φ（斜面から測った投射角） */
    var phiScr = sl ? v.phi * DEG : P.m25.beta(v);
    ctx.save(); ctx.strokeStyle = '#9aa3ac'; ctx.setLineDash([4, 4]); ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(vw.X(0), vw.Y(0));
    ctx.lineTo(vw.X(0) + Math.cos(phiScr) * 78, vw.Y(0) - Math.sin(phiScr) * 78); ctx.stroke();
    ctx.restore();
    angArc(ctx, vw.X(0), vw.Y(0), 64, -phiScr, -slopeScr,
      'Φ = ' + fmt(v.phi, 0) + '°', -(phiScr + slopeScr) / 2 - 0.25, 86);

    /* 2人の観測者を棒人間で描く（いま選んでいるほうを青く） */
    (function () {
      /* 「上」の向き（画面の座標）。水平面の観測者は鉛直、斜面の観測者は斜面に垂直 */
      var upH = sl ? { x: stS, y: -ctS } : { x: 0, y: -1 };
      var upS = sl ? { x: 0, y: -1 } : { x: -stS, y: -ctS };
      /* 水平面の観測者：水平線 y=0 の上（斜面の外側になる向き）に立つ */
      var hx0 = (v.th >= 0 ? box.x0 : box.x1) * 0.62, hy0 = 0;
      var hp = sl ? { x: hx0 * ctS, y: -hx0 * stS } : { x: hx0, y: hy0 };
      observer(ctx, vw.X(hp.x), vw.Y(hp.y), upH.x, upH.y, '水平面の観測者', !sl, 28);
      /* 斜面の観測者：着地点より少し先の斜面の上に立つ */
      var Xs = P.m25.rangeOnSlope(v) + 1.6;
      var sp = sl ? { x: Xs, y: 0 } : { x: Xs * ctS, y: Xs * stS };
      observer(ctx, vw.X(sp.x), vw.Y(sp.y), upS.x, upS.y, '斜面の観測者', sl, 28);
    })();

    drawTraj(ctx, vw, v, dsam, T, t, 0.2);
    var m = P.m25.sample(v, t), md = dsam(v, t);
    var px = vw.X(md.x), py = vw.Y(md.y);
    ball(ctx, px, py, 8);
    /* 重力の向きは「ほんとうの下」。斜面の観測者の絵では θ だけかたむいて見える */
    var gux = sl ? -stS : 0, guy = sl ? ctS : 1;
    if (s.o.showF) {
      arrow(ctx, px, py, px + gux * 46, py + guy * 46, 'force');
      label(ctx, 'mg', px + gux * 40 - 10, py + guy * 40, { align: 'right', size: 11.5, color: COL.force });
    }
    /* 分解した力：斜面の観測者のときは X 方向・Y 方向に分ける */
    if (s.o.showFc && sl) {
      arrow(ctx, px, py, px - stS * 46, py, 'comp');
      label(ctx, 'mg sinθ（−X 向き）', px - stS * 46 - 8, py + 15,
        { align: 'right', size: 11, color: COL.force });
      arrow(ctx, px, py, px, py + ctS * 46, 'comp');
      label(ctx, 'mg cosθ（−Y 向き）', px + 9, py + ctS * 46 - 6,
        { align: 'left', size: 11, color: COL.force });
    } else if (s.o.showFc) {
      label(ctx, '重力はもともと y 方向だけ（分ける必要なし）', px + 12, py + 56,
        { align: 'left', size: 10.5, color: COL.sub });
    }
    drawVel(ctx, px, py, md, s.o.showV, s.o.showVc, Math.max(6, v.v0 * 1.45),
      sl ? ['v_X', 'v_Y'] : null);
    label(ctx, 't = ' + fmt(t, 2) + ' s', 10, 16, { align: 'left', size: 13.5, bold: true });
    drawPosNote(ctx, DEFS['m4-2'], s, W, 34);
    label(ctx, sl ? '斜面の上の観測者（X・Y）' : '水平面の観測者（x・y）', W - 10, 16,
      { align: 'right', size: 12, bold: true, color: COL.sub });
    if (t >= T - 1e-9) bubble(ctx, '斜面に落下', px, py - 16, { size: 12.5 });
  },
  info: function (s, t) {
    var v = V(s), m = P.m25.sample(v, t), T = P.m25.tEnd(v);
    return [
      ['水平から測った投射角 $\\Phi+\\theta$', fmt(v.phi + v.th, 0) + '°'],
      ['斜面に落ちるまでの時間', fmt(T, 2) + ' s'],
      ['斜面にそった飛距離', fmt(P.m25.rangeOnSlope(v), 2) + ' m'],
      ['いまの $x$', fmt(m.x, 2) + ' m'],
      ['いまの $y$', fmt(m.y * s.sign, 2) + ' m'],
      ['いまの $v_y$', fmt(m.vy * s.sign, 2) + ' m/s']
    ];
  },
  eq: function (s) {
    return 'y = x\\tan\\theta \\;\\text{に落ちる}\\;\\Rightarrow\\; t = \\dfrac{2v_0\\{\\sin(\\Phi+\\theta) - \\cos(\\Phi+\\theta)\\tan\\theta\\}}{g}';
  },
  note: '斜面に落ちる条件は「軌道の式」と「斜面の式 <span class="tex">y=-x\\tan\\theta</span>」の<b>連立</b>。飛距離が最大になる Φ を、Φ を動かしながらさがしてみよう（答えは 45°ではない）。'
};