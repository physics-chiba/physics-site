/* 状態 st と DOM。render は st だけから描く。 */
'use strict';

var st = { cur: 'm1-1', sims: {}, qmode: false, bigFml: false };

/* 表示チェックボックスの既定（力は最初オフ） */
var VIS_LABEL = { F: '力を表示', Fm: '運動方向の力のみ表示', Fc: '分解した力を表示', V: '速度を表示', Vc: '分解した速度を表示' };
var VIS_DEF = { F: false, Fm: false, Fc: false, V: true, Vc: false };
var QLETTER = ['ア', 'イ', 'ウ'];

/* 変数（v）と表示オプション（o）をまとめて物理へ渡す */
function V(s) {
  var o = {}, k;
  for (k in s.v) o[k] = s.v[k];
  for (k in s.o) o[k] = s.o[k];
  return o;
}

function $(id) { return document.getElementById(id); }

/* いま表示するグラフだけを返す。
   グラフに when(v) を書くと、その条件のときだけ出る（4-2 の観測者切りかえで使う）。 */
function graphsOf(d, s) {
  var list = d.graphs || [];
  if (!s) return list;
  var v = V(s);
  return list.filter(function (g) { return !g.when || g.when(v); });
}

var FREE_AXES = [
  { k: 't', label: 't [s]' }, { k: 'x', label: 'x [m]' }, { k: 'y', label: 'y [m]' },
  { k: 'vx', label: 'vx [m/s]' }, { k: 'vy', label: 'vy [m/s]' },
  { k: 'v', label: '速さ v [m/s]' }, { k: 'ay', label: 'ay [m/s²]' }
];
function quant(m, t, k) { return k === 't' ? t : m[k]; }

function initState() {
  Object.keys(DEFS).forEach(function (id) {
    var d = DEFS[id];
    var s = {
      v: {}, o: {}, t: 0, playing: false, slow: false, sign: 1,
      open: {}, gview: {}, quiz: null, view: null, _eq: null,
      qphase: 3, qpick: null
    };
    d.vars.forEach(function (vd) { s.v[vd.k] = vd.def; });
    (d.toggles || []).forEach(function (td) { s.o[td.k] = td.def; });
    (d.selects || []).forEach(function (sd) { s.o[sd.k] = sd.def; });
    (d.vis || []).forEach(function (k) {
      s.o['show' + k] = (d.visDef && d.visDef[k] !== undefined) ? d.visDef[k] : VIS_DEF[k];
    });
    if (d.consts) Object.keys(d.consts).forEach(function (k) { s.o[k] = d.consts[k]; });
    (d.graphs || []).forEach(function (g) { s.open[g.key] = !!g.open; });
    if (d.freeGraph) { s.fx = d.freeGraph.defX; s.fy = d.freeGraph.defY; s.open._free = true; }
    if (d.cam3d) s.cam = { az: d.cam3d.az, el: d.cam3d.el, zoom: d.cam3d.zoom || 1 };
    st.sims[id] = s;
  });
}

/* ===== 凡例の小さな矢印 ===== */
function drawLegend() {
  var list = document.querySelectorAll('#legend canvas');
  Array.prototype.forEach.call(list, function (cv) {
    var ctx = prep(cv, 56, 16);
    var ck = cv.getAttribute('data-col');
    arrow(ctx, 4, 8, 50, 8, cv.getAttribute('data-kind'), 0.8, ck ? COL[ck] : null);
  });
}

/* ===== タブ ===== */
function buildTabs() {
  var mt = $('modetabs'), stb = $('simtabs'), cur = DEFS[st.cur];
  mt.innerHTML = '';
  var curBtn = null, curMode = null;
  MODES.forEach(function (M) {
    var b = document.createElement('button');
    b.textContent = M.label;
    if (M.n === cur.mode) { b.className = 'on'; curBtn = b; curMode = M; }
    b.addEventListener('click', function () { if (M.n !== DEFS[st.cur].mode) gotoSim(M.ids[0]); });
    mt.appendChild(b);
  });
  /* 問題モードのスイッチ（タブ列の右端。入れるとどのシミュレーションも問題モードになる） */
  var sw = document.createElement('label');
  sw.className = 'qswitch' + (st.qmode ? ' on' : '');
  sw.id = 'qswitch';
  sw.innerHTML = '<input type="checkbox" id="qmodeChk"' + (st.qmode ? ' checked' : '') + '> 問題モード';
  sw.querySelector('input').addEventListener('change', function (e) { setQmode(e.target.checked); });
  mt.appendChild(sw);
  /* 選んでいるモードのひとこと（青いボタンの真下に表示する） */
  var tip = $('modetip');
  if (!tip) {
    tip = document.createElement('div');
    tip.id = 'modetip';
    mt.parentNode.insertBefore(tip, mt.nextSibling);
  }
  tip.innerHTML = (curMode && curMode.tip) ? curMode.tip : '';
  st._tipBtn = curBtn;
  placeModeTip();
  stb.innerHTML = '';
  MODES.forEach(function (M) {
    if (M.n !== cur.mode) return;
    M.ids.forEach(function (id) {
      if (!DEFS[id]) return;          /* まだ作っていない番号は飛ばす */
      var b = document.createElement('button');
      b.textContent = DEFS[id].tab;
      b.className = (DEFS[id].game ? 'game' : '') + (id === st.cur ? ' on' : '');
      b.addEventListener('click', function () { gotoSim(id); });
      stb.appendChild(b);
    });
  });
}

/* ページ下の「このシミュレーションのURL」欄は外した（ハッシュ自体は今までどおり働く）。
   欄が無くても落ちないように、あるときだけ書きかえる。 */
function updateUrlBar() {
  var box = $('urltext');
  if (!box) return;
  var h = '#' + hashOf();
  box.textContent = (location.protocol === 'file:' || location.origin === 'null')
    ? (location.pathname.split('/').pop() + h)
    : (location.origin + location.pathname + h);
  var msg = $('urlmsg');
  if (msg) msg.textContent = '';
}

/* 画面の高さが低いとき（スマホを横向きにしたときなど）に、図がまるごと1画面に入るよう
   図の列の幅に上限をかける。縦横比は保たれるので高さもいっしょに縮み、
   オレンジの帯や図の上にのせるカードも列といっしょに縮むので、ずれない。 */
function fitStageHeight() {
  var col = document.querySelector('#simhost .cv'), cv = $('mainCv');
  if (!col || !cv) return;
  var vh = window.innerHeight, vw = window.innerWidth;
  var key = vh + 'x' + vw + '|' + (cv.style.aspectRatio || '');
  if (col._fitKey === key) return;
  col._fitKey = key;
  col.style.maxWidth = '';
  if (vh > 620 || vw < 600) return;          /* 縦長の画面・狭い画面はそのまま */
  var r = cv.getBoundingClientRect();
  if (r.width < 1 || r.height < 1) return;
  var avail = vh - 196;                      /* 再生ボタン・帯・見出しのぶんを空ける */
  /* 高さから決まる幅。ただし小さくしすぎると図が読めなくなるので 420px は確保し、
     右のグラフ列を残すための横の上限（画面幅 − 268px）を超えないようにする。 */
  var byH = avail * (r.width / r.height);
  var maxW = Math.min(vw - 268, Math.max(420, byH));
  if (maxW < 340) maxW = 340;
  if (r.width > maxW) col.style.maxWidth = Math.round(maxW) + 'px';
}

/* ひとことの ▲ が、選んでいるモードのボタンの真下に来るようにする */
function placeModeTip() {
  var tip = $('modetip'), b = st._tipBtn, mt = $('modetabs');
  if (!tip || !b || !mt) return;
  /* タブ列の左端を基準にして、選んでいるボタンの真下に ▲ が来るようにする */
  var off = b.getBoundingClientRect().left - mt.getBoundingClientRect().left;
  tip.style.paddingLeft = Math.max(0, off + b.offsetWidth / 2 - 7) + 'px';
}

/* ===== パネルの組み立て ===== */
function buildPanel() {
  /* シムを選んだ瞬間を覚えておく（図の中の「ここを操作してね」を数秒ピカピカさせるため） */
  st._hintT0 = (window.performance && performance.now) ? performance.now() : Date.now();
  var d = DEFS[st.cur], s = st.sims[st.cur];
  s._eq = null;                       /* DOM を作り直すのでキャッシュを捨てる */
  var h = [];
  h.push('<div class="simhead"><div class="simtitle">' + d.title + '</div></div>');
  h.push('<div class="simgrid"><div class="cv">');
  /* 左上：再生ボタンと時間バー */
  h.push('<div class="ctrl playctrl">');
  h.push('<div class="btnrow">');
  h.push('<button id="bPlay">▶ スタート</button>');
  h.push('<button id="bSlow" class="sub">スロー再生</button>');
  h.push('<button id="bReset" class="sub">↺ リセット</button>');
  h.push('<span class="tspan"><label>時間 t</label><input type="range" id="tBar" min="0" max="1" step="0.01" value="0"><span class="tval" id="tVal">0.00 s</span></span>');
  h.push('</div>');
  h.push('<div class="mini" id="qhint" style="display:none"></div>');
  h.push('</div>');
  /* 図（キャンバス）と、その左上にのせる操作エリア
     ＝ 左：よく変える値のカード／右：選択メニュー（上）＋表示チェック（下） */
  var mainKeys = mainVarKeys(d);
  /* カードの並びは mainVars に書いた順（vars の宣言順ではない） */
  var mainList = [];
  mainKeys.forEach(function (k) {
    d.vars.forEach(function (vd) { if (vd.k === k) mainList.push(vd); });
  });
  var topSel = d.mainOpts ? (d.selects || []) : [];
  var topTog = d.mainOpts ? (d.toggles || []) : [];
  h.push('<div class="cvstage' + ((d.actions && d.actions.length) ? '' : ' nobar') + '">');
  h.push('<canvas id="mainCv"' + (d.drag || d.drag3d ? ' class="dragcv"' : '') + '></canvas>');
  h.push('<div class="cvtop" id="cvtop">');
  h.push('<div class="cvvars' + (mainList.length > 3 ? ' two' : '') + '" id="cvvars">');
  mainList.forEach(function (vd) {
    h.push(varRowHtml(vd, 'a', focusOn(d, s, vd), d.mainVarFocus === vd.k));
  });
  h.push('</div>');
  h.push('<div class="cvside">');
  if (topSel.length || topTog.length) {
    h.push('<div class="cvopts">');
    topSel.forEach(function (sd) {
      h.push('<label class="cvsel">' + sd.label + '<select data-sel="' + sd.k + '">' +
        sd.options.map(function (o) { return '<option value="' + o.v + '"' + (o.v === s.o[sd.k] ? ' selected' : '') + '>' + o.label + '</option>'; }).join('') +
        '</select></label>');
    });
    topTog.forEach(function (td) {
      h.push('<label><input type="checkbox" data-tog="' + td.k + '"' + (s.o[td.k] ? ' checked' : '') + '> ' + mathHtml(td.label) + '</label>');
    });
    if (d.optSlider && s.o[d.optSlider.when]) {          /* チェックを入れたときだけ出るスライダー */
      var sv = null;
      d.vars.forEach(function (x) { if (x.k === d.optSlider.k) sv = x; });
      if (sv) {
        h.push('<span class="optsl"><input type="range" class="vsl" data-vsl="' + sv.k + '" ' +
          'min="' + sv.min + '" max="' + sv.max + '" step="' + sv.step + '">' +
          '<span class="vval" data-vval="' + sv.k + '"></span></span>');
      }
    }
    h.push('</div>');
  }
  if (d.vis && d.vis.length) {
    h.push('<div class="opts">');
    d.vis.forEach(function (k) {
      /* d.visFlash に指定したものは、チェックが入るまで目立たせて光らせる */
      var fl = (d.visFlash === k && !s.o['show' + k]) ? ' class="vflash"' : '';
      h.push('<label' + fl + '><input type="checkbox" data-vis="show' + k + '"' +
        (s.o['show' + k] ? ' checked' : '') + '> ' + VIS_LABEL[k] + '</label>');
    });
    h.push('</div>');
  }
  h.push('</div></div></div>');
  /* 図の下のバー：状況を変えるオレンジのボタン */
  if (d.actions && d.actions.length) {
    h.push('<div class="cvbar"><div class="acts n' + Math.min(5, d.actions.length) + '">');
    d.actions.forEach(function (a, i) { h.push('<button class="warm" data-act="' + i + '" id="act_' + i + '">' + a.label + '</button>'); });
    h.push('</div></div>');
  }
  if (d.sub) h.push('<p class="cvsub">' + mathHtml(d.sub) + '</p>');
  h.push('<div class="eqwrap"><div class="eqttl" id="eqttl" style="display:none"></div>' +
    '<div class="eq" id="eqbox"></div></div>');
  h.push('</div><div class="side">');

  if (d.quiz) {
    h.push('<div class="quiz"><b>クイズ</b>：' + d.quiz.q + '<div class="qbtns">');
    d.quiz.choices.forEach(function (c, i) { h.push('<button data-q="' + i + '">' + c + '</button>'); });
    h.push('</div><div class="ans" id="quizans">まず3つの中から予想を選ぼう。選んでから「スタート」！</div></div>');
  }

  /* 問題モードの3択（ゲームには問題を出さない） */
  if (!d.game) h.push('<div class="gquiz" id="gquiz" style="display:none"><b>問題</b>：' + mathHtml(quizName(d)) +
    ' はどれ？<span class="qsign" id="qsign"></span>' +
    '<div class="gqrow" id="gqrow">');
  if (!d.game) for (var qi = 0; qi < 3; qi++) {
    h.push('<div class="gqopt" data-gq="' + qi + '"><canvas id="gq_' + qi + '"></canvas><div class="lb">' + QLETTER[qi] + '</div></div>');
  }
  if (!d.game) h.push('</div><div class="gqmsg" id="gqmsg"></div></div>');

  h.push('<div class="btnrow openrow"><button class="warm" id="bOpenAll">' + openAllLabel() + '</button>' +
    '<button class="sub" id="bBigFml">' + bigFmlLabel() + '</button>' +
    '<span class="ghint1">グラフは ドラッグ＝移動／目盛りの上でドラッグ＝軸の拡大縮小／ホイール＝拡大縮小／ダブルクリック＝自動</span></div>');

  graphsOf(d, s).forEach(function (g) {
    h.push('<div class="gsec"><button class="ghead" data-g="' + g.key + '"><span class="tri">' +
      (s.open[g.key] ? '▼' : '▶') + '</span>' + mathHtml(g.title) + '</button>' +
      '<div class="gbody' + (s.open[g.key] ? '' : ' hide') + (st.bigFml ? ' bigf' : '') + '" id="gb_' + g.key + '">' +
      '<div class="gleft"><canvas id="gc_' + g.key + '"></canvas></div>' +
      (g.fml ? '<div class="gform" id="gf_' + g.key + '"></div>' : '') +
      '</div></div>');
  });
  if (d.freeGraph) {
    h.push('<div class="gsec"><button class="ghead" data-g="_free"><span class="tri">' +
      (s.open._free ? '▼' : '▶') + '</span>縦軸・横軸を自由に選べるグラフ</button>' +
      '<div class="gbody' + (s.open._free ? '' : ' hide') + (st.bigFml ? ' bigf' : '') + '" id="gb__free"><div class="gleft"><div class="gsel">' +
      '縦軸<select id="selFy">' + FREE_AXES.map(function (a) { return '<option value="' + a.k + '"' + (a.k === s.fy ? ' selected' : '') + '>' + a.label + '</option>'; }).join('') + '</select>' +
      '横軸<select id="selFx">' + FREE_AXES.map(function (a) { return '<option value="' + a.k + '"' + (a.k === s.fx ? ' selected' : '') + '>' + a.label + '</option>'; }).join('') + '</select>' +
      '</div><canvas id="gc__free"></canvas></div></div></div>');
  }

  /* note も sub と同じく「$…$」を KaTeX に変換する（<span class="tex"> 直書きも可） */
  h.push('<div class="note" id="notebox"><b>見るポイント</b>：' + mathHtml(d.note) + '</div>');

  h.push('<div class="signsw"><span>グラフで正とする向き：</span>' +
    '<button id="sgnP" class="' + (s.sign > 0 ? '' : 'sub') + '">' + d.signLabels[0] + '</button>' +
    '<button id="sgnM" class="' + (s.sign < 0 ? '' : 'sub') + '">' + d.signLabels[1] + '</button></div>');

  h.push('<div class="ctrl">');
  (d.mainOpts ? [] : (d.selects || [])).forEach(function (sd) {
    h.push('<div class="row"><label>' + sd.label + '</label><select data-sel="' + sd.k + '">' +
      sd.options.map(function (o) { return '<option value="' + o.v + '"' + (o.v === s.o[sd.k] ? ' selected' : '') + '>' + o.label + '</option>'; }).join('') +
      '</select></div>');
  });
  (d.mainOpts ? [] : (d.toggles || [])).forEach(function (td) {
    h.push('<div class="row"><label><input type="checkbox" data-tog="' + td.k + '"' + (s.o[td.k] ? ' checked' : '') + '> ' + td.label + '</label></div>');
  });
  var restCount = 0;
  d.vars.forEach(function (vd) {
    if (mainKeys.indexOf(vd.k) >= 0) return;
    restCount++;
    h.push(varRowHtml(vd, 'b'));
  });
  h.push('</div>');
  if (restCount === 0 && (d.mainOpts || (!(d.selects || []).length && !(d.toggles || []).length))) {
    h[h.length - 1] = '';   /* 変えるものが残っていなければ、下のブロックは出さない */
    h[h.length - 2] = '';
  }
  h.push('<table class="read" id="readout"></table>');
  h.push('</div></div>');
  $('simhost').innerHTML = h.join('');
  /* 3次元の視点操作の説明は、3次元の図のシム（4-3）を見ているときだけ出す */
  var h3d = $('hint3d');
  if (h3d) h3d.style.display = d.drag3d ? '' : 'none';
  /* くわしい解説は、パネルを差しかえた「あと」に出す
     （中で renderActive() が走るので、先に呼ぶと運動方程式の欄が空になる） */
  renderLong(d);

  /* --- イベント --- */
  if (d.game) {
    $('mainCv').addEventListener('dblclick', function () { resetSim(); renderActive(); });
  }
  $('bPlay').addEventListener('click', onPlay);
  $('bSlow').addEventListener('click', function () {
    s.slow = !s.slow;
    $('bSlow').className = s.slow ? '' : 'sub';
    $('bSlow').textContent = s.slow ? 'スロー再生 中' : 'スロー再生';
  });
  $('bReset').addEventListener('click', function () { s.t = 0; s.playing = false; setPlayLabel(); renderActive(); });
  $('tBar').addEventListener('input', function (e) {
    s.t = +e.target.value; s.playing = false; setPlayLabel(); renderActive();
  });
  $('bOpenAll').addEventListener('click', function () { toggleAllGraphs(); });
  $('bBigFml').addEventListener('click', function () { toggleBigFml(); });
  if (st.bigFml) $('bBigFml').className = '';

  Array.prototype.forEach.call($('simhost').querySelectorAll('.ghead'), function (b) {
    b.addEventListener('click', function () {
      var k = b.getAttribute('data-g');
      s.open[k] = !s.open[k];
      $('gb_' + k).className = 'gbody' + (s.open[k] ? '' : ' hide') + (st.bigFml ? ' bigf' : '');
      b.querySelector('.tri').textContent = s.open[k] ? '▼' : '▶';
      $('bOpenAll').innerHTML = openAllLabel();
      renderMath($('bOpenAll'));
      renderActive();
    });
  });
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-ga]'), function (b) {
    b.addEventListener('click', function () { delete s.gview[b.getAttribute('data-ga')]; renderActive(); });
  });
  $('sgnP').addEventListener('click', function () { setSign(s, 1); });
  $('sgnM').addEventListener('click', function () { setSign(s, -1); });

  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-act]'), function (b) {
    b.addEventListener('click', function () {
      d.actions[+b.getAttribute('data-act')].fn(s);
      if (!d.cam3d) resetSim();
      syncVarVals(); renderActive();
    });
  });
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-sel]'), function (el) {
    el.addEventListener('change', function () {
      var sk = el.getAttribute('data-sel');
      s.o[sk] = el.value;
      if (d.onSelect) d.onSelect(s, sk, el.value);   /* 視点を切りかえるなど */
      resetSim();
      /* 選択でグラフの顔ぶれが変わるシム（4-2）は、パネルを作り直す */
      if ((d.graphs || []).some(function (g) { return !!g.when; })) buildPanel();
      renderActive();
    });
  });
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-tog]'), function (el) {
    el.addEventListener('change', function () {
      var k = el.getAttribute('data-tog');
      s.o[k] = el.checked;
      if (d.optSlider && d.optSlider.when === k) { buildPanel(); }   /* スライダーを出し入れ */
      renderActive();
    });
  });
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-vis]'), function (el) {
    el.addEventListener('change', function () {
      var key = el.getAttribute('data-vis');
      s.o[key] = el.checked;
      if (el.checked && el.parentNode) el.parentNode.classList.remove('vflash');   /* 押されたら光りをやめる */
      /* 「力を表示」と「運動方向の力のみ表示」は同時にはチェックできない */
      if (el.checked && (key === 'showF' || key === 'showFm')) {
        var other = (key === 'showF') ? 'showFm' : 'showF';
        if (s.o[other]) {
          s.o[other] = false;
          var ob = $('simhost').querySelector('[data-vis="' + other + '"]');
          if (ob) ob.checked = false;
        }
      }
      renderActive();
    });
  });
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-vsl]'), function (r) {
    r.addEventListener('input', function () { setVar(r.getAttribute('data-vsl'), +r.value); });
  });
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-var]'), function (b) {
    b.addEventListener('click', function () { stepVar(b.getAttribute('data-var'), +b.getAttribute('data-dir')); });
  });
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-q]'), function (b) {
    b.addEventListener('click', function () {
      s.quiz = +b.getAttribute('data-q');
      Array.prototype.forEach.call($('simhost').querySelectorAll('[data-q]'), function (x) {
        x.className = (+x.getAttribute('data-q') === s.quiz) ? 'on' : '';
      });
      var ok = s.quiz === d.quiz.answer;
      var el = $('quizans');
      el.className = 'ans ' + (ok ? 'ok' : 'ng');
      el.innerHTML = (ok ? '正解！ ' : 'ざんねん… 正解は「' + d.quiz.choices[d.quiz.answer] + '」。 ') + d.quiz.explain +
        '<br>「スタート」で確かめよう。';
      setPlayLabel();
      syncSimQuiz();
    });
  });
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-gq]'), function (b) {
    b.addEventListener('click', function () { pickGraphQuiz(+b.getAttribute('data-gq')); });
  });
  if (d.freeGraph) {
    $('selFx').addEventListener('change', function (e) { s.fx = e.target.value; delete s.gview._free; renderActive(); });
    $('selFy').addEventListener('change', function (e) { s.fy = e.target.value; delete s.gview._free; renderActive(); });
  }
  graphsOf(d, s).forEach(function (g) { attachGraphDrag($('gc_' + g.key), g.key); });
  if (d.freeGraph) attachGraphDrag($('gc__free'), '_free');
  if (d.drag) attachSimDrag(d, s);
  if (d.drag3d) attach3dDrag(d, s);

  setPlayLabel();
  $('bSlow').className = s.slow ? '' : 'sub';
  $('bSlow').textContent = s.slow ? 'スロー再生 中' : 'スロー再生';
  syncVarVals();
  syncQuiz();
  renderMath($('simhost'));
}

/* 「よく変える変数」＝再生ボタンの右に置くもの */
function mainVarKeys(d) {
  if (d.mainVars === '*') return d.vars.map(function (x) { return x.k; });
  if (d.mainVars) return d.mainVars;
  return d.vars.slice(0, 2).map(function (x) { return x.k; });
}

/* いちばん先に試してほしい変数（d.mainVarFocus）を目立たせるか。
   まだ既定値のままのあいだだけ光らせ、動かしたら静かになる。 */
function focusOn(d, s, vd) {
  return !!(d.mainVarFocus && d.mainVarFocus === vd.k && Math.abs(s.v[vd.k] - vd.def) < 1e-9);
}

function varRowHtml(vd, tag, focus, focusable) {
  /* 図の上のカードでは（かっこ書き）を落として短く見せる */
  var lab = (tag === 'a') ? vd.label.replace(/（[^）]*）/g, '') : vd.label;
  if (focusable) lab += ' <span class="tryme"' + (focus ? '' : ' style="display:none"') + '>変えてみよう</span>';
  var h = '<div class="vrow' + (focus ? ' focus' : '') + '" data-vrow="' + vd.k + '">' +
    '<span class="vlab">' + mathHtml(lab) + '</span>' +
    '<button class="stp" data-var="' + vd.k + '" data-dir="-1">−</button>' +
    '<span class="vval" data-vval="' + vd.k + '"></span>' +
    '<button class="stp" data-var="' + vd.k + '" data-dir="1">＋</button>';
  if (tag === 'a') {                     /* メイン値はスライドでも変えられる */
    h += '<input type="range" class="vsl" data-vsl="' + vd.k + '" ' +
      'min="' + vd.min + '" max="' + vd.max + '" step="' + vd.step + '">';
  }
  return h + '</div>';
}

/* ゲーム3種（1-6 カーリング／2-4 かご／3-3 モンキー）は問題モードでも「問題なし」 */
function quizOn(id) { return st.qmode && !DEFS[id || st.cur].game; }

/* 問題モードの入り切り（ゲーム以外のすべてのシミュレーションに効く） */
function setQmode(on) {
  hideQNotice();                       /* 自分で切りかえたら、お知らせは役目を終える */
  st.qmode = !!on;
  Object.keys(st.sims).forEach(function (id) {
    var x = st.sims[id];
    x.qphase = quizOn(id) ? 0 : 3;
    x.qpick = null;
    x.t = 0; x.playing = false; x.gview = {};
  });
  buildTabs();
  buildPanel();
  renderActive();
  syncHash();
  updateUrlBar();
  placeQNotice();                      /* タブ列を作り直すとボタンの位置が変わる */
}

/* 図の中の「ここを操作してね」のまばたきの強さ（0〜1）。
   シムを選んでから 2.6 秒だけピカピカして、そのあとは光ったまま落ち着く。 */
function flashK() {
  if (!st._hintT0) return 1;
  var now = (window.performance && performance.now) ? performance.now() : Date.now();
  var e = now - st._hintT0;
  if (e > 2600) return 1;
  return Math.abs(Math.sin(e / 250));
}

/* ===== 「…!q」で開いたときの大きなお知らせ =====
   リンクから問題モードで入ってきた生徒に、「いまは問題モードだよ／戻すならこのボタン」を
   矢印つきで大きく知らせる。自分でスイッチを押した人には出さない。 */
function placeQNotice() {
  var el = $('qnotice');
  if (!el || el.hidden) return;
  var sw = $('qswitch'), card = $('qncard'), hole = $('qnhole'), arw = $('qnarrow');
  if (!sw || !card) return;
  var r = sw.getBoundingClientRect(), pad = 8, VH = window.innerHeight;
  hole.style.left = Math.round(r.left - pad) + 'px';
  hole.style.top = Math.round(r.top - pad) + 'px';
  hole.style.width = Math.round(r.width + pad * 2) + 'px';
  hole.style.height = Math.round(r.height + pad * 2) + 'px';
  /* ふきだしを先に横だけ決めて、高さをはかる */
  card.style.right = Math.round(Math.max(10, window.innerWidth - r.right)) + 'px';
  card.style.left = 'auto';
  card.style.top = '0px';
  var ch = card.getBoundingClientRect().height;
  if (card.getBoundingClientRect().left < 8) { card.style.right = 'auto'; card.style.left = '8px'; }
  /* 画面からはみ出さない範囲で、ボタンの下に置く（矢印のぶんだけあける） */
  var wantTop = r.bottom + 112;
  var top = Math.max(8, Math.min(wantTop, VH - ch - 10));
  card.style.top = Math.round(top) + 'px';
  /* 矢印は「ボタンの左下 → ボタン」。すきまが足りないときは小さくし、
     どうしても入らないときは出さない（ふきだしだけにする） */
  var room = top - r.bottom - 10;
  var k = clamp(room / 106, 0.42, 1);
  if (room < 26) { arw.style.display = 'none'; return; }
  arw.style.display = '';
  arw.style.width = Math.round(140 * k) + 'px';
  arw.style.height = Math.round(110 * k) + 'px';
  arw.style.left = Math.round(Math.max(4, r.right - 24 - 124 * k)) + 'px';
  arw.style.top = Math.round(r.bottom + 8 - 10 * k) + 'px';
}
function showQNotice() {
  var el = $('qnotice');
  if (!el) return;
  el.hidden = false;
  /* せまい画面ではボタンがずっと下にあるので、まずボタンが上のほうに来るまでスクロールする
     （そうしないと、ふきだしがボタンを隠してしまう） */
  var sw0 = $('qswitch'), card0 = $('qncard');
  if (sw0 && card0) {
    card0.style.top = '0px';
    var ch0 = card0.getBoundingClientRect().height;
    var r0 = sw0.getBoundingClientRect();
    if (r0.bottom + 130 + ch0 > window.innerHeight) {
      var want = Math.max(8, window.innerHeight * 0.08);
      if (r0.top > want) window.scrollBy(0, r0.top - want);
    }
  }
  placeQNotice();
  var ok = $('qnok');
  if (ok && !ok._wired) {
    ok._wired = true;
    ok.addEventListener('click', function (e) { e.stopPropagation(); hideQNotice(); });
  }
  if (!el._wired) {
    el._wired = true;
    /* カード以外のどこを押しても消す（ボタンを押した場合はそのまま切りかわる） */
    document.addEventListener('click', function () { hideQNotice(); }, true);
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') hideQNotice(); });
    window.addEventListener('resize', placeQNotice);
    window.addEventListener('scroll', placeQNotice, { passive: true });
  }
}
function hideQNotice() {
  var el = $('qnotice');
  if (el && !el.hidden) el.hidden = true;
}

/* 入試物理の「くわしい解説」（ページの下・矢印の凡例の上） */
function renderLong(d) {
  var box = $('longbox');
  if (!box) return;
  if (!d.long) { box.style.display = 'none'; box.innerHTML = ''; return; }
  box.style.display = '';
  box.innerHTML = mathHtml(d.long);
  renderMath(box);
  refitFormulas();
}

/* ===== 再生ボタン（問題モードの流れもここで処理） ===== */
function onPlay() {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  if (d.quiz && s.quiz === null) { $('quizans').textContent = 'まずクイズに答えよう！'; return; }
  if (quizOn() && s.qphase === 2) { s.qphase = 3; s.t = 0; syncQuiz(); }
  var T = d.tEnd(V(s));
  if (s.t >= T - 1e-9) s.t = 0;
  s.playing = !s.playing;
  if (s.playing && s.t < 1e-9 && d.startSfx) sfx(d.startSfx);
  setPlayLabel();
  renderActive();
}

/* 問題モードの表示を state に合わせる */
function syncQuiz() {
  var s = st.sims[st.cur];
  var gq = $('gquiz'), hint = $('qhint'), play = $('bPlay');
  if (!gq) { setPlayLabel(); return; }
  gq.className = 'gquiz';
  setPlayLabel();
  if (!quizOn()) {
    gq.style.display = 'none'; hint.style.display = 'none';
    return;
  }
  if (s.qphase === 0) {
    gq.style.display = 'none';
    hint.style.display = '';
    hint.innerHTML = '<span class="nextmark">① まず「スタート」</span>：運動のようすだけを見てみよう（グラフはまだ出ません）。';
  } else if (s.qphase === 1) {
    gq.style.display = ''; $('gqmsg').textContent = ''; $('gqmsg').className = 'gqmsg';
    hint.style.display = '';
    hint.innerHTML = '<span class="nextmark">② 下の3つから選ぼう</span>：運動は「スタート」で何度でも見られます。';
    gq.className = 'gquiz pulse';
  } else if (s.qphase === 2) {
    gq.style.display = '';
    hint.style.display = '';
    hint.innerHTML = '<span class="nextmark">③ もう一度「スタート」</span>：運動といっしょに、本当のグラフが出ます。';
  } else {
    gq.style.display = s.qpick === null ? 'none' : '';
    hint.style.display = 'none';
  }
}

/* 問題文に「正の向き」を書き添える（向きを変えたらすぐ直る） */
/* いまの状態がすでに条件を満たしているボタンを、少し濃く見せる */
function refreshActs() {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  if (!d.actions) return;
  d.actions.forEach(function (a, i) {
    var b = $('act_' + i);
    if (!b) return;
    var on = a.is ? !!a.is(V(s), s) : false;
    /* next(s,t) を書いておくと、「次はこれを押す」ときにオレンジで点滅する */
    var nx = (!on && a.next) ? !!a.next(s, s.t, V(s)) : false;
    b.className = 'warm' + (on ? ' on' : '') + (nx ? ' pulse' : '');
  });
}

function renderQuizSign() {
  var el = $('qsign');
  if (!el) return;
  var d = DEFS[st.cur], s = st.sims[st.cur], g = quizGraph(d);
  var txt = (g && g.signed) ? ('ただし' + d.signLabels[s.sign > 0 ? 0 : 1] + 'とする。') : '';
  if (el.textContent !== txt) el.textContent = txt;
}

/* 3択の答え合わせ */
function pickGraphQuiz(i) {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  if (!quizOn() || s.qphase < 1) return;
  s.qpick = i;
  s.qphase = 2;
  sfx('pico');
  var correct = quizCorrectIndex(d);
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-gq]'), function (x) {
    x.className = 'gqopt' + (+x.getAttribute('data-gq') === i ? ' on' : '');
  });
  var msg = $('gqmsg');
  if (i === correct) {
    msg.className = 'gqmsg ok';
    msg.textContent = '正解！　「スタート」を押して、グラフが本当にこの形になるか確かめよう。';
  } else {
    msg.className = 'gqmsg ng';
    msg.textContent = 'ざんねん。正解は「' + QLETTER[correct] + '」。「スタート」を押して確かめよう。';
  }
  syncQuiz();
  renderActive();
}

/* 3択の正解の位置（シムごとに固定＝毎回同じ） */
function quizCorrectIndex(d) {
  var s = 0;
  for (var i = 0; i < d.id.length; i++) s += d.id.charCodeAt(i);
  return s % 3;
}

/* 問題に使うグラフ（def の quizKey で指定。なければ v–t を優先） */
function quizGraph(d) {
  var s = st.sims[d.id], list = graphsOf(d, s);
  var key = (typeof d.quizKey === 'function') ? d.quizKey(V(s)) : d.quizKey;
  var g = null;
  if (key) list.forEach(function (x) { if (x.key === key) g = x; });
  if (!g) list.forEach(function (x) { if (!g && (x.key === 'v' || x.key === 'vy')) g = x; });
  if (!g) g = list[0];
  return g;
}

/* 問題の言い方（どの物体の・どの向きのグラフかをはっきりさせる） */
function quizName(d) {
  if (typeof d.quizName === 'function') return d.quizName(V(st.sims[d.id]));
  if (d.quizName) return d.quizName;
  var g = quizGraph(d);
  return (g && g.short) ? g.short : '$v$–$t$ 図';
}

/* 3択のグラフの点列をつくる（本物・一定・傾きが逆。本物が横一直線のときは別の2つを出す）。
   ★2物体のシムのように線が2本あるグラフでは、2本とも作る★
   （1-12 は「板 A と物体 B の v–t 図」を聞いているので、A だけ描いてはいけない） */
function quizOptionPts(d, s, T, which) {
  var g = quizGraph(d), N = 60, out = [];
  (g.series || []).forEach(function (se) {
    var vals = [], i;
    for (i = 0; i <= N; i++) vals.push(se.f(d.sample(V(s), T * i / N)) * (g.signed ? s.sign : 1));
    var v0 = vals[0], amp = 0, sum = 0;
    for (i = 0; i <= N; i++) { amp = Math.max(amp, Math.abs(vals[i] - v0)); sum += vals[i]; }
    var flat = amp < 1e-6;                       /* 本物が横一直線か */
    var mean = sum / (N + 1);
    var base = Math.abs(v0) > 1e-6 ? v0 : (Math.abs(mean) > 1e-6 ? mean : 1);
    var lvl = Math.abs(mean) > 1e-6 ? mean : base;   /* 「ずっと一定」の高さ（0 の線にしない） */
    var pts = [];
    for (i = 0; i <= N; i++) {
      var t = T * i / N, f = i / N;
      if (which === 'true') pts.push([t, vals[i]]);
      else if (which === 'const') pts.push([t, flat ? base * (0.2 + 1.6 * f) : lvl]);
      else pts.push([t, flat ? base * (1.8 - 1.6 * f) : 2 * v0 - vals[i]]);
    }
    out.push({ color: se.color || COL.vel, name: se.name || '', pts: pts });
  });
  return out;
}

/* ===== 「まだ閉じているグラフ」をまとめて開くボタン ===== */
function openAllLabel() {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  var closed = [];
  graphsOf(d, s).forEach(function (g) { if (!s.open[g.key]) closed.push(g.short || g.title); });
  if (d.freeGraph && !s.open._free) closed.push('自由軸グラフ');
  if (!closed.length) return '最初の表示にもどす（v–t 図だけにする）';
  return mathHtml(closed.join('・') + ' をまとめて開く');
}

function bigFmlLabel() { return st.bigFml ? '式をもとの大きさに' : '式を拡大'; }

/* 「公式・代入・数値」の3段を大きく見せる（式が細かくて読みにくいときに） */
function toggleBigFml() {
  st.bigFml = !st.bigFml;
  Array.prototype.forEach.call(document.querySelectorAll('#simhost .gbody'), function (b) {
    b.className = b.className.replace(' bigf', '') + (st.bigFml ? ' bigf' : '');
  });
  var bt = $('bBigFml');
  if (bt) { bt.textContent = bigFmlLabel(); bt.className = st.bigFml ? '' : 'sub'; }
  refitFormulas();
}

function toggleAllGraphs() {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  var closed = graphsOf(d, s).some(function (g) { return !s.open[g.key]; }) || (d.freeGraph && !s.open._free);
  /* 観測者を切りかえても「まとめて開いた」状態が続くよう、見えていないグラフも一緒に開閉する */
  (d.graphs || []).forEach(function (g) { s.open[g.key] = closed ? true : !!g.open; });
  if (d.freeGraph) s.open._free = true;
  graphsOf(d, s).forEach(function (g) {
    var body = $('gb_' + g.key), head = $('simhost').querySelector('.ghead[data-g="' + g.key + '"]');
    if (body) body.className = 'gbody' + (s.open[g.key] ? '' : ' hide') + (st.bigFml ? ' bigf' : '');
    if (head) head.querySelector('.tri').textContent = s.open[g.key] ? '▼' : '▶';
  });
  $('bOpenAll').innerHTML = openAllLabel();
  renderMath($('bOpenAll'));
  renderActive();
}

/* ===== グラフのドラッグ（移動・軸の拡大縮小） ===== */
function attachGraphDrag(cv, key) {
  if (!cv) return;
  var drag = null;
  function local(e) {
    var mp = cv._map, r = cv.getBoundingClientRect();
    return { x: (e.clientX - r.left) / r.width * mp.W, y: (e.clientY - r.top) / r.height * mp.H };
  }
  function cur() {
    var s = st.sims[st.cur];
    if (s.gview[key]) return s.gview[key];
    var mp = cv._map;
    return { xmin: mp.xmin, xmax: mp.xmax, ymin: mp.ymin, ymax: mp.ymax };
  }
  cv.addEventListener('pointerdown', function (e) {
    if (!cv._map) return;
    var p = local(e), mp = cv._map;
    var mode = 'pan';
    if (p.x < mp.pad.l) mode = 'sy';
    else if (p.y > mp.pad.t + mp.gh) mode = 'sx';
    drag = { p: p, view: cur(), mode: mode };
    cv.setPointerCapture(e.pointerId);
    e.preventDefault();
  });
  cv.addEventListener('pointermove', function (e) {
    if (!drag || !cv._map) return;
    var s = st.sims[st.cur], mp = cv._map, p = local(e);
    var dx = p.x - drag.p.x, dy = p.y - drag.p.y, v0 = drag.view, nv;
    if (drag.mode === 'pan') {
      var kx = (v0.xmax - v0.xmin) / mp.gw, ky = (v0.ymax - v0.ymin) / mp.gh;
      nv = { xmin: v0.xmin - dx * kx, xmax: v0.xmax - dx * kx, ymin: v0.ymin + dy * ky, ymax: v0.ymax + dy * ky };
    } else if (drag.mode === 'sx') {
      var f = Math.exp(-dx / 110), c = (v0.xmin + v0.xmax) / 2, hh = (v0.xmax - v0.xmin) / 2 * f;
      nv = { xmin: c - hh, xmax: c + hh, ymin: v0.ymin, ymax: v0.ymax };
    } else {
      var f2 = Math.exp(dy / 110), c2 = (v0.ymin + v0.ymax) / 2, h2 = (v0.ymax - v0.ymin) / 2 * f2;
      nv = { xmin: v0.xmin, xmax: v0.xmax, ymin: c2 - h2, ymax: c2 + h2 };
    }
    s.gview[key] = nv;
    renderActive();
    e.preventDefault();
  });
  function end() { drag = null; }
  cv.addEventListener('pointerup', end);
  cv.addEventListener('pointercancel', end);
  cv.addEventListener('wheel', function (e) {
    if (!cv._map) return;
    var s = st.sims[st.cur], mp = cv._map, p = local(e), v0 = cur();
    var f = Math.exp(e.deltaY * 0.0014);
    var px = v0.xmin + (p.x - mp.pad.l) / mp.gw * (v0.xmax - v0.xmin);
    var py = v0.ymax - (p.y - mp.pad.t) / mp.gh * (v0.ymax - v0.ymin);
    s.gview[key] = {
      xmin: px - (px - v0.xmin) * f, xmax: px + (v0.xmax - px) * f,
      ymin: py - (py - v0.ymin) * f, ymax: py + (v0.ymax - py) * f
    };
    renderActive();
    e.preventDefault();
  }, { passive: false });
  cv.addEventListener('dblclick', function () {
    delete st.sims[st.cur].gview[key];
    renderActive();
  });
}

/* ===== 本体キャンバスのドラッグ（かご・銃） ===== */
function attachSimDrag(d, s) {
  var cv = $('mainCv'), dragging = false;
  function endDrag() {
    if (!dragging) return;
    dragging = false;
    if (d.dragUp && d.dragUp(s)) {           /* はなしたら動き出すシム（1-6 など） */
      s.t = 0; s.playing = true;
      if (d.startSfx) sfx(d.startSfx);
      setPlayLabel();
    }
    renderActive();
  }
  function toWorld(ev) {
    var r = cv.getBoundingClientRect();
    var lx = (ev.clientX - r.left) / r.width * d.cw;
    var pd = cv._pad || 0;
    var ly = (ev.clientY - r.top) / r.height * ((cv._ch || d.ch) + pd) - pd;
    if (!s.view) return null;
    return { x: s.view.invX(lx), y: s.view.invY(ly), lx: lx, ly: ly };
  }
  cv.addEventListener('pointerdown', function (ev) {
    var w = toWorld(ev); if (!w) return;
    if (d.dragDown && !d.dragDown(s, w.x, w.y, w.lx, w.ly)) return;
    dragging = true; cv.setPointerCapture(ev.pointerId);
    d.drag(s, w.x, w.y, w.lx, w.ly); resetSim(); syncVarVals(); renderActive(); ev.preventDefault();
  });
  cv.addEventListener('pointermove', function (ev) {
    if (!dragging) return;
    var w = toWorld(ev); if (!w) return;
    d.drag(s, w.x, w.y, w.lx, w.ly); resetSim(); syncVarVals(); renderActive(); ev.preventDefault();
  });
  cv.addEventListener('pointerup', endDrag);
  cv.addEventListener('pointercancel', endDrag);
}

/* ===== 3次元の視点操作 ===== */
function attach3dDrag(d, s) {
  var cv = $('mainCv'), last = null;
  cv.addEventListener('pointerdown', function (ev) {
    last = { x: ev.clientX, y: ev.clientY };
    cv.setPointerCapture(ev.pointerId); ev.preventDefault();
  });
  cv.addEventListener('pointermove', function (ev) {
    if (!last) return;
    var dx = ev.clientX - last.x, dy = ev.clientY - last.y;
    last = { x: ev.clientX, y: ev.clientY };
    s.cam.az = (s.cam.az - dx * 0.32 + 540) % 360 - 180;
    s.cam.el = clamp(s.cam.el - dy * 0.26, 0, 88);
    renderActive(); ev.preventDefault();
  });
  function end() { last = null; }
  cv.addEventListener('pointerup', end);
  cv.addEventListener('pointercancel', end);
  cv.addEventListener('wheel', function (ev) {
    s.cam.zoom = clamp(s.cam.zoom * Math.exp(-ev.deltaY * 0.0012), 0.5, 3.0);
    renderActive(); ev.preventDefault();
  }, { passive: false });
}

/* 「グラフで正とする向き」を切りかえたとき。
   どちらが＋になったのかが空間のイメージと結びつくよう、図の上に一瞬だけ知らせを出す。 */
function setSign(s, sg) {
  var d = DEFS[st.cur];
  if (s.sign === sg) return;
  s.sign = sg; s.gview = {};
  refreshSignBtns(); renderActive();
  var stage = document.querySelector('#simhost .cvstage');
  if (!stage) return;
  var old = stage.querySelector('.signflash');
  if (old) old.parentNode.removeChild(old);
  var el = document.createElement('div');
  el.className = 'signflash';
  el.textContent = posWord(d, s) + ' が ＋ になりました';
  stage.appendChild(el);
  setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 1900);
}

function refreshSignBtns() {
  var s = st.sims[st.cur];
  $('sgnP').className = s.sign > 0 ? '' : 'sub';
  $('sgnM').className = s.sign < 0 ? '' : 'sub';
}

function setPlayLabel() {
  var s = st.sims[st.cur], d = DEFS[st.cur], b = $('bPlay');
  if (!b) return;
  b.disabled = false;
  if (s.playing) { b.textContent = '❚❚ 一時停止'; b.className = ''; return; }
  if (d.dragStart && s.t < 1e-9) {          /* ドラッグでスタートするゲーム */
    b.textContent = '▶ ドラッグでスタート';
    b.className = ''; b.disabled = true;
    return;
  }
  b.textContent = (quizOn() && s.qphase === 2) ? '▶ スタートしてグラフを見る' : '▶ スタート';
  /* 問題モードでは「次に押すところ」を光らせる */
  b.className = (quizOn() && (s.qphase === 0 || s.qphase === 2)) ? 'pulse' : '';
  /* このシムだけのクイズ（3-2）でも、同じように次に押すところへ誘導する */
  if (d.quiz && !quizOn()) {
    b.className = (s.quiz !== null && s.t < 1e-9) ? 'pulse' : '';
  }
}

/* シムごとのクイズ（3-2）の誘導：まだ答えていなければ3択を光らせる */
function syncSimQuiz() {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  var box = document.querySelector('#simhost .quiz');
  if (!box || !d.quiz) return;
  var need = (s.quiz === null);
  box.className = 'quiz' + (need ? ' pulse' : '');
  Array.prototype.forEach.call(box.querySelectorAll('[data-q]'), function (x) {
    var on = (+x.getAttribute('data-q') === s.quiz);
    x.className = on ? 'on' : (need ? 'pulse' : '');
  });
}

function resetSim() {
  var s = st.sims[st.cur];
  s.t = 0; s.playing = false; s.gview = {}; s._sfx = null;
  if (quizOn()) { s.qphase = 0; s.qpick = null; syncQuiz(); } else { s.qphase = 3; s.qpick = null; syncQuiz(); }
  setPlayLabel();
}

/* スライダーなどから値を直接セットする */
function setVar(k, val) {
  var d = DEFS[st.cur], s = st.sims[st.cur], vd = null;
  d.vars.forEach(function (x) { if (x.k === k) vd = x; });
  if (!vd) return;
  var nv = clamp(Math.round(val / vd.step) * vd.step, vd.min, vd.max);
  if (Math.abs(nv - s.v[k]) < 1e-9) return;
  s.v[k] = +nv.toFixed(6);
  resetSim(); syncVarVals(); renderActive();
}

function stepVar(k, dir) {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  var vd = null;
  d.vars.forEach(function (x) { if (x.k === k) vd = x; });
  if (!vd) return;
  var nv = s.v[k] + dir * vd.step;
  nv = clamp(Math.round(nv / vd.step) * vd.step, vd.min, vd.max);
  s.v[k] = +nv.toFixed(6);
  resetSim(); syncVarVals(); renderActive();
}

function syncVarVals() {
  var d = DEFS[st.cur], s = st.sims[st.cur], host = $('simhost');
  if (!host) return;
  d.vars.forEach(function (vd) {
    var txt = fmt(s.v[vd.k], vd.dec) + vd.unit;
    Array.prototype.forEach.call(host.querySelectorAll('[data-vval="' + vd.k + '"]'), function (el) {
      el.textContent = txt;
    });
    Array.prototype.forEach.call(host.querySelectorAll('[data-vsl="' + vd.k + '"]'), function (r) {
      if (+r.value !== s.v[vd.k]) r.value = s.v[vd.k];
    });
    /* 「変えてみよう」の強調は、その変数を動かしたら消す（もどせばまた出る） */
    if (d.mainVarFocus === vd.k) {
      var on = focusOn(d, s, vd);
      Array.prototype.forEach.call(host.querySelectorAll('[data-vrow="' + vd.k + '"]'), function (row) {
        row.className = 'vrow' + (on ? ' focus' : '');
        var tip = row.querySelector('.tryme');
        if (tip) tip.style.display = on ? '' : 'none';
      });
    }
  });
}

/* ===== 描画 ===== */
function seriesPts(d, s, g, T) {
  var N = 160, out = [], i, v = V(s);
  g.series.forEach(function () { out.push([]); });
  for (i = 0; i <= N; i++) {
    var t = T * i / N;
    var m = d.sample(v, t);
    g.series.forEach(function (se, j) {
      out[j].push([t, se.f(m, v, t) * (g.signed ? s.sign : 1)]);
    });
  }
  return out;
}

/* 横軸の右端。目盛りの間隔のちょうど整数倍まで伸ばして、
   「運動が終わる時刻」に必ず目盛りが届くようにする（届かないと t が読めない）。 */
function niceXMax(T) {
  var Tx = Math.max(0.2, T);
  var st2 = niceStep(Tx, 6);
  var xm = Math.ceil(Tx / st2 - 1e-9) * st2;
  return (xm < Tx * (1 + 1e-9)) ? xm + st2 : xm;
}

function graphsHidden(s) { return quizOn() && s.qphase < 3; }

function renderGraphs(d, s, T, t) {
  var m = d.sample(V(s), t);
  var hide = graphsHidden(s);
  graphsOf(d, s).forEach(function (g) {
    if (!s.open[g.key]) return;
    var cv = $('gc_' + g.key);
    if (!cv) return;
    var pts = seriesPts(d, s, g, T);
    var lo = Infinity, hi = -Infinity;
    pts.forEach(function (p) { p.forEach(function (q) { if (isFinite(q[1])) { lo = Math.min(lo, q[1]); hi = Math.max(hi, q[1]); } }); });
    if (!isFinite(lo)) { lo = -1; hi = 1; }
    var r = niceRange(lo, hi);
    plot(cv, {
      xlabel: 't [s]', ylabel: g.ylabel,
      note: g.signed ? DEFS[st.cur].signLabels[s.sign > 0 ? 0 : 1] : '',
      xmin: 0, xmax: niceXMax(T), xstep: niceStep(Math.max(0.2, T), 6), ymin: r.lo, ymax: r.hi,
      view: s.gview[g.key], hide: hide,
      series: g.series.map(function (se, j) { return { color: se.color, dash: se.dash, width: se.width, area: se.area, pts: pts[j] }; }),
      band: g.band ? { i: g.band.i, j: g.band.j, color: g.band.color } : null,
      cursors: g.series.map(function (se) { return { color: se.color, x: t, y: se.f(m) * (g.signed ? s.sign : 1) }; }),
      legend: g.legend ? g.series.map(function (se) { return { name: se.name, color: se.color }; }) : null
    });
  });
  if (d.freeGraph && s.open._free) {
    var cv2 = $('gc__free');
    if (cv2) {
      var N = 160, pts2 = [], i, xlo = Infinity, xhi = -Infinity, ylo = Infinity, yhi = -Infinity;
      for (i = 0; i <= N; i++) {
        var tt = T * i / N, mm = d.sample(V(s), tt);
        var X = quant(mm, tt, s.fx), Y = quant(mm, tt, s.fy);
        if (s.fy !== 't' && s.fy !== 'x' && s.fy !== 'vx') Y = Y * s.sign;
        if (s.fx !== 't' && s.fx !== 'x' && s.fx !== 'vx') X = X * s.sign;
        pts2.push([X, Y]);
        xlo = Math.min(xlo, X); xhi = Math.max(xhi, X); ylo = Math.min(ylo, Y); yhi = Math.max(yhi, Y);
      }
      var mc = d.sample(V(s), t);
      var cx = quant(mc, t, s.fx), cy = quant(mc, t, s.fy);
      if (s.fy !== 't' && s.fy !== 'x' && s.fy !== 'vx') cy = cy * s.sign;
      if (s.fx !== 't' && s.fx !== 'x' && s.fx !== 'vx') cx = cx * s.sign;
      var rx = niceRange(xlo, xhi), ry = niceRange(ylo, yhi);
      var lx = '', ly = '';
      FREE_AXES.forEach(function (a) { if (a.k === s.fx) lx = a.label; if (a.k === s.fy) ly = a.label; });
      plot(cv2, {
        xlabel: lx, ylabel: ly, xmin: rx.lo, xmax: rx.hi, ymin: ry.lo, ymax: ry.hi,
        view: s.gview._free, hide: hide,
        series: [{ color: COL.acc, pts: pts2 }], cursors: [{ color: COL.acc, x: cx, y: cy }]
      });
    }
  }
  /* 3択の小さいグラフ */
  if (quizOn() && s.qphase >= 1 && s.qphase <= 3 && $('gq_0')) {
    var correct = quizCorrectIndex(d);
    var sets = [], qlo = Infinity, qhi = -Infinity, qi;
    for (qi = 0; qi < 3; qi++) {
      var kind = qi === correct ? 'true' : (((qi - correct + 3) % 3) === 1 ? 'const' : 'rev');
      var qp = quizOptionPts(d, s, T, kind);
      qp.forEach(function (se) {
        se.pts.forEach(function (p) { qlo = Math.min(qlo, p[1]); qhi = Math.max(qhi, p[1]); });
      });
      sets.push(qp);
    }
    var qr = niceRange(qlo, qhi);      /* 3つとも同じ目盛りにして見くらべやすくする */
    for (qi = 0; qi < 3; qi++) plotMini($('gq_' + qi), sets[qi], T, qr.lo, qr.hi);
  }
}

/* 3択用の小さなグラフ（series＝[{color, name, pts}]。2物体なら2本描く） */
function plotMini(cv, series, T, lo, hi) {
  if (!cv) return;
  var W = 150, H = 100, ctx = prep(cv, W, H);
  var pad = { l: 16, r: 8, t: 8, b: 14 };
  var gw = W - pad.l - pad.r, gh = H - pad.t - pad.b;
  function X(x) { return pad.l + gw * x / Math.max(1e-6, T); }
  function Y(y) { return pad.t + gh * (hi - y) / Math.max(1e-6, hi - lo); }
  ctx.save(); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H); ctx.restore();
  ctx.save(); ctx.strokeStyle = AX.col; ctx.lineWidth = 1.2;
  var yz = (lo <= 0 && hi >= 0) ? Y(0) : pad.t + gh;
  ctx.beginPath(); ctx.moveTo(pad.l, yz); ctx.lineTo(pad.l + gw, yz); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(pad.l, pad.t); ctx.lineTo(pad.l, pad.t + gh); ctx.stroke();
  ctx.restore();
  arrowHead(ctx, pad.l + gw + 7, yz, 1, 0, AX.col);
  arrowHead(ctx, pad.l, pad.t - 7, 0, -1, AX.col);
  label(ctx, 't', pad.l + gw + 2, yz + 9, { size: 9.5, color: AX.col });
  label(ctx, 'v', pad.l + 8, pad.t - 2, { size: 9.5, color: AX.col });
  series.forEach(function (se) {
    ctx.save();
    ctx.strokeStyle = se.color || COL.vel; ctx.lineWidth = 2.4;
    ctx.beginPath();
    se.pts.forEach(function (p, i) { if (i === 0) ctx.moveTo(X(p[0]), Y(p[1])); else ctx.lineTo(X(p[0]), Y(p[1])); });
    ctx.stroke(); ctx.restore();
  });
  /* 線が2本以上あるときは、どちらがどちらか分かるように名前を小さく出す */
  if (series.length > 1) {
    var ly = pad.t + 1;
    series.forEach(function (se) {
      if (!se.name) return;
      label(ctx, se.name, pad.l + gw - 2, ly, { size: 9, color: se.color, align: 'right' });
      ly += 11;
    });
  }
}

/* 各グラフの右に出す3段の式 */
function renderFormulas(d, s) {
  graphsOf(d, s).forEach(function (g) {
    if (!g.fml || !s.open[g.key]) return;
    var box = $('gf_' + g.key);
    if (!box) return;
    var arr = g.fml(V(s), s.sign);
    /* 式の3行の下に出す解説（あれば）。2-2 の vy–t 図の「面積」の話などに使う */
    var fn = g.fnote ? (typeof g.fnote === 'function' ? g.fnote(V(s), s) : g.fnote) : '';
    var key = arr.join('|') + '||' + fn;
    var bw = box.clientWidth;
    if (box._key === key && box._bw === bw) return;
    box._key = key; box._bw = bw;
    var names = ['公式', '代入', '数値'];
    box.innerHTML = arr.map(function (x, i) {
      return '<div class="fl f' + (i + 1) + '"><span class="fk">' + names[i] + '</span><span class="fv"><span class="tex">' + x + '</span></span></div>';
    }).join('') + (fn ? '<div class="fnote">' + mathHtml(fn) + '</div>' : '');
    renderMath(box);
    fitFormula(box);
    /* KaTeX のフォントが読み込まれたあとに幅が変わることがあるので、次のフレームでもう一度そろえる */
    requestAnimationFrame(function () { fitFormula(box); });
  });
}

/* 式がはみ出すときは、切らずに縮めて全部見せる（何度呼んでも同じ結果になる） */
function fitFormula(box) {
  Array.prototype.forEach.call(box.querySelectorAll('.fv'), function (fv) {
    var inner = fv.firstElementChild;
    if (!inner) return;
    var k = inner._k || 1;
    var w = inner.getBoundingClientRect().width / k;      /* 拡大縮小なしの幅 */
    var avail = fv.clientWidth;
    if (avail < 20 || w < 1) return;
    var nk = (w > avail) ? Math.max(0.5, (avail - 3) / w) : 1;
    if (Math.abs(nk - k) > 0.004) {
      inner._k = nk;
      inner.style.transform = nk < 1 ? 'scale(' + nk.toFixed(3) + ')' : '';
    }
  });
}

/* すべての式を組み直して幅をそろえ直す */
function refitFormulas() {
  Array.prototype.forEach.call(document.querySelectorAll('.gform'), function (b) { b._key = null; });
  renderActive();
}

function renderReadout(d, s, t) {
  var el = $('readout');
  if (!el) return;
  var rows = d.info(s, t), i;
  var keys = rows.map(function (r) { return r[0]; }).join('|');
  if (el._keys !== keys) {
    el.innerHTML = rows.map(function (r) {
      return '<tr><td class="k">' + mathHtml(r[0]) + '</td><td class="v"></td></tr>';
    }).join('');
    el._keys = keys;
    renderMath(el);
  }
  var tds = el.querySelectorAll('td.v');
  for (i = 0; i < rows.length; i++) if (tds[i]) tds[i].textContent = rows[i][1];
}

function renderEq(d, s) {
  var el = $('eqbox');
  if (!el) return;
  var src = d.eq(s);
  if (src === s._eq) return;
  s._eq = src;
  /* 「運動方程式をたてると」の見出し。運動方程式を書いている式だけに出す */
  var ttl = $('eqttl'), head = '';
  if (src.indexOf(EQM) === 0) { head = '運動方程式をたてると'; src = src.slice(EQM.length); }
  else if (src.indexOf(EQBAL) === 0) { head = '力のつり合いを考えると'; src = src.slice(EQBAL.length); }
  else if (d.eqHead) head = d.eqHead;
  if (ttl) {
    ttl.textContent = head;
    ttl.style.display = head ? '' : 'none';
  }
  el.textContent = '';
  if (window.katex) {
    try { window.katex.render(src, el, { throwOnError: false, displayMode: false }); }
    catch (e) { el.textContent = src; }
  } else el.textContent = src;
}

/* キャンバスの高さ（def の ch は関数でもよい：斜面の角度で高さを変えるため） */
function chOf(d, s) {
  return (typeof d.ch === 'function') ? Math.round(d.ch(V(s))) : d.ch;
}

/* 図の上に空ける帯の高さ（「よく変える値」のカードがのる場所） */
function cvTopPad(d, cv, ch) {
  var el = $('cvtop');
  if (!el) return 0;
  var wcss = cv.clientWidth || d.cw;
  var hpx = el.offsetHeight;
  if (!hpx) return 0;
  /* 画面が狭いときはカードが図の下に出るので、帯は空けない */
  if (window.getComputedStyle(el).position !== 'absolute') return 0;
  return Math.min(Math.round(ch * 0.45), Math.round((hpx + 16) * (d.cw / wcss)));
}

function renderActive() {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  var cv = $('mainCv');
  if (!cv) return;
  var T = d.tEnd(V(s));
  if (s.t > T) s.t = T;
  var ch = chOf(d, s);
  var pad = cvTopPad(d, cv, ch);
  cv._pad = pad; cv._ch = ch;
  var ctx = prep(cv, d.cw, ch + pad);
  ctx.save();
  ctx.translate(0, pad);
  ctx.beginPath(); ctx.rect(0, 0, d.cw, ch); ctx.clip();   /* 絵が値のカードの帯にはみ出さないように */
  d.draw(ctx, s, s.t, d.cw, ch);
  drawEqualTicks(ctx);                       /* 同じ大きさの力・速度に「｜」印 */
  if (d.win) {                               /* ゲームに成功したら1回だけ音を鳴らす */
    if (s.t < T - 1e-9) s._sfx = null;
    else if (d.win(s, s.t) && s._sfx !== 'win') { s._sfx = 'win'; sfx('win'); }
  }
  if (d.game) label(ctx, '画面をダブルクリックでリセット', d.cw - 10, ch - 9,
    { align: 'right', size: 10.5, color: COL.sub });
  ctx.restore();
  var Tg = d.tGraph ? d.tGraph(V(s)) : T;
  renderGraphs(d, s, Tg, Math.min(s.t, Tg));
  renderFormulas(d, s);
  renderQuizSign();
  refreshActs();
  syncSimQuiz();
  renderReadout(d, s, s.t);
  renderEq(d, s);
  var bar = $('tBar');
  if (bar) {
    var mx = T.toFixed(2);
    if (bar.max !== mx) bar.max = mx;
    bar.value = s.t.toFixed(2);
    $('tVal').textContent = fmt(s.t, 2) + ' s';
  }
  renderMath($('notebox'));
  fitStageHeight();
}

/* .tex の中身を KaTeX で組む（1度だけ） */
function renderMath(root) {
  if (!root || !window.katex) return;
  Array.prototype.forEach.call(root.querySelectorAll('.tex'), function (el) {
    if (el.getAttribute('data-done')) return;
    el.setAttribute('data-done', '1');
    var src = el.textContent;
    el.textContent = '';
    try { window.katex.render(src, el, { throwOnError: false }); }
    catch (e) { el.textContent = src; }
  });
}

/* ===== 画面の切りかえ ===== */
/* ハッシュの形： #m1-1  … ふつう
                  #m1-1!q … 問題モードで開く                                   */
function hashOf() { return st.cur + (st.qmode ? '!q' : ''); }
function parseHash(h) {
  h = (h || '').replace('#', '');
  var q = false, i = h.indexOf('!');
  if (i < 0) i = h.indexOf('?');
  if (i >= 0) { q = /^[!?]q/i.test(h.slice(i)); h = h.slice(0, i); }
  return { id: h, quiz: q };
}
function syncHash() {
  var want = '#' + hashOf();
  if (location.hash !== want) {
    st._skipHash = true;
    location.hash = want;
  }
}

function gotoSim(id) {
  if (!DEFS[id]) return;
  st.cur = id;
  buildTabs();
  buildPanel();
  renderActive();
  syncHash();
  updateUrlBar();
}

/* ===== アニメーション ===== */
var lastTs = null;
function tick(ts) {
  var s = st.sims[st.cur], d = DEFS[st.cur];
  if (lastTs === null) lastTs = ts;
  var dt = Math.min(0.033, (ts - lastTs) / 1000);
  lastTs = ts;
  /* 止まっていても、選んだ直後だけは「ここを操作してね」をまばたきさせる */
  if (s && !s.playing && d && d.hintFlash && st._hintT0) {
    var el2 = (window.performance && performance.now) ? performance.now() : Date.now();
    if (el2 - st._hintT0 < 2700 && (!st._hintLast || ts - st._hintLast > 55)) {
      st._hintLast = ts; renderActive();
    }
  }
  if (s && s.playing) {
    var T = d.tEnd(V(s));
    s.t = Math.min(T, s.t + dt * (s.slow ? 0.25 : 1));
    if (s.t >= T - 1e-9) {
      s.playing = false;
      if (quizOn() && s.qphase === 0) { s.qphase = 1; sfx('pico'); syncQuiz(); }
      setPlayLabel();
    }
    renderActive();
  }
  requestAnimationFrame(tick);
}
