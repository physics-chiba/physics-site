/* シミュレーションの登録表。各モードのファイルが DEFS に自分を足していく。 */
'use strict';
var DEFS = {};
var MODES = [
  { n: 1, label: '1　一次元の等加速度直線運動　※物理基礎', tip: '直線上の運動は単純に見えて、奥が深いです。<b>※物理基礎の内容はここまで</b>',
    ids: ['m1-1', 'm1-2', 'm1-3', 'm1-4', 'm1-5', 'm1-6', 'm1-7',
      'm1-8', 'm1-9', 'm1-10', 'm1-11', 'm1-12'] },
  { n: 2, label: '2　平面上の運動', tip: '基本的にベクトル的に考える。必要なら分解して成分を見る。',
    ids: ['m2-1', 'm2-2', 'm2-3', 'm2-4'] },
  { n: 3, label: '3　2物体の運動', tip: '2物体それぞれの運動を考えよう。ぶつかるのは座標が一致したときです。',
    ids: ['m3-1', 'm3-2', 'm3-3'] },
  { n: 4, label: '4　入試物理', tip: '基本的だからこそ、奥深い問題が出題されます。', ids: ['m4-1', 'm4-2', 'm4-3'] }
];

/* 「正の向き」の言い方（水平面か斜面かで変える） */
function dirWord(th, sign) {
  if (Math.abs(th) < 0.5) return sign > 0 ? '右向き（水平面）' : '左向き（水平面）';
  if (th > 0) return sign > 0 ? '斜面上向き（右）' : '斜面下向き（左）';
  return sign > 0 ? '斜面下向き（右）' : '斜面上向き（左）';
}

/* 式のあたまにつける「見出しの印」。左下の式のエリアでは、この印を消して
   かわりに「運動方程式をたてると」「力のつり合いを考えると」という見出しを
   式の上に出す（80_ui.js の renderEq）。グラフの中の式では印がそのまま出る。 */
var EQM = '\\text{運動方程式}\\;\\; ';
var EQBAL = '\\text{つり合い：}\\; ';

/* 図の中に出す「正の向き」の表示。全シミュレーションで言い方をそろえる。
   ・かならず「正の向き：○○」の形にする（「下向きが正」などと書かない）
   ・○○ は signLabels（グラフの「正とする向き」ボタン）から作るので、
     向きを切りかえると図の表示もいっしょに変わる */
function posWord(d, s, word) {
  var w = word || d.signLabels[s.sign > 0 ? 0 : 1];
  return String(w).replace(/を正$/, '').replace(/が正$/, '');
}
/* 図の右上（時刻の下）に「正の向き：○○」を出す。位置も全シムでそろえる。 */
function drawPosNote(ctx, d, s, W, y, word) {
  label(ctx, '正の向き：' + posWord(d, s, word), W - 10, y === undefined ? 36 : y,
    { align: 'right', size: 11, color: COL.sub });
}

/* 「$…$」を KaTeX で組む span に変える（添え字をきれいに出すため） */
function mathHtml(str) {
  var out = '', i = 0;
  while (i < str.length) {
    var a = str.indexOf('$', i);
    if (a === -1) { out += str.slice(i); break; }
    out += str.slice(i, a);
    var b = str.indexOf('$', a + 1);
    if (b === -1) { out += str.slice(a); break; }
    out += '<span class="tex">' + str.slice(a + 1, b) + '</span>';
    i = b + 1;
  }
  return out;
}

/* 図の中の「ヒントになる言葉」（答えにつながる説明）を出してよいか。
   ・ふつうのモード：スタートを押して動き出してから
   ・問題モード　　：3択に答えたあと、もう一度スタートを押してから（qphase 3）
   図のラベルのうち、運動の結論を書いているものは必ずこれで囲む。 */
function hintOn(s, t) {
  if (t <= 1e-9) return false;
  if (typeof quizOn === 'function' && quizOn()) return s.qphase >= 3;
  return true;
}

/* 質量 m に応じて物体の「見た目の大きさ」を変える倍率。
   ・標準の質量（vars の def、なければ consts）でちょうど 1.0 ＝ これまでの見た目。
   ・体積のイメージに合わせて m の 3 乗根で変える。
   ・矢印やラベルの読みとりのじゃまにならないよう 0.78〜1.45 におさえる
     （どのシムも最小質量→最大質量で、さしわたしが約 1.9 倍）。
   ・質量が変えられないシムでは 1.0 のまま。 */
function mSize(d, v) {
  if (!d || !v || typeof v.m !== 'number' || !(v.m > 0)) return 1;
  var vs = d.vars || [], md = null, i;
  for (i = 0; i < vs.length; i++) if (vs[i].k === 'm') md = vs[i];
  if (!md) return 1;                       /* 定数の質量＝変わらないので拡大しない */
  var ref = md.def;
  if (!(ref > 0)) return 1;
  return clamp(Math.pow(v.m / ref, 1 / 3), 0.78, 1.45);
}

/* v–t 図の「面積」の解説で使う。上りの区間が「正の面積」になるかは、
   いま選んでいる「グラフで正とする向き」で入れかわる。 */
function areaSignWord(sign, rising) { return ((sign > 0) === !!rising) ? '正' : '負'; }

/* 汎用の描画部品（複数モードで使う） */

/* 直方体のブロック（斜面の上など）。ang＝面の傾き(rad, 反時計まわりが正の見た目) */
function blockShape(ctx, cx, cy, ang, w, h, fill) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(-ang);
  ctx.fillStyle = fill || '#e8eef5';
  ctx.strokeStyle = '#2c3e50';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.rect(-w / 2, -h / 2, w, h);
  ctx.fill(); ctx.stroke();
  ctx.restore();
}

/* 地面（横一直線＋ハッチ） */
function ground(ctx, x1, x2, y) { hatchLine(ctx, x1, y, x2, y, 1); }

/* 気球（(x,y)＝ゴンドラの底＝小球を投げ出す位置）。r＝球皮の半径の目安 */
function balloonShape(ctx, x, y, r) {
  var cy = y - r * 2.25;
  ctx.save();
  /* ロープ */
  ctx.strokeStyle = '#8a7452'; ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.moveTo(x - r * 0.66, cy + r * 1.02); ctx.lineTo(x - r * 0.40, y - r * 0.60);
  ctx.moveTo(x + r * 0.66, cy + r * 1.02); ctx.lineTo(x + r * 0.40, y - r * 0.60);
  ctx.stroke();
  /* 球皮 */
  ctx.beginPath(); ctx.ellipse(x, cy, r, r * 1.18, 0, 0, Math.PI * 2);
  ctx.fillStyle = '#fbeccd'; ctx.fill();
  ctx.save(); ctx.clip();
  ctx.fillStyle = '#e2705f'; ctx.fillRect(x - r * 0.20, cy - r * 1.4, r * 0.40, r * 2.8);
  ctx.fillStyle = '#7fa9d8';
  ctx.fillRect(x - r * 0.80, cy - r * 1.4, r * 0.22, r * 2.8);
  ctx.fillRect(x + r * 0.58, cy - r * 1.4, r * 0.22, r * 2.8);
  ctx.restore();
  ctx.strokeStyle = '#a8763a'; ctx.lineWidth = 1.5; ctx.stroke();
  /* ゴンドラ */
  ctx.beginPath(); ctx.rect(x - r * 0.42, y - r * 0.60, r * 0.84, r * 0.60);
  ctx.fillStyle = '#cf9a58'; ctx.fill();
  ctx.strokeStyle = '#8a6431'; ctx.lineWidth = 1.4; ctx.stroke();
  ctx.restore();
}

/* 観測者の棒人間。(x,y)＝足もと、(ux,uy)＝画面での「上」の向き（単位ベクトル）。
   s＝背の高さの目安。円運動のシミュレーションと同じ描き方にそろえている。 */
function stickman(ctx, x, y, ux, uy, s, color, lw) {
  var px = -uy, py = ux;
  function P(du, dp) { return [x + ux * du * s + px * dp * s, y + uy * du * s + py * dp * s]; }
  ctx.save();
  ctx.strokeStyle = color || COL.sub; ctx.lineWidth = lw || 2; ctx.lineCap = 'round';
  var hip = P(0.38, 0), sh = P(0.64, 0), hd = P(0.80, 0);
  ctx.beginPath(); ctx.arc(hd[0], hd[1], s * 0.13, 0, Math.PI * 2); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(hip[0], hip[1]); ctx.lineTo(sh[0], sh[1]); ctx.stroke();
  var f1 = P(0, -0.17), f2 = P(0, 0.17);
  ctx.beginPath(); ctx.moveTo(f1[0], f1[1]); ctx.lineTo(hip[0], hip[1]); ctx.lineTo(f2[0], f2[1]); ctx.stroke();
  var a1 = P(0.48, -0.22), a2 = P(0.48, 0.22);
  ctx.beginPath(); ctx.moveTo(a1[0], a1[1]); ctx.lineTo(sh[0], sh[1]); ctx.lineTo(a2[0], a2[1]); ctx.stroke();
  ctx.restore();
}

/* 観測者（棒人間＋名前）。active なら青くて太い＋「（いまの視点）」 */
function observer(ctx, x, y, ux, uy, name, active, s, lab) {
  var sz = s || 30;
  var col = active ? COL.vel : '#9aa3ac';
  lab = lab || {};
  stickman(ctx, x, y, ux, uy, sz, col, active ? 2.4 : 1.7);
  var txt = name + (active ? '（いまの視点）' : '');
  var lx = x + ux * sz * 1.12 + (lab.dx || 0);
  var ly = y + uy * sz * 1.12 + (lab.dy || 0);
  if (uy > -0.2) ly = y + 14 + (lab.dy || 0);       /* 上向きでないときは下に書く */
  label(ctx, txt, clamp(lx, 4, CVW - 4), clamp(ly, 12, CVH - 4),
    { size: active ? 11 : 10.5, bold: !!active, color: col, align: lab.align || 'center' });
}

/* 滑車（軸つきの円）。(cx,cy)＝中心、r＝半径 */
function pulley(ctx, cx, cy, r) {
  ctx.save();
  ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fillStyle = '#e3e9ef'; ctx.fill();
  ctx.strokeStyle = '#2c3e50'; ctx.lineWidth = 2; ctx.stroke();
  ctx.beginPath(); ctx.arc(cx, cy, r * 0.62, 0, Math.PI * 2);
  ctx.strokeStyle = '#9aa4ae'; ctx.lineWidth = 1.2; ctx.stroke();
  ctx.beginPath(); ctx.arc(cx, cy, r * 0.16, 0, Math.PI * 2);
  ctx.fillStyle = '#5b6672'; ctx.fill();
  ctx.restore();
}

/* 板（1-12 の A）。(cx,yTop)＝上面の中心、w＝幅、h＝厚み */
function plank(ctx, cx, yTop, w, h) {
  ctx.save();
  ctx.beginPath(); ctx.rect(cx - w / 2, yTop, w, h);
  ctx.fillStyle = '#e9d9bd'; ctx.fill();
  ctx.strokeStyle = '#a5854f'; ctx.lineWidth = 2; ctx.stroke();
  ctx.restore();
}

/* 人（棒人間） */
function person(ctx, x, yFoot, h, flip) {
  ctx.save();
  ctx.translate(x, yFoot);
  if (flip) ctx.scale(-1, 1);
  ctx.strokeStyle = '#2c3e50'; ctx.fillStyle = '#2c3e50'; ctx.lineWidth = 2;
  var H = h;
  ctx.beginPath(); ctx.arc(0, -H + 7, 7, 0, Math.PI * 2); ctx.fillStyle = '#fdf2e2'; ctx.fill(); ctx.stroke();
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, -H + 14); ctx.lineTo(0, -H * 0.42);
  ctx.moveTo(0, -H * 0.42); ctx.lineTo(-7, 0);
  ctx.moveTo(0, -H * 0.42); ctx.lineTo(8, 0);
  ctx.stroke();
  /* 腕（頭にかからないよう下げて、ひじで曲げる） */
  ctx.beginPath();
  ctx.moveTo(0, -H + 26); ctx.lineTo(12, -H + 34); ctx.lineTo(16, -H + 24);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(0, -H + 26); ctx.lineTo(-11, -H + 34); ctx.lineTo(-15, -H + 44);
  ctx.stroke();
  ctx.lineCap = 'butt';
  ctx.restore();
}

/* ボールをける直前の人（右を向いて、右足をふりかぶっている） */
function kicker(ctx, x, yFoot, h, flip) {
  ctx.save();
  ctx.translate(x, yFoot);
  if (flip) ctx.scale(-1, 1);
  ctx.strokeStyle = '#2c3e50'; ctx.lineWidth = 2.2; ctx.lineCap = 'round';
  var H = h;
  /* 頭 */
  ctx.beginPath(); ctx.arc(2, -H + 7, 7, 0, Math.PI * 2);
  ctx.fillStyle = '#fdf2e2'; ctx.fill(); ctx.stroke();
  /* 体（少し前かがみ） */
  ctx.beginPath();
  ctx.moveTo(2, -H + 14); ctx.lineTo(-2, -H * 0.45);
  ctx.stroke();
  /* 腕（ひじで曲げる。まっすぐだと2本が1本の棒に見えてしまう） */
  ctx.beginPath();
  ctx.moveTo(0, -H * 0.72); ctx.lineTo(-11, -H * 0.63); ctx.lineTo(-16, -H * 0.74);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(0, -H * 0.72); ctx.lineTo(11, -H * 0.79); ctx.lineTo(17, -H * 0.69);
  ctx.stroke();
  /* 軸足（左） */
  ctx.beginPath();
  ctx.moveTo(-2, -H * 0.45); ctx.lineTo(-7, -H * 0.2); ctx.lineTo(-6, 0);
  ctx.stroke();
  /* けり足（右・後ろにふりかぶって前へ） */
  ctx.beginPath();
  ctx.moveTo(-2, -H * 0.45); ctx.lineTo(8, -H * 0.28); ctx.lineTo(17, -H * 0.1);
  ctx.stroke();
  /* 足先 */
  ctx.beginPath(); ctx.moveTo(17, -H * 0.1); ctx.lineTo(22, -H * 0.08); ctx.stroke();
  ctx.restore();
}

/* カーリングのハウス（同心円の的） */
function houseTarget(ctx, cx, cy, r) {
  ctx.save();
  var cols = ['#d94a3d', '#ffffff', '#3b7dd8', '#ffffff'];
  for (var i = 0; i < 4; i++) {
    ctx.beginPath();
    ctx.arc(cx, cy, r * (1 - i * 0.25), 0, Math.PI * 2);
    ctx.fillStyle = cols[i]; ctx.fill();
    ctx.strokeStyle = '#8a949e'; ctx.lineWidth = 1; ctx.stroke();
  }
  ctx.restore();
}

/* カーリングのストーン */
function stone(ctx, cx, cy, r) {
  ctx.save();
  ctx.beginPath(); ctx.ellipse(cx, cy, r, r * 0.68, 0, 0, Math.PI * 2);
  ctx.fillStyle = '#6b7078'; ctx.strokeStyle = '#3a3f45'; ctx.lineWidth = 1.6;
  ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.ellipse(cx, cy - r * 0.42, r * 0.8, r * 0.38, 0, 0, Math.PI * 2);
  ctx.fillStyle = '#aeb4bb'; ctx.fill(); ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(cx - 2, cy - r * 0.7); ctx.lineTo(cx - 2, cy - r * 1.15);
  ctx.lineTo(cx + 6, cy - r * 1.15);
  ctx.strokeStyle = '#c0392b'; ctx.lineWidth = 2.4; ctx.stroke();
  ctx.restore();
}

/* 木（モンキーハンティング用） */
function tree(ctx, x, yBase, h) {
  ctx.save();
  ctx.fillStyle = '#8d6e4a'; ctx.strokeStyle = '#6b5236'; ctx.lineWidth = 1.4;
  ctx.beginPath(); ctx.rect(x - 7, yBase - h, 14, h); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#4e9c56'; ctx.strokeStyle = '#37753e';
  [[0, -h - 6, 30], [-24, -h + 14, 24], [24, -h + 14, 24]].forEach(function (c) {
    ctx.beginPath(); ctx.arc(x + c[0], yBase + c[1], c[2], 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  });
  ctx.restore();
}

/* 猿 */
function monkeyShape(ctx, x, y, r) {
  ctx.save();
  ctx.strokeStyle = '#7a4b21'; ctx.lineWidth = 1.5;
  /* しっぽ */
  ctx.beginPath(); ctx.moveTo(x + r * 0.7, y + r * 0.2);
  ctx.quadraticCurveTo(x + r * 2.0, y + r * 0.2, x + r * 1.5, y - r * 0.9);
  ctx.stroke();
  ctx.fillStyle = '#a9713a';
  /* からだ */
  ctx.beginPath(); ctx.ellipse(x, y + r * 0.6, r * 0.75, r * 0.85, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  /* 耳 */
  ctx.beginPath(); ctx.arc(x - r * 0.85, y - r * 0.5, r * 0.36, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.arc(x + r * 0.85, y - r * 0.5, r * 0.36, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  /* 頭 */
  ctx.beginPath(); ctx.arc(x, y - r * 0.45, r * 0.8, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#f0d3ac';
  ctx.beginPath(); ctx.ellipse(x, y - r * 0.3, r * 0.5, r * 0.42, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#3a2312';
  ctx.beginPath(); ctx.arc(x - r * 0.24, y - r * 0.62, r * 0.11, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc(x + r * 0.24, y - r * 0.62, r * 0.11, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
}

/* かわいいコルク銃 */
function corkGun(ctx, x, y, angRad) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(-angRad);
  ctx.lineWidth = 1.6; ctx.strokeStyle = '#2c4f73';
  /* 銃身 */
  ctx.fillStyle = '#7fb2e5';
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(-6, -9, 52, 18, 8); else ctx.rect(-6, -9, 52, 18);
  ctx.fill(); ctx.stroke();
  /* 口 */
  ctx.fillStyle = '#cfe4f8';
  ctx.beginPath(); ctx.ellipse(45, 0, 4, 9, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  /* にぎり */
  ctx.fillStyle = '#f2a341';
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(-2, 6, 15, 26, 6); else ctx.rect(-2, 6, 15, 26);
  ctx.fill(); ctx.stroke();
  /* 引き金 */
  ctx.strokeStyle = '#5b6672';
  ctx.beginPath(); ctx.arc(16, 12, 6, 0.2, Math.PI * 0.95); ctx.stroke();
  /* 目（かわいく） */
  ctx.fillStyle = '#22394f';
  ctx.beginPath(); ctx.arc(8, -3, 2.2, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc(18, -3, 2.2, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
}

/* かご */
function basketShape(ctx, cx, yTop, wTop, h) {
  ctx.save();
  ctx.strokeStyle = '#9a6b3f'; ctx.lineWidth = 2.2;
  var wBot = wTop * 0.62;
  ctx.beginPath();
  ctx.moveTo(cx - wTop / 2, yTop); ctx.lineTo(cx - wBot / 2, yTop + h);
  ctx.lineTo(cx + wBot / 2, yTop + h); ctx.lineTo(cx + wTop / 2, yTop);
  ctx.stroke();
  ctx.lineWidth = 1.1;
  var i;
  for (i = 1; i < 5; i++) {
    var f = i / 5, w = wTop + (wBot - wTop) * f;
    ctx.beginPath(); ctx.moveTo(cx - w / 2, yTop + h * f); ctx.lineTo(cx + w / 2, yTop + h * f); ctx.stroke();
  }
  for (i = 1; i < 5; i++) {
    var g = -0.5 + i / 5;
    ctx.beginPath(); ctx.moveTo(cx + wTop * g, yTop); ctx.lineTo(cx + wBot * g, yTop + h); ctx.stroke();
  }
  ctx.lineWidth = 3; ctx.strokeStyle = '#7d5430';
  ctx.beginPath(); ctx.moveTo(cx - wTop / 2, yTop); ctx.lineTo(cx + wTop / 2, yTop); ctx.stroke();
  ctx.restore();
}

/* 台車 */
function cart(ctx, cx, yBase, w) {
  ctx.save();
  ctx.fillStyle = '#dbe7f3'; ctx.strokeStyle = '#2c4f73'; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.rect(cx - w / 2, yBase - 20, w, 16); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#586b7d';
  [-w / 3, w / 3].forEach(function (dx) {
    ctx.beginPath(); ctx.arc(cx + dx, yBase - 2, 7, 0, Math.PI * 2); ctx.fill();
  });
  /* 発射筒 */
  ctx.fillStyle = '#b9cde0'; ctx.strokeStyle = '#2c4f73';
  ctx.beginPath(); ctx.rect(cx - 6, yBase - 34, 12, 15); ctx.fill(); ctx.stroke();
  ctx.restore();
}
