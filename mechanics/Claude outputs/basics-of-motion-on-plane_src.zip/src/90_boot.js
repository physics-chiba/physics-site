/* 起動とテスト用フック */
'use strict';
(function () {
  initState();
  drawLegend();
  renderMath(document.body);

  var hp = parseHash(location.hash);
  if (!DEFS[hp.id]) hp.id = 'm1-1';
  st.cur = hp.id;
  buildTabs();
  buildPanel();
  renderActive();
  if (hp.quiz) {
    setQmode(true);                      /* 問題モードで開く（各シムを①の状態にそろえる） */
    showQNotice();                       /* リンクで来た生徒に「いまは問題モード」と大きく知らせる */
  }
  updateUrlBar();

  window.addEventListener('hashchange', function () {
    if (st._skipHash) { st._skipHash = false; return; }
    var q = parseHash(location.hash);
    if (!DEFS[q.id]) return;
    if (q.quiz !== st.qmode) {
      st.cur = q.id;
      setQmode(q.quiz);
      if (q.quiz) showQNotice();         /* リンクで問題モードに入ったときも知らせる */
      return;
    }
    if (q.id !== st.cur) gotoSim(q.id);
  });


  /* KaTeX のフォントが読み込まれたら、式の幅をそろえ直す */
  if (document.fonts && document.fonts.ready && document.fonts.ready.then) {
    document.fonts.ready.then(function () { refitFormulas(); placeModeTip(); });
  }
  window.addEventListener('resize', function () { refitFormulas(); placeModeTip(); fitStageHeight(); renderActive(); });
  requestAnimationFrame(tick);

  /* ===== 自動テスト用のフック ===== */
  window.TEST = {
    sims: function () { return Object.keys(DEFS); },
    state: function () {
      var s = st.sims[st.cur];
      return { sim: st.cur, v: JSON.parse(JSON.stringify(s.v)), o: JSON.parse(JSON.stringify(s.o)), sign: s.sign, t: +s.t.toFixed(4) };
    },
    goto: function (id) { gotoSim(id); return st.cur; },
    /* 3次元の視点（テスト・スクリーンショット用） */
    cam: function (az, el, zoom) {
      var s = st.sims[st.cur];
      if (!s.cam) return null;
      s.cam.az = az; s.cam.el = el; s.cam.zoom = zoom || 1;
      renderActive();
      return { az: s.cam.az, el: s.cam.el, zoom: s.cam.zoom };
    },
    camGet: function () {
      var s = st.sims[st.cur];
      return s.cam ? { az: +s.cam.az.toFixed(3), el: +s.cam.el.toFixed(3), zoom: +s.cam.zoom.toFixed(3) } : null;
    },
    /* グラフの表示範囲（ドラッグ操作の確認用） */
    gview: function (key, view) {
      var s = st.sims[st.cur];
      if (view === undefined) return s.gview[key] || null;
      if (view === null) delete s.gview[key]; else s.gview[key] = view;
      renderActive();
      return s.gview[key] || null;
    },
    graphMap: function (key) {
      var cv = document.getElementById('gc_' + key);
      if (!cv || !cv._map) return null;
      var m = cv._map;
      return { xmin: +m.xmin.toFixed(4), xmax: +m.xmax.toFixed(4), ymin: +m.ymin.toFixed(4), ymax: +m.ymax.toFixed(4) };
    },
    /* 横軸（時間）の目盛りが、運動の終わりまで届いているか */
    xTicks: function () {
      var d = DEFS[st.cur], s = st.sims[st.cur], out = {};
      var T = d.tGraph ? d.tGraph(V(s)) : d.tEnd(V(s));
      graphsOf(d, s).forEach(function (g) {
        var cv = document.getElementById('gc_' + g.key);
        if (!s.open[g.key] || !cv || !cv._map) return;
        var m = cv._map, last = null, i;
        for (i = Math.ceil(m.xmin / m.xstep) * m.xstep; i <= m.xmax + 1e-9; i += m.xstep) {
          if (Math.abs(i) > 1e-9) last = i;
        }
        out[g.key] = { T: +T.toFixed(4), xmax: +m.xmax.toFixed(4), step: +m.xstep.toFixed(4),
          last: last === null ? null : +last.toFixed(4), ok: last !== null && last >= T - 1e-6 };
      });
      return out;
    },
    openAll: function () { toggleAllGraphs(); return window.TEST.graphsOpen(); },
    /* 問題モード */
    qmode: function (on) {
      setQmode(on);
      return { qmode: st.qmode, qphase: st.sims[st.cur].qphase };
    },
    qstate: function () {
      var s = st.sims[st.cur];
      return {
        qmode: st.qmode, qphase: s.qphase, qpick: s.qpick,
        correct: quizCorrectIndex(DEFS[st.cur]),
        quizVisible: $('gquiz') ? $('gquiz').style.display !== 'none' : null,
        hidden: graphsHidden(s), quizName: quizName(DEFS[st.cur]), game: !!DEFS[st.cur].game,
        playDisabled: $('bPlay') ? !!$('bPlay').disabled : null
      };
    },
    qplayToEnd: function () {
      var s = st.sims[st.cur], d = DEFS[st.cur];
      s.t = d.tEnd(V(s));
      if (st.qmode && s.qphase === 0) { s.qphase = 1; syncQuiz(); }
      renderActive();
      return window.TEST.qstate();
    },
    qpick: function (i) { pickGraphQuiz(i); return window.TEST.qstate(); },
    /* ゲームの成功判定（テスト用） */
    win: function (id) {
      var d = DEFS[id || st.cur], s = st.sims[id || st.cur];
      return d.win ? !!d.win(s, s.t) : null;
    },
    /* 各グラフの式（3段） */
    formulas: function () {
      var d = DEFS[st.cur], s = st.sims[st.cur], out = {};
      graphsOf(d, s).forEach(function (g) { if (g.fml) out[g.key] = g.fml(V(s), s.sign); });
      return out;
    },
    set: function (o) {
      var s = st.sims[st.cur];
      if (o.vars) Object.keys(o.vars).forEach(function (k) { if (k in s.v) s.v[k] = o.vars[k]; });
      if (o.opts) Object.keys(o.opts).forEach(function (k) { s.o[k] = o.opts[k]; });
      if (o.sign !== undefined) s.sign = o.sign;
      if (o.t !== undefined) s.t = o.t; else s.t = 0;
      s.playing = false;
      buildPanel();
      renderActive();
      return window.TEST.state();
    },
    /* いま表示しているシムの読み出し（DOM の文言） */
    readout: function () {
      return Array.prototype.map.call(document.querySelectorAll('#readout tr'), function (tr) {
        return tr.children[0].textContent + '=' + tr.children[1].textContent;
      });
    },
    graphsOpen: function () {
      var s = st.sims[st.cur];
      return JSON.parse(JSON.stringify(s.open));
    },
    /* 物理の検算（UI の状態によらない固定の計算） */
    check: function () {
      var r = {};
      /* 自由落下 h=19.6 m */
      var f = { h: 19.6, v0: 0, m: 1 };
      r.freefall_T = +P.m12.tEnd(f).toFixed(6);
      r.freefall_v = +P.m12.sample(f, P.m12.tEnd(f)).v.toFixed(6);
      /* 投げ上げ v0=9.8 */
      var u = { v0: 9.8, y0: 0, H: 0, m: 1 };
      r.up_tTop = +P.m13.tTop(u).toFixed(6);
      r.up_yTop = +P.m13.yTop(u).toFixed(6);
      r.up_tEnd = +P.m13.tEnd(u).toFixed(6);
      var u2 = { v0: 9.8, y0: 0, H: 19.6, m: 1 };
      r.up_building_tEnd = +P.m13.tEnd(u2).toFixed(6);
      r.up_building_vEnd = +P.m13.sample(u2, P.m13.tEnd(u2)).v.toFixed(6);
      /* 斜面 1-1（θ>0 が下り坂・x は斜面にそって右向きが正） */
      r.slope30_a = +Math.abs(P.m11.a({ th: 30, v0: 6, m: 1 })).toFixed(6);   /* 大きさは g sin30 */
      r.slope_down_a = +P.m11.a({ th: 30, v0: 6, m: 1 }).toFixed(6);          /* 下り坂は正 */
      r.slope_up_a = +P.m11.a({ th: -30, v0: 6, m: 1 }).toFixed(6);           /* のぼりは負 */
      r.slope_up_tBack = +P.m11.tEnd({ th: -30, v0: 6, m: 1 }).toFixed(6);    /* のぼって戻るまで */
      r.slope0_a = +P.m11.a({ th: 0, v0: 6, m: 1 }).toFixed(6);
      /* 1-1 マイナスの v0（左向き）でも出発点にもどる */
      r.slope_neg_tEnd = +P.m11.tEnd({ th: 30, v0: -4, m: 1 }).toFixed(6);
      r.slope_neg_back = +P.m11.s({ th: 30, v0: -4, m: 1 }, P.m11.tEnd({ th: 30, v0: -4, m: 1 })).toFixed(6);
      /* 摩擦つき斜面（既定値） */
      var w = { F: 20, v0: 0, m: 2, th: 30, mu: 0.5, mud: 0.3 };
      r.pull_a0 = +P.m14.a0(w).toFixed(4);
      r.pull_static_F5 = P.m14.staticAtStart({ F: 5, v0: 0, m: 2, th: 30, mu: 0.5, mud: 0.3 });
      /* 斜方投射 */
      var p = { v0: 15, th: 45, m: 1 };
      r.proj45_range = +(p.v0 * p.v0 * Math.sin(2 * 45 * DEG) / G).toFixed(6);
      /* 2-2：アニメーションは y=0 でぴたりと止まる／vy–t 図の正負の面積が等しい */
      var pj = { v0: 15, th: 45, m: 1 };
      var Tp = P.m22.tEnd(pj), ttop = P.m22.tTop(pj);
      r.proj_tEnd_y0 = +P.m22.sample(pj, Tp).y.toFixed(9);          /* 0 ちょうど */
      r.proj_tEnd_formula = +(2 * pj.v0 * Math.sin(45 * DEG) / G).toFixed(9);
      r.proj_tEnd_value = +Tp.toFixed(9);
      var areaUp = 0, areaDn = 0, NN = 4000, kk;
      for (kk = 0; kk < NN; kk++) {                                  /* vy を台形則で積分＝面積 */
        var t1 = ttop * kk / NN, t2 = ttop * (kk + 1) / NN;
        areaUp += (P.m22.sample(pj, t1).vy + P.m22.sample(pj, t2).vy) / 2 * (t2 - t1);
        var t3 = ttop + (Tp - ttop) * kk / NN, t4 = ttop + (Tp - ttop) * (kk + 1) / NN;
        areaDn += (P.m22.sample(pj, t3).vy + P.m22.sample(pj, t4).vy) / 2 * (t4 - t3);
      }
      r.proj_area_up = +areaUp.toFixed(4);                           /* ＝最高点の高さ */
      r.proj_area_dn = +areaDn.toFixed(4);                           /* ＝−（最高点の高さ） */
      r.proj_area_sum = +(areaUp + areaDn).toFixed(4);               /* ＝0 */
      r.proj_yTop = +P.m22.yTop(pj).toFixed(4);
      r.proj_horiz_vx = +P.m22.sample({ v0: 15, th: 0, m: 1 }, 1.0).vx.toFixed(6);
      r.proj_horiz_y1s = +P.m22.sample({ v0: 15, th: 0, m: 1 }, 1.0).y.toFixed(6);
      /* ストロボ：2つの運動の高さの差はいつも 0 */
      var q = { v0: 12, th: 60, dt: 0.1, pair: 'B' };
      var maxd = 0, i;
      for (i = 0; i <= 50; i++) {
        var tt = P.m21.tEnd(q) * i / 50;
        maxd = Math.max(maxd, Math.abs(P.m21.left(q, tt).y - P.m21.right(q, tt).y));
      }
      r.strobe_ydiff = +maxd.toFixed(9);
      /* ビルの上から：原点を変えても vy は同じ */
      var b1 = { v0: 15, th: 30, H: 20, m: 1, org: 'launch' };
      var b2 = { v0: 15, th: 30, H: 20, m: 1, org: 'base' };
      r.build_vy_same = +Math.abs(P.m23.sample(b1, 1.3).vy - P.m23.sample(b2, 1.3).vy).toFixed(9);
      r.build_tEnd = +P.m23.tEnd(b1).toFixed(6);
      /* 斜面上を転がる：a = g sinθ */
      r.roll30_a = +Math.abs(P.m26.a({ th: 30, v0: 6, al: 55, m: 1 })).toFixed(6);
      /* 4-2 斜面から斜方投射：かならず斜面 y = x tanθ の上に落ちる */
      r.slopeproj_land = [30, -30, 0, 45].map(function (th) {
        var vv = { th: th, phi: 45, v0: 14 }, T = P.m25.tEnd(vv), q = P.m25.sample(vv, T);
        return +Math.abs(q.y - q.x * Math.tan(th * DEG)).toFixed(9);
      }).join(',');
      /* 4-2 斜面座標：着地は Y=0、T = 2v0 sinΦ/(g cosθ)、飛距離は X(T) */
      var sp = { th: 30, phi: 45, v0: 14 }, Tsp = P.m25.tEnd(sp), qsp = P.m25.sample(sp, Tsp);
      r.slopeXY_T = +Tsp.toFixed(6);
      r.slopeXY_T_formula = +(2 * sp.v0 * Math.sin(sp.phi * DEG) / (G * Math.cos(sp.th * DEG))).toFixed(6);
      r.slopeXY_Yend = +Math.abs(qsp.Y).toFixed(9);
      r.slopeXY_L = +qsp.X.toFixed(6);
      r.slopeXY_aY = +qsp.aY.toFixed(6);
      /* 3-3 弾は地面ではね返る（y は 0 より下に行かない） */
      var mk = { v0: 20, th: 10, mx: 20, my: 12 }, below = 0;
      for (var bi = 0; bi <= 200; bi++) if (P.m33.path(mk, P.m33.tEnd(mk) * bi / 200).y < -1e-9) below++;
      r.monkey_bounce_below = below;
      r.monkey_safe_low = P.m33.safe(mk);
      r.monkey_safe_high = P.m33.safe({ v0: 20, th: 55, mx: 20, my: 12 });
      /* 3-1 衝突時刻 = H / v0 */
      var c = { v0: 14, H: 20 };
      r.col_t = +P.m31.tCol(c).toFixed(6);
      r.col_t_formula = +(c.H / c.v0).toFixed(6);
      r.col_height = +P.m31.A(c, P.m31.tCol(c)).y.toFixed(6);
      r.col_relvel = +(P.m31.sample(c, 0.5).rel).toFixed(6);
      /* 3-2 台車：ずれはいつも 0 */
      var d2 = { V: 4, u: 9.8 }, mx = 0;
      for (i = 0; i <= 50; i++) {
        var s2 = P.m32.sample(d2, P.m32.tEnd(d2) * i / 50);
        mx = Math.max(mx, Math.abs(s2.xB - s2.xA));
      }
      r.cart_dx = +mx.toFixed(9);
      r.cart_launch_t = +P.m32.tLaunch(d2).toFixed(6);          /* x=5 m に来る時刻 */
      r.cart_launch_x = +P.m32.sample(d2, P.m32.tLaunch(d2)).xA.toFixed(6);
      r.cart_before_y = +P.m32.sample(d2, P.m32.tLaunch(d2) * 0.5).yB.toFixed(9);
      /* 3-3 モンキーハンティング：ねらえば必ず当たる */
      var hits = [], miss = [];
      [[20, 12], [15, 20], [30, 8], [40, 25], [10, 5]].forEach(function (pos) {
        var vv = { v0: 25, th: 0, mx: pos[0], my: pos[1] };
        vv.th = P.m33.aimDeg(vv);
        hits.push(P.m33.hit(vv) ? 1 : 0);
        var vm = { v0: 25, th: vv.th + 8, mx: pos[0], my: pos[1] };
        miss.push(P.m33.hit(vm) ? 1 : 0);
      });
      r.monkey_aimed_hits = hits.join('');
      r.monkey_offaim_hits = miss.join('');
      r.monkey_aim_deg = +P.m33.aimDeg({ v0: 20, th: 25, mx: 20, my: 12 }).toFixed(6);
      r.monkey_mindist = +P.m33.closest({ v0: 20, th: P.m33.aimDeg({ mx: 20, my: 12 }), mx: 20, my: 12 }).d.toFixed(6);
      /* 1-9〜1-12 2物体の運動 */
      var tb = { f: 12, m: 1, M: 3 };
      r.two_string_a = +P.m18.a(tb).toFixed(6);                      /* f/(m+M) */
      r.two_string_T = +P.m18.T(tb).toFixed(6);                      /* m f/(m+M) */
      r.two_string_check = +(tb.f - P.m18.T(tb) - tb.M * P.m18.a(tb)).toFixed(9);   /* B の式 = 0 */
      var pl9 = { m: 1, M: 2, th: 0 };
      r.pulley_a0 = +P.m19.a(pl9).toFixed(6);
      r.pulley_a0_formula = +(pl9.M * G / (pl9.m + pl9.M)).toFixed(6);
      r.pulley_T_lt_Mg = P.m19.T(pl9) < pl9.M * G;                   /* T < Mg */
      var pl9b = { m: 4, M: 2, th: 30 };
      r.pulley_balance_a = +P.m19.a(pl9b).toFixed(9);                /* M = m sinθ → a = 0 */
      var at = { m: 1, M: 3 };
      r.atwood_a = +P.m110.a(at).toFixed(6);
      r.atwood_a_formula = +((at.M - at.m) * G / (at.M + at.m)).toFixed(6);
      r.atwood_a_lt_g = P.m110.a(at) < G;
      r.atwood_T = +P.m110.T(at).toFixed(6);
      r.atwood_T_between = (P.m110.T(at) > at.m * G) && (P.m110.T(at) < at.M * G);
      r.atwood_same_mass_a = +P.m110.a({ m: 3, M: 3 }).toFixed(9);   /* 同じ質量なら 0 */
      /* 1-12 板の上の物体 */
      var bd = { mA: 3, mB: 1, mud: 0.3, FA: 12, FB: 0, vA0: 0, vB0: 0 };
      var q1 = P.m111.acc(bd, 0, 0);
      r.board_aB = +q1.aB.toFixed(6);                                /* μ'g */
      r.board_aB_formula = +(bd.mud * G).toFixed(6);
      r.board_aA = +q1.aA.toFixed(6);
      r.board_aA_formula = +((bd.FA - bd.mud * bd.mB * G) / bd.mA).toFixed(6);
      var bd2 = { mA: 3, mB: 1, mud: 0.3, FA: 6, FB: 0, vA0: 0, vB0: 0 };
      r.board_weakF_together = !P.m111.acc(bd2, 0, 0).slip;          /* 弱い力ならすべらない */
      r.board_weakF_a = +P.m111.acc(bd2, 0, 0).aA.toFixed(6);        /* F/(M+m) */
      var bd3 = { mA: 3, mB: 1, mud: 0.3, mus: 0.3, FA: 0, FB: 0, vA0: 0, vB0: 2.5 };
      var ts3 = P.m111.tStick(bd3), sm3 = P.m111.sample(bd3, ts3 + 1.0);
      r.board_p_before = +(bd3.mA * bd3.vA0 + bd3.mB * bd3.vB0).toFixed(6);
      r.board_p_after = +(bd3.mA * sm3.vA + bd3.mB * sm3.vB).toFixed(6);   /* 運動量保存 */
      r.board_same_v = +(sm3.vA - sm3.vB).toFixed(9);
      r.board_slid = +Math.abs(sm3.slid).toFixed(6);
      r.board_no_fall = !isFinite(P.m111.tFall(bd3));                     /* 板から落ちない設定 */
      /* 静止摩擦係数 μ でくっつくかどうかが決まる（μ が大きいほどすべり出しにくい） */
      var bd5 = { mA: 3, mB: 2, mud: 0.25, mus: 0.5, FA: 26, FB: 0, vA0: 0, vB0: 0 };
      r.board_mus_slip_at0 = P.m111.acc(bd5, 0, 0).slip;                  /* F > μg(M+m) → はじめからすべる */
      r.board_mus_limit = +(bd5.mus * G * (bd5.mA + bd5.mB)).toFixed(3);  /* 24.5 N < 26 N */
      bd5.FA = 20;
      r.board_mus_stick_at0 = !P.m111.acc(bd5, 0, 0).slip;                /* F < μg(M+m) → すべらない */
      /* B が板からすべり落ちる → 水平投射。水平の速さは落ちたあと変わらない */
      var bd4 = { mA: 3, mB: 2, mud: 0.25, mus: 0.5, FA: 26, FB: 0, vA0: 0, vB0: 0 };
      var tf4 = P.m111.tFall(bd4);
      r.board_fall_t = +tf4.toFixed(6);
      r.board_fall_slid = +Math.abs(P.m111.sample(bd4, tf4).slid).toFixed(6);   /* = LB/2 */
      r.board_fall_half = +(P.m111.LB / 2).toFixed(6);
      r.board_air_vB = +(P.m111.sample(bd4, tf4 + 0.1).vB - P.m111.sample(bd4, tf4).vB).toFixed(9);
      r.board_land_y = +P.m111.sample(bd4, tf4 + P.m111.tFly() + 0.01).yB.toFixed(9);
      r.board_after_aA = +(P.m111.sample(bd4, tf4 + 0.3).aA - bd4.FA / bd4.mA).toFixed(9);
      /* 1-4 水平面で引く（なめらか）：a = (F1 - F2 - mg sinθ)/m。左右同じ力なら a = 0 */
      var pl = { F: 10, F2: 0, th: 0, m: 2, v0: 0, mu: 0, mud: 0, LEN: 9, TMAX: 6 };
      r.pull_a = +P.m14.a0(pl).toFixed(6);
      r.pull_a_formula = +((pl.F - pl.F2) / pl.m).toFixed(6);
      var pl2 = { F: 5, F2: 5, th: 0, m: 2, v0: 3, mu: 0, mud: 0, LEN: 9, TMAX: 6 };
      r.pull_balance_a = +P.m14.a0(pl2).toFixed(9);                   /* つり合い＝0 */
      r.pull_balance_v = +P.m14.sample(pl2, 1).v.toFixed(6);          /* 等速のまま */
      var pl3 = { F: 20, F2: 5, th: 30, m: 2, v0: 0, mu: 0, mud: 0, LEN: 9, TMAX: 6 };
      r.pull_slope_a = +P.m14.a0(pl3).toFixed(6);
      r.pull_slope_formula =
        +((pl3.F - pl3.F2 - pl3.m * G * Math.sin(30 * DEG)) / pl3.m).toFixed(6);
      /* 1-7 カーリング：止まる位置は v0²/(2|a|)。氷の長さで打ち切られないこと */
      var cu = { v0: 12, mud: 0.005, th: 0, m: 18, mu: 0.6, F: 0, LEN: 50, TMAX: 20 };
      r.curl_xstop = +P.m14.xStopIdeal(cu).toFixed(3);
      r.curl_xstop_formula = +(cu.v0 * cu.v0 / (2 * G * cu.mud)).toFixed(3);
      var cu2 = { v0: 5, mud: 0.05, th: 0, m: 18, mu: 0.6, F: 0, LEN: 50, TMAX: 20 };
      r.curl_xstop2 = +P.m14.xStopIdeal(cu2).toFixed(3);
      r.curl_xstop2_table = +P.m14.xStop(cu2).toFixed(3);     /* 氷の中なら表の値と一致 */
      var cu3 = { v0: 8, mud: 0.05, th: 3, m: 18, mu: 0.6, F: 0, LEN: 50, TMAX: 20 };
      r.curl_slope_xstop = +P.m14.xStopIdeal(cu3).toFixed(3);
      r.curl_slope_table = +P.m14.xStop(cu3).toFixed(3);
      /* 4-1 気球からの水平投射 */
      var bl = { v0: 10, V0: 5, h: 30, obs: 'ground' };
      var Tb = P.m41.tEnd(bl);
      r.balloon_T = +Tb.toFixed(6);
      r.balloon_T_formula = +((bl.V0 + Math.sqrt(bl.V0 * bl.V0 + 2 * G * bl.h)) / G).toFixed(6);
      r.balloon_yEnd = +P.m41.sample(bl, Tb).y.toFixed(9);           /* 地面に着く＝0 */
      r.balloon_vy0_ground = +P.m41.sample(bl, 0).vy.toFixed(6);      /* ＝V0（水平ではない！） */
      var blb = { v0: 10, V0: 5, h: 30, obs: 'balloon' };
      r.balloon_vy0_rel = +P.m41.sample(blb, 0).vy.toFixed(9);        /* ＝0（気球から見れば水平投射） */
      r.balloon_yrel_end = +P.m41.sample(blb, Tb).y.toFixed(6);
      r.balloon_yrel_formula = +(-0.5 * G * Tb * Tb).toFixed(6);
      /* 観測者を変えても加速度は同じ。速度差はいつも V0 で一定 */
      var dvy = 0, dax = 0;
      for (i = 0; i <= 40; i++) {
        var tb = Tb * i / 40;
        var g1 = P.m41.sample(bl, tb), b1 = P.m41.sample(blb, tb);
        dvy = Math.max(dvy, Math.abs((g1.vy - b1.vy) - bl.V0));
        dax = Math.max(dax, Math.abs(g1.ay - b1.ay));
      }
      r.balloon_dvy_const = +dvy.toFixed(9);
      r.balloon_same_a = +dax.toFixed(9);
      /* 落下の瞬間の速さ＝エネルギー保存の値と一致 */
      var vend = P.m41.sample(bl, Tb).v;
      r.balloon_vEnd = +vend.toFixed(6);
      r.balloon_vEnd_energy = +Math.sqrt(bl.v0 * bl.v0 + bl.V0 * bl.V0 + 2 * G * bl.h).toFixed(6);
      /* 最高点 */
      r.balloon_yTop = +P.m41.yTop(bl).toFixed(6);
      r.balloon_yTop_num = +P.m41.sample(bl, bl.V0 / G).y.toFixed(6);
      return r;
    }
  };
})();
