/* 1　一次元の等加速度直線運動（2物体の運動） */
'use strict';

/* 2物体のシミュレーションで共通に使う、左下の「運動方程式を解く」欄の組み方。
   ・1行目：A についての運動方程式
   ・2行目：B についての運動方程式
   ・3行目：辺々たして a を出す
   ・4行目：a を代入して張力 T を出す
   記号の式と数値の式を、そのまま順に並べる。 */
/* 2物体のシムの説明文の最後にそえる、色の決めごと（生徒への説明） */
var OBJCOL = '<br>力の矢印は、<b>A にはたらく力＝あかるい色</b>／<b>B にはたらく力＝こい色</b>で描き分けている' +
  '（色みは力の種類：重力＝赤・垂直抗力＝むらさき・摩擦＝青緑・手や糸＝ピンク）。';

function twoBodyEq(rows) {
  return '\\begin{aligned}' + rows.join(' \\\\[2pt] ') + '\\end{aligned}';
}

/* 2物体のシミュレーションで共通の変数（質量）。m < M の並びで見せる */
function twoMassVars(mDef, MDef) {
  return [
    { k: 'm', label: 'A の質量 $m$', unit: ' kg', min: 0.5, max: 6, step: 0.5, dec: 1, def: mDef },
    { k: 'M', label: 'B の質量 $M$', unit: ' kg', min: 0.5, max: 8, step: 0.5, dec: 1, def: MDef }
  ];
}

/* 「支えている手を放す」の吹き出し（手の右がわ）。動かす前（t=0）だけ出す。
   (hx, hy) ＝ 手のひらのてっぺん（＝物体の下のはし）。 */
function releaseHint(ctx, hx, hy, W, dy) {
  /* しっぽは「手」を指すので、吹き出しは手の右・しっぽは左向き（side:'left'） */
  bubble(ctx, '支えている手を放す', hx + 32, hy + (dy === undefined ? 18 : dy),
    { size: 12.5, side: 'left', bg: '#fff5e8', border: '#e07b18', color: '#a85c0c' });
}

/* 2物体で共通のグラフ（x・v・a）。fml は各シミュレーションから渡す */
function twoBodyGraphs(xLabel, fmlX, fmlV, fmlA) {
  return [
    { key: 'x', short: '$x$–$t$ 図', title: '$x$–$t$ 図（' + xLabel + '）', ylabel: 'x [m]', open: false, signed: true,
      series: [{ color: COL.ink, f: function (mm) { return mm.x; } }], fml: fmlX },
    { key: 'v', short: '$v$–$t$ 図', title: '$v$–$t$ 図（速さ）', ylabel: 'v [m/s]', open: true, signed: true,
      series: [{ color: COL.vel, f: function (mm) { return mm.v; } }], fml: fmlV },
    { key: 'a', short: '$a$–$t$ 図', title: '$a$–$t$ 図（加速度）　※ a の運動方程式による導出', ylabel: 'a [m/s²]', open: false, signed: true,
      series: [{ color: COL.acc, f: function (mm) { return mm.a; } }], fml: fmlA }
  ];
}

/* ============ 1-9 2物体（糸でつなぐ） ============ */
DEFS['m1-9'] = {
  id: 'm1-9', mode: 1, tab: '1-9 2物体（糸）',
  quizKey: 'v', quizName: 'A と B の $v$–$t$ 図（右向きが正）',
  title: '1-9　2物体を糸でつないで引く（なめらかな水平面）',
  sub: 'なめらかな水平面の上に、質量 $m$ の A と質量 $M$ の B を軽い糸でつなぎ、B を大きさ $f$ の力で右へ引き続ける。' +
    '<b>糸は伸び縮みしないので、A と B の加速度・速さ・進んだ距離は同じ</b>。' +
    'まず<b>2つをひとまとまり</b>と見て $a$ を出し、つぎに<b>A だけ</b>を見て糸の張力 $T$ を出す、というのが定石。' + OBJCOL,
  cw: 520, ch: 250,
  vis: ['F', 'Fm', 'V'], visDef: { F: true },
  signLabels: ['右向きを正', '左向きを正'],
  mainVars: ['f', 'm', 'M'], mainVarFocus: 'f',
  vars: [{ k: 'f', label: '引く力 $f$', unit: ' N', min: 4, max: 40, step: 2, dec: 0, def: 30 }].concat(twoMassVars(1.0, 3.0)),
  toggles: [],
  actions: [
    { label: 'A を軽くする（m＝0.5 kg）', fn: function (s) { s.v.m = 0.5; }, is: function (v) { return v.m === 0.5; } },
    { label: 'A と B を同じ質量にする', fn: function (s) { s.v.m = 2; s.v.M = 2; }, is: function (v) { return v.m === v.M; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.f = 30; s.v.m = 1; s.v.M = 3; },
      is: function (v) { return v.f === 30 && v.m === 1 && v.M === 3; } }
  ],
  tEnd: function (v) { return P.m18.tEnd(v); },
  sample: function (v, t) { return P.m18.sample(v, t); },
  graphs: twoBodyGraphs('進んだ距離（A・B 共通）',
    function (v, sg) {
      var a = P.m18.a(v) * sg;
      return ['x = v_0 t + \\tfrac{1}{2}a t^2', 'x = \\tfrac{1}{2}\\dfrac{f}{m+M} t^2',
        'x = \\tfrac{1}{2}(' + fmt(a, 2) + ')t^2'];
    },
    function (v, sg) {
      var a = P.m18.a(v) * sg;
      return ['v = v_0 + at', 'v = \\dfrac{f}{m+M} t', 'v = (' + fmt(a, 2) + ')t'];
    },
    function (v, sg) {
      var a = P.m18.a(v) * sg;
      return [EQM + '(m+M)a = f', 'a = \\dfrac{f}{m+M}',
        'a = \\dfrac{' + fmt(v.f, 0) + '}{' + fmt(v.m, 1) + '+' + fmt(v.M, 1) + '} = ' + fmt(a, 2) + '\\ \\mathrm{m/s^2}'];
    }),
  draw: function (ctx, s, t, W, H) {
    var v = V(s), m = P.m18.sample(v, t), T = P.m18.tEnd(v);
    /* 右はしに「手・引く力の矢印・その文字」の場所を空けておく。
       下は「重力の矢印とその文字」のぶんだけあけて、その下に目もりを引く。 */
    var gy = H - 100, sc = (W - 330) / Math.max(1, P.m18.LEN);
    var kA = mSize({ vars: [{ k: 'm', def: 1 }] }, { m: v.m });
    var kB = mSize({ vars: [{ k: 'm', def: 3 }] }, { m: v.M });
    var bwA = 30 * kA, bhA = 22 * kA, bwB = 34 * kB, bhB = 26 * kB;
    ground(ctx, 10, W - 10, gy);
    /* 目盛り（進んだ距離） */
    axisX(ctx, function (x) { return 56 + x * sc; }, gy + 72, 0, P.m18.LEN, 'x [m]', s.sign, { step: 2 });
    originMark(ctx, 56, gy + 72, -12, 13);

    var xA = 56 + m.x * sc, xB = xA + 110;
    blockShape(ctx, xA, gy - bhA / 2, 0, bwA, bhA, '#e8eef5');
    blockShape(ctx, xB, gy - bhB / 2, 0, bwB, bhB, '#e3ecf6');
    /* 物体の名前は、垂直抗力の矢印より上のいつも同じ高さに書く */
    label(ctx, 'A（' + fmt(v.m, 1) + ' kg）', xA, 88, { size: 11, bold: true });
    label(ctx, 'B（' + fmt(v.M, 1) + ' kg）', xB, 88, { size: 11, bold: true });
    /* 糸をつなぐ高さは A・B で共通（水平な糸）。小さいほうの物体の中心の高さに合わせる */
    var ty = gy - Math.min(bhA, bhB) / 2;
    string(ctx, xA + bwA / 2, ty, xB - bwB / 2, ty);
    /* 手で B を引く（1-5 と同じ「物体 → 糸 → 手」の並び） */
    var hx = xB + bwB / 2 + 3, hy = ty;
    string(ctx, hx, hy, hx + 30, hy);
    hand(ctx, hx + 30, hy, 0);

    if (s.o.showF || s.o.showFm) {
      /* 力の縮尺は「いちばん大きい力」に合わせて全部そろえる */
      var fs = 46 / Math.max(v.f, v.m * G, v.M * G, 1), Tn = m.T;
      /* --- 運動の向き（水平）の力 --- */
      arrow(ctx, hx, hy, hx + v.f * fs, hy, 'force', 1, fcol('B', COL.hand));
      label(ctx, 'B：引く力 f = ' + fmt(v.f, 0) + ' N', hx + v.f * fs + 8, hy - 17,
        { size: 11.5, color: fcol('B', COL.hand), align: 'left' });
      arrow(ctx, xA + bwA / 2, ty, xA + bwA / 2 + Tn * fs, ty, 'force', 1, fcol('A', COL.hand));
      label(ctx, 'A：T', xA + bwA / 2 + 5, ty - 14, { size: 11, color: fcol('A', COL.hand), align: 'left' });
      arrow(ctx, xB - bwB / 2, ty, xB - bwB / 2 - Tn * fs, ty, 'force', 1, fcol('B', COL.hand));
      label(ctx, 'B：T', xB - bwB / 2 - 5, ty - 14, { size: 11, color: fcol('B', COL.hand), align: 'right' });
      label(ctx, '糸の張力 T = ' + fmt(Tn, 2) + ' N', W - 10, 54, { size: 11, color: COL.sub, align: 'right' });
      /* --- 面に垂直な力（重力と垂直抗力）。「運動方向の力のみ」のときは出さない --- */
      if (!s.o.showFm) {
        [{ w: 'A', x: xA, bh: bhA, mm: v.m, g: 'mg' },
          { w: 'B', x: xB, bh: bhB, mm: v.M, g: 'Mg' }].forEach(function (o) {
          var wt = o.mm * G * fs;
          arrow(ctx, o.x, gy - o.bh / 2, o.x, gy - o.bh / 2 + wt, 'force', 1, fcol(o.w, COL.force));
          label(ctx, o.w + '：' + o.g, o.x - 16, gy - o.bh / 2 + wt + 12,
            { size: 11, color: fcol(o.w, COL.force), align: 'right' });
          arrow(ctx, o.x, gy, o.x, gy - wt, 'force', 1, fcol(o.w, COL.norm));
          label(ctx, o.w + '：N', o.x - 16, gy - wt - 5,
            { size: 11, color: fcol(o.w, COL.norm), align: 'right' });
        });
      }
    }
    if (s.o.showV && m.v > 0.05) {
      var vl = 16 + 40 * Math.min(1, m.v / 8);
      arrow(ctx, xA, 66, xA + vl, 66, 'vel');
      label(ctx, 'v = ' + fmt(m.v * s.sign, 2) + ' m/s', xA + vl + 6, 66, { size: 11.5, color: COL.vel, align: 'left' });
    }
    if (hintOn(s, t)) {
      label(ctx, '糸でつながっているので、A も B も同じ加速度・同じ速さ', 12, 40,
        { size: 11.5, bold: true, color: COL.acc, align: 'left' });
    }
    label(ctx, 't = ' + fmt(t, 2) + ' s', W - 10, 18, { align: 'right', size: 13.5, bold: true });
    drawPosNote(ctx, DEFS['m1-9'], s, W, 36);
  },
  info: function (s, t) {
    var v = V(s), m = P.m18.sample(v, t);
    return [
      ['加速度 $a$（A・B 共通）', fmt(m.a * s.sign, 2) + ' m/s²'],
      ['糸の張力 $T$', fmt(m.T, 2) + ' N'],
      ['速さ $v$', fmt(m.v * s.sign, 2) + ' m/s'],
      ['進んだ距離 $x$', fmt(m.x * s.sign, 2) + ' m'],
      ['$f - T$（B にはたらく合力）', fmt(v.f - m.T, 2) + ' N'],
      ['$Ma$（確かめ）', fmt(v.M * m.a, 2) + ' N']
    ];
  },
  eqHead: '運動方程式をたてると',
  eq: function (s) {
    var v = V(s), a = P.m18.a(v), T = P.m18.T(v);
    return twoBodyEq([
      '&\\text{A について}&& ma = T',
      '&\\text{B について}&& Ma = f - T',
      '&\\text{辺々たすと}&& (m+M)a = f \\;\\Rightarrow\\; a = \\dfrac{f}{m+M} = \\dfrac{' +
        fmt(v.f, 0) + '}{' + fmt(v.m, 1) + '+' + fmt(v.M, 1) + '} = ' + fmt(a, 2) + '\\ \\mathrm{m/s^2}',
      '&\\text{A の式にもどして}&& T = ma = ' + fmt(v.m, 1) + '\\times' + fmt(a, 2) + ' = ' + fmt(T, 2) + '\\ \\mathrm{N}'
    ]);
  },
  note: '<b>2つまとめて見ると、糸の張力は内側で打ち消し合って消える</b>ので、いきなり $a$ が出せる。' +
    '$T$ を知りたいときは、<b>片方だけ</b>（ここでは A）を取り出して運動方程式を書けばよい。' +
    'A が軽いほど $T$ は小さくなる（$T = \\dfrac{m}{m+M}f$）。'
};

/* ============ 1-10 2物体（糸と滑車） ============ */
DEFS['m1-10'] = {
  id: 'm1-10', mode: 1, tab: '1-10 2物体（糸と滑車）',
  quizKey: 'v', quizName: 'A と B の $v$–$t$ 図（A が上る向きを正）',
  title: '1-10　なめらかな面の上の A を、つるした B が引く（滑車）',
  sub: 'なめらかな面（傾き $\\theta$）の上の A（質量 $m$）に軽い糸をつけ、なめらかに回る軽い滑車を通して、他端に B（質量 $M$）をつるす。' +
    '静かにはなすと B が下り、A は面にそって上る。<b>糸は伸びないので、A が上る速さと B が下りる速さは同じ</b>。' +
    '正の向きは「A が上る向き＝B が下りる向き」にそろえてとる。' + OBJCOL,
  cw: 560, ch: function (v) { return 340 + 90 * Math.abs(Math.sin(v.th * DEG)); },
  vis: ['F', 'Fm', 'Fc', 'V'], visDef: { F: true },
  signLabels: ['A が上る向き（B が下りる向き）を正', 'A が下る向き（B が上る向き）を正'],
  mainVars: ['th', 'm', 'M'], mainVarFocus: 'th',
  vars: [{ k: 'th', label: '面の傾き $\\theta$', unit: '°', min: 0, max: 45, step: 5, dec: 0, def: 0 }].concat(twoMassVars(1.0, 2.0)),
  toggles: [],
  actions: [
    { label: '水平にもどす（θ＝0°）', fn: function (s) { s.v.th = 0; }, is: function (v) { return v.th === 0; } },
    { label: '斜面にする（θ＝30°）', fn: function (s) { s.v.th = 30; }, is: function (v) { return v.th === 30; } },
    { label: 'つり合う直前にする', fn: function (s) { s.v.th = 30; s.v.m = 4; s.v.M = 2; },
      is: function (v) { return v.th === 30 && v.m === 4 && v.M === 2; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.th = 0; s.v.m = 1; s.v.M = 2; },
      is: function (v) { return v.th === 0 && v.m === 1 && v.M === 2; } }
  ],
  tEnd: function (v) { return P.m19.tEnd(v); },
  sample: function (v, t) { return P.m19.sample(v, t); },
  graphs: twoBodyGraphs('A が上った距離＝B が下りた距離',
    function (v, sg) {
      var a = P.m19.a(v) * sg;
      return ['x = v_0 t + \\tfrac{1}{2}a t^2', 'x = \\tfrac{1}{2}\\dfrac{(M - m\\sin\\theta)g}{m+M} t^2',
        'x = \\tfrac{1}{2}(' + fmt(a, 2) + ')t^2'];
    },
    function (v, sg) {
      var a = P.m19.a(v) * sg;
      return ['v = v_0 + at', 'v = \\dfrac{(M - m\\sin\\theta)g}{m+M} t', 'v = (' + fmt(a, 2) + ')t'];
    },
    function (v, sg) {
      var a = P.m19.a(v) * sg;
      return [EQM + '(m+M)a = Mg - mg\\sin\\theta', 'a = \\dfrac{(M - m\\sin\\theta)g}{m+M}',
        'a = ' + fmt(a, 2) + '\\ \\mathrm{m/s^2}'];
    }),
  draw: function (ctx, s, t, W, H) {
    var v = V(s), m = P.m19.sample(v, t);
    var th = v.th * DEG, ct = Math.cos(th), st2 = Math.sin(th);
    var pr = 11;
    var PX = W - 192, PY = 112;                         /* 滑車の中心（右に吹き出しの場所をあける） */
    var kA = mSize({ vars: [{ k: 'm', def: 1 }] }, { m: v.m });
    var bw = 32 * kA, bh = 23 * kA;
    /* 糸は「面と平行に進んで滑車の上がわに接し、上を通って向こう側へ回りこむ」。
       そうなるように、面（台）の高さと、台のはしの位置を滑車から決める。
       ・A の中心を通る線＝滑車の接線 → 面は滑車の中心から n 向きに (pr - bh/2)
       ・台のはしは滑車より (pr+4) だけ手前（＝滑車は台のはしからはみ出す） */
    var nx0 = -Math.sin(th), ny0 = -Math.cos(th);       /* 面から外（上）向き */
    var ux0 = -Math.cos(th), uy0 = Math.sin(th);        /* 面を下る向き */
    var arm = pr * 1.9;                                 /* 台のはしから滑車の中心までの長さ（支柱） */
    var cnX = PX + nx0 * (pr - bh / 2) + ux0 * arm;
    var cnY = PY + ny0 * (pr - bh / 2) + uy0 * arm;     /* 台のはし（面のいちばん高いところ） */
    /* B が下りるぶんの縦の余白から、1 m あたりの px を決める */
    var sc = clamp((H - cnY - 96) / (P.m19.LEN + 0.6), 24, 46);
    /* 面の横の広がり（下がりすぎないように制限する） */
    var HS = PX - 52;
    if (st2 > 1e-6) HS = Math.min(HS, (H - 48 - cnY) / Math.tan(th));
    var Dspan = Math.max(2.4, (HS / ct) / sc);          /* 面にそって見せる長さ [m] */
    var d0 = Math.max(1.0, Dspan - 1.8);               /* A のはじめの位置（滑車からの距離） */

    var ux = -ct, uy = st2;                             /* 滑車から下る向き（画面） */
    var nx = nx0, ny = ny0;                             /* 面から外（上）向き */
    var Lx = cnX + ux * Dspan * sc, Ly = cnY + uy * Dspan * sc;
    /* 面（ハッチは「台の内側」＝面のすぐ下に出す。
       hatchLine は「進む向きの右がわ」に引くので、下り坂の向きに引くと上に出てしまう。
       かならず「下 → 上（左から右）」の向きにわたすこと。 */
    hatchLine(ctx, Lx, Ly, cnX, cnY, 1);
    ctx.save(); ctx.strokeStyle = '#98a0a8'; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(cnX, cnY); ctx.lineTo(cnX, H - 22); ctx.lineTo(Lx, H - 22);
    ctx.lineTo(Lx, Ly); ctx.stroke(); ctx.restore();
    if (v.th > 0.5) angArc(ctx, Lx, Ly, 30, -th, 0, 'θ = ' + fmt(v.th, 0) + '°', -th * 0.45, 66);

    /* A：面の上を、滑車に向かって上っていく */
    var dA = Math.max(0.3, d0 - m.x);
    var cx = cnX + ux * dA * sc, cy = cnY + uy * dA * sc;      /* 面と接している点 */
    var ax = cx + nx * bh / 2, ay = cy + ny * bh / 2;          /* 物体の中心 */
    blockShape(ctx, ax, ay, th, bw, bh, '#e8eef5');
    label(ctx, 'A（' + fmt(v.m, 1) + ' kg）', ax + nx * 78, ay + ny * 78, { size: 11, bold: true });
    /* 糸（A の上側の面 → 滑車の接点）。面と平行で、滑車にちょうど接する */
    var atx = ax - ux * bw / 2, aty = ay - uy * bw / 2;        /* 糸と A が接する点 */
    var tgx = PX + nx * pr, tgy = PY + ny * pr;                /* 滑車の接点（A 側・上がわ） */
    string(ctx, atx, aty, tgx, tgy);
    /* 滑車と、つるした B。糸は滑車の上を通って、右がわ（PX+pr）へ回りこむ */
    stringArc(ctx, PX, PY, pr, Math.atan2(ny, nx), 0);         /* 滑車に巻きついた部分 */
    /* ★滑車は台のはしに「支柱」で取りつける★（教科書の図と同じ。宙に浮かせない） */
    ctx.save(); ctx.lineCap = 'round';
    ctx.strokeStyle = '#5b6672'; ctx.lineWidth = 9;
    ctx.beginPath(); ctx.moveTo(cnX, cnY); ctx.lineTo(PX, PY); ctx.stroke();
    ctx.strokeStyle = '#e3e9ef'; ctx.lineWidth = 5;
    ctx.beginPath(); ctx.moveTo(cnX, cnY); ctx.lineTo(PX, PY); ctx.stroke();
    ctx.restore();
    pulley(ctx, PX, PY, pr);
    var yB0 = PY + 62, yB = yB0 + m.x * sc;
    var kB = mSize({ vars: [{ k: 'm', def: 2 }] }, { m: v.M });
    var rB = 14 * kB;
    string(ctx, PX + pr, PY, PX + pr, yB - rB);
    ball(ctx, PX + pr, yB, rB, 'B');
    label(ctx, 'B（' + fmt(v.M, 1) + ' kg）', PX + pr - rB - 10, yB - 6, { size: 11, bold: true, align: 'right' });
    if (t < 0.34) {              /* 下から支えていた手が、下へ抜けて消える */
      var hp = clamp((t - 0.08) / 0.22, 0, 1), fa = 1 - hp;
      if (fa > 0.02) {
        ctx.save(); ctx.globalAlpha = fa;
        handUnder(ctx, PX + pr, yB + rB + 2 + hp * 34, 0.7);
        ctx.restore();
      }
    }
    /* 動かす前だけ「支えている手を放す」と出す（スタートを押すと消える） */
    if (t <= 1e-9) releaseHint(ctx, PX + pr, yB + rB + 2, W);

    if (s.o.showF || s.o.showFm) {
      var only = !!s.o.showFm;                    /* 運動の向きの力だけを描くか */
      var fs = 46 / Math.max(1, G * Math.max(v.m, v.M)), Tn = m.T;
      /* B：張力と重力 */
      arrow(ctx, PX + pr, yB - rB, PX + pr, yB - rB - Tn * fs, 'force', 1, fcol('B', COL.hand));
      label(ctx, 'B：T = ' + fmt(Tn, 2) + ' N', PX + pr + 10, yB - rB - Tn * fs - 8,
        { size: 11, color: fcol('B', COL.hand), align: 'left' });
      arrow(ctx, PX + pr, yB, PX + pr, yB + v.M * G * fs, 'force', 1, fcol('B', COL.force));
      label(ctx, 'B：Mg', PX + pr - 12, yB + v.M * G * fs - 6,
        { size: 11, color: fcol('B', COL.force), align: 'right' });
      /* A：張力（面にそって上向き）・重力・垂直抗力 */
      arrow(ctx, atx, aty, atx - ux * Tn * fs, aty - uy * Tn * fs, 'force', 1, fcol('A', COL.hand));
      label(ctx, 'A：T', atx - ux * Tn * fs + nx * 13, aty - uy * Tn * fs + ny * 13,
        { size: 11, color: fcol('A', COL.hand), align: 'center' });
      if (!only) {
        arrow(ctx, ax, ay, ax, ay + v.m * G * fs, 'force', 1, fcol('A', COL.force));
        label(ctx, 'A：mg', ax + 13, ay + v.m * G * fs + 6, { size: 11, color: fcol('A', COL.force), align: 'left' });
        var Nn = v.m * G * ct;
        arrow(ctx, cx, cy, cx + nx * Nn * fs, cy + ny * Nn * fs, 'force', 1, fcol('A', COL.norm));
        label(ctx, 'A：N', cx + nx * Nn * fs - 8, cy + ny * Nn * fs - 10, { size: 11, color: fcol('A', COL.norm), align: 'right' });
      } else if (v.th > 0.5) {
        /* 運動の向き（面にそう向き）の成分だけを描く */
        var gsn0 = v.m * G * st2;
        arrow(ctx, ax, ay, ax + ux * gsn0 * fs, ay + uy * gsn0 * fs, 'force', 1, fcol('A', COL.force));
        label(ctx, 'A：mg sinθ = ' + fmt(gsn0, 2) + ' N', ax + ux * gsn0 * fs - 10, ay + uy * gsn0 * fs + 16,
          { size: 10.5, color: fcol('A', COL.force), align: 'right' });
      }
    }
    if (s.o.showFc && v.th > 0.5) {
      var fs2 = 46 / Math.max(1, G * Math.max(v.m, v.M)), gsn = v.m * G * st2;
      arrow(ctx, ax, ay, ax + ux * gsn * fs2, ay + uy * gsn * fs2, 'comp', 1, fcol('A', COL.force));
      label(ctx, 'A：mg sinθ', ax + ux * gsn * fs2 - 10, ay + uy * gsn * fs2 + 16,
        { size: 10.5, color: fcol('A', COL.force), align: 'right' });
    }
    if (s.o.showV && Math.abs(m.v) > 0.05) {
      var vl = 14 + 34 * Math.min(1, Math.abs(m.v) / 6), sg2 = m.v > 0 ? 1 : -1;
      var vax = ax + nx * 44, vay = ay + ny * 44;
      arrow(ctx, vax, vay, vax - ux * vl * sg2, vay - uy * vl * sg2, 'vel');
      arrow(ctx, PX + pr + 34, yB, PX + pr + 34, yB + vl * sg2, 'vel');
      label(ctx, 'v = ' + fmt(m.v * s.sign, 2) + ' m/s', PX + pr + 40, yB + vl * sg2 * 0.5 + 14,
        { size: 11, color: COL.vel, align: 'left' });
    }
    if (hintOn(s, t)) {
      label(ctx, '糸でつながっているので、A が上る速さ＝B が下りる速さ', 12, H - 36,
        { size: 11.5, bold: true, color: COL.acc, align: 'left' });
    }
    label(ctx, 't = ' + fmt(t, 2) + ' s', W - 10, 18, { align: 'right', size: 13.5, bold: true });
    drawPosNote(ctx, DEFS['m1-10'], s, W, 36);
  },
  info: function (s, t) {
    var v = V(s), m = P.m19.sample(v, t), th = v.th * DEG;
    return [
      ['加速度 $a$（A・B 共通）', fmt(m.a * s.sign, 2) + ' m/s²'],
      ['糸の張力 $T$', fmt(m.T, 2) + ' N'],
      ['B にはたらく重力 $Mg$', fmt(v.M * G, 2) + ' N'],
      ['重力の面にそった成分 $mg\\sin\\theta$', fmt(v.m * G * Math.sin(th), 2) + ' N'],
      ['速さ $v$', fmt(m.v * s.sign, 2) + ' m/s'],
      ['進んだ距離 $x$', fmt(m.x * s.sign, 2) + ' m']
    ];
  },
  eqHead: '運動方程式をたてると',
  eq: function (s) {
    var v = V(s), a = P.m19.a(v), T = P.m19.T(v), th = v.th * DEG;
    var sinTxt = (v.th < 0.5) ? '' : ' - mg\\sin\\theta';
    return twoBodyEq([
      '&\\text{A について}&& ma = T' + sinTxt,
      '&\\text{B について}&& Ma = Mg - T',
      '&\\text{辺々たすと}&& (m+M)a = Mg' + (v.th < 0.5 ? '' : ' - mg\\sin\\theta') +
        ' \\;\\Rightarrow\\; a = \\dfrac{' + fmt(v.M * G, 2) + (v.th < 0.5 ? '' : ' - ' + fmt(v.m * G * Math.sin(th), 2)) +
        '}{' + fmt(v.m + v.M, 1) + '} = ' + fmt(a, 2) + '\\ \\mathrm{m/s^2}',
      '&\\text{B の式にもどして}&& T = M(g-a) = ' + fmt(v.M, 1) + '(9.80-' + fmt(a, 2) + ') = ' + fmt(T, 2) + '\\ \\mathrm{N}'
    ]);
  },
  note: '<b>張力 T は「B にはたらく重力 Mg」より必ず小さい</b>。もし $T = Mg$ なら B はつり合って動かないはずだから。' +
    '面を傾けていくと $mg\\sin\\theta$ が大きくなり、$M = m\\sin\\theta$ になったところで $a = 0$（動かない）。' +
    'それより傾けると A のほうが下りる（$a$ が負になる）。'
};

/* ============ 1-11 2物体（アトウッドの装置） ============ */
DEFS['m1-11'] = {
  id: 'm1-11', mode: 1, tab: '1-11 2物体（アトウッド）',
  quizKey: 'v', quizName: 'A と B の $v$–$t$ 図（B が下りる向きを正）',
  title: '1-11　アトウッドの装置（滑車の両側におもり）',
  sub: 'なめらかに回る軽い滑車に軽い糸をかけ、両端に A（質量 $m$）と B（質量 $M$）をつるす。$m < M$ なので、' +
    '静かにはなすと <b>B が下り、A が上る</b>。糸は伸びないので<b>2つの速さは同じ</b>。' +
    '正の向きは「B が下りる向き＝A が上る向き」にそろえてとる。' + OBJCOL,
  cw: 500, ch: 344,
  vis: ['F', 'Fm', 'V'], visDef: { F: true },
  signLabels: ['B が下りる向き（A が上る向き）を正', 'B が上る向き（A が下りる向き）を正'],
  mainVars: ['m', 'M'], mainVarFocus: 'M',
  vars: twoMassVars(1.0, 3.0),
  toggles: [],
  actions: [
    { label: '質量差を小さくする（m＝2.5, M＝3）', fn: function (s) { s.v.m = 2.5; s.v.M = 3; },
      is: function (v) { return v.m === 2.5 && v.M === 3; } },
    { label: '同じ質量にする（動かない）', fn: function (s) { s.v.m = 3; s.v.M = 3; }, is: function (v) { return v.m === v.M; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.m = 1; s.v.M = 3; },
      is: function (v) { return v.m === 1 && v.M === 3; } }
  ],
  tEnd: function (v) { return P.m110.tEnd(v); },
  sample: function (v, t) { return P.m110.sample(v, t); },
  graphs: twoBodyGraphs('B が下りた距離＝A が上った距離',
    function (v, sg) {
      var a = P.m110.a(v) * sg;
      return ['x = v_0 t + \\tfrac{1}{2}a t^2', 'x = \\tfrac{1}{2}\\dfrac{(M-m)g}{M+m} t^2', 'x = \\tfrac{1}{2}(' + fmt(a, 2) + ')t^2'];
    },
    function (v, sg) {
      var a = P.m110.a(v) * sg;
      return ['v = v_0 + at', 'v = \\dfrac{(M-m)g}{M+m} t', 'v = (' + fmt(a, 2) + ')t'];
    },
    function (v, sg) {
      var a = P.m110.a(v) * sg;
      return [EQM + '(m+M)a = (M-m)g', 'a = \\dfrac{M-m}{M+m}\\,g',
        'a = \\dfrac{' + fmt(v.M - v.m, 1) + '}{' + fmt(v.M + v.m, 1) + '}\\times 9.80 = ' + fmt(a, 2) + '\\ \\mathrm{m/s^2}'];
    }),
  draw: function (ctx, s, t, W, H) {
    var v = V(s), m = P.m110.sample(v, t);
    var PX = W * 0.5, PY = 108, pr = 22, sc = 44;
    /* 天井 */
    ctx.save();
    ctx.fillStyle = '#c9d2da'; ctx.fillRect(W * 0.5 - 110, 56, 220, 10);
    ctx.strokeStyle = '#8b949e'; ctx.lineWidth = 1.4;
    ctx.strokeRect(W * 0.5 - 110, 56, 220, 10);      /* 天井は板だけ（ハッチは出さない） */
    ctx.restore();
    ctx.save(); ctx.strokeStyle = '#5b6672'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(PX, 66); ctx.lineTo(PX, PY - pr); ctx.stroke(); ctx.restore();
    pulley(ctx, PX, PY, pr);

    var kA = mSize({ vars: [{ k: 'm', def: 1 }] }, { m: v.m });
    var kB = mSize({ vars: [{ k: 'm', def: 3 }] }, { m: v.M });
    var rA = 15 * kA, rB = 15 * kB;
    var yA0 = PY + 152, yB0 = PY + 96;
    var yA = yA0 - m.x * sc, yB = yB0 + m.x * sc;
    string(ctx, PX - pr, PY, PX - pr, yA - rA);
    string(ctx, PX + pr, PY, PX + pr, yB - rB);
    ball(ctx, PX - pr, yA, rA, 'A');
    label(ctx, 'A（' + fmt(v.m, 1) + ' kg）', PX - pr - rA - 44, yA + 18, { size: 11, bold: true, align: 'right' });
    ball(ctx, PX + pr, yB, rB, 'B');
    label(ctx, 'B（' + fmt(v.M, 1) + ' kg）', PX + pr + rB + 30, yB, { size: 11, bold: true, align: 'left' });
    if (t < 0.34) {              /* 下から支えていた手が、下へ抜けて消える */
      var hp = clamp((t - 0.08) / 0.22, 0, 1), fa = 1 - hp;
      if (fa > 0.02) {
        ctx.save(); ctx.globalAlpha = fa;
        handUnder(ctx, PX + pr, yB + rB + 2 + hp * 34, 0.7);
        ctx.restore();
      }
    }
    /* 動かす前だけ「支えている手を放す」と出す（スタートを押すと消える） */
    if (t <= 1e-9) releaseHint(ctx, PX + pr, yB + rB + 2, W, 46);
    if (s.o.showF || s.o.showFm) {     /* この図の力はすべて運動の向き（鉛直）にそっている */
      var fs = 42 / Math.max(1, v.M * G), Tn = m.T;
      arrow(ctx, PX - pr, yA - rA, PX - pr, yA - rA - Tn * fs, 'force', 1, fcol('A', COL.hand));
      label(ctx, 'A：T = ' + fmt(Tn, 2) + ' N', PX - pr - 10, yA - rA - Tn * fs + 8,
        { size: 11, color: fcol('A', COL.hand), align: 'right' });
      arrow(ctx, PX - pr, yA, PX - pr, yA + v.m * G * fs, 'force', 1, fcol('A', COL.force));
      label(ctx, 'A：mg', PX - pr - 10, yA + v.m * G * fs - 6,
        { size: 11, color: fcol('A', COL.force), align: 'right' });
      arrow(ctx, PX + pr, yB - rB, PX + pr, yB - rB - Tn * fs, 'force', 1, fcol('B', COL.hand));
      label(ctx, 'B：T = ' + fmt(Tn, 2) + ' N', PX + pr + 10, yB - rB - Tn * fs + 8,
        { size: 11, color: fcol('B', COL.hand), align: 'left' });
      arrow(ctx, PX + pr, yB, PX + pr, yB + v.M * G * fs, 'force', 1, fcol('B', COL.force));
      label(ctx, 'B：Mg = ' + fmt(v.M * G, 1) + ' N', PX + pr + 10, yB + v.M * G * fs - 6,
        { size: 11, color: fcol('B', COL.force), align: 'left' });
    }
    if (s.o.showV && Math.abs(m.v) > 0.05) {
      var vl = 14 + 34 * Math.min(1, Math.abs(m.v) / 6), sg2 = m.v > 0 ? 1 : -1;
      arrow(ctx, PX - pr - 34, yA, PX - pr - 34, yA - vl * sg2, 'vel');
      arrow(ctx, PX + pr + 34, yB, PX + pr + 34, yB + vl * sg2, 'vel');
      label(ctx, 'v = ' + fmt(m.v * s.sign, 2) + ' m/s', W - 10, H - 14, { size: 11, color: COL.vel, align: 'right' });
    }
    if (hintOn(s, t)) {
      if (Math.abs(v.M - v.m) < 1e-9) {
        label(ctx, '質量が同じなので合力 0 → 動かない', 12, H - 12, { size: 12, bold: true, color: COL.acc, align: 'left' });
      } else {
        label(ctx, '重いほうが下り、軽いほうが上る', 12, H - 12,
          { size: 11.5, bold: true, color: COL.acc, align: 'left' });
      }
    }
    label(ctx, 't = ' + fmt(t, 2) + ' s', W - 10, 18, { align: 'right', size: 13.5, bold: true });
    drawPosNote(ctx, DEFS['m1-11'], s, W, 36);
  },
  info: function (s, t) {
    var v = V(s), m = P.m110.sample(v, t);
    return [
      ['加速度 $a$（A・B 共通）', fmt(m.a * s.sign, 2) + ' m/s²'],
      ['$a$ と $g$ の比', fmt(m.a / G, 3) + ' 倍'],
      ['糸の張力 $T$', fmt(m.T, 2) + ' N'],
      ['$mg$（A）／$Mg$（B）', fmt(v.m * G, 1) + ' ／ ' + fmt(v.M * G, 1) + ' N'],
      ['速さ $v$', fmt(m.v * s.sign, 2) + ' m/s'],
      ['進んだ距離 $x$', fmt(m.x * s.sign, 2) + ' m']
    ];
  },
  eqHead: '運動方程式をたてると',
  eq: function (s) {
    var v = V(s), a = P.m110.a(v), T = P.m110.T(v);
    return twoBodyEq([
      '&\\text{A（上る）について}&& ma = T - mg',
      '&\\text{B（下りる）について}&& Ma = Mg - T',
      '&\\text{辺々たすと}&& (m+M)a = (M-m)g \\;\\Rightarrow\\; a = \\dfrac{M-m}{M+m}g = \\dfrac{' +
        fmt(v.M - v.m, 1) + '}{' + fmt(v.M + v.m, 1) + '}\\times 9.80 = ' + fmt(a, 2) + '\\ \\mathrm{m/s^2}',
      '&\\text{A の式にもどして}&& T = m(g+a) = ' + fmt(v.m, 1) + '(9.80+' + fmt(a, 2) + ') = ' + fmt(T, 2) + '\\ \\mathrm{N}'
    ]);
  },
  note: '<b>加速度は必ず $g$ より小さい</b>（$a = \\dfrac{M-m}{M+m}g$ で、分数は 1 より小さい）。' +
    '質量差を小さくするほど $a$ は小さくなり、運動がゆっくりになる。' +
    '$T$ は $mg$ より大きく $Mg$ より小さい——そうでないと A が上り B が下りることにならない。',
  long: '<h3>ミニコラム：アトウッドの装置</h3>' +
    '<p>この装置は、1784 年にイギリスのケンブリッジ大学の数学者 <b>ジョージ・アトウッド</b>（George Atwood, 1745–1807）が、' +
    '力学の講義で使うために考えたものです。目的はただひとつ、<b>「重力による運動を、ゆっくりにして見せる」</b>ことでした。</p>' +
    '<p>自由落下は加速度が 9.8 m/s² もあります。1 秒で 4.9 m も落ちてしまうので、' +
    '振り子時計しかなかった 18 世紀には、落ちる時間や距離を手で測るのはほとんど不可能でした。' +
    'ところが滑車の両側に近い質量のおもりをつるすと、加速度は</p>' +
    '<p class="tex">a = \\dfrac{M-m}{M+m}\\,g</p>' +
    '<p>となり、たとえば $M=1.02$ kg・$m=1.00$ kg なら $a$ は $g$ の約 1/100、つまり 0.1 m/s² ほどまで下がります。' +
    'これなら目と耳で追える速さです。アトウッドはこの装置に振り子時計と目盛り板を組み合わせ、' +
    '<b>「速度は時間に比例する」「距離は時間の2乗に比例する」</b>というガリレオ以来の等加速度運動の法則を、' +
    '教室で目の前で確かめてみせました。ニュートンの『プリンキピア』が出てからちょうど100年後のことです。</p>' +
    '<p>物理としての要点は<b>「動かす力は $(M-m)g$ なのに、動かされる質量は $M+m$ だ」</b>というところにあります。' +
    '重力がはたらいているのは差の分だけなのに、加速されるのは2つ合わせた全部。' +
    'だから $a$ は必ず $g$ より小さくなります。これは運動方程式 $ma=F$ の意味そのものを見せてくれる、よくできた仕掛けです。</p>' +
    '<p>いまでも高校・大学の実験室でよく使われていて、$g$ の測定や、糸の張力の確認、' +
    '「軽い糸・軽い滑車」という理想化がどれくらい成り立つかを調べる題材になっています。</p>' +
    '<p class="src">※ おもりや糸の質量、滑車の慣性や摩擦は 0 として単純化しています。実際の実験では、これらのずれが測定値に効いてきます。</p>'
};

/* ============ 1-12 2物体（板と、その上にのる物体） ============ */
DEFS['m1-12'] = {
  id: 'm1-12', mode: 1, tab: '1-12 2物体（板の上）',
  quizKey: 'v', quizName: '板 A と物体 B の $v$–$t$ 図（右向きが正）',
  title: '1-12　なめらかな床の上の板とその上で滑る物体',
  sub: '水平でなめらかな床の上に板 A（質量 $M$）を置き、その上に物体 B（質量 $m$）をのせる。' +
    '<b>摩擦があるのは A と B のあいだだけ</b>（床はなめらか）。B が A の上をすべるとき、' +
    'B にはたらく動摩擦力は「A が B に対して動く向き」、A にはその<b>反対向き</b>にはたらく（作用・反作用）。' +
    '<b>A と B は加速度がちがう</b>ので、x・v・a のグラフは2本ずつ重ねて描いてある。' +
    '板の長さは ' + fmt(P.m111.LB, 1) + ' m で、B ははじめ板のまん中にのっている。' +
    '<b>板の半分（' + fmt(P.m111.LB / 2, 2) + ' m）だけすべると B は板から落ちて、水平投射になる。</b>' + OBJCOL,
  cw: 520, ch: 264,
  vis: ['F', 'Fm', 'V'], visDef: { F: true },
  signLabels: ['右向きを正', '左向きを正'],
  mainVars: ['FA', 'mus', 'mud'], mainVarFocus: 'FA',
  vars: [
    { k: 'FA', label: 'A を引く力 $F_A$', unit: ' N', min: 0, max: 40, step: 1, dec: 0, def: 26 },
    { k: 'FB', label: 'B を引く力 $F_B$', unit: ' N', min: 0, max: 40, step: 1, dec: 0, def: 0 },
    { k: 'vA0', label: 'A の初速度', unit: ' m/s', min: 0, max: 8, step: 0.5, dec: 1, def: 0 },
    { k: 'vB0', label: 'B の初速度', unit: ' m/s', min: 0, max: 8, step: 0.5, dec: 1, def: 0 },
    { k: 'mud', label: 'A と B の動摩擦係数 $\\mu\'$', unit: '', min: 0.05, max: 0.8, step: 0.05, dec: 2, def: 0.25 },
    { k: 'mus', label: 'A と B の静止摩擦係数 $\\mu$', unit: '', min: 0.05, max: 0.8, step: 0.05, dec: 2, def: 0.50 },
    { k: 'mA', label: '板 A の質量 $M$', unit: ' kg', min: 1, max: 8, step: 0.5, dec: 1, def: 3.0 },
    { k: 'mB', label: '物体 B の質量 $m$', unit: ' kg', min: 0.5, max: 6, step: 0.5, dec: 1, def: 2.0 }
  ],
  toggles: [],
  actions: [
    /* 「すべる」と「一体」は、引く力が最大静止摩擦 μg(M+m) をこえるかどうかのちがい。
       ボタンが濃くなる条件も「実際にすべるかどうか」で判定する。 */
    { label: '板 A を引く（すべる）', fn: function (s) { s.v.FA = 26; s.v.FB = 0; s.v.vA0 = 0; s.v.vB0 = 0; },
      is: function (v) {
        return v.FA > 0 && v.FB === 0 && v.vA0 === 0 && v.vB0 === 0 && P.m111.acc(v, 0, 0).slip;
      } },
    { label: '板 A を引く（一体）', fn: function (s) { s.v.FA = 18; s.v.FB = 0; s.v.vA0 = 0; s.v.vB0 = 0; },
      is: function (v) {
        return v.FA > 0 && v.FB === 0 && v.vA0 === 0 && v.vB0 === 0 && !P.m111.acc(v, 0, 0).slip;
      } },
    { label: '物体 B に初速度を与える', fn: function (s) { s.v.FA = 0; s.v.FB = 0; s.v.vA0 = 0; s.v.vB0 = 2.5; },
      is: function (v) { return v.FA === 0 && v.FB === 0 && v.vA0 === 0 && v.vB0 > 0; } },
    { label: '板 A に初速度を与える', fn: function (s) { s.v.FA = 0; s.v.FB = 0; s.v.vB0 = 0; s.v.vA0 = 2.5; },
      is: function (v) { return v.FA === 0 && v.FB === 0 && v.vB0 === 0 && v.vA0 > 0; } },
    { label: 'はじめの設定にもどす',
      fn: function (s) { s.v.FA = 26; s.v.FB = 0; s.v.vA0 = 0; s.v.vB0 = 0; s.v.mud = 0.25; s.v.mus = 0.5; s.v.mA = 3; s.v.mB = 2; },
      is: function (v) { return v.FA === 26 && v.FB === 0 && v.vA0 === 0 && v.vB0 === 0 && v.mud === 0.25 && v.mus === 0.5 && v.mA === 3 && v.mB === 2; } }
  ],
  tEnd: function (v) { return P.m111.tEnd(v); },
  sample: function (v, t) { return P.m111.sample(v, t); },
  graphs: [
    { key: 'x', short: '$x$–$t$ 図', title: '$x$–$t$ 図（位置）', ylabel: 'x [m]', open: false, signed: true, legend: true,
      series: [{ color: COL.A, name: '板 A', f: function (mm) { return mm.xA; } },
        { color: COL.B, name: '物体 B', f: function (mm) { return mm.xB; } }],
      fml: function (v, sg) {
        var q = P.m111.acc(v, v.vA0, v.vB0);
        return ['x = v_0 t + \\tfrac{1}{2}a t^2',
          '\\text{A: } x_A = v_{A0}t + \\tfrac{1}{2}a_A t^2 \\quad \\text{B: } x_B = v_{B0}t + \\tfrac{1}{2}a_B t^2',
          '\\text{A: } ' + fmt(v.vA0 * sg, 1) + 't + \\tfrac{1}{2}(' + fmt(q.aA * sg, 2) + ')t^2 \\quad \\text{B: } ' +
            fmt(v.vB0 * sg, 1) + 't + \\tfrac{1}{2}(' + fmt(q.aB * sg, 2) + ')t^2'];
      } },
    { key: 'v', short: '$v$–$t$ 図', title: '$v$–$t$ 図（速度）　※色をつけた部分の面積＝B が A に対してすべった距離', ylabel: 'v [m/s]', open: true, signed: true, legend: true,
      band: { i: 0, j: 1, color: 'rgba(224,123,24,.20)' },
      series: [{ color: COL.A, name: '板 A', f: function (mm) { return mm.vA; } },
        { color: COL.B, name: '物体 B', f: function (mm) { return mm.vB; } }],
      fml: function (v, sg) {
        var q = P.m111.acc(v, v.vA0, v.vB0);
        return ['v = v_0 + at',
          '\\text{A: } v_A = v_{A0} + a_A t \\quad \\text{B: } v_B = v_{B0} + a_B t',
          '\\text{A: } ' + fmt(v.vA0 * sg, 1) + ' + (' + fmt(q.aA * sg, 2) + ')t \\quad \\text{B: } ' +
            fmt(v.vB0 * sg, 1) + ' + (' + fmt(q.aB * sg, 2) + ')t'];
      },
      fnote: function (v, s2) {
        var ts = P.m111.tStick(v), tfl = P.m111.tFall(v);
        var m2 = P.m111.sample(v, isFinite(ts) ? ts : P.m111.tEnd(v));
        if (!P.m111.acc(v, v.vA0, v.vB0).slip) {         /* はじめから一体で動く */
          return '<b>2本の線がぴったり重なっている ＝ すべっていない。</b>' +
            '引く力が最大静止摩擦 $\\mu g(M+m)$＝<b>' + fmt((v.mus || 0) * G * (v.mA + v.mB), 1) +
            ' N</b> をこえていないので、<b>静止摩擦力</b>が B をいっしょに運び、A と B は一体で動く。';
        }
        if (isFinite(tfl)) {
          return '<b>2本の線ではさまれた面積 ＝ B が A に対してすべった距離。</b>' +
            '（速度の差を時間でたし合わせたものが、位置の差になる）<br>' +
            'すべった距離が板の半分（<b>' + fmt(P.m111.LB / 2, 2) + ' m</b>）になる <b>' + fmt(tfl, 2) +
            ' s</b> で、B は板からすべり落ちる。そのあとは B は水平投射になり、' +
            'なめらかな床の上を<b>そのままの速さ</b>で進む（水平の線）。板 A は B の摩擦がなくなるぶん、急に速くなる。';
        }
        return '<b>2本の線ではさまれた面積 ＝ B が A に対してすべった距離。</b>' +
          '（速度の差を時間でたし合わせたものが、位置の差になる）<br>' +
          (isFinite(ts)
            ? '速さがそろうのは <b>' + fmt(ts, 2) + ' s</b>。そこまでにすべる距離は <b>' + fmt(Math.abs(m2.slid), 2) +
              ' m</b> で、そのあとは2つがいっしょに動くので面積は増えない。'
            : '力をかけ続けているあいだ、速さの差は開いていく（面積はふえ続ける）。');
      } },
    { key: 'a', short: '$a$–$t$ 図', title: '$a$–$t$ 図（加速度）　※ a の運動方程式による導出', ylabel: 'a [m/s²]', open: false, signed: true, legend: true,
      series: [{ color: COL.A, name: '板 A', f: function (mm) { return mm.aA; } },
        { color: COL.B, name: '物体 B', f: function (mm) { return mm.aB; } }],
      fml: function (v, sg) {
        var q = P.m111.acc(v, v.vA0, v.vB0);
        return [EQM + 'ma = F_{\\text{合力}}',
          '\\text{A: } Ma_A = F_A - \\mu\' mg \\quad \\text{B: } ma_B = F_B + \\mu\' mg',
          '\\text{A: } a_A = ' + fmt(q.aA * sg, 2) + ' \\quad \\text{B: } a_B = ' + fmt(q.aB * sg, 2) + '\\ \\mathrm{m/s^2}'];
      } }
  ],
  draw: function (ctx, s, t, W, H) {
    var v = V(s), m = P.m111.sample(v, t), T = P.m111.tEnd(v);
    var gy = H - 76, i;
    var xmax = 0.6;
    for (i = 0; i <= 40; i++) {
      var q = P.m111.sample(v, T * i / 40);
      xmax = Math.max(xmax, q.xA + P.m111.LB / 2, q.xB);
    }
    var sc = Math.min(52, (W - 250) / Math.max(1, xmax));
    var X = function (x) { return 78 + x * sc; };
    ground(ctx, 10, W - 10, gy);
    axisX(ctx, X, gy + 44, 0, xmax + 0.5, 'x [m]', s.sign, { target: 5 });
    originMark(ctx, X(0), gy + 44, -12, 13);

    /* 板の長さは決まっている（P.m111.LB）。B ははじめ、板のまん中にのっている */
    var ph = 30, pw = P.m111.LB * sc;
    var kB = mSize({ vars: [{ k: 'm', def: 1 }] }, { m: v.mB });
    var bw = 34 * kB, bh = 26 * kB;
    var pxA = X(m.xA), pxB = X(m.xB);
    /* B の高さ。板の上にいるあいだは板の上面、落ちたら床に向かって落ちていく */
    var byTop = gy - ph * clamp((m.yB === undefined ? P.m111.HB : m.yB) / P.m111.HB, 0, 1);
    plank(ctx, pxA, gy - ph, pw, ph);
    label(ctx, 'A（板 ' + fmt(v.mA, 1) + ' kg）', pxA - pw / 2, gy + 20, { size: 11, bold: true, align: 'left' });
    blockShape(ctx, pxB, byTop - bh / 2, 0, bw, bh, '#e3ecf6');
    label(ctx, 'B（' + fmt(v.mB, 1) + ' kg）', pxB, byTop - bh - 30, { size: 11, bold: true });

    /* 引く手／デコピン */
    if (v.FA > 0.5) {
      var hax = pxA + pw / 2 + 3, hay = gy - ph / 2;
      string(ctx, hax, hay, hax + 26, hay);
      hand(ctx, hax + 26, hay, 0);
    }
    if (v.FB > 0.5) {
      var hbx = pxB + bw / 2 + 3, hby = byTop - bh / 2;
      string(ctx, hbx, hby, hbx + 26, hby);
      hand(ctx, hbx + 26, hby, 0);
    }
    if (t < 0.34 && v.FA < 0.5 && v.FB < 0.5) {          /* 初速度はデコピンで与えたことにする */
      var fk = clamp(t / 0.10, 0, 1);
      var fa = (t <= 0.13) ? 1 : Math.max(0, 1 - (t - 0.13) / 0.18);
      var who = (v.vB0 > 0.01) ? 'B' : ((v.vA0 > 0.01) ? 'A' : null);
      if (who && fa > 0.02) {
        var fx = (who === 'B') ? X(0) - bw / 2 - 20 : X(0) - pw / 2 - 20;
        var fy = (who === 'B') ? gy - ph - bh / 2 : gy - ph / 2;
        flickHand(ctx, fx, fy, 0, fk, 1, 0.40, fa);
        ctx.save(); ctx.globalAlpha = fa;
        bubble(ctx, who + ' をデコピン！', clamp(fx + 10, 66, W - 66), Math.max(26, fy - 40),
          { size: 12, bg: '#fff5e8', border: '#e07b18', color: '#a85c0c' });
        ctx.restore();
      }
    }

    if (s.o.showF || s.o.showFm) {     /* この図の力はすべて運動の向き（水平）にそっている */
      var fmax = v.mud * v.mB * G, fs = 76 / Math.max(6, fmax, v.FA, v.FB);
      var fB = m.f;                                       /* B にはたらく摩擦（右が正） */
      /* ★摩擦力は「実際に動いて（あるいは動こうとして）から」出す★
         スタート前（t=0）から動摩擦の矢印が出ていると、
         「相対的にすべっているから動摩擦がはたらく」という順番が伝わらない。 */
      if (Math.abs(fB) > 0.05 && !m.fell && t > 1e-9) {
        /* ★作用・反作用なので作用点は同じ（A と B がふれあう面）★
           まったく同じ点だと2本が重なって見えないので、上下に 4 px だけずらして描く。 */
        var fpx = pxB, fpy = gy - ph;
        arrow(ctx, fpx, fpy - 4, fpx + fB * fs, fpy - 4, 'force', 1, fcol('B', COL.fric));
        label(ctx, 'B：' + (m.slip ? '動摩擦 ' : '静止摩擦 ') + fmt(Math.abs(fB), 2) + ' N',
          fpx + fB * fs + (fB > 0 ? 10 : -10), fpy - 9,
          { size: 10.5, color: fcol('B', COL.fric), align: fB > 0 ? 'left' : 'right' });
        arrow(ctx, fpx, fpy + 4, fpx - fB * fs, fpy + 4, 'force', 1, fcol('A', COL.fric));
        label(ctx, 'A：反作用', fpx - fB * fs - (fB > 0 ? 10 : -10), fpy + 15,
          { size: 10.5, color: fcol('A', COL.fric), align: fB > 0 ? 'right' : 'left' });
      }
      if (v.FA > 0.5) {
        arrow(ctx, pxA + pw / 2, gy - ph / 2, pxA + pw / 2 + v.FA * fs, gy - ph / 2, 'force', 1, fcol('A', COL.hand));
        label(ctx, 'A：F_A = ' + fmt(v.FA, 0) + ' N', pxA + pw / 2 + v.FA * fs + 8, gy - ph / 2 - 16,
          { size: 11, color: fcol('A', COL.hand), align: 'left' });
      }
      if (v.FB > 0.5) {
        arrow(ctx, pxB + bw / 2, byTop - bh / 2, pxB + bw / 2 + v.FB * fs, byTop - bh / 2, 'force', 1, fcol('B', COL.hand));
        label(ctx, 'B：F_B = ' + fmt(v.FB, 0) + ' N', pxB + bw / 2 + v.FB * fs + 8, byTop - bh / 2 - 16,
          { size: 11, color: fcol('B', COL.hand), align: 'left' });
      }
    }
    if (s.o.showV) {
      var vlen = function (x) { return 16 + 30 * Math.min(1, Math.abs(x) / 6); };
      if (Math.abs(m.vA) > 0.05) {
        arrow(ctx, pxA - pw / 2 + 12, gy - 8, pxA - pw / 2 + 12 + vlen(m.vA) * (m.vA > 0 ? 1 : -1), gy - 8, 'vel');
      }
      if (Math.abs(m.vB) > 0.05) {
        arrow(ctx, pxB, byTop - bh - 13, pxB + vlen(m.vB) * (m.vB > 0 ? 1 : -1), byTop - bh - 13, 'vel');
      }
      label(ctx, 'v_A = ' + fmt(m.vA * s.sign, 2) + '　v_B = ' + fmt(m.vB * s.sign, 2) + ' m/s',
        12, 74, { size: 11.5, color: COL.vel, align: 'left' });
    }
    if (hintOn(s, t)) {
      var msg2 = m.fell
        ? (m.air ? 'B は板からすべり落ちた → 水平投射（水平の速さはそのまま）' : 'B は床に着いた。床はなめらかなので等速で進む')
        : ((m.slip ? 'B は A の上をすべっている（動摩擦がはたらく）'
          : (Math.abs(m.slid) < 0.005 ? '静止摩擦力がはたらいて、A と B は一体で動く'
            : '速さがそろった → 2つはいっしょに動く')) +
          (Math.abs(m.slid) > 0.01 ? '　すべった距離 ' + fmt(Math.abs(m.slid), 2) + ' m' : ''));
      label(ctx, msg2, 12, 56, { size: 11.5, bold: true, color: COL.acc, align: 'left' });
    }
    label(ctx, 't = ' + fmt(t, 2) + ' s', W - 10, 18, { align: 'right', size: 13.5, bold: true });
    drawPosNote(ctx, DEFS['m1-12'], s, W, 36);
  },
  info: function (s, t) {
    var v = V(s), m = P.m111.sample(v, t);
    return [
      ['板 A の加速度 $a_A$', fmt(m.aA * s.sign, 2) + ' m/s²'],
      ['物体 B の加速度 $a_B$', fmt(m.aB * s.sign, 2) + ' m/s²'],
      ['A と B のあいだの摩擦力', fmt(Math.abs(m.f), 2) + ' N' + (m.slip ? '（動摩擦）' : '（静止摩擦）')],
      ['動摩擦力 $\\mu\' mg$ ／ 最大静止摩擦 $\\mu mg$',
        fmt(v.mud * v.mB * G, 2) + ' ／ ' + fmt((v.mus || 0) * v.mB * G, 2) + ' N'],
      ['速度 $v_A$ ／ $v_B$', fmt(m.vA * s.sign, 2) + ' ／ ' + fmt(m.vB * s.sign, 2) + ' m/s'],
      ['B が A に対してすべった距離', fmt(Math.abs(m.slid), 2) + ' m' +
        (m.fell ? '（板からすべり落ちた）' : '')]
    ];
  },
  eqHead: '運動方程式をたてると',
  eq: function (s) {
    var v = V(s), q = P.m111.acc(v, v.vA0, v.vB0), fmax = v.mud * v.mB * G;
    if (!q.slip) {
      return twoBodyEq([
        '&\\text{すべらないとき}&& \\text{A と B をひとまとめにして } (M+m)a = F_A + F_B',
        '&&& a = \\dfrac{' + fmt(v.FA + v.FB, 1) + '}{' + fmt(v.mA + v.mB, 1) + '} = ' + fmt(q.aA, 2) + '\\ \\mathrm{m/s^2}',
        '&\\text{B に必要な摩擦}&& f = ma - F_B = ' + fmt(Math.abs(q.f), 2) +
          '\\ \\mathrm{N} \\le \\mu mg = ' + fmt((v.mus || 0) * v.mB * G, 2) + '\\ \\mathrm{N}\\;(\\text{だからすべらない})'
      ]);
    }
    var sg = (q.f >= 0) ? '+' : '-';
    return twoBodyEq([
      '&\\text{B について}&& ma_B = F_B ' + sg + ' \\mu\' mg = ' + fmt(v.FB, 0) + ' ' + sg + ' ' + fmt(fmax, 2) +
        ' \\;\\Rightarrow\\; a_B = ' + fmt(q.aB, 2) + '\\ \\mathrm{m/s^2}',
      '&\\text{A について}&& Ma_A = F_A ' + (sg === '+' ? '-' : '+') + ' \\mu\' mg = ' + fmt(v.FA, 0) + ' ' +
        (sg === '+' ? '-' : '+') + ' ' + fmt(fmax, 2) + ' \\;\\Rightarrow\\; a_A = ' + fmt(q.aA, 2) + '\\ \\mathrm{m/s^2}',
      '&\\text{垂直抗力}&& N = mg = ' + fmt(v.mB * G, 2) + '\\ \\mathrm{N} \\;\\Rightarrow\\; \\mu\' N = ' +
        fmt(fmax, 2) + '\\ \\mathrm{N}',
      '&\\text{摩擦力は}&& \\text{B には A が動く向き、A にはその反対向き（作用・反作用）}'
    ]);
  },
  note: '<b>摩擦力の向きは「相手に対してどちらへ動いているか」で決まる。</b>' +
    'A を引くと A のほうが速くなるので、A から見て B は後ろへ下がる → B には<b>前向き</b>の摩擦、A には<b>後ろ向き</b>の摩擦。' +
    'B に初速度を与えたときは逆になる。<b>力をかけずに初速度だけ与えた場合</b>は、外から力がはたらかないので' +
    '<b>運動量 $Mv_A + mv_B$ が保存</b>し、やがて2つは同じ速さになってそのまま進む。'
};
