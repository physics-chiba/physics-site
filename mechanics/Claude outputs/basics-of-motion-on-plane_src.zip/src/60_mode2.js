/* 2　平面上の運動 */
'use strict';

/* 軌道の外接箱（余白つき） */
function trajBox(v, T, fn, extra) {
  var x0 = 0, x1 = 0, y0 = 0, y1 = 0, i;
  for (i = 0; i <= 120; i++) {
    var p = fn(v, T * i / 120);
    x0 = Math.min(x0, p.x); x1 = Math.max(x1, p.x);
    y0 = Math.min(y0, p.y); y1 = Math.max(y1, p.y);
  }
  (extra || []).forEach(function (p) {
    x0 = Math.min(x0, p.x); x1 = Math.max(x1, p.x);
    y0 = Math.min(y0, p.y); y1 = Math.max(y1, p.y);
  });
  var mx = Math.max(1.2, (x1 - x0) * 0.14), my = Math.max(1.2, (y1 - y0) * 0.18);
  return { x0: x0 - mx, x1: x1 + mx, y0: y0 - my, y1: y1 + my * 1.3 };
}

/* 軌道の線と残像 */
function drawTraj(ctx, vw, v, fn, T, tNow, dotStep) {
  var i;
  ctx.save();
  ctx.strokeStyle = '#c6ccd4'; ctx.setLineDash([4, 4]); ctx.lineWidth = 1.4;
  ctx.beginPath();
  for (i = 0; i <= 120; i++) {
    var p = fn(v, T * i / 120);
    if (i === 0) ctx.moveTo(vw.X(p.x), vw.Y(p.y)); else ctx.lineTo(vw.X(p.x), vw.Y(p.y));
  }
  ctx.stroke(); ctx.restore();
  ctx.save();
  ctx.strokeStyle = '#e07b18'; ctx.lineWidth = 2.4;
  ctx.beginPath();
  var n = Math.max(2, Math.round(120 * tNow / Math.max(1e-6, T)));
  for (i = 0; i <= n; i++) {
    var q = fn(v, tNow * i / n);
    if (i === 0) ctx.moveTo(vw.X(q.x), vw.Y(q.y)); else ctx.lineTo(vw.X(q.x), vw.Y(q.y));
  }
  ctx.stroke(); ctx.restore();
  if (dotStep) for (i = 1; i * dotStep < tNow - 1e-9; i++) {
    var r = fn(v, i * dotStep);
    ball(ctx, vw.X(r.x), vw.Y(r.y), 4.5, 'faint');
  }
}

/* 速度ベクトル。showV＝合成、showC＝分解（vx は明るい青、vy は緑がかった青） */
function drawVel(ctx, px, py, m, showV, showC, vref, names) {
  var L = 84 / Math.max(1e-6, vref);      /* px per (m/s) */
  var NX = (names && names[0]) || 'v_x', NY = (names && names[1]) || 'v_y';
  var ex = px + m.vx * L, ey = py - m.vy * L;
  if (showC) {
    ctx.save();
    ctx.setLineDash([3, 3]); ctx.strokeStyle = '#b9c1c9'; ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(px + m.vx * L, py); ctx.lineTo(ex, ey);
    ctx.moveTo(px, py - m.vy * L); ctx.lineTo(ex, ey);
    ctx.stroke(); ctx.restore();
    arrow(ctx, px, py, px + m.vx * L, py, 'velx');
    label(ctx, NX + ' = ' + fmt(m.vx, 1), px + m.vx * L * 0.55, py + (m.vy < 0 ? -13 : 15),
      { size: 12, color: COL.velx, bold: true });
    arrow(ctx, px, py, px, py - m.vy * L, 'vely');
    label(ctx, NY + ' = ' + fmt(m.vy, 1), px - 9, py - m.vy * L * 0.55,
      { size: 12, color: COL.vely, bold: true, align: 'right' });
  }
  if (showV) {
    arrow(ctx, px, py, ex, ey, 'vel');
    label(ctx, 'v = ' + fmt(Math.hypot(m.vx, m.vy), 1) + ' m/s', ex + 11, ey + (m.vy < 0 ? 12 : -12),
      { size: 12, color: COL.vel, align: 'left' });
  }
  /* 分解して見せるときは、vx の向きと v の向きがつくる角 θ′ を必ず書き入れる */
  if (showC) drawVelAngle(ctx, px, py, m, L);
}

/* vx の向きと、もとの速度 v の向きがなす角 θ′。
   「平面の運動は、水平と鉛直に分けて考える」ことを角でも見せるための共通部品。 */
function drawVelAngle(ctx, px, py, m, L) {
  var sp = Math.hypot(m.vx, m.vy);
  if (sp < 1e-6 || Math.abs(m.vx) < 1e-6 || Math.abs(m.vy) < 1e-6) return;
  var len = sp * L;
  if (len < 22) return;                       /* 矢印が短すぎるときは書かない */
  var sgx = m.vx >= 0 ? 1 : -1;
  var aX = (sgx > 0) ? 0 : Math.PI;           /* vx の向き（画面の角。y は下が正） */
  var aV = Math.atan2(-m.vy, m.vx);           /* v の向き（画面の角） */
  var r = clamp(len * 0.42, 13, 34);
  var am = (aX + aV) / 2;
  if (Math.abs(aV - aX) > Math.PI) am += Math.PI;   /* 短いほうの弧の真ん中 */
  angArc(ctx, px, py, r, aX, aV,
    'θ′ = ' + fmt(Math.abs(Math.atan2(m.vy, m.vx)) / DEG, 0) + '°', am, r + 22);
}

/* よく使う式（斜方投射） */
function projFml(v, sg, kind) {
  var vx = v.v0 * Math.cos(v.th * DEG), vy0 = v.v0 * Math.sin(v.th * DEG);
  if (kind === 'x') return ['x = v_x t \\;(\\text{等速})', 'x = v_0\\cos\\theta\\, t', 'x = ' + fmt(vx, 2) + 't'];
  if (kind === 'y') return ['y = v_{y0} t + \\tfrac{1}{2}a t^2', 'y = v_0\\sin\\theta\\, t - \\tfrac{1}{2}g t^2',
    'y = ' + fmt(vy0 * sg, 2) + 't + \\tfrac{1}{2}(' + fmt(-G * sg, 2) + ')t^2'];
  if (kind === 'vx') return ['v_x = \\text{一定}', 'v_x = v_0\\cos\\theta', 'v_x = ' + fmt(vx, 2) + '\\ \\mathrm{m/s}'];
  if (kind === 'vy') return ['v_y = v_{y0} + a t', 'v_y = v_0\\sin\\theta - g t',
    'v_y = ' + fmt(vy0 * sg, 2) + ' + (' + fmt(-G * sg, 2) + ')t'];
  return [EQM + 'ma = F \\;\\Rightarrow\\; a = \\dfrac{F}{m}',
    EQM + 'ma_y = -mg \\;\\Rightarrow\\; a_y = -g \\;(\\text{水平方向は }a_x=0)',
    'a_y = ' + fmt(-G * sg, 2) + '\\ \\mathrm{m/s^2}'];
}

/* ============ 2-1 ストロボ比較 ============ */
DEFS['m2-1'] = {
  id: 'm2-1', mode: 2, tab: '2-1 ストロボ比較',
  quizKey: 'v', quizName: '右の運動（平面内）の $v_y$–$t$ 図（鉛直方向）',
  title: '2-1　ストロボ写真でくらべる（運動の分解）',
  desc: '左と右で、同じ時刻の球の高さが「いつも同じ」ことを確かめよう。',
  sub: '平面内の運動は、水平方向（等速直線運動）と鉛直方向（等加速度運動）に分けて考えられる。ストロボの間隔を変えて、同じ高さを結ぶ線を見くらべよう。',
  cw: 560, ch: 380,
  vis: ['F', 'V', 'Vc'], visFlash: 'Vc',
  signLabels: ['上向きを正', '下向きを正'],
  mainVars: ['v0', 'th', 'dt'], mainOpts: true,
  vars: [
    { k: 'v0', label: '初速度 $v_0$', unit: ' m/s', min: 4, max: 24, step: 1, dec: 0, def: 12 },
    { k: 'th', label: '投射角 $\\theta$（右の運動）', unit: '°', min: 20, max: 80, step: 5, dec: 0, def: 60 },
    { k: 'dt', label: 'ストロボの間隔', unit: ' s', min: 0.1, max: 0.2, step: 0.05, dec: 2, def: 0.10 }
  ],
  toggles: [{ k: 'guide', label: '同じ高さを結ぶ線を表示', def: true }],
  selects: [{
    k: 'pair', label: '選択', def: 'A',
    options: [{ v: 'A', label: '自由落下 と 水平投射' }, { v: 'B', label: '鉛直投げ上げ と 斜方投射' }]
  }],
  tEnd: function (v) { return P.m21.tEnd(v); },
  sample: function (v, t) { return P.m21.sample(v, t); },
  graphs: [
    { key: 'y', short: '$y$–$t$ 図', title: '$y$–$t$ 図（2つの運動の高さ）', ylabel: 'y [m]', open: true, signed: true, legend: true,
      series: [
        { name: '左（鉛直だけ）', color: COL.ok, f: function (m) { return m.yL; } },
        { name: '右（平面内）', color: COL.acc, f: function (m) { return m.y; }, dash: [6, 4] }
      ],
      fml: function (v, sg) {
        var vy0 = (v.pair === 'A') ? 0 : v.v0 * Math.sin(v.th * DEG);
        return ['y = v_{y0} t + \\tfrac{1}{2}a t^2', 'y = v_0\\sin\\theta\\, t - \\tfrac{1}{2}g t^2',
          'y = ' + fmt(vy0 * sg, 2) + 't + \\tfrac{1}{2}(' + fmt(-G * sg, 2) + ')t^2\\;(\\text{左右とも同じ})'];
      } },
    { key: 'x', short: '$x$–$t$ 図', title: '$x$–$t$ 図（右の運動の水平位置）', ylabel: 'x [m]', open: false, signed: false,
      series: [{ color: COL.ink, f: function (m) { return m.x; } }],
      fml: function (v, sg) {
        var vx = (v.pair === 'A') ? v.v0 : v.v0 * Math.cos(v.th * DEG);
        return ['x = v_x t \\;(\\text{等速})', 'x = v_0\\cos\\theta\\, t', 'x = ' + fmt(vx, 2) + 't'];
      } },
    { key: 'v', short: '$v_y$–$t$ 図', title: '$v_y$–$t$ 図（鉛直方向の速度）', ylabel: 'vy [m/s]', open: false, signed: true,
      series: [{ color: COL.vel, f: function (m) { return m.vy; } }],
      fml: function (v, sg) {
        var vy0 = (v.pair === 'A') ? 0 : v.v0 * Math.sin(v.th * DEG);
        return ['v_y = v_{y0} + at', 'v_y = v_0\\sin\\theta - gt',
          'v_y = ' + fmt(vy0 * sg, 2) + ' + (' + fmt(-G * sg, 2) + ')t'];
      } },
    { key: 'a', short: '$a$–$t$ 図', title: '$a$–$t$ 図（鉛直方向の加速度）　※ a の運動方程式による導出', ylabel: 'a [m/s²]', open: false, signed: true,
      series: [{ color: COL.acc, f: function (m) { return m.a; } }],
      fml: function (v, sg) { return projFml(v, sg, 'a'); } }
  ],
  draw: function (ctx, s, t, W, H) {
    var v = V(s), T = P.m21.tEnd(v), i;
    var isA = v.pair === 'A';
    var yLo, yHi, xHi;
    if (isA) { yLo = -P.m21.DROP; yHi = 1.0; xHi = v.v0 * T * 1.05 + 1; }
    else {
      var yTop = Math.pow(v.v0 * Math.sin(v.th * DEG), 2) / (2 * G);
      yLo = -1.0; yHi = yTop + 1.5; xHi = v.v0 * Math.cos(v.th * DEG) * T * 1.05 + 1;
    }
    var padT = 52, padB = 22, lx0 = 10, lw = 108, gap = 10;
    var rx0 = lx0 + lw + gap, rw = W - rx0 - 10;
    var sc = Math.min((H - padT - padB) / (yHi - yLo), rw / Math.max(1e-6, xHi));
    function Y(y) { return H - padB - (y - yLo) * sc; }
    function XR(x) { return rx0 + 12 + x * sc; }
    var lcx = lx0 + lw / 2;

    ctx.save();
    ctx.fillStyle = '#0f1216';
    ctx.fillRect(lx0, padT, lw, H - padT - padB + 4);
    ctx.fillRect(rx0, padT, rw, H - padT - padB + 4);
    ctx.strokeStyle = 'rgba(255,255,255,.34)'; ctx.lineWidth = 1;
    var gs = niceStep(yHi - yLo, 8);
    for (i = Math.ceil(yLo / gs) * gs; i <= yHi + 1e-9; i += gs) {
      if (Y(i) < padT || Y(i) > H - padB + 4) continue;
      ctx.beginPath(); ctx.moveTo(lx0, Y(i)); ctx.lineTo(lx0 + lw, Y(i)); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(rx0, Y(i)); ctx.lineTo(rx0 + rw, Y(i)); ctx.stroke();
    }
    for (i = 0; XR(i) < rx0 + rw; i += gs) {
      ctx.beginPath(); ctx.moveTo(XR(i), padT); ctx.lineTo(XR(i), H - padB + 4); ctx.stroke();
    }
    for (i = -gs; lcx + i * sc > lx0; i -= gs) {
      ctx.beginPath(); ctx.moveTo(lcx + i * sc, padT); ctx.lineTo(lcx + i * sc, H - padB + 4); ctx.stroke();
    }
    for (i = gs; lcx + i * sc < lx0 + lw; i += gs) {
      ctx.beginPath(); ctx.moveTo(lcx + i * sc, padT); ctx.lineTo(lcx + i * sc, H - padB + 4); ctx.stroke();
    }
    ctx.restore();

    ctx.save();
    ctx.fillStyle = '#4a5560';
    ctx.fillRect(lx0, padT - 22, lw, 22);
    ctx.fillRect(rx0, padT - 22, rw, 22);
    ctx.restore();
    label(ctx, isA ? '自由落下' : '鉛直投げ上げ', lx0 + 6, padT - 11, { align: 'left', size: 12, bold: true, color: '#fff', halo: false });
    label(ctx, isA ? '水平投射' : '斜方投射', rx0 + 6, padT - 11, { align: 'left', size: 12, bold: true, color: '#fff', halo: false });

    var n = Math.floor(t / v.dt + 1e-9);
    for (i = 0; i <= n; i++) {
      var tt = i * v.dt;
      var L = P.m21.left(v, tt), R = P.m21.right(v, tt);
      var yl = Y(L.y), yr = Y(R.y), xr = XR(R.x);
      if (s.o.guide) {
        ctx.save();
        ctx.strokeStyle = 'rgba(255,255,255,.55)'; ctx.setLineDash([5, 5]); ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(lx0, yl); ctx.lineTo(rx0 + rw, yr); ctx.stroke();
        ctx.restore();
      }
      strobeDot(ctx, lcx, yl, 7, '#7ee08a', '#2f7d3d');
      strobeDot(ctx, xr, yr, 7, '#f4c04a', '#a97313');
    }
    var Lc = P.m21.left(v, t), Rc = P.m21.right(v, t);
    strobeDot(ctx, lcx, Y(Lc.y), 9, '#a8f0b2', '#2f7d3d');
    strobeDot(ctx, XR(Rc.x), Y(Rc.y), 9, '#ffd97a', '#a97313');
    var pxL = lcx, pyL = Y(Lc.y), pxR = XR(Rc.x), pyR = Y(Rc.y);
    if (s.o.showF) {
      arrow(ctx, pxL, pyL, pxL, pyL + 40, 'force');
      arrow(ctx, pxR, pyR, pxR, pyR + 40, 'force');
      label(ctx, 'mg', pxR + 8, pyR + 34, { align: 'left', size: 11, color: COL.force, haloColor: 'rgba(0,0,0,.6)' });
    }
    var vref = Math.max(6, v.v0 * 1.6);
    if (s.o.showV) {
      arrow(ctx, pxL, pyL, pxL, pyL - Lc.vy * 84 / vref, 'vel');
      arrow(ctx, pxR, pyR, pxR + Rc.vx * 84 / vref, pyR - Rc.vy * 84 / vref, 'vel');
    }
    if (s.o.showVc) {
      arrow(ctx, pxR, pyR, pxR + Rc.vx * 84 / vref, pyR, 'velx');
      arrow(ctx, pxR, pyR, pxR, pyR - Rc.vy * 84 / vref, 'vely');
      label(ctx, 'v_x', pxR + Rc.vx * 84 / vref * 0.6, pyR + 13, { size: 11.5, color: COL.velx, bold: true, haloColor: 'rgba(0,0,0,.6)' });
      label(ctx, 'v_y', pxR - 8, pyR - Rc.vy * 84 / vref * 0.6, { size: 11.5, color: COL.vely, bold: true, align: 'right', haloColor: 'rgba(0,0,0,.6)' });
      drawVelAngle(ctx, pxR, pyR, Rc, 84 / vref);
    }

    label(ctx, 't = ' + fmt(t, 2) + ' s（' + fmt(v.dt, 2) + ' s ごと）', lx0 + 2, 14, { align: 'left', size: 12, bold: true });
    drawPosNote(ctx, DEFS['m2-1'], s, W, 32);
    if (hintOn(s, t)) label(ctx, '2つの球の高さはいつも同じ', W - 10, 14, { align: 'right', size: 11.5, color: COL.sub });
  },
  info: function (s, t) {
    var v = V(s), m = P.m21.sample(v, t);
    return [
      ['左の球の高さ $y$', fmt(m.yL * s.sign, 2) + ' m'],
      ['右の球の高さ $y$', fmt(m.y * s.sign, 2) + ' m'],
      ['高さの差', fmt(Math.abs(m.y - m.yL), 3) + ' m'],
      ['右の球の水平位置 $x$', fmt(m.x, 2) + ' m'],
      ['鉛直方向の速度 $v_y$', fmt(m.vy * s.sign, 2) + ' m/s']
    ];
  },
  eq: function (s) {
    return '\\text{水平：} x = v_x t \\;(\\text{等速}) \\qquad \\text{鉛直：} y = v_{y0}t - \\tfrac{1}{2}gt^2 \\;(\\text{等加速度})';
  },
  note: '高さの差はいつも <b>0.000 m</b>。つまり水平方向の運動があってもなくても、<b>鉛直方向の運動はまったく同じ</b>。だから平面内の運動は「水平方向」と「鉛直方向」に分けて別々に考えてよい。'
};

function strobeDot(ctx, x, y, r, fill, edge) {
  ctx.save();
  var g = ctx.createRadialGradient(x - r * 0.3, y - r * 0.3, r * 0.2, x, y, r);
  g.addColorStop(0, '#ffffff'); g.addColorStop(0.45, fill); g.addColorStop(1, edge);
  ctx.fillStyle = g;
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
}

/* 2-2 の vy–t 図の下に出す解説。
   「グラフの面積 ＝ そのあいだの y の変化」を、上りと下りで見くらべさせる。 */
function m22AreaNote(v, st2) {
  var sg = st2 ? st2.sign : 1;
  if (v.th < 0.5) {
    return '<b>この図とヨコ軸ではさまれた面積は、そのあいだの y の変化（動いた高さ）を表す。</b>' +
      'いまは θ＝0° なので vy の符号は変わらず、面積も片側だけ。' +
      '<b>θ を大きくすると</b>上がる区間と下りる区間の2つができて、面積の大きさをくらべられる。';
  }
  var tt = P.m22.tTop(v), T = P.m22.tEnd(v), yt = P.m22.yTop(v);
  return '<b>この図の面積 ＝ そのあいだの y の変化（動いた高さ）。</b>（正＝みどり／負＝グレー）<br>' +
    '上り（0 〜 ' + fmt(tt, 2) + ' s）の<b>' + areaSignWord(sg, true) + 'の面積</b>　' +
    '<span class="tex">\\tfrac{1}{2}t_1 v_0\\sin\\theta = \\dfrac{v_0^2\\sin^2\\theta}{2g} = ' +
    fmt(yt, 2) + '\\,\\mathrm{m}</span>　← 最高点の高さ<br>' +
    '下り（' + fmt(tt, 2) + ' 〜 ' + fmt(T, 2) + ' s）の<b>' + areaSignWord(sg, false) + 'の面積</b>　' +
    '<span class="tex">' + fmt(yt, 2) + '\\,\\mathrm{m}</span>　← 最高点から下りた距離<br>' +
    '底辺（時間）も高さ（速さ）も同じ三角形なので、<b>2つの面積は必ず等しい</b>。' +
    '符号がちがうのでたすと 0 になり、<b>y はもとの高さ（y＝0）にもどる</b>——アニメーションはここで止まる。';
}

/* ============ 2-2 原点からの斜方投射 ============ */
DEFS['m2-2'] = {
  id: 'm2-2', mode: 2, tab: '2-2 水平・斜方投射',
  quizKey: 'vy', quizName: 'このボールの $v_y$–$t$ 図（鉛直方向）',
  title: '2-2　原点からの水平投射・斜方投射',
  desc: 'はじめは θ＝0°、つまり水平投射。角度を変えると斜方投射になる。',
  sub: '「分解した速度を表示」にすると、いつも一定の vx と、まっすぐ減っていく vy が見える。<b>投射角 θ を変えると、同じ v₀ でも飛び方がまったく変わる。</b>いろいろな θ で試してみよう。<br>アニメーションは<b>原点と同じ高さ（y＝0）にもどったところで止まる</b>（うすい放物線はその先も描いてある）。なぜそこで止まるのかは、vy–t 図の下の解説を見よう。',
  cw: 520, ch: 360,
  vis: ['F', 'V', 'Vc'], visFlash: 'Vc',
  signLabels: ['上向きを正', '下向きを正'],
  mainVars: ['th', 'v0'], mainVarFocus: 'th',
  vars: [
    { k: 'v0', label: '初速度 $v_0$', unit: ' m/s', min: 5, max: 30, step: 1, dec: 0, def: 15 },
    { k: 'th', label: '投射角 $\\theta$', unit: '°', min: 0, max: 80, step: 5, dec: 0, def: 0 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 5, step: 0.5, dec: 1, def: 1.0 }
  ],
  toggles: [],
  actions: [{ label: '斜方投射にする（θ＝45°）', fn: function (s) { s.v.th = 45; }, is: function (v) { return v.th === 45; } },
    { label: '水平投射にもどす（θ＝0°）', fn: function (s) { s.v.th = 0; }, is: function (v) { return v.th === 0; } }],
  tEnd: function (v) { return P.m22.tEnd(v); },
  sample: function (v, t) { return P.m22.sample(v, t); },
  graphs: [
    { key: 'x', short: '$x$–$t$ 図', title: '$x$–$t$ 図（水平位置）', ylabel: 'x [m]', open: false, signed: false,
      series: [{ color: COL.ink, f: function (m) { return m.x; } }], fml: function (v, sg) { return projFml(v, sg, 'x'); } },
    { key: 'y', short: '$y$–$t$ 図', title: '$y$–$t$ 図（高さ）', ylabel: 'y [m]', open: false, signed: true,
      series: [{ color: COL.ink, f: function (m) { return m.y; } }], fml: function (v, sg) { return projFml(v, sg, 'y'); } },
    { key: 'vx', short: '$v_x$–$t$ 図', title: '$v_x$–$t$ 図（水平方向の速度）', ylabel: 'vx [m/s]', open: true, signed: false,
      series: [{ color: COL.velx, f: function (m) { return m.vx; } }], fml: function (v, sg) { return projFml(v, sg, 'vx'); } },
    { key: 'vy', short: '$v_y$–$t$ 図', title: '$v_y$–$t$ 図（鉛直方向の速度）', ylabel: 'vy [m/s]', open: true, signed: true,
      series: [{ color: COL.vely, area: true, f: function (m) { return m.vy; } }],
      fml: function (v, sg) { return projFml(v, sg, 'vy'); },
      fnote: function (v) { return m22AreaNote(v); } },
    { key: 'a', short: '$a$–$t$ 図', title: '$a$–$t$ 図（鉛直方向の加速度）　※ a の運動方程式による導出', ylabel: 'ay [m/s²]', open: false, signed: true,
      series: [{ color: COL.acc, f: function (m) { return m.ay; } }], fml: function (v, sg) { return projFml(v, sg, 'a'); } }
  ],
  freeGraph: { defX: 'x', defY: 'y' },
  draw: function (ctx, s, t, W, H) {
    var v = V(s), T = P.m22.tEnd(v), TD = P.m22.tDraw(v);
    var box = trajBox(v, TD, P.m22.sample);
    var vw = mkView(W, H, { l: 44, r: 22, t: 30, b: 34 }, box);
    s.view = vw;
    worldAxes(ctx, vw, box, 'x [m]', 'y [m]', s.sign);
    /* うすい放物線は y=0 のあとも描く。オレンジの実線（通った跡）は t までなので変わらない */
    drawTraj(ctx, vw, v, P.m22.sample, TD, t, 0.2);

    var m = P.m22.sample(v, t);
    var px = vw.X(m.x), py = vw.Y(m.y);
    ball(ctx, px, py, 8 * mSize(DEFS['m2-2'], v));
    if (s.o.showF) {
      arrow(ctx, px, py, px, py + 46, 'force');
      label(ctx, '重力 mg', px - 9, py + 42, { align: 'right', size: 11.5, color: COL.force });
    }
    drawVel(ctx, px, py, m, s.o.showV, s.o.showVc, Math.max(6, v.v0 * 1.45));
    label(ctx, 't = ' + fmt(t, 2) + ' s', 10, 16, { align: 'left', size: 13.5, bold: true });
    drawPosNote(ctx, DEFS['m2-2'], s, W, 34);
    if (hintOn(s, t)) label(ctx, '水平は等速、鉛直だけが等加速度', W - 10, 16, { align: 'right', size: 11, color: COL.sub });
  },
  info: function (s, t) {
    var v = V(s), m = P.m22.sample(v, t);
    return [
      ['$x = v_0\\cos\\theta\\,t$', fmt(m.x, 2) + ' m'],
      ['$y = v_0\\sin\\theta\\,t - \\frac{1}{2}gt^2$', fmt(m.y * s.sign, 2) + ' m'],
      ['$v_x = v_0\\cos\\theta$', fmt(m.vx, 2) + ' m/s'],
      ['$v_y = v_0\\sin\\theta - gt$', fmt(m.vy * s.sign, 2) + ' m/s'],
      ['速さ $|v|$', fmt(m.v, 2) + ' m/s']
    ];
  },
  eq: function (s) {
    return '\\begin{aligned} v_x &= v_0\\cos\\theta \\;(\\text{一定}) & x &= v_0\\cos\\theta\\, t \\\\ v_y &= v_0\\sin\\theta - gt & y &= v_0\\sin\\theta\\, t - \\tfrac{1}{2}gt^2 \\end{aligned}';
  },
  note: '<b>vx–t 図は横一直線</b>（水平方向に力がはたらかない＝加速度0）。<b>vy–t 図は傾き −9.8 の直線</b>（重力だけがはたらく）。この2つを合わせると放物線になる。<br><b>vy–t 図の色をつけた2つの三角形は面積が等しい</b>：上がった高さと下りた高さが同じ、ということ。だから y＝0 にもどる。'
};

/* ============ 2-3 ビルの上からの斜方投射 ============ */
DEFS['m2-3'] = {
  id: 'm2-3', mode: 2, tab: '2-3 ビルの上からの斜方投射',
  quizKey: 'vy', quizName: 'このボールの $v_y$–$t$ 図（鉛直方向）',
  title: '2-3　ビルの上からの斜方投射（原点の取り方）',
  desc: '同じ運動でも、原点をどこに取るかで式の形は変わる。けれど $v$–$t$ 図・$a$–$t$ 図は変わらない。',
  sub: '「原点の取り方」を切りかえて、y の式と y–t 図がどう変わるかを確かめよう。',
  cw: 520, ch: 360,
  vis: ['F', 'V', 'Vc'], visFlash: 'Vc',
  signLabels: ['上向きを正', '下向きを正'],
  mainVars: ['v0', 'th', 'H'], mainOpts: true,
  vars: [
    { k: 'v0', label: '初速度 $v_0$', unit: ' m/s', min: 5, max: 30, step: 1, dec: 0, def: 15 },
    { k: 'th', label: '投射角 $\\theta$', unit: '°', min: -30, max: 80, step: 5, dec: 0, def: 30 },
    { k: 'H', label: 'ビルの高さ $H$', unit: ' m', min: 5, max: 45, step: 1, dec: 0, def: 20 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 5, step: 0.5, dec: 1, def: 1.0 }
  ],
  toggles: [],
  selects: [{
    k: 'org', label: '原点の取り方', def: 'launch',
    options: [{ v: 'launch', label: '投げた点を原点にする' }, { v: 'base', label: 'ビルの足元を原点にする' }, { v: 'landing', label: '着地点を原点にする' }]
  }],
  tEnd: function (v) { return P.m23.tEnd(v); },
  sample: function (v, t) { return P.m23.sample(v, t); },
  graphs: [
    { key: 'x', short: '$x$–$t$ 図', title: '$x$–$t$ 図（水平位置）', ylabel: 'x [m]', open: false, signed: false,
      series: [{ color: COL.ink, f: function (m) { return m.x; } }],
      fml: function (v, sg) {
        var o = P.m23.origin(v), vx = v.v0 * Math.cos(v.th * DEG);
        return ['x = x_0 + v_x t', 'x = x_0 + v_0\\cos\\theta\\, t',
          'x = ' + fmt(-o.ox, 1) + ' + ' + fmt(vx, 2) + 't'];
      } },
    { key: 'y', short: '$y$–$t$ 図', title: '$y$–$t$ 図（高さ）', ylabel: 'y [m]', open: false, signed: true,
      series: [{ color: COL.ink, f: function (m) { return m.y; } }],
      fml: function (v, sg) {
        var o = P.m23.origin(v), vy0 = v.v0 * Math.sin(v.th * DEG);
        return ['y = y_0 + v_{y0}t + \\tfrac{1}{2}at^2', 'y = y_0 + v_0\\sin\\theta\\,t - \\tfrac{1}{2}gt^2',
          'y = ' + fmt(-o.oy * sg, 1) + ' + ' + fmt(vy0 * sg, 2) + 't + \\tfrac{1}{2}(' + fmt(-G * sg, 2) + ')t^2'];
      } },
    { key: 'vx', short: '$v_x$–$t$ 図', title: '$v_x$–$t$ 図（水平方向の速度：原点を変えても変わらない）', ylabel: 'vx [m/s]', open: true, signed: false,
      series: [{ color: COL.velx, f: function (m) { return m.vx; } }],
      fml: function (v) {
        var vx = v.v0 * Math.cos(v.th * DEG);
        return ['v_x = v_{x0} \\;(\\text{一定})', 'v_x = v_0\\cos\\theta', 'v_x = ' + fmt(vx, 2)];
      } },
    { key: 'vy', short: '$v_y$–$t$ 図', title: '$v_y$–$t$ 図（原点を変えても変わらない）', ylabel: 'vy [m/s]', open: true, signed: true,
      series: [{ color: COL.vely, f: function (m) { return m.vy; } }], fml: function (v, sg) { return projFml(v, sg, 'vy'); } },
    { key: 'a', short: '$a$–$t$ 図', title: '$a$–$t$ 図　※ a の運動方程式による導出', ylabel: 'ay [m/s²]', open: false, signed: true,
      series: [{ color: COL.acc, f: function (m) { return m.ay; } }], fml: function (v, sg) { return projFml(v, sg, 'a'); } }
  ],
  draw: function (ctx, s, t, W, H) {
    var v = V(s), T = P.m23.tEnd(v), o = P.m23.origin(v);
    var R = P.m23.range(v);
    var box = trajBox(v, T, P.m23.sample, [{ x: -o.ox, y: -o.oy }, { x: R - o.ox + 2, y: -v.H - o.oy }]);
    var vw = mkView(W, H, { l: 44, r: 22, t: 30, b: 34 }, box);
    s.view = vw;

    var gy = -v.H - o.oy, lx = -o.ox;
    ground(ctx, vw.X(box.x0), vw.X(box.x1), vw.Y(gy));
    ctx.save();
    ctx.fillStyle = '#eef1f4'; ctx.strokeStyle = '#8b949e'; ctx.lineWidth = 1.5;
    var bw = Math.max(20, 3.0 * vw.s);
    ctx.beginPath(); ctx.rect(vw.X(lx) - bw, vw.Y(-o.oy), bw, vw.Y(gy) - vw.Y(-o.oy)); ctx.fill(); ctx.stroke();
    ctx.restore();
    worldAxes(ctx, vw, box, 'x [m]', 'y [m]', s.sign);
    label(ctx, 'H = ' + fmt(v.H, 0) + ' m', vw.X(lx) - bw - 5, (vw.Y(-o.oy) + vw.Y(gy)) / 2, { align: 'right', size: 11, color: COL.sub });
    drawTraj(ctx, vw, v, P.m23.sample, T, t, 0.2);

    var m = P.m23.sample(v, t);
    var px = vw.X(m.x), py = vw.Y(m.y);
    ball(ctx, px, py, 8 * mSize(DEFS['m2-3'], v));
    if (s.o.showF) {
      arrow(ctx, px, py, px, py + 44, 'force');
      label(ctx, 'mg', px - 8, py + 40, { align: 'right', size: 11.5, color: COL.force });
    }
    drawVel(ctx, px, py, m, s.o.showV, s.o.showVc, Math.max(6, v.v0 * 1.45));
    label(ctx, 't = ' + fmt(t, 2) + ' s', 10, 16, { align: 'left', size: 13.5, bold: true });
    drawPosNote(ctx, DEFS['m2-3'], s, W, 34);
    var on = { launch: '投げた点', base: 'ビルの足元', landing: '着地点' }[v.org];
    label(ctx, '原点：' + on, W - 10, 16, { align: 'right', size: 12, bold: true, color: COL.sub });
  },
  info: function (s, t) {
    var v = V(s), m = P.m23.sample(v, t), T = P.m23.tEnd(v);
    return [
      ['$x$', fmt(m.x, 2) + ' m'],
      ['$y$', fmt(m.y * s.sign, 2) + ' m'],
      ['$v_x$', fmt(m.vx, 2) + ' m/s'],
      ['$v_y$', fmt(m.vy * s.sign, 2) + ' m/s'],
      ['着地の時刻', fmt(T, 2) + ' s'],
      ['水平到達距離', fmt(P.m23.range(v), 2) + ' m']
    ];
  },
  eq: function (s) {
    var v = V(s), o = P.m23.origin(v);
    var yc = -o.oy, xc = -o.ox;
    var xs = 'x = ' + (Math.abs(xc) < 1e-9 ? '' : '(' + fmt(xc, 1) + ') + ') + 'v_0\\cos\\theta\\, t';
    var ys = 'y = ' + (Math.abs(yc) < 1e-9 ? '' : '(' + fmt(yc, 1) + ') + ') + 'v_0\\sin\\theta\\, t - \\tfrac{1}{2}gt^2';
    return xs + ',\\qquad ' + ys;
  },
  note: '原点を変えると <b>x や y の式に定数がつく</b>だけで、<b>速度と加速度の式は変わらない</b>。だから vy–t 図と a–t 図は原点を変えてもまったく同じ。'
};

/* ============ 2-4 かご入れゲーム ============ */
DEFS['m2-4'] = {
  id: 'm2-4', mode: 2, tab: '2-4 かご入れゲーム', game: true, startSfx: 'bang',
  title: '2-4　かごにボールを蹴り入れよう！',
  desc: 'ける速さと角度を変えて、ボールをかごに蹴り入れよう。',
  sub: '<b>成功するのは、ボールが「上から」かごの口に落ちこんだときだけ</b>（横からぶつかっても入らない）。だから、かごの上まで届かせて、そこで<b>下向きに落ちてくる</b>ようにねらおう。かごはドラッグで動かせる。水平到達距離は v₀²sin2θ / g。同じ距離になる角度が2つあることにも注目。',
  cw: 520, ch: 280,
  vis: ['F', 'V', 'Vc'], visFlash: 'Vc',
  signLabels: ['上向きを正', '下向きを正'],
  mainVars: ['v0', 'th'],
  vars: [
    { k: 'v0', label: 'ける速さ $v_0$', unit: ' m/s', min: 5, max: 30, step: 1, dec: 0, def: 15 },
    { k: 'th', label: 'ける角 $\\theta$', unit: '°', min: 5, max: 85, step: 5, dec: 0, def: 30 },
    { k: 'bx', label: 'かごの横位置', unit: ' m', min: 5, max: 80, step: 1, dec: 0, def: 30 },
    { k: 'by', label: 'かごの高さ', unit: ' m', min: 0, max: 25, step: 1, dec: 0, def: 0 }
  ],
  toggles: [],
  actions: [
    { label: 'かごを地面にもどす', fn: function (s) { s.v.by = 0; }, is: function (v) { return v.by === 0; } },
    { label: '背が高いバスケットゴールにする（5 m）', fn: function (s) { s.v.by = 5; }, is: function (v) { return v.by === 5; } }
  ],
  tEnd: function (v) { return P.m24.tEnd(v); },
  sample: function (v, t) { return P.m24.sample(v, t); },
  win: function (s) { return P.m24.catchT(V(s)) !== null; },
  graphs: [
    { key: 'y', short: '$y$–$t$ 図', title: '$y$–$t$ 図（高さ）', ylabel: 'y [m]', open: true, signed: true,
      series: [{ color: COL.ink, f: function (m) { return m.y; } }], fml: function (v, sg) { return projFml(v, sg, 'y'); } },
    { key: 'x', short: '$x$–$t$ 図', title: '$x$–$t$ 図（水平位置）', ylabel: 'x [m]', open: false, signed: false,
      series: [{ color: COL.ink, f: function (m) { return m.x; } }], fml: function (v, sg) { return projFml(v, sg, 'x'); } },
    { key: 'vy', short: '$v_y$–$t$ 図', title: '$v_y$–$t$ 図', ylabel: 'vy [m/s]', open: false, signed: true,
      series: [{ color: COL.vely, f: function (m) { return m.vy; } }], fml: function (v, sg) { return projFml(v, sg, 'vy'); } },
    { key: 'a', short: '$a$–$t$ 図', title: '$a$–$t$ 図　※ a の運動方程式による導出', ylabel: 'ay [m/s²]', open: false, signed: true,
      series: [{ color: COL.acc, f: function (m) { return m.ay; } }], fml: function (v, sg) { return projFml(v, sg, 'a'); } }
  ],
  drag: function (s, wx, wy) {
    s.v.bx = clamp(Math.round(wx), 5, 80);
    s.v.by = clamp(Math.round(wy), 0, 25);
  },
  draw: function (ctx, s, t, W, H) {
    var v = V(s), T = P.m24.tEnd(v), hit = P.m24.catchT(v) !== null;
    var box = trajBox(v, T, P.m24.sample, [{ x: 0, y: 0 }, { x: v.bx + 3, y: v.by + 3 }, { x: v.bx - 3, y: 0 }]);
    box.y0 = Math.min(box.y0, -1.5);
    var vw = mkView(W, H, { l: 44, r: 22, t: 28, b: 34 }, box);
    s.view = vw;
    ground(ctx, vw.X(box.x0), vw.X(box.x1), vw.Y(0));
    worldAxes(ctx, vw, box, 'x [m]', 'y [m]', s.sign);
    drawTraj(ctx, vw, v, P.m24.sample, T, t, 0.2);

    var bw = P.m24.W * vw.s;
    basketShape(ctx, vw.X(v.bx), vw.Y(v.by), bw, Math.max(14, bw * 0.55));
    if (v.by > 0.5) {
      ctx.save(); ctx.strokeStyle = '#b9a07c'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(vw.X(v.bx), vw.Y(v.by) + Math.max(14, bw * 0.55)); ctx.lineTo(vw.X(v.bx), vw.Y(0)); ctx.stroke();
      ctx.restore();
    }
    if (t < 1e-9) {
      label(ctx, 'かご（ドラッグで動かせる）', vw.X(v.bx), vw.Y(v.by) - 62, { size: 11, color: '#8a5a2a' });
      /* 判定のルールをヒントとして出す（横からぶつかってもダメ） */
      label(ctx, '上から落ちこむと成功', vw.X(v.bx), vw.Y(v.by) - 46, { size: 11.5, bold: true, color: '#1c8f4a' });
      /* かごの口に「上から入る」ことを示す小さな下向き矢印 */
      arrow(ctx, vw.X(v.bx), vw.Y(v.by) - 34, vw.X(v.bx), vw.Y(v.by) - 8, 'vel');
    }

    kicker(ctx, vw.X(0) - 14, vw.Y(0), 34, false);
    var m = P.m24.sample(v, t);
    var px = vw.X(m.x), py = vw.Y(m.y);
    ball(ctx, px, py, 8);
    if (s.o.showF) arrow(ctx, px, py, px, py + 42, 'force');
    drawVel(ctx, px, py, m, s.o.showV, s.o.showVc, Math.max(6, v.v0 * 1.45));
    label(ctx, 't = ' + fmt(t, 2) + ' s', 10, 15, { align: 'left', size: 13.5, bold: true });
    drawPosNote(ctx, DEFS['m2-4'], s, W, 33);
    if (hintOn(s, t)) label(ctx, '到達距離 = v_0²sin2θ/g = ' + fmt(v.v0 * v.v0 * Math.sin(2 * v.th * DEG) / G, 1) + ' m',
      W - 10, 15, { align: 'right', size: 11, color: COL.sub });
    if (!hit && t >= T - 1e-9) {
      var R2 = v.v0 * v.v0 * Math.sin(2 * v.th * DEG) / G, dd = R2 - v.bx;
      impact(ctx, px, py - 6, 18, 'ドサッ！');
      bubble(ctx, (dd < 0 ? '手前に落ちた（あと ' : 'とび過ぎた（' ) + fmt(Math.abs(dd), 1) + ' m）',
        Math.min(W - 100, Math.max(100, px)), Math.max(54, py - 46),
        { size: 13, bg: '#fff5d6', border: '#d9a545', color: '#8a5000' });
    }
    if (hit && t >= T - 1e-9) {
      bubble(ctx, 'ナイスシュート！　かごに入った！', vw.X(v.bx), vw.Y(v.by) - 30, { size: 14, bg: '#e6f7ea', border: '#1c8f4a', color: '#14713a' });
      ctx.save();
      for (var i = 0; i < 16; i++) {
        var an = i * Math.PI / 8;
        ctx.strokeStyle = ['#e07b18', '#1c8f4a', '#1663b5', '#d1352b'][i % 4];
        ctx.lineWidth = 2.2;
        ctx.beginPath();
        ctx.moveTo(vw.X(v.bx) + Math.cos(an) * 26, vw.Y(v.by) - 52 + Math.sin(an) * 26);
        ctx.lineTo(vw.X(v.bx) + Math.cos(an) * 36, vw.Y(v.by) - 52 + Math.sin(an) * 36);
        ctx.stroke();
      }
      ctx.restore();
    }
  },
  info: function (s, t) {
    var v = V(s), m = P.m24.sample(v, t), c = P.m24.catchT(v);
    return [
      ['水平到達距離', fmt(v.v0 * v.v0 * Math.sin(2 * v.th * DEG) / G, 2) + ' m'],
      ['最高点の高さ', fmt(Math.pow(v.v0 * Math.sin(v.th * DEG), 2) / (2 * G), 2) + ' m'],
      ['滞空時間', fmt(P.m24.flight(v), 2) + ' s'],
      ['かごの位置', '(' + fmt(v.bx, 0) + ', ' + fmt(v.by, 0) + ') m'],
      ['判定', c !== null ? '入る！' : '入らない'],
      ['いまの高さ $y$', fmt(m.y * s.sign, 2) + ' m']
    ];
  },
  eq: function (s) {
    return '\\text{水平到達距離}\\; R = \\dfrac{v_0^2 \\sin 2\\theta}{g} \\quad(\\theta = 45^\\circ \\text{で最大})';
  },
  note: '同じ距離に届く角度は<b>2通り</b>ある（例：30° と 60°）。かごを高いところに上げると、<b>下りぎわ</b>に入れるか<b>上りぎわ</b>に入れるかで必要な角度が変わる。'
};


