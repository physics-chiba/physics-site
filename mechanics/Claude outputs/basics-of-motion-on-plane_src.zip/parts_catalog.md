# 共通部品カタログ（シリーズ全体で使いまわす）

`basics-of-motion-on-plane.html` で作った**描画部品と補助関数の一覧**。
新しいシミュレーションのページ（力学的エネルギー保存則、万有引力、…）を作るときは、
**まずこの表を見て「もうある部品」を探すこと**。作り直さない。

実体は `claude/basics-of-motion-on-plane_ソース全文.md` の中の

- `src/40_draw.js` … 矢印・文字・軸・グラフ・手・音（**そのまま丸ごと持っていける**）
- `src/45_defs.js` … 物体の絵（棒人間・かご・木・…）と共通ルール
- `src/50_mode1.js` の先頭 … 斜面の座標系
- `src/60_mode2.js` の先頭 … 放物運動まわり

にある。新しいページでは **`40_draw.js` は基本まるごとコピー**、`45_defs.js` からは必要な絵だけ
持っていく、という使い方を想定している。

⚠ **座標は「画面の px」**（y は下向きが正）。物理の値は `mkView()` などで画面座標に直してから渡す。

---

## 1. 手・人

| 部品 | 呼び出し方 | 何が出るか |
|---|---|---|
| **手（つかむ・押す・引く）** | `hand(ctx, x, y, ang)` | こぶしが `(x,y)`、腕が `ang` 方向へのびる。**押す**なら物体の反対側から、**引く**なら「物体 → 糸 → 手」の順に並ぶよう 30 px ほど離す |
| **デコピン（はじく）** | `flickHand(ctx, x, y, ang, k, dir, sc, alpha)` | `k`：0→1 で指が曲げた形からまっすぐに弾ける／`dir`：+1 で右向き、−1 で左向き／`sc`：大きさ（0.42 くらい）／`alpha`：消え際 |
| **手をはなす（落とす）** | `dropHand(ctx, x, y, sc, open, alpha)` | `open`：0＝つかんでいる、1＝開いてはなした |
| **下から支える手** | `handUnder(ctx, x, y, sc, flip)` | 手のひらを上に向けた線画。`(x,y)`＝手のひらのてっぺん（＝ものが乗るところ）。**物体の下にぴったり接するように置く**。mechanical-energy.html と同じ形 |
| **棒人間** | `stickman(ctx, x, y, ux, uy, s, color, lw)` | `(x,y)`＝足もと、`(ux,uy)`＝画面での「上」の向き（斜面の上に立たせられる） |
| **観測者（棒人間＋名前）** | `observer(ctx, x, y, ux, uy, name, active, s, lab)` | `active` なら青くて太く、名前に「（いまの視点）」が付く。`lab={dx,dy,align}` で名前の位置を調整 |
| **人（立ち姿）** | `person(ctx, x, yFoot, h, flip)` | ふつうに立っている人 |
| **ボールをける人** | `kicker(ctx, x, yFoot, h, flip)` | 右足をふりかぶった姿 |
| **糸（ひも）** | `string(ctx, x1, y1, x2, y2)` | 細い茶色の線 |
| **面（ハッチつき）** | `hatchLine(ctx, x1, y1, x2, y2, side)` | ★ハッチは「進む向きの右がわ」に出る。**かならず左→右（斜面なら下→上）の向きでわたす**こと。逆向きにわたすと、もようが面の上に浮いてしまう（1-10 で実際に起きた） |
| **2物体の力の色分け** | `fcol(who, col)` | `who='B'` なら同じ色みの「こい色」を返す。A にはたらく力＝あかるい色／B にはたらく力＝こい色（「力のベクトルの描き方ルール」⑨） |

### 「下から支える手」がなくなる出し方（1-10・1-11 で使用）

**動かす前（t=0）だけ、手の右に「支えている手を放す」の吹き出しを出す**（`releaseHint()`）。
スタートを押すと t が進むので自動的に消える。吹き出しはデコピンと同じオレンジの配色で、
**しっぽは左向き（`side:'left'`）にして手を指す**。


**静かにはなす**場面は、`dropHand` ではなく **`handUnder`（下から支える手）が下へ抜けて消える**形にする。

```js
if (t < 0.34) {                                  /* 下から支えていた手が、下へ抜けて消える */
  var hp = clamp((t - 0.08) / 0.22, 0, 1), fa = 1 - hp;
  if (fa > 0.02) {
    ctx.save(); ctx.globalAlpha = fa;
    handUnder(ctx, bx, by + rB + 2 + hp * 34, 0.7);   /* (bx, by+rB) ＝ 物体の下のはし */
    ctx.restore();
  }
}
```

### デコピンの出し方（1-1 のやり方をそのまま使う）

**はじいた直後だけ出して、すっと消す。** ずっと出ていると「ずっと押している」ように見えてしまう。

```js
/* 初速度は「デコピンではじいた」ものとして見せる（すべり出したら手は消える） */
if (Math.abs(v.v0) > 0.05 && t < 0.34) {
  var fdir = v.v0 > 0 ? 1 : -1;
  var fk = clamp(t / 0.10, 0, 1);                                  /* 0.10 s で指が弾ける */
  var fa = (t <= 0.13) ? 1 : Math.max(0, 1 - (t - 0.13) / 0.18);   /* 0.13 s から薄くなる */
  if (fa > 0.02) {
    flickHand(ctx, fcx, fcy, -sn.th, fk, fdir, 0.42, fa);
    ctx.save(); ctx.globalAlpha = fa;
    bubble(ctx, 'デコピン！', bx, by,
      { size: 12.5, bg: '#fff5e8', border: '#e07b18', color: '#a85c0c' });
    ctx.restore();
  }
}
```

置く場所は「物体の、進む向きと反対側」。斜面なら `-sn.u * dir * (物体の幅/2 + 20)` だけずらす。

---

## 2. 物体の絵

| 部品 | 呼び出し方 | 備考 |
|---|---|---|
| **ボール** | `ball(ctx, x, y, r, style)` | `style`：省略＝白丸／`'faint'`＝残像／`'A'`＝青／`'B'`＝赤 |
| **直方体のブロック** | `blockShape(ctx, cx, cy, ang, w, h, fill)` | `ang`＝面の傾き（rad）。斜面の上に置ける |
| **地面（ハッチつき）** | `ground(ctx, x1, x2, y)` | 横一直線＋斜線 |
| **斜めのハッチ線** | `hatchLine(ctx, x1, y1, x2, y2, side)` | 斜面の下側を塗るときに |
| **かご（バスケット）** | `basketShape(ctx, cx, yTop, wTop, h)` | |
| **台車（発射筒つき）** | `cart(ctx, cx, yBase, w)` | |
| **カーリングのストーン** | `stone(ctx, cx, cy, r)` | |
| **的（ハウス）** | `houseTarget(ctx, cx, cy, r)` | 赤白青の同心円 |
| **木** | `tree(ctx, x, yBase, h)` | |
| **猿** | `monkeyShape(ctx, x, y, r)` | |
| **コルク銃** | `corkGun(ctx, x, y, angRad)` | |
| **気球** | `balloonShape(ctx, x, y, r)` | `(x,y)`＝ゴンドラの底（＝物を投げ出す位置） |
| **滑車** | `pulley(ctx, cx, cy, r)` | 軸つきの円。糸は `string()` でつなぐ。**滑車に巻きつく部分は `stringArc(ctx,cx,cy,r,a1,a2)`** |
| **糸の円弧** | `stringArc(ctx, cx, cy, r, a1, a2)` | 滑車に巻きついた糸。`string()` と同じ色・太さ |
| **板（1-12 の A）** | `plank(ctx, cx, yTop, w, h)` | `(cx,yTop)`＝上面の中心。上に物体をのせる |

**質量に応じて大きさを変える**：`mSize(d, v)` が倍率を返す。`ball(ctx, x, y, 8 * mSize(d, v))`
のように掛ける。標準の質量で 1.0、最小〜最大でさしわたし約 1.9 倍。

---

## 3. 矢印・文字・角

| 部品 | 呼び出し方 | 備考 |
|---|---|---|
| **矢印** | `arrow(ctx, x1, y1, x2, y2, kind, scale, col)` | `kind`：`force`（力・作用点に「・」）／`comp`（分力・破線）／`vel`（速度・白抜き）／`velx`・`vely`（成分）／`acc`（加速度）／`dim`（寸法） |
| **文字** | `label(ctx, text, x, y, opt)` | `opt = {size, color, align:'left'\|'center'\|'right', bold, halo}`。白フチが自動で付くので、線の上でも読める。`_` で下付き（`v_0`） |
| **光るチェックボックス** | def に `visFlash: 'Vc'` | そのチェックボックスをオレンジの丸枠で目立たせ、シムを選ぶたびに**4回だけピコピコ光る**（CSS `.vflash`）。生徒がチェックを入れたら光りをやめる |
| **光る帯（操作の案内）** | `hintChip(ctx, text, x, y, k, opt)` | 「ここを操作してね」をオレンジの帯で目立たせる。`k`＝0〜1 のまばたきの強さ（`flashK()` を渡すと、シムを選んだ直後だけ2.6秒ピカピカする）。def に `hintFlash:true` を書くと、止まっていても点滅ぶんだけ描き直す |
| **吹きだし** | `bubble(ctx, text, x, y, opt)` | `opt = {size, bg, border, color, side}`。★**しっぽ（三角）は必ず「指し示したいもの」の向きに出す**★ `side:'down'`（既定・(x,y)＝箱の下辺の中央）／`'up'`／`'left'`／`'right'`（この3つは (x,y)＝しっぽの先） |
| **角の弧（θ）** | `angArc(ctx, cx, cy, r, a1, a2, text, labAng, labR)` | **画面の角 ＝ −(数学の角)**。符号の反転を忘れない |
| **衝突の星** | `impact(ctx, x, y, r, text)` | 「ドコッ！」など |
| **原点マーク** | `originMark(ctx, px, py, ox, oy)` | ● と大きめの「O」 |
| **同じ長さの印「｜」** | `drawEqualTicks(ctx)` | 各フレームの矢印を描き終えたあとに1回呼ぶ |
| **色を薄くする** | `fade('#d1352b', 0.2)` | rgba 文字列を返す |

### 色（`COL`）— シリーズ全体で固定。ほかの意味に使わない

```
force #d1352b（重力・一般の力）   norm  #7b3fd4（垂直抗力）
fric  #0f8a8a（摩擦力）           hand  #c2367f（手・ひもの力）
vel   #1663b5（速度）             velx  #1f7fd4 / vely #0d8f7a（速度の成分）
acc   #e07b18（加速度）           comp  もとの力と同じ色の破線
dim   #1b1f24（寸法・変位）       areaNeg #7a8794（グラフの負の面積）
```

---

## 4. 座標系・軸・グラフ

| 部品 | 呼び出し方 | 備考 |
|---|---|---|
| **キャンバスの準備** | `prep(cv, w, h)` | 2倍解像度にして ctx を返す |
| **世界座標→画面** | `mkView(W, H, pad, box)` | `.X() .Y() .invX() .invY() .s` を持つ。y 上向き、等方スケール |
| **世界の x・y 軸** | `worldAxes(ctx, vw, box, xlabel, ylabel, signY)` | 目盛り・矢じり・原点つき |
| **軸1本** | `axisX(ctx, X, ypx, lo, hi, name, sign, opt)` / `axisY(...)` | `opt = {step, numDec, noNum, target}` |
| **きりのよい目盛り幅** | `niceStep(range, target)` | |
| **0 を含むきりのよい範囲** | `niceRange(lo, hi)` | グラフの縦軸に |
| **グラフを描く** | `plot(cv, spec)` | `spec = {xlabel, ylabel, xmin, xmax, xstep, ymin, ymax, series, cursors, legend, view, hide, note}` |
| **系列の面積を塗る** | `series: [{ color, pts, area: true }]` | 正＝線と同じ色、負＝グレー。「グラフの面積＝変化量」を見せるときに |
| **2本の線ではさむ帯を塗る** | `band: { i, j, color }`（グラフの定義） | 2つの系列の差＝面積。1-11 の「B が A に対してすべった距離」で使う |
| **斜面の座標系** | `slopeScene(W, H, thDeg, sLo, sHi)` | `.pos(s)`＝斜面にそった座標→画面、`.u`＝斜面上向き、`.n`＝斜面の外向き、`.sc`＝px/m |
| **斜面の板・角・軸** | `drawSlopeBase(ctx, sn, W, H, thDeg, sign, labelDeg, labelUp)` | |
| **軌道の枠** | `trajBox(v, T, fn, extra)` | 運動全体が入る範囲を返す |
| **軌道の線と残像** | `drawTraj(ctx, vw, v, fn, T, tNow, dotStep)` | うすい破線＋通った跡のオレンジ |
| **速度と分解** | `drawVel(ctx, px, py, m, showV, showC, vref, names)` | 分解すると θ′ も自動で書く |

---

## 5. 決めごと（部品ではないが必ず使う）

| 何 | 呼び出し方 | 中身 |
|---|---|---|
| **答えのヒントを出してよいか** | `hintOn(s, t)` | 動かす前・問題モードの途中では出さない。運動の結論を書くラベルは必ずこれで囲む |
| **正の向きの表示** | `drawPosNote(ctx, d, s, W, y, word)` | 図の右上に「正の向き：○○」。全シムで言い方をそろえる |
| **正の向きの言葉** | `posWord(d, s, word)` / `dirWord(th, sign)` | |
| **面積の正負の言い方** | `areaSignWord(sign, rising)` | 「正の向き」を切りかえると入れかわるので、解説文はこれで作る |
| **$…$ を KaTeX に** | `mathHtml(str)` | ラベルや変数名に使う |
| **効果音** | `sfx('bang' \| 'hit' \| 'win' \| ...)` | Web Audio で作る（音声ファイルは持たない＝オフラインのまま） |
| **式の見出し** | 式のあたまに `EQM` / `EQBAL`、または def に `eqHead:'…'` | 左下の式のエリアで「運動方程式をたてると」「力のつり合いを考えると」という見出しが式の上に出る |
| **力の表示の切りかえ** | `vis:['F','Fm','V']` ＋ `visDef:{F:true}` | `F`＝力を表示／`Fm`＝運動方向の力のみ表示（**F と排他**）／`V`＝速度。`visDef` で既定のオン・オフを変えられる |

---

## 使うときの手順（新しいページを作るとき）

1. `claude/basics-of-motion-on-plane_ソース全文.md` から **`src/40_draw.js` をまるごとコピー**する。
   矢印・文字・軸・グラフ・手・音がぜんぶ入っていて、単元に依存しない。
2. `src/45_defs.js` からは、**共通ルール**（`hintOn` `drawPosNote` `mSize` `mathHtml` `areaSignWord`）
   と、**その単元で使う絵だけ**を持っていく。
3. その単元の新しい絵（ばね、ジェットコースター、惑星…）を足すときは、
   **既存の部品と同じ書き方**（`ctx.save()`/`restore()` で囲む、色は `COL` から取る、
   引数は `(ctx, x, y, …)` の順）にそろえ、**この表に1行追記する**。
4. 色は絶対に増やさない。新しい色が要るときは `COL` に足して、
   ページ下の `#legend` にも並べる。

## 力学的エネルギー保存で使えそうなもの（見当）

- `flickHand` … **外から仕事をして運動エネルギーを与える瞬間**の絵。出発点で使う
- `hand` + `string` … 引き上げる・ゆっくり下ろす（仕事の正負）
- `ball` / `blockShape` + `slopeScene` … 斜面をすべり下りる
- `plot` の `area: true` … 「力–位置グラフの面積 ＝ 仕事」を見せる（**そのまま使える**）
- `stickman` / `observer` … 基準面をどこに取るかを見る人
- `impact` + `sfx('hit')` … 着地・衝突
