#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Gemini の5つの指摘について、ほんとうにそうなっているかを機械で確かめ、
エクセルに貼る「前」「後」のスクリーンショットも撮る。

  python3 test/gemini.py            … いまの dist を「後」として撮る
  python3 test/gemini.py before PATH … PATH の HTML を「前」として撮る
"""
import json
import pathlib
import sys

from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = ROOT / "shots" / "gemini"
OUT.mkdir(parents=True, exist_ok=True)

TAG = "after"
PAGE = ROOT / "dist" / "mechanical-energy.html"
if len(sys.argv) > 2 and sys.argv[1] == "before":
    TAG = "before"
    PAGE = pathlib.Path(sys.argv[2])


def shot(el, name):
    el.screenshot(path=str(OUT / (name + "_" + TAG + ".png")))


with sync_playwright() as pw:
    b = pw.chromium.launch()
    res = {}

    # ---- ふつうの画面（PC） ----
    p = b.new_page(viewport={"width": 1400, "height": 1100}, device_scale_factor=2)
    errs = []
    reqs = []
    p.on("pageerror", lambda e: errs.append(str(e)))
    p.on("request", lambda r: reqs.append(r.url) if not r.url.startswith("file:") else None)
    p.goto(PAGE.as_uri())
    p.wait_for_timeout(900)

    # === 指摘① 数式が3重に見えている？ ===
    p.evaluate("()=>window.TEST.goto('m1-3')")
    p.wait_for_timeout(200)
    p.evaluate("window.TEST.toEnd()")
    p.wait_for_timeout(300)
    p.evaluate("()=>{var c=document.getElementById('cbAllEq');"
               "if(c&&!c.checked)c.click();}")
    p.wait_for_timeout(200)
    p.evaluate("""()=>{var hs=document.querySelectorAll('.eqhead');
      for(var i=0;i<hs.length;i++){if(hs[i].parentNode.className.indexOf('open')<0)hs[i].click();}}""")
    p.wait_for_timeout(400)
    res["katex"] = p.evaluate("""()=>{
      var all = document.querySelectorAll('.katex');
      var mml = document.querySelectorAll('.katex .katex-mathml');
      var vis = 0, hid = 0, i, r;
      for (i=0;i<mml.length;i++){
        r = mml[i].getBoundingClientRect();
        if (r.width > 2 || r.height > 2) vis++; else hid++;
      }
      /* ページに出ている「見える文字」の中に、生の LaTeX が残っていないか */
      var txt = document.body.innerText;
      var raw = (txt.match(/\\\\(frac|tfrac|underbrace|quad|text|mathrm|sqrt)/g) || []).length;
      var dollars = (txt.match(/\\$[^$\\n]{2,}\\$/g) || []).length;
      /* KaTeX が「読み上げ用」に置く MathML の指定 */
      var st = mml.length ? getComputedStyle(mml[0]) : null;
      return { katex_nodes: all.length, mathml_nodes: mml.length,
               mathml_visible: vis, mathml_hidden_1px: hid,
               raw_latex_in_visible_text: raw, dollar_math_in_visible_text: dollars,
               mathml_position: st ? st.position : null,
               mathml_clip: st ? (st.clipPath || st.clip) : null,
               katex_error_nodes: document.querySelectorAll('.katex-error').length };
    }""")
    # 「3重に見える」のは、文字を機械で抜き出したときだけ起きる（人の目には1つ）
    res["katex_sample"] = p.evaluate("""()=>{
      var k = document.querySelector('#eqzone .katex');
      if (!k) return null;
      var mm = k.querySelector('.katex-mathml');
      var hh = k.querySelector('.katex-html');
      var an = k.querySelector('annotation');
      return {
        textContent_all : k.textContent,                 /* 機械が読むと重なって見える */
        innerText_visible: k.innerText,                  /* 人が見えるのはこれだけ */
        from_mathml     : mm ? mm.textContent : null,    /* 読み上げ用（1px に隠してある） */
        from_tex_source : an ? an.textContent : null,    /* もとの LaTeX（同じく隠してある） */
        from_html_shown : hh ? hh.textContent : null,    /* 実際に描かれている字 */
        mathml_rect     : mm ? [Math.round(mm.getBoundingClientRect().width),
                                Math.round(mm.getBoundingClientRect().height)] : null,
        html_rect       : hh ? [Math.round(hh.getBoundingClientRect().width),
                                Math.round(hh.getBoundingClientRect().height)] : null
      };
    }""")
    shot(p.query_selector("#eqzone"), "no1_eqzone")

    # === 指摘② グラフの拡大縮小ボタン ===
    p.evaluate("()=>window.TEST.goto('m1-1')")
    p.wait_for_timeout(200)
    p.evaluate("window.TEST.toEnd()")
    p.wait_for_timeout(200)
    p.evaluate("()=>window.TEST.openAll()")
    p.wait_for_timeout(500)
    res["zoom_buttons"] = p.evaluate("()=>document.querySelectorAll('[data-gz]').length")
    el = p.query_selector("#gb_KUE")
    if el:
        shot(el, "no2_graph")

    # === 指摘③ 数値積分（ばね系） ===
    res["integrator"] = p.evaluate("""()=>{
      function drift(id, v, T, N){
        var d=DEFS[id], E0=d.sample(v,0).E, mx=0, sc=0;
        for(var i=0;i<=N;i++){ var m=d.sample(v, T*i/N);
          mx=Math.max(mx, Math.abs(m.E-E0));
          sc=Math.max(sc, Math.abs(m.K), Math.abs(m.Ug), Math.abs(m.Us), Math.abs(E0)); }
        return +(mx/Math.max(1e-9,sc)*100).toPrecision(3);
      }
      function amp(id, v, T, N){
        var d=DEFS[id], a1=0, a2=0, i, m;
        for(i=0;i<=N/2;i++){ m=d.sample(v,T*i/N); a1=Math.max(a1,Math.abs(m.x)); }
        for(i=N/2;i<=N;i++){ m=d.sample(v,T*i/N); a2=Math.max(a2,Math.abs(m.x)); }
        return [+a1.toFixed(6), +a2.toFixed(6)];
      }
      var T9 = 50*2*Math.PI*Math.sqrt(1.0/200), T12 = 50*2*Math.PI*Math.sqrt(1.0/30);
      return {
        m1_9_drift_50periods_pct : drift('m1-9', {x0:0.30,k:200,m:1.0}, T9, 20000),
        m1_9_amplitude_first_last: amp('m1-9', {x0:0.30,k:200,m:1.0}, T9, 20000),
        m1_10_drift_pct: drift('m1-10',{v0:4,k:200,m:1.0}, DEFS['m1-10'].tEnd({v0:4,k:200,m:1.0}), 20000),
        m1_11_drift_pct: drift('m1-11',{x0:0.75,k:35,m:1.0}, DEFS['m1-11'].tEnd({x0:0.75,k:35,m:1.0}), 20000),
        m1_12_drift_50periods_pct: drift('m1-12',{d:0.10,k:30,m:1.0}, T12, 20000),
        page_max_drift_pct: window.TEST.check().drift_max_all
      };
    }""")
    p.evaluate("()=>window.TEST.goto('m1-12')")
    p.wait_for_timeout(200)
    p.evaluate("window.TEST.toEnd()")
    p.wait_for_timeout(200)
    p.evaluate("()=>window.TEST.openAll()")
    p.wait_for_timeout(500)
    el = p.query_selector("#gb_KUE")
    if el:
        shot(el, "no3_spring_graph")

    # === 指摘④ 曲面から飛び出す条件 ===
    c = p.evaluate("()=>window.TEST.check()")
    res["bowl"] = {k: c[k] for k in c if k.startswith("bowl")}
    p.evaluate("()=>window.TEST.goto('m1-13')")
    p.wait_for_timeout(200)
    p.evaluate("window.TEST.toEnd()")
    p.wait_for_timeout(400)
    box = p.evaluate("""()=>{var w=document.querySelector('.cvwrap'); var r=w.getBoundingClientRect();
      return {x:r.x+window.scrollX,y:r.y+window.scrollY,w:r.width,h:r.height};}""")
    p.screenshot(path=str(OUT / ("no4_bowl_" + TAG + ".png")), full_page=True,
                 clip={"x": box["x"] - 4, "y": box["y"] - 4,
                       "width": box["w"] + 8, "height": box["h"] + 8})
    res["errors_pc"] = errs
    res["external_requests"] = [u for u in reqs if u]
    p.close()

    # ---- スマホの画面（390 px） ----
    p2 = b.new_page(viewport={"width": 390, "height": 844}, device_scale_factor=2)
    errs2 = []
    p2.on("pageerror", lambda e: errs2.append(str(e)))
    p2.goto(PAGE.as_uri())
    p2.wait_for_timeout(900)
    p2.evaluate("()=>window.TEST.goto('m1-3')")
    p2.wait_for_timeout(200)
    p2.evaluate("window.TEST.toEnd()")
    p2.wait_for_timeout(300)
    p2.evaluate("()=>{var c=document.getElementById('cbAllEq'); if(c&&!c.checked)c.click();}")
    p2.wait_for_timeout(200)
    p2.evaluate("""()=>{var hs=document.querySelectorAll('.eqhead');
      for(var i=0;i<hs.length;i++){if(hs[i].parentNode.className.indexOf('open')<0)hs[i].click();}}""")
    p2.wait_for_timeout(500)
    res["mobile"] = p2.evaluate("""()=>{
      var de = document.documentElement;
      var tw = document.querySelector('.ptabwrap');
      var out = { page_scrollWidth: de.scrollWidth, page_clientWidth: de.clientWidth,
        page_h_scroll: de.scrollWidth > de.clientWidth + 1,
        ptabwrap_overflowX: tw ? getComputedStyle(tw).overflowX : null,
        ptabwrap_can_scroll: tw ? (tw.scrollWidth > tw.clientWidth) : null };
      /* 立式・表・数式が、親の箱から右へはみ出していないか */
      var bad = [], i, els = document.querySelectorAll('#eqzone .fv, #eqzone .eqsec, .ptab, .gform');
      for (i=0;i<els.length;i++){
        var e = els[i], pr = e.parentElement;
        var r = e.getBoundingClientRect(), q = pr.getBoundingClientRect();
        var cs = getComputedStyle(pr);
        if (r.right > q.right + 1.5 && cs.overflowX === 'visible')
          bad.push((e.className||e.tagName) + ' +' + Math.round(r.right - q.right) + 'px');
      }
      out.overflow_hits = bad;
      return out;
    }""")
    p2.screenshot(path=str(OUT / ("no5_top_" + TAG + ".png")), full_page=False)
    el = p2.query_selector(".ptabwrap")
    if el:
        shot(el, "no5_table")
    # 立式の欄までスクロールして、390 px の画面のまま写す（右がはみ出ていないこと）
    p2.evaluate("()=>{var e=document.getElementById('eqzone');"
                "if(e) window.scrollTo(0, e.getBoundingClientRect().top + window.scrollY - 8);}")
    p2.wait_for_timeout(400)
    p2.screenshot(path=str(OUT / ("no5_mobile_" + TAG + ".png")), full_page=False)
    res["errors_mobile"] = errs2
    p2.close()
    b.close()

print(json.dumps(res, ensure_ascii=False, indent=2))
(OUT / ("result_" + TAG + ".json")).write_text(
    json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")
