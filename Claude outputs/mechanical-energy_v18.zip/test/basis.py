#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""斜面の「面にそう向き (ux, uy)」と「面から外向き (nx, ny)」が
直角になっているかを、ソースから読み取って確かめる。

★第7回★ 2-2 と 2-5 で nx の符号がまちがっていて（+sin θ）、
垂直抗力が斜面に垂直に描かれず、物体も面から少しずれて乗っていた。
同じまちがいが入りこまないように、機械的に見張る。
"""
import math
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
FILES = ["src/50_mode1.js", "src/60_mode2.js"]

# 式の文字列 → 値（角の記号はぜんぶ TH に読みかえて数値で確かめる）
TH = 0.4123


def val(e):
    e = e.strip()
    e = re.sub(r"Math\.(sin|cos)\(-\s*([A-Za-z_][\w.]*)\)", r"-Math.\1(\2)", e)
    m = re.fullmatch(r"(-?)Math\.(sin|cos)\(([A-Za-z_][\w.]*)\)", e)
    if not m:
        return None
    s = -1.0 if m.group(1) else 1.0
    return s * (math.sin(TH) if m.group(2) == "sin" else math.cos(TH))


E = r"(-?\s*Math\.(?:sin|cos)\(-?\s*[A-Za-z_][\w.]*\))"
PAT_U = re.compile(r"ux = " + E + r", uy = " + E)
PAT_N = re.compile(r"nx = " + E + r", ny = " + E)

bad, checked = [], 0
for f in FILES:
    lines = (ROOT / f).read_text(encoding="utf-8").split("\n")
    for i, ln in enumerate(lines):
        mu = PAT_U.search(ln)
        if not mu:
            continue
        ux, uy = val(mu.group(1)), val(mu.group(2))
        if ux is None or uy is None:
            continue
        # 同じ行か、すぐ下の数行の nx/ny を見る（間にコメントが入ることがある）
        mn = PAT_N.search(ln)
        j = i
        while mn is None and j + 1 < len(lines) and j - i < 6:
            j += 1
            mn = PAT_N.search(lines[j])
        if not mn:
            continue
        nx, ny = val(mn.group(1)), val(mn.group(2))
        if nx is None or ny is None:
            continue
        checked += 1
        dot = ux * nx + uy * ny
        if abs(dot) > 1e-9:
            bad.append("%s:%d  ux·n = %.4f  （直角ではない）\n    %s\n    %s"
                       % (f, i + 1, dot, ln.strip(), lines[j].strip()))
        if ny > 0:
            bad.append("%s:%d  n が下を向いている（外向きは ny < 0）" % (f, i + 1))

print("調べた斜面の座標系:", checked, "組")
if bad:
    print("NG")
    for b in bad:
        print(" ", b)
    sys.exit(1)
print("OK  すべて (ux, uy) ⊥ (nx, ny) で、n は外（上）向き")
