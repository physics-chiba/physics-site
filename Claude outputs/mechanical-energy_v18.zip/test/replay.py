#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""1-11 と 1-7 の「続き」の再生を、時刻を追ってスクリーンショットで確かめる。"""
import pathlib, sys
from playwright.sync_api import sync_playwright
ROOT = pathlib.Path(__file__).resolve().parent.parent
PAGE = ROOT / "dist" / "mechanical-energy.html"
OUT = ROOT / "shots_replay"; OUT.mkdir(exist_ok=True)
JOBS = [("m1-11", [0.0, 0.17, 0.333, 0.5, 0.667, 0.833, 1.0]),
        ("m1-7",  [0.0, 0.25, 0.5, 0.72, 0.9, 1.0])]
with sync_playwright() as pw:
    b = pw.chromium.launch()
    p = b.new_page(viewport={"width":1300,"height":1100}, device_scale_factor=1)
    errs=[]; p.on("pageerror", lambda e: errs.append(str(e)))
    p.goto(PAGE.as_uri()); p.wait_for_timeout(700)
    for sid, fracs in JOBS:
        p.evaluate("(id)=>window.TEST.goto(id)", sid); p.wait_for_timeout(150)
        p.evaluate("()=>window.TEST.set({opts:{showF:true,showV:true,showA:true}})")
        for f in fracs:
            p.evaluate("""(f)=>{var s=st.sims[st.cur],d=DEFS[st.cur];
              s._played=true; s.t=d.tEnd(V(s))*f; s.playing=false; renderActive();}""", f)
            p.wait_for_timeout(200)
            cv = p.query_selector(".cvwrap")
            cv.screenshot(path=str(OUT / ("%s_%03d.png" % (sid, round(f*100)))))
    b.close()
print("errors:", errs); print("saved", OUT)
