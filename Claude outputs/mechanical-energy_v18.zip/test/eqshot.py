#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""左下の「くらべる2点で立式する」の欄だけを切り取って保存する（バツ印の確認用）。
  python3 test/eqshot.py m2-1 [out.png]
"""
import pathlib
import sys

from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
PAGE = ROOT / "dist" / "mechanical-energy.html"

sid = sys.argv[1]
out = sys.argv[2] if len(sys.argv) > 2 else "/tmp/eq.png"

with sync_playwright() as pw:
    b = pw.chromium.launch()
    p = b.new_page(viewport={"width": 1400, "height": 1100}, device_scale_factor=2)
    errs = []
    p.on("pageerror", lambda e: errs.append(str(e)))
    p.goto(PAGE.as_uri())
    p.wait_for_timeout(700)
    p.evaluate("(id)=>window.TEST.goto(id)", sid)
    p.wait_for_timeout(160)
    p.evaluate("window.TEST.toEnd()")
    p.wait_for_timeout(200)
    p.evaluate("()=>{document.getElementById('cbAllEq').checked=true;"
               "document.getElementById('cbAllEq').dispatchEvent(new Event('change',{bubbles:true}));}")
    p.wait_for_timeout(300)
    p.evaluate("""()=>{
      var hs=document.querySelectorAll('.eqhead');
      for(var i=0;i<hs.length;i++){ if(!hs[i].parentNode.className.match(/open/)) hs[i].click(); }
    }""")
    p.wait_for_timeout(400)
    el = p.query_selector("#eqzone") or p.query_selector(".eqzone")
    el.screenshot(path=out)
    print("errors:", errs)
    print("saved", out)
    b.close()
