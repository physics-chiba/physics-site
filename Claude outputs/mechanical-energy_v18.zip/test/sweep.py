#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""変数をいろいろ変えて、図の中の文字が重ならないかを総当たりで調べる。"""
import pathlib, json, sys
from playwright.sync_api import sync_playwright
ROOT = pathlib.Path(__file__).resolve().parent.parent
PAGE = ROOT / "dist" / "mechanical-energy.html"
CASES = {
 'm1-1': [{'v0':1,'m':0.5},{'v0':8,'m':5},{'v0':4,'m':2},{'v0':8,'m':0.5}],
 'm1-2': [{'h':5,'m':0.5},{'h':20,'m':5},{'h':12.5,'m':2},{'h':5,'m':5}],
 'm1-3': [{'th':15,'h':1,'m':0.5},{'th':75,'h':5,'m':5},{'th':45,'h':3,'m':2},{'th':15,'h':5,'m':5},{'th':75,'h':1,'m':0.5}],
 'm1-5': [{'h':1,'m':0.5},{'h':5,'m':5},{'h':3,'m':1},{'h':5,'m':0.5}],
 'm1-6': [{'th':10,'v0':0,'l':0.6,'m':0.5},{'th':75,'v0':3,'l':1.6,'m':5},{'th':40,'v0':0,'l':1.0,'m':1},
          {'th':75,'v0':0,'l':0.6,'m':5},{'th':10,'v0':3,'l':1.6,'m':0.5}],
 'm1-4': [{'v0':3,'th':15,'m':0.5},{'v0':8,'th':75,'m':5},{'v0':6,'th':30,'m':2},
          {'v0':8,'th':15,'m':5},{'v0':3,'th':75,'m':0.5}],
 'm1-7': [{'v0':14,'th':35,'m':100},{'v0':16,'th':60,'m':500},{'v0':14,'th':40,'m':200},
          {'v0':16,'th':35,'m':500},{'v0':14,'th':60,'m':100},{'v0':15,'th':50,'m':300}],
 'm1-8': [{'v0':6,'th':15,'h':0,'m':0.5},{'v0':12,'th':75,'h':5,'m':4},{'v0':9,'th':45,'h':2,'m':1},
          {'v0':12,'th':15,'h':5,'m':4},{'v0':6,'th':75,'h':0,'m':0.5}],
 'm1-9': [{'x0':0.1,'k':20,'m':0.5},{'x0':0.4,'k':80,'m':3},{'x0':0.3,'k':40,'m':1},{'x0':0.4,'k':20,'m':3}],
 'm1-10': [{'v0':2,'k':400,'m':0.5},{'v0':5,'k':150,'m':2},{'v0':4,'k':200,'m':1},
           {'v0':5,'k':400,'m':0.5},{'v0':2,'k':150,'m':2}],
 'm1-11': [{'x0':0.15,'k':300,'m':2},{'x0':0.30,'k':600,'m':1},{'x0':0.25,'k':500,'m':1},
           {'x0':0.30,'k':300,'m':2},{'x0':0.15,'k':600,'m':1}],
 'm1-12': [{'k':30,'d':0},{'k':100,'d':0.1},{'k':50,'d':0},{'k':30,'d':0.1}],
 'm1-13': [{'h':1.5,'v0':0,'m':0.5},{'h':3.5,'v0':4,'m':4},{'h':2.5,'v0':0,'m':1},{'h':3.5,'v0':0,'m':4}],
 'm2-1': [{'v0':3,'mu':0.5,'m':0.5},{'v0':7,'mu':0.2,'m':5},{'v0':5,'mu':0.3,'m':2},{'v0':7,'mu':0.5,'m':0.5}],
 'm2-2': [{'th':15,'mu':0.1,'v0':3,'m':0.5},{'th':45,'mu':0.5,'v0':7,'m':5},{'th':30,'mu':0.2,'v0':6,'m':2},
          {'th':15,'mu':0.5,'v0':7,'m':5},{'th':45,'mu':0.1,'v0':3,'m':0.5}],
 'm2-3': [{'k':40,'d':0},{'k':100,'d':0.08},{'k':50,'d':0},{'k':40,'d':0.08}],
 'm2-4': [{'x0':0.20,'k':40,'m':1.5,'mu':0.20},{'x0':0.40,'k':100,'m':0.5,'mu':0.05},
          {'x0':0.30,'k':40,'m':1.0,'mu':0.10},{'x0':0.20,'k':100,'m':1.5,'mu':0.20},
          {'x0':0.40,'k':40,'m':0.5,'mu':0.05},{'x0':0.40,'k':40,'m':1.5,'mu':0.20}],
 'm2-5': [{'Ft':32,'mu':0.50,'th':45,'m':3.0},{'Ft':44,'mu':0.15,'th':20,'m':2.0},
          {'Ft':36,'mu':0.30,'th':30,'m':2.0},{'Ft':32,'mu':0.15,'th':45,'m':2.0},
          {'Ft':44,'mu':0.50,'th':20,'m':3.0},{'Ft':36,'mu':0.50,'th':45,'m':3.0}],
}
TIMES = [0.0, 0.15, 0.25, 0.35, 0.5, 0.6, 0.75, 0.9, 1.0]
bad = []
with sync_playwright() as pw:
    b = pw.chromium.launch(); p = b.new_page(viewport={'width':1300,'height':1000})
    errs=[]; p.on('pageerror', lambda e: errs.append(str(e)))
    p.goto(PAGE.as_uri()); p.wait_for_timeout(700)
    for sid, cases in CASES.items():
        p.evaluate("(id)=>window.TEST.goto(id)", sid); p.wait_for_timeout(160)
        # ★力・速度・加速度をすべて出した状態で調べる★（第17回）
        # 加速度の矢印の位置を直したので、その文字も重なり検査に入れる。
        p.evaluate("()=>window.TEST.set({opts:{showF:true,showV:true,showA:true}})")
        p.wait_for_timeout(80)
        for cs in cases:
            p.evaluate("(o)=>window.TEST.set({vars:o})", cs); p.wait_for_timeout(120)
            T = p.evaluate("()=>{const d=DEFS[st.cur];return d.tEnd(V(st.sims[st.cur]));}")
            for f in TIMES:
                p.evaluate("(t)=>{window.__labelLog=[];window.TEST.set({t:t});}", round(T*f,4))
                p.wait_for_timeout(60)
                ov = p.evaluate("()=>window.TEST.labelOverlap()")
                if ov:
                    bad.append({'sim':sid,'vars':cs,'f':f,'ov':[(o['a'],o['b'],o['ox'],o['oy']) for o in ov]})
    b.close()
print('page errors:', errs)
print('重なりのあった場合の数:', len(bad))
for x in bad[:80]:
    print(' ', x['sim'], x['vars'], 't=', x['f'], x['ov'][:3])
sys.exit(1 if bad else 0)
