#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""グラフの欄（＋／－／もどす のボタン）を切り取って保存し、
そのボタンがちゃんときいているかも確かめる。
  python3 test/zoomshot.py [out.png]
"""
import pathlib
import sys

from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
PAGE = ROOT / "dist" / "mechanical-energy.html"
out = sys.argv[1] if len(sys.argv) > 1 else "/tmp/zoom.png"

with sync_playwright() as pw:
    b = pw.chromium.launch()
    p = b.new_page(viewport={"width": 1400, "height": 1100}, device_scale_factor=2)
    errs = []
    p.on("pageerror", lambda e: errs.append(str(e)))
    p.goto(PAGE.as_uri())
    p.wait_for_timeout(700)
    p.evaluate("()=>window.TEST.goto('m1-1')")
    p.wait_for_timeout(200)
    p.evaluate("window.TEST.toEnd()")
    p.wait_for_timeout(200)
    p.evaluate("()=>window.TEST.openAll()")
    p.wait_for_timeout(400)
    base = p.evaluate("()=>window.TEST.graphMap('KUE')")
    p.click('[data-gz="in"][data-gk="KUE"]')
    p.wait_for_timeout(250)
    zin = p.evaluate("()=>window.TEST.gview('KUE')")
    p.click('[data-gz="out"][data-gk="KUE"]')
    p.click('[data-gz="out"][data-gk="KUE"]')
    p.wait_for_timeout(250)
    zout = p.evaluate("()=>window.TEST.gview('KUE')")
    p.click('[data-gz="reset"][data-gk="KUE"]')
    p.wait_for_timeout(250)
    zrst = p.evaluate("()=>window.TEST.gview('KUE')")
    print("自動の目もり :", base)
    print("＋を1回      :", zin)
    print("－を2回      :", zout)
    print("もどす       :", zrst, "(null なら自動にもどっている)")
    ok = (zin and (zin["xmax"] - zin["xmin"]) < (base["xmax"] - base["xmin"]) - 1e-9
          and zout and (zout["xmax"] - zout["xmin"]) > (zin["xmax"] - zin["xmin"]) + 1e-9
          and zrst is None)
    print("ボタンの動き:", "OK" if ok else "NG")
    p.evaluate("()=>window.TEST.gview('KUE', {xmin:0,xmax:1.2,ymin:0,ymax:40})")
    p.wait_for_timeout(250)
    p.evaluate("()=>window.TEST.gview('KUE', null)")
    p.wait_for_timeout(250)
    el = p.query_selector("#gb_KUE")
    el.screenshot(path=out)
    print("errors:", errs)
    print("saved", out)
    b.close()
    sys.exit(0 if ok and not errs else 1)
