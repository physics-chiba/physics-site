#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""自動テスト。

    python3 test/run_test.py 1
    python3 test/run_test.py 2

を続けて実行し、test/result_1.json と result_2.json が **完全一致** することを確かめる。

チェックするもの
  * ページエラー 0 / コンソールエラー 0
  * 外部リクエスト 0（file:// 以外へ 1 本も飛ばない ＝ 完全オフライン）
  * 物理の検算（E のずれ・√(2gh)・振り子・摩擦の E(t)−E(0)=W など）
  * 全シムの既定値・計算結果の帯・各点の表・くらべる式・ステップ図
  * 図の中の文字の重なり（window.__labelLog）
  * 横軸（時間）の目盛りが運動の終わりまで届いているか
  * グラフのドラッグ・まとめて開く・オレンジの状況ボタン
  * ハッシュ URL で直接開けること
  * レイアウトの安定（変数を変えて戻すと位置が同じ）
  * 横幅 320〜1440 px で横スクロールが出ない（全シム）
"""
import json
import pathlib
import sys

from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
PAGE = ROOT / "dist" / "mechanical-energy.html"
RUN = sys.argv[1] if len(sys.argv) > 1 else "1"
OUT = ROOT / "test" / f"result_{RUN}.json"

results = {}
errors = []
external = []
console_errors = []


def box(page):
    return page.evaluate(
        "()=>[...document.querySelectorAll('h1,h2,canvas,.card,.simtitle')]"
        ".map(e=>{const r=e.getBoundingClientRect();"
        "return [Math.round(r.x),Math.round(r.y),Math.round(r.width)].join(',')})")


def main():
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        page = browser.new_page(viewport={"width": 1280, "height": 950})
        page.on("pageerror", lambda e: errors.append(str(e)))
        # ★第18回★ このページに外部リソースは「先生が足したアクセス数カウンタ」だけ。
        #   ネットにつながらない所で開くと、その1本だけが読み込みに失敗する。
        #   （ほかに外部リソースが無いことは、上の OK_HOSTS の検査が保証している）
        page.on("console", lambda m: console_errors.append(m.text)
                if (m.type == "error" and not m.text.startswith("Failed to load resource"))
                else None)
        # ★第18回★ 先生が足したアクセス数カウンタ（GoatCounter）だけは通す。
        #   それ以外の外部通信は 0 でなければならない（完全オフラインの約束）。
        OK_HOSTS = ("file:", "https://physics-chiba.goatcounter.com/",
                    "http://gc.zgo.at/", "https://gc.zgo.at/")
        page.on("request", lambda r: None if r.url.startswith(OK_HOSTS) else external.append(r.url))
        page.goto(PAGE.as_uri())
        page.wait_for_timeout(700)

        # --- 1. 物理の検算（UI によらない） ---
        results["physics"] = page.evaluate("()=>window.TEST.check()")

        # --- 2. 全シム：既定値・帯・表・式・ステップ図・重なり ---
        sims = page.evaluate("()=>window.TEST.sims()")
        results["sim_list"] = sims
        per = {}
        for sid in sims:
            page.goto(PAGE.as_uri() + "#" + sid)
            page.wait_for_timeout(300)
            page.evaluate("()=>window.TEST.pause()")
            rec = {
                "state": page.evaluate("()=>window.TEST.state()"),
                "open": page.evaluate("()=>window.TEST.graphsOpen()"),
                "resbar_t0": page.evaluate("()=>window.TEST.resbar()"),
                "readout_t0": page.evaluate("()=>window.TEST.readout()"),
                "step": page.evaluate("()=>window.TEST.step()"),
                "compare_t0": page.evaluate("()=>window.TEST.compare()")["shown"],
                "formulas": page.evaluate("()=>window.TEST.formulas()"),
            }
            # 運動を最後まで進めた状態
            page.evaluate("()=>{window.TEST.openAll();window.__labelLog=[];window.TEST.toEnd();}")
            page.wait_for_timeout(200)
            # ★重なりの検査は、ほかの操作で描き直す前に読む★
            #   （描き直すと __labelLog に同じ文字が二重に積まれて、自分自身と重なって見える）
            rec["xticks"] = page.evaluate("()=>window.TEST.xTicks()")
            rec["overlap"] = page.evaluate("()=>window.TEST.labelOverlap()")
            rec["ghost_v"] = page.evaluate("()=>window.TEST.ghostVel()")
            rec["resbar_end"] = page.evaluate("()=>window.TEST.resbar()")
            rec["ptab"] = page.evaluate("()=>window.TEST.ptab()")
            rec["compare_end"] = page.evaluate("()=>window.TEST.compare()")
            # 図の下の立式3つ（見出し・○✕・開閉）と「仕事を表示」の中身
            rec["eqzone"] = page.evaluate("()=>window.TEST.eqzone()")
            # 立式でくらべる2点を1組ずつ選んだときの式
            rec["pairs"] = page.evaluate(
                "()=>{var bs=document.querySelectorAll('#eqzone .eqpair'),o=[],i;"
                "for(i=0;i<bs.length;i++){bs[i].click();"
                "o.push(window.TEST.eqzone().secs.map(function(x){return x.key+':'+x.badge;}).join(','));}"
                "if(bs.length)bs[bs.length-1].click();return o;}")
            # 「仕事の分析」モード：全部の力の仕事と、図の中のクリックできる場所
            rec["work_mode"] = page.evaluate("()=>window.TEST.workMode(true)")
            rec["work_panel"] = page.evaluate("()=>window.TEST.workPanel()")
            rec["force_hits"] = page.evaluate("()=>window.TEST.forceHits()")
            rec["work_click"] = page.evaluate(
                "()=>window.TEST.forceHits().map(function(h){return window.TEST.clickForce(h.key);})")
            page.evaluate("()=>window.TEST.workMode(false)")
            per[sid] = rec
        results["per_sim"] = per

        # --- 2b. オレンジの状況ボタン ---
        acts = {}
        for sid in sims:
            page.goto(PAGE.as_uri() + "#" + sid)
            page.wait_for_timeout(260)
            rows = []
            n = page.evaluate("()=>document.querySelectorAll('[data-act]').length")
            for i in range(n):
                rows.append(page.evaluate("(i)=>window.TEST.act(i)", i))
                rows.append(page.evaluate(
                    "()=>[...document.querySelectorAll('[data-act]')].map(b=>b.className)"))
            acts[sid] = rows
        results["actions"] = acts

        # --- 2c. グラフのドラッグ操作 ---
        page.goto(PAGE.as_uri() + "#m1-2")
        page.wait_for_timeout(400)
        gcv = page.query_selector("#gc_KUE")
        gcv.scroll_into_view_if_needed()
        page.wait_for_timeout(200)
        bb = gcv.bounding_box()
        drag = {}

        def gmap():
            return page.evaluate('()=>window.TEST.graphMap("KUE")')

        drag["auto"] = gmap()
        page.mouse.move(bb["x"] + bb["width"] * 0.6, bb["y"] + bb["height"] * 0.5)
        page.mouse.down()
        page.mouse.move(bb["x"] + bb["width"] * 0.4, bb["y"] + bb["height"] * 0.6, steps=5)
        page.mouse.up()
        page.wait_for_timeout(180)
        drag["pan"] = gmap()
        page.dblclick("#gc_KUE"); page.wait_for_timeout(150)
        page.mouse.move(bb["x"] + bb["width"] * 0.5, bb["y"] + bb["height"] * 0.94)
        page.mouse.down()
        page.mouse.move(bb["x"] + bb["width"] * 0.8, bb["y"] + bb["height"] * 0.94, steps=5)
        page.mouse.up()
        page.wait_for_timeout(180)
        drag["scale_x"] = gmap()
        page.dblclick("#gc_KUE"); page.wait_for_timeout(150)
        page.mouse.move(bb["x"] + bb["width"] * 0.5, bb["y"] + bb["height"] * 0.5)
        page.mouse.wheel(0, -300)
        page.wait_for_timeout(220)
        drag["wheel"] = gmap()
        page.dblclick("#gc_KUE"); page.wait_for_timeout(200)
        drag["reset"] = gmap()
        results["graph_drag"] = drag

        # --- 2d. まとめて開く ---
        page.goto(PAGE.as_uri() + "#m1-1")
        page.wait_for_timeout(400)
        openall = {"before": page.evaluate("()=>window.TEST.graphsOpen()")}
        openall["after"] = page.evaluate("()=>window.TEST.openAll()")
        openall["again"] = page.evaluate("()=>window.TEST.openAll()")
        results["open_all"] = openall

        # --- 2e. 「3つの式を表示」は全シム共通か ---
        alleq = {}
        page.goto(PAGE.as_uri() + "#m2-1")
        page.wait_for_timeout(350)
        page.evaluate("()=>window.TEST.toEnd()")
        page.wait_for_timeout(150)
        alleq["m2-1_default"] = page.evaluate("()=>window.TEST.eqzone().secs")
        alleq["m2-1_on"] = page.evaluate("()=>window.TEST.allEq(true)")
        page.goto(PAGE.as_uri() + "#m1-5")
        page.wait_for_timeout(350)
        page.evaluate("()=>window.TEST.toEnd()")
        page.wait_for_timeout(150)
        alleq["m1-5_shared"] = page.evaluate("()=>window.TEST.eqzone().secs")
        alleq["m1-5_off"] = page.evaluate("()=>window.TEST.allEq(false)")
        alleq["m1-5_toggle_wk"] = page.evaluate("()=>window.TEST.eqToggle('wk')")
        results["all_eq"] = alleq

        # --- 3. ハッシュ URL で直接開ける ---
        hashes = {}
        for sid in ["m1-3", "m1-6", "m1-13", "m2-1", "m2-3"]:
            page.goto(PAGE.as_uri() + "#" + sid)
            page.wait_for_timeout(400)
            hashes[sid] = page.evaluate("()=>({sim:window.TEST.state().sim,"
                                        "title:document.querySelector('.simtitle').textContent,"
                                        "url:document.getElementById('urltext').textContent})")
        results["hash_open"] = hashes

        # --- 4. レイアウトの安定 ---
        page.goto(PAGE.as_uri() + "#m1-3")
        page.wait_for_timeout(400)
        before = box(page)
        page.evaluate("()=>window.TEST.set({vars:{th:60},t:0.5})")
        page.wait_for_timeout(150)
        page.evaluate("()=>window.TEST.set({vars:{th:30},t:0})")
        page.wait_for_timeout(150)
        results["layout_stable"] = (before == box(page))

        # --- 5. 横スクロールが出ない（全シム × 代表的な幅） ---
        hs = {}
        for w in (320, 390, 768, 1024, 1360, 1440):
            page.set_viewport_size({"width": w, "height": 800})
            bad = []
            for sid in sims:
                page.goto(PAGE.as_uri() + "#" + sid)
                page.wait_for_timeout(220)
                if page.evaluate("()=>document.documentElement.scrollWidth>window.innerWidth+1"):
                    bad.append(sid)
                page.evaluate("()=>window.TEST.openAll()")
                page.wait_for_timeout(150)
                if page.evaluate("()=>document.documentElement.scrollWidth>window.innerWidth+1"):
                    bad.append(sid + "(open)")
            hs[str(w)] = bad
        results["h_scroll"] = hs

        browser.close()

    results["errors"] = errors
    results["console_errors"] = console_errors
    results["external"] = external
    OUT.write_text(json.dumps(results, ensure_ascii=False, indent=1), encoding="utf-8")

    ov = {k: v["overlap"] for k, v in results["per_sim"].items() if v["overlap"]}
    xt = {k: [g for g, r in v["xticks"].items() if not r["ok"]]
          for k, v in results["per_sim"].items()}
    xt = {k: v for k, v in xt.items() if v}
    print(f"--- run {RUN} ---")
    print("pageerrors:", len(errors), " console errors:", len(console_errors),
          " external requests:", len(external))
    print("layout_stable:", results["layout_stable"])
    print("h_scroll:", json.dumps(results["h_scroll"], ensure_ascii=False))
    print("label overlaps:", json.dumps(ov, ensure_ascii=False))
    print("x ticks NG:", json.dumps(xt, ensure_ascii=False))
    print("physics:", json.dumps(results["physics"], ensure_ascii=False))


if __name__ == "__main__":
    main()
