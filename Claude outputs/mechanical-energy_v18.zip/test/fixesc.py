#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""JS 文字列の中の「\\;」（バックスラッシュ1個＋;）を探して数える。
   1個だと JS のエスケープでただの ; になり、KaTeX のすきまが消える。必ず2個にすること。"""
import re
import sys
import pathlib

BAD = re.compile(r'(?<!\\)\\;')          # \ が1個だけ続いて ; になっているところ

for f in sorted(pathlib.Path('src').glob('*.js')):
    s = f.read_text(encoding='utf-8')
    hits = [m.start() for m in BAD.finditer(s)]
    if hits:
        print(f'--- {f}: {len(hits)} か所')
        for pos in hits:
            print('   ', s[max(0, pos - 60):pos + 20].replace('\n', '/'))
    if len(sys.argv) > 1 and sys.argv[1] == 'fix' and hits:
        f.write_text(BAD.sub(r'\\\\;', s), encoding='utf-8')
        print(f'    → {len(hits)} か所を「\\\\;」に直しました')
print('done')
