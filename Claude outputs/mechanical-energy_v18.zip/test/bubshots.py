#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""各シミュレーションの「運動が終わったところ（吹きだしが出た図）」だけを切り取って保存する。
先生の確認用エクセル（シム名＋スクショ）のもとになる。"""
import pathlib
import sys

from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
PAGE = ROOT / "dist" / "mechanical-energy.html"
OUT = ROOT / "shots" / "bub"
OUT.mkdir(parents=True, exist_ok=True)

SIMS = ["m1-1", "m1-2", "m1-3", "m1-4", "m1-5", "m1-6", "m1-7", "m1-8", "m1-9", "m1-10",
        "m1-11", "m1-12", "m1-13", "m2-1", "m2-2", "m2-3", "m2-4", "m2-5"]
if len(sys.argv) > 1:
    SIMS = sys.argv[1].split(",")

with sync_playwright() as pw:
    b = pw.chromium.launch()
    p = b.new_page(viewport={"width": 1400, "height": 1100}, device_scale_factor=2)
    errs = []
    p.on("pageerror", lambda e: errs.append(str(e)))
    p.goto(PAGE.as_uri())
    p.wait_for_timeout(700)
    names = {}
    for sid in SIMS:
        p.evaluate("(id)=>window.TEST.goto(id)", sid)
        p.wait_for_timeout(160)
        p.evaluate("window.TEST.toEnd()")
        p.wait_for_timeout(320)
        box = p.evaluate("""()=>{
          var w=document.querySelector('.cvwrap'); var r=w.getBoundingClientRect();
          return {x:r.x+window.scrollX, y:r.y+window.scrollY, w:r.width, h:r.height};
        }""")
        names[sid] = p.evaluate("(id)=>DEFS[id].tab", sid)
        p.screenshot(path=str(OUT / (sid + ".png")), full_page=True,
                     clip={"x": box["x"] - 4, "y": box["y"] - 4,
                           "width": box["w"] + 8, "height": box["h"] + 8})
    b.close()
import json
(OUT / "names.json").write_text(json.dumps(names, ensure_ascii=False, indent=1), encoding="utf-8")
print("errors:", errs)
print("saved to", OUT)
