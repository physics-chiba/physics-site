#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""好きな時刻の図だけを切り取って保存する（目で確かめる用）。
  python3 test/at.py m1-7 0.06 [out.png]
"""
import pathlib
import sys

from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
PAGE = ROOT / "dist" / "mechanical-energy.html"

sid = sys.argv[1]
tt = float(sys.argv[2]) if len(sys.argv) > 2 else 0.0
out = sys.argv[3] if len(sys.argv) > 3 else "/tmp/at.png"

with sync_playwright() as pw:
    b = pw.chromium.launch()
    p = b.new_page(viewport={"width": 1400, "height": 1100}, device_scale_factor=2)
    errs = []
    p.on("pageerror", lambda e: errs.append(str(e)))
    p.goto(PAGE.as_uri())
    p.wait_for_timeout(700)
    p.evaluate("(id)=>window.TEST.goto(id)", sid)
    p.wait_for_timeout(160)
    p.evaluate("(t)=>window.TEST.set({t:t})", tt)
    p.wait_for_timeout(260)
    box = p.evaluate("""()=>{
      var w=document.querySelector('.cvwrap'); var r=w.getBoundingClientRect();
      return {x:r.x+window.scrollX, y:r.y+window.scrollY, w:r.width, h:r.height};
    }""")
    p.screenshot(path=out, full_page=True,
                 clip={"x": box["x"] - 4, "y": box["y"] - 4,
                       "width": box["w"] + 8, "height": box["h"] + 8})
    print("errors:", errs)
    print("saved", out)
    b.close()
