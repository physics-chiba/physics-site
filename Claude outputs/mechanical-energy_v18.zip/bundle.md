# mechanical-energy.html ソース全文（第18回・2026-09-03）

`node build.js` で `src/*` をこの順に連結し、KaTeX の CSS/JS/woff2 を base64 で埋めこんで
`dist/mechanical-energy.html`（1ファイル・約 940 KB・完全オフライン）を作る。

## build.js

```js
#!/usr/bin/env node
/* 単一 HTML ビルドスクリプト（mechanical-energy.html）
 * src/ の部品を決まった順に連結して dist/mechanical-energy.html を作る。
 * KaTeX は CSS / JS / フォント(woff2 を base64) をすべて埋め込み、完全オフラインにする。
 * ※ basics-of-motion-on-plane.html の build.js をそのまま受けついでいる。
 */
'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const SRC = path.join(ROOT, 'src');
const OUT = path.join(ROOT, 'dist', 'mechanical-energy.html');
const KATEX = '/home/claude/.npm-global/lib/node_modules/markdownlint-cli2/node_modules/katex/dist';
const KATEX_VER = '0.16.45';

/* この教材で使う字種に必要なものだけ埋め込む */
const FONT_WHITELIST = [
  'KaTeX_Main-Regular', 'KaTeX_Main-Bold', 'KaTeX_Main-Italic',
  'KaTeX_Math-Italic', 'KaTeX_Math-BoldItalic',
  'KaTeX_Size1-Regular', 'KaTeX_Size2-Regular', 'KaTeX_Size3-Regular', 'KaTeX_Size4-Regular',
  'KaTeX_AMS-Regular'
];

function read(p) { return fs.readFileSync(p, 'utf8'); }

/** KaTeX の CSS を、@font-face ブロック単位で走査して差し替える（一括正規表現置換はしない） */
function inlineKatexCss() {
  const css = read(path.join(KATEX, 'katex.min.css'));
  const out = [];
  let i = 0, kept = 0, dropped = 0;
  while (i < css.length) {
    const at = css.indexOf('@font-face{', i);
    if (at === -1) { out.push(css.slice(i)); break; }
    out.push(css.slice(i, at));
    const end = css.indexOf('}', at);
    if (end === -1) { out.push(css.slice(at)); break; }
    const block = css.slice(at, end + 1);
    const face = rewriteFontFace(block);
    if (face) { out.push(face); kept++; } else { dropped++; }
    i = end + 1;
  }
  console.log(`  @font-face: ${kept} 個を埋め込み / ${dropped} 個を除外`);
  return out.join('');
}

function rewriteFontFace(block) {
  const m = block.indexOf('fonts/');
  if (m === -1) return null;
  const tail = block.slice(m + 'fonts/'.length);
  const dot = tail.indexOf('.');
  if (dot === -1) return null;
  const name = tail.slice(0, dot);
  if (FONT_WHITELIST.indexOf(name) === -1) return null;

  const woff2 = path.join(KATEX, 'fonts', name + '.woff2');
  if (!fs.existsSync(woff2)) return null;
  const b64 = fs.readFileSync(woff2).toString('base64');

  const srcAt = block.indexOf('src:');
  if (srcAt === -1) return null;
  const head = block.slice(0, srcAt);
  return head + `src:url(data:font/woff2;base64,${b64}) format("woff2")}`;
}

const JS_FILES = [
  '30_physics.js',
  '40_draw.js',
  '45_defs.js',
  '47_step.js',
  '50_mode1.js',
  '60_mode2.js',
  '80_ui.js',
  '90_boot.js'
];

function build() {
  console.log('ビルド開始');
  const katexCss = inlineKatexCss();
  const katexJs = read(path.join(KATEX, 'katex.min.js'));

  const head = read(path.join(SRC, '00_head.html'));
  const style = read(path.join(SRC, '10_style.css'));
  const body = read(path.join(SRC, '20_body.html'));
  const scripts = JS_FILES
    .map(f => `/* ===== ${f} ===== */\n${read(path.join(SRC, f))}`)
    .join('\n');

  const html = `<!DOCTYPE html>
<html lang="ja">
<head>
${head}
<style>
/* ===== KaTeX ${KATEX_VER} (fonts embedded / offline) ===== */
${katexCss}
</style>
<style>
/* ===== 10_style.css ===== */
${style}
</style>
</head>
<body>
${body}
<script>/* ===== KaTeX ${KATEX_VER} ===== */
${katexJs}
</script>
<script>
${scripts}
</script>
<!-- アクセス数のカウント（GoatCounter・Cookieなし） -->
<!-- ★先生が第18回に手で足したもの。ビルドで消えないよう、ここに入れてある。
     このページで唯一の外部通信。test/run_test.py はこのホストだけ通す。 -->
<script data-goatcounter="https://physics-chiba.goatcounter.com/count"
        async src="https://gc.zgo.at/count.js"></script>
</body>
</html>
`;

  fs.mkdirSync(path.dirname(OUT), { recursive: true });
  fs.writeFileSync(OUT, html, 'utf8');
  const kb = (Buffer.byteLength(html) / 1024).toFixed(0);
  console.log(`出力: ${OUT} (${kb} KB)`);
}

build();
```

## src/10_style.css

```css
/* =========================================================
   一次元運動と平面運動の基本 — デザイン定義
   ・色は「力＝赤／速度＝青／加速度＝オレンジ」を主役に、UI は青系で統一
   ・余白は 4 の倍数（4 / 6 / 8 / 12 / 16 / 24）だけを使う
   ========================================================= */
:root{
  /* 文字と線 */
  --ink:#16202b;
  --ink2:#3d4c5a;
  --sub:#66737f;
  --line:#e2e7ec;
  --line2:#cfd8e0;

  /* 面 */
  --bg:#f2f5f8;
  --card:#ffffff;
  --panel:#f7f9fb;
  --panel2:#eef3f8;

  /* アクセント */
  --accent:#1663b5;
  --accent-d:#0f4c8f;
  --accent-l:#e8f0fa;
  --orange:#e07b18;
  --orange-d:#a85c0c;
  --orange-l:#fff5e8;
  --ok:#1c8f4a;
  --ok-l:#e9f7ee;
  --ng:#c0392b;

  /* 物理量の色（矢印・グラフと共通） */
  --force:#d1352b;
  --vel:#1663b5;
  --acc:#e07b18;

  /* 角丸・影 */
  --r-s:6px;
  --r-m:9px;
  --r-l:14px;
  --sh-1:0 1px 2px rgba(22,32,43,.05);
  --sh-2:0 2px 8px rgba(22,32,43,.07);
  --sh-3:0 4px 16px rgba(22,32,43,.10);

  --mono:"SFMono-Regular",Consolas,"Liberation Mono",Menlo,monospace;
  --jp:"Hiragino Kaku Gothic ProN","Hiragino Sans","Yu Gothic","Meiryo",
       system-ui,-apple-system,"Segoe UI",sans-serif;
}
*{box-sizing:border-box}
html{-webkit-text-size-adjust:100%}
body{
  margin:0; background:var(--bg); color:var(--ink);
  font-family:var(--jp); font-size:16px; line-height:1.7;
  overflow-x:hidden;
  -webkit-font-smoothing:antialiased;
}
.wrap{max-width:1320px;margin:0 auto;padding:20px 14px 72px}

/* ===== 見出し ===== */
h1{font-size:1.42rem;line-height:1.45;margin:0 0 2px;letter-spacing:.01em}
.subtitle{font-size:1rem;color:var(--accent);font-weight:700;margin:0 0 8px}
h2{font-size:1.08rem;margin:24px 0 8px}
h3{font-size:.98rem;margin:0 0 6px;color:var(--accent-d);
  display:flex;align-items:center;gap:7px}
h3::before{content:'';width:4px;height:1.05em;border-radius:2px;background:var(--accent);flex:none}

.card{background:var(--card);border:1px solid var(--line);border-radius:var(--r-l);
  padding:16px;margin:12px 0;box-shadow:var(--sh-1)}
.purpose{border-left:5px solid var(--orange);background:linear-gradient(180deg,#fffdfa,#fff)}
.purpose ol{margin:2px 0 0;padding-left:1.35em}
.purpose li{margin:1px 0}
.lead{font-weight:700;margin:0 0 2px;color:var(--orange-d)}
.mini{font-size:.85rem;color:var(--sub);margin:4px 0;line-height:1.75}

.val{font-family:var(--mono);font-variant-numeric:tabular-nums;text-align:right;white-space:nowrap}

canvas{display:block;background:#fff;border:1px solid var(--line);border-radius:var(--r-m);
  width:100%;height:auto;touch-action:pan-y}
canvas.dragcv{touch-action:none;cursor:grab}
canvas.dragcv:active{cursor:grabbing}

/* ===== ボタン ===== */
button{
  font-family:var(--jp);font-size:.88rem;font-weight:600;
  border:1px solid var(--accent);border-radius:var(--r-m);
  background:var(--accent);color:#fff;padding:5px 14px;cursor:pointer;
  transition:background .12s,border-color .12s,color .12s,box-shadow .12s;
  line-height:1.55;
}
button:hover{background:var(--accent-d);border-color:var(--accent-d)}
button.sub{background:#fff;color:var(--accent)}
button.sub:hover{background:var(--accent-l);color:var(--accent-d)}
button.warm{background:#fff;color:var(--orange-d);border-color:#e6bb85}
button.warm:hover{background:var(--orange-l);border-color:var(--orange)}
button:active{transform:translateY(1px)}
button:focus-visible,input:focus-visible,select:focus-visible,
.gqopt:focus-visible{outline:3px solid rgba(22,99,181,.45);outline-offset:2px}
.btnrow{display:flex;gap:6px;margin:8px 0;flex-wrap:wrap;align-items:center}

/* ===== タブ ===== */
.tabs{display:flex;flex-wrap:wrap;gap:6px;margin:18px 0 6px;align-items:center}
.tabs button{font-size:.9rem;border-radius:999px;background:#fff;color:var(--accent);
  border-color:var(--line2);padding:6px 16px;font-weight:600;box-shadow:var(--sh-1)}
.tabs button:hover{background:var(--accent-l);border-color:var(--accent);color:var(--accent-d)}
.tabs button.on{background:var(--accent);border-color:var(--accent);color:#fff;font-weight:700;
  box-shadow:0 2px 6px rgba(22,99,181,.28)}
.tabs.sub{margin:0 0 4px;gap:5px}
.tabs.sub button{font-size:.83rem;padding:4px 12px;border-color:var(--line2);color:#2a5f96;
  box-shadow:none;border-radius:8px}
.tabs.sub button.on{background:#245a8d;border-color:#245a8d;color:#fff}
/* ゲームのシミュレーションは色を変える */
.tabs.sub button.game{border-color:#e6bb85;color:var(--orange-d);background:var(--orange-l)}
.tabs.sub button.game:hover{border-color:var(--orange)}
.tabs.sub button.game.on{background:var(--orange);border-color:var(--orange);color:#fff}

/* 選んでいるモードのひとこと（ボタンの真下に ▲） */
#modetip{font-size:.8rem;color:var(--accent-d);margin:2px 0 8px;line-height:1.5;
  display:flex;align-items:center;gap:6px}
#modetip:not(:empty)::before{content:'▲';font-size:.62rem;color:var(--accent);transform:translateY(-1px)}

/* 問題モードのスイッチ（モードのタブ列の右端） */
.qswitch{margin-left:auto;flex:none;display:inline-flex;align-items:center;gap:7px;font-size:.85rem;
  background:#fff;border:1px solid #b9e0c6;border-radius:999px;padding:5px 16px;cursor:pointer;
  color:#186c3d;white-space:nowrap;font-weight:600;box-shadow:var(--sh-1)}
.qswitch input{accent-color:var(--ok)}
.qswitch:hover{background:var(--ok-l)}
.qswitch.on{background:var(--ok);color:#fff;border-color:var(--ok);font-weight:700}

/* ===== シミュレーション本体 ===== */
#simhost{padding:16px 16px 18px}
.simhead{display:flex;gap:10px;align-items:baseline;justify-content:space-between;flex-wrap:wrap}
.simtitle{font-size:1.06rem;font-weight:700;color:var(--accent-d);margin:0 0 4px;flex:1 1 auto;
  letter-spacing:.01em}
.simdesc{font-size:.86rem;color:var(--ink2);margin:0 0 12px;line-height:1.7}

.simgrid{display:flex;gap:18px;flex-wrap:wrap;align-items:flex-start}
.simgrid .cv{flex:5 1 470px;min-width:280px;max-width:680px}
.simgrid .side{flex:4 1 420px;min-width:280px;max-width:100%}

/* ===== 図のまわり ===== */
/* 図の下のバー：状況を変えるオレンジのボタン（1行におさめる） */
.cvbar{background:var(--panel);border:1px solid var(--line);border-top:0;
  border-radius:0 0 var(--r-l) var(--r-l);padding:8px 10px}
.cvbar .acts{display:flex;flex-wrap:wrap;gap:5px;justify-content:flex-start}
.cvbar .acts button{font-size:.75rem;padding:3px 9px;border-radius:999px;white-space:nowrap;
  flex:0 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis}
/* ボタンが多いとき（1-1・1-4・1-6・1-7）は、さらに小さくして1行におさめる */
.cvbar .acts.n3 button{font-size:.72rem;padding:3px 8px}
.cvbar .acts.n4 button{font-size:.685rem;padding:2px 7px;letter-spacing:-.01em}
/* いまの状態がその条件になっているボタンは、少し濃く（塗って）見せる */
.cvbar .acts button.on{background:var(--orange-l);border-color:var(--orange);
  color:var(--orange-d);font-weight:700;box-shadow:0 0 0 3px rgba(224,123,24,.14)}
.cvbar .acts button.on:hover{background:#fbe4c8}
/* 「次はこれを押す」ボタン（3-2 の手順の誘導） */
.cvbar .acts button.pulse{background:var(--orange);border-color:var(--orange);color:#fff;font-weight:700}
.cvbar .acts button.pulse:hover{background:var(--orange-d);border-color:var(--orange-d)}
.cvside .cvopts{display:flex;flex-wrap:wrap;gap:4px 12px;align-items:center;font-size:.77rem;
  max-width:100%;
  background:rgba(255,255,255,.96);border:1px solid var(--accent);border-radius:var(--r-m);
  padding:5px 10px;box-shadow:0 0 0 3px var(--accent-l)}
.cvside .cvopts label{display:inline-flex;align-items:center;gap:5px;white-space:nowrap;cursor:pointer;
  font-weight:600;color:var(--ink2);max-width:100%;min-width:0}
.cvside .cvopts label.cvsel{flex:1 1 auto}
.cvside .cvopts select{max-width:100%;min-width:0;flex:0 1 auto;
  overflow:hidden;text-overflow:ellipsis}
.cvside .cvopts .optsl{display:inline-flex;align-items:center;gap:7px}
.cvside .cvopts .optsl input[type=range]{width:104px;accent-color:var(--accent)}
.cvside .cvopts .optsl .vval{font-family:var(--mono);font-variant-numeric:tabular-nums;
  font-size:.8rem;font-weight:600;min-width:5.2em;text-align:right}
.cvside .cvopts select{font-family:var(--jp);font-size:.79rem;padding:2px 6px;
  border:1px solid var(--line2);border-radius:var(--r-s);margin-left:4px;background:#fff}
.cvside > *{max-width:100%}
.cvside .opts{display:flex;flex-wrap:wrap;gap:1px 10px;align-items:center;font-size:.75rem;
  background:rgba(255,255,255,.94);border:1px solid var(--line2);border-radius:var(--r-m);
  padding:5px 9px;box-shadow:var(--sh-1);max-width:100%}
.cvside .opts label{display:inline-flex;align-items:center;gap:5px;white-space:nowrap;cursor:pointer;
  color:var(--ink2)}
.cvside input[type=checkbox]{accent-color:var(--accent);width:15px;height:15px;margin:0}

/* 図（キャンバス）＋その左上にのせる操作エリア */
.cvstage{position:relative}
.cvtop{position:absolute;top:10px;left:10px;right:10px;z-index:2;
  display:flex;flex-wrap:wrap;align-items:flex-start;gap:8px;pointer-events:none}
.cvtop > *{pointer-events:auto}
.cvside{display:flex;flex-direction:column;align-items:flex-start;gap:6px;
  flex:1 1 165px;min-width:0}
.cvstage canvas{border-radius:var(--r-l) var(--r-l) 0 0;border-bottom-color:var(--line)}
.cvstage.nobar canvas{border-radius:var(--r-l)}   /* 下にボタンの帯がないときは四隅とも丸く */

.cvvars{
  display:grid;
  grid-template-columns:minmax(0,max-content) 24px 4.8em 24px minmax(50px,86px);
  gap:5px 6px;align-items:center;flex:0 1 auto;min-width:0;
  background:rgba(255,255,255,.95);
  border:1px solid var(--line2);border-radius:var(--r-m);
  padding:8px 11px;box-shadow:var(--sh-2);
  width:max-content;max-width:calc(100% - 20px);
}
.cvvars.two{
  gap:4px 6px;padding:7px 9px;
  grid-template-columns:
    minmax(0,max-content) 24px 4.7em 24px minmax(44px,76px)
    minmax(0,max-content) 24px 4.7em 24px minmax(44px,76px);
}
.cvvars .vrow{display:contents}          /* 行の中身をそのままグリッドに並べて、縦をそろえる */
.cvvars .vlab{display:block;min-width:0;font-size:.79rem;color:var(--ink2);white-space:nowrap;
  overflow:hidden;text-overflow:ellipsis;max-width:13em;justify-self:stretch}
.cvvars.two .vlab{font-size:.76rem}
.cvvars .vval{font-size:.82rem;text-align:right;justify-self:stretch}
.cvvars.two .vval{font-size:.79rem}
.cvvars .stp{width:100%;height:21px;padding:0;font-size:.95rem}
.cvvars .vsl{width:100%;accent-color:var(--accent);height:16px;margin:0}
.cvvars:empty{display:none}

/* いちばん先に試してほしい変数を目立たせる（まだ既定値のあいだだけ）。
   2-2 の投射角 θ のように、「ここを変えるんだ」と気づかせたいときに使う。 */
.vrow.focus > .vlab{color:var(--orange-d);font-weight:700;max-width:none;overflow:visible}
/* せまい画面では「変えてみよう」が数字の上に乗ってしまうので、折り返して収める */
.cvvars .vrow.focus > .vlab{overflow:hidden;white-space:normal;line-height:1.4}
.vrow.focus > .vval{color:var(--orange-d);font-weight:700}
.vrow.focus > .stp{background:var(--orange);border-color:var(--orange);color:#fff;
  animation:varpulse 1.6s ease-in-out infinite}
.vrow.focus > .stp:hover{background:var(--orange-d);border-color:var(--orange-d);color:#fff}
.vrow.focus > .vsl{box-shadow:0 0 0 3px rgba(224,123,24,.20);border-radius:999px}
.tryme{display:inline-block;margin-left:5px;padding:0 7px;border-radius:999px;
  background:var(--orange);color:#fff;font-size:.66rem;font-weight:700;line-height:1.55;
  vertical-align:middle;animation:trypulse 1.6s ease-in-out infinite}
@keyframes varpulse{0%,100%{box-shadow:0 0 0 0 rgba(224,123,24,.55)}
  50%{box-shadow:0 0 0 5px rgba(224,123,24,0)}}
@keyframes trypulse{0%,100%{opacity:1;transform:translateY(0)}
  50%{opacity:.72;transform:translateY(-1px)}}
@media (prefers-reduced-motion:reduce){
  .vrow.focus > .stp,.tryme{animation:none}
}

/* 左図の下の補足（小さく、控えめに） */
.cvsub{font-size:.79rem;color:var(--sub);line-height:1.7;margin:8px 2px 0}

/* ===== 変数ステッパー（右カラムの残りの変数） ===== */
.vrow{display:flex;align-items:center;gap:6px;margin:6px 0;flex-wrap:nowrap}
.vrow .vlab{font-size:.84rem;flex:1 1 auto;min-width:0;overflow:hidden;
  text-overflow:ellipsis;white-space:nowrap;color:var(--ink2)}
.stp{flex:none;width:28px;padding:2px 0;font-size:1rem;line-height:1.2;background:#fff;
  color:var(--accent);border:1px solid var(--line2);border-radius:var(--r-s);font-weight:700}
.stp:hover{background:var(--accent-l);border-color:var(--accent);color:var(--accent-d)}
.vrow .vval{flex:none;width:5.6em;text-align:right;font-family:var(--mono);
  font-variant-numeric:tabular-nums;font-size:.86rem;font-weight:600}
input[type=range]{accent-color:var(--accent)}

/* ===== 再生まわり ===== */
.ctrl{background:var(--panel);border:1px solid var(--line);border-radius:var(--r-l);
  padding:10px 12px;margin-bottom:10px}
.ctrl .row{display:flex;align-items:center;gap:8px;margin:5px 0;flex-wrap:wrap}
.ctrl label{font-size:.85rem;color:var(--ink2)}
.ctrl .btnrow{margin:0}
.ctrl.playctrl{margin-bottom:10px}
.ctrl .btnrow #bPlay{min-width:14.4em}   /* 文字が変わっても幅が動かないように */
.tspan{display:inline-flex;align-items:center;gap:8px;flex:1 1 200px;min-width:180px}
.tspan label{font-size:.82rem;color:var(--sub);flex:none}
.tspan input[type=range]{flex:1 1 auto;min-width:60px;max-width:130px}
.tspan .tval{font-family:var(--mono);font-variant-numeric:tabular-nums;font-size:.84rem;
  flex:none;min-width:5.2em;text-align:right;font-weight:600}
#qhint{margin:8px 0 0;font-size:.83rem;color:var(--ink2);line-height:1.6}

/* グラフ操作のヒント（「…をひらく」行の右端に1回だけ） */
.btnrow.openrow{align-items:center;margin:10px 0 8px}
.ghint1{flex:1 1 210px;min-width:150px;font-size:.67rem;color:var(--sub);line-height:1.4;text-align:left}

/* ===== 読み出し（図の下・2列） ===== */
table.read{border-collapse:collapse;width:100%;font-size:.85rem;margin:5px 0}
table.read td{border-bottom:1px dashed var(--line);padding:2px 5px}
table.read td.k{color:var(--sub)}
table.read td.v{font-family:var(--mono);font-variant-numeric:tabular-nums;text-align:right;
  white-space:nowrap;font-weight:600}
table.read#readout{display:block;background:var(--panel);border:1px solid var(--line);
  border-radius:var(--r-m);margin:10px 0 0;padding:6px 10px}
table.read#readout tbody{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:0 20px}
table.read#readout tr{display:flex;align-items:baseline;gap:8px;border-bottom:1px dashed var(--line)}
table.read#readout tr:last-child,
table.read#readout tr:nth-last-child(2):nth-child(odd){border-bottom:0}
table.read#readout td{border:0;padding:2px 0}
table.read#readout td.k{flex:0 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
table.read#readout td.v{flex:1 1 auto;text-align:right}

/* ===== 折りたたみグラフ＋右の式 ===== */
.gsec{border:1px solid var(--line);border-radius:var(--r-l);background:#fff;margin:8px 0;
  overflow:hidden;box-shadow:var(--sh-1)}
.ghead{width:100%;text-align:left;background:var(--panel2);color:var(--accent-d);border:0;
  border-radius:0;padding:7px 12px;font-size:.86rem;font-weight:700;cursor:pointer;
  display:flex;align-items:center;gap:4px}
.ghead:hover{background:#e4ecf5}
.ghead .tri{display:inline-block;width:1.15em;font-size:.8em;color:var(--accent)}
.gbody{padding:10px;display:flex;gap:10px;flex-wrap:wrap;align-items:flex-start;
  border-top:1px solid var(--line)}
.gbody.hide{display:none}
.gbody .gleft{flex:1 1 265px;min-width:225px;max-width:390px;position:relative}
/* ★グラフの拡大・縮小ボタン★（第9回）グラフのすぐ上・右よせに置く
   （グラフの中に重ねると、右上のはんれいがかくれてしまう） */
.gzoom{display:flex;justify-content:flex-end;align-items:center;gap:4px;margin:0 0 3px}
.gzoom .gzl{flex:1 1 auto;font-size:.67rem;color:var(--sub);text-align:left}
.gzoom button{font-family:inherit;font-size:.86rem;font-weight:700;line-height:1;
  min-width:27px;height:25px;padding:0 7px;cursor:pointer;
  background:#fff;border:1.5px solid var(--line);border-radius:7px;color:var(--sub)}
.gzoom button:hover{background:#eef4fa;border-color:var(--accent);color:var(--accent-d)}
.gzoom .gzr{font-size:.72rem}
.gbody canvas{border:0;touch-action:none;cursor:crosshair;max-width:390px}
.gform{flex:1 1 215px;min-width:185px;background:var(--panel);border:1px solid var(--line);
  border-radius:var(--r-m);padding:9px 11px;font-size:.84rem;overflow:hidden}
.gform .fl{display:flex;gap:8px;align-items:center;margin:5px 0;flex-wrap:nowrap}
.gform .fl:first-child{margin-top:0}
.gform .fl:last-child{margin-bottom:0}
/* 式の3行の下に足す解説（2-2 の vy–t 図の「面積」の話など） */
.gform .fnote{margin-top:9px;padding-top:8px;border-top:1px dashed var(--line2);
  font-size:.78rem;line-height:1.75;color:var(--ink2)}
.gform .fnote b{color:var(--ink)}
.gbody.bigf .gform .fnote{font-size:.95rem}
.gform .fk{flex:none;font-size:.68rem;color:#fff;background:#8794a1;border-radius:999px;
  padding:1px 8px;line-height:1.6;font-weight:700;letter-spacing:.04em}
.gform .fl.f2 .fk{background:var(--accent)}
.gform .fl.f3 .fk{background:var(--orange)}
.gform .fv{flex:1 1 auto;min-width:0;overflow:hidden;white-space:nowrap}
.gform .fv > span{display:inline-block;transform-origin:left center}

/* 「式を拡大」：グラフの下に式を回して、幅いっぱいで大きく見せる */
.gbody.bigf{flex-direction:column}
.gbody.bigf .gleft{max-width:100%;width:100%;flex:0 0 auto}
.gbody.bigf .gform{width:100%;flex:0 0 auto;font-size:1.22rem;padding:12px 14px}
.gbody.bigf .gform .fl{margin:9px 0;gap:11px}
.gbody.bigf .gform .fk{font-size:.86rem;padding:2px 11px}
.gsel{display:flex;gap:8px;flex-wrap:wrap;align-items:center;font-size:.81rem;margin-bottom:7px;
  color:var(--ink2)}
.gsel select{font-family:var(--jp);font-size:.81rem;padding:2px 6px;border:1px solid var(--line2);
  border-radius:var(--r-s);background:#fff}

/* ===== 正の向きスイッチ ===== */
.signsw{display:flex;gap:8px;align-items:center;flex-wrap:wrap;font-size:.84rem;
  background:var(--accent-l);border:1px solid #cfe0f0;border-radius:var(--r-l);
  padding:8px 12px;margin:10px 0;color:var(--ink2)}
.signsw button{font-size:.81rem;padding:3px 11px;border-radius:999px}

/* ===== 補足・式 ===== */
.note{background:var(--orange-l);border:1px solid #f0d6ac;border-left:4px solid var(--orange);
  border-radius:var(--r-m);padding:9px 12px;font-size:.85rem;margin-top:10px;line-height:1.75}
.note b{color:var(--orange-d)}
.eq{background:var(--panel2);border:1px solid #dde5ee;border-radius:var(--r-m);
  padding:8px 12px;margin:10px 0 0;font-size:.9rem;line-height:1.9;overflow-x:auto}

/* ===== クイズ ===== */
.quiz{background:var(--ok-l);border:1px solid #b9e0c6;border-radius:var(--r-l);
  padding:10px 12px;margin:10px 0;font-size:.86rem}
.quiz .qbtns{display:flex;gap:6px;flex-wrap:wrap;margin:8px 0}
.quiz .qbtns button{background:#fff;color:#186c3d;border-color:#8cc7a4;font-size:.83rem}
.quiz .qbtns button:hover{background:#dff2e6}
.quiz .qbtns button.on{background:var(--ok);color:#fff;border-color:var(--ok)}
.quiz.pulse{border-color:var(--orange);border-width:3px;background:var(--orange-l)}
.quiz .qbtns button.pulse{background:var(--orange);border-color:var(--orange);color:#fff;font-weight:700}
.quiz .qbtns button.pulse:hover{background:var(--orange-d);border-color:var(--orange-d)}
.quiz .ans{margin-top:6px;font-size:.84rem}
.quiz .ans.ok{color:var(--ok);font-weight:700}
.quiz .ans.ng{color:var(--ng);font-weight:700}

/* 問題モードの3択 */
.gquiz{background:#fffdf6;border:1px solid #e8d3a4;border-radius:var(--r-l);
  padding:10px 12px;margin:10px 0;font-size:.86rem}
.gquiz > b{color:var(--orange-d)}
.gquiz .qsign{color:var(--ink2);font-weight:600}
.gquiz .gqrow{display:flex;gap:10px;flex-wrap:wrap;margin:8px 0}
.gqopt{flex:1 1 150px;min-width:132px;background:#fff;border:2px solid var(--line2);
  border-radius:var(--r-m);padding:5px;cursor:pointer;text-align:center;transition:border-color .12s}
.gqopt:hover{border-color:var(--accent)}
.gqopt.on{border-color:var(--ok);box-shadow:0 0 0 3px rgba(28,143,74,.16)}
.gqopt canvas{border:0}
.gqopt .lb{font-size:.79rem;color:var(--sub);font-weight:700}
.gqmsg{font-size:.84rem;margin-top:6px}
.gqmsg.ok{color:var(--ok);font-weight:700}
.gqmsg.ng{color:var(--ng);font-weight:700}

/* 「次はここ！」の合図（問題モードの誘導） */
@keyframes pulseNext{
  0%{box-shadow:0 0 0 0 rgba(224,123,24,.85)}
  60%{box-shadow:0 0 0 17px rgba(224,123,24,0)}
  100%{box-shadow:0 0 0 0 rgba(224,123,24,0)}
}
@keyframes blinkNext{
  0%,100%{background:var(--orange);border-color:var(--orange)}
  50%{background:#f7a13f;border-color:#f7a13f}
}
.pulse{animation:pulseNext 1.35s ease-out infinite}
button.pulse{background:var(--orange);border-color:var(--orange);color:#fff;font-weight:700;
  animation:pulseNext 1.35s ease-out infinite, blinkNext 1.35s ease-in-out infinite}
button.pulse:hover{background:var(--orange-d);border-color:var(--orange-d)}
.gquiz.pulse{border-color:var(--orange);border-width:3px;background:var(--orange-l)}
.nextmark{color:var(--orange-d);font-weight:700;font-size:1.02em}
@media (prefers-reduced-motion:reduce){
  .pulse,button.pulse{animation:none;box-shadow:0 0 0 4px rgba(224,123,24,.45)}
  button{transition:none}
}

/* ===== 入試物理のくわしい解説 ===== */
.longbox{font-size:.88rem;line-height:1.85}
.longbox h3{margin:0 0 8px}
.longbox h4{font-size:.9rem;margin:16px 0 4px;color:var(--accent-d);
  border-left:4px solid var(--accent-l);padding-left:8px}
.longbox p{margin:4px 0}
.longbox ol,.longbox ul{margin:4px 0;padding-left:1.5em}
.longbox li{margin:2px 0}
.longbox .exam{background:var(--orange-l);border:1px solid #f0d6ac;border-radius:var(--r-m);
  padding:9px 12px;margin:10px 0}
.longbox .exam b{color:var(--orange-d)}
.longbox .fmlbox{background:var(--panel2);border:1px solid #dde5ee;border-radius:var(--r-m);
  padding:8px 12px;margin:6px 0;overflow-x:auto}
.longbox .src{font-size:.8rem;color:var(--sub);margin-top:10px}

/* ===== 矢印の凡例・URL ===== */
#legend{display:flex;flex-wrap:wrap;gap:3px 14px;align-items:center;
  padding:2px 2px 0;font-size:.72rem;color:#98a2ac;margin:18px 0 0}
#legend .lg{display:inline-flex;align-items:center;gap:5px;white-space:nowrap}
#legend canvas{width:44px;height:13px;border:0;background:transparent;border-radius:0;flex:none;opacity:.9}

#urlbar{display:flex;flex-wrap:wrap;gap:7px;align-items:center;font-size:.78rem;
  color:var(--sub);margin:8px 0 2px}
#urlbar code{font-family:var(--mono);background:#e9eef3;border-radius:var(--r-s);padding:2px 8px;
  word-break:break-all;font-size:.76rem}
#urlbar button{font-size:.76rem;padding:2px 10px}
#urlmsg{color:var(--ok);font-weight:600}

/* ===== 画面が狭いとき ===== */
@media (max-width:900px){
  .cvvars.two{grid-template-columns:max-content 26px 5.1em 26px minmax(58px,88px)}
}
@media (max-width:640px){
  body{font-size:15px}
  .wrap{padding:14px 10px 60px}
  h1{font-size:1.24rem}
  .card{padding:12px;border-radius:12px}
  #simhost{padding:12px}
  .tabs button{padding:5px 12px;font-size:.85rem}
  .simgrid{gap:14px}
  .simgrid .cv{max-width:100%}
  .cvtop{position:static;margin:8px 0 0;gap:8px}
  .cvvars{max-width:100%;box-shadow:none}
  .cvside{width:100%}
  .cvstage canvas{border-radius:var(--r-l)}
  .cvbar{border-top:1px solid var(--line);border-radius:var(--r-l);margin-top:8px}
  .gbody{padding:8px}
}

/* =========================================================
   ここから下は mechanical-energy.html（力学的エネルギー）で足したぶん。
   上の定義は 1 行も変えていない（姉妹ページと見た目をそろえるため）。
   ========================================================= */

/* ===== エネルギーの3色（矢印の色とは別枠。グラフ・表・式・棒でそろえる） ===== */
:root{
  --eK:#22a465;      /* 運動エネルギー K＝緑 */
  --eU:#63390c;      /* 位置エネルギー U＝茶 */
  --eE:#38475a;      /* 力学的エネルギー E＝濃い青灰 */
  --eKtx:#14663d;    /* 緑の文字は少し濃くして読みやすくする */
  --lost:#7a8794;    /* 失われたエネルギー＝グレー */
}

/* ===== いちばん上の「立式のステップ図」 ===== */
.stepcard{padding:12px 14px 14px}
.stepcard .stephead{font-size:.9rem;font-weight:700;color:var(--accent-d);margin-bottom:6px}
.stepcard .stephead .mini{display:inline;font-weight:400}
#stepCv{border:0;background:transparent}

/* ===== 図の上に置く行（変数カード＋表示チェック） =====
   ★もとの .cvtop は position:absolute（図に重ねる）なので、必ず打ち消す★
   　打ち消さないとカードがページの左上へ飛んでいって、広い画面でだけ消える。 */
.cvtop.toprow{position:static;top:auto;left:auto;right:auto;margin:0 0 8px;
  display:flex;flex-wrap:wrap;align-items:flex-start;gap:8px}
.cvtop.toprow .cvvars{box-shadow:var(--sh-1)}

/* ===== オレンジの状況ボタンを「図の上」に置く（このページの決めごと） ===== */
.cvbar.top{border:1px solid var(--line);border-bottom:0;
  border-radius:var(--r-l) var(--r-l) 0 0}
.cvstage.topbar canvas{border-radius:0 0 var(--r-l) var(--r-l);border-top-color:var(--line)}

/* ===== ⑥ 計算結果の帯 ===== */
.resbar{display:flex;flex-wrap:wrap;gap:6px 10px;align-items:stretch;
  background:var(--panel);border:1px solid var(--line);border-radius:var(--r-m);
  padding:8px 10px;margin:10px 0 0}
.resbar .ritem{display:flex;flex-wrap:wrap;align-items:baseline;gap:6px;
  background:#fff;border:1px solid var(--line2);border-radius:var(--r-s);padding:3px 9px}
.resbar .rk{font-size:.78rem;color:var(--sub)}
.resbar .rv{font-family:var(--mono);font-variant-numeric:tabular-nums;font-size:.86rem;
  font-weight:700;overflow-wrap:anywhere}
.resbar .ritem.c-eK{border-color:var(--eK);background:#f2fbf6}
.resbar .ritem.c-eK .rv{color:var(--eKtx)}
.resbar .ritem.c-eU{border-color:var(--eU);background:#fbf7f2}
.resbar .ritem.c-eU .rv{color:var(--eU)}
.resbar .ritem.kbox{border:2px solid var(--eE);background:#eef2f7}
.resbar .ritem.kbox .rk{color:var(--eE);font-weight:700}
.resbar .ritem.kbox .rv{color:var(--eE);font-size:.94rem}

/* ===== ⑦ 図の下の「立式」3つ ＋ 仕事を表示（★先生の指示・第4回★） ===== */
.eqzone{margin:10px 0 0;border:1px solid var(--line);border-radius:var(--r-l);
  background:var(--panel2);padding:8px 10px 10px;box-shadow:var(--sh-1)}
.eqztop{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin:0 2px 6px}
.eqztitle{font-size:.82rem;font-weight:700;color:var(--accent-d)}
.eqzall{margin-left:auto;font-size:.78rem;color:var(--ink2);display:flex;align-items:center;
  gap:5px;background:#fff;border:1px solid var(--line);border-radius:999px;padding:2px 10px;
  cursor:pointer;white-space:nowrap}
.eqzall input{margin:0}

.eqsec{background:#fff;border:1px solid var(--line);border-radius:var(--r-m);margin:6px 0}
.eqsec.ok{border-color:#a7d9bb}
.eqsec.ng{border-color:#efbdb5}
.eqsec .eqhead{width:100%;display:flex;align-items:center;gap:7px;flex-wrap:wrap;
  background:none;border:0;padding:7px 10px;cursor:pointer;text-align:left;
  font-size:.85rem;font-weight:700;color:var(--accent-d);font-family:inherit}
.eqsec .eqhead:hover{background:#f6f9fc}
.eqsec .tri{flex:none;color:var(--sub);font-size:.7rem}
.eqsec .badge{flex:none;font-size:.72rem;font-weight:700;border-radius:999px;padding:1px 9px;
  background:#e9eef3;color:var(--sub)}
.eqsec.ok .badge{background:var(--ok);color:#fff}
.eqsec.ng .badge{background:var(--ng);color:#fff}
.eqsec .eqsub{font-size:.72rem;font-weight:400;color:var(--sub)}
.eqsec .eqbody{display:none;padding:2px 10px 9px;border-top:1px dashed var(--line2)}
.eqsec.open .eqbody{display:block}
.eqsec .eqnote{font-size:.78rem;color:var(--sub);margin-top:5px;line-height:1.7}

/* 記号／数値の行（立式と「仕事を表示」で共通） */
.eqzone .enqline,.wkpanel .enqline{display:flex;gap:8px;align-items:center;margin:6px 0;flex-wrap:nowrap}
.eqzone .fk,.wkpanel .fk{flex:none;font-size:.68rem;color:#fff;background:#8794a1;border-radius:999px;
  padding:1px 8px;line-height:1.6;font-weight:700;letter-spacing:.04em}
.eqzone .fk.num,.wkpanel .fk.num{background:var(--orange)}
.eqzone .fv,.wkpanel .fv{flex:1 1 auto;min-width:0;overflow:hidden;white-space:nowrap;font-size:1.02rem}
.eqzone .fv > span,.wkpanel .fv > span{display:inline-block;transform-origin:left center}

/* ★成り立たない式には、赤いバツ印を重ねる★（先生の指示・第8回／第9回に直した）
   「○ 成り立つ／✕ 成り立たない」のバッジだけだと見落とすので、式そのものを消す。
   ★第9回★ 行の上に斜めの線を2本ひくやり方だと、行からはみ出した所が切れてしまい、
   $(E = 一定)$ のあたりにバツがかからなかった。式の箱そのものの背景に
   バツの SVG を敷いて、$K_A+U_A=K_B+U_B\ (E=一定)$ の全体にかかるようにした。 */
.eqsec.ng .enqline.symline .fv > span{
  background-image:url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 40' preserveAspectRatio='none'%3E%3Cpath d='M0 0L100 40M0 40L100 0' stroke='%23c0392b' stroke-opacity='0.78' stroke-width='3'/%3E%3C/svg%3E");
  background-repeat:no-repeat;background-size:100% 100%;background-position:center}

/* くらべる2点を選ぶボタン（点が3つ以上のシム） */
.eqpairs{display:inline-flex;gap:5px;margin-right:4px;flex-wrap:wrap;vertical-align:middle}
.eqpair{font-family:inherit;font-size:.78rem;font-weight:700;line-height:1.5;
  background:#fff;border:1.5px solid var(--line);color:var(--sub);
  border-radius:999px;padding:1px 10px;cursor:pointer}
.eqpair:hover{background:#f2f5f8;border-color:var(--accent)}
.eqpair.on{background:var(--accent);border-color:var(--accent);color:#fff}

/* ===== 「仕事の分析」モード（★先生の指示・第5回★） ===== */
/* ★右の欄の切りかえ（グラフ ⇄ 仕事の分析）★ 図の上のオレンジの状況ボタンと同じ見た目 */
.wkbar{margin:0 0 8px}
.wkbar .acts{display:flex;flex-wrap:wrap;gap:5px;justify-content:flex-start}
.wkbar .acts button{font-size:.78rem;padding:3px 11px;border-radius:999px;white-space:nowrap;
  flex:0 1 auto;min-width:0}
.wkbar .acts button.on{background:var(--orange-l);border-color:var(--orange);
  color:var(--orange-d);font-weight:700;box-shadow:0 0 0 3px rgba(224,123,24,.14)}
.wkbar .acts button.on:hover{background:#fbe4c8}
.wkbarhint{display:block;font-size:.74rem;color:var(--sub);margin:5px 2px 0}

/* 右の列に出る「仕事の分析」の欄（グラフと入れかえ） */
.wkpanel{border:1px solid #e8d3a4;border-radius:var(--r-l);background:#fffdf6;
  padding:9px 11px 11px;margin:0 0 8px}
.wkhead{font-size:.9rem;font-weight:700;color:var(--orange-d);margin:0 2px 4px}
.wkhead .wksub{font-weight:400;font-size:.76rem;color:var(--sub)}
/* 「A点 → B点」の選択（左下の立式の欄と同じボタン。★第7回★） */
.wkpairs{margin:0 2px 6px;display:flex;flex-wrap:wrap;align-items:center;gap:4px}
.wkpairs .wksub{font-size:.76rem;color:var(--sub)}
.wkpairs .wkflow{font-size:.78rem;font-weight:700;color:var(--ink2)}
.wkhint2{font-size:.75rem;color:var(--sub);margin:0 2px 8px;line-height:1.6}
.wkwait{font-size:.82rem;color:var(--ink2);line-height:1.9;background:#fff;
  border:1px dashed var(--line);border-radius:var(--r-m);padding:10px 12px}
.wkcard{margin-top:7px;background:#fff;border:1px solid var(--line);
  border-left:4px solid var(--wc);border-radius:var(--r-m);padding:7px 11px}
.wkcard.sel{box-shadow:0 0 0 2px var(--wc)}
.wkttl{font-size:.84rem;font-weight:700;color:var(--ink);display:flex;align-items:center;
  gap:8px;flex-wrap:wrap}
.wkval{margin-left:auto;font-weight:400;font-size:.92rem;color:var(--ink)}
.wkbadge{font-size:.72rem;border-radius:999px;padding:1px 9px;background:#e9eef3;color:var(--sub)}
.wkcard.pos .wkbadge{background:var(--ok);color:#fff}
.wkcard.neg .wkbadge{background:var(--ng);color:#fff}
.wkwhy{font-size:.77rem;color:var(--ink2);line-height:1.75;margin-top:3px}
.wksum{margin-top:9px;background:#eef2f7;border:2px solid var(--eE);
  border-radius:var(--r-m);padding:7px 11px}
.wksum .wkttl{color:var(--eE)}
/* クリックされた力の欄が「ピコーン」と光る */
@keyframes wkflash{
  0%{box-shadow:0 0 0 0 rgba(224,123,24,.85);transform:scale(1)}
  22%{box-shadow:0 0 0 10px rgba(224,123,24,0);transform:scale(1.035)}
  55%{box-shadow:0 0 0 0 rgba(224,123,24,.55);transform:scale(1)}
  78%{box-shadow:0 0 0 8px rgba(224,123,24,0);transform:scale(1.015)}
  100%{box-shadow:0 0 0 0 rgba(224,123,24,0);transform:scale(1)}
}
.wkcard.flash{animation:wkflash 1.1s ease-out}
@media (prefers-reduced-motion:reduce){.wkcard.flash{animation:none;outline:3px solid var(--orange)}}

/* ===== ⑤ 各点の K・U の表 ===== */
.ptabwrap{overflow-x:auto;margin:8px 0}   /* 包まないと 320px でページごと横スクロールが出る */
table.ptab{border-collapse:collapse;width:100%;font-size:.82rem;background:#fff}
table.ptab caption{caption-side:top;text-align:left;font-size:.78rem;color:var(--sub);
  padding:0 0 4px}
table.ptab th,table.ptab td{border:1px solid var(--line2);padding:4px 8px;text-align:center;
  white-space:nowrap}
table.ptab th{background:var(--panel2);font-size:.76rem;color:var(--ink2);font-weight:700}
table.ptab th.ck{color:var(--eKtx)}
table.ptab th.cu{color:var(--eU)}
table.ptab th.ce{color:var(--eE)}
table.ptab td.pn{background:var(--panel);font-weight:700}
table.ptab td.pn .pj{display:block;font-size:.7rem;font-weight:400;color:var(--sub)}
table.ptab td .sym{display:block}
table.ptab td .num{display:block;font-family:var(--mono);font-variant-numeric:tabular-nums;
  font-size:.8rem;color:var(--sub)}
table.ptab td .num::after{content:' J';font-size:.9em}
table.ptab td.ck .sym{color:var(--eKtx)}
table.ptab td.cu .sym{color:var(--eU)}
table.ptab td.ce .num{color:var(--eE);font-weight:700;font-size:.88rem}
/* ばねがあるときは5列になるので、はみ出さないように少し細くする */
table.ptab.wide{font-size:.76rem}
table.ptab.wide th,table.ptab.wide td{padding:4px 4px}
table.ptab.wide th{font-size:.71rem}
table.ptab.wide td.pn .pj{font-size:.66rem}
table.ptab.wide td .num{font-size:.72rem}
table.ptab.wide td.ce .num{font-size:.8rem}

/* 公式の欄がないグラフの「見えない場所とり」（グラフの大きさをそろえる） */
.gspacer{flex:1 1 215px;min-width:185px}

@media (max-width:640px){
  .resbar{padding:7px 8px;gap:5px 7px}
  .cvtop.toprow{gap:6px}
  .eqzone .fv{font-size:.94rem}
  .wkpanel .fv{font-size:.92rem}
  .eqsec .eqhead{font-size:.8rem;padding:6px 8px}
  .eqzone{padding:7px 8px 8px}
}

/* 説明文の中の「別のシミュレーションへ飛ぶ」リンク */
[data-goto]{color:var(--accent);font-weight:700;text-decoration:underline;cursor:pointer}
[data-goto]:hover{color:var(--accent-d)}

/* ステップ図のカードは、余白を切りつめて低くする */
.stepcard{padding:10px 12px 10px}
.stepcard .stephead{margin-bottom:4px}

/* 図のすぐ下の「ひとこと」（スタートを押してから出る） */
.cvhint{font-size:.84rem;color:var(--ink2);line-height:1.7;margin:8px 2px 0;
  border-left:3px solid var(--eE);padding-left:8px}
.cvhint b{color:var(--eE)}

/* ===== 点のエネルギーの吹きだし（canvas の上に重ねる HTML・KaTeX） =====
   文字の大きさは canvas の表示倍率（--ptk）に比例させるので、
   どの画面幅でも「図に対する大きさ」は変わらない。 */
.cvwrap{position:relative;line-height:0}
.ptbubs{position:absolute;inset:0;pointer-events:none;--ptk:1}
.ptbub{position:absolute;transform:translate(-50%,-50%);white-space:nowrap;text-align:center;
  background:#eef2f7;border:calc(1.6px * var(--ptk)) solid var(--eE);
  border-radius:calc(7px * var(--ptk));
  padding:calc(3px * var(--ptk)) calc(8px * var(--ptk));
  font-size:calc(12px * var(--ptk));line-height:1.4;
  box-shadow:0 1px 3px rgba(22,32,43,.14)}
.ptbub .pn{font-weight:700;color:var(--eE);margin-right:.35em}
.ptbub .pv{display:block;font-size:.8em;color:var(--sub);
  font-family:var(--mono);font-variant-numeric:tabular-nums}

/* 別のシミュレーションへ飛ぶボタン（オレンジの状況ボタンとは役目がちがうので青にする） */
.cvbar .acts button.jump{color:var(--accent);border-color:var(--line2);background:#fff;
  margin-left:auto}
.cvbar .acts button.jump:hover{background:var(--accent-l);border-color:var(--accent)}
```

## src/20_body.html

```html
<div class="wrap">

<h1>力学的エネルギーと非保存力の仕事の関係</h1>
<p class="mini">それぞれのタブからシミュレーションを選び、「スタート」を押して運動を見て、3つのグラフと式がなぜそうなるかを納得いくまで考えよう。</p>

<div class="tabs" id="modetabs"></div>
<div class="tabs sub" id="simtabs"></div>

<div class="card stepcard">
  <div class="stephead">立式のステップ　<span class="mini">— いま見ているシミュレーションに合わせて変わります</span></div>
  <canvas id="stepCv"></canvas>
</div>

<div class="card" id="simhost"></div>

<div id="legend">
  <span class="lg"><canvas data-kind="line" data-col="eK"></canvas>運動エネルギー K</span>
  <span class="lg"><canvas data-kind="line" data-col="eU" data-dash="1"></canvas>位置エネルギー U</span>
  <span class="lg"><canvas data-kind="line" data-col="eE" data-w="3.2"></canvas>力学的エネルギー E</span>
  <span class="lg"><canvas data-kind="band" data-col="areaNeg"></canvas>失われた分（図のエネルギーの棒）</span>
  <span class="lg"><canvas data-kind="force"></canvas>重力・その他の力</span>
  <span class="lg"><canvas data-kind="force" data-col="norm"></canvas>垂直抗力</span>
  <span class="lg"><canvas data-kind="force" data-col="fric"></canvas>摩擦力</span>
  <span class="lg"><canvas data-kind="force" data-col="hand"></canvas>手（ひも・ばね）の力</span>
  <span class="lg"><canvas data-kind="vel"></canvas>速度</span>
  <span class="lg"><canvas data-kind="acc"></canvas>加速度</span>
  <span class="lg"><canvas data-kind="comp"></canvas>分力</span>
  <span class="lg"><canvas data-kind="dim"></canvas>寸法・高さ</span>
</div>

<div id="urlbar">
  <span>このシミュレーションのURL：</span><code id="urltext"></code>
  <button class="sub" id="urlcopy" style="font-size:.76rem;padding:2px 9px">コピー</button>
  <span id="urlmsg"></span>
</div>

<div class="card">
  <h3>使い方のヒント</h3>
  <p class="mini">
  ・図の上の<b>オレンジのボタン</b>で状況を変え、<b>スライドバー</b>で数値を変えられます。変えると自動的にはじめに戻ります。<br>
  ・<b>時間バー</b>を手で動かすと、好きな瞬間で止めて矢印とグラフの点を見くらべられます。<br>
  ・<b>運動が終わると</b>、図の中に「その点の力学的エネルギー」の吹きだしが出て、その点に物体・速度・高さが描きもどされます。<br>
  ・そのとき図の下に<b>3つの立式</b>（力学的エネルギー保存則／力学的エネルギー変化量と非保存力の仕事の関係／運動エネルギー変化量と仕事の関係）が出ます。見出しをおすと開きます。<b>「3つの式を表示」</b>にチェックを入れると、どのシミュレーションでも3つとも開いた状態になります。<br>
  ・くらべる点が3つ以上あるシミュレーションでは、<b>「A点とB点」「A点とC点」…</b>をおして、どの2点で立式するかを選べます。<br>
  ・右上の<b>「仕事の分析」</b>ボタンをおすと、グラフの欄が<b>力ごとの仕事</b>に切りかわります（正・負・0 になる理由つき）。<b>「エネルギーのグラフを表示」</b>でもとにもどります。<b>図の中の力をクリック</b>すると、その力の欄が光ります。<br>
  ・右の列の<b>「K・U・E をまとめて開く」</b>ボタンで、3つのグラフを一度に開いて見くらべられます。<br>
  ・各グラフの右には、<b>公式 → 記号を代入した式 → 数値を代入した式</b>の3段が出ます。<br>
  ・グラフは<b>ドラッグで移動</b>、<b>目盛りの上でドラッグすると軸の拡大縮小</b>、<b>ホイールで拡大縮小</b>、<b>ダブルクリックで自動</b>にもどります。<br>
  ・このページは1つのファイルで動きます（インターネット不要）。</p>
</div>

<div class="card purpose">
  <p class="lead">【このシミュレーションの目的】</p>
  <ol>
    <li><b>保存力だけが仕事をするとき</b>、力学的エネルギー <span class="tex">E=K+U</span> が
      <b>一定に保たれる</b>（力学的エネルギー保存則）ことを、
      <b>アニメーションと力のはたらき方、グラフ</b>で理解する。</li>
    <li>摩擦力や手の力のような<b>非保存力が仕事をすると、その仕事の分だけ力学的エネルギーが変わる</b>
      <span class="tex">E_2-E_1=W_{\text{非保存}}</span> ことを、
      <b>アニメーションと力のはたらき方、グラフ</b>で理解する。</li>
    <li>各点の<b>運動エネルギー</b> <span class="tex">K=\tfrac{1}{2}mv^2</span>、
      <b>重力による位置エネルギー</b> <span class="tex">U_g=mgh</span>、
      <b>弾性力による位置エネルギー</b> <span class="tex">U_k=\tfrac{1}{2}kx^2</span> を、自分で書き出せるようになる。</li>
    <li>2つの位置で <span class="tex">K</span> と <span class="tex">U</span> を書き出して等号でつなぐ、という
      <b>立式の手順</b>を身につける（<b>重力の位置エネルギーの基準面</b>はどこにとってもよいが、必ず先に決める）。</li>
    <li><b>1つ1つの力がした仕事</b>が正か負か 0 かを、力の向きと動く向きから言えるようになり、
      それを合計すると<b>運動エネルギーの変化量</b>になることを確かめる
      （右上の「仕事の分析」ボタン）。</li>
  </ol>
</div>

</div>
```

## src/30_physics.js

```js
/* 純粋な物理計算だけ（描画を混ぜない）。同じ入力 → 同じ出力。
   ★このページのいちばん大事な決めごと★
   　エネルギーの定義は下の EN ただ1か所。ほかの場所で ½mv² や mgh を直接書かない。 */
'use strict';
var G = 9.8;
var DEG = Math.PI / 180;

function clamp(x, a, b) { return x < a ? a : (x > b ? b : x); }
function fmt(x, d) {
  if (d === undefined) d = 1;
  if (!isFinite(x)) return '—';
  var s = x.toFixed(d);
  if (s === '-' + (0).toFixed(d)) s = (0).toFixed(d);   /* −0.0 を出さない */
  return s;
}

/* =========================================================
   エネルギーの定義（ページ全体でここ1か所）
   K  = ½mv²          運動エネルギー
   Ug = mgh           重力による位置エネルギー（h は「基準面からの高さ」）
   Us = ½kx²          弾性力による位置エネルギー（x は「自然の長さからの変形」）
   E  = K + Ug + Us   力学的エネルギー
   W  = 非保存力がした仕事（保存力だけのときは 0）
   各シムの sample() は「速さ v・高さ h・ばねの変形 sp・仕事 w」だけを返し、
   エネルギーは必ず EN.mix() を通して作る。
   ========================================================= */
var EN = {
  K: function (m, v) { return 0.5 * m * v * v; },
  Ug: function (m, h) { return m * G * h; },
  Us: function (k, x) { return 0.5 * k * x * x; },
  /* q = {v, h, sp, w} → q に K/Ug/Us/U/E/W を書き足して返す */
  mix: function (v, q) {
    var K = EN.K(v.m, q.v || 0);
    var Ug = EN.Ug(v.m, q.h || 0);
    var Us = (v.k > 0 && q.sp) ? EN.Us(v.k, q.sp) : 0;
    q.K = K; q.Ug = Ug; q.Us = Us; q.U = Ug + Us; q.E = K + Ug + Us;
    q.W = q.w || 0;
    return q;
  }
};

/* =========================================================
   数値積分：拘束された1自由度 q に対する q'' = a(q)
   ★エネルギーが保存する解法（速度ベルレ法）を使う★
   　オイラー法だと E がじわじわ増えて、このページの主役
   　「E が一定」がくずれてしまう。
   同じ入力なら必ず同じ表になる（表は入力で作り、時刻から読む）。
   ========================================================= */
var INT = {
  DT: 0.002,
  /* acc(q) … 位置だけで決まる加速度。stop(q, w, i) … true になったらそこで打ち切る */
  verlet: function (acc, q0, w0, dt, n, stop) {
    var q = q0, w = w0, a = acc(q0), i, arr = [{ q: q0, w: w0, a: a, t: 0 }];
    for (i = 1; i <= n; i++) {
      var qN = q + w * dt + 0.5 * a * dt * dt;
      var aN = acc(qN);
      var wN = w + 0.5 * (a + aN) * dt;
      q = qN; w = wN; a = aN;
      arr.push({ q: q, w: w, a: a, t: i * dt });
      if (stop && stop(q, w, i)) break;
    }
    return arr;
  },
  /* 表から時刻 t の行を読む（丸めだけ。補間しない＝同じ入力なら同じ値） */
  at: function (tab, t, dt) {
    return tab[clamp(Math.round(t / dt), 0, tab.length - 1)];
  }
};

/* 1つ前の計算をおぼえておく（同じ設定なら作り直さない） */
function memo1(build) {
  var key = null, val = null;
  return function (k, v) {
    if (key === k) return val;
    key = k; val = build(v);
    return val;
  };
}

/* =========================================================
   曲線を「弧長 s」で表す（曲面をすべる運動のため）
   fy(x) … 高さ、fd(x) … dy/dx。x を細かく刻んで弧長を積む。
   返り値： sMax, at(s) → {x, y, dyds}
   ========================================================= */
function arcCurve(fy, fd, x0, x1, n) {
  var i, xs = [], ys = [], ss = [], dd = [];
  var dx = (x1 - x0) / n, sAcc = 0, px = x0, py = fy(x0);
  xs.push(x0); ys.push(py); ss.push(0); dd.push(fd(x0));
  for (i = 1; i <= n; i++) {
    var x = x0 + dx * i, y = fy(x);
    sAcc += Math.hypot(x - px, y - py);
    xs.push(x); ys.push(y); ss.push(sAcc); dd.push(fd(x));
    px = x; py = y;
  }
  return {
    sMax: sAcc,
    /* s → {x, y, dyds}（線形補間） */
    at: function (s) {
      var lo = 0, hi = ss.length - 1, mid;
      if (s <= 0) { var d0 = dd[0]; return { x: xs[0], y: ys[0], dyds: d0 / Math.sqrt(1 + d0 * d0) }; }
      if (s >= sAcc) { var d1 = dd[hi]; return { x: xs[hi], y: ys[hi], dyds: d1 / Math.sqrt(1 + d1 * d1) }; }
      while (hi - lo > 1) { mid = (lo + hi) >> 1; if (ss[mid] <= s) lo = mid; else hi = mid; }
      var f = (s - ss[lo]) / Math.max(1e-12, ss[hi] - ss[lo]);
      var d = dd[lo] + (dd[hi] - dd[lo]) * f;
      return { x: xs[lo] + (xs[hi] - xs[lo]) * f, y: ys[lo] + (ys[hi] - ys[lo]) * f,
        dyds: d / Math.sqrt(1 + d * d) };
    }
  };
}

var P = {};

/* ===== どの P がどのタブか（第2回でタブ番号をふり直したので対応表を残す） =====
   P.m11 → 1-1 摩擦のない水平面      P.m12 → 1-2 自由落下
   P.m13 → 1-3 滑台（直線）1         P.slopeUp → 1-4 滑台（直線）2（昇る・新規）
   P.m14 → 1-5 滑台（曲線）          P.m15 → 1-6 振り子
   P.cylWall → 1-7 円筒面（作り直し） P.m17 → 1-8 斜方投射
   P.m18 → 1-9 水平ばね              P.m19 → 1-12 鉛直ばね
   P.m110 → 1-13 曲面飛び出し
   P.m21 → 2-1 摩擦のある床          P.m22 → 2-2 摩擦のある斜面
   P.m23 → 2-3 鉛直ばね（手の仕事）  P.m24 → 2-4 摩擦のある水平面のばね（新規）
   P.m25 → 2-5 摩擦のある斜面を糸で引き上げる（新規）
   ※ P.m16 は使わなくなった（もとの円筒面）。 */

/* ============ 1-4 滑台（直線）2：斜面を昇る ============
   デコピンで初速度 v0 をもらって、なめらかな斜面を昇る。
   斜面にそった加速度 a = −g sinθ。止まる位置までの距離 L = v0²/(2g sinθ)、
   ★上がる高さ h = L sinθ = v0²/(2g) は θ によらない★（1-3 の裏返し）。 */
P.slopeUp = {
  a: function (v) { return G * Math.sin(v.th * DEG); },      /* 減速の大きさ */
  tEnd: function (v) { return v.v0 / P.slopeUp.a(v); },      /* 止まるまで */
  len: function (v) { return v.v0 * v.v0 / (2 * P.slopeUp.a(v)); },   /* ★式で出す★ */
  hTop: function (v) { return v.v0 * v.v0 / (2 * G); },      /* ★θ によらない★ */
  sample: function (v, t) {
    var T = P.slopeUp.tEnd(v), tt = clamp(t, 0, T), a = P.slopeUp.a(v);
    var s = v.v0 * tt - 0.5 * a * tt * tt;
    var sp = v.v0 - a * tt;
    var y = s * Math.sin(v.th * DEG);
    return EN.mix(v, { s: s, x: s * Math.cos(v.th * DEG), y: y, v: Math.max(0, sp),
      h: y, sp: 0, w: 0, a: -a });
  }
};

/* ============ 1-7 ジェットコースター（★第5回で作り直し★）============
   なめらかな軌道。水平面を速さ v0 で走ってきて、鉛直な円（ループ）を1周し、
   そのあと斜面を昇って止まる。
   ★経路にそった座標 s の1本で表す★ 加速度は a(s) = −g·(dy/ds)。
     s < L1                     水平面（y = 0）
     L1 ≤ s < L1+2πR            ループ（φ=(s−L1)/R、y = R(1−cosφ)）
     L1+2πR ≤ s < L1+2πR+L2     水平面
     それより先                 斜面（y = (s−s3)sinθ）
   ★答えは式で出す★
     ループの頂上 B：v_B = √(v0² − 2gD)（D＝ループの直径）
     止まる高さ  C：h_C = v0²/(2g)（★θ によらない★）
   ★ループを1周できる条件★ v_B² ≥ gR。v0 の範囲はこれを必ず満たすようにとってある。 */
P.coaster = {
  D: 7.5, L1: 6.0, L2: 4.0, DT: INT.DT,
  R: function () { return P.coaster.D / 2; },
  loopLen: function () { return 2 * Math.PI * P.coaster.R(); },
  /* ★斜面のつけ根はまるめる（半径 RF）★
     とがったままだと dy/ds が急に変わって、数値積分の E がずれる（0.05 % まで出た）。
     実物のコースターにも角はないので、絵としても正しくなる。 */
  RF: 1.2,
  /* 経路の s → {x, y, dyds, seg, phi, ang}（ang＝進む向きの角度[rad]、画面の上向きが正） */
  at: function (s, th) {
    var R = P.coaster.R(), L1 = P.coaster.L1, L2 = P.coaster.L2, LL = P.coaster.loopLen();
    var RF = P.coaster.RF, thr = th * DEG, sF = L1 + LL + L2, aLen = RF * thr;
    if (s <= L1) return { x: s, y: 0, dyds: 0, seg: 0, phi: 0, ang: 0 };
    if (s <= L1 + LL) {
      var phi = (s - L1) / R;
      return { x: L1 + R * Math.sin(phi), y: R * (1 - Math.cos(phi)),
        dyds: Math.sin(phi), seg: 1, phi: phi, ang: phi };
    }
    if (s <= sF) return { x: L1 + (s - L1 - LL), y: 0, dyds: 0, seg: 2, phi: 0, ang: 0 };
    if (s <= sF + aLen) {                      /* 斜面のつけ根のまるみ */
      var al = (s - sF) / RF;
      return { x: L1 + L2 + RF * Math.sin(al), y: RF * (1 - Math.cos(al)),
        dyds: Math.sin(al), seg: 3, phi: 0, ang: al };
    }
    var u = s - sF - aLen, si = Math.sin(thr), co = Math.cos(thr);
    return { x: L1 + L2 + RF * si + u * co, y: RF * (1 - Math.cos(thr)) + u * si,
      dyds: si, seg: 4, phi: 0, ang: thr };
  },
  /* 表の最後（＝止まる所）の経路長 */
  sEnd: function (v) { var tb = P.coaster.table(v); return tb[tb.length - 1].q; },
  _tab: memo1(function (v) {
    var dt = P.coaster.DT;
    return INT.verlet(function (q) { return -G * P.coaster.at(q, v.th).dyds; }, 0, v.v0, dt, 12000,
      function (q, w, i) { return i > 3 && w <= 0; });        /* 速さが 0（斜面の最高点） */
  }),
  table: function (v) { return P.coaster._tab([v.v0, v.th].join('|'), v); },
  /* 斜面の最高点（速さ 0）に着く時刻 */
  tTop: function (v) { var tb = P.coaster.table(v); return tb[tb.length - 1].t; },
  /* ★第18回・先生の指示★ 最高点で終わりにせず、「本来の続き」を見せる。
     なめらかなので、帰りは行きの巻きもどし（同じ道を逆にたどる）。
     最高点でいったん止まり、ループをもう一度くぐって、スタート地点 A まで
     帰ってくる。A にもどったときの速さは、はじめと同じ v0。 */
  tEnd: function (v) { return 2 * P.coaster.tTop(v); },
  /* 時刻 t を「行き（0〜tTop）」に折り返す。back = 帰り道 */
  fold: function (v, t) {
    var T1 = P.coaster.tTop(v);
    if (!(T1 > 1e-9)) return { u: 0, back: false };
    var u = clamp(t, 0, 2 * T1);
    if (u > T1) return { u: 2 * T1 - u, back: true };
    return { u: u, back: false };
  },
  tAt: function (v, sTarget) {
    var tb = P.coaster.table(v), i;
    for (i = 0; i < tb.length; i++) if (tb[i].q >= sTarget) return tb[i].t;
    return tb[tb.length - 1].t;
  },
  tB: function (v) { return P.coaster.tAt(v, P.coaster.L1 + P.coaster.loopLen() / 2); },
  /* ★答えは式で★ */
  vB: function (v) { return Math.sqrt(Math.max(0, v.v0 * v.v0 - 2 * G * P.coaster.D)); },
  hC: function (v) { return v.v0 * v.v0 / (2 * G); },
  /* 止まる所の水平の位置（斜面のつけ根 x = L1+L2 からの距離）。まるみの分も入れる */
  runC: function (v) {
    var RF = P.coaster.RF, thr = v.th * DEG, hC = P.coaster.hC(v), hF = RF * (1 - Math.cos(thr));
    if (hC <= hF) return RF * Math.sin(Math.acos(clamp(1 - hC / RF, -1, 1)));
    return RF * Math.sin(thr) + (hC - hF) / Math.sin(thr) * Math.cos(thr);
  },
  /* ループを1周できるか（頂上で v² ≥ gR） */
  loopOK: function (v) { return P.coaster.vB(v) * P.coaster.vB(v) >= G * P.coaster.R() - 1e-9; },
  vLoopMin: function () { return Math.sqrt(5 * G * P.coaster.R()); },  /* 頂上でのぎりぎりの速さ */
  /* 軌道から受ける垂直抗力。ループの上は N = m(v²/R + g cosφ) */
  Nof: function (v, m) {
    if (m.seg === 1) return v.m * (m.v * m.v / P.coaster.R() + G * Math.cos(m.phi));
    if (m.seg === 3) return v.m * (m.v * m.v / P.coaster.RF + G * Math.cos(m.ang));
    if (m.seg === 4) return v.m * G * Math.cos(v.th * DEG);
    return v.m * G;
  },
  sample: function (v, t) {
    var f = P.coaster.fold(v, t);
    var tb = P.coaster.table(v), r = INT.at(tb, f.u, P.coaster.DT), p = P.coaster.at(r.q, v.th);
    var q = EN.mix(v, { s: r.q, x: p.x, y: p.y, v: Math.max(0, r.w), h: p.y, sp: 0, w: 0,
      seg: p.seg, phi: p.phi, ang: p.ang, dyds: p.dyds, back: f.back });
    q.vs = f.back ? -q.v : q.v;                 /* 向きつきの速度（矢印の向きに使う） */
    return q;
  }
};

/* ============ 1-1 水平な面をただすべる物体 ============
   なめらかな床。力は重力と垂直抗力だけで、どちらも運動の向きに垂直（＝仕事をしない）。
   基準面＝床。h = 0 なので U = 0、K は一定。 */
P.m11 = {
  /* ★くらべる点 B と、アニメの終わりを分ける★（先生の指示・第8回）
     B で運動が終わると「そこで止まる」と思われるので、B のあとも床のはしまで走らせる。 */
  LB: 5.0,                        /* くらべる点 B の位置 [m] */
  LEN: 9.4,                       /* アニメの終わり（床のはし）[m] */
  tB: function (v) { return P.m11.LB / Math.max(0.2, v.v0); },
  tEnd: function (v) { return P.m11.LEN / Math.max(0.2, v.v0); },
  sample: function (v, t) {
    var x = v.v0 * t;
    return EN.mix(v, { x: x, y: 0, v: v.v0, h: 0, sp: 0, w: 0, a: 0 });
  },
  /* 答えとして見せる量は式で出す */
  xEnd: function (v) { return P.m11.LB; }
};

/* ============ 1-2 自由落下 ============
   基準面＝地面。h(t) = h − ½gt²、v = gt。 */
P.m12 = {
  tEnd: function (v) { return Math.sqrt(2 * v.h / G); },
  vEnd: function (v) { return Math.sqrt(2 * G * v.h); },       /* ★式で出す★ */
  sample: function (v, t) {
    var T = P.m12.tEnd(v), tt = clamp(t, 0, T);
    var drop = 0.5 * G * tt * tt;
    var y = v.h - drop;
    return EN.mix(v, { x: 0, y: y, v: G * tt, h: y, sp: 0, w: 0, a: G });
  }
};

/* ============ 1-3 滑り台（直線） ============
   なめらかな斜面。斜面にそった加速度 a = g sinθ。
   基準面＝地面（斜面の下端）。斜面の長さ L = h / sinθ。 */
P.m13 = {
  a: function (v) { return G * Math.sin(v.th * DEG); },
  len: function (v) { return v.h / Math.sin(v.th * DEG); },
  tEnd: function (v) { return Math.sqrt(2 * P.m13.len(v) / P.m13.a(v)); },
  vEnd: function (v) { return Math.sqrt(2 * G * v.h); },       /* ★θ によらない★ */
  sample: function (v, t) {
    var T = P.m13.tEnd(v), tt = clamp(t, 0, T), a = P.m13.a(v);
    var s = 0.5 * a * tt * tt;
    var y = v.h - s * Math.sin(v.th * DEG);
    return EN.mix(v, { s: s, x: s * Math.cos(v.th * DEG), y: y, v: a * tt, h: y, sp: 0, w: 0, a: a });
  }
};

/* ============ 1-4 滑り台（曲線） ============
   なめらかな曲面 y = h(1 − x/L)²（下で地面に接する）。
   弧長 s を変数にとると s'' = −g·(dy/ds) と「加速度が位置だけで決まる」形になるので、
   速度ベルレ法がそのまま使える。 */
P.m14 = {
  L: 4.0,                          /* 横のはば [m] */
  DT: INT.DT,
  curve: function (v) {
    var L = P.m14.L, h = v.h;
    return arcCurve(function (x) { return h * (1 - x / L) * (1 - x / L); },
      function (x) { return -2 * h * (1 - x / L) / L; }, 0, L, 900);
  },
  _tab: memo1(function (v) {
    var cv = P.m14.curve(v), dt = P.m14.DT;
    var tab = INT.verlet(function (s) { return -G * cv.at(s).dyds; }, 0, 0, dt, 6000,
      function (s) { return s >= cv.sMax; });
    return { tab: tab, cv: cv };
  }),
  table: function (v) { return P.m14._tab('h' + v.h, v); },
  tEnd: function (v) { var o = P.m14.table(v); return o.tab[o.tab.length - 1].t; },
  vEnd: function (v) { return Math.sqrt(2 * G * v.h); },       /* ★形によらない★ */
  sample: function (v, t) {
    var o = P.m14.table(v), r = INT.at(o.tab, t, P.m14.DT), p = o.cv.at(r.q);
    return EN.mix(v, { s: r.q, x: p.x, y: p.y, v: Math.abs(r.w), h: p.y, sp: 0, w: 0,
      a: r.a, dyds: p.dyds });
  }
};

/* ============ 1-5 振り子 ============
   θ'' = −(g/l) sinθ（θ は鉛直からの角、右が正）。糸の張力は運動の向きに垂直で仕事をしない。
   基準面＝最下点。h = l(1 − cosθ)。
   ★折り返しの点から積分して「ぴったり周期的」な表を作る★
   　（そうしないとくり返し再生でずれる）。 */
P.m15 = {
  DT: INT.DT,
  /* 折り返しの角（エネルギー保存から閉じた式で出す） */
  thTurn: function (v) {
    var c = Math.cos(v.th * DEG) - v.v0 * v.v0 / (2 * G * v.l);
    return Math.acos(clamp(c, -1, 1));
  },
  _tab: memo1(function (v) {
    var dt = P.m15.DT, thT = P.m15.thTurn(v), l = v.l;
    /* 折り返しの点（+thT, ω=0）から、反対がわの折り返しまで＝半周期。
       ★止める条件は「速度の向きが変わったとき」★
       　「θ ≤ −thT」で止めようとすると、離散化のせいでほんのわずか手前で折り返して
       　条件を満たさず、いつまでも積分が終わらない（実際にそうなった）。 */
    var tab = INT.verlet(function (q) { return -(G / l) * Math.sin(q); }, thT, 0, dt, 20000,
      function (q, w, i) { return i > 5 && w >= 0; });
    var Th = tab[tab.length - 1].t;
    /* はじめの状態（θ = th、最下点へ向かって動いている）が半周期のどこにあたるか */
    var th0 = v.th * DEG, i, t0 = 0;
    for (i = 0; i < tab.length; i++) { if (tab[i].q <= th0) { t0 = tab[i].t; break; } }
    return { tab: tab, Th: Th, t0: t0, thT: thT };
  }),
  table: function (v) { return P.m15._tab([v.th, v.v0, v.l].join('|'), v); },
  /* 1周期 */
  tEnd: function (v) { return 2 * P.m15.table(v).Th; },
  /* 最下点に来る時刻（はじめの点から数えて） */
  tBottom: function (v) { var o = P.m15.table(v); return o.Th / 2 - o.t0; },
  /* 最下点の速さ（★式で出す★） */
  vBottom: function (v) {
    return Math.sqrt(v.v0 * v.v0 + 2 * G * v.l * (1 - Math.cos(v.th * DEG)));
  },
  sample: function (v, t) {
    var o = P.m15.table(v), T = 2 * o.Th;
    var ph = (t + o.t0) % T;
    if (ph < 0) ph += T;
    var sgn = 1, r;
    if (ph <= o.Th) { r = INT.at(o.tab, ph, P.m15.DT); }
    else { r = INT.at(o.tab, ph - o.Th, P.m15.DT); sgn = -1; }
    var th = r.q * sgn, om = r.w * sgn;
    var h = v.l * (1 - Math.cos(th));
    return EN.mix(v, { th: th, om: om, x: v.l * Math.sin(th), y: -v.l * Math.cos(th),
      v: Math.abs(om) * v.l, h: h, sp: 0, w: 0 });
  }
};

/* ============ 2-1 摩擦がある水平な床 ============
   動摩擦力（非保存力）が負の仕事をする。すべて閉じた式で出せる。
   W摩擦 = −μ' m g x（x は進んだ距離）、止まる位置 L = v0²/(2μ'g)。 */
P.m21 = {
  a: function (v) { return -v.mu * G; },
  tStop: function (v) { return v.v0 / (v.mu * G); },
  xStop: function (v) { return v.v0 * v.v0 / (2 * v.mu * G); },   /* ★式で出す★ */
  tEnd: function (v) { return P.m21.tStop(v) * 1.15 + 0.25; },
  sample: function (v, t) {
    var ts = P.m21.tStop(v), tt = clamp(t, 0, ts);
    var x = v.v0 * tt - 0.5 * v.mu * G * tt * tt;
    var sp = v.v0 - v.mu * G * tt;
    var w = -v.mu * v.m * G * x;                                  /* 摩擦力がした仕事 */
    return EN.mix(v, { x: x, y: 0, v: sp, h: 0, sp: 0, w: w, a: (t < ts ? -v.mu * G : 0),
      moving: t < ts - 1e-9, f: v.mu * v.m * G, N: v.m * G });
  }
};

/* ============ 1-6 円筒面（内側を回る） ============
   なめらかな円筒の内側。θ は最下点からの角。θ'' = −(g/R) sinθ（振り子と同じ形）。
   垂直抗力 N/m = v²/R + g cosθ が負になったら面から離れて放物運動になる。
   ★一番上まで届くには v₀ ≥ √(5gR) が必要★ */
P.m16 = {
  R: 1.0, DT: INT.DT,
  vLoop: function () { return Math.sqrt(5 * G * P.m16.R); },
  _tab: memo1(function (v) {
    var R = P.m16.R, dt = P.m16.DT, i;
    var th = 0, om = v.v0 / R, arr = [], left = null;
    function acc(q) { return -(G / R) * Math.sin(q); }
    var a = acc(th);
    for (i = 0; i <= 5000; i++) {
      var t = i * dt;
      if (!left) {
        var x = R * Math.sin(th), y = R * (1 - Math.cos(th));
        var sp = Math.abs(om) * R;
        var vx = om * R * Math.cos(th), vy = om * R * Math.sin(th);
        var Nm = sp * sp / R + G * Math.cos(th);          /* N/m */
        arr.push({ t: t, x: x, y: y, vx: vx, vy: vy, v: sp, th: th, om: om, on: true, Nm: Nm });
        if (Nm < 0) { left = { x: x, y: y, vx: vx, vy: vy, t: t }; continue; }
        if (th >= 2 * Math.PI) break;
        var thN = th + om * dt + 0.5 * a * dt * dt;
        var aN = acc(thN);
        om = om + 0.5 * (a + aN) * dt;
        th = thN; a = aN;
      } else {
        var tt = t - left.t;
        var fx = left.x + left.vx * tt, fy = left.y + left.vy * tt - 0.5 * G * tt * tt;
        var fvy = left.vy - G * tt;
        arr.push({ t: t, x: fx, y: fy, vx: left.vx, vy: fvy, v: Math.hypot(left.vx, fvy),
          th: null, om: 0, on: false, Nm: 0 });
        if (fy <= 0 && tt > 0.02) break;
      }
    }
    /* 一周もせず、離れもしないとき（＝振り子のように往復する）は1周期で切る */
    var kind = left ? 'fly' : (arr[arr.length - 1].th >= 2 * Math.PI - 1e-6 ? 'loop' : 'swing');
    var tEnd = arr[arr.length - 1].t, turn = [];
    if (kind === 'swing') {
      for (i = 1; i < arr.length; i++) {
        if (arr[i - 1].om * arr[i].om <= 0) { turn.push(arr[i].t); if (turn.length >= 2) break; }
      }
      if (turn.length >= 2) tEnd = 2 * (turn[1] - turn[0]);
    }
    /* 一番高くなる時刻 */
    var tTop = 0, hi = -1;
    for (i = 0; i < arr.length && arr[i].t <= tEnd + 1e-9; i++) {
      if (arr[i].y > hi) { hi = arr[i].y; tTop = arr[i].t; }
    }
    return { tab: arr, kind: kind, tEnd: tEnd, tTop: tTop, hTop: hi };
  }),
  table: function (v) { return P.m16._tab('v' + v.v0, v); },
  tEnd: function (v) { return P.m16.table(v).tEnd; },
  tTop: function (v) { return P.m16.table(v).tTop; },
  kind: function (v) { return P.m16.table(v).kind; },
  sample: function (v, t) {
    var o = P.m16.table(v), r = INT.at(o.tab, t, P.m16.DT);
    return EN.mix(v, { x: r.x, y: r.y, v: r.v, h: r.y, sp: 0, w: 0,
      th: r.th, on: r.on, vx: r.vx, vy: r.vy, N: r.Nm * v.m });
  }
};

/* ============ 1-7 斜方投射 ============ 基準面＝地面。すべて閉じた式。 */
P.m17 = {
  vx: function (v) { return v.v0 * Math.cos(v.th * DEG); },
  vy0: function (v) { return v.v0 * Math.sin(v.th * DEG); },
  tTop: function (v) { return P.m17.vy0(v) / G; },
  tEnd: function (v) {
    var u = P.m17.vy0(v);
    return (u + Math.sqrt(u * u + 2 * G * v.h)) / G;
  },
  yTop: function (v) { return v.h + P.m17.vy0(v) * P.m17.vy0(v) / (2 * G); },
  vTop: function (v) { return P.m17.vx(v); },                      /* 最高点の速さ＝水平成分 */
  vEnd: function (v) { return Math.sqrt(v.v0 * v.v0 + 2 * G * v.h); },
  sample: function (v, t) {
    var T = P.m17.tEnd(v), tt = clamp(t, 0, T);
    var vx = P.m17.vx(v), vy = P.m17.vy0(v) - G * tt;
    var y = v.h + P.m17.vy0(v) * tt - 0.5 * G * tt * tt;
    return EN.mix(v, { x: vx * tt, y: y, vx: vx, vy: vy, v: Math.hypot(vx, vy),
      h: y, sp: 0, w: 0 });
  }
};

/* ============ 1-8 水平面ばね（単振動・閉じた式） ============
   基準面＝床（h = 0）。x は自然長からの変形。E = ½mv² + ½kx² が一定。 */
P.m18 = {
  om: function (v) { return Math.sqrt(v.k / v.m); },
  /* ★1.25周期で止める★ 終わりが「自然長を通るところ（＝くらべる点 B）」に来るので、
     最後の画面がそのまま B の説明になる。 */
  period: function (v) { return 2 * Math.PI / P.m18.om(v); },
  tEnd: function (v) { return 1.25 * P.m18.period(v); },
  tNat: function (v) { return Math.PI / 2 / P.m18.om(v); },        /* 自然長に来る時刻 */
  vMax: function (v) { return v.x0 * P.m18.om(v); },               /* ★式で出す★ */
  sample: function (v, t) {
    var w = P.m18.om(v), x = v.x0 * Math.cos(w * t), sp = -v.x0 * w * Math.sin(w * t);
    /* v は「速さ」（0以上）。向きつきは vs に入れる（矢印の向きに使う） */
    return EN.mix(v, { x: x, y: 0, v: Math.abs(sp), vs: sp, h: 0, sp: x, w: 0 });
  }
};

/* ============ 1-9 鉛直のばね（手をはなす・単振動） ============
   x は自然長からの伸び（下向き正）。つりあいの位置 x_eq = mg/k のまわりの単振動。
   基準面＝最下点なので h ≥ 0。 */
P.m19 = {
  xEq: function (v) { return v.m * G / v.k; },
  om: function (v) { return Math.sqrt(v.k / v.m); },
  xLow: function (v) { return 2 * P.m19.xEq(v) - v.d; },           /* 最下点の伸び */
  tEnd: function (v) { return 2 * Math.PI / P.m19.om(v); },
  tEq: function (v) { return Math.PI / 2 / P.m19.om(v); },         /* つりあいの位置に来る時刻 */
  tLow: function (v) { return Math.PI / P.m19.om(v); },            /* 最下点に来る時刻 */
  vEq: function (v) { return (P.m19.xEq(v) - v.d) * P.m19.om(v); },/* つりあいの位置での速さ（最大） */
  sample: function (v, t) {
    var w = P.m19.om(v), xe = P.m19.xEq(v);
    var x = xe + (v.d - xe) * Math.cos(w * t);
    var sp = -(v.d - xe) * w * Math.sin(w * t);
    /* ★基準面は「はじめの位置（手をはなす高さ）」★ 下がると高さは負になる */
    var h = v.d - x;
    /* v は「速さ」（0以上）。向きつきは vs（下向きが正） */
    return EN.mix(v, { x: x, y: -x, v: Math.abs(sp), vs: sp, h: h, sp: x, w: 0 });
  }
};

/* ============ 1-13 曲面から飛び出す ============
   ★第8回に形を作り直した★（先生の指摘）
   前は「半径 R の円のくぼみ」だけだったので、h > R にすると出発点が円の
   90°より上（オーバーハング）になり、静かにはなしても面にそって滑るという
   物理的にありえない動きになっていた（垂直抗力 0 なのに面から離れない）。
   いまは道を2つに分ける。
     ① 鉛直な壁（高さ h から R まで）… 自由落下（面は運動の向きと平行、N = 0）
     ② 円のくぼみ（θ = −90° → +60°）… 円の接線は壁とつながっていてなめらか
   道にそった座標 s で表し、加速度は a = −g·(dy/ds)。1-7 と同じ考え方。
     s < hw            壁：x = −R、y = h − s、dy/ds = −1
     s ≥ hw            円：θ = θ₀ + (s − hw)/R、x = R sinθ、y = R(1−cosθ)、dy/ds = sinθ
   （h ≤ R のときは壁がなく、θ₀ = −acos(1 − h/R)。h > R なら θ₀ = −90°）
   飛び出す点 C は θ = 60°、そのあとは放物運動。 */
P.m110 = {
  R: 2.0, PHI: 60 * Math.PI / 180, DT: INT.DT,
  alpha: function (v) { return Math.acos(clamp(1 - v.h / P.m110.R, -1, 1)); },
  /* 鉛直な壁の高さ（h が R より高いぶん） */
  wallH: function (v) { return Math.max(0, v.h - P.m110.R); },
  /* 円に入るときの角（壁があれば −90°） */
  th0: function (v) {
    return (v.h >= P.m110.R) ? -Math.PI / 2 : -P.m110.alpha(v);
  },
  /* 道にそった座標 s → 位置と傾き */
  at: function (v, s) {
    var R = P.m110.R, hw = P.m110.wallH(v);
    if (s < hw) return { x: -R, y: v.h - s, dyds: -1, th: -Math.PI / 2, wall: true };
    var q = P.m110.th0(v) + (s - hw) / R;
    return { x: R * Math.sin(q), y: R * (1 - Math.cos(q)), dyds: Math.sin(q), th: q, wall: false };
  },
  _tab: memo1(function (v) {
    var dt = P.m110.DT, PHI = P.m110.PHI, i;
    var sPos = 0, u = v.v0, arr = [], fly = null;
    var a = -G * P.m110.at(v, 0).dyds;
    for (i = 0; i <= 6000; i++) {
      var t = i * dt;
      if (!fly) {
        var p = P.m110.at(v, sPos);
        var vx = p.wall ? 0 : u * Math.cos(p.th);
        var vy = p.wall ? -u : u * Math.sin(p.th);
        arr.push({ t: t, x: p.x, y: p.y, vx: vx, vy: vy, v: Math.abs(u),
          th: p.th, on: true, wall: p.wall });
        if (!p.wall && p.th >= PHI) {
          /* 飛び出す点は「ちょうど 60°」にそろえる（式で出した答えとぴったり合わせるため）。
             速さはエネルギー保存の式 v_C = √(v0² + 2g(h − h_C)) から出す。 */
          var hC = P.m110.R * (1 - Math.cos(PHI));
          var vC = Math.sqrt(Math.max(0, v.v0 * v.v0 + 2 * G * (v.h - hC)));
          var xC = P.m110.R * Math.sin(PHI);
          fly = { x: xC, y: hC, vx: vC * Math.cos(PHI), vy: vC * Math.sin(PHI), t: t };
          arr[arr.length - 1] = { t: t, x: xC, y: hC, vx: fly.vx, vy: fly.vy,
            v: vC, th: PHI, on: true, wall: false };
          continue;
        }
        var sN = sPos + u * dt + 0.5 * a * dt * dt;
        var aN = -G * P.m110.at(v, sN).dyds;
        u = u + 0.5 * (a + aN) * dt;
        sPos = sN; a = aN;
      } else {
        var tt = t - fly.t;
        var fy = fly.y + fly.vy * tt - 0.5 * G * tt * tt;
        var fvy = fly.vy - G * tt;
        arr.push({ t: t, x: fly.x + fly.vx * tt, y: fy, vx: fly.vx, vy: fvy,
          v: Math.hypot(fly.vx, fvy), th: null, on: false, wall: false });
        if (fvy < 0 && fy <= fly.y) break;      /* 同じ高さまで下りたら終わり */
      }
    }
    var tB = 0, tC = fly ? fly.t : arr[arr.length - 1].t, tD = tC, hi = -1;
    for (i = 0; i < arr.length; i++) {
      /* 最下点を通る時刻（壁の上は θ = −90° のままなので、円に入ってからだけ見る） */
      if (arr[i].on && !arr[i].wall && arr[i].th <= 0) tB = arr[i].t;
      /* 最高点 D は「飛び出したあと」だけで探す（スタート地点 A の方が高いことがあるため） */
      if (!arr[i].on && arr[i].y > hi) { hi = arr[i].y; tD = arr[i].t; }
    }
    return { tab: arr, tB: tB, tC: tC, tD: tD, tEnd: arr[arr.length - 1].t, fly: fly };
  }),
  table: function (v) { return P.m110._tab([v.v0, v.h].join('|'), v); },
  tEnd: function (v) { return P.m110.table(v).tEnd; },
  tB: function (v) { return P.m110.table(v).tB; },
  tC: function (v) { return P.m110.table(v).tC; },
  tD: function (v) { return P.m110.table(v).tD; },
  /* 答えは式で出す */
  vB: function (v) { return Math.sqrt(v.v0 * v.v0 + 2 * G * v.h); },
  hC: function (v) { return P.m110.R * (1 - Math.cos(P.m110.PHI)); },
  vC: function (v) { return Math.sqrt(v.v0 * v.v0 + 2 * G * (v.h - P.m110.hC(v))); },
  /* 円のくぼみを通っているときの垂直抗力 [N]（面から外向き＝円の中心向きを正）。
     まん中向きの運動方程式：N − mg cos θ = m v² / R  →  N = m(g cos θ + v²/R)。
     ★くぼみ（凹の面）だから、|θ| < 90° では cos θ > 0 で、いつでも N > 0★
     ＝「面から離れる（N ≤ 0）」ことは起こらない。だから飛び出す所は
     「面がそこで切れている」C（θ = 60°）で決まる。90_boot.js の check() で見張る。
     壁（鉛直）の上は、まっすぐ落ちるだけなので N = 0。 */
  Nof: function (v, q) {
    if (!q || q.wall || q.th === null || q.th === undefined || !q.on) return 0;
    return v.m * (G * Math.cos(q.th) + q.v * q.v / P.m110.R);
  },
  hD: function (v) {
    var vc = P.m110.vC(v), s = Math.sin(P.m110.PHI);
    return P.m110.hC(v) + vc * vc * s * s / (2 * G);
  },
  sample: function (v, t) {
    var o = P.m110.table(v), r = INT.at(o.tab, t, P.m110.DT);
    return EN.mix(v, { x: r.x, y: r.y, v: r.v, h: r.y, sp: 0, w: 0,
      vx: r.vx, vy: r.vy, on: r.on, th: r.th, wall: !!r.wall });
  }
};

/* ============ 2-2 摩擦がある斜面（すべり上がる） ============
   斜面下端から斜面上向きに v0 ですべり上がり、やがて止まる。
   加速度の大きさ |a| = g(sinθ + μ' cosθ)。基準面＝出発点（斜面の下端）。 */
P.m22 = {
  aMag: function (v) { return G * (Math.sin(v.th * DEG) + v.mu * Math.cos(v.th * DEG)); },
  tStop: function (v) { return v.v0 / P.m22.aMag(v); },
  sStop: function (v) { return v.v0 * v.v0 / (2 * P.m22.aMag(v)); },     /* ★式で出す★ */
  tEnd: function (v) { return P.m22.tStop(v) * 1.15 + 0.25; },
  /* 止まったあとに、すべり下りるか（tanθ > μ' なら下りる）。この図では止まったところで終わる */
  slidesBack: function (v) { return Math.tan(v.th * DEG) > v.mu + 1e-12; },
  sample: function (v, t) {
    var ts = P.m22.tStop(v), tt = clamp(t, 0, ts), am = P.m22.aMag(v);
    var s = v.v0 * tt - 0.5 * am * tt * tt;
    var sp = v.v0 - am * tt;
    var N = v.m * G * Math.cos(v.th * DEG);
    var w = -v.mu * N * s;                                   /* 動摩擦力がした仕事 */
    return EN.mix(v, { s: s, x: s * Math.cos(v.th * DEG), y: s * Math.sin(v.th * DEG),
      v: sp, h: s * Math.sin(v.th * DEG), sp: 0, w: w,
      moving: t < ts - 1e-9, f: v.mu * N, N: N });
  }
};

/* ============ 2-3 鉛直のばね（手でゆっくり下ろす） ============
   ★この単元の山場★ 手（非保存力）が仕事をするので力学的エネルギーは保存しない。
   動きは「手で決めた動き」なので、なめらかな関数で与える（両はしで速さ 0）。
   手がした仕事 W は、E の変化とは別に「手の力 × 変位」を数値積分して出す
   （そうしないと E(t)−E(0)=W が“定義から自明”になって検算にならない）。 */
P.m23 = {
  T: 3.0, DT: 0.002,
  xEq: function (v) { return v.m * G / v.k; },
  u: function (t) { return clamp(t / P.m23.T, 0, 1); },
  x: function (v, t) { var u = P.m23.u(t); return v.d + (P.m23.xEq(v) - v.d) * u * u * (3 - 2 * u); },
  vel: function (v, t) {
    var u = P.m23.u(t);
    if (u <= 0 || u >= 1) return 0;
    return (P.m23.xEq(v) - v.d) * 6 * u * (1 - u) / P.m23.T;
  },
  accel: function (v, t) {
    var u = P.m23.u(t);
    if (u <= 0 || u >= 1) return 0;
    return (P.m23.xEq(v) - v.d) * 6 * (1 - 2 * u) / (P.m23.T * P.m23.T);
  },
  /* 手の力（上向きの大きさ）＝ mg − kx − m·(下向きの加速度) */
  fHand: function (v, t) { return v.m * G - v.k * P.m23.x(v, t) - v.m * P.m23.accel(v, t); },
  _tab: memo1(function (v) {
    var dt = P.m23.DT, n = Math.round(P.m23.T / dt), i, W = 0, arr = [{ t: 0, W: 0 }];
    for (i = 1; i <= n; i++) {
      var t0 = (i - 1) * dt, t1 = i * dt;
      /* W = ∫ F・dx。手の力は上向き、変位は下向きなので負の仕事になる */
      var p0 = -P.m23.fHand(v, t0) * P.m23.vel(v, t0);
      var p1 = -P.m23.fHand(v, t1) * P.m23.vel(v, t1);
      W += (p0 + p1) / 2 * dt;
      arr.push({ t: t1, W: W });
    }
    return arr;
  }),
  table: function (v) { return P.m23._tab([v.d, v.k, v.m].join('|'), v); },
  W: function (v, t) { return INT.at(P.m23.table(v), clamp(t, 0, P.m23.T), P.m23.DT).W; },
  /* 手がした仕事の答え（式）：Wは −½k(x_eq² − d²) + mg(x_eq − d) の符号付き…
     ゆっくり下ろす（両はしで K=0）ので W = E2 − E1 に等しい */
  tEnd: function () { return P.m23.T; },
  xLow: function (v) { return P.m19.xLow(v); },       /* 手をはなしたときの最下点（見くらべ用） */
  sample: function (v, t) {
    var tt = clamp(t, 0, P.m23.T);
    var x = P.m23.x(v, tt), sp = P.m23.vel(v, tt);
    /* ★基準面は 1-10 と同じ「はじめの位置」★ 下がると高さは負になる */
    var h = v.d - x;
    return EN.mix(v, { x: x, y: -x, v: Math.abs(sp), vs: sp, h: h, sp: x, w: P.m23.W(v, tt),
      fh: P.m23.fHand(v, tt) });
  }
};

/* ============ 2-4 摩擦がある水平面のばね（1-9 の摩擦あり版） ============
   x は自然長からの伸び。動摩擦力の大きさ f = μ' m g は一定なので、
   半周期ごとに「中心が ±f/k にずれた単振動」になる（＝閉じた式で書ける）。
   ★はじめの伸び x0 から自然長を通るときの速さ★
     ½kx0² = ½mv² + μ' m g x0  →  v = √((k x0² − 2 μ' m g x0)/m)
   変数の範囲は x0 > 2f/k になるようにとってある（必ず自然長を通る）。 */
P.m24 = {
  om: function (v) { return Math.sqrt(v.k / v.m); },
  f: function (v) { return v.mu * v.m * G; },
  xc: function (v) { return P.m24.f(v) / v.k; },              /* 振動の中心のずれ */
  period: function (v) { return 2 * Math.PI / P.m24.om(v); },
  /* ★第14回・先生の指示★ 何往復も見せると、動摩擦力の仕事（＝力×動いた道のり）を
     求めるのが難しくなって、生徒には分かりにくい。そこで再生を2段に分けた。
       ① 0 〜 tStop            … 止まるまで、ふつうに動かす
       ② tStop 〜 +HOLD        … 止まった所でひと呼吸おく
       ③ そのあと tNat のぶん  … もう一度はじめから再生して、点 B（はじめて自然長を
                                  通る瞬間）でぴたりと止める（そこで吹きだしが出る）
     グラフの横軸は ① だけ（d.tGraph）。 */
  HOLD: 0.6,
  tGraph: function (v) { return P.m24.tStop(v); },
  tEnd: function (v) { return P.m24.tStop(v) + P.m24.HOLD + P.m24.tNat(v); },
  tNat: function (v) {                                        /* はじめて自然長を通る時刻 */
    var xc = P.m24.xc(v), A = v.x0 - xc;
    return Math.acos(clamp(-xc / A, -1, 1)) / P.m24.om(v);
  },
  /* はじめの半周期のうちに、伸びが x になる時刻（とちゅうの姿を描く場所決めに使う） */
  tAtX: function (v, xT) {
    var xc = P.m24.xc(v), A = v.x0 - xc;
    return Math.acos(clamp((xT - xc) / A, -1, 1)) / P.m24.om(v);
  },
  vNat: function (v) {                                        /* ★式で出す★ */
    return Math.sqrt(Math.max(0, (v.k * v.x0 * v.x0 - 2 * P.m24.f(v) * v.x0) / v.m));
  },
  /* 半周期ごとの区間。x(t) = c + A cos(ω(t − t0))、p0＝その区間までに動いた道のり */
  _segs: memo1(function (v) {
    var om = P.m24.om(v), xc = P.m24.xc(v), half = Math.PI / om;
    var segs = [], cross = [], x = v.x0, sg = 1, t0 = 0, p0 = 0, i;
    for (i = 0; i < 400; i++) {
      var c = sg * xc, A = x - c;
      if (Math.abs(A) < 1e-12) break;
      segs.push({ t0: t0, c: c, A: A, p0: p0 });
      /* この区間で自然長（x = 0）を通る時刻 */
      if (Math.abs(c / A) <= 1) cross.push(t0 + Math.acos(-c / A) / om);
      x = c - A;                                  /* 半周期あとの折り返し点 */
      p0 += Math.abs(2 * A); t0 += half; sg = -sg;
      if (Math.abs(x) <= xc + 1e-12) break;       /* 静止摩擦でそこに止まる */
    }
    return { segs: segs, half: half, tStop: t0, xStop: x, path: p0, cross: cross };
  }),
  tab: function (v) { return P.m24._segs([v.x0, v.k, v.m, v.mu].join('|'), v); },
  xStop: function (v) { return P.m24.tab(v).xStop; },
  tStop: function (v) { return P.m24.tab(v).tStop; },
  pathAll: function (v) { return P.m24.tab(v).path; },
  sample: function (v, t) {
    var T = P.m24.tab(v), om = P.m24.om(v), x, sp, path;
    /* ★2回目の再生★（第14回）止まって HOLD だけおいたら、はじめにもどして
       点 B（tNat）まで もう一度動かす。時刻を先頭にまきもどすだけ。 */
    var rep = false;
    if (t > T.tStop + P.m24.HOLD) {
      t = Math.min(t - T.tStop - P.m24.HOLD, P.m24.tNat(v));
      rep = true;
    }
    if (t >= T.tStop || !T.segs.length) { x = T.xStop; sp = 0; path = T.path; }
    else {
      var sg = T.segs[clamp(Math.floor(t / T.half), 0, T.segs.length - 1)];
      var tau = t - sg.t0;
      x = sg.c + sg.A * Math.cos(om * tau);
      sp = -sg.A * om * Math.sin(om * tau);
      path = sg.p0 + Math.abs(sg.A) * (1 - Math.cos(om * tau));
    }
    /* v は「速さ」（0以上）。向きつきは vs。摩擦の仕事は −f×（動いた道のり） */
    return EN.mix(v, { x: x, y: 0, v: Math.abs(sp), vs: sp, h: 0, sp: x,
      w: -P.m24.f(v) * path, path: path, replay: rep,
      moving: t < T.tStop - 1e-9, f: P.m24.f(v), N: v.m * G });
  }
};

/* ============ 2-5 摩擦がある斜面を、糸で引き上げる ============
   斜面にそって一定の力 F で引き上げる。動摩擦力は運動と逆（斜面下向き）。
   a = (F − mg sinθ − μ' mg cosθ)/m（一定）。基準面＝出発点（斜面の下端）。
   引く距離 L は 3.0 m で固定（斜面の見た目を変数で変えないため）。
   ★変数の範囲は F > mg(sinθ + μ' cosθ) になるようにとってある（必ず動きだす）★ */
P.m25 = {
  L: 3.0,
  N: function (v) { return v.m * G * Math.cos(v.th * DEG); },
  fr: function (v) { return v.mu * P.m25.N(v); },
  need: function (v) { return v.m * G * Math.sin(v.th * DEG) + P.m25.fr(v); },
  a: function (v) { return (v.Ft - P.m25.need(v)) / v.m; },
  tEnd: function (v) { return Math.sqrt(2 * P.m25.L / P.m25.a(v)); },
  vEnd: function (v) { return Math.sqrt(2 * P.m25.a(v) * P.m25.L); },   /* ★式で出す★ */
  sample: function (v, t) {
    var a = P.m25.a(v), tt = clamp(t, 0, P.m25.tEnd(v));
    var s = 0.5 * a * tt * tt, sp = a * tt;
    var si = Math.sin(v.th * DEG), co = Math.cos(v.th * DEG);
    /* 非保存力（糸の力と動摩擦力）がした仕事 */
    var w = (v.Ft - P.m25.fr(v)) * s;
    return EN.mix(v, { s: s, x: s * co, y: s * si, v: sp, h: s * si, sp: 0, w: w,
      moving: true, f: P.m25.fr(v), N: P.m25.N(v), Ft: v.Ft, a: a });
  }
};

/* ============ 1-10 水平ばねにぶつかる（★第5回・新規★）============
   なめらかな水平面を速さ v0 で走ってきて、壁につけたばねにぶつかって縮める。
   ・ぶつかるまで（A → B）：力は重力と垂直抗力だけ（どちらも運動と垂直）→ 速さは変わらない。
   ・ぶつかってから：単振動の4分の1周期で最大の縮み x_max に達する（C）。
   ★答えは式で出す★ ½mv0² = ½k x_max² → x_max = v0√(m/k)
   そのあと同じだけ押しもどされ、速さ v0 で左へ帰っていく（見せて確かめさせる）。 */
P.hitSpring = {
  D0: 1.2,                                    /* ぶつかるまでの距離（絵の都合で固定） */
  om: function (v) { return Math.sqrt(v.k / v.m); },
  xMax: function (v) { return v.v0 / P.hitSpring.om(v); },      /* ★式で出す★ = v0√(m/k) */
  t1: function (v) { return P.hitSpring.D0 / v.v0; },           /* ぶつかる時刻 */
  tC: function (v) { return P.hitSpring.t1(v) + Math.PI / 2 / P.hitSpring.om(v); },
  tOut: function (v) { return P.hitSpring.t1(v) + Math.PI / P.hitSpring.om(v); }, /* はなれる時刻 */
  tEnd: function (v) { return P.hitSpring.tOut(v) + 0.6 * P.hitSpring.t1(v); },
  sample: function (v, t) {
    var om = P.hitSpring.om(v), t1 = P.hitSpring.t1(v), A = P.hitSpring.xMax(v);
    var tOut = P.hitSpring.tOut(v), u, sp;
    if (t <= t1) { u = -P.hitSpring.D0 + v.v0 * t; sp = v.v0; }
    else if (t <= tOut) { var q = om * (t - t1); u = A * Math.sin(q); sp = v.v0 * Math.cos(q); }
    else { u = -v.v0 * (t - tOut); sp = -v.v0; }
    /* u > 0 のときだけ、ばねが u だけ縮んでいる */
    return EN.mix(v, { x: u, y: 0, v: Math.abs(sp), vs: sp, h: 0, sp: Math.max(0, u), w: 0,
      touch: u > 0 });
  }
};

/* ============ 1-11 水平ばねと滑台（★第5回・新規★）============
   なめらかな面。ばねを x0 だけ縮めて静かにはなす。
   ・A（スタート・縮めた状態）→ B（自然長にもどってばねから離れる瞬間）
     ：単振動の4分の1周期。★½k x0² = ½m v_B²★ → v_B = x0√(k/m)
   ・B →（平らな床）→ C（曲面の最高点。v = 0）
     ：★½m v_B² = mg h_C★ → h_C = k x0²/(2mg)
   曲面は y = C x²（0 ≤ x ≤ XTOP）で固定。変数の範囲は h_C < 曲面の高さになるようにとってある。 */
P.sprSlide = {
  /* ★滑台は「30° のまっすぐな坂」★（先生の指示・第8回）
     前は放物線（y = 0.75x²）で、止まる高さのあたりの傾きが 67° もあった。
     つけ根は半径 RF でまるめる（dy/ds に角があると数値積分で E がずれるため。㉓）。
       x ≤ x_F …… 円（半径 RF）  y = RF − √(RF² − x²)
       x > x_F …… 直線 30°       y = RF(1−cosθ) + (x − x_F)tanθ
     どちらも y' が x_F でつながるので、なめらか。 */
  TH: 30, RF: 0.6, XTOP: 3.3, LF: 1.2, DT: INT.DT,
  th: function () { return P.sprSlide.TH * DEG; },
  xF: function () { return P.sprSlide.RF * Math.sin(P.sprSlide.th()); },
  yAt: function (x) {
    var R = P.sprSlide.RF, th = P.sprSlide.th(), xf = P.sprSlide.xF();
    if (x <= xf) return R - Math.sqrt(Math.max(0, R * R - x * x));
    return R * (1 - Math.cos(th)) + (x - xf) * Math.tan(th);
  },
  dyAt: function (x) {
    var R = P.sprSlide.RF, th = P.sprSlide.th(), xf = P.sprSlide.xF();
    if (x <= xf) return x / Math.sqrt(Math.max(1e-9, R * R - x * x));
    return Math.tan(th);
  },
  /* 高さ h に対応する坂の上の x（吹きだし・印を置くのに使う） */
  xOfH: function (h) {
    var R = P.sprSlide.RF, th = P.sprSlide.th(), xf = P.sprSlide.xF();
    var yf = R * (1 - Math.cos(th));
    if (h <= yf) return Math.sqrt(Math.max(0, R * R - (R - h) * (R - h)));
    return xf + (h - yf) / Math.tan(th);
  },
  yTop: function () { return P.sprSlide.yAt(P.sprSlide.XTOP); },
  om: function (v) { return Math.sqrt(v.k / v.m); },
  vB: function (v) { return v.x0 * P.sprSlide.om(v); },          /* ★式で出す★ */
  hC: function (v) { return v.k * v.x0 * v.x0 / (2 * v.m * G); },/* ★式で出す★ */
  t1: function (v) { return Math.PI / 2 / P.sprSlide.om(v); },   /* ばねから離れる時刻 */
  t2: function (v) { return P.sprSlide.t1(v) + P.sprSlide.LF / P.sprSlide.vB(v); },
  _curve: null,
  curve: function () {
    if (!P.sprSlide._curve) {
      P.sprSlide._curve = arcCurve(P.sprSlide.yAt, P.sprSlide.dyAt, 0, P.sprSlide.XTOP, 900);
    }
    return P.sprSlide._curve;
  },
  _tab: memo1(function (v) {
    var cv = P.sprSlide.curve();
    return INT.verlet(function (q) { return -G * cv.at(q).dyds; }, 0, P.sprSlide.vB(v),
      P.sprSlide.DT, 6000, function (q, w, i) { return i > 3 && w <= 0; });
  }),
  table: function (v) { return P.sprSlide._tab([v.x0, v.k, v.m].join('|'), v); },
  tC: function (v) { var tb = P.sprSlide.table(v); return P.sprSlide.t2(v) + tb[tb.length - 1].t; },
  /* ★第18回・先生の指示★ 最高点で終わりにせず、「本来の続き」を見せる。
     なめらかなので運動はくり返す。行き（0〜tC）と帰り（tC〜2tC）は同じ道で、
     2tC でばねがもう一度いちばん縮む（＝A にもどる）。周期は 2tC なので、
     最高点に着くのは tC, 3tC, 5tC…。ここでは【2回目の最高点】3tC で終わりにする。
       0  〜 tC  … A →(ばねがのびる)→ B →(平ら)→ C（1回目の最高点）
       tC 〜 2tC … C →(下る)→ B →(平ら)→ A（もう一度ばねを縮める）
       2tC〜 3tC … A → B → C（2回目の最高点）でおしまい */
  tEnd: function (v) { return 3 * P.sprSlide.tC(v); },
  /* 時刻 t を「行き（0〜tC）」に折り返す。back = もどっている途中 */
  fold: function (v, t) {
    var TC = P.sprSlide.tC(v), PER = 2 * TC;
    if (!(PER > 1e-9)) return { u: 0, back: false };
    var u = clamp(t, 0, 3 * TC) % PER;
    if (u > TC) return { u: PER - u, back: true };
    return { u: u, back: false };
  },
  sample: function (v, t) {
    var f = P.sprSlide.fold(v, t);
    var q = P.sprSlide._fwd(v, f.u);
    q.back = f.back;
    q.vs = f.back ? -q.v : q.v;                 /* 向きつきの速度（矢印の向きに使う） */
    return q;
  },
  _fwd: function (v, t) {
    var om = P.sprSlide.om(v), t1 = P.sprSlide.t1(v), t2 = P.sprSlide.t2(v);
    var X, Y, sp2, spd, seg;
    if (t <= t1) {
      /* ばねの上：u = −x0 cos(ωt)（自然長の位置を 0 とする） */
      X = -v.x0 * Math.cos(om * t); Y = 0; spd = v.x0 * om * Math.sin(om * t);
      sp2 = -X; seg = 0;                       /* 縮み（正の値） */
    } else if (t <= t2) {
      X = P.sprSlide.vB(v) * (t - t1); Y = 0; spd = P.sprSlide.vB(v); sp2 = 0; seg = 1;
    } else {
      var tb = P.sprSlide.table(v), r = INT.at(tb, t - t2, P.sprSlide.DT);
      var p = P.sprSlide.curve().at(r.q);
      X = P.sprSlide.LF + p.x; Y = p.y; spd = Math.max(0, r.w); sp2 = 0; seg = 2;
      var dd = p.dyds;
      return EN.mix(v, { x: X, y: Y, v: spd, h: Y, sp: 0, w: 0, seg: seg, dyds: dd,
        cx: p.x, s: r.q });
    }
    return EN.mix(v, { x: X, y: Y, v: spd, h: Y, sp: sp2, w: 0, seg: seg, dyds: 0 });
  }
};
```

## src/40_draw.js

```js
/* 共通の描画部品。canvas の中は 1 書体（FONT）にそろえる。内部解像度は 2 倍。 */
'use strict';
var FONT = '"Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
var COL = {
  force: '#d1352b',   /* 重力・一般の力＝赤 */
  norm: '#7b3fd4',    /* 垂直抗力＝むらさき */
  fric: '#0f8a8a',    /* 摩擦力＝青緑 */
  hand: '#c2367f',    /* 手・ひもの力＝ピンク */
  vel: '#1663b5',     /* 速度＝青の白抜き */
  velx: '#1f7fd4',    /* 速度の水平成分＝明るい青の破線 */
  vely: '#0d8f7a',    /* 速度の鉛直成分＝緑がかった青の破線 */
  acc: '#e07b18',     /* 加速度＝オレンジ */
  comp: '#d1352b',    /* 分力＝もとの力と同じ色の破線 */
  areaNeg: '#7a8794',   /* グラフの「負の面積」「失われたエネルギー」の塗り＝グレー */
  dim: '#1b1f24',     /* 寸法・変位・高さ＝黒の細い破線 */
  /* ▼ このページで足した3色（エネルギー）。力・速度・加速度の色は流用しない。
     色だけでなく線の形でも区別する：K＝実線／U＝破線／E＝太い実線 */
  eK: '#22a465',      /* 運動エネルギー K＝緑 */
  eU: '#63390c',      /* 位置エネルギー U＝茶（弾性力による位置エネルギーは同じ色の点線） */
  eE: '#38475a',      /* 力学的エネルギー E＝濃い青灰 */
  A: '#1663b5',
  B: '#c0392b',
  ink: '#1b1f24',
  sub: '#5b6672',
  grid: '#e2e6ea',
  axis: '#8b949e'
};

/* いま描いている canvas の論理サイズ（ラベルのはみ出しを防ぐのに使う） */
var CVW = 0, CVH = 0, CVID = '';

/* ★このフレームで描いた「文字の場所」と「物体の場所」★
   点のエネルギーの吹きだしを、点の近くで・何にも重ならない場所に置くために使う。
   prep() で空にし、label() / ball() / blockShape() などが自動で足していく。 */
var _txtBox = [], _objBox = [];
function noteBox(arr, x, y, w, h) { arr.push({ x: x, y: y, w: w, h: h }); }

/* ★「仕事の分析」で図の力をクリックできるようにするための当たり判定★（第5回）
   力の矢印につける文字（mg・N・μ'N…）から、その力の key を決める。
   label() が自動で場所を記録するので、シムの draw を書きかえなくてよい。
   ここに無い文字は「クリックできる力」にならない。 */
var FKEY_BY_TEXT = {
  'mg': 'g', 'N': 'N', 'S': 'T',
  "μ'N": 'fr', '弾性力 kx': 'sp', '手の力 F': 'hand', 'F': 'pull'
};
var _forceHit = [];              /* [{key, x, y, w, h}]（prep でリセット） */
/* 地面の下の「吹きだしの帯」の上はし（px）。ptSide:'row' のシムが ptRow() で教える。 */
var _ptRowY = null;
function ptRow(y) { _ptRowY = y; }
var _lastFArrow = null;          /* 直前に描いた「力の矢印」（文字と合わせて当たり判定にする） */
function forceHits() { return _forceHit; }
function noteForceHit(key, left, top, w, h) {
  var x1 = left - 10, y1 = top - 8, x2 = left + w + 10, y2 = top + h + 8;
  if (_lastFArrow) {
    x1 = Math.min(x1, _lastFArrow.x1 - 7); y1 = Math.min(y1, _lastFArrow.y1 - 7);
    x2 = Math.max(x2, _lastFArrow.x2 + 7); y2 = Math.max(y2, _lastFArrow.y2 + 7);
  }
  _forceHit.push({ key: key, x: x1, y: y1, w: x2 - x1, h: y2 - y1 });
}
function noteObj(x, y, w, h) { noteBox(_objBox, x, y, w, h); }
/* 2つの長方形の重なりの面積（0 なら重なっていない） */
function boxOverlap(a, b) {
  var ox = Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x);
  var oy = Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y);
  return (ox > 0 && oy > 0) ? ox * oy : 0;
}

/* canvas を 2 倍解像度で用意して ctx を返す（論理サイズ w×h で描ける） */
function prep(cv, w, h) {
  CVW = w; CVH = h; CVID = cv.id || '';
  resetArrowOverlap();
  _txtBox.length = 0; _objBox.length = 0;
  _forceHit.length = 0; _lastFArrow = null; _ptRowY = null; _ptMarkAt.length = 0;
  var need = cv.width !== w * 2 || cv.height !== h * 2;
  if (need) { cv.width = w * 2; cv.height = h * 2; cv.style.aspectRatio = w + ' / ' + h; }
  var ctx = cv.getContext('2d');
  ctx.setTransform(2, 0, 0, 2, 0, 0);
  ctx.clearRect(0, 0, w, h);
  ctx.lineJoin = 'round';
  ctx.lineCap = 'butt';
  return ctx;
}

/* ★ベクトル（力・速度・加速度）は「いちばん前面」に描く★（先生の指示・第6回）
   終わりの絵（ゴースト）やとちゅうの姿（midGhost）を、力の矢印のあとに描いていたので
   矢印が隠れてしまった。そこで、ベクトルの矢印と、その名前の文字だけを
   いったん「あとまわしの箱」にためて、ゴーストを描いたあとにまとめて描く。
   ・deferVec(true) … ためはじめる（renderActive が d.draw の前に呼ぶ）
   ・flushVec(ctx)  … たまったものをまとめて描く
       （drawPts がゴーストと midGhost を描いたすぐあと。吹きだしを置く前）
   ためている間も、矢印のずらし（arrowShift）や文字のよけ（avoidSpot）は
   「描くとき」に計算されるので、順番は変わっても結果は正しい。
   ★点の印（A・B・C…）も同じように、あとまわしにする★（第6回の直し）
   ゴーストの物体を印の上に描いてしまい、文字が読めなくなっていた。
   前面のならび順は　ゴースト → 点の印 → ベクトル　。 */
var _defVec = null;
var _defMark = null;
function deferVec(on) { _defVec = on ? [] : null; _defMark = on ? [] : null; }
function flushVec(ctx) {
  var q, i;
  if (_defMark) {                       /* 先に点の印（ベクトルより後ろ） */
    q = _defMark; _defMark = null;
    for (i = 0; i < q.length; i++) q[i]();
  }
  if (!_defVec) return;
  q = _defVec;
  _defVec = null;                       /* 先に外す（flush 中の描画はそのまま描く） */
  for (i = 0; i < q.length; i++) q[i]();
}
/* あとまわしにする矢印の種類と、文字の色 */
var VEC_KIND = { force: 1, comp: 1, vel: 1, velcomp: 1, velx: 1, vely: 1, acc: 1 };
function isVecColor(c) {
  return c === COL.force || c === COL.norm || c === COL.fric || c === COL.hand ||
    c === COL.vel || c === COL.velx || c === COL.vely || c === COL.acc;
}

/* 矢印。kind: force / vel / acc / comp / dim / thin */
/* 力の矢印が同じ作用点で重なったとき、少しだけずらして両方見えるようにする。
   キャンバスを描き直すたびに prep() がリセットする。 */
var _fArrows = [];
function resetArrowOverlap() { _fArrows.length = 0; }
function arrowShift(x1, y1, ux, uy, len, k) {
  var step = 5.5 * k, n = 0, i;
  for (i = 0; i < _fArrows.length; i++) {
    var a = _fArrows[i];
    if (a.cat !== 'F') continue;                                   /* ずらすのは力どうしだけ */
    if (Math.abs(a.ux * uy - a.uy * ux) > 0.25) continue;          /* 平行でなければ関係ない */
    var dPerp = Math.abs((a.x - x1) * uy - (a.y - y1) * ux);       /* 直線どうしのへだたり */
    if (dPerp > 6 * k) continue;
    var t0 = (a.x - x1) * ux + (a.y - y1) * uy;                    /* 相手の始点の射影 */
    var t1 = t0 + a.len * ((a.ux * ux + a.uy * uy >= 0) ? 1 : -1); /* 相手の終点の射影 */
    var lo = Math.min(t0, t1), hi = Math.max(t0, t1);
    if (hi > 1 && lo < len - 1) n++;                               /* 線が重なっている */
  }
  var rec = { x: x1, y: y1, ux: ux, uy: uy, len: len, cat: 'F', color: COL.force };
  _fArrows.push(rec);
  var out = { dx: 0, dy: 0, rec: rec };
  if (n) {
    var sgn = (n % 2) ? 1 : -1;                           /* 右・左・右…と交互にずらす */
    var mag = step * Math.ceil(n / 2);
    out.dx = -uy * mag * sgn; out.dy = ux * mag * sgn;
  }
  return out;
}

/* 同じ長さ（＝同じ大きさ）の力の矢印に、等長の印「｜」をつける。
   1組目は1本、2組目は2本…と本数を変える。d.draw のあとに1回だけ呼ぶ。 */
function drawEqualTicks(ctx) {
  ['F', 'V'].forEach(function (cat) {
    var i, j, groups = [];
    for (i = 0; i < _fArrows.length; i++) {
      var a = _fArrows[i];
      if (a.cat.charAt(0) !== cat) continue;              /* 力は力どうし、速度は速度どうし */
      if (a.len < 19) continue;                           /* 短すぎる矢印には付けない */
      var g = null;
      for (j = 0; j < groups.length; j++) {
        if (Math.abs(groups[j].len - a.len) <= 0.8) { g = groups[j]; break; }
      }
      if (!g) { g = { len: a.len, cat: a.cat, items: [] }; groups.push(g); }
      g.items.push(a);
    }
    var eq = [];
    for (i = 0; i < groups.length; i++) if (groups[i].items.length >= 2) eq.push(groups[i]);
    eq.sort(function (p, q) { return q.len - p.len; });    /* 長い組から 1本・2本・3本 */
    for (i = 0; i < eq.length; i++) {
      var n2 = Math.min(3, i + 1);
      for (j = 0; j < eq[i].items.length; j++) equalTick(ctx, eq[i].items[j], n2);
    }
  });
}
function equalTick(ctx, a, n) {
  /* 矢じりにかからないよう、少し手前（40%くらい）に印をつける */
  var pos = Math.max(6, Math.min(a.len * 0.42, a.len - 13));
  var mx = a.x + a.ux * pos, my = a.y + a.uy * pos;
  var px = -a.uy, py = a.ux, i, d, cx, cy;
  ctx.save();
  ctx.strokeStyle = a.color; ctx.lineWidth = 2.1; ctx.lineCap = 'round'; ctx.setLineDash([]);
  for (i = 0; i < n; i++) {
    d = (i - (n - 1) / 2) * 4.6;
    cx = mx + a.ux * d; cy = my + a.uy * d;
    ctx.beginPath();
    ctx.moveTo(cx - px * 5.6, cy - py * 5.6);
    ctx.lineTo(cx + px * 5.6, cy + py * 5.6);
    ctx.stroke();
  }
  ctx.restore();
}

function arrow(ctx, x1, y1, x2, y2, kind, scale, col) {
  if (_defVec && VEC_KIND[kind]) {
    _defVec.push(function () { arrow(ctx, x1, y1, x2, y2, kind, scale, col); });
    return;
  }
  var dx = x2 - x1, dy = y2 - y1;
  var len = Math.hypot(dx, dy);
  if (len < 1.5) return;
  var k = scale || 1;
  var ux = dx / len, uy = dy / len;
  if (kind === 'force' || kind === 'comp') {              /* 重なったらずらす */
    var sh = arrowShift(x1, y1, ux, uy, len, k);
    x1 += sh.dx; y1 += sh.dy; x2 += sh.dx; y2 += sh.dy;
    sh.rec.x = x1; sh.rec.y = y1;
    sh.rec.color = col || ((kind === 'comp') ? COL.comp : COL.force);
    /* 直後に来る力の名前（label）と合わせて、クリックできる範囲にする */
    if (kind === 'force') {
      _lastFArrow = { x1: Math.min(x1, x2), y1: Math.min(y1, y2),
        x2: Math.max(x1, x2), y2: Math.max(y1, y2) };
    }
  } else if (kind === 'vel' || kind === 'velcomp' || kind === 'velx' || kind === 'vely') {
    /* 速度の矢印も「同じ長さ」の印をつけるために記録する（ずらしはしない） */
    _fArrows.push({
      x: x1, y: y1, ux: ux, uy: uy, len: len, cat: 'V',
      color: (kind === 'velx') ? COL.velx : ((kind === 'vely') ? COL.vely : COL.vel)
    });
  }
  var head = (kind === 'dim' ? 8 : (kind === 'vel' || kind === 'comp' || kind === 'velcomp' || kind === 'velx' || kind === 'vely' ? 10 : 12)) * k;
  if (head > len * 0.8) head = len * 0.8;
  var bx = x2 - ux * head, by = y2 - uy * head;

  ctx.save();
  ctx.lineJoin = 'round';
  var FC = col || COL.force;                 /* 力の色（種類ごとに変えられる） */
  if (kind === 'force') { ctx.strokeStyle = FC; ctx.fillStyle = FC; ctx.lineWidth = 3.4 * k; }
  else if (kind === 'acc') { ctx.strokeStyle = COL.acc; ctx.fillStyle = COL.acc; ctx.lineWidth = 3.0 * k; }
  else if (kind === 'vel') { ctx.strokeStyle = COL.vel; ctx.fillStyle = '#ffffff'; ctx.lineWidth = 2.2 * k; }
  else if (kind === 'velcomp') { ctx.strokeStyle = COL.vel; ctx.fillStyle = 'rgba(22,99,181,.35)'; ctx.lineWidth = 2.0 * k; ctx.setLineDash([6 * k, 4 * k]); }
  else if (kind === 'velx') { ctx.strokeStyle = COL.velx; ctx.fillStyle = COL.velx; ctx.lineWidth = 2.2 * k; ctx.setLineDash([7 * k, 4 * k]); }
  else if (kind === 'vely') { ctx.strokeStyle = COL.vely; ctx.fillStyle = COL.vely; ctx.lineWidth = 2.2 * k; ctx.setLineDash([7 * k, 4 * k]); }
  else if (kind === 'comp') { ctx.strokeStyle = FC; ctx.fillStyle = fade(FC, .38); ctx.lineWidth = 2.1 * k; ctx.setLineDash([6 * k, 4 * k]); }
  else { ctx.strokeStyle = COL.dim; ctx.fillStyle = COL.dim; ctx.lineWidth = 1.2 * k; ctx.setLineDash([5 * k, 4 * k]); }

  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(bx, by); ctx.stroke();
  ctx.setLineDash([]);
  if (kind === 'force' || kind === 'comp') {              /* 作用点を「・」ではっきり示す */
    ctx.beginPath();
    ctx.arc(x1, y1, 3.1 * k, 0, Math.PI * 2);
    ctx.fillStyle = FC; ctx.fill();
    if (kind === 'comp') { ctx.lineWidth = 1.2 * k; ctx.strokeStyle = '#fff'; ctx.stroke(); ctx.strokeStyle = FC; }
    ctx.fillStyle = (kind === 'comp') ? fade(FC, .38) : FC;
  }
  var wA = head * 0.5;
  ctx.beginPath();
  ctx.moveTo(x2, y2);
  ctx.lineTo(bx - uy * wA, by + ux * wA);
  ctx.lineTo(bx + uy * wA, by - ux * wA);
  ctx.closePath();
  ctx.fill();
  if (kind === 'vel' || kind === 'comp' || kind === 'velcomp') {
    ctx.lineWidth = Math.max(2.0 * k, ctx.lineWidth);
    ctx.setLineDash([]);
    ctx.stroke();
  }
  ctx.restore();
}

/* 文字列を「ふつうの字」と「添え字」に分ける。v_0 / v_x / v_{y0} と書ける */
function splitSub(text) {
  var segs = [], i = 0, cur = '';
  while (i < text.length) {
    var ch = text.charAt(i);
    if (ch === '_' && i + 1 < text.length) {
      if (cur) { segs.push({ s: cur, sub: false }); cur = ''; }
      if (text.charAt(i + 1) === '{') {
        var end = text.indexOf('}', i + 2);
        if (end === -1) end = text.length;
        segs.push({ s: text.slice(i + 2, end), sub: true });
        i = end + 1;
      } else {
        segs.push({ s: text.charAt(i + 1), sub: true });
        i += 2;
      }
    } else { cur += ch; i++; }
  }
  if (cur) segs.push({ s: cur, sub: false });
  return segs;
}

/* canvas の文字。添え字（v_0 など）に対応し、canvas の外にはみ出さないように寄せる */
/* この色の文字は「よけてよい文字」（力・速度・加速度・寸法のラベル）。
   図の名前・軸・基準面などは動かさない。 */
var AVOID_COLORS = [COL.force, COL.norm, COL.fric, COL.hand,
  COL.vel, COL.velx, COL.vely, COL.acc, COL.dim];
function isAvoidColor(c) {
  if (!c) return false;
  for (var i = 0; i < AVOID_COLORS.length; i++) if (AVOID_COLORS[i] === c) return true;
  return false;
}
/* すでに置いた文字（_txtBox）とぶつからない場所を、近いところから探す。
   [dx, dy] を返す。見つからなければ、いちばんぶつかりの少ないところ。 */
function avoidSpot(left, y, w, h) {
  var DX = [0, 10, -10, 20, -20, 28, -28];
  var DY = [0, 12, -12, 24, -24];
  var best = [0, 0], bestSc = Infinity, i, j, k;
  for (i = 0; i < DY.length; i++) {
    for (j = 0; j < DX.length; j++) {
      var b = { x: left + DX[j], y: y - h / 2 + DY[i], w: w, h: h }, sc = 0;
      for (k = 0; k < _txtBox.length; k++) sc += boxOverlap(b, _txtBox[k]);
      sc = sc * 4 + Math.abs(DX[j]) + Math.abs(DY[i]);
      if (sc < bestSc) { bestSc = sc; best = [DX[j], DY[i]]; }
    }
  }
  return best;
}

function label(ctx, text, x, y, opt) {
  opt = opt || {};
  if (_defVec && isVecColor(opt.color)) {
    _defVec.push(function () { label(ctx, text, x, y, opt); });
    return;
  }
  var size = opt.size || 13;
  var bold = opt.bold ? 'bold ' : '';
  var mainFont = bold + size + 'px ' + FONT;
  var subFont = bold + (size * 0.72).toFixed(1) + 'px ' + FONT;
  var segs = splitSub(String(text));
  var i, sg;
  ctx.save();
  ctx.textBaseline = opt.base || 'middle';
  ctx.textAlign = 'left';
  ctx.lineJoin = 'round';
  var tw = 0;
  for (i = 0; i < segs.length; i++) {
    ctx.font = segs[i].sub ? subFont : mainFont;
    segs[i].w = ctx.measureText(segs[i].s).width;
    tw += segs[i].w;
  }
  var al = opt.align || 'center';
  var left = al === 'right' ? x - tw : (al === 'left' ? x : x - tw / 2);
  if (CVW > 0 && opt.clamp !== false) {
    if (left < 4) left = 4;
    else if (left + tw > CVW - 4) left = Math.max(4, CVW - 4 - tw);
    if (y < 9) y = 9; else if (y > CVH - 7) y = CVH - 7;
  }
  /* ★力・速度・寸法の文字は、先に置いた文字とぶつかったら少しだけよける★
     （矢印から離れすぎないよう、ずらすのは 28px まで） */
  if (CVW > 0 && opt.clamp !== false && (opt.avoid || isAvoidColor(opt.color))) {
    var sp = avoidSpot(left, y, tw, size);
    left += sp[0]; y += sp[1];
    if (left < 4) left = 4;
    else if (left + tw > CVW - 4) left = Math.max(4, CVW - 4 - tw);
    if (y < 9) y = 9; else if (y > CVH - 7) y = CVH - 7;
  }
  var cx, sy;
  if (opt.halo !== false) {                 /* まず白フチをぜんぶ描く */
    ctx.strokeStyle = opt.haloColor || 'rgba(255,255,255,.92)';
    ctx.lineWidth = opt.haloW || 4.5;
    cx = left;
    for (i = 0; i < segs.length; i++) {
      sg = segs[i];
      ctx.font = sg.sub ? subFont : mainFont;
      sy = y + (sg.sub ? size * 0.26 : 0);
      ctx.strokeText(sg.s, cx, sy);
      cx += sg.w;
    }
  }
  /* 文字の置き場所を記録する（吹きだしの自動配置と、重なりの自動検査に使う） */
  noteBox(_txtBox, left, y - size / 2, tw, size);
  /* 力の名前なら、クリックできる場所としても記録する（「仕事の分析」で使う） */
  if (FKEY_BY_TEXT[String(text)] && opt.fhit !== false) {
    noteForceHit(FKEY_BY_TEXT[String(text)], left, y - size / 2, tw, size);
  }
  if (typeof window !== 'undefined' && window.__labelLog) {
    window.__labelLog.push({ cv: CVID, text: String(text), x: left, y: y, w: tw, h: size });
  }
  ctx.fillStyle = opt.color || COL.ink;
  cx = left;
  for (i = 0; i < segs.length; i++) {
    sg = segs[i];
    ctx.font = sg.sub ? subFont : mainFont;
    sy = y + (sg.sub ? size * 0.26 : 0);
    ctx.fillText(sg.s, cx, sy);
    cx += sg.w;
  }
  ctx.restore();
}

/* 衝突のエフェクト（ギザギザ＋文字）。文字がはみ出さないように星を広げる */
function impact(ctx, x, y, r, text) {
  var i, a, rr;
  text = text || 'ドコッ！';
  var sz = Math.max(12, Math.min(18, r * 0.6));
  ctx.save();
  ctx.font = 'bold ' + sz + 'px ' + FONT;
  var tw = ctx.measureText(text).width;
  ctx.restore();
  r = Math.max(r, tw / 2 + 14);
  ctx.save();
  ctx.beginPath();
  var n = 11;
  for (i = 0; i < n * 2; i++) {
    a = Math.PI * i / n - Math.PI / 2;
    rr = (i % 2 === 0) ? r : r * 0.56;
    if (i === 0) ctx.moveTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr);
    else ctx.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr);
  }
  ctx.closePath();
  ctx.fillStyle = '#ffe27a'; ctx.strokeStyle = '#d1352b'; ctx.lineWidth = 2.4;
  ctx.fill(); ctx.stroke();
  /* まわりに飛び散る線 */
  ctx.lineWidth = 2.2; ctx.strokeStyle = '#d1352b';
  for (i = 0; i < 8; i++) {
    a = Math.PI * 2 * i / 8 + 0.2;
    ctx.beginPath();
    ctx.moveTo(x + Math.cos(a) * (r + 4), y + Math.sin(a) * (r + 4));
    ctx.lineTo(x + Math.cos(a) * (r + 15), y + Math.sin(a) * (r + 15));
    ctx.stroke();
  }
  ctx.restore();
  label(ctx, text, x, y + 1, { size: sz, bold: true, color: '#c0392b', halo: false, clamp: false });
}

/* ===== かんたんな3次元の投影（正射影・方位角と仰角で見回す） ===== */
function mk3d(az, el, S, cx, cy) {
  var ca = Math.cos(az), sa = Math.sin(az), ce = Math.cos(el), se = Math.sin(el);
  return {
    az: az, el: el, S: S,
    p: function (x, y, z) {
      var x1 = x * ca - y * sa, y1 = x * sa + y * ca;
      return {
        x: cx + x1 * S,
        y: cy - (z * ce - y1 * se) * S,
        d: y1 * ce + z * se
      };
    }
  };
}

/* 面のハッチング。ang＝面の向き（rad, 右向きが0）、below＝面の下側にかく */
function hatchLine(ctx, x1, y1, x2, y2, side) {
  ctx.save();
  ctx.strokeStyle = '#333'; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
  var dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy);
  if (L < 1) { ctx.restore(); return; }
  var ux = dx / L, uy = dy / L;
  var nx = -uy * side, ny = ux * side;    /* 面の「内側」向き法線 */
  ctx.lineWidth = 1;
  for (var d = 4; d < L; d += 10) {
    var px = x1 + ux * d, py = y1 + uy * d;
    ctx.beginPath();
    ctx.moveTo(px, py);
    ctx.lineTo(px - ux * 8 + nx * 8, py - uy * 8 + ny * 8);
    ctx.stroke();
  }
  ctx.restore();
}

function ball(ctx, x, y, r, style) {
  noteObj(x - r, y - r, 2 * r, 2 * r);
  ctx.save();
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2);
  if (style === 'faint') { ctx.fillStyle = '#e7eaee'; ctx.strokeStyle = '#aab0b8'; ctx.lineWidth = 1.1; }
  else if (style === 'A') { ctx.fillStyle = '#cfe0f4'; ctx.strokeStyle = COL.A; ctx.lineWidth = 2; }
  else if (style === 'B') { ctx.fillStyle = '#f6d6d2'; ctx.strokeStyle = COL.B; ctx.lineWidth = 2; }
  else { ctx.fillStyle = '#fff'; ctx.strokeStyle = '#111'; ctx.lineWidth = 2; }
  ctx.fill(); ctx.stroke();
  ctx.restore();
}

/* 角度の弧（θ の記号） */
function angArc(ctx, cx, cy, r, a1, a2, text, labAng, labR) {
  ctx.save();
  ctx.strokeStyle = COL.sub; ctx.lineWidth = 1.3;
  ctx.beginPath(); ctx.arc(cx, cy, r, a1, a2, a2 < a1);
  ctx.stroke();
  ctx.restore();
  var am = (labAng === undefined || labAng === null) ? (a1 + a2) / 2 : labAng;
  var rr = labR || (r + 15);
  if (text) label(ctx, text, cx + Math.cos(am) * rr, cy + Math.sin(am) * rr,
    { size: 12.5, color: COL.sub, avoid: true });
}

/* 手（斜面上向きに引く／押す）。(hx,hy)＝手のひらの中心、ang＝向き（rad） */
/* 色をうすくする（#rrggbb → rgba） */
function fade(hex, a) {
  var h = (hex || '#d1352b').replace('#', '');
  var r = parseInt(h.substring(0, 2), 16), g = parseInt(h.substring(2, 4), 16), b = parseInt(h.substring(4, 6), 16);
  return 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')';
}

/* ===== 小さな効果音（Web Audio。外部ファイルは使わない） ===== */
var _AC = null;
function sfx(kind) {
  try {
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    if (!_AC) _AC = new AC();
    if (_AC.state === 'suspended' && _AC.resume) _AC.resume();
    var t0 = _AC.currentTime, o = _AC.createOscillator(), g = _AC.createGain();
    o.connect(g); g.connect(_AC.destination);
    if (kind === 'bang') {               /* 発射音「ばん！」 */
      o.type = 'square';
      o.frequency.setValueAtTime(260, t0);
      o.frequency.exponentialRampToValueAtTime(60, t0 + 0.16);
      g.gain.setValueAtTime(0.16, t0);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + 0.2);
      o.start(t0); o.stop(t0 + 0.22);
    } else if (kind === 'hit') {         /* 命中音 */
      o.type = 'triangle';
      o.frequency.setValueAtTime(880, t0);
      o.frequency.exponentialRampToValueAtTime(180, t0 + 0.18);
      g.gain.setValueAtTime(0.13, t0);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + 0.22);
      o.start(t0); o.stop(t0 + 0.24);
    } else if (kind === 'win') {         /* 成功の「ぴろりん」 */
      o.type = 'triangle';
      o.frequency.setValueAtTime(784, t0);
      o.frequency.setValueAtTime(1046, t0 + 0.09);
      o.frequency.setValueAtTime(1318, t0 + 0.18);
      g.gain.setValueAtTime(0.12, t0);
      g.gain.setValueAtTime(0.12, t0 + 0.24);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + 0.42);
      o.start(t0); o.stop(t0 + 0.44);
    } else {                             /* 「ピコン」 */
      o.type = 'sine';
      o.frequency.setValueAtTime(660, t0);
      o.frequency.setValueAtTime(990, t0 + 0.07);
      g.gain.setValueAtTime(0.09, t0);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + 0.18);
      o.start(t0); o.stop(t0 + 0.2);
    }
    /* 鳴り終わったノードは切りはなす（何度も鳴らすうちに音のつながりがたまらないように） */
    o.onended = function () { try { o.disconnect(); g.disconnect(); } catch (e2) { } };
  } catch (e) { /* 音が出せない環境では何もしない */ }
}

/* 小球を落とそうとする手（真横やや上から。指先の下に小球が来るように描く）。
   (x,y)＝小球の中心。sc＝大きさ、open＝0〜1（1 で親指と人差し指をひらいた形）、
   alpha＝濃さ。 */
function dropHand(ctx, x, y, sc, open, alpha) {
  sc = sc || 1;
  noteObj(x - 70 * sc, y - 100 * sc, 170 * sc, 105 * sc);
  var o = Math.max(0, Math.min(1, open || 0));
  var INK = '#3f4a54', SKIN = '#ffffff';
  ctx.save();
  ctx.translate(x, y); ctx.scale(sc, sc);
  ctx.globalAlpha = (alpha === undefined) ? 1 : alpha;
  ctx.lineJoin = 'round'; ctx.lineCap = 'round';

  function limb(x0, y0, cx, cy, x1, y1, w) {     /* 指・親指（外枠つきの太い線） */
    ctx.beginPath();
    ctx.moveTo(x0, y0); ctx.quadraticCurveTo(cx, cy, x1, y1);
    ctx.lineWidth = w + 3.4; ctx.strokeStyle = INK; ctx.stroke();
    ctx.lineWidth = w; ctx.strokeStyle = SKIN; ctx.stroke();
  }
  /* 指（奥から手前へ4本）。右から2本目＝人差し指だけ、ひらくときに動く */
  limb(-28, -66, -58, -54, -66, -28, 12);
  limb(-14, -72, -46, -58, -52, -21, 13);
  limb(2, -74, -30, -60, -33, -16, 14);
  limb(16, -72, -10 - 9 * o, -58, -13 - 21 * o, -15 - 9 * o, 14);   /* 人差し指 */
  /* 手の甲 */
  ctx.beginPath();
  ctx.moveTo(-32, -62);
  ctx.bezierCurveTo(-8, -94, 42, -98, 64, -74);
  ctx.bezierCurveTo(80, -58, 62, -40, 34, -40);
  ctx.bezierCurveTo(10, -40, -12, -46, -32, -62);
  ctx.closePath();
  ctx.fillStyle = SKIN; ctx.fill();
  ctx.lineWidth = 3.2; ctx.strokeStyle = INK; ctx.stroke();
  /* 手首・腕 */
  ctx.beginPath();
  ctx.moveTo(56, -84); ctx.lineTo(96, -78);
  ctx.lineTo(96, -50); ctx.lineTo(58, -46);
  ctx.closePath();
  ctx.fillStyle = SKIN; ctx.fill(); ctx.lineWidth = 3.2; ctx.strokeStyle = INK; ctx.stroke();
  /* 親指（右手前）。ひらくときは右へ開く */
  limb(42, -48, 40 + 10 * o, -25, 17 + 24 * o, -12 - 8 * o, 15);
  /* 指のしわ */
  ctx.lineWidth = 1.3; ctx.strokeStyle = INK; ctx.globalAlpha *= 0.75;
  ctx.beginPath(); ctx.moveTo(-46, -47); ctx.lineTo(-38, -44); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(-26, -47); ctx.lineTo(-18, -45); ctx.stroke();
  ctx.restore();
}

/* デコピンする手（物体をはじく）。
   (x,y)＝こぶしの中心、ang＝はじく向き（rad、+x がはじく向き）、
   k＝0…指を曲げた形／1…はじいたあとの形、dir＝+1 か −1（左右の向き）、
   sc＝大きさ、alpha＝濃さ。 */
function flickHand(ctx, x, y, ang, k, dir, sc, alpha) {
  k = Math.max(0, Math.min(1, k || 0));
  sc = sc || 0.45;
  noteObj(x - 110 * sc, y - 60 * sc, 220 * sc, 130 * sc);
  var SKIN = '#fbd7b7', INK = '#4a3730';
  function mix(a, b) { return a + (b - a) * k; }
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(ang);
  if (dir < 0) ctx.scale(-1, 1);
  ctx.scale(sc, sc);
  ctx.globalAlpha = (alpha === undefined) ? 1 : alpha;
  ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  ctx.fillStyle = SKIN; ctx.strokeStyle = INK;

  /* 腕（後ろへ） */
  ctx.lineWidth = 26; ctx.strokeStyle = SKIN;
  ctx.beginPath(); ctx.moveTo(-6, 10); ctx.lineTo(-96, 58); ctx.stroke();
  ctx.lineWidth = 3.4; ctx.strokeStyle = INK;
  ctx.beginPath(); ctx.moveTo(-14, -2); ctx.lineTo(-100, 46); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(-2, 22); ctx.lineTo(-92, 70); ctx.stroke();

  /* こぶし */
  ctx.beginPath(); ctx.arc(0, 0, 30, 0, Math.PI * 2);
  ctx.fillStyle = SKIN; ctx.fill(); ctx.lineWidth = 3.4; ctx.strokeStyle = INK; ctx.stroke();
  /* 折りたたんだ指（3つのふくらみ） */
  ctx.lineWidth = 2.6;
  ctx.beginPath(); ctx.ellipse(24, -18, 15, 11, -0.35, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.ellipse(28, 2, 16, 12, -0.15, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.ellipse(22, 22, 17, 12, 0.15, 0, Math.PI * 2); ctx.fill(); ctx.stroke();

  /* はじく指：曲げた形（Λ）→ まっすぐ */
  var jx = mix(34, 44), jy = mix(-52, -20), tx = mix(52, 80), ty = mix(-16, -12);
  ctx.lineWidth = 15; ctx.strokeStyle = SKIN;
  ctx.beginPath(); ctx.moveTo(16, -20); ctx.lineTo(jx, jy); ctx.lineTo(tx, ty); ctx.stroke();
  ctx.lineWidth = 18; ctx.strokeStyle = INK;
  ctx.beginPath(); ctx.moveTo(16, -20); ctx.lineTo(jx, jy); ctx.lineTo(tx, ty);
  ctx.strokeStyle = INK; ctx.lineWidth = 3.2;
  ctx.stroke();
  ctx.lineWidth = 12; ctx.strokeStyle = SKIN;
  ctx.beginPath(); ctx.moveTo(16, -20); ctx.lineTo(jx, jy); ctx.lineTo(tx, ty); ctx.stroke();

  /* はじいた瞬間の勢いの線 */
  if (k > 0.15 && k < 0.95) {
    ctx.strokeStyle = INK; ctx.lineWidth = 2.4; ctx.globalAlpha *= (1 - k);
    for (var i2 = -1; i2 <= 1; i2++) {
      ctx.beginPath();
      ctx.moveTo(tx + 12, ty + i2 * 14); ctx.lineTo(tx + 30, ty + i2 * 20);
      ctx.stroke();
    }
  }
  ctx.restore();
}

/* 糸（ひも）：物体と手をつなぐ細い線 */
function string(ctx, x1, y1, x2, y2) {
  ctx.save();
  ctx.strokeStyle = '#6b5442'; ctx.lineWidth = 1.6; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
  ctx.restore();
}

function hand(ctx, hx, hy, ang) {
  /* 吹きだしがこの手をよけられるように、場所を覚えておく（まわした形のはこ） */
  var ca = Math.cos(ang || 0), sa = Math.sin(ang || 0);
  var cs = [[-15, -13], [43, -13], [43, 13], [-15, 13]], ii, xs = [], ys = [];
  for (ii = 0; ii < 4; ii++) {
    xs.push(hx + cs[ii][0] * ca - cs[ii][1] * sa);
    ys.push(hy + cs[ii][0] * sa + cs[ii][1] * ca);
  }
  var x1 = Math.min.apply(null, xs), y1 = Math.min.apply(null, ys);
  noteObj(x1, y1, Math.max.apply(null, xs) - x1, Math.max.apply(null, ys) - y1);
  ctx.save();
  ctx.translate(hx, hy);
  ctx.rotate(ang);
  ctx.fillStyle = '#f6d9bd'; ctx.strokeStyle = '#a97b4c'; ctx.lineWidth = 1.4;
  /* 腕 */
  ctx.beginPath();
  ctx.moveTo(10, -6); ctx.lineTo(40, -7); ctx.lineTo(40, 7); ctx.lineTo(10, 6);
  ctx.closePath(); ctx.fill(); ctx.stroke();
  /* こぶし */
  ctx.beginPath();
  ctx.ellipse(2, 0, 13, 11, 0, 0, Math.PI * 2);
  ctx.fill(); ctx.stroke();
  /* 指の線 */
  ctx.beginPath();
  ctx.moveTo(-8, -5); ctx.lineTo(4, -5);
  ctx.moveTo(-9, 0); ctx.lineTo(5, 0);
  ctx.moveTo(-8, 5); ctx.lineTo(4, 5);
  ctx.stroke();
  ctx.restore();
}

/* 下から支える手（手のひらを上に向けた線画。添付のイラストに合わせた形）。
   (x, y) ＝ 手のひらのてっぺん（＝ものが乗るところ）、sc＝大きさ、flip＝左右を返す。
   ★物体の下にぴったり接するように置く★（2-3 でおもりを支える手） */
function handUnder(ctx, x, y, sc, flip) {
  sc = sc || 1;
  var INK = '#1b1f24', SKIN = '#ffffff';
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(flip ? -sc : sc, sc);
  ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  function limb(x0, y0, cx2, cy2, x1, y1, w) {      /* 指（外枠つきの太い線） */
    ctx.beginPath();
    ctx.moveTo(x0, y0); ctx.quadraticCurveTo(cx2, cy2, x1, y1);
    ctx.lineWidth = w + 3; ctx.strokeStyle = INK; ctx.stroke();
    ctx.lineWidth = w; ctx.strokeStyle = SKIN; ctx.stroke();
  }
  /* 指（奥から手前へ4本）。手のひらの左はしから左へのびる */
  limb(-4, 16, -26, 20, -44, 12, 7);
  limb(-4, 12, -30, 15, -48, 5, 7.5);
  limb(-4, 8, -30, 9, -46, -3, 7.5);
  limb(-4, 4, -26, 3, -38, -9, 7);
  /* 手のひら（上の面が平ら＝ものが乗る） */
  ctx.beginPath();
  ctx.moveTo(-10, 18);
  ctx.bezierCurveTo(-16, 4, -4, -4, 12, -3);
  ctx.lineTo(26, 6);
  ctx.lineTo(12, 20);
  ctx.closePath();
  ctx.fillStyle = SKIN; ctx.fill();
  ctx.lineWidth = 2.6; ctx.strokeStyle = INK; ctx.stroke();
  /* 親指（上へ折れる） */
  limb(4, -1, -2, -10, -14, -9, 7);
  /* 手首と腕（右下へ） */
  ctx.beginPath(); ctx.moveTo(20, 2); ctx.lineTo(46, 34);
  ctx.lineWidth = 19; ctx.strokeStyle = SKIN; ctx.stroke();
  ctx.lineWidth = 2.6; ctx.strokeStyle = INK;
  ctx.beginPath(); ctx.moveTo(13, -2); ctx.lineTo(39, 30); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(27, 7); ctx.lineTo(53, 39); ctx.stroke();
  ctx.restore();
  noteObj(x - 52 * sc, y - 14 * sc, 108 * sc, 56 * sc);
}

/* 吹き出し。opt.up＝true でしっぽを上向きにする（指したいものが吹き出しより上にあるとき）。
   (x, y) は「しっぽの先」＝指したい場所。 */
/* ★見どころの数値を1つだけ大きく出す小さなパネル★（先生の指示・第11回）
   1-12（手をはなす）と 2-3（手でゆっくり下ろす）で
   「つりあいの位置での速さ」を、生徒が一目で見くらべられるようにするために作った。
   (x, y) は箱の左上。title＝小さい見出し、value＝大きい数値、sub＝そのあとの短い言葉。
   吹きだしと同じように、場所を _txtBox に記録して他の文字が避けられるようにする。 */
function factPanel(ctx, x, y, title, value, sub, opt) {
  opt = opt || {};
  var pad = 11, tSz = 11.5, vSz = 17, sSz = 12;
  ctx.save();
  ctx.font = tSz + 'px ' + FONT;
  var wT = ctx.measureText(title).width;
  ctx.font = 'bold ' + vSz + 'px ' + FONT;
  var wV = ctx.measureText(value).width;
  ctx.font = sSz + 'px ' + FONT;
  var wS = sub ? ctx.measureText(sub).width : 0;
  var w = Math.max(wT, wV + (sub ? wS + 9 : 0)) + pad * 2 + 6;
  var h = 54;
  if (CVW > 0) x = clamp(x, 3, Math.max(3, CVW - w - 3));
  /* 箱 */
  ctx.fillStyle = opt.bg || '#fff8e9';
  ctx.strokeStyle = opt.border || COL.acc;
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(x, y, w, h, 8);
  else ctx.rect(x, y, w, h);
  ctx.fill(); ctx.stroke();
  /* 左のたての帯（見どころの色） */
  ctx.fillStyle = opt.border || COL.acc;
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(x + 4, y + 6, 4, h - 12, 2);
  else ctx.rect(x + 4, y + 6, 4, h - 12);
  ctx.fill();
  ctx.restore();
  label(ctx, title, x + pad + 6, y + 15,
    { size: tSz, color: opt.tcolor || '#8a5000', align: 'left', halo: false });
  label(ctx, value, x + pad + 6, y + 37,
    { size: vSz, bold: true, color: opt.vcolor || '#28323d', align: 'left', halo: false });
  if (sub) {
    label(ctx, sub, x + pad + 6 + wV + 9, y + 39,
      { size: sSz, color: opt.scolor || '#6b7683', align: 'left', halo: false });
  }
  noteBox(_txtBox, x, y, w, h);
  noteObj(x, y, w, h);
  /* ★__labelLog には箱を入れない★ 中の3つの文字は label() が自分で記録するので、
     箱まで入れると「箱と、その中の文字が重なっている」と毎回さわがれてしまう
     （sweep.py が 8 件出した。第11回）。 */
  return { w: w, h: h };
}

function bubble(ctx, text, x, y, opt) {
  opt = opt || {};
  var up = !!opt.up;
  ctx.save();
  ctx.font = 'bold ' + (opt.size || 14) + 'px ' + FONT;
  var w = ctx.measureText(text).width + 18, h = (opt.size || 14) + 14;
  /* opt.dx … しっぽの先はそのままで、箱だけ横にずらす（まわりの文字を避けるため） */
  var bx = x - w / 2 + (opt.dx || 0), by = up ? y + 8 : y - h;
  /* 画面からはみ出さないように、箱だけ横にずらす（しっぽの先は動かさない） */
  if (CVW > 0) bx = clamp(bx, 3, Math.max(3, CVW - w - 3));
  var tipX = clamp(x, bx + 10, bx + w - 10);
  var edge = up ? by : by + h;                    /* しっぽの根もとの高さ */
  var tipY = up ? by - 8 : by + h + 8;
  ctx.fillStyle = opt.bg || '#fff5d6';
  ctx.strokeStyle = opt.border || '#d9a545';
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(bx, by, w, h, 7);
  else ctx.rect(bx, by, w, h);
  ctx.fill(); ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(tipX - 6, edge); ctx.lineTo(tipX, tipY); ctx.lineTo(tipX + 6, edge);
  ctx.closePath(); ctx.fillStyle = opt.bg || '#fff5d6'; ctx.fill();
  ctx.strokeStyle = opt.border || '#d9a545';
  ctx.beginPath(); ctx.moveTo(tipX - 6, edge); ctx.lineTo(tipX, tipY); ctx.lineTo(tipX + 6, edge); ctx.stroke();
  ctx.fillStyle = opt.color || '#8a5000';
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText(text, bx + w / 2, by + h / 2);
  ctx.restore();
  /* 吹きだしの場所も「文字の箱」として記録する（点のエネルギーの吹きだしが避けられるように） */
  noteBox(_txtBox, bx, by, w, h);
  if (typeof window !== 'undefined' && window.__labelLog) {
    window.__labelLog.push({ cv: CVID, text: '吹:' + text, x: bx, y: by + h / 2, w: w, h: h });
  }
}

/* つる巻きばね。(x1,y1)＝固定はし、(x2,y2)＝物体につくはし。
   opt = { coils（コイルの数）, r（コイルの半径 px）, color, lw, lead（両はしのまっすぐな部分 px） } */
/* 指差しマーク（「ここをクリックしてね」の合図）。(x,y)＝指の先。
   人さし指を上に立てた手を、少し右下から出す形。 */
function pointerIcon(ctx, x, y, sc) {
  sc = sc || 1;
  var INK = '#1b1f24', SKIN = '#ffffff';
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(sc, sc);
  ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  ctx.beginPath();
  /* 人さし指 */
  ctx.moveTo(0, 0);
  ctx.lineTo(-3.4, 3.2);
  ctx.lineTo(-3.4, 10);
  /* 手のひら（にぎった指のふくらみ） */
  ctx.quadraticCurveTo(-3.4, 13, -1.2, 13.6);
  ctx.lineTo(7.4, 13.6);
  ctx.quadraticCurveTo(10.2, 13.6, 10.2, 10.8);
  ctx.lineTo(10.2, 7.2);
  ctx.quadraticCurveTo(10.2, 5.2, 8.2, 5.2);
  ctx.lineTo(2.6, 5.2);
  ctx.quadraticCurveTo(3.4, 3.4, 3.4, 0.6);
  ctx.quadraticCurveTo(3.4, -1.6, 1.7, -1.6);
  ctx.quadraticCurveTo(0, -1.6, 0, 0);
  ctx.closePath();
  ctx.fillStyle = SKIN; ctx.fill();
  ctx.strokeStyle = INK; ctx.lineWidth = 1.5; ctx.stroke();
  /* にぎった指の線 */
  ctx.strokeStyle = INK; ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(4.6, 5.2); ctx.lineTo(4.6, 13.6);
  ctx.moveTo(7.0, 5.4); ctx.lineTo(7.0, 13.6);
  ctx.stroke();
  ctx.restore();
}

/* ジェットコースターの車（人が1人乗っている）。
   (x,y)＝車体の中心。ang＝進む向きの角度[rad]（0＝右へ水平、正で反時計まわり）。
   ループの中では上下がひっくり返るので、そのまま回して描く。 */
function coasterCar(ctx, x, y, ang, sc) {
  sc = sc || 1;
  var w = 26 * sc, h = 18 * sc;
  noteObj(x - w * 0.8, y - h * 1.3, w * 1.6, h * 2.6);
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(-ang);
  /* 車体 */
  ctx.fillStyle = '#e8eef5'; ctx.strokeStyle = '#4a5560'; ctx.lineWidth = 1.6;
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(-w / 2, -h / 2, w, h, 4);
  else ctx.rect(-w / 2, -h / 2, w, h);
  ctx.fill(); ctx.stroke();
  /* 前のへり（進む向きを分かりやすく） */
  ctx.beginPath();
  ctx.moveTo(w / 2 - 5, -h / 2); ctx.lineTo(w / 2, 0); ctx.lineTo(w / 2 - 5, h / 2);
  ctx.stroke();
  /* 車輪 */
  ctx.fillStyle = '#4a5560';
  ctx.beginPath(); ctx.arc(-w * 0.26, h / 2 + 2.6, 2.8, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc(w * 0.26, h / 2 + 2.6, 2.8, 0, Math.PI * 2); ctx.fill();
  /* 乗っている人（頭と体） */
  ctx.strokeStyle = '#4a5560'; ctx.lineWidth = 1.5;
  ctx.fillStyle = '#ffffff';
  ctx.beginPath(); ctx.arc(0, -h / 2 - 4.4, 3.4, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(0, -h / 2 - 1); ctx.lineTo(0, -h / 2 + 3); ctx.stroke();
  ctx.restore();
}

function spring(ctx, x1, y1, x2, y2, opt) {
  opt = opt || {};
  var col = opt.color || COL.hand, lw = opt.lw || 2.0;
  var lead = opt.lead === undefined ? 8 : opt.lead;
  var n = opt.coils || 9, r = opt.r || 8;
  var dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy);
  ctx.save();
  ctx.strokeStyle = col; ctx.lineWidth = lw; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  if (L < 2) { ctx.restore(); return; }
  var ux = dx / L, uy = dy / L, px = -uy, py = ux;
  var body = Math.max(6, L - lead * 2);
  /* 吹きだしがばねの上に乗らないように、ばねの場所を「物体」として記録する */
  noteObj(Math.min(x1, x2) - Math.abs(py) * r - 2, Math.min(y1, y2) - Math.abs(px) * r - 2,
    Math.abs(dx) + 2 * Math.abs(py) * r + 4, Math.abs(dy) + 2 * Math.abs(px) * r + 4);
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x1 + ux * lead, y1 + uy * lead);
  var N = n * 2, i;
  for (i = 1; i <= N; i++) {
    var f = i / N, s = lead + body * (i - 0.5) / N;
    var side = (i % 2 === 0) ? -1 : 1;
    var rr = r * (1 - 0.12 * Math.abs(Math.cos(Math.PI * f)));   /* はしを少しすぼめる */
    ctx.lineTo(x1 + ux * s + px * side * rr, y1 + uy * s + py * side * rr);
  }
  ctx.lineTo(x1 + ux * (lead + body), y1 + uy * (lead + body));
  ctx.lineTo(x2, y2);
  ctx.stroke();
  ctx.restore();
}

/* 世界座標（y 上向き）→ 画面座標。等方スケールで box を pad の内側に収める */
function mkView(W, H, pad, box) {
  var w = W - pad.l - pad.r, h = H - pad.t - pad.b;
  var bw = Math.max(1e-6, box.x1 - box.x0), bh = Math.max(1e-6, box.y1 - box.y0);
  var s = Math.min(w / bw, h / bh);
  var cx = (box.x0 + box.x1) / 2, cy = (box.y0 + box.y1) / 2;
  var ox = pad.l + w / 2, oy = pad.t + h / 2;
  return {
    s: s,
    X: function (x) { return ox + (x - cx) * s; },
    Y: function (y) { return oy - (y - cy) * s; },
    invX: function (px) { return cx + (px - ox) / s; },
    invY: function (py) { return cy - (py - oy) / s; }
  };
}

/* 「きり」のよい目盛り間隔 */
function niceStep(range, target) {
  var raw = range / Math.max(1, target);
  var p = Math.pow(10, Math.floor(Math.log(raw) / Math.LN10));
  var c = [1, 2, 2.5, 5, 10];
  for (var i = 0; i < c.length; i++) if (raw <= c[i] * p * 1.0001) return c[i] * p;
  return 10 * p;
}

/* 0 を必ず含み、きりのよい端で切った範囲にする（グラフの原点を画面に入れるため） */
function niceRange(lo, hi) {
  var a = Math.min(0, lo), b = Math.max(0, hi);
  if (b - a < 1e-9) { a -= 1; b += 1; }
  var pad = (b - a) * 0.14;
  a -= (lo < -1e-9 ? pad : pad * 0.35);
  b += (hi > 1e-9 ? pad : pad * 0.35);
  var st = niceStep(b - a, 5);
  a = Math.floor(a / st) * st;
  b = Math.ceil(b / st) * st;
  if (b - a < st * 1.5) b = a + st * 2;
  return { lo: a, hi: b };
}

/* ===== 軸の共通スタイル（1-3 の y 軸をベースに全シムでそろえる） =====
   ・軸は細い実線、正の向きの端に太めの矢じり
   ・目盛りは短い線＋数値（等幅っぽい小さめの字）
   ・原点は ● と大きめの「O」で強調
*/
var AX = { tick: 4.5, num: 11, name: 12.5, head: 13, col: '#5b6672' };

/* 原点の強調 */
function originMark(ctx, px, py, ox, oy) {
  ctx.save();
  ctx.fillStyle = AX.col;
  ctx.beginPath(); ctx.arc(px, py, 3.4, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
  label(ctx, 'O', px + (ox === undefined ? -13 : ox), py + (oy === undefined ? 13 : oy),
    { size: AX.name + 2, bold: true, color: AX.col });
}

/* 軸を1本ひく（すべての図で共通）。
   P(値)→{x,y} 画面座標、nrm＝目盛りの数字を置く向き（単位ベクトル）、
   sign>0 で「値が増える向き」が正。opt.numDec で小数桁を固定できる。 */
function axisLine(ctx, P, lo, hi, nrm, name, sign, opt) {
  opt = opt || {};
  var s = opt.step || niceStep(hi - lo, opt.target || 5);
  var pLo = P(lo), pHi = P(hi), i;
  var dx = pHi.x - pLo.x, dy = pHi.y - pLo.y, L = Math.hypot(dx, dy);
  if (L < 2) return;
  var ux = dx / L, uy = dy / L;                       /* 値が増える向き（画面） */
  ctx.save();
  ctx.strokeStyle = AX.col; ctx.lineWidth = 1.4;
  ctx.beginPath(); ctx.moveTo(pLo.x, pLo.y); ctx.lineTo(pHi.x, pHi.y); ctx.stroke();
  ctx.restore();
  var sg = sign >= 0 ? 1 : -1;
  var tip = sg > 0 ? pHi : pLo;
  var tx = ux * sg, ty = uy * sg;
  arrowHead(ctx, tip.x + tx * AX.head, tip.y + ty * AX.head, tx, ty, AX.col);
  /* 目盛り幅にあわせた小数けた数（0.05 きざみを 1 けたで書くと「0.1・0.1・0.2」と重なる） */
  var dec = opt.numDec !== undefined ? opt.numDec
    : (s >= 1 ? 0 : (s >= 0.1 ? 1 : (s >= 0.01 ? 2 : 3)));
  for (i = Math.ceil(lo / s) * s; i <= hi + 1e-9; i += s) {
    if (Math.abs(i) < 1e-9) continue;
    var p = P(i);
    ctx.save(); ctx.strokeStyle = AX.col; ctx.lineWidth = 1.1;
    ctx.beginPath();
    ctx.moveTo(p.x - nrm.x * AX.tick, p.y - nrm.y * AX.tick);
    ctx.lineTo(p.x + nrm.x * AX.tick, p.y + nrm.y * AX.tick);
    ctx.stroke(); ctx.restore();
    if (!opt.noNum) label(ctx, fmt(i * sg, dec), p.x + nrm.x * 13, p.y + nrm.y * 13,
      { size: AX.num, color: AX.col, align: nrm.x < -0.5 ? 'right' : (nrm.x > 0.5 ? 'left' : 'center') });
  }
  if (name) {
    var nx = tip.x + tx * (AX.head + 8) - nrm.x * 12;
    var ny = tip.y + ty * (AX.head + 8) - nrm.y * 12;
    label(ctx, name, nx, ny, { size: AX.name, color: AX.col });
  }
}

/* 横軸。X(値)→px、ypx＝軸の高さ。sign>0 で右が正 */
function axisX(ctx, X, ypx, lo, hi, name, sign, opt) {
  axisLine(ctx, function (v) { return { x: X(v), y: ypx }; }, lo, hi, { x: 0, y: 1 }, name, sign, opt);
}

/* 縦軸。Y(値)→px、xpx＝軸の横位置。sign>0 で「値が増える向き」が正 */
function axisY(ctx, Y, xpx, lo, hi, name, sign, opt) {
  axisLine(ctx, function (v) { return { x: xpx, y: Y(v) }; }, lo, hi, { x: -1, y: 0 }, name, sign, opt);
}

/* 矢じりだけ描く（軸の先） */
function arrowHead(ctx, x, y, ux, uy, color) {
  var h = AX.head, w = h * 0.42;
  ctx.save();
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.lineTo(x - ux * h - uy * w, y - uy * h + ux * w);
  ctx.lineTo(x - ux * h + uy * w, y - uy * h - ux * w);
  ctx.closePath(); ctx.fill();
  ctx.restore();
}

/* 世界座標の x,y 軸（うすい格子つき）を、共通スタイルで描く */
function worldAxes(ctx, vw, box, xlabel, ylabel, signY) {
  var x0 = vw.X(box.x0), x1 = vw.X(box.x1), y0 = vw.Y(box.y0), y1 = vw.Y(box.y1);
  var sx = niceStep(box.x1 - box.x0, 6), sy = niceStep(box.y1 - box.y0, 5), i;
  ctx.save();
  ctx.strokeStyle = COL.grid; ctx.lineWidth = 1;
  for (i = Math.ceil(box.x0 / sx) * sx; i <= box.x1 + 1e-9; i += sx) {
    ctx.beginPath(); ctx.moveTo(vw.X(i), y1); ctx.lineTo(vw.X(i), y0); ctx.stroke();
  }
  for (i = Math.ceil(box.y0 / sy) * sy; i <= box.y1 + 1e-9; i += sy) {
    ctx.beginPath(); ctx.moveTo(x0, vw.Y(i)); ctx.lineTo(x1, vw.Y(i)); ctx.stroke();
  }
  ctx.restore();
  var ax = vw.Y(0), ay = vw.X(0);
  var hasY0 = (box.y0 <= 0 && box.y1 >= 0), hasX0 = (box.x0 <= 0 && box.x1 >= 0);
  if (hasY0) axisX(ctx, vw.X, ax, box.x0, box.x1 - sx * 0.35, xlabel, 1);
  if (hasX0) axisY(ctx, vw.Y, ay, box.y0, box.y1 - sy * 0.35, ylabel, signY === undefined ? 1 : signY);
  if (hasY0 && hasX0) originMark(ctx, ay, ax);
}

/* ===== 折れ線グラフ ===== */
/* spec: {xlabel,ylabel,xmin,xmax,ymin,ymax,series:[{color,dash,pts,name}],cursors:[{color,x,y}],zeroNote} */
function plot(cv, spec) {
  var W = 320, H = spec.H || 174;
  var ctx = prep(cv, W, H);
  var pad = { l: 46, r: 16, t: 20, b: 26 };
  var gw = W - pad.l - pad.r, gh = H - pad.t - pad.b;
  var xmin = spec.xmin, xmax = spec.xmax, ymin = spec.ymin, ymax = spec.ymax;
  if (spec.view) { xmin = spec.view.xmin; xmax = spec.view.xmax; ymin = spec.view.ymin; ymax = spec.view.ymax; }
  if (ymax - ymin < 1e-6) { ymax += 0.5; ymin -= 0.5; }
  /* ドラッグ操作のために、いまの対応づけを canvas に覚えさせる */
  cv._map = { W: W, H: H, pad: pad, gw: gw, gh: gh, xmin: xmin, xmax: xmax, ymin: ymin, ymax: ymax, xstep: 0 };
  function X(x) { return pad.l + gw * (x - xmin) / (xmax - xmin || 1); }
  function Y(y) { return pad.t + gh * (ymax - y) / (ymax - ymin || 1); }

  ctx.save();
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, W, H);
  /* 目盛りグリッド */
  /* spec.xstep があればそれを使う（運動の長さから決めた目盛り幅。右端を切り上げても
     目盛りが粗くならないようにするため）。ドラッグで範囲を変えたときは計算し直す。 */
  var sx = (!spec.view && spec.xstep) ? spec.xstep : niceStep(xmax - xmin, 5);
  var sy = niceStep(ymax - ymin, 4), i;
  cv._map.xstep = sx;      /* 実際に描いた目盛り幅（テストで確認するため） */
  ctx.strokeStyle = COL.grid; ctx.lineWidth = 1;
  for (i = Math.ceil(xmin / sx) * sx; i <= xmax + 1e-9; i += sx) {
    ctx.beginPath(); ctx.moveTo(X(i), pad.t); ctx.lineTo(X(i), pad.t + gh); ctx.stroke();
  }
  for (i = Math.ceil(ymin / sy) * sy; i <= ymax + 1e-9; i += sy) {
    ctx.beginPath(); ctx.moveTo(pad.l, Y(i)); ctx.lineTo(pad.l + gw, Y(i)); ctx.stroke();
  }
  ctx.restore();

  /* 軸（本体の図と同じ書き方にそろえる。グラフは小さいので字だけ少し小さく） */
  var axSave = { tick: AX.tick, num: AX.num, name: AX.name, head: AX.head };
  AX.tick = 3.5; AX.num = 9.5; AX.name = 11; AX.head = 10;
  var hasY0 = (ymin <= 0 && ymax >= 0), hasX0 = (xmin <= 0 && xmax >= 0);
  var yz = hasY0 ? Y(0) : pad.t + gh;
  var xz = hasX0 ? X(0) : pad.l;
  /* 横軸はグラフの右端までいっぱいに引く（手前で切ると、運動の終わりの時刻に
     目盛りが届かず「どこまで動いたのか」が読めなくなる）。目盛りの間隔はグリッドとそろえる。 */
  axisX(ctx, X, yz, xmin, xmax, spec.xlabel || '', 1, { step: sx });
  axisY(ctx, Y, xz, ymin, ymax - sy * 0.3, spec.ylabel || '', 1);
  if (hasY0 && hasX0) originMark(ctx, xz, yz, -10, 11);
  AX.tick = axSave.tick; AX.num = axSave.num; AX.name = axSave.name; AX.head = axSave.head;
  if (spec.note) label(ctx, spec.note, W - 6, 9, { size: 9.5, color: COL.sub, align: 'right' });

  ctx.save();
  ctx.beginPath(); ctx.rect(pad.l - 1, pad.t - 1, gw + 2, gh + 2); ctx.clip();
  (spec.hide ? [] : (spec.series || [])).forEach(function (se) {
    if (!se.pts || se.pts.length < 2) return;
    /* se.fillTo: 「はじめの E」の高さに、うすい横線を1本だけ引く。
       ★グラフの中はグレーに塗らない★（先生の指示・第7回）
       図のエネルギーの棒でも「失われた分」をグレーで塗っているので、
       グラフの中まで塗ると、どちらのグレーの話か分からなくなる。
       E の線が下がっていくこと自体が「減った」ことを表すので、塗らなくても伝わる。 */
    if (se.fillTo !== undefined && isFinite(se.fillTo)) {
      var y0 = Y(se.fillTo);
      ctx.save();
      ctx.strokeStyle = fade(COL.areaNeg, 0.75); ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
      ctx.beginPath(); ctx.moveTo(X(se.pts[0][0]), y0);
      ctx.lineTo(X(se.pts[se.pts.length - 1][0]), y0); ctx.stroke();
      ctx.restore();
    }
    /* se.area: 曲線と t 軸ではさまれた部分を塗る（面積＝変化量、を目で見せるため）。
       t 軸より上と下を別々にクリップして塗り、正と負を見分けられるようにする。 */
    if (se.area) {
      var yz = Y(0), k;
      var poly = function () {
        ctx.beginPath();
        ctx.moveTo(X(se.pts[0][0]), yz);
        for (k = 0; k < se.pts.length; k++) {
          if (isFinite(se.pts[k][0]) && isFinite(se.pts[k][1])) ctx.lineTo(X(se.pts[k][0]), Y(se.pts[k][1]));
        }
        ctx.lineTo(X(se.pts[se.pts.length - 1][0]), yz);
        ctx.closePath();
      };
      ctx.save();
      ctx.beginPath(); ctx.rect(pad.l - 1, pad.t - 1, gw + 2, Math.max(0, yz - pad.t + 1)); ctx.clip();
      ctx.fillStyle = fade(se.color, 0.20); poly(); ctx.fill();
      ctx.restore();
      ctx.save();
      ctx.beginPath(); ctx.rect(pad.l - 1, yz, gw + 2, Math.max(0, pad.t + gh - yz + 1)); ctx.clip();
      /* 負の面積は色を変える（正＝グラフの色／負＝ニュートラルなグレー） */
      ctx.fillStyle = fade(COL.areaNeg, 0.30); poly(); ctx.fill();
      ctx.strokeStyle = fade(COL.areaNeg, 0.60); ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
      poly(); ctx.stroke();
      ctx.restore();
    }
    ctx.save();
    ctx.strokeStyle = se.color; ctx.lineWidth = se.width || 2.2;
    if (se.dash) ctx.setLineDash(se.dash);
    ctx.beginPath();
    var started = false;
    for (var j = 0; j < se.pts.length; j++) {
      var p = se.pts[j];
      if (!isFinite(p[0]) || !isFinite(p[1])) { started = false; continue; }
      var px = X(p[0]), py = Y(p[1]);
      if (!started) { ctx.moveTo(px, py); started = true; } else ctx.lineTo(px, py);
    }
    ctx.stroke();
    ctx.restore();
  });

  (spec.hide ? [] : (spec.cursors || [])).forEach(function (c) {
    if (!isFinite(c.x) || !isFinite(c.y)) return;
    ctx.save();
    ctx.fillStyle = c.color; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.6;
    ctx.beginPath(); ctx.arc(X(c.x), Y(c.y), 4.6, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.restore();
  });
  ctx.restore();   /* clip 解除 */

  /* 凡例は「右上」に置く（左上に置くと、左で大きくなる曲線が白い箱にかくれる） */
  if (spec.legend && !spec.hide) {
    var lw = 0;
    ctx.save(); ctx.font = '10px ' + FONT;
    spec.legend.forEach(function (lg) { lw = Math.max(lw, ctx.measureText(lg.name).width); });
    ctx.restore();
    /* x 軸（y = 0 の線）がグラフの上のほうに来ると、目盛りの数字と凡例がぶつかる。
       そのときは凡例を下にずらす（2-3 のように U が大きく負になるシム）。 */
    var legTop = !(hasY0 && (yz - pad.t) < gh * 0.45);
    var lx = pad.l + gw - (lw + 22);
    var ly = legTop ? (pad.t + 8) : (pad.t + gh - spec.legend.length * 13 + 2);
    ctx.save();
    ctx.fillStyle = 'rgba(255,255,255,.88)';
    ctx.fillRect(lx - 4, ly - 8, lw + 28, spec.legend.length * 13 + 4);
    ctx.restore();
    spec.legend.forEach(function (lg, k) {
      ctx.save();
      ctx.strokeStyle = lg.color; ctx.lineWidth = lg.width || 2.4;
      if (lg.dash) ctx.setLineDash(lg.dash);
      ctx.beginPath(); ctx.moveTo(lx, ly + k * 13); ctx.lineTo(lx + 16, ly + k * 13); ctx.stroke();
      ctx.restore();
      label(ctx, lg.name, lx + 20, ly + k * 13, { size: 10, color: COL.sub, align: 'left', clamp: false });
    });
  }
}
```

## src/45_defs.js

```js
/* シミュレーションの登録表と、このページ共通の決めごと・描画部品。
   各モードのファイルが DEFS に自分を足していく。 */
'use strict';
var DEFS = {};
var MODES = [
  { n: 1, label: '1　非保存力が仕事をしないケース（力学的エネルギーが保存される）',
    tip: '重力や弾性力（＝<b>保存力</b>）だけが仕事をしています。垂直抗力や糸の張力は運動の向きに垂直なので仕事をしません。だから <b>E = K + U は一定</b>。',
    ids: ['m1-1', 'm1-2', 'm1-3', 'm1-4', 'm1-5', 'm1-6', 'm1-7', 'm1-8', 'm1-9', 'm1-10',
      'm1-11', 'm1-12', 'm1-13'] },
  { n: 2, label: '2　非保存力が仕事をするケース（力学的エネルギーが保存されない）',
    tip: '摩擦力や手の力（＝<b>非保存力</b>）が仕事をしたら？',
    ids: ['m2-1', 'm2-2', 'm2-3', 'm2-4', 'm2-5'] }
];

/* ===== 文字まわりの共通ルール ===== */

/* 「$…$」を KaTeX で組む span に変える（添え字をきれいに出すため）。
   $…$ を書いた文字列は、必ずこれを通すこと（通し忘れると生の $ が画面に出る）。 */
function mathHtml(str) {
  var out = '', i = 0;
  str = String(str);
  while (i < str.length) {
    var a = str.indexOf('$', i);
    if (a === -1) { out += str.slice(i); break; }
    out += str.slice(i, a);
    var b = str.indexOf('$', a + 1);
    if (b === -1) { out += str.slice(a); break; }
    out += '<span class="tex">' + escTex(str.slice(a + 1, b)) + '</span>';
    i = b + 1;
  }
  return out;
}

/* KaTeX に渡す式の中の & < > を実体参照にする（innerHTML に入れる前に必ず通す）。
   通さないと「$K<U$」の < 以降がタグと見なされて文が消える。 */
function escTex(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

/* 図の中の「ヒントになる言葉」（答えにつながる説明）を出してよいか。
   ・スタートを押して動き出してから出す（先に答えを見せない）
   ・軸名・時刻・力や速さの値・物の名前・操作の説明は、これで囲まなくてよい */
function hintOn(s, t) { return t > 1e-9; }

/* 「運動が終わったか」。吹きだしと「2点をくらべる式」はこれで囲む。 */
function endOn(d, s, t) { return t >= d.tEnd(V(s)) - 1e-6; }

/* 同じ文字を書き直さない（毎フレームの DOM 書きこみを減らす） */
function setText(el, txt) { if (el && el.textContent !== txt) el.textContent = txt; }
function setCls(el, cls) { if (el && el.className !== cls) el.className = cls; }

/* 質量 m に応じて物体の「見た目の大きさ」を変える倍率（basics と同じ決めごと） */
function mSize(d, v) {
  if (!d || !v || typeof v.m !== 'number' || !(v.m > 0)) return 1;
  var vs = d.vars || [], md = null, i;
  for (i = 0; i < vs.length; i++) if (vs[i].k === 'm') md = vs[i];
  if (!md) return 1;
  var ref = md.def;
  if (!(ref > 0)) return 1;
  return clamp(Math.pow(v.m / ref, 1 / 3), 0.78, 1.45);
}

/* KaTeX の式を、canvas に書ける「ふつうの文字」に直す。
   canvas は KaTeX を組めないので、ステップ図の表などはこれを通すこと
   （通さないと画面に \tfrac{1}{2}mv^2 と生の LaTeX が出る）。 */
function texPlain(s) {
  return String(s)
    .replace(/\\tfrac\{1\}\{2\}/g, '½').replace(/\\frac\{1\}\{2\}/g, '½')
    .replace(/\^\{\\,2\}/g, '²').replace(/\^\{2\}/g, '²').replace(/\^2/g, '²')
    .replace(/_\{0\}/g, '₀').replace(/_0/g, '₀')
    .replace(/\\cos/g, 'cos').replace(/\\sin/g, 'sin')
    .replace(/\\theta/g, 'θ').replace(/\\mu/g, 'μ')
    .replace(/\^\{?\\circ\}?/g, '°').replace(/\\circ/g, '°')
    .replace(/\\text\{([^}]*)\}/g, '$1')
    .replace(/\\,/g, '').replace(/\\;/g, ' ')
    /* 添字の中かっこは残す（label が _{…} を小さい字で描くため）。
       いったん見えない印に置きかえて、ほかの { } を消してから、もどす。 */
    .replace(/_\{([^}]*)\}/g, '\u0001$1\u0002')
    .replace(/[{}]/g, '')
    .replace(/\u0001/g, '_{').replace(/\u0002/g, '}');
}

/* ===== エネルギーの表示の決めごと ===== */
var EJ = ' J';
/* エネルギーの数値。★1000 J 以上は小数点以下を出さない★
   （1-7 ジェットコースターのように質量が 100 kg 台のシムでは、
     19600.00 J のような表示が長すぎて表からはみ出す。）
   エネルギーの数値を書くところは、必ずこの関数を通すこと。 */
function fmtE(x) { return fmt(x, Math.abs(x) >= 1000 ? 0 : 2); }
function fmtJ(x, d) { return (d === undefined ? fmtE(x) : fmt(x, d)) + EJ; }

/* いまのシムで「保存力だけが仕事をしているか」 */
function consOf(d, v) { return (typeof d.cons === 'function') ? !!d.cons(v) : (d.cons !== false); }

/* くらべる点（pts）を、いまの変数で時刻つきにして返す */
function ptsOf(d, v) {
  return (d.pts || []).map(function (p) {
    var t = (typeof p.t === 'function') ? p.t(v) : p.t;
    return { name: p.name, jp: p.jp, t: t, sym: p.sym || {}, hsym: p.hsym,
      m: d.sample(v, t) };
  });
}

/* 点の記号（K と U）。立式を作るところは、すべてこの2つを通す。 */
function symK(p) { return p.sym.K || '0'; }
function symU(p) {
  var g = p.sym.Ug || '0', s = p.sym.Us;
  return (s === undefined || s === null) ? g : (g === '0' ? s : (s === '0' ? g : g + ' + ' + s));
}
function numE(p) { return fmtE(p.m.E); }
function numKU(p) { return fmtE(p.m.K) + ' + ' + fmtE(p.m.U); }
/* 数値をたし算の中に置く（負の数はかっこでくくる） */
function numTerm(x) { var s = fmtE(x); return (x < 0) ? '(' + s + ')' : s; }

/* =========================================================
   図の下の「立式」3つ（★先生の指示・第4回★）
   ① 力学的エネルギー保存則
   ② 力学的エネルギー変化量（後－前）と非保存力の仕事の関係
   ③ 運動エネルギー変化量（後－前）と仕事の関係
   ①は保存の成否で ○ / ✕、②③は<b>いつでもなりたつ</b>ので必ず ○。
   ★式の名前は先生の指示（第6回）。「変化量（後－前）」を必ず入れること。★
   ========================================================= */
function eqSections(d, v, jj) {
  var ps = ptsOf(d, v);
  if (ps.length < 2) return [];
  var A = ps[0], B = ps[pairJ(d, v, jj)], ok = consOf(d, v);
  var wName = d.wName || '非保存力';
  var out = [];

  /* ① 力学的エネルギー保存則 */
  out.push({
    key: 'cons', title: '力学的エネルギー保存則', ok: ok,
    badge: ok ? '○ 成り立つ' : '✕ 成り立たない',
    sub: '非保存力の仕事がなければなりたつ',
    sym: ok
      ? '\\underbrace{' + symK(A) + '}_{K_{' + A.name + '}} + \\underbrace{' + symU(A) +
        '}_{U_{' + A.name + '}} \\;=\\; \\underbrace{' + symK(B) + '}_{K_{' + B.name +
        '}} + \\underbrace{' + symU(B) + '}_{U_{' + B.name + '}}'
      : 'K_{' + A.name + '} + U_{' + A.name + '} \\;=\\; K_{' + B.name + '} + U_{' + B.name +
        '} \\quad(E = \\text{一定})',
    num: ok ? numKU(A) + ' \\;=\\; ' + numKU(B) + ' \\quad(\\mathrm{J})'
      : numKU(A) + ' = ' + numE(A) + ' \\;\\ne\\; ' + numE(B) + ' = ' + numKU(B),
    note: ok ? '保存力だけが仕事をしているので、$E$ はどこでも同じ。'
      : wName + 'が仕事をしているので、<b>$E$ は保存しない</b>。下の②を使う。'
  });

  /* ② 力学的エネルギーと非保存力の仕事の関係（いつでも成り立つ） */
  out.push({
    key: 'rel', title: '力学的エネルギー変化量（後－前）と非保存力の仕事の関係',
    ok: true, badge: '○ 成り立つ',
    sub: 'いつでもなりたつ',
    sym: 'E_{' + B.name + '} - E_{' + A.name + '} = (' + symK(B) + ') + (' + symU(B) +
      ') - \\{(' + symK(A) + ') + (' + symU(A) + ')\\} = ' +
      (ok ? '0' : (d.wSym || 'W_{\\text{非保存}}')),
    num: numE(B) + ' - ' + numE(A) + ' = ' + fmtE(B.m.E - A.m.E) + '\\ \\mathrm{J}',
    note: ok ? '非保存力が仕事をしていないので $W_{\\text{非保存}}=0$。だから $E_2=E_1$（＝①の保存則）。'
      : wName + 'が <b>' + fmtJ(B.m.W - A.m.W) + '</b> の仕事をしたので、その分だけ $E$ が変わった。'
  });

  /* ③ 運動エネルギーと仕事の関係（保存力の仕事も入れて合計する） */
  var fs = forcesOf(d, v, jj), i, symR = [], numR = [], tot = 0;
  for (i = 0; i < fs.length; i++) {
    symR.push('W_{\\text{' + fs[i].name + '}}');
    numR.push(numTerm(fs[i].W));
    tot += fs[i].W;
  }
  out.push({
    key: 'wk', title: '運動エネルギー変化量（後－前）と仕事の関係', ok: true, badge: '○ 成り立つ',
    sub: 'いつでもなりたつ',
    sym: 'K_{' + B.name + '} - K_{' + A.name + '} = ' +
      (symR.length ? symR.join(' + ') : 'W_{\\text{すべての力}}'),
    num: fmtE(B.m.K) + ' - ' + fmtE(A.m.K) + ' = ' +
      (numR.length ? numR.join(' + ') + ' = ' : '') + fmtE(tot) + '\\ \\mathrm{J}',
    note: '左辺は<b>運動エネルギー変化量のみ</b>。右辺の仕事は<b>非保存力の仕事＋保存力の仕事</b>。' +
      '右上の「仕事の分析」モードにすると、それぞれの力の仕事を1つずつ確かめられる。'
  });
  return out;
}

/* =========================================================
   力ごとの仕事（「仕事を表示」と「運動エネルギーと仕事の関係」は、ここ1か所から作る）
   d.forces に、その図ではたらく力を並べる。よくある力は名前だけでよい。
     forces: ['g', 'N', 'fr']
     forces: ['g', { key: 'pull', name: '糸の力', sym: 'F', color: COL.hand,
                     w: function (v, A, B) { … }, wsym: '…', why: '…' }]
   w(v, A, B) … 点 A から点 B までにその力がした仕事 [J]（書かなければ下の既定）。
   ★合計は必ず K_B − K_A に一致する★（90_boot.js の work_sum_err で確かめている）
   ========================================================= */
var FORCE_LIB = {
  g: { name: '重力', sym: 'mg', color: COL.force,
    w: function (v, A, B) { return A.m.Ug - B.m.Ug; },
    wsym: 'W_{\\text{重力}} = U_{g1} - U_{g2} = -mg(h_2 - h_1)',
    why: '重力は<b>保存力</b>。下がれば正、上がれば負の仕事になる。' },
  N: { name: '垂直抗力', sym: 'N', color: COL.norm,
    w: function () { return 0; },
    wsym: 'W_N = N\\,L\\cos 90^\\circ = 0',
    why: '垂直抗力は<b>いつも運動の向きと垂直</b>なので、仕事は 0。' },
  T: { name: '糸の張力', sym: 'S', color: COL.hand,
    w: function () { return 0; },
    wsym: 'W_S = S\\,L\\cos 90^\\circ = 0',
    why: '糸の張力は<b>いつも運動の向きと垂直</b>（円の中心を向く）なので、仕事は 0。' },
  sp: { name: 'ばねの弾性力', sym: 'kx', color: COL.hand,
    w: function (v, A, B) { return A.m.Us - B.m.Us; },
    wsym: 'W_{\\text{弾性力}} = U_{s1} - U_{s2}',
    why: '弾性力は<b>保存力</b>。自然長にもどる向きへ動くときは正の仕事になる。' },
  fr: { name: '動摩擦力', sym: '\\mu\' N', color: COL.fric,
    w: function (v, A, B) { return B.m.W - A.m.W; },
    wsym: 'W_{\\text{摩擦}} = -\\mu\' N L',
    why: '動摩擦力は<b>非保存力</b>で、いつも運動と逆向き。だからいつも<b>負の仕事</b>。' },
  hand: { name: '手の力', sym: 'F_{\\text{手}}', color: COL.hand,
    w: function (v, A, B) { return B.m.W - A.m.W; },
    wsym: 'W_{\\text{手}} = \\sum F_{\\text{手}}\\,\\Delta x',
    why: '手の力は<b>非保存力</b>。向きと動く向きしだいで、正にも負にもなる。' }
};

/* くらべる2点の組（いつも A と、それより後ろの点）。jj は 2 つめの点の番号。 */
function pairsOf(d, v) {
  var ps = ptsOf(d, v), out = [], i;
  for (i = 1; i < ps.length; i++) {
    out.push({ j: i,
      name: ps[0].name + '点と' + ps[i].name + '点',      /* 立式の欄（左下）の書き方 */
      flow: ps[0].name + '点 → ' + ps[i].name + '点' });  /* 仕事の分析（右上）の書き方 */
  }
  return out;
}
function pairJ(d, v, jj) {
  var n = (d.pts || []).length;
  if (jj === undefined || jj === null || jj < 1 || jj > n - 1) return n - 1;
  return jj;
}

/* いまの設定で、各力がした仕事（点 A → 点 jj）を並べて返す */
function forcesOf(d, v, jj) {
  var ps = ptsOf(d, v), A = ps[0], B = ps[pairJ(d, v, jj)];
  return (d.forces || []).map(function (f) {
    var base = (typeof f === 'string') ? FORCE_LIB[f] : (FORCE_LIB[f.key] || {});
    var o = {}, k;
    for (k in base) o[k] = base[k];
    if (typeof f !== 'string') for (k in f) o[k] = f[k];
    o.key = (typeof f === 'string') ? f : f.key;
    o.W = o.w ? o.w(v, A, B) : 0;
    return o;
  });
}

/* その仕事が「正・負・0」のどれか（理由の文をそろえるため） */
function workSign(W) { return Math.abs(W) < 5e-3 ? 0 : (W > 0 ? 1 : -1); }
function workWhy(W) {
  var s = workSign(W);
  return s === 0 ? '力の向きと動く向きが<b>垂直</b>（または動いていない）なので、仕事は <b>0</b>。'
    : s > 0 ? '力の向きと動く向きが<b>同じ</b>ほうを向いているので、<b>正の仕事</b>。'
      : '力の向きと動く向きが<b>逆</b>を向いているので、<b>負の仕事</b>。';
}

/* ===== 図の中の共通部品 ===== */

/* 直方体のブロック（斜面の上など）。ang＝面の傾き(rad) */
function blockShape(ctx, cx, cy, ang, w, h, fill) {
  var rr = Math.max(w, h) / 2 * 1.05;
  noteObj(cx - rr, cy - rr, 2 * rr, 2 * rr);
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(-ang);
  ctx.fillStyle = fill || '#e8eef5';
  ctx.strokeStyle = '#2c3e50';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.rect(-w / 2, -h / 2, w, h);
  ctx.fill(); ctx.stroke();
  ctx.restore();
}

/* 地面（横一直線＋ハッチ） */
function ground(ctx, x1, x2, y) { hatchLine(ctx, x1, y, x2, y, 1); }

/* 基準面（位置エネルギーの h = 0 の線）。★どのシムでも必ず図に出す★ */
function datumLine(ctx, x1, x2, y, text, right, below) {
  ctx.save();
  ctx.strokeStyle = COL.eU; ctx.lineWidth = 1.4; ctx.setLineDash([7, 5]);
  ctx.beginPath(); ctx.moveTo(x1, y); ctx.lineTo(x2, y); ctx.stroke();
  ctx.restore();
  label(ctx, text || '基準面（h = 0）', right ? x2 - 3 : x1 + 3, y + (below ? 18 : -9),
    { size: 11, color: COL.eU, align: right ? 'right' : 'left' });
}

/* ★このページの決めごと★
   図の「ひとこと」（結論の言葉）は canvas の中に書かず、図のすぐ下の HTML の行に出す
   （d.hintFig）。canvas の中に置くと、下向きの重力の矢印のラベルと必ずぶつかるため。
   出すのはスタートを押してから（hintOn）。 */

/* 高さの寸法（基準面からの h）。破線の矢印＋数値。
   lead を渡すと、その x まで細い引き出し線を引く（寸法線を絵から離して置けるように）。
   高さがほとんど 0 のときは、文字だけ残ると意味が分からないので何も書かない。 */
function heightDim(ctx, x, yTop, yBase, text, lead, top) {
  if (Math.abs(yBase - yTop) < 7) return;
  if (lead !== undefined) {
    ctx.save();
    ctx.strokeStyle = fade(COL.dim, 0.35); ctx.lineWidth = 1; ctx.setLineDash([4, 4]);
    ctx.beginPath(); ctx.moveTo(x, yTop); ctx.lineTo(lead, yTop); ctx.stroke();
    ctx.restore();
  }
  arrow(ctx, x, yBase, x, yTop, 'dim');
  arrow(ctx, x, yTop, x, yBase, 'dim');
  if (top === true) label(ctx, text, x, yTop - 11, { size: 11.5, color: COL.dim });
  /* top に 'left' を渡すと、寸法線の「左」に数値を出す（左の列に寸法線を2本ならべるとき） */
  else if (top === 'left') label(ctx, text, x - 6, (yTop + yBase) / 2 - 10,
    { size: 11.5, align: 'right', color: COL.dim });
  /* まん中に置くと、ちょうど「つりあい」などの横線と重なることが多いので少し上にずらす */
  else label(ctx, text, x + 6, (yTop + yBase) / 2 - 10, { size: 11.5, align: 'left', color: COL.dim });
}

/* デコピン（はじく手）。1-1 と同じ出し方：はじいた直後だけ出して、すっと消す。
   ★吹きだしの しっぽは、かならず「手の真上」★（先生の指摘・第13回）
   前は呼び出しごとに好きな場所を渡していたので、1-4・1-7・1-8 では
   吹きだしが手から遠くはなれた所に浮いて、何を指しているのか分からなかった。
   いまは 手の場所 (cx, cy) から up [px] だけ上に しっぽの先を置く。
   箱が画面の外に出そうなときは bubble が箱だけ内側へ寄せる（しっぽの先は動かない）。 */
function flickStart(ctx, t, v0, cx, cy, ang, up, dx) {
  if (!(Math.abs(v0) > 0.05) || t >= 0.34) return;
  var dir = v0 > 0 ? 1 : -1;
  var k = clamp(t / 0.10, 0, 1);
  var a = (t <= 0.13) ? 1 : Math.max(0, 1 - (t - 0.13) / 0.18);
  if (a <= 0.02) return;
  flickHand(ctx, cx, cy, ang, k, dir, 0.42, a);
  ctx.save(); ctx.globalAlpha = a;
  bubble(ctx, 'デコピン！', cx, cy - (up || 48),
    { size: 12.5, dx: dx || 0, bg: '#fff5e8', border: '#e07b18', color: '#a85c0c' });
  ctx.restore();
}

/* ★「最高点（点B）」のような、点の名前の吹きだし★（先生の指示・第13回／第14回に2行へ）
   1-4・1-6・1-7・1-8・1-11・1-12・1-13・2-2 は「いちばん高い（低い）所」が見どころなので、
   運動が終わって各点のエネルギーを出すときに、その点のそばに小さく出す。
   ★2行で書く★ 1行目＝「最高点」「最下点」、2行目＝「（点B）」
   （どの点の話かを、式や表の記号とすぐ結びつけられるように。先生の指示・第14回）
   (x, y) は しっぽの先＝さす場所。
     up を渡さない … しっぽは下向き（▼）。箱はその上（＝最高点で使う）
     up = true     … しっぽは上向き（▲）。箱はその下（＝最下点で使う） */
function ptNote(ctx, px, py, title, sub, opt) {
  opt = opt || {};
  var s1 = 12, s2 = 11, padx = 11, pady = 7, gap = 2;
  ctx.save();
  ctx.font = 'bold ' + s1 + 'px ' + FONT;
  var w1 = ctx.measureText(title).width;
  ctx.font = s2 + 'px ' + FONT;
  var w2 = sub ? ctx.measureText(sub).width : 0;
  ctx.restore();
  var w = Math.max(w1, w2) + padx * 2;
  var h = pady * 2 + s1 + (sub ? gap + s2 : 0);
  var off = (opt.gap === undefined) ? 46 : opt.gap;
  /* ★上に入らなければ、下がわに出す★（第14回）
     入らないまま描くと、箱が画面の外へ出て、2行が同じ高さにつぶれてしまう
     （label が y < 9 でクランプするため。1-7 の v0 = 16 で実際に起きた）。 */
  var up = !!opt.below || (py - off - h < 4);
  var y = up ? py + off : py - off;
  var bx = px - w / 2 + (opt.dx || 0);      /* dx＝しっぽはそのまま、箱だけ横へ */
  var by = up ? y + 8 : y - h;
  if (CVW > 0) bx = clamp(bx, 3, Math.max(3, CVW - w - 3));
  if (CVH > 0) by = clamp(by, 3, Math.max(3, CVH - h - 3));
  var tipX = clamp(px, bx + 10, bx + w - 10);
  var edge = up ? by : by + h;
  var tipY = up ? by - 8 : by + h + 8;
  ctx.save();
  ctx.fillStyle = '#eef2f7';
  ctx.strokeStyle = COL.eE;
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(bx, by, w, h, 7); else ctx.rect(bx, by, w, h);
  ctx.fill(); ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(tipX - 6, edge); ctx.lineTo(tipX, tipY); ctx.lineTo(tipX + 6, edge);
  ctx.closePath(); ctx.fillStyle = '#eef2f7'; ctx.fill();
  ctx.strokeStyle = COL.eE;
  ctx.beginPath();
  ctx.moveTo(tipX - 6, edge); ctx.lineTo(tipX, tipY); ctx.lineTo(tipX + 6, edge); ctx.stroke();
  ctx.restore();
  label(ctx, title, bx + w / 2, by + pady + s1 / 2,
    { size: s1, bold: true, color: '#28323d', halo: false });
  if (sub) {
    label(ctx, sub, bx + w / 2, by + pady + s1 + gap + s2 / 2,
      { size: s2, color: '#5b6672', halo: false });
  }
  noteBox(_txtBox, bx, by, w, h);
  noteObj(bx, by, w, h);
}

/* ★図の上に出す「このシムで何をくらべるか」の帯★（先生の指示・第14回）
   2-4 は「止まるまで動かす → もう一度はじめから → 点 B で止まる」という
   ふつうと違う再生をするので、何と何をくらべているのかを図の中にことばで出す。
   横は「エネルギーの棒をのぞいた絵の幅」のまん中にそろえる。 */
function bannerNote(ctx, lines, y, opt) {
  opt = opt || {};
  /* ★第15回：小さくて読めないと言われたので、字を大きく（12 → 14 px）した。
     そのぶん1行に入らないので、行を配列で渡せるようにした。 */
  var sz = opt.size || 14, padx = 14, pady = 9, lead = 5;
  if (typeof lines === 'string') lines = [lines];
  ctx.save();
  ctx.font = sz + 'px ' + FONT;
  var wmax = 0, i;
  for (i = 0; i < lines.length; i++) wmax = Math.max(wmax, ctx.measureText(lines[i]).width);
  ctx.restore();
  var w = wmax + padx * 2;
  var h = pady * 2 + lines.length * sz + (lines.length - 1) * lead;
  var cxm = ((CVW > 0 ? CVW : 640) - 72) / 2;
  var x = clamp(cxm - w / 2, 3, Math.max(3, (CVW > 0 ? CVW : 640) - w - 3));
  ctx.save();
  ctx.fillStyle = opt.bg || '#eaf1f8';
  ctx.strokeStyle = opt.border || '#7f9fbb';
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(x, y, w, h, 9); else ctx.rect(x, y, w, h);
  ctx.fill(); ctx.stroke();
  ctx.restore();
  for (i = 0; i < lines.length; i++) {
    label(ctx, lines[i], x + w / 2, y + pady + sz / 2 + i * (sz + lead),
      { size: sz, color: opt.color || '#1f4a70', halo: false });
  }
  noteBox(_txtBox, x, y, w, h);
  noteObj(x, y, w, h);
}

/* ===== 図の中の「エネルギーの棒」 =====
   K を下、U を上に積む。てっぺんが E。非保存力があるときは、
   はじめの E までの残り（＝失われた分）をうすいグレーで塗る。
   色はグラフ・表・式とぴったり同じ（COL.eK / COL.eU / COL.eE）。 */
function energyBar(ctx, x, yTop, yBot, w, m, lo, hi, opt) {
  opt = opt || {};
  noteObj(x - 6, yTop - 10, w + 34, (yBot - yTop) + 32);
  if (!(hi - lo > 1e-9)) { hi = lo + 1; }
  function Yv(e) { return yBot - (e - lo) / (hi - lo) * (yBot - yTop); }
  var y0 = Yv(0);
  var yE = Yv(m.E);
  ctx.save();
  /* 枠 */
  ctx.strokeStyle = '#c9d2da'; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.rect(x, yTop, w, yBot - yTop); ctx.stroke();
  /* 0 の線（負の位置エネルギーが出るシムのため） */
  if (lo < -1e-9) {
    ctx.strokeStyle = '#aeb8c2'; ctx.setLineDash([4, 3]); ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(x - 3, y0); ctx.lineTo(x + w + 3, y0); ctx.stroke();
    ctx.setLineDash([]);
  }
  /* 失われた分（はじめの E まで） */
  if (opt.E0 !== undefined && opt.E0 - m.E > 1e-9) {
    var yE0 = Yv(opt.E0);
    ctx.fillStyle = fade(COL.areaNeg, 0.30);
    ctx.fillRect(x, yE0, w, yE - yE0);
    ctx.strokeStyle = fade(COL.areaNeg, 0.8); ctx.setLineDash([3, 3]); ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(x, yE0); ctx.lineTo(x + w, yE0); ctx.stroke();
    ctx.setLineDash([]);
  }
  function band(yA, yB, col, fillA, dash) {
    if (Math.abs(yA - yB) < 0.6) return;
    ctx.fillStyle = fade(col, fillA);
    ctx.fillRect(x, Math.min(yA, yB), w, Math.abs(yA - yB));
    ctx.strokeStyle = col; ctx.lineWidth = 1.3;
    if (dash) ctx.setLineDash([3, 2]);
    ctx.strokeRect(x, Math.min(yA, yB), w, Math.abs(yA - yB));
    ctx.setLineDash([]);
  }
  /* ★正のものは 0 から上へ、負のものは 0 から下へ積む★（先生の指摘・第6回）
     「K の上に U_g を積む」やり方だと、U_g が負のシム（1-12・2-3）で帯が上下に
     行ったり来たりして、合計が一定に見えなかった。
     こうすると「上にのびた分」と「下にのびた分」の差が E になり、
     E の線が動かないことが目で分かる。 */
  var up = y0, dn = y0, segs = [
    { e: m.K, col: COL.eK, a: 0.60, dash: false, nm: 'K', kc: '#14663d', sz: 12 },
    { e: m.Ug, col: COL.eU, a: 0.45, dash: false, nm: 'U_g', kc: COL.eU, sz: 11.5 },
    { e: m.Us, col: COL.eU, a: 0.22, dash: true, nm: 'U_k', kc: COL.eU, sz: 11 }
  ], si, sg, ya, yb, ph, mids = [];
  for (si = 0; si < segs.length; si++) {
    sg = segs[si];
    if (!(Math.abs(sg.e) > 1e-9)) continue;
    ph = Math.abs(Yv(0) - Yv(sg.e));         /* その量の長さ [px] */
    if (sg.e > 0) { ya = up; yb = up - ph; up = yb; }     /* 正のものは 0 から上へ */
    else { ya = dn; yb = dn + ph; dn = yb; }              /* 負のものは 0 から下へ */
    band(ya, yb, sg.col, sg.a, sg.dash);
    if (Math.abs(yb - ya) > 15) mids.push({ y: (ya + yb) / 2, nm: sg.nm, kc: sg.kc, sz: sg.sz });
  }
  /* E の高さに太い線 */
  ctx.strokeStyle = COL.eE; ctx.lineWidth = 3;
  ctx.beginPath(); ctx.moveTo(x - 4, yE); ctx.lineTo(x + w + 4, yE); ctx.stroke();
  ctx.restore();
  /* 文字（せまいところには書かない） */
  for (si = 0; si < mids.length; si++) {
    label(ctx, mids[si].nm, x + w / 2, mids[si].y,
      { size: mids[si].sz, bold: true, color: mids[si].kc, halo: false });
  }
  label(ctx, 'E', x + w + 7, yE, { size: 12, bold: true, color: COL.eE, align: 'left' });
  label(ctx, opt.title || 'エネルギー', x + w / 2, yBot + 13, { size: 10.5, color: COL.sub });
}

/* 2点をくらべるシムで、印を「相手の点から遠いほう」へずらした場所を返す。
   ★印は物体・力の矢印と重ねない★（先生の指示・第6回）
   nx, ny＝面から外向き、off＝面からの高さ、along＝坂にそってずらす長さ。 */
function markAway(p, other, nx, ny, off, along) {
  var dx = p.x - other.x, dy = p.y - other.y, L = Math.hypot(dx, dy) || 1;
  return { x: p.x + nx * off + dx / L * along, y: p.y + ny * off + dy / L * along };
}

/* 点（A・B…）の印。「どこをくらべているか」は答えではないので、いつも出してよい。
   ★どこに印を出したかを覚えておく★（吹きだしの引き出し線の「黒丸」を、
   　この印の上に重ねて描くと、文字がつぶれて読めなくなるため） */
var _ptMarkAt = [];
function ptMarkNear(x, y) {
  var i;
  for (i = 0; i < _ptMarkAt.length; i++) {
    if (Math.abs(_ptMarkAt[i].x - x) < 11 && Math.abs(_ptMarkAt[i].y - y) < 11) return true;
  }
  return false;
}
function ptMark(ctx, name, x, y) {
  _ptMarkAt.push({ x: x, y: y });
  noteObj(x - 11, y - 11, 22, 22);
  /* ★ゴーストの物体より前面に出す★（第6回）ためておいて flushVec でまとめて描く */
  if (_defMark) {
    _defMark.push(function () { ptMarkNow(ctx, name, x, y); });
    return;
  }
  ptMarkNow(ctx, name, x, y);
}
function ptMarkNow(ctx, name, x, y) {
  ctx.save();
  ctx.fillStyle = '#fff'; ctx.strokeStyle = COL.eE; ctx.lineWidth = 1.8;
  ctx.beginPath(); ctx.arc(x, y, 9, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.restore();
  label(ctx, name, x, y + 0.5, { size: 12, bold: true, color: COL.eE, halo: false });
}

/* ===== くらべる点のエネルギーの吹きだし（★このページの決めごと★） =====
   ★点のすぐ近くに、その点のエネルギーを置く。物体・ほかの文字・ほかの吹きだしとは重ねない。★
   　吹きだしの中身は HTML（KaTeX）で組み、canvas の上に重ねて出す
   　（canvas では ½mv² のような式をきれいに組めないため）。
   　canvas 側は「置き場所を決めて、点まで引き出し線を引く」ところだけを受け持つ。 */

/* 置き場所を決める。点のまわりの候補から、重なりがいちばん少なくて点に近いものを選ぶ。 */
/* ★吹きだしは「A・B・C… の順」にならべる★（先生の指示・第6回）
   ばらばらの位置に置くと、どれがどの点か読み取れない。
   ・ふつう … 左から右へ A → B → C（前の吹きだしより左に来たら大きな罰）
   ・stack  … 上から下へ A → B → C（前の吹きだしより上に来たら大きな罰）
   prev＝1つ前に置いた吹きだしの箱（null なら制限なし）。 */
function placePtBox(px, py, w, h, taken, side, prev) {
  /* 16 方向 × 4 とおりのへだたりを試す */
  var dirs = [], a, i, j, k;
  for (a = 0; a < 16; a++) dirs.push([Math.cos(a * Math.PI / 8), Math.sin(a * Math.PI / 8)]);
  var rings = [14, 34, 62, 96, 140];
  /* 点数：文字・ほかの吹きだしに1つでも重なったら大きな罰。物体は軽い罰。
     そのうえで「点に近いほど良い」。重なり 0 を最優先し、そのうえで点のそば。 */
  function ptScore(b, taken2, pad) {
    var sc = 0, k, ov, m2 = pad || 0;
    for (k = 0; k < _txtBox.length; k++) {
      ov = boxOverlap(b, m2 ? infl(_txtBox[k], m2) : _txtBox[k]);
      if (ov > 0) sc += 1400 + ov * 10;                 /* 文字は隠さない */
    }
    for (k = 0; k < _objBox.length; k++) sc += boxOverlap(b, _objBox[k]) * 3.0;  /* 物体も避ける */
    for (k = 0; k < taken2.length; k++) {
      ov = boxOverlap(b, m2 ? infl(taken2[k], m2) : taken2[k]);
      if (ov > 0) sc += 4000 + ov * 10;                 /* 吹きだしどうしは絶対に重ねない */
    }
    /* ★点にどれだけ近いか★ 箱のいちばん近いふちから点までの長さで測る */
    var ax = Math.max(b.x - px, 0, px - (b.x + b.w));
    var ay = Math.max(b.y - py, 0, py - (b.y + b.h));
    /* 'row' は「地面の下に1列」がねらいなので、点への近さは軽くみる。
       重くすると、点のそばに残ってしまって列にならばない（第6回の直し） */
    sc += Math.hypot(ax, ay) * (side === 'row' ? 4 : 20);
    /* 点が3つ以上あるシムは、吹きだしを1つの列にそろえて「縦に並べる」と見やすい。
       d.ptSide に 'stack'（右の列）／'stackL'（左の列）を書くと、その列へ引きよせる。 */
    if (side === 'stack') sc += Math.abs(b.x - (CVW - w - 96)) * 26;
    else if (side === 'stackL') sc += Math.abs(b.x - 6) * 6;
    /* ★'row'★ 地面の下の「吹きだしの帯」に、左から順に1列にならべる（先生の指示・第6回）。
       シムの draw が ptRow(gy + 14) で帯の高さを教える。 */
    else if (side === 'row' && _ptRowY !== null) {
      sc += Math.abs(b.y - _ptRowY) * 30;
      sc += Math.abs((b.x + b.w / 2) - px) * 3;
    }
    /* ★順番★ 前の吹きだしより「あと」に来るようにする */
    if (prev) {
      if (side === 'stack' || side === 'stackL') {
        if (b.y < prev.y + prev.h * 0.5) sc += 2600 + (prev.y + prev.h * 0.5 - b.y) * 24;
      } else if (b.x < prev.x + prev.w * 0.34) {
        sc += 2600 + (prev.x + prev.w * 0.34 - b.x) * 24;
      }
    }
    return sc;
  }
  function infl(b, m2) { return { x: b.x - m2, y: b.y - m2, w: b.w + 2 * m2, h: b.h + 2 * m2 }; }
  var best = null, bestScore = Infinity, cand = [];
  for (j = 0; j < rings.length; j++) {
    for (i = 0; i < dirs.length; i++) {
      var L = rings[j];
      cand.push([px + dirs[i][0] * (w / 2 + L) - w / 2, py + dirs[i][1] * (h / 2 + L) - h / 2]);
    }
  }
  /* ★'row' は「帯のどこか」も必ず候補に入れる★
     山登りだけだと、図の文字が壁になって帯までたどりつけないことがある。 */
  if (side === 'row' && _ptRowY !== null) {
    for (i = -3; i <= 3; i++) cand.push([px - w / 2 + i * (w * 0.55), _ptRowY]);
  }
  /* ★'stack'／'stackL' も「列のあちこち」を必ず候補に入れる★（先生の指示・第6回）
     山登りだけだと、いちばん近い所しか見つからず、A→B→C の順にならばないことがあった。 */
  if (side === 'stack' || side === 'stackL') {
    var sx = (side === 'stack') ? (CVW - w - 96) : 6;
    for (i = -3; i <= 3; i++) cand.push([sx, py - h / 2 + i * (h * 0.85)]);
    if (prev) cand.push([sx, prev.y + prev.h + 8]);
  }
  for (i = 0; i < cand.length; i++) {
    var b = { w: w, h: h };
    b.x = clamp(cand[i][0], 3, Math.max(3, CVW - w - 3));
    b.y = clamp(cand[i][1], 3, Math.max(3, CVH - h - 3));
    var sc = ptScore(b, taken);
    if (sc < bestScore) { bestScore = sc; best = b; }
  }
  /* さらに、いちばん良かった場所のまわりを少しずつずらして、重なりを 0 に追いこむ */
  function score(b) { return ptScore(b, taken, 3); }
  var steps = [14, 7, 3], si, dd, cur = { x: best.x, y: best.y, w: w, h: h }, curSc = score(cur);
  var d8 = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
  for (si = 0; si < steps.length; si++) {
    for (var it = 0; it < 12; it++) {
      var moved = false;
      for (dd = 0; dd < d8.length; dd++) {
        var nb = { w: w, h: h,
          x: clamp(cur.x + d8[dd][0] * steps[si], 3, Math.max(3, CVW - w - 3)),
          y: clamp(cur.y + d8[dd][1] * steps[si], 3, Math.max(3, CVH - h - 3)) };
        var ns = score(nb);
        if (ns < curSc - 0.01) { cur = nb; curSc = ns; moved = true; }
      }
      if (!moved) break;
    }
  }
  return cur;
}

/* 箱の中心から点へ向かう線が、箱のふちを出るところ */
function boxEdge(b, px, py) {
  var cx = b.x + b.w / 2, cy = b.y + b.h / 2;
  var dx = px - cx, dy = py - cy;
  if (Math.abs(dx) < 1e-6 && Math.abs(dy) < 1e-6) return { x: cx, y: cy };
  var tx = dx === 0 ? Infinity : (b.w / 2 + 2) / Math.abs(dx);
  var ty = dy === 0 ? Infinity : (b.h / 2 + 2) / Math.abs(dy);
  var tt = Math.min(tx, ty);
  return { x: cx + dx * tt, y: cy + dy * tt };
}

/* map(p, m) → {x, y}（その点の画面での位置）。運動が終わってから出す。
   決めた置き場所は st._ptPos に入れて、HTML の吹きだし（80_ui.js）がそこへ移動する。 */
/* map(p, m) が返せるもの
     x, y      … 吹きだしの引き出し線がさす点（必須）
     ox, oy    … 物体をもう一度描く場所（省略すると x, y）
     r         … 物体の半径 px（省略すると描かない）
     bw, bh    … 物体が四角のときの大きさ（r のかわり）
     ang       … 四角の傾き（rad）
     vx, vy    … 速度の向き（画面の単位ベクトル。省略すると描かない）
     vlen      … 速度の矢印の長さ px（省略すると 30）
     base      … 高さの両矢印をひく基準面の y（省略すると描かない）
     hx        … 高さの両矢印の x（省略すると ox）
   ★運動が終わったら、くらべる点それぞれに「物体・速度・高さ」をもう一度描く★
   　どの点の話なのかを目で追えるようにするため。 */
/* ★'row'（地面の下の1列）は、さがすのをやめて「左から順にきちんとならべる」★
   （先生の指示・第6回：吹きだしは左から A・B・C の順）
   さがし方（placePtBox）だと、図の中の文字をよけて1つだけ列から外れることがあった。
   ここで幅を足し算して、入るなら等間隔でならべる。入らないときだけ、さがし方にもどす。 */
function rowPlace(qs, sizes) {
  var n = sizes.length, i, tot = 0, gap = 8, L = 4, R = CVW - 72;  /* 右はエネルギーの棒のぶん */
  for (i = 0; i < n; i++) tot += sizes[i].w;
  if (tot + gap * (n - 1) > R - L) gap = 4;
  if (tot + gap * (n - 1) > R - L) return null;
  var span = tot + gap * (n - 1), cxs = 0;
  for (i = 0; i < n; i++) cxs += qs[i].x;
  var x0r = clamp(cxs / n - span / 2, L, R - span);
  /* ★帯に文字がかかっていたら、帯ごと下へずらす★（第8回）
     各点に力の矢印も描くようになって、mg の字が帯まで下りてくるようになったため。 */
  var yr = _ptRowY, k, j, hit;
  for (k = 0; k < 8; k++) {
    hit = 0;
    for (i = 0; i < n && !hit; i++) {
      var b0 = { x: x0r, y: yr, w: sizes[i].w, h: sizes[i].h };
      b0.x = x0r; 
      for (j = 0; j < i; j++) b0.x += sizes[j].w + gap;
      for (var t2 = 0; t2 < _txtBox.length; t2++) {
        if (boxOverlap(b0, _txtBox[t2]) > 0) { hit = 1; break; }
      }
    }
    if (!hit) break;
    if (yr + sizes[0].h + 8 > CVH - 3) break;
    yr += 8;
  }
  var x = x0r, out = [];
  for (i = 0; i < n; i++) {
    out.push({ x: x, y: yr, w: sizes[i].w, h: sizes[i].h });
    x += sizes[i].w + gap;
  }
  return out;
}

function drawPts(ctx, d, s, t, map) {
  st._ptPos = null;
  st._vGhost = [];        /* 検算用：ゴーストの速度ベクトルの「速さ」と「長さ」 */
  if (!endOn(d, s, t)) return;
  var ps = ptsOf(d, V(s)), i, taken = [], out = [], qs = [];
  var live = d.sample(V(s), t);          /* いまの物体の場所（二重に描かないための照合用） */
  for (i = 0; i < ps.length; i++) qs.push(map(ps[i], ps[i].m, i));
  /* ★★ 速度ベクトルの長さは「その点の速さ」に比例させる ★★（先生の指摘・第7回）
     いままでは map が返す vlen（決め打ちの px）でどの点も同じ長さに描いていたので、
     1-7 のように v_A = 14 m/s・v_B = 7 m/s とちがう点が、同じ速さに見えてしまった。
     ここで「その図の中でいちばん速い点」を出しておき、ptGhost が比で縮める。 */
  var vmax = 0;
  for (i = 0; i < ps.length; i++) if (ps[i].m.v > vmax) vmax = ps[i].m.v;
  for (i = 0; i < qs.length; i++) if (qs[i]) qs[i].vmax = vmax;
  /* ① 各点に物体・速度・高さを描き直す（吹きだしより先に。吹きだしがこれを避けるため） */
  for (i = 0; i < qs.length; i++) {
    /* いま物体がその点にいるときは、物体と速度は本物がもう描かれているので描き直さない
       （二重に見えるため）。★高さの寸法線だけは、どの点にも必ず出す★
       時刻はちがっても「場所が同じ」ことがある（ばねが自然長にもどってきたときなど）。
       そのときは map が q.here = true を返す。 */
    if (qs[i]) {
      /* ★「本物がいまその点にいる」かどうかは、時刻ではなく「場所」で見る★（第8回）
         止まったあともアニメが続くシム（2-1・2-2・2-5）や、1周期でもどるシム（1-6）では
         時刻がちがうのに場所は同じ。時刻だけで見ると、物体も力も二重に描かれてしまう。 */
      var same = (Math.abs((ps[i].m.x || 0) - (live.x || 0)) < 1e-3 &&
        Math.abs((ps[i].m.y || 0) - (live.y || 0)) < 1e-3);
      ptGhost(ctx, d, s, ps[i], qs[i], !!qs[i].here || Math.abs(ps[i].t - t) <= 1e-6 || same);
    }
  }
  /* ①' モード2は「途中の状態」も描く（力の向きが運動と逆＝負の仕事、が大事なので） */
  if (d.midGhost) d.midGhost(ctx, s);
  /* ★ここでベクトル（力・速度・加速度）をまとめて描く★
     ゴーストのあとに描くので、矢印が物体やゴーストに隠れない。
     吹きだしを置く前に描くので、吹きだしは矢印の文字をちゃんとよけてくれる。 */
  flushVec(ctx);
  /* ② そのうえで吹きだしを置く */
  var sizes = [];
  for (i = 0; i < ps.length; i++) {
    sizes.push((st._ptSz && st._ptSz[ps[i].name]) || { w: 132, h: 40 });
  }
  var rows = (d.ptSide === 'row' && _ptRowY !== null) ? rowPlace(qs, sizes) : null;
  for (i = 0; i < ps.length; i++) {
    var p = ps[i], q = qs[i];
    if (!q) continue;
    var sz = sizes[i];
    var b = rows ? rows[i]
      : placePtBox(q.x, q.y, sz.w, sz.h, taken, d.ptSide, taken[taken.length - 1] || null);
    taken.push(b);
    var e = boxEdge(b, q.x, q.y);
    ctx.save();
    ctx.strokeStyle = fade(COL.eE, 0.6); ctx.lineWidth = 1.3; ctx.setLineDash([4, 3]);
    ctx.beginPath(); ctx.moveTo(e.x, e.y); ctx.lineTo(q.x, q.y); ctx.stroke();
    ctx.restore();
    if (!ptMarkNear(q.x, q.y)) {
      ctx.save();
      ctx.fillStyle = COL.eE;
      ctx.beginPath(); ctx.arc(q.x, q.y, 3.2, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
    }
    out.push({ name: p.name, x: b.x + b.w / 2, y: b.y + b.h / 2 });
    /* 重なりの自動検査に、吹きだしの場所も記録する */
    if (typeof window !== 'undefined' && window.__labelLog) {
      window.__labelLog.push({ cv: CVID, text: '吹:' + p.name, x: b.x, y: b.y + b.h / 2, w: b.w, h: b.h });
    }
  }
  st._ptPos = out;
}

/* くらべる点の「物体・速度ベクトル・高さ」をうすく描き直す */
function ptGhost(ctx, d, s, p, q, here) {
  var ox = (q.ox === undefined) ? q.x : q.ox;
  var oy = (q.oy === undefined) ? q.y : q.oy;
  ctx.save();
  noteObj(ox - 26, oy - 26, 52, 52);
  if (!here) {
    ctx.save(); ctx.globalAlpha = 0.9;
    if (q.bw) blockShape(ctx, ox, oy, q.ang || 0, q.bw, q.bh || q.bw, '#f2f4f7');
    else if (q.r) ball(ctx, ox, oy, q.r, 'faint');
    ctx.restore();
  }
  /* 高さ（両矢印）。0 に近いときは heightDim が自分で何も描かない。
     ★記号は「その点の式で使っている名前」にする★（先生の指示・第12回）
     どの点も 'h = …' だと、式の $mgh_B$ が図のどの寸法なのか分からない。
     pts に hsym（例 'h_B'・'D'・'L sinθ'）を書いておくと、それを使う。 */
  if (q.base !== undefined && Math.abs(p.m.h) > 0.005) {
    /* 高さは「面に接している点」ではかりたいので、map が hy を返せばそれを使う */
    heightDim(ctx, (q.hx === undefined) ? ox : q.hx, (q.hy === undefined) ? oy : q.hy, q.base,
      (p.hsym || 'h') + ' = ' + fmt(p.m.h, 2) + ' m', undefined, q.hside);
  }
  /* ★「力を表示」が ON なら、その点ではたらく力も描く★（先生の指示・第8回）
     どの点でどの力がはたらいているかを、吹きだしの式と見くらべられるようにするため。
     描き方はシムごとにちがうので、map が返す fdraw() にまかせる。
     本物の物体がそこにいるときは、本物の矢印がもう出ているので描かない。 */
  if (!here && q.fdraw && s.o.showF) q.fdraw();
  /* 速度ベクトル（物体から少し離して出す）。本物がそこにいるときは本物にまかせる。
     ★中点を物体の中点の真上（横に出すときはすぐ横）にそろえる★ */
  if (!here && q.vx !== undefined && p.m.v > 0.02) {
    /* ★長さは速さに比例★（第7回）本物の矢印とまったく同じ式（vArrowLen）を使う。
       map が vref（目安の速さ）と vk（そのときの長さ）を返す。 */
    var L, off = q.voff || 20;
    if (q.vref) L = vArrowLen(p.m.v, q.vref, q.vk);
    else if (q.vmax > 0.02) L = (q.vlen || 30) * (p.m.v / q.vmax);
    else L = q.vlen || 30;
    var gnx = q.vy, gny = -q.vx;             /* 速度と垂直 */
    if (gny > 0) { gnx = -gnx; gny = -gny; } /* 画面の上向き（横向きの速度なら真上）にそろえる */
    var va = velArrow(ctx, ox, oy, gnx, gny, off, q.vx, q.vy, L);
    if (st._vGhost) st._vGhost.push({ n: p.name, v: p.m.v, L: L });
    label(ctx, 'v', va.tx + q.vx * 10, va.ty + q.vy * 10, { size: 11, color: COL.vel });
  }
  ctx.restore();
}

/* 吹きだしに書く式（KaTeX）。K と U の記号を「+」でつないだもの。 */
function ptTex(d, p) {
  var parts = [p.sym.K || '0', p.sym.Ug || '0'];
  if (d.hasUs) parts.push(p.sym.Us || '0');
  return 'E_' + p.name + ' = ' + parts.join(' + ');
}

/* ★速度ベクトルは「物体の中点をはさんで、前後に半分ずつ」描く★（先生の指示・第6回）
   こうすると矢印の<b>まん中</b>が、物体の中点の真上（横に出すときはすぐ横）に来る。
   (ox,oy)＝物体の中心／(nx,ny)＝物体からずらす向き（ふつうは面の外向き＝画面の上）／
   off＝ずらす距離［px］／(ux,uy)＝速度の向き（単位ベクトル）／len＝矢印の長さ［px］。
   返り値の tx,ty＝矢印の先。文字「v」はそこから少し先に置く。 */
/* ★速度ベクトルの長さは「速さ」にきっちり比例させる★（先生の指示・第7回）
   前は 14 + k*v/vref と下駄をはかせていたので、たとえば 1-7 の
   v_A = 14 m/s と v_B = 7 m/s（ちょうど2倍）が 44 px と 29 px になり、
   ゴーストの決め打ち（24 px）ではまったく同じ長さに見えていた。
   比例にすれば「矢印の長さの比＝速さの比」になり、図から速さを読み取れる。
   v … その瞬間の速さ／vref … そのシムの目安の速さ／k … vref のときの長さ[px] */
function vArrowLen(v, vref, k) {
  return (k || 46) * Math.abs(v) / Math.max(1e-6, vref);
}

function velArrow(ctx, ox, oy, nx, ny, off, ux, uy, len) {
  var cx = ox + nx * off, cy = oy + ny * off;
  var hx = ux * len / 2, hy = uy * len / 2;
  arrow(ctx, cx - hx, cy - hy, cx + hx, cy + hy, 'vel');
  return { x: cx, y: cy, tx: cx + hx, ty: cy + hy };
}

/* ===== 加速度ベクトル（表示チェック「加速度ベクトルを表示」で出す） =====
   (ax, ay) は画面の向きの加速度［m/s²］（y は下向きが正）。
   長さは「g のとき 34 px」にそろえてあるので、どのシムでも大きさを見くらべられる。 */
function drawAcc(ctx, x, y, ax, ay, opt) {
  opt = opt || {};
  var mag = Math.hypot(ax, ay);
  if (!(mag > 0.05)) return;
  var k = 34 / G, L = Math.min(mag * k, opt.max || 76);
  var ux = ax / mag, uy = ay / mag;
  /* ★加速度の矢印は「速度の矢印よりさらに外がわ」に、まん中をそろえて描く★
     （先生の指示・第17回）前は物体のすぐ近くから描き出していたので、
     物体や斜面に重なって読めなかった。
     (x,y)＝物体の中心／(nx,ny)＝ずらす向き（ふつうは面の外向き＝画面の上）／
     off＝ずらす距離［px］。矢印はその点を「まん中」にして描くので、
     a がどちらを向いても帯の中におさまり、物体に重ならない。 */
  var nx = (opt.nx === undefined) ? 0 : opt.nx;
  var ny = (opt.ny === undefined) ? -1 : opt.ny;
  var nl = Math.hypot(nx, ny) || 1;
  var off = (opt.off === undefined) ? 44 : opt.off;
  /* ★a が「ずらした向き」と逆を向くときは、矢じりが物体まで戻ってきてしまう★
     （1-8 の最高点など）。そのぶん余分に離しておく。 */
  if (ux * (nx / nl) + uy * (ny / nl) < -0.05) off = Math.max(off, L / 2 + 38);
  var cx = x + (nx / nl) * off + (opt.dx || 0), cy = y + (ny / nl) * off + (opt.dy || 0);
  /* 図の外へはみ出さないように、矢印ぜんたいを枠の中へおさめる */
  if (CVW > 0) {
    var mx = Math.abs(ux) * L / 2 + 15, my = Math.abs(uy) * L / 2 + 15;
    cx = clamp(cx, mx, Math.max(mx, CVW - mx));
    cy = clamp(cy, my, Math.max(my, CVH - my));
  }
  var hx = ux * L / 2, hy = uy * L / 2;
  arrow(ctx, cx - hx, cy - hy, cx + hx, cy + hy, 'acc');
  label(ctx, 'a', cx + hx + ux * 11, cy + hy + uy * 11, { size: 11.5, color: COL.acc });
}

/* 図の右はしに「エネルギーの棒」を出す（全シム共通の置き場所） */
var _ebRange = { key: null, lo: 0, hi: 1 };
/* エネルギーの棒の目盛りは、運動の間ずっと同じにする（棒が伸び縮みして見えないように）。
   位置エネルギーが負になるシム（1-10・2-3）があるので、下の端も見る。 */
function energyRange(d, s) {
  var v = V(s), key = st.cur + '|' + JSON.stringify(v);
  if (_ebRange.key === key) return _ebRange;
  /* ★目もりは「棒がのびる長さ」に合わせる★（第10回に直したバグ）
     energyBar は【正のものを 0 から上へ、負のものを 0 から下へ】積む（第6回）。
     だから棒が上へのびる長さは「正のものの合計」、下へのびる長さは
     「負のものの合計」であって、K + U_g + U_k のような“途中までの和”ではない。
     前は途中までの和で目もりを決めていたので、U_g が負になるシム
     （1-12 鉛直ばね・2-3 手でゆっくり下ろす）で U_k の帯が枠の上にはみ出し、
     「K は変わっていないのに棒が伸びていく」ように見えていた（先生の指摘）。 */
  var T = d.tEnd(v), lo = 0, hi = 1e-6, i, j, e3;
  for (i = 0; i <= 40; i++) {
    var q = d.sample(v, T * i / 40), pos = 0, neg = 0;
    e3 = [q.K, q.Ug, q.Us];
    for (j = 0; j < 3; j++) {
      if (e3[j] > 0) pos += e3[j];
      else if (e3[j] < 0) neg += e3[j];
    }
    lo = Math.min(lo, q.E, neg);
    hi = Math.max(hi, q.E, pos);
  }
  var E0 = d.sample(v, 0).E;
  lo = Math.min(lo, E0); hi = Math.max(hi, E0);
  var pad = Math.max(1e-6, (hi - lo)) * 0.08;
  _ebRange = { key: key, lo: lo - (lo < -1e-9 ? pad : 0), hi: hi + pad };
  return _ebRange;
}

function drawEnergyBar(ctx, d, s, t, W, H, m) {
  var v = V(s), E0 = d.sample(v, 0).E, r = energyRange(d, s);
  var yBot = H - 32, yTop = Math.max(20, yBot - Math.max(60, H - 92));
  energyBar(ctx, W - 62, yTop, yBot, 28, m, r.lo, r.hi,
    { E0: consOf(d, v) ? undefined : E0, title: 'エネルギー' });
}

/* 図の右上の時刻 */
function drawClock(ctx, W, t) {
  label(ctx, 't = ' + fmt(t, 2) + ' s', W - 78, 18, { align: 'right', size: 13.5, bold: true });
}
```

## src/47_step.js

```js
/* ページのいちばん上の「立式のステップ図」。
   Step1 保存力だけが仕事をしているか？ → Step2 2つの位置でエネルギーを書き出す
   → Step3 式を立てる
   ★いま見ているシミュレーションの状態を反映させる★
   　Step1 に ○/× を出し、× のときは Step3 の式が
   　「力学的エネルギー保存則」から「E₂ − E₁ = W非保存」に切りかわる。 */
'use strict';

var STEP = {
  W: 980, H: 150,          /* 広い画面（横に3つ並べる） */
  NW: 380, NH: 330         /* せまい画面（たてに3つ積む） */
};

/* 角丸の箱 */
function stepBox(ctx, x, y, w, h, tone) {
  ctx.save();
  ctx.fillStyle = tone === 'ok' ? '#eef8f1' : (tone === 'ng' ? '#fdf0ee' : '#f2f6fa');
  ctx.strokeStyle = tone === 'ok' ? '#a7d9bb' : (tone === 'ng' ? '#efbdb5' : '#cfdce8');
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(x, y, w, h, 10); else ctx.rect(x, y, w, h);
  ctx.fill(); ctx.stroke();
  ctx.restore();
}

/* 「Step 1」の小さなふだ */
function stepTag(ctx, x, y, n) {
  var w = 52, h = 19;
  ctx.save();
  ctx.fillStyle = '#245a8d';
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(x, y, w, h, 9); else ctx.rect(x, y, w, h);
  ctx.fill();
  ctx.restore();
  label(ctx, 'Step ' + n, x + w / 2, y + h / 2 + 0.5,
    { size: 11.5, bold: true, color: '#ffffff', halo: false, clamp: false });
  return w;
}

/* ○ / × のふだ */
function stepMark(ctx, x, y, ok) {
  ctx.save();
  ctx.fillStyle = ok ? '#1c8f4a' : '#c0392b';
  ctx.beginPath(); ctx.arc(x, y, 11, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
  label(ctx, ok ? '○' : '×', x, y + 0.5,
    { size: 15, bold: true, color: '#fff', halo: false, clamp: false });
}

/* 箱と箱をつなぐ矢印 */
function stepArrow(ctx, x, y, len, vertical) {
  ctx.save();
  ctx.strokeStyle = '#8b98a5'; ctx.fillStyle = '#8b98a5'; ctx.lineWidth = 2.4;
  ctx.beginPath();
  if (vertical) { ctx.moveTo(x, y); ctx.lineTo(x, y + len - 8); }
  else { ctx.moveTo(x, y); ctx.lineTo(x + len - 8, y); }
  ctx.stroke();
  ctx.beginPath();
  if (vertical) { ctx.moveTo(x, y + len); ctx.lineTo(x - 5.5, y + len - 9); ctx.lineTo(x + 5.5, y + len - 9); }
  else { ctx.moveTo(x + len, y); ctx.lineTo(x + len - 9, y - 5.5); ctx.lineTo(x + len - 9, y + 5.5); }
  ctx.closePath(); ctx.fill();
  ctx.restore();
}

/* Step2 の中の小さな表（点・K・U） */
function stepTable(ctx, x, y, w, rows, hasUs, rh) {
  var cols = hasUs ? 4 : 3;
  var cw = [w * 0.16, w * (hasUs ? 0.30 : 0.42), w * (hasUs ? 0.27 : 0.42), w * 0.27];
  var i, j;
  rh = rh || 15;
  var head = hasUs ? ['', '運動エネルギー', '重力の位置エネ', '弾性力の位置エネ']
    : ['', '運動エネルギー K', '位置エネルギー U'];
  var colX = [x], acc = x;
  for (i = 0; i < cols; i++) { acc += cw[i]; colX.push(acc); }
  ctx.save();
  ctx.strokeStyle = '#c3cfdb'; ctx.lineWidth = 1;
  ctx.fillStyle = '#e7eef5';
  ctx.fillRect(x, y, acc - x, rh);
  ctx.strokeRect(x, y, acc - x, rh);
  for (i = 0; i < rows.length; i++) ctx.strokeRect(x, y + rh * (i + 1), acc - x, rh);
  for (j = 1; j < cols; j++) {
    ctx.beginPath(); ctx.moveTo(colX[j], y); ctx.lineTo(colX[j], y + rh * (rows.length + 1)); ctx.stroke();
  }
  ctx.restore();
  for (j = 0; j < cols; j++) {
    label(ctx, head[j] || '', (colX[j] + colX[j + 1]) / 2, y + rh / 2,
      { size: rh >= 15 ? 9 : 8.5, color: COL.sub, clamp: false });
  }
  var fz = rh >= 15 ? 11 : 10;
  for (i = 0; i < rows.length; i++) {
    var yy = y + rh * (i + 1) + rh / 2;
    label(ctx, rows[i][0], (colX[0] + colX[1]) / 2, yy, { size: fz, bold: true, clamp: false });
    label(ctx, rows[i][1], (colX[1] + colX[2]) / 2, yy, { size: fz, color: '#14663d', clamp: false });
    label(ctx, rows[i][2], (colX[2] + colX[3]) / 2, yy, { size: fz, color: COL.eU, clamp: false });
    if (hasUs) label(ctx, rows[i][3] || '0', (colX[3] + colX[4]) / 2, yy, { size: fz, color: COL.eU, clamp: false });
  }
  return rh * (rows.length + 1);
}

/* いま見ているシムから、ステップ図に出す中身を作る */
function stepData() {
  var d = DEFS[st.cur], s = st.sims[st.cur], v = V(s);
  var ok = consOf(d, v);
  var ps = ptsOf(d, v);
  var hasUs = !!d.hasUs;
  var rows = ps.map(function (p) {
    return [p.name, texPlain(p.sym.K || '0'), texPlain(p.sym.Ug || '0'), texPlain(p.sym.Us || '0')];
  });
  return {
    ok: ok, rows: rows, hasUs: hasUs,
    why: ok ? (d.step1 || '保存力（重力・弾性力）だけが仕事をしている')
      : (d.step1 || '非保存力が仕事をしている'),
    /* ★式は2行で書く★ 1行目＝エネルギーどうしの関係、2行目＝K と U に書きひらいた形 */
    eq1: ok ? 'E_1 = E_2' : 'E_2 - E_1 = W_{非保存}',
    eq2: ok ? 'K_1 + U_1 = K_2 + U_2' : '(K_2 + U_2) - (K_1 + U_1) = W_{非保存}',
    /* ★補足は「式を立てる」の右に置く★ 横に入る長さにそろえておく */
    eqSub: ok ? '（力学的エネルギー保存則）' : '（' + (d.wName || '非保存力') + 'の仕事の分だけ変わる）'
  };
}

function drawStep(cv) {
  if (!cv) return;
  var wide = (cv.clientWidth || 900) >= 640;
  var D = stepData();
  if (wide) drawStepWide(cv, D); else drawStepNarrow(cv, D);
}

/* 表の1行の高さと、それに合わせた箱の高さ（点の数で変わる） */
var STEP_RH = 15;
function stepBodyH(D) { return STEP_RH * (D.rows.length + 1); }

function drawStepWide(cv, D) {
  var W = STEP.W;
  /* ★縦はできるだけ低く★ 中身（Step2 の表）に合わせて決める */
  var bh = Math.max(94, 32 + stepBodyH(D) + 8);
  var H = bh + 12, ctx = prep(cv, W, H);
  var gap = 30, bw = (W - gap * 2 - 8) / 3, x0 = 4, y0 = 6;
  var i, xs = [x0, x0 + bw + gap, x0 + (bw + gap) * 2];
  stepBox(ctx, xs[0], y0, bw, bh, D.ok ? 'ok' : 'ng');
  stepBox(ctx, xs[1], y0, bw, bh);
  stepBox(ctx, xs[2], y0, bw, bh, D.ok ? 'ok' : 'ng');
  for (i = 0; i < 2; i++) stepArrow(ctx, xs[i] + bw + 4, y0 + bh / 2, gap - 8, false);

  var pad = 11, tagW = 52;
  /* --- Step1 --- */
  stepTag(ctx, xs[0] + pad, y0 + 7, 1);
  label(ctx, '保存力だけが仕事をしているか？', xs[0] + pad + tagW + 7, y0 + 16.5,
    { size: 12, bold: true, align: 'left', clamp: false });
  stepMark(ctx, xs[0] + pad + 12, y0 + 43, D.ok);
  label(ctx, D.ok ? '保存力だけ' : '非保存力が仕事をする', xs[0] + pad + 28, y0 + 43,
    { size: 12, bold: true, align: 'left', color: D.ok ? '#1c8f4a' : '#c0392b', clamp: false });
  wrapLabel(ctx, D.why, xs[0] + pad, y0 + 62, bw - pad * 2, 10.5, 13.5, '#3d4c5a');

  /* --- Step2 --- */
  stepTag(ctx, xs[1] + pad, y0 + 7, 2);
  label(ctx, '2つの位置でエネルギーを書き出す', xs[1] + pad + tagW + 7, y0 + 16.5,
    { size: 12, bold: true, align: 'left', clamp: false });
  stepTable(ctx, xs[1] + pad, y0 + 28, bw - pad * 2, D.rows, D.hasUs, STEP_RH);

  /* --- Step3 --- ★補足（力学的エネルギー保存則 など）は見出しの右に置く★ */
  stepTag(ctx, xs[2] + pad, y0 + 7, 3);
  label(ctx, '式を立てる', xs[2] + pad + tagW + 7, y0 + 16.5,
    { size: 12, bold: true, align: 'left', clamp: false });
  var subX = xs[2] + pad + tagW + 7 + 62;
  labelFitLeft(ctx, D.eqSub, subX, y0 + 17, xs[2] + bw - pad - subX, 10, { color: COL.sub });
  var eqY = y0 + 30 + (bh - 30) / 2;             /* 見出しの下の空きの中央 */
  labelFit(ctx, D.eq1, xs[2] + bw / 2, eqY - 13, bw - pad * 2, 19,
    { bold: true, color: D.ok ? '#14663d' : '#a5382c' });
  labelFit(ctx, D.eq2, xs[2] + bw / 2, eqY + 12, bw - pad * 2, 14,
    { bold: true, color: D.ok ? '#14663d' : '#a5382c' });
}

function drawStepNarrow(cv, D) {
  var W = STEP.NW, x = 4, pad = 9, bw = W - 8;
  var hs = [70, 26 + stepBodyH(D), 62], gapv = 17;
  var H = hs[0] + hs[1] + hs[2] + gapv * 2 + 8, ctx = prep(cv, W, H);
  var y = 2, i, ys = [];
  for (i = 0; i < 3; i++) { ys.push(y); y += hs[i] + gapv; }
  stepBox(ctx, x, ys[0], bw, hs[0], D.ok ? 'ok' : 'ng');
  stepBox(ctx, x, ys[1], bw, hs[1]);
  stepBox(ctx, x, ys[2], bw, hs[2], D.ok ? 'ok' : 'ng');
  for (i = 0; i < 2; i++) stepArrow(ctx, W / 2, ys[i] + hs[i] + 3, 12, true);

  var tagW = 52;
  stepTag(ctx, x + pad, ys[0] + 6, 1);
  label(ctx, '保存力だけが仕事をしている？', x + pad + tagW + 6, ys[0] + 15.5,
    { size: 11.5, bold: true, align: 'left', clamp: false });
  stepMark(ctx, x + pad + 12, ys[0] + 38, D.ok);
  label(ctx, D.ok ? '保存力だけ' : '非保存力が仕事をする', x + pad + 28, ys[0] + 38,
    { size: 11.5, bold: true, align: 'left', color: D.ok ? '#1c8f4a' : '#c0392b', clamp: false });
  wrapLabel(ctx, D.why, x + pad, ys[0] + 55, bw - pad * 2, 9.5, 12, '#3d4c5a');

  stepTag(ctx, x + pad, ys[1] + 6, 2);
  label(ctx, '2つの位置で書き出す', x + pad + tagW + 6, ys[1] + 15.5,
    { size: 11.5, bold: true, align: 'left', clamp: false });
  stepTable(ctx, x + pad, ys[1] + 25, bw - pad * 2, D.rows, D.hasUs, STEP_RH);

  stepTag(ctx, x + pad, ys[2] + 6, 3);
  label(ctx, '式を立てる', x + pad + tagW + 6, ys[2] + 15.5,
    { size: 11.5, bold: true, align: 'left', clamp: false });
  var subX2 = x + pad + tagW + 6 + 58;
  labelFitLeft(ctx, D.eqSub, subX2, ys[2] + 16, x + bw - pad - subX2, 9, { color: COL.sub });
  labelFit(ctx, D.eq1, x + bw / 2, ys[2] + 34, bw - pad * 2, 16,
    { bold: true, color: D.ok ? '#14663d' : '#a5382c' });
  labelFit(ctx, D.eq2, x + bw / 2, ys[2] + 52, bw - pad * 2, 12.5,
    { bold: true, color: D.ok ? '#14663d' : '#a5382c' });
}

/* 左そろえで、幅に入るまで字を小さくして書く（見出しの右のひとこと用） */
function labelFitLeft(ctx, text, x, y, maxW, size, opt) {
  opt = opt || {};
  var sz = size, w;
  for (; sz > 6.5; sz -= 0.5) {
    ctx.save(); ctx.font = sz + 'px ' + FONT;
    w = ctx.measureText(String(text)).width; ctx.restore();
    if (w <= maxW) break;
  }
  label(ctx, text, x, y, { size: sz, color: opt.color, align: 'left', clamp: false });
}

/* 幅に入るまで字を小さくして、中央に書く（式がはみ出さないように） */
function labelFit(ctx, text, cx, cy, maxW, size, opt) {
  opt = opt || {};
  var sz = size, w;
  var segs = String(text).replace(/_\{[^}]*\}|_./g, '');   /* 添え字は幅の見積もりから外す */
  for (; sz > 8; sz -= 0.5) {
    ctx.save(); ctx.font = (opt.bold ? 'bold ' : '') + sz + 'px ' + FONT;
    w = ctx.measureText(segs).width; ctx.restore();
    if (w <= maxW) break;
  }
  label(ctx, text, cx, cy, { size: sz, bold: opt.bold, color: opt.color, clamp: false });
}

/* 文字を幅で折り返して書く（日本語なので1文字ずつ測る） */
function wrapLabel(ctx, text, x, y, w, size, lh, color) {
  ctx.save();
  ctx.font = size + 'px ' + FONT;
  var line = '', i, lines = [];
  for (i = 0; i < text.length; i++) {
    var ch = text.charAt(i);
    if (ctx.measureText(line + ch).width > w && line) { lines.push(line); line = ''; }
    line += ch;
  }
  if (line) lines.push(line);
  ctx.restore();
  for (i = 0; i < lines.length; i++) {
    label(ctx, lines[i], x, y + i * lh, { size: size, color: color, align: 'left', clamp: false });
  }
}
```

## src/50_mode1.js

```js
/* モード1　非保存力が仕事をしないケース（力学的エネルギーが保存される） */
'use strict';

/* ★1-3（直線の滑台）・1-4（昇る）・1-5（曲線の滑台）は、同じ h なら同じ高さに見せる★
   （縮尺の上限をそろえる。ばらばらだと「同じ 3 m なのに曲線のほうが高い」と見える） */
var SC_SLIDE = 70;   /* 第9回：図が小さすぎたので上限を上げた（実際は横はばで決まる） */

/* ★地面の下にあける「吹きだしの帯」の高さ [px]★（先生の指示・第6回）
   吹きだしを A → B → C の順にならべるために、地面より下も使ってよいことにした。
   帯を使うシムは ch にこの分を足し、gy を「H − もとの余白 − PTBAND」にする。 */
var PTBAND = 66;

/* 1-7 ジェットコースターの縮尺 [px/m]。★固定★
   （自動にすると θ で絵の大きさが変わって「止まる高さは θ によらない」が伝わらない）
   いちばん広がる設定（v0 = 16、θ = 35°）でも横も縦も入る値にしてある。 */
var SC_COAST = 15.5;   /* 第6回：図が左に寄って右があいていたので大きくした */

/* 1-10 水平ばねにぶつかる／1-11 水平ばねと滑台 の縮尺 [px/m]。どちらも固定。 */
var SC_HIT = 215;   /* 第9回：右があいていたので大きくした（壁の右はしが 578 px で、地面の右はし 624 px に入る） */
var SC_SPSL = 84;

/* ============ 1-1 摩擦のない水平面 ============ */
DEFS['m1-1'] = {
  id: 'm1-1', mode: 1, tab: '1-1 摩擦のない水平面',
  title: '1-1　摩擦のない水平面',
  sub: 'なめらかな水平面。<b>重力と垂直抗力はつり合って</b>いて、しかもどちらも<b>運動の向きに垂直</b>だから<b>仕事をしない</b>。' +
    'だから速さは変わらず、$K$ も $U$ も、その和の $E$ も一定のまま。ここが「力学的エネルギーが保存する」いちばん単純な形。',
  cw: 520, ch: 215,
  vis: ['F', 'V', 'A'],
  mainVars: ['v0', 'm'],
  mainVarFocus: 'v0',
  vars: [
    { k: 'v0', label: '速さ $v$', unit: ' m/s', min: 1, max: 8, step: 0.5, dec: 1, def: 4.0 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 5, step: 0.5, dec: 1, def: 2.0 }
  ],
  actions: [
    { label: '速くする（v＝6 m/s）', fn: function (s) { s.v.v0 = 6; },
      is: function (v) { return Math.abs(v.v0 - 6) < 1e-9; },
      next: function (s) { return s._played && Math.abs(s.v.v0 - 6) > 1e-9; } },
    { label: '重くする（m＝4 kg）', fn: function (s) { s.v.m = 4; },
      is: function (v) { return Math.abs(v.m - 4) < 1e-9; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.v0 = 4; s.v.m = 2; },
      is: function (v) { return Math.abs(v.v0 - 4) < 1e-9 && Math.abs(v.m - 2) < 1e-9; } }
  ],
  cons: true,
  forces: ['g', 'N'],
  hintFig: '<b>速さが変わらない → K が変わらない</b>（基準面を床にとったので $U=0$ のまま。だから $E$ も変わらない）',
  step1: '重力と垂直抗力しかはたらかず、どちらも運動の向きに垂直なので仕事をしない',
  datum: '床（物体のある水平面）',
  hint2: '<b>次は</b>：オレンジのボタンで速さや質量を変えて、グラフの高さがどう変わるか見てみよう（形は変わらない）。',
  tEnd: function (v) { return P.m11.tEnd(v); },
  sample: function (v, t) { return P.m11.sample(v, t); },
  pts: [
    { name: 'A', jp: 'スタート', t: function () { return 0; },
      sym: { K: '\\tfrac{1}{2}mv^2', Ug: '0' } },
    { name: 'B', jp: fmt(P.m11.LB, 0) + ' m 進んだところ', t: function (v) { return P.m11.tB(v); },
      sym: { K: '\\tfrac{1}{2}mv^2', Ug: '0' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m1-1'], v = V(s), m = d.sample(v, t);
    var gy = H - 58, x0 = 70, sc = (W - 120 - x0) / P.m11.LEN;   /* 床のはしまで走らせる */
    function X(x) { return x0 + x * sc; }
    var kz = mSize(d, v), bw = 34 * kz, bh = 24 * kz;

    ground(ctx, 20, W - 96, gy);
    datumLine(ctx, 20, W - 96, gy, '基準面 h = 0', false, true);
    /* ★印は物体の横★（第6回）上下は mg・N の矢印が通るので、外側の横に置く */
    ptMark(ctx, 'A', X(0) - bw / 2 - 13, gy - bh / 2);
    ptMark(ctx, 'B', X(P.m11.LB) + bw / 2 + 13, gy - bh / 2);

    /* 残像 */
    var i;
    for (i = 0; i * 0.25 < t - 1e-9; i++) {
      ctx.save(); ctx.globalAlpha = 0.28;
      blockShape(ctx, X(v.v0 * i * 0.25), gy - bh / 2, 0, bw, bh, '#f2f4f7');
      ctx.restore();
    }
    var cx = X(m.x), cy = gy - bh / 2;
    blockShape(ctx, cx, cy, 0, bw, bh, '#e8eef5');

    /* デコピンではじいて動き出す */
    flickStart(ctx, t, v.v0, X(0) - bw / 2 - 20, cy, 0, 74);

    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 40 / mg;
    function fAt(ax) {
      arrow(ctx, ax, cy, ax, cy + mg * fs, 'force');
      label(ctx, 'mg', ax, cy + mg * fs + 11, { size: 11.5, color: COL.force });
      arrow(ctx, ax, gy, ax, gy - mg * fs, 'force', 1, COL.norm);
      label(ctx, 'N', ax + bw / 2 + 8, gy - mg * fs + 4, { align: 'left', size: 11.5, color: COL.norm });
    }
    if (s.o.showF) fAt(cx);
    if (s.o.showV) {
      var vl = vArrowLen(v.v0, 8, 56);
      var va = velArrow(ctx, cx, cy, 0, -1, bh / 2 + 42, 1, 0, vl);
      label(ctx, 'v', va.tx + 10, va.ty, { align: 'left', size: 11.5, color: COL.vel });
    }
    if (s.o.showA) {
      /* 力がつり合っているので加速度は 0。矢印が描けないので、そう書いておく */
      label(ctx, 'a = 0', cx, cy - bh / 2 - 22, { size: 11.5, color: COL.acc });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    drawPts(ctx, d, s, t, function (p) {
      var A = (p.name === 'A'), xx = X(A ? 0 : P.m11.LB);
      return { x: xx + (A ? -1 : 1) * (bw / 2 + 13), y: gy - bh / 2,
        ox: xx, oy: gy - bh / 2, bw: bw, bh: bh,
        fdraw: function () { fAt(xx); },
        vx: 1, vy: 0, vref: 8, vk: 56, voff: bw / 2 + 10 };
    });
  },
  resItems: function (v) {
    return [{ k: 'A から B までの距離', v: fmt(P.m11.LB, 1) + ' m' }];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m1-1'].sample(v, t);
    return [
      ['位置 $x$', fmt(m.x, 2) + ' m'],
      ['重力 $mg$', fmt(v.m * G, 1) + ' N'],
      ['垂直抗力 $N$', fmt(v.m * G, 1) + ' N'],
      ['運動の続く時間', fmt(P.m11.tEnd(v), 2) + ' s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return 'E = K + U = \\tfrac{1}{2}mv^2 + 0 = ' + fmt(EN.K(v.m, v.v0), 2) +
      '\\ \\mathrm{J}\\quad(\\text{一定})';
  },
  note: '力は<b>重力と垂直抗力の2本だけ</b>で、どちらも運動の向き（水平）に<b>垂直</b>だから仕事をしません。' +
    'だから <b>K は一定</b>。基準面を床にとったので <b>U = 0</b>、したがって <b>E = K も一定</b>です。' +
    'グラフはどれも<b>水平な直線</b>になります。'
};

/* ============ 1-2 自由落下 ============ */
DEFS['m1-2'] = {
  id: 'm1-2', mode: 1, tab: '1-2 自由落下',
  title: '1-2　自由落下',
  sub: '手をはなすだけ（初速度 0）。はたらく力は<b>重力だけ</b>で、重力は<b>保存力</b>だから力学的エネルギーは保存される。' +
    '落ちるにつれて $U_g=mgh$ が減り、そのぶん $K=\\tfrac12mv^2$ が増える。<b>地面に着く直前の速さは $v=\\sqrt{2gh}$</b>。',
  /* 縮尺を 10 px ＝ 1 m に固定し、h を変えたら「絵の高さ」が変わるようにする
     （ch = 150 + 10h なので、手をはなす位置はいつも同じ高さ y = 104 に来る） */
  cw: 430,
  ch: function (v) { return Math.round(150 + 10 * v.h); },
  vis: ['F', 'V', 'A'],
  mainVars: ['h', 'm'],
  mainVarFocus: 'h',
  vars: [
    { k: 'h', label: '手をはなす高さ $h$', unit: ' m', min: 5, max: 20, step: 0.5, dec: 1, def: 12.0 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 5, step: 0.5, dec: 1, def: 1.0 }
  ],
  actions: [
    { label: '低くする（h＝6 m）', fn: function (s) { s.v.h = 6; },
      is: function (v) { return Math.abs(v.h - 6) < 1e-9; },
      next: function (s) { return s._played && Math.abs(s.v.h - 6) > 1e-9; } },
    { label: '重くする（m＝3 kg）', fn: function (s) { s.v.m = 3; },
      is: function (v) { return Math.abs(v.m - 3) < 1e-9; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.h = 12; s.v.m = 1; },
      is: function (v) { return Math.abs(v.h - 12) < 1e-9 && Math.abs(v.m - 1) < 1e-9; } }
  ],
  cons: true,
  forces: ['g'],
  hintFig: '<b>$U$ が減った分だけ $K$ が増える</b>（その和の $E$ は変わらない）',
  step1: '重力（保存力）だけが仕事をしている',
  datum: '地面',
  hint2: '<b>次は</b>：質量 $m$ を変えても<b>着地の速さが変わらない</b>ことを確かめよう（$m$ は両辺から消える）。',
  tEnd: function (v) { return P.m12.tEnd(v); },
  sample: function (v, t) { return P.m12.sample(v, t); },
  pts: [
    { name: 'A', jp: '手をはなす点', t: function () { return 0; }, sym: { K: '0', Ug: 'mgh' } },
    { name: 'B', jp: '地面', t: function (v) { return P.m12.tEnd(v); },
      sym: { K: '\\tfrac{1}{2}mv^2', Ug: '0' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m1-2'], v = V(s), m = d.sample(v, t);
    var sc = 10, gy = H - 46, topY = gy - v.h * sc, bx = W * 0.40;
    function Y(y) { return gy - y * sc; }
    var kz = mSize(d, v), r = 9 * kz;

    ground(ctx, 18, W - 96, gy);
    datumLine(ctx, 18, W - 96, gy, '基準面 h = 0', true);
    /* 運動が終わったら、点ごとの高さ（drawPts）に任せてこの1本は消す */
    if (!endOn(d, s, t)) heightDim(ctx, bx + 52, topY, gy, 'h = ' + fmt(v.h, 1) + ' m');
    ptMark(ctx, 'A', bx - 34, topY);
    ptMark(ctx, 'B', bx - 34, gy);

    /* 残像 */
    var i;
    for (i = 1; i * 0.2 < t - 1e-9; i++) ball(ctx, bx, Y(d.sample(v, i * 0.2).y), r, 'faint');

    var y = Y(m.y);
    ball(ctx, bx, y, r);

    /* 手をはなす（0.16 s で指をひらいて、すっと消える） */
    var hA = (t <= 0.16) ? 1 : Math.max(0, 1 - (t - 0.16) / 0.20);
    if (hA > 0.02) dropHand(ctx, bx, topY, 0.60, clamp(t / 0.16, 0, 1), hA);

    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 40 / mg;
    function fAt(ay) {
      arrow(ctx, bx, ay, bx, ay + mg * fs, 'force');
      label(ctx, 'mg', bx, ay + mg * fs + 11, { size: 11.5, color: COL.force });
    }
    if (s.o.showF) fAt(y);
    if (s.o.showV && m.v > 0.05) {
      /* 地面より下へ矢印がはみ出さないように、長さに頭を打たせる */
      var vl = Math.min(vArrowLen(m.v, Math.max(1, P.m12.vEnd(v)), 60), H - 18 - y);
      var va = velArrow(ctx, bx, y, 1, 0, 22, 0, 1, vl);
      label(ctx, 'v', va.x + 10, va.ty + 8, { align: 'left', size: 11.5, color: COL.vel });
    }
    if (s.o.showA) drawAcc(ctx, bx, y, 0, G, { nx: -1, ny: 0, off: 30 });
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    drawPts(ctx, d, s, t, function (p) {
      var yy = p.name === 'A' ? topY : gy;
      return { x: bx - 34, y: yy, ox: bx, oy: yy, r: r,
        fdraw: function () { fAt(yy); },
        vx: 0, vy: 1, vref: Math.max(1, P.m12.vEnd(v)), vk: 60, voff: r + 8, base: gy, hx: bx + 52 };
    });
  },
  resItems: function (v) {
    return [{ k: '着地の速さ（式 $\\sqrt{2gh}$）', v: fmt(P.m12.vEnd(v), 2) + ' m/s' }];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m1-2'].sample(v, t);
    return [
      ['落ちた距離', fmt(v.h - m.y, 2) + ' m'],
      ['重力 $mg$', fmt(v.m * G, 1) + ' N'],
      ['地面に着く時刻', fmt(P.m12.tEnd(v), 2) + ' s'],
      ['着地直前の速さ', fmt(P.m12.vEnd(v), 2) + ' m/s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return 'mgh = \\tfrac{1}{2}mv^2 \\;\\Rightarrow\\; v = \\sqrt{2gh} = ' +
      fmt(P.m12.vEnd(v), 2) + '\\ \\mathrm{m/s}';
  },
  note: '仕事をするのは<b>重力だけ</b>（保存力）。だから力学的エネルギーは保存されます。' +
    '$U_g=mgh$ が減った分がそのまま $K$ に変わるので、<b>K–t 図と U–t 図は上下対称</b>になり、' +
    '<b>E–t 図は水平</b>。式は $mgh=\\tfrac12mv^2$ で、両辺の $m$ が消えるので<b>着地の速さは質量によりません</b>。'
};

/* ============ 1-3 滑台（直線）1：すべり下りる ============ */
DEFS['m1-3'] = {
  id: 'm1-3', mode: 1, tab: '1-3 滑台（直線）1',
  title: '1-3　滑台（直線）1 — すべり下りる',
  sub: 'なめらかな斜面。<b>垂直抗力は運動の向きに垂直</b>なので仕事をしません。仕事をするのは重力だけ。' +
    'だから下端の速さは <b>$v=\\sqrt{2gh}$</b> で、<b>斜面の傾き $\\theta$ を変えても同じ</b>（かかる時間は変わります）。',
  cw: 580, ch: 290,        /* 第6回：吹きだしが「エネルギー」の字にかかるので少し広く */
  vis: ['F', 'Fc', 'V', 'A'],
  mainVars: ['th', 'h'],
  mainVarFocus: 'th',
  vars: [
    { k: 'th', label: '斜面の角 $\\theta$', unit: '°', min: 15, max: 75, step: 5, dec: 0, def: 30 },
    { k: 'h', label: '高さ $h$', unit: ' m', min: 1, max: 5, step: 0.5, dec: 1, def: 3.0 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 5, step: 0.5, dec: 1, def: 2.0 }
  ],
  actions: [
    { label: '急にする（θ＝60°）', fn: function (s) { s.v.th = 60; },
      is: function (v) { return v.th === 60; },
      next: function (s) { return s._played && s.v.th !== 60; } },
    { label: 'ゆるくする（θ＝15°）', fn: function (s) { s.v.th = 15; },
      is: function (v) { return v.th === 15; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.th = 30; s.v.h = 3; },
      is: function (v) { return v.th === 30 && Math.abs(v.h - 3) < 1e-9; } }
  ],
  cons: true,
  forces: ['g', 'N'],
  hintFig: '<b>垂直抗力は運動の向きに垂直 → 仕事をしない</b>。だから下端の速さは傾きによらず $\\sqrt{2gh}$',
  step1: '重力（保存力）だけが仕事をする。垂直抗力は運動の向きに垂直なので仕事をしない',
  datum: '地面（斜面の下端）',
  hint2: '<b>次は</b>：$\\theta$ を変えても<b>下端の速さが同じ</b>になることを確かめよう（かかる時間だけが変わります）。',
  tEnd: function (v) { return P.m13.tEnd(v); },
  sample: function (v, t) { return P.m13.sample(v, t); },
  pts: [
    { name: 'A', jp: '斜面の上', t: function () { return 0; }, sym: { K: '0', Ug: 'mgh' } },
    { name: 'B', jp: '一番下', t: function (v) { return P.m13.tEnd(v); },
      sym: { K: '\\tfrac{1}{2}mv^2', Ug: '0' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m1-3'], v = V(s), m = d.sample(v, t);
    var th = v.th * DEG, gy = H - 52;
    var run = v.h / Math.tan(th);
    /* ★縮尺は θ を変えても動かさない★（見どころは「下端の速さは θ によらない」）
       いちばん寝かせた坂（θ = 15°）でも収まる大きさにしておく。 */
    var runMax = v.h / Math.tan(15 * DEG);
    var sc = Math.min(SC_SLIDE, (W - 210) / Math.max(runMax, 0.4), (H - 118) / v.h);
    /* ★急な斜面（run が小さい）だと左すみに固まるので、横の中央に置く★ */
    var x0 = Math.max(92, 40 + ((W - 150) - run * sc) / 2);
    var TX = x0, TY = gy - v.h * sc, BX = x0 + run * sc, BY = gy;
    var ux = Math.cos(th), uy = Math.sin(th);        /* 斜面を下る向き（画面） */
    var nx = Math.sin(th), ny = -Math.cos(th);       /* 斜面から外向き（画面） */

    /* 斜面の板 */
    ctx.save();
    ctx.fillStyle = '#eef1f4';
    ctx.beginPath(); ctx.moveTo(TX, TY); ctx.lineTo(BX, BY); ctx.lineTo(TX, BY); ctx.closePath();
    ctx.fill();
    ctx.restore();
    hatchLine(ctx, TX, TY, BX, BY, 1);
    ctx.save();
    ctx.strokeStyle = '#98a0a8'; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(TX, TY); ctx.lineTo(TX, BY); ctx.stroke();
    ctx.restore();
    ground(ctx, 20, W - 96, gy);
    datumLine(ctx, 20, W - 96, gy, '基準面 h = 0', false, true);
    angArc(ctx, BX, BY, 32, -Math.PI, th - Math.PI, '', 0, 0);
    label(ctx, 'θ = ' + fmt(v.th, 0) + '°', BX - 46, gy - 13, { align: 'right', size: 12, color: COL.sub });
    /* 運動が終わったら、点ごとの高さ（drawPts）に任せてこの1本は消す */
    if (!endOn(d, s, t)) heightDim(ctx, 26, TY, gy, 'h = ' + fmt(v.h, 1) + ' m', TX, true);

    var kz = mSize(d, v), bw = 30 * kz, bh = 22 * kz;
    function pos(sv) { return { x: TX + ux * sv * sc, y: TY + uy * sv * sc }; }
    var pB = pos(P.m13.len(v));
    /* ★印は物体の「坂にそって外がわ」★（第6回）真上は N の矢印が通るのでずらす */
    var pA3 = { x: TX, y: TY };
    var mA3 = markAway(pA3, pB, nx, ny, bh / 2 + 4, bw / 2 + 14);
    var mB3 = markAway(pB, pA3, nx, ny, bh / 2 + 4, bw / 2 + 14);
    ptMark(ctx, 'A', mA3.x, mA3.y);
    ptMark(ctx, 'B', mB3.x, mB3.y);

    var i;
    for (i = 1; i * 0.2 < t - 1e-9; i++) {
      var q = pos(d.sample(v, i * 0.2).s);
      ctx.save(); ctx.globalAlpha = 0.26;
      blockShape(ctx, q.x + nx * bh / 2, q.y + ny * bh / 2, -th, bw, bh, '#f2f4f7');
      ctx.restore();
    }
    var p = pos(m.s), cx = p.x + nx * bh / 2, cy = p.y + ny * bh / 2;
    blockShape(ctx, cx, cy, -th, bw, bh, '#e8eef5');

    var hA = (t <= 0.16) ? 1 : Math.max(0, 1 - (t - 0.16) / 0.20);
    if (hA > 0.02) dropHand(ctx, TX + nx * 16 + 4, TY + ny * 16, 0.52, clamp(t / 0.16, 0, 1), hA);

    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 40 / mg;
    function fAt(sx, sy) {          /* sx, sy＝面に接している点 */
      var ax = sx + nx * bh / 2, ay = sy + ny * bh / 2;
      arrow(ctx, ax, ay, ax, ay + mg * fs, 'force');
      label(ctx, 'mg', ax, ay + mg * fs + 11, { size: 11.5, color: COL.force });
      var Nn = mg * Math.cos(th);
      arrow(ctx, sx, sy, sx + nx * Nn * fs, sy + ny * Nn * fs, 'force', 1, COL.norm);
      label(ctx, 'N', sx + nx * Nn * fs + 10, sy + ny * Nn * fs - 4, { align: 'left', size: 11.5, color: COL.norm });
    }
    if (s.o.showF) fAt(p.x, p.y);
    if (s.o.showFc) {
      var gs = mg * Math.sin(th), gc = mg * Math.cos(th);
      arrow(ctx, cx, cy, cx + ux * gs * fs, cy + uy * gs * fs, 'comp');
      label(ctx, 'mg sinθ', cx + ux * gs * fs + 6, cy + uy * gs * fs + 10, { align: 'left', size: 11, color: COL.force });
      arrow(ctx, cx, cy, cx - nx * gc * fs, cy - ny * gc * fs, 'comp');
      label(ctx, 'mg cosθ', cx - nx * gc * fs - 8, cy - ny * gc * fs + 12, { align: 'right', size: 11, color: COL.force });
    }
    if (s.o.showV && m.v > 0.05) {
      /* ★速度の矢印は物体から離して出す★（物体の上に重ねると読めない） */
      var vof = 34, vl = vArrowLen(m.v, Math.max(1, P.m13.vEnd(v)), 56);
      var va = velArrow(ctx, cx, cy, nx, ny, vof, ux, uy, vl);
      label(ctx, 'v', Math.min(va.tx + ux * 10, W - 104), Math.min(va.ty + uy * 10 - 8, gy - 16),
        { align: 'left', size: 11.5, color: COL.vel });
    }
    if (s.o.showA) {
      var aa = P.m13.a(v);          /* 斜面を下る向きに g sinθ */
      drawAcc(ctx, cx, cy, ux * aa, uy * aa, { nx: nx, ny: ny, off: 64 });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    drawPts(ctx, d, s, t, function (pt) {
      var q = (pt.name === 'A') ? { x: TX, y: TY } : pB, mk3 = (pt.name === 'A') ? mA3 : mB3;
      return { x: mk3.x, y: mk3.y,
        fdraw: function () { fAt(q.x, q.y); },
        ox: q.x + nx * bh / 2, oy: q.y + ny * bh / 2, bw: bw, bh: bh, ang: -th,
        vx: ux, vy: uy, vref: Math.max(1, P.m13.vEnd(v)), vk: 56, voff: 26, base: gy, hx: 26 };
    });
  },
  resItems: function (v) {
    return [
      { k: '斜面の長さ', v: fmt(P.m13.len(v), 2) + ' m' },
      { k: '下端の速さ（式 $\\sqrt{2gh}$）', v: fmt(P.m13.vEnd(v), 2) + ' m/s' }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m1-3'].sample(v, t);
    return [
      ['斜面にそって進んだ距離', fmt(m.s, 2) + ' m'],
      ['斜面方向の加速度 $g\\sin\\theta$', fmt(P.m13.a(v), 2) + ' m/s²'],
      ['垂直抗力 $N=mg\\cos\\theta$', fmt(v.m * G * Math.cos(v.th * DEG), 1) + ' N'],
      ['下まですべる時間', fmt(P.m13.tEnd(v), 2) + ' s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return 'mgh = \\tfrac{1}{2}mv^2 \\;\\Rightarrow\\; v = \\sqrt{2gh} = ' +
      fmt(P.m13.vEnd(v), 2) + '\\ \\mathrm{m/s}\\quad(\\theta \\text{ によらない})';
  },
  note: '斜面をすべっても、仕事をするのは<b>重力だけ</b>です（垂直抗力は運動の向きに垂直）。' +
    'だから $mgh=\\tfrac12mv^2$ が成り立ち、<b>下端の速さは傾きによらず $\\sqrt{2gh}$</b>。' +
    '$\\theta$ を変えると<b>かかる時間とグラフの横はば</b>だけが変わり、<b>E の高さは変わりません</b>。'
};

/* ============ 1-4 滑台（直線）2：斜面を昇る（新規） ============ */
DEFS['m1-4'] = {
  id: 'm1-4', mode: 1, tab: '1-4 滑台（直線）2',
  title: '1-4　滑台（直線）2 — 斜面を昇る',
  sub: 'なめらかな斜面の下から、<b>デコピンで初速度 $v_0$</b> を与えて昇らせます。' +
    '仕事をするのは重力だけ（垂直抗力は運動の向きに垂直）なので力学的エネルギーは保存され、' +
    '$\\tfrac12mv_0^{\\,2}=mgh$ から <b>上がる高さは $h=\\dfrac{v_0^{\\,2}}{2g}$</b>。' +
    '<b>斜面の角 $\\theta$ を変えても、上がる高さは変わりません</b>（斜面にそった距離は変わります）。',
  cw: 620, ch: 290,        /* 第9回：横をもっと使う */
  vis: ['F', 'Fc', 'V', 'A'],
  mainVars: ['v0', 'th'],
  mainVarFocus: 'th',
  vars: [
    { k: 'v0', label: 'はじめの速さ $v_0$', unit: ' m/s', min: 3, max: 8, step: 0.5, dec: 1, def: 6.0 },
    { k: 'th', label: '斜面の角 $\\theta$', unit: '°', min: 15, max: 75, step: 5, dec: 0, def: 30 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 5, step: 0.5, dec: 1, def: 2.0 }
  ],
  actions: [
    { label: '急にする（θ＝60°）', fn: function (s) { s.v.th = 60; },
      is: function (v) { return v.th === 60; },
      next: function (s) { return s._played && s.v.th !== 60; } },
    { label: 'ゆるくする（θ＝15°）', fn: function (s) { s.v.th = 15; },
      is: function (v) { return v.th === 15; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.v0 = 6; s.v.th = 30; },
      is: function (v) { return Math.abs(v.v0 - 6) < 1e-9 && v.th === 30; } }
  ],
  cons: true,
  forces: ['g', 'N'],
  hintFig: '<b>$\\theta$ を変えても、上がる高さ $h=v_0^{\\,2}/(2g)$ は変わらない</b>（斜面にそった距離は変わる）',
  step1: '重力（保存力）だけが仕事をする。垂直抗力は運動の向きに垂直なので仕事をしない',
  datum: '地面（斜面の下端）',
  hint2: '<b>次は</b>：$\\theta$ を変えても<b>上がる高さが同じ</b>になることを確かめよう（斜面にそった距離だけが変わります）。',
  tEnd: function (v) { return P.slopeUp.tEnd(v); },
  sample: function (v, t) { return P.slopeUp.sample(v, t); },
  pts: [
    { name: 'A', jp: 'スタート（下端）', t: function () { return 0; },
      sym: { K: '\\tfrac{1}{2}mv_0^{\\,2}', Ug: '0' } },
    { name: 'B', jp: '止まる位置', t: function (v) { return P.slopeUp.tEnd(v); },
      sym: { K: '0', Ug: 'mgh' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m1-4'], v = V(s), m = d.sample(v, t);
    var th = v.th * DEG, gy = H - 62;
    /* ★縮尺は θ を変えても動かさない★（この図の見どころは「上がる高さは θ によらない」）
       いちばん寝かせた坂（θ = 15°）でも横に収まる大きさにしておけば、
       θ をどう変えても縮尺は同じままで、高さをそのまま見くらべられる。
       ★第9回：右があきすぎていたので、余白を 250 → 176 px にして図を大きくした★ */
    var hTop = P.slopeUp.hTop(v), L = P.slopeUp.len(v);
    var run = L * Math.cos(th);
    var runMax = v.v0 * v.v0 / (2 * G * Math.tan(15 * DEG));   /* θ が最小のときの横はば */
    var sc = Math.min(SC_SLIDE, (W - 176) / Math.max(runMax, 0.4), (gy - 58) / Math.max(hTop, 0.3));
    var x0 = 96;
    var BX = x0, BY = gy, TX = x0 + run * sc, TY = gy - hTop * sc;
    var ux = Math.cos(th), uy = -Math.sin(th);       /* 斜面を昇る向き（画面） */
    var nx = -Math.sin(th), ny = -Math.cos(th);      /* 斜面から外向き（画面・上） */
    function pos(sv) { return { x: BX + ux * sv * sc, y: BY + uy * sv * sc }; }

    /* 斜面の板（下端が左、上が右） */
    ctx.save();
    ctx.fillStyle = '#eef1f4';
    ctx.beginPath(); ctx.moveTo(BX, BY); ctx.lineTo(TX, TY); ctx.lineTo(TX, BY); ctx.closePath();
    ctx.fill();
    ctx.restore();
    hatchLine(ctx, BX, BY, TX, TY, -1);
    ctx.save();
    ctx.strokeStyle = '#98a0a8'; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(TX, TY); ctx.lineTo(TX, BY); ctx.stroke();
    ctx.restore();
    ground(ctx, 20, W - 96, gy);
    datumLine(ctx, 20, W - 96, gy, '基準面 h = 0', true, true);
    angArc(ctx, BX, BY, 30, -th, 0, '', 0, 0);
    label(ctx, 'θ = ' + fmt(v.th, 0) + '°', BX + 44, gy - 12, { align: 'left', size: 12, color: COL.sub });

    var kz = mSize(d, v), bw = 30 * kz, bh = 22 * kz;
    var pA = pos(0), pB = pos(L);
    /* ★印は物体の「坂にそって外がわ」★（第6回） */
    var mA4 = markAway(pA, pB, nx, ny, bh / 2 + 4, bw / 2 + 14);
    var mB4 = markAway(pB, pA, nx, ny, bh / 2 + 4, bw / 2 + 14);
    ptMark(ctx, 'A', mA4.x, mA4.y);
    ptMark(ctx, 'B', mB4.x, mB4.y);

    var i;
    for (i = 1; i * 0.12 < t - 1e-9; i++) {
      var q = pos(d.sample(v, i * 0.12).s);
      ctx.save(); ctx.globalAlpha = 0.26;
      blockShape(ctx, q.x + nx * bh / 2, q.y + ny * bh / 2, th, bw, bh, '#f2f4f7');
      ctx.restore();
    }
    var p = pos(m.s), cx = p.x + nx * bh / 2, cy = p.y + ny * bh / 2;
    blockShape(ctx, cx, cy, th, bw, bh, '#e8eef5');
    /* 運動が終わったら、点ごとの高さ（drawPts）に任せてこの1本は消す */
    if (!endOn(d, s, t)) heightDim(ctx, 26, p.y, gy, 'h = ' + fmt(m.h, 2) + ' m', p.x, true);
    /* デコピンで打ち上げる（斜面の下から） */
    flickStart(ctx, t, v.v0, pA.x - ux * 22 + nx * bh / 2, pA.y - uy * 22 + ny * bh / 2, -th,
      118, 30);   /* 左は高さの寸法線、右上は坂。箱だけ右へ寄せる（しっぽは手の真上のまま） */
    /* ★いちばん高い所に「最高点」の吹きだし★（先生の指示・第13回）
       しっぽは下（＝その点をさす）。運動が終わってから出す。 */
    if (endOn(d, s, t)) ptNote(ctx, pB.x, pB.y, '最高点', '（点B）', { gap: 54 });

    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 34 / mg;
    function fAt(sx, sy) {
      var ax = sx + nx * bh / 2, ay = sy + ny * bh / 2;
      arrow(ctx, ax, ay, ax, ay + mg * fs, 'force');
      label(ctx, 'mg', ax, ay + mg * fs + 11, { size: 11.5, color: COL.force });
      var Nn = mg * Math.cos(th);
      arrow(ctx, sx, sy, sx + nx * Nn * fs, sy + ny * Nn * fs, 'force', 1, COL.norm);
      label(ctx, 'N', sx + nx * (Nn * fs + 12), sy + ny * (Nn * fs + 12),
        { size: 11.5, color: COL.norm });
    }
    if (s.o.showF) fAt(p.x, p.y);
    if (s.o.showFc) {
      var gs = mg * Math.sin(th);
      arrow(ctx, cx, cy, cx - ux * gs * fs, cy - uy * gs * fs, 'comp');
      label(ctx, 'mg sinθ', cx - ux * gs * fs - 6, cy - uy * gs * fs + 12,
        { align: 'right', size: 11, color: COL.force });
    }
    if (s.o.showV && m.v > 0.05) {
      var vof = 34, vl = vArrowLen(m.v, Math.max(1, v.v0), 50);
      var va = velArrow(ctx, cx, cy, nx, ny, vof, ux, uy, vl);
      label(ctx, 'v', va.tx + ux * 10, va.ty + uy * 10, { size: 11.5, color: COL.vel });
    }
    if (s.o.showA) {
      /* 加速度は斜面を下る向き（＝運動と逆）に g sinθ。だから減速する */
      var aa = P.slopeUp.a(v);
      drawAcc(ctx, cx, cy, -ux * aa, -uy * aa, { nx: nx, ny: ny, off: 64 });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    drawPts(ctx, d, s, t, function (pt) {
      var q = (pt.name === 'A') ? pA : pB, mk4 = (pt.name === 'A') ? mA4 : mB4;
      return { x: mk4.x, y: mk4.y,
        fdraw: function () { fAt(q.x, q.y); },
        ox: q.x + nx * bh / 2, oy: q.y + ny * bh / 2, bw: bw, bh: bh, ang: th,
        vx: ux, vy: uy, vref: Math.max(1, v.v0), vk: 50, voff: 26, base: gy, hx: 26 };
    });
  },
  resItems: function (v) {
    return [
      { k: '上がる高さ（式 $v_0^{\\,2}/2g$）', v: fmt(P.slopeUp.hTop(v), 2) + ' m' },
      { k: '斜面にそった距離 $L$', v: fmt(P.slopeUp.len(v), 2) + ' m' }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m1-4'].sample(v, t);
    return [
      ['斜面にそって進んだ距離', fmt(m.s, 2) + ' m'],
      ['斜面方向の加速度 $-g\\sin\\theta$', fmt(-P.slopeUp.a(v), 2) + ' m/s²'],
      ['垂直抗力 $N=mg\\cos\\theta$', fmt(v.m * G * Math.cos(v.th * DEG), 1) + ' N'],
      ['止まるまでの時間', fmt(P.slopeUp.tEnd(v), 2) + ' s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return '\\tfrac{1}{2}mv_0^{\\,2} = mgh \\;\\Rightarrow\\; h = \\dfrac{v_0^{\\,2}}{2g} = ' +
      fmt(P.slopeUp.hTop(v), 2) + '\\ \\mathrm{m}\\quad(\\theta \\text{ によらない})';
  },
  note: '1-3 の裏返しです。<b>はじめの運動エネルギーが、そっくり位置エネルギーに変わる</b>ところで止まります。' +
    '$\\tfrac12mv_0^{\\,2}=mgh$ の両辺から $m$ が消えるので、<b>上がる高さは質量にも斜面の角にもよりません</b>。' +
    '$\\theta$ を変えると<b>斜面にそった距離 $L=h/\\sin\\theta$ と、かかる時間</b>だけが変わります。'
};

/* ============ 1-5 滑台（曲線） ============ */
DEFS['m1-5'] = {
  id: 'm1-5', mode: 1, tab: '1-5 滑台（曲線）',
  title: '1-5　滑台（曲線）をすべり下りる',
  sub: '曲がっていても、面からの垂直抗力は<b>いつでも運動の向きに垂直</b>なので仕事をしません。' +
    'だから<b>斜面の形によらず</b> $mgh=\\tfrac12mv^2$ が成り立ち、下端の速さは 1-3 とまったく同じ $\\sqrt{2gh}$。',
  cw: 520, ch: 290,
  vis: ['F', 'V', 'A'],
  mainVars: ['h', 'm'],
  mainVarFocus: 'h',
  vars: [
    { k: 'h', label: '高さ $h$', unit: ' m', min: 1, max: 5, step: 0.5, dec: 1, def: 3.0 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 5, step: 0.5, dec: 1, def: 1.0 }
  ],
  actions: [
    { label: '高くする（h＝5 m）', fn: function (s) { s.v.h = 5; },
      is: function (v) { return Math.abs(v.h - 5) < 1e-9; },
      next: function (s) { return s._played && Math.abs(s.v.h - 5) > 1e-9; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.h = 3; s.v.m = 1; },
      is: function (v) { return Math.abs(v.h - 3) < 1e-9 && Math.abs(v.m - 1) < 1e-9; } }
  ],
  cons: true,
  forces: ['g', 'N'],
  hintFig: '<b>形がちがっても、同じ高さから出発すれば下端の速さは同じ</b>（$mgh=\\tfrac12mv^2$）',
  step1: '重力（保存力）だけが仕事をする。曲面でも垂直抗力は運動の向きに垂直',
  datum: '地面（曲面の下端）',
  hint2: '<b>次は</b>：<a href="#m1-3" data-goto="m1-3">1-3（直線の滑台）</a>と<b>同じ $h$</b> にして、下端の速さをくらべてみよう。',
  tEnd: function (v) { return P.m14.tEnd(v); },
  sample: function (v, t) { return P.m14.sample(v, t); },
  pts: [
    { name: 'A', jp: '曲面の上', t: function () { return 0; }, sym: { K: '0', Ug: 'mgh' } },
    { name: 'B', jp: '一番下', t: function (v) { return P.m14.tEnd(v); },
      sym: { K: '\\tfrac{1}{2}mv^2', Ug: '0' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m1-5'], v = V(s), m = d.sample(v, t), L = P.m14.L;
    var gy = H - 52, x0 = 92;      /* 左に高さの寸法を置くぶんの余白 */
    var sc = Math.min(SC_SLIDE, (W - 230) / L, (H - 118) / v.h);
    function X(x) { return x0 + x * sc; }
    function Y(y) { return gy - y * sc; }
    var o = P.m14.table(v), cv = o.cv, i, q;

    /* 曲面 */
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(X(0), Y(v.h));
    for (i = 1; i <= 80; i++) {
      var xx = L * i / 80;
      ctx.lineTo(X(xx), Y(v.h * (1 - xx / L) * (1 - xx / L)));
    }
    ctx.lineTo(X(0), Y(0)); ctx.closePath();
    ctx.fillStyle = '#eef1f4'; ctx.fill();
    ctx.strokeStyle = '#333'; ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(X(0), Y(v.h));
    for (i = 1; i <= 80; i++) {
      var x2 = L * i / 80;
      ctx.lineTo(X(x2), Y(v.h * (1 - x2 / L) * (1 - x2 / L)));
    }
    ctx.stroke();
    ctx.restore();
    ground(ctx, 20, W - 96, gy);
    datumLine(ctx, 20, W - 96, gy, '基準面 h = 0', false, true);
    /* 運動が終わったら、点ごとの高さ（drawPts）に任せてこの1本は消す */
    if (!endOn(d, s, t)) heightDim(ctx, 26, Y(v.h), gy, 'h = ' + fmt(v.h, 1) + ' m', X(0), true);
    /* ★印は球と力の矢印からずらす★（第6回）B は真下に mg が通るので、右へずらす */
    ptMark(ctx, 'A', X(0), Y(v.h) - 14);
    ptMark(ctx, 'B', X(L) + 22, gy + 14);

    var kz = mSize(d, v), r = 9 * kz;
    for (i = 1; i * 0.2 < t - 1e-9; i++) {
      q = d.sample(v, i * 0.2);
      ball(ctx, X(q.x), Y(q.y) - r, r, 'faint');
    }
    var px = X(m.x), py = Y(m.y) - r;
    ball(ctx, px, py, r);

    var hA = (t <= 0.16) ? 1 : Math.max(0, 1 - (t - 0.16) / 0.20);
    if (hA > 0.02) dropHand(ctx, X(0), Y(v.h) - r, 0.52, clamp(t / 0.16, 0, 1), hA);

    var mg = v.m * G, fs = 40 / mg;
    var dyds = m.dyds || 0, tx = Math.sqrt(Math.max(0, 1 - dyds * dyds));
    /* 世界座標での外向き法線は (−dy/ds, dx/ds)。画面は y が下向きなので (−dy/ds, −dx/ds) */
    var nx = -dyds, ny = -tx;
    var nl = Math.hypot(nx, ny) || 1; nx /= nl; ny /= nl;
    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    function fAt(qq, ax, ay) {              /* ax, ay＝球の中心 */
      var dd = qq.dyds || 0, tt = Math.sqrt(Math.max(0, 1 - dd * dd));
      var n2x = -dd, n2y = -tt, n2l = Math.hypot(n2x, n2y) || 1;
      n2x /= n2l; n2y /= n2l;
      arrow(ctx, ax, ay, ax, ay + mg * fs, 'force');
      label(ctx, 'mg', ax, ay + mg * fs + 11, { size: 11.5, color: COL.force });
      var Nn = mg * tt;                       /* N = mg cosθ（速さが変わるので目安） */
      arrow(ctx, ax, ay + r, ax + n2x * Nn * fs, ay + r + n2y * Nn * fs, 'force', 1, COL.norm);
      label(ctx, 'N', ax + n2x * Nn * fs + 10, ay + r + n2y * Nn * fs - 4,
        { align: 'left', size: 11.5, color: COL.norm });
    }
    if (s.o.showF) fAt(m, px, py);
    var vx = tx, vy = -dyds;                /* 進む向き（画面。y は下向きが正） */
    if (s.o.showV && m.v > 0.05) {
      /* ★物体から離して出す★（上に 26 px ずらしてから進む向きへ） */
      var vl = vArrowLen(m.v, Math.max(1, P.m14.vEnd(v)), 56);
      var va = velArrow(ctx, px, py, nx, ny, 26, vx, vy, vl);
      label(ctx, 'v', va.tx + vx * 10, va.ty + vy * 10, { size: 11.5, color: COL.vel });
    }
    if (s.o.showA) {
      /* 加速度＝重力＋垂直抗力（合力）／m。曲面では接線方向と向心方向の和になる */
      var Na = mg * tx, ax = nx * Na / v.m, ay = G + ny * Na / v.m;
      drawAcc(ctx, px, py, ax, ay, { nx: nx, ny: ny, off: 56 });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    drawPts(ctx, d, s, t, function (p) {
      var A = (p.name === 'A');
      /* A では曲面の接線が水平（dy/dx = −2h/L）なので、速度の向きは点ごとに出す */
      var q = d.sample(v, p.t), dq = q.dyds || 0, tq = Math.sqrt(Math.max(0, 1 - dq * dq));
      return { x: A ? X(0) : X(L) + 22, y: A ? Y(v.h) - 14 : gy + 14,
        ox: A ? X(0) : X(L), oy: (A ? Y(v.h) : gy) - r, r: r,
        fdraw: function () { fAt(q, A ? X(0) : X(L), (A ? Y(v.h) : gy) - r); },
        vx: tq, vy: -dq, vref: Math.max(1, P.m14.vEnd(v)), vk: 56, voff: r + 10, base: gy, hx: 26 };
    });
  },
  resItems: function (v) {
    return [{ k: '下端の速さ（式 $\\sqrt{2gh}$）', v: fmt(P.m14.vEnd(v), 2) + ' m/s' }];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m1-5'].sample(v, t);
    return [
      ['曲面にそって進んだ距離', fmt(m.s, 2) + ' m'],
      ['いまの高さ', fmt(m.h, 2) + ' m'],
      ['下まですべる時間', fmt(P.m14.tEnd(v), 2) + ' s'],
      ['下端の速さ', fmt(P.m14.vEnd(v), 2) + ' m/s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return 'mgh = \\tfrac{1}{2}mv^2 \\;\\Rightarrow\\; v = \\sqrt{2gh} = ' +
      fmt(P.m14.vEnd(v), 2) + '\\ \\mathrm{m/s}\\quad(\\text{曲面の形によらない})';
  },
  note: '曲面の傾きは場所ごとに変わりますが、<b>垂直抗力はいつでも運動の向きに垂直</b>なので、' +
    'やはり仕事をしません。だから力学的エネルギーは保存され、<b>下端の速さは 1-3 とぴったり同じ</b>になります。' +
    'この図の運動は式では書けないので<b>数値計算</b>で動かしていますが、' +
    'エネルギーの<b>答えは式（$\\sqrt{2gh}$）から</b>出しています。'
};

/* ============ 1-6 振り子 ============ */
DEFS['m1-6'] = {
  id: 'm1-6', mode: 1, tab: '1-6 振り子',
  title: '1-6　振り子',
  sub: '糸の張力は<b>いつでも運動の向きに垂直</b>（円の中心を向く）なので仕事をしません。仕事をするのは重力だけ。' +
    'だから<b>最下点で $K$ が最大・最高点で $U$ が最大</b>になり、和の $E$ はずっと一定です。',
  /* 縮尺は 115 px ＝ 1 m に固定（ch = 108 + 115l なので、最下点の下の余白はいつも 54 px） */
  cw: 580,                 /* 第8回：各点に力の矢印も出すので、吹きだしの逃げ場を広げた */
  /* 第14回：最下点の下に「最下点（点C…B）」の吹きだしを置くぶん、54 px 高くした */
  ch: function (v) { return Math.round(186 + 105 * v.l); },
  vis: ['F', 'Fc', 'V', 'A'],
  mainVars: ['th', 'v0'],
  mainVarFocus: 'th',
  vars: [
    { k: 'th', label: 'はじめの角 $\\theta$', unit: '°', min: 10, max: 75, step: 5, dec: 0, def: 40 },
    { k: 'v0', label: 'はじめの速さ $v_0$', unit: ' m/s', min: 0, max: 3, step: 0.1, dec: 1, def: 0.0 },
    { k: 'l', label: '糸の長さ $l$', unit: ' m', min: 0.6, max: 1.6, step: 0.1, dec: 1, def: 1.0 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 5, step: 0.5, dec: 1, def: 1.0 }
  ],
  actions: [
    { label: '大きく振る（θ＝70°）', fn: function (s) { s.v.th = 70; },
      is: function (v) { return v.th === 70; },
      next: function (s) { return s._played && s.v.th !== 70; } },
    { label: '初速度をつける（v₀＝2 m/s）', fn: function (s) { s.v.v0 = 2; },
      is: function (v) { return Math.abs(v.v0 - 2) < 1e-9; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.th = 40; s.v.v0 = 0; },
      is: function (v) { return v.th === 40 && Math.abs(v.v0) < 1e-9; } }
  ],
  cons: true,
  forces: ['g', 'T'],
  hintFig: '<b>糸の張力は運動の向きに垂直 → 仕事をしない</b>。最下点で $K$ が最大、両はしで $U$ が最大',
  step1: '重力（保存力）だけが仕事をする。糸の張力は運動の向きに垂直なので仕事をしない',
  datum: '最下点',
  hint2: '<b>次は</b>：$\\theta$ を変えて、<b>最下点の速さ $v=\\sqrt{2gl(1-\\cos\\theta)}$</b> がどう変わるか確かめよう。',
  tEnd: function (v) { return P.m15.tEnd(v); },
  sample: function (v, t) { return P.m15.sample(v, t); },
  pts: [
    { name: 'A', jp: 'はじめの位置', t: function () { return 0; },
      sym: { K: '\\tfrac{1}{2}mv_0^{\\,2}', Ug: 'mgl(1-\\cos\\theta)' } },
    { name: 'B', jp: '最下点', t: function (v) { return P.m15.tBottom(v); },
      sym: { K: '\\tfrac{1}{2}mv^2', Ug: '0' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m1-6'], v = V(s), m = d.sample(v, t);
    var sc = 105, ox = W * 0.42, oy = 54, Lp = v.l * sc;
    var by = oy + Lp;                                   /* 最下点の高さ */
    function pos(th) { return { x: ox + Math.sin(th) * Lp, y: oy + Math.cos(th) * Lp }; }
    var o = P.m15.table(v), thT = o.thT;
    var kz = mSize(d, v), r = 10 * kz;

    /* 天井 */
    hatchLine(ctx, ox - 52, oy, ox + 52, oy, -1);
    /* 通る道すじ（うすい破線） */
    ctx.save();
    ctx.strokeStyle = '#c3cbd3'; ctx.lineWidth = 1.2; ctx.setLineDash([5, 5]);
    ctx.beginPath();
    ctx.arc(ox, oy, Lp, Math.PI / 2 - thT, Math.PI / 2 + thT);
    ctx.stroke();
    ctx.restore();
    datumLine(ctx, Math.max(16, ox - Lp - 20), W - 96, by, '基準面（最下点）h = 0', true, true);

    var pA = pos(v.th * DEG), pB = pos(0);
    /* 印はおもりの外がわ（支点から遠いほう）に置く。おもりが来てもかくれない */
    function outer(p2) {
      var dx = p2.x - ox, dy = p2.y - oy, L2 = Math.hypot(dx, dy) || 1;
      return { x: p2.x + dx / L2 * 30, y: p2.y + dy / L2 * 30 };
    }
    var mA = outer(pA), mB = outer(pB);
    ptMark(ctx, 'A', mA.x, mA.y);
    ptMark(ctx, 'B', mB.x, mB.y);
    /* ★いちばん低い所に「最下点（点B）」の吹きだし★（先生の指示・第14回）
       しっぽは上向き（箱は下）。運動が終わってから出す。 */
    if (endOn(d, s, t)) ptNote(ctx, pB.x, pB.y, '最下点', '（点B）', { below: true, gap: 62 });

    /* 角 θ */
    ctx.save();
    ctx.strokeStyle = '#c3cbd3'; ctx.lineWidth = 1.1; ctx.setLineDash([4, 4]);
    ctx.beginPath(); ctx.moveTo(ox, oy); ctx.lineTo(ox, by + 8); ctx.stroke();
    ctx.restore();
    var thNow = m.th;
    if (Math.abs(thNow) > 0.03) {
      var a1 = Math.PI / 2, a2 = Math.PI / 2 - thNow;
      var ar = Math.min(40, Lp * 0.42);          /* 糸が短いときは弧も小さくする */
      angArc(ctx, ox, oy, ar, Math.min(a1, a2), Math.max(a1, a2),
        'θ = ' + fmt(Math.abs(thNow) / DEG, 0) + '°', (a1 + a2) / 2, ar + 18);
    }

    /* 糸とおもり */
    var p = pos(thNow);
    string(ctx, ox, oy, p.x, p.y);
    /* ★式の $l$（糸の長さ）が図のどこかを見せる★（先生の指示・第12回）
       $U_g = mgl(1-\cos\theta)$ の $l$。糸のわきに、ふれている側へ少しずらして書く。 */
    var lsg = (thNow >= 0) ? 1 : -1;
    label(ctx, 'l = ' + fmt(v.l, 1) + ' m',
      ox + Math.sin(thNow) * Lp * 0.80 + Math.cos(thNow) * lsg * 24,
      oy + Math.cos(thNow) * Lp * 0.80 - Math.sin(thNow) * lsg * 24,
      { size: 11.5, color: COL.dim });
    ctx.save(); ctx.fillStyle = '#5b6672';
    ctx.beginPath(); ctx.arc(ox, oy, 3.4, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    ball(ctx, p.x, p.y, r);
    /* 高さの寸法は左はしに固定して、おもりまで引き出し線でつなぐ
       （おもりのそばに置くと、mg や θ の文字と必ずぶつかる） */
    /* 運動が終わったら、点ごとの高さ（drawPts）に任せてこの1本は消す */
    if (!endOn(d, s, t)) heightDim(ctx, 26, p.y, by, 'h = ' + fmt(m.h, 2) + ' m', p.x, true);

    var hA = (t <= 0.18) ? 1 : Math.max(0, 1 - (t - 0.18) / 0.22);
    if (hA > 0.02 && v.v0 < 0.05) dropHand(ctx, pA.x, pA.y, 0.52, clamp(t / 0.18, 0, 1), hA);

    /* 張力は最下点で mg(3−2cosθ_t) まで大きくなる。矢印が糸より長くならないように縮尺を決める */
    var mg = v.m * G, Tmax = mg * (3 - 2 * Math.cos(thT));
    var fs = Math.min(42 / mg, Lp * 0.72 / Tmax);
    var rx = (ox - p.x), ry = (oy - p.y), rl = Math.hypot(rx, ry) || 1;
    rx /= rl; ry /= rl;                                  /* おもり → 支点（張力の向き） */
    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    function fAt(qq, ax, ay, th2) {
      var r2x = (ox - ax), r2y = (oy - ay), r2l = Math.hypot(r2x, r2y) || 1;
      r2x /= r2l; r2y /= r2l;
      arrow(ctx, ax, ay, ax, ay + mg * fs, 'force');
      label(ctx, 'mg', ax, ay + mg * fs + 11, { size: 11.5, color: COL.force });
      var T = mg * Math.cos(th2) + v.m * qq.v * qq.v / v.l;     /* 張力（円運動の式） */
      arrow(ctx, ax, ay, ax + r2x * T * fs, ay + r2y * T * fs, 'force', 1, COL.hand);
      /* S の文字は「糸の、角 θ とは反対がわ」に置く（θ の文字とぶつからないように） */
      var sg2 = (th2 >= 0) ? 1 : -1;
      label(ctx, 'S', ax + r2x * T * fs - r2y * 13 * sg2, ay + r2y * T * fs + r2x * 13 * sg2,
        { size: 11.5, color: COL.hand });
    }
    if (s.o.showF) fAt(m, p.x, p.y, thNow);
    if (s.o.showFc) {
      var gt = mg * Math.sin(thNow), gr = mg * Math.cos(thNow);
      var tx2 = -ry, ty2 = rx;                            /* 接線の向き（円の接線） */
      arrow(ctx, p.x, p.y, p.x - tx2 * gt * fs, p.y - ty2 * gt * fs, 'comp');
      label(ctx, 'mg sinθ', p.x - tx2 * gt * fs, p.y - ty2 * gt * fs + 14, { size: 11, color: COL.force });
      arrow(ctx, p.x, p.y, p.x - rx * gr * fs, p.y - ry * gr * fs, 'comp');
      label(ctx, 'mg cosθ', p.x - rx * gr * fs + 4, p.y - ry * gr * fs + 12, { align: 'left', size: 11, color: COL.force });
    }
    var sg = m.om > 0 ? 1 : -1, vux = -ry * sg, vuy = rx * sg;   /* 進む向き（接線） */
    if (s.o.showV && m.v > 0.05) {
      /* ★物体から離して出す★ 糸と反対がわ（外向き）へ 26 px ずらしてから接線方向へ */
      var vl = vArrowLen(m.v, Math.max(0.5, P.m15.vBottom(v)), 54);
      var va = velArrow(ctx, p.x, p.y, -rx, -ry, 26, vux, vuy, vl);
      label(ctx, 'v', va.tx + vux * 10, va.ty + vuy * 10, { size: 11.5, color: COL.vel });
    }
    if (s.o.showA) {
      /* 加速度＝接線方向 −g sinθ ＋ 向心方向 v²/l */
      var at = -G * Math.sin(thNow), an = m.v * m.v / v.l;
      var ax = (-ry) * at + rx * an, ay = rx * at + ry * an;
      /* 真下は mg の矢印と字が通るので、進む向きと反対がわへ横にずらす */
      /* 下は mg と点の印、上はひもと S が通る。外がわの斜め上があいている */
      drawAcc(ctx, p.x, p.y, ax, ay,
        { nx: (rx >= 0 ? 1 : -1), ny: -0.55, off: 58, max: 56 });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    drawPts(ctx, d, s, t, function (pt) {
      var A = (pt.name === 'A');
      var pp = A ? pA : pB, mm = A ? mA : mB;
      /* その点での接線の向き（A は折り返しなので速度 0＝矢印は出ない） */
      var qq = d.sample(v, pt.t);
      var ex = pp.x - ox, ey = pp.y - oy, el = Math.hypot(ex, ey) || 1;
      var sg2 = qq.om > 0 ? 1 : -1;
      return { x: mm.x, y: mm.y, ox: pp.x, oy: pp.y, r: r,
        /* 時刻はちがっても場所が同じ（1周期でもどる）ときは、本物にまかせる */
        here: (Math.abs(pp.x - p.x) < 1.5 && Math.abs(pp.y - p.y) < 1.5),
        fdraw: function () { fAt(qq, pp.x, pp.y, qq.th); },
        vx: (ey / el) * sg2, vy: (-ex / el) * sg2, vref: Math.max(0.5, P.m15.vBottom(v)), vk: 54, voff: r + 12,
        base: by, hx: 26 };
    });
  },
  resItems: function (v) {
    return [{ k: '最下点の速さ（式）', v: fmt(P.m15.vBottom(v), 2) + ' m/s' }];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m1-6'].sample(v, t);
    return [
      ['いまの角 $\\theta$', fmt(m.th / DEG, 1) + '°'],
      ['折り返しの角', fmt(P.m15.thTurn(v) / DEG, 1) + '°'],
      ['最下点に来る時刻', fmt(P.m15.tBottom(v), 2) + ' s'],
      ['1往復の時間（周期）', fmt(P.m15.tEnd(v), 2) + ' s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return '\\tfrac{1}{2}mv_0^{\\,2} + mgl(1-\\cos\\theta) = \\tfrac{1}{2}mv^2 \\;\\Rightarrow\\; v = ' +
      fmt(P.m15.vBottom(v), 2) + '\\ \\mathrm{m/s}';
  },
  note: 'おもりにはたらく力は<b>重力と糸の張力</b>。張力はいつも円の中心を向いていて<b>運動の向きに垂直</b>' +
    'なので仕事をしません。だから力学的エネルギーは保存され、$v_0=0$ のときの最下点の速さは ' +
    '<b>$v=\\sqrt{2gl(1-\\cos\\theta)}$</b>。<b>最下点で K が最大・両はしで U が最大</b>になり、' +
    'E–t 図は水平のままです。'
};

/* ============ 1-7 ジェットコースター（★第5回で作り直し★） ============ */
DEFS['m1-7'] = {
  id: 'm1-7', mode: 1, tab: '1-7 ジェットコースター',
  title: '1-7　ジェットコースター（ループと斜面）',
  sub: 'なめらかな軌道。水平面を速さ $v_0$ で走ってきて、<b>鉛直な円（ループ）</b>を1周し、' +
    'そのあと斜面を昇って止まります（C）。<b>そこで終わりではありません。</b>' +
    'なめらかなので、そこから<b>もどってきて、ループをもう一度くぐり、' +
    'スタート地点 A に速さ $v_0$ で帰ってきます</b>。仕事をするのは<b>重力（保存力）だけ</b>' +
    '（垂直抗力はいつも運動の向きと垂直）。だから <b>$E = K + U$ は一定</b>です。',
  cw: 720, ch: 356,
  vis: ['F', 'V', 'A'],
  mainVars: ['v0', 'th'],
  mainVarFocus: 'th',
  vars: [
    { k: 'v0', label: 'はじめの速さ $v_0$', unit: ' m/s', min: 14, max: 16, step: 0.5, dec: 1, def: 14.0 },
    { k: 'th', label: '斜面の角 $\\theta$', unit: '°', min: 35, max: 60, step: 5, dec: 0, def: 35 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 100, max: 500, step: 100, dec: 0, def: 200 }
  ],
  /* 第9回：はじめの斜面の角を 35° にした（ゆるい斜面のほうが図が広く使える） */
  actions: [
    { label: '斜面を急にする（θ＝60°）', fn: function (s) { s.v.th = 60; },
      is: function (v) { return v.th === 60; },
      next: function (s) { return s._played && s.v.th !== 60; } },
    { label: '速くする（v₀＝16 m/s）', fn: function (s) { s.v.v0 = 16; },
      is: function (v) { return Math.abs(v.v0 - 16) < 1e-9; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.th = 35; s.v.v0 = 14; },
      is: function (v) { return v.th === 35 && Math.abs(v.v0 - 14) < 1e-9; } }
  ],
  cons: true,
  forces: ['g', 'N'],
  hintFig: '<b>止まる高さ $h_C = v_0^{\\,2}/(2g)$ は、斜面の角 $\\theta$ を変えても同じ</b>',
  step1: '重力（保存力）だけが仕事をする。垂直抗力はいつも運動の向きと垂直',
  datum: '水平面（レールの高さ）',
  hint2: '<b>次は</b>：$\\theta$ を変えて、<b>止まる高さが変わらない</b>ことを確かめよう。' +
    '$v_0$ を変えると高さはどう変わる？',
  ptSide: 'row',
  tEnd: function (v) { return P.coaster.tEnd(v); },
  sample: function (v, t) { return P.coaster.sample(v, t); },
  pts: [
    { name: 'A', jp: 'スタート（水平面）', t: function () { return 0; },
      sym: { K: '\\tfrac{1}{2}mv_0^{\\,2}', Ug: '0' } },
    { name: 'B', jp: 'ループの頂上', t: function (v) { return P.coaster.tB(v); },
      hsym: 'D',                       /* ★式と図で同じ記号を使う★（第12回） */
      sym: { K: '\\tfrac{1}{2}mv_B^{\\,2}', Ug: 'mgD' } },
    { name: 'C', jp: '止まる所（最高点）', t: function (v) { return P.coaster.tTop(v); },
      hsym: 'h_C',
      sym: { K: '0', Ug: 'mgh_C' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m1-7'], v = V(s), m = d.sample(v, t);
    /* ★縮尺は固定★ 自動にすると θ で絵の大きさが変わって
       「止まる高さは θ によらない」ことが伝わらない */
    var SC = SC_COAST, gy = H - 56 - PTBAND, x0 = 95, R = P.coaster.R(), L1 = P.coaster.L1, L2 = P.coaster.L2;
    function X(x) { return x0 + x * SC; }
    function Y(y) { return gy - y * SC; }
    var th = v.th * DEG, hC = P.coaster.hC(v), run = P.coaster.runC(v);

    /* レール（水平面 → ループ → 水平面 → 斜面） */
    ctx.save();
    ctx.strokeStyle = '#6b7683'; ctx.lineWidth = 3.2; ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(X(0), Y(0));
    /* 床 → 斜面のつけ根のまるみ → 斜面（経路の at() をそのままなぞる） */
    var sF = L1 + P.coaster.loopLen() + L2, sMaxDraw = P.coaster.sEnd(v) * 1.05, iq;
    ctx.lineTo(X(L1 + L2), Y(0));
    for (iq = 1; iq <= 60; iq++) {
      var pq = P.coaster.at(sF + (sMaxDraw - sF) * iq / 60, v.th);
      ctx.lineTo(X(pq.x), Y(pq.y));
    }
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(X(L1), Y(R), R * SC, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
    /* 地面 */
    ground(ctx, 20, W - 96, gy + 4);
    /* ★吹きだしの帯（地面の下）に文字を置かない★ 基準面の文字は線の上・右のはしに出す（第6回）
       左のはしだと、高さの寸法線と A の印がならぶところにぶつかる。 */
    datumLine(ctx, 20, W - 96, gy, '基準面 h = 0', true, false);

    /* ループの直径は、円の「まん中」に書く（左に置くと高さの寸法線とぶつかる） */
    /* 第12回：点 B の高さの寸法も「D = …」と出るので、こちらは「直径」と書き分ける */
    label(ctx, '直径 D = ' + fmt(P.coaster.D, 1) + ' m', X(L1), Y(R), { size: 11.5, color: COL.sub });

    var kz = mSize(d, v), cw2 = 26 * kz, chh = 18 * kz;
    var qC = P.coaster.at(P.coaster.sEnd(v), v.th);
    var pA = { x: X(0), y: Y(0) }, pB = { x: X(L1), y: Y(2 * R) };
    var pC = { x: X(qC.x), y: Y(qC.y) };
    /* ★印は車と矢印からずらす★（第6回）
       A は車の左、B はループの頂上の左（真上は速度ベクトルが通る）、
       C は斜面の「下がわ」（上がわは車と N の矢印） */
    ptMark(ctx, 'A', pA.x - cw2 / 2 - 13, pA.y - chh / 2);
    ptMark(ctx, 'B', pB.x - 34, pB.y - 4);
    ptMark(ctx, 'C', pC.x + Math.sin(th) * 18, pC.y + Math.cos(th) * 18);
    /* ★いちばん高い所に「最高点（点C）」の吹きだし★（先生の指示・第14回） */
    if (endOn(d, s, t)) ptNote(ctx, pC.x, pC.y, '最高点', '（点C）', { gap: 46 });

    /* 車（軌道の内がわに乗る） */
    var carAng = (m.seg === 1 || m.seg === 3) ? m.ang : (m.seg === 4 ? th : 0);
    /* 軌道から内向き（画面の向き）。ループの中では上下がひっくり返る */
    var nx = -Math.sin(carAng), ny = -Math.cos(carAng);
    var cx = X(m.x) + nx * chh / 2, cy = Y(m.y) + ny * chh / 2;
    coasterCar(ctx, cx, cy, carAng, kz);
    /* ★スタートはデコピン★（第9回・先生の指示）走ってきたのではなく、はじいて動き出す */
    flickStart(ctx, t, v.v0, X(0) - cw2 / 2 - 44, Y(0) - chh / 2, 0, 74);
    if (!endOn(d, s, t)) heightDim(ctx, 20, Y(m.y), gy, 'h = ' + fmt(m.h, 2) + ' m', cx, true);

    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 30 / mg, N = P.coaster.Nof(v, m);
    function fAt(qq, sx, sy, ang3) {
      var n3x = -Math.sin(ang3), n3y = -Math.cos(ang3);
      var ax = sx + n3x * chh / 2, ay = sy + n3y * chh / 2;
      arrow(ctx, ax, ay, ax, ay + mg * fs, 'force');
      label(ctx, 'mg', ax, ay + mg * fs + 11, { size: 11.5, color: COL.force });
      var nl = clamp(P.coaster.Nof(v, qq) * fs, 6, 74);
      arrow(ctx, sx, sy, sx + n3x * nl, sy + n3y * nl, 'force', 1, COL.norm);
      label(ctx, 'N', sx + n3x * (nl + 12), sy + n3y * (nl + 12),
        { size: 11.5, color: COL.norm });
    }
    if (s.o.showF) fAt(m, X(m.x), Y(m.y), carAng);
    if (s.o.showV && m.v > 0.05) {
      /* ★物体から離して出す★（軌道の内向きに 30 px ずらしてから進む向きへ） */
      var ux = Math.cos(carAng), uy = -Math.sin(carAng);
      if (m.back) { ux = -ux; uy = -uy; }        /* 帰り道は進む向きが逆（第18回） */
      var vl = vArrowLen(m.v, 16, 46);
      var va = velArrow(ctx, cx, cy, nx, ny, 30, ux, uy, vl);
      label(ctx, 'v', va.tx + ux * 10, va.ty + uy * 10, { size: 11.5, color: COL.vel });
    }
    if (s.o.showA) {
      /* 軌道にそった加速度（重力の接線成分）。ループの上は向心加速度も大きいが、
         ここでは「速さの変わり方」を見せたいので接線成分だけを描く */
      var at = -G * m.dyds;
      drawAcc(ctx, cx, cy, Math.cos(carAng) * at, -Math.sin(carAng) * at,
        { nx: -nx, ny: -ny, off: 46, max: 58 });
    }
    if (hintOn(s, t)) {
      ctx.save();
      ctx.strokeStyle = fade(COL.dim, 0.55); ctx.lineWidth = 1.2; ctx.setLineDash([5, 4]);
      ctx.beginPath(); ctx.moveTo(X(L1), Y(hC)); ctx.lineTo(pC.x + 14, Y(hC)); ctx.stroke();
      ctx.restore();
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    ptRow(gy + 30);                   /* 吹きだしは地面の下に1列でならべる */
    drawPts(ctx, d, s, t, function (p, mm, i2) {
      var q = (p.name === 'A') ? pA : (p.name === 'B' ? pB : pC);
      var nx2 = 0, ny2 = -1, ang2 = 0;
      if (p.name === 'B') { nx2 = 0; ny2 = 1; ang2 = Math.PI; }
      if (p.name === 'C') { ang2 = qC.ang; nx2 = -Math.sin(ang2); ny2 = -Math.cos(ang2); }
      var ux2 = Math.cos(ang2), uy2 = -Math.sin(ang2);
      /* 引き出し先は「印を置いた所」。高いほうの寸法線を外（左）にして、線どうしを離す */
      var mk = (p.name === 'A') ? { x: q.x - cw2 / 2 - 13, y: q.y - chh / 2 }
        : (p.name === 'B' ? { x: q.x - 34, y: q.y - 4 }
        : { x: q.x + Math.sin(th) * 18, y: q.y + Math.cos(th) * 18 });
      return { x: mk.x, y: mk.y, ox: q.x + nx2 * chh / 2, oy: q.y + ny2 * chh / 2,
        fdraw: function () { fAt(d.sample(v, p.t), q.x, q.y, (p.name === 'B') ? Math.PI : ang2); },
        bw: cw2, bh: chh, ang: (p.name === 'B') ? 0 : ang2,
        vx: (p.name === 'B') ? -1 : ux2, vy: (p.name === 'B') ? 0 : uy2,
        vref: 16, vk: 46, voff: 26, base: gy, hx: 20 + (2 - i2) * 26 };
    });
  },
  resItems: function (v) {
    return [
      { k: 'ループの頂上の速さ（式 $\\sqrt{v_0^2-2gD}$）', v: fmt(P.coaster.vB(v), 2) + ' m/s' },
      { k: '止まる高さ（式 $v_0^{\\,2}/2g$）', v: fmt(P.coaster.hC(v), 2) + ' m' },
      { k: '1周できる最低の速さ（頂上で $\\sqrt{gR}$）', v: fmt(Math.sqrt(G * P.coaster.R()), 2) + ' m/s' }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m1-7'].sample(v, t);
    return [
      ['進んだ道のり $s$', fmt(m.s, 2) + ' m'],
      ['垂直抗力 $N$', fmt(P.coaster.Nof(v, m), 0) + ' N'],
      ['ループの頂上の時刻', fmt(P.coaster.tB(v), 2) + ' s'],
      ['最高点で止まる時刻', fmt(P.coaster.tTop(v), 2) + ' s'],
      ['スタート地点にもどる時刻', fmt(P.coaster.tEnd(v), 2) + ' s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return '\\tfrac{1}{2}mv_0^{\\,2} = mgh_C \\;\\Rightarrow\\; h_C = \\dfrac{v_0^{\\,2}}{2g} = ' +
      fmt(P.coaster.hC(v), 2) + '\\ \\mathrm{m}';
  },
  note: 'なめらかな軌道では、仕事をするのは<b>重力だけ</b>です（垂直抗力はいつも運動の向きと垂直）。' +
    'だから <b>$E = K + U$ はどこでも同じ</b>。ループの頂上は高さ $D$ なので ' +
    '$\\tfrac12mv_B^{\\,2} = \\tfrac12mv_0^{\\,2} - mgD$、' +
    '止まる高さは <b>$h_C = v_0^{\\,2}/(2g)$</b> で、<b>斜面の角によりません</b>。' +
    'ループを1周するには、頂上で $v_B^{\\,2} \\ge gR$ が必要です。'
};

/* ============ 1-8 斜方投射 ============ */
DEFS['m1-8'] = {
  id: 'm1-8', mode: 1, tab: '1-8 斜方投射',
  title: '1-8　斜方投射',
  sub: '高さ $h$ の点から、水平と角 $\\theta$ をなす向きに速さ $v_0$ で投げ出します。' +
    '空気の抵抗を考えなければ<b>仕事をするのは重力だけ</b>なので、力学的エネルギーは保存されます。' +
    '<b>最高点でも速さは 0 になりません</b>（水平方向の速さが残る）。',
  cw: 690, ch: 386,        /* 第6回：吹きだし3つを地面の下に1列でならべる幅 */
  vis: ['F', 'V', 'A'],
  mainVars: ['th', 'v0'],
  mainVarFocus: 'th',
  vars: [
    { k: 'th', label: '投げ出す角 $\\theta$', unit: '°', min: 15, max: 75, step: 5, dec: 0, def: 45 },
    { k: 'v0', label: 'はじめの速さ $v_0$', unit: ' m/s', min: 5, max: 14, step: 0.5, dec: 1, def: 9.0 },
    { k: 'h', label: '投げ出す高さ $h$', unit: ' m', min: 0, max: 6, step: 0.5, dec: 1, def: 2.0 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 5, step: 0.5, dec: 1, def: 1.0 }
  ],
  actions: [
    { label: '真上に近く（θ＝75°）', fn: function (s) { s.v.th = 75; },
      is: function (v) { return v.th === 75; },
      next: function (s) { return s._played && s.v.th !== 75; } },
    { label: '低く投げる（θ＝15°）', fn: function (s) { s.v.th = 15; },
      is: function (v) { return v.th === 15; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.th = 45; s.v.v0 = 9; s.v.h = 2; },
      is: function (v) { return v.th === 45 && Math.abs(v.v0 - 9) < 1e-9 && Math.abs(v.h - 2) < 1e-9; } }
  ],
  ptSide: 'row',
  cons: true,
  forces: ['g'],
  hintFig: '<b>最高点でも $K$ は 0 にならない</b>（水平方向の速さ $v_0\\cos\\theta$ が残る）',
  step1: '重力（保存力）だけが仕事をしている',
  datum: '地面',
  hint2: '<b>次は</b>：$\\theta$ を変えても、<b>着地の速さ</b>が変わらないことを確かめよう（$E$ が同じだから）。',
  tEnd: function (v) { return P.m17.tEnd(v); },
  sample: function (v, t) { return P.m17.sample(v, t); },
  pts: [
    { name: 'A', jp: '投げ出す点', t: function () { return 0; },
      hsym: 'h',                       /* ★式と図で同じ記号を使う★（第12回） */
      sym: { K: '\\tfrac{1}{2}mv_0^{\\,2}', Ug: 'mgh' } },
    { name: 'B', jp: '最高点', t: function (v) { return P.m17.tTop(v); },
      hsym: 'h_B',
      sym: { K: '\\tfrac{1}{2}m(v_0\\cos\\theta)^2', Ug: 'mgh_B' } },
    { name: 'C', jp: '着地', t: function (v) { return P.m17.tEnd(v); },
      sym: { K: '\\tfrac{1}{2}mv^2', Ug: '0' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m1-8'], v = V(s), m = d.sample(v, t);
    var T = P.m17.tEnd(v), xEnd = P.m17.vx(v) * T, yTop = P.m17.yTop(v);
    /* 第9回：右の余白が大きかったので上限を上げた。横は「台の左はし x0 = 118」から
       「地面の右はし W - 96」までに着地点が入るように、W - 232 で見る。 */
    var sc = Math.min(46, (W - 232) / Math.max(xEnd, 1), (H - 116) / Math.max(yTop, 1));
    var gy = H - 46 - PTBAND, x0 = 118;   /* 第6回：左に高さの寸法線を2本置くので、台を右へ */
    function X(x) { return x0 + x * sc; }
    function Y(y) { return gy - y * sc; }
    var i;

    ground(ctx, 20, W - 96, gy);
    /* 第9回：図を大きくして着地点が右はしに来たので、基準面の文字は左の下に置く
       （右上のままだと、着地の玉・v の矢印とぶつかる） */
    datumLine(ctx, 20, W - 96, gy, '基準面 h = 0', false, true);
    /* 投げ出す台 */
    if (v.h > 0.05) {
      ctx.save();
      ctx.fillStyle = '#eef1f4'; ctx.strokeStyle = '#98a0a8'; ctx.lineWidth = 1.4;
      ctx.beginPath(); ctx.rect(X(0) - 26, Y(v.h), 52, gy - Y(v.h)); ctx.fill(); ctx.stroke();
      ctx.restore();
      /* 運動が終わったら、点ごとの高さ（drawPts）に任せてこの1本は消す */
      if (!endOn(d, s, t)) heightDim(ctx, 26, Y(v.h), gy, 'h = ' + fmt(v.h, 1) + ' m', X(0) - 26, true);
    }
    /* 道すじ */
    ctx.save();
    ctx.strokeStyle = '#c3cbd3'; ctx.lineWidth = 1.2; ctx.setLineDash([5, 5]);
    ctx.beginPath();
    for (i = 0; i <= 90; i++) {
      var q = d.sample(v, T * i / 90);
      if (i === 0) ctx.moveTo(X(q.x), Y(q.y)); else ctx.lineTo(X(q.x), Y(q.y));
    }
    ctx.stroke(); ctx.restore();

    var mB = d.sample(v, P.m17.tTop(v)), mC = d.sample(v, T);
    /* ★いちばん高い所に「最高点」の吹きだし★（先生の指示・第13回）しっぽは下 */
    if (endOn(d, s, t)) ptNote(ctx, X(mB.x), Y(mB.y), '最高点', '（点B）', { gap: 52 });
    /* ★印は球と矢印からずらす★（第6回）A は台の上・球の右下、C は着地点の右下 */
    ptMark(ctx, 'A', X(0) + 20, Y(v.h) + 18);
    ptMark(ctx, 'B', X(mB.x), Y(mB.y) - 13);
    ptMark(ctx, 'C', X(mC.x) + 22, Y(0) + 16);

    var kz = mSize(d, v), r = 8 * kz;
    for (i = 1; i * 0.12 < t - 1e-9; i++) {
      var q2 = d.sample(v, i * 0.12);
      ball(ctx, X(q2.x), Y(q2.y), r, 'faint');
    }
    var px = X(m.x), py = Y(m.y);
    ball(ctx, px, py, r);

    /* 投げ出す角 */
    var av = -v.th * DEG;
    ctx.save();
    ctx.strokeStyle = '#c3cbd3'; ctx.lineWidth = 1.1; ctx.setLineDash([4, 4]);
    ctx.beginPath(); ctx.moveTo(X(0), Y(v.h)); ctx.lineTo(X(0) + 62, Y(v.h)); ctx.stroke();
    ctx.restore();
    angArc(ctx, X(0), Y(v.h), 30, av, 0, 'θ = ' + fmt(v.th, 0) + '°', av / 2, 60);

    /* ★スタートはデコピン★（手をはなすのではなく、はじいて投げ出す） */
    /* 第9回：図を大きくしたので、θ が大きいと吹きだしが「最高点 B」の印とぶつかる。
       吹きだしだけ右へ寄せる（手の位置はそのまま）。 */
    flickStart(ctx, t, v.v0, X(0) - Math.cos(av) * 24, Y(v.h) - Math.sin(av) * 24, av, 74);

    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 34 / mg;
    function fAt(ax, ay) {
      arrow(ctx, ax, ay, ax, ay + mg * fs, 'force');
      label(ctx, 'mg', ax, ay + mg * fs + 11, { size: 11.5, color: COL.force });
    }
    if (s.o.showF) fAt(px, py);
    if (s.o.showV && m.v > 0.05) {
      /* ★物体から離して出す★ 進む向きと垂直に 22 px ずらしてから */
      var vl = vArrowLen(m.v, Math.max(1, P.m17.vEnd(v)), 50);
      var ux = m.vx / m.v, uy = -m.vy / m.v;
      var va = velArrow(ctx, px, py, -uy, ux, 22, ux, uy, vl);
      label(ctx, 'v', va.tx + ux * 10, va.ty + uy * 10, { size: 11.5, color: COL.vel });
    }
    if (s.o.showA) {
      /* 速度は進む向きの片がわに出しているので、加速度は反対がわへ出す */
      var uax = (m.v > 0.02) ? m.vx / m.v : 1, uay = (m.v > 0.02) ? -m.vy / m.v : 0;
      drawAcc(ctx, px, py, 0, G, { nx: uay, ny: -uax, off: 36 });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    ptRow(gy + 50);                   /* 吹きだしは地面の下に1列。着地点の mg の字より下に置く */
    drawPts(ctx, d, s, t, function (p, mm, i2) {
      var q = d.sample(v, p.t), sp = { x: X(q.x), y: Y(q.y) };
      var uq = q.v > 0.02 ? { x: q.vx / q.v, y: -q.vy / q.v } : { x: 1, y: 0 };
      var mk = (p.name === 'A') ? { x: X(0) + 20, y: Y(v.h) + 18 }
        : (p.name === 'B' ? { x: X(mB.x), y: Y(mB.y) - 13 } : { x: X(mC.x) + 22, y: Y(0) + 16 });
      return { x: mk.x, y: mk.y, ox: sp.x, oy: sp.y, r: r,
        fdraw: function () { fAt(sp.x, sp.y); },
        vx: uq.x, vy: uq.y, vref: Math.max(1, P.m17.vEnd(v)), vk: 50, voff: r + 12,
        /* 高さの寸法線：B（最高点）は数値を線の上に出して、A の数値とぶつけない */
        base: gy, hx: 24 + i2 * 32, hside: (i2 === 1) ? true : 0 };
    });
  },
  resItems: function (v) {
    return [
      { k: '最高点の高さ', v: fmt(P.m17.yTop(v), 2) + ' m' },
      { k: '最高点の速さ（＝$v_0\\cos\\theta$）', v: fmt(P.m17.vTop(v), 2) + ' m/s' },
      { k: '着地の速さ（式）', v: fmt(P.m17.vEnd(v), 2) + ' m/s' }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m1-8'].sample(v, t);
    return [
      ['水平の位置 $x$', fmt(m.x, 2) + ' m'],
      ['高さ $y$', fmt(m.y, 2) + ' m'],
      ['最高点に来る時刻', fmt(P.m17.tTop(v), 2) + ' s'],
      ['着地する時刻', fmt(P.m17.tEnd(v), 2) + ' s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return '\\tfrac{1}{2}mv_0^{\\,2} + mgh = \\tfrac{1}{2}mv^2 \\;\\Rightarrow\\; v = \\sqrt{v_0^{\\,2}+2gh} = ' +
      fmt(P.m17.vEnd(v), 2) + '\\ \\mathrm{m/s}';
  },
  note: '投げ出したあと仕事をするのは<b>重力だけ</b>なので、力学的エネルギーは保存されます。' +
    '<b>最高点（B）でも運動エネルギーは 0 になりません</b>——上下の速さが 0 になるだけで、' +
    '水平方向の $v_0\\cos\\theta$ は残るからです。着地（C）の速さは <b>$\\sqrt{v_0^{\\,2}+2gh}$</b> で、' +
    '<b>投げ出す角によりません</b>（$E$ が同じだから）。'
};

/* ============ 1-9 水平ばね（単振動） ============ */
DEFS['m1-9'] = {
  id: 'm1-9', mode: 1, tab: '1-9 水平ばね',
  title: '1-9　水平ばね（単振動）',
  sub: 'なめらかな水平面。ばねを $x_0$ だけ伸ばして手をはなします。重力と垂直抗力は仕事をせず、' +
    '仕事をするのは<b>ばねの弾性力（保存力）</b>だけ。だから ' +
    '<b>$K + U_k = \\tfrac12mv^2 + \\tfrac12kx^2$ が一定</b>に保たれます。',
  cw: 520, ch: 250,
  vis: ['F', 'V', 'A'],
  hasUs: true,
  mainVars: ['x0', 'k'],
  mainVarFocus: 'x0',
  vars: [
    { k: 'x0', label: 'はじめの伸び $x_0$', unit: ' m', min: 0.1, max: 0.4, step: 0.02, dec: 2, def: 0.30 },
    { k: 'k', label: 'ばね定数 $k$', unit: ' N/m', min: 20, max: 100, step: 5, dec: 0, def: 40 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 4, step: 0.5, dec: 1, def: 1.0 }
  ],
  actions: [
    { label: 'かたいばね（k＝80）', fn: function (s) { s.v.k = 80; },
      is: function (v) { return v.k === 80; },
      next: function (s) { return s._played && s.v.k !== 80; } },
    { label: '大きく伸ばす（x₀＝0.40 m）', fn: function (s) { s.v.x0 = 0.4; },
      is: function (v) { return Math.abs(v.x0 - 0.4) < 1e-9; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.x0 = 0.3; s.v.k = 40; },
      is: function (v) { return Math.abs(v.x0 - 0.3) < 1e-9 && v.k === 40; } }
  ],
  cons: true,
  forces: ['g', 'N', 'sp'],
  hintFig: '<b>弾性力による位置エネルギー $U_k$ が減った分だけ $K$ が増える</b>（$U_g$ は 0 のまま）',
  step1: 'ばねの弾性力（保存力）だけが仕事をする。重力と垂直抗力は運動の向きに垂直',
  datum: '床（高さは変わらないので $U_g = 0$）',
  hint2: '<b>次は</b>：$k$ を変えて、<b>自然長を通るときの速さ</b> $v=x_0\\sqrt{k/m}$ がどう変わるか見てみよう。',
  slow: true,                /* ★はじめからスロー再生★（第8回・ばねのシム） */
  tEnd: function (v) { return P.m18.tEnd(v); },
  sample: function (v, t) { return P.m18.sample(v, t); },
  pts: [
    { name: 'A', jp: 'スタート（いちばん伸びた所）', t: function () { return 0; },
      sym: { K: '0', Ug: '0', Us: '\\tfrac{1}{2}kx_0^{\\,2}' } },
    { name: 'B', jp: '自然長の位置', t: function (v) { return P.m18.tEnd(v); },
      sym: { K: '\\tfrac{1}{2}mv^2', Ug: '0', Us: '0' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m1-9'], v = V(s), m = d.sample(v, t);
    var sc = 230, gy = H - 58, wallX = 40, natX = wallX + 150;
    function X(x) { return natX + x * sc; }
    var kz = mSize(d, v), bw = 34 * kz, bh = 26 * kz;

    ground(ctx, 20, W - 96, gy);
    datumLine(ctx, 20, W - 96, gy, '基準面 h = 0', true, true);
    /* 壁 */
    ctx.save();
    ctx.fillStyle = '#d7dde4'; ctx.fillRect(wallX - 14, gy - 96, 14, 96);
    ctx.strokeStyle = '#8b949e'; ctx.lineWidth = 1.4; ctx.strokeRect(wallX - 14, gy - 96, 14, 96);
    ctx.restore();
    /* 自然長の位置 */
    ctx.save();
    ctx.strokeStyle = '#9aa3ac'; ctx.lineWidth = 1.2; ctx.setLineDash([5, 4]);
    ctx.beginPath(); ctx.moveTo(natX, gy - 100); ctx.lineTo(natX, gy + 4); ctx.stroke();
    ctx.restore();
    label(ctx, '自然長', natX, gy - 108, { size: 11, color: COL.sub });

    var cx = X(m.x), cy = gy - bh / 2;
    spring(ctx, wallX, cy, cx - bw / 2, cy, { coils: 10, r: 11, color: COL.hand, lw: 2 });
    /* ★式の $x_0$（はじめの伸び）が図のどこかを見せる★（先生の指示・第12回）
       $U_k = \tfrac12kx_0^2$ の $x_0$。自然長の線から A（スタート）までの長さ。 */
    if (X(v.x0) - natX > 8) {
      var y0d = gy - bh - 40;
      arrow(ctx, natX, y0d, X(v.x0), y0d, 'dim');
      arrow(ctx, X(v.x0), y0d, natX, y0d, 'dim');
      label(ctx, 'x_0 = ' + fmt(v.x0, 2) + ' m', (natX + X(v.x0)) / 2, y0d - 11,
        { size: 11, color: COL.dim });
    }
    ptMark(ctx, 'A', X(v.x0) + bw / 2 + 13, gy - bh / 2);
    /* ★B は「自然長」の点線の上★（第9回・先生の指示）
       物体とは重ならない高さ（物体の上 30 px ほど）に置く。 */
    var bMarkY = gy - bh - 16;
    ptMark(ctx, 'B', natX, bMarkY);
    blockShape(ctx, cx, cy, 0, bw, bh, '#e8eef5');
    /* 伸びの寸法 */
    if (Math.abs(m.x) > 0.005) {
      arrow(ctx, natX, gy + 16, cx, gy + 16, 'dim');
      label(ctx, 'x = ' + fmt(m.x, 2) + ' m', (natX + cx) / 2, gy + 30, { size: 11, color: COL.dim });
    }
    var hA = (t <= 0.16) ? 1 : Math.max(0, 1 - (t - 0.16) / 0.20);
    if (hA > 0.02) dropHand(ctx, X(v.x0) + bw / 2 + 6, cy, 0.5, clamp(t / 0.16, 0, 1), hA);

    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 30 / mg;
    function fAt(qq, ax) {
      arrow(ctx, ax, cy, ax, cy + mg * fs, 'force');
      label(ctx, 'mg', ax, cy + mg * fs + 11, { size: 11.5, color: COL.force });
      arrow(ctx, ax, gy, ax, gy - mg * fs, 'force', 1, COL.norm);
      label(ctx, 'N', ax + bw / 2 + 8, gy - mg * fs + 4, { align: 'left', size: 11.5, color: COL.norm });
      var F = -v.k * qq.x, fl = clamp(F * fs * 0.55, -70, 70);
      if (Math.abs(fl) > 3) {
        arrow(ctx, ax - bw / 2, cy, ax - bw / 2 + fl, cy, 'force', 1, COL.hand);
        label(ctx, '弾性力 kx', ax - bw / 2 + fl / 2, cy - 14, { size: 11, color: COL.hand });
      }
    }
    if (s.o.showF) fAt(m, cx);
    if (s.o.showV && Math.abs(m.v) > 0.05) {
      /* ★物体から離して出す★（ブロックの上 40 px） */
      var sgv = (m.vs > 0 ? 1 : -1), vl = vArrowLen(m.v, Math.max(0.3, P.m18.vMax(v)), 48);
      var va = velArrow(ctx, cx, cy, 0, -1, bh / 2 + 40, sgv, 0, vl);
      label(ctx, 'v', va.tx + sgv * 10, va.ty, { size: 11.5, color: COL.vel });
    }
    if (s.o.showA) drawAcc(ctx, cx, cy, -v.k * m.x / v.m, 0, { nx: 0, ny: -1, off: bh / 2 + 76 });
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    drawPts(ctx, d, s, t, function (p) {
      var A = (p.name === 'A');
      var q = d.sample(v, p.t);
      /* 吹きだしは、物体の横に置いた印から引き出す */
      return { x: (A ? X(v.x0) + bw / 2 + 13 : natX), y: (A ? gy - bh / 2 : bMarkY),
        ox: A ? X(v.x0) : natX, oy: gy - bh / 2, bw: bw, bh: bh,
        fdraw: function () { fAt(q, A ? X(v.x0) : natX); },
        /* 終わりに物体がその点と同じ場所にいるときは、ゴーストを描かない */
        here: Math.abs(m.x - (A ? v.x0 : 0)) < 0.004,
        vx: (q.vs >= 0 ? 1 : -1), vy: 0, vref: Math.max(0.3, P.m18.vMax(v)), vk: 48, voff: bw / 2 + 10 };
    });
  },
  resItems: function (v) {
    return [
      { k: '自然長を通る速さ（式 $x_0\\sqrt{k/m}$）', v: fmt(P.m18.vMax(v), 2) + ' m/s' },
      { k: '1往復の時間（周期）', v: fmt(P.m18.period(v), 2) + ' s' }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m1-9'].sample(v, t);
    return [
      ['ばねの伸び $x$', fmt(m.x, 3) + ' m'],
      ['弾性力 $kx$', fmt(v.k * Math.abs(m.x), 1) + ' N'],
      ['自然長に来る時刻', fmt(P.m18.tNat(v), 2) + ' s'],
      ['1往復の時間（周期）', fmt(P.m18.period(v), 2) + ' s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return '\\tfrac{1}{2}kx_0^{\\,2} = \\tfrac{1}{2}mv^2 \\;\\Rightarrow\\; v = x_0\\sqrt{\\dfrac{k}{m}} = ' +
      fmt(P.m18.vMax(v), 2) + '\\ \\mathrm{m/s}';
  },
  note: 'ばねの弾性力は<b>保存力</b>で、その位置エネルギーが<b>弾性力による位置エネルギー $U_k=\\tfrac12kx^2$</b> です。' +
    '高さが変わらないので $U_g = 0$、つまり <b>$E = K + U_k$</b>。' +
    'いちばん伸びた所で $K=0$・$U_k$ が最大、<b>自然長の位置で $U_k=0$・$K$ が最大</b>になり、' +
    'その和はずっと一定です。'
};


/* ============ 1-10 水平ばねにぶつかる（★第5回・新規★） ============ */
DEFS['m1-10'] = {
  id: 'm1-10', mode: 1, tab: '1-10 水平ばねにぶつかる',
  title: '1-10　水平ばねにぶつかる',
  sub: 'なめらかな水平面を速さ $v_0$ で走ってきて、壁につけたばねにぶつかります。' +
    'ぶつかるまでは<b>重力も垂直抗力も仕事をしない</b>ので速さは変わりません（A → B）。' +
    'ぶつかってからは<b>弾性力（保存力）</b>だけが仕事をするので、' +
    '<b>$\\tfrac12mv_0^{\\,2} = \\tfrac12kx^2$</b> から縮み $x$ が求まります。',
  cw: 720, ch: 386,
  vis: ['F', 'V', 'A'],
  hasUs: true,
  mainVars: ['v0', 'k'],
  mainVarFocus: 'k',
  vars: [
    /* ★第11回：既定でもっとばねが縮むように★（先生の指示）
       縮み x = v0√(m/k)。v0 = 4 → 5、k = 200 → 100 にして 0.28 m → 0.50 m（約1.8倍）。 */
    { k: 'v0', label: 'はじめの速さ $v_0$', unit: ' m/s', min: 2, max: 5, step: 0.5, dec: 1, def: 5.0 },
    { k: 'k', label: 'ばね定数 $k$', unit: ' N/m', min: 100, max: 400, step: 50, dec: 0, def: 100 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 2, step: 0.5, dec: 1, def: 1.0 }
  ],
  actions: [
    { label: 'かたいばね（k＝400）', fn: function (s) { s.v.k = 400; },
      is: function (v) { return v.k === 400; },
      next: function (s) { return s._played && s.v.k !== 400; } },
    { label: 'ゆっくりぶつける（v₀＝2.5 m/s）', fn: function (s) { s.v.v0 = 2.5; },
      is: function (v) { return Math.abs(v.v0 - 2.5) < 1e-9; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.v0 = 5; s.v.k = 100; },
      is: function (v) { return Math.abs(v.v0 - 5) < 1e-9 && v.k === 100; } }
  ],
  cons: true,
  forces: ['g', 'N', 'sp'],
  hintFig: '<b>ばねが受けとった $\\tfrac12kx^2$ は、はじめの $\\tfrac12mv_0^{\\,2}$ とぴったり同じ</b>',
  step1: 'ばねの弾性力（保存力）だけが仕事をする。重力と垂直抗力は運動の向きに垂直',
  datum: '水平面（高さは変わらないので $U_g = 0$）',
  hint2: '<b>次は</b>：$k$ を変えて、<b>いちばん縮んだ長さ</b> $x=v_0\\sqrt{m/k}$ がどう変わるか見てみよう。',
  ptSide: 'row',
  slow: true,                /* ★はじめからスロー再生★（第8回・ばねのシム） */
  tEnd: function (v) { return P.hitSpring.tEnd(v); },
  sample: function (v, t) { return P.hitSpring.sample(v, t); },
  pts: [
    { name: 'A', jp: 'スタート', t: function () { return 0; },
      sym: { K: '\\tfrac{1}{2}mv_0^{\\,2}', Ug: '0', Us: '0' } },
    { name: 'B', jp: 'ぶつかる瞬間', t: function (v) { return P.hitSpring.t1(v); },
      sym: { K: '\\tfrac{1}{2}mv_0^{\\,2}', Ug: '0', Us: '0' } },
    { name: 'C', jp: 'いちばん縮んだ所', t: function (v) { return P.hitSpring.tC(v); },
      sym: { K: '0', Ug: '0', Us: '\\tfrac{1}{2}kx^2' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m1-10'], v = V(s), m = d.sample(v, t);
    /* ★地面の下に「吹きだしの帯」（PTBAND）をあける★（先生の指示・第6回）
       A・B・C を左から順にならべるために、地面より下を使えるようにしておく。 */
    var SC = SC_HIT, gy = H - 78 - PTBAND, x0 = 46, D0 = P.hitSpring.D0, L0 = 1.2;
    var natX = x0 + D0 * SC, wallX = natX + L0 * SC;
    function X(u) { return natX + u * SC; }
    var kz = mSize(d, v), bw = 34 * kz, bh = 26 * kz;
    var xMax = P.hitSpring.xMax(v);

    ground(ctx, 20, W - 96, gy);
    /* 第9回：図を大きくして壁が右へ寄ったので、基準面の文字は線の下に置く（壁と重ならない） */
    datumLine(ctx, 20, W - 96, gy, '基準面 h = 0', true, true);
    /* 壁 */
    ctx.save();
    ctx.fillStyle = '#d7dde4'; ctx.fillRect(wallX, gy - 104, 16, 104);
    ctx.strokeStyle = '#8b949e'; ctx.lineWidth = 1.4; ctx.strokeRect(wallX, gy - 104, 16, 104);
    ctx.restore();
    /* 自然の長さの位置（O） */
    ctx.save();
    ctx.strokeStyle = '#9aa3ac'; ctx.lineWidth = 1.2; ctx.setLineDash([5, 4]);
    ctx.beginPath(); ctx.moveTo(natX, gy - 92); ctx.lineTo(natX, gy + 4); ctx.stroke();
    ctx.restore();
    label(ctx, '自然の長さの位置', natX, gy - 100, { size: 11, color: COL.sub });

    var free = X(Math.max(0, m.x));                 /* ばねの左はし */
    var cx = free - bw / 2, cy = gy - bh / 2;
    if (m.x < 0) cx = X(m.x) - bw / 2;              /* まだぶつかっていない */
    spring(ctx, wallX, cy, Math.min(free, wallX - 8), cy, { coils: 11, r: 11, color: COL.hand, lw: 2 });
    /* ★点の印は地面の下に出す★ 物体と重なると読めない（先生の指摘・第6回） */
    ptMark(ctx, 'A', X(-D0), gy + 17);
    ptMark(ctx, 'B', natX, gy + 17);
    ptMark(ctx, 'C', X(xMax), gy + 17);
    blockShape(ctx, cx, cy, 0, bw, bh, '#e8eef5');
    /* 縮みの寸法。動いているあいだは「いまの縮み」、
       ★運動が終わったら「いちばん縮んだ長さ x」（＝式 $\tfrac12kx^2$ の x）を残す★
       （先生の指示・第12回。式に出てくる記号は図にも出す） */
    if (m.x > 0.004) {
      arrow(ctx, natX, gy + 18, X(m.x), gy + 18, 'dim');
      label(ctx, 'x = ' + fmt(m.x, 3) + ' m', (natX + X(m.x)) / 2, gy + 32,
        { size: 11, color: COL.dim });
    } else if (endOn(d, s, t) && xMax > 0.004) {
      /* 運動が終わったら「いちばん縮んだ長さ x」を図の上のほうに残す。
         地面の下は 印・mg・吹きだしでうまっているので、上に寸法線をひく。 */
      var ytop = gy - 130;
      ctx.save();
      ctx.strokeStyle = fade(COL.dim, 0.35); ctx.lineWidth = 1; ctx.setLineDash([4, 4]);
      ctx.beginPath(); ctx.moveTo(X(xMax), ytop); ctx.lineTo(X(xMax), gy - 30); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(natX, ytop); ctx.lineTo(natX, gy - 104); ctx.stroke();
      ctx.restore();
      arrow(ctx, natX, ytop, X(xMax), ytop, 'dim');
      arrow(ctx, X(xMax), ytop, natX, ytop, 'dim');
      label(ctx, 'x = ' + fmt(xMax, 3) + ' m', (natX + X(xMax)) / 2, ytop - 11,
        { size: 11, color: COL.dim });
    }
    flickStart(ctx, t, v.v0, X(-D0) - bw / 2 - 20, cy, 0, 74);

    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 30 / mg;
    function fAt(qq, ax) {
      arrow(ctx, ax, cy, ax, cy + mg * fs, 'force');
      label(ctx, 'mg', ax, cy + mg * fs + 11, { size: 11.5, color: COL.force });
      arrow(ctx, ax, gy, ax, gy - mg * fs, 'force', 1, COL.norm);
      label(ctx, 'N', ax - bw / 2 - 8, gy - mg * fs + 4,
        { align: 'right', size: 11.5, color: COL.norm });
      if (qq.x > 0.004) {
        var fl = clamp(v.k * qq.x * fs * 0.5, 6, 78);
        arrow(ctx, ax + bw / 2, cy, ax + bw / 2 - fl, cy, 'force', 1, COL.hand);
        label(ctx, '弾性力 kx', ax + bw / 2 - fl / 2, cy - 15, { size: 11, color: COL.hand });
      }
    }
    if (s.o.showF) fAt(m, cx);
    if (s.o.showV && m.v > 0.05) {
      /* ★物体から離して出す★（ブロックの上 40 px） */
      var sgv = (m.vs > 0 ? 1 : -1), vl = vArrowLen(m.v, 5, 46);
      var va = velArrow(ctx, cx, cy, 0, -1, bh / 2 + 40, sgv, 0, vl);
      label(ctx, 'v', va.tx + sgv * 10, va.ty, { size: 11.5, color: COL.vel });
    }
    if (s.o.showA) {
      if (m.x > 0.004) drawAcc(ctx, cx, cy, -v.k * m.x / v.m, 0, { nx: 0, ny: -1, off: bh / 2 + 76 });
      else label(ctx, 'a = 0', cx, cy - bh / 2 - 76, { size: 11.5, color: COL.acc, avoid: true });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    ptRow(gy + 50);                   /* 吹きだしは地面の下に1列。物体の mg の字より下に置く */
    drawPts(ctx, d, s, t, function (p) {
      var ux = (p.name === 'C') ? X(xMax) : (p.name === 'B' ? natX : X(-D0));
      var q = d.sample(v, p.t);
      return { x: ux, y: gy - 10, ox: ux - bw / 2, oy: gy - bh / 2, bw: bw, bh: bh,
        fdraw: function () { fAt(q, ux - bw / 2); },
        here: Math.abs(m.x - (p.name === 'C' ? xMax : (p.name === 'B' ? 0 : -D0))) < 0.004,
        vx: (q.vs >= 0 ? 1 : -1), vy: 0, vref: 5, vk: 46, voff: bw / 2 + 12 };
    });
  },
  resItems: function (v) {
    return [
      { k: 'いちばん縮んだ長さ（式 $v_0\\sqrt{m/k}$）', v: fmt(P.hitSpring.xMax(v), 3) + ' m' },
      { k: 'そのときの弾性力 $kx$', v: fmt(v.k * P.hitSpring.xMax(v), 1) + ' N' },
      { k: 'ぶつかる時刻', v: fmt(P.hitSpring.t1(v), 2) + ' s' }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m1-10'].sample(v, t);
    return [
      ['ばねの縮み $x$', fmt(Math.max(0, m.x), 3) + ' m'],
      ['弾性力 $kx$', fmt(v.k * Math.max(0, m.x), 1) + ' N'],
      ['ばねから離れる時刻', fmt(P.hitSpring.tOut(v), 2) + ' s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return '\\tfrac{1}{2}mv_0^{\\,2} = \\tfrac{1}{2}kx^2 \\;\\Rightarrow\\; x = v_0\\sqrt{\\dfrac{m}{k}} = ' +
      fmt(P.hitSpring.xMax(v), 3) + '\\ \\mathrm{m}';
  },
  note: 'A から B までは、はたらく力（重力と垂直抗力）が<b>どちらも運動の向きと垂直</b>なので' +
    '<b>仕事は 0</b>、速さは変わりません。B からは<b>弾性力</b>が負の仕事をして物体を止め、' +
    'そのぶんが<b>弾性力による位置エネルギー $U_k=\\tfrac12kx^2$</b> にたくわえられます。' +
    'いちばん縮んだところ（C）で $K=0$、$U_k$ が最大。そのあと同じ速さで押しもどされます。'
};

/* ============ 1-11 水平ばねと滑台（★第5回・新規★） ============ */
DEFS['m1-11'] = {
  id: 'm1-11', mode: 1, tab: '1-11 水平ばねと滑台',
  title: '1-11　水平ばねと滑台',
  sub: 'なめらかな面。ばねを $x_0$ だけ縮めて、静かにはなします。' +
    'ばねが自然の長さにもどったところ（B）で物体はばねから離れ、' +
    'そのまま滑台を昇って高さ $h_C$ で止まります（C）。<b>そこで終わりではありません。</b>' +
    'なめらかなので、<b>下りてきてもう一度ばねを $x_0$ だけ縮め、' +
    'また同じ高さ $h_C$ まで昇ります</b>（行ったり来たりをくり返します）。仕事をするのは' +
    '<b>弾性力と重力（どちらも保存力）だけ</b>なので、<b>$E=K+U_g+U_k$ は一定</b>です。',
  cw: 680, ch: 416,
  vis: ['F', 'V', 'A'],
  hasUs: true,
  mainVars: ['x0', 'k'],
  mainVarFocus: 'x0',
  vars: [
    /* ★ばねが押す距離を3倍に★（先生の指示・第8回）
       x₀ を 3 倍にし、エネルギーが同じくらいになるよう k を 1/9 にした。 */
    { k: 'x0', label: 'はじめの縮み $x_0$', unit: ' m', min: 0.45, max: 0.90, step: 0.05, dec: 2, def: 0.75 },
    { k: 'k', label: 'ばね定数 $k$', unit: ' N/m', min: 20, max: 40, step: 5, dec: 0, def: 35 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 1.0, max: 2.0, step: 0.25, dec: 2, def: 1.0 }
  ],
  /* ★第13回：ヒントの「x₀ を2倍」がそのまま押せるようにボタンを入れかえた★
     x₀ は 0.45〜0.90 m なので、0.45 → 0.90 がちょうど2倍。 */
  actions: [
    { label: '小さく縮める（x₀＝0.45 m）', fn: function (s) { s.v.x0 = 0.45; },
      is: function (v) { return Math.abs(v.x0 - 0.45) < 1e-9; },
      next: function (s) { return s._played && Math.abs(s.v.x0 - 0.45) > 1e-9; } },
    { label: 'その2倍に（x₀＝0.90 m）', fn: function (s) { s.v.x0 = 0.90; },
      is: function (v) { return Math.abs(v.x0 - 0.90) < 1e-9; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.x0 = 0.75; s.v.k = 35; s.v.m = 1.0; },
      is: function (v) { return Math.abs(v.x0 - 0.75) < 1e-9 && v.k === 35 && Math.abs(v.m - 1) < 1e-9; } }
  ],
  cons: true,
  forces: ['g', 'N', 'sp'],
  hintFig: '<b>$\\tfrac12kx_0^{\\,2}$ が、そのまま $mgh_C$ に変わる</b>（とちゅうは $\\tfrac12mv^2$）',
  step1: '弾性力と重力（どちらも保存力）だけが仕事をする。垂直抗力は運動の向きに垂直',
  datum: '水平面（ばねと平らな床の高さ）',
  hint2: '<b>次は</b>：$x_0$ を変えて、<b>昇る高さ</b> $h_C = kx_0^{\\,2}/(2mg)$ が' +
    'どう変わるか見てみよう（$x_0$ を <b>0.45 m → 0.90 m</b> と2倍にすると、$h_C$ は何倍？）。',
  ptSide: 'row',
  /* ★第14回：1-11 は「はじめからスロー」をやめた（先生の指示）★
     第8回にばねが押す距離を3倍にしたので、ふつうの速さでも十分に追える。 */
  tEnd: function (v) { return P.sprSlide.tEnd(v); },
  sample: function (v, t) { return P.sprSlide.sample(v, t); },
  pts: [
    { name: 'A', jp: 'スタート（縮めた所）', t: function () { return 0; },
      sym: { K: '0', Ug: '0', Us: '\\tfrac{1}{2}kx_0^{\\,2}' } },
    { name: 'B', jp: 'ばねから離れる所', t: function (v) { return P.sprSlide.t1(v); },
      sym: { K: '\\tfrac{1}{2}mv_B^{\\,2}', Ug: '0', Us: '0' } },
    { name: 'C', jp: '最高点', t: function (v) { return P.sprSlide.tC(v); },
      hsym: 'h_C',                     /* ★式と図で同じ記号を使う★（第12回） */
      sym: { K: '0', Ug: 'mgh_C', Us: '0' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m1-11'], v = V(s), m = d.sample(v, t);
    var SC = SC_SPSL, gy = H - 62 - PTBAND, x0p = 40, LN = 0.8, LF = P.sprSlide.LF;
    var natX = x0p + LN * SC, wallX = x0p;
    function X(u) { return natX + u * SC; }
    function Y(y) { return gy - y * SC; }
    var cv = P.sprSlide.curve(), XT = P.sprSlide.XTOP;
    function HY(x) { return P.sprSlide.yAt(x); }        /* 坂の形（まるみ＋30°の直線） */
    var r = 12 * mSize(d, v);
    var hC = P.sprSlide.hC(v);

    /* 平らな床と、そのあとの曲面 */
    ctx.save();
    ctx.strokeStyle = '#333'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(X(-LN - 0.05), Y(0)); ctx.lineTo(X(LF), Y(0));
    var i;
    for (i = 0; i <= 80; i++) {
      var xx = XT * i / 80;
      ctx.lineTo(X(LF + xx), Y(HY(xx)));
    }
    ctx.stroke();
    ctx.restore();
    /* 下のハッチ（床と曲面の下） */
    hatchLine(ctx, X(-LN - 0.05), Y(0), X(LF), Y(0), 1);
    ctx.save();
    ctx.fillStyle = '#eef1f4';
    ctx.beginPath();
    ctx.moveTo(X(LF), Y(0));
    for (i = 0; i <= 80; i++) {
      var x2 = XT * i / 80;
      ctx.lineTo(X(LF + x2), Y(HY(x2)));
    }
    ctx.lineTo(X(LF + XT), Y(0));
    ctx.closePath(); ctx.fill();
    ctx.restore();
    /* 文字は線の右のはしに出す。左のはしだと、地面の下に置いた A の印とぶつかる（第6回の直し） */
    /* ★吹きだしの帯（地面の下）に文字を置かない★ 基準面の文字は線の上に出す（第6回） */
    datumLine(ctx, 20, X(LF) + 10, gy, '基準面 h = 0', true, false);
    /* 壁 */
    ctx.save();
    ctx.fillStyle = '#d7dde4'; ctx.fillRect(wallX - 16, gy - 96, 16, 96);
    ctx.strokeStyle = '#8b949e'; ctx.lineWidth = 1.4; ctx.strokeRect(wallX - 16, gy - 96, 16, 96);
    ctx.restore();
    /* 自然の長さの位置 */
    ctx.save();
    ctx.strokeStyle = '#9aa3ac'; ctx.lineWidth = 1.2; ctx.setLineDash([5, 4]);
    ctx.beginPath(); ctx.moveTo(natX, gy - 102); ctx.lineTo(natX, gy + 4); ctx.stroke();
    ctx.restore();
    label(ctx, '自然の長さ', natX, gy - 110, { size: 11, color: COL.sub });
    /* ★式の $x_0$（はじめの縮み）が図のどこかを見せる★（先生の指示・第12回）
       $U_k = \tfrac12kx_0^2$ の $x_0$。自然の長さの位置から A（スタート）まで。 */
    if (natX - X(-v.x0) > 8) {
      var y0d = gy - 66;
      arrow(ctx, X(-v.x0), y0d, natX, y0d, 'dim');
      arrow(ctx, natX, y0d, X(-v.x0), y0d, 'dim');
      label(ctx, 'x_0 = ' + fmt(v.x0, 2) + ' m', (natX + X(-v.x0)) / 2, y0d - 11,
        { size: 11, color: COL.dim });
    }

    /* 物体（球）の位置 */
    var bx, by, ang = 0;
    if (m.seg === 2) { bx = X(LF + m.cx); by = Y(m.y); ang = Math.atan(P.sprSlide.dyAt(m.cx)); }
    else { bx = X(m.x); by = Y(0); }
    var ox = bx, oy = by - r - Math.cos(ang) * 0 - 2;
    /* 面から外向きに r だけ浮かせる */
    var nx = -Math.sin(-ang), ny = -Math.cos(-ang);
    if (m.seg === 2) { nx = -Math.sin(ang); ny = -Math.cos(ang); } else { nx = 0; ny = -1; }
    ox = bx + nx * r; oy = by + ny * r;
    /* ばね（自然の長さより縮んでいるときだけ物体につながる） */
    var sEnd = (m.seg <= 1) ? X(Math.min(0, m.x)) : natX;
    spring(ctx, wallX, gy - r - 4, sEnd, gy - r - 4, { coils: 9, r: 9, color: COL.hand, lw: 2 });

    var pA = { x: X(-v.x0), y: gy }, pB = { x: natX, y: gy };
    var xC = P.sprSlide.xOfH(hC);
    var pC = { x: X(LF + xC), y: Y(hC) };
    /* ★いちばん高い所に「最高点」の吹きだし★（先生の指示・第13回）しっぽは下 */
    if (endOn(d, s, t)) ptNote(ctx, pC.x, pC.y, '最高点', '（点C）', { gap: 46 });
    /* ★A と B は近いので、A は地面の下・B は物体の上に分ける★（物体と重ねない） */
    /* ★印は地面の下（A・B）と坂の中（C）★（第6回）
       球・力の矢印・左の高さの数値とぶつからない場所にそろえる。 */
    var mk11 = { A: { x: pA.x, y: gy + 17 }, B: { x: pB.x, y: gy + 17 },
      C: { x: pC.x + 15, y: pC.y + 13 } };
    ptMark(ctx, 'A', mk11.A.x, mk11.A.y);
    ptMark(ctx, 'B', mk11.B.x, mk11.B.y);
    ptMark(ctx, 'C', mk11.C.x, mk11.C.y);
    ball(ctx, ox, oy, r);
    /* ★高さの寸法線は坂の右のはしに出す★（先生の指示・第8回）
       左に置くと、ばね・壁・A の印がならぶところとぶつかる。
       高さは「面に接している点」ではかる（球の半径ぶんを高さに数えない）。 */
    var HX = X(LF + XT) + 24;
    if (!endOn(d, s, t)) heightDim(ctx, HX, by, gy, 'h = ' + fmt(m.h, 2) + ' m', ox, true);
    /* 縮みの寸法 */
    if (m.seg === 0 && m.sp > 0.004) {
      arrow(ctx, natX, gy + 18, X(-m.sp), gy + 18, 'dim');
      label(ctx, 'x = ' + fmt(m.sp, 2) + ' m', (natX + X(-m.sp)) / 2, gy + 32,
        { size: 11, color: COL.dim });
    }

    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 30 / mg;
    function fAt(qq, sx, sy, ang4) {
      var n4x = -Math.sin(ang4), n4y = -Math.cos(ang4);
      var ax = sx + n4x * r, ay = sy + n4y * r;
      arrow(ctx, ax, ay, ax, ay + mg * fs, 'force');
      label(ctx, 'mg', ax, ay + mg * fs + 11, { size: 11.5, color: COL.force });
      var Nn = mg * Math.cos(ang4);
      arrow(ctx, sx, sy, sx + n4x * Nn * fs, sy + n4y * Nn * fs, 'force', 1, COL.norm);
      label(ctx, 'N', sx + n4x * (Nn * fs + 12), sy + n4y * (Nn * fs + 12),
        { size: 11.5, color: COL.norm });
      if (qq.seg === 0 && qq.sp > 0.004) {
        var fl = clamp(v.k * qq.sp * fs * 0.4, 6, 76);
        arrow(ctx, ax + r, ay, ax + r + fl, ay, 'force', 1, COL.hand);
        label(ctx, '弾性力 kx', ax + r + fl / 2, ay - 15, { size: 11, color: COL.hand });
      }
    }
    if (s.o.showF) fAt(m, bx, by, (m.seg === 2) ? ang : 0);
    if (s.o.showV && m.v > 0.05) {
      /* ★物体から離して出す★（面から外向きに 30 px ずらしてから進む向きへ） */
      var ux = Math.cos(ang), uy = -Math.sin(ang);
      if (m.back) { ux = -ux; uy = -uy; }        /* もどっている途中は逆向き（第18回） */
      var vl = vArrowLen(m.v, Math.max(1, P.sprSlide.vB(v)), 46);
      var va = velArrow(ctx, ox, oy, nx, ny, 30, ux, uy, vl);
      label(ctx, 'v', va.tx + ux * 10, va.ty + uy * 10, { size: 11.5, color: COL.vel });
    }
    if (s.o.showA) {
      var ax = 0, ay = 0;
      if (m.seg === 0) ax = v.k * m.sp / v.m;
      else if (m.seg === 2) { var at = -G * m.dyds; ax = Math.cos(ang) * at; ay = -Math.sin(ang) * at; }
      if (Math.hypot(ax, ay) > 0.05) drawAcc(ctx, ox, oy, ax, ay, { nx: nx, ny: ny, off: 60 });
      else label(ctx, 'a = 0', ox + nx * 60, oy + ny * 60, { size: 11.5, color: COL.acc, avoid: true });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    ptRow(gy + 30);                   /* 吹きだしは地面の下に1列でならべる */
    drawPts(ctx, d, s, t, function (p, mm, i2) {
      var q = (p.name === 'A') ? pA : (p.name === 'B' ? pB : pC);
      var a2 = (p.name === 'C') ? Math.atan(P.sprSlide.dyAt(xC)) : 0;
      var n2x = (p.name === 'C') ? -Math.sin(a2) : 0, n2y = (p.name === 'C') ? -Math.cos(a2) : -1;
      return { x: mk11[p.name].x, y: mk11[p.name].y, ox: q.x + n2x * r, oy: q.y + n2y * r,
        fdraw: function () { fAt(d.sample(v, p.t), q.x, q.y, a2); },
        r: r, vx: Math.cos(a2), vy: -Math.sin(a2), vref: Math.max(1, P.sprSlide.vB(v)), vk: 46, voff: r + 14,
        base: gy, hx: HX, hy: q.y };
    });
  },
  resItems: function (v) {
    return [
      { k: 'ばねから離れる速さ（式 $x_0\\sqrt{k/m}$）', v: fmt(P.sprSlide.vB(v), 2) + ' m/s' },
      { k: '昇る高さ（式 $kx_0^{\\,2}/2mg$）', v: fmt(P.sprSlide.hC(v), 2) + ' m' },
      { k: 'はじめの弾性力による位置エネルギー', v: fmtJ(EN.Us(v.k, v.x0)) }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m1-11'].sample(v, t);
    return [
      ['ばねの縮み $x$', fmt(m.sp || 0, 3) + ' m'],
      ['ばねから離れる時刻', fmt(P.sprSlide.t1(v), 2) + ' s'],
      ['1回目の最高点', fmt(P.sprSlide.tC(v), 2) + ' s'],
      ['もう一度ばねがいちばん縮む時刻', fmt(2 * P.sprSlide.tC(v), 2) + ' s'],
      ['2回目の最高点（おしまい）', fmt(3 * P.sprSlide.tC(v), 2) + ' s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return '\\tfrac{1}{2}kx_0^{\\,2} = \\tfrac{1}{2}mv_B^{\\,2} = mgh_C \\;\\Rightarrow\\; h_C = ' +
      '\\dfrac{kx_0^{\\,2}}{2mg} = ' + fmt(P.sprSlide.hC(v), 2) + '\\ \\mathrm{m}';
  },
  note: '<b>弾性力による位置エネルギー → 運動エネルギー → 位置エネルギー</b>と、すがたを変えていくようすが見えます。' +
    'A では $U_k$ だけ、B では $K$ だけ、C では $U_g$ だけ。<b>合計 $E$ はずっと同じ</b>です。' +
    '昇る高さは <b>$h_C = kx_0^{\\,2}/(2mg)$</b>。$x_0$ を2倍にすると高さは<b>4倍</b>になります。'
};

/* ============ 1-12 鉛直ばね（手をはなす） ============ */
DEFS['m1-12'] = {
  id: 'm1-12', mode: 1, tab: '1-12 鉛直ばね',
  title: '1-12　鉛直ばね（手をはなす）',
  sub: 'ばねが自然の長さのままおもりを支えておき、<b>手を急にはなす</b>と、おもりは下がって' +
    '<b>最下点</b>まで行き、また戻ってきます。仕事をするのは<b>重力と弾性力（どちらも保存力）</b>だけなので、' +
    '$K + U_g + U_k$ は一定。最下点は<b>つりあいの位置の2倍</b>の深さです。' +
    '<b>基準面ははじめの位置</b>にとってあるので、下がったところの高さは<b>負</b>になります。',
  cw: 760,                 /* 吹きだしの式が長いので、横を広めにとる（第6回で 620 → 760） */
  /* 第14回：最下点の下に「最下点（点C）」の吹きだしを置くぶん、60 px 高くした */
  ch: function (v) { return 410; },
  vis: ['F', 'V', 'A'],
  hasUs: true,
  ptSide: 'stack',
  mainVars: ['k', 'd'],
  mainVarFocus: 'k',
  vars: [
    { k: 'k', label: 'ばね定数 $k$', unit: ' N/m', min: 40, max: 100, step: 5, dec: 0, def: 50 },
    { k: 'd', label: 'はじめの伸び $d$（自然長から下へ）', unit: ' m', min: 0, max: 0.08, step: 0.01, dec: 2, def: 0.00 }
  ],
  consts: { m: 1.0 },
  actions: [
    { label: 'やわらかいばね（k＝40）', fn: function (s) { s.v.k = 40; },
      is: function (v) { return v.k === 40; },
      next: function (s) { return s._played && s.v.k !== 40; } },
    { label: '手でゆっくり下ろす場合を見る →', jump: 'm2-3' },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.k = 50; s.v.d = 0; },
      is: function (v) { return v.k === 50 && Math.abs(v.d) < 1e-9; } }
  ],
  cons: true,
  forces: ['g', 'sp'],
  hintFig: '<b>最下点はつりあいの位置の2倍の深さ</b>（$x_{最下}=2mg/k$）。そこで $K=0$ になり、また上がる',
  step1: '重力と弾性力（どちらも保存力）だけが仕事をしている',
  datum: 'はじめの位置（手をはなす高さ）。下がると高さは負',
  hint2: '<b>次は</b>：<a href="#m2-3" data-goto="m2-3">2-3（手でゆっくり下ろす）</a>を見て、手の仕事による結果のちがいを確かめよう。',
  slow: true,                /* ★はじめからスロー再生★（第8回・ばねのシム） */
  /* ★2.5 周期ぶん見せてから止める★（先生の指示・第8回）
     1周期だと「行って帰った」だけで、くり返しの運動だと分かりにくい。 */
  tEnd: function (v) { return 2.5 * P.m19.tEnd(v); },
  sample: function (v, t) { return P.m19.sample(v, t); },
  pts: [
    { name: 'A', jp: 'はじめの状態', t: function () { return 0; },
      sym: { K: '0', Ug: '0', Us: '\\tfrac{1}{2}kd^2' } },
    { name: 'B', jp: 'つりあいの位置', t: function (v) { return P.m19.tEq(v); },
      hsym: 'd-x_{eq}',                /* ★式と図で同じ記号を使う★（第12回） */
      sym: { K: '\\tfrac{1}{2}mv^2', Ug: 'mg(d-x_{\\text{eq}})', Us: '\\tfrac{1}{2}kx_{\\text{eq}}^{\\,2}' } },
    { name: 'C', jp: '最下点', t: function (v) { return P.m19.tLow(v); },
      hsym: 'd-x_{最下}',
      sym: { K: '0', Ug: 'mg(d-x_{\\text{最下}})', Us: '\\tfrac{1}{2}kx_{\\text{最下}}^{\\,2}' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m1-12'], v = V(s), m = d.sample(v, t);
    /* ★横の場所わけ（第6回で作り直し）★
       左  … 高さの寸法線（h）を2列　／　まん中 … ばねとおもり
       右  … 点の印 A・B・C → 加速度 → 「自然長」「つりあい」の文字 → 吹きだしの列 */
    var cx = W * 0.34, topY = 46;
    var natY = topY + 86;                       /* 自然長のときのおもりの位置 */
    var xe = P.m19.xEq(v), xl = P.m19.xLow(v);
    /* 縮尺は「最下点が図に収まる」ように決める（やわらかいばねだと下にはみ出すため）。
       第14回：最下点の下に吹きだしを置くので、下の余白を 76 → 136 px にした。 */
    var sc = Math.min(300, (H - 136 - natY) / Math.max(0.05, xl));
    function Y(x) { return natY + x * sc; }     /* x＝自然長からの伸び */
    var kz = 1, bw = 40, bh = 26;

    /* 天井 */
    hatchLine(ctx, cx - 52, topY, cx + 52, topY, -1);
    /* 目印 */
    ctx.save();
    ctx.strokeStyle = '#9aa3ac'; ctx.lineWidth = 1.1; ctx.setLineDash([5, 4]);
    ctx.beginPath(); ctx.moveTo(cx - 96, natY); ctx.lineTo(cx + 60, natY); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(cx - 96, Y(xe)); ctx.lineTo(cx + 60, Y(xe)); ctx.stroke();
    ctx.restore();
    /* 文字は線の「右のはし」の少し上に置く。線の上に置くと、破線が文字を横切って読めない
       （第6回の直し）。左に置くと、左の高さの寸法線とぶつかる。 */
    label(ctx, '自然長', cx + 64, natY - 11, { size: 11, color: COL.sub, align: 'left' });
    /* ★式の $x_{eq}$ が図のどこかを見せる★（先生の指示・第12回） */
    label(ctx, 'つりあい x_{eq} = ' + fmt(xe, 3) + ' m', cx + 64, Y(xe) - 11,
      { size: 11, color: COL.sub, align: 'left' });
    datumLine(ctx, cx - 110, W - 96, Y(v.d), '基準面 h = 0（スタート）', true, false);
    /* ★2-3（手でゆっくり下ろす）との見くらべ★（先生の指示・第11回）
       同じばね・同じおもりでも、手が仕事をするかどうかで
       「つりあいの位置での速さ」がまるでちがう。2-3 にも同じパネルを出す。 */
    if (hintOn(s, t)) {
      factPanel(ctx, W * 0.53, 36, 'つりあいの位置（B点）での速さ',
        fmt(P.m19.vEq(v), 2) + ' m/s', '止まらずに通りすぎる');
    }
    /* ★表の $d$（はじめの伸び）が図のどこかを見せる★（第6回）
       自然長の線から、スタート（＝基準面）の線までの長さが d。
       ★第11回★ d = 0 のときは、矢印も数値も出さない。
       「d = 0.00 m（自然長から）」だけが動かずに残っていると、
       「いまの伸び」を表しているように読めてしまう（先生の指摘）。 */
    if (Y(v.d) - natY > 7) {
      arrow(ctx, cx - 90, natY, cx - 90, Y(v.d), 'dim');
      arrow(ctx, cx - 90, Y(v.d), cx - 90, natY, 'dim');
      label(ctx, 'はじめの伸び d = ' + fmt(v.d, 2) + ' m', cx - 90, natY - 12,
        { size: 11, color: COL.dim });
    }

    var by = Y(m.x);
    spring(ctx, cx, topY, cx, by - bh / 2, { coils: 11, r: 13, color: COL.hand, lw: 2 });
    /* ★3点は高さがちがうので、印は1本の列にそろえる★（第6回の直し）
       前は横にずらしていたので、おもりや吹きだしの上に乗ってしまっていた。
       ただし k と d の組み合わせで3点がほとんど同じ高さになることがある
       （d ≒ x_eq のとき）。そのときだけ横にずらして、文字が重ならないようにする。 */
    var mSpread = Math.max(Math.abs(Y(xe) - Y(v.d)), Math.abs(Y(xl) - Y(v.d)),
      Math.abs(Y(xl) - Y(xe)));
    var mDx = (mSpread < 26) ? 26 : 0;
    ptMark(ctx, 'A', cx + 40, Y(v.d));
    ptMark(ctx, 'B', cx + 40 + mDx, Y(xe));
    ptMark(ctx, 'C', cx + 40 + 2 * mDx, Y(xl));
    /* ★いちばん低い所に「最下点（点C）」の吹きだし★（先生の指示・第14回）
       しっぽは上向き（箱は下）。まん中は mg の矢印が通るので、箱は左へ寄せる。 */
    if (endOn(d, s, t)) ptNote(ctx, cx, Y(xl), '最下点', '（点C）', { below: true, gap: 78 });
    blockShape(ctx, cx, by, 0, bw, bh, '#e8eef5');
    /* 運動が終わったら、点ごとの高さ（drawPts）に任せてこの1本は消す */
    if (!endOn(d, s, t)) heightDim(ctx, cx - 116, by, Y(v.d), 'h = ' + fmt(m.h, 3) + ' m');   /* 下は負 */

    var hA = (t <= 0.18) ? 1 : Math.max(0, 1 - (t - 0.18) / 0.22);
    if (hA > 0.02) dropHand(ctx, cx - 4, Y(v.d) + bh / 2, 0.5, clamp(t / 0.18, 0, 1), hA);

    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 30 / mg;
    function fAt(qq, ay) {
      arrow(ctx, cx, ay, cx, ay + mg * fs, 'force');
      label(ctx, 'mg', cx, ay + mg * fs + 11, { size: 11.5, color: COL.force });
      var F = v.k * qq.x;
      if (F * fs > 3) {
        arrow(ctx, cx, ay - bh / 2, cx, ay - bh / 2 - F * fs, 'force', 1, COL.hand);
        label(ctx, '弾性力 kx', cx + 12, ay - bh / 2 - F * fs + 6, { size: 11, color: COL.hand, align: 'left' });
      }
    }
    if (s.o.showF) {
      fAt(m, by);
    }
    if (s.o.showV && Math.abs(m.v) > 0.03) {
      /* ★物体から離して出す★（ブロックの左 76 px。加速度は左 34 px なので、ぶつからない） */
      var sgv = (m.vs > 0 ? 1 : -1), vl = vArrowLen(m.v, Math.max(0.2, P.m19.vEq(v)), 44);
      var va = velArrow(ctx, cx, by, -1, 0, 76, 0, sgv, vl);
      label(ctx, 'v', va.x - 12, va.y, { size: 11.5, color: COL.vel, align: 'right' });
    }
    if (s.o.showA) drawAcc(ctx, cx, by, 0, G - v.k * m.x / v.m, { nx: -1, ny: 0, off: bw / 2 + 24 });
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    drawPts(ctx, d, s, t, function (p, mm, i2) {
      var yy = (p.name === 'A') ? Y(v.d) : (p.name === 'B' ? Y(xe) : Y(xl));
      var q = d.sample(v, p.t);
      /* 高さの寸法線は左に2列。深いほう（C）は数値を線の左に出して、B の線とぶつけない */
      return { x: cx + 40 + i2 * mDx, y: yy, ox: cx, oy: yy, bw: bw, bh: bh,
        here: Math.abs(yy - by) < 1.5,      /* 2.5 周期で最下点（C）に止まる */
        fdraw: function () { fAt(q, yy); },
        vx: 0, vy: (q.vs >= 0 ? 1 : -1), vref: Math.max(0.2, P.m19.vEq(v)), vk: 44, voff: bh / 2 + 10,
        base: Y(v.d), hx: cx - 116 - i2 * 44, hside: (i2 >= 2) ? 'left' : 0 };
    });
  },
  resItems: function (v) {
    return [
      { k: 'つりあいの位置 $x_{eq}=mg/k$', v: fmt(P.m19.xEq(v), 3) + ' m' },
      { k: '最下点 $x=2mg/k$', v: fmt(P.m19.xLow(v), 3) + ' m' },
      { k: 'つりあいでの速さ（最大）', v: fmt(P.m19.vEq(v), 2) + ' m/s' }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m1-12'].sample(v, t);
    return [
      ['ばねの伸び $x$', fmt(m.x, 3) + ' m'],
      ['弾性力 $kx$', fmt(v.k * m.x, 1) + ' N'],
      ['最下点に来る時刻', fmt(P.m19.tLow(v), 2) + ' s'],
      ['1往復の時間', fmt(P.m19.tEnd(v), 2) + ' s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return 'mgx = \\tfrac{1}{2}kx^2 \\;\\Rightarrow\\; x_{\\text{最下}} = \\dfrac{2mg}{k} = ' +
      fmt(P.m19.xLow(v), 3) + '\\ \\mathrm{m}\\quad(x_{\\text{eq}} = ' + fmt(P.m19.xEq(v), 3) + '\\ \\mathrm{m})';
  },
  note: '重力も弾性力も<b>保存力</b>なので、$K+U_g+U_k$ は一定です。' +
    '自然長から静かに手をはなすと、<b>最下点はつりあいの位置のちょうど2倍</b>の深さ（$2mg/k$）になります。' +
    'これは「$mgx = \\tfrac12kx^2$ を解く」だけで出ます。' +
    '<b>つりあいの位置</b>では弾性力と重力がつり合っていて、そこで<b>速さが最大</b>になります。' +
    'モード2の <b>2-3</b> では、同じばねを<b>手でゆっくり下ろし</b>ます。見くらべてみてください。'
};

/* ============ 1-13 曲面から飛び出す ============ */
DEFS['m1-13'] = {
  id: 'm1-13', mode: 1, tab: '1-13 曲面飛び出し',
  title: '1-13　曲面から飛び出す',
  sub: 'なめらかな円弧のくぼみを、高さ $h$ の点 A から初速度 $v_0$ ですべり下り、' +
    '最下点 B を通って、<b>60° の向きの点 C から飛び出し</b>、最高点 D まで上がります。' +
    '面の上でも空中でも<b>仕事をするのは重力だけ</b>なので、力学的エネルギーはずっと一定です。',
  cw: 790, ch: 452,          /* 点が4つ＝吹きだしも4つ。地面の下に1列でならべる（第6回で 680 → 790） */
  vis: ['F', 'V', 'A'],
  mainVars: ['h', 'v0'],
  mainVarFocus: 'v0',
  vars: [
    { k: 'h', label: 'はじめの高さ $h$', unit: ' m', min: 1.5, max: 3.5, step: 0.1, dec: 1, def: 2.5 },
    { k: 'v0', label: 'はじめの速さ $v_0$', unit: ' m/s', min: 0, max: 4, step: 0.5, dec: 1, def: 0.0 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 4, step: 0.5, dec: 1, def: 1.0 }
  ],
  actions: [
    { label: '勢いをつける（v₀＝3 m/s）', fn: function (s) { s.v.v0 = 3; },
      is: function (v) { return Math.abs(v.v0 - 3) < 1e-9; },
      next: function (s) { return s._played && Math.abs(s.v.v0 - 3) > 1e-9; } },
    { label: '高いところから（h＝3.5 m）', fn: function (s) { s.v.h = 3.5; },
      is: function (v) { return Math.abs(v.h - 3.5) < 1e-9; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.h = 2.5; s.v.v0 = 0; },
      is: function (v) { return Math.abs(v.h - 2.5) < 1e-9 && Math.abs(v.v0) < 1e-9; } }
  ],
  ptSide: 'row',
  cons: true,
  forces: ['g', 'N'],
  hintFig: '<b>飛び出したあとも $E$ は変わらない</b>。最高点 D でも水平方向の速さが残るので $K \\ne 0$',
  step1: '重力（保存力）だけが仕事をする。曲面の垂直抗力は運動の向きに垂直',
  datum: 'くぼみの最下点',
  hint2: '<b>次は</b>：$h$ を変えて、<b>最高点 D の高さ</b>がどう変わるか確かめよう。',
  tEnd: function (v) { return P.m110.tEnd(v); },
  sample: function (v, t) { return P.m110.sample(v, t); },
  pts: [
    { name: 'A', jp: 'スタート', t: function () { return 0; },
      hsym: 'h',                       /* ★式と図で同じ記号を使う★（第12回） */
      sym: { K: '\\tfrac{1}{2}mv_0^{\\,2}', Ug: 'mgh' } },
    { name: 'B', jp: '最下点', t: function (v) { return P.m110.tB(v); },
      sym: { K: '\\tfrac{1}{2}mv_B^{\\,2}', Ug: '0' } },
    { name: 'C', jp: '飛び出す点', t: function (v) { return P.m110.tC(v); },
      hsym: 'h_C',
      sym: { K: '\\tfrac{1}{2}mv_C^{\\,2}', Ug: 'mgh_C' } },
    { name: 'D', jp: '最高点', t: function (v) { return P.m110.tD(v); },
      hsym: 'h_D',
      sym: { K: '\\tfrac{1}{2}m(v_C\\cos 60^\\circ)^2', Ug: 'mgh_D' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m1-13'], v = V(s), m = d.sample(v, t);
    var R = P.m110.R, o = P.m110.table(v);
    /* ★くぼみの左は「鉛直な壁」★（先生の指示・第8回）
       h > R のときは、円は 90°（＝いちばん左）まででやめて、そこから上は鉛直な壁にする。
       円のままだとオーバーハングになり、静かにはなしても面にそって滑る＝ありえない動きになる。 */
    var th0 = P.m110.th0(v), al = -th0;              /* 円に入る角（0〜90°） */
    var hw = P.m110.wallH(v);                        /* 壁の高さ（0 なら壁なし） */
    var tab = o.tab, i;
    var xmin = -R * Math.sin(al), xmax = 0, ymax = Math.max(v.h, 0);
    for (i = 0; i < tab.length; i++) {
      if (tab[i].x > xmax) xmax = tab[i].x;
      if (tab[i].y > ymax) ymax = tab[i].y;
    }
    /* 第9回：右の余白が大きかったので 56 → 62（どの設定でも横 63.3・縦 96 まで入るので、
       62 なら「いつも同じ縮尺」のまま、いちばん大きく見せられる） */
    var sc = Math.min(62, (W - 190) / Math.max(0.5, xmax - xmin), (H - 116) / Math.max(0.5, ymax));
    var gy = H - 52 - PTBAND, x0 = 50 - xmin * sc;
    function X(x) { return x0 + x * sc; }
    function Y(y) { return gy - y * sc; }

    /* 円弧のくぼみ */
    var cyc = Y(R);
    ctx.save();
    ctx.strokeStyle = '#333'; ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.arc(X(0), cyc, R * sc, Math.PI / 2 - P.m110.PHI, Math.PI / 2 + al);
    ctx.stroke();
    /* 鉛直な壁（円の左はし＝高さ R の点から、スタートの高さまで） */
    if (hw > 0.001) {
      ctx.beginPath();
      ctx.moveTo(X(-R), Y(R)); ctx.lineTo(X(-R), Y(v.h));
      ctx.stroke();
    }
    ctx.lineWidth = 1; ctx.strokeStyle = '#333';
    for (var aa = Math.PI / 2 - P.m110.PHI; aa < Math.PI / 2 + al; aa += 0.09) {
      ctx.beginPath();
      ctx.moveTo(X(0) + Math.cos(aa) * R * sc, cyc + Math.sin(aa) * R * sc);
      ctx.lineTo(X(0) + Math.cos(aa + 0.05) * (R * sc + 8), cyc + Math.sin(aa + 0.05) * (R * sc + 8));
      ctx.stroke();
    }
    /* 壁のハッチ（左がわが「かべの中」） */
    for (var hy2 = Y(R) - 6; hy2 > Y(v.h) - 1 && hw > 0.001; hy2 -= 9) {
      ctx.beginPath(); ctx.moveTo(X(-R), hy2); ctx.lineTo(X(-R) - 8, hy2 + 5); ctx.stroke();
    }
    ctx.restore();
    /* ★吹きだしの帯（地面の下）に文字を置かない★ 基準面の文字は線の上に出す（第6回） */
    datumLine(ctx, X(xmin) - 20, W - 96, gy, '基準面 h = 0', true, false);

    /* 飛び出したあとの道すじ */
    ctx.save();
    ctx.strokeStyle = '#c3cbd3'; ctx.lineWidth = 1.2; ctx.setLineDash([5, 5]);
    ctx.beginPath();
    for (i = 0; i < tab.length; i += 4) {
      if (i === 0) ctx.moveTo(X(tab[i].x), Y(tab[i].y)); else ctx.lineTo(X(tab[i].x), Y(tab[i].y));
    }
    ctx.stroke(); ctx.restore();

    var mA = d.sample(v, 0), mB = d.sample(v, P.m110.tB(v));
    var mC = d.sample(v, P.m110.tC(v)), mD = d.sample(v, P.m110.tD(v));
    /* ★いちばん高い所に「最高点」の吹きだし★（先生の指示・第13回）しっぽは下 */
    if (endOn(d, s, t)) ptNote(ctx, X(mD.x), Y(mD.y), '最高点', '（点D）', { gap: 50 });
    /* ★飛び出す点 C が「まん中から 60°」であることを図に出す★（先生の指示・第8回）
       円の中心から、最下点 B の向きと C の向きへ細い線を引き、その間の角を 60° と書く。 */
    ctx.save();
    ctx.strokeStyle = fade(COL.sub, 0.75); ctx.lineWidth = 1; ctx.setLineDash([4, 3]);
    ctx.beginPath(); ctx.moveTo(X(0), cyc); ctx.lineTo(X(0), Y(0)); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(X(0), cyc); ctx.lineTo(X(mC.x), Y(mC.y)); ctx.stroke();
    ctx.restore();
    angArc(ctx, X(0), cyc, R * sc * 0.42, Math.PI / 2 - P.m110.PHI, Math.PI / 2,
      '60°', Math.PI / 2 - P.m110.PHI / 2, R * sc * 0.42 + 16);
    /* 円の中心も小さく打っておく（どこから測った角なのかが分かるように） */
    ctx.save();
    ctx.fillStyle = fade(COL.sub, 0.8);
    ctx.beginPath(); ctx.arc(X(0), cyc, 2.4, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    /* ★印は球からずらす★（第6回）球やゴースト、力の矢印にかぶると文字が読めない。
       A は、壁があるときは壁の右上（壁の中には置けない）、ないときはくぼみの外（左上）へ。
       C は飛び出したあとの道すじの外（右上）へ。 */
    var mkA13 = { x: X(mA.x) + 20, y: Y(mA.y) - 13 };   /* 左は高さの数値がならぶので、いつも右上へ */
    ptMark(ctx, 'A', mkA13.x, mkA13.y);
    ptMark(ctx, 'B', X(mB.x), Y(mB.y) - 30);   /* 球は面の内がわに乗るので、その上へ */
    ptMark(ctx, 'C', X(mC.x) + 22, Y(mC.y) - 15);
    ptMark(ctx, 'D', X(mD.x), Y(mD.y) - 13);
    /* 運動が終わったら、点ごとの高さ（drawPts）に任せてこの1本は消す */
    if (!endOn(d, s, t)) heightDim(ctx, 22, Y(v.h), gy, 'h = ' + fmt(v.h, 1) + ' m', X(mA.x), true);

    var kz = mSize(d, v), r = 8 * kz;
    /* ★球は「面の内がわ」に半径ぶん浮かせて描く★（第8回）
       面の上に中心をのせると、球が面（とくに鉛直な壁）の線をかくしてしまう。
       内向き＝円の中心へ向かう向き。壁の上（θ=−90°）なら真右。 */
    function inN(q) {
      if (!q.on) return { x: 0, y: 0 };
      return { x: -Math.sin(q.th), y: -Math.cos(q.th) };
    }
    for (i = 1; i * 0.12 < t - 1e-9; i++) {
      var q = d.sample(v, i * 0.12), n2 = inN(q);
      ball(ctx, X(q.x) + n2.x * r, Y(q.y) + n2.y * r, r, 'faint');
    }
    var px = X(m.x), py = Y(m.y), n0 = inN(m);
    var bx = px + n0.x * r, by = py + n0.y * r;      /* 球の中心 */
    ball(ctx, bx, by, r);
    /* ★初速度 0 のときは「手をはなす」、勢いをつけるときは「デコピン」★ */
    var nA = inN(mA), aBx = X(mA.x) + nA.x * r, aBy = Y(mA.y) + nA.y * r;
    if (v.v0 < 0.05) {
      var hA = (t <= 0.18) ? 1 : Math.max(0, 1 - (t - 0.18) / 0.22);
      if (hA > 0.02) dropHand(ctx, aBx, aBy, 0.5, clamp(t / 0.18, 0, 1), hA);
    } else {
      flickStart(ctx, t, v.v0, aBx - 20, aBy, 0, 62);
    }

    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 30 / mg;
    function fAt(qq, sx, sy) {                /* sx, sy＝面に接している点 */
      var n5 = inN(qq), ax = sx + n5.x * r, ay = sy + n5.y * r;
      arrow(ctx, ax, ay, ax, ay + mg * fs, 'force');
      label(ctx, 'mg', ax, ay + mg * fs + 11, { size: 11.5, color: COL.force });
      /* ★鉛直な壁の上では N = 0★（面が運動の向きと平行で、押しつける力がない）。
         だから矢印を描かない。ここを描いてしまうと「壁が横に押している」と誤解される。
         飛んでいる間（on = false）も、はたらくのは重力だけ。 */
      if (qq.on && !qq.wall) {
        var Nn = Math.min((mg * Math.cos(qq.th) + v.m * qq.v * qq.v / R) * fs, 70);
        arrow(ctx, sx, sy, sx + n5.x * Nn, sy + n5.y * Nn, 'force', 1, COL.norm);
        label(ctx, 'N', sx + n5.x * (Nn + 12), sy + n5.y * (Nn + 12), { size: 11.5, color: COL.norm });
      }
    }
    if (s.o.showF) fAt(m, px, py);
    if (s.o.showV && m.v > 0.05) {
      /* ★物体から離して出す★ 進む向きと垂直に 22 px ずらしてから */
      var vl = vArrowLen(m.v, Math.max(1, P.m110.vB(v)), 46);
      var ux = m.vx / m.v, uy = -m.vy / m.v;
      /* ずらす向きは「進む向きと垂直」。ただし mg（真下）とぶつからないよう、
         左右のうち mg から遠いほうへ出す */
      var sgv = (ux >= 0) ? 1 : -1;
      var va = velArrow(ctx, bx, by, -uy * sgv, ux * sgv, 40, ux, uy, vl);
      label(ctx, 'v', va.tx + ux * 10, va.ty + uy * 10, { size: 11.5, color: COL.vel });
    }
    if (s.o.showA) {
      var ax2 = 0, ay2 = G;
      if (m.on) {
        var nx3 = X(0) - px, ny3 = cyc - py, nl3 = Math.hypot(nx3, ny3) || 1;
        var Nm = mg * Math.cos(m.th) + v.m * m.v * m.v / R;
        ax2 = (nx3 / nl3) * Nm / v.m; ay2 = G + (ny3 / nl3) * Nm / v.m;
      }
      var ubx = (m.v > 0.05) ? m.vx / m.v : 0, uby = (m.v > 0.05) ? -m.vy / m.v : -1;
      var sgb = (ubx >= 0) ? 1 : -1;
      drawAcc(ctx, bx, by, ax2, ay2,
        { nx: (m.v > 0.05) ? ubx : 0, ny: (m.v > 0.05) ? uby : -1, off: 48, max: 54 });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    ptRow(gy + 30);                   /* 吹きだしは地面の下に1列でならべる */
    drawPts(ctx, d, s, t, function (p, mm, i2) {
      var q = d.sample(v, p.t);
      var mk = (p.name === 'A') ? mkA13
        : (p.name === 'B' ? { x: X(mB.x), y: Y(mB.y) - 30 }
        : (p.name === 'C' ? { x: X(mC.x) + 22, y: Y(mC.y) - 15 } : { x: X(mD.x), y: Y(mD.y) - 13 }));
      var uq = q.v > 0.02 ? { x: q.vx / q.v, y: -q.vy / q.v } : { x: 1, y: 0 };
      var nq = inN(q);
      return { x: mk.x, y: mk.y, ox: X(q.x) + nq.x * r, oy: Y(q.y) + nq.y * r, r: r,
        fdraw: function () { fAt(q, X(q.x), Y(q.y)); },
        vx: uq.x, vy: uq.y, vref: Math.max(1, P.m110.vB(v)), vk: 46, voff: r + 16,
        base: gy, hx: 22 + i2 * 27 };
    });
  },
  resItems: function (v) {
    return [
      { k: '最下点 B の速さ（式）', v: fmt(P.m110.vB(v), 2) + ' m/s' },
      { k: '飛び出す点 C の速さ（式）', v: fmt(P.m110.vC(v), 2) + ' m/s' },
      { k: '最高点 D の高さ（式）', v: fmt(P.m110.hD(v), 2) + ' m' }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m1-13'].sample(v, t);
    return [
      ['いまの高さ', fmt(m.h, 2) + ' m'],
      ['飛び出す点の高さ $h_C$', fmt(P.m110.hC(v), 2) + ' m'],
      ['飛び出す時刻', fmt(P.m110.tC(v), 2) + ' s'],
      ['最高点に来る時刻', fmt(P.m110.tD(v), 2) + ' s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return '\\tfrac{1}{2}mv_0^{\\,2} + mgh = \\tfrac{1}{2}mv_C^{\\,2} + mgh_C \\;\\Rightarrow\\; v_C = ' +
      fmt(P.m110.vC(v), 2) + '\\ \\mathrm{m/s}';
  },
  note: '面の上でも空中でも、仕事をするのは<b>重力だけ</b>です（垂直抗力は運動の向きに垂直）。' +
    'だから A・B・C・D の<b>どこでも $E$ は同じ</b>。高さが低いほど速く、高いほど遅くなります。' +
    '<b>最高点 D でも運動エネルギーは 0 になりません</b>——飛び出す向きが 60° なので、' +
    '水平方向の速さ $v_C\\cos 60°$ が残るからです。'
};
```

## src/60_mode2.js

```js
/* モード2　非保存力が仕事をするケース（力学的エネルギーが保存されない） */
'use strict';

/* 2-5 の斜面の縮尺 [px/m]。★固定★（θ を変えても坂の長さは変えない）
   θ = 45° でも高さが入り、θ = 20° でも横幅が入る値にしてある。 */
var SC_PULL = 76;
/* 斜面は引く長さ L より少し長く描く（上のはしに巻き上げ機を置くため） */
var SMAX_PULL = 1.55;   /* 第7回：手が物体といっしょに上がるので、坂を長めに描く */

/* ============ 2-1 摩擦がある水平な床 ============ */
DEFS['m2-1'] = {
  id: 'm2-1', mode: 2, tab: '2-1 摩擦がある水平な床',
  title: '2-1　摩擦がある水平な床',
  sub: '粗い床の上をすべる物体。<b>動摩擦力は非保存力</b>で、進む向きと逆を向いているので<b>負の仕事</b>をします。' +
    'その仕事の分だけ力学的エネルギーが減り、減った分は<b>熱</b>になって逃げていきます。' +
    '止まる位置は $\\tfrac12mv_0^{\\,2}=\\mu\' mgL$ から <b>$L=v_0^{\\,2}/(2\\mu\' g)$</b>。',
  cw: 520, ch: 372,        /* 第7回：mg の矢印を長くしたぶん、下を広げた */
  vis: ['F', 'V', 'A'],
  mainVars: ['v0', 'mu'],
  mainVarFocus: 'mu',
  vars: [
    { k: 'v0', label: 'はじめの速さ $v_0$', unit: ' m/s', min: 3, max: 7, step: 0.5, dec: 1, def: 6.0 },
    { k: 'mu', label: '動摩擦係数 $\\mu\'$', unit: '', min: 0.2, max: 0.5, step: 0.05, dec: 2, def: 0.20 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 5, step: 0.5, dec: 1, def: 2.0 }
  ],
  actions: [
    { label: 'ざらざらの床にする（μ′＝0.50）', fn: function (s) { s.v.mu = 0.50; },
      is: function (v) { return Math.abs(v.mu - 0.50) < 1e-9; },
      next: function (s) { return s._played && Math.abs(s.v.mu - 0.50) > 1e-9; } },
    { label: '少しざらざらに（μ′＝0.35）', fn: function (s) { s.v.mu = 0.35; },
      is: function (v) { return Math.abs(v.mu - 0.35) < 1e-9; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.v0 = 6; s.v.mu = 0.20; },
      is: function (v) { return Math.abs(v.v0 - 6) < 1e-9 && Math.abs(v.mu - 0.20) < 1e-9; } }
  ],
  cons: false,
  forces: ['g', 'N', 'fr'],
  hintFig: '<b>減った力学的エネルギーは熱になって逃げる</b>（図のエネルギーの棒のグレー＝$|W_{\\text{非保存}}|$）',
  wName: '動摩擦力',
  wSym: "-\\mu' mgL",
  step1: '動摩擦力（非保存力）が、進む向きと逆向きに負の仕事をしている',
  datum: '床（物体のある水平面）',
  hint2: '<b>次は</b>：$\\mu\'$ を変えて、<b>止まる位置</b>と<b>E–t 図の下がり方</b>がどう変わるか見てみよう。',
  tEnd: function (v) { return P.m21.tEnd(v); },
  sample: function (v, t) { return P.m21.sample(v, t); },
  pts: [
    { name: 'A', jp: 'スタート', t: function () { return 0; },
      sym: { K: '\\tfrac{1}{2}mv_0^{\\,2}', Ug: '0' } },
    { name: 'B', jp: '止まる位置', t: function (v) { return P.m21.tStop(v); },
      sym: { K: '0', Ug: '0' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m2-1'], v = V(s), m = d.sample(v, t);
    /* ★縮尺は固定★（自動にすると、いつも同じ場所で止まって見えてスライドバーが効かない） */
    var SCX = 26.4, gy = H - 128, x0 = 64;
    function X(x) { return x0 + x * SCX; }
    var kz = mSize(d, v), bw = 34 * kz, bh = 24 * kz;
    var L = P.m21.xStop(v);

    /* 粗い床（ハッチ＋つぶつぶ） */
    ground(ctx, 20, W - 96, gy);
    ctx.save();
    ctx.fillStyle = '#9aa3ac';
    for (var g2 = 26; g2 < W - 100; g2 += 9) {
      ctx.beginPath(); ctx.arc(g2, gy - 2.2, 1.5, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
    datumLine(ctx, 20, W - 96, gy, '基準面 h = 0', false, true);
    axisX(ctx, X, gy + 86, 0, Math.min(12.5, (W - 110 - x0) / SCX), 'x [m]', 1, { step: 2 });

    /* ★印は物体の横★（第6回）上下は mg・N の矢印が通るので、外側の横に置く */
    ptMark(ctx, 'A', X(0) - bw / 2 - 13, gy - bh / 2);
    ptMark(ctx, 'B', X(L) + bw / 2 + 13, gy - bh / 2);

    var i;
    for (i = 1; i * 0.2 < t - 1e-9; i++) {
      ctx.save(); ctx.globalAlpha = 0.26;
      blockShape(ctx, X(d.sample(v, i * 0.2).x), gy - bh / 2, 0, bw, bh, '#f2f4f7');
      ctx.restore();
    }
    var cx = X(m.x), cy = gy - bh / 2;
    blockShape(ctx, cx, cy, 0, bw, bh, '#e8eef5');
    flickStart(ctx, t, v.v0, X(0) - bw / 2 - 20, cy, 0, 152);   /* L の寸法線より上に出す */

    /* ★力の縮尺は大きめにとる★（先生の指摘・第7回）
       もとは「mg が 30 px」だったが、動摩擦力 μ'N は mg の 1/5〜1/3 しかないので
       5〜10 px にしかならず、いちばん見せたい力が見えなかった。
       矢印の長さの比は力の比のまま（★量に比例★ レイアウト規約 ㉞）。 */
    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 62 / mg;
    function fAt(qq, ax) {
      arrow(ctx, ax, cy, ax, cy + mg * fs, 'force');
      label(ctx, 'mg', ax, cy + mg * fs + 11, { size: 11.5, color: COL.force });
      arrow(ctx, ax, gy, ax, gy - mg * fs, 'force', 1, COL.norm);
      label(ctx, 'N', ax + bw / 2 + 8, gy - mg * fs + 4, { align: 'left', size: 11.5, color: COL.norm });
      if (qq.moving) {
        var fl = qq.f * fs;
        arrow(ctx, ax, gy - 3, ax - fl, gy - 3, 'force', 1, COL.fric);
        label(ctx, "μ'N", ax - fl - 8, gy - 16,
          { align: 'right', size: 11.5, color: COL.fric });
      }
    }
    if (s.o.showF) fAt(m, cx);
    if (s.o.showV && m.v > 0.05) {
      var vl = vArrowLen(m.v, 7, 54);
      /* ★N の矢じりより上に出す★ N の長さは力の縮尺で変わるので、そこから決める */
      var va = velArrow(ctx, cx, cy, 0, -1, mg * fs - bh / 2 + 22, 1, 0, vl);
      label(ctx, 'v', va.tx + 10, va.ty, { align: 'left', size: 11.5, color: COL.vel });
    }
    var aOff21 = mg * fs - bh / 2 + 46;      /* 速度の矢印よりさらに外がわ */
    if (s.o.showA && m.moving) drawAcc(ctx, cx, cy, -v.mu * G, 0, { nx: 0, ny: -1, off: aOff21 });
    else if (s.o.showA) label(ctx, 'a = 0', cx, cy - aOff21,
      { size: 11.5, color: COL.acc, avoid: true });
    if (hintOn(s, t)) {
      /* 止まる位置は「答え」なので、スタートを押してから出す */
      ctx.save();
      ctx.strokeStyle = fade(COL.areaNeg, 0.9); ctx.lineWidth = 1.4; ctx.setLineDash([5, 4]);
      ctx.beginPath(); ctx.moveTo(X(L), gy - 112); ctx.lineTo(X(L), gy + 6); ctx.stroke();
      ctx.restore();
      arrow(ctx, X(0), gy - 120, X(L), gy - 120, 'dim');
      arrow(ctx, X(L), gy - 120, X(0), gy - 120, 'dim');
      label(ctx, "L = v₀²/(2μ'g) = " + fmt(L, 2) + ' m', (X(0) + X(L)) / 2, gy - 130,
        { size: 11.5, color: COL.dim });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    drawPts(ctx, d, s, t, function (p) {
      var A = (p.name === 'A');
      return { x: X(A ? 0 : L) + (A ? -1 : 1) * (bw / 2 + 13), y: gy - bh / 2,
        ox: X(A ? 0 : L), oy: gy - bh / 2,
        fdraw: function () { fAt(d.sample(v, p.t), X(A ? 0 : L)); },
        bw: bw, bh: bh, vx: 1, vy: 0, vref: 7, vk: 54, voff: bw / 2 + 10 };
    });
  },
  /* ★モード2の見どころ★ とちゅうの状態で「動摩擦力が運動と逆向き」を見せる */
  midGhost: function (ctx, s) {
    var d = DEFS['m2-1'], v = V(s), tm = P.m21.tStop(v) * 0.5, m = d.sample(v, tm);
    /* ★ここの定数は draw とそろえる★ ずれると「とちゅうの姿」だけ別の場所に描かれる */
    var SCX = 26.4, gy = CVH - 128, x0 = 64;
    var kz = mSize(d, v), bw = 34 * kz, bh = 24 * kz;
    var cx = x0 + m.x * SCX, cy = gy - bh / 2, fs = 62 / (v.m * G);
    ctx.save(); ctx.globalAlpha = 0.9;
    blockShape(ctx, cx, cy, 0, bw, bh, '#f2f4f7');
    ctx.restore();
    var vl = vArrowLen(m.v, 7, 54);
    var va = velArrow(ctx, cx, cy, 0, -1, v.m * G * fs - bh / 2 + 22, 1, 0, vl);
    label(ctx, 'v', va.tx + 10, va.ty, { align: 'left', size: 11, color: COL.vel });
    var fl = m.f * fs;
    arrow(ctx, cx, gy - 3, cx - fl, gy - 3, 'force', 1, COL.fric);
    label(ctx, "μ'N", cx - fl - 8, gy - 16, { align: 'right', size: 11, color: COL.fric });
    /* 吹きだしは N の矢じりより上（A・B の印と重なるため。第7回）。
       ★第9回★ しっぽ（▼）の先は「動摩擦力の矢印の まん中の真上」にそろえる。
       説明している力が動摩擦力なので、そこを指していないと何の話か分からない。 */
    bubble(ctx, '力の向きが運動と逆 → 負の仕事！', cx - fl / 2, gy - v.m * G * fs - 30,
      { size: 11.5, bg: '#eef2f7', border: COL.eE, color: '#28323d' });
  },
  resItems: function (v) {
    return [
      { k: "動摩擦力 $\\mu' mg$", v: fmt(v.mu * v.m * G, 2) + ' N' },
      { k: "止まるまでの距離（式 $v_0^2/2\\mu' g$）", v: fmt(P.m21.xStop(v), 2) + ' m' }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m2-1'].sample(v, t);
    return [
      ['進んだ距離 $x$', fmt(m.x, 2) + ' m'],
      ['加速度 $-\\mu\' g$', fmt(-v.mu * G, 2) + ' m/s²'],
      ['止まる時刻', fmt(P.m21.tStop(v), 2) + ' s'],
      ['熱になったエネルギー', fmt(-m.W, 2) + ' J']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return "\\tfrac{1}{2}mv_0^{\\,2} = \\mu' mgL \\;\\Rightarrow\\; L = \\dfrac{v_0^{\\,2}}{2\\mu' g} = " +
      fmt(P.m21.xStop(v), 2) + '\\ \\mathrm{m}';
  },
  note: '動摩擦力は<b>非保存力</b>です。進む向きと逆を向いているので<b>負の仕事</b>をし、' +
    'その分だけ力学的エネルギーが減ります（<b>$E_2-E_1=W_{\\text{非保存}}$</b>）。' +
    'E–t 図が下がっていき、<b>下がった分が失われたエネルギー</b>＝熱になった分です' +
    '（図のエネルギーの棒では、その分をグレーに塗っています）。' +
    'ここでは高さが変わらないので $U=0$ のまま、$E$ の変化はそのまま $K$ の変化になります。'
};

/* ============ 2-2 摩擦がある斜面 ============ */
DEFS['m2-2'] = {
  id: 'm2-2', mode: 2, tab: '2-2 摩擦がある斜面',
  title: '2-2　摩擦がある斜面（すべり上がる）',
  sub: '粗い斜面を、下から斜面にそって速さ $v_0$ ですべり上がります。' +
    '重力（保存力）のほかに<b>動摩擦力（非保存力）が運動と逆向きにはたらいて負の仕事</b>をするので、' +
    '力学的エネルギーは保存されません。止まるまでの距離は ' +
    '$L=\\dfrac{v_0^{\\,2}}{2g(\\sin\\theta+\\mu\'\\cos\\theta)}$。',
  cw: 560, ch: 366,          /* 下にデコピンの手と mg の矢印が出るぶん、高くとる */
  vis: ['F', 'Fc', 'V', 'A'],
  mainVars: ['th', 'mu'],
  mainVarFocus: 'mu',
  vars: [
    { k: 'th', label: '斜面の角 $\\theta$', unit: '°', min: 15, max: 45, step: 5, dec: 0, def: 30 },
    { k: 'mu', label: '動摩擦係数 $\\mu\'$', unit: '', min: 0.10, max: 0.50, step: 0.05, dec: 2, def: 0.30 },
    { k: 'v0', label: 'はじめの速さ $v_0$', unit: ' m/s', min: 3, max: 7, step: 0.5, dec: 1, def: 6.0 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 5, step: 0.5, dec: 1, def: 2.0 }
  ],
  actions: [
    { label: 'ざらざらにする（μ′＝0.50）', fn: function (s) { s.v.mu = 0.50; },
      is: function (v) { return Math.abs(v.mu - 0.50) < 1e-9; },
      next: function (s) { return s._played && Math.abs(s.v.mu - 0.50) > 1e-9; } },
    { label: 'なめらかにする（μ′＝0.10）', fn: function (s) { s.v.mu = 0.10; },
      is: function (v) { return Math.abs(v.mu - 0.10) < 1e-9; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.th = 30; s.v.mu = 0.3; s.v.v0 = 6; },
      is: function (v) { return v.th === 30 && Math.abs(v.mu - 0.3) < 1e-9 && Math.abs(v.v0 - 6) < 1e-9; } }
  ],
  cons: false,
  forces: ['g', 'N', 'fr'],
  hintFig: '<b>動摩擦力が負の仕事をした分だけ $E$ が減る</b>。' +
    'なめらかな斜面（1-3）なら $E$ は減らず、もっと高くまで上がる',
  wName: '動摩擦力',
  wSym: "-\\mu' mg\\cos\\theta\\,L",
  step1: '重力のほかに、動摩擦力（非保存力）が運動と逆向きに負の仕事をしている',
  datum: '出発点（斜面の下端）',
  hint2: '<b>次は</b>：$\\mu\'$ を変えて、<b>止まる位置</b>と<b>失われるエネルギー</b>がどう変わるか見てみよう。',
  tEnd: function (v) { return P.m22.tEnd(v); },
  sample: function (v, t) { return P.m22.sample(v, t); },
  pts: [
    { name: 'A', jp: 'スタート（下端）', t: function () { return 0; },
      sym: { K: '\\tfrac{1}{2}mv_0^{\\,2}', Ug: '0' } },
    { name: 'B', jp: '止まる位置', t: function (v) { return P.m22.tStop(v); },
      hsym: 'L sinθ',                  /* ★式と図で同じ記号を使う★（第12回） */
      sym: { K: '0', Ug: 'mgL\\sin\\theta' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m2-2'], v = V(s), m = d.sample(v, t);
    /* ★縮尺は μ′ では変えない★
       斜面の長さは「いちばんなめらかなとき（μ′=0.10）に上がれる距離」で決める。
       こうすると μ′ を変えたときに、同じ坂の上で止まる場所だけが変わって見くらべられる。 */
    var th = v.th * DEG, gy = H - 98, x0 = 96;
    var ux = Math.cos(th), uy = -Math.sin(th);      /* 斜面を上る向き（画面の座標） */
    /* ★斜面から外向き★ 右上がりの坂では「左上」を向く（＝ux と直角）。
       第7回まで nx = +sin(th) と符号をまちがえていて、垂直抗力が斜面に垂直に
       ならず、物体も坂から少しずれて乗っていた（先生の指摘）。 */
    var nx = -Math.sin(th), ny = -Math.cos(th);
    var sRef = Math.min(9.0, v.v0 * v.v0 /
      (2 * G * (Math.sin(th) + 0.10 * Math.cos(th))) * 1.2);
    /* 第9回：右の余白が大きかったので上限 70 → 100 */
    var SC = Math.min(88, (W - 96 - x0 - 16) / Math.max(0.5, sRef * Math.cos(th)),
      (gy - 46) / Math.max(0.3, sRef * Math.sin(th)));
    function P2(sv) { return { x: x0 + ux * sv * SC, y: gy + uy * sv * SC }; }
    var L = P.m22.sStop(v), sMax = sRef;
    var top = P2(sMax);

    /* 斜面（粗い面） */
    ctx.save();
    ctx.fillStyle = '#eef1f4';
    ctx.beginPath(); ctx.moveTo(x0, gy); ctx.lineTo(top.x, top.y); ctx.lineTo(top.x, gy);
    ctx.closePath(); ctx.fill();
    ctx.restore();
    hatchLine(ctx, x0, gy, top.x, top.y, -1);
    ctx.save();
    ctx.fillStyle = '#9aa3ac';
    for (var q = 0.12; q < sMax; q += 0.22) {
      var pp = P2(q);
      ctx.beginPath(); ctx.arc(pp.x + nx * 2.4, pp.y + ny * 2.4, 1.5, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
    ground(ctx, 20, W - 96, gy);
    /* 基準面の字は右はしに置く（左は物体・手・寸法線でこみあうため） */
    datumLine(ctx, 20, W - 96, gy, '基準面 h = 0', true, true);
    angArc(ctx, x0, gy, 30, -th, 0, '', 0, 0);
    label(ctx, 'θ = ' + fmt(v.th, 0) + '°', x0 + 44, gy - 12, { size: 12, color: COL.sub, align: 'left' });

    var kz = mSize(d, v), bw = 30 * kz, bh = 22 * kz;
    var pA = P2(0), pB = P2(L);
    /* ★いちばん高い所に「最高点」の吹きだし★（先生の指示・第13回）しっぽは下 */
    if (endOn(d, s, t)) ptNote(ctx, pB.x, pB.y, '最高点', '（点B）', { gap: 56 });
    /* ★印は物体の「坂にそって外がわ」★（第6回）真上は N の矢印が通るのでずらす */
    var mkA = markAway(pA, pB, nx, ny, bh / 2 + 4, bw / 2 + 14);
    var mkB = markAway(pB, pA, nx, ny, bh / 2 + 4, bw / 2 + 14);
    ptMark(ctx, 'A', mkA.x, mkA.y);
    ptMark(ctx, 'B', mkB.x, mkB.y);

    /* ★式の $L$ が図のどこかを見せる★（先生の指示・第12回）
       $U_g = mgL\sin\theta$ の $L$（すべり上がった斜面にそった長さ）を、
       坂の内がわ（下）に両矢印でひく。答えなのでスタートを押してから出す。 */
    if (hintOn(s, t)) {
      var lo1 = { x: pA.x - nx * 30, y: pA.y - ny * 30 };
      var lo2 = { x: pB.x - nx * 30, y: pB.y - ny * 30 };
      arrow(ctx, lo1.x, lo1.y, lo2.x, lo2.y, 'dim');
      arrow(ctx, lo2.x, lo2.y, lo1.x, lo1.y, 'dim');
      /* 文字は「θ = ○°」の弧を避けて、坂の 0.62 くらいの所に置く */
      label(ctx, 'L = ' + fmt(L, 2) + ' m', lo1.x + (lo2.x - lo1.x) * 0.62 - nx * 14,
        lo1.y + (lo2.y - lo1.y) * 0.62 - ny * 14, { size: 11.5, color: COL.dim });
    }

    var i;
    for (i = 1; i * 0.15 < t - 1e-9; i++) {
      var qq = P2(d.sample(v, i * 0.15).s);
      ctx.save(); ctx.globalAlpha = 0.26;
      blockShape(ctx, qq.x + nx * bh / 2, qq.y + ny * bh / 2, th, bw, bh, '#f2f4f7');
      ctx.restore();
    }
    var p0 = P2(m.s), cx = p0.x + nx * bh / 2, cy = p0.y + ny * bh / 2;
    blockShape(ctx, cx, cy, th, bw, bh, '#e8eef5');
    flickStart(ctx, t, v.v0, pA.x - ux * 22 + nx * bh / 2, pA.y - uy * 22 + ny * bh / 2, -th, 112);
    /* 高さは「斜面に接している点」ではかる（物体の厚みぶんを高さに数えない） */
    /* 運動が終わったら、点ごとの高さ（drawPts）に任せてこの1本は消す */
    if (!endOn(d, s, t)) heightDim(ctx, 24, p0.y, gy, 'h = ' + fmt(m.h, 2) + ' m', cx, true);

    /* ★力の縮尺は大きめにとる★（先生の指摘・第7回）
       もとは「mg が 30 px」だったが、動摩擦力 μ'N は mg の 1/5〜1/3 しかないので
       5〜10 px にしかならず、いちばん見せたい力が見えなかった。
       矢印の長さの比は力の比のまま（★量に比例★ レイアウト規約 ㉞）。 */
    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 62 / mg;
    function fAt(qq, sx, sy) {
      var ax = sx + nx * bh / 2, ay = sy + ny * bh / 2;
      arrow(ctx, ax, ay, ax, ay + mg * fs, 'force');
      label(ctx, 'mg', ax, ay + mg * fs + 11, { size: 11.5, color: COL.force });
      arrow(ctx, sx, sy, sx + nx * qq.N * fs, sy + ny * qq.N * fs, 'force', 1, COL.norm);
      label(ctx, 'N', sx + nx * (qq.N * fs + 12), sy + ny * (qq.N * fs + 12),
        { size: 11.5, color: COL.norm });
      if (qq.moving) {
        var fl = qq.f * fs;
        arrow(ctx, sx, sy, sx - ux * fl, sy - uy * fl, 'force', 1, COL.fric);
        label(ctx, "μ'N", sx - ux * (fl + 14), sy - uy * (fl + 14), { size: 11.5, color: COL.fric });
      }
    }
    if (s.o.showF) {
      fAt(m, p0.x, p0.y);
    }
    if (s.o.showFc) {
      var gs = mg * Math.sin(th);
      arrow(ctx, cx, cy, cx - ux * gs * fs, cy - uy * gs * fs, 'comp');
      label(ctx, 'mg sinθ', cx - ux * gs * fs - 10, cy - uy * gs * fs + 12, { size: 11, color: COL.force });
    }
    if (s.o.showV && m.v > 0.05) {
      /* ★物体から離して出す★ */
      /* ★N の矢じりより外に出す★（力の縮尺を大きくしたので、36 px では中に入る） */
      var vof = m.N * fs - bh / 2 + 22, vl = vArrowLen(m.v, 7, 48);
      var va = velArrow(ctx, cx, cy, nx, ny, vof, ux, uy, vl);
      label(ctx, 'v', va.tx + ux * 10, va.ty + uy * 10, { size: 11.5, color: COL.vel });
    }
    if (s.o.showA) {
      var aa = P.m22.aMag(v);        /* 斜面を下る向き（＝運動と逆）に大きさ g(sinθ+μ'cosθ) */
      drawAcc(ctx, cx, cy, -ux * aa, -uy * aa,
        { nx: nx, ny: ny, off: m.N * fs - bh / 2 + 58 });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    drawPts(ctx, d, s, t, function (p, mm, i2) {
      var q = (p.name === 'A') ? pA : pB, mk2 = (p.name === 'A') ? mkA : mkB;
      return { x: mk2.x, y: mk2.y,
        fdraw: function () { fAt(d.sample(v, p.t), q.x, q.y); },
        ox: q.x + nx * bh / 2, oy: q.y + ny * bh / 2, bw: bw, bh: bh, ang: th,
        vx: ux, vy: uy, vref: 7, vk: 48, voff: 28, base: gy, hx: 24 + i2 * 20 };
    });
  },
  /* ★モード2の見どころ★ とちゅうで「動摩擦力が運動と逆向き」を見せる */
  midGhost: function (ctx, s) {
    var d = DEFS['m2-2'], v = V(s), tm = P.m22.tStop(v) * 0.5, m = d.sample(v, tm);
    /* ★ここの定数は draw とそろえる★ */
    var th = v.th * DEG, gy = CVH - 98, x0 = 96;
    var sRef = Math.min(9.0, v.v0 * v.v0 / (2 * G * (Math.sin(th) + 0.10 * Math.cos(th))) * 1.2);
    var sc = Math.min(88, (CVW - 96 - x0 - 16) / Math.max(0.5, sRef * Math.cos(th)),
      (gy - 46) / Math.max(0.3, sRef * Math.sin(th)));
    var ux = Math.cos(th), uy = -Math.sin(th), nx = -Math.sin(th), ny = -Math.cos(th);
    var kz = mSize(d, v), bw = 30 * kz, bh = 22 * kz;
    var px = x0 + ux * m.s * sc, py = gy + uy * m.s * sc;
    var cx = px + nx * bh / 2, cy = py + ny * bh / 2, fs = 62 / (v.m * G);
    ctx.save(); ctx.globalAlpha = 0.9;
    blockShape(ctx, cx, cy, th, bw, bh, '#f2f4f7');
    ctx.restore();
    var vl = vArrowLen(m.v, 7, 48);
    var va = velArrow(ctx, cx, cy, nx, ny, m.N * fs - bh / 2 + 22, ux, uy, vl);
    label(ctx, 'v', va.tx + ux * 10, va.ty + uy * 10, { size: 11, color: COL.vel });
    var fl = m.f * fs;
    arrow(ctx, px, py, px - ux * fl, py - uy * fl, 'force', 1, COL.fric);
    label(ctx, "μ'N", px - ux * (fl + 14), py - uy * (fl + 14), { size: 11, color: COL.fric });
    /* ★吹きだしは物体の斜め上（坂の外がわ）に出す★（第8回）
       坂の右下（山の中）に置いていたので、引き出しの▼が何もささずに浮いて見えた。
       ★第9回★ しっぽ（▼）の先は「動摩擦力の矢印の まん中の真上」にそろえる。 */
    bubble(ctx, '力の向きが運動と逆 → 負の仕事！', px - ux * fl / 2, cy + ny * 158,
      { size: 11.5, bg: '#eef2f7', border: COL.eE, color: '#28323d' });
  },
  resItems: function (v) {
    return [
      { k: '止まるまでの距離 $L$（式）', v: fmt(P.m22.sStop(v), 2) + ' m' },
      { k: '止まる高さ $L\\sin\\theta$', v: fmt(P.m22.sStop(v) * Math.sin(v.th * DEG), 2) + ' m' },
      { k: 'なめらかなら上がる高さ', v: fmt(v.v0 * v.v0 / (2 * G), 2) + ' m' }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m2-2'].sample(v, t);
    return [
      ['斜面にそって進んだ距離', fmt(m.s, 2) + ' m'],
      ['動摩擦力 $\\mu\' mg\\cos\\theta$', fmt(m.f, 2) + ' N'],
      ['止まる時刻', fmt(P.m22.tStop(v), 2) + ' s'],
      ['熱になったエネルギー', fmt(-m.W, 2) + ' J']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return "\\tfrac{1}{2}mv_0^{\\,2} = mgL\\sin\\theta + \\mu' mg\\cos\\theta\\,L \\;\\Rightarrow\\; L = " +
      fmt(P.m22.sStop(v), 2) + '\\ \\mathrm{m}';
  },
  note: 'すべり上がるあいだ、<b>動摩擦力は運動と逆（斜面下向き）</b>を向いているので<b>負の仕事</b>をします。' +
    'その分だけ力学的エネルギーが減るので、<b>なめらかな斜面より低いところで止まります</b>。' +
    'エネルギーの式は「はじめの $K$ ＝ 上がった分の $U$ ＋ 摩擦で失われた分」。' +
    '$\\mu\'$ を 0 に近づけると 1-3（なめらかな滑り台）に近づきます。'
};

/* ============ 2-3 鉛直のばね（手の仕事あり）★この単元の山場★ ============ */
DEFS['m2-3'] = {
  id: 'm2-3', mode: 2, tab: '2-3 鉛直のばね（手の仕事あり）',
  title: '2-3　鉛直のばね（手でゆっくり下ろす）',
  sub: '1-12 と<b>同じばね・同じおもり</b>ですが、今度は<b>手で支えながらゆっくり下ろします</b>。' +
    '重力と弾性力（保存力）のほかに<b>手の力（非保存力）が仕事をする</b>ので、力学的エネルギーは保存されません。' +
    'つりあいの位置で手をはなすと、おもりはそこで静止したままになります。',
  cw: 760, ch: 350,        /* 吹きだしの式が長いので、横も縦も広めにとる（第6回で 620 → 760） */
  vis: ['F', 'V', 'A'],
  hasUs: true,
  ptSide: 'stack',
  mainVars: ['k', 'd'],
  mainVarFocus: 'k',
  vars: [
    { k: 'k', label: 'ばね定数 $k$', unit: ' N/m', min: 40, max: 100, step: 5, dec: 0, def: 50 },
    { k: 'd', label: 'はじめの伸び $d$（自然長から下へ）', unit: ' m', min: 0, max: 0.08, step: 0.01, dec: 2, def: 0.00 }
  ],
  consts: { m: 1.0 },
  actions: [
    { label: 'やわらかいばね（k＝40）', fn: function (s) { s.v.k = 40; },
      is: function (v) { return v.k === 40; },
      next: function (s) { return s._played && s.v.k !== 40; } },
    { label: '手をはなす場合（1-12）を見る →', jump: 'm1-12' },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.k = 50; s.v.d = 0; },
      is: function (v) { return v.k === 50 && Math.abs(v.d) < 1e-9; } }
  ],
  cons: false,
  forces: ['g', 'sp', 'hand'],
  hintFig: '<b>手がした仕事の分だけ $E$ が減る</b>。だから<b>つりあいの位置で止まれる</b>' +
    '（手をはなした 1-12 では、その2倍の深さまで行ってしまう）',
  wName: '手の力',
  wSym: 'W_{\\text{手}}',
  step1: '重力と弾性力のほかに、手の力（非保存力）が仕事をしている',
  datum: 'はじめの位置（手をはなす高さ）。下がると高さは負',
  hint2: '<b>次は</b>：<a href="#m1-12" data-goto="m1-12">1-12（手の仕事なし）</a>を見て、手の仕事による結果のちがいを確かめよう。',
  tEnd: function (v) { return P.m23.tEnd(v); },
  sample: function (v, t) { return P.m23.sample(v, t); },
  pts: [
    { name: 'A', jp: 'はじめの状態', t: function () { return 0; },
      sym: { K: '0', Ug: '0', Us: '\\tfrac{1}{2}kd^2' } },
    { name: 'B', jp: 'つりあいの位置', t: function () { return P.m23.T; },
      hsym: 'd-x_{eq}',                /* ★式と図で同じ記号を使う★（第12回） */
      sym: { K: '0', Ug: 'mg(d-x_{\\text{eq}})', Us: '\\tfrac{1}{2}kx_{\\text{eq}}^{\\,2}' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m2-3'], v = V(s), m = d.sample(v, t);
    /* ★横の場所わけ（1-12 と同じ・第6回）★
       左 … 高さの寸法線／まん中 … ばねとおもり／右 … 点の印 → 文字 → 吹きだしの列 */
    var cx = W * 0.34, topY = 46;
    var natY = topY + 86;
    function Y(x) { return natY + x * sc; }
    var xe = P.m19.xEq(v), xl = P.m19.xLow(v);
    /* 縮尺は「1-12 の最下点まで図に収まる」ように決める（見くらべるため） */
    var sc = Math.min(300, (H - 86 - natY) / Math.max(0.05, xl));
    var bw = 40, bh = 26;

    hatchLine(ctx, cx - 52, topY, cx + 52, topY, -1);
    ctx.save();
    ctx.strokeStyle = '#9aa3ac'; ctx.lineWidth = 1.1; ctx.setLineDash([5, 4]);
    ctx.beginPath(); ctx.moveTo(cx - 96, natY); ctx.lineTo(cx + 96, natY); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(cx - 96, Y(xe)); ctx.lineTo(cx + 96, Y(xe)); ctx.stroke();
    ctx.restore();
    /* 文字は線の右のはしの少し上（線が字を横切らないように・第6回） */
    label(ctx, '自然長', cx + 64, natY - 11, { size: 11, color: COL.sub, align: 'left' });
    /* ★式の $x_{eq}$ が図のどこかを見せる★（先生の指示・第12回） */
    label(ctx, 'つりあい x_{eq} = ' + fmt(xe, 3) + ' m', cx + 64, Y(xe) - 11,
      { size: 11, color: COL.sub, align: 'left' });
    datumLine(ctx, cx - 110, W - 96, Y(v.d), '基準面 h = 0（スタート）', true, false);
    /* ★1-12（手をはなす）との見くらべ★（先生の指示・第11回）
       同じばね・同じおもりでも、手が仕事をするかどうかで
       「つりあいの位置での速さ」がまるでちがう。1-12 にも同じパネルを出す。 */
    if (hintOn(s, t)) {
      factPanel(ctx, W * 0.53, 36, 'つりあいの位置（B点）での速さ',
        fmt(d.sample(v, P.m23.T).v, 2) + ' m/s', 'ここで止まる');
    }
    /* ★表の d（はじめの伸び）が図のどこかを見せる★（第6回・1-12 と同じ）
       ★第11回★ d = 0 のときは何も書かない（1-12 と同じ理由） */
    if (Y(v.d) - natY > 7) {
      arrow(ctx, cx - 90, natY, cx - 90, Y(v.d), 'dim');
      arrow(ctx, cx - 90, Y(v.d), cx - 90, natY, 'dim');
      label(ctx, 'はじめの伸び d = ' + fmt(v.d, 2) + ' m', cx - 90, natY - 12,
        { size: 11, color: COL.dim });
    }

    var by = Y(m.x);
    spring(ctx, cx, topY, cx, by - bh / 2, { coils: 11, r: 13, color: COL.hand, lw: 2 });
    /* ★印は1本の列にそろえる★（第6回）ただし2点が同じ高さに見えるときは横にずらす */
    var mDx = (Math.abs(Y(xe) - Y(v.d)) < 26) ? 26 : 0;
    ptMark(ctx, 'A', cx + 40, Y(v.d));
    ptMark(ctx, 'B', cx + 40 + mDx, Y(xe));
    blockShape(ctx, cx, by, 0, bw, bh, '#e8eef5');
    /* 運動が終わったら、点ごとの高さ（drawPts）に任せてこの1本は消す */
    if (!endOn(d, s, t)) heightDim(ctx, cx - 116, by, Y(v.d), 'h = ' + fmt(m.h, 3) + ' m');   /* 下は負 */

    /* 手（手のひらを上に向けて、おもりの下にぴったり接するように支える） */
    handUnder(ctx, cx + 2, by + bh / 2 + 5, 0.85);
    label(ctx, 'ゆっくり下ろす', cx + 74, by + bh / 2 + 40,
      { size: 11, color: COL.sub, align: 'left', avoid: true });

    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 30 / mg;
    function fAt(qq, ay) {
      arrow(ctx, cx, ay, cx, ay + mg * fs, 'force');
      label(ctx, 'mg', cx, ay + mg * fs + 11, { size: 11.5, color: COL.force });
      var F = v.k * qq.x;
      if (F * fs > 3) {
        arrow(ctx, cx, ay - bh / 2, cx, ay - bh / 2 - F * fs, 'force', 1, COL.hand);
        label(ctx, '弾性力 kx', cx + 12, ay - bh / 2 - F * fs + 6, { size: 11, color: COL.hand, align: 'left' });
      }
      if (qq.fh * fs > 3) {
        arrow(ctx, cx - 12, ay + bh / 2, cx - 12, ay + bh / 2 - qq.fh * fs, 'force', 1, COL.hand);
        label(ctx, '手の力 F', cx - 24, ay + bh / 2 - qq.fh * fs - 6,
          { size: 11, color: COL.hand, align: 'right' });
      }
    }
    if (s.o.showF) fAt(m, by);
    if (s.o.showV && Math.abs(m.v) > 0.005) {
      /* ★物体から離して出す★ */
      var vl = vArrowLen(m.v, 0.12, 40);
      var va = velArrow(ctx, cx, by, -1, 0, 76, 0, 1, vl);
      label(ctx, 'v', va.x - 12, va.y, { size: 11.5, color: COL.vel, align: 'right' });
    }
    if (s.o.showA) {
      /* ゆっくり下ろすので加速度はごく小さい。そのことが分かるように書いておく */
      var aA = P.m23.accel(v, t);
      if (Math.abs(aA) > 0.05) drawAcc(ctx, cx, by, 0, aA, { nx: -1, ny: 0, off: bw / 2 + 24 });
      else label(ctx, 'a ≒ 0', cx - bw / 2 - 30, by, { size: 11, color: COL.acc, align: 'right' });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    drawPts(ctx, d, s, t, function (p, mm, i2) {
      var A = (p.name === 'A'), yy = A ? Y(v.d) : Y(xe);
      return { x: cx + 40 + (A ? 0 : mDx), y: yy, ox: cx, oy: yy, bw: bw, bh: bh,
        fdraw: function () { fAt(d.sample(v, p.t), yy); },
        base: Y(v.d), hx: cx - 116 - i2 * 44, hside: (i2 >= 1) ? 'left' : 0 };
    });
  },
  /* ★モード2の見どころ★ とちゅうで「手の力が運動と逆向き（上向き）」を見せる */
  midGhost: function (ctx, s) {
    var d = DEFS['m2-3'], v = V(s), m = d.sample(v, P.m23.T * 0.5);
    var cx = CVW * 0.42, topY = 46, natY = topY + 86;
    var xl = P.m19.xLow(v);
    var sc = Math.min(300, (CVH - 86 - natY) / Math.max(0.05, xl));
    var by = natY + m.x * sc, bw = 40, bh = 26, fs = 30 / (v.m * G);
    ctx.save(); ctx.globalAlpha = 0.9;
    blockShape(ctx, cx, by, 0, bw, bh, '#f2f4f7');
    ctx.restore();
    var vl = vArrowLen(m.v, 0.12, 40);
    var va = velArrow(ctx, cx, by, -1, 0, 56, 0, 1, vl);
    label(ctx, 'v', va.x - 12, va.y, { size: 11, color: COL.vel, align: 'right' });
    if (m.fh * fs > 3) {
      arrow(ctx, cx - 12, by + bh / 2, cx - 12, by + bh / 2 - m.fh * fs, 'force', 1, COL.hand);
      label(ctx, '手の力 F', cx - 26, by + bh / 2 - m.fh * fs - 8,
        { size: 11, color: COL.hand, align: 'right' });
    }
    bubble(ctx, '力は上向き・動きは下向き → 負の仕事！', cx - 116, by + 104,
      { size: 11.5, bg: '#eef2f7', border: COL.eE, color: '#28323d' });
  },
  resItems: function (v) {
    /* ★第11回★「手をはなした場合（1-12）の最下点」はここから消した。
       1-12 とのちがいは、図の中の「つりあいの位置での速さ」のパネルで見せる。 */
    return [
      { k: 'つりあいの位置 $x_{eq}=mg/k$', v: fmt(P.m19.xEq(v), 3) + ' m' },
      { k: '手がした仕事 $W_{手}$', v: fmt(P.m23.W(v, P.m23.T), 2) + ' J' }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m2-3'].sample(v, t);
    return [
      ['ばねの伸び $x$', fmt(m.x, 3) + ' m'],
      ['手の力 $F$', fmt(m.fh, 2) + ' N'],
      ['弾性力 $kx$', fmt(v.k * m.x, 2) + ' N'],
      ['下ろすのにかける時間', fmt(P.m23.T, 1) + ' s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return 'E_2 - E_1 = W_{\\text{手}} = ' + fmt(P.m23.W(v, P.m23.T), 2) +
      '\\ \\mathrm{J}\\quad(\\text{手の力は上向き・動きは下向きなので負})';
  },
  note: '<b>ここがこの単元の山場です。</b>手はおもりを<b>上向きに支え</b>ながら、おもりは<b>下向きに動く</b>ので、' +
    '手のする仕事は<b>負</b>になります。その分だけ力学的エネルギーが減るので、' +
    '<b>つりあいの位置（$x=mg/k$）でぴたりと止まれます</b>。' +
    '手をはなした 1-12 では手が仕事をしないので $E$ が減らず、<b>その2倍の深さ（$2mg/k$）まで</b>行ってしまいます。' +
    '同じばね・同じおもりでも、<b>非保存力が仕事をするかどうかで結果が変わる</b>のです。'
};

/* ============ 2-4 摩擦がある水平面のばね（1-9 の摩擦あり版） ============ */
DEFS['m2-4'] = {
  id: 'm2-4', mode: 2, tab: '2-4 摩擦がある水平面のばね',
  title: '2-4　摩擦がある水平面のばね（1-9 の摩擦あり版）',
  sub: '粗い水平面。ばねを $x_0$ だけ伸ばして手をはなします。' +
    '<b>弾性力（保存力）</b>のほかに<b>動摩擦力（非保存力）</b>が運動と逆向きにはたらくので、' +
    '力学的エネルギーは保存されません。自然長を通るときの速さは ' +
    '$\\tfrac12kx_0^{\\,2} = \\tfrac12mv^2 + \\mu\' mgx_0$ から求めます。',
  cw: 640, ch: 366,        /* 第12回：上に x_0 の寸法線を入れるぶん高くした */
  vis: ['F', 'V', 'A'],
  hasUs: true,
  mainVars: ['x0', 'mu'],
  mainVarFocus: 'mu',
  vars: [
    { k: 'x0', label: 'はじめの伸び $x_0$', unit: ' m', min: 0.20, max: 0.40, step: 0.02, dec: 2, def: 0.30 },
    { k: 'mu', label: '動摩擦係数 $\\mu\'$', unit: '', min: 0.05, max: 0.25, step: 0.05, dec: 2, def: 0.20 },
    { k: 'k', label: 'ばね定数 $k$', unit: ' N/m', min: 40, max: 100, step: 10, dec: 0, def: 40 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 1.5, step: 0.25, dec: 2, def: 1.0 }
  ],
  actions: [
    { label: 'よくすべる床にする（μ′＝0.05）', fn: function (s) { s.v.mu = 0.05; },
      is: function (v) { return Math.abs(v.mu - 0.05) < 1e-9; },
      next: function (s) { return s._played && Math.abs(s.v.mu - 0.05) > 1e-9; } },
    { label: 'もっとざらざらに（μ′＝0.25）', fn: function (s) { s.v.mu = 0.25; },
      is: function (v) { return Math.abs(v.mu - 0.25) < 1e-9; } },
    { label: '摩擦なし（1-9）を見る →', jump: 'm1-9' }
  ],
  cons: false,
  forces: ['g', 'N', 'sp', 'fr'],
  hintFig: '<b>動摩擦力が負の仕事をした分だけ $E$ が減る</b>。' +
    '摩擦がなければ（<span data-goto="m1-9">1-9</span>）振れ幅は小さくならない',
  wName: '動摩擦力',
  wSym: '-\\mu\' mgx_0',
  step1: 'ばねの弾性力のほかに、動摩擦力（非保存力）が運動と逆向きに負の仕事をしている',
  datum: '床（高さは変わらないので $U_g = 0$）',
  hint2: '<b>次は</b>：$\\mu\'$ を変えて、<b>自然長を通る速さ</b>と<b>振れ幅の減り方</b>が' +
    'どう変わるか見てみよう。摩擦なしは <span data-goto="m1-9">1-9</span>。',
  slow: true,                /* ★はじめからスロー再生★（第8回・ばねのシム） */
  tEnd: function (v) { return P.m24.tEnd(v); },
  /* ★グラフの横軸は「止まるまで」だけ★（第14回）
     アニメは「止まる → もう一度はじめから → 点 B で止まる」の2段になっている。 */
  tGraph: function (v) { return P.m24.tGraph(v); },
  /* 2回目の再生のあいだは、グラフのカーソルもはじめにもどす（同じ状態を指す） */
  tCursor: function (v, t) {
    var ts = P.m24.tStop(v);
    return (t > ts + P.m24.HOLD) ? Math.min(t - ts - P.m24.HOLD, P.m24.tNat(v)) : Math.min(t, ts);
  },
  sample: function (v, t) { return P.m24.sample(v, t); },
  pts: [
    { name: 'A', jp: 'スタート（いちばん伸びた所）', t: function () { return 0; },
      sym: { K: '0', Ug: '0', Us: '\\tfrac{1}{2}kx_0^{\\,2}' } },
    { name: 'B', jp: 'はじめて自然長を通る所', t: function (v) { return P.m24.tNat(v); },
      sym: { K: '\\tfrac{1}{2}mv^2', Ug: '0', Us: '0' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m2-4'], v = V(s), m = d.sample(v, t);
    /* ★1-9 より広い縮尺★ 終わりに「A のゴースト・とちゅうの姿・本物」の3つが
       ならぶので、これくらい離さないと重なって見える */
    var sc = 300, gy = H - 82, wallX = 46, natX = wallX + 190;
    function X(x) { return natX + x * sc; }
    var kz = mSize(d, v), bw = 34 * kz, bh = 26 * kz;

    /* 粗い床（ハッチ＋つぶつぶ） */
    ground(ctx, 20, W - 96, gy);
    ctx.save();
    ctx.fillStyle = '#9aa3ac';
    for (var g2 = 26; g2 < W - 100; g2 += 9) {
      ctx.beginPath(); ctx.arc(g2, gy - 2.2, 1.5, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
    datumLine(ctx, 20, W - 96, gy, '基準面 h = 0', true, true);
    /* ★何と何をくらべているのかを、図の上に出す★（先生の指示・第14回）
       何往復も見せると動摩擦力の仕事が求めにくいので、このシムは
       「止まるまで → もう一度はじめから → 点 B で止まる」という再生にしてある。 */
    bannerNote(ctx, ['先ほど見せたように、本来まだ振動が続きますが、ここでは',
      'スタート（点A）と、はじめて自然長の位置（点B）を通過する瞬間をくらべます'], 32);
    /* 壁 */
    ctx.save();
    ctx.fillStyle = '#d7dde4'; ctx.fillRect(wallX - 14, gy - 96, 14, 96);
    ctx.strokeStyle = '#8b949e'; ctx.lineWidth = 1.4; ctx.strokeRect(wallX - 14, gy - 96, 14, 96);
    ctx.restore();
    /* 自然長の位置 */
    ctx.save();
    ctx.strokeStyle = '#9aa3ac'; ctx.lineWidth = 1.2; ctx.setLineDash([5, 4]);
    ctx.beginPath(); ctx.moveTo(natX, gy - 160); ctx.lineTo(natX, gy + 4); ctx.stroke();
    ctx.restore();
    label(ctx, '自然長', natX, gy - 168, { size: 11, color: COL.sub });
    /* ★式の $x_0$（はじめの伸び）が図のどこかを見せる★（先生の指示・第12回）
       $U_k = \tfrac12kx_0^2$ の $x_0$。自然長の線から A（スタート）まで。1-9 と同じ作法。 */
    if (X(v.x0) - natX > 8) {
      /* とちゅうの姿の吹きだしが gy − 100 に出るので、その上に置く */
      var y0d = gy - 140;
      arrow(ctx, natX, y0d, X(v.x0), y0d, 'dim');
      arrow(ctx, X(v.x0), y0d, natX, y0d, 'dim');
      label(ctx, 'x_0 = ' + fmt(v.x0, 2) + ' m', (natX + X(v.x0)) / 2, y0d - 11,
        { size: 11, color: COL.dim });
    }

    var cx = X(m.x), cy = gy - bh / 2;
    spring(ctx, wallX, cy, cx - bw / 2, cy, { coils: 10, r: 11, color: COL.hand, lw: 2 });
    ptMark(ctx, 'A', X(v.x0) + bw / 2 + 13, gy - bh / 2);
    ptMark(ctx, 'B', natX - bw / 2 - 13, gy - bh / 2);
    blockShape(ctx, cx, cy, 0, bw, bh, '#e8eef5');
    /* 伸びの寸法 */
    if (Math.abs(m.x) > 0.005) {
      arrow(ctx, natX, gy + 18, cx, gy + 18, 'dim');
      label(ctx, 'x = ' + fmt(m.x, 2) + ' m', (natX + cx) / 2, gy + 32, { size: 11, color: COL.dim });
    }
    var hA = (t <= 0.16) ? 1 : Math.max(0, 1 - (t - 0.16) / 0.20);
    if (hA > 0.02) dropHand(ctx, X(v.x0) + bw / 2 + 6, cy, 0.5, clamp(t / 0.16, 0, 1), hA);

    /* ★力の縮尺は大きめにとる★（先生の指摘・第7回）
       もとは「mg が 30 px」だったが、動摩擦力 μ'N は mg の 1/5〜1/3 しかないので
       5〜10 px にしかならず、いちばん見せたい力が見えなかった。
       矢印の長さの比は力の比のまま（★量に比例★ レイアウト規約 ㉞）。 */
    /* ★縮尺は「その図でいちばん大きい力」から決める★（第7回）
       ここはばねの力（最大 k·x₀）が mg より大きくなることがあるので、mg でそろえると
       ばねの矢印が図からはみ出す。いちばん大きい力を 76 px にして、あとは同じ比で描く
       （前は、ばねの力だけ 0.55 倍にしていた＝力の比が絵とちがっていた。第7回に直した）。 */
    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 76 / Math.max(mg, v.k * v.x0);
    function fAt(qq, ax) {
      arrow(ctx, ax, cy, ax, cy + mg * fs, 'force');
      label(ctx, 'mg', ax, cy + mg * fs + 11, { size: 11.5, color: COL.force });
      arrow(ctx, ax, gy, ax, gy - mg * fs, 'force', 1, COL.norm);
      label(ctx, 'N', ax + bw / 2 + 8, gy - mg * fs + 4, { align: 'left', size: 11.5, color: COL.norm });
      var F = -v.k * qq.x, fl = F * fs;
      if (Math.abs(fl) > 3) {
        arrow(ctx, ax - bw / 2, cy, ax - bw / 2 + fl, cy, 'force', 1, COL.hand);
        label(ctx, '弾性力 kx', ax - bw / 2 + fl / 2, cy - 15, { size: 11, color: COL.hand });
      }
      /* 動摩擦力は「運動と逆向き」 */
      if (qq.moving && Math.abs(qq.vs) > 1e-6) {
        var dir = (qq.vs > 0 ? -1 : 1), ffl = qq.f * fs;
        arrow(ctx, ax, gy - 3, ax + dir * ffl, gy - 3, 'force', 1, COL.fric);
        label(ctx, 'μ\'N', ax + dir * (ffl + 10), gy - 17,
          { align: dir > 0 ? 'left' : 'right', size: 11.5, color: COL.fric });
      }
    }
    if (s.o.showF) fAt(m, cx);
    if (s.o.showV && m.v > 0.05) {
      /* ★物体から離して出す★（ブロックの上 40 px） */
      var sgv = (m.vs > 0 ? 1 : -1), vl = vArrowLen(m.v, Math.max(0.3, P.m24.vNat(v)), 48);
      var va = velArrow(ctx, cx, cy, 0, -1, mg * fs - bh / 2 + 22, sgv, 0, vl);
      label(ctx, 'v', va.tx + sgv * 10, va.ty, { size: 11.5, color: COL.vel });
    }
    if (s.o.showA) {
      var ax = (-v.k * m.x - (m.moving && Math.abs(m.vs) > 1e-6 ? (m.vs > 0 ? 1 : -1) * m.f : 0)) / v.m;
      drawAcc(ctx, cx, cy, ax, 0, { nx: 0, ny: -1, off: mg * fs - bh / 2 + 58 });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    drawPts(ctx, d, s, t, function (p) {
      var A = (p.name === 'A');
      var q = d.sample(v, p.t);
      /* 吹きだしは、物体の横に置いた印から引き出す */
      return { x: (A ? X(v.x0) + bw / 2 + 13 : natX - bw / 2 - 13), y: gy - bh / 2,
        ox: A ? X(v.x0) : natX, oy: gy - bh / 2, bw: bw, bh: bh,
        fdraw: function () { fAt(q, A ? X(v.x0) : natX); },
        /* 終わりに物体がその点と同じ場所にいるときは、ゴーストを描かない */
        here: Math.abs(m.x - (A ? v.x0 : 0)) < 0.004,
        vx: (q.vs >= 0 ? 1 : -1), vy: 0, vref: Math.max(0.3, P.m24.vNat(v)), vk: 48, voff: bw / 2 + 10 };
    });
  },
  /* ★モード2の見どころ★ とちゅうで「動摩擦力が運動と逆向き」を見せる */
  midGhost: function (ctx, s) {
    /* ★A と B のまん中（伸びが x0/2 の所）に置く★ 時刻で半分にすると、
       物体が B に寄りすぎて本物と重なってしまう。 */
    var d = DEFS['m2-4'], v = V(s), tm = P.m24.tAtX(v, v.x0 / 2), m = d.sample(v, tm);
    var sc = 300, gy = CVH - 82, wallX = 46, natX = wallX + 190;
    var kz = mSize(d, v), bw = 34 * kz, bh = 26 * kz;
    var cx = natX + m.x * sc, cy = gy - bh / 2, fs = 76 / Math.max(v.m * G, v.k * v.x0);
    ctx.save(); ctx.globalAlpha = 0.9;
    blockShape(ctx, cx, cy, 0, bw, bh, '#f2f4f7');
    ctx.restore();
    /* 速度の矢印は、本物より1段上に出す（同じ高さだと2本ならんで分かりにくい） */
    var vl = vArrowLen(m.v, Math.max(0.3, P.m24.vNat(v)), 48);
    var va = velArrow(ctx, cx, cy, 0, -1, v.m * G * fs - bh / 2 + 22, -1, 0, vl);
    label(ctx, 'v', va.tx - 10, va.ty, { align: 'right', size: 11, color: COL.vel });
    var ffl = m.f * fs;
    arrow(ctx, cx, gy - 3, cx + ffl, gy - 3, 'force', 1, COL.fric);
    label(ctx, 'μ\'N', cx + ffl + 10, gy - 17, { align: 'left', size: 11, color: COL.fric });
    /* ★第9回★ しっぽ（▼）の先は「動摩擦力の矢印の まん中の真上」にそろえる */
    bubble(ctx, '力の向きが運動と逆 → 負の仕事！', cx + ffl / 2, gy - 100,
      { size: 11.5, bg: '#eef2f7', border: COL.eE, color: '#28323d' });
  },
  resItems: function (v) {
    return [
      { k: '自然長を通る速さ（式）', v: fmt(P.m24.vNat(v), 2) + ' m/s' },
      { k: '摩擦がなければ（1-9）', v: fmt(v.x0 * Math.sqrt(v.k / v.m), 2) + ' m/s' },
      { k: '最後に止まる伸び', v: fmt(P.m24.xStop(v), 3) + ' m' }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m2-4'].sample(v, t);
    return [
      ['ばねの伸び $x$', fmt(m.x, 3) + ' m'],
      ['弾性力 $kx$', fmt(v.k * Math.abs(m.x), 1) + ' N'],
      ['動摩擦力 $\\mu\' mg$', fmt(P.m24.f(v), 2) + ' N'],
      ['動いた道のり', fmt(m.path, 3) + ' m'],
      ['熱になったエネルギー', fmt(-m.W, 2) + ' J']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return '\\tfrac{1}{2}kx_0^{\\,2} = \\tfrac{1}{2}mv^2 + \\mu\' mgx_0 \\;\\Rightarrow\\; v = ' +
      fmt(P.m24.vNat(v), 2) + '\\ \\mathrm{m/s}';
  },
  note: 'ばねの弾性力は<b>保存力</b>、動摩擦力は<b>非保存力</b>です。' +
    '動摩擦力はいつも運動と逆を向いているので<b>負の仕事</b>をし、その分だけ $E$ が減ります。' +
    'だから<b>行ったり来たりするたびに振れ幅が小さくなり</b>、やがて止まります。' +
    '$\\mu\'$ を 0 に近づけると <span data-goto="m1-9">1-9</span>（摩擦なし）に近づきます。'
};

/* ============ 2-5 摩擦がある斜面を、糸で引き上げる ============ */
DEFS['m2-5'] = {
  id: 'm2-5', mode: 2, tab: '2-5 斜面を糸で引き上げる',
  title: '2-5　摩擦がある斜面を、糸で引き上げる',
  sub: '粗い斜面にそって、一定の力 $F$ で長さ $L$ だけ引き上げます。' +
    '<b>糸の力は正の仕事</b>、<b>動摩擦力は負の仕事</b>をする<b>どちらも非保存力</b>です。' +
    'エネルギーの式は $\\tfrac12mv^2 + mgL\\sin\\theta = FL - \\mu\' mg\\cos\\theta\\,L$。',
  cw: 640, ch: 360,
  vis: ['F', 'Fc', 'V', 'A'],
  mainVars: ['Ft', 'mu'],
  mainVarFocus: 'Ft',
  vars: [
    { k: 'Ft', label: '糸の力 $F$', unit: ' N', min: 32, max: 44, step: 2, dec: 0, def: 36 },
    { k: 'mu', label: '動摩擦係数 $\\mu\'$', unit: '', min: 0.15, max: 0.50, step: 0.05, dec: 2, def: 0.40 },
    { k: 'th', label: '斜面の角 $\\theta$', unit: '°', min: 20, max: 45, step: 5, dec: 0, def: 30 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 2.0, max: 3.0, step: 0.5, dec: 1, def: 2.0 }
  ],
  actions: [
    { label: '強く引く（F＝44 N）', fn: function (s) { s.v.Ft = 44; },
      is: function (v) { return v.Ft === 44; },
      next: function (s) { return s._played && s.v.Ft !== 44; } },
    { label: 'ざらざらにする（μ′＝0.50）', fn: function (s) { s.v.mu = 0.50; },
      is: function (v) { return Math.abs(v.mu - 0.50) < 1e-9; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.Ft = 36; s.v.mu = 0.40; s.v.th = 30; },
      is: function (v) { return v.Ft === 36 && Math.abs(v.mu - 0.40) < 1e-9 && v.th === 30; } }
  ],
  cons: false,
  forces: ['g', 'N',
    { key: 'pull', name: '糸の力', sym: 'F', color: COL.hand,
      w: function (v, A, B) { return v.Ft * ((B.m.s || 0) - (A.m.s || 0)); },
      wsym: 'W_F = F L\\cos 0^\\circ = FL',
      why: '糸の力は<b>非保存力</b>。動く向きと同じ向きなので、いつも<b>正の仕事</b>。' },
    { key: 'fr', name: '動摩擦力',
      w: function (v, A, B) { return -P.m25.fr(v) * ((B.m.s || 0) - (A.m.s || 0)); } }],
  rate: function (v) { return clamp(P.m25.tEnd(v) / 2.4, 0.3, 1); },
  hintFig: '<b>糸の力は正の仕事、動摩擦力は負の仕事</b>。合わせた分だけ $E$ が増える',
  wName: '糸の力と動摩擦力',
  wSym: '(F - \\mu\' mg\\cos\\theta)L',
  step1: '重力のほかに、糸の力（正の仕事）と動摩擦力（負の仕事）＝非保存力が仕事をしている',
  datum: '出発点（斜面の下端）',
  /* ★第13回：F は 32〜44 N しか選べないので、「動きだせなくなるまで小さくする」は
     このシムではできない（動きだすのに必要な力は既定の設定で 16.6 N）。
     押せば必ずできることだけを「次は」に書く。 */
  hint2: '<b>次は</b>：$F$ を <b>44 N → 32 N</b> と小さくして、<b>$E$ の増え方</b>（＝糸がした仕事）が' +
    'どう変わるか見てみよう。動きだすのに必要な力は $mg\\sin\\theta + \\mu\' mg\\cos\\theta$ で、' +
    'いまの設定では <b>16.6 N</b>。このシムの $F$ はいつもそれより大きくしてあります。',
  tEnd: function (v) { return P.m25.tEnd(v); },
  sample: function (v, t) { return P.m25.sample(v, t); },
  pts: [
    { name: 'A', jp: 'スタート（下端・静止）', t: function () { return 0; },
      sym: { K: '0', Ug: '0' } },
    { name: 'B', jp: '$L$ だけ引き上げた所', t: function (v) { return P.m25.tEnd(v); },
      hsym: 'L sinθ',                  /* ★式と図で同じ記号を使う★（第12回） */
      sym: { K: '\\tfrac{1}{2}mv^2', Ug: 'mgL\\sin\\theta' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m2-5'], v = V(s), m = d.sample(v, t), L = P.m25.L;
    var th = v.th * DEG, gy = H - 62, x0 = 76;
    var ux = Math.cos(th), uy = -Math.sin(th);      /* 斜面を上る向き */
    /* ★斜面から外向き★ 右上がりの坂では「左上」（ux と直角）。第7回に符号を直した */
    var nx = -Math.sin(th), ny = -Math.cos(th);
    /* ★縮尺は固定★（L も固定なので、θ を変えても坂の「長さ」は変わらず、
       傾きだけが変わる。自動にすると θ で坂の長さが変わって見くらべられない） */
    var SC = SC_PULL;
    function P2(sv) { return { x: x0 + ux * sv * SC, y: gy + uy * sv * SC }; }
    var top = P2(L * SMAX_PULL);

    /* 斜面（粗い面） */
    ctx.save();
    ctx.fillStyle = '#eef1f4';
    ctx.beginPath(); ctx.moveTo(x0, gy); ctx.lineTo(top.x, top.y); ctx.lineTo(top.x, gy);
    ctx.closePath(); ctx.fill();
    ctx.restore();
    hatchLine(ctx, x0, gy, top.x, top.y, -1);
    ctx.save();
    ctx.fillStyle = '#9aa3ac';
    for (var q = 0.12; q < L * SMAX_PULL; q += 0.22) {
      var pp = P2(q);
      ctx.beginPath(); ctx.arc(pp.x + nx * 2.4, pp.y + ny * 2.4, 1.5, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
    ground(ctx, 20, W - 96, gy);
    datumLine(ctx, 20, W - 96, gy, '基準面 h = 0', true, true);
    angArc(ctx, x0, gy, 30, -th, 0, '', 0, 0);
    label(ctx, 'θ = ' + fmt(v.th, 0) + '°', x0 + 44, gy - 12, { size: 12, color: COL.sub, align: 'left' });

    var kz = mSize(d, v), bw = 30 * kz, bh = 22 * kz;
    var pA = P2(0), pB = P2(L);
    /* ★印は斜面の「中（下がわ）」★（第6回）
       2-5 は坂の上に糸・手・F の矢印がならぶので、外がわには置けない。 */
    var mkA = { x: pA.x - nx * 20, y: pA.y - ny * 20 };
    var mkB = { x: pB.x - nx * 20, y: pB.y - ny * 20 };
    ptMark(ctx, 'A', mkA.x, mkA.y);
    ptMark(ctx, 'B', mkB.x, mkB.y);
    /* ★式の $L$（引く長さ）が図のどこかを見せる★（先生の指示・第12回）
       $U_g = mgL\sin\theta$ の $L$。A の印と B の印の間に、坂と平行な両矢印をひく。
       ここは決めた値なので、はじめから出しておく。 */
    var lu1 = { x: pA.x + nx * 44, y: pA.y + ny * 44 };
    var lu2 = { x: pB.x + nx * 44, y: pB.y + ny * 44 };
    arrow(ctx, lu1.x, lu1.y, lu2.x, lu2.y, 'dim');
    arrow(ctx, lu2.x, lu2.y, lu1.x, lu1.y, 'dim');
    label(ctx, 'L = ' + fmt(L, 1) + ' m', (lu1.x + lu2.x) / 2 + nx * 15,
      (lu1.y + lu2.y) / 2 + ny * 15, { size: 11.5, color: COL.dim });

    /* ★通った跡（うすい長方形）は描かない★（先生の指示・第6回）
       まっすぐ上がるだけなので、たくさん並ぶと図がうるさいだけだった。
       「とちゅうの姿」は midGhost が1つだけ出す。 */
    var p0 = P2(m.s), cx = p0.x + nx * bh / 2, cy = p0.y + ny * bh / 2;
    /* ★糸を引く手は、物体といっしょに斜面を上がっていく★（先生の指示・第7回）
       前は坂の上のはしに置きっぱなしだったので、引いているように見えなかった。
       物体の中心から、斜面にそって HAND_GAP [m] だけ上に手を置く。 */
    var HAND_GAP = 1.5;      /* 糸の力 F の矢印（最大 76 px）より外に手が来るようにする */
    var hp = P2(Math.min(m.s + HAND_GAP, L * SMAX_PULL));
    var wx = hp.x + nx * 15, wy = hp.y + ny * 15;
    ctx.save();
    ctx.strokeStyle = COL.hand; ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.moveTo(cx + ux * bw / 2, cy + uy * bw / 2);
    ctx.lineTo(wx, wy);
    ctx.stroke();
    ctx.restore();
    hand(ctx, wx, wy, -th);          /* ★人が手で引く★（先生の指示・第6回） */
    blockShape(ctx, cx, cy, th, bw, bh, '#e8eef5');
    if (!endOn(d, s, t)) heightDim(ctx, 26, p0.y, gy, 'h = ' + fmt(m.h, 2) + ' m', cx, true);

    /* ★力の縮尺は大きめにとる★（先生の指摘・第7回）
       もとは「mg が 30 px」だったが、動摩擦力 μ'N は mg の 1/5〜1/3 しかないので
       5〜10 px にしかならず、いちばん見せたい力が見えなかった。
       矢印の長さの比は力の比のまま（★量に比例★ レイアウト規約 ㉞）。 */
    /* 縮尺は「その図でいちばん大きい力」から決める（糸の力 F が mg より大きい） */
    var mg = v.m * G, fs = 76 / Math.max(mg, v.Ft);
    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    function fAt(qq, sx, sy) {
      var ax = sx + nx * bh / 2, ay = sy + ny * bh / 2;
      arrow(ctx, ax, ay, ax, ay + mg * fs, 'force');
      label(ctx, 'mg', ax, ay + mg * fs + 11, { size: 11.5, color: COL.force });
      arrow(ctx, sx, sy, sx + nx * qq.N * fs, sy + ny * qq.N * fs, 'force', 1, COL.norm);
      label(ctx, 'N', sx + nx * (qq.N * fs + 12), sy + ny * (qq.N * fs + 12),
        { size: 11.5, color: COL.norm });
      var fl = qq.f * fs;
      arrow(ctx, sx, sy, sx - ux * fl, sy - uy * fl, 'force', 1, COL.fric);
      label(ctx, 'μ\'N', sx - ux * (fl + 14), sy - uy * (fl + 14), { size: 11.5, color: COL.fric });
      var Fl = v.Ft * fs;
      arrow(ctx, ax + ux * bw / 2, ay + uy * bw / 2,
        ax + ux * (bw / 2 + Fl), ay + uy * (bw / 2 + Fl), 'force', 1, COL.hand);
      label(ctx, 'F', ax + ux * (bw / 2 + Fl + 12) + nx * 10,
        ay + uy * (bw / 2 + Fl + 12) + ny * 10, { size: 11.5, color: COL.hand });
    }
    if (s.o.showF) fAt(m, p0.x, p0.y);
    if (s.o.showFc) {
      var gs = mg * Math.sin(th);
      arrow(ctx, cx, cy, cx - ux * gs * fs, cy - uy * gs * fs, 'comp');
      label(ctx, 'mg sinθ', cx - ux * gs * fs - 12, cy - uy * gs * fs + 13, { size: 11, color: COL.force });
    }
    if (s.o.showV && m.v > 0.05) {
      /* ★N の矢じりより外に出す★（力の縮尺を大きくしたので） */
      var vof = m.N * fs - bh / 2 + 22, vl = vArrowLen(m.v, Math.max(1, P.m25.vEnd(v)), 48);
      var va = velArrow(ctx, cx, cy, nx, ny, vof, ux, uy, vl);
      label(ctx, 'v', va.tx + ux * 10, va.ty + uy * 10, { size: 11.5, color: COL.vel });
    }
    if (s.o.showA) {
      var aa = P.m25.a(v);           /* 斜面を上る向き（＝運動と同じ向き）に一定 */
      drawAcc(ctx, cx, cy, ux * aa, uy * aa,
        { nx: nx, ny: ny, off: m.N * fs - bh / 2 + 58 });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    drawPts(ctx, d, s, t, function (p, mm, i2) {
      var q2 = (p.name === 'A') ? pA : pB, mk5 = (p.name === 'A') ? mkA : mkB;
      return { x: mk5.x, y: mk5.y,
        fdraw: function () { fAt(d.sample(v, p.t), q2.x, q2.y); },
        ox: q2.x + nx * bh / 2, oy: q2.y + ny * bh / 2, bw: bw, bh: bh, ang: th,
        vx: ux, vy: uy, vref: Math.max(1, P.m25.vEnd(v)), vk: 48, voff: 28, base: gy, hx: 26 + i2 * 20 };
    });
  },
  /* ★モード2の見どころ★ 2つの非保存力の向きを、とちゅうの姿で見せる */
  midGhost: function (ctx, s) {
    var d = DEFS['m2-5'], v = V(s), L = P.m25.L, m = d.sample(v, P.m25.tEnd(v) * 0.62);
    var th = v.th * DEG, gy = CVH - 62, x0 = 76;
    var ux = Math.cos(th), uy = -Math.sin(th), nx = -Math.sin(th), ny = -Math.cos(th);
    var SC = SC_PULL;
    var kz = mSize(d, v), bw = 30 * kz, bh = 22 * kz;
    var px = x0 + ux * m.s * SC, py = gy + uy * m.s * SC;
    var cx = px + nx * bh / 2, cy = py + ny * bh / 2, fs = 76 / Math.max(v.m * G, v.Ft);
    ctx.save(); ctx.globalAlpha = 0.9;
    blockShape(ctx, cx, cy, th, bw, bh, '#f2f4f7');
    ctx.restore();
    var vl = vArrowLen(m.v, Math.max(1, P.m25.vEnd(v)), 48);
    var va = velArrow(ctx, cx, cy, nx, ny, m.N * fs - bh / 2 + 22, ux, uy, vl);
    label(ctx, 'v', va.tx + ux * 10, va.ty + uy * 10, { size: 11, color: COL.vel });
    var fl = m.f * fs;
    arrow(ctx, px, py, px - ux * fl, py - uy * fl, 'force', 1, COL.fric);
    label(ctx, 'μ\'N', px - ux * (fl + 14), py - uy * (fl + 14), { size: 11, color: COL.fric });
    var Fl = v.Ft * fs;
    arrow(ctx, cx + ux * bw / 2, cy + uy * bw / 2,
      cx + ux * (bw / 2 + Fl), cy + uy * (bw / 2 + Fl), 'force', 1, COL.hand);
    label(ctx, 'F', cx + ux * (bw / 2 + Fl + 12) + nx * 10,
      cy + uy * (bw / 2 + Fl + 12) + ny * 10, { size: 11, color: COL.hand });
    /* 2つの非保存力は向きが逆。★第9回★ しっぽ（▼）の先は、
       それぞれ「その力の矢印の まん中」にそろえる（何の力の話か分かるように）。
       F は坂の外がわ（上）から、μ'N は坂の内がわ（下）から出す。
       fmx/fmy＝動摩擦力の矢印のまん中、Fmx/Fmy＝F の矢印のまん中。 */
    var fmx = px - ux * fl / 2, fmy = py - uy * fl / 2;
    var Fmx = cx + ux * (bw / 2 + Fl / 2), Fmy = cy + uy * (bw / 2 + Fl / 2);
    /* しっぽ（▼）はまっすぐ下を向くので、ずらすのは たて だけ（横は矢印のまん中のまま） */
    /* 2つとも坂の外がわ（上）に、たてにはなして置く。
       上が F（坂の上がわの矢印）、下が μ'N（坂の下がわの矢印）。 */
    /* F（坂を上る向き）の吹きだしは、坂の外がわ（上）から矢印のまん中へ。 */
    bubble(ctx, 'F は運動と同じ向き → 正の仕事！', Fmx, Fmy + ny * 96,
      { size: 11.5, bg: '#eef2f7', border: COL.eE, color: '#28323d' });
    /* μ'N の吹きだしは、坂の下のあきから上向きに出す。
       箱をそのまま置くと「θ = ○°」の文字とぶつかるので、しっぽの先（＝動摩擦力の
       矢印のまん中）はそのままにして、箱だけ右へずらす（bubble の dx）。
       ずらす量は、箱の左はしが θ の文字より右に来るように、そのつど計算する。 */
    var txF = 'μ\'N は運動と逆向き → 負の仕事！';
    ctx.save(); ctx.font = 'bold 11.5px ' + FONT;
    var wF = ctx.measureText(txF).width + 18;
    ctx.restore();
    var dxF = clamp(x0 + 116 + wF / 2 - fmx, 0, wF / 2 + 80);
    /* 地面より下は「A の吹きだし」の帯なので、そこまで下げない */
    bubble(ctx, txF, fmx, Math.min(fmy - ny * 30, gy - 18),
      { size: 11.5, up: true, dx: dxF, bg: '#eef2f7', border: COL.eE, color: '#28323d' });
  },
  resItems: function (v) {
    return [
      { k: '引く長さ $L$', v: fmt(P.m25.L, 1) + ' m' },
      { k: '動きだすのに必要な力（式）', v: fmt(P.m25.need(v), 1) + ' N' },
      { k: '上がった高さ $L\\sin\\theta$', v: fmt(P.m25.L * Math.sin(v.th * DEG), 2) + ' m' },
      { k: '$B$ での速さ（式）', v: fmt(P.m25.vEnd(v), 2) + ' m/s' }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m2-5'].sample(v, t);
    return [
      ['斜面にそって進んだ距離', fmt(m.s, 2) + ' m'],
      ['動摩擦力 $\\mu\' mg\\cos\\theta$', fmt(m.f, 2) + ' N'],
      ['加速度 $a$', fmt(P.m25.a(v), 2) + ' m/s²'],
      ['糸の力がした仕事', fmt(v.Ft * m.s, 2) + ' J'],
      ['動摩擦力がした仕事', fmt(-m.f * m.s, 2) + ' J']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return '\\tfrac{1}{2}mv^2 + mgL\\sin\\theta = FL - \\mu\' mg\\cos\\theta\\,L \\;\\Rightarrow\\; v = ' +
      fmt(P.m25.vEnd(v), 2) + '\\ \\mathrm{m/s}';
  },
  note: '非保存力は<b>1つとはかぎりません</b>。ここでは<b>糸の力（正の仕事）</b>と' +
    '<b>動摩擦力（負の仕事）</b>の2つがはたらいています。' +
    '$E$ の変化は、この2つの仕事を<b>合計した分</b>です（$E_2-E_1=W_{\\text{非保存}}$）。' +
    '「仕事を表示」で1つずつ見ると、正と負がはっきり分かります。'
};
```

## src/80_ui.js

```js
/* 状態 st と DOM。render は st だけから描く。
   basics-of-motion-on-plane.html の 80_ui.js を受けついで、
   ・「正の向き」の切りかえと問題モードを外し（エネルギーはスカラーなので向きがない）
   ・計算結果の帯／2点をくらべる式／法則の箱／各点の表 を足したもの。 */
'use strict';

/* allEq … 「3つの式を表示」のチェック。★全シムで共有する★（先生の指示・第4回） */
var st = { cur: 'm1-1', sims: {}, bigFml: false, allEq: false, workMode: false,
  _fHover: null, _fSel: null };   /* _fSel＝右の欄で選ばれている力（図の中で光る・第7回） */

/* 表示チェックボックス（このページは3つだけ） */
var VIS_LABEL = { F: '力を表示', Fc: '分解した力を表示', V: '速度ベクトルを表示',
  A: '加速度ベクトルを表示' };
var VIS_DEF = { F: true, Fc: false, V: true, A: false };   /* 加速度は既定で OFF */

/* 変数（v）と表示オプション（o）をまとめて物理へ渡す */
function V(s) {
  var o = {}, k;
  for (k in s.v) o[k] = s.v[k];
  for (k in s.o) o[k] = s.o[k];
  return o;
}

function $(id) { return document.getElementById(id); }

function graphsOf(d, s) {
  var list = d.graphs || [];
  if (!s) return list;
  var v = V(s);
  return list.filter(function (g) { return !g.when || g.when(v); });
}

/* ===== エネルギーのグラフ（全シム共通の4枚）=====
   K–t 図・U–t 図・E–t 図と、3本を重ねた1枚。
   「K が減った分だけ U が増え、E は水平のまま」が一目で分かるように、
   重ねた1枚を既定で開いておく。 */
function energyGraphs(d) {
  var us = !!d.hasUs;
  function sK(m) { return m.K; }
  function sU(m) { return m.U; }
  function sUg(m) { return m.Ug; }
  function sUs(m) { return m.Us; }
  function sE(m) { return m.E; }
  function E0(v) { return d.sample(v, 0).E; }
  function nums(v) {
    var a = d.sample(v, 0), b = d.sample(v, d.tEnd(v));
    return { a: a, b: b };
  }
  var uSeries = us
    ? [{ name: 'U = U_g + U_k', color: COL.eU, dash: [7, 4], f: sU },
       { name: 'U_g 重力', color: COL.eU, width: 1.5, f: sUg },
       { name: 'U_k ばね', color: COL.eU, width: 1.5, dash: [2, 3], f: sUs }]
    : [{ name: 'U 位置エネルギー', color: COL.eU, dash: [7, 4], f: sU }];

  var g = [];
  g.push({
    key: 'KUE', short: '$K$・$U$・$E$ を重ねた図',
    title: '$K$・$U$・$E$ を重ねた図　※まずここを見る', ylabel: 'エネルギー [J]',
    open: true, H: 208,
    /* ★重なったときに下になる線から先に描く★
       E と K がぴったり重なる（U = 0 の）シムでは、E を先に描かないと K が見えない */
    series: [{ name: 'E = K + U', color: COL.eE, width: 3.2, f: sE, fillTo: E0 }]
      .concat(us ? [{ name: 'U = U_g+U_k', color: COL.eU, dash: [7, 4], f: sU }] : uSeries)
      .concat([{ name: 'K 運動エネルギー', color: COL.eK, f: sK }]),
    /* 凡例は K → U → E の順（式の書き方とそろえる） */
    legend: [{ name: 'K 運動エネルギー', color: COL.eK },
      { name: 'U 位置エネルギー', color: COL.eU, dash: [7, 4] },
      { name: 'E = K + U', color: COL.eE, width: 3.2 }],
    fml: function (v) {
      var n = nums(v);
      if (consOf(d, v)) {
        return ['E = K + U \\;(\\text{一定})',
          'E = \\tfrac{1}{2}mv^2 + ' + (us ? 'mgh + \\tfrac{1}{2}kx^2' : 'mgh'),
          'E = ' + fmtE(n.a.E) + '\\ \\mathrm{J}\\;\\to\\;' + fmtE(n.b.E) + '\\ \\mathrm{J}\\;(\\text{変わらない})'];
      }
      return ['E_2 - E_1 = W_{\\text{非保存}}',
        'E_2 - E_1 = ' + (d.wSym || 'W_{\\text{非保存}}'),
        fmtE(n.b.E) + ' - ' + fmtE(n.a.E) + ' = ' + fmtE(n.b.E - n.a.E) + '\\ \\mathrm{J}'];
    }
  });
  g.push({
    key: 'K', short: '$K$–$t$ 図', title: '$K$–$t$ 図（運動エネルギー）', ylabel: 'K [J]', open: false,
    series: [{ color: COL.eK, f: sK }],
    fml: function (v) {
      var n = nums(v);
      return ['K = \\tfrac{1}{2}mv^2',
        'K = \\tfrac{1}{2}\\times' + fmt(v.m, 1) + '\\times v^2',
        'K:\\;' + fmtE(n.a.K) + '\\ \\mathrm{J}\\;\\to\\;' + fmtE(n.b.K) + '\\ \\mathrm{J}'];
    }
  });
  g.push({
    key: 'U', short: '$U$–$t$ 図', title: '$U$–$t$ 図（位置エネルギー）', ylabel: 'U [J]', open: false,
    legend: us, series: uSeries,
    fml: function (v) {
      var n = nums(v);
      return [us ? 'U = mgh + \\tfrac{1}{2}kx^2' : 'U = mgh',
        'U = ' + fmt(v.m, 1) + '\\times 9.8 \\times h' + (us ? ' + \\tfrac{1}{2}\\times' + fmt(v.k, 0) + '\\times x^2' : ''),
        'U:\\;' + fmtE(n.a.U) + '\\ \\mathrm{J}\\;\\to\\;' + fmtE(n.b.U) + '\\ \\mathrm{J}'];
    }
  });
  g.push({
    key: 'E', short: '$E$–$t$ 図', title: '$E$–$t$ 図（力学的エネルギー）', ylabel: 'E [J]', open: false,
    series: [{ color: COL.eE, width: 3.2, f: sE, fillTo: E0 }],
    fml: function (v) {
      var n = nums(v);
      if (consOf(d, v)) {
        return ['E = K + U', 'E = \\text{一定}（\\text{保存力だけが仕事をしている}）',
          'E = ' + fmtE(n.a.E) + '\\ \\mathrm{J}\\;(\\text{ずっと同じ})'];
      }
      return ['E(t) = E(0) + W_{\\text{非保存}}(t)',
        'E(t) = E(0) + ' + (d.wSym || 'W_{\\text{非保存}}'),
        'E:\\;' + fmtE(n.a.E) + '\\ \\mathrm{J}\\;\\to\\;' + fmtE(n.b.E) +
        '\\ \\mathrm{J}\\;(' + fmtE(n.b.E - n.a.E) + '\\ \\mathrm{J})'];
    }
  });
  return g;
}

function initState() {
  Object.keys(DEFS).forEach(function (id) {
    var d = DEFS[id];
    if (!d.graphs) d.graphs = energyGraphs(d);
    var s = {
      /* slow … ★ばねのシムは速すぎるので、はじめからスロー再生にする★（先生の指示・第8回）
         DEFS に slow: true と書いたシムだけ、最初からスローで動く。 */
      v: {}, o: {}, t: 0, playing: false, slow: !!d.slow,
      open: {}, gview: {}, _eq: null, _played: false,
      /* 立式の3つの開閉（null＝まだ決めていない＝保存の成否と st.allEq で決める）と、
         「仕事を表示」でいま選んでいる力 */
      eqOpen: null, wkSel: null,
      /* 立式でくらべる2つめの点（null なら最後の点）と、
         「一度でも最後まで進めたか」（仕事の分析の欄を出しておくかどうか） */
      eqPair: null, _wkReady: false
    };
    d.vars.forEach(function (vd) { s.v[vd.k] = vd.def; });
    (d.toggles || []).forEach(function (td) { s.o[td.k] = td.def; });
    (d.selects || []).forEach(function (sd) { s.o[sd.k] = sd.def; });
    (d.vis || []).forEach(function (k) {
      s.o['show' + k] = (d.visDef && d.visDef[k] !== undefined) ? d.visDef[k] : VIS_DEF[k];
    });
    if (d.consts) Object.keys(d.consts).forEach(function (k) { s.o[k] = d.consts[k]; });
    (d.graphs || []).forEach(function (g) { s.open[g.key] = !!g.open; });
    st.sims[id] = s;
  });
}

/* ===== 凡例の小さな線・矢印 ===== */
function drawLegend() {
  var list = document.querySelectorAll('#legend canvas');
  Array.prototype.forEach.call(list, function (cv) {
    var ctx = prep(cv, 56, 16);
    var ck = cv.getAttribute('data-col');
    var kind = cv.getAttribute('data-kind');
    var col = ck ? COL[ck] : null;
    if (kind === 'line') {
      ctx.save();
      ctx.strokeStyle = col; ctx.lineWidth = +(cv.getAttribute('data-w') || 2.4);
      if (cv.getAttribute('data-dash')) ctx.setLineDash([7, 4]);
      ctx.beginPath(); ctx.moveTo(3, 8); ctx.lineTo(53, 8); ctx.stroke();
      ctx.restore();
    } else if (kind === 'band') {
      ctx.save();
      ctx.fillStyle = fade(COL.areaNeg, 0.30); ctx.fillRect(3, 2, 50, 12);
      ctx.strokeStyle = fade(COL.areaNeg, 0.8); ctx.setLineDash([3, 3]); ctx.lineWidth = 1;
      ctx.strokeRect(3, 2, 50, 12);
      ctx.restore();
    } else {
      arrow(ctx, 4, 8, 50, 8, kind, 0.8, col);
    }
  });
}

/* ===== タブ ===== */
function buildTabs() {
  var mt = $('modetabs'), stb = $('simtabs'), cur = DEFS[st.cur];
  mt.innerHTML = '';
  var curBtn = null, curMode = null;
  MODES.forEach(function (M) {
    var b = document.createElement('button');
    b.textContent = M.label;
    if (M.n === cur.mode) { b.className = 'on'; curBtn = b; curMode = M; }
    b.addEventListener('click', function () { if (M.n !== DEFS[st.cur].mode) gotoSim(M.ids[0]); });
    mt.appendChild(b);
  });
  var tip = $('modetip');
  if (!tip) {
    tip = document.createElement('div');
    tip.id = 'modetip';
    mt.parentNode.insertBefore(tip, mt.nextSibling);
  }
  /* ★#modetip は flex なので、中身は必ず1つの span に包む★
     包まないと KaTeX の span が1つずつ flex の子になって、文がバラバラに折り返される */
  tip.innerHTML = (curMode && curMode.tip) ? '<span>' + mathHtml(curMode.tip) + '</span>' : '';
  renderMath(tip);
  st._tipBtn = curBtn;
  placeModeTip();
  stb.innerHTML = '';
  MODES.forEach(function (M) {
    if (M.n !== cur.mode) return;
    M.ids.forEach(function (id) {
      var b = document.createElement('button');
      b.textContent = DEFS[id].tab;
      b.className = (id === st.cur ? 'on' : '');
      b.addEventListener('click', function () { gotoSim(id); });
      stb.appendChild(b);
    });
  });
}

function updateUrlBar() {
  var h = '#' + hashOf();
  setText($('urltext'), (location.protocol === 'file:' || location.origin === 'null')
    ? (location.pathname.split('/').pop() + h)
    : (location.origin + location.pathname + h));
  var msg = $('urlmsg');
  if (msg) setText(msg, '');
}

function placeModeTip() {
  var tip = $('modetip'), b = st._tipBtn, mt = $('modetabs');
  if (!tip || !b || !mt) return;
  var off = b.getBoundingClientRect().left - mt.getBoundingClientRect().left;
  var pad = Math.max(0, off + b.offsetWidth / 2 - 7);
  /* せまい画面ではボタンが横いっぱいになるので、真下に置こうとすると文が右端に寄って読めない */
  tip.style.paddingLeft = Math.min(pad, Math.max(0, mt.clientWidth - 260)) + 'px';
}

/* ===== パネルの組み立て =====
   ★左の列の並び（今回のページの決めごと）★
   ① 再生ボタンと時間バー ② 変数のスライドバー ③ オレンジの状況ボタン
   ④ 表示チェック ⑤ キャンバス ⑥ 計算結果の帯 ⑦ 2点をくらべる式
   （② と ④ は1行に並べて図の上に置く） */
function buildPanel() {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  s._eq = null;
  st._ptSz = null; st._ptPos = null;
  var h = [];
  h.push('<div class="simhead"><div class="simtitle">' + mathHtml(d.title) + '</div></div>');
  h.push('<div class="simgrid"><div class="cv">');

  /* ① 再生ボタンと時間バー */
  h.push('<div class="ctrl playctrl">');
  h.push('<div class="btnrow">');
  h.push('<button id="bPlay">▶ スタート</button>');
  h.push('<button id="bSlow" class="sub">スロー再生</button>');
  h.push('<button id="bReset" class="sub">↺ リセット</button>');
  h.push('<span class="tspan"><label>時間 t</label><input type="range" id="tBar" min="0" max="1" step="0.01" value="0"><span class="tval" id="tVal">0.00 s</span></span>');
  h.push('</div>');
  h.push('<div class="mini" id="qhint"></div>');
  h.push('</div>');

  /* ②④ 変数のカード（左）と表示チェック（右） */
  var mainKeys = mainVarKeys(d);
  var mainList = [];
  mainKeys.forEach(function (k) {
    d.vars.forEach(function (vd) { if (vd.k === k) mainList.push(vd); });
  });
  h.push('<div class="cvtop toprow" id="cvtop">');
  h.push('<div class="cvvars' + (mainList.length > 3 ? ' two' : '') + '" id="cvvars">');
  mainList.forEach(function (vd) {
    h.push(varRowHtml(vd, 'a', focusOn(d, s, vd), d.mainVarFocus === vd.k));
  });
  h.push('</div>');
  h.push('<div class="cvside">');
  if (d.vis && d.vis.length) {
    h.push('<div class="opts">');
    d.vis.forEach(function (k) {
      h.push('<label><input type="checkbox" data-vis="show' + k + '"' + (s.o['show' + k] ? ' checked' : '') + '> ' + mathHtml(VIS_LABEL[k]) + '</label>');
    });
    h.push('</div>');
  }
  h.push('</div></div>');

  /* ③⑤ オレンジの状況ボタン（図の上）＋ キャンバス */
  h.push('<div class="cvstage' + ((d.actions && d.actions.length) ? ' topbar' : ' nobar') + '">');
  if (d.actions && d.actions.length) {
    h.push('<div class="cvbar top"><div class="acts n' + Math.min(4, d.actions.length) + '">');
    d.actions.forEach(function (a, i) {
      h.push('<button class="' + (a.jump ? 'sub jump' : 'warm') + '" data-act="' + i + '" id="act_' + i + '">' + a.label + '</button>');
    });
    h.push('</div></div>');
  }
  h.push('<div class="cvwrap"><canvas id="mainCv"></canvas><div class="ptbubs" id="ptbubs"></div></div>');
  h.push('</div>');

  /* 図のすぐ下の「ひとこと」（スタートを押してから出る） */
  h.push('<div class="cvhint" id="cvhint" hidden></div>');
  /* ⑥ 計算結果の帯 */
  h.push('<div class="resbar" id="resbar"></div>');
  /* ⑦ 立式（3つ）と「仕事を表示」。★図の下・左★（先生の指示・第4回）
        中身は renderEqZone が作る。運動が終わってから出す。 */
  h.push('<div class="eqzone" id="eqzone" hidden></div>');

  if (d.sub) h.push('<p class="cvsub">' + mathHtml(d.sub) + '</p>');
  h.push('<div class="eq" id="eqbox"></div>');
  h.push('</div><div class="side">');

  /* 右の列 */
  /* ★右の欄の切りかえ（先生の指示・第6回）★
     「エネルギーのグラフを表示」と「仕事の分析」を2つとも出し、
     いま選んでいるほうをオレンジに塗る（図の上のオレンジの状況ボタンと同じ作法）。 */
  h.push('<div class="wkbar"><div class="acts n2">' +
    '<button class="warm' + (st.workMode ? '' : ' on') + '" id="bGraphMode">エネルギーのグラフを表示</button>' +
    '<button class="warm' + (st.workMode ? ' on' : '') + '" id="bWork">仕事の分析</button>' +
    '</div><span class="wkbarhint">' + (st.workMode
      ? '力ごとの仕事が出ています。図の中の力をクリックしてみよう'
      : '「仕事の分析」にすると、力ごとの仕事に切りかわります') + '</span></div>');
  /* ★「仕事の分析」モードでは、グラフの欄をまるごとこれに入れかえる★ */
  h.push('<div class="wkpanel" id="wkpanel"' + (st.workMode ? '' : ' hidden') + '></div>');
  h.push('<div id="gwrap"' + (st.workMode ? ' hidden' : '') + '>');
  h.push('<div class="btnrow openrow"><button class="warm" id="bOpenAll">' + openAllLabel() + '</button>' +
    '<button class="sub" id="bBigFml">' + bigFmlLabel() + '</button>' +
    '<span class="ghint1">グラフの右上の <b>＋</b>／<b>－</b>／<b>もどす</b> で大きさを変えられます' +
    '（ドラッグ＝移動／目盛りの上でドラッグ＝その軸だけ拡大縮小／ホイール＝拡大縮小／ダブルクリック＝自動）</span></div>');

  graphsOf(d, s).forEach(function (g) {
    h.push('<div class="gsec"><button class="ghead" data-g="' + g.key + '"><span class="tri">' +
      (s.open[g.key] ? '▼' : '▶') + '</span>' + mathHtml(g.title) + '</button>' +
      '<div class="gbody' + (s.open[g.key] ? '' : ' hide') + (st.bigFml ? ' bigf' : '') + '" id="gb_' + g.key + '">' +
      /* ★グラフの拡大・縮小ボタン★（第9回）
         ドラッグだけだと、はじめて見る生徒やスマホ・タブレットでは分かりにくいので、
         右上に ＋ / － / もどす を出す。 */
      '<div class="gleft"><div class="gzoom"><span class="gzl">グラフの大きさ</span>' +
      '<button type="button" data-gz="in" data-gk="' + g.key + '" title="拡大">＋</button>' +
      '<button type="button" data-gz="out" data-gk="' + g.key + '" title="縮小">－</button>' +
      '<button type="button" class="gzr" data-gz="reset" data-gk="' + g.key +
      '" title="はじめの大きさにもどす">もどす</button></div>' +
      '<canvas id="gc_' + g.key + '"></canvas></div>' +
      (g.fml ? '<div class="gform" id="gf_' + g.key + '"></div>' : '<div class="gspacer"></div>') +
      '</div></div>');
  });

  h.push('</div>');       /* #gwrap ここまで */
  /* ★第4回：右の列にあった「関係の箱」「保存則の箱」は、図の下の立式（#eqzone）へ移した★ */
  h.push('<div class="ptabwrap"><table class="ptab" id="ptab"></table></div>');
  h.push('<div class="note" id="notebox"><b>見るポイント</b>：' + mathHtml(d.note) + '</div>');

  var restCount = 0, rest = [];
  d.vars.forEach(function (vd) {
    if (mainKeys.indexOf(vd.k) >= 0) return;
    if (vd.when && !vd.when(V(s))) return;
    restCount++;
    rest.push(varRowHtml(vd, 'b'));
  });
  if (restCount) h.push('<div class="ctrl">' + rest.join('') + '</div>');
  h.push('<table class="read" id="readout"></table>');
  h.push('</div></div>');
  $('simhost').innerHTML = h.join('');

  /* --- イベント --- */
  $('bPlay').addEventListener('click', onPlay);
  $('bSlow').addEventListener('click', function () {
    s.slow = !s.slow;
    $('bSlow').className = s.slow ? '' : 'sub';
    $('bSlow').textContent = s.slow ? 'スロー再生 中' : 'スロー再生';
  });
  $('bReset').addEventListener('click', function () { s.t = 0; s.playing = false; setPlayLabel(); renderActive(); });
  $('tBar').addEventListener('input', function (e) {
    s.t = +e.target.value; s.playing = false; setPlayLabel(); renderActive();
  });
  /* 仕事の欄のクリック。
     ・「A点 → B点」のボタン … くらべる2点を変える（左下の立式の欄と共通の s.eqPair）
     ・力のカード           … ★図の中のその力が光る★（先生の指示・第7回。図→欄の逆） */
  $('wkpanel').addEventListener('click', function (e) {
    var el = e.target;
    while (el && el !== this) {
      if (el.getAttribute && el.getAttribute('data-pair')) {
        s.eqPair = +el.getAttribute('data-pair');
        st._fSel = null;
        renderActive();
        return;
      }
      if (el.id && el.id.indexOf('wkc_') === 0) { flashWork(el.id.slice(4)); return; }
      el = el.parentNode;
    }
  });

  /* 図の中の力にマウスを乗せる／クリックする（仕事の分析モードのときだけ効く） */
  (function () {
    var cv = $('mainCv');
    cv.addEventListener('mousemove', function (e) {
      if (!st.workMode) { if (cv.style.cursor) cv.style.cursor = ''; return; }
      var pt = cvPoint(cv, d, s, e);
      if (!pt) return;
      var b = hitAt(pt), k = b ? b.key : null;
      var want = b ? 'pointer' : '';
      if (cv.style.cursor !== want) cv.style.cursor = want;
      if (st._fHover !== k) { st._fHover = k; renderActive(); }
    });
    cv.addEventListener('mouseleave', function () {
      cv.style.cursor = '';
      if (st._fHover) { st._fHover = null; renderActive(); }
    });
    cv.addEventListener('click', function (e) {
      if (!st.workMode) return;
      var pt = cvPoint(cv, d, s, e);
      if (!pt) return;
      var b = hitAt(pt);
      if (b) flashWork(b.key);
    });
  })();

  /* 「仕事の分析」⇄「エネルギーのグラフ」の切りかえ（★全シムで共有★） */
  function setWorkMode(on) {
    if (st.workMode === on) return;
    st.workMode = on;
    st._fSel = null;
    buildPanel();
    renderActive();
  }
  $('bWork').addEventListener('click', function () { setWorkMode(true); });
  $('bGraphMode').addEventListener('click', function () { setWorkMode(false); });
  $('bOpenAll').addEventListener('click', function () { toggleAllGraphs(); });
  $('bBigFml').addEventListener('click', function () { toggleBigFml(); });
  if (st.bigFml) $('bBigFml').className = '';

  Array.prototype.forEach.call($('simhost').querySelectorAll('.ghead'), function (b) {
    b.addEventListener('click', function () {
      var k = b.getAttribute('data-g');
      s.open[k] = !s.open[k];
      $('gb_' + k).className = 'gbody' + (s.open[k] ? '' : ' hide') + (st.bigFml ? ' bigf' : '');
      b.querySelector('.tri').textContent = s.open[k] ? '▼' : '▶';
      $('bOpenAll').innerHTML = openAllLabel();
      renderMath($('bOpenAll'));
      renderActive();
    });
  });
  /* 立式の3つの開閉と、くらべる2点の選択。
     #eqzone の中身は作り直されるので、外側の箱に1つだけ付けて委譲する。 */
  $('eqzone').addEventListener('click', function (e) {
    var el = e.target, k = null, pr = null;
    while (el && el !== this) {
      if (el.getAttribute) {
        if (el.getAttribute('data-eqk')) { k = el.getAttribute('data-eqk'); break; }
        if (el.getAttribute('data-pair')) { pr = +el.getAttribute('data-pair'); break; }
      }
      el = el.parentNode;
    }
    if (k) {
      var op = eqOpenOf(d, s);
      op[k] = !op[k];
      applyEqOpen(d, s);
      fitFormula($('eqzone'));
    } else if (pr !== null) {
      s.eqPair = pr;
      st._fSel = null;            /* 2点を変えたら、力の選択はいったん解除 */
      renderActive();
    }
  });
  $('eqzone').addEventListener('change', function (e) {
    if (!e.target || e.target.id !== 'cbAllEq') return;
    st.allEq = !!e.target.checked;
    /* ★全シムで共有★ ON にしたら、どのシミュレーションでも3つとも開く */
    Object.keys(st.sims).forEach(function (id) { st.sims[id].eqOpen = null; });
    if (!st.allEq) s.eqOpen = null;
    applyEqOpen(d, s);
    fitFormula($('eqzone'));
  });

  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-act]'), function (b) {
    b.addEventListener('click', function () {
      var a = d.actions[+b.getAttribute('data-act')];
      if (a.jump) { gotoSim(a.jump); return; }      /* 別のシミュレーションへ飛ぶボタン */
      a.fn(s);
      resetSim();
      syncVarVals(); renderActive();
    });
  });
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-vis]'), function (el) {
    el.addEventListener('change', function () { s.o[el.getAttribute('data-vis')] = el.checked; renderActive(); });
  });
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-vsl]'), function (r) {
    r.addEventListener('input', function () { setVar(r.getAttribute('data-vsl'), +r.value); });
  });
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-var]'), function (b) {
    b.addEventListener('click', function () { stepVar(b.getAttribute('data-var'), +b.getAttribute('data-dir')); });
  });
  graphsOf(d, s).forEach(function (g) { attachGraphDrag($('gc_' + g.key), g.key); });
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-gz]'), function (b) {
    b.addEventListener('click', function (e) {
      e.stopPropagation();
      graphZoom(b.getAttribute('data-gk'), b.getAttribute('data-gz'));
    });
  });

  setPlayLabel();
  $('bSlow').className = s.slow ? '' : 'sub';
  $('bSlow').textContent = s.slow ? 'スロー再生 中' : 'スロー再生';
  syncVarVals();
  renderMath($('simhost'));
}

/* 「よく変える変数」＝図の上のカードに出すもの */
function mainVarKeys(d) {
  if (d.mainVars === '*') return d.vars.map(function (x) { return x.k; });
  if (d.mainVars) return d.mainVars;
  return d.vars.slice(0, 2).map(function (x) { return x.k; });
}

function focusOn(d, s, vd) {
  return !!(d.mainVarFocus && d.mainVarFocus === vd.k && Math.abs(s.v[vd.k] - vd.def) < 1e-9);
}

function varRowHtml(vd, tag, focus, focusable) {
  var lab = (tag === 'a') ? vd.label.replace(/（[^）]*）/g, '') : vd.label;
  if (focusable) lab += ' <span class="tryme"' + (focus ? '' : ' style="display:none"') + '>変えてみよう</span>';
  var h = '<div class="vrow' + (focus ? ' focus' : '') + '" data-vrow="' + vd.k + '">' +
    '<span class="vlab">' + mathHtml(lab) + '</span>' +
    '<button class="stp" data-var="' + vd.k + '" data-dir="-1">−</button>' +
    '<span class="vval" data-vval="' + vd.k + '"></span>' +
    '<button class="stp" data-var="' + vd.k + '" data-dir="1">＋</button>';
  if (tag === 'a') {
    h += '<input type="range" class="vsl" data-vsl="' + vd.k + '" ' +
      'min="' + vd.min + '" max="' + vd.max + '" step="' + vd.step + '">';
  }
  return h + '</div>';
}

/* ===== 再生 ===== */
function onPlay() {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  var T = d.tEnd(V(s));
  if (s.t >= T - 1e-9) s.t = 0;
  s.playing = !s.playing;
  if (s.playing) s._played = true;
  if (s.playing && s.t < 1e-9 && d.startSfx) sfx(d.startSfx);
  setPlayLabel();
  renderActive();
}

/* いまの状態がすでに条件を満たしているボタンを、少し濃く見せる。
   next(s,t,v) を書いておくと「次はこれを押す」ときにオレンジで点滅する。 */
function refreshActs() {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  if (!d.actions) return;
  d.actions.forEach(function (a, i) {
    var b = $('act_' + i);
    if (!b) return;
    if (a.jump) { setCls(b, 'sub jump'); return; }
    var on = a.is ? !!a.is(V(s), s) : false;
    var nx = (!on && a.next) ? !!a.next(s, s.t, V(s)) : false;
    setCls(b, 'warm' + (on ? ' on' : '') + (nx ? ' pulse' : ''));
  });
}

function openAllLabel() {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  var closed = [];
  graphsOf(d, s).forEach(function (g) { if (!s.open[g.key]) closed.push(g.short || g.title); });
  if (!closed.length) return '最初の表示にもどす（重ねた図だけにする）';
  return mathHtml(closed.join('・') + ' をまとめて開く');
}

function bigFmlLabel() { return st.bigFml ? '式をもとの大きさに' : '式を拡大'; }

function toggleBigFml() {
  st.bigFml = !st.bigFml;
  Array.prototype.forEach.call(document.querySelectorAll('#simhost .gbody'), function (b) {
    b.className = b.className.replace(' bigf', '') + (st.bigFml ? ' bigf' : '');
  });
  var bt = $('bBigFml');
  if (bt) { bt.textContent = bigFmlLabel(); bt.className = st.bigFml ? '' : 'sub'; }
  refitFormulas();
}

function toggleAllGraphs() {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  var closed = graphsOf(d, s).some(function (g) { return !s.open[g.key]; });
  (d.graphs || []).forEach(function (g) { s.open[g.key] = closed ? true : !!g.open; });
  graphsOf(d, s).forEach(function (g) {
    var body = $('gb_' + g.key), head = $('simhost').querySelector('.ghead[data-g="' + g.key + '"]');
    if (body) body.className = 'gbody' + (s.open[g.key] ? '' : ' hide') + (st.bigFml ? ' bigf' : '');
    if (head) head.querySelector('.tri').textContent = s.open[g.key] ? '▼' : '▶';
  });
  $('bOpenAll').innerHTML = openAllLabel();
  renderMath($('bOpenAll'));
  renderActive();
}

/* ===== グラフのドラッグ（移動・軸の拡大縮小） ===== */
function attachGraphDrag(cv, key) {
  if (!cv) return;
  var drag = null;
  function local(e) {
    var mp = cv._map, r = cv.getBoundingClientRect();
    return { x: (e.clientX - r.left) / r.width * mp.W, y: (e.clientY - r.top) / r.height * mp.H };
  }
  function cur() {
    var s = st.sims[st.cur];
    if (s.gview[key]) return s.gview[key];
    var mp = cv._map;
    return { xmin: mp.xmin, xmax: mp.xmax, ymin: mp.ymin, ymax: mp.ymax };
  }
  cv.addEventListener('pointerdown', function (e) {
    if (!cv._map) return;
    var p = local(e), mp = cv._map;
    var mode = 'pan';
    if (p.x < mp.pad.l) mode = 'sy';
    else if (p.y > mp.pad.t + mp.gh) mode = 'sx';
    drag = { p: p, view: cur(), mode: mode };
    cv.setPointerCapture(e.pointerId);
    e.preventDefault();
  });
  cv.addEventListener('pointermove', function (e) {
    if (!drag || !cv._map) return;
    var s = st.sims[st.cur], mp = cv._map, p = local(e);
    var dx = p.x - drag.p.x, dy = p.y - drag.p.y, v0 = drag.view, nv;
    if (drag.mode === 'pan') {
      var kx = (v0.xmax - v0.xmin) / mp.gw, ky = (v0.ymax - v0.ymin) / mp.gh;
      nv = { xmin: v0.xmin - dx * kx, xmax: v0.xmax - dx * kx, ymin: v0.ymin + dy * ky, ymax: v0.ymax + dy * ky };
    } else if (drag.mode === 'sx') {
      var f = Math.exp(-dx / 110), c = (v0.xmin + v0.xmax) / 2, hh = (v0.xmax - v0.xmin) / 2 * f;
      nv = { xmin: c - hh, xmax: c + hh, ymin: v0.ymin, ymax: v0.ymax };
    } else {
      var f2 = Math.exp(dy / 110), c2 = (v0.ymin + v0.ymax) / 2, h2 = (v0.ymax - v0.ymin) / 2 * f2;
      nv = { xmin: v0.xmin, xmax: v0.xmax, ymin: c2 - h2, ymax: c2 + h2 };
    }
    s.gview[key] = nv;
    renderActive();
    e.preventDefault();
  });
  function end() { drag = null; }
  cv.addEventListener('pointerup', end);
  cv.addEventListener('pointercancel', end);
  cv.addEventListener('wheel', function (e) {
    if (!cv._map) return;
    var s = st.sims[st.cur], mp = cv._map, p = local(e), v0 = cur();
    var f = Math.exp(e.deltaY * 0.0014);
    var px = v0.xmin + (p.x - mp.pad.l) / mp.gw * (v0.xmax - v0.xmin);
    var py = v0.ymax - (p.y - mp.pad.t) / mp.gh * (v0.ymax - v0.ymin);
    s.gview[key] = {
      xmin: px - (px - v0.xmin) * f, xmax: px + (v0.xmax - px) * f,
      ymin: py - (py - v0.ymin) * f, ymax: py + (v0.ymax - py) * f
    };
    renderActive();
    e.preventDefault();
  }, { passive: false });
  cv.addEventListener('dblclick', function () {
    delete st.sims[st.cur].gview[key];
    renderActive();
  });
}

/* ★グラフの ＋ / － / もどす ★（第9回）
   まん中をそのままにして、たてよこ同じ割合で広げたり縮めたりする。
   「もどす」は自分で決めた見え方を捨てて、自動の目もりにもどす。 */
function graphZoom(key, kind) {
  var s = st.sims[st.cur], cv = $('gc_' + key);
  if (kind === 'reset') { delete s.gview[key]; renderActive(); return; }
  if (!cv || !cv._map) return;
  var mp = cv._map;
  var v0 = s.gview[key] || { xmin: mp.xmin, xmax: mp.xmax, ymin: mp.ymin, ymax: mp.ymax };
  var f = (kind === 'in') ? 1 / 1.4 : 1.4;
  var cxx = (v0.xmin + v0.xmax) / 2, cyy = (v0.ymin + v0.ymax) / 2;
  var hx = (v0.xmax - v0.xmin) / 2 * f, hy = (v0.ymax - v0.ymin) / 2 * f;
  s.gview[key] = { xmin: cxx - hx, xmax: cxx + hx, ymin: cyy - hy, ymax: cyy + hy };
  renderActive();
}

function setPlayLabel() {
  var s = st.sims[st.cur], b = $('bPlay');
  if (!b) return;
  if (s.playing) { setText(b, '❚❚ 一時停止'); setCls(b, ''); return; }
  setText(b, '▶ スタート');
  /* ★止まっているあいだは、いつでもスタートを光らせる★（先生の指示・第11回）
     前は「まだ一度も動かしていないシムだけ」光らせていたので、
     一度でも見たシムにもどるとボタンが光らず、シムによって見え方がちがった。
     押せば（終わっていても）はじめから動きだすので、止まっている＝次に押すところ。 */
  setCls(b, 'pulse');
  var hint = $('qhint');
  if (hint) {
    var d = DEFS[st.cur];
    var txt = mathHtml(s._played ? (d.hint2 || '')
      : '<span class="nextmark">① まず「スタート」</span>：運動を最後まで見ると、図に吹きだしと式が出ます。');
    if (hint.innerHTML !== txt) { hint.innerHTML = txt; renderMath(hint); }
    hint.style.display = txt ? '' : 'none';
  }
}

function resetSim() {
  var s = st.sims[st.cur];
  s.t = 0; s.playing = false; s.gview = {}; s._sfx = null;
  /* 設定を変えたら、仕事の分析も「まだ最後まで進めていない」にもどす */
  s._wkReady = false;
  setPlayLabel();
}

function setVar(k, val) {
  var d = DEFS[st.cur], s = st.sims[st.cur], vd = null;
  d.vars.forEach(function (x) { if (x.k === k) vd = x; });
  if (!vd) return;
  var nv = clamp(Math.round(val / vd.step) * vd.step, vd.min, vd.max);
  if (Math.abs(nv - s.v[k]) < 1e-9) return;
  s.v[k] = +nv.toFixed(6);
  if (d.onVar) d.onVar(s, k);
  resetSim(); syncVarVals(); renderActive();
}

function stepVar(k, dir) {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  var vd = null;
  d.vars.forEach(function (x) { if (x.k === k) vd = x; });
  if (!vd) return;
  var nv = s.v[k] + dir * vd.step;
  nv = clamp(Math.round(nv / vd.step) * vd.step, vd.min, vd.max);
  s.v[k] = +nv.toFixed(6);
  if (d.onVar) d.onVar(s, k);
  resetSim(); syncVarVals(); renderActive();
}

function syncVarVals() {
  var d = DEFS[st.cur], s = st.sims[st.cur], host = $('simhost');
  if (!host) return;
  d.vars.forEach(function (vd) {
    var txt = (vd.fmt ? vd.fmt(s.v[vd.k]) : fmt(s.v[vd.k], vd.dec) + vd.unit);
    Array.prototype.forEach.call(host.querySelectorAll('[data-vval="' + vd.k + '"]'), function (el) {
      setText(el, txt);
    });
    Array.prototype.forEach.call(host.querySelectorAll('[data-vsl="' + vd.k + '"]'), function (r) {
      if (+r.value !== s.v[vd.k]) r.value = s.v[vd.k];
    });
    if (d.mainVarFocus === vd.k) {
      var on = focusOn(d, s, vd);
      Array.prototype.forEach.call(host.querySelectorAll('[data-vrow="' + vd.k + '"]'), function (row) {
        setCls(row, 'vrow' + (on ? ' focus' : ''));
        var tip = row.querySelector('.tryme');
        if (tip) tip.style.display = on ? '' : 'none';
      });
    }
  });
}

/* ===== グラフを描く ===== */
function seriesPts(d, s, g, T) {
  var N = 180, out = [], i, v = V(s);
  g.series.forEach(function () { out.push([]); });
  for (i = 0; i <= N; i++) {
    var t = T * i / N;
    var m = d.sample(v, t);
    g.series.forEach(function (se, j) { out[j].push([t, se.f(m, v, t)]); });
  }
  return out;
}

function niceXMax(T) {
  var Tx = Math.max(0.2, T);
  var st2 = niceStep(Tx, 6);
  var xm = Math.ceil(Tx / st2 - 1e-9) * st2;
  return (xm < Tx * (1 + 1e-9)) ? xm + st2 : xm;
}

function renderGraphs(d, s, T, t) {
  var v = V(s), m = d.sample(v, t);
  graphsOf(d, s).forEach(function (g) {
    if (!s.open[g.key]) return;
    var cv = $('gc_' + g.key);
    if (!cv) return;
    var pts = seriesPts(d, s, g, T);
    var lo = Infinity, hi = -Infinity;
    pts.forEach(function (p) { p.forEach(function (q) { if (isFinite(q[1])) { lo = Math.min(lo, q[1]); hi = Math.max(hi, q[1]); } }); });
    if (!isFinite(lo)) { lo = -1; hi = 1; }
    var r = niceRange(Math.min(0, lo), hi);
    if (lo >= -1e-9) r.lo = 0;                      /* エネルギーは負にならないので 0 から見せる */
    plot(cv, {
      xlabel: 't [s]', ylabel: g.ylabel, H: g.H,
      xmin: 0, xmax: niceXMax(T), xstep: niceStep(Math.max(0.2, T), 6), ymin: r.lo, ymax: r.hi,
      view: s.gview[g.key],
      series: g.series.map(function (se, j) {
        return { color: se.color, dash: se.dash, width: se.width, pts: pts[j],
          fillTo: (typeof se.fillTo === 'function') ? se.fillTo(v) : se.fillTo };
      }),
      cursors: g.series.map(function (se) { return { color: se.color, x: t, y: se.f(m, v, t) }; }),
      legend: (g.legend === true) ? g.series.map(function (se) {
        return { name: se.name, color: se.color, dash: se.dash, width: se.width };
      }) : (g.legend || null)
    });
  });
}

/* 各グラフの右に出す3段の式 */
function renderFormulas(d, s) {
  graphsOf(d, s).forEach(function (g) {
    if (!g.fml || !s.open[g.key]) return;
    var box = $('gf_' + g.key);
    if (!box) return;
    var arr = g.fml(V(s), s);
    var fn = g.fnote ? (typeof g.fnote === 'function' ? g.fnote(V(s), s) : g.fnote) : '';
    var key = arr.join('|') + '||' + fn;
    var bw = box.clientWidth;
    if (box._key === key && box._bw === bw) return;
    box._key = key; box._bw = bw;
    var names = ['公式', '代入', '数値'];
    box.innerHTML = arr.map(function (x, i) {
      return '<div class="fl f' + (i + 1) + '"><span class="fk">' + names[i] + '</span><span class="fv"><span class="tex">' + escTex(x) + '</span></span></div>';
    }).join('') + (fn ? '<div class="fnote">' + fn + '</div>' : '');
    renderMath(box);
    fitFormula(box);
    requestAnimationFrame(function () { fitFormula(box); });
  });
}

function fitFormula(box) {
  Array.prototype.forEach.call(box.querySelectorAll('.fv'), function (fv) {
    var inner = fv.firstElementChild;
    if (!inner) return;
    var k = inner._k || 1;
    var w = inner.getBoundingClientRect().width / k;
    var avail = fv.clientWidth;
    if (avail < 20 || w < 1) return;
    var nk = (w > avail) ? Math.max(0.5, (avail - 3) / w) : 1;
    if (Math.abs(nk - k) > 0.004) {
      inner._k = nk;
      inner.style.transform = nk < 1 ? 'scale(' + nk.toFixed(3) + ')' : '';
    }
  });
}

function refitFormulas() {
  Array.prototype.forEach.call(document.querySelectorAll('.gform'), function (b) { b._key = null; });
  renderActive();
}

/* ===== ⑥ 計算結果の帯 ===== */
function resultItems(d, s, t) {
  var v = V(s), m = d.sample(v, t), out = [];
  out.push({ k: '速さ $v$', v: fmt(m.v, 2) + ' m/s' });
  if (d.showH !== false) out.push({ k: '基準面からの高さ $h$', v: fmt(m.h, 2) + ' m' });
  out.push({ k: '運動エネルギー $K$', v: fmtJ(m.K), col: 'eK' });
  out.push({ k: '位置エネルギー $U$', v: fmtJ(m.U), col: 'eU' });
  out.push({ k: '力学的エネルギー $E$', v: fmtJ(m.E), kbox: true });
  if (!consOf(d, v)) {
    out.push({ k: '非保存力の仕事 $W$', v: fmtJ(m.W) });
    /* W < 0 のときだけ「失われた」。2-5 のように W > 0 のシムでは「増えた」にする */
    out.push(m.W > 1e-9 ? { k: '増えたエネルギー', v: fmtJ(m.W) }
      : { k: '失われたエネルギー', v: fmtJ(-m.W) });
  }
  if (d.resItems) d.resItems(v, s, t).forEach(function (x) { out.push(x); });
  return out;
}

function renderResult(d, s, t) {
  var box = $('resbar');
  if (!box) return;
  var items = resultItems(d, s, t);
  var key = items.map(function (x) { return x.k + (x.kbox ? '!' : '') + (x.col || ''); }).join('|');
  if (box._key !== key) {
    box.innerHTML = items.map(function (x) {
      return '<span class="ritem' + (x.kbox ? ' kbox' : '') + (x.col ? ' c-' + x.col : '') + '">' +
        '<span class="rk">' + mathHtml(x.k) + '</span><span class="rv"></span></span>';
    }).join('');
    box._key = key;
    renderMath(box);
  }
  var vs = box.querySelectorAll('.rv');
  items.forEach(function (x, i) { if (vs[i]) setText(vs[i], x.v); });
}

/* ===== 点のエネルギーの吹きだし（HTML・KaTeX） =====
   ★点のすぐ近くに置く。置き場所は canvas 側（drawPts）が
   　「物体・文字と重ならないところ」を選んで st._ptPos に入れる。★
   文字の大きさは canvas の表示倍率 --ptk に合わせるので、
   どの画面幅でも「図に対する大きさ」が変わらない（＝置き場所の計算がずれない）。 */
function preparePtBubbles(d, s, t) {
  var host = $('ptbubs');
  if (!host) return;
  if (!endOn(d, s, t)) { if (host.style.display !== 'none') host.style.display = 'none'; return; }
  host.style.display = '';
  var v = V(s), ps = ptsOf(d, v), cv = $('mainCv');
  var k = (cv && cv.clientWidth) ? cv.clientWidth / d.cw : 1;
  host.style.setProperty('--ptk', k.toFixed(4));
  var key = ps.map(function (p) { return p.name + '|' + ptTex(d, p) + '|' + fmt(p.m.E, 2); }).join('/');
  if (host._key !== key) {
    host._key = key;
    host.innerHTML = ps.map(function (p) {
      return '<div class="ptbub" data-pt="' + p.name + '">' +
        '<span class="pn">' + p.name + '</span>' +
        '<span class="tex">' + escTex(ptTex(d, p)) + '</span>' +
        '<span class="pv">= ' + fmtJ(p.m.E) + '</span></div>';
    }).join('');
    renderMath(host);
    st._ptSz = null;
  }
  if (!st._ptSz) {                         /* 大きさを測るのは中身が変わったときだけ */
    st._ptSz = {};
    Array.prototype.forEach.call(host.children, function (el) {
      st._ptSz[el.getAttribute('data-pt')] = { w: el.offsetWidth / k, h: el.offsetHeight / k };
    });
  }
}

function placePtBubbles(d, ch) {
  var host = $('ptbubs');
  if (!host || !st._ptPos) return;
  st._ptPos.forEach(function (q) {
    var el = host.querySelector('[data-pt="' + q.name + '"]');
    if (!el) return;
    var L = (q.x / d.cw * 100).toFixed(3) + '%', T = (q.y / ch * 100).toFixed(3) + '%';
    if (el.style.left !== L) el.style.left = L;
    if (el.style.top !== T) el.style.top = T;
  });
}

/* 図のすぐ下の「ひとこと」。スタートを押してから出す（先に答えを見せない）。 */
function renderFigHint(d, s, t) {
  var el = $('cvhint');
  if (!el) return;
  var txt = (d.hintFig && hintOn(s, t)) ? d.hintFig : '';
  if (el._key !== txt) {
    el._key = txt;
    el.innerHTML = mathHtml(txt);
    renderMath(el);
  }
  if (el.hidden === !!txt) el.hidden = !txt;
}

/* ===== ⑦ 図の下の「立式」3つ（★先生の指示・第4回／第5回で2点を選べるように★） =====
   ・並びは ① 力学的エネルギー保存則 ② 力学的エネルギーと非保存力の仕事の関係
     ③ 運動エネルギーと仕事の関係。
   ・はじめに開いておくのは、保存するなら①だけ、保存しないなら①と②。
   ・「3つの式を表示」のチェックは st.allEq（★全シム共通★）。ON なら3つとも開く。
   ・見出しは「A点とB点の間で立式する」。点が3つ以上なら
     「A点とB点」「A点とC点」…をボタンで選べる（s.eqPair）。
   ・「仕事を表示」は第5回で右の列（#wkpanel・仕事の分析モード）へ移した。
   ・答えを先に見せないため、運動が終わってから（endOn）出す。 */

/* この図で開いておく式（まだ決めていなければ、保存の成否と st.allEq から決める） */
function eqOpenOf(d, s) {
  if (!s.eqOpen) {
    var ok = consOf(d, V(s));
    s.eqOpen = st.allEq ? { cons: true, rel: true, wk: true }
      : { cons: true, rel: !ok, wk: false };
  }
  return s.eqOpen;
}

/* いま立式している2つめの点の番号 */
function eqPairOf(d, s) {
  return pairJ(d, V(s), s.eqPair);
}

function eqZoneKey(d, s, secs) {
  var a = secs.map(function (q) { return q.badge + '|' + q.sym + '|' + q.num; }).join('#');
  return a + '@' + (st.allEq ? '1' : '0') + '@' + eqPairOf(d, s);
}

function renderEqZone(d, s, t) {
  var box = $('eqzone');
  if (!box) return;
  if (!endOn(d, s, t)) {
    if (!box.hidden) { box.hidden = true; box._key = null; }
    return;
  }
  var v = V(s), jj = eqPairOf(d, s), secs = eqSections(d, v, jj), prs = pairsOf(d, v);
  if (!secs.length) return;
  box.hidden = false;
  var key = eqZoneKey(d, s, secs);
  if (box._key !== key) {
    box._key = key;
    var h = [];
    /* 見出し：2点が1組だけなら文だけ、2組以上ならボタンで選ばせる */
    h.push('<div class="eqztop"><span class="eqztitle">');
    if (prs.length <= 1) {
      h.push(prs.length ? prs[0].name + 'の間で立式する' : '2点の間で立式する');
    } else {
      h.push('<span class="eqpairs">');
      prs.forEach(function (q) {
        h.push('<button class="eqpair' + (q.j === jj ? ' on' : '') + '" data-pair="' + q.j + '">' +
          q.name + '</button>');
      });
      h.push('</span>の間で立式する');
    }
    h.push('</span><label class="eqzall"><input type="checkbox" id="cbAllEq"' +
      (st.allEq ? ' checked' : '') + '> 3つの式を表示</label></div>');
    secs.forEach(function (q) {
      h.push('<div class="eqsec ' + (q.ok ? 'ok' : 'ng') + '" id="eqs_' + q.key +
        '" data-base="eqsec ' + (q.ok ? 'ok' : 'ng') + '">' +
        '<button class="eqhead" data-eqk="' + q.key + '"><span class="tri">▶</span>' +
        '<span class="badge">' + q.badge + '</span>' +
        '<span class="eqttl">' + q.title + '</span>' +
        '<span class="eqsub">' + mathHtml(q.sub) + '</span></button>' +
        '<div class="eqbody">' +
        /* ★成り立たない式には、記号の行にバツ印を重ねる★（先生の指示・第8回） */
        '<div class="enqline symline"><span class="fk">記号</span><span class="fv"><span class="tex">' +
        escTex(q.sym) + '</span></span></div>' +
        '<div class="enqline"><span class="fk num">数値</span><span class="fv"><span class="tex">' +
        escTex(q.num) + '</span></span></div>' +
        '<div class="eqnote">' + mathHtml(q.note) + '</div></div></div>');
    });
    box.innerHTML = h.join('');
    renderMath(box);
    applyEqOpen(d, s);
    fitFormula(box);
    requestAnimationFrame(function () { fitFormula(box); });
  }
}

/* 開閉のクラスだけを付けかえる（中身は作り直さない） */
function applyEqOpen(d, s) {
  var op = eqOpenOf(d, s);
  ['cons', 'rel', 'wk'].forEach(function (k) {
    var el = $('eqs_' + k);
    if (!el) return;
    var on = !!op[k], base = el.getAttribute('data-base') || 'eqsec';
    setCls(el, base + (on ? ' open' : ''));
    var tri = el.querySelector('.tri');
    if (tri) setText(tri, on ? '▼' : '▶');
  });
}

/* ===== 「仕事の分析」の欄（右の列。グラフと入れかえ）★先生の指示・第5回★ =====
   ・その図ではたらく力の仕事を、★ぜんぶまとめて★出す（1つずつ選ぶのはやめた）。
   ・図の中の力をクリックすると、その力の枠がピカッと光る（.flash）。 */
function wkPanelKey(d, s, fs, jj) {
  return fs.map(function (f) { return f.name + '|' + fmt(f.W, 3); }).join('#') + '@' + jj;
}

function renderWorkPanel(d, s, t) {
  var el = $('wkpanel');
  if (!el || !st.workMode) return;
  var v = V(s), jj = eqPairOf(d, s), ps = ptsOf(d, v);
  var A = ps[0], B = ps[pairJ(d, v, jj)];
  /* ★一度でも最後まで進めたら、時間バーをもどしても表は出したまま★
     こうすると「とちゅうの姿で力をクリックする」ことができる（ばねの力など、
     終わりの瞬間には 0 になっていて図に出ない力があるため）。 */
  if (!s._wkReady) {
    var k0 = 'wait|' + A.name + B.name;
    if (el._key !== k0) {
      el._key = k0;
      el.innerHTML = '<div class="wkhead">仕事の分析</div>' +
        '<div class="wkwait">▶ スタートをおして、運動を最後まで進めてください。<br>' +
        'そのあと、はたらいた力それぞれの<b>仕事</b>がここに出ます。</div>';
    }
    return;
  }
  var fs = forcesOf(d, v, jj), tot = 0, i;
  for (i = 0; i < fs.length; i++) tot += fs[i].W;
  var key = wkPanelKey(d, s, fs, jj);
  if (el._key === key) return;
  el._key = key;
  var h = [], prs = pairsOf(d, v);
  h.push('<div class="wkhead">仕事の分析</div>');
  /* ★どの2点の間の仕事かを、ここでも選べるようにする★（先生の指示・第7回）
     選ぶ場所は左下の立式の欄と共通（s.eqPair）なので、どちらで選んでも両方が動く。
     ボタンの見た目は左下とそろえ、書き方だけ「A点 → B点」にする。 */
  h.push('<div class="wkpairs">');
  if (prs.length > 1) {
    h.push('<span class="eqpairs">');
    prs.forEach(function (q) {
      h.push('<button class="eqpair' + (q.j === jj ? ' on' : '') + '" data-pair="' + q.j + '">' +
        q.flow + '</button>');
    });
    h.push('</span>');
  } else {
    h.push('<span class="wkflow">' + A.name + '点 → ' + B.name + '点</span>');
  }
  h.push('<span class="wksub">で、それぞれの力がした仕事</span></div>');
  h.push('<div class="wkhint2">図の中の力（矢印や記号）をクリックすると、その力の欄が光ります。' +
    '<br>逆に、下の<b>仕事の欄をクリック</b>すると、図の中のその力が光ります。' +
    '<br>その瞬間にはたらいていない力（縮んでいないばねの力など）は図に出ないので、' +
    '<b>時間バーを動かして</b>からクリックしてください。</div>');
  fs.forEach(function (f, j) {
    var sg = workSign(f.W);
    var cls = sg > 0 ? 'pos' : (sg < 0 ? 'neg' : 'zero');
    var tag = sg > 0 ? '正の仕事' : (sg < 0 ? '負の仕事' : '仕事は 0');
    h.push('<div class="wkcard ' + cls + '" id="wkc_' + f.key + '" data-wk="' + j +
      '" style="--wc:' + f.color + '">' +
      '<div class="wkttl"><span class="wkbadge">' + tag + '</span>' +
      f.name + '　<span class="tex">' + escTex(f.sym) + '</span>' +
      '<span class="wkval"><span class="tex">' + escTex('W = ' + fmtE(f.W) + '\\ \\mathrm{J}') +
      '</span></span></div>' +
      '<div class="wkwhy">' + mathHtml(workWhy(f.W)) + (f.why ? '　' + mathHtml(f.why) : '') + '</div>' +
      (f.wsym ? '<div class="enqline"><span class="fk">記号</span><span class="fv"><span class="tex">' +
        escTex(f.wsym) + '</span></span></div>' : '') +
      '</div>');
  });
  /* 合計＝運動エネルギーの変化 */
  h.push('<div class="wksum"><div class="wkttl">合計（＝運動エネルギーの変化）</div>' +
    '<div class="enqline"><span class="fk num">数値</span><span class="fv"><span class="tex">' +
    escTex(fs.map(function (f) { return numTerm(f.W); }).join(' + ') + ' = ' + fmtE(tot) +
      '\\ \\mathrm{J} = K_{' + B.name + '} - K_{' + A.name + '}') +
    '</span></span></div></div>');
  el.innerHTML = h.join('');
  renderMath(el);
  fitFormula(el);
  requestAnimationFrame(function () { fitFormula(el); });
}

/* 力の欄と、図の中のその力を、いっしょに光らせる。
   ・図の力をクリック → この関数（欄が光る）
   ・欄をクリック    → この関数（★図のその力が光る★＝ st._fSel。先生の指示・第7回） */
function flashWork(key) {
  var el = $('wkc_' + key);
  if (!el) return;
  if (st._fSel !== key) { st._fSel = key; renderActive(); }
  Array.prototype.forEach.call(document.querySelectorAll('#wkpanel .wkcard'), function (c) {
    c.className = c.className.replace(' flash', '').replace(' sel', '');
  });
  el.className += ' sel flash';
  if (el.scrollIntoView) el.scrollIntoView({ block: 'nearest' });
  if (st._flashT) clearTimeout(st._flashT);
  st._flashT = setTimeout(function () {
    el.className = el.className.replace(' flash', '');
  }, 1100);
}

/* ===== ⑤ 各点の K・U の表 ===== */
function renderPtab(d, s) {
  var el = $('ptab');
  if (!el) return;
  var v = V(s), ps = ptsOf(d, v), us = !!d.hasUs;
  var key = ps.map(function (p) { return p.name + p.jp; }).join('|') + (us ? '|us' : '');
  el.className = us ? 'ptab wide' : 'ptab';   /* ばねがあるときは5列。少し細くして収める */
  if (el._key !== key) {
    el._key = key;
    var head = '<tr><th>点</th><th class="ck">運動エネルギー $K$</th><th class="cu">重力による位置エネルギー $U_g$</th>' +
      (us ? '<th class="cu">弾性力による位置エネルギー $U_k$</th>' : '') + '<th class="ce">合計 $E$</th></tr>';
    var body = ps.map(function (p) {
      return '<tr><td class="pn">' + p.name + '<span class="pj">' + p.jp + '</span></td>' +
        '<td class="ck"><span class="sym"></span><span class="num"></span></td>' +
        '<td class="cu"><span class="sym"></span><span class="num"></span></td>' +
        (us ? '<td class="cu"><span class="sym"></span><span class="num"></span></td>' : '') +
        '<td class="ce"><span class="num"></span></td></tr>';
    }).join('');
    el.innerHTML = mathHtml('<caption>各点の運動エネルギーと位置エネルギー（' +
      (d.datum || '基準面') + 'を基準面にとる）</caption>') + mathHtml(head) + body;
    renderMath(el);
  }
  /* 記号の式（KaTeX）は中身が変わったときだけ組み直す */
  var symKey = ps.map(function (p) { return [p.sym.K, p.sym.Ug, p.sym.Us].join(','); }).join('|');
  var rows = el.querySelectorAll('tr');
  if (el._sym !== symKey) {
    el._sym = symKey;
    ps.forEach(function (p, i) {
      var tr = rows[i + 1];
      if (!tr) return;
      var syms = tr.querySelectorAll('.sym');
      var list = us ? [p.sym.K || '0', p.sym.Ug || '0', p.sym.Us || '0'] : [p.sym.K || '0', p.sym.Ug || '0'];
      list.forEach(function (x, j) {
        if (syms[j]) syms[j].innerHTML = '<span class="tex">' + escTex(x) + '</span>';
      });
    });
    renderMath(el);
  }
  ps.forEach(function (p, i) {
    var tr = rows[i + 1];
    if (!tr) return;
    var ns = tr.querySelectorAll('.num');
    var list = us ? [p.m.K, p.m.Ug, p.m.Us, p.m.E] : [p.m.K, p.m.U, p.m.E];
    list.forEach(function (x, j) { if (ns[j]) setText(ns[j], fmtE(x)); });
  });
}

function renderReadout(d, s, t) {
  var el = $('readout');
  if (!el || !d.info) return;
  var rows = d.info(s, t), i;
  var keys = rows.map(function (r) { return r[0]; }).join('|');
  if (el._keys !== keys) {
    el.innerHTML = rows.map(function (r) {
      return '<tr><td class="k">' + mathHtml(r[0]) + '</td><td class="v"></td></tr>';
    }).join('');
    el._keys = keys;
    renderMath(el);
  }
  var tds = el.querySelectorAll('td.v');
  for (i = 0; i < rows.length; i++) if (tds[i]) setText(tds[i], rows[i][1]);
}

function renderEq(d, s) {
  var el = $('eqbox');
  if (!el) return;
  if (!d.eq) { el.style.display = 'none'; return; }
  el.style.display = '';
  var src = d.eq(s);
  if (src === s._eq) return;
  s._eq = src;
  el.textContent = '';
  if (window.katex) {
    try { window.katex.render(src, el, { throwOnError: false, displayMode: false }); }
    catch (e) { el.textContent = src; }
  } else el.textContent = src;
}

/* ===== 図の中の力を「クリックできる」ようにする（仕事の分析モード）★第5回★ =====
   ・当たり判定は、力の矢印と力の名前（label）から自動でできている（_forceHit）。
   ・いま出ている力のうち、d.forces にあるものだけをクリックできるようにする。 */
function activeForceHits(d, s, t) {
  if (!st.workMode || !s._wkReady) return [];
  var keys = {}, hits = forceHits(), out = [], i;
  forcesOf(d, V(s), eqPairOf(d, s)).forEach(function (f) { keys[f.key] = 1; });
  for (i = 0; i < hits.length; i++) if (keys[hits[i].key]) out.push(hits[i]);
  return out;
}

/* 図の上に、クリックできる場所の合図（うすい枠）と、ホバー中の指差しマークを描く */
function drawForceHints(ctx, d, s, t) {
  var hits = activeForceHits(d, s, t);
  st._fHits = hits;
  if (!hits.length) return;
  var i, hv = st._fHover, sel = st._fSel;
  for (i = 0; i < hits.length; i++) {
    var b = hits[i], on = (b.key === hv), pick = (b.key === sel);
    ctx.save();
    /* ★選ばれている力（右の欄でクリックされた力）はオレンジで太く囲む★（第7回） */
    ctx.strokeStyle = pick ? COL.acc : (on ? COL.acc : fade(COL.eE, 0.26));
    ctx.fillStyle = pick ? fade(COL.acc, 0.18) : (on ? fade(COL.acc, 0.14) : fade(COL.eE, 0.035));
    ctx.lineWidth = pick ? 3 : (on ? 2 : 1);
    if (!on && !pick) ctx.setLineDash([2, 4]);
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(b.x, b.y, b.w, b.h, 6);
    else ctx.rect(b.x, b.y, b.w, b.h);
    ctx.fill(); ctx.stroke();
    if (pick) {                       /* 外がわにもう1本、うすい輪を出して目立たせる */
      ctx.strokeStyle = fade(COL.acc, 0.45); ctx.lineWidth = 2; ctx.setLineDash([]);
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(b.x - 4, b.y - 4, b.w + 8, b.h + 8, 9);
      else ctx.rect(b.x - 4, b.y - 4, b.w + 8, b.h + 8);
      ctx.stroke();
    }
    ctx.restore();
    if (on) pointerIcon(ctx, b.x + b.w - 4, b.y + b.h - 2, 1.15);
  }
}

/* canvas の上の座標（px）→ 図の論理座標 */
function cvPoint(cv, d, s, e) {
  var r = cv.getBoundingClientRect();
  if (!(r.width > 0)) return null;
  var k = d.cw / r.width;
  return { x: (e.clientX - r.left) * k, y: (e.clientY - r.top) * k };
}
function hitAt(pt) {
  var hits = st._fHits || [], i;
  for (i = 0; i < hits.length; i++) {
    var b = hits[i];
    if (pt.x >= b.x && pt.x <= b.x + b.w && pt.y >= b.y && pt.y <= b.y + b.h) return b;
  }
  return null;
}

function chOf(d, s) {
  return (typeof d.ch === 'function') ? Math.round(d.ch(V(s))) : d.ch;
}

function renderActive() {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  var cv = $('mainCv');
  if (!cv) return;
  var T = d.tEnd(V(s));
  if (s.t > T) s.t = T;
  var ch = chOf(d, s);
  if (endOn(d, s, s.t)) s._wkReady = true;
  preparePtBubbles(d, s, s.t);        /* 先に吹きだしの大きさを決めてから図を描く */
  var ctx = prep(cv, d.cw, ch);
  deferVec(true);                     /* ★ベクトルは最後にまとめて描く（前面に出す）★ */
  d.draw(ctx, s, s.t, d.cw, ch);
  flushVec(ctx);                      /* drawPts が呼ばれなかったとき（運動のとちゅう）用 */
  drawEqualTicks(ctx);
  /* ★「仕事の分析」モードのときだけ、力を「クリックできる」ように見せる★ */
  drawForceHints(ctx, d, s, s.t);
  placePtBubbles(d, ch);
  drawStep($('stepCv'));
  /* ★グラフは「ほんとうの運動のあいだ」だけ描く★（第14回）
     2-4 は「止まったあと、もう一度はじめから再生して点 B で止める」ので、
     アニメの長さ（tEnd）はくり返しのぶんだけ長い。そのまま横軸にすると
     グラフが途中でもどってしまうので、d.tGraph があればそちらを使う。 */
  var TG = (d.tGraph ? d.tGraph(V(s)) : T);
  /* グラフのカーソル（いまの時刻の点）も、グラフの横軸に合わせた時刻で打つ。
     2-4 の「2回目の再生」では、カーソルがグラフを右から左へもどる＝
     「いま見ているのは、はじめの所をもう一度」が目で分かる。 */
  var TC = (d.tCursor ? d.tCursor(V(s), s.t) : Math.min(s.t, TG));
  renderGraphs(d, s, TG, TC);
  renderFormulas(d, s);
  renderFigHint(d, s, s.t);
  renderResult(d, s, s.t);
  renderEqZone(d, s, s.t);
  renderWorkPanel(d, s, s.t);
  renderPtab(d, s);
  refreshActs();
  renderReadout(d, s, s.t);
  renderEq(d, s);
  var bar = $('tBar');
  if (bar) {
    var mx = T.toFixed(2);
    if (bar.max !== mx) bar.max = mx;
    var val = s.t.toFixed(2);
    if (bar.value !== val) bar.value = val;
    setText($('tVal'), fmt(s.t, 2) + ' s');
  }
}

/* .tex の中身を KaTeX で組む（1度だけ） */
function renderMath(root) {
  if (!root || !window.katex) return;
  Array.prototype.forEach.call(root.querySelectorAll('.tex'), function (el) {
    if (el.getAttribute('data-done')) return;
    el.setAttribute('data-done', '1');
    var src = el.textContent;
    el.textContent = '';
    try { window.katex.render(src, el, { throwOnError: false }); }
    catch (e) { el.textContent = src; }
  });
}

/* ===== 画面の切りかえ（ハッシュ #m1-3） ===== */
function hashOf() { return st.cur; }
function parseHash(h) {
  h = (h || '').replace('#', '');
  var i = h.indexOf('!');
  if (i < 0) i = h.indexOf('?');
  if (i >= 0) h = h.slice(0, i);
  return { id: h };
}
function syncHash() {
  var want = '#' + hashOf();
  if (location.hash !== want) {
    st._skipHash = true;
    location.hash = want;
  }
}

function gotoSim(id) {
  if (!DEFS[id]) return;
  st.cur = id;
  st._fSel = null; st._fHover = null;    /* 力の選択はシムごとにリセット */
  buildTabs();
  buildPanel();
  renderActive();
  syncHash();
  updateUrlBar();
}

/* ===== アニメーション ===== */
var lastTs = null;
function tick(ts) {
  var s = st.sims[st.cur], d = DEFS[st.cur];
  if (lastTs === null) lastTs = ts;
  var dt = Math.min(0.033, (ts - lastTs) / 1000);
  lastTs = ts;
  if (s && s.playing) {
    var T = d.tEnd(V(s));
    var rate = d.rate ? d.rate(V(s)) : 1;
    s.t = Math.min(T, s.t + dt * rate * (s.slow ? 0.25 : 1));
    if (s.t >= T - 1e-9) {
      if (d.loop) { s.t = 0; }
      else { s.playing = false; setPlayLabel(); }
    }
    renderActive();
  }
  requestAnimationFrame(tick);
}
```

## src/90_boot.js

```js
/* 起動とテスト用フック */
'use strict';
(function () {
  initState();
  drawLegend();
  renderMath(document.body);

  var hp = parseHash(location.hash);
  if (!DEFS[hp.id]) hp.id = 'm1-1';
  st.cur = hp.id;
  buildTabs();
  buildPanel();
  renderActive();
  updateUrlBar();

  window.addEventListener('hashchange', function () {
    if (st._skipHash) { st._skipHash = false; return; }
    var q = parseHash(location.hash);
    if (!DEFS[q.id]) return;
    if (q.id !== st.cur) gotoSim(q.id);
  });

  $('urlcopy').addEventListener('click', function () {
    var txt = location.href.indexOf('#') >= 0 ? location.href : location.href + '#' + st.cur;
    var done = function () { $('urlmsg').textContent = 'コピーしました'; };
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(txt).then(done, fallback);
      } else fallback();
    } catch (e) { fallback(); }
    function fallback() {
      var ta = document.createElement('textarea');
      ta.value = txt; document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); done(); }
      catch (e2) { $('urlmsg').textContent = '手動でコピーしてください'; }
      document.body.removeChild(ta);
    }
  });

  if (document.fonts && document.fonts.ready && document.fonts.ready.then) {
    document.fonts.ready.then(function () { refitFormulas(); placeModeTip(); });
  }
  window.addEventListener('resize', function () {
    refitFormulas(); placeModeTip(); drawStep($('stepCv'));
  });
  /* 説明文の中の「1-10 を見る」などのリンクで、そのシミュレーションへ飛ぶ */
  document.addEventListener('click', function (e) {
    var el = e.target;
    while (el && el !== document) {
      if (el.getAttribute && el.getAttribute('data-goto')) {
        var id = el.getAttribute('data-goto');
        if (DEFS[id]) { e.preventDefault(); gotoSim(id); }
        return;
      }
      el = el.parentNode;
    }
  });

  requestAnimationFrame(tick);

  /* ===== 自動テスト用のフック ===== */
  window.TEST = {
    sims: function () { return Object.keys(DEFS); },
    state: function () {
      var s = st.sims[st.cur];
      return { sim: st.cur, v: JSON.parse(JSON.stringify(s.v)), o: JSON.parse(JSON.stringify(s.o)), t: +s.t.toFixed(4) };
    },
    goto: function (id) { gotoSim(id); window.TEST.pause(); return st.cur; },
    pause: function () {
      var s = st.sims[st.cur];
      s.playing = false; s.t = 0;
      setPlayLabel(); renderActive();
      return +s.t.toFixed(4);
    },
    set: function (o) {
      var s = st.sims[st.cur];
      if (o.vars) Object.keys(o.vars).forEach(function (k) { if (k in s.v) s.v[k] = o.vars[k]; });
      if (o.opts) Object.keys(o.opts).forEach(function (k) { s.o[k] = o.opts[k]; });
      if (o.t !== undefined) s.t = o.t; else s.t = 0;
      s.playing = false;
      buildPanel();
      renderActive();
      return window.TEST.state();
    },
    /* 運動を最後まで進めた状態にする（吹きだしとくらべる式を出す） */
    toEnd: function () {
      var s = st.sims[st.cur], d = DEFS[st.cur];
      s._played = true;
      s.t = d.tEnd(V(s));
      s.playing = false;
      setPlayLabel(); renderActive();
      return +s.t.toFixed(4);
    },
    act: function (i) {
      var b = document.getElementById('act_' + i);
      if (!b) return null;
      b.click(); window.TEST.pause();
      return window.TEST.state();
    },
    openAll: function () { toggleAllGraphs(); return window.TEST.graphsOpen(); },
    graphsOpen: function () { return JSON.parse(JSON.stringify(st.sims[st.cur].open)); },
    graphMap: function (key) {
      var cv = document.getElementById('gc_' + key);
      if (!cv || !cv._map) return null;
      var m = cv._map;
      return { xmin: +m.xmin.toFixed(4), xmax: +m.xmax.toFixed(4), ymin: +m.ymin.toFixed(4), ymax: +m.ymax.toFixed(4) };
    },
    gview: function (key, view) {
      var s = st.sims[st.cur];
      if (view === undefined) return s.gview[key] || null;
      if (view === null) delete s.gview[key]; else s.gview[key] = view;
      renderActive();
      return s.gview[key] || null;
    },
    /* 横軸（時間）の目盛りが、運動の終わりまで届いているか */
    xTicks: function () {
      var d = DEFS[st.cur], s = st.sims[st.cur], out = {};
      /* ★グラフの横軸は d.tGraph があればそちら★（第14回）
         2-4 は「止まったあと、もう一度はじめから再生して点 B で止める」ので、
         アニメの長さ（tEnd）とグラフの長さ（tGraph）がちがう。 */
      var T = (d.tGraph ? d.tGraph(V(s)) : d.tEnd(V(s)));
      graphsOf(d, s).forEach(function (g) {
        var cv = document.getElementById('gc_' + g.key);
        if (!s.open[g.key] || !cv || !cv._map) return;
        var m = cv._map, last = null, i;
        for (i = Math.ceil(m.xmin / m.xstep) * m.xstep; i <= m.xmax + 1e-9; i += m.xstep) {
          if (Math.abs(i) > 1e-9) last = i;
        }
        out[g.key] = { T: +T.toFixed(4), xmax: +m.xmax.toFixed(4), step: +m.xstep.toFixed(4),
          last: last === null ? null : +last.toFixed(4), ok: last !== null && last >= T - 1e-6 };
      });
      return out;
    },
    formulas: function () {
      var d = DEFS[st.cur], s = st.sims[st.cur], out = {};
      graphsOf(d, s).forEach(function (g) { if (g.fml) out[g.key] = g.fml(V(s), s); });
      return out;
    },
    readout: function () {
      return Array.prototype.map.call(document.querySelectorAll('#readout tr'), function (tr) {
        return tr.children[0].textContent + '=' + tr.children[1].textContent;
      });
    },
    /* 計算結果の帯 */
    resbar: function () {
      return Array.prototype.map.call(document.querySelectorAll('#resbar .ritem'), function (el) {
        return el.querySelector('.rk').textContent + '=' + el.querySelector('.rv').textContent;
      });
    },
    /* 各点の表（記号と数値） */
    ptab: function () {
      return Array.prototype.map.call(document.querySelectorAll('#ptab tr'), function (tr) {
        return Array.prototype.map.call(tr.children, function (td) { return td.textContent; }).join('|');
      });
    },
    /* 図の下の立式3つ（出ているかどうかも返す） */
    compare: function () {
      var box = document.getElementById('eqzone');
      return { shown: box ? !box.hidden : null, text: box ? box.textContent : '' };
    },
    /* 立式3つの見出し・開閉と、「仕事を表示」のボタン */
    eqzone: function () {
      var box = document.getElementById('eqzone');
      if (!box || box.hidden) return { shown: false, secs: [], pairs: [] };
      return {
        shown: true,
        allEq: !!st.allEq,
        secs: Array.prototype.map.call(box.querySelectorAll('.eqsec'), function (el) {
          return { key: el.id.replace('eqs_', ''),
            title: el.querySelector('.eqttl').textContent,
            badge: el.querySelector('.badge').textContent,
            open: el.className.indexOf('open') >= 0 };
        }),
        title: (function () {
          var e2 = box.querySelector('.eqztitle');
          return e2 ? e2.textContent : '';
        })(),
        pairs: Array.prototype.map.call(box.querySelectorAll('.eqpair'), function (b) {
          return b.textContent + (b.className.indexOf('on') >= 0 ? '*' : '');
        })
      };
    },
    /* 「仕事の分析」モードに入る／出る（★全シム共通★） */
    workMode: function (on) {
      /* ★第6回からボタンは2つ★（「エネルギーのグラフを表示」／「仕事の分析」）。
         入るときと出るときで、おすボタンがちがう。 */
      var b = document.getElementById(on ? 'bWork' : 'bGraphMode');
      if (b && !!st.workMode !== !!on) b.click();
      return { on: !!st.workMode, label: b ? b.textContent : null,
        graphsShown: !document.getElementById('gwrap').hidden,
        panelShown: !document.getElementById('wkpanel').hidden };
    },
    /* 仕事の分析の欄の中身（力・正負・仕事の値・合計） */
    workPanel: function () {
      var el = document.getElementById('wkpanel');
      if (!el || el.hidden) return { shown: false, cards: [] };
      return {
        shown: true,
        cards: Array.prototype.map.call(el.querySelectorAll('.wkcard'), function (c) {
          return { key: c.id.replace('wkc_', ''),
            badge: c.querySelector('.wkbadge') ? c.querySelector('.wkbadge').textContent : '',
            val: c.querySelector('.wkval') ? c.querySelector('.wkval').textContent : '' };
        }),
        sum: el.querySelector('.wksum') ? el.querySelector('.wksum').textContent : ''
      };
    },
    /* 図の中の「クリックできる力」の場所（仕事の分析モードのとき） */
    /* ★検算用★ ゴーストの速度ベクトルの「長さ ÷ 速さ」が全点で同じか
       （＝矢印の長さの比が速さの比と合っているか）。第7回の直しの見張り。 */
    ghostVel: function () {
      var g = st._vGhost || [], out = [], i, r, r0 = null, err = 0;
      for (i = 0; i < g.length; i++) {
        if (!(g[i].v > 0.02)) continue;
        r = g[i].L / g[i].v;
        if (r0 === null) r0 = r;
        else err = Math.max(err, Math.abs(r - r0) / Math.max(1e-9, r0));
        out.push({ n: g[i].n, v: +g[i].v.toFixed(3), L: +g[i].L.toFixed(2) });
      }
      return { pts: out, ratio_err: +err.toFixed(6) };
    },
    forceHits: function () {
      return (st._fHits || []).map(function (h) {
        return { key: h.key, x: Math.round(h.x), y: Math.round(h.y),
          w: Math.round(h.w), h: Math.round(h.h) };
      });
    },
    /* その力をクリックしたことにする（欄が光る） */
    clickForce: function (key) {
      flashWork(key);
      var el = document.getElementById('wkc_' + key);
      return el ? el.className : null;
    },
    /* 立式でくらべる2点を選ぶ（j＝2つめの点の番号） */
    eqPairs: function (j) {
      var bs = document.querySelectorAll('#eqzone .eqpair');
      if (j !== undefined && bs[j - 1]) bs[j - 1].click();
      return Array.prototype.map.call(document.querySelectorAll('#eqzone .eqpair'), function (b) {
        return b.textContent + (b.className.indexOf('on') >= 0 ? '*' : '');
      });
    },
    eqTitle: function () {
      var el = document.querySelector('#eqzone .eqztitle');
      return el ? el.textContent : null;
    },
    /* 立式の見出しをおす（'cons' / 'rel' / 'wk'）／「3つの式を表示」を切りかえる */
    eqToggle: function (k) {
      var b = document.querySelector('#eqzone [data-eqk="' + k + '"]');
      if (b) b.click();
      return window.TEST.eqzone().secs;
    },
    allEq: function (on) {
      var cb = document.getElementById('cbAllEq');
      /* ★click() を使う★ dispatchEvent(new Event('change')) は bubbles が false なので、
         #eqzone に付けた委譲のハンドラに届かない（テストだけ動かなくてハマった）。 */
      if (cb && cb.checked !== !!on) cb.click();
      return window.TEST.eqzone().secs;
    },
    /* ステップ図の中身 */
    step: function () {
      var D = stepData();
      return { ok: D.ok, eq: D.eq, why: D.why, rows: D.rows };
    },
    /* 図の中の文字の重なりを調べる（__labelLog を使う） */
    labelOverlap: function () {
      var log = window.__labelLog || [], out = [], i, j;
      function box(a) { return { x1: a.x, y1: a.y - a.h / 2, x2: a.x + a.w, y2: a.y + a.h / 2, t: a.text, cv: a.cv }; }
      for (i = 0; i < log.length; i++) {
        for (j = i + 1; j < log.length; j++) {
          if (log[i].cv !== log[j].cv) continue;
          var A = box(log[i]), B = box(log[j]);
          var ox = Math.min(A.x2, B.x2) - Math.max(A.x1, B.x1);
          var oy = Math.min(A.y2, B.y2) - Math.max(A.y1, B.y1);
          if (ox > 3 && oy > 3) out.push({ a: A.t, b: B.t, cv: A.cv, ox: +ox.toFixed(1), oy: +oy.toFixed(1) });
        }
      }
      return out;
    },

    /* ===== 物理の検算（UI の状態によらない固定の計算） ===== */
    check: function () {
      var r = {}, i, k;

      /* E のずれ [%]（保存系では 0.1 % 未満でなければならない） */
      function drift(id, v) {
        var d = DEFS[id], T = d.tEnd(v), N = 600, E0 = d.sample(v, 0).E, mx = 0, sc = 0;
        for (var q = 0; q <= N; q++) {
          var m0 = d.sample(v, T * q / N);
          mx = Math.max(mx, Math.abs(m0.E - E0));
          /* 1-10・2-3 は基準面のとり方で E = 0 になる。0 で割らないよう
             「エネルギーの大きさ」でわり算する */
          sc = Math.max(sc, Math.abs(m0.K), Math.abs(m0.Ug), Math.abs(m0.Us), Math.abs(E0));
        }
        return +(mx / Math.max(1e-9, sc) * 100).toFixed(5);
      }
      r.drift_m11 = drift('m1-1', { v0: 4, m: 2 });
      r.drift_m12 = drift('m1-2', { h: 5, m: 1 });
      r.drift_m12b = drift('m1-2', { h: 20, m: 3 });
      r.drift_m13_30 = drift('m1-3', { th: 30, h: 3, m: 2 });
      r.drift_m13_75 = drift('m1-3', { th: 75, h: 5, m: 2 });
      r.drift_m14 = drift('m1-5', { h: 3, m: 1 });
      r.drift_m14b = drift('m1-5', { h: 5, m: 2 });
      r.drift_m15 = drift('m1-6', { th: 40, v0: 0, l: 1, m: 1 });
      r.drift_m15b = drift('m1-6', { th: 70, v0: 2, l: 1.6, m: 2 });
      r.drift_max = Math.max(r.drift_m11, r.drift_m12, r.drift_m12b, r.drift_m13_30,
        r.drift_m13_75, r.drift_m14, r.drift_m14b, r.drift_m15, r.drift_m15b);

      /* 自由落下 v = √(2gh) */
      var f = { h: 5, m: 1 };
      r.fall_v = +P.m12.sample(f, P.m12.tEnd(f)).v.toFixed(6);
      r.fall_v_formula = +Math.sqrt(2 * G * f.h).toFixed(6);
      r.fall_T = +P.m12.tEnd(f).toFixed(6);
      r.fall_E_start = +P.m12.sample(f, 0).E.toFixed(6);      /* = mgh */
      r.fall_E_end = +P.m12.sample(f, P.m12.tEnd(f)).E.toFixed(6);

      /* 直線の滑り台：傾きによらず下端の速さが同じ */
      r.slope_v = [15, 30, 45, 60, 75].map(function (th) {
        var v = { th: th, h: 3, m: 2 };
        return +P.m13.sample(v, P.m13.tEnd(v)).v.toFixed(4);
      }).join(',');
      r.slope_v_formula = +Math.sqrt(2 * G * 3).toFixed(4);
      r.slope_t = [15, 30, 45, 60, 75].map(function (th) {
        return +P.m13.tEnd({ th: th, h: 3, m: 2 }).toFixed(3);
      }).join(',');

      /* 曲線の滑り台：数値計算でも下端の速さが √(2gh) と合う */
      var c1 = { h: 3, m: 1 }, tc = P.m14.tEnd(c1);
      r.curve_v = +P.m14.sample(c1, tc).v.toFixed(4);
      r.curve_v_formula = +Math.sqrt(2 * G * 3).toFixed(4);
      r.curve_v_err_pct = +(Math.abs(P.m14.sample(c1, tc).v - Math.sqrt(2 * G * 3)) /
        Math.sqrt(2 * G * 3) * 100).toFixed(4);
      r.curve_same_as_line = +Math.abs(P.m14.vEnd(c1) - P.m13.vEnd({ th: 30, h: 3 })).toFixed(9);

      /* 振り子 v = √(2gl(1−cosθ)) */
      var p1 = { th: 40, v0: 0, l: 1, m: 1 };
      r.pend_v = +P.m15.sample(p1, P.m15.tBottom(p1)).v.toFixed(4);
      r.pend_v_formula = +Math.sqrt(2 * G * 1 * (1 - Math.cos(40 * DEG))).toFixed(4);
      r.pend_v_err_pct = +(Math.abs(P.m15.sample(p1, P.m15.tBottom(p1)).v - P.m15.vBottom(p1)) /
        P.m15.vBottom(p1) * 100).toFixed(4);
      r.pend_T = +P.m15.tEnd(p1).toFixed(4);
      /* 小さな振れなら T ≈ 2π√(l/g) */
      var p2 = { th: 10, v0: 0, l: 1, m: 1 };
      r.pend_T_small = +P.m15.tEnd(p2).toFixed(4);
      r.pend_T_ideal = +(2 * Math.PI * Math.sqrt(1 / G)).toFixed(4);
      /* 1周期まわると、はじめの状態にもどる */
      var pa = P.m15.sample(p1, 0), pb = P.m15.sample(p1, P.m15.tEnd(p1));
      r.pend_loop_dth = +Math.abs(pa.th - pb.th).toFixed(6);

      /* 摩擦：E(t) − E(0) = W(t) がいつでも成り立つ／止まる位置が式と合う */
      var w1 = { v0: 5, mu: 0.3, m: 2 }, mx2 = 0, N2 = 500;
      for (i = 0; i <= N2; i++) {
        var q2 = P.m21.sample(w1, P.m21.tEnd(w1) * i / N2);
        mx2 = Math.max(mx2, Math.abs((q2.E - P.m21.sample(w1, 0).E) - q2.W));
      }
      r.fric_identity_max = +mx2.toFixed(9);
      r.fric_L = +P.m21.xStop(w1).toFixed(6);
      r.fric_L_formula = +(w1.v0 * w1.v0 / (2 * w1.mu * G)).toFixed(6);
      r.fric_x_at_stop = +P.m21.sample(w1, P.m21.tStop(w1)).x.toFixed(6);
      r.fric_E_end = +P.m21.sample(w1, P.m21.tStop(w1)).E.toFixed(9);
      r.fric_W_end = +P.m21.sample(w1, P.m21.tStop(w1)).W.toFixed(6);
      r.fric_E0 = +P.m21.sample(w1, 0).E.toFixed(6);

      /* ===== 1-4 滑台（直線）2：斜面を昇る ===== */
      var su = { v0: 6, th: 30, m: 2 };
      r.up_h = +P.slopeUp.sample(su, P.slopeUp.tEnd(su)).h.toFixed(6);
      r.up_h_formula = +(su.v0 * su.v0 / (2 * G)).toFixed(6);
      /* ★θ を変えても上がる高さは同じ★ */
      r.up_h_by_theta = [15, 30, 45, 60, 75].map(function (th) {
        var q = { v0: 6, th: th, m: 2 };
        return +P.slopeUp.sample(q, P.slopeUp.tEnd(q)).h.toFixed(4);
      }).join(',');
      r.up_L = +P.slopeUp.len(su).toFixed(6);
      r.up_v_at_top = +P.slopeUp.sample(su, P.slopeUp.tEnd(su)).v.toFixed(9);
      r.drift_up = drift('m1-4', su);

      /* ===== 1-7 ジェットコースター（ループ＋斜面） ===== */
      var cw1 = { v0: 14, th: 40, m: 200 };
      r.drift_cyl = drift('m1-7', cw1);
      r.drift_cylb = drift('m1-7', { v0: 16, th: 60, m: 500 });
      r.coast_vB = +P.coaster.sample(cw1, P.coaster.tB(cw1)).v.toFixed(3);
      r.coast_vB_formula = +P.coaster.vB(cw1).toFixed(3);
      r.coast_hB = +P.coaster.sample(cw1, P.coaster.tB(cw1)).h.toFixed(3);
      r.coast_hB_formula = +P.coaster.D.toFixed(3);
      r.coast_hC = +P.coaster.sample(cw1, P.coaster.tTop(cw1)).h.toFixed(2);
      r.coast_hC_formula = +P.coaster.hC(cw1).toFixed(2);
      r.coast_v_at_top = +P.coaster.sample(cw1, P.coaster.tTop(cw1)).v.toFixed(6);
      /* ★第18回★ 帰りにスタート地点へもどったときの速さは v0 にもどる */
      r.coast_v_back_at_A = +P.coaster.sample(cw1, P.coaster.tEnd(cw1)).v.toFixed(4);
      r.coast_x_back_at_A = +P.coaster.sample(cw1, P.coaster.tEnd(cw1)).x.toFixed(4);
      /* ★止まる高さは θ によらない★ */
      r.coast_hC_by_theta = [35, 40, 45, 50, 55, 60].map(function (th2) {
        var q = { v0: 14, th: th2, m: 200 };
        return +P.coaster.sample(q, P.coaster.tTop(q)).h.toFixed(2);
      }).join(',');
      /* ★どの設定でもループを1周できる（頂上で v² ≥ gR）★ */
      var okLoop = 1;
      for (var vv = 14; vv <= 16.0001; vv += 0.5) {
        [35, 40, 45, 50, 55, 60].forEach(function (th3) {
          [100, 200, 300, 400, 500].forEach(function (m4) {
            if (!P.coaster.loopOK({ v0: vv, th: th3, m: m4 })) okLoop = 0;
          });
        });
      }
      r.coast_loop_ok_all = okLoop;

      /* ===== 1-10 水平ばねにぶつかる ===== */
      var hs1 = { v0: 4, k: 200, m: 1.0 };
      r.hit_xmax = +P.hitSpring.sample(hs1, P.hitSpring.tC(hs1)).x.toFixed(6);
      r.hit_xmax_formula = +(hs1.v0 * Math.sqrt(hs1.m / hs1.k)).toFixed(6);
      r.hit_vB = +P.hitSpring.sample(hs1, P.hitSpring.t1(hs1)).v.toFixed(6);
      r.hit_v0 = +hs1.v0.toFixed(6);                  /* A→B で速さは変わらない */
      r.hit_K_at_C = +P.hitSpring.sample(hs1, P.hitSpring.tC(hs1)).K.toFixed(6);
      r.hit_Us_at_C = +P.hitSpring.sample(hs1, P.hitSpring.tC(hs1)).Us.toFixed(6);
      r.hit_E0 = +P.hitSpring.sample(hs1, 0).E.toFixed(6);
      r.drift_hit = drift('m1-10', hs1);

      /* ===== 1-11 水平ばねと滑台 ===== */
      var ss1 = { x0: 0.75, k: 35, m: 1.0 };
      r.spsl_vB = +P.sprSlide.sample(ss1, P.sprSlide.t1(ss1)).v.toFixed(6);
      r.spsl_vB_formula = +P.sprSlide.vB(ss1).toFixed(6);
      r.spsl_hC = +P.sprSlide.sample(ss1, P.sprSlide.tC(ss1)).h.toFixed(4);
      r.spsl_hC_formula = +P.sprSlide.hC(ss1).toFixed(4);
      r.spsl_v_at_C = +P.sprSlide.sample(ss1, P.sprSlide.tC(ss1)).v.toFixed(6);
      /* ★x0 を2倍にすると高さは4倍★ */
      r.spsl_h_ratio = +(P.sprSlide.hC({ x0: 0.90, k: 35, m: 1 }) /
        P.sprSlide.hC({ x0: 0.45, k: 35, m: 1 })).toFixed(4);
      /* ★どの設定でも坂のてっぺんを越えない★ */
      var okHill = 1;
      [0.45, 0.55, 0.65, 0.75, 0.85, 0.90].forEach(function (x0b) {
        [20, 25, 30, 35, 40].forEach(function (kb) {
          [1.0, 1.25, 1.5, 1.75, 2.0].forEach(function (mb) {
            if (!(P.sprSlide.hC({ x0: x0b, k: kb, m: mb }) < P.sprSlide.yTop() - 0.05)) okHill = 0;
          });
        });
      });
      r.spsl_fits_hill_all = okHill;
      r.drift_spsl = drift('m1-11', ss1);

      /* ===== 1-8 斜方投射 ===== */
      var pj = { v0: 8, th: 40, h: 2, m: 1 };
      r.proj_vend = +P.m17.sample(pj, P.m17.tEnd(pj)).v.toFixed(6);
      r.proj_vend_formula = +Math.sqrt(pj.v0 * pj.v0 + 2 * G * pj.h).toFixed(6);
      r.proj_ytop = +P.m17.sample(pj, P.m17.tTop(pj)).h.toFixed(6);
      r.proj_ytop_formula = +P.m17.yTop(pj).toFixed(6);
      r.proj_vtop = +P.m17.sample(pj, P.m17.tTop(pj)).v.toFixed(6);
      r.proj_vtop_formula = +P.m17.vx(pj).toFixed(6);
      r.drift_m17 = drift('m1-8', pj);

      /* ===== 1-9 水平ばね：½kx₀² = ½mv² ===== */
      var s8 = { x0: 0.3, k: 40, m: 1.0 };
      r.spr_vmax = +P.m18.sample(s8, P.m18.tNat(s8)).v.toFixed(6);
      r.spr_vmax_formula = +Math.sqrt(v18E(s8) * 2 / s8.m).toFixed(6);
      function v18E(q) { return 0.5 * q.k * q.x0 * q.x0; }
      r.spr_Us0 = +EN.Us(s8.k, s8.x0).toFixed(6);
      r.spr_K_at_nat = +P.m18.sample(s8, P.m18.tNat(s8)).K.toFixed(6);
      r.drift_m18 = drift('m1-9', s8);

      /* ===== 1-12 鉛直ばね：E が一定、最下点 x = 2mg/k ===== */
      var s9 = { d: 0, k: 50, m: 1.0 };
      r.vspr_xeq = +P.m19.xEq(s9).toFixed(6);
      r.vspr_xlow = +P.m19.xLow(s9).toFixed(6);
      r.vspr_xlow_formula = +(2 * s9.m * G / s9.k).toFixed(6);
      r.vspr_x_at_tlow = +P.m19.sample(s9, P.m19.tLow(s9)).x.toFixed(6);
      r.vspr_veq = +P.m19.sample(s9, P.m19.tEq(s9)).v.toFixed(6);
      r.vspr_veq_formula = +Math.abs(P.m19.vEq(s9)).toFixed(6);
      r.drift_m19 = drift('m1-12', s9);
      r.drift_m19b = drift('m1-12', { d: 0.1, k: 30, m: 1.0 });

      /* ===== 1-11 曲面から飛び出す ===== */
      var s10 = { h: 2.5, v0: 0, m: 1 };
      r.drift_m110 = drift('m1-13', s10);
      r.drift_m110b = drift('m1-13', { h: 3.5, v0: 3, m: 2 });
      r.bowl_vB = +P.m110.sample(s10, P.m110.tB(s10)).v.toFixed(4);
      r.bowl_vB_formula = +P.m110.vB(s10).toFixed(4);
      r.bowl_vC = +P.m110.sample(s10, P.m110.tC(s10)).v.toFixed(4);
      r.bowl_vC_formula = +P.m110.vC(s10).toFixed(4);
      r.bowl_hD = +P.m110.sample(s10, P.m110.tD(s10)).h.toFixed(3);
      r.bowl_hD_formula = +P.m110.hD(s10).toFixed(3);
      /* 最高点 D は「飛び出したあと」にある */
      r.bowl_tD_after_tC = P.m110.tD(s10) > P.m110.tC(s10) ? 1 : 0;
      /* ★飛び出す条件の見張り★（第9回）
         「N ≤ 0 になった所で面から離れるべきでは？」という指摘への答え。
         くぼみ（凹の面）では N = m(g cosθ + v²/R) がいつでも正なので、
         円の上で面から離れることは起こらない。どの設定でも N > 0 かを確かめる。 */
      var nmin = Infinity, nmov = Infinity, nAtC = Infinity, nneg = 0, iv0, ih, iq;
      for (iv0 = 0; iv0 <= 4; iv0 += 0.5) {
        for (ih = 1.5; ih <= 3.5001; ih += 0.1) {
          var vN = { h: +ih.toFixed(1), v0: iv0, m: 1 }, tbN = P.m110.table(vN).tab;
          for (iq = 0; iq < tbN.length; iq++) {
            if (!tbN[iq].on || tbN[iq].wall) continue;
            var nn = P.m110.Nof(vN, tbN[iq]);
            if (nn < 0) nneg++;
            nmin = Math.min(nmin, nn);
            if (tbN[iq].v > 0.05) nmov = Math.min(nmov, nn);
          }
          nAtC = Math.min(nAtC, vN.m * (G * Math.cos(P.m110.PHI) +
            P.m110.vC(vN) * P.m110.vC(vN) / P.m110.R));
        }
      }
      /* しらべた設定の数：v0 = 0〜4（0.5 きざみ）× h = 1.5〜3.5（0.1 きざみ）＝ 189 通り */
      r.bowl_N_min = +nmin.toPrecision(3);      /* 円の上でいちばん小さい N（＝はなす瞬間） */
      r.bowl_N_min_moving = +nmov.toFixed(3);   /* 動いているあいだのいちばん小さい N */
      r.bowl_N_at_C = +nAtC.toFixed(3);         /* 飛び出す点 C での N */
      r.bowl_N_negative_count = nneg;           /* N < 0 になった回数（0 でなければならない） */
      r.bowl_N_always_pos = nneg === 0 ? 1 : 0; /* 1 なら「面から離れることはない」 */

      /* ===== 2-2 あらい斜面を上る ===== */
      var s22 = { v0: 6, th: 30, mu: 0.25, m: 2 }, mx22 = 0, E22 = P.m22.sample(s22, 0).E;
      for (i = 0; i <= 500; i++) {
        var q22 = P.m22.sample(s22, P.m22.tStop(s22) * i / 500);
        mx22 = Math.max(mx22, Math.abs((q22.E - E22) - q22.W));
      }
      r.rough_identity_max = +mx22.toFixed(9);
      r.rough_L = +P.m22.sStop(s22).toFixed(6);
      r.rough_L_formula = +(s22.v0 * s22.v0 /
        (2 * G * (Math.sin(30 * DEG) + s22.mu * Math.cos(30 * DEG)))).toFixed(6);
      r.rough_L_smooth = +(s22.v0 * s22.v0 / (2 * G * Math.sin(30 * DEG))).toFixed(6);
      r.rough_v_at_stop = +P.m22.sample(s22, P.m22.tStop(s22)).v.toFixed(9);

      /* ===== 2-3 手でゆっくり下ろす：E(t) − E(0) = W_手(t) ===== */
      var s23 = { d: 0, k: 50, m: 1.0 }, mx23 = 0, E23 = P.m23.sample(s23, 0).E;
      for (i = 0; i <= 500; i++) {
        var q23 = P.m23.sample(s23, P.m23.T * i / 500);
        mx23 = Math.max(mx23, Math.abs((q23.E - E23) - q23.W));
      }
      r.hand_identity_max = +mx23.toFixed(6);
      r.hand_W_end = +P.m23.W(s23, P.m23.T).toFixed(4);
      /* 両はしで K=0 なので W = ΔU（＝ ½kx_eq² − mg·x_eq、d=0 のとき） */
      r.hand_W_formula = +(EN.Us(s23.k, P.m23.xEq(s23)) - s23.m * G * P.m23.xEq(s23) -
        (EN.Us(s23.k, s23.d) - s23.m * G * s23.d)).toFixed(4);
      /* 手をはなしたときの最下点（1-12）は、つりあいの位置の2倍 */
      r.hand_xeq = +P.m23.xEq(s23).toFixed(6);
      r.hand_xlow_free = +P.m23.xLow(s23).toFixed(6);

      /* ===== 2-4 摩擦がある水平面のばね ===== */
      var s24 = { x0: 0.30, k: 40, m: 1.0, mu: 0.10 }, mx24 = 0, E24 = P.m24.sample(s24, 0).E;
      for (i = 0; i <= 800; i++) {
        var q24 = P.m24.sample(s24, P.m24.tEnd(s24) * i / 800);
        mx24 = Math.max(mx24, Math.abs((q24.E - E24) - q24.W));
      }
      r.sprfric_identity_max = +mx24.toExponential(2);
      r.sprfric_vnat = +P.m24.sample(s24, P.m24.tNat(s24)).v.toFixed(6);
      r.sprfric_vnat_formula = +P.m24.vNat(s24).toFixed(6);
      /* 自然長を通るとき、伸び x はちょうど 0 */
      r.sprfric_x_at_nat = +Math.abs(P.m24.sample(s24, P.m24.tNat(s24)).x).toExponential(1);
      /* 摩擦なし（1-9）より必ずおそい */
      r.sprfric_slower = P.m24.vNat(s24) < P.m18.vMax({ x0: 0.3, k: 40, m: 1.0 }) ? 1 : 0;
      /* どの設定でも、自然長までは必ずとどく（x0 > 2μ'mg/k） */
      var okReach = 1;
      [0.20, 0.30, 0.40].forEach(function (x0) {
        [40, 70, 100].forEach(function (k2) {
          [0.05, 0.10, 0.15, 0.20].forEach(function (mu) {
            [0.5, 1.0, 1.5].forEach(function (m2) {
              var w2 = { x0: x0, k: k2, m: m2, mu: mu };
              if (!(x0 > 2 * P.m24.xc(w2) + 1e-9) || !(P.m24.vNat(w2) > 0)) okReach = 0;
            });
          });
        });
      });
      r.sprfric_reaches_nat_all = okReach;
      /* 最後に止まる位置は |x| ≤ μ'mg/k（静止摩擦でとまる範囲）の中 */
      r.sprfric_stop_in_band = Math.abs(P.m24.xStop(s24)) <= P.m24.xc(s24) + 1e-9 ? 1 : 0;

      /* ===== 2-5 斜面を糸で引き上げる ===== */
      var s25 = { Ft: 36, mu: 0.30, th: 30, m: 2.0 }, mx25 = 0, E25 = P.m25.sample(s25, 0).E;
      for (i = 0; i <= 500; i++) {
        var q25 = P.m25.sample(s25, P.m25.tEnd(s25) * i / 500);
        mx25 = Math.max(mx25, Math.abs((q25.E - E25) - q25.W));
      }
      r.pull_identity_max = +mx25.toExponential(2);
      r.pull_vend = +P.m25.sample(s25, P.m25.tEnd(s25)).v.toFixed(6);
      r.pull_vend_formula = +P.m25.vEnd(s25).toFixed(6);
      r.pull_h = +P.m25.sample(s25, P.m25.tEnd(s25)).h.toFixed(6);
      r.pull_h_formula = +(P.m25.L * Math.sin(30 * DEG)).toFixed(6);
      /* どの設定でも必ず動きだす（F > mg sinθ + μ' mg cosθ） */
      var okMove = 1;
      for (var Ft = 32; Ft <= 44; Ft += 2) {
        [20, 25, 30, 35, 40, 45].forEach(function (th2) {
          [0.15, 0.25, 0.35, 0.45, 0.50].forEach(function (mu2) {
            [2.0, 2.5, 3.0].forEach(function (m3) {
              var w3 = { Ft: Ft, th: th2, mu: mu2, m: m3 };
              if (!(P.m25.a(w3) > 0) || !isFinite(P.m25.tEnd(w3))) okMove = 0;
            });
          });
        });
      }
      r.pull_moves_all = okMove;

      /* ★各力の仕事の合計 ＝ 運動エネルギーの変化★（全シム） */
      /* 数値積分のシム（1-5・1-6・1-7 など）は E がごくわずかに動くので、
         大きさで割った「割合」で見る。0.01 % より大きければ直すこと。 */
      var wErr = 0, wMiss = [];
      Object.keys(DEFS).forEach(function (id) {
        var d = DEFS[id], v = V(st.sims[id]);
        var ps = ptsOf(d, v), A = ps[0], B = ps[ps.length - 1];
        var sum = 0, sc2 = Math.max(1e-9, Math.abs(A.m.E), Math.abs(B.m.E),
          Math.abs(A.m.K), Math.abs(B.m.K), Math.abs(A.m.U), Math.abs(B.m.U));
        forcesOf(d, v).forEach(function (f) { sum += f.W; });
        var e = Math.abs(sum - (B.m.K - A.m.K)) / sc2 * 100;
        if (e > 0.01) wMiss.push(id + ':' + e.toExponential(2));
        wErr = Math.max(wErr, e);
      });
      r.work_sum_err_pct = +wErr.toExponential(2);
      r.work_sum_bad = wMiss.join(',');

      /* ★エネルギーの棒が枠からはみ出していないか★（全シム・第10回に追加）
         energyBar は【正のものを 0 から上へ、負のものを 0 から下へ】積むので、
         上へのびる長さ＝正のものの合計、下へのびる長さ＝負のものの合計。
         energyRange の lo〜hi がこれを含んでいないと、帯が枠の外へ出てしまう。
         2-3 と 1-12（U_g が負になるシム）で実際に出ていた（先生の指摘・第10回）。 */
      var ebOver = 0, ebBad = [];
      Object.keys(DEFS).forEach(function (id) {
        var d = DEFS[id], sS = st.sims[id], v = V(sS);
        var rg = energyRange(d, sS), T2 = d.tEnd(v), i2, j2, worst = 0;
        var span = Math.max(1e-9, rg.hi - rg.lo);
        for (i2 = 0; i2 <= 200; i2++) {
          var q3 = d.sample(v, T2 * i2 / 200), pos3 = 0, neg3 = 0, e4 = [q3.K, q3.Ug, q3.Us];
          for (j2 = 0; j2 < 3; j2++) {
            if (e4[j2] > 0) pos3 += e4[j2];
            else if (e4[j2] < 0) neg3 += e4[j2];
          }
          worst = Math.max(worst, pos3 - rg.hi, rg.lo - neg3, q3.E - rg.hi, rg.lo - q3.E);
        }
        var pct = worst / span * 100;
        if (pct > 0.01) ebBad.push(id + ':' + pct.toFixed(2) + '%');
        ebOver = Math.max(ebOver, pct);
      });
      r.ebar_overflow_pct = +ebOver.toFixed(4);   /* 0 でなければならない */
      r.ebar_overflow_bad = ebBad.join(',');

      r.drift_max_all = Math.max(r.drift_max, r.drift_up, r.drift_cyl, r.drift_cylb,
        r.drift_m17, r.drift_m18, r.drift_m19, r.drift_m19b, r.drift_m110, r.drift_m110b,
        r.drift_hit, r.drift_spsl);

      /* 表に出している各点の K・U が、グラフ（＝同じ sample）の値と一致する */
      var mism = 0;
      Object.keys(DEFS).forEach(function (id) {
        var d = DEFS[id], s = st.sims[id], v = V(s);
        ptsOf(d, v).forEach(function (pt) {
          var m2 = d.sample(v, pt.t);
          if (Math.abs(m2.K - pt.m.K) > 1e-9 || Math.abs(m2.U - pt.m.U) > 1e-9 ||
            Math.abs(m2.E - (m2.K + m2.U)) > 1e-9) mism++;
        });
      });
      r.ptab_matches_graph = mism;

      /* エネルギーの定義が1か所であること（EN を通した値と手計算が一致） */
      r.en_K = +EN.K(2, 3).toFixed(6);
      r.en_Ug = +EN.Ug(2, 5).toFixed(6);
      r.en_Us = +EN.Us(100, 0.2).toFixed(6);
      return r;
    }
  };
})();
```
