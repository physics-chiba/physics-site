/* モード1　非保存力が仕事をしないケース（力学的エネルギーが保存される） */
'use strict';

/* ★1-3（直線の滑台）・1-4（昇る）・1-5（曲線の滑台）は、同じ h なら同じ高さに見せる★
   （縮尺の上限をそろえる。ばらばらだと「同じ 3 m なのに曲線のほうが高い」と見える） */
var SC_SLIDE = 70;   /* 第9回：図が小さすぎたので上限を上げた（実際は横はばで決まる） */

/* ★地面の下にあける「吹きだしの帯」の高さ [px]★（先生の指示・第6回）
   吹きだしを A → B → C の順にならべるために、地面より下も使ってよいことにした。
   帯を使うシムは ch にこの分を足し、gy を「H − もとの余白 − PTBAND」にする。 */
var PTBAND = 66;

/* 1-7 ジェットコースターの縮尺 [px/m]。★固定★
   （自動にすると θ で絵の大きさが変わって「止まる高さは θ によらない」が伝わらない）
   いちばん広がる設定（v0 = 16、θ = 35°）でも横も縦も入る値にしてある。 */
var SC_COAST = 15.5;   /* 第6回：図が左に寄って右があいていたので大きくした */

/* 1-10 水平ばねにぶつかる／1-11 水平ばねと滑台 の縮尺 [px/m]。どちらも固定。 */
var SC_HIT = 215;   /* 第9回：右があいていたので大きくした（壁の右はしが 578 px で、地面の右はし 624 px に入る） */
var SC_SPSL = 84;

/* ============ 1-1 摩擦のない水平面 ============ */
DEFS['m1-1'] = {
  id: 'm1-1', mode: 1, tab: '1-1 摩擦のない水平面',
  title: '1-1　摩擦のない水平面',
  sub: 'なめらかな水平面。<b>重力と垂直抗力はつり合って</b>いて、しかもどちらも<b>運動の向きに垂直</b>だから<b>仕事をしない</b>。' +
    'だから速さは変わらず、$K$ も $U$ も、その和の $E$ も一定のまま。ここが「力学的エネルギーが保存する」いちばん単純な形。',
  cw: 520, ch: 215,
  vis: ['F', 'V', 'A'],
  mainVars: ['v0', 'm'],
  mainVarFocus: 'v0',
  vars: [
    { k: 'v0', label: '速さ $v$', unit: ' m/s', min: 1, max: 8, step: 0.5, dec: 1, def: 4.0 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 5, step: 0.5, dec: 1, def: 2.0 }
  ],
  actions: [
    { label: '速くする（v＝6 m/s）', fn: function (s) { s.v.v0 = 6; },
      is: function (v) { return Math.abs(v.v0 - 6) < 1e-9; },
      next: function (s) { return s._played && Math.abs(s.v.v0 - 6) > 1e-9; } },
    { label: '重くする（m＝4 kg）', fn: function (s) { s.v.m = 4; },
      is: function (v) { return Math.abs(v.m - 4) < 1e-9; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.v0 = 4; s.v.m = 2; },
      is: function (v) { return Math.abs(v.v0 - 4) < 1e-9 && Math.abs(v.m - 2) < 1e-9; } }
  ],
  cons: true,
  forces: ['g', 'N'],
  hintFig: '<b>速さが変わらない → K が変わらない</b>（基準面を床にとったので $U=0$ のまま。だから $E$ も変わらない）',
  step1: '重力と垂直抗力しかはたらかず、どちらも運動の向きに垂直なので仕事をしない',
  datum: '床（物体のある水平面）',
  hint2: '<b>次は</b>：オレンジのボタンで速さや質量を変えて、グラフの高さがどう変わるか見てみよう（形は変わらない）。',
  tEnd: function (v) { return P.m11.tEnd(v); },
  sample: function (v, t) { return P.m11.sample(v, t); },
  pts: [
    { name: 'A', jp: 'スタート', t: function () { return 0; },
      sym: { K: '\\tfrac{1}{2}mv^2', Ug: '0' } },
    { name: 'B', jp: fmt(P.m11.LB, 0) + ' m 進んだところ', t: function (v) { return P.m11.tB(v); },
      sym: { K: '\\tfrac{1}{2}mv^2', Ug: '0' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m1-1'], v = V(s), m = d.sample(v, t);
    var gy = H - 58, x0 = 70, sc = (W - 120 - x0) / P.m11.LEN;   /* 床のはしまで走らせる */
    function X(x) { return x0 + x * sc; }
    var kz = mSize(d, v), bw = 34 * kz, bh = 24 * kz;

    ground(ctx, 20, W - 96, gy);
    datumLine(ctx, 20, W - 96, gy, '基準面 h = 0', false, true);
    /* ★印は物体の横★（第6回）上下は mg・N の矢印が通るので、外側の横に置く */
    ptMark(ctx, 'A', X(0) - bw / 2 - 13, gy - bh / 2);
    ptMark(ctx, 'B', X(P.m11.LB) + bw / 2 + 13, gy - bh / 2);

    /* 残像 */
    var i;
    for (i = 0; i * 0.25 < t - 1e-9; i++) {
      ctx.save(); ctx.globalAlpha = 0.28;
      blockShape(ctx, X(v.v0 * i * 0.25), gy - bh / 2, 0, bw, bh, '#f2f4f7');
      ctx.restore();
    }
    var cx = X(m.x), cy = gy - bh / 2;
    blockShape(ctx, cx, cy, 0, bw, bh, '#e8eef5');

    /* デコピンではじいて動き出す */
    flickStart(ctx, t, v.v0, X(0) - bw / 2 - 20, cy, 0, 74);

    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 40 / mg;
    function fAt(ax) {
      arrow(ctx, ax, cy, ax, cy + mg * fs, 'force');
      label(ctx, 'mg', ax, cy + mg * fs + 11, { size: 11.5, color: COL.force });
      arrow(ctx, ax, gy, ax, gy - mg * fs, 'force', 1, COL.norm);
      label(ctx, 'N', ax + bw / 2 + 8, gy - mg * fs + 4, { align: 'left', size: 11.5, color: COL.norm });
    }
    if (s.o.showF) fAt(cx);
    if (s.o.showV) {
      var vl = vArrowLen(v.v0, 8, 56);
      var va = velArrow(ctx, cx, cy, 0, -1, bh / 2 + 42, 1, 0, vl);
      label(ctx, 'v', va.tx + 10, va.ty, { align: 'left', size: 11.5, color: COL.vel });
    }
    if (s.o.showA) {
      /* 力がつり合っているので加速度は 0。矢印が描けないので、そう書いておく */
      label(ctx, 'a = 0', cx, cy - bh / 2 - 22, { size: 11.5, color: COL.acc });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    drawPts(ctx, d, s, t, function (p) {
      var A = (p.name === 'A'), xx = X(A ? 0 : P.m11.LB);
      return { x: xx + (A ? -1 : 1) * (bw / 2 + 13), y: gy - bh / 2,
        ox: xx, oy: gy - bh / 2, bw: bw, bh: bh,
        fdraw: function () { fAt(xx); },
        vx: 1, vy: 0, vref: 8, vk: 56, voff: bw / 2 + 10 };
    });
  },
  resItems: function (v) {
    return [{ k: 'A から B までの距離', v: fmt(P.m11.LB, 1) + ' m' }];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m1-1'].sample(v, t);
    return [
      ['位置 $x$', fmt(m.x, 2) + ' m'],
      ['重力 $mg$', fmt(v.m * G, 1) + ' N'],
      ['垂直抗力 $N$', fmt(v.m * G, 1) + ' N'],
      ['運動の続く時間', fmt(P.m11.tEnd(v), 2) + ' s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return 'E = K + U = \\tfrac{1}{2}mv^2 + 0 = ' + fmt(EN.K(v.m, v.v0), 2) +
      '\\ \\mathrm{J}\\quad(\\text{一定})';
  },
  note: '力は<b>重力と垂直抗力の2本だけ</b>で、どちらも運動の向き（水平）に<b>垂直</b>だから仕事をしません。' +
    'だから <b>K は一定</b>。基準面を床にとったので <b>U = 0</b>、したがって <b>E = K も一定</b>です。' +
    'グラフはどれも<b>水平な直線</b>になります。'
};

/* ============ 1-2 自由落下 ============ */
DEFS['m1-2'] = {
  id: 'm1-2', mode: 1, tab: '1-2 自由落下',
  title: '1-2　自由落下',
  sub: '手をはなすだけ（初速度 0）。はたらく力は<b>重力だけ</b>で、重力は<b>保存力</b>だから力学的エネルギーは保存される。' +
    '落ちるにつれて $U_g=mgh$ が減り、そのぶん $K=\\tfrac12mv^2$ が増える。<b>地面に着く直前の速さは $v=\\sqrt{2gh}$</b>。',
  /* 縮尺を 10 px ＝ 1 m に固定し、h を変えたら「絵の高さ」が変わるようにする
     （ch = 150 + 10h なので、手をはなす位置はいつも同じ高さ y = 104 に来る） */
  cw: 430,
  ch: function (v) { return Math.round(150 + 10 * v.h); },
  vis: ['F', 'V', 'A'],
  mainVars: ['h', 'm'],
  mainVarFocus: 'h',
  vars: [
    { k: 'h', label: '手をはなす高さ $h$', unit: ' m', min: 5, max: 20, step: 0.5, dec: 1, def: 12.0 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 5, step: 0.5, dec: 1, def: 1.0 }
  ],
  actions: [
    { label: '低くする（h＝6 m）', fn: function (s) { s.v.h = 6; },
      is: function (v) { return Math.abs(v.h - 6) < 1e-9; },
      next: function (s) { return s._played && Math.abs(s.v.h - 6) > 1e-9; } },
    { label: '重くする（m＝3 kg）', fn: function (s) { s.v.m = 3; },
      is: function (v) { return Math.abs(v.m - 3) < 1e-9; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.h = 12; s.v.m = 1; },
      is: function (v) { return Math.abs(v.h - 12) < 1e-9 && Math.abs(v.m - 1) < 1e-9; } }
  ],
  cons: true,
  forces: ['g'],
  hintFig: '<b>$U$ が減った分だけ $K$ が増える</b>（その和の $E$ は変わらない）',
  step1: '重力（保存力）だけが仕事をしている',
  datum: '地面',
  hint2: '<b>次は</b>：質量 $m$ を変えても<b>着地の速さが変わらない</b>ことを確かめよう（$m$ は両辺から消える）。',
  tEnd: function (v) { return P.m12.tEnd(v); },
  sample: function (v, t) { return P.m12.sample(v, t); },
  pts: [
    { name: 'A', jp: '手をはなす点', t: function () { return 0; }, sym: { K: '0', Ug: 'mgh' } },
    { name: 'B', jp: '地面', t: function (v) { return P.m12.tEnd(v); },
      sym: { K: '\\tfrac{1}{2}mv^2', Ug: '0' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m1-2'], v = V(s), m = d.sample(v, t);
    var sc = 10, gy = H - 46, topY = gy - v.h * sc, bx = W * 0.40;
    function Y(y) { return gy - y * sc; }
    var kz = mSize(d, v), r = 9 * kz;

    ground(ctx, 18, W - 96, gy);
    datumLine(ctx, 18, W - 96, gy, '基準面 h = 0', true);
    /* 運動が終わったら、点ごとの高さ（drawPts）に任せてこの1本は消す */
    if (!endOn(d, s, t)) heightDim(ctx, bx + 52, topY, gy, 'h = ' + fmt(v.h, 1) + ' m');
    ptMark(ctx, 'A', bx - 34, topY);
    ptMark(ctx, 'B', bx - 34, gy);

    /* 残像 */
    var i;
    for (i = 1; i * 0.2 < t - 1e-9; i++) ball(ctx, bx, Y(d.sample(v, i * 0.2).y), r, 'faint');

    var y = Y(m.y);
    ball(ctx, bx, y, r);

    /* 手をはなす（0.16 s で指をひらいて、すっと消える） */
    var hA = (t <= 0.16) ? 1 : Math.max(0, 1 - (t - 0.16) / 0.20);
    if (hA > 0.02) dropHand(ctx, bx, topY, 0.60, clamp(t / 0.16, 0, 1), hA);

    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 40 / mg;
    function fAt(ay) {
      arrow(ctx, bx, ay, bx, ay + mg * fs, 'force');
      label(ctx, 'mg', bx, ay + mg * fs + 11, { size: 11.5, color: COL.force });
    }
    if (s.o.showF) fAt(y);
    if (s.o.showV && m.v > 0.05) {
      /* 地面より下へ矢印がはみ出さないように、長さに頭を打たせる */
      var vl = Math.min(vArrowLen(m.v, Math.max(1, P.m12.vEnd(v)), 60), H - 18 - y);
      var va = velArrow(ctx, bx, y, 1, 0, 22, 0, 1, vl);
      label(ctx, 'v', va.x + 10, va.ty + 8, { align: 'left', size: 11.5, color: COL.vel });
    }
    if (s.o.showA) drawAcc(ctx, bx, y, 0, G, { nx: -1, ny: 0, off: 30 });
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    drawPts(ctx, d, s, t, function (p) {
      var yy = p.name === 'A' ? topY : gy;
      return { x: bx - 34, y: yy, ox: bx, oy: yy, r: r,
        fdraw: function () { fAt(yy); },
        vx: 0, vy: 1, vref: Math.max(1, P.m12.vEnd(v)), vk: 60, voff: r + 8, base: gy, hx: bx + 52 };
    });
  },
  resItems: function (v) {
    return [{ k: '着地の速さ（式 $\\sqrt{2gh}$）', v: fmt(P.m12.vEnd(v), 2) + ' m/s' }];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m1-2'].sample(v, t);
    return [
      ['落ちた距離', fmt(v.h - m.y, 2) + ' m'],
      ['重力 $mg$', fmt(v.m * G, 1) + ' N'],
      ['地面に着く時刻', fmt(P.m12.tEnd(v), 2) + ' s'],
      ['着地直前の速さ', fmt(P.m12.vEnd(v), 2) + ' m/s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return 'mgh = \\tfrac{1}{2}mv^2 \\;\\Rightarrow\\; v = \\sqrt{2gh} = ' +
      fmt(P.m12.vEnd(v), 2) + '\\ \\mathrm{m/s}';
  },
  note: '仕事をするのは<b>重力だけ</b>（保存力）。だから力学的エネルギーは保存されます。' +
    '$U_g=mgh$ が減った分がそのまま $K$ に変わるので、<b>K–t 図と U–t 図は上下対称</b>になり、' +
    '<b>E–t 図は水平</b>。式は $mgh=\\tfrac12mv^2$ で、両辺の $m$ が消えるので<b>着地の速さは質量によりません</b>。'
};

/* ============ 1-3 滑台（直線）1：すべり下りる ============ */
DEFS['m1-3'] = {
  id: 'm1-3', mode: 1, tab: '1-3 滑台（直線）1',
  title: '1-3　滑台（直線）1 — すべり下りる',
  sub: 'なめらかな斜面。<b>垂直抗力は運動の向きに垂直</b>なので仕事をしません。仕事をするのは重力だけ。' +
    'だから下端の速さは <b>$v=\\sqrt{2gh}$</b> で、<b>斜面の傾き $\\theta$ を変えても同じ</b>（かかる時間は変わります）。',
  cw: 580, ch: 290,        /* 第6回：吹きだしが「エネルギー」の字にかかるので少し広く */
  vis: ['F', 'Fc', 'V', 'A'],
  mainVars: ['th', 'h'],
  mainVarFocus: 'th',
  vars: [
    { k: 'th', label: '斜面の角 $\\theta$', unit: '°', min: 15, max: 75, step: 5, dec: 0, def: 30 },
    { k: 'h', label: '高さ $h$', unit: ' m', min: 1, max: 5, step: 0.5, dec: 1, def: 3.0 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 5, step: 0.5, dec: 1, def: 2.0 }
  ],
  actions: [
    { label: '急にする（θ＝60°）', fn: function (s) { s.v.th = 60; },
      is: function (v) { return v.th === 60; },
      next: function (s) { return s._played && s.v.th !== 60; } },
    { label: 'ゆるくする（θ＝15°）', fn: function (s) { s.v.th = 15; },
      is: function (v) { return v.th === 15; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.th = 30; s.v.h = 3; },
      is: function (v) { return v.th === 30 && Math.abs(v.h - 3) < 1e-9; } }
  ],
  cons: true,
  forces: ['g', 'N'],
  hintFig: '<b>垂直抗力は運動の向きに垂直 → 仕事をしない</b>。だから下端の速さは傾きによらず $\\sqrt{2gh}$',
  step1: '重力（保存力）だけが仕事をする。垂直抗力は運動の向きに垂直なので仕事をしない',
  datum: '地面（斜面の下端）',
  hint2: '<b>次は</b>：$\\theta$ を変えても<b>下端の速さが同じ</b>になることを確かめよう（かかる時間だけが変わります）。',
  tEnd: function (v) { return P.m13.tEnd(v); },
  sample: function (v, t) { return P.m13.sample(v, t); },
  pts: [
    { name: 'A', jp: '斜面の上', t: function () { return 0; }, sym: { K: '0', Ug: 'mgh' } },
    { name: 'B', jp: '一番下', t: function (v) { return P.m13.tEnd(v); },
      sym: { K: '\\tfrac{1}{2}mv^2', Ug: '0' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m1-3'], v = V(s), m = d.sample(v, t);
    var th = v.th * DEG, gy = H - 52;
    var run = v.h / Math.tan(th);
    /* ★縮尺は θ を変えても動かさない★（見どころは「下端の速さは θ によらない」）
       いちばん寝かせた坂（θ = 15°）でも収まる大きさにしておく。 */
    var runMax = v.h / Math.tan(15 * DEG);
    var sc = Math.min(SC_SLIDE, (W - 210) / Math.max(runMax, 0.4), (H - 118) / v.h);
    /* ★急な斜面（run が小さい）だと左すみに固まるので、横の中央に置く★ */
    var x0 = Math.max(92, 40 + ((W - 150) - run * sc) / 2);
    var TX = x0, TY = gy - v.h * sc, BX = x0 + run * sc, BY = gy;
    var ux = Math.cos(th), uy = Math.sin(th);        /* 斜面を下る向き（画面） */
    var nx = Math.sin(th), ny = -Math.cos(th);       /* 斜面から外向き（画面） */

    /* 斜面の板 */
    ctx.save();
    ctx.fillStyle = '#eef1f4';
    ctx.beginPath(); ctx.moveTo(TX, TY); ctx.lineTo(BX, BY); ctx.lineTo(TX, BY); ctx.closePath();
    ctx.fill();
    ctx.restore();
    hatchLine(ctx, TX, TY, BX, BY, 1);
    ctx.save();
    ctx.strokeStyle = '#98a0a8'; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(TX, TY); ctx.lineTo(TX, BY); ctx.stroke();
    ctx.restore();
    ground(ctx, 20, W - 96, gy);
    datumLine(ctx, 20, W - 96, gy, '基準面 h = 0', false, true);
    angArc(ctx, BX, BY, 32, -Math.PI, th - Math.PI, '', 0, 0);
    label(ctx, 'θ = ' + fmt(v.th, 0) + '°', BX - 46, gy - 13, { align: 'right', size: 12, color: COL.sub });
    /* 運動が終わったら、点ごとの高さ（drawPts）に任せてこの1本は消す */
    if (!endOn(d, s, t)) heightDim(ctx, 26, TY, gy, 'h = ' + fmt(v.h, 1) + ' m', TX, true);

    var kz = mSize(d, v), bw = 30 * kz, bh = 22 * kz;
    function pos(sv) { return { x: TX + ux * sv * sc, y: TY + uy * sv * sc }; }
    var pB = pos(P.m13.len(v));
    /* ★印は物体の「坂にそって外がわ」★（第6回）真上は N の矢印が通るのでずらす */
    var pA3 = { x: TX, y: TY };
    var mA3 = markAway(pA3, pB, nx, ny, bh / 2 + 4, bw / 2 + 14);
    var mB3 = markAway(pB, pA3, nx, ny, bh / 2 + 4, bw / 2 + 14);
    ptMark(ctx, 'A', mA3.x, mA3.y);
    ptMark(ctx, 'B', mB3.x, mB3.y);

    var i;
    for (i = 1; i * 0.2 < t - 1e-9; i++) {
      var q = pos(d.sample(v, i * 0.2).s);
      ctx.save(); ctx.globalAlpha = 0.26;
      blockShape(ctx, q.x + nx * bh / 2, q.y + ny * bh / 2, -th, bw, bh, '#f2f4f7');
      ctx.restore();
    }
    var p = pos(m.s), cx = p.x + nx * bh / 2, cy = p.y + ny * bh / 2;
    blockShape(ctx, cx, cy, -th, bw, bh, '#e8eef5');

    var hA = (t <= 0.16) ? 1 : Math.max(0, 1 - (t - 0.16) / 0.20);
    if (hA > 0.02) dropHand(ctx, TX + nx * 16 + 4, TY + ny * 16, 0.52, clamp(t / 0.16, 0, 1), hA);

    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 40 / mg;
    function fAt(sx, sy) {          /* sx, sy＝面に接している点 */
      var ax = sx + nx * bh / 2, ay = sy + ny * bh / 2;
      arrow(ctx, ax, ay, ax, ay + mg * fs, 'force');
      label(ctx, 'mg', ax, ay + mg * fs + 11, { size: 11.5, color: COL.force });
      var Nn = mg * Math.cos(th);
      arrow(ctx, sx, sy, sx + nx * Nn * fs, sy + ny * Nn * fs, 'force', 1, COL.norm);
      label(ctx, 'N', sx + nx * Nn * fs + 10, sy + ny * Nn * fs - 4, { align: 'left', size: 11.5, color: COL.norm });
    }
    if (s.o.showF) fAt(p.x, p.y);
    if (s.o.showFc) {
      var gs = mg * Math.sin(th), gc = mg * Math.cos(th);
      arrow(ctx, cx, cy, cx + ux * gs * fs, cy + uy * gs * fs, 'comp');
      label(ctx, 'mg sinθ', cx + ux * gs * fs + 6, cy + uy * gs * fs + 10, { align: 'left', size: 11, color: COL.force });
      arrow(ctx, cx, cy, cx - nx * gc * fs, cy - ny * gc * fs, 'comp');
      label(ctx, 'mg cosθ', cx - nx * gc * fs - 8, cy - ny * gc * fs + 12, { align: 'right', size: 11, color: COL.force });
    }
    if (s.o.showV && m.v > 0.05) {
      /* ★速度の矢印は物体から離して出す★（物体の上に重ねると読めない） */
      var vof = 34, vl = vArrowLen(m.v, Math.max(1, P.m13.vEnd(v)), 56);
      var va = velArrow(ctx, cx, cy, nx, ny, vof, ux, uy, vl);
      label(ctx, 'v', Math.min(va.tx + ux * 10, W - 104), Math.min(va.ty + uy * 10 - 8, gy - 16),
        { align: 'left', size: 11.5, color: COL.vel });
    }
    if (s.o.showA) {
      var aa = P.m13.a(v);          /* 斜面を下る向きに g sinθ */
      drawAcc(ctx, cx, cy, ux * aa, uy * aa, { nx: nx, ny: ny, off: 64 });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    drawPts(ctx, d, s, t, function (pt) {
      var q = (pt.name === 'A') ? { x: TX, y: TY } : pB, mk3 = (pt.name === 'A') ? mA3 : mB3;
      return { x: mk3.x, y: mk3.y,
        fdraw: function () { fAt(q.x, q.y); },
        ox: q.x + nx * bh / 2, oy: q.y + ny * bh / 2, bw: bw, bh: bh, ang: -th,
        vx: ux, vy: uy, vref: Math.max(1, P.m13.vEnd(v)), vk: 56, voff: 26, base: gy, hx: 26 };
    });
  },
  resItems: function (v) {
    return [
      { k: '斜面の長さ', v: fmt(P.m13.len(v), 2) + ' m' },
      { k: '下端の速さ（式 $\\sqrt{2gh}$）', v: fmt(P.m13.vEnd(v), 2) + ' m/s' }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m1-3'].sample(v, t);
    return [
      ['斜面にそって進んだ距離', fmt(m.s, 2) + ' m'],
      ['斜面方向の加速度 $g\\sin\\theta$', fmt(P.m13.a(v), 2) + ' m/s²'],
      ['垂直抗力 $N=mg\\cos\\theta$', fmt(v.m * G * Math.cos(v.th * DEG), 1) + ' N'],
      ['下まですべる時間', fmt(P.m13.tEnd(v), 2) + ' s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return 'mgh = \\tfrac{1}{2}mv^2 \\;\\Rightarrow\\; v = \\sqrt{2gh} = ' +
      fmt(P.m13.vEnd(v), 2) + '\\ \\mathrm{m/s}\\quad(\\theta \\text{ によらない})';
  },
  note: '斜面をすべっても、仕事をするのは<b>重力だけ</b>です（垂直抗力は運動の向きに垂直）。' +
    'だから $mgh=\\tfrac12mv^2$ が成り立ち、<b>下端の速さは傾きによらず $\\sqrt{2gh}$</b>。' +
    '$\\theta$ を変えると<b>かかる時間とグラフの横はば</b>だけが変わり、<b>E の高さは変わりません</b>。'
};

/* ============ 1-4 滑台（直線）2：斜面を昇る（新規） ============ */
DEFS['m1-4'] = {
  id: 'm1-4', mode: 1, tab: '1-4 滑台（直線）2',
  title: '1-4　滑台（直線）2 — 斜面を昇る',
  sub: 'なめらかな斜面の下から、<b>デコピンで初速度 $v_0$</b> を与えて昇らせます。' +
    '仕事をするのは重力だけ（垂直抗力は運動の向きに垂直）なので力学的エネルギーは保存され、' +
    '$\\tfrac12mv_0^{\\,2}=mgh$ から <b>上がる高さは $h=\\dfrac{v_0^{\\,2}}{2g}$</b>。' +
    '<b>斜面の角 $\\theta$ を変えても、上がる高さは変わりません</b>（斜面にそった距離は変わります）。',
  cw: 620, ch: 290,        /* 第9回：横をもっと使う */
  vis: ['F', 'Fc', 'V', 'A'],
  mainVars: ['v0', 'th'],
  mainVarFocus: 'th',
  vars: [
    { k: 'v0', label: 'はじめの速さ $v_0$', unit: ' m/s', min: 3, max: 8, step: 0.5, dec: 1, def: 6.0 },
    { k: 'th', label: '斜面の角 $\\theta$', unit: '°', min: 15, max: 75, step: 5, dec: 0, def: 30 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 5, step: 0.5, dec: 1, def: 2.0 }
  ],
  actions: [
    { label: '急にする（θ＝60°）', fn: function (s) { s.v.th = 60; },
      is: function (v) { return v.th === 60; },
      next: function (s) { return s._played && s.v.th !== 60; } },
    { label: 'ゆるくする（θ＝15°）', fn: function (s) { s.v.th = 15; },
      is: function (v) { return v.th === 15; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.v0 = 6; s.v.th = 30; },
      is: function (v) { return Math.abs(v.v0 - 6) < 1e-9 && v.th === 30; } }
  ],
  cons: true,
  forces: ['g', 'N'],
  hintFig: '<b>$\\theta$ を変えても、上がる高さ $h=v_0^{\\,2}/(2g)$ は変わらない</b>（斜面にそった距離は変わる）',
  step1: '重力（保存力）だけが仕事をする。垂直抗力は運動の向きに垂直なので仕事をしない',
  datum: '地面（斜面の下端）',
  hint2: '<b>次は</b>：$\\theta$ を変えても<b>上がる高さが同じ</b>になることを確かめよう（斜面にそった距離だけが変わります）。',
  tEnd: function (v) { return P.slopeUp.tEnd(v); },
  sample: function (v, t) { return P.slopeUp.sample(v, t); },
  pts: [
    { name: 'A', jp: 'スタート（下端）', t: function () { return 0; },
      sym: { K: '\\tfrac{1}{2}mv_0^{\\,2}', Ug: '0' } },
    { name: 'B', jp: '止まる位置', t: function (v) { return P.slopeUp.tEnd(v); },
      sym: { K: '0', Ug: 'mgh' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m1-4'], v = V(s), m = d.sample(v, t);
    var th = v.th * DEG, gy = H - 62;
    /* ★縮尺は θ を変えても動かさない★（この図の見どころは「上がる高さは θ によらない」）
       いちばん寝かせた坂（θ = 15°）でも横に収まる大きさにしておけば、
       θ をどう変えても縮尺は同じままで、高さをそのまま見くらべられる。
       ★第9回：右があきすぎていたので、余白を 250 → 176 px にして図を大きくした★ */
    var hTop = P.slopeUp.hTop(v), L = P.slopeUp.len(v);
    var run = L * Math.cos(th);
    var runMax = v.v0 * v.v0 / (2 * G * Math.tan(15 * DEG));   /* θ が最小のときの横はば */
    var sc = Math.min(SC_SLIDE, (W - 176) / Math.max(runMax, 0.4), (gy - 58) / Math.max(hTop, 0.3));
    var x0 = 96;
    var BX = x0, BY = gy, TX = x0 + run * sc, TY = gy - hTop * sc;
    var ux = Math.cos(th), uy = -Math.sin(th);       /* 斜面を昇る向き（画面） */
    var nx = -Math.sin(th), ny = -Math.cos(th);      /* 斜面から外向き（画面・上） */
    function pos(sv) { return { x: BX + ux * sv * sc, y: BY + uy * sv * sc }; }

    /* 斜面の板（下端が左、上が右） */
    ctx.save();
    ctx.fillStyle = '#eef1f4';
    ctx.beginPath(); ctx.moveTo(BX, BY); ctx.lineTo(TX, TY); ctx.lineTo(TX, BY); ctx.closePath();
    ctx.fill();
    ctx.restore();
    hatchLine(ctx, BX, BY, TX, TY, -1);
    ctx.save();
    ctx.strokeStyle = '#98a0a8'; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(TX, TY); ctx.lineTo(TX, BY); ctx.stroke();
    ctx.restore();
    ground(ctx, 20, W - 96, gy);
    datumLine(ctx, 20, W - 96, gy, '基準面 h = 0', true, true);
    angArc(ctx, BX, BY, 30, -th, 0, '', 0, 0);
    label(ctx, 'θ = ' + fmt(v.th, 0) + '°', BX + 44, gy - 12, { align: 'left', size: 12, color: COL.sub });

    var kz = mSize(d, v), bw = 30 * kz, bh = 22 * kz;
    var pA = pos(0), pB = pos(L);
    /* ★印は物体の「坂にそって外がわ」★（第6回） */
    var mA4 = markAway(pA, pB, nx, ny, bh / 2 + 4, bw / 2 + 14);
    var mB4 = markAway(pB, pA, nx, ny, bh / 2 + 4, bw / 2 + 14);
    ptMark(ctx, 'A', mA4.x, mA4.y);
    ptMark(ctx, 'B', mB4.x, mB4.y);

    var i;
    for (i = 1; i * 0.12 < t - 1e-9; i++) {
      var q = pos(d.sample(v, i * 0.12).s);
      ctx.save(); ctx.globalAlpha = 0.26;
      blockShape(ctx, q.x + nx * bh / 2, q.y + ny * bh / 2, th, bw, bh, '#f2f4f7');
      ctx.restore();
    }
    var p = pos(m.s), cx = p.x + nx * bh / 2, cy = p.y + ny * bh / 2;
    blockShape(ctx, cx, cy, th, bw, bh, '#e8eef5');
    /* 運動が終わったら、点ごとの高さ（drawPts）に任せてこの1本は消す */
    if (!endOn(d, s, t)) heightDim(ctx, 26, p.y, gy, 'h = ' + fmt(m.h, 2) + ' m', p.x, true);
    /* デコピンで打ち上げる（斜面の下から） */
    flickStart(ctx, t, v.v0, pA.x - ux * 22 + nx * bh / 2, pA.y - uy * 22 + ny * bh / 2, -th,
      118, 30);   /* 左は高さの寸法線、右上は坂。箱だけ右へ寄せる（しっぽは手の真上のまま） */
    /* ★いちばん高い所に「最高点」の吹きだし★（先生の指示・第13回）
       しっぽは下（＝その点をさす）。運動が終わってから出す。 */
    if (endOn(d, s, t)) ptNote(ctx, pB.x, pB.y, '最高点', '（点B）', { gap: 54 });

    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 34 / mg;
    function fAt(sx, sy) {
      var ax = sx + nx * bh / 2, ay = sy + ny * bh / 2;
      arrow(ctx, ax, ay, ax, ay + mg * fs, 'force');
      label(ctx, 'mg', ax, ay + mg * fs + 11, { size: 11.5, color: COL.force });
      var Nn = mg * Math.cos(th);
      arrow(ctx, sx, sy, sx + nx * Nn * fs, sy + ny * Nn * fs, 'force', 1, COL.norm);
      label(ctx, 'N', sx + nx * (Nn * fs + 12), sy + ny * (Nn * fs + 12),
        { size: 11.5, color: COL.norm });
    }
    if (s.o.showF) fAt(p.x, p.y);
    if (s.o.showFc) {
      var gs = mg * Math.sin(th);
      arrow(ctx, cx, cy, cx - ux * gs * fs, cy - uy * gs * fs, 'comp');
      label(ctx, 'mg sinθ', cx - ux * gs * fs - 6, cy - uy * gs * fs + 12,
        { align: 'right', size: 11, color: COL.force });
    }
    if (s.o.showV && m.v > 0.05) {
      var vof = 34, vl = vArrowLen(m.v, Math.max(1, v.v0), 50);
      var va = velArrow(ctx, cx, cy, nx, ny, vof, ux, uy, vl);
      label(ctx, 'v', va.tx + ux * 10, va.ty + uy * 10, { size: 11.5, color: COL.vel });
    }
    if (s.o.showA) {
      /* 加速度は斜面を下る向き（＝運動と逆）に g sinθ。だから減速する */
      var aa = P.slopeUp.a(v);
      drawAcc(ctx, cx, cy, -ux * aa, -uy * aa, { nx: nx, ny: ny, off: 64 });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    drawPts(ctx, d, s, t, function (pt) {
      var q = (pt.name === 'A') ? pA : pB, mk4 = (pt.name === 'A') ? mA4 : mB4;
      return { x: mk4.x, y: mk4.y,
        fdraw: function () { fAt(q.x, q.y); },
        ox: q.x + nx * bh / 2, oy: q.y + ny * bh / 2, bw: bw, bh: bh, ang: th,
        vx: ux, vy: uy, vref: Math.max(1, v.v0), vk: 50, voff: 26, base: gy, hx: 26 };
    });
  },
  resItems: function (v) {
    return [
      { k: '上がる高さ（式 $v_0^{\\,2}/2g$）', v: fmt(P.slopeUp.hTop(v), 2) + ' m' },
      { k: '斜面にそった距離 $L$', v: fmt(P.slopeUp.len(v), 2) + ' m' }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m1-4'].sample(v, t);
    return [
      ['斜面にそって進んだ距離', fmt(m.s, 2) + ' m'],
      ['斜面方向の加速度 $-g\\sin\\theta$', fmt(-P.slopeUp.a(v), 2) + ' m/s²'],
      ['垂直抗力 $N=mg\\cos\\theta$', fmt(v.m * G * Math.cos(v.th * DEG), 1) + ' N'],
      ['止まるまでの時間', fmt(P.slopeUp.tEnd(v), 2) + ' s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return '\\tfrac{1}{2}mv_0^{\\,2} = mgh \\;\\Rightarrow\\; h = \\dfrac{v_0^{\\,2}}{2g} = ' +
      fmt(P.slopeUp.hTop(v), 2) + '\\ \\mathrm{m}\\quad(\\theta \\text{ によらない})';
  },
  note: '1-3 の裏返しです。<b>はじめの運動エネルギーが、そっくり位置エネルギーに変わる</b>ところで止まります。' +
    '$\\tfrac12mv_0^{\\,2}=mgh$ の両辺から $m$ が消えるので、<b>上がる高さは質量にも斜面の角にもよりません</b>。' +
    '$\\theta$ を変えると<b>斜面にそった距離 $L=h/\\sin\\theta$ と、かかる時間</b>だけが変わります。'
};

/* ============ 1-5 滑台（曲線） ============ */
DEFS['m1-5'] = {
  id: 'm1-5', mode: 1, tab: '1-5 滑台（曲線）',
  title: '1-5　滑台（曲線）をすべり下りる',
  sub: '曲がっていても、面からの垂直抗力は<b>いつでも運動の向きに垂直</b>なので仕事をしません。' +
    'だから<b>斜面の形によらず</b> $mgh=\\tfrac12mv^2$ が成り立ち、下端の速さは 1-3 とまったく同じ $\\sqrt{2gh}$。',
  cw: 520, ch: 290,
  vis: ['F', 'V', 'A'],
  mainVars: ['h', 'm'],
  mainVarFocus: 'h',
  vars: [
    { k: 'h', label: '高さ $h$', unit: ' m', min: 1, max: 5, step: 0.5, dec: 1, def: 3.0 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 5, step: 0.5, dec: 1, def: 1.0 }
  ],
  actions: [
    { label: '高くする（h＝5 m）', fn: function (s) { s.v.h = 5; },
      is: function (v) { return Math.abs(v.h - 5) < 1e-9; },
      next: function (s) { return s._played && Math.abs(s.v.h - 5) > 1e-9; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.h = 3; s.v.m = 1; },
      is: function (v) { return Math.abs(v.h - 3) < 1e-9 && Math.abs(v.m - 1) < 1e-9; } }
  ],
  cons: true,
  forces: ['g', 'N'],
  hintFig: '<b>形がちがっても、同じ高さから出発すれば下端の速さは同じ</b>（$mgh=\\tfrac12mv^2$）',
  step1: '重力（保存力）だけが仕事をする。曲面でも垂直抗力は運動の向きに垂直',
  datum: '地面（曲面の下端）',
  hint2: '<b>次は</b>：<a href="#m1-3" data-goto="m1-3">1-3（直線の滑台）</a>と<b>同じ $h$</b> にして、下端の速さをくらべてみよう。',
  tEnd: function (v) { return P.m14.tEnd(v); },
  sample: function (v, t) { return P.m14.sample(v, t); },
  pts: [
    { name: 'A', jp: '曲面の上', t: function () { return 0; }, sym: { K: '0', Ug: 'mgh' } },
    { name: 'B', jp: '一番下', t: function (v) { return P.m14.tEnd(v); },
      sym: { K: '\\tfrac{1}{2}mv^2', Ug: '0' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m1-5'], v = V(s), m = d.sample(v, t), L = P.m14.L;
    var gy = H - 52, x0 = 92;      /* 左に高さの寸法を置くぶんの余白 */
    var sc = Math.min(SC_SLIDE, (W - 230) / L, (H - 118) / v.h);
    function X(x) { return x0 + x * sc; }
    function Y(y) { return gy - y * sc; }
    var o = P.m14.table(v), cv = o.cv, i, q;

    /* 曲面 */
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(X(0), Y(v.h));
    for (i = 1; i <= 80; i++) {
      var xx = L * i / 80;
      ctx.lineTo(X(xx), Y(v.h * (1 - xx / L) * (1 - xx / L)));
    }
    ctx.lineTo(X(0), Y(0)); ctx.closePath();
    ctx.fillStyle = '#eef1f4'; ctx.fill();
    ctx.strokeStyle = '#333'; ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(X(0), Y(v.h));
    for (i = 1; i <= 80; i++) {
      var x2 = L * i / 80;
      ctx.lineTo(X(x2), Y(v.h * (1 - x2 / L) * (1 - x2 / L)));
    }
    ctx.stroke();
    ctx.restore();
    ground(ctx, 20, W - 96, gy);
    datumLine(ctx, 20, W - 96, gy, '基準面 h = 0', false, true);
    /* 運動が終わったら、点ごとの高さ（drawPts）に任せてこの1本は消す */
    if (!endOn(d, s, t)) heightDim(ctx, 26, Y(v.h), gy, 'h = ' + fmt(v.h, 1) + ' m', X(0), true);
    /* ★印は球と力の矢印からずらす★（第6回）B は真下に mg が通るので、右へずらす */
    ptMark(ctx, 'A', X(0), Y(v.h) - 14);
    ptMark(ctx, 'B', X(L) + 22, gy + 14);

    var kz = mSize(d, v), r = 9 * kz;
    for (i = 1; i * 0.2 < t - 1e-9; i++) {
      q = d.sample(v, i * 0.2);
      ball(ctx, X(q.x), Y(q.y) - r, r, 'faint');
    }
    var px = X(m.x), py = Y(m.y) - r;
    ball(ctx, px, py, r);

    var hA = (t <= 0.16) ? 1 : Math.max(0, 1 - (t - 0.16) / 0.20);
    if (hA > 0.02) dropHand(ctx, X(0), Y(v.h) - r, 0.52, clamp(t / 0.16, 0, 1), hA);

    var mg = v.m * G, fs = 40 / mg;
    var dyds = m.dyds || 0, tx = Math.sqrt(Math.max(0, 1 - dyds * dyds));
    /* 世界座標での外向き法線は (−dy/ds, dx/ds)。画面は y が下向きなので (−dy/ds, −dx/ds) */
    var nx = -dyds, ny = -tx;
    var nl = Math.hypot(nx, ny) || 1; nx /= nl; ny /= nl;
    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    function fAt(qq, ax, ay) {              /* ax, ay＝球の中心 */
      var dd = qq.dyds || 0, tt = Math.sqrt(Math.max(0, 1 - dd * dd));
      var n2x = -dd, n2y = -tt, n2l = Math.hypot(n2x, n2y) || 1;
      n2x /= n2l; n2y /= n2l;
      arrow(ctx, ax, ay, ax, ay + mg * fs, 'force');
      label(ctx, 'mg', ax, ay + mg * fs + 11, { size: 11.5, color: COL.force });
      var Nn = mg * tt;                       /* N = mg cosθ（速さが変わるので目安） */
      arrow(ctx, ax, ay + r, ax + n2x * Nn * fs, ay + r + n2y * Nn * fs, 'force', 1, COL.norm);
      label(ctx, 'N', ax + n2x * Nn * fs + 10, ay + r + n2y * Nn * fs - 4,
        { align: 'left', size: 11.5, color: COL.norm });
    }
    if (s.o.showF) fAt(m, px, py);
    var vx = tx, vy = -dyds;                /* 進む向き（画面。y は下向きが正） */
    if (s.o.showV && m.v > 0.05) {
      /* ★物体から離して出す★（上に 26 px ずらしてから進む向きへ） */
      var vl = vArrowLen(m.v, Math.max(1, P.m14.vEnd(v)), 56);
      var va = velArrow(ctx, px, py, nx, ny, 26, vx, vy, vl);
      label(ctx, 'v', va.tx + vx * 10, va.ty + vy * 10, { size: 11.5, color: COL.vel });
    }
    if (s.o.showA) {
      /* 加速度＝重力＋垂直抗力（合力）／m。曲面では接線方向と向心方向の和になる */
      var Na = mg * tx, ax = nx * Na / v.m, ay = G + ny * Na / v.m;
      drawAcc(ctx, px, py, ax, ay, { nx: nx, ny: ny, off: 56 });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    drawPts(ctx, d, s, t, function (p) {
      var A = (p.name === 'A');
      /* A では曲面の接線が水平（dy/dx = −2h/L）なので、速度の向きは点ごとに出す */
      var q = d.sample(v, p.t), dq = q.dyds || 0, tq = Math.sqrt(Math.max(0, 1 - dq * dq));
      return { x: A ? X(0) : X(L) + 22, y: A ? Y(v.h) - 14 : gy + 14,
        ox: A ? X(0) : X(L), oy: (A ? Y(v.h) : gy) - r, r: r,
        fdraw: function () { fAt(q, A ? X(0) : X(L), (A ? Y(v.h) : gy) - r); },
        vx: tq, vy: -dq, vref: Math.max(1, P.m14.vEnd(v)), vk: 56, voff: r + 10, base: gy, hx: 26 };
    });
  },
  resItems: function (v) {
    return [{ k: '下端の速さ（式 $\\sqrt{2gh}$）', v: fmt(P.m14.vEnd(v), 2) + ' m/s' }];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m1-5'].sample(v, t);
    return [
      ['曲面にそって進んだ距離', fmt(m.s, 2) + ' m'],
      ['いまの高さ', fmt(m.h, 2) + ' m'],
      ['下まですべる時間', fmt(P.m14.tEnd(v), 2) + ' s'],
      ['下端の速さ', fmt(P.m14.vEnd(v), 2) + ' m/s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return 'mgh = \\tfrac{1}{2}mv^2 \\;\\Rightarrow\\; v = \\sqrt{2gh} = ' +
      fmt(P.m14.vEnd(v), 2) + '\\ \\mathrm{m/s}\\quad(\\text{曲面の形によらない})';
  },
  note: '曲面の傾きは場所ごとに変わりますが、<b>垂直抗力はいつでも運動の向きに垂直</b>なので、' +
    'やはり仕事をしません。だから力学的エネルギーは保存され、<b>下端の速さは 1-3 とぴったり同じ</b>になります。' +
    'この図の運動は式では書けないので<b>数値計算</b>で動かしていますが、' +
    'エネルギーの<b>答えは式（$\\sqrt{2gh}$）から</b>出しています。'
};

/* ============ 1-6 振り子 ============ */
DEFS['m1-6'] = {
  id: 'm1-6', mode: 1, tab: '1-6 振り子',
  title: '1-6　振り子',
  sub: '糸の張力は<b>いつでも運動の向きに垂直</b>（円の中心を向く）なので仕事をしません。仕事をするのは重力だけ。' +
    'だから<b>最下点で $K$ が最大・最高点で $U$ が最大</b>になり、和の $E$ はずっと一定です。',
  /* 縮尺は 115 px ＝ 1 m に固定（ch = 108 + 115l なので、最下点の下の余白はいつも 54 px） */
  cw: 580,                 /* 第8回：各点に力の矢印も出すので、吹きだしの逃げ場を広げた */
  /* 第14回：最下点の下に「最下点（点C…B）」の吹きだしを置くぶん、54 px 高くした */
  ch: function (v) { return Math.round(186 + 105 * v.l); },
  vis: ['F', 'Fc', 'V', 'A'],
  mainVars: ['th', 'v0'],
  mainVarFocus: 'th',
  vars: [
    { k: 'th', label: 'はじめの角 $\\theta$', unit: '°', min: 10, max: 75, step: 5, dec: 0, def: 40 },
    { k: 'v0', label: 'はじめの速さ $v_0$', unit: ' m/s', min: 0, max: 3, step: 0.1, dec: 1, def: 0.0 },
    { k: 'l', label: '糸の長さ $l$', unit: ' m', min: 0.6, max: 1.6, step: 0.1, dec: 1, def: 1.0 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 5, step: 0.5, dec: 1, def: 1.0 }
  ],
  actions: [
    { label: '大きく振る（θ＝70°）', fn: function (s) { s.v.th = 70; },
      is: function (v) { return v.th === 70; },
      next: function (s) { return s._played && s.v.th !== 70; } },
    { label: '初速度をつける（v₀＝2 m/s）', fn: function (s) { s.v.v0 = 2; },
      is: function (v) { return Math.abs(v.v0 - 2) < 1e-9; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.th = 40; s.v.v0 = 0; },
      is: function (v) { return v.th === 40 && Math.abs(v.v0) < 1e-9; } }
  ],
  cons: true,
  forces: ['g', 'T'],
  hintFig: '<b>糸の張力は運動の向きに垂直 → 仕事をしない</b>。最下点で $K$ が最大、両はしで $U$ が最大',
  step1: '重力（保存力）だけが仕事をする。糸の張力は運動の向きに垂直なので仕事をしない',
  datum: '最下点',
  hint2: '<b>次は</b>：$\\theta$ を変えて、<b>最下点の速さ $v=\\sqrt{2gl(1-\\cos\\theta)}$</b> がどう変わるか確かめよう。',
  tEnd: function (v) { return P.m15.tEnd(v); },
  sample: function (v, t) { return P.m15.sample(v, t); },
  pts: [
    { name: 'A', jp: 'はじめの位置', t: function () { return 0; },
      sym: { K: '\\tfrac{1}{2}mv_0^{\\,2}', Ug: 'mgl(1-\\cos\\theta)' } },
    { name: 'B', jp: '最下点', t: function (v) { return P.m15.tBottom(v); },
      sym: { K: '\\tfrac{1}{2}mv^2', Ug: '0' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m1-6'], v = V(s), m = d.sample(v, t);
    var sc = 105, ox = W * 0.42, oy = 54, Lp = v.l * sc;
    var by = oy + Lp;                                   /* 最下点の高さ */
    function pos(th) { return { x: ox + Math.sin(th) * Lp, y: oy + Math.cos(th) * Lp }; }
    var o = P.m15.table(v), thT = o.thT;
    var kz = mSize(d, v), r = 10 * kz;

    /* 天井 */
    hatchLine(ctx, ox - 52, oy, ox + 52, oy, -1);
    /* 通る道すじ（うすい破線） */
    ctx.save();
    ctx.strokeStyle = '#c3cbd3'; ctx.lineWidth = 1.2; ctx.setLineDash([5, 5]);
    ctx.beginPath();
    ctx.arc(ox, oy, Lp, Math.PI / 2 - thT, Math.PI / 2 + thT);
    ctx.stroke();
    ctx.restore();
    datumLine(ctx, Math.max(16, ox - Lp - 20), W - 96, by, '基準面（最下点）h = 0', true, true);

    var pA = pos(v.th * DEG), pB = pos(0);
    /* 印はおもりの外がわ（支点から遠いほう）に置く。おもりが来てもかくれない */
    function outer(p2) {
      var dx = p2.x - ox, dy = p2.y - oy, L2 = Math.hypot(dx, dy) || 1;
      return { x: p2.x + dx / L2 * 30, y: p2.y + dy / L2 * 30 };
    }
    var mA = outer(pA), mB = outer(pB);
    ptMark(ctx, 'A', mA.x, mA.y);
    ptMark(ctx, 'B', mB.x, mB.y);
    /* ★いちばん低い所に「最下点（点B）」の吹きだし★（先生の指示・第14回）
       しっぽは上向き（箱は下）。運動が終わってから出す。 */
    if (endOn(d, s, t)) ptNote(ctx, pB.x, pB.y, '最下点', '（点B）', { below: true, gap: 62 });

    /* 角 θ */
    ctx.save();
    ctx.strokeStyle = '#c3cbd3'; ctx.lineWidth = 1.1; ctx.setLineDash([4, 4]);
    ctx.beginPath(); ctx.moveTo(ox, oy); ctx.lineTo(ox, by + 8); ctx.stroke();
    ctx.restore();
    var thNow = m.th;
    if (Math.abs(thNow) > 0.03) {
      var a1 = Math.PI / 2, a2 = Math.PI / 2 - thNow;
      var ar = Math.min(40, Lp * 0.42);          /* 糸が短いときは弧も小さくする */
      angArc(ctx, ox, oy, ar, Math.min(a1, a2), Math.max(a1, a2),
        'θ = ' + fmt(Math.abs(thNow) / DEG, 0) + '°', (a1 + a2) / 2, ar + 18);
    }

    /* 糸とおもり */
    var p = pos(thNow);
    string(ctx, ox, oy, p.x, p.y);
    /* ★式の $l$（糸の長さ）が図のどこかを見せる★（先生の指示・第12回）
       $U_g = mgl(1-\cos\theta)$ の $l$。糸のわきに、ふれている側へ少しずらして書く。 */
    var lsg = (thNow >= 0) ? 1 : -1;
    label(ctx, 'l = ' + fmt(v.l, 1) + ' m',
      ox + Math.sin(thNow) * Lp * 0.80 + Math.cos(thNow) * lsg * 24,
      oy + Math.cos(thNow) * Lp * 0.80 - Math.sin(thNow) * lsg * 24,
      { size: 11.5, color: COL.dim });
    ctx.save(); ctx.fillStyle = '#5b6672';
    ctx.beginPath(); ctx.arc(ox, oy, 3.4, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    ball(ctx, p.x, p.y, r);
    /* 高さの寸法は左はしに固定して、おもりまで引き出し線でつなぐ
       （おもりのそばに置くと、mg や θ の文字と必ずぶつかる） */
    /* 運動が終わったら、点ごとの高さ（drawPts）に任せてこの1本は消す */
    if (!endOn(d, s, t)) heightDim(ctx, 26, p.y, by, 'h = ' + fmt(m.h, 2) + ' m', p.x, true);

    var hA = (t <= 0.18) ? 1 : Math.max(0, 1 - (t - 0.18) / 0.22);
    if (hA > 0.02 && v.v0 < 0.05) dropHand(ctx, pA.x, pA.y, 0.52, clamp(t / 0.18, 0, 1), hA);

    /* 張力は最下点で mg(3−2cosθ_t) まで大きくなる。矢印が糸より長くならないように縮尺を決める */
    var mg = v.m * G, Tmax = mg * (3 - 2 * Math.cos(thT));
    var fs = Math.min(42 / mg, Lp * 0.72 / Tmax);
    var rx = (ox - p.x), ry = (oy - p.y), rl = Math.hypot(rx, ry) || 1;
    rx /= rl; ry /= rl;                                  /* おもり → 支点（張力の向き） */
    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    function fAt(qq, ax, ay, th2) {
      var r2x = (ox - ax), r2y = (oy - ay), r2l = Math.hypot(r2x, r2y) || 1;
      r2x /= r2l; r2y /= r2l;
      arrow(ctx, ax, ay, ax, ay + mg * fs, 'force');
      label(ctx, 'mg', ax, ay + mg * fs + 11, { size: 11.5, color: COL.force });
      var T = mg * Math.cos(th2) + v.m * qq.v * qq.v / v.l;     /* 張力（円運動の式） */
      arrow(ctx, ax, ay, ax + r2x * T * fs, ay + r2y * T * fs, 'force', 1, COL.hand);
      /* S の文字は「糸の、角 θ とは反対がわ」に置く（θ の文字とぶつからないように） */
      var sg2 = (th2 >= 0) ? 1 : -1;
      label(ctx, 'S', ax + r2x * T * fs - r2y * 13 * sg2, ay + r2y * T * fs + r2x * 13 * sg2,
        { size: 11.5, color: COL.hand });
    }
    if (s.o.showF) fAt(m, p.x, p.y, thNow);
    if (s.o.showFc) {
      var gt = mg * Math.sin(thNow), gr = mg * Math.cos(thNow);
      var tx2 = -ry, ty2 = rx;                            /* 接線の向き（円の接線） */
      arrow(ctx, p.x, p.y, p.x - tx2 * gt * fs, p.y - ty2 * gt * fs, 'comp');
      label(ctx, 'mg sinθ', p.x - tx2 * gt * fs, p.y - ty2 * gt * fs + 14, { size: 11, color: COL.force });
      arrow(ctx, p.x, p.y, p.x - rx * gr * fs, p.y - ry * gr * fs, 'comp');
      label(ctx, 'mg cosθ', p.x - rx * gr * fs + 4, p.y - ry * gr * fs + 12, { align: 'left', size: 11, color: COL.force });
    }
    var sg = m.om > 0 ? 1 : -1, vux = -ry * sg, vuy = rx * sg;   /* 進む向き（接線） */
    if (s.o.showV && m.v > 0.05) {
      /* ★物体から離して出す★ 糸と反対がわ（外向き）へ 26 px ずらしてから接線方向へ */
      var vl = vArrowLen(m.v, Math.max(0.5, P.m15.vBottom(v)), 54);
      var va = velArrow(ctx, p.x, p.y, -rx, -ry, 26, vux, vuy, vl);
      label(ctx, 'v', va.tx + vux * 10, va.ty + vuy * 10, { size: 11.5, color: COL.vel });
    }
    if (s.o.showA) {
      /* 加速度＝接線方向 −g sinθ ＋ 向心方向 v²/l */
      var at = -G * Math.sin(thNow), an = m.v * m.v / v.l;
      var ax = (-ry) * at + rx * an, ay = rx * at + ry * an;
      /* 真下は mg の矢印と字が通るので、進む向きと反対がわへ横にずらす */
      /* 下は mg と点の印、上はひもと S が通る。外がわの斜め上があいている */
      drawAcc(ctx, p.x, p.y, ax, ay,
        { nx: (rx >= 0 ? 1 : -1), ny: -0.55, off: 58, max: 56 });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    drawPts(ctx, d, s, t, function (pt) {
      var A = (pt.name === 'A');
      var pp = A ? pA : pB, mm = A ? mA : mB;
      /* その点での接線の向き（A は折り返しなので速度 0＝矢印は出ない） */
      var qq = d.sample(v, pt.t);
      var ex = pp.x - ox, ey = pp.y - oy, el = Math.hypot(ex, ey) || 1;
      var sg2 = qq.om > 0 ? 1 : -1;
      return { x: mm.x, y: mm.y, ox: pp.x, oy: pp.y, r: r,
        /* 時刻はちがっても場所が同じ（1周期でもどる）ときは、本物にまかせる */
        here: (Math.abs(pp.x - p.x) < 1.5 && Math.abs(pp.y - p.y) < 1.5),
        fdraw: function () { fAt(qq, pp.x, pp.y, qq.th); },
        vx: (ey / el) * sg2, vy: (-ex / el) * sg2, vref: Math.max(0.5, P.m15.vBottom(v)), vk: 54, voff: r + 12,
        base: by, hx: 26 };
    });
  },
  resItems: function (v) {
    return [{ k: '最下点の速さ（式）', v: fmt(P.m15.vBottom(v), 2) + ' m/s' }];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m1-6'].sample(v, t);
    return [
      ['いまの角 $\\theta$', fmt(m.th / DEG, 1) + '°'],
      ['折り返しの角', fmt(P.m15.thTurn(v) / DEG, 1) + '°'],
      ['最下点に来る時刻', fmt(P.m15.tBottom(v), 2) + ' s'],
      ['1往復の時間（周期）', fmt(P.m15.tEnd(v), 2) + ' s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return '\\tfrac{1}{2}mv_0^{\\,2} + mgl(1-\\cos\\theta) = \\tfrac{1}{2}mv^2 \\;\\Rightarrow\\; v = ' +
      fmt(P.m15.vBottom(v), 2) + '\\ \\mathrm{m/s}';
  },
  note: 'おもりにはたらく力は<b>重力と糸の張力</b>。張力はいつも円の中心を向いていて<b>運動の向きに垂直</b>' +
    'なので仕事をしません。だから力学的エネルギーは保存され、$v_0=0$ のときの最下点の速さは ' +
    '<b>$v=\\sqrt{2gl(1-\\cos\\theta)}$</b>。<b>最下点で K が最大・両はしで U が最大</b>になり、' +
    'E–t 図は水平のままです。'
};

/* ============ 1-7 ジェットコースター（★第5回で作り直し★） ============ */
DEFS['m1-7'] = {
  id: 'm1-7', mode: 1, tab: '1-7 ジェットコースター',
  title: '1-7　ジェットコースター（ループと斜面）',
  sub: 'なめらかな軌道。水平面を速さ $v_0$ で走ってきて、<b>鉛直な円（ループ）</b>を1周し、' +
    'そのあと斜面を昇って止まります（C）。<b>そこで終わりではありません。</b>' +
    'なめらかなので、そこから<b>もどってきて、ループをもう一度くぐり、' +
    'スタート地点 A に速さ $v_0$ で帰ってきます</b>。仕事をするのは<b>重力（保存力）だけ</b>' +
    '（垂直抗力はいつも運動の向きと垂直）。だから <b>$E = K + U$ は一定</b>です。',
  cw: 720, ch: 356,
  vis: ['F', 'V', 'A'],
  mainVars: ['v0', 'th'],
  mainVarFocus: 'th',
  vars: [
    { k: 'v0', label: 'はじめの速さ $v_0$', unit: ' m/s', min: 14, max: 16, step: 0.5, dec: 1, def: 14.0 },
    { k: 'th', label: '斜面の角 $\\theta$', unit: '°', min: 35, max: 60, step: 5, dec: 0, def: 35 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 100, max: 500, step: 100, dec: 0, def: 200 }
  ],
  /* 第9回：はじめの斜面の角を 35° にした（ゆるい斜面のほうが図が広く使える） */
  actions: [
    { label: '斜面を急にする（θ＝60°）', fn: function (s) { s.v.th = 60; },
      is: function (v) { return v.th === 60; },
      next: function (s) { return s._played && s.v.th !== 60; } },
    { label: '速くする（v₀＝16 m/s）', fn: function (s) { s.v.v0 = 16; },
      is: function (v) { return Math.abs(v.v0 - 16) < 1e-9; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.th = 35; s.v.v0 = 14; },
      is: function (v) { return v.th === 35 && Math.abs(v.v0 - 14) < 1e-9; } }
  ],
  cons: true,
  forces: ['g', 'N'],
  hintFig: '<b>止まる高さ $h_C = v_0^{\\,2}/(2g)$ は、斜面の角 $\\theta$ を変えても同じ</b>',
  step1: '重力（保存力）だけが仕事をする。垂直抗力はいつも運動の向きと垂直',
  datum: '水平面（レールの高さ）',
  hint2: '<b>次は</b>：$\\theta$ を変えて、<b>止まる高さが変わらない</b>ことを確かめよう。' +
    '$v_0$ を変えると高さはどう変わる？',
  ptSide: 'row',
  tEnd: function (v) { return P.coaster.tEnd(v); },
  sample: function (v, t) { return P.coaster.sample(v, t); },
  pts: [
    { name: 'A', jp: 'スタート（水平面）', t: function () { return 0; },
      sym: { K: '\\tfrac{1}{2}mv_0^{\\,2}', Ug: '0' } },
    { name: 'B', jp: 'ループの頂上', t: function (v) { return P.coaster.tB(v); },
      hsym: 'D',                       /* ★式と図で同じ記号を使う★（第12回） */
      sym: { K: '\\tfrac{1}{2}mv_B^{\\,2}', Ug: 'mgD' } },
    { name: 'C', jp: '止まる所（最高点）', t: function (v) { return P.coaster.tTop(v); },
      hsym: 'h_C',
      sym: { K: '0', Ug: 'mgh_C' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m1-7'], v = V(s), m = d.sample(v, t);
    /* ★縮尺は固定★ 自動にすると θ で絵の大きさが変わって
       「止まる高さは θ によらない」ことが伝わらない */
    var SC = SC_COAST, gy = H - 56 - PTBAND, x0 = 95, R = P.coaster.R(), L1 = P.coaster.L1, L2 = P.coaster.L2;
    function X(x) { return x0 + x * SC; }
    function Y(y) { return gy - y * SC; }
    var th = v.th * DEG, hC = P.coaster.hC(v), run = P.coaster.runC(v);

    /* レール（水平面 → ループ → 水平面 → 斜面） */
    ctx.save();
    ctx.strokeStyle = '#6b7683'; ctx.lineWidth = 3.2; ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(X(0), Y(0));
    /* 床 → 斜面のつけ根のまるみ → 斜面（経路の at() をそのままなぞる） */
    var sF = L1 + P.coaster.loopLen() + L2, sMaxDraw = P.coaster.sEnd(v) * 1.05, iq;
    ctx.lineTo(X(L1 + L2), Y(0));
    for (iq = 1; iq <= 60; iq++) {
      var pq = P.coaster.at(sF + (sMaxDraw - sF) * iq / 60, v.th);
      ctx.lineTo(X(pq.x), Y(pq.y));
    }
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(X(L1), Y(R), R * SC, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
    /* 地面 */
    ground(ctx, 20, W - 96, gy + 4);
    /* ★吹きだしの帯（地面の下）に文字を置かない★ 基準面の文字は線の上・右のはしに出す（第6回）
       左のはしだと、高さの寸法線と A の印がならぶところにぶつかる。 */
    datumLine(ctx, 20, W - 96, gy, '基準面 h = 0', true, false);

    /* ループの直径は、円の「まん中」に書く（左に置くと高さの寸法線とぶつかる） */
    /* 第12回：点 B の高さの寸法も「D = …」と出るので、こちらは「直径」と書き分ける */
    label(ctx, '直径 D = ' + fmt(P.coaster.D, 1) + ' m', X(L1), Y(R), { size: 11.5, color: COL.sub });

    var kz = mSize(d, v), cw2 = 26 * kz, chh = 18 * kz;
    var qC = P.coaster.at(P.coaster.sEnd(v), v.th);
    var pA = { x: X(0), y: Y(0) }, pB = { x: X(L1), y: Y(2 * R) };
    var pC = { x: X(qC.x), y: Y(qC.y) };
    /* ★印は車と矢印からずらす★（第6回）
       A は車の左、B はループの頂上の左（真上は速度ベクトルが通る）、
       C は斜面の「下がわ」（上がわは車と N の矢印） */
    ptMark(ctx, 'A', pA.x - cw2 / 2 - 13, pA.y - chh / 2);
    ptMark(ctx, 'B', pB.x - 34, pB.y - 4);
    ptMark(ctx, 'C', pC.x + Math.sin(th) * 18, pC.y + Math.cos(th) * 18);
    /* ★いちばん高い所に「最高点（点C）」の吹きだし★（先生の指示・第14回） */
    if (endOn(d, s, t)) ptNote(ctx, pC.x, pC.y, '最高点', '（点C）', { gap: 46 });

    /* 車（軌道の内がわに乗る） */
    var carAng = (m.seg === 1 || m.seg === 3) ? m.ang : (m.seg === 4 ? th : 0);
    /* 軌道から内向き（画面の向き）。ループの中では上下がひっくり返る */
    var nx = -Math.sin(carAng), ny = -Math.cos(carAng);
    var cx = X(m.x) + nx * chh / 2, cy = Y(m.y) + ny * chh / 2;
    coasterCar(ctx, cx, cy, carAng, kz);
    /* ★スタートはデコピン★（第9回・先生の指示）走ってきたのではなく、はじいて動き出す */
    flickStart(ctx, t, v.v0, X(0) - cw2 / 2 - 44, Y(0) - chh / 2, 0, 74);
    if (!endOn(d, s, t)) heightDim(ctx, 20, Y(m.y), gy, 'h = ' + fmt(m.h, 2) + ' m', cx, true);

    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 30 / mg, N = P.coaster.Nof(v, m);
    function fAt(qq, sx, sy, ang3) {
      var n3x = -Math.sin(ang3), n3y = -Math.cos(ang3);
      var ax = sx + n3x * chh / 2, ay = sy + n3y * chh / 2;
      arrow(ctx, ax, ay, ax, ay + mg * fs, 'force');
      label(ctx, 'mg', ax, ay + mg * fs + 11, { size: 11.5, color: COL.force });
      var nl = clamp(P.coaster.Nof(v, qq) * fs, 6, 74);
      arrow(ctx, sx, sy, sx + n3x * nl, sy + n3y * nl, 'force', 1, COL.norm);
      label(ctx, 'N', sx + n3x * (nl + 12), sy + n3y * (nl + 12),
        { size: 11.5, color: COL.norm });
    }
    if (s.o.showF) fAt(m, X(m.x), Y(m.y), carAng);
    if (s.o.showV && m.v > 0.05) {
      /* ★物体から離して出す★（軌道の内向きに 30 px ずらしてから進む向きへ） */
      var ux = Math.cos(carAng), uy = -Math.sin(carAng);
      if (m.back) { ux = -ux; uy = -uy; }        /* 帰り道は進む向きが逆（第18回） */
      var vl = vArrowLen(m.v, 16, 46);
      var va = velArrow(ctx, cx, cy, nx, ny, 30, ux, uy, vl);
      label(ctx, 'v', va.tx + ux * 10, va.ty + uy * 10, { size: 11.5, color: COL.vel });
    }
    if (s.o.showA) {
      /* 軌道にそった加速度（重力の接線成分）。ループの上は向心加速度も大きいが、
         ここでは「速さの変わり方」を見せたいので接線成分だけを描く */
      var at = -G * m.dyds;
      drawAcc(ctx, cx, cy, Math.cos(carAng) * at, -Math.sin(carAng) * at,
        { nx: -nx, ny: -ny, off: 46, max: 58 });
    }
    if (hintOn(s, t)) {
      ctx.save();
      ctx.strokeStyle = fade(COL.dim, 0.55); ctx.lineWidth = 1.2; ctx.setLineDash([5, 4]);
      ctx.beginPath(); ctx.moveTo(X(L1), Y(hC)); ctx.lineTo(pC.x + 14, Y(hC)); ctx.stroke();
      ctx.restore();
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    ptRow(gy + 30);                   /* 吹きだしは地面の下に1列でならべる */
    drawPts(ctx, d, s, t, function (p, mm, i2) {
      var q = (p.name === 'A') ? pA : (p.name === 'B' ? pB : pC);
      var nx2 = 0, ny2 = -1, ang2 = 0;
      if (p.name === 'B') { nx2 = 0; ny2 = 1; ang2 = Math.PI; }
      if (p.name === 'C') { ang2 = qC.ang; nx2 = -Math.sin(ang2); ny2 = -Math.cos(ang2); }
      var ux2 = Math.cos(ang2), uy2 = -Math.sin(ang2);
      /* 引き出し先は「印を置いた所」。高いほうの寸法線を外（左）にして、線どうしを離す */
      var mk = (p.name === 'A') ? { x: q.x - cw2 / 2 - 13, y: q.y - chh / 2 }
        : (p.name === 'B' ? { x: q.x - 34, y: q.y - 4 }
        : { x: q.x + Math.sin(th) * 18, y: q.y + Math.cos(th) * 18 });
      return { x: mk.x, y: mk.y, ox: q.x + nx2 * chh / 2, oy: q.y + ny2 * chh / 2,
        fdraw: function () { fAt(d.sample(v, p.t), q.x, q.y, (p.name === 'B') ? Math.PI : ang2); },
        bw: cw2, bh: chh, ang: (p.name === 'B') ? 0 : ang2,
        vx: (p.name === 'B') ? -1 : ux2, vy: (p.name === 'B') ? 0 : uy2,
        vref: 16, vk: 46, voff: 26, base: gy, hx: 20 + (2 - i2) * 26 };
    });
  },
  resItems: function (v) {
    return [
      { k: 'ループの頂上の速さ（式 $\\sqrt{v_0^2-2gD}$）', v: fmt(P.coaster.vB(v), 2) + ' m/s' },
      { k: '止まる高さ（式 $v_0^{\\,2}/2g$）', v: fmt(P.coaster.hC(v), 2) + ' m' },
      { k: '1周できる最低の速さ（頂上で $\\sqrt{gR}$）', v: fmt(Math.sqrt(G * P.coaster.R()), 2) + ' m/s' }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m1-7'].sample(v, t);
    return [
      ['進んだ道のり $s$', fmt(m.s, 2) + ' m'],
      ['垂直抗力 $N$', fmt(P.coaster.Nof(v, m), 0) + ' N'],
      ['ループの頂上の時刻', fmt(P.coaster.tB(v), 2) + ' s'],
      ['最高点で止まる時刻', fmt(P.coaster.tTop(v), 2) + ' s'],
      ['スタート地点にもどる時刻', fmt(P.coaster.tEnd(v), 2) + ' s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return '\\tfrac{1}{2}mv_0^{\\,2} = mgh_C \\;\\Rightarrow\\; h_C = \\dfrac{v_0^{\\,2}}{2g} = ' +
      fmt(P.coaster.hC(v), 2) + '\\ \\mathrm{m}';
  },
  note: 'なめらかな軌道では、仕事をするのは<b>重力だけ</b>です（垂直抗力はいつも運動の向きと垂直）。' +
    'だから <b>$E = K + U$ はどこでも同じ</b>。ループの頂上は高さ $D$ なので ' +
    '$\\tfrac12mv_B^{\\,2} = \\tfrac12mv_0^{\\,2} - mgD$、' +
    '止まる高さは <b>$h_C = v_0^{\\,2}/(2g)$</b> で、<b>斜面の角によりません</b>。' +
    'ループを1周するには、頂上で $v_B^{\\,2} \\ge gR$ が必要です。'
};

/* ============ 1-8 斜方投射 ============ */
DEFS['m1-8'] = {
  id: 'm1-8', mode: 1, tab: '1-8 斜方投射',
  title: '1-8　斜方投射',
  sub: '高さ $h$ の点から、水平と角 $\\theta$ をなす向きに速さ $v_0$ で投げ出します。' +
    '空気の抵抗を考えなければ<b>仕事をするのは重力だけ</b>なので、力学的エネルギーは保存されます。' +
    '<b>最高点でも速さは 0 になりません</b>（水平方向の速さが残る）。',
  cw: 690, ch: 386,        /* 第6回：吹きだし3つを地面の下に1列でならべる幅 */
  vis: ['F', 'V', 'A'],
  mainVars: ['th', 'v0'],
  mainVarFocus: 'th',
  vars: [
    { k: 'th', label: '投げ出す角 $\\theta$', unit: '°', min: 15, max: 75, step: 5, dec: 0, def: 45 },
    { k: 'v0', label: 'はじめの速さ $v_0$', unit: ' m/s', min: 5, max: 14, step: 0.5, dec: 1, def: 9.0 },
    { k: 'h', label: '投げ出す高さ $h$', unit: ' m', min: 0, max: 6, step: 0.5, dec: 1, def: 2.0 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 5, step: 0.5, dec: 1, def: 1.0 }
  ],
  actions: [
    { label: '真上に近く（θ＝75°）', fn: function (s) { s.v.th = 75; },
      is: function (v) { return v.th === 75; },
      next: function (s) { return s._played && s.v.th !== 75; } },
    { label: '低く投げる（θ＝15°）', fn: function (s) { s.v.th = 15; },
      is: function (v) { return v.th === 15; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.th = 45; s.v.v0 = 9; s.v.h = 2; },
      is: function (v) { return v.th === 45 && Math.abs(v.v0 - 9) < 1e-9 && Math.abs(v.h - 2) < 1e-9; } }
  ],
  ptSide: 'row',
  cons: true,
  forces: ['g'],
  hintFig: '<b>最高点でも $K$ は 0 にならない</b>（水平方向の速さ $v_0\\cos\\theta$ が残る）',
  step1: '重力（保存力）だけが仕事をしている',
  datum: '地面',
  hint2: '<b>次は</b>：$\\theta$ を変えても、<b>着地の速さ</b>が変わらないことを確かめよう（$E$ が同じだから）。',
  tEnd: function (v) { return P.m17.tEnd(v); },
  sample: function (v, t) { return P.m17.sample(v, t); },
  pts: [
    { name: 'A', jp: '投げ出す点', t: function () { return 0; },
      hsym: 'h',                       /* ★式と図で同じ記号を使う★（第12回） */
      sym: { K: '\\tfrac{1}{2}mv_0^{\\,2}', Ug: 'mgh' } },
    { name: 'B', jp: '最高点', t: function (v) { return P.m17.tTop(v); },
      hsym: 'h_B',
      sym: { K: '\\tfrac{1}{2}m(v_0\\cos\\theta)^2', Ug: 'mgh_B' } },
    { name: 'C', jp: '着地', t: function (v) { return P.m17.tEnd(v); },
      sym: { K: '\\tfrac{1}{2}mv^2', Ug: '0' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m1-8'], v = V(s), m = d.sample(v, t);
    var T = P.m17.tEnd(v), xEnd = P.m17.vx(v) * T, yTop = P.m17.yTop(v);
    /* 第9回：右の余白が大きかったので上限を上げた。横は「台の左はし x0 = 118」から
       「地面の右はし W - 96」までに着地点が入るように、W - 232 で見る。 */
    var sc = Math.min(46, (W - 232) / Math.max(xEnd, 1), (H - 116) / Math.max(yTop, 1));
    var gy = H - 46 - PTBAND, x0 = 118;   /* 第6回：左に高さの寸法線を2本置くので、台を右へ */
    function X(x) { return x0 + x * sc; }
    function Y(y) { return gy - y * sc; }
    var i;

    ground(ctx, 20, W - 96, gy);
    /* 第9回：図を大きくして着地点が右はしに来たので、基準面の文字は左の下に置く
       （右上のままだと、着地の玉・v の矢印とぶつかる） */
    datumLine(ctx, 20, W - 96, gy, '基準面 h = 0', false, true);
    /* 投げ出す台 */
    if (v.h > 0.05) {
      ctx.save();
      ctx.fillStyle = '#eef1f4'; ctx.strokeStyle = '#98a0a8'; ctx.lineWidth = 1.4;
      ctx.beginPath(); ctx.rect(X(0) - 26, Y(v.h), 52, gy - Y(v.h)); ctx.fill(); ctx.stroke();
      ctx.restore();
      /* 運動が終わったら、点ごとの高さ（drawPts）に任せてこの1本は消す */
      if (!endOn(d, s, t)) heightDim(ctx, 26, Y(v.h), gy, 'h = ' + fmt(v.h, 1) + ' m', X(0) - 26, true);
    }
    /* 道すじ */
    ctx.save();
    ctx.strokeStyle = '#c3cbd3'; ctx.lineWidth = 1.2; ctx.setLineDash([5, 5]);
    ctx.beginPath();
    for (i = 0; i <= 90; i++) {
      var q = d.sample(v, T * i / 90);
      if (i === 0) ctx.moveTo(X(q.x), Y(q.y)); else ctx.lineTo(X(q.x), Y(q.y));
    }
    ctx.stroke(); ctx.restore();

    var mB = d.sample(v, P.m17.tTop(v)), mC = d.sample(v, T);
    /* ★いちばん高い所に「最高点」の吹きだし★（先生の指示・第13回）しっぽは下 */
    if (endOn(d, s, t)) ptNote(ctx, X(mB.x), Y(mB.y), '最高点', '（点B）', { gap: 52 });
    /* ★印は球と矢印からずらす★（第6回）A は台の上・球の右下、C は着地点の右下 */
    ptMark(ctx, 'A', X(0) + 20, Y(v.h) + 18);
    ptMark(ctx, 'B', X(mB.x), Y(mB.y) - 13);
    ptMark(ctx, 'C', X(mC.x) + 22, Y(0) + 16);

    var kz = mSize(d, v), r = 8 * kz;
    for (i = 1; i * 0.12 < t - 1e-9; i++) {
      var q2 = d.sample(v, i * 0.12);
      ball(ctx, X(q2.x), Y(q2.y), r, 'faint');
    }
    var px = X(m.x), py = Y(m.y);
    ball(ctx, px, py, r);

    /* 投げ出す角 */
    var av = -v.th * DEG;
    ctx.save();
    ctx.strokeStyle = '#c3cbd3'; ctx.lineWidth = 1.1; ctx.setLineDash([4, 4]);
    ctx.beginPath(); ctx.moveTo(X(0), Y(v.h)); ctx.lineTo(X(0) + 62, Y(v.h)); ctx.stroke();
    ctx.restore();
    angArc(ctx, X(0), Y(v.h), 30, av, 0, 'θ = ' + fmt(v.th, 0) + '°', av / 2, 60);

    /* ★スタートはデコピン★（手をはなすのではなく、はじいて投げ出す） */
    /* 第9回：図を大きくしたので、θ が大きいと吹きだしが「最高点 B」の印とぶつかる。
       吹きだしだけ右へ寄せる（手の位置はそのまま）。 */
    flickStart(ctx, t, v.v0, X(0) - Math.cos(av) * 24, Y(v.h) - Math.sin(av) * 24, av, 74);

    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 34 / mg;
    function fAt(ax, ay) {
      arrow(ctx, ax, ay, ax, ay + mg * fs, 'force');
      label(ctx, 'mg', ax, ay + mg * fs + 11, { size: 11.5, color: COL.force });
    }
    if (s.o.showF) fAt(px, py);
    if (s.o.showV && m.v > 0.05) {
      /* ★物体から離して出す★ 進む向きと垂直に 22 px ずらしてから */
      var vl = vArrowLen(m.v, Math.max(1, P.m17.vEnd(v)), 50);
      var ux = m.vx / m.v, uy = -m.vy / m.v;
      var va = velArrow(ctx, px, py, -uy, ux, 22, ux, uy, vl);
      label(ctx, 'v', va.tx + ux * 10, va.ty + uy * 10, { size: 11.5, color: COL.vel });
    }
    if (s.o.showA) {
      /* 速度は進む向きの片がわに出しているので、加速度は反対がわへ出す */
      var uax = (m.v > 0.02) ? m.vx / m.v : 1, uay = (m.v > 0.02) ? -m.vy / m.v : 0;
      drawAcc(ctx, px, py, 0, G, { nx: uay, ny: -uax, off: 36 });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    ptRow(gy + 50);                   /* 吹きだしは地面の下に1列。着地点の mg の字より下に置く */
    drawPts(ctx, d, s, t, function (p, mm, i2) {
      var q = d.sample(v, p.t), sp = { x: X(q.x), y: Y(q.y) };
      var uq = q.v > 0.02 ? { x: q.vx / q.v, y: -q.vy / q.v } : { x: 1, y: 0 };
      var mk = (p.name === 'A') ? { x: X(0) + 20, y: Y(v.h) + 18 }
        : (p.name === 'B' ? { x: X(mB.x), y: Y(mB.y) - 13 } : { x: X(mC.x) + 22, y: Y(0) + 16 });
      return { x: mk.x, y: mk.y, ox: sp.x, oy: sp.y, r: r,
        fdraw: function () { fAt(sp.x, sp.y); },
        vx: uq.x, vy: uq.y, vref: Math.max(1, P.m17.vEnd(v)), vk: 50, voff: r + 12,
        /* 高さの寸法線：B（最高点）は数値を線の上に出して、A の数値とぶつけない */
        base: gy, hx: 24 + i2 * 32, hside: (i2 === 1) ? true : 0 };
    });
  },
  resItems: function (v) {
    return [
      { k: '最高点の高さ', v: fmt(P.m17.yTop(v), 2) + ' m' },
      { k: '最高点の速さ（＝$v_0\\cos\\theta$）', v: fmt(P.m17.vTop(v), 2) + ' m/s' },
      { k: '着地の速さ（式）', v: fmt(P.m17.vEnd(v), 2) + ' m/s' }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m1-8'].sample(v, t);
    return [
      ['水平の位置 $x$', fmt(m.x, 2) + ' m'],
      ['高さ $y$', fmt(m.y, 2) + ' m'],
      ['最高点に来る時刻', fmt(P.m17.tTop(v), 2) + ' s'],
      ['着地する時刻', fmt(P.m17.tEnd(v), 2) + ' s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return '\\tfrac{1}{2}mv_0^{\\,2} + mgh = \\tfrac{1}{2}mv^2 \\;\\Rightarrow\\; v = \\sqrt{v_0^{\\,2}+2gh} = ' +
      fmt(P.m17.vEnd(v), 2) + '\\ \\mathrm{m/s}';
  },
  note: '投げ出したあと仕事をするのは<b>重力だけ</b>なので、力学的エネルギーは保存されます。' +
    '<b>最高点（B）でも運動エネルギーは 0 になりません</b>——上下の速さが 0 になるだけで、' +
    '水平方向の $v_0\\cos\\theta$ は残るからです。着地（C）の速さは <b>$\\sqrt{v_0^{\\,2}+2gh}$</b> で、' +
    '<b>投げ出す角によりません</b>（$E$ が同じだから）。'
};

/* ============ 1-9 水平ばね（単振動） ============ */
DEFS['m1-9'] = {
  id: 'm1-9', mode: 1, tab: '1-9 水平ばね',
  title: '1-9　水平ばね（単振動）',
  sub: 'なめらかな水平面。ばねを $x_0$ だけ伸ばして手をはなします。重力と垂直抗力は仕事をせず、' +
    '仕事をするのは<b>ばねの弾性力（保存力）</b>だけ。だから ' +
    '<b>$K + U_k = \\tfrac12mv^2 + \\tfrac12kx^2$ が一定</b>に保たれます。',
  cw: 520, ch: 250,
  vis: ['F', 'V', 'A'],
  hasUs: true,
  mainVars: ['x0', 'k'],
  mainVarFocus: 'x0',
  vars: [
    { k: 'x0', label: 'はじめの伸び $x_0$', unit: ' m', min: 0.1, max: 0.4, step: 0.02, dec: 2, def: 0.30 },
    { k: 'k', label: 'ばね定数 $k$', unit: ' N/m', min: 20, max: 100, step: 5, dec: 0, def: 40 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 4, step: 0.5, dec: 1, def: 1.0 }
  ],
  actions: [
    { label: 'かたいばね（k＝80）', fn: function (s) { s.v.k = 80; },
      is: function (v) { return v.k === 80; },
      next: function (s) { return s._played && s.v.k !== 80; } },
    { label: '大きく伸ばす（x₀＝0.40 m）', fn: function (s) { s.v.x0 = 0.4; },
      is: function (v) { return Math.abs(v.x0 - 0.4) < 1e-9; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.x0 = 0.3; s.v.k = 40; },
      is: function (v) { return Math.abs(v.x0 - 0.3) < 1e-9 && v.k === 40; } }
  ],
  cons: true,
  forces: ['g', 'N', 'sp'],
  hintFig: '<b>弾性力による位置エネルギー $U_k$ が減った分だけ $K$ が増える</b>（$U_g$ は 0 のまま）',
  step1: 'ばねの弾性力（保存力）だけが仕事をする。重力と垂直抗力は運動の向きに垂直',
  datum: '床（高さは変わらないので $U_g = 0$）',
  hint2: '<b>次は</b>：$k$ を変えて、<b>自然長を通るときの速さ</b> $v=x_0\\sqrt{k/m}$ がどう変わるか見てみよう。',
  slow: true,                /* ★はじめからスロー再生★（第8回・ばねのシム） */
  tEnd: function (v) { return P.m18.tEnd(v); },
  sample: function (v, t) { return P.m18.sample(v, t); },
  pts: [
    { name: 'A', jp: 'スタート（いちばん伸びた所）', t: function () { return 0; },
      sym: { K: '0', Ug: '0', Us: '\\tfrac{1}{2}kx_0^{\\,2}' } },
    { name: 'B', jp: '自然長の位置', t: function (v) { return P.m18.tEnd(v); },
      sym: { K: '\\tfrac{1}{2}mv^2', Ug: '0', Us: '0' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m1-9'], v = V(s), m = d.sample(v, t);
    var sc = 230, gy = H - 58, wallX = 40, natX = wallX + 150;
    function X(x) { return natX + x * sc; }
    var kz = mSize(d, v), bw = 34 * kz, bh = 26 * kz;

    ground(ctx, 20, W - 96, gy);
    datumLine(ctx, 20, W - 96, gy, '基準面 h = 0', true, true);
    /* 壁 */
    ctx.save();
    ctx.fillStyle = '#d7dde4'; ctx.fillRect(wallX - 14, gy - 96, 14, 96);
    ctx.strokeStyle = '#8b949e'; ctx.lineWidth = 1.4; ctx.strokeRect(wallX - 14, gy - 96, 14, 96);
    ctx.restore();
    /* 自然長の位置 */
    ctx.save();
    ctx.strokeStyle = '#9aa3ac'; ctx.lineWidth = 1.2; ctx.setLineDash([5, 4]);
    ctx.beginPath(); ctx.moveTo(natX, gy - 100); ctx.lineTo(natX, gy + 4); ctx.stroke();
    ctx.restore();
    label(ctx, '自然長', natX, gy - 108, { size: 11, color: COL.sub });

    var cx = X(m.x), cy = gy - bh / 2;
    spring(ctx, wallX, cy, cx - bw / 2, cy, { coils: 10, r: 11, color: COL.hand, lw: 2 });
    /* ★式の $x_0$（はじめの伸び）が図のどこかを見せる★（先生の指示・第12回）
       $U_k = \tfrac12kx_0^2$ の $x_0$。自然長の線から A（スタート）までの長さ。 */
    if (X(v.x0) - natX > 8) {
      var y0d = gy - bh - 40;
      arrow(ctx, natX, y0d, X(v.x0), y0d, 'dim');
      arrow(ctx, X(v.x0), y0d, natX, y0d, 'dim');
      label(ctx, 'x_0 = ' + fmt(v.x0, 2) + ' m', (natX + X(v.x0)) / 2, y0d - 11,
        { size: 11, color: COL.dim });
    }
    ptMark(ctx, 'A', X(v.x0) + bw / 2 + 13, gy - bh / 2);
    /* ★B は「自然長」の点線の上★（第9回・先生の指示）
       物体とは重ならない高さ（物体の上 30 px ほど）に置く。 */
    var bMarkY = gy - bh - 16;
    ptMark(ctx, 'B', natX, bMarkY);
    blockShape(ctx, cx, cy, 0, bw, bh, '#e8eef5');
    /* 伸びの寸法 */
    if (Math.abs(m.x) > 0.005) {
      arrow(ctx, natX, gy + 16, cx, gy + 16, 'dim');
      label(ctx, 'x = ' + fmt(m.x, 2) + ' m', (natX + cx) / 2, gy + 30, { size: 11, color: COL.dim });
    }
    var hA = (t <= 0.16) ? 1 : Math.max(0, 1 - (t - 0.16) / 0.20);
    if (hA > 0.02) dropHand(ctx, X(v.x0) + bw / 2 + 6, cy, 0.5, clamp(t / 0.16, 0, 1), hA);

    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 30 / mg;
    function fAt(qq, ax) {
      arrow(ctx, ax, cy, ax, cy + mg * fs, 'force');
      label(ctx, 'mg', ax, cy + mg * fs + 11, { size: 11.5, color: COL.force });
      arrow(ctx, ax, gy, ax, gy - mg * fs, 'force', 1, COL.norm);
      label(ctx, 'N', ax + bw / 2 + 8, gy - mg * fs + 4, { align: 'left', size: 11.5, color: COL.norm });
      var F = -v.k * qq.x, fl = clamp(F * fs * 0.55, -70, 70);
      if (Math.abs(fl) > 3) {
        arrow(ctx, ax - bw / 2, cy, ax - bw / 2 + fl, cy, 'force', 1, COL.hand);
        label(ctx, '弾性力 kx', ax - bw / 2 + fl / 2, cy - 14, { size: 11, color: COL.hand });
      }
    }
    if (s.o.showF) fAt(m, cx);
    if (s.o.showV && Math.abs(m.v) > 0.05) {
      /* ★物体から離して出す★（ブロックの上 40 px） */
      var sgv = (m.vs > 0 ? 1 : -1), vl = vArrowLen(m.v, Math.max(0.3, P.m18.vMax(v)), 48);
      var va = velArrow(ctx, cx, cy, 0, -1, bh / 2 + 40, sgv, 0, vl);
      label(ctx, 'v', va.tx + sgv * 10, va.ty, { size: 11.5, color: COL.vel });
    }
    if (s.o.showA) drawAcc(ctx, cx, cy, -v.k * m.x / v.m, 0, { nx: 0, ny: -1, off: bh / 2 + 76 });
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    drawPts(ctx, d, s, t, function (p) {
      var A = (p.name === 'A');
      var q = d.sample(v, p.t);
      /* 吹きだしは、物体の横に置いた印から引き出す */
      return { x: (A ? X(v.x0) + bw / 2 + 13 : natX), y: (A ? gy - bh / 2 : bMarkY),
        ox: A ? X(v.x0) : natX, oy: gy - bh / 2, bw: bw, bh: bh,
        fdraw: function () { fAt(q, A ? X(v.x0) : natX); },
        /* 終わりに物体がその点と同じ場所にいるときは、ゴーストを描かない */
        here: Math.abs(m.x - (A ? v.x0 : 0)) < 0.004,
        vx: (q.vs >= 0 ? 1 : -1), vy: 0, vref: Math.max(0.3, P.m18.vMax(v)), vk: 48, voff: bw / 2 + 10 };
    });
  },
  resItems: function (v) {
    return [
      { k: '自然長を通る速さ（式 $x_0\\sqrt{k/m}$）', v: fmt(P.m18.vMax(v), 2) + ' m/s' },
      { k: '1往復の時間（周期）', v: fmt(P.m18.period(v), 2) + ' s' }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m1-9'].sample(v, t);
    return [
      ['ばねの伸び $x$', fmt(m.x, 3) + ' m'],
      ['弾性力 $kx$', fmt(v.k * Math.abs(m.x), 1) + ' N'],
      ['自然長に来る時刻', fmt(P.m18.tNat(v), 2) + ' s'],
      ['1往復の時間（周期）', fmt(P.m18.period(v), 2) + ' s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return '\\tfrac{1}{2}kx_0^{\\,2} = \\tfrac{1}{2}mv^2 \\;\\Rightarrow\\; v = x_0\\sqrt{\\dfrac{k}{m}} = ' +
      fmt(P.m18.vMax(v), 2) + '\\ \\mathrm{m/s}';
  },
  note: 'ばねの弾性力は<b>保存力</b>で、その位置エネルギーが<b>弾性力による位置エネルギー $U_k=\\tfrac12kx^2$</b> です。' +
    '高さが変わらないので $U_g = 0$、つまり <b>$E = K + U_k$</b>。' +
    'いちばん伸びた所で $K=0$・$U_k$ が最大、<b>自然長の位置で $U_k=0$・$K$ が最大</b>になり、' +
    'その和はずっと一定です。'
};


/* ============ 1-10 水平ばねにぶつかる（★第5回・新規★） ============ */
DEFS['m1-10'] = {
  id: 'm1-10', mode: 1, tab: '1-10 水平ばねにぶつかる',
  title: '1-10　水平ばねにぶつかる',
  sub: 'なめらかな水平面を速さ $v_0$ で走ってきて、壁につけたばねにぶつかります。' +
    'ぶつかるまでは<b>重力も垂直抗力も仕事をしない</b>ので速さは変わりません（A → B）。' +
    'ぶつかってからは<b>弾性力（保存力）</b>だけが仕事をするので、' +
    '<b>$\\tfrac12mv_0^{\\,2} = \\tfrac12kx^2$</b> から縮み $x$ が求まります。',
  cw: 720, ch: 386,
  vis: ['F', 'V', 'A'],
  hasUs: true,
  mainVars: ['v0', 'k'],
  mainVarFocus: 'k',
  vars: [
    /* ★第11回：既定でもっとばねが縮むように★（先生の指示）
       縮み x = v0√(m/k)。v0 = 4 → 5、k = 200 → 100 にして 0.28 m → 0.50 m（約1.8倍）。 */
    { k: 'v0', label: 'はじめの速さ $v_0$', unit: ' m/s', min: 2, max: 5, step: 0.5, dec: 1, def: 5.0 },
    { k: 'k', label: 'ばね定数 $k$', unit: ' N/m', min: 100, max: 400, step: 50, dec: 0, def: 100 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 2, step: 0.5, dec: 1, def: 1.0 }
  ],
  actions: [
    { label: 'かたいばね（k＝400）', fn: function (s) { s.v.k = 400; },
      is: function (v) { return v.k === 400; },
      next: function (s) { return s._played && s.v.k !== 400; } },
    { label: 'ゆっくりぶつける（v₀＝2.5 m/s）', fn: function (s) { s.v.v0 = 2.5; },
      is: function (v) { return Math.abs(v.v0 - 2.5) < 1e-9; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.v0 = 5; s.v.k = 100; },
      is: function (v) { return Math.abs(v.v0 - 5) < 1e-9 && v.k === 100; } }
  ],
  cons: true,
  forces: ['g', 'N', 'sp'],
  hintFig: '<b>ばねが受けとった $\\tfrac12kx^2$ は、はじめの $\\tfrac12mv_0^{\\,2}$ とぴったり同じ</b>',
  step1: 'ばねの弾性力（保存力）だけが仕事をする。重力と垂直抗力は運動の向きに垂直',
  datum: '水平面（高さは変わらないので $U_g = 0$）',
  hint2: '<b>次は</b>：$k$ を変えて、<b>いちばん縮んだ長さ</b> $x=v_0\\sqrt{m/k}$ がどう変わるか見てみよう。',
  ptSide: 'row',
  slow: true,                /* ★はじめからスロー再生★（第8回・ばねのシム） */
  tEnd: function (v) { return P.hitSpring.tEnd(v); },
  sample: function (v, t) { return P.hitSpring.sample(v, t); },
  pts: [
    { name: 'A', jp: 'スタート', t: function () { return 0; },
      sym: { K: '\\tfrac{1}{2}mv_0^{\\,2}', Ug: '0', Us: '0' } },
    { name: 'B', jp: 'ぶつかる瞬間', t: function (v) { return P.hitSpring.t1(v); },
      sym: { K: '\\tfrac{1}{2}mv_0^{\\,2}', Ug: '0', Us: '0' } },
    { name: 'C', jp: 'いちばん縮んだ所', t: function (v) { return P.hitSpring.tC(v); },
      sym: { K: '0', Ug: '0', Us: '\\tfrac{1}{2}kx^2' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m1-10'], v = V(s), m = d.sample(v, t);
    /* ★地面の下に「吹きだしの帯」（PTBAND）をあける★（先生の指示・第6回）
       A・B・C を左から順にならべるために、地面より下を使えるようにしておく。 */
    var SC = SC_HIT, gy = H - 78 - PTBAND, x0 = 46, D0 = P.hitSpring.D0, L0 = 1.2;
    var natX = x0 + D0 * SC, wallX = natX + L0 * SC;
    function X(u) { return natX + u * SC; }
    var kz = mSize(d, v), bw = 34 * kz, bh = 26 * kz;
    var xMax = P.hitSpring.xMax(v);

    ground(ctx, 20, W - 96, gy);
    /* 第9回：図を大きくして壁が右へ寄ったので、基準面の文字は線の下に置く（壁と重ならない） */
    datumLine(ctx, 20, W - 96, gy, '基準面 h = 0', true, true);
    /* 壁 */
    ctx.save();
    ctx.fillStyle = '#d7dde4'; ctx.fillRect(wallX, gy - 104, 16, 104);
    ctx.strokeStyle = '#8b949e'; ctx.lineWidth = 1.4; ctx.strokeRect(wallX, gy - 104, 16, 104);
    ctx.restore();
    /* 自然の長さの位置（O） */
    ctx.save();
    ctx.strokeStyle = '#9aa3ac'; ctx.lineWidth = 1.2; ctx.setLineDash([5, 4]);
    ctx.beginPath(); ctx.moveTo(natX, gy - 92); ctx.lineTo(natX, gy + 4); ctx.stroke();
    ctx.restore();
    label(ctx, '自然の長さの位置', natX, gy - 100, { size: 11, color: COL.sub });

    var free = X(Math.max(0, m.x));                 /* ばねの左はし */
    var cx = free - bw / 2, cy = gy - bh / 2;
    if (m.x < 0) cx = X(m.x) - bw / 2;              /* まだぶつかっていない */
    spring(ctx, wallX, cy, Math.min(free, wallX - 8), cy, { coils: 11, r: 11, color: COL.hand, lw: 2 });
    /* ★点の印は地面の下に出す★ 物体と重なると読めない（先生の指摘・第6回） */
    ptMark(ctx, 'A', X(-D0), gy + 17);
    ptMark(ctx, 'B', natX, gy + 17);
    ptMark(ctx, 'C', X(xMax), gy + 17);
    blockShape(ctx, cx, cy, 0, bw, bh, '#e8eef5');
    /* 縮みの寸法。動いているあいだは「いまの縮み」、
       ★運動が終わったら「いちばん縮んだ長さ x」（＝式 $\tfrac12kx^2$ の x）を残す★
       （先生の指示・第12回。式に出てくる記号は図にも出す） */
    if (m.x > 0.004) {
      arrow(ctx, natX, gy + 18, X(m.x), gy + 18, 'dim');
      label(ctx, 'x = ' + fmt(m.x, 3) + ' m', (natX + X(m.x)) / 2, gy + 32,
        { size: 11, color: COL.dim });
    } else if (endOn(d, s, t) && xMax > 0.004) {
      /* 運動が終わったら「いちばん縮んだ長さ x」を図の上のほうに残す。
         地面の下は 印・mg・吹きだしでうまっているので、上に寸法線をひく。 */
      var ytop = gy - 130;
      ctx.save();
      ctx.strokeStyle = fade(COL.dim, 0.35); ctx.lineWidth = 1; ctx.setLineDash([4, 4]);
      ctx.beginPath(); ctx.moveTo(X(xMax), ytop); ctx.lineTo(X(xMax), gy - 30); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(natX, ytop); ctx.lineTo(natX, gy - 104); ctx.stroke();
      ctx.restore();
      arrow(ctx, natX, ytop, X(xMax), ytop, 'dim');
      arrow(ctx, X(xMax), ytop, natX, ytop, 'dim');
      label(ctx, 'x = ' + fmt(xMax, 3) + ' m', (natX + X(xMax)) / 2, ytop - 11,
        { size: 11, color: COL.dim });
    }
    flickStart(ctx, t, v.v0, X(-D0) - bw / 2 - 20, cy, 0, 74);

    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 30 / mg;
    function fAt(qq, ax) {
      arrow(ctx, ax, cy, ax, cy + mg * fs, 'force');
      label(ctx, 'mg', ax, cy + mg * fs + 11, { size: 11.5, color: COL.force });
      arrow(ctx, ax, gy, ax, gy - mg * fs, 'force', 1, COL.norm);
      label(ctx, 'N', ax - bw / 2 - 8, gy - mg * fs + 4,
        { align: 'right', size: 11.5, color: COL.norm });
      if (qq.x > 0.004) {
        var fl = clamp(v.k * qq.x * fs * 0.5, 6, 78);
        arrow(ctx, ax + bw / 2, cy, ax + bw / 2 - fl, cy, 'force', 1, COL.hand);
        label(ctx, '弾性力 kx', ax + bw / 2 - fl / 2, cy - 15, { size: 11, color: COL.hand });
      }
    }
    if (s.o.showF) fAt(m, cx);
    if (s.o.showV && m.v > 0.05) {
      /* ★物体から離して出す★（ブロックの上 40 px） */
      var sgv = (m.vs > 0 ? 1 : -1), vl = vArrowLen(m.v, 5, 46);
      var va = velArrow(ctx, cx, cy, 0, -1, bh / 2 + 40, sgv, 0, vl);
      label(ctx, 'v', va.tx + sgv * 10, va.ty, { size: 11.5, color: COL.vel });
    }
    if (s.o.showA) {
      if (m.x > 0.004) drawAcc(ctx, cx, cy, -v.k * m.x / v.m, 0, { nx: 0, ny: -1, off: bh / 2 + 76 });
      else label(ctx, 'a = 0', cx, cy - bh / 2 - 76, { size: 11.5, color: COL.acc, avoid: true });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    ptRow(gy + 50);                   /* 吹きだしは地面の下に1列。物体の mg の字より下に置く */
    drawPts(ctx, d, s, t, function (p) {
      var ux = (p.name === 'C') ? X(xMax) : (p.name === 'B' ? natX : X(-D0));
      var q = d.sample(v, p.t);
      return { x: ux, y: gy - 10, ox: ux - bw / 2, oy: gy - bh / 2, bw: bw, bh: bh,
        fdraw: function () { fAt(q, ux - bw / 2); },
        here: Math.abs(m.x - (p.name === 'C' ? xMax : (p.name === 'B' ? 0 : -D0))) < 0.004,
        vx: (q.vs >= 0 ? 1 : -1), vy: 0, vref: 5, vk: 46, voff: bw / 2 + 12 };
    });
  },
  resItems: function (v) {
    return [
      { k: 'いちばん縮んだ長さ（式 $v_0\\sqrt{m/k}$）', v: fmt(P.hitSpring.xMax(v), 3) + ' m' },
      { k: 'そのときの弾性力 $kx$', v: fmt(v.k * P.hitSpring.xMax(v), 1) + ' N' },
      { k: 'ぶつかる時刻', v: fmt(P.hitSpring.t1(v), 2) + ' s' }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m1-10'].sample(v, t);
    return [
      ['ばねの縮み $x$', fmt(Math.max(0, m.x), 3) + ' m'],
      ['弾性力 $kx$', fmt(v.k * Math.max(0, m.x), 1) + ' N'],
      ['ばねから離れる時刻', fmt(P.hitSpring.tOut(v), 2) + ' s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return '\\tfrac{1}{2}mv_0^{\\,2} = \\tfrac{1}{2}kx^2 \\;\\Rightarrow\\; x = v_0\\sqrt{\\dfrac{m}{k}} = ' +
      fmt(P.hitSpring.xMax(v), 3) + '\\ \\mathrm{m}';
  },
  note: 'A から B までは、はたらく力（重力と垂直抗力）が<b>どちらも運動の向きと垂直</b>なので' +
    '<b>仕事は 0</b>、速さは変わりません。B からは<b>弾性力</b>が負の仕事をして物体を止め、' +
    'そのぶんが<b>弾性力による位置エネルギー $U_k=\\tfrac12kx^2$</b> にたくわえられます。' +
    'いちばん縮んだところ（C）で $K=0$、$U_k$ が最大。そのあと同じ速さで押しもどされます。'
};

/* ============ 1-11 水平ばねと滑台（★第5回・新規★） ============ */
DEFS['m1-11'] = {
  id: 'm1-11', mode: 1, tab: '1-11 水平ばねと滑台',
  title: '1-11　水平ばねと滑台',
  sub: 'なめらかな面。ばねを $x_0$ だけ縮めて、静かにはなします。' +
    'ばねが自然の長さにもどったところ（B）で物体はばねから離れ、' +
    'そのまま滑台を昇って高さ $h_C$ で止まります（C）。<b>そこで終わりではありません。</b>' +
    'なめらかなので、<b>下りてきてもう一度ばねを $x_0$ だけ縮め、' +
    'また同じ高さ $h_C$ まで昇ります</b>（行ったり来たりをくり返します）。仕事をするのは' +
    '<b>弾性力と重力（どちらも保存力）だけ</b>なので、<b>$E=K+U_g+U_k$ は一定</b>です。',
  cw: 680, ch: 416,
  vis: ['F', 'V', 'A'],
  hasUs: true,
  mainVars: ['x0', 'k'],
  mainVarFocus: 'x0',
  vars: [
    /* ★ばねが押す距離を3倍に★（先生の指示・第8回）
       x₀ を 3 倍にし、エネルギーが同じくらいになるよう k を 1/9 にした。 */
    { k: 'x0', label: 'はじめの縮み $x_0$', unit: ' m', min: 0.45, max: 0.90, step: 0.05, dec: 2, def: 0.75 },
    { k: 'k', label: 'ばね定数 $k$', unit: ' N/m', min: 20, max: 40, step: 5, dec: 0, def: 35 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 1.0, max: 2.0, step: 0.25, dec: 2, def: 1.0 }
  ],
  /* ★第13回：ヒントの「x₀ を2倍」がそのまま押せるようにボタンを入れかえた★
     x₀ は 0.45〜0.90 m なので、0.45 → 0.90 がちょうど2倍。 */
  actions: [
    { label: '小さく縮める（x₀＝0.45 m）', fn: function (s) { s.v.x0 = 0.45; },
      is: function (v) { return Math.abs(v.x0 - 0.45) < 1e-9; },
      next: function (s) { return s._played && Math.abs(s.v.x0 - 0.45) > 1e-9; } },
    { label: 'その2倍に（x₀＝0.90 m）', fn: function (s) { s.v.x0 = 0.90; },
      is: function (v) { return Math.abs(v.x0 - 0.90) < 1e-9; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.x0 = 0.75; s.v.k = 35; s.v.m = 1.0; },
      is: function (v) { return Math.abs(v.x0 - 0.75) < 1e-9 && v.k === 35 && Math.abs(v.m - 1) < 1e-9; } }
  ],
  cons: true,
  forces: ['g', 'N', 'sp'],
  hintFig: '<b>$\\tfrac12kx_0^{\\,2}$ が、そのまま $mgh_C$ に変わる</b>（とちゅうは $\\tfrac12mv^2$）',
  step1: '弾性力と重力（どちらも保存力）だけが仕事をする。垂直抗力は運動の向きに垂直',
  datum: '水平面（ばねと平らな床の高さ）',
  hint2: '<b>次は</b>：$x_0$ を変えて、<b>昇る高さ</b> $h_C = kx_0^{\\,2}/(2mg)$ が' +
    'どう変わるか見てみよう（$x_0$ を <b>0.45 m → 0.90 m</b> と2倍にすると、$h_C$ は何倍？）。',
  ptSide: 'row',
  /* ★第14回：1-11 は「はじめからスロー」をやめた（先生の指示）★
     第8回にばねが押す距離を3倍にしたので、ふつうの速さでも十分に追える。 */
  tEnd: function (v) { return P.sprSlide.tEnd(v); },
  sample: function (v, t) { return P.sprSlide.sample(v, t); },
  pts: [
    { name: 'A', jp: 'スタート（縮めた所）', t: function () { return 0; },
      sym: { K: '0', Ug: '0', Us: '\\tfrac{1}{2}kx_0^{\\,2}' } },
    { name: 'B', jp: 'ばねから離れる所', t: function (v) { return P.sprSlide.t1(v); },
      sym: { K: '\\tfrac{1}{2}mv_B^{\\,2}', Ug: '0', Us: '0' } },
    { name: 'C', jp: '最高点', t: function (v) { return P.sprSlide.tC(v); },
      hsym: 'h_C',                     /* ★式と図で同じ記号を使う★（第12回） */
      sym: { K: '0', Ug: 'mgh_C', Us: '0' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m1-11'], v = V(s), m = d.sample(v, t);
    var SC = SC_SPSL, gy = H - 62 - PTBAND, x0p = 40, LN = 0.8, LF = P.sprSlide.LF;
    var natX = x0p + LN * SC, wallX = x0p;
    function X(u) { return natX + u * SC; }
    function Y(y) { return gy - y * SC; }
    var cv = P.sprSlide.curve(), XT = P.sprSlide.XTOP;
    function HY(x) { return P.sprSlide.yAt(x); }        /* 坂の形（まるみ＋30°の直線） */
    var r = 12 * mSize(d, v);
    var hC = P.sprSlide.hC(v);

    /* 平らな床と、そのあとの曲面 */
    ctx.save();
    ctx.strokeStyle = '#333'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(X(-LN - 0.05), Y(0)); ctx.lineTo(X(LF), Y(0));
    var i;
    for (i = 0; i <= 80; i++) {
      var xx = XT * i / 80;
      ctx.lineTo(X(LF + xx), Y(HY(xx)));
    }
    ctx.stroke();
    ctx.restore();
    /* 下のハッチ（床と曲面の下） */
    hatchLine(ctx, X(-LN - 0.05), Y(0), X(LF), Y(0), 1);
    ctx.save();
    ctx.fillStyle = '#eef1f4';
    ctx.beginPath();
    ctx.moveTo(X(LF), Y(0));
    for (i = 0; i <= 80; i++) {
      var x2 = XT * i / 80;
      ctx.lineTo(X(LF + x2), Y(HY(x2)));
    }
    ctx.lineTo(X(LF + XT), Y(0));
    ctx.closePath(); ctx.fill();
    ctx.restore();
    /* 文字は線の右のはしに出す。左のはしだと、地面の下に置いた A の印とぶつかる（第6回の直し） */
    /* ★吹きだしの帯（地面の下）に文字を置かない★ 基準面の文字は線の上に出す（第6回） */
    datumLine(ctx, 20, X(LF) + 10, gy, '基準面 h = 0', true, false);
    /* 壁 */
    ctx.save();
    ctx.fillStyle = '#d7dde4'; ctx.fillRect(wallX - 16, gy - 96, 16, 96);
    ctx.strokeStyle = '#8b949e'; ctx.lineWidth = 1.4; ctx.strokeRect(wallX - 16, gy - 96, 16, 96);
    ctx.restore();
    /* 自然の長さの位置 */
    ctx.save();
    ctx.strokeStyle = '#9aa3ac'; ctx.lineWidth = 1.2; ctx.setLineDash([5, 4]);
    ctx.beginPath(); ctx.moveTo(natX, gy - 102); ctx.lineTo(natX, gy + 4); ctx.stroke();
    ctx.restore();
    label(ctx, '自然の長さ', natX, gy - 110, { size: 11, color: COL.sub });
    /* ★式の $x_0$（はじめの縮み）が図のどこかを見せる★（先生の指示・第12回）
       $U_k = \tfrac12kx_0^2$ の $x_0$。自然の長さの位置から A（スタート）まで。 */
    if (natX - X(-v.x0) > 8) {
      var y0d = gy - 66;
      arrow(ctx, X(-v.x0), y0d, natX, y0d, 'dim');
      arrow(ctx, natX, y0d, X(-v.x0), y0d, 'dim');
      label(ctx, 'x_0 = ' + fmt(v.x0, 2) + ' m', (natX + X(-v.x0)) / 2, y0d - 11,
        { size: 11, color: COL.dim });
    }

    /* 物体（球）の位置 */
    var bx, by, ang = 0;
    if (m.seg === 2) { bx = X(LF + m.cx); by = Y(m.y); ang = Math.atan(P.sprSlide.dyAt(m.cx)); }
    else { bx = X(m.x); by = Y(0); }
    var ox = bx, oy = by - r - Math.cos(ang) * 0 - 2;
    /* 面から外向きに r だけ浮かせる */
    var nx = -Math.sin(-ang), ny = -Math.cos(-ang);
    if (m.seg === 2) { nx = -Math.sin(ang); ny = -Math.cos(ang); } else { nx = 0; ny = -1; }
    ox = bx + nx * r; oy = by + ny * r;
    /* ばね（自然の長さより縮んでいるときだけ物体につながる） */
    var sEnd = (m.seg <= 1) ? X(Math.min(0, m.x)) : natX;
    spring(ctx, wallX, gy - r - 4, sEnd, gy - r - 4, { coils: 9, r: 9, color: COL.hand, lw: 2 });

    var pA = { x: X(-v.x0), y: gy }, pB = { x: natX, y: gy };
    var xC = P.sprSlide.xOfH(hC);
    var pC = { x: X(LF + xC), y: Y(hC) };
    /* ★いちばん高い所に「最高点」の吹きだし★（先生の指示・第13回）しっぽは下 */
    if (endOn(d, s, t)) ptNote(ctx, pC.x, pC.y, '最高点', '（点C）', { gap: 46 });
    /* ★A と B は近いので、A は地面の下・B は物体の上に分ける★（物体と重ねない） */
    /* ★印は地面の下（A・B）と坂の中（C）★（第6回）
       球・力の矢印・左の高さの数値とぶつからない場所にそろえる。 */
    var mk11 = { A: { x: pA.x, y: gy + 17 }, B: { x: pB.x, y: gy + 17 },
      C: { x: pC.x + 15, y: pC.y + 13 } };
    ptMark(ctx, 'A', mk11.A.x, mk11.A.y);
    ptMark(ctx, 'B', mk11.B.x, mk11.B.y);
    ptMark(ctx, 'C', mk11.C.x, mk11.C.y);
    ball(ctx, ox, oy, r);
    /* ★高さの寸法線は坂の右のはしに出す★（先生の指示・第8回）
       左に置くと、ばね・壁・A の印がならぶところとぶつかる。
       高さは「面に接している点」ではかる（球の半径ぶんを高さに数えない）。 */
    var HX = X(LF + XT) + 24;
    if (!endOn(d, s, t)) heightDim(ctx, HX, by, gy, 'h = ' + fmt(m.h, 2) + ' m', ox, true);
    /* 縮みの寸法 */
    if (m.seg === 0 && m.sp > 0.004) {
      arrow(ctx, natX, gy + 18, X(-m.sp), gy + 18, 'dim');
      label(ctx, 'x = ' + fmt(m.sp, 2) + ' m', (natX + X(-m.sp)) / 2, gy + 32,
        { size: 11, color: COL.dim });
    }

    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 30 / mg;
    function fAt(qq, sx, sy, ang4) {
      var n4x = -Math.sin(ang4), n4y = -Math.cos(ang4);
      var ax = sx + n4x * r, ay = sy + n4y * r;
      arrow(ctx, ax, ay, ax, ay + mg * fs, 'force');
      label(ctx, 'mg', ax, ay + mg * fs + 11, { size: 11.5, color: COL.force });
      var Nn = mg * Math.cos(ang4);
      arrow(ctx, sx, sy, sx + n4x * Nn * fs, sy + n4y * Nn * fs, 'force', 1, COL.norm);
      label(ctx, 'N', sx + n4x * (Nn * fs + 12), sy + n4y * (Nn * fs + 12),
        { size: 11.5, color: COL.norm });
      if (qq.seg === 0 && qq.sp > 0.004) {
        var fl = clamp(v.k * qq.sp * fs * 0.4, 6, 76);
        arrow(ctx, ax + r, ay, ax + r + fl, ay, 'force', 1, COL.hand);
        label(ctx, '弾性力 kx', ax + r + fl / 2, ay - 15, { size: 11, color: COL.hand });
      }
    }
    if (s.o.showF) fAt(m, bx, by, (m.seg === 2) ? ang : 0);
    if (s.o.showV && m.v > 0.05) {
      /* ★物体から離して出す★（面から外向きに 30 px ずらしてから進む向きへ） */
      var ux = Math.cos(ang), uy = -Math.sin(ang);
      if (m.back) { ux = -ux; uy = -uy; }        /* もどっている途中は逆向き（第18回） */
      var vl = vArrowLen(m.v, Math.max(1, P.sprSlide.vB(v)), 46);
      var va = velArrow(ctx, ox, oy, nx, ny, 30, ux, uy, vl);
      label(ctx, 'v', va.tx + ux * 10, va.ty + uy * 10, { size: 11.5, color: COL.vel });
    }
    if (s.o.showA) {
      var ax = 0, ay = 0;
      if (m.seg === 0) ax = v.k * m.sp / v.m;
      else if (m.seg === 2) { var at = -G * m.dyds; ax = Math.cos(ang) * at; ay = -Math.sin(ang) * at; }
      if (Math.hypot(ax, ay) > 0.05) drawAcc(ctx, ox, oy, ax, ay, { nx: nx, ny: ny, off: 60 });
      else label(ctx, 'a = 0', ox + nx * 60, oy + ny * 60, { size: 11.5, color: COL.acc, avoid: true });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    ptRow(gy + 30);                   /* 吹きだしは地面の下に1列でならべる */
    drawPts(ctx, d, s, t, function (p, mm, i2) {
      var q = (p.name === 'A') ? pA : (p.name === 'B' ? pB : pC);
      var a2 = (p.name === 'C') ? Math.atan(P.sprSlide.dyAt(xC)) : 0;
      var n2x = (p.name === 'C') ? -Math.sin(a2) : 0, n2y = (p.name === 'C') ? -Math.cos(a2) : -1;
      return { x: mk11[p.name].x, y: mk11[p.name].y, ox: q.x + n2x * r, oy: q.y + n2y * r,
        fdraw: function () { fAt(d.sample(v, p.t), q.x, q.y, a2); },
        r: r, vx: Math.cos(a2), vy: -Math.sin(a2), vref: Math.max(1, P.sprSlide.vB(v)), vk: 46, voff: r + 14,
        base: gy, hx: HX, hy: q.y };
    });
  },
  resItems: function (v) {
    return [
      { k: 'ばねから離れる速さ（式 $x_0\\sqrt{k/m}$）', v: fmt(P.sprSlide.vB(v), 2) + ' m/s' },
      { k: '昇る高さ（式 $kx_0^{\\,2}/2mg$）', v: fmt(P.sprSlide.hC(v), 2) + ' m' },
      { k: 'はじめの弾性力による位置エネルギー', v: fmtJ(EN.Us(v.k, v.x0)) }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m1-11'].sample(v, t);
    return [
      ['ばねの縮み $x$', fmt(m.sp || 0, 3) + ' m'],
      ['ばねから離れる時刻', fmt(P.sprSlide.t1(v), 2) + ' s'],
      ['1回目の最高点', fmt(P.sprSlide.tC(v), 2) + ' s'],
      ['もう一度ばねがいちばん縮む時刻', fmt(2 * P.sprSlide.tC(v), 2) + ' s'],
      ['2回目の最高点（おしまい）', fmt(3 * P.sprSlide.tC(v), 2) + ' s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return '\\tfrac{1}{2}kx_0^{\\,2} = \\tfrac{1}{2}mv_B^{\\,2} = mgh_C \\;\\Rightarrow\\; h_C = ' +
      '\\dfrac{kx_0^{\\,2}}{2mg} = ' + fmt(P.sprSlide.hC(v), 2) + '\\ \\mathrm{m}';
  },
  note: '<b>弾性力による位置エネルギー → 運動エネルギー → 位置エネルギー</b>と、すがたを変えていくようすが見えます。' +
    'A では $U_k$ だけ、B では $K$ だけ、C では $U_g$ だけ。<b>合計 $E$ はずっと同じ</b>です。' +
    '昇る高さは <b>$h_C = kx_0^{\\,2}/(2mg)$</b>。$x_0$ を2倍にすると高さは<b>4倍</b>になります。'
};

/* ============ 1-12 鉛直ばね（手をはなす） ============ */
DEFS['m1-12'] = {
  id: 'm1-12', mode: 1, tab: '1-12 鉛直ばね',
  title: '1-12　鉛直ばね（手をはなす）',
  sub: 'ばねが自然の長さのままおもりを支えておき、<b>手を急にはなす</b>と、おもりは下がって' +
    '<b>最下点</b>まで行き、また戻ってきます。仕事をするのは<b>重力と弾性力（どちらも保存力）</b>だけなので、' +
    '$K + U_g + U_k$ は一定。最下点は<b>つりあいの位置の2倍</b>の深さです。' +
    '<b>基準面ははじめの位置</b>にとってあるので、下がったところの高さは<b>負</b>になります。',
  cw: 760,                 /* 吹きだしの式が長いので、横を広めにとる（第6回で 620 → 760） */
  /* 第14回：最下点の下に「最下点（点C）」の吹きだしを置くぶん、60 px 高くした */
  ch: function (v) { return 410; },
  vis: ['F', 'V', 'A'],
  hasUs: true,
  ptSide: 'stack',
  mainVars: ['k', 'd'],
  mainVarFocus: 'k',
  vars: [
    { k: 'k', label: 'ばね定数 $k$', unit: ' N/m', min: 40, max: 100, step: 5, dec: 0, def: 50 },
    { k: 'd', label: 'はじめの伸び $d$（自然長から下へ）', unit: ' m', min: 0, max: 0.08, step: 0.01, dec: 2, def: 0.00 }
  ],
  consts: { m: 1.0 },
  actions: [
    { label: 'やわらかいばね（k＝40）', fn: function (s) { s.v.k = 40; },
      is: function (v) { return v.k === 40; },
      next: function (s) { return s._played && s.v.k !== 40; } },
    { label: '手でゆっくり下ろす場合を見る →', jump: 'm2-3' },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.k = 50; s.v.d = 0; },
      is: function (v) { return v.k === 50 && Math.abs(v.d) < 1e-9; } }
  ],
  cons: true,
  forces: ['g', 'sp'],
  hintFig: '<b>最下点はつりあいの位置の2倍の深さ</b>（$x_{最下}=2mg/k$）。そこで $K=0$ になり、また上がる',
  step1: '重力と弾性力（どちらも保存力）だけが仕事をしている',
  datum: 'はじめの位置（手をはなす高さ）。下がると高さは負',
  hint2: '<b>次は</b>：<a href="#m2-3" data-goto="m2-3">2-3（手でゆっくり下ろす）</a>を見て、手の仕事による結果のちがいを確かめよう。',
  slow: true,                /* ★はじめからスロー再生★（第8回・ばねのシム） */
  /* ★2.5 周期ぶん見せてから止める★（先生の指示・第8回）
     1周期だと「行って帰った」だけで、くり返しの運動だと分かりにくい。 */
  tEnd: function (v) { return 2.5 * P.m19.tEnd(v); },
  sample: function (v, t) { return P.m19.sample(v, t); },
  pts: [
    { name: 'A', jp: 'はじめの状態', t: function () { return 0; },
      sym: { K: '0', Ug: '0', Us: '\\tfrac{1}{2}kd^2' } },
    { name: 'B', jp: 'つりあいの位置', t: function (v) { return P.m19.tEq(v); },
      hsym: 'd-x_{eq}',                /* ★式と図で同じ記号を使う★（第12回） */
      sym: { K: '\\tfrac{1}{2}mv^2', Ug: 'mg(d-x_{\\text{eq}})', Us: '\\tfrac{1}{2}kx_{\\text{eq}}^{\\,2}' } },
    { name: 'C', jp: '最下点', t: function (v) { return P.m19.tLow(v); },
      hsym: 'd-x_{最下}',
      sym: { K: '0', Ug: 'mg(d-x_{\\text{最下}})', Us: '\\tfrac{1}{2}kx_{\\text{最下}}^{\\,2}' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m1-12'], v = V(s), m = d.sample(v, t);
    /* ★横の場所わけ（第6回で作り直し）★
       左  … 高さの寸法線（h）を2列　／　まん中 … ばねとおもり
       右  … 点の印 A・B・C → 加速度 → 「自然長」「つりあい」の文字 → 吹きだしの列 */
    var cx = W * 0.34, topY = 46;
    var natY = topY + 86;                       /* 自然長のときのおもりの位置 */
    var xe = P.m19.xEq(v), xl = P.m19.xLow(v);
    /* 縮尺は「最下点が図に収まる」ように決める（やわらかいばねだと下にはみ出すため）。
       第14回：最下点の下に吹きだしを置くので、下の余白を 76 → 136 px にした。 */
    var sc = Math.min(300, (H - 136 - natY) / Math.max(0.05, xl));
    function Y(x) { return natY + x * sc; }     /* x＝自然長からの伸び */
    var kz = 1, bw = 40, bh = 26;

    /* 天井 */
    hatchLine(ctx, cx - 52, topY, cx + 52, topY, -1);
    /* 目印 */
    ctx.save();
    ctx.strokeStyle = '#9aa3ac'; ctx.lineWidth = 1.1; ctx.setLineDash([5, 4]);
    ctx.beginPath(); ctx.moveTo(cx - 96, natY); ctx.lineTo(cx + 60, natY); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(cx - 96, Y(xe)); ctx.lineTo(cx + 60, Y(xe)); ctx.stroke();
    ctx.restore();
    /* 文字は線の「右のはし」の少し上に置く。線の上に置くと、破線が文字を横切って読めない
       （第6回の直し）。左に置くと、左の高さの寸法線とぶつかる。 */
    label(ctx, '自然長', cx + 64, natY - 11, { size: 11, color: COL.sub, align: 'left' });
    /* ★式の $x_{eq}$ が図のどこかを見せる★（先生の指示・第12回） */
    label(ctx, 'つりあい x_{eq} = ' + fmt(xe, 3) + ' m', cx + 64, Y(xe) - 11,
      { size: 11, color: COL.sub, align: 'left' });
    datumLine(ctx, cx - 110, W - 96, Y(v.d), '基準面 h = 0（スタート）', true, false);
    /* ★2-3（手でゆっくり下ろす）との見くらべ★（先生の指示・第11回）
       同じばね・同じおもりでも、手が仕事をするかどうかで
       「つりあいの位置での速さ」がまるでちがう。2-3 にも同じパネルを出す。 */
    if (hintOn(s, t)) {
      factPanel(ctx, W * 0.53, 36, 'つりあいの位置（B点）での速さ',
        fmt(P.m19.vEq(v), 2) + ' m/s', '止まらずに通りすぎる');
    }
    /* ★表の $d$（はじめの伸び）が図のどこかを見せる★（第6回）
       自然長の線から、スタート（＝基準面）の線までの長さが d。
       ★第11回★ d = 0 のときは、矢印も数値も出さない。
       「d = 0.00 m（自然長から）」だけが動かずに残っていると、
       「いまの伸び」を表しているように読めてしまう（先生の指摘）。 */
    if (Y(v.d) - natY > 7) {
      arrow(ctx, cx - 90, natY, cx - 90, Y(v.d), 'dim');
      arrow(ctx, cx - 90, Y(v.d), cx - 90, natY, 'dim');
      label(ctx, 'はじめの伸び d = ' + fmt(v.d, 2) + ' m', cx - 90, natY - 12,
        { size: 11, color: COL.dim });
    }

    var by = Y(m.x);
    spring(ctx, cx, topY, cx, by - bh / 2, { coils: 11, r: 13, color: COL.hand, lw: 2 });
    /* ★3点は高さがちがうので、印は1本の列にそろえる★（第6回の直し）
       前は横にずらしていたので、おもりや吹きだしの上に乗ってしまっていた。
       ただし k と d の組み合わせで3点がほとんど同じ高さになることがある
       （d ≒ x_eq のとき）。そのときだけ横にずらして、文字が重ならないようにする。 */
    var mSpread = Math.max(Math.abs(Y(xe) - Y(v.d)), Math.abs(Y(xl) - Y(v.d)),
      Math.abs(Y(xl) - Y(xe)));
    var mDx = (mSpread < 26) ? 26 : 0;
    ptMark(ctx, 'A', cx + 40, Y(v.d));
    ptMark(ctx, 'B', cx + 40 + mDx, Y(xe));
    ptMark(ctx, 'C', cx + 40 + 2 * mDx, Y(xl));
    /* ★いちばん低い所に「最下点（点C）」の吹きだし★（先生の指示・第14回）
       しっぽは上向き（箱は下）。まん中は mg の矢印が通るので、箱は左へ寄せる。 */
    if (endOn(d, s, t)) ptNote(ctx, cx, Y(xl), '最下点', '（点C）', { below: true, gap: 78 });
    blockShape(ctx, cx, by, 0, bw, bh, '#e8eef5');
    /* 運動が終わったら、点ごとの高さ（drawPts）に任せてこの1本は消す */
    if (!endOn(d, s, t)) heightDim(ctx, cx - 116, by, Y(v.d), 'h = ' + fmt(m.h, 3) + ' m');   /* 下は負 */

    var hA = (t <= 0.18) ? 1 : Math.max(0, 1 - (t - 0.18) / 0.22);
    if (hA > 0.02) dropHand(ctx, cx - 4, Y(v.d) + bh / 2, 0.5, clamp(t / 0.18, 0, 1), hA);

    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 30 / mg;
    function fAt(qq, ay) {
      arrow(ctx, cx, ay, cx, ay + mg * fs, 'force');
      label(ctx, 'mg', cx, ay + mg * fs + 11, { size: 11.5, color: COL.force });
      var F = v.k * qq.x;
      if (F * fs > 3) {
        arrow(ctx, cx, ay - bh / 2, cx, ay - bh / 2 - F * fs, 'force', 1, COL.hand);
        label(ctx, '弾性力 kx', cx + 12, ay - bh / 2 - F * fs + 6, { size: 11, color: COL.hand, align: 'left' });
      }
    }
    if (s.o.showF) {
      fAt(m, by);
    }
    if (s.o.showV && Math.abs(m.v) > 0.03) {
      /* ★物体から離して出す★（ブロックの左 76 px。加速度は左 34 px なので、ぶつからない） */
      var sgv = (m.vs > 0 ? 1 : -1), vl = vArrowLen(m.v, Math.max(0.2, P.m19.vEq(v)), 44);
      var va = velArrow(ctx, cx, by, -1, 0, 76, 0, sgv, vl);
      label(ctx, 'v', va.x - 12, va.y, { size: 11.5, color: COL.vel, align: 'right' });
    }
    if (s.o.showA) drawAcc(ctx, cx, by, 0, G - v.k * m.x / v.m, { nx: -1, ny: 0, off: bw / 2 + 24 });
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    drawPts(ctx, d, s, t, function (p, mm, i2) {
      var yy = (p.name === 'A') ? Y(v.d) : (p.name === 'B' ? Y(xe) : Y(xl));
      var q = d.sample(v, p.t);
      /* 高さの寸法線は左に2列。深いほう（C）は数値を線の左に出して、B の線とぶつけない */
      return { x: cx + 40 + i2 * mDx, y: yy, ox: cx, oy: yy, bw: bw, bh: bh,
        here: Math.abs(yy - by) < 1.5,      /* 2.5 周期で最下点（C）に止まる */
        fdraw: function () { fAt(q, yy); },
        vx: 0, vy: (q.vs >= 0 ? 1 : -1), vref: Math.max(0.2, P.m19.vEq(v)), vk: 44, voff: bh / 2 + 10,
        base: Y(v.d), hx: cx - 116 - i2 * 44, hside: (i2 >= 2) ? 'left' : 0 };
    });
  },
  resItems: function (v) {
    return [
      { k: 'つりあいの位置 $x_{eq}=mg/k$', v: fmt(P.m19.xEq(v), 3) + ' m' },
      { k: '最下点 $x=2mg/k$', v: fmt(P.m19.xLow(v), 3) + ' m' },
      { k: 'つりあいでの速さ（最大）', v: fmt(P.m19.vEq(v), 2) + ' m/s' }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m1-12'].sample(v, t);
    return [
      ['ばねの伸び $x$', fmt(m.x, 3) + ' m'],
      ['弾性力 $kx$', fmt(v.k * m.x, 1) + ' N'],
      ['最下点に来る時刻', fmt(P.m19.tLow(v), 2) + ' s'],
      ['1往復の時間', fmt(P.m19.tEnd(v), 2) + ' s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return 'mgx = \\tfrac{1}{2}kx^2 \\;\\Rightarrow\\; x_{\\text{最下}} = \\dfrac{2mg}{k} = ' +
      fmt(P.m19.xLow(v), 3) + '\\ \\mathrm{m}\\quad(x_{\\text{eq}} = ' + fmt(P.m19.xEq(v), 3) + '\\ \\mathrm{m})';
  },
  note: '重力も弾性力も<b>保存力</b>なので、$K+U_g+U_k$ は一定です。' +
    '自然長から静かに手をはなすと、<b>最下点はつりあいの位置のちょうど2倍</b>の深さ（$2mg/k$）になります。' +
    'これは「$mgx = \\tfrac12kx^2$ を解く」だけで出ます。' +
    '<b>つりあいの位置</b>では弾性力と重力がつり合っていて、そこで<b>速さが最大</b>になります。' +
    'モード2の <b>2-3</b> では、同じばねを<b>手でゆっくり下ろし</b>ます。見くらべてみてください。'
};

/* ============ 1-13 曲面から飛び出す ============ */
DEFS['m1-13'] = {
  id: 'm1-13', mode: 1, tab: '1-13 曲面飛び出し',
  title: '1-13　曲面から飛び出す',
  sub: 'なめらかな円弧のくぼみを、高さ $h$ の点 A から初速度 $v_0$ ですべり下り、' +
    '最下点 B を通って、<b>60° の向きの点 C から飛び出し</b>、最高点 D まで上がります。' +
    '面の上でも空中でも<b>仕事をするのは重力だけ</b>なので、力学的エネルギーはずっと一定です。',
  cw: 790, ch: 452,          /* 点が4つ＝吹きだしも4つ。地面の下に1列でならべる（第6回で 680 → 790） */
  vis: ['F', 'V', 'A'],
  mainVars: ['h', 'v0'],
  mainVarFocus: 'v0',
  vars: [
    { k: 'h', label: 'はじめの高さ $h$', unit: ' m', min: 1.5, max: 3.5, step: 0.1, dec: 1, def: 2.5 },
    { k: 'v0', label: 'はじめの速さ $v_0$', unit: ' m/s', min: 0, max: 4, step: 0.5, dec: 1, def: 0.0 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 4, step: 0.5, dec: 1, def: 1.0 }
  ],
  actions: [
    { label: '勢いをつける（v₀＝3 m/s）', fn: function (s) { s.v.v0 = 3; },
      is: function (v) { return Math.abs(v.v0 - 3) < 1e-9; },
      next: function (s) { return s._played && Math.abs(s.v.v0 - 3) > 1e-9; } },
    { label: '高いところから（h＝3.5 m）', fn: function (s) { s.v.h = 3.5; },
      is: function (v) { return Math.abs(v.h - 3.5) < 1e-9; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.h = 2.5; s.v.v0 = 0; },
      is: function (v) { return Math.abs(v.h - 2.5) < 1e-9 && Math.abs(v.v0) < 1e-9; } }
  ],
  ptSide: 'row',
  cons: true,
  forces: ['g', 'N'],
  hintFig: '<b>飛び出したあとも $E$ は変わらない</b>。最高点 D でも水平方向の速さが残るので $K \\ne 0$',
  step1: '重力（保存力）だけが仕事をする。曲面の垂直抗力は運動の向きに垂直',
  datum: 'くぼみの最下点',
  hint2: '<b>次は</b>：$h$ を変えて、<b>最高点 D の高さ</b>がどう変わるか確かめよう。',
  tEnd: function (v) { return P.m110.tEnd(v); },
  sample: function (v, t) { return P.m110.sample(v, t); },
  pts: [
    { name: 'A', jp: 'スタート', t: function () { return 0; },
      hsym: 'h',                       /* ★式と図で同じ記号を使う★（第12回） */
      sym: { K: '\\tfrac{1}{2}mv_0^{\\,2}', Ug: 'mgh' } },
    { name: 'B', jp: '最下点', t: function (v) { return P.m110.tB(v); },
      sym: { K: '\\tfrac{1}{2}mv_B^{\\,2}', Ug: '0' } },
    { name: 'C', jp: '飛び出す点', t: function (v) { return P.m110.tC(v); },
      hsym: 'h_C',
      sym: { K: '\\tfrac{1}{2}mv_C^{\\,2}', Ug: 'mgh_C' } },
    { name: 'D', jp: '最高点', t: function (v) { return P.m110.tD(v); },
      hsym: 'h_D',
      sym: { K: '\\tfrac{1}{2}m(v_C\\cos 60^\\circ)^2', Ug: 'mgh_D' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m1-13'], v = V(s), m = d.sample(v, t);
    var R = P.m110.R, o = P.m110.table(v);
    /* ★くぼみの左は「鉛直な壁」★（先生の指示・第8回）
       h > R のときは、円は 90°（＝いちばん左）まででやめて、そこから上は鉛直な壁にする。
       円のままだとオーバーハングになり、静かにはなしても面にそって滑る＝ありえない動きになる。 */
    var th0 = P.m110.th0(v), al = -th0;              /* 円に入る角（0〜90°） */
    var hw = P.m110.wallH(v);                        /* 壁の高さ（0 なら壁なし） */
    var tab = o.tab, i;
    var xmin = -R * Math.sin(al), xmax = 0, ymax = Math.max(v.h, 0);
    for (i = 0; i < tab.length; i++) {
      if (tab[i].x > xmax) xmax = tab[i].x;
      if (tab[i].y > ymax) ymax = tab[i].y;
    }
    /* 第9回：右の余白が大きかったので 56 → 62（どの設定でも横 63.3・縦 96 まで入るので、
       62 なら「いつも同じ縮尺」のまま、いちばん大きく見せられる） */
    var sc = Math.min(62, (W - 190) / Math.max(0.5, xmax - xmin), (H - 116) / Math.max(0.5, ymax));
    var gy = H - 52 - PTBAND, x0 = 50 - xmin * sc;
    function X(x) { return x0 + x * sc; }
    function Y(y) { return gy - y * sc; }

    /* 円弧のくぼみ */
    var cyc = Y(R);
    ctx.save();
    ctx.strokeStyle = '#333'; ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.arc(X(0), cyc, R * sc, Math.PI / 2 - P.m110.PHI, Math.PI / 2 + al);
    ctx.stroke();
    /* 鉛直な壁（円の左はし＝高さ R の点から、スタートの高さまで） */
    if (hw > 0.001) {
      ctx.beginPath();
      ctx.moveTo(X(-R), Y(R)); ctx.lineTo(X(-R), Y(v.h));
      ctx.stroke();
    }
    ctx.lineWidth = 1; ctx.strokeStyle = '#333';
    for (var aa = Math.PI / 2 - P.m110.PHI; aa < Math.PI / 2 + al; aa += 0.09) {
      ctx.beginPath();
      ctx.moveTo(X(0) + Math.cos(aa) * R * sc, cyc + Math.sin(aa) * R * sc);
      ctx.lineTo(X(0) + Math.cos(aa + 0.05) * (R * sc + 8), cyc + Math.sin(aa + 0.05) * (R * sc + 8));
      ctx.stroke();
    }
    /* 壁のハッチ（左がわが「かべの中」） */
    for (var hy2 = Y(R) - 6; hy2 > Y(v.h) - 1 && hw > 0.001; hy2 -= 9) {
      ctx.beginPath(); ctx.moveTo(X(-R), hy2); ctx.lineTo(X(-R) - 8, hy2 + 5); ctx.stroke();
    }
    ctx.restore();
    /* ★吹きだしの帯（地面の下）に文字を置かない★ 基準面の文字は線の上に出す（第6回） */
    datumLine(ctx, X(xmin) - 20, W - 96, gy, '基準面 h = 0', true, false);

    /* 飛び出したあとの道すじ */
    ctx.save();
    ctx.strokeStyle = '#c3cbd3'; ctx.lineWidth = 1.2; ctx.setLineDash([5, 5]);
    ctx.beginPath();
    for (i = 0; i < tab.length; i += 4) {
      if (i === 0) ctx.moveTo(X(tab[i].x), Y(tab[i].y)); else ctx.lineTo(X(tab[i].x), Y(tab[i].y));
    }
    ctx.stroke(); ctx.restore();

    var mA = d.sample(v, 0), mB = d.sample(v, P.m110.tB(v));
    var mC = d.sample(v, P.m110.tC(v)), mD = d.sample(v, P.m110.tD(v));
    /* ★いちばん高い所に「最高点」の吹きだし★（先生の指示・第13回）しっぽは下 */
    if (endOn(d, s, t)) ptNote(ctx, X(mD.x), Y(mD.y), '最高点', '（点D）', { gap: 50 });
    /* ★飛び出す点 C が「まん中から 60°」であることを図に出す★（先生の指示・第8回）
       円の中心から、最下点 B の向きと C の向きへ細い線を引き、その間の角を 60° と書く。 */
    ctx.save();
    ctx.strokeStyle = fade(COL.sub, 0.75); ctx.lineWidth = 1; ctx.setLineDash([4, 3]);
    ctx.beginPath(); ctx.moveTo(X(0), cyc); ctx.lineTo(X(0), Y(0)); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(X(0), cyc); ctx.lineTo(X(mC.x), Y(mC.y)); ctx.stroke();
    ctx.restore();
    angArc(ctx, X(0), cyc, R * sc * 0.42, Math.PI / 2 - P.m110.PHI, Math.PI / 2,
      '60°', Math.PI / 2 - P.m110.PHI / 2, R * sc * 0.42 + 16);
    /* 円の中心も小さく打っておく（どこから測った角なのかが分かるように） */
    ctx.save();
    ctx.fillStyle = fade(COL.sub, 0.8);
    ctx.beginPath(); ctx.arc(X(0), cyc, 2.4, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    /* ★印は球からずらす★（第6回）球やゴースト、力の矢印にかぶると文字が読めない。
       A は、壁があるときは壁の右上（壁の中には置けない）、ないときはくぼみの外（左上）へ。
       C は飛び出したあとの道すじの外（右上）へ。 */
    var mkA13 = { x: X(mA.x) + 20, y: Y(mA.y) - 13 };   /* 左は高さの数値がならぶので、いつも右上へ */
    ptMark(ctx, 'A', mkA13.x, mkA13.y);
    ptMark(ctx, 'B', X(mB.x), Y(mB.y) - 30);   /* 球は面の内がわに乗るので、その上へ */
    ptMark(ctx, 'C', X(mC.x) + 22, Y(mC.y) - 15);
    ptMark(ctx, 'D', X(mD.x), Y(mD.y) - 13);
    /* 運動が終わったら、点ごとの高さ（drawPts）に任せてこの1本は消す */
    if (!endOn(d, s, t)) heightDim(ctx, 22, Y(v.h), gy, 'h = ' + fmt(v.h, 1) + ' m', X(mA.x), true);

    var kz = mSize(d, v), r = 8 * kz;
    /* ★球は「面の内がわ」に半径ぶん浮かせて描く★（第8回）
       面の上に中心をのせると、球が面（とくに鉛直な壁）の線をかくしてしまう。
       内向き＝円の中心へ向かう向き。壁の上（θ=−90°）なら真右。 */
    function inN(q) {
      if (!q.on) return { x: 0, y: 0 };
      return { x: -Math.sin(q.th), y: -Math.cos(q.th) };
    }
    for (i = 1; i * 0.12 < t - 1e-9; i++) {
      var q = d.sample(v, i * 0.12), n2 = inN(q);
      ball(ctx, X(q.x) + n2.x * r, Y(q.y) + n2.y * r, r, 'faint');
    }
    var px = X(m.x), py = Y(m.y), n0 = inN(m);
    var bx = px + n0.x * r, by = py + n0.y * r;      /* 球の中心 */
    ball(ctx, bx, by, r);
    /* ★初速度 0 のときは「手をはなす」、勢いをつけるときは「デコピン」★ */
    var nA = inN(mA), aBx = X(mA.x) + nA.x * r, aBy = Y(mA.y) + nA.y * r;
    if (v.v0 < 0.05) {
      var hA = (t <= 0.18) ? 1 : Math.max(0, 1 - (t - 0.18) / 0.22);
      if (hA > 0.02) dropHand(ctx, aBx, aBy, 0.5, clamp(t / 0.18, 0, 1), hA);
    } else {
      flickStart(ctx, t, v.v0, aBx - 20, aBy, 0, 62);
    }

    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 30 / mg;
    function fAt(qq, sx, sy) {                /* sx, sy＝面に接している点 */
      var n5 = inN(qq), ax = sx + n5.x * r, ay = sy + n5.y * r;
      arrow(ctx, ax, ay, ax, ay + mg * fs, 'force');
      label(ctx, 'mg', ax, ay + mg * fs + 11, { size: 11.5, color: COL.force });
      /* ★鉛直な壁の上では N = 0★（面が運動の向きと平行で、押しつける力がない）。
         だから矢印を描かない。ここを描いてしまうと「壁が横に押している」と誤解される。
         飛んでいる間（on = false）も、はたらくのは重力だけ。 */
      if (qq.on && !qq.wall) {
        var Nn = Math.min((mg * Math.cos(qq.th) + v.m * qq.v * qq.v / R) * fs, 70);
        arrow(ctx, sx, sy, sx + n5.x * Nn, sy + n5.y * Nn, 'force', 1, COL.norm);
        label(ctx, 'N', sx + n5.x * (Nn + 12), sy + n5.y * (Nn + 12), { size: 11.5, color: COL.norm });
      }
    }
    if (s.o.showF) fAt(m, px, py);
    if (s.o.showV && m.v > 0.05) {
      /* ★物体から離して出す★ 進む向きと垂直に 22 px ずらしてから */
      var vl = vArrowLen(m.v, Math.max(1, P.m110.vB(v)), 46);
      var ux = m.vx / m.v, uy = -m.vy / m.v;
      /* ずらす向きは「進む向きと垂直」。ただし mg（真下）とぶつからないよう、
         左右のうち mg から遠いほうへ出す */
      var sgv = (ux >= 0) ? 1 : -1;
      var va = velArrow(ctx, bx, by, -uy * sgv, ux * sgv, 40, ux, uy, vl);
      label(ctx, 'v', va.tx + ux * 10, va.ty + uy * 10, { size: 11.5, color: COL.vel });
    }
    if (s.o.showA) {
      var ax2 = 0, ay2 = G;
      if (m.on) {
        var nx3 = X(0) - px, ny3 = cyc - py, nl3 = Math.hypot(nx3, ny3) || 1;
        var Nm = mg * Math.cos(m.th) + v.m * m.v * m.v / R;
        ax2 = (nx3 / nl3) * Nm / v.m; ay2 = G + (ny3 / nl3) * Nm / v.m;
      }
      var ubx = (m.v > 0.05) ? m.vx / m.v : 0, uby = (m.v > 0.05) ? -m.vy / m.v : -1;
      var sgb = (ubx >= 0) ? 1 : -1;
      drawAcc(ctx, bx, by, ax2, ay2,
        { nx: (m.v > 0.05) ? ubx : 0, ny: (m.v > 0.05) ? uby : -1, off: 48, max: 54 });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    ptRow(gy + 30);                   /* 吹きだしは地面の下に1列でならべる */
    drawPts(ctx, d, s, t, function (p, mm, i2) {
      var q = d.sample(v, p.t);
      var mk = (p.name === 'A') ? mkA13
        : (p.name === 'B' ? { x: X(mB.x), y: Y(mB.y) - 30 }
        : (p.name === 'C' ? { x: X(mC.x) + 22, y: Y(mC.y) - 15 } : { x: X(mD.x), y: Y(mD.y) - 13 }));
      var uq = q.v > 0.02 ? { x: q.vx / q.v, y: -q.vy / q.v } : { x: 1, y: 0 };
      var nq = inN(q);
      return { x: mk.x, y: mk.y, ox: X(q.x) + nq.x * r, oy: Y(q.y) + nq.y * r, r: r,
        fdraw: function () { fAt(q, X(q.x), Y(q.y)); },
        vx: uq.x, vy: uq.y, vref: Math.max(1, P.m110.vB(v)), vk: 46, voff: r + 16,
        base: gy, hx: 22 + i2 * 27 };
    });
  },
  resItems: function (v) {
    return [
      { k: '最下点 B の速さ（式）', v: fmt(P.m110.vB(v), 2) + ' m/s' },
      { k: '飛び出す点 C の速さ（式）', v: fmt(P.m110.vC(v), 2) + ' m/s' },
      { k: '最高点 D の高さ（式）', v: fmt(P.m110.hD(v), 2) + ' m' }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m1-13'].sample(v, t);
    return [
      ['いまの高さ', fmt(m.h, 2) + ' m'],
      ['飛び出す点の高さ $h_C$', fmt(P.m110.hC(v), 2) + ' m'],
      ['飛び出す時刻', fmt(P.m110.tC(v), 2) + ' s'],
      ['最高点に来る時刻', fmt(P.m110.tD(v), 2) + ' s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return '\\tfrac{1}{2}mv_0^{\\,2} + mgh = \\tfrac{1}{2}mv_C^{\\,2} + mgh_C \\;\\Rightarrow\\; v_C = ' +
      fmt(P.m110.vC(v), 2) + '\\ \\mathrm{m/s}';
  },
  note: '面の上でも空中でも、仕事をするのは<b>重力だけ</b>です（垂直抗力は運動の向きに垂直）。' +
    'だから A・B・C・D の<b>どこでも $E$ は同じ</b>。高さが低いほど速く、高いほど遅くなります。' +
    '<b>最高点 D でも運動エネルギーは 0 になりません</b>——飛び出す向きが 60° なので、' +
    '水平方向の速さ $v_C\\cos 60°$ が残るからです。'
};
