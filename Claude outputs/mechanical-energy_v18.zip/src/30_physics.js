/* 純粋な物理計算だけ（描画を混ぜない）。同じ入力 → 同じ出力。
   ★このページのいちばん大事な決めごと★
   　エネルギーの定義は下の EN ただ1か所。ほかの場所で ½mv² や mgh を直接書かない。 */
'use strict';
var G = 9.8;
var DEG = Math.PI / 180;

function clamp(x, a, b) { return x < a ? a : (x > b ? b : x); }
function fmt(x, d) {
  if (d === undefined) d = 1;
  if (!isFinite(x)) return '—';
  var s = x.toFixed(d);
  if (s === '-' + (0).toFixed(d)) s = (0).toFixed(d);   /* −0.0 を出さない */
  return s;
}

/* =========================================================
   エネルギーの定義（ページ全体でここ1か所）
   K  = ½mv²          運動エネルギー
   Ug = mgh           重力による位置エネルギー（h は「基準面からの高さ」）
   Us = ½kx²          弾性力による位置エネルギー（x は「自然の長さからの変形」）
   E  = K + Ug + Us   力学的エネルギー
   W  = 非保存力がした仕事（保存力だけのときは 0）
   各シムの sample() は「速さ v・高さ h・ばねの変形 sp・仕事 w」だけを返し、
   エネルギーは必ず EN.mix() を通して作る。
   ========================================================= */
var EN = {
  K: function (m, v) { return 0.5 * m * v * v; },
  Ug: function (m, h) { return m * G * h; },
  Us: function (k, x) { return 0.5 * k * x * x; },
  /* q = {v, h, sp, w} → q に K/Ug/Us/U/E/W を書き足して返す */
  mix: function (v, q) {
    var K = EN.K(v.m, q.v || 0);
    var Ug = EN.Ug(v.m, q.h || 0);
    var Us = (v.k > 0 && q.sp) ? EN.Us(v.k, q.sp) : 0;
    q.K = K; q.Ug = Ug; q.Us = Us; q.U = Ug + Us; q.E = K + Ug + Us;
    q.W = q.w || 0;
    return q;
  }
};

/* =========================================================
   数値積分：拘束された1自由度 q に対する q'' = a(q)
   ★エネルギーが保存する解法（速度ベルレ法）を使う★
   　オイラー法だと E がじわじわ増えて、このページの主役
   　「E が一定」がくずれてしまう。
   同じ入力なら必ず同じ表になる（表は入力で作り、時刻から読む）。
   ========================================================= */
var INT = {
  DT: 0.002,
  /* acc(q) … 位置だけで決まる加速度。stop(q, w, i) … true になったらそこで打ち切る */
  verlet: function (acc, q0, w0, dt, n, stop) {
    var q = q0, w = w0, a = acc(q0), i, arr = [{ q: q0, w: w0, a: a, t: 0 }];
    for (i = 1; i <= n; i++) {
      var qN = q + w * dt + 0.5 * a * dt * dt;
      var aN = acc(qN);
      var wN = w + 0.5 * (a + aN) * dt;
      q = qN; w = wN; a = aN;
      arr.push({ q: q, w: w, a: a, t: i * dt });
      if (stop && stop(q, w, i)) break;
    }
    return arr;
  },
  /* 表から時刻 t の行を読む（丸めだけ。補間しない＝同じ入力なら同じ値） */
  at: function (tab, t, dt) {
    return tab[clamp(Math.round(t / dt), 0, tab.length - 1)];
  }
};

/* 1つ前の計算をおぼえておく（同じ設定なら作り直さない） */
function memo1(build) {
  var key = null, val = null;
  return function (k, v) {
    if (key === k) return val;
    key = k; val = build(v);
    return val;
  };
}

/* =========================================================
   曲線を「弧長 s」で表す（曲面をすべる運動のため）
   fy(x) … 高さ、fd(x) … dy/dx。x を細かく刻んで弧長を積む。
   返り値： sMax, at(s) → {x, y, dyds}
   ========================================================= */
function arcCurve(fy, fd, x0, x1, n) {
  var i, xs = [], ys = [], ss = [], dd = [];
  var dx = (x1 - x0) / n, sAcc = 0, px = x0, py = fy(x0);
  xs.push(x0); ys.push(py); ss.push(0); dd.push(fd(x0));
  for (i = 1; i <= n; i++) {
    var x = x0 + dx * i, y = fy(x);
    sAcc += Math.hypot(x - px, y - py);
    xs.push(x); ys.push(y); ss.push(sAcc); dd.push(fd(x));
    px = x; py = y;
  }
  return {
    sMax: sAcc,
    /* s → {x, y, dyds}（線形補間） */
    at: function (s) {
      var lo = 0, hi = ss.length - 1, mid;
      if (s <= 0) { var d0 = dd[0]; return { x: xs[0], y: ys[0], dyds: d0 / Math.sqrt(1 + d0 * d0) }; }
      if (s >= sAcc) { var d1 = dd[hi]; return { x: xs[hi], y: ys[hi], dyds: d1 / Math.sqrt(1 + d1 * d1) }; }
      while (hi - lo > 1) { mid = (lo + hi) >> 1; if (ss[mid] <= s) lo = mid; else hi = mid; }
      var f = (s - ss[lo]) / Math.max(1e-12, ss[hi] - ss[lo]);
      var d = dd[lo] + (dd[hi] - dd[lo]) * f;
      return { x: xs[lo] + (xs[hi] - xs[lo]) * f, y: ys[lo] + (ys[hi] - ys[lo]) * f,
        dyds: d / Math.sqrt(1 + d * d) };
    }
  };
}

var P = {};

/* ===== どの P がどのタブか（第2回でタブ番号をふり直したので対応表を残す） =====
   P.m11 → 1-1 摩擦のない水平面      P.m12 → 1-2 自由落下
   P.m13 → 1-3 滑台（直線）1         P.slopeUp → 1-4 滑台（直線）2（昇る・新規）
   P.m14 → 1-5 滑台（曲線）          P.m15 → 1-6 振り子
   P.cylWall → 1-7 円筒面（作り直し） P.m17 → 1-8 斜方投射
   P.m18 → 1-9 水平ばね              P.m19 → 1-12 鉛直ばね
   P.m110 → 1-13 曲面飛び出し
   P.m21 → 2-1 摩擦のある床          P.m22 → 2-2 摩擦のある斜面
   P.m23 → 2-3 鉛直ばね（手の仕事）  P.m24 → 2-4 摩擦のある水平面のばね（新規）
   P.m25 → 2-5 摩擦のある斜面を糸で引き上げる（新規）
   ※ P.m16 は使わなくなった（もとの円筒面）。 */

/* ============ 1-4 滑台（直線）2：斜面を昇る ============
   デコピンで初速度 v0 をもらって、なめらかな斜面を昇る。
   斜面にそった加速度 a = −g sinθ。止まる位置までの距離 L = v0²/(2g sinθ)、
   ★上がる高さ h = L sinθ = v0²/(2g) は θ によらない★（1-3 の裏返し）。 */
P.slopeUp = {
  a: function (v) { return G * Math.sin(v.th * DEG); },      /* 減速の大きさ */
  tEnd: function (v) { return v.v0 / P.slopeUp.a(v); },      /* 止まるまで */
  len: function (v) { return v.v0 * v.v0 / (2 * P.slopeUp.a(v)); },   /* ★式で出す★ */
  hTop: function (v) { return v.v0 * v.v0 / (2 * G); },      /* ★θ によらない★ */
  sample: function (v, t) {
    var T = P.slopeUp.tEnd(v), tt = clamp(t, 0, T), a = P.slopeUp.a(v);
    var s = v.v0 * tt - 0.5 * a * tt * tt;
    var sp = v.v0 - a * tt;
    var y = s * Math.sin(v.th * DEG);
    return EN.mix(v, { s: s, x: s * Math.cos(v.th * DEG), y: y, v: Math.max(0, sp),
      h: y, sp: 0, w: 0, a: -a });
  }
};

/* ============ 1-7 ジェットコースター（★第5回で作り直し★）============
   なめらかな軌道。水平面を速さ v0 で走ってきて、鉛直な円（ループ）を1周し、
   そのあと斜面を昇って止まる。
   ★経路にそった座標 s の1本で表す★ 加速度は a(s) = −g·(dy/ds)。
     s < L1                     水平面（y = 0）
     L1 ≤ s < L1+2πR            ループ（φ=(s−L1)/R、y = R(1−cosφ)）
     L1+2πR ≤ s < L1+2πR+L2     水平面
     それより先                 斜面（y = (s−s3)sinθ）
   ★答えは式で出す★
     ループの頂上 B：v_B = √(v0² − 2gD)（D＝ループの直径）
     止まる高さ  C：h_C = v0²/(2g)（★θ によらない★）
   ★ループを1周できる条件★ v_B² ≥ gR。v0 の範囲はこれを必ず満たすようにとってある。 */
P.coaster = {
  D: 7.5, L1: 6.0, L2: 4.0, DT: INT.DT,
  R: function () { return P.coaster.D / 2; },
  loopLen: function () { return 2 * Math.PI * P.coaster.R(); },
  /* ★斜面のつけ根はまるめる（半径 RF）★
     とがったままだと dy/ds が急に変わって、数値積分の E がずれる（0.05 % まで出た）。
     実物のコースターにも角はないので、絵としても正しくなる。 */
  RF: 1.2,
  /* 経路の s → {x, y, dyds, seg, phi, ang}（ang＝進む向きの角度[rad]、画面の上向きが正） */
  at: function (s, th) {
    var R = P.coaster.R(), L1 = P.coaster.L1, L2 = P.coaster.L2, LL = P.coaster.loopLen();
    var RF = P.coaster.RF, thr = th * DEG, sF = L1 + LL + L2, aLen = RF * thr;
    if (s <= L1) return { x: s, y: 0, dyds: 0, seg: 0, phi: 0, ang: 0 };
    if (s <= L1 + LL) {
      var phi = (s - L1) / R;
      return { x: L1 + R * Math.sin(phi), y: R * (1 - Math.cos(phi)),
        dyds: Math.sin(phi), seg: 1, phi: phi, ang: phi };
    }
    if (s <= sF) return { x: L1 + (s - L1 - LL), y: 0, dyds: 0, seg: 2, phi: 0, ang: 0 };
    if (s <= sF + aLen) {                      /* 斜面のつけ根のまるみ */
      var al = (s - sF) / RF;
      return { x: L1 + L2 + RF * Math.sin(al), y: RF * (1 - Math.cos(al)),
        dyds: Math.sin(al), seg: 3, phi: 0, ang: al };
    }
    var u = s - sF - aLen, si = Math.sin(thr), co = Math.cos(thr);
    return { x: L1 + L2 + RF * si + u * co, y: RF * (1 - Math.cos(thr)) + u * si,
      dyds: si, seg: 4, phi: 0, ang: thr };
  },
  /* 表の最後（＝止まる所）の経路長 */
  sEnd: function (v) { var tb = P.coaster.table(v); return tb[tb.length - 1].q; },
  _tab: memo1(function (v) {
    var dt = P.coaster.DT;
    return INT.verlet(function (q) { return -G * P.coaster.at(q, v.th).dyds; }, 0, v.v0, dt, 12000,
      function (q, w, i) { return i > 3 && w <= 0; });        /* 速さが 0（斜面の最高点） */
  }),
  table: function (v) { return P.coaster._tab([v.v0, v.th].join('|'), v); },
  /* 斜面の最高点（速さ 0）に着く時刻 */
  tTop: function (v) { var tb = P.coaster.table(v); return tb[tb.length - 1].t; },
  /* ★第18回・先生の指示★ 最高点で終わりにせず、「本来の続き」を見せる。
     なめらかなので、帰りは行きの巻きもどし（同じ道を逆にたどる）。
     最高点でいったん止まり、ループをもう一度くぐって、スタート地点 A まで
     帰ってくる。A にもどったときの速さは、はじめと同じ v0。 */
  tEnd: function (v) { return 2 * P.coaster.tTop(v); },
  /* 時刻 t を「行き（0〜tTop）」に折り返す。back = 帰り道 */
  fold: function (v, t) {
    var T1 = P.coaster.tTop(v);
    if (!(T1 > 1e-9)) return { u: 0, back: false };
    var u = clamp(t, 0, 2 * T1);
    if (u > T1) return { u: 2 * T1 - u, back: true };
    return { u: u, back: false };
  },
  tAt: function (v, sTarget) {
    var tb = P.coaster.table(v), i;
    for (i = 0; i < tb.length; i++) if (tb[i].q >= sTarget) return tb[i].t;
    return tb[tb.length - 1].t;
  },
  tB: function (v) { return P.coaster.tAt(v, P.coaster.L1 + P.coaster.loopLen() / 2); },
  /* ★答えは式で★ */
  vB: function (v) { return Math.sqrt(Math.max(0, v.v0 * v.v0 - 2 * G * P.coaster.D)); },
  hC: function (v) { return v.v0 * v.v0 / (2 * G); },
  /* 止まる所の水平の位置（斜面のつけ根 x = L1+L2 からの距離）。まるみの分も入れる */
  runC: function (v) {
    var RF = P.coaster.RF, thr = v.th * DEG, hC = P.coaster.hC(v), hF = RF * (1 - Math.cos(thr));
    if (hC <= hF) return RF * Math.sin(Math.acos(clamp(1 - hC / RF, -1, 1)));
    return RF * Math.sin(thr) + (hC - hF) / Math.sin(thr) * Math.cos(thr);
  },
  /* ループを1周できるか（頂上で v² ≥ gR） */
  loopOK: function (v) { return P.coaster.vB(v) * P.coaster.vB(v) >= G * P.coaster.R() - 1e-9; },
  vLoopMin: function () { return Math.sqrt(5 * G * P.coaster.R()); },  /* 頂上でのぎりぎりの速さ */
  /* 軌道から受ける垂直抗力。ループの上は N = m(v²/R + g cosφ) */
  Nof: function (v, m) {
    if (m.seg === 1) return v.m * (m.v * m.v / P.coaster.R() + G * Math.cos(m.phi));
    if (m.seg === 3) return v.m * (m.v * m.v / P.coaster.RF + G * Math.cos(m.ang));
    if (m.seg === 4) return v.m * G * Math.cos(v.th * DEG);
    return v.m * G;
  },
  sample: function (v, t) {
    var f = P.coaster.fold(v, t);
    var tb = P.coaster.table(v), r = INT.at(tb, f.u, P.coaster.DT), p = P.coaster.at(r.q, v.th);
    var q = EN.mix(v, { s: r.q, x: p.x, y: p.y, v: Math.max(0, r.w), h: p.y, sp: 0, w: 0,
      seg: p.seg, phi: p.phi, ang: p.ang, dyds: p.dyds, back: f.back });
    q.vs = f.back ? -q.v : q.v;                 /* 向きつきの速度（矢印の向きに使う） */
    return q;
  }
};

/* ============ 1-1 水平な面をただすべる物体 ============
   なめらかな床。力は重力と垂直抗力だけで、どちらも運動の向きに垂直（＝仕事をしない）。
   基準面＝床。h = 0 なので U = 0、K は一定。 */
P.m11 = {
  /* ★くらべる点 B と、アニメの終わりを分ける★（先生の指示・第8回）
     B で運動が終わると「そこで止まる」と思われるので、B のあとも床のはしまで走らせる。 */
  LB: 5.0,                        /* くらべる点 B の位置 [m] */
  LEN: 9.4,                       /* アニメの終わり（床のはし）[m] */
  tB: function (v) { return P.m11.LB / Math.max(0.2, v.v0); },
  tEnd: function (v) { return P.m11.LEN / Math.max(0.2, v.v0); },
  sample: function (v, t) {
    var x = v.v0 * t;
    return EN.mix(v, { x: x, y: 0, v: v.v0, h: 0, sp: 0, w: 0, a: 0 });
  },
  /* 答えとして見せる量は式で出す */
  xEnd: function (v) { return P.m11.LB; }
};

/* ============ 1-2 自由落下 ============
   基準面＝地面。h(t) = h − ½gt²、v = gt。 */
P.m12 = {
  tEnd: function (v) { return Math.sqrt(2 * v.h / G); },
  vEnd: function (v) { return Math.sqrt(2 * G * v.h); },       /* ★式で出す★ */
  sample: function (v, t) {
    var T = P.m12.tEnd(v), tt = clamp(t, 0, T);
    var drop = 0.5 * G * tt * tt;
    var y = v.h - drop;
    return EN.mix(v, { x: 0, y: y, v: G * tt, h: y, sp: 0, w: 0, a: G });
  }
};

/* ============ 1-3 滑り台（直線） ============
   なめらかな斜面。斜面にそった加速度 a = g sinθ。
   基準面＝地面（斜面の下端）。斜面の長さ L = h / sinθ。 */
P.m13 = {
  a: function (v) { return G * Math.sin(v.th * DEG); },
  len: function (v) { return v.h / Math.sin(v.th * DEG); },
  tEnd: function (v) { return Math.sqrt(2 * P.m13.len(v) / P.m13.a(v)); },
  vEnd: function (v) { return Math.sqrt(2 * G * v.h); },       /* ★θ によらない★ */
  sample: function (v, t) {
    var T = P.m13.tEnd(v), tt = clamp(t, 0, T), a = P.m13.a(v);
    var s = 0.5 * a * tt * tt;
    var y = v.h - s * Math.sin(v.th * DEG);
    return EN.mix(v, { s: s, x: s * Math.cos(v.th * DEG), y: y, v: a * tt, h: y, sp: 0, w: 0, a: a });
  }
};

/* ============ 1-4 滑り台（曲線） ============
   なめらかな曲面 y = h(1 − x/L)²（下で地面に接する）。
   弧長 s を変数にとると s'' = −g·(dy/ds) と「加速度が位置だけで決まる」形になるので、
   速度ベルレ法がそのまま使える。 */
P.m14 = {
  L: 4.0,                          /* 横のはば [m] */
  DT: INT.DT,
  curve: function (v) {
    var L = P.m14.L, h = v.h;
    return arcCurve(function (x) { return h * (1 - x / L) * (1 - x / L); },
      function (x) { return -2 * h * (1 - x / L) / L; }, 0, L, 900);
  },
  _tab: memo1(function (v) {
    var cv = P.m14.curve(v), dt = P.m14.DT;
    var tab = INT.verlet(function (s) { return -G * cv.at(s).dyds; }, 0, 0, dt, 6000,
      function (s) { return s >= cv.sMax; });
    return { tab: tab, cv: cv };
  }),
  table: function (v) { return P.m14._tab('h' + v.h, v); },
  tEnd: function (v) { var o = P.m14.table(v); return o.tab[o.tab.length - 1].t; },
  vEnd: function (v) { return Math.sqrt(2 * G * v.h); },       /* ★形によらない★ */
  sample: function (v, t) {
    var o = P.m14.table(v), r = INT.at(o.tab, t, P.m14.DT), p = o.cv.at(r.q);
    return EN.mix(v, { s: r.q, x: p.x, y: p.y, v: Math.abs(r.w), h: p.y, sp: 0, w: 0,
      a: r.a, dyds: p.dyds });
  }
};

/* ============ 1-5 振り子 ============
   θ'' = −(g/l) sinθ（θ は鉛直からの角、右が正）。糸の張力は運動の向きに垂直で仕事をしない。
   基準面＝最下点。h = l(1 − cosθ)。
   ★折り返しの点から積分して「ぴったり周期的」な表を作る★
   　（そうしないとくり返し再生でずれる）。 */
P.m15 = {
  DT: INT.DT,
  /* 折り返しの角（エネルギー保存から閉じた式で出す） */
  thTurn: function (v) {
    var c = Math.cos(v.th * DEG) - v.v0 * v.v0 / (2 * G * v.l);
    return Math.acos(clamp(c, -1, 1));
  },
  _tab: memo1(function (v) {
    var dt = P.m15.DT, thT = P.m15.thTurn(v), l = v.l;
    /* 折り返しの点（+thT, ω=0）から、反対がわの折り返しまで＝半周期。
       ★止める条件は「速度の向きが変わったとき」★
       　「θ ≤ −thT」で止めようとすると、離散化のせいでほんのわずか手前で折り返して
       　条件を満たさず、いつまでも積分が終わらない（実際にそうなった）。 */
    var tab = INT.verlet(function (q) { return -(G / l) * Math.sin(q); }, thT, 0, dt, 20000,
      function (q, w, i) { return i > 5 && w >= 0; });
    var Th = tab[tab.length - 1].t;
    /* はじめの状態（θ = th、最下点へ向かって動いている）が半周期のどこにあたるか */
    var th0 = v.th * DEG, i, t0 = 0;
    for (i = 0; i < tab.length; i++) { if (tab[i].q <= th0) { t0 = tab[i].t; break; } }
    return { tab: tab, Th: Th, t0: t0, thT: thT };
  }),
  table: function (v) { return P.m15._tab([v.th, v.v0, v.l].join('|'), v); },
  /* 1周期 */
  tEnd: function (v) { return 2 * P.m15.table(v).Th; },
  /* 最下点に来る時刻（はじめの点から数えて） */
  tBottom: function (v) { var o = P.m15.table(v); return o.Th / 2 - o.t0; },
  /* 最下点の速さ（★式で出す★） */
  vBottom: function (v) {
    return Math.sqrt(v.v0 * v.v0 + 2 * G * v.l * (1 - Math.cos(v.th * DEG)));
  },
  sample: function (v, t) {
    var o = P.m15.table(v), T = 2 * o.Th;
    var ph = (t + o.t0) % T;
    if (ph < 0) ph += T;
    var sgn = 1, r;
    if (ph <= o.Th) { r = INT.at(o.tab, ph, P.m15.DT); }
    else { r = INT.at(o.tab, ph - o.Th, P.m15.DT); sgn = -1; }
    var th = r.q * sgn, om = r.w * sgn;
    var h = v.l * (1 - Math.cos(th));
    return EN.mix(v, { th: th, om: om, x: v.l * Math.sin(th), y: -v.l * Math.cos(th),
      v: Math.abs(om) * v.l, h: h, sp: 0, w: 0 });
  }
};

/* ============ 2-1 摩擦がある水平な床 ============
   動摩擦力（非保存力）が負の仕事をする。すべて閉じた式で出せる。
   W摩擦 = −μ' m g x（x は進んだ距離）、止まる位置 L = v0²/(2μ'g)。 */
P.m21 = {
  a: function (v) { return -v.mu * G; },
  tStop: function (v) { return v.v0 / (v.mu * G); },
  xStop: function (v) { return v.v0 * v.v0 / (2 * v.mu * G); },   /* ★式で出す★ */
  tEnd: function (v) { return P.m21.tStop(v) * 1.15 + 0.25; },
  sample: function (v, t) {
    var ts = P.m21.tStop(v), tt = clamp(t, 0, ts);
    var x = v.v0 * tt - 0.5 * v.mu * G * tt * tt;
    var sp = v.v0 - v.mu * G * tt;
    var w = -v.mu * v.m * G * x;                                  /* 摩擦力がした仕事 */
    return EN.mix(v, { x: x, y: 0, v: sp, h: 0, sp: 0, w: w, a: (t < ts ? -v.mu * G : 0),
      moving: t < ts - 1e-9, f: v.mu * v.m * G, N: v.m * G });
  }
};

/* ============ 1-6 円筒面（内側を回る） ============
   なめらかな円筒の内側。θ は最下点からの角。θ'' = −(g/R) sinθ（振り子と同じ形）。
   垂直抗力 N/m = v²/R + g cosθ が負になったら面から離れて放物運動になる。
   ★一番上まで届くには v₀ ≥ √(5gR) が必要★ */
P.m16 = {
  R: 1.0, DT: INT.DT,
  vLoop: function () { return Math.sqrt(5 * G * P.m16.R); },
  _tab: memo1(function (v) {
    var R = P.m16.R, dt = P.m16.DT, i;
    var th = 0, om = v.v0 / R, arr = [], left = null;
    function acc(q) { return -(G / R) * Math.sin(q); }
    var a = acc(th);
    for (i = 0; i <= 5000; i++) {
      var t = i * dt;
      if (!left) {
        var x = R * Math.sin(th), y = R * (1 - Math.cos(th));
        var sp = Math.abs(om) * R;
        var vx = om * R * Math.cos(th), vy = om * R * Math.sin(th);
        var Nm = sp * sp / R + G * Math.cos(th);          /* N/m */
        arr.push({ t: t, x: x, y: y, vx: vx, vy: vy, v: sp, th: th, om: om, on: true, Nm: Nm });
        if (Nm < 0) { left = { x: x, y: y, vx: vx, vy: vy, t: t }; continue; }
        if (th >= 2 * Math.PI) break;
        var thN = th + om * dt + 0.5 * a * dt * dt;
        var aN = acc(thN);
        om = om + 0.5 * (a + aN) * dt;
        th = thN; a = aN;
      } else {
        var tt = t - left.t;
        var fx = left.x + left.vx * tt, fy = left.y + left.vy * tt - 0.5 * G * tt * tt;
        var fvy = left.vy - G * tt;
        arr.push({ t: t, x: fx, y: fy, vx: left.vx, vy: fvy, v: Math.hypot(left.vx, fvy),
          th: null, om: 0, on: false, Nm: 0 });
        if (fy <= 0 && tt > 0.02) break;
      }
    }
    /* 一周もせず、離れもしないとき（＝振り子のように往復する）は1周期で切る */
    var kind = left ? 'fly' : (arr[arr.length - 1].th >= 2 * Math.PI - 1e-6 ? 'loop' : 'swing');
    var tEnd = arr[arr.length - 1].t, turn = [];
    if (kind === 'swing') {
      for (i = 1; i < arr.length; i++) {
        if (arr[i - 1].om * arr[i].om <= 0) { turn.push(arr[i].t); if (turn.length >= 2) break; }
      }
      if (turn.length >= 2) tEnd = 2 * (turn[1] - turn[0]);
    }
    /* 一番高くなる時刻 */
    var tTop = 0, hi = -1;
    for (i = 0; i < arr.length && arr[i].t <= tEnd + 1e-9; i++) {
      if (arr[i].y > hi) { hi = arr[i].y; tTop = arr[i].t; }
    }
    return { tab: arr, kind: kind, tEnd: tEnd, tTop: tTop, hTop: hi };
  }),
  table: function (v) { return P.m16._tab('v' + v.v0, v); },
  tEnd: function (v) { return P.m16.table(v).tEnd; },
  tTop: function (v) { return P.m16.table(v).tTop; },
  kind: function (v) { return P.m16.table(v).kind; },
  sample: function (v, t) {
    var o = P.m16.table(v), r = INT.at(o.tab, t, P.m16.DT);
    return EN.mix(v, { x: r.x, y: r.y, v: r.v, h: r.y, sp: 0, w: 0,
      th: r.th, on: r.on, vx: r.vx, vy: r.vy, N: r.Nm * v.m });
  }
};

/* ============ 1-7 斜方投射 ============ 基準面＝地面。すべて閉じた式。 */
P.m17 = {
  vx: function (v) { return v.v0 * Math.cos(v.th * DEG); },
  vy0: function (v) { return v.v0 * Math.sin(v.th * DEG); },
  tTop: function (v) { return P.m17.vy0(v) / G; },
  tEnd: function (v) {
    var u = P.m17.vy0(v);
    return (u + Math.sqrt(u * u + 2 * G * v.h)) / G;
  },
  yTop: function (v) { return v.h + P.m17.vy0(v) * P.m17.vy0(v) / (2 * G); },
  vTop: function (v) { return P.m17.vx(v); },                      /* 最高点の速さ＝水平成分 */
  vEnd: function (v) { return Math.sqrt(v.v0 * v.v0 + 2 * G * v.h); },
  sample: function (v, t) {
    var T = P.m17.tEnd(v), tt = clamp(t, 0, T);
    var vx = P.m17.vx(v), vy = P.m17.vy0(v) - G * tt;
    var y = v.h + P.m17.vy0(v) * tt - 0.5 * G * tt * tt;
    return EN.mix(v, { x: vx * tt, y: y, vx: vx, vy: vy, v: Math.hypot(vx, vy),
      h: y, sp: 0, w: 0 });
  }
};

/* ============ 1-8 水平面ばね（単振動・閉じた式） ============
   基準面＝床（h = 0）。x は自然長からの変形。E = ½mv² + ½kx² が一定。 */
P.m18 = {
  om: function (v) { return Math.sqrt(v.k / v.m); },
  /* ★1.25周期で止める★ 終わりが「自然長を通るところ（＝くらべる点 B）」に来るので、
     最後の画面がそのまま B の説明になる。 */
  period: function (v) { return 2 * Math.PI / P.m18.om(v); },
  tEnd: function (v) { return 1.25 * P.m18.period(v); },
  tNat: function (v) { return Math.PI / 2 / P.m18.om(v); },        /* 自然長に来る時刻 */
  vMax: function (v) { return v.x0 * P.m18.om(v); },               /* ★式で出す★ */
  sample: function (v, t) {
    var w = P.m18.om(v), x = v.x0 * Math.cos(w * t), sp = -v.x0 * w * Math.sin(w * t);
    /* v は「速さ」（0以上）。向きつきは vs に入れる（矢印の向きに使う） */
    return EN.mix(v, { x: x, y: 0, v: Math.abs(sp), vs: sp, h: 0, sp: x, w: 0 });
  }
};

/* ============ 1-9 鉛直のばね（手をはなす・単振動） ============
   x は自然長からの伸び（下向き正）。つりあいの位置 x_eq = mg/k のまわりの単振動。
   基準面＝最下点なので h ≥ 0。 */
P.m19 = {
  xEq: function (v) { return v.m * G / v.k; },
  om: function (v) { return Math.sqrt(v.k / v.m); },
  xLow: function (v) { return 2 * P.m19.xEq(v) - v.d; },           /* 最下点の伸び */
  tEnd: function (v) { return 2 * Math.PI / P.m19.om(v); },
  tEq: function (v) { return Math.PI / 2 / P.m19.om(v); },         /* つりあいの位置に来る時刻 */
  tLow: function (v) { return Math.PI / P.m19.om(v); },            /* 最下点に来る時刻 */
  vEq: function (v) { return (P.m19.xEq(v) - v.d) * P.m19.om(v); },/* つりあいの位置での速さ（最大） */
  sample: function (v, t) {
    var w = P.m19.om(v), xe = P.m19.xEq(v);
    var x = xe + (v.d - xe) * Math.cos(w * t);
    var sp = -(v.d - xe) * w * Math.sin(w * t);
    /* ★基準面は「はじめの位置（手をはなす高さ）」★ 下がると高さは負になる */
    var h = v.d - x;
    /* v は「速さ」（0以上）。向きつきは vs（下向きが正） */
    return EN.mix(v, { x: x, y: -x, v: Math.abs(sp), vs: sp, h: h, sp: x, w: 0 });
  }
};

/* ============ 1-13 曲面から飛び出す ============
   ★第8回に形を作り直した★（先生の指摘）
   前は「半径 R の円のくぼみ」だけだったので、h > R にすると出発点が円の
   90°より上（オーバーハング）になり、静かにはなしても面にそって滑るという
   物理的にありえない動きになっていた（垂直抗力 0 なのに面から離れない）。
   いまは道を2つに分ける。
     ① 鉛直な壁（高さ h から R まで）… 自由落下（面は運動の向きと平行、N = 0）
     ② 円のくぼみ（θ = −90° → +60°）… 円の接線は壁とつながっていてなめらか
   道にそった座標 s で表し、加速度は a = −g·(dy/ds)。1-7 と同じ考え方。
     s < hw            壁：x = −R、y = h − s、dy/ds = −1
     s ≥ hw            円：θ = θ₀ + (s − hw)/R、x = R sinθ、y = R(1−cosθ)、dy/ds = sinθ
   （h ≤ R のときは壁がなく、θ₀ = −acos(1 − h/R)。h > R なら θ₀ = −90°）
   飛び出す点 C は θ = 60°、そのあとは放物運動。 */
P.m110 = {
  R: 2.0, PHI: 60 * Math.PI / 180, DT: INT.DT,
  alpha: function (v) { return Math.acos(clamp(1 - v.h / P.m110.R, -1, 1)); },
  /* 鉛直な壁の高さ（h が R より高いぶん） */
  wallH: function (v) { return Math.max(0, v.h - P.m110.R); },
  /* 円に入るときの角（壁があれば −90°） */
  th0: function (v) {
    return (v.h >= P.m110.R) ? -Math.PI / 2 : -P.m110.alpha(v);
  },
  /* 道にそった座標 s → 位置と傾き */
  at: function (v, s) {
    var R = P.m110.R, hw = P.m110.wallH(v);
    if (s < hw) return { x: -R, y: v.h - s, dyds: -1, th: -Math.PI / 2, wall: true };
    var q = P.m110.th0(v) + (s - hw) / R;
    return { x: R * Math.sin(q), y: R * (1 - Math.cos(q)), dyds: Math.sin(q), th: q, wall: false };
  },
  _tab: memo1(function (v) {
    var dt = P.m110.DT, PHI = P.m110.PHI, i;
    var sPos = 0, u = v.v0, arr = [], fly = null;
    var a = -G * P.m110.at(v, 0).dyds;
    for (i = 0; i <= 6000; i++) {
      var t = i * dt;
      if (!fly) {
        var p = P.m110.at(v, sPos);
        var vx = p.wall ? 0 : u * Math.cos(p.th);
        var vy = p.wall ? -u : u * Math.sin(p.th);
        arr.push({ t: t, x: p.x, y: p.y, vx: vx, vy: vy, v: Math.abs(u),
          th: p.th, on: true, wall: p.wall });
        if (!p.wall && p.th >= PHI) {
          /* 飛び出す点は「ちょうど 60°」にそろえる（式で出した答えとぴったり合わせるため）。
             速さはエネルギー保存の式 v_C = √(v0² + 2g(h − h_C)) から出す。 */
          var hC = P.m110.R * (1 - Math.cos(PHI));
          var vC = Math.sqrt(Math.max(0, v.v0 * v.v0 + 2 * G * (v.h - hC)));
          var xC = P.m110.R * Math.sin(PHI);
          fly = { x: xC, y: hC, vx: vC * Math.cos(PHI), vy: vC * Math.sin(PHI), t: t };
          arr[arr.length - 1] = { t: t, x: xC, y: hC, vx: fly.vx, vy: fly.vy,
            v: vC, th: PHI, on: true, wall: false };
          continue;
        }
        var sN = sPos + u * dt + 0.5 * a * dt * dt;
        var aN = -G * P.m110.at(v, sN).dyds;
        u = u + 0.5 * (a + aN) * dt;
        sPos = sN; a = aN;
      } else {
        var tt = t - fly.t;
        var fy = fly.y + fly.vy * tt - 0.5 * G * tt * tt;
        var fvy = fly.vy - G * tt;
        arr.push({ t: t, x: fly.x + fly.vx * tt, y: fy, vx: fly.vx, vy: fvy,
          v: Math.hypot(fly.vx, fvy), th: null, on: false, wall: false });
        if (fvy < 0 && fy <= fly.y) break;      /* 同じ高さまで下りたら終わり */
      }
    }
    var tB = 0, tC = fly ? fly.t : arr[arr.length - 1].t, tD = tC, hi = -1;
    for (i = 0; i < arr.length; i++) {
      /* 最下点を通る時刻（壁の上は θ = −90° のままなので、円に入ってからだけ見る） */
      if (arr[i].on && !arr[i].wall && arr[i].th <= 0) tB = arr[i].t;
      /* 最高点 D は「飛び出したあと」だけで探す（スタート地点 A の方が高いことがあるため） */
      if (!arr[i].on && arr[i].y > hi) { hi = arr[i].y; tD = arr[i].t; }
    }
    return { tab: arr, tB: tB, tC: tC, tD: tD, tEnd: arr[arr.length - 1].t, fly: fly };
  }),
  table: function (v) { return P.m110._tab([v.v0, v.h].join('|'), v); },
  tEnd: function (v) { return P.m110.table(v).tEnd; },
  tB: function (v) { return P.m110.table(v).tB; },
  tC: function (v) { return P.m110.table(v).tC; },
  tD: function (v) { return P.m110.table(v).tD; },
  /* 答えは式で出す */
  vB: function (v) { return Math.sqrt(v.v0 * v.v0 + 2 * G * v.h); },
  hC: function (v) { return P.m110.R * (1 - Math.cos(P.m110.PHI)); },
  vC: function (v) { return Math.sqrt(v.v0 * v.v0 + 2 * G * (v.h - P.m110.hC(v))); },
  /* 円のくぼみを通っているときの垂直抗力 [N]（面から外向き＝円の中心向きを正）。
     まん中向きの運動方程式：N − mg cos θ = m v² / R  →  N = m(g cos θ + v²/R)。
     ★くぼみ（凹の面）だから、|θ| < 90° では cos θ > 0 で、いつでも N > 0★
     ＝「面から離れる（N ≤ 0）」ことは起こらない。だから飛び出す所は
     「面がそこで切れている」C（θ = 60°）で決まる。90_boot.js の check() で見張る。
     壁（鉛直）の上は、まっすぐ落ちるだけなので N = 0。 */
  Nof: function (v, q) {
    if (!q || q.wall || q.th === null || q.th === undefined || !q.on) return 0;
    return v.m * (G * Math.cos(q.th) + q.v * q.v / P.m110.R);
  },
  hD: function (v) {
    var vc = P.m110.vC(v), s = Math.sin(P.m110.PHI);
    return P.m110.hC(v) + vc * vc * s * s / (2 * G);
  },
  sample: function (v, t) {
    var o = P.m110.table(v), r = INT.at(o.tab, t, P.m110.DT);
    return EN.mix(v, { x: r.x, y: r.y, v: r.v, h: r.y, sp: 0, w: 0,
      vx: r.vx, vy: r.vy, on: r.on, th: r.th, wall: !!r.wall });
  }
};

/* ============ 2-2 摩擦がある斜面（すべり上がる） ============
   斜面下端から斜面上向きに v0 ですべり上がり、やがて止まる。
   加速度の大きさ |a| = g(sinθ + μ' cosθ)。基準面＝出発点（斜面の下端）。 */
P.m22 = {
  aMag: function (v) { return G * (Math.sin(v.th * DEG) + v.mu * Math.cos(v.th * DEG)); },
  tStop: function (v) { return v.v0 / P.m22.aMag(v); },
  sStop: function (v) { return v.v0 * v.v0 / (2 * P.m22.aMag(v)); },     /* ★式で出す★ */
  tEnd: function (v) { return P.m22.tStop(v) * 1.15 + 0.25; },
  /* 止まったあとに、すべり下りるか（tanθ > μ' なら下りる）。この図では止まったところで終わる */
  slidesBack: function (v) { return Math.tan(v.th * DEG) > v.mu + 1e-12; },
  sample: function (v, t) {
    var ts = P.m22.tStop(v), tt = clamp(t, 0, ts), am = P.m22.aMag(v);
    var s = v.v0 * tt - 0.5 * am * tt * tt;
    var sp = v.v0 - am * tt;
    var N = v.m * G * Math.cos(v.th * DEG);
    var w = -v.mu * N * s;                                   /* 動摩擦力がした仕事 */
    return EN.mix(v, { s: s, x: s * Math.cos(v.th * DEG), y: s * Math.sin(v.th * DEG),
      v: sp, h: s * Math.sin(v.th * DEG), sp: 0, w: w,
      moving: t < ts - 1e-9, f: v.mu * N, N: N });
  }
};

/* ============ 2-3 鉛直のばね（手でゆっくり下ろす） ============
   ★この単元の山場★ 手（非保存力）が仕事をするので力学的エネルギーは保存しない。
   動きは「手で決めた動き」なので、なめらかな関数で与える（両はしで速さ 0）。
   手がした仕事 W は、E の変化とは別に「手の力 × 変位」を数値積分して出す
   （そうしないと E(t)−E(0)=W が“定義から自明”になって検算にならない）。 */
P.m23 = {
  T: 3.0, DT: 0.002,
  xEq: function (v) { return v.m * G / v.k; },
  u: function (t) { return clamp(t / P.m23.T, 0, 1); },
  x: function (v, t) { var u = P.m23.u(t); return v.d + (P.m23.xEq(v) - v.d) * u * u * (3 - 2 * u); },
  vel: function (v, t) {
    var u = P.m23.u(t);
    if (u <= 0 || u >= 1) return 0;
    return (P.m23.xEq(v) - v.d) * 6 * u * (1 - u) / P.m23.T;
  },
  accel: function (v, t) {
    var u = P.m23.u(t);
    if (u <= 0 || u >= 1) return 0;
    return (P.m23.xEq(v) - v.d) * 6 * (1 - 2 * u) / (P.m23.T * P.m23.T);
  },
  /* 手の力（上向きの大きさ）＝ mg − kx − m·(下向きの加速度) */
  fHand: function (v, t) { return v.m * G - v.k * P.m23.x(v, t) - v.m * P.m23.accel(v, t); },
  _tab: memo1(function (v) {
    var dt = P.m23.DT, n = Math.round(P.m23.T / dt), i, W = 0, arr = [{ t: 0, W: 0 }];
    for (i = 1; i <= n; i++) {
      var t0 = (i - 1) * dt, t1 = i * dt;
      /* W = ∫ F・dx。手の力は上向き、変位は下向きなので負の仕事になる */
      var p0 = -P.m23.fHand(v, t0) * P.m23.vel(v, t0);
      var p1 = -P.m23.fHand(v, t1) * P.m23.vel(v, t1);
      W += (p0 + p1) / 2 * dt;
      arr.push({ t: t1, W: W });
    }
    return arr;
  }),
  table: function (v) { return P.m23._tab([v.d, v.k, v.m].join('|'), v); },
  W: function (v, t) { return INT.at(P.m23.table(v), clamp(t, 0, P.m23.T), P.m23.DT).W; },
  /* 手がした仕事の答え（式）：Wは −½k(x_eq² − d²) + mg(x_eq − d) の符号付き…
     ゆっくり下ろす（両はしで K=0）ので W = E2 − E1 に等しい */
  tEnd: function () { return P.m23.T; },
  xLow: function (v) { return P.m19.xLow(v); },       /* 手をはなしたときの最下点（見くらべ用） */
  sample: function (v, t) {
    var tt = clamp(t, 0, P.m23.T);
    var x = P.m23.x(v, tt), sp = P.m23.vel(v, tt);
    /* ★基準面は 1-10 と同じ「はじめの位置」★ 下がると高さは負になる */
    var h = v.d - x;
    return EN.mix(v, { x: x, y: -x, v: Math.abs(sp), vs: sp, h: h, sp: x, w: P.m23.W(v, tt),
      fh: P.m23.fHand(v, tt) });
  }
};

/* ============ 2-4 摩擦がある水平面のばね（1-9 の摩擦あり版） ============
   x は自然長からの伸び。動摩擦力の大きさ f = μ' m g は一定なので、
   半周期ごとに「中心が ±f/k にずれた単振動」になる（＝閉じた式で書ける）。
   ★はじめの伸び x0 から自然長を通るときの速さ★
     ½kx0² = ½mv² + μ' m g x0  →  v = √((k x0² − 2 μ' m g x0)/m)
   変数の範囲は x0 > 2f/k になるようにとってある（必ず自然長を通る）。 */
P.m24 = {
  om: function (v) { return Math.sqrt(v.k / v.m); },
  f: function (v) { return v.mu * v.m * G; },
  xc: function (v) { return P.m24.f(v) / v.k; },              /* 振動の中心のずれ */
  period: function (v) { return 2 * Math.PI / P.m24.om(v); },
  /* ★第14回・先生の指示★ 何往復も見せると、動摩擦力の仕事（＝力×動いた道のり）を
     求めるのが難しくなって、生徒には分かりにくい。そこで再生を2段に分けた。
       ① 0 〜 tStop            … 止まるまで、ふつうに動かす
       ② tStop 〜 +HOLD        … 止まった所でひと呼吸おく
       ③ そのあと tNat のぶん  … もう一度はじめから再生して、点 B（はじめて自然長を
                                  通る瞬間）でぴたりと止める（そこで吹きだしが出る）
     グラフの横軸は ① だけ（d.tGraph）。 */
  HOLD: 0.6,
  tGraph: function (v) { return P.m24.tStop(v); },
  tEnd: function (v) { return P.m24.tStop(v) + P.m24.HOLD + P.m24.tNat(v); },
  tNat: function (v) {                                        /* はじめて自然長を通る時刻 */
    var xc = P.m24.xc(v), A = v.x0 - xc;
    return Math.acos(clamp(-xc / A, -1, 1)) / P.m24.om(v);
  },
  /* はじめの半周期のうちに、伸びが x になる時刻（とちゅうの姿を描く場所決めに使う） */
  tAtX: function (v, xT) {
    var xc = P.m24.xc(v), A = v.x0 - xc;
    return Math.acos(clamp((xT - xc) / A, -1, 1)) / P.m24.om(v);
  },
  vNat: function (v) {                                        /* ★式で出す★ */
    return Math.sqrt(Math.max(0, (v.k * v.x0 * v.x0 - 2 * P.m24.f(v) * v.x0) / v.m));
  },
  /* 半周期ごとの区間。x(t) = c + A cos(ω(t − t0))、p0＝その区間までに動いた道のり */
  _segs: memo1(function (v) {
    var om = P.m24.om(v), xc = P.m24.xc(v), half = Math.PI / om;
    var segs = [], cross = [], x = v.x0, sg = 1, t0 = 0, p0 = 0, i;
    for (i = 0; i < 400; i++) {
      var c = sg * xc, A = x - c;
      if (Math.abs(A) < 1e-12) break;
      segs.push({ t0: t0, c: c, A: A, p0: p0 });
      /* この区間で自然長（x = 0）を通る時刻 */
      if (Math.abs(c / A) <= 1) cross.push(t0 + Math.acos(-c / A) / om);
      x = c - A;                                  /* 半周期あとの折り返し点 */
      p0 += Math.abs(2 * A); t0 += half; sg = -sg;
      if (Math.abs(x) <= xc + 1e-12) break;       /* 静止摩擦でそこに止まる */
    }
    return { segs: segs, half: half, tStop: t0, xStop: x, path: p0, cross: cross };
  }),
  tab: function (v) { return P.m24._segs([v.x0, v.k, v.m, v.mu].join('|'), v); },
  xStop: function (v) { return P.m24.tab(v).xStop; },
  tStop: function (v) { return P.m24.tab(v).tStop; },
  pathAll: function (v) { return P.m24.tab(v).path; },
  sample: function (v, t) {
    var T = P.m24.tab(v), om = P.m24.om(v), x, sp, path;
    /* ★2回目の再生★（第14回）止まって HOLD だけおいたら、はじめにもどして
       点 B（tNat）まで もう一度動かす。時刻を先頭にまきもどすだけ。 */
    var rep = false;
    if (t > T.tStop + P.m24.HOLD) {
      t = Math.min(t - T.tStop - P.m24.HOLD, P.m24.tNat(v));
      rep = true;
    }
    if (t >= T.tStop || !T.segs.length) { x = T.xStop; sp = 0; path = T.path; }
    else {
      var sg = T.segs[clamp(Math.floor(t / T.half), 0, T.segs.length - 1)];
      var tau = t - sg.t0;
      x = sg.c + sg.A * Math.cos(om * tau);
      sp = -sg.A * om * Math.sin(om * tau);
      path = sg.p0 + Math.abs(sg.A) * (1 - Math.cos(om * tau));
    }
    /* v は「速さ」（0以上）。向きつきは vs。摩擦の仕事は −f×（動いた道のり） */
    return EN.mix(v, { x: x, y: 0, v: Math.abs(sp), vs: sp, h: 0, sp: x,
      w: -P.m24.f(v) * path, path: path, replay: rep,
      moving: t < T.tStop - 1e-9, f: P.m24.f(v), N: v.m * G });
  }
};

/* ============ 2-5 摩擦がある斜面を、糸で引き上げる ============
   斜面にそって一定の力 F で引き上げる。動摩擦力は運動と逆（斜面下向き）。
   a = (F − mg sinθ − μ' mg cosθ)/m（一定）。基準面＝出発点（斜面の下端）。
   引く距離 L は 3.0 m で固定（斜面の見た目を変数で変えないため）。
   ★変数の範囲は F > mg(sinθ + μ' cosθ) になるようにとってある（必ず動きだす）★ */
P.m25 = {
  L: 3.0,
  N: function (v) { return v.m * G * Math.cos(v.th * DEG); },
  fr: function (v) { return v.mu * P.m25.N(v); },
  need: function (v) { return v.m * G * Math.sin(v.th * DEG) + P.m25.fr(v); },
  a: function (v) { return (v.Ft - P.m25.need(v)) / v.m; },
  tEnd: function (v) { return Math.sqrt(2 * P.m25.L / P.m25.a(v)); },
  vEnd: function (v) { return Math.sqrt(2 * P.m25.a(v) * P.m25.L); },   /* ★式で出す★ */
  sample: function (v, t) {
    var a = P.m25.a(v), tt = clamp(t, 0, P.m25.tEnd(v));
    var s = 0.5 * a * tt * tt, sp = a * tt;
    var si = Math.sin(v.th * DEG), co = Math.cos(v.th * DEG);
    /* 非保存力（糸の力と動摩擦力）がした仕事 */
    var w = (v.Ft - P.m25.fr(v)) * s;
    return EN.mix(v, { s: s, x: s * co, y: s * si, v: sp, h: s * si, sp: 0, w: w,
      moving: true, f: P.m25.fr(v), N: P.m25.N(v), Ft: v.Ft, a: a });
  }
};

/* ============ 1-10 水平ばねにぶつかる（★第5回・新規★）============
   なめらかな水平面を速さ v0 で走ってきて、壁につけたばねにぶつかって縮める。
   ・ぶつかるまで（A → B）：力は重力と垂直抗力だけ（どちらも運動と垂直）→ 速さは変わらない。
   ・ぶつかってから：単振動の4分の1周期で最大の縮み x_max に達する（C）。
   ★答えは式で出す★ ½mv0² = ½k x_max² → x_max = v0√(m/k)
   そのあと同じだけ押しもどされ、速さ v0 で左へ帰っていく（見せて確かめさせる）。 */
P.hitSpring = {
  D0: 1.2,                                    /* ぶつかるまでの距離（絵の都合で固定） */
  om: function (v) { return Math.sqrt(v.k / v.m); },
  xMax: function (v) { return v.v0 / P.hitSpring.om(v); },      /* ★式で出す★ = v0√(m/k) */
  t1: function (v) { return P.hitSpring.D0 / v.v0; },           /* ぶつかる時刻 */
  tC: function (v) { return P.hitSpring.t1(v) + Math.PI / 2 / P.hitSpring.om(v); },
  tOut: function (v) { return P.hitSpring.t1(v) + Math.PI / P.hitSpring.om(v); }, /* はなれる時刻 */
  tEnd: function (v) { return P.hitSpring.tOut(v) + 0.6 * P.hitSpring.t1(v); },
  sample: function (v, t) {
    var om = P.hitSpring.om(v), t1 = P.hitSpring.t1(v), A = P.hitSpring.xMax(v);
    var tOut = P.hitSpring.tOut(v), u, sp;
    if (t <= t1) { u = -P.hitSpring.D0 + v.v0 * t; sp = v.v0; }
    else if (t <= tOut) { var q = om * (t - t1); u = A * Math.sin(q); sp = v.v0 * Math.cos(q); }
    else { u = -v.v0 * (t - tOut); sp = -v.v0; }
    /* u > 0 のときだけ、ばねが u だけ縮んでいる */
    return EN.mix(v, { x: u, y: 0, v: Math.abs(sp), vs: sp, h: 0, sp: Math.max(0, u), w: 0,
      touch: u > 0 });
  }
};

/* ============ 1-11 水平ばねと滑台（★第5回・新規★）============
   なめらかな面。ばねを x0 だけ縮めて静かにはなす。
   ・A（スタート・縮めた状態）→ B（自然長にもどってばねから離れる瞬間）
     ：単振動の4分の1周期。★½k x0² = ½m v_B²★ → v_B = x0√(k/m)
   ・B →（平らな床）→ C（曲面の最高点。v = 0）
     ：★½m v_B² = mg h_C★ → h_C = k x0²/(2mg)
   曲面は y = C x²（0 ≤ x ≤ XTOP）で固定。変数の範囲は h_C < 曲面の高さになるようにとってある。 */
P.sprSlide = {
  /* ★滑台は「30° のまっすぐな坂」★（先生の指示・第8回）
     前は放物線（y = 0.75x²）で、止まる高さのあたりの傾きが 67° もあった。
     つけ根は半径 RF でまるめる（dy/ds に角があると数値積分で E がずれるため。㉓）。
       x ≤ x_F …… 円（半径 RF）  y = RF − √(RF² − x²)
       x > x_F …… 直線 30°       y = RF(1−cosθ) + (x − x_F)tanθ
     どちらも y' が x_F でつながるので、なめらか。 */
  TH: 30, RF: 0.6, XTOP: 3.3, LF: 1.2, DT: INT.DT,
  th: function () { return P.sprSlide.TH * DEG; },
  xF: function () { return P.sprSlide.RF * Math.sin(P.sprSlide.th()); },
  yAt: function (x) {
    var R = P.sprSlide.RF, th = P.sprSlide.th(), xf = P.sprSlide.xF();
    if (x <= xf) return R - Math.sqrt(Math.max(0, R * R - x * x));
    return R * (1 - Math.cos(th)) + (x - xf) * Math.tan(th);
  },
  dyAt: function (x) {
    var R = P.sprSlide.RF, th = P.sprSlide.th(), xf = P.sprSlide.xF();
    if (x <= xf) return x / Math.sqrt(Math.max(1e-9, R * R - x * x));
    return Math.tan(th);
  },
  /* 高さ h に対応する坂の上の x（吹きだし・印を置くのに使う） */
  xOfH: function (h) {
    var R = P.sprSlide.RF, th = P.sprSlide.th(), xf = P.sprSlide.xF();
    var yf = R * (1 - Math.cos(th));
    if (h <= yf) return Math.sqrt(Math.max(0, R * R - (R - h) * (R - h)));
    return xf + (h - yf) / Math.tan(th);
  },
  yTop: function () { return P.sprSlide.yAt(P.sprSlide.XTOP); },
  om: function (v) { return Math.sqrt(v.k / v.m); },
  vB: function (v) { return v.x0 * P.sprSlide.om(v); },          /* ★式で出す★ */
  hC: function (v) { return v.k * v.x0 * v.x0 / (2 * v.m * G); },/* ★式で出す★ */
  t1: function (v) { return Math.PI / 2 / P.sprSlide.om(v); },   /* ばねから離れる時刻 */
  t2: function (v) { return P.sprSlide.t1(v) + P.sprSlide.LF / P.sprSlide.vB(v); },
  _curve: null,
  curve: function () {
    if (!P.sprSlide._curve) {
      P.sprSlide._curve = arcCurve(P.sprSlide.yAt, P.sprSlide.dyAt, 0, P.sprSlide.XTOP, 900);
    }
    return P.sprSlide._curve;
  },
  _tab: memo1(function (v) {
    var cv = P.sprSlide.curve();
    return INT.verlet(function (q) { return -G * cv.at(q).dyds; }, 0, P.sprSlide.vB(v),
      P.sprSlide.DT, 6000, function (q, w, i) { return i > 3 && w <= 0; });
  }),
  table: function (v) { return P.sprSlide._tab([v.x0, v.k, v.m].join('|'), v); },
  tC: function (v) { var tb = P.sprSlide.table(v); return P.sprSlide.t2(v) + tb[tb.length - 1].t; },
  /* ★第18回・先生の指示★ 最高点で終わりにせず、「本来の続き」を見せる。
     なめらかなので運動はくり返す。行き（0〜tC）と帰り（tC〜2tC）は同じ道で、
     2tC でばねがもう一度いちばん縮む（＝A にもどる）。周期は 2tC なので、
     最高点に着くのは tC, 3tC, 5tC…。ここでは【2回目の最高点】3tC で終わりにする。
       0  〜 tC  … A →(ばねがのびる)→ B →(平ら)→ C（1回目の最高点）
       tC 〜 2tC … C →(下る)→ B →(平ら)→ A（もう一度ばねを縮める）
       2tC〜 3tC … A → B → C（2回目の最高点）でおしまい */
  tEnd: function (v) { return 3 * P.sprSlide.tC(v); },
  /* 時刻 t を「行き（0〜tC）」に折り返す。back = もどっている途中 */
  fold: function (v, t) {
    var TC = P.sprSlide.tC(v), PER = 2 * TC;
    if (!(PER > 1e-9)) return { u: 0, back: false };
    var u = clamp(t, 0, 3 * TC) % PER;
    if (u > TC) return { u: PER - u, back: true };
    return { u: u, back: false };
  },
  sample: function (v, t) {
    var f = P.sprSlide.fold(v, t);
    var q = P.sprSlide._fwd(v, f.u);
    q.back = f.back;
    q.vs = f.back ? -q.v : q.v;                 /* 向きつきの速度（矢印の向きに使う） */
    return q;
  },
  _fwd: function (v, t) {
    var om = P.sprSlide.om(v), t1 = P.sprSlide.t1(v), t2 = P.sprSlide.t2(v);
    var X, Y, sp2, spd, seg;
    if (t <= t1) {
      /* ばねの上：u = −x0 cos(ωt)（自然長の位置を 0 とする） */
      X = -v.x0 * Math.cos(om * t); Y = 0; spd = v.x0 * om * Math.sin(om * t);
      sp2 = -X; seg = 0;                       /* 縮み（正の値） */
    } else if (t <= t2) {
      X = P.sprSlide.vB(v) * (t - t1); Y = 0; spd = P.sprSlide.vB(v); sp2 = 0; seg = 1;
    } else {
      var tb = P.sprSlide.table(v), r = INT.at(tb, t - t2, P.sprSlide.DT);
      var p = P.sprSlide.curve().at(r.q);
      X = P.sprSlide.LF + p.x; Y = p.y; spd = Math.max(0, r.w); sp2 = 0; seg = 2;
      var dd = p.dyds;
      return EN.mix(v, { x: X, y: Y, v: spd, h: Y, sp: 0, w: 0, seg: seg, dyds: dd,
        cx: p.x, s: r.q });
    }
    return EN.mix(v, { x: X, y: Y, v: spd, h: Y, sp: sp2, w: 0, seg: seg, dyds: 0 });
  }
};
