/* モード2　非保存力が仕事をするケース（力学的エネルギーが保存されない） */
'use strict';

/* 2-5 の斜面の縮尺 [px/m]。★固定★（θ を変えても坂の長さは変えない）
   θ = 45° でも高さが入り、θ = 20° でも横幅が入る値にしてある。 */
var SC_PULL = 76;
/* 斜面は引く長さ L より少し長く描く（上のはしに巻き上げ機を置くため） */
var SMAX_PULL = 1.55;   /* 第7回：手が物体といっしょに上がるので、坂を長めに描く */

/* ============ 2-1 摩擦がある水平な床 ============ */
DEFS['m2-1'] = {
  id: 'm2-1', mode: 2, tab: '2-1 摩擦がある水平な床',
  title: '2-1　摩擦がある水平な床',
  sub: '粗い床の上をすべる物体。<b>動摩擦力は非保存力</b>で、進む向きと逆を向いているので<b>負の仕事</b>をします。' +
    'その仕事の分だけ力学的エネルギーが減り、減った分は<b>熱</b>になって逃げていきます。' +
    '止まる位置は $\\tfrac12mv_0^{\\,2}=\\mu\' mgL$ から <b>$L=v_0^{\\,2}/(2\\mu\' g)$</b>。',
  cw: 520, ch: 372,        /* 第7回：mg の矢印を長くしたぶん、下を広げた */
  vis: ['F', 'V', 'A'],
  mainVars: ['v0', 'mu'],
  mainVarFocus: 'mu',
  vars: [
    { k: 'v0', label: 'はじめの速さ $v_0$', unit: ' m/s', min: 3, max: 7, step: 0.5, dec: 1, def: 6.0 },
    { k: 'mu', label: '動摩擦係数 $\\mu\'$', unit: '', min: 0.2, max: 0.5, step: 0.05, dec: 2, def: 0.20 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 5, step: 0.5, dec: 1, def: 2.0 }
  ],
  actions: [
    { label: 'ざらざらの床にする（μ′＝0.50）', fn: function (s) { s.v.mu = 0.50; },
      is: function (v) { return Math.abs(v.mu - 0.50) < 1e-9; },
      next: function (s) { return s._played && Math.abs(s.v.mu - 0.50) > 1e-9; } },
    { label: '少しざらざらに（μ′＝0.35）', fn: function (s) { s.v.mu = 0.35; },
      is: function (v) { return Math.abs(v.mu - 0.35) < 1e-9; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.v0 = 6; s.v.mu = 0.20; },
      is: function (v) { return Math.abs(v.v0 - 6) < 1e-9 && Math.abs(v.mu - 0.20) < 1e-9; } }
  ],
  cons: false,
  forces: ['g', 'N', 'fr'],
  hintFig: '<b>減った力学的エネルギーは熱になって逃げる</b>（図のエネルギーの棒のグレー＝$|W_{\\text{非保存}}|$）',
  wName: '動摩擦力',
  wSym: "-\\mu' mgL",
  step1: '動摩擦力（非保存力）が、進む向きと逆向きに負の仕事をしている',
  datum: '床（物体のある水平面）',
  hint2: '<b>次は</b>：$\\mu\'$ を変えて、<b>止まる位置</b>と<b>E–t 図の下がり方</b>がどう変わるか見てみよう。',
  tEnd: function (v) { return P.m21.tEnd(v); },
  sample: function (v, t) { return P.m21.sample(v, t); },
  pts: [
    { name: 'A', jp: 'スタート', t: function () { return 0; },
      sym: { K: '\\tfrac{1}{2}mv_0^{\\,2}', Ug: '0' } },
    { name: 'B', jp: '止まる位置', t: function (v) { return P.m21.tStop(v); },
      sym: { K: '0', Ug: '0' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m2-1'], v = V(s), m = d.sample(v, t);
    /* ★縮尺は固定★（自動にすると、いつも同じ場所で止まって見えてスライドバーが効かない） */
    var SCX = 26.4, gy = H - 128, x0 = 64;
    function X(x) { return x0 + x * SCX; }
    var kz = mSize(d, v), bw = 34 * kz, bh = 24 * kz;
    var L = P.m21.xStop(v);

    /* 粗い床（ハッチ＋つぶつぶ） */
    ground(ctx, 20, W - 96, gy);
    ctx.save();
    ctx.fillStyle = '#9aa3ac';
    for (var g2 = 26; g2 < W - 100; g2 += 9) {
      ctx.beginPath(); ctx.arc(g2, gy - 2.2, 1.5, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
    datumLine(ctx, 20, W - 96, gy, '基準面 h = 0', false, true);
    axisX(ctx, X, gy + 86, 0, Math.min(12.5, (W - 110 - x0) / SCX), 'x [m]', 1, { step: 2 });

    /* ★印は物体の横★（第6回）上下は mg・N の矢印が通るので、外側の横に置く */
    ptMark(ctx, 'A', X(0) - bw / 2 - 13, gy - bh / 2);
    ptMark(ctx, 'B', X(L) + bw / 2 + 13, gy - bh / 2);

    var i;
    for (i = 1; i * 0.2 < t - 1e-9; i++) {
      ctx.save(); ctx.globalAlpha = 0.26;
      blockShape(ctx, X(d.sample(v, i * 0.2).x), gy - bh / 2, 0, bw, bh, '#f2f4f7');
      ctx.restore();
    }
    var cx = X(m.x), cy = gy - bh / 2;
    blockShape(ctx, cx, cy, 0, bw, bh, '#e8eef5');
    flickStart(ctx, t, v.v0, X(0) - bw / 2 - 20, cy, 0, 152);   /* L の寸法線より上に出す */

    /* ★力の縮尺は大きめにとる★（先生の指摘・第7回）
       もとは「mg が 30 px」だったが、動摩擦力 μ'N は mg の 1/5〜1/3 しかないので
       5〜10 px にしかならず、いちばん見せたい力が見えなかった。
       矢印の長さの比は力の比のまま（★量に比例★ レイアウト規約 ㉞）。 */
    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 62 / mg;
    function fAt(qq, ax) {
      arrow(ctx, ax, cy, ax, cy + mg * fs, 'force');
      label(ctx, 'mg', ax, cy + mg * fs + 11, { size: 11.5, color: COL.force });
      arrow(ctx, ax, gy, ax, gy - mg * fs, 'force', 1, COL.norm);
      label(ctx, 'N', ax + bw / 2 + 8, gy - mg * fs + 4, { align: 'left', size: 11.5, color: COL.norm });
      if (qq.moving) {
        var fl = qq.f * fs;
        arrow(ctx, ax, gy - 3, ax - fl, gy - 3, 'force', 1, COL.fric);
        label(ctx, "μ'N", ax - fl - 8, gy - 16,
          { align: 'right', size: 11.5, color: COL.fric });
      }
    }
    if (s.o.showF) fAt(m, cx);
    if (s.o.showV && m.v > 0.05) {
      var vl = vArrowLen(m.v, 7, 54);
      /* ★N の矢じりより上に出す★ N の長さは力の縮尺で変わるので、そこから決める */
      var va = velArrow(ctx, cx, cy, 0, -1, mg * fs - bh / 2 + 22, 1, 0, vl);
      label(ctx, 'v', va.tx + 10, va.ty, { align: 'left', size: 11.5, color: COL.vel });
    }
    var aOff21 = mg * fs - bh / 2 + 46;      /* 速度の矢印よりさらに外がわ */
    if (s.o.showA && m.moving) drawAcc(ctx, cx, cy, -v.mu * G, 0, { nx: 0, ny: -1, off: aOff21 });
    else if (s.o.showA) label(ctx, 'a = 0', cx, cy - aOff21,
      { size: 11.5, color: COL.acc, avoid: true });
    if (hintOn(s, t)) {
      /* 止まる位置は「答え」なので、スタートを押してから出す */
      ctx.save();
      ctx.strokeStyle = fade(COL.areaNeg, 0.9); ctx.lineWidth = 1.4; ctx.setLineDash([5, 4]);
      ctx.beginPath(); ctx.moveTo(X(L), gy - 112); ctx.lineTo(X(L), gy + 6); ctx.stroke();
      ctx.restore();
      arrow(ctx, X(0), gy - 120, X(L), gy - 120, 'dim');
      arrow(ctx, X(L), gy - 120, X(0), gy - 120, 'dim');
      label(ctx, "L = v₀²/(2μ'g) = " + fmt(L, 2) + ' m', (X(0) + X(L)) / 2, gy - 130,
        { size: 11.5, color: COL.dim });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    drawPts(ctx, d, s, t, function (p) {
      var A = (p.name === 'A');
      return { x: X(A ? 0 : L) + (A ? -1 : 1) * (bw / 2 + 13), y: gy - bh / 2,
        ox: X(A ? 0 : L), oy: gy - bh / 2,
        fdraw: function () { fAt(d.sample(v, p.t), X(A ? 0 : L)); },
        bw: bw, bh: bh, vx: 1, vy: 0, vref: 7, vk: 54, voff: bw / 2 + 10 };
    });
  },
  /* ★モード2の見どころ★ とちゅうの状態で「動摩擦力が運動と逆向き」を見せる */
  midGhost: function (ctx, s) {
    var d = DEFS['m2-1'], v = V(s), tm = P.m21.tStop(v) * 0.5, m = d.sample(v, tm);
    /* ★ここの定数は draw とそろえる★ ずれると「とちゅうの姿」だけ別の場所に描かれる */
    var SCX = 26.4, gy = CVH - 128, x0 = 64;
    var kz = mSize(d, v), bw = 34 * kz, bh = 24 * kz;
    var cx = x0 + m.x * SCX, cy = gy - bh / 2, fs = 62 / (v.m * G);
    ctx.save(); ctx.globalAlpha = 0.9;
    blockShape(ctx, cx, cy, 0, bw, bh, '#f2f4f7');
    ctx.restore();
    var vl = vArrowLen(m.v, 7, 54);
    var va = velArrow(ctx, cx, cy, 0, -1, v.m * G * fs - bh / 2 + 22, 1, 0, vl);
    label(ctx, 'v', va.tx + 10, va.ty, { align: 'left', size: 11, color: COL.vel });
    var fl = m.f * fs;
    arrow(ctx, cx, gy - 3, cx - fl, gy - 3, 'force', 1, COL.fric);
    label(ctx, "μ'N", cx - fl - 8, gy - 16, { align: 'right', size: 11, color: COL.fric });
    /* 吹きだしは N の矢じりより上（A・B の印と重なるため。第7回）。
       ★第9回★ しっぽ（▼）の先は「動摩擦力の矢印の まん中の真上」にそろえる。
       説明している力が動摩擦力なので、そこを指していないと何の話か分からない。 */
    bubble(ctx, '力の向きが運動と逆 → 負の仕事！', cx - fl / 2, gy - v.m * G * fs - 30,
      { size: 11.5, bg: '#eef2f7', border: COL.eE, color: '#28323d' });
  },
  resItems: function (v) {
    return [
      { k: "動摩擦力 $\\mu' mg$", v: fmt(v.mu * v.m * G, 2) + ' N' },
      { k: "止まるまでの距離（式 $v_0^2/2\\mu' g$）", v: fmt(P.m21.xStop(v), 2) + ' m' }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m2-1'].sample(v, t);
    return [
      ['進んだ距離 $x$', fmt(m.x, 2) + ' m'],
      ['加速度 $-\\mu\' g$', fmt(-v.mu * G, 2) + ' m/s²'],
      ['止まる時刻', fmt(P.m21.tStop(v), 2) + ' s'],
      ['熱になったエネルギー', fmt(-m.W, 2) + ' J']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return "\\tfrac{1}{2}mv_0^{\\,2} = \\mu' mgL \\;\\Rightarrow\\; L = \\dfrac{v_0^{\\,2}}{2\\mu' g} = " +
      fmt(P.m21.xStop(v), 2) + '\\ \\mathrm{m}';
  },
  note: '動摩擦力は<b>非保存力</b>です。進む向きと逆を向いているので<b>負の仕事</b>をし、' +
    'その分だけ力学的エネルギーが減ります（<b>$E_2-E_1=W_{\\text{非保存}}$</b>）。' +
    'E–t 図が下がっていき、<b>下がった分が失われたエネルギー</b>＝熱になった分です' +
    '（図のエネルギーの棒では、その分をグレーに塗っています）。' +
    'ここでは高さが変わらないので $U=0$ のまま、$E$ の変化はそのまま $K$ の変化になります。'
};

/* ============ 2-2 摩擦がある斜面 ============ */
DEFS['m2-2'] = {
  id: 'm2-2', mode: 2, tab: '2-2 摩擦がある斜面',
  title: '2-2　摩擦がある斜面（すべり上がる）',
  sub: '粗い斜面を、下から斜面にそって速さ $v_0$ ですべり上がります。' +
    '重力（保存力）のほかに<b>動摩擦力（非保存力）が運動と逆向きにはたらいて負の仕事</b>をするので、' +
    '力学的エネルギーは保存されません。止まるまでの距離は ' +
    '$L=\\dfrac{v_0^{\\,2}}{2g(\\sin\\theta+\\mu\'\\cos\\theta)}$。',
  cw: 560, ch: 366,          /* 下にデコピンの手と mg の矢印が出るぶん、高くとる */
  vis: ['F', 'Fc', 'V', 'A'],
  mainVars: ['th', 'mu'],
  mainVarFocus: 'mu',
  vars: [
    { k: 'th', label: '斜面の角 $\\theta$', unit: '°', min: 15, max: 45, step: 5, dec: 0, def: 30 },
    { k: 'mu', label: '動摩擦係数 $\\mu\'$', unit: '', min: 0.10, max: 0.50, step: 0.05, dec: 2, def: 0.30 },
    { k: 'v0', label: 'はじめの速さ $v_0$', unit: ' m/s', min: 3, max: 7, step: 0.5, dec: 1, def: 6.0 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 5, step: 0.5, dec: 1, def: 2.0 }
  ],
  actions: [
    { label: 'ざらざらにする（μ′＝0.50）', fn: function (s) { s.v.mu = 0.50; },
      is: function (v) { return Math.abs(v.mu - 0.50) < 1e-9; },
      next: function (s) { return s._played && Math.abs(s.v.mu - 0.50) > 1e-9; } },
    { label: 'なめらかにする（μ′＝0.10）', fn: function (s) { s.v.mu = 0.10; },
      is: function (v) { return Math.abs(v.mu - 0.10) < 1e-9; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.th = 30; s.v.mu = 0.3; s.v.v0 = 6; },
      is: function (v) { return v.th === 30 && Math.abs(v.mu - 0.3) < 1e-9 && Math.abs(v.v0 - 6) < 1e-9; } }
  ],
  cons: false,
  forces: ['g', 'N', 'fr'],
  hintFig: '<b>動摩擦力が負の仕事をした分だけ $E$ が減る</b>。' +
    'なめらかな斜面（1-3）なら $E$ は減らず、もっと高くまで上がる',
  wName: '動摩擦力',
  wSym: "-\\mu' mg\\cos\\theta\\,L",
  step1: '重力のほかに、動摩擦力（非保存力）が運動と逆向きに負の仕事をしている',
  datum: '出発点（斜面の下端）',
  hint2: '<b>次は</b>：$\\mu\'$ を変えて、<b>止まる位置</b>と<b>失われるエネルギー</b>がどう変わるか見てみよう。',
  tEnd: function (v) { return P.m22.tEnd(v); },
  sample: function (v, t) { return P.m22.sample(v, t); },
  pts: [
    { name: 'A', jp: 'スタート（下端）', t: function () { return 0; },
      sym: { K: '\\tfrac{1}{2}mv_0^{\\,2}', Ug: '0' } },
    { name: 'B', jp: '止まる位置', t: function (v) { return P.m22.tStop(v); },
      hsym: 'L sinθ',                  /* ★式と図で同じ記号を使う★（第12回） */
      sym: { K: '0', Ug: 'mgL\\sin\\theta' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m2-2'], v = V(s), m = d.sample(v, t);
    /* ★縮尺は μ′ では変えない★
       斜面の長さは「いちばんなめらかなとき（μ′=0.10）に上がれる距離」で決める。
       こうすると μ′ を変えたときに、同じ坂の上で止まる場所だけが変わって見くらべられる。 */
    var th = v.th * DEG, gy = H - 98, x0 = 96;
    var ux = Math.cos(th), uy = -Math.sin(th);      /* 斜面を上る向き（画面の座標） */
    /* ★斜面から外向き★ 右上がりの坂では「左上」を向く（＝ux と直角）。
       第7回まで nx = +sin(th) と符号をまちがえていて、垂直抗力が斜面に垂直に
       ならず、物体も坂から少しずれて乗っていた（先生の指摘）。 */
    var nx = -Math.sin(th), ny = -Math.cos(th);
    var sRef = Math.min(9.0, v.v0 * v.v0 /
      (2 * G * (Math.sin(th) + 0.10 * Math.cos(th))) * 1.2);
    /* 第9回：右の余白が大きかったので上限 70 → 100 */
    var SC = Math.min(88, (W - 96 - x0 - 16) / Math.max(0.5, sRef * Math.cos(th)),
      (gy - 46) / Math.max(0.3, sRef * Math.sin(th)));
    function P2(sv) { return { x: x0 + ux * sv * SC, y: gy + uy * sv * SC }; }
    var L = P.m22.sStop(v), sMax = sRef;
    var top = P2(sMax);

    /* 斜面（粗い面） */
    ctx.save();
    ctx.fillStyle = '#eef1f4';
    ctx.beginPath(); ctx.moveTo(x0, gy); ctx.lineTo(top.x, top.y); ctx.lineTo(top.x, gy);
    ctx.closePath(); ctx.fill();
    ctx.restore();
    hatchLine(ctx, x0, gy, top.x, top.y, -1);
    ctx.save();
    ctx.fillStyle = '#9aa3ac';
    for (var q = 0.12; q < sMax; q += 0.22) {
      var pp = P2(q);
      ctx.beginPath(); ctx.arc(pp.x + nx * 2.4, pp.y + ny * 2.4, 1.5, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
    ground(ctx, 20, W - 96, gy);
    /* 基準面の字は右はしに置く（左は物体・手・寸法線でこみあうため） */
    datumLine(ctx, 20, W - 96, gy, '基準面 h = 0', true, true);
    angArc(ctx, x0, gy, 30, -th, 0, '', 0, 0);
    label(ctx, 'θ = ' + fmt(v.th, 0) + '°', x0 + 44, gy - 12, { size: 12, color: COL.sub, align: 'left' });

    var kz = mSize(d, v), bw = 30 * kz, bh = 22 * kz;
    var pA = P2(0), pB = P2(L);
    /* ★いちばん高い所に「最高点」の吹きだし★（先生の指示・第13回）しっぽは下 */
    if (endOn(d, s, t)) ptNote(ctx, pB.x, pB.y, '最高点', '（点B）', { gap: 56 });
    /* ★印は物体の「坂にそって外がわ」★（第6回）真上は N の矢印が通るのでずらす */
    var mkA = markAway(pA, pB, nx, ny, bh / 2 + 4, bw / 2 + 14);
    var mkB = markAway(pB, pA, nx, ny, bh / 2 + 4, bw / 2 + 14);
    ptMark(ctx, 'A', mkA.x, mkA.y);
    ptMark(ctx, 'B', mkB.x, mkB.y);

    /* ★式の $L$ が図のどこかを見せる★（先生の指示・第12回）
       $U_g = mgL\sin\theta$ の $L$（すべり上がった斜面にそった長さ）を、
       坂の内がわ（下）に両矢印でひく。答えなのでスタートを押してから出す。 */
    if (hintOn(s, t)) {
      var lo1 = { x: pA.x - nx * 30, y: pA.y - ny * 30 };
      var lo2 = { x: pB.x - nx * 30, y: pB.y - ny * 30 };
      arrow(ctx, lo1.x, lo1.y, lo2.x, lo2.y, 'dim');
      arrow(ctx, lo2.x, lo2.y, lo1.x, lo1.y, 'dim');
      /* 文字は「θ = ○°」の弧を避けて、坂の 0.62 くらいの所に置く */
      label(ctx, 'L = ' + fmt(L, 2) + ' m', lo1.x + (lo2.x - lo1.x) * 0.62 - nx * 14,
        lo1.y + (lo2.y - lo1.y) * 0.62 - ny * 14, { size: 11.5, color: COL.dim });
    }

    var i;
    for (i = 1; i * 0.15 < t - 1e-9; i++) {
      var qq = P2(d.sample(v, i * 0.15).s);
      ctx.save(); ctx.globalAlpha = 0.26;
      blockShape(ctx, qq.x + nx * bh / 2, qq.y + ny * bh / 2, th, bw, bh, '#f2f4f7');
      ctx.restore();
    }
    var p0 = P2(m.s), cx = p0.x + nx * bh / 2, cy = p0.y + ny * bh / 2;
    blockShape(ctx, cx, cy, th, bw, bh, '#e8eef5');
    flickStart(ctx, t, v.v0, pA.x - ux * 22 + nx * bh / 2, pA.y - uy * 22 + ny * bh / 2, -th, 112);
    /* 高さは「斜面に接している点」ではかる（物体の厚みぶんを高さに数えない） */
    /* 運動が終わったら、点ごとの高さ（drawPts）に任せてこの1本は消す */
    if (!endOn(d, s, t)) heightDim(ctx, 24, p0.y, gy, 'h = ' + fmt(m.h, 2) + ' m', cx, true);

    /* ★力の縮尺は大きめにとる★（先生の指摘・第7回）
       もとは「mg が 30 px」だったが、動摩擦力 μ'N は mg の 1/5〜1/3 しかないので
       5〜10 px にしかならず、いちばん見せたい力が見えなかった。
       矢印の長さの比は力の比のまま（★量に比例★ レイアウト規約 ㉞）。 */
    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 62 / mg;
    function fAt(qq, sx, sy) {
      var ax = sx + nx * bh / 2, ay = sy + ny * bh / 2;
      arrow(ctx, ax, ay, ax, ay + mg * fs, 'force');
      label(ctx, 'mg', ax, ay + mg * fs + 11, { size: 11.5, color: COL.force });
      arrow(ctx, sx, sy, sx + nx * qq.N * fs, sy + ny * qq.N * fs, 'force', 1, COL.norm);
      label(ctx, 'N', sx + nx * (qq.N * fs + 12), sy + ny * (qq.N * fs + 12),
        { size: 11.5, color: COL.norm });
      if (qq.moving) {
        var fl = qq.f * fs;
        arrow(ctx, sx, sy, sx - ux * fl, sy - uy * fl, 'force', 1, COL.fric);
        label(ctx, "μ'N", sx - ux * (fl + 14), sy - uy * (fl + 14), { size: 11.5, color: COL.fric });
      }
    }
    if (s.o.showF) {
      fAt(m, p0.x, p0.y);
    }
    if (s.o.showFc) {
      var gs = mg * Math.sin(th);
      arrow(ctx, cx, cy, cx - ux * gs * fs, cy - uy * gs * fs, 'comp');
      label(ctx, 'mg sinθ', cx - ux * gs * fs - 10, cy - uy * gs * fs + 12, { size: 11, color: COL.force });
    }
    if (s.o.showV && m.v > 0.05) {
      /* ★物体から離して出す★ */
      /* ★N の矢じりより外に出す★（力の縮尺を大きくしたので、36 px では中に入る） */
      var vof = m.N * fs - bh / 2 + 22, vl = vArrowLen(m.v, 7, 48);
      var va = velArrow(ctx, cx, cy, nx, ny, vof, ux, uy, vl);
      label(ctx, 'v', va.tx + ux * 10, va.ty + uy * 10, { size: 11.5, color: COL.vel });
    }
    if (s.o.showA) {
      var aa = P.m22.aMag(v);        /* 斜面を下る向き（＝運動と逆）に大きさ g(sinθ+μ'cosθ) */
      drawAcc(ctx, cx, cy, -ux * aa, -uy * aa,
        { nx: nx, ny: ny, off: m.N * fs - bh / 2 + 58 });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    drawPts(ctx, d, s, t, function (p, mm, i2) {
      var q = (p.name === 'A') ? pA : pB, mk2 = (p.name === 'A') ? mkA : mkB;
      return { x: mk2.x, y: mk2.y,
        fdraw: function () { fAt(d.sample(v, p.t), q.x, q.y); },
        ox: q.x + nx * bh / 2, oy: q.y + ny * bh / 2, bw: bw, bh: bh, ang: th,
        vx: ux, vy: uy, vref: 7, vk: 48, voff: 28, base: gy, hx: 24 + i2 * 20 };
    });
  },
  /* ★モード2の見どころ★ とちゅうで「動摩擦力が運動と逆向き」を見せる */
  midGhost: function (ctx, s) {
    var d = DEFS['m2-2'], v = V(s), tm = P.m22.tStop(v) * 0.5, m = d.sample(v, tm);
    /* ★ここの定数は draw とそろえる★ */
    var th = v.th * DEG, gy = CVH - 98, x0 = 96;
    var sRef = Math.min(9.0, v.v0 * v.v0 / (2 * G * (Math.sin(th) + 0.10 * Math.cos(th))) * 1.2);
    var sc = Math.min(88, (CVW - 96 - x0 - 16) / Math.max(0.5, sRef * Math.cos(th)),
      (gy - 46) / Math.max(0.3, sRef * Math.sin(th)));
    var ux = Math.cos(th), uy = -Math.sin(th), nx = -Math.sin(th), ny = -Math.cos(th);
    var kz = mSize(d, v), bw = 30 * kz, bh = 22 * kz;
    var px = x0 + ux * m.s * sc, py = gy + uy * m.s * sc;
    var cx = px + nx * bh / 2, cy = py + ny * bh / 2, fs = 62 / (v.m * G);
    ctx.save(); ctx.globalAlpha = 0.9;
    blockShape(ctx, cx, cy, th, bw, bh, '#f2f4f7');
    ctx.restore();
    var vl = vArrowLen(m.v, 7, 48);
    var va = velArrow(ctx, cx, cy, nx, ny, m.N * fs - bh / 2 + 22, ux, uy, vl);
    label(ctx, 'v', va.tx + ux * 10, va.ty + uy * 10, { size: 11, color: COL.vel });
    var fl = m.f * fs;
    arrow(ctx, px, py, px - ux * fl, py - uy * fl, 'force', 1, COL.fric);
    label(ctx, "μ'N", px - ux * (fl + 14), py - uy * (fl + 14), { size: 11, color: COL.fric });
    /* ★吹きだしは物体の斜め上（坂の外がわ）に出す★（第8回）
       坂の右下（山の中）に置いていたので、引き出しの▼が何もささずに浮いて見えた。
       ★第9回★ しっぽ（▼）の先は「動摩擦力の矢印の まん中の真上」にそろえる。 */
    bubble(ctx, '力の向きが運動と逆 → 負の仕事！', px - ux * fl / 2, cy + ny * 158,
      { size: 11.5, bg: '#eef2f7', border: COL.eE, color: '#28323d' });
  },
  resItems: function (v) {
    return [
      { k: '止まるまでの距離 $L$（式）', v: fmt(P.m22.sStop(v), 2) + ' m' },
      { k: '止まる高さ $L\\sin\\theta$', v: fmt(P.m22.sStop(v) * Math.sin(v.th * DEG), 2) + ' m' },
      { k: 'なめらかなら上がる高さ', v: fmt(v.v0 * v.v0 / (2 * G), 2) + ' m' }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m2-2'].sample(v, t);
    return [
      ['斜面にそって進んだ距離', fmt(m.s, 2) + ' m'],
      ['動摩擦力 $\\mu\' mg\\cos\\theta$', fmt(m.f, 2) + ' N'],
      ['止まる時刻', fmt(P.m22.tStop(v), 2) + ' s'],
      ['熱になったエネルギー', fmt(-m.W, 2) + ' J']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return "\\tfrac{1}{2}mv_0^{\\,2} = mgL\\sin\\theta + \\mu' mg\\cos\\theta\\,L \\;\\Rightarrow\\; L = " +
      fmt(P.m22.sStop(v), 2) + '\\ \\mathrm{m}';
  },
  note: 'すべり上がるあいだ、<b>動摩擦力は運動と逆（斜面下向き）</b>を向いているので<b>負の仕事</b>をします。' +
    'その分だけ力学的エネルギーが減るので、<b>なめらかな斜面より低いところで止まります</b>。' +
    'エネルギーの式は「はじめの $K$ ＝ 上がった分の $U$ ＋ 摩擦で失われた分」。' +
    '$\\mu\'$ を 0 に近づけると 1-3（なめらかな滑り台）に近づきます。'
};

/* ============ 2-3 鉛直のばね（手の仕事あり）★この単元の山場★ ============ */
DEFS['m2-3'] = {
  id: 'm2-3', mode: 2, tab: '2-3 鉛直のばね（手の仕事あり）',
  title: '2-3　鉛直のばね（手でゆっくり下ろす）',
  sub: '1-12 と<b>同じばね・同じおもり</b>ですが、今度は<b>手で支えながらゆっくり下ろします</b>。' +
    '重力と弾性力（保存力）のほかに<b>手の力（非保存力）が仕事をする</b>ので、力学的エネルギーは保存されません。' +
    'つりあいの位置で手をはなすと、おもりはそこで静止したままになります。',
  cw: 760, ch: 350,        /* 吹きだしの式が長いので、横も縦も広めにとる（第6回で 620 → 760） */
  vis: ['F', 'V', 'A'],
  hasUs: true,
  ptSide: 'stack',
  mainVars: ['k', 'd'],
  mainVarFocus: 'k',
  vars: [
    { k: 'k', label: 'ばね定数 $k$', unit: ' N/m', min: 40, max: 100, step: 5, dec: 0, def: 50 },
    { k: 'd', label: 'はじめの伸び $d$（自然長から下へ）', unit: ' m', min: 0, max: 0.08, step: 0.01, dec: 2, def: 0.00 }
  ],
  consts: { m: 1.0 },
  actions: [
    { label: 'やわらかいばね（k＝40）', fn: function (s) { s.v.k = 40; },
      is: function (v) { return v.k === 40; },
      next: function (s) { return s._played && s.v.k !== 40; } },
    { label: '手をはなす場合（1-12）を見る →', jump: 'm1-12' },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.k = 50; s.v.d = 0; },
      is: function (v) { return v.k === 50 && Math.abs(v.d) < 1e-9; } }
  ],
  cons: false,
  forces: ['g', 'sp', 'hand'],
  hintFig: '<b>手がした仕事の分だけ $E$ が減る</b>。だから<b>つりあいの位置で止まれる</b>' +
    '（手をはなした 1-12 では、その2倍の深さまで行ってしまう）',
  wName: '手の力',
  wSym: 'W_{\\text{手}}',
  step1: '重力と弾性力のほかに、手の力（非保存力）が仕事をしている',
  datum: 'はじめの位置（手をはなす高さ）。下がると高さは負',
  hint2: '<b>次は</b>：<a href="#m1-12" data-goto="m1-12">1-12（手の仕事なし）</a>を見て、手の仕事による結果のちがいを確かめよう。',
  tEnd: function (v) { return P.m23.tEnd(v); },
  sample: function (v, t) { return P.m23.sample(v, t); },
  pts: [
    { name: 'A', jp: 'はじめの状態', t: function () { return 0; },
      sym: { K: '0', Ug: '0', Us: '\\tfrac{1}{2}kd^2' } },
    { name: 'B', jp: 'つりあいの位置', t: function () { return P.m23.T; },
      hsym: 'd-x_{eq}',                /* ★式と図で同じ記号を使う★（第12回） */
      sym: { K: '0', Ug: 'mg(d-x_{\\text{eq}})', Us: '\\tfrac{1}{2}kx_{\\text{eq}}^{\\,2}' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m2-3'], v = V(s), m = d.sample(v, t);
    /* ★横の場所わけ（1-12 と同じ・第6回）★
       左 … 高さの寸法線／まん中 … ばねとおもり／右 … 点の印 → 文字 → 吹きだしの列 */
    var cx = W * 0.34, topY = 46;
    var natY = topY + 86;
    function Y(x) { return natY + x * sc; }
    var xe = P.m19.xEq(v), xl = P.m19.xLow(v);
    /* 縮尺は「1-12 の最下点まで図に収まる」ように決める（見くらべるため） */
    var sc = Math.min(300, (H - 86 - natY) / Math.max(0.05, xl));
    var bw = 40, bh = 26;

    hatchLine(ctx, cx - 52, topY, cx + 52, topY, -1);
    ctx.save();
    ctx.strokeStyle = '#9aa3ac'; ctx.lineWidth = 1.1; ctx.setLineDash([5, 4]);
    ctx.beginPath(); ctx.moveTo(cx - 96, natY); ctx.lineTo(cx + 96, natY); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(cx - 96, Y(xe)); ctx.lineTo(cx + 96, Y(xe)); ctx.stroke();
    ctx.restore();
    /* 文字は線の右のはしの少し上（線が字を横切らないように・第6回） */
    label(ctx, '自然長', cx + 64, natY - 11, { size: 11, color: COL.sub, align: 'left' });
    /* ★式の $x_{eq}$ が図のどこかを見せる★（先生の指示・第12回） */
    label(ctx, 'つりあい x_{eq} = ' + fmt(xe, 3) + ' m', cx + 64, Y(xe) - 11,
      { size: 11, color: COL.sub, align: 'left' });
    datumLine(ctx, cx - 110, W - 96, Y(v.d), '基準面 h = 0（スタート）', true, false);
    /* ★1-12（手をはなす）との見くらべ★（先生の指示・第11回）
       同じばね・同じおもりでも、手が仕事をするかどうかで
       「つりあいの位置での速さ」がまるでちがう。1-12 にも同じパネルを出す。 */
    if (hintOn(s, t)) {
      factPanel(ctx, W * 0.53, 36, 'つりあいの位置（B点）での速さ',
        fmt(d.sample(v, P.m23.T).v, 2) + ' m/s', 'ここで止まる');
    }
    /* ★表の d（はじめの伸び）が図のどこかを見せる★（第6回・1-12 と同じ）
       ★第11回★ d = 0 のときは何も書かない（1-12 と同じ理由） */
    if (Y(v.d) - natY > 7) {
      arrow(ctx, cx - 90, natY, cx - 90, Y(v.d), 'dim');
      arrow(ctx, cx - 90, Y(v.d), cx - 90, natY, 'dim');
      label(ctx, 'はじめの伸び d = ' + fmt(v.d, 2) + ' m', cx - 90, natY - 12,
        { size: 11, color: COL.dim });
    }

    var by = Y(m.x);
    spring(ctx, cx, topY, cx, by - bh / 2, { coils: 11, r: 13, color: COL.hand, lw: 2 });
    /* ★印は1本の列にそろえる★（第6回）ただし2点が同じ高さに見えるときは横にずらす */
    var mDx = (Math.abs(Y(xe) - Y(v.d)) < 26) ? 26 : 0;
    ptMark(ctx, 'A', cx + 40, Y(v.d));
    ptMark(ctx, 'B', cx + 40 + mDx, Y(xe));
    blockShape(ctx, cx, by, 0, bw, bh, '#e8eef5');
    /* 運動が終わったら、点ごとの高さ（drawPts）に任せてこの1本は消す */
    if (!endOn(d, s, t)) heightDim(ctx, cx - 116, by, Y(v.d), 'h = ' + fmt(m.h, 3) + ' m');   /* 下は負 */

    /* 手（手のひらを上に向けて、おもりの下にぴったり接するように支える） */
    handUnder(ctx, cx + 2, by + bh / 2 + 5, 0.85);
    label(ctx, 'ゆっくり下ろす', cx + 74, by + bh / 2 + 40,
      { size: 11, color: COL.sub, align: 'left', avoid: true });

    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 30 / mg;
    function fAt(qq, ay) {
      arrow(ctx, cx, ay, cx, ay + mg * fs, 'force');
      label(ctx, 'mg', cx, ay + mg * fs + 11, { size: 11.5, color: COL.force });
      var F = v.k * qq.x;
      if (F * fs > 3) {
        arrow(ctx, cx, ay - bh / 2, cx, ay - bh / 2 - F * fs, 'force', 1, COL.hand);
        label(ctx, '弾性力 kx', cx + 12, ay - bh / 2 - F * fs + 6, { size: 11, color: COL.hand, align: 'left' });
      }
      if (qq.fh * fs > 3) {
        arrow(ctx, cx - 12, ay + bh / 2, cx - 12, ay + bh / 2 - qq.fh * fs, 'force', 1, COL.hand);
        label(ctx, '手の力 F', cx - 24, ay + bh / 2 - qq.fh * fs - 6,
          { size: 11, color: COL.hand, align: 'right' });
      }
    }
    if (s.o.showF) fAt(m, by);
    if (s.o.showV && Math.abs(m.v) > 0.005) {
      /* ★物体から離して出す★ */
      var vl = vArrowLen(m.v, 0.12, 40);
      var va = velArrow(ctx, cx, by, -1, 0, 76, 0, 1, vl);
      label(ctx, 'v', va.x - 12, va.y, { size: 11.5, color: COL.vel, align: 'right' });
    }
    if (s.o.showA) {
      /* ゆっくり下ろすので加速度はごく小さい。そのことが分かるように書いておく */
      var aA = P.m23.accel(v, t);
      if (Math.abs(aA) > 0.05) drawAcc(ctx, cx, by, 0, aA, { nx: -1, ny: 0, off: bw / 2 + 24 });
      else label(ctx, 'a ≒ 0', cx - bw / 2 - 30, by, { size: 11, color: COL.acc, align: 'right' });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    drawPts(ctx, d, s, t, function (p, mm, i2) {
      var A = (p.name === 'A'), yy = A ? Y(v.d) : Y(xe);
      return { x: cx + 40 + (A ? 0 : mDx), y: yy, ox: cx, oy: yy, bw: bw, bh: bh,
        fdraw: function () { fAt(d.sample(v, p.t), yy); },
        base: Y(v.d), hx: cx - 116 - i2 * 44, hside: (i2 >= 1) ? 'left' : 0 };
    });
  },
  /* ★モード2の見どころ★ とちゅうで「手の力が運動と逆向き（上向き）」を見せる */
  midGhost: function (ctx, s) {
    var d = DEFS['m2-3'], v = V(s), m = d.sample(v, P.m23.T * 0.5);
    var cx = CVW * 0.42, topY = 46, natY = topY + 86;
    var xl = P.m19.xLow(v);
    var sc = Math.min(300, (CVH - 86 - natY) / Math.max(0.05, xl));
    var by = natY + m.x * sc, bw = 40, bh = 26, fs = 30 / (v.m * G);
    ctx.save(); ctx.globalAlpha = 0.9;
    blockShape(ctx, cx, by, 0, bw, bh, '#f2f4f7');
    ctx.restore();
    var vl = vArrowLen(m.v, 0.12, 40);
    var va = velArrow(ctx, cx, by, -1, 0, 56, 0, 1, vl);
    label(ctx, 'v', va.x - 12, va.y, { size: 11, color: COL.vel, align: 'right' });
    if (m.fh * fs > 3) {
      arrow(ctx, cx - 12, by + bh / 2, cx - 12, by + bh / 2 - m.fh * fs, 'force', 1, COL.hand);
      label(ctx, '手の力 F', cx - 26, by + bh / 2 - m.fh * fs - 8,
        { size: 11, color: COL.hand, align: 'right' });
    }
    bubble(ctx, '力は上向き・動きは下向き → 負の仕事！', cx - 116, by + 104,
      { size: 11.5, bg: '#eef2f7', border: COL.eE, color: '#28323d' });
  },
  resItems: function (v) {
    /* ★第11回★「手をはなした場合（1-12）の最下点」はここから消した。
       1-12 とのちがいは、図の中の「つりあいの位置での速さ」のパネルで見せる。 */
    return [
      { k: 'つりあいの位置 $x_{eq}=mg/k$', v: fmt(P.m19.xEq(v), 3) + ' m' },
      { k: '手がした仕事 $W_{手}$', v: fmt(P.m23.W(v, P.m23.T), 2) + ' J' }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m2-3'].sample(v, t);
    return [
      ['ばねの伸び $x$', fmt(m.x, 3) + ' m'],
      ['手の力 $F$', fmt(m.fh, 2) + ' N'],
      ['弾性力 $kx$', fmt(v.k * m.x, 2) + ' N'],
      ['下ろすのにかける時間', fmt(P.m23.T, 1) + ' s']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return 'E_2 - E_1 = W_{\\text{手}} = ' + fmt(P.m23.W(v, P.m23.T), 2) +
      '\\ \\mathrm{J}\\quad(\\text{手の力は上向き・動きは下向きなので負})';
  },
  note: '<b>ここがこの単元の山場です。</b>手はおもりを<b>上向きに支え</b>ながら、おもりは<b>下向きに動く</b>ので、' +
    '手のする仕事は<b>負</b>になります。その分だけ力学的エネルギーが減るので、' +
    '<b>つりあいの位置（$x=mg/k$）でぴたりと止まれます</b>。' +
    '手をはなした 1-12 では手が仕事をしないので $E$ が減らず、<b>その2倍の深さ（$2mg/k$）まで</b>行ってしまいます。' +
    '同じばね・同じおもりでも、<b>非保存力が仕事をするかどうかで結果が変わる</b>のです。'
};

/* ============ 2-4 摩擦がある水平面のばね（1-9 の摩擦あり版） ============ */
DEFS['m2-4'] = {
  id: 'm2-4', mode: 2, tab: '2-4 摩擦がある水平面のばね',
  title: '2-4　摩擦がある水平面のばね（1-9 の摩擦あり版）',
  sub: '粗い水平面。ばねを $x_0$ だけ伸ばして手をはなします。' +
    '<b>弾性力（保存力）</b>のほかに<b>動摩擦力（非保存力）</b>が運動と逆向きにはたらくので、' +
    '力学的エネルギーは保存されません。自然長を通るときの速さは ' +
    '$\\tfrac12kx_0^{\\,2} = \\tfrac12mv^2 + \\mu\' mgx_0$ から求めます。',
  cw: 640, ch: 366,        /* 第12回：上に x_0 の寸法線を入れるぶん高くした */
  vis: ['F', 'V', 'A'],
  hasUs: true,
  mainVars: ['x0', 'mu'],
  mainVarFocus: 'mu',
  vars: [
    { k: 'x0', label: 'はじめの伸び $x_0$', unit: ' m', min: 0.20, max: 0.40, step: 0.02, dec: 2, def: 0.30 },
    { k: 'mu', label: '動摩擦係数 $\\mu\'$', unit: '', min: 0.05, max: 0.25, step: 0.05, dec: 2, def: 0.20 },
    { k: 'k', label: 'ばね定数 $k$', unit: ' N/m', min: 40, max: 100, step: 10, dec: 0, def: 40 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 0.5, max: 1.5, step: 0.25, dec: 2, def: 1.0 }
  ],
  actions: [
    { label: 'よくすべる床にする（μ′＝0.05）', fn: function (s) { s.v.mu = 0.05; },
      is: function (v) { return Math.abs(v.mu - 0.05) < 1e-9; },
      next: function (s) { return s._played && Math.abs(s.v.mu - 0.05) > 1e-9; } },
    { label: 'もっとざらざらに（μ′＝0.25）', fn: function (s) { s.v.mu = 0.25; },
      is: function (v) { return Math.abs(v.mu - 0.25) < 1e-9; } },
    { label: '摩擦なし（1-9）を見る →', jump: 'm1-9' }
  ],
  cons: false,
  forces: ['g', 'N', 'sp', 'fr'],
  hintFig: '<b>動摩擦力が負の仕事をした分だけ $E$ が減る</b>。' +
    '摩擦がなければ（<span data-goto="m1-9">1-9</span>）振れ幅は小さくならない',
  wName: '動摩擦力',
  wSym: '-\\mu\' mgx_0',
  step1: 'ばねの弾性力のほかに、動摩擦力（非保存力）が運動と逆向きに負の仕事をしている',
  datum: '床（高さは変わらないので $U_g = 0$）',
  hint2: '<b>次は</b>：$\\mu\'$ を変えて、<b>自然長を通る速さ</b>と<b>振れ幅の減り方</b>が' +
    'どう変わるか見てみよう。摩擦なしは <span data-goto="m1-9">1-9</span>。',
  slow: true,                /* ★はじめからスロー再生★（第8回・ばねのシム） */
  tEnd: function (v) { return P.m24.tEnd(v); },
  /* ★グラフの横軸は「止まるまで」だけ★（第14回）
     アニメは「止まる → もう一度はじめから → 点 B で止まる」の2段になっている。 */
  tGraph: function (v) { return P.m24.tGraph(v); },
  /* 2回目の再生のあいだは、グラフのカーソルもはじめにもどす（同じ状態を指す） */
  tCursor: function (v, t) {
    var ts = P.m24.tStop(v);
    return (t > ts + P.m24.HOLD) ? Math.min(t - ts - P.m24.HOLD, P.m24.tNat(v)) : Math.min(t, ts);
  },
  sample: function (v, t) { return P.m24.sample(v, t); },
  pts: [
    { name: 'A', jp: 'スタート（いちばん伸びた所）', t: function () { return 0; },
      sym: { K: '0', Ug: '0', Us: '\\tfrac{1}{2}kx_0^{\\,2}' } },
    { name: 'B', jp: 'はじめて自然長を通る所', t: function (v) { return P.m24.tNat(v); },
      sym: { K: '\\tfrac{1}{2}mv^2', Ug: '0', Us: '0' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m2-4'], v = V(s), m = d.sample(v, t);
    /* ★1-9 より広い縮尺★ 終わりに「A のゴースト・とちゅうの姿・本物」の3つが
       ならぶので、これくらい離さないと重なって見える */
    var sc = 300, gy = H - 82, wallX = 46, natX = wallX + 190;
    function X(x) { return natX + x * sc; }
    var kz = mSize(d, v), bw = 34 * kz, bh = 26 * kz;

    /* 粗い床（ハッチ＋つぶつぶ） */
    ground(ctx, 20, W - 96, gy);
    ctx.save();
    ctx.fillStyle = '#9aa3ac';
    for (var g2 = 26; g2 < W - 100; g2 += 9) {
      ctx.beginPath(); ctx.arc(g2, gy - 2.2, 1.5, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
    datumLine(ctx, 20, W - 96, gy, '基準面 h = 0', true, true);
    /* ★何と何をくらべているのかを、図の上に出す★（先生の指示・第14回）
       何往復も見せると動摩擦力の仕事が求めにくいので、このシムは
       「止まるまで → もう一度はじめから → 点 B で止まる」という再生にしてある。 */
    bannerNote(ctx, ['先ほど見せたように、本来まだ振動が続きますが、ここでは',
      'スタート（点A）と、はじめて自然長の位置（点B）を通過する瞬間をくらべます'], 32);
    /* 壁 */
    ctx.save();
    ctx.fillStyle = '#d7dde4'; ctx.fillRect(wallX - 14, gy - 96, 14, 96);
    ctx.strokeStyle = '#8b949e'; ctx.lineWidth = 1.4; ctx.strokeRect(wallX - 14, gy - 96, 14, 96);
    ctx.restore();
    /* 自然長の位置 */
    ctx.save();
    ctx.strokeStyle = '#9aa3ac'; ctx.lineWidth = 1.2; ctx.setLineDash([5, 4]);
    ctx.beginPath(); ctx.moveTo(natX, gy - 160); ctx.lineTo(natX, gy + 4); ctx.stroke();
    ctx.restore();
    label(ctx, '自然長', natX, gy - 168, { size: 11, color: COL.sub });
    /* ★式の $x_0$（はじめの伸び）が図のどこかを見せる★（先生の指示・第12回）
       $U_k = \tfrac12kx_0^2$ の $x_0$。自然長の線から A（スタート）まで。1-9 と同じ作法。 */
    if (X(v.x0) - natX > 8) {
      /* とちゅうの姿の吹きだしが gy − 100 に出るので、その上に置く */
      var y0d = gy - 140;
      arrow(ctx, natX, y0d, X(v.x0), y0d, 'dim');
      arrow(ctx, X(v.x0), y0d, natX, y0d, 'dim');
      label(ctx, 'x_0 = ' + fmt(v.x0, 2) + ' m', (natX + X(v.x0)) / 2, y0d - 11,
        { size: 11, color: COL.dim });
    }

    var cx = X(m.x), cy = gy - bh / 2;
    spring(ctx, wallX, cy, cx - bw / 2, cy, { coils: 10, r: 11, color: COL.hand, lw: 2 });
    ptMark(ctx, 'A', X(v.x0) + bw / 2 + 13, gy - bh / 2);
    ptMark(ctx, 'B', natX - bw / 2 - 13, gy - bh / 2);
    blockShape(ctx, cx, cy, 0, bw, bh, '#e8eef5');
    /* 伸びの寸法 */
    if (Math.abs(m.x) > 0.005) {
      arrow(ctx, natX, gy + 18, cx, gy + 18, 'dim');
      label(ctx, 'x = ' + fmt(m.x, 2) + ' m', (natX + cx) / 2, gy + 32, { size: 11, color: COL.dim });
    }
    var hA = (t <= 0.16) ? 1 : Math.max(0, 1 - (t - 0.16) / 0.20);
    if (hA > 0.02) dropHand(ctx, X(v.x0) + bw / 2 + 6, cy, 0.5, clamp(t / 0.16, 0, 1), hA);

    /* ★力の縮尺は大きめにとる★（先生の指摘・第7回）
       もとは「mg が 30 px」だったが、動摩擦力 μ'N は mg の 1/5〜1/3 しかないので
       5〜10 px にしかならず、いちばん見せたい力が見えなかった。
       矢印の長さの比は力の比のまま（★量に比例★ レイアウト規約 ㉞）。 */
    /* ★縮尺は「その図でいちばん大きい力」から決める★（第7回）
       ここはばねの力（最大 k·x₀）が mg より大きくなることがあるので、mg でそろえると
       ばねの矢印が図からはみ出す。いちばん大きい力を 76 px にして、あとは同じ比で描く
       （前は、ばねの力だけ 0.55 倍にしていた＝力の比が絵とちがっていた。第7回に直した）。 */
    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    var mg = v.m * G, fs = 76 / Math.max(mg, v.k * v.x0);
    function fAt(qq, ax) {
      arrow(ctx, ax, cy, ax, cy + mg * fs, 'force');
      label(ctx, 'mg', ax, cy + mg * fs + 11, { size: 11.5, color: COL.force });
      arrow(ctx, ax, gy, ax, gy - mg * fs, 'force', 1, COL.norm);
      label(ctx, 'N', ax + bw / 2 + 8, gy - mg * fs + 4, { align: 'left', size: 11.5, color: COL.norm });
      var F = -v.k * qq.x, fl = F * fs;
      if (Math.abs(fl) > 3) {
        arrow(ctx, ax - bw / 2, cy, ax - bw / 2 + fl, cy, 'force', 1, COL.hand);
        label(ctx, '弾性力 kx', ax - bw / 2 + fl / 2, cy - 15, { size: 11, color: COL.hand });
      }
      /* 動摩擦力は「運動と逆向き」 */
      if (qq.moving && Math.abs(qq.vs) > 1e-6) {
        var dir = (qq.vs > 0 ? -1 : 1), ffl = qq.f * fs;
        arrow(ctx, ax, gy - 3, ax + dir * ffl, gy - 3, 'force', 1, COL.fric);
        label(ctx, 'μ\'N', ax + dir * (ffl + 10), gy - 17,
          { align: dir > 0 ? 'left' : 'right', size: 11.5, color: COL.fric });
      }
    }
    if (s.o.showF) fAt(m, cx);
    if (s.o.showV && m.v > 0.05) {
      /* ★物体から離して出す★（ブロックの上 40 px） */
      var sgv = (m.vs > 0 ? 1 : -1), vl = vArrowLen(m.v, Math.max(0.3, P.m24.vNat(v)), 48);
      var va = velArrow(ctx, cx, cy, 0, -1, mg * fs - bh / 2 + 22, sgv, 0, vl);
      label(ctx, 'v', va.tx + sgv * 10, va.ty, { size: 11.5, color: COL.vel });
    }
    if (s.o.showA) {
      var ax = (-v.k * m.x - (m.moving && Math.abs(m.vs) > 1e-6 ? (m.vs > 0 ? 1 : -1) * m.f : 0)) / v.m;
      drawAcc(ctx, cx, cy, ax, 0, { nx: 0, ny: -1, off: mg * fs - bh / 2 + 58 });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    drawPts(ctx, d, s, t, function (p) {
      var A = (p.name === 'A');
      var q = d.sample(v, p.t);
      /* 吹きだしは、物体の横に置いた印から引き出す */
      return { x: (A ? X(v.x0) + bw / 2 + 13 : natX - bw / 2 - 13), y: gy - bh / 2,
        ox: A ? X(v.x0) : natX, oy: gy - bh / 2, bw: bw, bh: bh,
        fdraw: function () { fAt(q, A ? X(v.x0) : natX); },
        /* 終わりに物体がその点と同じ場所にいるときは、ゴーストを描かない */
        here: Math.abs(m.x - (A ? v.x0 : 0)) < 0.004,
        vx: (q.vs >= 0 ? 1 : -1), vy: 0, vref: Math.max(0.3, P.m24.vNat(v)), vk: 48, voff: bw / 2 + 10 };
    });
  },
  /* ★モード2の見どころ★ とちゅうで「動摩擦力が運動と逆向き」を見せる */
  midGhost: function (ctx, s) {
    /* ★A と B のまん中（伸びが x0/2 の所）に置く★ 時刻で半分にすると、
       物体が B に寄りすぎて本物と重なってしまう。 */
    var d = DEFS['m2-4'], v = V(s), tm = P.m24.tAtX(v, v.x0 / 2), m = d.sample(v, tm);
    var sc = 300, gy = CVH - 82, wallX = 46, natX = wallX + 190;
    var kz = mSize(d, v), bw = 34 * kz, bh = 26 * kz;
    var cx = natX + m.x * sc, cy = gy - bh / 2, fs = 76 / Math.max(v.m * G, v.k * v.x0);
    ctx.save(); ctx.globalAlpha = 0.9;
    blockShape(ctx, cx, cy, 0, bw, bh, '#f2f4f7');
    ctx.restore();
    /* 速度の矢印は、本物より1段上に出す（同じ高さだと2本ならんで分かりにくい） */
    var vl = vArrowLen(m.v, Math.max(0.3, P.m24.vNat(v)), 48);
    var va = velArrow(ctx, cx, cy, 0, -1, v.m * G * fs - bh / 2 + 22, -1, 0, vl);
    label(ctx, 'v', va.tx - 10, va.ty, { align: 'right', size: 11, color: COL.vel });
    var ffl = m.f * fs;
    arrow(ctx, cx, gy - 3, cx + ffl, gy - 3, 'force', 1, COL.fric);
    label(ctx, 'μ\'N', cx + ffl + 10, gy - 17, { align: 'left', size: 11, color: COL.fric });
    /* ★第9回★ しっぽ（▼）の先は「動摩擦力の矢印の まん中の真上」にそろえる */
    bubble(ctx, '力の向きが運動と逆 → 負の仕事！', cx + ffl / 2, gy - 100,
      { size: 11.5, bg: '#eef2f7', border: COL.eE, color: '#28323d' });
  },
  resItems: function (v) {
    return [
      { k: '自然長を通る速さ（式）', v: fmt(P.m24.vNat(v), 2) + ' m/s' },
      { k: '摩擦がなければ（1-9）', v: fmt(v.x0 * Math.sqrt(v.k / v.m), 2) + ' m/s' },
      { k: '最後に止まる伸び', v: fmt(P.m24.xStop(v), 3) + ' m' }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m2-4'].sample(v, t);
    return [
      ['ばねの伸び $x$', fmt(m.x, 3) + ' m'],
      ['弾性力 $kx$', fmt(v.k * Math.abs(m.x), 1) + ' N'],
      ['動摩擦力 $\\mu\' mg$', fmt(P.m24.f(v), 2) + ' N'],
      ['動いた道のり', fmt(m.path, 3) + ' m'],
      ['熱になったエネルギー', fmt(-m.W, 2) + ' J']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return '\\tfrac{1}{2}kx_0^{\\,2} = \\tfrac{1}{2}mv^2 + \\mu\' mgx_0 \\;\\Rightarrow\\; v = ' +
      fmt(P.m24.vNat(v), 2) + '\\ \\mathrm{m/s}';
  },
  note: 'ばねの弾性力は<b>保存力</b>、動摩擦力は<b>非保存力</b>です。' +
    '動摩擦力はいつも運動と逆を向いているので<b>負の仕事</b>をし、その分だけ $E$ が減ります。' +
    'だから<b>行ったり来たりするたびに振れ幅が小さくなり</b>、やがて止まります。' +
    '$\\mu\'$ を 0 に近づけると <span data-goto="m1-9">1-9</span>（摩擦なし）に近づきます。'
};

/* ============ 2-5 摩擦がある斜面を、糸で引き上げる ============ */
DEFS['m2-5'] = {
  id: 'm2-5', mode: 2, tab: '2-5 斜面を糸で引き上げる',
  title: '2-5　摩擦がある斜面を、糸で引き上げる',
  sub: '粗い斜面にそって、一定の力 $F$ で長さ $L$ だけ引き上げます。' +
    '<b>糸の力は正の仕事</b>、<b>動摩擦力は負の仕事</b>をする<b>どちらも非保存力</b>です。' +
    'エネルギーの式は $\\tfrac12mv^2 + mgL\\sin\\theta = FL - \\mu\' mg\\cos\\theta\\,L$。',
  cw: 640, ch: 360,
  vis: ['F', 'Fc', 'V', 'A'],
  mainVars: ['Ft', 'mu'],
  mainVarFocus: 'Ft',
  vars: [
    { k: 'Ft', label: '糸の力 $F$', unit: ' N', min: 32, max: 44, step: 2, dec: 0, def: 36 },
    { k: 'mu', label: '動摩擦係数 $\\mu\'$', unit: '', min: 0.15, max: 0.50, step: 0.05, dec: 2, def: 0.40 },
    { k: 'th', label: '斜面の角 $\\theta$', unit: '°', min: 20, max: 45, step: 5, dec: 0, def: 30 },
    { k: 'm', label: '質量 $m$', unit: ' kg', min: 2.0, max: 3.0, step: 0.5, dec: 1, def: 2.0 }
  ],
  actions: [
    { label: '強く引く（F＝44 N）', fn: function (s) { s.v.Ft = 44; },
      is: function (v) { return v.Ft === 44; },
      next: function (s) { return s._played && s.v.Ft !== 44; } },
    { label: 'ざらざらにする（μ′＝0.50）', fn: function (s) { s.v.mu = 0.50; },
      is: function (v) { return Math.abs(v.mu - 0.50) < 1e-9; } },
    { label: 'はじめの設定にもどす', fn: function (s) { s.v.Ft = 36; s.v.mu = 0.40; s.v.th = 30; },
      is: function (v) { return v.Ft === 36 && Math.abs(v.mu - 0.40) < 1e-9 && v.th === 30; } }
  ],
  cons: false,
  forces: ['g', 'N',
    { key: 'pull', name: '糸の力', sym: 'F', color: COL.hand,
      w: function (v, A, B) { return v.Ft * ((B.m.s || 0) - (A.m.s || 0)); },
      wsym: 'W_F = F L\\cos 0^\\circ = FL',
      why: '糸の力は<b>非保存力</b>。動く向きと同じ向きなので、いつも<b>正の仕事</b>。' },
    { key: 'fr', name: '動摩擦力',
      w: function (v, A, B) { return -P.m25.fr(v) * ((B.m.s || 0) - (A.m.s || 0)); } }],
  rate: function (v) { return clamp(P.m25.tEnd(v) / 2.4, 0.3, 1); },
  hintFig: '<b>糸の力は正の仕事、動摩擦力は負の仕事</b>。合わせた分だけ $E$ が増える',
  wName: '糸の力と動摩擦力',
  wSym: '(F - \\mu\' mg\\cos\\theta)L',
  step1: '重力のほかに、糸の力（正の仕事）と動摩擦力（負の仕事）＝非保存力が仕事をしている',
  datum: '出発点（斜面の下端）',
  /* ★第13回：F は 32〜44 N しか選べないので、「動きだせなくなるまで小さくする」は
     このシムではできない（動きだすのに必要な力は既定の設定で 16.6 N）。
     押せば必ずできることだけを「次は」に書く。 */
  hint2: '<b>次は</b>：$F$ を <b>44 N → 32 N</b> と小さくして、<b>$E$ の増え方</b>（＝糸がした仕事）が' +
    'どう変わるか見てみよう。動きだすのに必要な力は $mg\\sin\\theta + \\mu\' mg\\cos\\theta$ で、' +
    'いまの設定では <b>16.6 N</b>。このシムの $F$ はいつもそれより大きくしてあります。',
  tEnd: function (v) { return P.m25.tEnd(v); },
  sample: function (v, t) { return P.m25.sample(v, t); },
  pts: [
    { name: 'A', jp: 'スタート（下端・静止）', t: function () { return 0; },
      sym: { K: '0', Ug: '0' } },
    { name: 'B', jp: '$L$ だけ引き上げた所', t: function (v) { return P.m25.tEnd(v); },
      hsym: 'L sinθ',                  /* ★式と図で同じ記号を使う★（第12回） */
      sym: { K: '\\tfrac{1}{2}mv^2', Ug: 'mgL\\sin\\theta' } }
  ],
  draw: function (ctx, s, t, W, H) {
    var d = DEFS['m2-5'], v = V(s), m = d.sample(v, t), L = P.m25.L;
    var th = v.th * DEG, gy = H - 62, x0 = 76;
    var ux = Math.cos(th), uy = -Math.sin(th);      /* 斜面を上る向き */
    /* ★斜面から外向き★ 右上がりの坂では「左上」（ux と直角）。第7回に符号を直した */
    var nx = -Math.sin(th), ny = -Math.cos(th);
    /* ★縮尺は固定★（L も固定なので、θ を変えても坂の「長さ」は変わらず、
       傾きだけが変わる。自動にすると θ で坂の長さが変わって見くらべられない） */
    var SC = SC_PULL;
    function P2(sv) { return { x: x0 + ux * sv * SC, y: gy + uy * sv * SC }; }
    var top = P2(L * SMAX_PULL);

    /* 斜面（粗い面） */
    ctx.save();
    ctx.fillStyle = '#eef1f4';
    ctx.beginPath(); ctx.moveTo(x0, gy); ctx.lineTo(top.x, top.y); ctx.lineTo(top.x, gy);
    ctx.closePath(); ctx.fill();
    ctx.restore();
    hatchLine(ctx, x0, gy, top.x, top.y, -1);
    ctx.save();
    ctx.fillStyle = '#9aa3ac';
    for (var q = 0.12; q < L * SMAX_PULL; q += 0.22) {
      var pp = P2(q);
      ctx.beginPath(); ctx.arc(pp.x + nx * 2.4, pp.y + ny * 2.4, 1.5, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
    ground(ctx, 20, W - 96, gy);
    datumLine(ctx, 20, W - 96, gy, '基準面 h = 0', true, true);
    angArc(ctx, x0, gy, 30, -th, 0, '', 0, 0);
    label(ctx, 'θ = ' + fmt(v.th, 0) + '°', x0 + 44, gy - 12, { size: 12, color: COL.sub, align: 'left' });

    var kz = mSize(d, v), bw = 30 * kz, bh = 22 * kz;
    var pA = P2(0), pB = P2(L);
    /* ★印は斜面の「中（下がわ）」★（第6回）
       2-5 は坂の上に糸・手・F の矢印がならぶので、外がわには置けない。 */
    var mkA = { x: pA.x - nx * 20, y: pA.y - ny * 20 };
    var mkB = { x: pB.x - nx * 20, y: pB.y - ny * 20 };
    ptMark(ctx, 'A', mkA.x, mkA.y);
    ptMark(ctx, 'B', mkB.x, mkB.y);
    /* ★式の $L$（引く長さ）が図のどこかを見せる★（先生の指示・第12回）
       $U_g = mgL\sin\theta$ の $L$。A の印と B の印の間に、坂と平行な両矢印をひく。
       ここは決めた値なので、はじめから出しておく。 */
    var lu1 = { x: pA.x + nx * 44, y: pA.y + ny * 44 };
    var lu2 = { x: pB.x + nx * 44, y: pB.y + ny * 44 };
    arrow(ctx, lu1.x, lu1.y, lu2.x, lu2.y, 'dim');
    arrow(ctx, lu2.x, lu2.y, lu1.x, lu1.y, 'dim');
    label(ctx, 'L = ' + fmt(L, 1) + ' m', (lu1.x + lu2.x) / 2 + nx * 15,
      (lu1.y + lu2.y) / 2 + ny * 15, { size: 11.5, color: COL.dim });

    /* ★通った跡（うすい長方形）は描かない★（先生の指示・第6回）
       まっすぐ上がるだけなので、たくさん並ぶと図がうるさいだけだった。
       「とちゅうの姿」は midGhost が1つだけ出す。 */
    var p0 = P2(m.s), cx = p0.x + nx * bh / 2, cy = p0.y + ny * bh / 2;
    /* ★糸を引く手は、物体といっしょに斜面を上がっていく★（先生の指示・第7回）
       前は坂の上のはしに置きっぱなしだったので、引いているように見えなかった。
       物体の中心から、斜面にそって HAND_GAP [m] だけ上に手を置く。 */
    var HAND_GAP = 1.5;      /* 糸の力 F の矢印（最大 76 px）より外に手が来るようにする */
    var hp = P2(Math.min(m.s + HAND_GAP, L * SMAX_PULL));
    var wx = hp.x + nx * 15, wy = hp.y + ny * 15;
    ctx.save();
    ctx.strokeStyle = COL.hand; ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.moveTo(cx + ux * bw / 2, cy + uy * bw / 2);
    ctx.lineTo(wx, wy);
    ctx.stroke();
    ctx.restore();
    hand(ctx, wx, wy, -th);          /* ★人が手で引く★（先生の指示・第6回） */
    blockShape(ctx, cx, cy, th, bw, bh, '#e8eef5');
    if (!endOn(d, s, t)) heightDim(ctx, 26, p0.y, gy, 'h = ' + fmt(m.h, 2) + ' m', cx, true);

    /* ★力の縮尺は大きめにとる★（先生の指摘・第7回）
       もとは「mg が 30 px」だったが、動摩擦力 μ'N は mg の 1/5〜1/3 しかないので
       5〜10 px にしかならず、いちばん見せたい力が見えなかった。
       矢印の長さの比は力の比のまま（★量に比例★ レイアウト規約 ㉞）。 */
    /* 縮尺は「その図でいちばん大きい力」から決める（糸の力 F が mg より大きい） */
    var mg = v.m * G, fs = 76 / Math.max(mg, v.Ft);
    /* ★その点ではたらく力★（第8回）吹きだしを出すとき、各点にも同じ力を描く */
    function fAt(qq, sx, sy) {
      var ax = sx + nx * bh / 2, ay = sy + ny * bh / 2;
      arrow(ctx, ax, ay, ax, ay + mg * fs, 'force');
      label(ctx, 'mg', ax, ay + mg * fs + 11, { size: 11.5, color: COL.force });
      arrow(ctx, sx, sy, sx + nx * qq.N * fs, sy + ny * qq.N * fs, 'force', 1, COL.norm);
      label(ctx, 'N', sx + nx * (qq.N * fs + 12), sy + ny * (qq.N * fs + 12),
        { size: 11.5, color: COL.norm });
      var fl = qq.f * fs;
      arrow(ctx, sx, sy, sx - ux * fl, sy - uy * fl, 'force', 1, COL.fric);
      label(ctx, 'μ\'N', sx - ux * (fl + 14), sy - uy * (fl + 14), { size: 11.5, color: COL.fric });
      var Fl = v.Ft * fs;
      arrow(ctx, ax + ux * bw / 2, ay + uy * bw / 2,
        ax + ux * (bw / 2 + Fl), ay + uy * (bw / 2 + Fl), 'force', 1, COL.hand);
      label(ctx, 'F', ax + ux * (bw / 2 + Fl + 12) + nx * 10,
        ay + uy * (bw / 2 + Fl + 12) + ny * 10, { size: 11.5, color: COL.hand });
    }
    if (s.o.showF) fAt(m, p0.x, p0.y);
    if (s.o.showFc) {
      var gs = mg * Math.sin(th);
      arrow(ctx, cx, cy, cx - ux * gs * fs, cy - uy * gs * fs, 'comp');
      label(ctx, 'mg sinθ', cx - ux * gs * fs - 12, cy - uy * gs * fs + 13, { size: 11, color: COL.force });
    }
    if (s.o.showV && m.v > 0.05) {
      /* ★N の矢じりより外に出す★（力の縮尺を大きくしたので） */
      var vof = m.N * fs - bh / 2 + 22, vl = vArrowLen(m.v, Math.max(1, P.m25.vEnd(v)), 48);
      var va = velArrow(ctx, cx, cy, nx, ny, vof, ux, uy, vl);
      label(ctx, 'v', va.tx + ux * 10, va.ty + uy * 10, { size: 11.5, color: COL.vel });
    }
    if (s.o.showA) {
      var aa = P.m25.a(v);           /* 斜面を上る向き（＝運動と同じ向き）に一定 */
      drawAcc(ctx, cx, cy, ux * aa, uy * aa,
        { nx: nx, ny: ny, off: m.N * fs - bh / 2 + 58 });
    }
    drawClock(ctx, W, t);
    drawEnergyBar(ctx, d, s, t, W, H, m);
    drawPts(ctx, d, s, t, function (p, mm, i2) {
      var q2 = (p.name === 'A') ? pA : pB, mk5 = (p.name === 'A') ? mkA : mkB;
      return { x: mk5.x, y: mk5.y,
        fdraw: function () { fAt(d.sample(v, p.t), q2.x, q2.y); },
        ox: q2.x + nx * bh / 2, oy: q2.y + ny * bh / 2, bw: bw, bh: bh, ang: th,
        vx: ux, vy: uy, vref: Math.max(1, P.m25.vEnd(v)), vk: 48, voff: 28, base: gy, hx: 26 + i2 * 20 };
    });
  },
  /* ★モード2の見どころ★ 2つの非保存力の向きを、とちゅうの姿で見せる */
  midGhost: function (ctx, s) {
    var d = DEFS['m2-5'], v = V(s), L = P.m25.L, m = d.sample(v, P.m25.tEnd(v) * 0.62);
    var th = v.th * DEG, gy = CVH - 62, x0 = 76;
    var ux = Math.cos(th), uy = -Math.sin(th), nx = -Math.sin(th), ny = -Math.cos(th);
    var SC = SC_PULL;
    var kz = mSize(d, v), bw = 30 * kz, bh = 22 * kz;
    var px = x0 + ux * m.s * SC, py = gy + uy * m.s * SC;
    var cx = px + nx * bh / 2, cy = py + ny * bh / 2, fs = 76 / Math.max(v.m * G, v.Ft);
    ctx.save(); ctx.globalAlpha = 0.9;
    blockShape(ctx, cx, cy, th, bw, bh, '#f2f4f7');
    ctx.restore();
    var vl = vArrowLen(m.v, Math.max(1, P.m25.vEnd(v)), 48);
    var va = velArrow(ctx, cx, cy, nx, ny, m.N * fs - bh / 2 + 22, ux, uy, vl);
    label(ctx, 'v', va.tx + ux * 10, va.ty + uy * 10, { size: 11, color: COL.vel });
    var fl = m.f * fs;
    arrow(ctx, px, py, px - ux * fl, py - uy * fl, 'force', 1, COL.fric);
    label(ctx, 'μ\'N', px - ux * (fl + 14), py - uy * (fl + 14), { size: 11, color: COL.fric });
    var Fl = v.Ft * fs;
    arrow(ctx, cx + ux * bw / 2, cy + uy * bw / 2,
      cx + ux * (bw / 2 + Fl), cy + uy * (bw / 2 + Fl), 'force', 1, COL.hand);
    label(ctx, 'F', cx + ux * (bw / 2 + Fl + 12) + nx * 10,
      cy + uy * (bw / 2 + Fl + 12) + ny * 10, { size: 11, color: COL.hand });
    /* 2つの非保存力は向きが逆。★第9回★ しっぽ（▼）の先は、
       それぞれ「その力の矢印の まん中」にそろえる（何の力の話か分かるように）。
       F は坂の外がわ（上）から、μ'N は坂の内がわ（下）から出す。
       fmx/fmy＝動摩擦力の矢印のまん中、Fmx/Fmy＝F の矢印のまん中。 */
    var fmx = px - ux * fl / 2, fmy = py - uy * fl / 2;
    var Fmx = cx + ux * (bw / 2 + Fl / 2), Fmy = cy + uy * (bw / 2 + Fl / 2);
    /* しっぽ（▼）はまっすぐ下を向くので、ずらすのは たて だけ（横は矢印のまん中のまま） */
    /* 2つとも坂の外がわ（上）に、たてにはなして置く。
       上が F（坂の上がわの矢印）、下が μ'N（坂の下がわの矢印）。 */
    /* F（坂を上る向き）の吹きだしは、坂の外がわ（上）から矢印のまん中へ。 */
    bubble(ctx, 'F は運動と同じ向き → 正の仕事！', Fmx, Fmy + ny * 96,
      { size: 11.5, bg: '#eef2f7', border: COL.eE, color: '#28323d' });
    /* μ'N の吹きだしは、坂の下のあきから上向きに出す。
       箱をそのまま置くと「θ = ○°」の文字とぶつかるので、しっぽの先（＝動摩擦力の
       矢印のまん中）はそのままにして、箱だけ右へずらす（bubble の dx）。
       ずらす量は、箱の左はしが θ の文字より右に来るように、そのつど計算する。 */
    var txF = 'μ\'N は運動と逆向き → 負の仕事！';
    ctx.save(); ctx.font = 'bold 11.5px ' + FONT;
    var wF = ctx.measureText(txF).width + 18;
    ctx.restore();
    var dxF = clamp(x0 + 116 + wF / 2 - fmx, 0, wF / 2 + 80);
    /* 地面より下は「A の吹きだし」の帯なので、そこまで下げない */
    bubble(ctx, txF, fmx, Math.min(fmy - ny * 30, gy - 18),
      { size: 11.5, up: true, dx: dxF, bg: '#eef2f7', border: COL.eE, color: '#28323d' });
  },
  resItems: function (v) {
    return [
      { k: '引く長さ $L$', v: fmt(P.m25.L, 1) + ' m' },
      { k: '動きだすのに必要な力（式）', v: fmt(P.m25.need(v), 1) + ' N' },
      { k: '上がった高さ $L\\sin\\theta$', v: fmt(P.m25.L * Math.sin(v.th * DEG), 2) + ' m' },
      { k: '$B$ での速さ（式）', v: fmt(P.m25.vEnd(v), 2) + ' m/s' }
    ];
  },
  info: function (s, t) {
    var v = V(s), m = DEFS['m2-5'].sample(v, t);
    return [
      ['斜面にそって進んだ距離', fmt(m.s, 2) + ' m'],
      ['動摩擦力 $\\mu\' mg\\cos\\theta$', fmt(m.f, 2) + ' N'],
      ['加速度 $a$', fmt(P.m25.a(v), 2) + ' m/s²'],
      ['糸の力がした仕事', fmt(v.Ft * m.s, 2) + ' J'],
      ['動摩擦力がした仕事', fmt(-m.f * m.s, 2) + ' J']
    ];
  },
  eq: function (s) {
    var v = V(s);
    return '\\tfrac{1}{2}mv^2 + mgL\\sin\\theta = FL - \\mu\' mg\\cos\\theta\\,L \\;\\Rightarrow\\; v = ' +
      fmt(P.m25.vEnd(v), 2) + '\\ \\mathrm{m/s}';
  },
  note: '非保存力は<b>1つとはかぎりません</b>。ここでは<b>糸の力（正の仕事）</b>と' +
    '<b>動摩擦力（負の仕事）</b>の2つがはたらいています。' +
    '$E$ の変化は、この2つの仕事を<b>合計した分</b>です（$E_2-E_1=W_{\\text{非保存}}$）。' +
    '「仕事を表示」で1つずつ見ると、正と負がはっきり分かります。'
};
