/* 起動とテスト用フック */
'use strict';
(function () {
  initState();
  drawLegend();
  renderMath(document.body);

  var hp = parseHash(location.hash);
  if (!DEFS[hp.id]) hp.id = 'm1-1';
  st.cur = hp.id;
  buildTabs();
  buildPanel();
  renderActive();
  updateUrlBar();

  window.addEventListener('hashchange', function () {
    if (st._skipHash) { st._skipHash = false; return; }
    var q = parseHash(location.hash);
    if (!DEFS[q.id]) return;
    if (q.id !== st.cur) gotoSim(q.id);
  });

  $('urlcopy').addEventListener('click', function () {
    var txt = location.href.indexOf('#') >= 0 ? location.href : location.href + '#' + st.cur;
    var done = function () { $('urlmsg').textContent = 'コピーしました'; };
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(txt).then(done, fallback);
      } else fallback();
    } catch (e) { fallback(); }
    function fallback() {
      var ta = document.createElement('textarea');
      ta.value = txt; document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); done(); }
      catch (e2) { $('urlmsg').textContent = '手動でコピーしてください'; }
      document.body.removeChild(ta);
    }
  });

  if (document.fonts && document.fonts.ready && document.fonts.ready.then) {
    document.fonts.ready.then(function () { refitFormulas(); placeModeTip(); });
  }
  window.addEventListener('resize', function () {
    refitFormulas(); placeModeTip(); drawStep($('stepCv'));
  });
  /* 説明文の中の「1-10 を見る」などのリンクで、そのシミュレーションへ飛ぶ */
  document.addEventListener('click', function (e) {
    var el = e.target;
    while (el && el !== document) {
      if (el.getAttribute && el.getAttribute('data-goto')) {
        var id = el.getAttribute('data-goto');
        if (DEFS[id]) { e.preventDefault(); gotoSim(id); }
        return;
      }
      el = el.parentNode;
    }
  });

  requestAnimationFrame(tick);

  /* ===== 自動テスト用のフック ===== */
  window.TEST = {
    sims: function () { return Object.keys(DEFS); },
    state: function () {
      var s = st.sims[st.cur];
      return { sim: st.cur, v: JSON.parse(JSON.stringify(s.v)), o: JSON.parse(JSON.stringify(s.o)), t: +s.t.toFixed(4) };
    },
    goto: function (id) { gotoSim(id); window.TEST.pause(); return st.cur; },
    pause: function () {
      var s = st.sims[st.cur];
      s.playing = false; s.t = 0;
      setPlayLabel(); renderActive();
      return +s.t.toFixed(4);
    },
    set: function (o) {
      var s = st.sims[st.cur];
      if (o.vars) Object.keys(o.vars).forEach(function (k) { if (k in s.v) s.v[k] = o.vars[k]; });
      if (o.opts) Object.keys(o.opts).forEach(function (k) { s.o[k] = o.opts[k]; });
      if (o.t !== undefined) s.t = o.t; else s.t = 0;
      s.playing = false;
      buildPanel();
      renderActive();
      return window.TEST.state();
    },
    /* 運動を最後まで進めた状態にする（吹きだしとくらべる式を出す） */
    toEnd: function () {
      var s = st.sims[st.cur], d = DEFS[st.cur];
      s._played = true;
      s.t = d.tEnd(V(s));
      s.playing = false;
      setPlayLabel(); renderActive();
      return +s.t.toFixed(4);
    },
    act: function (i) {
      var b = document.getElementById('act_' + i);
      if (!b) return null;
      b.click(); window.TEST.pause();
      return window.TEST.state();
    },
    openAll: function () { toggleAllGraphs(); return window.TEST.graphsOpen(); },
    graphsOpen: function () { return JSON.parse(JSON.stringify(st.sims[st.cur].open)); },
    graphMap: function (key) {
      var cv = document.getElementById('gc_' + key);
      if (!cv || !cv._map) return null;
      var m = cv._map;
      return { xmin: +m.xmin.toFixed(4), xmax: +m.xmax.toFixed(4), ymin: +m.ymin.toFixed(4), ymax: +m.ymax.toFixed(4) };
    },
    gview: function (key, view) {
      var s = st.sims[st.cur];
      if (view === undefined) return s.gview[key] || null;
      if (view === null) delete s.gview[key]; else s.gview[key] = view;
      renderActive();
      return s.gview[key] || null;
    },
    /* 横軸（時間）の目盛りが、運動の終わりまで届いているか */
    xTicks: function () {
      var d = DEFS[st.cur], s = st.sims[st.cur], out = {};
      /* ★グラフの横軸は d.tGraph があればそちら★（第14回）
         2-4 は「止まったあと、もう一度はじめから再生して点 B で止める」ので、
         アニメの長さ（tEnd）とグラフの長さ（tGraph）がちがう。 */
      var T = (d.tGraph ? d.tGraph(V(s)) : d.tEnd(V(s)));
      graphsOf(d, s).forEach(function (g) {
        var cv = document.getElementById('gc_' + g.key);
        if (!s.open[g.key] || !cv || !cv._map) return;
        var m = cv._map, last = null, i;
        for (i = Math.ceil(m.xmin / m.xstep) * m.xstep; i <= m.xmax + 1e-9; i += m.xstep) {
          if (Math.abs(i) > 1e-9) last = i;
        }
        out[g.key] = { T: +T.toFixed(4), xmax: +m.xmax.toFixed(4), step: +m.xstep.toFixed(4),
          last: last === null ? null : +last.toFixed(4), ok: last !== null && last >= T - 1e-6 };
      });
      return out;
    },
    formulas: function () {
      var d = DEFS[st.cur], s = st.sims[st.cur], out = {};
      graphsOf(d, s).forEach(function (g) { if (g.fml) out[g.key] = g.fml(V(s), s); });
      return out;
    },
    readout: function () {
      return Array.prototype.map.call(document.querySelectorAll('#readout tr'), function (tr) {
        return tr.children[0].textContent + '=' + tr.children[1].textContent;
      });
    },
    /* 計算結果の帯 */
    resbar: function () {
      return Array.prototype.map.call(document.querySelectorAll('#resbar .ritem'), function (el) {
        return el.querySelector('.rk').textContent + '=' + el.querySelector('.rv').textContent;
      });
    },
    /* 各点の表（記号と数値） */
    ptab: function () {
      return Array.prototype.map.call(document.querySelectorAll('#ptab tr'), function (tr) {
        return Array.prototype.map.call(tr.children, function (td) { return td.textContent; }).join('|');
      });
    },
    /* 図の下の立式3つ（出ているかどうかも返す） */
    compare: function () {
      var box = document.getElementById('eqzone');
      return { shown: box ? !box.hidden : null, text: box ? box.textContent : '' };
    },
    /* 立式3つの見出し・開閉と、「仕事を表示」のボタン */
    eqzone: function () {
      var box = document.getElementById('eqzone');
      if (!box || box.hidden) return { shown: false, secs: [], pairs: [] };
      return {
        shown: true,
        allEq: !!st.allEq,
        secs: Array.prototype.map.call(box.querySelectorAll('.eqsec'), function (el) {
          return { key: el.id.replace('eqs_', ''),
            title: el.querySelector('.eqttl').textContent,
            badge: el.querySelector('.badge').textContent,
            open: el.className.indexOf('open') >= 0 };
        }),
        title: (function () {
          var e2 = box.querySelector('.eqztitle');
          return e2 ? e2.textContent : '';
        })(),
        pairs: Array.prototype.map.call(box.querySelectorAll('.eqpair'), function (b) {
          return b.textContent + (b.className.indexOf('on') >= 0 ? '*' : '');
        })
      };
    },
    /* 「仕事の分析」モードに入る／出る（★全シム共通★） */
    workMode: function (on) {
      /* ★第6回からボタンは2つ★（「エネルギーのグラフを表示」／「仕事の分析」）。
         入るときと出るときで、おすボタンがちがう。 */
      var b = document.getElementById(on ? 'bWork' : 'bGraphMode');
      if (b && !!st.workMode !== !!on) b.click();
      return { on: !!st.workMode, label: b ? b.textContent : null,
        graphsShown: !document.getElementById('gwrap').hidden,
        panelShown: !document.getElementById('wkpanel').hidden };
    },
    /* 仕事の分析の欄の中身（力・正負・仕事の値・合計） */
    workPanel: function () {
      var el = document.getElementById('wkpanel');
      if (!el || el.hidden) return { shown: false, cards: [] };
      return {
        shown: true,
        cards: Array.prototype.map.call(el.querySelectorAll('.wkcard'), function (c) {
          return { key: c.id.replace('wkc_', ''),
            badge: c.querySelector('.wkbadge') ? c.querySelector('.wkbadge').textContent : '',
            val: c.querySelector('.wkval') ? c.querySelector('.wkval').textContent : '' };
        }),
        sum: el.querySelector('.wksum') ? el.querySelector('.wksum').textContent : ''
      };
    },
    /* 図の中の「クリックできる力」の場所（仕事の分析モードのとき） */
    /* ★検算用★ ゴーストの速度ベクトルの「長さ ÷ 速さ」が全点で同じか
       （＝矢印の長さの比が速さの比と合っているか）。第7回の直しの見張り。 */
    ghostVel: function () {
      var g = st._vGhost || [], out = [], i, r, r0 = null, err = 0;
      for (i = 0; i < g.length; i++) {
        if (!(g[i].v > 0.02)) continue;
        r = g[i].L / g[i].v;
        if (r0 === null) r0 = r;
        else err = Math.max(err, Math.abs(r - r0) / Math.max(1e-9, r0));
        out.push({ n: g[i].n, v: +g[i].v.toFixed(3), L: +g[i].L.toFixed(2) });
      }
      return { pts: out, ratio_err: +err.toFixed(6) };
    },
    forceHits: function () {
      return (st._fHits || []).map(function (h) {
        return { key: h.key, x: Math.round(h.x), y: Math.round(h.y),
          w: Math.round(h.w), h: Math.round(h.h) };
      });
    },
    /* その力をクリックしたことにする（欄が光る） */
    clickForce: function (key) {
      flashWork(key);
      var el = document.getElementById('wkc_' + key);
      return el ? el.className : null;
    },
    /* 立式でくらべる2点を選ぶ（j＝2つめの点の番号） */
    eqPairs: function (j) {
      var bs = document.querySelectorAll('#eqzone .eqpair');
      if (j !== undefined && bs[j - 1]) bs[j - 1].click();
      return Array.prototype.map.call(document.querySelectorAll('#eqzone .eqpair'), function (b) {
        return b.textContent + (b.className.indexOf('on') >= 0 ? '*' : '');
      });
    },
    eqTitle: function () {
      var el = document.querySelector('#eqzone .eqztitle');
      return el ? el.textContent : null;
    },
    /* 立式の見出しをおす（'cons' / 'rel' / 'wk'）／「3つの式を表示」を切りかえる */
    eqToggle: function (k) {
      var b = document.querySelector('#eqzone [data-eqk="' + k + '"]');
      if (b) b.click();
      return window.TEST.eqzone().secs;
    },
    allEq: function (on) {
      var cb = document.getElementById('cbAllEq');
      /* ★click() を使う★ dispatchEvent(new Event('change')) は bubbles が false なので、
         #eqzone に付けた委譲のハンドラに届かない（テストだけ動かなくてハマった）。 */
      if (cb && cb.checked !== !!on) cb.click();
      return window.TEST.eqzone().secs;
    },
    /* ステップ図の中身 */
    step: function () {
      var D = stepData();
      return { ok: D.ok, eq: D.eq, why: D.why, rows: D.rows };
    },
    /* 図の中の文字の重なりを調べる（__labelLog を使う） */
    labelOverlap: function () {
      var log = window.__labelLog || [], out = [], i, j;
      function box(a) { return { x1: a.x, y1: a.y - a.h / 2, x2: a.x + a.w, y2: a.y + a.h / 2, t: a.text, cv: a.cv }; }
      for (i = 0; i < log.length; i++) {
        for (j = i + 1; j < log.length; j++) {
          if (log[i].cv !== log[j].cv) continue;
          var A = box(log[i]), B = box(log[j]);
          var ox = Math.min(A.x2, B.x2) - Math.max(A.x1, B.x1);
          var oy = Math.min(A.y2, B.y2) - Math.max(A.y1, B.y1);
          if (ox > 3 && oy > 3) out.push({ a: A.t, b: B.t, cv: A.cv, ox: +ox.toFixed(1), oy: +oy.toFixed(1) });
        }
      }
      return out;
    },

    /* ===== 物理の検算（UI の状態によらない固定の計算） ===== */
    check: function () {
      var r = {}, i, k;

      /* E のずれ [%]（保存系では 0.1 % 未満でなければならない） */
      function drift(id, v) {
        var d = DEFS[id], T = d.tEnd(v), N = 600, E0 = d.sample(v, 0).E, mx = 0, sc = 0;
        for (var q = 0; q <= N; q++) {
          var m0 = d.sample(v, T * q / N);
          mx = Math.max(mx, Math.abs(m0.E - E0));
          /* 1-10・2-3 は基準面のとり方で E = 0 になる。0 で割らないよう
             「エネルギーの大きさ」でわり算する */
          sc = Math.max(sc, Math.abs(m0.K), Math.abs(m0.Ug), Math.abs(m0.Us), Math.abs(E0));
        }
        return +(mx / Math.max(1e-9, sc) * 100).toFixed(5);
      }
      r.drift_m11 = drift('m1-1', { v0: 4, m: 2 });
      r.drift_m12 = drift('m1-2', { h: 5, m: 1 });
      r.drift_m12b = drift('m1-2', { h: 20, m: 3 });
      r.drift_m13_30 = drift('m1-3', { th: 30, h: 3, m: 2 });
      r.drift_m13_75 = drift('m1-3', { th: 75, h: 5, m: 2 });
      r.drift_m14 = drift('m1-5', { h: 3, m: 1 });
      r.drift_m14b = drift('m1-5', { h: 5, m: 2 });
      r.drift_m15 = drift('m1-6', { th: 40, v0: 0, l: 1, m: 1 });
      r.drift_m15b = drift('m1-6', { th: 70, v0: 2, l: 1.6, m: 2 });
      r.drift_max = Math.max(r.drift_m11, r.drift_m12, r.drift_m12b, r.drift_m13_30,
        r.drift_m13_75, r.drift_m14, r.drift_m14b, r.drift_m15, r.drift_m15b);

      /* 自由落下 v = √(2gh) */
      var f = { h: 5, m: 1 };
      r.fall_v = +P.m12.sample(f, P.m12.tEnd(f)).v.toFixed(6);
      r.fall_v_formula = +Math.sqrt(2 * G * f.h).toFixed(6);
      r.fall_T = +P.m12.tEnd(f).toFixed(6);
      r.fall_E_start = +P.m12.sample(f, 0).E.toFixed(6);      /* = mgh */
      r.fall_E_end = +P.m12.sample(f, P.m12.tEnd(f)).E.toFixed(6);

      /* 直線の滑り台：傾きによらず下端の速さが同じ */
      r.slope_v = [15, 30, 45, 60, 75].map(function (th) {
        var v = { th: th, h: 3, m: 2 };
        return +P.m13.sample(v, P.m13.tEnd(v)).v.toFixed(4);
      }).join(',');
      r.slope_v_formula = +Math.sqrt(2 * G * 3).toFixed(4);
      r.slope_t = [15, 30, 45, 60, 75].map(function (th) {
        return +P.m13.tEnd({ th: th, h: 3, m: 2 }).toFixed(3);
      }).join(',');

      /* 曲線の滑り台：数値計算でも下端の速さが √(2gh) と合う */
      var c1 = { h: 3, m: 1 }, tc = P.m14.tEnd(c1);
      r.curve_v = +P.m14.sample(c1, tc).v.toFixed(4);
      r.curve_v_formula = +Math.sqrt(2 * G * 3).toFixed(4);
      r.curve_v_err_pct = +(Math.abs(P.m14.sample(c1, tc).v - Math.sqrt(2 * G * 3)) /
        Math.sqrt(2 * G * 3) * 100).toFixed(4);
      r.curve_same_as_line = +Math.abs(P.m14.vEnd(c1) - P.m13.vEnd({ th: 30, h: 3 })).toFixed(9);

      /* 振り子 v = √(2gl(1−cosθ)) */
      var p1 = { th: 40, v0: 0, l: 1, m: 1 };
      r.pend_v = +P.m15.sample(p1, P.m15.tBottom(p1)).v.toFixed(4);
      r.pend_v_formula = +Math.sqrt(2 * G * 1 * (1 - Math.cos(40 * DEG))).toFixed(4);
      r.pend_v_err_pct = +(Math.abs(P.m15.sample(p1, P.m15.tBottom(p1)).v - P.m15.vBottom(p1)) /
        P.m15.vBottom(p1) * 100).toFixed(4);
      r.pend_T = +P.m15.tEnd(p1).toFixed(4);
      /* 小さな振れなら T ≈ 2π√(l/g) */
      var p2 = { th: 10, v0: 0, l: 1, m: 1 };
      r.pend_T_small = +P.m15.tEnd(p2).toFixed(4);
      r.pend_T_ideal = +(2 * Math.PI * Math.sqrt(1 / G)).toFixed(4);
      /* 1周期まわると、はじめの状態にもどる */
      var pa = P.m15.sample(p1, 0), pb = P.m15.sample(p1, P.m15.tEnd(p1));
      r.pend_loop_dth = +Math.abs(pa.th - pb.th).toFixed(6);

      /* 摩擦：E(t) − E(0) = W(t) がいつでも成り立つ／止まる位置が式と合う */
      var w1 = { v0: 5, mu: 0.3, m: 2 }, mx2 = 0, N2 = 500;
      for (i = 0; i <= N2; i++) {
        var q2 = P.m21.sample(w1, P.m21.tEnd(w1) * i / N2);
        mx2 = Math.max(mx2, Math.abs((q2.E - P.m21.sample(w1, 0).E) - q2.W));
      }
      r.fric_identity_max = +mx2.toFixed(9);
      r.fric_L = +P.m21.xStop(w1).toFixed(6);
      r.fric_L_formula = +(w1.v0 * w1.v0 / (2 * w1.mu * G)).toFixed(6);
      r.fric_x_at_stop = +P.m21.sample(w1, P.m21.tStop(w1)).x.toFixed(6);
      r.fric_E_end = +P.m21.sample(w1, P.m21.tStop(w1)).E.toFixed(9);
      r.fric_W_end = +P.m21.sample(w1, P.m21.tStop(w1)).W.toFixed(6);
      r.fric_E0 = +P.m21.sample(w1, 0).E.toFixed(6);

      /* ===== 1-4 滑台（直線）2：斜面を昇る ===== */
      var su = { v0: 6, th: 30, m: 2 };
      r.up_h = +P.slopeUp.sample(su, P.slopeUp.tEnd(su)).h.toFixed(6);
      r.up_h_formula = +(su.v0 * su.v0 / (2 * G)).toFixed(6);
      /* ★θ を変えても上がる高さは同じ★ */
      r.up_h_by_theta = [15, 30, 45, 60, 75].map(function (th) {
        var q = { v0: 6, th: th, m: 2 };
        return +P.slopeUp.sample(q, P.slopeUp.tEnd(q)).h.toFixed(4);
      }).join(',');
      r.up_L = +P.slopeUp.len(su).toFixed(6);
      r.up_v_at_top = +P.slopeUp.sample(su, P.slopeUp.tEnd(su)).v.toFixed(9);
      r.drift_up = drift('m1-4', su);

      /* ===== 1-7 ジェットコースター（ループ＋斜面） ===== */
      var cw1 = { v0: 14, th: 40, m: 200 };
      r.drift_cyl = drift('m1-7', cw1);
      r.drift_cylb = drift('m1-7', { v0: 16, th: 60, m: 500 });
      r.coast_vB = +P.coaster.sample(cw1, P.coaster.tB(cw1)).v.toFixed(3);
      r.coast_vB_formula = +P.coaster.vB(cw1).toFixed(3);
      r.coast_hB = +P.coaster.sample(cw1, P.coaster.tB(cw1)).h.toFixed(3);
      r.coast_hB_formula = +P.coaster.D.toFixed(3);
      r.coast_hC = +P.coaster.sample(cw1, P.coaster.tTop(cw1)).h.toFixed(2);
      r.coast_hC_formula = +P.coaster.hC(cw1).toFixed(2);
      r.coast_v_at_top = +P.coaster.sample(cw1, P.coaster.tTop(cw1)).v.toFixed(6);
      /* ★第18回★ 帰りにスタート地点へもどったときの速さは v0 にもどる */
      r.coast_v_back_at_A = +P.coaster.sample(cw1, P.coaster.tEnd(cw1)).v.toFixed(4);
      r.coast_x_back_at_A = +P.coaster.sample(cw1, P.coaster.tEnd(cw1)).x.toFixed(4);
      /* ★止まる高さは θ によらない★ */
      r.coast_hC_by_theta = [35, 40, 45, 50, 55, 60].map(function (th2) {
        var q = { v0: 14, th: th2, m: 200 };
        return +P.coaster.sample(q, P.coaster.tTop(q)).h.toFixed(2);
      }).join(',');
      /* ★どの設定でもループを1周できる（頂上で v² ≥ gR）★ */
      var okLoop = 1;
      for (var vv = 14; vv <= 16.0001; vv += 0.5) {
        [35, 40, 45, 50, 55, 60].forEach(function (th3) {
          [100, 200, 300, 400, 500].forEach(function (m4) {
            if (!P.coaster.loopOK({ v0: vv, th: th3, m: m4 })) okLoop = 0;
          });
        });
      }
      r.coast_loop_ok_all = okLoop;

      /* ===== 1-10 水平ばねにぶつかる ===== */
      var hs1 = { v0: 4, k: 200, m: 1.0 };
      r.hit_xmax = +P.hitSpring.sample(hs1, P.hitSpring.tC(hs1)).x.toFixed(6);
      r.hit_xmax_formula = +(hs1.v0 * Math.sqrt(hs1.m / hs1.k)).toFixed(6);
      r.hit_vB = +P.hitSpring.sample(hs1, P.hitSpring.t1(hs1)).v.toFixed(6);
      r.hit_v0 = +hs1.v0.toFixed(6);                  /* A→B で速さは変わらない */
      r.hit_K_at_C = +P.hitSpring.sample(hs1, P.hitSpring.tC(hs1)).K.toFixed(6);
      r.hit_Us_at_C = +P.hitSpring.sample(hs1, P.hitSpring.tC(hs1)).Us.toFixed(6);
      r.hit_E0 = +P.hitSpring.sample(hs1, 0).E.toFixed(6);
      r.drift_hit = drift('m1-10', hs1);

      /* ===== 1-11 水平ばねと滑台 ===== */
      var ss1 = { x0: 0.75, k: 35, m: 1.0 };
      r.spsl_vB = +P.sprSlide.sample(ss1, P.sprSlide.t1(ss1)).v.toFixed(6);
      r.spsl_vB_formula = +P.sprSlide.vB(ss1).toFixed(6);
      r.spsl_hC = +P.sprSlide.sample(ss1, P.sprSlide.tC(ss1)).h.toFixed(4);
      r.spsl_hC_formula = +P.sprSlide.hC(ss1).toFixed(4);
      r.spsl_v_at_C = +P.sprSlide.sample(ss1, P.sprSlide.tC(ss1)).v.toFixed(6);
      /* ★x0 を2倍にすると高さは4倍★ */
      r.spsl_h_ratio = +(P.sprSlide.hC({ x0: 0.90, k: 35, m: 1 }) /
        P.sprSlide.hC({ x0: 0.45, k: 35, m: 1 })).toFixed(4);
      /* ★どの設定でも坂のてっぺんを越えない★ */
      var okHill = 1;
      [0.45, 0.55, 0.65, 0.75, 0.85, 0.90].forEach(function (x0b) {
        [20, 25, 30, 35, 40].forEach(function (kb) {
          [1.0, 1.25, 1.5, 1.75, 2.0].forEach(function (mb) {
            if (!(P.sprSlide.hC({ x0: x0b, k: kb, m: mb }) < P.sprSlide.yTop() - 0.05)) okHill = 0;
          });
        });
      });
      r.spsl_fits_hill_all = okHill;
      r.drift_spsl = drift('m1-11', ss1);

      /* ===== 1-8 斜方投射 ===== */
      var pj = { v0: 8, th: 40, h: 2, m: 1 };
      r.proj_vend = +P.m17.sample(pj, P.m17.tEnd(pj)).v.toFixed(6);
      r.proj_vend_formula = +Math.sqrt(pj.v0 * pj.v0 + 2 * G * pj.h).toFixed(6);
      r.proj_ytop = +P.m17.sample(pj, P.m17.tTop(pj)).h.toFixed(6);
      r.proj_ytop_formula = +P.m17.yTop(pj).toFixed(6);
      r.proj_vtop = +P.m17.sample(pj, P.m17.tTop(pj)).v.toFixed(6);
      r.proj_vtop_formula = +P.m17.vx(pj).toFixed(6);
      r.drift_m17 = drift('m1-8', pj);

      /* ===== 1-9 水平ばね：½kx₀² = ½mv² ===== */
      var s8 = { x0: 0.3, k: 40, m: 1.0 };
      r.spr_vmax = +P.m18.sample(s8, P.m18.tNat(s8)).v.toFixed(6);
      r.spr_vmax_formula = +Math.sqrt(v18E(s8) * 2 / s8.m).toFixed(6);
      function v18E(q) { return 0.5 * q.k * q.x0 * q.x0; }
      r.spr_Us0 = +EN.Us(s8.k, s8.x0).toFixed(6);
      r.spr_K_at_nat = +P.m18.sample(s8, P.m18.tNat(s8)).K.toFixed(6);
      r.drift_m18 = drift('m1-9', s8);

      /* ===== 1-12 鉛直ばね：E が一定、最下点 x = 2mg/k ===== */
      var s9 = { d: 0, k: 50, m: 1.0 };
      r.vspr_xeq = +P.m19.xEq(s9).toFixed(6);
      r.vspr_xlow = +P.m19.xLow(s9).toFixed(6);
      r.vspr_xlow_formula = +(2 * s9.m * G / s9.k).toFixed(6);
      r.vspr_x_at_tlow = +P.m19.sample(s9, P.m19.tLow(s9)).x.toFixed(6);
      r.vspr_veq = +P.m19.sample(s9, P.m19.tEq(s9)).v.toFixed(6);
      r.vspr_veq_formula = +Math.abs(P.m19.vEq(s9)).toFixed(6);
      r.drift_m19 = drift('m1-12', s9);
      r.drift_m19b = drift('m1-12', { d: 0.1, k: 30, m: 1.0 });

      /* ===== 1-11 曲面から飛び出す ===== */
      var s10 = { h: 2.5, v0: 0, m: 1 };
      r.drift_m110 = drift('m1-13', s10);
      r.drift_m110b = drift('m1-13', { h: 3.5, v0: 3, m: 2 });
      r.bowl_vB = +P.m110.sample(s10, P.m110.tB(s10)).v.toFixed(4);
      r.bowl_vB_formula = +P.m110.vB(s10).toFixed(4);
      r.bowl_vC = +P.m110.sample(s10, P.m110.tC(s10)).v.toFixed(4);
      r.bowl_vC_formula = +P.m110.vC(s10).toFixed(4);
      r.bowl_hD = +P.m110.sample(s10, P.m110.tD(s10)).h.toFixed(3);
      r.bowl_hD_formula = +P.m110.hD(s10).toFixed(3);
      /* 最高点 D は「飛び出したあと」にある */
      r.bowl_tD_after_tC = P.m110.tD(s10) > P.m110.tC(s10) ? 1 : 0;
      /* ★飛び出す条件の見張り★（第9回）
         「N ≤ 0 になった所で面から離れるべきでは？」という指摘への答え。
         くぼみ（凹の面）では N = m(g cosθ + v²/R) がいつでも正なので、
         円の上で面から離れることは起こらない。どの設定でも N > 0 かを確かめる。 */
      var nmin = Infinity, nmov = Infinity, nAtC = Infinity, nneg = 0, iv0, ih, iq;
      for (iv0 = 0; iv0 <= 4; iv0 += 0.5) {
        for (ih = 1.5; ih <= 3.5001; ih += 0.1) {
          var vN = { h: +ih.toFixed(1), v0: iv0, m: 1 }, tbN = P.m110.table(vN).tab;
          for (iq = 0; iq < tbN.length; iq++) {
            if (!tbN[iq].on || tbN[iq].wall) continue;
            var nn = P.m110.Nof(vN, tbN[iq]);
            if (nn < 0) nneg++;
            nmin = Math.min(nmin, nn);
            if (tbN[iq].v > 0.05) nmov = Math.min(nmov, nn);
          }
          nAtC = Math.min(nAtC, vN.m * (G * Math.cos(P.m110.PHI) +
            P.m110.vC(vN) * P.m110.vC(vN) / P.m110.R));
        }
      }
      /* しらべた設定の数：v0 = 0〜4（0.5 きざみ）× h = 1.5〜3.5（0.1 きざみ）＝ 189 通り */
      r.bowl_N_min = +nmin.toPrecision(3);      /* 円の上でいちばん小さい N（＝はなす瞬間） */
      r.bowl_N_min_moving = +nmov.toFixed(3);   /* 動いているあいだのいちばん小さい N */
      r.bowl_N_at_C = +nAtC.toFixed(3);         /* 飛び出す点 C での N */
      r.bowl_N_negative_count = nneg;           /* N < 0 になった回数（0 でなければならない） */
      r.bowl_N_always_pos = nneg === 0 ? 1 : 0; /* 1 なら「面から離れることはない」 */

      /* ===== 2-2 あらい斜面を上る ===== */
      var s22 = { v0: 6, th: 30, mu: 0.25, m: 2 }, mx22 = 0, E22 = P.m22.sample(s22, 0).E;
      for (i = 0; i <= 500; i++) {
        var q22 = P.m22.sample(s22, P.m22.tStop(s22) * i / 500);
        mx22 = Math.max(mx22, Math.abs((q22.E - E22) - q22.W));
      }
      r.rough_identity_max = +mx22.toFixed(9);
      r.rough_L = +P.m22.sStop(s22).toFixed(6);
      r.rough_L_formula = +(s22.v0 * s22.v0 /
        (2 * G * (Math.sin(30 * DEG) + s22.mu * Math.cos(30 * DEG)))).toFixed(6);
      r.rough_L_smooth = +(s22.v0 * s22.v0 / (2 * G * Math.sin(30 * DEG))).toFixed(6);
      r.rough_v_at_stop = +P.m22.sample(s22, P.m22.tStop(s22)).v.toFixed(9);

      /* ===== 2-3 手でゆっくり下ろす：E(t) − E(0) = W_手(t) ===== */
      var s23 = { d: 0, k: 50, m: 1.0 }, mx23 = 0, E23 = P.m23.sample(s23, 0).E;
      for (i = 0; i <= 500; i++) {
        var q23 = P.m23.sample(s23, P.m23.T * i / 500);
        mx23 = Math.max(mx23, Math.abs((q23.E - E23) - q23.W));
      }
      r.hand_identity_max = +mx23.toFixed(6);
      r.hand_W_end = +P.m23.W(s23, P.m23.T).toFixed(4);
      /* 両はしで K=0 なので W = ΔU（＝ ½kx_eq² − mg·x_eq、d=0 のとき） */
      r.hand_W_formula = +(EN.Us(s23.k, P.m23.xEq(s23)) - s23.m * G * P.m23.xEq(s23) -
        (EN.Us(s23.k, s23.d) - s23.m * G * s23.d)).toFixed(4);
      /* 手をはなしたときの最下点（1-12）は、つりあいの位置の2倍 */
      r.hand_xeq = +P.m23.xEq(s23).toFixed(6);
      r.hand_xlow_free = +P.m23.xLow(s23).toFixed(6);

      /* ===== 2-4 摩擦がある水平面のばね ===== */
      var s24 = { x0: 0.30, k: 40, m: 1.0, mu: 0.10 }, mx24 = 0, E24 = P.m24.sample(s24, 0).E;
      for (i = 0; i <= 800; i++) {
        var q24 = P.m24.sample(s24, P.m24.tEnd(s24) * i / 800);
        mx24 = Math.max(mx24, Math.abs((q24.E - E24) - q24.W));
      }
      r.sprfric_identity_max = +mx24.toExponential(2);
      r.sprfric_vnat = +P.m24.sample(s24, P.m24.tNat(s24)).v.toFixed(6);
      r.sprfric_vnat_formula = +P.m24.vNat(s24).toFixed(6);
      /* 自然長を通るとき、伸び x はちょうど 0 */
      r.sprfric_x_at_nat = +Math.abs(P.m24.sample(s24, P.m24.tNat(s24)).x).toExponential(1);
      /* 摩擦なし（1-9）より必ずおそい */
      r.sprfric_slower = P.m24.vNat(s24) < P.m18.vMax({ x0: 0.3, k: 40, m: 1.0 }) ? 1 : 0;
      /* どの設定でも、自然長までは必ずとどく（x0 > 2μ'mg/k） */
      var okReach = 1;
      [0.20, 0.30, 0.40].forEach(function (x0) {
        [40, 70, 100].forEach(function (k2) {
          [0.05, 0.10, 0.15, 0.20].forEach(function (mu) {
            [0.5, 1.0, 1.5].forEach(function (m2) {
              var w2 = { x0: x0, k: k2, m: m2, mu: mu };
              if (!(x0 > 2 * P.m24.xc(w2) + 1e-9) || !(P.m24.vNat(w2) > 0)) okReach = 0;
            });
          });
        });
      });
      r.sprfric_reaches_nat_all = okReach;
      /* 最後に止まる位置は |x| ≤ μ'mg/k（静止摩擦でとまる範囲）の中 */
      r.sprfric_stop_in_band = Math.abs(P.m24.xStop(s24)) <= P.m24.xc(s24) + 1e-9 ? 1 : 0;

      /* ===== 2-5 斜面を糸で引き上げる ===== */
      var s25 = { Ft: 36, mu: 0.30, th: 30, m: 2.0 }, mx25 = 0, E25 = P.m25.sample(s25, 0).E;
      for (i = 0; i <= 500; i++) {
        var q25 = P.m25.sample(s25, P.m25.tEnd(s25) * i / 500);
        mx25 = Math.max(mx25, Math.abs((q25.E - E25) - q25.W));
      }
      r.pull_identity_max = +mx25.toExponential(2);
      r.pull_vend = +P.m25.sample(s25, P.m25.tEnd(s25)).v.toFixed(6);
      r.pull_vend_formula = +P.m25.vEnd(s25).toFixed(6);
      r.pull_h = +P.m25.sample(s25, P.m25.tEnd(s25)).h.toFixed(6);
      r.pull_h_formula = +(P.m25.L * Math.sin(30 * DEG)).toFixed(6);
      /* どの設定でも必ず動きだす（F > mg sinθ + μ' mg cosθ） */
      var okMove = 1;
      for (var Ft = 32; Ft <= 44; Ft += 2) {
        [20, 25, 30, 35, 40, 45].forEach(function (th2) {
          [0.15, 0.25, 0.35, 0.45, 0.50].forEach(function (mu2) {
            [2.0, 2.5, 3.0].forEach(function (m3) {
              var w3 = { Ft: Ft, th: th2, mu: mu2, m: m3 };
              if (!(P.m25.a(w3) > 0) || !isFinite(P.m25.tEnd(w3))) okMove = 0;
            });
          });
        });
      }
      r.pull_moves_all = okMove;

      /* ★各力の仕事の合計 ＝ 運動エネルギーの変化★（全シム） */
      /* 数値積分のシム（1-5・1-6・1-7 など）は E がごくわずかに動くので、
         大きさで割った「割合」で見る。0.01 % より大きければ直すこと。 */
      var wErr = 0, wMiss = [];
      Object.keys(DEFS).forEach(function (id) {
        var d = DEFS[id], v = V(st.sims[id]);
        var ps = ptsOf(d, v), A = ps[0], B = ps[ps.length - 1];
        var sum = 0, sc2 = Math.max(1e-9, Math.abs(A.m.E), Math.abs(B.m.E),
          Math.abs(A.m.K), Math.abs(B.m.K), Math.abs(A.m.U), Math.abs(B.m.U));
        forcesOf(d, v).forEach(function (f) { sum += f.W; });
        var e = Math.abs(sum - (B.m.K - A.m.K)) / sc2 * 100;
        if (e > 0.01) wMiss.push(id + ':' + e.toExponential(2));
        wErr = Math.max(wErr, e);
      });
      r.work_sum_err_pct = +wErr.toExponential(2);
      r.work_sum_bad = wMiss.join(',');

      /* ★エネルギーの棒が枠からはみ出していないか★（全シム・第10回に追加）
         energyBar は【正のものを 0 から上へ、負のものを 0 から下へ】積むので、
         上へのびる長さ＝正のものの合計、下へのびる長さ＝負のものの合計。
         energyRange の lo〜hi がこれを含んでいないと、帯が枠の外へ出てしまう。
         2-3 と 1-12（U_g が負になるシム）で実際に出ていた（先生の指摘・第10回）。 */
      var ebOver = 0, ebBad = [];
      Object.keys(DEFS).forEach(function (id) {
        var d = DEFS[id], sS = st.sims[id], v = V(sS);
        var rg = energyRange(d, sS), T2 = d.tEnd(v), i2, j2, worst = 0;
        var span = Math.max(1e-9, rg.hi - rg.lo);
        for (i2 = 0; i2 <= 200; i2++) {
          var q3 = d.sample(v, T2 * i2 / 200), pos3 = 0, neg3 = 0, e4 = [q3.K, q3.Ug, q3.Us];
          for (j2 = 0; j2 < 3; j2++) {
            if (e4[j2] > 0) pos3 += e4[j2];
            else if (e4[j2] < 0) neg3 += e4[j2];
          }
          worst = Math.max(worst, pos3 - rg.hi, rg.lo - neg3, q3.E - rg.hi, rg.lo - q3.E);
        }
        var pct = worst / span * 100;
        if (pct > 0.01) ebBad.push(id + ':' + pct.toFixed(2) + '%');
        ebOver = Math.max(ebOver, pct);
      });
      r.ebar_overflow_pct = +ebOver.toFixed(4);   /* 0 でなければならない */
      r.ebar_overflow_bad = ebBad.join(',');

      r.drift_max_all = Math.max(r.drift_max, r.drift_up, r.drift_cyl, r.drift_cylb,
        r.drift_m17, r.drift_m18, r.drift_m19, r.drift_m19b, r.drift_m110, r.drift_m110b,
        r.drift_hit, r.drift_spsl);

      /* 表に出している各点の K・U が、グラフ（＝同じ sample）の値と一致する */
      var mism = 0;
      Object.keys(DEFS).forEach(function (id) {
        var d = DEFS[id], s = st.sims[id], v = V(s);
        ptsOf(d, v).forEach(function (pt) {
          var m2 = d.sample(v, pt.t);
          if (Math.abs(m2.K - pt.m.K) > 1e-9 || Math.abs(m2.U - pt.m.U) > 1e-9 ||
            Math.abs(m2.E - (m2.K + m2.U)) > 1e-9) mism++;
        });
      });
      r.ptab_matches_graph = mism;

      /* エネルギーの定義が1か所であること（EN を通した値と手計算が一致） */
      r.en_K = +EN.K(2, 3).toFixed(6);
      r.en_Ug = +EN.Ug(2, 5).toFixed(6);
      r.en_Us = +EN.Us(100, 0.2).toFixed(6);
      return r;
    }
  };
})();
