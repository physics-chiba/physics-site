/* シミュレーションの登録表と、このページ共通の決めごと・描画部品。
   各モードのファイルが DEFS に自分を足していく。 */
'use strict';
var DEFS = {};
var MODES = [
  { n: 1, label: '1　非保存力が仕事をしないケース（力学的エネルギーが保存される）',
    tip: '重力や弾性力（＝<b>保存力</b>）だけが仕事をしています。垂直抗力や糸の張力は運動の向きに垂直なので仕事をしません。だから <b>E = K + U は一定</b>。',
    ids: ['m1-1', 'm1-2', 'm1-3', 'm1-4', 'm1-5', 'm1-6', 'm1-7', 'm1-8', 'm1-9', 'm1-10',
      'm1-11', 'm1-12', 'm1-13'] },
  { n: 2, label: '2　非保存力が仕事をするケース（力学的エネルギーが保存されない）',
    tip: '摩擦力や手の力（＝<b>非保存力</b>）が仕事をしたら？',
    ids: ['m2-1', 'm2-2', 'm2-3', 'm2-4', 'm2-5'] }
];

/* ===== 文字まわりの共通ルール ===== */

/* 「$…$」を KaTeX で組む span に変える（添え字をきれいに出すため）。
   $…$ を書いた文字列は、必ずこれを通すこと（通し忘れると生の $ が画面に出る）。 */
function mathHtml(str) {
  var out = '', i = 0;
  str = String(str);
  while (i < str.length) {
    var a = str.indexOf('$', i);
    if (a === -1) { out += str.slice(i); break; }
    out += str.slice(i, a);
    var b = str.indexOf('$', a + 1);
    if (b === -1) { out += str.slice(a); break; }
    out += '<span class="tex">' + escTex(str.slice(a + 1, b)) + '</span>';
    i = b + 1;
  }
  return out;
}

/* KaTeX に渡す式の中の & < > を実体参照にする（innerHTML に入れる前に必ず通す）。
   通さないと「$K<U$」の < 以降がタグと見なされて文が消える。 */
function escTex(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

/* 図の中の「ヒントになる言葉」（答えにつながる説明）を出してよいか。
   ・スタートを押して動き出してから出す（先に答えを見せない）
   ・軸名・時刻・力や速さの値・物の名前・操作の説明は、これで囲まなくてよい */
function hintOn(s, t) { return t > 1e-9; }

/* 「運動が終わったか」。吹きだしと「2点をくらべる式」はこれで囲む。 */
function endOn(d, s, t) { return t >= d.tEnd(V(s)) - 1e-6; }

/* 同じ文字を書き直さない（毎フレームの DOM 書きこみを減らす） */
function setText(el, txt) { if (el && el.textContent !== txt) el.textContent = txt; }
function setCls(el, cls) { if (el && el.className !== cls) el.className = cls; }

/* 質量 m に応じて物体の「見た目の大きさ」を変える倍率（basics と同じ決めごと） */
function mSize(d, v) {
  if (!d || !v || typeof v.m !== 'number' || !(v.m > 0)) return 1;
  var vs = d.vars || [], md = null, i;
  for (i = 0; i < vs.length; i++) if (vs[i].k === 'm') md = vs[i];
  if (!md) return 1;
  var ref = md.def;
  if (!(ref > 0)) return 1;
  return clamp(Math.pow(v.m / ref, 1 / 3), 0.78, 1.45);
}

/* KaTeX の式を、canvas に書ける「ふつうの文字」に直す。
   canvas は KaTeX を組めないので、ステップ図の表などはこれを通すこと
   （通さないと画面に \tfrac{1}{2}mv^2 と生の LaTeX が出る）。 */
function texPlain(s) {
  return String(s)
    .replace(/\\tfrac\{1\}\{2\}/g, '½').replace(/\\frac\{1\}\{2\}/g, '½')
    .replace(/\^\{\\,2\}/g, '²').replace(/\^\{2\}/g, '²').replace(/\^2/g, '²')
    .replace(/_\{0\}/g, '₀').replace(/_0/g, '₀')
    .replace(/\\cos/g, 'cos').replace(/\\sin/g, 'sin')
    .replace(/\\theta/g, 'θ').replace(/\\mu/g, 'μ')
    .replace(/\^\{?\\circ\}?/g, '°').replace(/\\circ/g, '°')
    .replace(/\\text\{([^}]*)\}/g, '$1')
    .replace(/\\,/g, '').replace(/\\;/g, ' ')
    /* 添字の中かっこは残す（label が _{…} を小さい字で描くため）。
       いったん見えない印に置きかえて、ほかの { } を消してから、もどす。 */
    .replace(/_\{([^}]*)\}/g, '\u0001$1\u0002')
    .replace(/[{}]/g, '')
    .replace(/\u0001/g, '_{').replace(/\u0002/g, '}');
}

/* ===== エネルギーの表示の決めごと ===== */
var EJ = ' J';
/* エネルギーの数値。★1000 J 以上は小数点以下を出さない★
   （1-7 ジェットコースターのように質量が 100 kg 台のシムでは、
     19600.00 J のような表示が長すぎて表からはみ出す。）
   エネルギーの数値を書くところは、必ずこの関数を通すこと。 */
function fmtE(x) { return fmt(x, Math.abs(x) >= 1000 ? 0 : 2); }
function fmtJ(x, d) { return (d === undefined ? fmtE(x) : fmt(x, d)) + EJ; }

/* いまのシムで「保存力だけが仕事をしているか」 */
function consOf(d, v) { return (typeof d.cons === 'function') ? !!d.cons(v) : (d.cons !== false); }

/* くらべる点（pts）を、いまの変数で時刻つきにして返す */
function ptsOf(d, v) {
  return (d.pts || []).map(function (p) {
    var t = (typeof p.t === 'function') ? p.t(v) : p.t;
    return { name: p.name, jp: p.jp, t: t, sym: p.sym || {}, hsym: p.hsym,
      m: d.sample(v, t) };
  });
}

/* 点の記号（K と U）。立式を作るところは、すべてこの2つを通す。 */
function symK(p) { return p.sym.K || '0'; }
function symU(p) {
  var g = p.sym.Ug || '0', s = p.sym.Us;
  return (s === undefined || s === null) ? g : (g === '0' ? s : (s === '0' ? g : g + ' + ' + s));
}
function numE(p) { return fmtE(p.m.E); }
function numKU(p) { return fmtE(p.m.K) + ' + ' + fmtE(p.m.U); }
/* 数値をたし算の中に置く（負の数はかっこでくくる） */
function numTerm(x) { var s = fmtE(x); return (x < 0) ? '(' + s + ')' : s; }

/* =========================================================
   図の下の「立式」3つ（★先生の指示・第4回★）
   ① 力学的エネルギー保存則
   ② 力学的エネルギー変化量（後－前）と非保存力の仕事の関係
   ③ 運動エネルギー変化量（後－前）と仕事の関係
   ①は保存の成否で ○ / ✕、②③は<b>いつでもなりたつ</b>ので必ず ○。
   ★式の名前は先生の指示（第6回）。「変化量（後－前）」を必ず入れること。★
   ========================================================= */
function eqSections(d, v, jj) {
  var ps = ptsOf(d, v);
  if (ps.length < 2) return [];
  var A = ps[0], B = ps[pairJ(d, v, jj)], ok = consOf(d, v);
  var wName = d.wName || '非保存力';
  var out = [];

  /* ① 力学的エネルギー保存則 */
  out.push({
    key: 'cons', title: '力学的エネルギー保存則', ok: ok,
    badge: ok ? '○ 成り立つ' : '✕ 成り立たない',
    sub: '非保存力の仕事がなければなりたつ',
    sym: ok
      ? '\\underbrace{' + symK(A) + '}_{K_{' + A.name + '}} + \\underbrace{' + symU(A) +
        '}_{U_{' + A.name + '}} \\;=\\; \\underbrace{' + symK(B) + '}_{K_{' + B.name +
        '}} + \\underbrace{' + symU(B) + '}_{U_{' + B.name + '}}'
      : 'K_{' + A.name + '} + U_{' + A.name + '} \\;=\\; K_{' + B.name + '} + U_{' + B.name +
        '} \\quad(E = \\text{一定})',
    num: ok ? numKU(A) + ' \\;=\\; ' + numKU(B) + ' \\quad(\\mathrm{J})'
      : numKU(A) + ' = ' + numE(A) + ' \\;\\ne\\; ' + numE(B) + ' = ' + numKU(B),
    note: ok ? '保存力だけが仕事をしているので、$E$ はどこでも同じ。'
      : wName + 'が仕事をしているので、<b>$E$ は保存しない</b>。下の②を使う。'
  });

  /* ② 力学的エネルギーと非保存力の仕事の関係（いつでも成り立つ） */
  out.push({
    key: 'rel', title: '力学的エネルギー変化量（後－前）と非保存力の仕事の関係',
    ok: true, badge: '○ 成り立つ',
    sub: 'いつでもなりたつ',
    sym: 'E_{' + B.name + '} - E_{' + A.name + '} = (' + symK(B) + ') + (' + symU(B) +
      ') - \\{(' + symK(A) + ') + (' + symU(A) + ')\\} = ' +
      (ok ? '0' : (d.wSym || 'W_{\\text{非保存}}')),
    num: numE(B) + ' - ' + numE(A) + ' = ' + fmtE(B.m.E - A.m.E) + '\\ \\mathrm{J}',
    note: ok ? '非保存力が仕事をしていないので $W_{\\text{非保存}}=0$。だから $E_2=E_1$（＝①の保存則）。'
      : wName + 'が <b>' + fmtJ(B.m.W - A.m.W) + '</b> の仕事をしたので、その分だけ $E$ が変わった。'
  });

  /* ③ 運動エネルギーと仕事の関係（保存力の仕事も入れて合計する） */
  var fs = forcesOf(d, v, jj), i, symR = [], numR = [], tot = 0;
  for (i = 0; i < fs.length; i++) {
    symR.push('W_{\\text{' + fs[i].name + '}}');
    numR.push(numTerm(fs[i].W));
    tot += fs[i].W;
  }
  out.push({
    key: 'wk', title: '運動エネルギー変化量（後－前）と仕事の関係', ok: true, badge: '○ 成り立つ',
    sub: 'いつでもなりたつ',
    sym: 'K_{' + B.name + '} - K_{' + A.name + '} = ' +
      (symR.length ? symR.join(' + ') : 'W_{\\text{すべての力}}'),
    num: fmtE(B.m.K) + ' - ' + fmtE(A.m.K) + ' = ' +
      (numR.length ? numR.join(' + ') + ' = ' : '') + fmtE(tot) + '\\ \\mathrm{J}',
    note: '左辺は<b>運動エネルギー変化量のみ</b>。右辺の仕事は<b>非保存力の仕事＋保存力の仕事</b>。' +
      '右上の「仕事の分析」モードにすると、それぞれの力の仕事を1つずつ確かめられる。'
  });
  return out;
}

/* =========================================================
   力ごとの仕事（「仕事を表示」と「運動エネルギーと仕事の関係」は、ここ1か所から作る）
   d.forces に、その図ではたらく力を並べる。よくある力は名前だけでよい。
     forces: ['g', 'N', 'fr']
     forces: ['g', { key: 'pull', name: '糸の力', sym: 'F', color: COL.hand,
                     w: function (v, A, B) { … }, wsym: '…', why: '…' }]
   w(v, A, B) … 点 A から点 B までにその力がした仕事 [J]（書かなければ下の既定）。
   ★合計は必ず K_B − K_A に一致する★（90_boot.js の work_sum_err で確かめている）
   ========================================================= */
var FORCE_LIB = {
  g: { name: '重力', sym: 'mg', color: COL.force,
    w: function (v, A, B) { return A.m.Ug - B.m.Ug; },
    wsym: 'W_{\\text{重力}} = U_{g1} - U_{g2} = -mg(h_2 - h_1)',
    why: '重力は<b>保存力</b>。下がれば正、上がれば負の仕事になる。' },
  N: { name: '垂直抗力', sym: 'N', color: COL.norm,
    w: function () { return 0; },
    wsym: 'W_N = N\\,L\\cos 90^\\circ = 0',
    why: '垂直抗力は<b>いつも運動の向きと垂直</b>なので、仕事は 0。' },
  T: { name: '糸の張力', sym: 'S', color: COL.hand,
    w: function () { return 0; },
    wsym: 'W_S = S\\,L\\cos 90^\\circ = 0',
    why: '糸の張力は<b>いつも運動の向きと垂直</b>（円の中心を向く）なので、仕事は 0。' },
  sp: { name: 'ばねの弾性力', sym: 'kx', color: COL.hand,
    w: function (v, A, B) { return A.m.Us - B.m.Us; },
    wsym: 'W_{\\text{弾性力}} = U_{s1} - U_{s2}',
    why: '弾性力は<b>保存力</b>。自然長にもどる向きへ動くときは正の仕事になる。' },
  fr: { name: '動摩擦力', sym: '\\mu\' N', color: COL.fric,
    w: function (v, A, B) { return B.m.W - A.m.W; },
    wsym: 'W_{\\text{摩擦}} = -\\mu\' N L',
    why: '動摩擦力は<b>非保存力</b>で、いつも運動と逆向き。だからいつも<b>負の仕事</b>。' },
  hand: { name: '手の力', sym: 'F_{\\text{手}}', color: COL.hand,
    w: function (v, A, B) { return B.m.W - A.m.W; },
    wsym: 'W_{\\text{手}} = \\sum F_{\\text{手}}\\,\\Delta x',
    why: '手の力は<b>非保存力</b>。向きと動く向きしだいで、正にも負にもなる。' }
};

/* くらべる2点の組（いつも A と、それより後ろの点）。jj は 2 つめの点の番号。 */
function pairsOf(d, v) {
  var ps = ptsOf(d, v), out = [], i;
  for (i = 1; i < ps.length; i++) {
    out.push({ j: i,
      name: ps[0].name + '点と' + ps[i].name + '点',      /* 立式の欄（左下）の書き方 */
      flow: ps[0].name + '点 → ' + ps[i].name + '点' });  /* 仕事の分析（右上）の書き方 */
  }
  return out;
}
function pairJ(d, v, jj) {
  var n = (d.pts || []).length;
  if (jj === undefined || jj === null || jj < 1 || jj > n - 1) return n - 1;
  return jj;
}

/* いまの設定で、各力がした仕事（点 A → 点 jj）を並べて返す */
function forcesOf(d, v, jj) {
  var ps = ptsOf(d, v), A = ps[0], B = ps[pairJ(d, v, jj)];
  return (d.forces || []).map(function (f) {
    var base = (typeof f === 'string') ? FORCE_LIB[f] : (FORCE_LIB[f.key] || {});
    var o = {}, k;
    for (k in base) o[k] = base[k];
    if (typeof f !== 'string') for (k in f) o[k] = f[k];
    o.key = (typeof f === 'string') ? f : f.key;
    o.W = o.w ? o.w(v, A, B) : 0;
    return o;
  });
}

/* その仕事が「正・負・0」のどれか（理由の文をそろえるため） */
function workSign(W) { return Math.abs(W) < 5e-3 ? 0 : (W > 0 ? 1 : -1); }
function workWhy(W) {
  var s = workSign(W);
  return s === 0 ? '力の向きと動く向きが<b>垂直</b>（または動いていない）なので、仕事は <b>0</b>。'
    : s > 0 ? '力の向きと動く向きが<b>同じ</b>ほうを向いているので、<b>正の仕事</b>。'
      : '力の向きと動く向きが<b>逆</b>を向いているので、<b>負の仕事</b>。';
}

/* ===== 図の中の共通部品 ===== */

/* 直方体のブロック（斜面の上など）。ang＝面の傾き(rad) */
function blockShape(ctx, cx, cy, ang, w, h, fill) {
  var rr = Math.max(w, h) / 2 * 1.05;
  noteObj(cx - rr, cy - rr, 2 * rr, 2 * rr);
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(-ang);
  ctx.fillStyle = fill || '#e8eef5';
  ctx.strokeStyle = '#2c3e50';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.rect(-w / 2, -h / 2, w, h);
  ctx.fill(); ctx.stroke();
  ctx.restore();
}

/* 地面（横一直線＋ハッチ） */
function ground(ctx, x1, x2, y) { hatchLine(ctx, x1, y, x2, y, 1); }

/* 基準面（位置エネルギーの h = 0 の線）。★どのシムでも必ず図に出す★ */
function datumLine(ctx, x1, x2, y, text, right, below) {
  ctx.save();
  ctx.strokeStyle = COL.eU; ctx.lineWidth = 1.4; ctx.setLineDash([7, 5]);
  ctx.beginPath(); ctx.moveTo(x1, y); ctx.lineTo(x2, y); ctx.stroke();
  ctx.restore();
  label(ctx, text || '基準面（h = 0）', right ? x2 - 3 : x1 + 3, y + (below ? 18 : -9),
    { size: 11, color: COL.eU, align: right ? 'right' : 'left' });
}

/* ★このページの決めごと★
   図の「ひとこと」（結論の言葉）は canvas の中に書かず、図のすぐ下の HTML の行に出す
   （d.hintFig）。canvas の中に置くと、下向きの重力の矢印のラベルと必ずぶつかるため。
   出すのはスタートを押してから（hintOn）。 */

/* 高さの寸法（基準面からの h）。破線の矢印＋数値。
   lead を渡すと、その x まで細い引き出し線を引く（寸法線を絵から離して置けるように）。
   高さがほとんど 0 のときは、文字だけ残ると意味が分からないので何も書かない。 */
function heightDim(ctx, x, yTop, yBase, text, lead, top) {
  if (Math.abs(yBase - yTop) < 7) return;
  if (lead !== undefined) {
    ctx.save();
    ctx.strokeStyle = fade(COL.dim, 0.35); ctx.lineWidth = 1; ctx.setLineDash([4, 4]);
    ctx.beginPath(); ctx.moveTo(x, yTop); ctx.lineTo(lead, yTop); ctx.stroke();
    ctx.restore();
  }
  arrow(ctx, x, yBase, x, yTop, 'dim');
  arrow(ctx, x, yTop, x, yBase, 'dim');
  if (top === true) label(ctx, text, x, yTop - 11, { size: 11.5, color: COL.dim });
  /* top に 'left' を渡すと、寸法線の「左」に数値を出す（左の列に寸法線を2本ならべるとき） */
  else if (top === 'left') label(ctx, text, x - 6, (yTop + yBase) / 2 - 10,
    { size: 11.5, align: 'right', color: COL.dim });
  /* まん中に置くと、ちょうど「つりあい」などの横線と重なることが多いので少し上にずらす */
  else label(ctx, text, x + 6, (yTop + yBase) / 2 - 10, { size: 11.5, align: 'left', color: COL.dim });
}

/* デコピン（はじく手）。1-1 と同じ出し方：はじいた直後だけ出して、すっと消す。
   ★吹きだしの しっぽは、かならず「手の真上」★（先生の指摘・第13回）
   前は呼び出しごとに好きな場所を渡していたので、1-4・1-7・1-8 では
   吹きだしが手から遠くはなれた所に浮いて、何を指しているのか分からなかった。
   いまは 手の場所 (cx, cy) から up [px] だけ上に しっぽの先を置く。
   箱が画面の外に出そうなときは bubble が箱だけ内側へ寄せる（しっぽの先は動かない）。 */
function flickStart(ctx, t, v0, cx, cy, ang, up, dx) {
  if (!(Math.abs(v0) > 0.05) || t >= 0.34) return;
  var dir = v0 > 0 ? 1 : -1;
  var k = clamp(t / 0.10, 0, 1);
  var a = (t <= 0.13) ? 1 : Math.max(0, 1 - (t - 0.13) / 0.18);
  if (a <= 0.02) return;
  flickHand(ctx, cx, cy, ang, k, dir, 0.42, a);
  ctx.save(); ctx.globalAlpha = a;
  bubble(ctx, 'デコピン！', cx, cy - (up || 48),
    { size: 12.5, dx: dx || 0, bg: '#fff5e8', border: '#e07b18', color: '#a85c0c' });
  ctx.restore();
}

/* ★「最高点（点B）」のような、点の名前の吹きだし★（先生の指示・第13回／第14回に2行へ）
   1-4・1-6・1-7・1-8・1-11・1-12・1-13・2-2 は「いちばん高い（低い）所」が見どころなので、
   運動が終わって各点のエネルギーを出すときに、その点のそばに小さく出す。
   ★2行で書く★ 1行目＝「最高点」「最下点」、2行目＝「（点B）」
   （どの点の話かを、式や表の記号とすぐ結びつけられるように。先生の指示・第14回）
   (x, y) は しっぽの先＝さす場所。
     up を渡さない … しっぽは下向き（▼）。箱はその上（＝最高点で使う）
     up = true     … しっぽは上向き（▲）。箱はその下（＝最下点で使う） */
function ptNote(ctx, px, py, title, sub, opt) {
  opt = opt || {};
  var s1 = 12, s2 = 11, padx = 11, pady = 7, gap = 2;
  ctx.save();
  ctx.font = 'bold ' + s1 + 'px ' + FONT;
  var w1 = ctx.measureText(title).width;
  ctx.font = s2 + 'px ' + FONT;
  var w2 = sub ? ctx.measureText(sub).width : 0;
  ctx.restore();
  var w = Math.max(w1, w2) + padx * 2;
  var h = pady * 2 + s1 + (sub ? gap + s2 : 0);
  var off = (opt.gap === undefined) ? 46 : opt.gap;
  /* ★上に入らなければ、下がわに出す★（第14回）
     入らないまま描くと、箱が画面の外へ出て、2行が同じ高さにつぶれてしまう
     （label が y < 9 でクランプするため。1-7 の v0 = 16 で実際に起きた）。 */
  var up = !!opt.below || (py - off - h < 4);
  var y = up ? py + off : py - off;
  var bx = px - w / 2 + (opt.dx || 0);      /* dx＝しっぽはそのまま、箱だけ横へ */
  var by = up ? y + 8 : y - h;
  if (CVW > 0) bx = clamp(bx, 3, Math.max(3, CVW - w - 3));
  if (CVH > 0) by = clamp(by, 3, Math.max(3, CVH - h - 3));
  var tipX = clamp(px, bx + 10, bx + w - 10);
  var edge = up ? by : by + h;
  var tipY = up ? by - 8 : by + h + 8;
  ctx.save();
  ctx.fillStyle = '#eef2f7';
  ctx.strokeStyle = COL.eE;
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(bx, by, w, h, 7); else ctx.rect(bx, by, w, h);
  ctx.fill(); ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(tipX - 6, edge); ctx.lineTo(tipX, tipY); ctx.lineTo(tipX + 6, edge);
  ctx.closePath(); ctx.fillStyle = '#eef2f7'; ctx.fill();
  ctx.strokeStyle = COL.eE;
  ctx.beginPath();
  ctx.moveTo(tipX - 6, edge); ctx.lineTo(tipX, tipY); ctx.lineTo(tipX + 6, edge); ctx.stroke();
  ctx.restore();
  label(ctx, title, bx + w / 2, by + pady + s1 / 2,
    { size: s1, bold: true, color: '#28323d', halo: false });
  if (sub) {
    label(ctx, sub, bx + w / 2, by + pady + s1 + gap + s2 / 2,
      { size: s2, color: '#5b6672', halo: false });
  }
  noteBox(_txtBox, bx, by, w, h);
  noteObj(bx, by, w, h);
}

/* ★図の上に出す「このシムで何をくらべるか」の帯★（先生の指示・第14回）
   2-4 は「止まるまで動かす → もう一度はじめから → 点 B で止まる」という
   ふつうと違う再生をするので、何と何をくらべているのかを図の中にことばで出す。
   横は「エネルギーの棒をのぞいた絵の幅」のまん中にそろえる。 */
function bannerNote(ctx, lines, y, opt) {
  opt = opt || {};
  /* ★第15回：小さくて読めないと言われたので、字を大きく（12 → 14 px）した。
     そのぶん1行に入らないので、行を配列で渡せるようにした。 */
  var sz = opt.size || 14, padx = 14, pady = 9, lead = 5;
  if (typeof lines === 'string') lines = [lines];
  ctx.save();
  ctx.font = sz + 'px ' + FONT;
  var wmax = 0, i;
  for (i = 0; i < lines.length; i++) wmax = Math.max(wmax, ctx.measureText(lines[i]).width);
  ctx.restore();
  var w = wmax + padx * 2;
  var h = pady * 2 + lines.length * sz + (lines.length - 1) * lead;
  var cxm = ((CVW > 0 ? CVW : 640) - 72) / 2;
  var x = clamp(cxm - w / 2, 3, Math.max(3, (CVW > 0 ? CVW : 640) - w - 3));
  ctx.save();
  ctx.fillStyle = opt.bg || '#eaf1f8';
  ctx.strokeStyle = opt.border || '#7f9fbb';
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(x, y, w, h, 9); else ctx.rect(x, y, w, h);
  ctx.fill(); ctx.stroke();
  ctx.restore();
  for (i = 0; i < lines.length; i++) {
    label(ctx, lines[i], x + w / 2, y + pady + sz / 2 + i * (sz + lead),
      { size: sz, color: opt.color || '#1f4a70', halo: false });
  }
  noteBox(_txtBox, x, y, w, h);
  noteObj(x, y, w, h);
}

/* ===== 図の中の「エネルギーの棒」 =====
   K を下、U を上に積む。てっぺんが E。非保存力があるときは、
   はじめの E までの残り（＝失われた分）をうすいグレーで塗る。
   色はグラフ・表・式とぴったり同じ（COL.eK / COL.eU / COL.eE）。 */
function energyBar(ctx, x, yTop, yBot, w, m, lo, hi, opt) {
  opt = opt || {};
  noteObj(x - 6, yTop - 10, w + 34, (yBot - yTop) + 32);
  if (!(hi - lo > 1e-9)) { hi = lo + 1; }
  function Yv(e) { return yBot - (e - lo) / (hi - lo) * (yBot - yTop); }
  var y0 = Yv(0);
  var yE = Yv(m.E);
  ctx.save();
  /* 枠 */
  ctx.strokeStyle = '#c9d2da'; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.rect(x, yTop, w, yBot - yTop); ctx.stroke();
  /* 0 の線（負の位置エネルギーが出るシムのため） */
  if (lo < -1e-9) {
    ctx.strokeStyle = '#aeb8c2'; ctx.setLineDash([4, 3]); ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(x - 3, y0); ctx.lineTo(x + w + 3, y0); ctx.stroke();
    ctx.setLineDash([]);
  }
  /* 失われた分（はじめの E まで） */
  if (opt.E0 !== undefined && opt.E0 - m.E > 1e-9) {
    var yE0 = Yv(opt.E0);
    ctx.fillStyle = fade(COL.areaNeg, 0.30);
    ctx.fillRect(x, yE0, w, yE - yE0);
    ctx.strokeStyle = fade(COL.areaNeg, 0.8); ctx.setLineDash([3, 3]); ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(x, yE0); ctx.lineTo(x + w, yE0); ctx.stroke();
    ctx.setLineDash([]);
  }
  function band(yA, yB, col, fillA, dash) {
    if (Math.abs(yA - yB) < 0.6) return;
    ctx.fillStyle = fade(col, fillA);
    ctx.fillRect(x, Math.min(yA, yB), w, Math.abs(yA - yB));
    ctx.strokeStyle = col; ctx.lineWidth = 1.3;
    if (dash) ctx.setLineDash([3, 2]);
    ctx.strokeRect(x, Math.min(yA, yB), w, Math.abs(yA - yB));
    ctx.setLineDash([]);
  }
  /* ★正のものは 0 から上へ、負のものは 0 から下へ積む★（先生の指摘・第6回）
     「K の上に U_g を積む」やり方だと、U_g が負のシム（1-12・2-3）で帯が上下に
     行ったり来たりして、合計が一定に見えなかった。
     こうすると「上にのびた分」と「下にのびた分」の差が E になり、
     E の線が動かないことが目で分かる。 */
  var up = y0, dn = y0, segs = [
    { e: m.K, col: COL.eK, a: 0.60, dash: false, nm: 'K', kc: '#14663d', sz: 12 },
    { e: m.Ug, col: COL.eU, a: 0.45, dash: false, nm: 'U_g', kc: COL.eU, sz: 11.5 },
    { e: m.Us, col: COL.eU, a: 0.22, dash: true, nm: 'U_k', kc: COL.eU, sz: 11 }
  ], si, sg, ya, yb, ph, mids = [];
  for (si = 0; si < segs.length; si++) {
    sg = segs[si];
    if (!(Math.abs(sg.e) > 1e-9)) continue;
    ph = Math.abs(Yv(0) - Yv(sg.e));         /* その量の長さ [px] */
    if (sg.e > 0) { ya = up; yb = up - ph; up = yb; }     /* 正のものは 0 から上へ */
    else { ya = dn; yb = dn + ph; dn = yb; }              /* 負のものは 0 から下へ */
    band(ya, yb, sg.col, sg.a, sg.dash);
    if (Math.abs(yb - ya) > 15) mids.push({ y: (ya + yb) / 2, nm: sg.nm, kc: sg.kc, sz: sg.sz });
  }
  /* E の高さに太い線 */
  ctx.strokeStyle = COL.eE; ctx.lineWidth = 3;
  ctx.beginPath(); ctx.moveTo(x - 4, yE); ctx.lineTo(x + w + 4, yE); ctx.stroke();
  ctx.restore();
  /* 文字（せまいところには書かない） */
  for (si = 0; si < mids.length; si++) {
    label(ctx, mids[si].nm, x + w / 2, mids[si].y,
      { size: mids[si].sz, bold: true, color: mids[si].kc, halo: false });
  }
  label(ctx, 'E', x + w + 7, yE, { size: 12, bold: true, color: COL.eE, align: 'left' });
  label(ctx, opt.title || 'エネルギー', x + w / 2, yBot + 13, { size: 10.5, color: COL.sub });
}

/* 2点をくらべるシムで、印を「相手の点から遠いほう」へずらした場所を返す。
   ★印は物体・力の矢印と重ねない★（先生の指示・第6回）
   nx, ny＝面から外向き、off＝面からの高さ、along＝坂にそってずらす長さ。 */
function markAway(p, other, nx, ny, off, along) {
  var dx = p.x - other.x, dy = p.y - other.y, L = Math.hypot(dx, dy) || 1;
  return { x: p.x + nx * off + dx / L * along, y: p.y + ny * off + dy / L * along };
}

/* 点（A・B…）の印。「どこをくらべているか」は答えではないので、いつも出してよい。
   ★どこに印を出したかを覚えておく★（吹きだしの引き出し線の「黒丸」を、
   　この印の上に重ねて描くと、文字がつぶれて読めなくなるため） */
var _ptMarkAt = [];
function ptMarkNear(x, y) {
  var i;
  for (i = 0; i < _ptMarkAt.length; i++) {
    if (Math.abs(_ptMarkAt[i].x - x) < 11 && Math.abs(_ptMarkAt[i].y - y) < 11) return true;
  }
  return false;
}
function ptMark(ctx, name, x, y) {
  _ptMarkAt.push({ x: x, y: y });
  noteObj(x - 11, y - 11, 22, 22);
  /* ★ゴーストの物体より前面に出す★（第6回）ためておいて flushVec でまとめて描く */
  if (_defMark) {
    _defMark.push(function () { ptMarkNow(ctx, name, x, y); });
    return;
  }
  ptMarkNow(ctx, name, x, y);
}
function ptMarkNow(ctx, name, x, y) {
  ctx.save();
  ctx.fillStyle = '#fff'; ctx.strokeStyle = COL.eE; ctx.lineWidth = 1.8;
  ctx.beginPath(); ctx.arc(x, y, 9, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.restore();
  label(ctx, name, x, y + 0.5, { size: 12, bold: true, color: COL.eE, halo: false });
}

/* ===== くらべる点のエネルギーの吹きだし（★このページの決めごと★） =====
   ★点のすぐ近くに、その点のエネルギーを置く。物体・ほかの文字・ほかの吹きだしとは重ねない。★
   　吹きだしの中身は HTML（KaTeX）で組み、canvas の上に重ねて出す
   　（canvas では ½mv² のような式をきれいに組めないため）。
   　canvas 側は「置き場所を決めて、点まで引き出し線を引く」ところだけを受け持つ。 */

/* 置き場所を決める。点のまわりの候補から、重なりがいちばん少なくて点に近いものを選ぶ。 */
/* ★吹きだしは「A・B・C… の順」にならべる★（先生の指示・第6回）
   ばらばらの位置に置くと、どれがどの点か読み取れない。
   ・ふつう … 左から右へ A → B → C（前の吹きだしより左に来たら大きな罰）
   ・stack  … 上から下へ A → B → C（前の吹きだしより上に来たら大きな罰）
   prev＝1つ前に置いた吹きだしの箱（null なら制限なし）。 */
function placePtBox(px, py, w, h, taken, side, prev) {
  /* 16 方向 × 4 とおりのへだたりを試す */
  var dirs = [], a, i, j, k;
  for (a = 0; a < 16; a++) dirs.push([Math.cos(a * Math.PI / 8), Math.sin(a * Math.PI / 8)]);
  var rings = [14, 34, 62, 96, 140];
  /* 点数：文字・ほかの吹きだしに1つでも重なったら大きな罰。物体は軽い罰。
     そのうえで「点に近いほど良い」。重なり 0 を最優先し、そのうえで点のそば。 */
  function ptScore(b, taken2, pad) {
    var sc = 0, k, ov, m2 = pad || 0;
    for (k = 0; k < _txtBox.length; k++) {
      ov = boxOverlap(b, m2 ? infl(_txtBox[k], m2) : _txtBox[k]);
      if (ov > 0) sc += 1400 + ov * 10;                 /* 文字は隠さない */
    }
    for (k = 0; k < _objBox.length; k++) sc += boxOverlap(b, _objBox[k]) * 3.0;  /* 物体も避ける */
    for (k = 0; k < taken2.length; k++) {
      ov = boxOverlap(b, m2 ? infl(taken2[k], m2) : taken2[k]);
      if (ov > 0) sc += 4000 + ov * 10;                 /* 吹きだしどうしは絶対に重ねない */
    }
    /* ★点にどれだけ近いか★ 箱のいちばん近いふちから点までの長さで測る */
    var ax = Math.max(b.x - px, 0, px - (b.x + b.w));
    var ay = Math.max(b.y - py, 0, py - (b.y + b.h));
    /* 'row' は「地面の下に1列」がねらいなので、点への近さは軽くみる。
       重くすると、点のそばに残ってしまって列にならばない（第6回の直し） */
    sc += Math.hypot(ax, ay) * (side === 'row' ? 4 : 20);
    /* 点が3つ以上あるシムは、吹きだしを1つの列にそろえて「縦に並べる」と見やすい。
       d.ptSide に 'stack'（右の列）／'stackL'（左の列）を書くと、その列へ引きよせる。 */
    if (side === 'stack') sc += Math.abs(b.x - (CVW - w - 96)) * 26;
    else if (side === 'stackL') sc += Math.abs(b.x - 6) * 6;
    /* ★'row'★ 地面の下の「吹きだしの帯」に、左から順に1列にならべる（先生の指示・第6回）。
       シムの draw が ptRow(gy + 14) で帯の高さを教える。 */
    else if (side === 'row' && _ptRowY !== null) {
      sc += Math.abs(b.y - _ptRowY) * 30;
      sc += Math.abs((b.x + b.w / 2) - px) * 3;
    }
    /* ★順番★ 前の吹きだしより「あと」に来るようにする */
    if (prev) {
      if (side === 'stack' || side === 'stackL') {
        if (b.y < prev.y + prev.h * 0.5) sc += 2600 + (prev.y + prev.h * 0.5 - b.y) * 24;
      } else if (b.x < prev.x + prev.w * 0.34) {
        sc += 2600 + (prev.x + prev.w * 0.34 - b.x) * 24;
      }
    }
    return sc;
  }
  function infl(b, m2) { return { x: b.x - m2, y: b.y - m2, w: b.w + 2 * m2, h: b.h + 2 * m2 }; }
  var best = null, bestScore = Infinity, cand = [];
  for (j = 0; j < rings.length; j++) {
    for (i = 0; i < dirs.length; i++) {
      var L = rings[j];
      cand.push([px + dirs[i][0] * (w / 2 + L) - w / 2, py + dirs[i][1] * (h / 2 + L) - h / 2]);
    }
  }
  /* ★'row' は「帯のどこか」も必ず候補に入れる★
     山登りだけだと、図の文字が壁になって帯までたどりつけないことがある。 */
  if (side === 'row' && _ptRowY !== null) {
    for (i = -3; i <= 3; i++) cand.push([px - w / 2 + i * (w * 0.55), _ptRowY]);
  }
  /* ★'stack'／'stackL' も「列のあちこち」を必ず候補に入れる★（先生の指示・第6回）
     山登りだけだと、いちばん近い所しか見つからず、A→B→C の順にならばないことがあった。 */
  if (side === 'stack' || side === 'stackL') {
    var sx = (side === 'stack') ? (CVW - w - 96) : 6;
    for (i = -3; i <= 3; i++) cand.push([sx, py - h / 2 + i * (h * 0.85)]);
    if (prev) cand.push([sx, prev.y + prev.h + 8]);
  }
  for (i = 0; i < cand.length; i++) {
    var b = { w: w, h: h };
    b.x = clamp(cand[i][0], 3, Math.max(3, CVW - w - 3));
    b.y = clamp(cand[i][1], 3, Math.max(3, CVH - h - 3));
    var sc = ptScore(b, taken);
    if (sc < bestScore) { bestScore = sc; best = b; }
  }
  /* さらに、いちばん良かった場所のまわりを少しずつずらして、重なりを 0 に追いこむ */
  function score(b) { return ptScore(b, taken, 3); }
  var steps = [14, 7, 3], si, dd, cur = { x: best.x, y: best.y, w: w, h: h }, curSc = score(cur);
  var d8 = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
  for (si = 0; si < steps.length; si++) {
    for (var it = 0; it < 12; it++) {
      var moved = false;
      for (dd = 0; dd < d8.length; dd++) {
        var nb = { w: w, h: h,
          x: clamp(cur.x + d8[dd][0] * steps[si], 3, Math.max(3, CVW - w - 3)),
          y: clamp(cur.y + d8[dd][1] * steps[si], 3, Math.max(3, CVH - h - 3)) };
        var ns = score(nb);
        if (ns < curSc - 0.01) { cur = nb; curSc = ns; moved = true; }
      }
      if (!moved) break;
    }
  }
  return cur;
}

/* 箱の中心から点へ向かう線が、箱のふちを出るところ */
function boxEdge(b, px, py) {
  var cx = b.x + b.w / 2, cy = b.y + b.h / 2;
  var dx = px - cx, dy = py - cy;
  if (Math.abs(dx) < 1e-6 && Math.abs(dy) < 1e-6) return { x: cx, y: cy };
  var tx = dx === 0 ? Infinity : (b.w / 2 + 2) / Math.abs(dx);
  var ty = dy === 0 ? Infinity : (b.h / 2 + 2) / Math.abs(dy);
  var tt = Math.min(tx, ty);
  return { x: cx + dx * tt, y: cy + dy * tt };
}

/* map(p, m) → {x, y}（その点の画面での位置）。運動が終わってから出す。
   決めた置き場所は st._ptPos に入れて、HTML の吹きだし（80_ui.js）がそこへ移動する。 */
/* map(p, m) が返せるもの
     x, y      … 吹きだしの引き出し線がさす点（必須）
     ox, oy    … 物体をもう一度描く場所（省略すると x, y）
     r         … 物体の半径 px（省略すると描かない）
     bw, bh    … 物体が四角のときの大きさ（r のかわり）
     ang       … 四角の傾き（rad）
     vx, vy    … 速度の向き（画面の単位ベクトル。省略すると描かない）
     vlen      … 速度の矢印の長さ px（省略すると 30）
     base      … 高さの両矢印をひく基準面の y（省略すると描かない）
     hx        … 高さの両矢印の x（省略すると ox）
   ★運動が終わったら、くらべる点それぞれに「物体・速度・高さ」をもう一度描く★
   　どの点の話なのかを目で追えるようにするため。 */
/* ★'row'（地面の下の1列）は、さがすのをやめて「左から順にきちんとならべる」★
   （先生の指示・第6回：吹きだしは左から A・B・C の順）
   さがし方（placePtBox）だと、図の中の文字をよけて1つだけ列から外れることがあった。
   ここで幅を足し算して、入るなら等間隔でならべる。入らないときだけ、さがし方にもどす。 */
function rowPlace(qs, sizes) {
  var n = sizes.length, i, tot = 0, gap = 8, L = 4, R = CVW - 72;  /* 右はエネルギーの棒のぶん */
  for (i = 0; i < n; i++) tot += sizes[i].w;
  if (tot + gap * (n - 1) > R - L) gap = 4;
  if (tot + gap * (n - 1) > R - L) return null;
  var span = tot + gap * (n - 1), cxs = 0;
  for (i = 0; i < n; i++) cxs += qs[i].x;
  var x0r = clamp(cxs / n - span / 2, L, R - span);
  /* ★帯に文字がかかっていたら、帯ごと下へずらす★（第8回）
     各点に力の矢印も描くようになって、mg の字が帯まで下りてくるようになったため。 */
  var yr = _ptRowY, k, j, hit;
  for (k = 0; k < 8; k++) {
    hit = 0;
    for (i = 0; i < n && !hit; i++) {
      var b0 = { x: x0r, y: yr, w: sizes[i].w, h: sizes[i].h };
      b0.x = x0r; 
      for (j = 0; j < i; j++) b0.x += sizes[j].w + gap;
      for (var t2 = 0; t2 < _txtBox.length; t2++) {
        if (boxOverlap(b0, _txtBox[t2]) > 0) { hit = 1; break; }
      }
    }
    if (!hit) break;
    if (yr + sizes[0].h + 8 > CVH - 3) break;
    yr += 8;
  }
  var x = x0r, out = [];
  for (i = 0; i < n; i++) {
    out.push({ x: x, y: yr, w: sizes[i].w, h: sizes[i].h });
    x += sizes[i].w + gap;
  }
  return out;
}

function drawPts(ctx, d, s, t, map) {
  st._ptPos = null;
  st._vGhost = [];        /* 検算用：ゴーストの速度ベクトルの「速さ」と「長さ」 */
  if (!endOn(d, s, t)) return;
  var ps = ptsOf(d, V(s)), i, taken = [], out = [], qs = [];
  var live = d.sample(V(s), t);          /* いまの物体の場所（二重に描かないための照合用） */
  for (i = 0; i < ps.length; i++) qs.push(map(ps[i], ps[i].m, i));
  /* ★★ 速度ベクトルの長さは「その点の速さ」に比例させる ★★（先生の指摘・第7回）
     いままでは map が返す vlen（決め打ちの px）でどの点も同じ長さに描いていたので、
     1-7 のように v_A = 14 m/s・v_B = 7 m/s とちがう点が、同じ速さに見えてしまった。
     ここで「その図の中でいちばん速い点」を出しておき、ptGhost が比で縮める。 */
  var vmax = 0;
  for (i = 0; i < ps.length; i++) if (ps[i].m.v > vmax) vmax = ps[i].m.v;
  for (i = 0; i < qs.length; i++) if (qs[i]) qs[i].vmax = vmax;
  /* ① 各点に物体・速度・高さを描き直す（吹きだしより先に。吹きだしがこれを避けるため） */
  for (i = 0; i < qs.length; i++) {
    /* いま物体がその点にいるときは、物体と速度は本物がもう描かれているので描き直さない
       （二重に見えるため）。★高さの寸法線だけは、どの点にも必ず出す★
       時刻はちがっても「場所が同じ」ことがある（ばねが自然長にもどってきたときなど）。
       そのときは map が q.here = true を返す。 */
    if (qs[i]) {
      /* ★「本物がいまその点にいる」かどうかは、時刻ではなく「場所」で見る★（第8回）
         止まったあともアニメが続くシム（2-1・2-2・2-5）や、1周期でもどるシム（1-6）では
         時刻がちがうのに場所は同じ。時刻だけで見ると、物体も力も二重に描かれてしまう。 */
      var same = (Math.abs((ps[i].m.x || 0) - (live.x || 0)) < 1e-3 &&
        Math.abs((ps[i].m.y || 0) - (live.y || 0)) < 1e-3);
      ptGhost(ctx, d, s, ps[i], qs[i], !!qs[i].here || Math.abs(ps[i].t - t) <= 1e-6 || same);
    }
  }
  /* ①' モード2は「途中の状態」も描く（力の向きが運動と逆＝負の仕事、が大事なので） */
  if (d.midGhost) d.midGhost(ctx, s);
  /* ★ここでベクトル（力・速度・加速度）をまとめて描く★
     ゴーストのあとに描くので、矢印が物体やゴーストに隠れない。
     吹きだしを置く前に描くので、吹きだしは矢印の文字をちゃんとよけてくれる。 */
  flushVec(ctx);
  /* ② そのうえで吹きだしを置く */
  var sizes = [];
  for (i = 0; i < ps.length; i++) {
    sizes.push((st._ptSz && st._ptSz[ps[i].name]) || { w: 132, h: 40 });
  }
  var rows = (d.ptSide === 'row' && _ptRowY !== null) ? rowPlace(qs, sizes) : null;
  for (i = 0; i < ps.length; i++) {
    var p = ps[i], q = qs[i];
    if (!q) continue;
    var sz = sizes[i];
    var b = rows ? rows[i]
      : placePtBox(q.x, q.y, sz.w, sz.h, taken, d.ptSide, taken[taken.length - 1] || null);
    taken.push(b);
    var e = boxEdge(b, q.x, q.y);
    ctx.save();
    ctx.strokeStyle = fade(COL.eE, 0.6); ctx.lineWidth = 1.3; ctx.setLineDash([4, 3]);
    ctx.beginPath(); ctx.moveTo(e.x, e.y); ctx.lineTo(q.x, q.y); ctx.stroke();
    ctx.restore();
    if (!ptMarkNear(q.x, q.y)) {
      ctx.save();
      ctx.fillStyle = COL.eE;
      ctx.beginPath(); ctx.arc(q.x, q.y, 3.2, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
    }
    out.push({ name: p.name, x: b.x + b.w / 2, y: b.y + b.h / 2 });
    /* 重なりの自動検査に、吹きだしの場所も記録する */
    if (typeof window !== 'undefined' && window.__labelLog) {
      window.__labelLog.push({ cv: CVID, text: '吹:' + p.name, x: b.x, y: b.y + b.h / 2, w: b.w, h: b.h });
    }
  }
  st._ptPos = out;
}

/* くらべる点の「物体・速度ベクトル・高さ」をうすく描き直す */
function ptGhost(ctx, d, s, p, q, here) {
  var ox = (q.ox === undefined) ? q.x : q.ox;
  var oy = (q.oy === undefined) ? q.y : q.oy;
  ctx.save();
  noteObj(ox - 26, oy - 26, 52, 52);
  if (!here) {
    ctx.save(); ctx.globalAlpha = 0.9;
    if (q.bw) blockShape(ctx, ox, oy, q.ang || 0, q.bw, q.bh || q.bw, '#f2f4f7');
    else if (q.r) ball(ctx, ox, oy, q.r, 'faint');
    ctx.restore();
  }
  /* 高さ（両矢印）。0 に近いときは heightDim が自分で何も描かない。
     ★記号は「その点の式で使っている名前」にする★（先生の指示・第12回）
     どの点も 'h = …' だと、式の $mgh_B$ が図のどの寸法なのか分からない。
     pts に hsym（例 'h_B'・'D'・'L sinθ'）を書いておくと、それを使う。 */
  if (q.base !== undefined && Math.abs(p.m.h) > 0.005) {
    /* 高さは「面に接している点」ではかりたいので、map が hy を返せばそれを使う */
    heightDim(ctx, (q.hx === undefined) ? ox : q.hx, (q.hy === undefined) ? oy : q.hy, q.base,
      (p.hsym || 'h') + ' = ' + fmt(p.m.h, 2) + ' m', undefined, q.hside);
  }
  /* ★「力を表示」が ON なら、その点ではたらく力も描く★（先生の指示・第8回）
     どの点でどの力がはたらいているかを、吹きだしの式と見くらべられるようにするため。
     描き方はシムごとにちがうので、map が返す fdraw() にまかせる。
     本物の物体がそこにいるときは、本物の矢印がもう出ているので描かない。 */
  if (!here && q.fdraw && s.o.showF) q.fdraw();
  /* 速度ベクトル（物体から少し離して出す）。本物がそこにいるときは本物にまかせる。
     ★中点を物体の中点の真上（横に出すときはすぐ横）にそろえる★ */
  if (!here && q.vx !== undefined && p.m.v > 0.02) {
    /* ★長さは速さに比例★（第7回）本物の矢印とまったく同じ式（vArrowLen）を使う。
       map が vref（目安の速さ）と vk（そのときの長さ）を返す。 */
    var L, off = q.voff || 20;
    if (q.vref) L = vArrowLen(p.m.v, q.vref, q.vk);
    else if (q.vmax > 0.02) L = (q.vlen || 30) * (p.m.v / q.vmax);
    else L = q.vlen || 30;
    var gnx = q.vy, gny = -q.vx;             /* 速度と垂直 */
    if (gny > 0) { gnx = -gnx; gny = -gny; } /* 画面の上向き（横向きの速度なら真上）にそろえる */
    var va = velArrow(ctx, ox, oy, gnx, gny, off, q.vx, q.vy, L);
    if (st._vGhost) st._vGhost.push({ n: p.name, v: p.m.v, L: L });
    label(ctx, 'v', va.tx + q.vx * 10, va.ty + q.vy * 10, { size: 11, color: COL.vel });
  }
  ctx.restore();
}

/* 吹きだしに書く式（KaTeX）。K と U の記号を「+」でつないだもの。 */
function ptTex(d, p) {
  var parts = [p.sym.K || '0', p.sym.Ug || '0'];
  if (d.hasUs) parts.push(p.sym.Us || '0');
  return 'E_' + p.name + ' = ' + parts.join(' + ');
}

/* ★速度ベクトルは「物体の中点をはさんで、前後に半分ずつ」描く★（先生の指示・第6回）
   こうすると矢印の<b>まん中</b>が、物体の中点の真上（横に出すときはすぐ横）に来る。
   (ox,oy)＝物体の中心／(nx,ny)＝物体からずらす向き（ふつうは面の外向き＝画面の上）／
   off＝ずらす距離［px］／(ux,uy)＝速度の向き（単位ベクトル）／len＝矢印の長さ［px］。
   返り値の tx,ty＝矢印の先。文字「v」はそこから少し先に置く。 */
/* ★速度ベクトルの長さは「速さ」にきっちり比例させる★（先生の指示・第7回）
   前は 14 + k*v/vref と下駄をはかせていたので、たとえば 1-7 の
   v_A = 14 m/s と v_B = 7 m/s（ちょうど2倍）が 44 px と 29 px になり、
   ゴーストの決め打ち（24 px）ではまったく同じ長さに見えていた。
   比例にすれば「矢印の長さの比＝速さの比」になり、図から速さを読み取れる。
   v … その瞬間の速さ／vref … そのシムの目安の速さ／k … vref のときの長さ[px] */
function vArrowLen(v, vref, k) {
  return (k || 46) * Math.abs(v) / Math.max(1e-6, vref);
}

function velArrow(ctx, ox, oy, nx, ny, off, ux, uy, len) {
  var cx = ox + nx * off, cy = oy + ny * off;
  var hx = ux * len / 2, hy = uy * len / 2;
  arrow(ctx, cx - hx, cy - hy, cx + hx, cy + hy, 'vel');
  return { x: cx, y: cy, tx: cx + hx, ty: cy + hy };
}

/* ===== 加速度ベクトル（表示チェック「加速度ベクトルを表示」で出す） =====
   (ax, ay) は画面の向きの加速度［m/s²］（y は下向きが正）。
   長さは「g のとき 34 px」にそろえてあるので、どのシムでも大きさを見くらべられる。 */
function drawAcc(ctx, x, y, ax, ay, opt) {
  opt = opt || {};
  var mag = Math.hypot(ax, ay);
  if (!(mag > 0.05)) return;
  var k = 34 / G, L = Math.min(mag * k, opt.max || 76);
  var ux = ax / mag, uy = ay / mag;
  /* ★加速度の矢印は「速度の矢印よりさらに外がわ」に、まん中をそろえて描く★
     （先生の指示・第17回）前は物体のすぐ近くから描き出していたので、
     物体や斜面に重なって読めなかった。
     (x,y)＝物体の中心／(nx,ny)＝ずらす向き（ふつうは面の外向き＝画面の上）／
     off＝ずらす距離［px］。矢印はその点を「まん中」にして描くので、
     a がどちらを向いても帯の中におさまり、物体に重ならない。 */
  var nx = (opt.nx === undefined) ? 0 : opt.nx;
  var ny = (opt.ny === undefined) ? -1 : opt.ny;
  var nl = Math.hypot(nx, ny) || 1;
  var off = (opt.off === undefined) ? 44 : opt.off;
  /* ★a が「ずらした向き」と逆を向くときは、矢じりが物体まで戻ってきてしまう★
     （1-8 の最高点など）。そのぶん余分に離しておく。 */
  if (ux * (nx / nl) + uy * (ny / nl) < -0.05) off = Math.max(off, L / 2 + 38);
  var cx = x + (nx / nl) * off + (opt.dx || 0), cy = y + (ny / nl) * off + (opt.dy || 0);
  /* 図の外へはみ出さないように、矢印ぜんたいを枠の中へおさめる */
  if (CVW > 0) {
    var mx = Math.abs(ux) * L / 2 + 15, my = Math.abs(uy) * L / 2 + 15;
    cx = clamp(cx, mx, Math.max(mx, CVW - mx));
    cy = clamp(cy, my, Math.max(my, CVH - my));
  }
  var hx = ux * L / 2, hy = uy * L / 2;
  arrow(ctx, cx - hx, cy - hy, cx + hx, cy + hy, 'acc');
  label(ctx, 'a', cx + hx + ux * 11, cy + hy + uy * 11, { size: 11.5, color: COL.acc });
}

/* 図の右はしに「エネルギーの棒」を出す（全シム共通の置き場所） */
var _ebRange = { key: null, lo: 0, hi: 1 };
/* エネルギーの棒の目盛りは、運動の間ずっと同じにする（棒が伸び縮みして見えないように）。
   位置エネルギーが負になるシム（1-10・2-3）があるので、下の端も見る。 */
function energyRange(d, s) {
  var v = V(s), key = st.cur + '|' + JSON.stringify(v);
  if (_ebRange.key === key) return _ebRange;
  /* ★目もりは「棒がのびる長さ」に合わせる★（第10回に直したバグ）
     energyBar は【正のものを 0 から上へ、負のものを 0 から下へ】積む（第6回）。
     だから棒が上へのびる長さは「正のものの合計」、下へのびる長さは
     「負のものの合計」であって、K + U_g + U_k のような“途中までの和”ではない。
     前は途中までの和で目もりを決めていたので、U_g が負になるシム
     （1-12 鉛直ばね・2-3 手でゆっくり下ろす）で U_k の帯が枠の上にはみ出し、
     「K は変わっていないのに棒が伸びていく」ように見えていた（先生の指摘）。 */
  var T = d.tEnd(v), lo = 0, hi = 1e-6, i, j, e3;
  for (i = 0; i <= 40; i++) {
    var q = d.sample(v, T * i / 40), pos = 0, neg = 0;
    e3 = [q.K, q.Ug, q.Us];
    for (j = 0; j < 3; j++) {
      if (e3[j] > 0) pos += e3[j];
      else if (e3[j] < 0) neg += e3[j];
    }
    lo = Math.min(lo, q.E, neg);
    hi = Math.max(hi, q.E, pos);
  }
  var E0 = d.sample(v, 0).E;
  lo = Math.min(lo, E0); hi = Math.max(hi, E0);
  var pad = Math.max(1e-6, (hi - lo)) * 0.08;
  _ebRange = { key: key, lo: lo - (lo < -1e-9 ? pad : 0), hi: hi + pad };
  return _ebRange;
}

function drawEnergyBar(ctx, d, s, t, W, H, m) {
  var v = V(s), E0 = d.sample(v, 0).E, r = energyRange(d, s);
  var yBot = H - 32, yTop = Math.max(20, yBot - Math.max(60, H - 92));
  energyBar(ctx, W - 62, yTop, yBot, 28, m, r.lo, r.hi,
    { E0: consOf(d, v) ? undefined : E0, title: 'エネルギー' });
}

/* 図の右上の時刻 */
function drawClock(ctx, W, t) {
  label(ctx, 't = ' + fmt(t, 2) + ' s', W - 78, 18, { align: 'right', size: 13.5, bold: true });
}
