/* ページのいちばん上の「立式のステップ図」。
   Step1 保存力だけが仕事をしているか？ → Step2 2つの位置でエネルギーを書き出す
   → Step3 式を立てる
   ★いま見ているシミュレーションの状態を反映させる★
   　Step1 に ○/× を出し、× のときは Step3 の式が
   　「力学的エネルギー保存則」から「E₂ − E₁ = W非保存」に切りかわる。 */
'use strict';

var STEP = {
  W: 980, H: 150,          /* 広い画面（横に3つ並べる） */
  NW: 380, NH: 330         /* せまい画面（たてに3つ積む） */
};

/* 角丸の箱 */
function stepBox(ctx, x, y, w, h, tone) {
  ctx.save();
  ctx.fillStyle = tone === 'ok' ? '#eef8f1' : (tone === 'ng' ? '#fdf0ee' : '#f2f6fa');
  ctx.strokeStyle = tone === 'ok' ? '#a7d9bb' : (tone === 'ng' ? '#efbdb5' : '#cfdce8');
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(x, y, w, h, 10); else ctx.rect(x, y, w, h);
  ctx.fill(); ctx.stroke();
  ctx.restore();
}

/* 「Step 1」の小さなふだ */
function stepTag(ctx, x, y, n) {
  var w = 52, h = 19;
  ctx.save();
  ctx.fillStyle = '#245a8d';
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(x, y, w, h, 9); else ctx.rect(x, y, w, h);
  ctx.fill();
  ctx.restore();
  label(ctx, 'Step ' + n, x + w / 2, y + h / 2 + 0.5,
    { size: 11.5, bold: true, color: '#ffffff', halo: false, clamp: false });
  return w;
}

/* ○ / × のふだ */
function stepMark(ctx, x, y, ok) {
  ctx.save();
  ctx.fillStyle = ok ? '#1c8f4a' : '#c0392b';
  ctx.beginPath(); ctx.arc(x, y, 11, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
  label(ctx, ok ? '○' : '×', x, y + 0.5,
    { size: 15, bold: true, color: '#fff', halo: false, clamp: false });
}

/* 箱と箱をつなぐ矢印 */
function stepArrow(ctx, x, y, len, vertical) {
  ctx.save();
  ctx.strokeStyle = '#8b98a5'; ctx.fillStyle = '#8b98a5'; ctx.lineWidth = 2.4;
  ctx.beginPath();
  if (vertical) { ctx.moveTo(x, y); ctx.lineTo(x, y + len - 8); }
  else { ctx.moveTo(x, y); ctx.lineTo(x + len - 8, y); }
  ctx.stroke();
  ctx.beginPath();
  if (vertical) { ctx.moveTo(x, y + len); ctx.lineTo(x - 5.5, y + len - 9); ctx.lineTo(x + 5.5, y + len - 9); }
  else { ctx.moveTo(x + len, y); ctx.lineTo(x + len - 9, y - 5.5); ctx.lineTo(x + len - 9, y + 5.5); }
  ctx.closePath(); ctx.fill();
  ctx.restore();
}

/* Step2 の中の小さな表（点・K・U） */
function stepTable(ctx, x, y, w, rows, hasUs, rh) {
  var cols = hasUs ? 4 : 3;
  var cw = [w * 0.16, w * (hasUs ? 0.30 : 0.42), w * (hasUs ? 0.27 : 0.42), w * 0.27];
  var i, j;
  rh = rh || 15;
  var head = hasUs ? ['', '運動エネルギー', '重力の位置エネ', '弾性力の位置エネ']
    : ['', '運動エネルギー K', '位置エネルギー U'];
  var colX = [x], acc = x;
  for (i = 0; i < cols; i++) { acc += cw[i]; colX.push(acc); }
  ctx.save();
  ctx.strokeStyle = '#c3cfdb'; ctx.lineWidth = 1;
  ctx.fillStyle = '#e7eef5';
  ctx.fillRect(x, y, acc - x, rh);
  ctx.strokeRect(x, y, acc - x, rh);
  for (i = 0; i < rows.length; i++) ctx.strokeRect(x, y + rh * (i + 1), acc - x, rh);
  for (j = 1; j < cols; j++) {
    ctx.beginPath(); ctx.moveTo(colX[j], y); ctx.lineTo(colX[j], y + rh * (rows.length + 1)); ctx.stroke();
  }
  ctx.restore();
  for (j = 0; j < cols; j++) {
    label(ctx, head[j] || '', (colX[j] + colX[j + 1]) / 2, y + rh / 2,
      { size: rh >= 15 ? 9 : 8.5, color: COL.sub, clamp: false });
  }
  var fz = rh >= 15 ? 11 : 10;
  for (i = 0; i < rows.length; i++) {
    var yy = y + rh * (i + 1) + rh / 2;
    label(ctx, rows[i][0], (colX[0] + colX[1]) / 2, yy, { size: fz, bold: true, clamp: false });
    label(ctx, rows[i][1], (colX[1] + colX[2]) / 2, yy, { size: fz, color: '#14663d', clamp: false });
    label(ctx, rows[i][2], (colX[2] + colX[3]) / 2, yy, { size: fz, color: COL.eU, clamp: false });
    if (hasUs) label(ctx, rows[i][3] || '0', (colX[3] + colX[4]) / 2, yy, { size: fz, color: COL.eU, clamp: false });
  }
  return rh * (rows.length + 1);
}

/* いま見ているシムから、ステップ図に出す中身を作る */
function stepData() {
  var d = DEFS[st.cur], s = st.sims[st.cur], v = V(s);
  var ok = consOf(d, v);
  var ps = ptsOf(d, v);
  var hasUs = !!d.hasUs;
  var rows = ps.map(function (p) {
    return [p.name, texPlain(p.sym.K || '0'), texPlain(p.sym.Ug || '0'), texPlain(p.sym.Us || '0')];
  });
  return {
    ok: ok, rows: rows, hasUs: hasUs,
    why: ok ? (d.step1 || '保存力（重力・弾性力）だけが仕事をしている')
      : (d.step1 || '非保存力が仕事をしている'),
    /* ★式は2行で書く★ 1行目＝エネルギーどうしの関係、2行目＝K と U に書きひらいた形 */
    eq1: ok ? 'E_1 = E_2' : 'E_2 - E_1 = W_{非保存}',
    eq2: ok ? 'K_1 + U_1 = K_2 + U_2' : '(K_2 + U_2) - (K_1 + U_1) = W_{非保存}',
    /* ★補足は「式を立てる」の右に置く★ 横に入る長さにそろえておく */
    eqSub: ok ? '（力学的エネルギー保存則）' : '（' + (d.wName || '非保存力') + 'の仕事の分だけ変わる）'
  };
}

function drawStep(cv) {
  if (!cv) return;
  var wide = (cv.clientWidth || 900) >= 640;
  var D = stepData();
  if (wide) drawStepWide(cv, D); else drawStepNarrow(cv, D);
}

/* 表の1行の高さと、それに合わせた箱の高さ（点の数で変わる） */
var STEP_RH = 15;
function stepBodyH(D) { return STEP_RH * (D.rows.length + 1); }

function drawStepWide(cv, D) {
  var W = STEP.W;
  /* ★縦はできるだけ低く★ 中身（Step2 の表）に合わせて決める */
  var bh = Math.max(94, 32 + stepBodyH(D) + 8);
  var H = bh + 12, ctx = prep(cv, W, H);
  var gap = 30, bw = (W - gap * 2 - 8) / 3, x0 = 4, y0 = 6;
  var i, xs = [x0, x0 + bw + gap, x0 + (bw + gap) * 2];
  stepBox(ctx, xs[0], y0, bw, bh, D.ok ? 'ok' : 'ng');
  stepBox(ctx, xs[1], y0, bw, bh);
  stepBox(ctx, xs[2], y0, bw, bh, D.ok ? 'ok' : 'ng');
  for (i = 0; i < 2; i++) stepArrow(ctx, xs[i] + bw + 4, y0 + bh / 2, gap - 8, false);

  var pad = 11, tagW = 52;
  /* --- Step1 --- */
  stepTag(ctx, xs[0] + pad, y0 + 7, 1);
  label(ctx, '保存力だけが仕事をしているか？', xs[0] + pad + tagW + 7, y0 + 16.5,
    { size: 12, bold: true, align: 'left', clamp: false });
  stepMark(ctx, xs[0] + pad + 12, y0 + 43, D.ok);
  label(ctx, D.ok ? '保存力だけ' : '非保存力が仕事をする', xs[0] + pad + 28, y0 + 43,
    { size: 12, bold: true, align: 'left', color: D.ok ? '#1c8f4a' : '#c0392b', clamp: false });
  wrapLabel(ctx, D.why, xs[0] + pad, y0 + 62, bw - pad * 2, 10.5, 13.5, '#3d4c5a');

  /* --- Step2 --- */
  stepTag(ctx, xs[1] + pad, y0 + 7, 2);
  label(ctx, '2つの位置でエネルギーを書き出す', xs[1] + pad + tagW + 7, y0 + 16.5,
    { size: 12, bold: true, align: 'left', clamp: false });
  stepTable(ctx, xs[1] + pad, y0 + 28, bw - pad * 2, D.rows, D.hasUs, STEP_RH);

  /* --- Step3 --- ★補足（力学的エネルギー保存則 など）は見出しの右に置く★ */
  stepTag(ctx, xs[2] + pad, y0 + 7, 3);
  label(ctx, '式を立てる', xs[2] + pad + tagW + 7, y0 + 16.5,
    { size: 12, bold: true, align: 'left', clamp: false });
  var subX = xs[2] + pad + tagW + 7 + 62;
  labelFitLeft(ctx, D.eqSub, subX, y0 + 17, xs[2] + bw - pad - subX, 10, { color: COL.sub });
  var eqY = y0 + 30 + (bh - 30) / 2;             /* 見出しの下の空きの中央 */
  labelFit(ctx, D.eq1, xs[2] + bw / 2, eqY - 13, bw - pad * 2, 19,
    { bold: true, color: D.ok ? '#14663d' : '#a5382c' });
  labelFit(ctx, D.eq2, xs[2] + bw / 2, eqY + 12, bw - pad * 2, 14,
    { bold: true, color: D.ok ? '#14663d' : '#a5382c' });
}

function drawStepNarrow(cv, D) {
  var W = STEP.NW, x = 4, pad = 9, bw = W - 8;
  var hs = [70, 26 + stepBodyH(D), 62], gapv = 17;
  var H = hs[0] + hs[1] + hs[2] + gapv * 2 + 8, ctx = prep(cv, W, H);
  var y = 2, i, ys = [];
  for (i = 0; i < 3; i++) { ys.push(y); y += hs[i] + gapv; }
  stepBox(ctx, x, ys[0], bw, hs[0], D.ok ? 'ok' : 'ng');
  stepBox(ctx, x, ys[1], bw, hs[1]);
  stepBox(ctx, x, ys[2], bw, hs[2], D.ok ? 'ok' : 'ng');
  for (i = 0; i < 2; i++) stepArrow(ctx, W / 2, ys[i] + hs[i] + 3, 12, true);

  var tagW = 52;
  stepTag(ctx, x + pad, ys[0] + 6, 1);
  label(ctx, '保存力だけが仕事をしている？', x + pad + tagW + 6, ys[0] + 15.5,
    { size: 11.5, bold: true, align: 'left', clamp: false });
  stepMark(ctx, x + pad + 12, ys[0] + 38, D.ok);
  label(ctx, D.ok ? '保存力だけ' : '非保存力が仕事をする', x + pad + 28, ys[0] + 38,
    { size: 11.5, bold: true, align: 'left', color: D.ok ? '#1c8f4a' : '#c0392b', clamp: false });
  wrapLabel(ctx, D.why, x + pad, ys[0] + 55, bw - pad * 2, 9.5, 12, '#3d4c5a');

  stepTag(ctx, x + pad, ys[1] + 6, 2);
  label(ctx, '2つの位置で書き出す', x + pad + tagW + 6, ys[1] + 15.5,
    { size: 11.5, bold: true, align: 'left', clamp: false });
  stepTable(ctx, x + pad, ys[1] + 25, bw - pad * 2, D.rows, D.hasUs, STEP_RH);

  stepTag(ctx, x + pad, ys[2] + 6, 3);
  label(ctx, '式を立てる', x + pad + tagW + 6, ys[2] + 15.5,
    { size: 11.5, bold: true, align: 'left', clamp: false });
  var subX2 = x + pad + tagW + 6 + 58;
  labelFitLeft(ctx, D.eqSub, subX2, ys[2] + 16, x + bw - pad - subX2, 9, { color: COL.sub });
  labelFit(ctx, D.eq1, x + bw / 2, ys[2] + 34, bw - pad * 2, 16,
    { bold: true, color: D.ok ? '#14663d' : '#a5382c' });
  labelFit(ctx, D.eq2, x + bw / 2, ys[2] + 52, bw - pad * 2, 12.5,
    { bold: true, color: D.ok ? '#14663d' : '#a5382c' });
}

/* 左そろえで、幅に入るまで字を小さくして書く（見出しの右のひとこと用） */
function labelFitLeft(ctx, text, x, y, maxW, size, opt) {
  opt = opt || {};
  var sz = size, w;
  for (; sz > 6.5; sz -= 0.5) {
    ctx.save(); ctx.font = sz + 'px ' + FONT;
    w = ctx.measureText(String(text)).width; ctx.restore();
    if (w <= maxW) break;
  }
  label(ctx, text, x, y, { size: sz, color: opt.color, align: 'left', clamp: false });
}

/* 幅に入るまで字を小さくして、中央に書く（式がはみ出さないように） */
function labelFit(ctx, text, cx, cy, maxW, size, opt) {
  opt = opt || {};
  var sz = size, w;
  var segs = String(text).replace(/_\{[^}]*\}|_./g, '');   /* 添え字は幅の見積もりから外す */
  for (; sz > 8; sz -= 0.5) {
    ctx.save(); ctx.font = (opt.bold ? 'bold ' : '') + sz + 'px ' + FONT;
    w = ctx.measureText(segs).width; ctx.restore();
    if (w <= maxW) break;
  }
  label(ctx, text, cx, cy, { size: sz, bold: opt.bold, color: opt.color, clamp: false });
}

/* 文字を幅で折り返して書く（日本語なので1文字ずつ測る） */
function wrapLabel(ctx, text, x, y, w, size, lh, color) {
  ctx.save();
  ctx.font = size + 'px ' + FONT;
  var line = '', i, lines = [];
  for (i = 0; i < text.length; i++) {
    var ch = text.charAt(i);
    if (ctx.measureText(line + ch).width > w && line) { lines.push(line); line = ''; }
    line += ch;
  }
  if (line) lines.push(line);
  ctx.restore();
  for (i = 0; i < lines.length; i++) {
    label(ctx, lines[i], x, y + i * lh, { size: size, color: color, align: 'left', clamp: false });
  }
}
