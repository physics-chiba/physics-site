#!/usr/bin/env node
/* 単一 HTML ビルドスクリプト
 * src/ の部品を決まった順に連結して dist/celestial-mechanics.html を作る。
 * KaTeX は CSS / JS / フォント(woff2 を base64) をすべて埋め込み、完全オフラインにする。
 */
'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const SRC = path.join(ROOT, 'src');
const OUT = path.join(ROOT, 'dist', 'celestial-mechanics.html');
const KATEX = '/home/claude/.npm-global/lib/node_modules/markdownlint-cli2/node_modules/katex/dist';
const KATEX_VER = '0.16.45';

/* この教材で使う字種に必要なものだけ埋め込む */
const FONT_WHITELIST = [
  'KaTeX_Main-Regular', 'KaTeX_Main-Bold', 'KaTeX_Main-Italic',
  'KaTeX_Math-Italic', 'KaTeX_Math-BoldItalic',
  'KaTeX_Size1-Regular', 'KaTeX_Size2-Regular', 'KaTeX_Size3-Regular', 'KaTeX_Size4-Regular',
  'KaTeX_AMS-Regular'
];

function read(p) { return fs.readFileSync(p, 'utf8'); }

/* assets/ の画像を base64 で埋め込み、IMG.〈ファイル名〉で使えるようにする。
   （完全オフラインの単一 HTML なので、外部ファイルは1つも参照しない） */
function imgScript() {
  const dir = path.join(ROOT, 'assets');
  if (!fs.existsSync(dir)) return '/* ===== assets: なし ===== */\nvar IMG = {};';
  const types = { '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png', '.webp': 'image/webp' };
  const lines = [];
  fs.readdirSync(dir).sort().forEach(f => {
    const ext = path.extname(f).toLowerCase();
    if (!types[ext]) return;
    const b64 = fs.readFileSync(path.join(dir, f)).toString('base64');
    const key = path.basename(f, ext);
    lines.push(`  ${JSON.stringify(key)}: 'data:${types[ext]};base64,${b64}'`);
    console.log(`  画像を埋め込み: ${f} (${(b64.length / 1024).toFixed(0)} KB)`);
  });
  return `/* ===== assets（base64 で埋め込み） ===== */\nvar IMG = {\n${lines.join(',\n')}\n};`;
}

/** KaTeX の CSS を、@font-face ブロック単位で走査して差し替える（一括正規表現置換はしない） */
function inlineKatexCss() {
  const css = read(path.join(KATEX, 'katex.min.css'));
  const out = [];
  let i = 0, kept = 0, dropped = 0;
  while (i < css.length) {
    const at = css.indexOf('@font-face{', i);
    if (at === -1) { out.push(css.slice(i)); break; }
    out.push(css.slice(i, at));
    const end = css.indexOf('}', at);
    if (end === -1) { out.push(css.slice(at)); break; }
    const block = css.slice(at, end + 1);
    const face = rewriteFontFace(block);
    if (face) { out.push(face); kept++; } else { dropped++; }
    i = end + 1;
  }
  console.log(`  @font-face: ${kept} 個を埋め込み / ${dropped} 個を除外`);
  return out.join('');
}

/** 1つの @font-face ブロックを base64 データ URI 版に書き換える。対象外なら null */
function rewriteFontFace(block) {
  const m = block.indexOf('fonts/');
  if (m === -1) return null;
  const tail = block.slice(m + 'fonts/'.length);
  const dot = tail.indexOf('.');
  if (dot === -1) return null;
  const name = tail.slice(0, dot);
  if (FONT_WHITELIST.indexOf(name) === -1) return null;

  const woff2 = path.join(KATEX, 'fonts', name + '.woff2');
  if (!fs.existsSync(woff2)) return null;
  const b64 = fs.readFileSync(woff2).toString('base64');

  const srcAt = block.indexOf('src:');
  if (srcAt === -1) return null;
  const head = block.slice(0, srcAt);
  return head + `src:url(data:font/woff2;base64,${b64}) format("woff2")}`;
}

const JS_FILES = [
  '30_physics.js',
  '40_draw.js',
  '45_defs.js',
  '50_mode1.js',
  '60_mode2.js',
  '70_mode3.js',
  '75_mode4.js',
  '80_ui.js',
  '90_boot.js'
];

function build() {
  console.log('ビルド開始');
  const katexCss = inlineKatexCss();
  const katexJs = read(path.join(KATEX, 'katex.min.js'));

  const head = read(path.join(SRC, '00_head.html'));
  const style = read(path.join(SRC, '10_style.css'));
  const body = read(path.join(SRC, '20_body.html'));
  /* ★95_tail.html＝ページ本体のうしろに足す「ページ共通の部品」★
     アクセス数のカウント（GoatCounter）と、▶スタートを光らせる仕掛け。
     physics-site の他のページと同じものを、同じかたちで足している。
     ★ここを消すとサイト全体の作法からはずれるので、消さないこと★ */
  const tail = fs.existsSync(path.join(SRC, '95_tail.html'))
    ? read(path.join(SRC, '95_tail.html')) : '';
  const scripts = [imgScript()].concat(JS_FILES
    .map(f => `/* ===== ${f} ===== */\n${read(path.join(SRC, f))}`))
    .join('\n');

  const html = `<!DOCTYPE html>
<html lang="ja">
<head>
${head}
<style>
/* ===== KaTeX ${KATEX_VER} (fonts embedded / offline) ===== */
${katexCss}
</style>
<style>
/* ===== 10_style.css ===== */
${style}
</style>
</head>
<body>
${body}
<script>/* ===== KaTeX ${KATEX_VER} ===== */
${katexJs}
</script>
<script>
${scripts}
</script>
${tail}</body>
</html>
`;

  fs.mkdirSync(path.dirname(OUT), { recursive: true });
  fs.writeFileSync(OUT, html, 'utf8');
  const kb = (Buffer.byteLength(html) / 1024).toFixed(0);
  console.log(`出力: ${OUT} (${kb} KB)`);
}

build();
