#!/usr/bin/env node
/* 単一 HTML ビルドスクリプト
 * src/ の部品を決まった順に連結して dist/celestial-mechanics.html を作る。
 * KaTeX は CSS / JS / フォント(woff2 を base64) をすべて埋め込み、完全オフラインにする。
 */
'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const SRC = path.join(ROOT, 'src');
const OUT = path.join(ROOT, 'dist', 'celestial-mechanics.html');
const KATEX = ['/home/claude/.npm-global/lib/node_modules/markdownlint-cli2/node_modules/katex/dist', '/opt/npm-tools/node_modules/katex/dist'].filter(p => fs.existsSync(p))[0];
const KATEX_VER = '0.16.45';

/* この教材で使う字種に必要なものだけ埋め込む。
   ★2026-11-12：Math-BoldItalic と AMS-Regular を外した（あわせて 59 KB 減）★
     ・Math-BoldItalic … \boldsymbol・\bm の太字斜体。このページでは1回も使っていない。
     ・AMS-Regular     … \fallingdotseq（≒）・\leqq・\therefore・\mathbb などの記号。同上。
   ★これらの命令を新しく使うときは、ここに書体を戻すこと★
   （戻さないと、その記号だけ別の書体〔Times など〕で出る。こわれはしない）
   Main-Bold と Main-Italic は、数式ではなく見出しの欧文（12_design.css の --f-serif）が使っている。 */
const FONT_WHITELIST = [
  'KaTeX_Main-Regular', 'KaTeX_Main-Bold', 'KaTeX_Main-Italic',
  'KaTeX_Math-Italic',
  'KaTeX_Size1-Regular', 'KaTeX_Size2-Regular', 'KaTeX_Size3-Regular', 'KaTeX_Size4-Regular'
];

/* ★公開用のファイルは、自前の JS・CSS のコメントと空白を取って小さくする★（2026-11-12）
   simple-harmonic-motion・Inertia-force と同じやり方。esbuild を使う。
     ・JS  … 空白とコメントを取り、書き方を短くする（★名前は変えない★ので、
             コンソールから st や DEFS をそのまま触れるし、test/run_test.py もそのまま動く）。
             target を es2017 にしてあるので、?. や ?? のような新しい書き方には変えない
             （古い iPad でも動くように）。
     ・CSS … 空白とコメントを取るだけ（書き方は変えない）。
   ★読みやすい版がほしいとき： node build.js --plain ★（コメントも改行もそのまま出る）
   esbuild が見つからないときは、取らずにそのまま出す（こわれはしない。大きいだけ）。 */
const PLAIN = process.argv.includes('--plain') || process.argv.includes('--no-min');
let esbuild = null;
if (!PLAIN) {
  for (const m of ['esbuild', path.join(ROOT, 'node_modules', 'esbuild'), '/opt/npm-tools/node_modules/esbuild',
    '/home/claude/.npm-global/lib/node_modules/esbuild']) {
    try { esbuild = require(m); break; } catch (e) { /* 次を試す */ }
  }
  if (!esbuild) console.log('  ※ esbuild が見つからないので、コメントと空白は取らずに出します');
}
function minJs(code) {
  if (!esbuild) return code;
  return esbuild.transformSync(code, {
    loader: 'js', minifyWhitespace: true, minifySyntax: true, minifyIdentifiers: false,
    charset: 'utf8', legalComments: 'none', target: 'es2017'
  }).code.trim();
}
function minCss(code) {
  if (!esbuild) return code;
  return esbuild.transformSync(code, {
    loader: 'css', minifyWhitespace: true, minifySyntax: false, charset: 'utf8', legalComments: 'none'
  }).code.trim();
}

function read(p) { return fs.readFileSync(p, 'utf8'); }

/* assets/ の画像を base64 で埋め込み、IMG.〈ファイル名〉で使えるようにする。
   （完全オフラインの単一 HTML なので、外部ファイルは1つも参照しない） */
function imgScript() {
  const dir = path.join(ROOT, 'assets');
  if (!fs.existsSync(dir)) return '/* ===== assets: なし ===== */\nvar IMG = {};';
  const types = { '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png', '.webp': 'image/webp' };
  const lines = [];
  fs.readdirSync(dir).sort().forEach(f => {
    const ext = path.extname(f).toLowerCase();
    if (!types[ext]) return;
    const b64 = fs.readFileSync(path.join(dir, f)).toString('base64');
    const key = path.basename(f, ext);
    lines.push(`  ${JSON.stringify(key)}: 'data:${types[ext]};base64,${b64}'`);
    console.log(`  画像を埋め込み: ${f} (${(b64.length / 1024).toFixed(0)} KB)`);
  });
  return `/* ===== assets（base64 で埋め込み） ===== */\nvar IMG = {\n${lines.join(',\n')}\n};`;
}

/* ★入試問題の「問題文」「解答と解き方」のシートは、画像ではなく HTML のまま埋めこむ★
   （2026-11-12。PNG 6枚で約 1.5 MB あったものが、60 KB ほどになった）
   assets/sheets/<キー>.html と <種類>.css は tools/probsheet.py・anssheet.py が書き出す。
   SHEET[キー] = { css: 'prob' | 'ans', html: '…' } ／ SHEETCSS[種類] = '…'
   表示するのは 80_ui.js の openProbImg（Shadow DOM の中に入れる）。 */
function sheetScript() {
  const dir = path.join(ROOT, 'assets', 'sheets');
  if (!fs.existsSync(dir)) return '/* ===== sheets: なし ===== */\nvar SHEET = {}, SHEETCSS = {};';
  const css = [], sh = [];
  let total = 0;
  fs.readdirSync(dir).sort().forEach(f => {
    const ext = path.extname(f), key = path.basename(f, ext);
    const txt = read(path.join(dir, f)).trim();
    total += Buffer.byteLength(txt);
    /* </script> と書いてあっても <script> が閉じないように、"<" を \u003c にしておく */
    const lit = JSON.stringify(txt).split('<').join('\\u003c');
    if (ext === '.css') css.push(`  ${JSON.stringify(key)}: ${lit}`);
    if (ext === '.html') {
      const kind = key.split('_')[0];              /* prob_m31 → prob */
      sh.push(`  ${JSON.stringify(key)}: { css: ${JSON.stringify(kind)}, html: ${lit} }`);
    }
  });
  console.log(`  シートを埋め込み: ${sh.length} 枚 (${(total / 1024).toFixed(0)} KB)`);
  return `/* ===== 問題文・解答のシート（HTML のまま埋め込み） ===== */\n`
    + `var SHEETCSS = {\n${css.join(',\n')}\n};\nvar SHEET = {\n${sh.join(',\n')}\n};`;
}

/** KaTeX の CSS を、@font-face ブロック単位で走査して差し替える（一括正規表現置換はしない） */
function inlineKatexCss() {
  const css = read(path.join(KATEX, 'katex.min.css'));
  const out = [];
  let i = 0, kept = 0, dropped = 0;
  while (i < css.length) {
    const at = css.indexOf('@font-face{', i);
    if (at === -1) { out.push(css.slice(i)); break; }
    out.push(css.slice(i, at));
    const end = css.indexOf('}', at);
    if (end === -1) { out.push(css.slice(at)); break; }
    const block = css.slice(at, end + 1);
    const face = rewriteFontFace(block);
    if (face) { out.push(face); kept++; } else { dropped++; }
    i = end + 1;
  }
  console.log(`  @font-face: ${kept} 個を埋め込み / ${dropped} 個を除外`);
  return out.join('');
}

/** 1つの @font-face ブロックを base64 データ URI 版に書き換える。対象外なら null */
function rewriteFontFace(block) {
  const m = block.indexOf('fonts/');
  if (m === -1) return null;
  const tail = block.slice(m + 'fonts/'.length);
  const dot = tail.indexOf('.');
  if (dot === -1) return null;
  const name = tail.slice(0, dot);
  if (FONT_WHITELIST.indexOf(name) === -1) return null;

  const woff2 = path.join(KATEX, 'fonts', name + '.woff2');
  if (!fs.existsSync(woff2)) return null;
  const b64 = fs.readFileSync(woff2).toString('base64');

  const srcAt = block.indexOf('src:');
  if (srcAt === -1) return null;
  const head = block.slice(0, srcAt);
  return head + `src:url(data:font/woff2;base64,${b64}) format("woff2")}`;
}

const JS_FILES = [
  /* ★29_canvas_theme.js は いちばん最初★
     canvas に色を入れる瞬間（fillStyle/strokeStyle）を横取りするので、
     ほかの JS より先に読まないと、先に描いた図に効かない。 */
  '29_canvas_theme.js',
  '30_physics.js',
  '40_draw.js',
  '45_defs.js',
  '50_mode1.js',
  '60_mode2.js',
  '70_mode3.js',
  '75_mode4.js',
  '80_ui.js',
  /* ★85（ヒーローの中身）→ 84（ページ一覧）の順★
     84 の buildSiteDrawer は #bPages を探すが、そのボタンは 85 の buildHeroParts が作る。
     順番を逆にすると、ボタンが見つからず「ページ一覧」が開かなくなる（実際そうなった）。 */
  '85_design.js',
  '84_sitenav.js',
  '90_boot.js'
];

function build() {
  console.log('ビルド開始');
  const katexCss = inlineKatexCss();
  const katexJs = read(path.join(KATEX, 'katex.min.js'));

  const head = read(path.join(SRC, '00_head.html'));
  const style = minCss(read(path.join(SRC, '10_style.css')));
  /* ★12_design.css は 10_style.css の「あと」に読む上書きの層★
     もとの見た目（10_style.css）は書きかえず、あとから色・形・余白だけをかぶせる。 */
  const design = minCss(read(path.join(SRC, '12_design.css')));
  const body = read(path.join(SRC, '20_body.html'));
  /* ★95_tail.html＝ページ本体のうしろに足す「ページ共通の部品」★
     アクセス数のカウント（GoatCounter）と、▶スタートを光らせる仕掛け。
     physics-site の他のページと同じものを、同じかたちで足している。
     ★ここを消すとサイト全体の作法からはずれるので、消さないこと★ */
  const tail = fs.existsSync(path.join(SRC, '95_tail.html'))
    ? read(path.join(SRC, '95_tail.html')) : '';
  const scriptsSrc = [imgScript(), sheetScript()].concat(JS_FILES
    .map(f => `/* ===== ${f} ===== */\n${read(path.join(SRC, f))}`))
    .join('\n');
  const scripts = esbuild
    ? '/* 公開用に、コメントと空白を取って小さくした版です。読みやすいソースは celestial-mechanics_src.zip にあります。 */\n' + minJs(scriptsSrc)
    : scriptsSrc;
  if (esbuild) {
    console.log(`  自前の JS: ${(Buffer.byteLength(scriptsSrc) / 1024).toFixed(0)} KB → ${(Buffer.byteLength(scripts) / 1024).toFixed(0)} KB`);
  }

  const html = `<!DOCTYPE html>
<html lang="ja">
<head>
${head}
<style>
/* ===== KaTeX ${KATEX_VER} (fonts embedded / offline) ===== */
${katexCss}
</style>
<style>
/* ===== 10_style.css ===== */
${style}
</style>
<style>
/* ===== 12_design.css（見た目の上書き層） ===== */
${design}
</style>
</head>
<body>
${body}
<script>/* ===== KaTeX ${KATEX_VER} ===== */
${katexJs}
</script>
<script>
${scripts}
</script>
${tail}</body>
</html>
`;

  fs.mkdirSync(path.dirname(OUT), { recursive: true });
  fs.writeFileSync(OUT, html, 'utf8');
  const kb = (Buffer.byteLength(html) / 1024).toFixed(0);
  const gz = (require('zlib').gzipSync(Buffer.from(html, 'utf8')).length / 1024).toFixed(0);
  console.log(`出力: ${OUT} (${kb} KB／圧縮して送られる量 ${gz} KB)${PLAIN ? '  ※読みやすい版（--plain）' : ''}`);
}

build();
