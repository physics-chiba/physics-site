# -*- coding: utf-8 -*-
"""
入試問題の「解答・解説シート」を画像（PNG）で作る。

★ねらい★
  生徒が自分で解いたあとに、答え合わせと解き方の確認ができるようにする。
★著作権への配慮★（問題文シートと同じ）
  ・解説は原文そのままの引き写しではなく、こちらで書き直した文にする。
  ・図は原図の複製ではなく、同じ内容を表す図をこちらで描き起こす。
  ・出典（大学名）は必ず書き、「一部を書きかえています」と明記する。
★記号★
  シミュレーションの本文（probs）と<b>まったく同じ記号・同じ番号</b>にそろえること。
  （3-3 の r₁・r₂ は、原典と逆向きにとってあるので、その断りをシートの中に書いてある）
つくり方：HTML を組み立てて Playwright で撮る → assets/ に置く
        → build.js が base64 で HTML に埋め込む（オフラインでも開ける）。
"""
import os
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'assets')

CSS = """
<style>
 *{box-sizing:border-box}
 body{margin:0;background:#fff;font-family:"Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif;
   color:#1b1f24;width:820px;padding:0 0 18px}
 .head{background:#12325c;color:#fff;padding:12px 20px}
 .head h1{margin:0;font-size:18px;letter-spacing:.02em}
 .head .src{margin-top:3px;font-size:12px;color:#c6d8ee}
 .wrap{padding:14px 20px 0}
 .sec{font-weight:700;color:#12325c;font-size:14px;margin:15px 0 5px;
   border-left:5px solid #e8951a;padding-left:7px}
 .tools{background:#f3f6fa;border:1px solid #d6dfe8;border-radius:6px;padding:9px 13px;
   font-size:13px;line-height:1.95}
 .tools td{padding:2px 10px 2px 0;vertical-align:top}
 .tools th{padding:2px 10px 2px 0;text-align:left;color:#12325c;white-space:nowrap}
 .item{border:1px solid #dde4ec;border-radius:6px;margin:9px 0 0;overflow:hidden}
 .qq{background:#eaf1f8;padding:6px 12px;font-size:13px;line-height:1.75;color:#12325c;
   font-weight:700}
 .body{padding:9px 13px 11px}
 .ans{background:#fff4e2;border:1px solid #f0c98a;border-radius:5px;
   padding:6px 11px;font-size:14px;line-height:2.05;margin:0 0 7px}
 .ans .lb{color:#a85c0c;font-weight:700;font-size:12px;margin-right:7px}
 .sol{font-size:13px;line-height:2.15}
 .sol .st{color:#12325c;font-weight:700}
 .memo{margin-top:6px;font-size:12.5px;line-height:1.85;color:#4a5560;
   background:#f6f8fa;border-left:3px solid #9fb0c0;padding:5px 10px;border-radius:0 4px 4px 0}
 .memo b{color:#12325c}
 .num{font-size:12.5px;color:#5b6672}
 .figbox{float:right;margin:0 0 6px 12px;border:1px solid #d6dfe8;border-radius:5px;padding:4px}
 .figcap{font-size:10.5px;color:#5b6672;text-align:center;margin-top:1px}
 .clr{clear:both}
 .foot{margin:14px 20px 0;font-size:11px;color:#5b6672;line-height:1.7;
   border-top:1px solid #d6dfe8;padding-top:8px}
 b{color:#12325c}
 .fr{display:inline-block;vertical-align:-0.55em;text-align:center;margin:0 2px;line-height:1.35}
 .fr .n{display:block;border-bottom:1.2px solid #1b1f24;padding:0 4px}
 .fr .d{display:block;padding:0 4px}
 .sq{border-top:1.2px solid #1b1f24;padding:1px 2px 0 1px}
 svg text{font-family:"Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif}
</style>
"""

FOOT = ('※ 著作権に配慮し、解説は原文の引き写しではなく、'
        'このページのために書き直したものです。'
        '図も原図の複製ではなく、同じ内容を表すものを新しく描き起こしています。<br>'
        '※ 記号と小問の番号は、シミュレーションの右側の「入試問題を読み解く」と'
        'そろえてあります。数値は地球（R = 6371 km・g = 9.82 m/s²）を入れたときの値です。')


def fr(n, d):
    """分数（見た目だけの組み方）"""
    return '<span class="fr"><span class="n">%s</span><span class="d">%s</span></span>' % (n, d)


def sq(x):
    """平方根（上線つき）"""
    return '&radic;<span class="sq">%s</span>' % x


def item(q, ans, sol, memo=None, fig=None, figcap=''):
    f = ''
    if fig:
        f = '<div class="figbox">%s<div class="figcap">%s</div></div>' % (fig, figcap)
    m = ('<div class="memo">%s</div>' % memo) if memo else ''
    return ('<div class="item"><div class="qq">%s</div><div class="body">%s'
            '<div class="ans"><span class="lb">答</span>%s</div>'
            '<div class="sol">%s</div>%s<div class="clr"></div></div></div>'
            % (q, f, ans, sol, m))


def page(title, src, tools, items):
    return f"""<!doctype html><html lang="ja"><meta charset="utf-8">{CSS}
<div class="head"><h1>{title}</h1><div class="src">{src}</div></div>
<div class="wrap">
  <div class="sec">この問題で使う道具</div>
  <div class="tools">{tools}</div>
  <div class="sec">解答と解き方</div>
  {''.join(items)}
</div>
<div class="foot">{FOOT}</div>
</html>"""


# ===================== 共通の「道具」表 =====================
TOOLS_COMMON = (
  '<table class="tools">'
  '<tr><th>力学的エネルギー保存</th><td>&frac12;mv&sup2; &minus; G' + fr('Mm', 'r') + ' = 一定'
  '　<span class="num">（向きは関係ない。道すじにもよらない）</span></td></tr>'
  '<tr><th>面積速度一定（ケプラーⅡ）</th><td>&frac12;rv sin&theta; = 一定'
  '　<span class="num">近点・遠点では rv = 一定</span></td></tr>'
  '<tr><th>円運動のとき</th><td>' + fr('mv&sup2;', 'r') + ' = G' + fr('Mm', 'r&sup2;')
  + '　<span class="num">（向心力 ＝ 万有引力）</span></td></tr>'
  '<tr><th>ケプラーの第3法則</th><td>T&sup2; = ka&sup3;'
  '　<span class="num">a は半長軸。同じ天体のまわりなら k は共通</span></td></tr>'
  '<tr><th>地表での関係</th><td>mg = G' + fr('Mm', 'R&sup2;') + ' より '
  '<b>GM = gR&sup2;</b>　<span class="num">これで G, M を g, R に置きかえられる</span></td></tr>'
  '</table>')

# ===================== 3-1 の図（(4) の「地表をかする」だ円）=====================
FIG31A = """
<svg width="220" height="168" viewBox="0 0 220 168">
  <!-- 縮尺 R = 34 px。O(95,84)・A は右へ 2R・C は左へ R（＝地表のうえ） -->
  <line x1="40" y1="84" x2="185" y2="84" stroke="#9aa5b1" stroke-width="1"
        stroke-dasharray="5 4"/>
  <!-- だ円：中心 (112,84)・a = 51・焦点 O まで c = 17 → b = 48 -->
  <ellipse cx="112" cy="84" rx="51" ry="48" fill="none" stroke="#1c8f4a" stroke-width="1.6"/>
  <circle cx="95" cy="84" r="34" fill="#cfe0f0" stroke="#2a5f96" stroke-width="1.3"/>
  <circle cx="95" cy="84" r="2.2" fill="#1b1f24"/>
  <text x="100" y="97" font-size="11" font-weight="bold">O</text>
  <circle cx="163" cy="84" r="4" fill="#fff" stroke="#1b1f24" stroke-width="1.6"/>
  <text x="171" y="80" font-size="11" font-weight="bold">A</text>
  <circle cx="61" cy="84" r="4" fill="#fff" stroke="#d1352b" stroke-width="1.8"/>
  <text x="52" y="80" font-size="11" text-anchor="end" font-weight="bold" fill="#d1352b">C</text>
  <line x1="163" y1="84" x2="163" y2="48" stroke="#1663b5" stroke-width="2"
        marker-end="url(#ah)"/>
  <text x="169" y="48" font-size="11" fill="#1663b5" font-weight="bold">v</text>
  <line x1="61" y1="84" x2="61" y2="128" stroke="#1663b5" stroke-width="2"
        marker-end="url(#ah)"/>
  <text x="50" y="126" font-size="11" fill="#1663b5" font-weight="bold" text-anchor="end">V</text>
  <text x="110" y="158" font-size="10.5" text-anchor="middle" fill="#5b6672">
    OA = 2R　OC = R（地表のうえ）</text>
  <defs><marker id="ah" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto">
    <path d="M0,0 L8,4 L0,8 z" fill="#1663b5"/></marker></defs>
</svg>"""

# ===================== 3-2 の図（f–x グラフ）=====================
FIG32A = """
<svg width="230" height="150" viewBox="0 0 230 150">
  <line x1="14" y1="75" x2="216" y2="75" stroke="#8b949e" stroke-width="1.2"/>
  <path d="M216,75 L208,71 L208,79 z" fill="#8b949e"/>
  <text x="212" y="66" font-size="11" font-weight="bold" fill="#8b949e">x</text>
  <line x1="115" y1="12" x2="115" y2="142" stroke="#8b949e" stroke-width="1.2"/>
  <path d="M115,12 L111,20 L119,20 z" fill="#8b949e"/>
  <text x="122" y="20" font-size="11" font-weight="bold" fill="#8b949e">f</text>
  <!-- 内は直線（−R→+R で f は正→負） -->
  <line x1="70" y1="33" x2="160" y2="117" stroke="#1b1f24" stroke-width="2"/>
  <!-- 外は 1/x²（右は負・左は正） -->
  <path d="M160,117 C176,96 192,88 212,84" fill="none" stroke="#1b1f24" stroke-width="2"/>
  <path d="M70,33 C54,54 38,62 18,66" fill="none" stroke="#1b1f24" stroke-width="2"/>
  <line x1="70" y1="71" x2="70" y2="79" stroke="#1b1f24"/>
  <line x1="160" y1="71" x2="160" y2="79" stroke="#1b1f24"/>
  <text x="66" y="92" font-size="11" text-anchor="end">&minus;R</text>
  <text x="164" y="66" font-size="11">R</text>
  <text x="108" y="90" font-size="11" text-anchor="end" font-weight="bold">O</text>
  <line x1="115" y1="117" x2="160" y2="117" stroke="#9aa5b1" stroke-dasharray="3 3"/>
  <line x1="70" y1="33" x2="115" y2="33" stroke="#9aa5b1" stroke-dasharray="3 3"/>
  <text x="111" y="130" font-size="10.5" text-anchor="end" fill="#5b6672">&minus;mg</text>
  <text x="111" y="30" font-size="10.5" text-anchor="end" fill="#5b6672">mg</text>
</svg>"""


# ===================== 3-1 =====================
A31 = page(
  '3-1　等速円運動から楕円軌道への遷移　—　解答と解き方',
  '出典：大阪市立大（一部を書きかえています）',
  TOOLS_COMMON,
  [
   item(
     '(1)　点 A（中心から 2R）で速度が 0 になるには、打ち上げの速さ v₀ をいくらにすればよいか。',
     'v<sub>0</sub> = ' + sq('gR') + '　<span class="num">＝ 7.91 km/s</span>',
     '<span class="st">地表と点 A で力学的エネルギー保存。</span>点 A では速さ 0 だから<br>'
     '&frac12;mv<sub>0</sub>&sup2; &minus; G' + fr('Mm', 'R') + ' = 0 &minus; G'
     + fr('Mm', '2R') + '<br>'
     '&frac12;v<sub>0</sub>&sup2; = ' + fr('GM', 'R') + ' &minus; ' + fr('GM', '2R')
     + ' = ' + fr('GM', '2R') + '　よって v<sub>0</sub>&sup2; = ' + fr('GM', 'R') + '<br>'
     'ここに <b>GM = gR&sup2;</b> を入れて　v<sub>0</sub>&sup2; = gR。',
     memo='この値は<b>第一宇宙速度（地表すれすれの円軌道の速さ）とぴったり同じ</b>です。'
          'まっすぐ上へ 2R まで打ち上げる速さと、横向きに回りつづける速さが同じ——'
          '偶然ではなく、どちらも GM/R の平方根だからです。'),
   item(
     '(2)　点 A で OA に垂直に速さ v をあたえたら、O を中心とする等速円運動になった。'
     'v と周期を求めよ。',
     'v = ' + sq(fr('gR', '2')) + '　<span class="num">＝ 5.59 km/s</span>'
     + '　　T = 4&pi;' + sq(fr('2R', 'g')) + '　<span class="num">＝ 238.6 分</span>',
     '<span class="st">向心力 ＝ 万有引力。</span>半径は 2R だから<br>'
     + fr('mv&sup2;', '2R') + ' = G' + fr('Mm', '(2R)&sup2;')
     + '　よって v&sup2; = ' + fr('GM', '2R') + ' = ' + fr('gR', '2') + '<br>'
     '<span class="st">周期は「1周の道のり &divide; 速さ」。</span><br>'
     'T = ' + fr('2&pi;(2R)', 'v') + ' = 4&pi;R&radic;<span class="sq">'
     + fr('2', 'gR') + '</span> = 4&pi;' + sq(fr('2R', 'g')) + '。'),
   item(
     '(3)　A と B（O から 6R）を両端とする長軸のだ円をえがいた。'
     '(a) B での速さ V を v で　(b) v を g, R で　(c) この運動の周期',
     '(a) V = ' + fr('v', '3') + '　　(b) v = &frac12;' + sq('3gR')
     + '　<span class="num">＝ 6.85 km/s</span>　　(c) T&prime; = 16&pi;' + sq(fr('R', 'g'))
     + '　<span class="num">＝ 674.8 分</span>',
     '<span class="st">(a) 面積速度一定。</span>A も B も長軸のはしなので、'
     '速度は動径に垂直。だから rv がそのまま使えて<br>'
     '&frac12;&times;2R&times;v = &frac12;&times;6R&times;V　よって V = ' + fr('v', '3')
     + '　……&#9312;<br>'
     '<span class="st">(b) A と B でエネルギー保存。</span>&#9312;と GM = gR&sup2; を入れて<br>'
     '&frac12;v&sup2; &minus; ' + fr('gR&sup2;', '2R') + ' = &frac12;'
     + '&#40;' + fr('v', '3') + '&#41;&sup2; &minus; ' + fr('gR&sup2;', '6R') + '<br>'
     'v&sup2; &minus; ' + fr('1', '9') + 'v&sup2; = gR &minus; ' + fr('1', '3') + 'gR'
     + '　→　' + fr('8', '9') + 'v&sup2; = ' + fr('2', '3') + 'gR'
     + '　→　v&sup2; = ' + fr('3', '4') + 'gR<br>'
     '<span class="st">(c) ケプラーの第3法則。</span>'
     '半長軸は a = (2R + 6R)/2 = <b>4R</b>。(2) の円は半径 2R（＝半長軸 2R）だから<br>'
     'T&sup2; = k(2R)&sup3;、T&prime;&sup2; = k(4R)&sup3;　→　'
     + fr('T&prime;&sup2;', 'T&sup2;') + ' = 2&sup3;　→　T&prime; = 2&radic;2&#8201;T<br>'
     'T = 4&pi;' + sq(fr('2R', 'g')) + ' を入れて　T&prime; = 16&pi;' + sq(fr('R', 'g')) + '。',
     memo='<b>ここが一番の山です。</b>面積速度一定（&#9312;）を先に出して V を v で表し、'
          'それをエネルギー保存に代入する——この順番が決まり手。'
          '逆にすると未知数が2つ残って解けません。'),
   item(
     '(4)　地球に衝突もせず、無限遠へ飛び去りもせず、だ円をえがき続けるための v の範囲は。',
     sq(fr('gR', '3')) + ' &lt; v &lt; ' + sq('gR')
     + '　<span class="num">（4.57 km/s &lt; v &lt; 7.91 km/s）</span>',
     '<span class="st">上の限界：飛び去らない条件。</span>'
     'E &ge; 0 なら無限遠まで行けてしまうので、E &lt; 0 でなければならない。<br>'
     '&frac12;mv&sup2; &minus; G' + fr('Mm', '2R') + ' &lt; 0　→　v&sup2; &lt; '
     + fr('GM', 'R') + ' = gR　→　v &lt; ' + sq('gR') + '<br>'
     '<span class="st">下の限界：地球にぶつからない条件。</span>'
     'ぎりぎりは、右図のように<b>近地点 C が地表（O から R）に来るとき</b>。'
     'A での速さを v、C での速さを V として<br>'
     '面積速度一定：2R&#8201;v = R&#8201;V　→　<b>V = 2v</b><br>'
     'エネルギー保存：&frac12;v&sup2; &minus; ' + fr('gR&sup2;', '2R')
     + ' = &frac12;(2v)&sup2; &minus; ' + fr('gR&sup2;', 'R') + '<br>'
     '&minus;' + fr('3', '2') + 'v&sup2; = &minus;' + fr('gR', '2')
     + '　→　v&sup2; = ' + fr('gR', '3') + '。',
     memo='この 2 つの限界を、加えるエネルギー E&prime; = &frac12;mv&sup2; で書き直すと '
          '<b>mgR/6 &lt; E&prime; &lt; mgR/2</b>。'
          'シミュレーションのスライドバーは、この E&prime; そのものです。'
          '1/6 で地表をかすめ、1/4 で円、3/8 で B が 6R、1/2 で脱出——'
          '4 つの目もりが全部この問題の答えになっています。',
     fig=FIG31A, figcap='ぎりぎり衝突するとき'),
  ])


# ===================== 3-2 =====================
TOOLS32 = (
  '<table class="tools">'
  '<tr><th>球の外がわ（|x| &ge; R）</th><td>ふつうの万有引力。'
  '全部の質量 M が中心にあると考えてよい</td></tr>'
  '<tr><th>球の内がわ（|x| &lt; R）</th><td>'
  '<b>自分より外がわの殻からの引力は、ぴったり打ち消し合って 0</b>。'
  'だから「半径 |x| より内がわの質量 M&prime;」だけが効く</td></tr>'
  '<tr><th>密度が一様</th><td>M = ' + fr('4', '3') + '&pi;&rho;R&sup3;、'
  'M&prime; = ' + fr('4', '3') + '&pi;&rho;|x|&sup3;'
  '　<span class="num">（&rho; は密度）</span></td></tr>'
  '<tr><th>単振動</th><td>f = &minus;kx の形になれば単振動。'
  '&omega; = ' + sq(fr('k', 'm')) + '、T = ' + fr('2&pi;', '&omega;') + '、'
  '中心を基準にした位置エネルギーは &frac12;kx&sup2;</td></tr>'
  '<tr><th>地表での関係</th><td>g = ' + fr('GM', 'R&sup2;') + ' = '
  + fr('4', '3') + '&pi;&rho;GR'
  '　<span class="num">これで &rho; と g を行き来できる</span></td></tr>'
  '</table>')

A32 = page(
  '3-2　地球トンネル　—　解答と解き方',
  '出典：名古屋大 2005（一部を書きかえています）',
  TOOLS32,
  [
   item(
     '(1)　x &ge; R にある小球 A にはたらく力 F と、位置エネルギー U（無限遠を基準）を求めよ。',
     'F = &minus;G' + fr('Mm', 'x&sup2;') + ' = &minus;'
     + fr('4&pi;&rho;GmR&sup3;', '3x&sup2;')
     + '　　U = &minus;G' + fr('Mm', 'x') + ' = &minus;' + fr('4&pi;&rho;GmR&sup3;', '3x'),
     '球の外なので、<span class="st">惑星の質量が全部中心にあると考えてよい。</span><br>'
     '<b>x の正の向きを力の正の向き</b>にとっているので、x &gt; 0 では引力は '
     '&minus;x の向き＝<b>マイナス</b>。<br>'
     'M = ' + fr('4', '3') + '&pi;&rho;R&sup3; を入れれば、&rho; を使った形になる。',
     memo='<b>U に負号がつく理由</b>：無限遠を基準（U = 0）にとると、'
          '近づくほど位置エネルギーは低くなるので、どこでも U &lt; 0 になります。'),
   item(
     '(2)　惑星の表面（x = R）から +x の向きに発射する。x = 3R に到達させるための、'
     '初速度 v₀ の最小値を求めよ。',
     'v<sub>0</sub> = ' + sq(fr('4gR', '3')) + ' = ' + fr('4', '3') + 'R'
     + sq('&pi;&rho;G') + '　<span class="num">＝ 9.13 km/s</span>',
     '<span class="st">「行き先の x = 3R で、ちょうど速さ 0 になる」のが最小。</span><br>'
     '&frac12;mv<sub>0</sub>&sup2; &minus; G' + fr('Mm', 'R') + ' = 0 &minus; G'
     + fr('Mm', '3R') + '<br>'
     'v<sub>0</sub>&sup2; = ' + fr('2GM', 'R') + ' &minus; ' + fr('2GM', '3R')
     + ' = ' + fr('4GM', '3R') + ' = ' + fr('4', '3') + 'gR。',
     memo='「最小」と言われたら、<b>行き先で運動エネルギーが 0</b> と置くのが定石です。'),
   item(
     '(3)　小球 A が穴の中（&minus;R &lt; x &lt; R）にあるとき、A が受ける力 f を求めよ。',
     'f = &minus;' + fr('4', '3') + '&pi;&rho;Gmx'
     + '　<span class="num">（＝ &minus;' + fr('GMm', 'R&sup3;') + 'x）</span>',
     '<span class="st">半径 |x| より内がわの質量 M&prime; だけが効く。</span><br>'
     'M&prime; = ' + fr('4', '3') + '&pi;&rho;|x|&sup3; なので、大きさは<br>'
     '|f| = G' + fr('mM&prime;', '|x|&sup2;') + ' = G' + fr('m', '|x|&sup2;')
     + '&middot;' + fr('4', '3') + '&pi;&rho;|x|&sup3; = ' + fr('4', '3')
     + '&pi;&rho;Gm|x|<br>'
     '向きはいつも中心を向くので、x &gt; 0 なら負、x &lt; 0 なら正。'
     'まとめて <b>f = &minus;(4/3)&pi;&rho;Gm&#8201;x</b> と書ける。',
     memo='<b>|x| ではなく x で書けるのがミソ</b>です。'
          '絶対値をはずしたとき、左右どちらでも同じ 1 本の式になる——'
          'それが「変位に比例して逆向き」＝ばねと同じ形、という意味。'),
   item(
     '(4)　f と x の関係のグラフの概形をかけ（x = R での値も書きこむこと）。',
     '内は原点を通る直線、外は 1/x&sup2; の曲線。'
     'つなぎ目 x = &plusmn;R で |f| が最大の <b>mg</b>'
     '　<span class="num">（= (4/3)&pi;&rho;GmR）</span>',
     '<span class="st">(3) より内は f &prop; x の直線。(1) より外は f &prop; 1/x&sup2;。</span><br>'
     '2 つは x = &plusmn;R でなめらかにではなく<b>折れて</b>つながり、'
     'そこがちょうど山（谷）のてっぺんになる。<br>'
     '|f| の最大値は '
     + fr('4', '3') + '&pi;&rho;GmR = ' + fr('GMm', 'R&sup2;') + ' = mg。',
     memo='<b>地表がいちばん重力が強い</b>——'
          '中に入ると外がわの殻が効かなくなるので弱まり、'
          '外に出ると距離が離れるので弱まる。だから表面が山のてっぺんです。',
     fig=FIG32A, figcap='f &minus; x のグラフ'),
   item(
     '(5)　惑星の表面から初速度 0 で放すと単振動する。その理由と周期を求めよ。',
     '理由：(3) より f = &minus;kx（k = ' + fr('GMm', 'R&sup3;') + '）＝'
     '<b>変位に比例して逆向きの復元力</b>だから。<br>'
     'T = ' + fr('2&pi;', '&omega;') + ' = 2&pi;' + sq(fr('R', 'g'))
     + ' = ' + sq(fr('3&pi;', '&rho;G')) + '　<span class="num">＝ 84.4 分</span>',
     '運動方程式は ma = &minus;' + fr('4', '3') + '&pi;&rho;Gmx　→　'
     'a = &minus;' + fr('4', '3') + '&pi;&rho;G&#8201;x<br>'
     '単振動なら a = &minus;&omega;&sup2;x なので、2 式をくらべて<br>'
     '&omega;&sup2; = ' + fr('4', '3') + '&pi;&rho;G = ' + fr('GM', 'R&sup3;')
     + ' = ' + fr('g', 'R') + '　→　&omega; = ' + sq(fr('4&pi;&rho;G', '3')) + '。',
     memo='<b>この 84.4 分は、地表すれすれの円軌道の周期とまったく同じ</b>です。'
          '&omega; = ' + sq('g/R') + ' が両方に出てくるからで、'
          '「穴を落ちる運動」は「円運動を真横から見たもの」と同じ、と言いかえられます。'),
   item(
     '(6)　(5) のとき、表面から中心に最初に到達するまでの時間 t₁ と、中心での速さ v₁ を求めよ。',
     't<sub>1</sub> = ' + fr('T', '4') + ' = ' + fr('&pi;', '2') + sq(fr('R', 'g'))
     + '　<span class="num">＝ 21.1 分</span>'
     + '　　v<sub>1</sub> = R&omega; = ' + sq('gR')
     + '　<span class="num">＝ 7.91 km/s</span>',
     '<span class="st">中心 O は単振動の中心、惑星の表面は最大変位（振幅 R）。</span><br>'
     '端から中心までは<b>周期の 1/4</b> なので t<sub>1</sub> = T/4。<br>'
     '単振動の最大の速さは v = A&omega; で、A = R だから<br>'
     'v<sub>1</sub> = R' + sq(fr('4&pi;&rho;G', '3')) + ' = 2R' + sq(fr('&pi;&rho;G', '3'))
     + ' = R' + sq(fr('g', 'R')) + ' = ' + sq('gR') + '。',
     memo='<b>これも 7.91 km/s ＝ 第一宇宙速度</b>。'
          '3-1 の (1) にも同じ値が出てきました。'),
   item(
     '(7)　小球 A が中心 O を通過するときの速さ v₂ が、いくら以上なら x = 3R まで到達できるか。',
     'v<sub>2</sub> = ' + sq(fr('7gR', '3')) + ' = ' + fr('2R', '3') + sq('7&pi;&rho;G')
     + '　<span class="num">＝ 12.08 km/s</span>',
     '<span class="st">x = R に出てきたときの速さが、(2) の v₀ になっていればよい。</span><br>'
     '穴の中では復元力が &minus;kx（k = ' + fr('GMm', 'R&sup3;') + '）なので、'
     '中心 O を基準にした位置エネルギーは &frac12;kx&sup2;。'
     '「&frac12;mv&sup2; + &frac12;kx&sup2; = 一定」を、中心（x = 0）と表面（x = R）でくらべて<br>'
     '&frac12;mv<sub>2</sub>&sup2; + 0 = &frac12;mv<sub>0</sub>&sup2; + &frac12;kR&sup2;<br>'
     'v<sub>2</sub>&sup2; = v<sub>0</sub>&sup2; + ' + fr('k', 'm') + 'R&sup2;'
     + ' = ' + fr('4', '3') + 'gR + gR = ' + fr('7', '3') + 'gR<br>'
     '<span class="num">（' + fr('k', 'm') + 'R&sup2; = ' + fr('GM', 'R&sup3;')
     + '&middot;R&sup2; = ' + fr('GM', 'R') + ' = gR）</span>',
     memo='(6) の中心での速さ 7.91 km/s よりずっと速い（12.08 km/s）のは、'
          '<b>穴を出るところまでで、ばねの位置エネルギーぶんを使ってしまう</b>から。'
          '穴の中と外で「位置エネルギーの基準」がちがうので、'
          '<b>中で &frac12;kx&sup2;、外で &minus;GMm/x</b> と'
          '使い分けるのがこの問題の一番むずかしいところです。'),
  ])


# ===================== 3-3 =====================
TOOLS33 = (
  '<table class="tools">'
  '<tr><th>円運動の式</th><td>mr&omega;&sup2; = G' + fr('Mm', 'r&sup2;')
  + '　または ' + fr('mv&sup2;', 'r') + ' = G' + fr('Mm', 'r&sup2;') + '</td></tr>'
  '<tr><th>円軌道のエネルギー</th><td>K = ' + fr('GMm', '2r') + '、U = &minus;'
  + fr('GMm', 'r') + '、E = K + U = &minus;' + fr('GMm', '2r')
  + '　<span class="num">（K は &minus;U の半分）</span></td></tr>'
  '<tr><th>共通重心</th><td>Mr<sub>1</sub> = mr<sub>2</sub>、r<sub>1</sub> + r<sub>2</sub> = r<sub>0</sub>'
  '　<span class="num">2 つは共通重心を通る直線に並んだまま、同じ &omega; で回る</span></td></tr>'
  '</table>'
  '<div style="margin-top:6px;font-size:12.5px;line-height:1.8;color:#4a5560">'
  '<b>※ 記号の向きに注意</b>：このページでは、'
  '<b>r<sub>1</sub> ＝ 共通重心から<u>地球</u>まで、r<sub>2</sub> ＝ 共通重心から<u>月</u>まで</b> '
  'と決めています（シミュレーションの図と同じ）。'
  '本によっては逆にとることもあるので、答えの形をくらべるときは気をつけてください。'
  '</div>')

A33 = page(
  '3-3　地球と月　—　解答と解き方',
  '出典：関西学院大（一部を書きかえています）',
  TOOLS33,
  [
   item(
     '【A】(1)　月が受ける万有引力の大きさを G, M, m, r₀ で表せ。',
     'F = G' + fr('Mm', 'r<sub>0</sub>&sup2;'),
     '万有引力の法則そのもの。<br>'
     '<span class="st">作用・反作用</span>なので、<b>地球も同じ大きさの力</b>を月から受けている。',
     memo='あとの【B】で「地球も動く」に進むとき、この'
          '<b>「2 つの力はいつも同じ大きさ」</b>が効いてきます。'),
   item(
     '【A】(2)(3)　月の運動の周期 T と速さ v を、G, M, r₀ で表せ。',
     '&omega; = ' + sq(fr('GM', 'r<sub>0</sub>&sup3;'))
     + '　　T = 2&pi;' + sq(fr('r<sub>0</sub>&sup3;', 'GM'))
     + '　<span class="num">＝ 27.45 日</span>'
     + '　　v = ' + sq(fr('GM', 'r<sub>0</sub>'))
     + '　<span class="num">＝ 1.02 km/s</span>',
     '<span class="st">半径方向の運動方程式（向心力 ＝ 万有引力）。</span><br>'
     'mr<sub>0</sub>&omega;&sup2; = G' + fr('Mm', 'r<sub>0</sub>&sup2;')
     + '　→　&omega;&sup2; = ' + fr('GM', 'r<sub>0</sub>&sup3;') + '<br>'
     'T = ' + fr('2&pi;', '&omega;') + '、v = r<sub>0</sub>&omega; から、上の答えが出る。',
     memo='<b>T&sup2; = ' + fr('4&pi;&sup2;', 'GM') + 'r<sub>0</sub>&sup3;</b>'
          '——ケプラーの第3法則が、ここから 3 行で出てきます。'
          '<b>月の質量 m が消えている</b>ことにも注目。'),
   item(
     '【A】(4)(5)(6)　月の力学的エネルギー E を求めよ。また、'
     '(5) E が減少すると r₀ はどうなるか。(6) r₀ が減少すると v はどうなるか。',
     '(4) E = &minus;' + fr('GMm', '2r<sub>0</sub>')
     + '　　(5) r<sub>0</sub> は<b>減少</b>する　　(6) v は<b>増加</b>する',
     '<span class="st">(4)</span> 円運動の式から K = &frac12;mv&sup2; = '
     + fr('GMm', '2r<sub>0</sub>') + '　……&#9312;<br>'
     'U = &minus;' + fr('GMm', 'r<sub>0</sub>') + ' なので<br>'
     'E = K + U = ' + fr('GMm', '2r<sub>0</sub>') + ' &minus; '
     + fr('GMm', 'r<sub>0</sub>') + ' = &minus;' + fr('GMm', '2r<sub>0</sub>')
     + '　……&#9313;<br>'
     '<span class="st">(5)</span> &#9313;で E は<b>負</b>。E が減る＝'
     + fr('GMm', '2r<sub>0</sub>') + ' の絶対値が大きくなる、ということ。'
     'だから r<sub>0</sub> は小さくなる。<br>'
     '<span class="st">(6)</span> &#9312;で r<sub>0</sub> が小さくなれば K は大きくなる。'
     'よって v は大きくなる。',
     memo='<b>エネルギーを失ったのに速くなる。</b>'
          '空気の抵抗で少しずつエネルギーを失う人工衛星が、'
          'かえって速くなりながら落ちてくるのはこのためです。<br>'
          '<b>※ここは「円軌道どうしをくらべた話」</b>です。'
          'いまの月に横向きの加速をあたえた場合は円ではなくなり、'
          'だ円が<b>大きく</b>なります（1-4・2-1 で確かめられます）。'
          '「速くする」と「エネルギーを失って落ちる」は別の話なので、混ぜないこと。'),
   item(
     '【B】(1)(2)　地球も月も共通重心のまわりを同じ角速度 &omega; で円運動している。'
     '月についての円運動の式を書き、&omega; を求めよ。',
     'm&#8201;r<sub>2</sub>&#8201;&omega;&sup2; = G' + fr('Mm', 'r<sub>0</sub>&sup2;')
     + '　→　&omega; = ' + sq(fr('GM', 'r<sub>2</sub>r<sub>0</sub>&sup2;')),
     '<span class="st">月が回る円の中心は共通重心、半径は r<sub>2</sub>。</span>'
     '（<b>2 つの距離 r<sub>0</sub> ではない</b>ことに注意。）<br>'
     'いっぽう、月にはたらく万有引力は<b>地球との距離 r<sub>0</sub></b> で決まる。<br>'
     'この <b>「半径は r<sub>2</sub>、力は r<sub>0</sub>」</b>の使い分けが、この問題の要。',
     memo='ここを r<sub>0</sub> どうしで書いてしまうのが、いちばん多いまちがいです。'
          '<b>向心力の式の左辺は「回っている円の半径」、'
          '右辺は「引き合っている 2 つの距離」</b>——別のものだと意識して書くこと。'),
   item(
     '【B】(3)(4)　地球についても同じ角速度になることを確かめ、'
     '円運動の周期 T を G, M, m, r₀ で表せ。',
     'r<sub>1</sub> = ' + fr('m', 'M + m') + 'r<sub>0</sub>、r<sub>2</sub> = '
     + fr('M', 'M + m') + 'r<sub>0</sub>　　'
     '&omega; = ' + sq(fr('G(M + m)', 'r<sub>0</sub>&sup3;'))
     + '　　T = 2&pi;' + sq(fr('r<sub>0</sub>&sup3;', 'G(M + m)')),
     '<span class="st">地球についての運動方程式（半径は r<sub>1</sub>）。</span><br>'
     'M&#8201;r<sub>1</sub>&#8201;&omega;&sup2; = G' + fr('Mm', 'r<sub>0</sub>&sup2;')
     + '<br>月の式（右辺が同じ）とくらべて　<b>M r<sub>1</sub> = m r<sub>2</sub></b><br>'
     'これは<b>重心の式そのもの</b>——つまり<b>円運動の中心は共通重心と一致する</b>。<br>'
     'r<sub>1</sub> + r<sub>2</sub> = r<sub>0</sub> と連立して r<sub>1</sub>、r<sub>2</sub> が出る。'
     'r<sub>2</sub> を【B】(2) に代入すると<br>'
     '&omega;&sup2; = ' + fr('GM', 'r<sub>0</sub>&sup2;') + '&middot;'
     + fr('M + m', 'M&#8201;r<sub>0</sub>') + ' = ' + fr('G(M + m)', 'r<sub>0</sub>&sup3;') + '。',
     memo='<b>【A】の M が、【B】では M + m に変わっただけ</b>です。'
          'だから m &#8810; M のときは【A】の答えに一致します。<br>'
          '本当の地球と月では m/M = 1/81 なので、周期のちがいは<b>わずか 0.6 %</b>。'
          '——高校の問題が「地球は動かない」で済ませてよい理由が、これで分かります。'),
  ])


SHEETS = [('ans_m31', A31), ('ans_m32', A32), ('ans_m33', A33)]


def main():
    os.makedirs(OUT, exist_ok=True)
    tmp = '/tmp/anssheet'
    os.makedirs(tmp, exist_ok=True)
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={'width': 820, 'height': 900}, device_scale_factor=2)
        for key, html in SHEETS:
            f = os.path.join(tmp, key + '.html')
            open(f, 'w', encoding='utf-8').write(html)
            pg.goto('file://' + f)
            pg.wait_for_timeout(350)
            pg.screenshot(path=os.path.join(tmp, key + '_raw.png'), full_page=True)
            print('shot', key)
        b.close()
    # 大きさをおさえる（HTML に base64 で入るので、1枚 250 KB 以下をめやすに）
    from PIL import Image
    for key, _ in SHEETS:
        im = Image.open(os.path.join(tmp, key + '_raw.png')).convert('RGB')
        w = 1100                                  # 元の 820px の 1.34 倍
        im = im.resize((w, int(im.size[1] * w / im.size[0])), Image.LANCZOS)
        im = im.quantize(colors=64, method=Image.MEDIANCUT).convert('P')
        out = os.path.join(OUT, key + '.png')
        im.save(out, optimize=True)
        print(out, '%d KB' % (os.path.getsize(out) // 1024), im.size)


if __name__ == '__main__':
    main()
