# -*- coding: utf-8 -*-
"""
入試問題の「問題文シート」を画像（PNG）で作る。

★ねらい★
  シミュレーションを触る前に、生徒がまず自分で問題を解けるようにする。
★著作権への配慮★
  ・問題文は原文そのままではなく、こちらで書きかえた文にする。
  ・図は原図をそのまま写すのではなく、同じ設定を表す図をこちらで描き起こす。
  ・出典（大学名）は必ず書き、「一部を書きかえています」と明記する。
つくり方：HTML を組み立てて Playwright で撮る → assets/ に置く
        → build.js が base64 で HTML に埋め込む（オフラインでも開ける）。
"""
import os, subprocess, sys
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'assets')

CSS = """
<style>
 *{box-sizing:border-box}
 body{margin:0;background:#fff;font-family:"Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif;
   color:#1b1f24;width:820px;padding:0 0 18px}
 .head{background:#1f4e79;color:#fff;padding:12px 20px}
 .head h1{margin:0;font-size:18px;letter-spacing:.02em}
 .head .src{margin-top:3px;font-size:12px;color:#cfe0f0}
 .wrap{padding:14px 20px 0}
 .sec{font-weight:700;color:#1f4e79;font-size:14px;margin:14px 0 5px;
   border-left:5px solid #e8951a;padding-left:7px}
 .setup{background:#f3f6fa;border:1px solid #d6dfe8;border-radius:6px;padding:10px 13px;
   font-size:13.5px;line-height:1.85}
 ol.q{margin:4px 0 0;padding-left:1.5em;font-size:13.5px;line-height:1.9}
 ol.q>li{margin:7px 0}
 .sub{margin:2px 0 0 0;padding-left:1.2em;list-style:lower-alpha;font-size:13px}
 .fig{border:1px solid #d6dfe8;border-radius:6px;background:#fff;padding:6px 4px;text-align:center}
 .cap{font-size:11.5px;color:#5b6672;margin-top:2px}
 .foot{margin:14px 20px 0;font-size:11px;color:#5b6672;line-height:1.7;
   border-top:1px solid #d6dfe8;padding-top:8px}
 b{color:#12325c}
 .u{border-bottom:2px solid #e8951a;padding-bottom:1px}
 svg text{font-family:"Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif}
</style>
"""

FOOT = ('※ 著作権に配慮し、問題文は原文のままではなく、'
        'このページのために言いまわしを書きかえたものです。'
        '図も原図の複製ではなく、同じ設定を表すものを新しく描き起こしています。<br>'
        '※ 数値を入れて確かめたいときは、シミュレーションの「計算結果を表示」を見てください。')


def page(title, src, setup, figsvg, figcap, questions):
    qs = ''.join('<li>%s</li>' % q for q in questions)
    return f"""<!doctype html><html lang="ja"><meta charset="utf-8">{CSS}
<div class="head"><h1>{title}</h1><div class="src">{src}</div></div>
<div class="wrap">
  <div class="sec">問題の設定</div>
  <div class="setup">{setup}</div>
  <div class="sec">図</div>
  <div class="fig">{figsvg}<div class="cap">{figcap}</div></div>
  <div class="sec">問</div>
  <ol class="q">{qs}</ol>
</div>
<div class="foot">{FOOT}</div>
</html>"""


# ===================== 3-1 =====================
FIG31 = """
<svg width="760" height="300" viewBox="0 0 760 300">
  <!-- 長軸 -->
  <line x1="90" y1="150" x2="700" y2="150" stroke="#9aa5b1" stroke-width="1"
        stroke-dasharray="6 5"/>
  <!-- だ円（焦点 O、A=2R、B=6R、a=4R、c=2R） -->
  <ellipse cx="360" cy="150" rx="120" ry="104" fill="none" stroke="#1c8f4a" stroke-width="2"/>
  <!-- 地球 -->
  <circle cx="300" cy="150" r="30" fill="#cfe0f0" stroke="#2a5f96" stroke-width="1.6"/>
  <circle cx="300" cy="150" r="2.6" fill="#1b1f24"/>
  <text x="288" y="168" font-size="13" font-weight="bold">O</text>
  <text x="300" y="198" font-size="12.5" text-anchor="middle" fill="#2a5f96"
        font-weight="bold">地球</text>
  <!-- 半径 R -->
  <line x1="300" y1="150" x2="300" y2="120" stroke="#1b1f24" stroke-width="1" stroke-dasharray="3 3"/>
  <text x="306" y="136" font-size="12">R</text>
  <!-- 点 A -->
  <circle cx="240" cy="150" r="5" fill="#fff" stroke="#1b1f24" stroke-width="1.8"/>
  <text x="240" y="134" font-size="13" text-anchor="middle" font-weight="bold">A（2R）</text>
  <!-- 点 B -->
  <circle cx="480" cy="150" r="5" fill="#fff" stroke="#1c8f4a" stroke-width="1.8"/>
  <text x="480" y="134" font-size="13" text-anchor="middle" font-weight="bold" fill="#1c8f4a">B（6R）</text>
  <!-- 打ち上げ v0（地表から A へ・OA にそって） -->
  <line x1="270" y1="150" x2="248" y2="150" stroke="#1663b5" stroke-width="2.4"
        marker-end="url(#a1)"/>
  <text x="230" y="180" font-size="12.5" text-anchor="end" fill="#1663b5"
        font-weight="bold">v₀（鉛直に打ち上げ）</text>
  <line x1="234" y1="176" x2="258" y2="156" stroke="#1663b5" stroke-width=".8"/>
  <!-- A で与える速さ v（OA に垂直） -->
  <line x1="240" y1="150" x2="240" y2="96" stroke="#1663b5" stroke-width="2.4"
        marker-end="url(#a1)"/>
  <text x="212" y="90" font-size="13" fill="#1663b5" font-weight="bold">v</text>
  <!-- 寸法 2R -->
  <line x1="240" y1="230" x2="300" y2="230" stroke="#1b1f24" stroke-width="1"/>
  <line x1="240" y1="225" x2="240" y2="235" stroke="#1b1f24" stroke-width="1"/>
  <line x1="300" y1="225" x2="300" y2="235" stroke="#1b1f24" stroke-width="1"/>
  <text x="270" y="247" font-size="12" text-anchor="middle">2R</text>
  <!-- 寸法 6R -->
  <line x1="300" y1="262" x2="480" y2="262" stroke="#1b1f24" stroke-width="1"/>
  <line x1="300" y1="257" x2="300" y2="267" stroke="#1b1f24" stroke-width="1"/>
  <line x1="480" y1="257" x2="480" y2="267" stroke="#1b1f24" stroke-width="1"/>
  <text x="390" y="279" font-size="12" text-anchor="middle">6R</text>
  <text x="548" y="212" font-size="12.5" fill="#1c8f4a">AB を長軸とするだ円</text>
  <defs>
    <marker id="a1" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto">
      <path d="M0,0 L9,4.5 L0,9 z" fill="#1663b5"/>
    </marker>
  </defs>
</svg>"""

P31 = page(
  '3-1　等速円運動から楕円軌道への遷移',
  '出典：大阪市立大（一部を書きかえています）',
  ('地球を<b>半径 R・質量 M の一様な球</b>とし、地球の自転と公転は考えない。'
   '万有引力定数を G、地表での重力加速度の大きさを g とする'
   '（したがって <b>GM = gR²</b>）。<br>'
   '<b>質量 m の小物体</b>を地表の1点から<b>鉛直上向き</b>に打ち上げたところ、'
   '地球の中心 O から <b>2R</b> の点 A でちょうど速さが 0 になった。<br>'
   'その<b>瞬間に</b>、OA に<b>垂直な向き</b>へ速さ <b>v</b> をあたえる。'
   'このとき加えた運動エネルギーを <b>E′ = ½mv²</b> とする。'),
  FIG31,
  '図　地球（半径 R・質量 M）・点 A（2R）・点 B（6R）と、AB を長軸とするだ円',
  [
   '点 A で速さが 0 になるためには、打ち上げの速さ v₀ をいくらにすればよいか。g と R で表せ。',
   '点 A で OA に垂直に速さ v をあたえたとき、O を中心とする<b>等速円運動</b>になった。'
   'このときの v と、その周期を求めよ。',
   'こんどは、A と B（O から 6R）を両端とする<b>長軸をもつだ円</b>をえがいた。'
   '<ol class="sub"><li>点 B での速さ V を、v を用いて表せ。</li>'
   '<li>v を g と R で表せ。</li><li>この運動の周期を g と R で表せ。</li></ol>',
   '地球に衝突することもなく、無限遠へ飛び去ることもなく、'
   'だ円をえがき続けるための v の範囲を求めよ。',
  ])

# ===================== 3-2 =====================
FIG32 = """
<svg width="760" height="300" viewBox="0 0 760 300">
  <!-- x 軸 -->
  <line x1="60" y1="170" x2="710" y2="170" stroke="#8b949e" stroke-width="1.4"/>
  <path d="M710,170 L700,165 L700,175 z" fill="#8b949e"/>
  <text x="716" y="166" font-size="13" font-weight="bold" fill="#8b949e">x</text>
  <!-- 惑星の断面 -->
  <circle cx="380" cy="170" r="80" fill="#cfe0f0" stroke="#2a5f96" stroke-width="1.8"/>
  <!-- トンネル -->
  <rect x="300" y="163" width="160" height="14" fill="#fff" stroke="#9fb0c0" stroke-width="1"/>
  <text x="380" y="78" font-size="12.5" text-anchor="middle" fill="#2a5f96"
        font-weight="bold">半径 R・質量 M の一様な球</text>
  <text x="504" y="112" font-size="12" fill="#5b6672">トンネル（体積は無視できる）</text>
  <line x1="500" y1="108" x2="448" y2="160" stroke="#9fb0c0" stroke-width=".8"/>
  <!-- 目もり -->
  <g font-size="12" text-anchor="middle">
    <line x1="140" y1="164" x2="140" y2="176" stroke="#8b949e"/><text x="140" y="192">−3R</text>
    <line x1="300" y1="164" x2="300" y2="176" stroke="#8b949e"/><text x="300" y="192">−R</text>
    <line x1="380" y1="164" x2="380" y2="176" stroke="#1b1f24"/><text x="380" y="150" font-weight="bold">O</text>
    <line x1="460" y1="164" x2="460" y2="176" stroke="#8b949e"/><text x="464" y="192">R</text>
    <line x1="620" y1="164" x2="620" y2="176" stroke="#8b949e"/><text x="620" y="192">3R</text>
  </g>
  <!-- 小球 A（(2) にそろえて、惑星の表面 x = R に置く） -->
  <circle cx="460" cy="170" r="7" fill="#b5543a" stroke="#7c3a26" stroke-width="1.2"/>
  <text x="478" y="150" font-size="12.5" font-weight="bold">小球 A（質量 m）</text>
  <line x1="474" y1="170" x2="514" y2="170" stroke="#1663b5" stroke-width="2.4" marker-end="url(#a2)"/>
  <text x="512" y="218" font-size="12.5" fill="#1663b5" font-weight="bold" text-anchor="middle">初速度 v₀（+x の向き）</text>
  <line x1="500" y1="206" x2="492" y2="180" stroke="#1663b5" stroke-width=".8"/>
  <defs>
    <marker id="a2" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto">
      <path d="M0,0 L9,4.5 L0,9 z" fill="#1663b5"/>
    </marker>
  </defs>
</svg>"""

P32 = page(
  '3-2　地球トンネル',
  '出典：名古屋大 2005（一部を書きかえています）',
  ('<b>半径 R・質量 M の、密度が一様な球</b>の惑星を考える'
   '（数値を分かりやすくするため「地球」としてよい）。<br>'
   'この惑星の<b>中心 O を通るまっすぐな細い穴（トンネル）</b>を掘り、'
   '穴にそって <b>x 軸</b>をとる。中心を原点 O とする。'
   '穴の体積は惑星にくらべてごくわずかで、惑星の質量は減らないものとする。'
   '惑星は<b>自転しておらず</b>、空気もないものとする。<br>'
   'この穴の中や外に<b>質量 m の小球 A</b> を置いて、静かに放したり、'
   '+x の向きに速さ v₀ で発射したりする。'
   '万有引力定数を G、地表での重力加速度の大きさを g とする。<br>'
   '<b>ヒント</b>：球の内部では、<b>自分より外がわの殻からの引力はぴったり打ち消し合って 0</b> になる。'
   'だから深さ |x| にいる小球には「半径 |x| より内がわの部分の質量」だけが効き、'
   'しかもそれが中心に集まっていると考えてよい。'),
  FIG32,
  '図　惑星の断面と、中心を通るトンネル（x 軸）。小球 A は (2) の「表面から発射」の場面',
  [
   'x 軸上の位置 x ≧ R にある小球 A にはたらく力 F と、'
   'その位置エネルギー U（無限遠を基準）を求めよ。',
   '小球 A を<b>惑星の表面（x = R）から +x の向きに発射</b>する。'
   'x = 3R の位置に到達させるために必要な、初速度 v₀ の最小値を求めよ。',
   '小球 A が穴の中の位置 −R &lt; x &lt; R にあるとき、A が受ける力 f を求めよ。',
   'f と x の関係のグラフの概形をかけ（x = R での値も書きこむこと）。',
   '惑星の表面から初速度 0 で放すと、小球は<b>単振動</b>する。'
   'その理由を述べ、周期を求めよ。',
   '(5) のとき、表面から中心に最初に到達するまでの時間 t₁ と、中心での速さ v₁ を求めよ。',
   '小球 A が<b>中心 O を通過するときの速さ v₂</b> が、いくら以上あれば '
   'x = 3R の位置まで到達できるか。<br>'
   '<span style="font-size:12.5px;color:#5b6672">'
   '（ヒント：x = R に達したときの速さが (2) の v₀ となればよい。'
   'また、−R ≦ x ≦ R での復元力を −kx（k は比例定数）とすると、'
   'この範囲での位置エネルギーは中心 O を基準として ½kx² の形で表せる。）</span>',
  ])

# ===================== 3-3 =====================
FIG33 = """
<svg width="760" height="320" viewBox="0 0 760 320">
  <!-- 左：【A】地球は動かない -->
  <text x="190" y="24" font-size="13.5" text-anchor="middle" font-weight="bold"
        fill="#1663b5">【A】地球は動かないとみなす</text>
  <circle cx="190" cy="175" r="98" fill="none" stroke="#9aa5b1" stroke-width="1.2"
          stroke-dasharray="6 5"/>
  <circle cx="190" cy="175" r="20" fill="#cfe0f0" stroke="#2a5f96" stroke-width="1.6"/>
  <text x="190" y="180" font-size="12" text-anchor="middle" font-weight="bold" fill="#2a5f96">M</text>
  <text x="190" y="214" font-size="12" text-anchor="middle" fill="#2a5f96">地球</text>
  <circle cx="288" cy="175" r="10" fill="#c8bda9" stroke="#8a7f6c" stroke-width="1.2"/>
  <text x="288" y="180" font-size="11" text-anchor="middle" font-weight="bold">m</text>
  <text x="300" y="204" font-size="12">月</text>
  <line x1="210" y1="175" x2="278" y2="175" stroke="#1b1f24" stroke-width="1" stroke-dasharray="4 3"/>
  <text x="244" y="167" font-size="12" text-anchor="middle">r₀</text>
  <line x1="288" y1="165" x2="288" y2="120" stroke="#1663b5" stroke-width="2.2" marker-end="url(#a3)"/>
  <text x="298" y="124" font-size="12.5" fill="#1663b5" font-weight="bold">v</text>
  <!-- 区切り -->
  <line x1="380" y1="10" x2="380" y2="310" stroke="#d6dfe8" stroke-width="1"/>
  <!-- 右：【B】共通重心のまわり -->
  <text x="570" y="24" font-size="13.5" text-anchor="middle" font-weight="bold"
        fill="#3f4a54">【B】地球も月も共通重心のまわりを回る</text>
  <circle cx="556" cy="175" r="26" fill="none" stroke="#2a5f96" stroke-width="1.1"
          stroke-dasharray="4 3"/>
  <circle cx="556" cy="175" r="98" fill="none" stroke="#9aa5b1" stroke-width="1.2"
          stroke-dasharray="6 5"/>
  <!-- 共通重心 -->
  <g stroke="#3f4a54" stroke-width="2">
    <line x1="549" y1="168" x2="563" y2="182"/><line x1="563" y1="168" x2="549" y2="182"/>
  </g>
  <text x="556" y="206" font-size="12" text-anchor="middle" font-weight="bold"
        fill="#3f4a54">共通重心</text>
  <circle cx="530" cy="175" r="18" fill="#cfe0f0" stroke="#2a5f96" stroke-width="1.6"/>
  <text x="530" y="180" font-size="11.5" text-anchor="middle" font-weight="bold" fill="#2a5f96">M</text>
  <circle cx="654" cy="175" r="10" fill="#c8bda9" stroke="#8a7f6c" stroke-width="1.2"/>
  <text x="654" y="180" font-size="11" text-anchor="middle" font-weight="bold">m</text>
  <!-- 寸法 r1 r2 -->
  <line x1="530" y1="246" x2="556" y2="246" stroke="#1b1f24" stroke-width="1"/>
  <line x1="530" y1="241" x2="530" y2="251" stroke="#1b1f24" stroke-width="1"/>
  <line x1="556" y1="241" x2="556" y2="251" stroke="#1b1f24" stroke-width="1"/>
  <text x="536" y="264" font-size="12">r₁</text>
  <line x1="556" y1="246" x2="654" y2="246" stroke="#1b1f24" stroke-width="1"/>
  <line x1="654" y1="241" x2="654" y2="251" stroke="#1b1f24" stroke-width="1"/>
  <text x="602" y="264" font-size="12" text-anchor="middle">r₂</text>
  <line x1="530" y1="286" x2="654" y2="286" stroke="#1b1f24" stroke-width="1"/>
  <line x1="530" y1="281" x2="530" y2="291" stroke="#1b1f24" stroke-width="1"/>
  <line x1="654" y1="281" x2="654" y2="291" stroke="#1b1f24" stroke-width="1"/>
  <text x="592" y="304" font-size="12" text-anchor="middle">r₀ = r₁ + r₂</text>
  <defs>
    <marker id="a3" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto">
      <path d="M0,0 L9,4.5 L0,9 z" fill="#1663b5"/>
    </marker>
  </defs>
</svg>"""

P33 = page(
  '3-3　地球と月',
  '出典：関西学院大（一部を書きかえています）',
  ('<b>地球（質量 M）と月（質量 m）だけ</b>を考える（太陽やほかの天体は無視する）。'
   '2つの距離は <b>r₀</b>、万有引力定数を G とする。'
   '地球も月も<b>大きさの無視できる質点</b>として扱う。<br>'
   '<b>【A】前半</b>：まず「<b>地球は動かない</b>」と考え、'
   '月だけが地球を中心とする<b>半径 r₀ の等速円運動</b>をしているとする。<br>'
   '<b>【B】後半</b>：実際には地球も月に引かれて動く。'
   '2つは<b>共通重心を通る直線上に並んだまま、同じ角速度</b>でそれぞれ円運動する。'
   '共通重心から地球までを r₁、月までを r₂（r₁ + r₂ = r₀）とする。'),
  FIG33,
  '図　【A】地球を固定したとき　　【B】共通重心のまわりを回るとき',
  [
   '<b>【A】</b> 月が受ける万有引力の大きさを G, M, m, r₀ で表せ。',
   '<b>【A】</b> 月の運動の周期 T と速さ v を、G, M, r₀ で表せ。',
   '<b>【A】</b> 月の力学的エネルギー E を求めよ。また、'
   '<b>(a)</b> E が減少すると半径 r₀ はどうなるか。'
   '<b>(b)</b> r₀ が減少すると速さ v はどうなるか。',
   '<b>【B】</b> 共通重心から地球までを r₁、月までを r₂ として、'
   '月についての円運動の式を書き、角速度 ω を求めよ。',
   '<b>【B】</b> 地球についても同じ角速度になることを確かめ、'
   '円運動の周期 T を G, M, m, r₀ で表せ。',
  ])

SHEETS = [('prob_m31', P31), ('prob_m32', P32), ('prob_m33', P33)]


def main():
    os.makedirs(OUT, exist_ok=True)
    tmp = '/tmp/probsheet'
    os.makedirs(tmp, exist_ok=True)
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={'width': 820, 'height': 900}, device_scale_factor=2)
        for key, html in SHEETS:
            f = os.path.join(tmp, key + '.html')
            open(f, 'w', encoding='utf-8').write(html)
            pg.goto('file://' + f)
            pg.wait_for_timeout(350)
            raw = os.path.join(tmp, key + '_raw.png')
            pg.screenshot(path=raw, full_page=True)
            print('shot', key)
        b.close()
    # 大きさをおさえる（HTML に base64 で入るので、1枚 200 KB 以下をめやすに）
    from PIL import Image
    for key, _ in SHEETS:
        im = Image.open(os.path.join(tmp, key + '_raw.png')).convert('RGB')
        w = 1100                                  # 元の 820px の 1.34 倍
        im = im.resize((w, int(im.size[1] * w / im.size[0])), Image.LANCZOS)
        im = im.quantize(colors=64, method=Image.MEDIANCUT).convert('P')
        out = os.path.join(OUT, key + '.png')
        im.save(out, optimize=True)
        print(out, os.path.getsize(out) // 1024, 'KB', im.size)


if __name__ == '__main__':
    main()
