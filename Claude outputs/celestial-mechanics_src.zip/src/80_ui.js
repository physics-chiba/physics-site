/* 状態 st と DOM。render は st だけから描く。
   姉妹ページ basics-of-motion-on-plane.html の 80_ui.js をもとに、
   ・表示チェックは図に重ねず「図の上の独立した行」に
   ・図のすぐ下に「計算結果の帯」（半長軸 a・周期 T・K = T²/a³）
   ・グラフの横軸を t 以外（r や a）にもできる／両対数にもできる
   の3点を足したもの。問題モードは持たない。 */
'use strict';

/* sysKind … 1-1〜1-4 で共通の「描画対象」（'sun' ＝ 太陽と惑星／'earth' ＝ 地球と人工衛星）。
   ★ここ1か所だけが正★ 各シムの v.sys / v.sys14 は applySysKind() が書きうつす。 */
var st = { cur: 'm1-1', sims: {}, bigFml: false, probKind: 'prob', sysKind: 'sun' };

/* 表示チェックボックスの名前と既定（力は最初オフ） */
var VIS_LABEL = {
  F: '力を表示', Fc: '分解した力を表示', V: '速度を表示', Vc: '分解した速度を表示',
  A: '加速度を表示', R: '距離 r を表示', O: '軌道を表示', T: '軌跡を表示'
};
var VIS_DEF = { F: false, Fc: false, V: true, Vc: false, A: false, R: true, O: true, T: true };

/* 変数（v）と表示オプション（o）をまとめて物理へ渡す */
function V(s) {
  var o = {}, k;
  for (k in s.v) o[k] = s.v[k];
  for (k in s.o) o[k] = s.o[k];
  return o;
}

function $(id) { return document.getElementById(id); }

/* いま出す変数だけを返す。変数に when(v) を書くと、その条件のときだけ出る
   （太陽系と地球まわりで「半長軸 a」の単位・範囲が変わるので、2本立てにしている）。 */
function varsOf(d, s) {
  var v = V(s);
  return (d.vars || []).filter(function (x) { return !x.when || x.when(v); });
}

/* いま表示するグラフだけを返す。グラフに when(v) を書くと、その条件のときだけ出る。 */
function graphsOf(d, s) {
  var list = d.graphs || [];
  if (!s) return list;
  var v = V(s);
  return list.filter(function (g) { return !g.when || g.when(v); });
}

function initState() {
  Object.keys(DEFS).forEach(function (id) {
    var d = DEFS[id];
    var s = {
      v: {}, o: {}, t: 0, playing: false, slow: false, sign: 1,
      open: {}, gview: {}, view: null, _eq: null, pick: null, ui: {}
    };
    (d.vars || []).forEach(function (vd) { s.v[vd.k] = vd.def; });
    (d.toggles || []).forEach(function (td) { s.o[td.k] = td.def; });
    (d.selects || []).forEach(function (sd) { s.o[sd.k] = sd.def; });
    (d.vis || []).forEach(function (k) {
      s.o['show' + k] = (d.visDef && d.visDef[k] !== undefined) ? d.visDef[k] : VIS_DEF[k];
    });
    if (d.consts) Object.keys(d.consts).forEach(function (k) { s.o[k] = d.consts[k]; });
    (d.graphs || []).forEach(function (g) { s.open[g.key] = !!g.open; });
    /* 3次元の図（2-1 のすりばち）の視点。既定は d.cam3d に書く */
    if (d.cam3d) s.cam = { az: d.cam3d.az, el: d.cam3d.el, zoom: d.cam3d.zoom || 1 };
    if (d.init) d.init(s);
    st.sims[id] = s;
  });
}

/* ===== 凡例（矢印の小さな絵と、色の四角） ===== */
function drawLegend() {
  var list = document.querySelectorAll('#legend canvas');
  Array.prototype.forEach.call(list, function (cv) {
    var ctx = prep(cv, 56, 16);
    var ck = cv.getAttribute('data-col');
    arrow(ctx, 4, 8, 50, 8, cv.getAttribute('data-kind'), 0.8, ck ? COL[ck] : null);
  });
  Array.prototype.forEach.call(document.querySelectorAll('#legend .sw'), function (el) {
    var c = COL[el.getAttribute('data-col')];
    if (c) el.style.background = c;
  });
}

/* ===== タブ ===== */
/* ★同じモードの中でシムを移るだけなら、タブは作り直さない★
   ボタンは全部で20個ほどあり、作り直すと DOM の作成＋レイアウトで
   1回 25 ms ほどかかっていた。タブを押すたびにこれが走るので、
   実機では「押すと固まる」と感じる（先生の指摘）。
   移っただけのときは、濃く塗るボタンを付けかえるだけで済む。 */
function buildTabs() {
  var cur0 = DEFS[st.cur];
  if (st._tabMode === cur0.mode) {
    var stb0 = $('simtabs'), ids0 = null, i0;
    MODES.forEach(function (M) { if (M.n === cur0.mode) ids0 = M.ids; });
    if (ids0) {
      var bs = stb0.children;
      for (i0 = 0; i0 < bs.length && i0 < ids0.length; i0++) {
        var id0 = ids0[i0], d0 = DEFS[id0];
        if (!d0) continue;
        setCls(bs[i0], (d0.read ? 'game' : (d0.intro ? 'intro' : '')) +
          (id0 === st.cur ? ' on' : ''));
      }
      return;
    }
  }
  st._tabMode = cur0.mode;
  buildTabsFull();
}

function buildTabsFull() {
  var mt = $('modetabs'), stb = $('simtabs'), cur = DEFS[st.cur];
  mt.innerHTML = '';
  var curBtn = null, curMode = null;
  MODES.forEach(function (M) {
    var b = document.createElement('button');
    b.textContent = M.label;
    if (M.n === cur.mode) { b.className = 'on'; curBtn = b; curMode = M; }
    b.addEventListener('click', function () { if (M.n !== DEFS[st.cur].mode) gotoSim(M.ids[0]); });
    mt.appendChild(b);
  });
  /* 選んでいるモードのひとこと（青いボタンの真下に表示する） */
  var tip = $('modetip');
  if (!tip) {
    tip = document.createElement('div');
    tip.id = 'modetip';
    mt.parentNode.insertBefore(tip, mt.nextSibling);
  }
  tip.innerHTML = (curMode && curMode.tip) ? curMode.tip : '';
  st._tipBtn = curBtn;
  placeModeTip();
  stb.innerHTML = '';
  MODES.forEach(function (M) {
    if (M.n !== cur.mode) return;
    M.ids.forEach(function (id) {
      if (!DEFS[id]) return;
      var b = document.createElement('button');
      b.textContent = DEFS[id].tab;
      /* read … 読み物（補足）はオレンジ、intro … 入り口のシムは灰青。
         どちらでもないシムはふつうの青。色でグループが分かるようにしている。 */
      b.className = (DEFS[id].read ? 'game' : (DEFS[id].intro ? 'intro' : '')) +
        (id === st.cur ? ' on' : '');
      b.addEventListener('click', function () { gotoSim(id); });
      stb.appendChild(b);
    });
  });
}

/* 矢印・色の説明（#legend）は、いまのシミュレーションで実際に出てくるものだけを出す。
   def の legendKeys（例：['sun','vel','dim','bound']）で指定する。
   書き忘れたシムでは、安全のため全部出す。 */
function renderLegend(d) {
  var keys = d.legendKeys || null;
  Array.prototype.forEach.call(document.querySelectorAll('#legend .lg'), function (el) {
    var k = el.getAttribute('data-lk');
    el.style.display = (!keys || keys.indexOf(k) >= 0) ? '' : 'none';
  });
}

/* ひとことの ▲ が、選んでいるモードのボタンの真下に来るようにする */
function placeModeTip() {
  var tip = $('modetip'), b = st._tipBtn, mt = $('modetabs');
  if (!tip || !b || !mt) return;
  var off = b.getBoundingClientRect().left - mt.getBoundingClientRect().left;
  tip.style.paddingLeft = Math.max(0, off + b.offsetWidth / 2 - 7) + 'px';
}

/* ===== 「入試問題の読み解き」の文の中に置く、動かせる部品 =====
   ★ねらい★ 解説を読みながら、その場でシミュレーションを動かして確かめられるようにする。
   文の中につぎの印を書くと、部品に置きかわる（そのほかの部分は mathHtml を通す）。

     @@v:eq@@              … 変数 eq のスライドバー（−・値・＋つき）をその場に置く
     @@r:打ち上げの速さ|文字@@ … 押すと「計算結果を表示」の中の その項目まで飛んで光る
     @@b:2|文字@@          … 押すと 図の左上のオレンジのボタン 2 番と同じことをする
     @@s:x0R=1,v0=0|文字@@ … 押すと 変数をその値にする
     @@g:Fx|文字@@         … 押すと そのグラフを開いて、そこまで飛ぶ

   ★書いたキーが本当にあるかどうか、必ず画面で確かめること★
   （「計算結果を表示」に無い項目名を書いてしまい、押しても飛ばない、という失敗をした） */
function rkey(k) { return String(k).replace(/[$\\{}^_"<>]/g, ''); }

function probHtml(d, s, str) {
  var out = '', i = 0, txt = String(str);
  while (i < txt.length) {
    var a1 = txt.indexOf('@@', i);
    if (a1 < 0) { out += mathHtml(txt.slice(i)); break; }
    out += mathHtml(txt.slice(i, a1));
    var b1 = txt.indexOf('@@', a1 + 2);
    if (b1 < 0) { out += mathHtml(txt.slice(a1)); break; }
    out += probWidget(d, s, txt.slice(a1 + 2, b1));
    i = b1 + 2;
  }
  return out;
}

function probWidget(d, s, spec) {
  var c = spec.indexOf(':');
  if (c < 0) return '';
  var kind = spec.slice(0, c), rest = spec.slice(c + 1);
  var bar = rest.indexOf('|');
  var arg = (bar < 0) ? rest : rest.slice(0, bar);
  var lab = (bar < 0) ? '' : rest.slice(bar + 1);
  if (kind === 'v') {
    var vd = null;
    (d.vars || []).forEach(function (x) { if (x.k === arg) vd = x; });
    if (!vd) return '';
    return '<span class="pvar"><span class="pvlab">' +
      mathHtml(vd.label.replace(/（[^）]*）/g, '')) + '</span>' +
      '<button class="stp" data-var="' + vd.k + '" data-dir="-1">−</button>' +
      '<span class="vval" data-vval="' + vd.k + '"></span>' +
      '<button class="stp" data-var="' + vd.k + '" data-dir="1">＋</button>' +
      '<input type="range" class="vsl" data-vsl="' + vd.k + '" min="' + vd.min +
      '" max="' + vd.max + '" step="' + vd.step + '"></span>';
  }
  if (kind === 'r') {
    var on = (st.flashRes === rkey(arg)) ? ' on' : '';
    return '<button class="reslink' + on + '" data-reskey="' + rkey(arg) + '">' +
      mathHtml(lab || arg) + '<span class="rlarrow">▸</span></button>';
  }
  if (kind === 'b') {
    return '<button class="pact" data-ptact="' + arg + '">' + mathHtml(lab || '押す') + '</button>';
  }
  if (kind === 's') {
    return '<button class="pact" data-pset="' + arg + '">' + mathHtml(lab || '押す') + '</button>';
  }
  if (kind === 'g') {
    return '<button class="pact glink" data-pgraph="' + arg + '">' + mathHtml(lab || 'グラフを開く') + '</button>';
  }
  return '';
}

/* ===== 入試問題の「問題文」「解答と解き方」（画像）を重ね窓で開く =====
   画像は build.js が base64 で埋め込む IMG[キー] を使うので、
   ネットにつながっていなくてもそのまま開ける。
   kind … 'prob'（問題文）または 'ans'（解答と解き方） */
function openProbImg(d, kind) {
  var ov = $('probov');
  if (!ov || !d) return;
  var key = (kind === 'ans') ? d.ansImg : d.probImg;
  if (!key || !IMG[key]) return;
  var im = $('probovImg');
  im.src = IMG[key];
  im.className = '';                 /* 前に拡大したままなら、幅に合わせるへ戻す */
  $('probov').querySelector('.probov-body').scrollTop = 0;
  $('probovTtl').textContent = (d.tab || '')
    + ((kind === 'ans') ? '　解答と解き方' : '　問題文');
  st.probKind = kind;
  ov.hidden = false;
  var x = $('bProbClose');
  if (x) x.focus();
}
function closeProbImg() {
  var ov = $('probov');
  if (!ov || ov.hidden) return;
  ov.hidden = true;
  var b = $(st.probKind === 'ans' ? 'bAnsImg' : 'bProbImg');
  if (b) b.focus();
}
function initProbOverlay() {
  var ov = $('probov');
  if (!ov) return;
  $('bProbClose').addEventListener('click', closeProbImg);
  /* 画像をクリックすると原寸（読みやすい大きさ）と、はば に合わせるを切りかえる */
  $('probovImg').addEventListener('click', function () {
    this.className = (this.className === 'zoom') ? '' : 'zoom';
  });
  /* 画像の外（暗いところ）をクリックしても閉じる */
  ov.addEventListener('click', function (e) { if (e.target === ov) closeProbImg(); });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeProbImg();
  });
}

/* ===== ★canvas は作り直さず、使いまわす★ =====
   buildPanel() は #simhost をまるごと innerHTML で書きかえるので、
   前は <canvas> も毎回すてて作り直していた。
   ★あたらしい canvas に1回目を描くのは、使いまわしの 13 倍おそい★
   （実測：新規 18.9 ms / 使いまわし 1.2 ms。1120×816 の裏バッファの確保と、
   文字の下ごしらえが毎回やり直しになるため）。
   1-4 は canvas が4枚（図＋グラフ3枚）あるので、タブを押すたびに 75 ms 以上——
   実機では「押すと固まる」と感じる（先生の指摘）。
   → HTML には入れものだけ書いておき（cvSlot）、innerHTML のあとで
     覚えておいた canvas をそこへ差しこむ（fillCvSlots）。
   ★差しこむだけなので、2次元コンテキストも裏バッファもそのまま生き残る★ */
var CVPOOL = {};
function cvSlot(id, cls) {
  return '<div class="cvslot" data-cv="' + id + '" data-cvcls="' + (cls || '') + '"></div>';
}
function fillCvSlots() {
  Array.prototype.forEach.call($('simhost').querySelectorAll('.cvslot'), function (slot) {
    var id = slot.getAttribute('data-cv'), cv = CVPOOL[id];
    if (!cv) { cv = document.createElement('canvas'); cv.id = id; CVPOOL[id] = cv; }
    setCls(cv, slot.getAttribute('data-cvcls') || '');
    slot.parentNode.replaceChild(cv, slot);
  });
}

/* ===== パネルの組み立て ===== */
function buildPanel() {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  closeProbImg();                     /* 別のシミュレーションへ移ったら問題文は閉じる */
  s._eq = null;                       /* DOM を作り直すのでキャッシュを捨てる */
  var h = [];
  /* タイトルは関数にもできる（描画対象で法則の文が変わる 1-1〜1-3 で使っている） */
  var ttlHtml = mathHtml(typeof d.title === 'function' ? d.title(V(s), s) : d.title);
  /* ★描画対象（太陽と惑星／地球と人工衛星）の共通切りかえ★
     1-1〜1-4 で1つの値（st.sysKind）を共有する。タブを移っても選び直さなくてよい。 */
  if (d.sysToggle) {
    ttlHtml += '<span class="systog"><span class="systog-lab">描画対象</span>'
      + '<button type="button" data-sys="sun"'
      + (st.sysKind === 'earth' ? '' : ' class="on"') + '>太陽と惑星</button>'
      + '<button type="button" data-sys="earth"'
      + (st.sysKind === 'earth' ? ' class="on"' : '') + '>地球と人工衛星</button></span>';
  }
  /* 入試問題のシミュレーションには、問題文と解答の画像を開くリンクをタイトルの横に出す。
     ★並び順は「問題 → 解答」★ 先に解答が目に入らないように、色も分けてある。 */
  if (typeof IMG !== 'undefined') {
    if (d.probImg && IMG[d.probImg]) {
      ttlHtml += '<button type="button" class="problink" id="bProbImg">'
        + '問題はこちら。まず解いてから以下を読もう</button>';
    }
    if (d.ansImg && IMG[d.ansImg]) {
      ttlHtml += '<button type="button" class="problink ans" id="bAnsImg">'
        + '解答と解き方はこちら</button>';
    }
  }
  h.push('<div class="simhead"><div class="simtitle">' + ttlHtml + '</div></div>');
  /* ★d.topCard＝タイトルのすぐ下に、横いっぱいで置く読み物★
     いまは 2-1 の「重力場とは何か」の動画つきの説明で使っている。
     図より先に読ませたいものだけ、ここに置くこと。
     ★名前を intro にしてはいけない★（2026-09-05 のしくじり）
       d.intro は「入り口のシム＝タブの色を変える」ための true/false で、
       1-0 が使っている。同じ名前にしたら 1-0 のタイトルの下に
       「true」という字が出た。 */
  if (d.topCard) h.push('<div class="card topcard">' + mathHtml(d.topCard) + '</div>');
  /* ★d.wide＝図を横いっぱいに使い、右の列（コラム・グラフ）は下に回す★
     4-5 のように「よこ一列に3つ並べて見くらべる」図で使う。
     ふだんは 図（左）／読み物（右）の2列。 */
  h.push('<div class="simgrid' + (d.wide ? ' widecv' : '') + '"><div class="cv">');

  /* ① 再生ボタンと時間バー */
  h.push('<div class="ctrl playctrl">');
  h.push('<div class="btnrow">');
  h.push('<button id="bPlay">▶ スタート</button>');
  h.push('<button id="bSlow" class="sub">スロー再生</button>');
  h.push('<button id="bReset" class="sub">↺ リセット</button>');
  h.push('<span class="tspan"><label>時間 t</label><input type="range" id="tBar" min="0" max="1" step="0.001" value="0"><span class="tval" id="tVal">0.00</span></span>');
  h.push('</div>');
  h.push('</div>');

  /* ② 図の上の行：よく変える値のカード＋選択メニュー＋表示チェック（図には重ねない） */
  var mainKeys = mainVarKeys(d);
  var mainList = varsOf(d, s).filter(function (vd) { return mainKeys.indexOf(vd.k) >= 0; });
  var topSel = d.selects || [];
  var topTog = d.toggles || [];
  h.push('<div class="cvtop toprow" id="cvtop">');
  h.push('<div class="cvleft">');
  /* いちばん見せたいボタン（1-2 の「離心率を大きくする」・1-5 の「軌道を大きくする」など）は、
     図の下のバーではなく、図の左上のこの位置に置く。 */
  function topActsHtml() {
    if (!d.topActions || !d.topActions.length) return '';
    var g = ['<div class="topacts">'];
    d.topActions.forEach(function (a, i) {
      /* label は文字列でも関数でもよい。関数にすると「押すと文字が変わるボタン」
         （＝オン／オフのトグル）が作れる。 */
      /* ★オレンジのボタンの濃さ★
         is() を持つボタン（＝「いまその状態か」が決まるボタン）は、
         その状態のときだけ濃く塗る。持たないボタン（＝押すたびに進むもの）は、
         prim なら いつも濃く。★ページ全体でこの決まりにそろえること★ */
      /* glow(v, s) … true のあいだ光る（「いま、ここを押してほしい」）
         dis(v, s)  … true のあいだ押せない（これ以上進めないボタン） */
      var on0 = a.is ? !!a.is(V(s), s) : false;
      var cls0 = tactCls(a, V(s), s, on0);
      /* br: true  … このボタンから行をかえる
         gap: true … このボタンの前に、すこし広いすき間を置く（4-5 のボタンのまとまり）
         wrap: true … 名前が長いボタンだけ、2行に折り返してよい */
      if (a.br) g.push('<span class="tbr"></span>');
      else if (a.gap) g.push('<span class="tgap"></span>');
      g.push('<button class="' + cls0 + '" data-tact="' + i + '" id="tact_' + i + '"' +
        (a.dis && a.dis(V(s), s) ? ' disabled' : '') + '>' +
        (typeof a.label === 'function' ? a.label(V(s), s) : a.label) + '</button>');
    });
    g.push('</div>');
    return g.join('');
  }
  /* d.topActionsBelow を true にすると、ボタンをスライドバーのカードの「下」に置く */
  if (!d.topActionsBelow) h.push(topActsHtml());
  /* ★2列（2×2）に並べるかどうか★
     d.varsTwoCol を true にしたシムだけ 2 列にする（2-1）。
     説明（hint）は varsTwoColHtml が「自分の列のぶんだけ」の幅で出すので、
     hint があっても 2 列がくずれない。 */
  var twoCol = !!d.varsTwoCol && mainList.length > 2;
  /* ★「まずここを動かしてほしい」変数がある画面には、カードの上に帯を出す★
     ラベルの背景を変えるだけでは弱くて気づいてもらえなかった（先生の指摘）。 */
  var focList = mainList.filter(function (vd) { return vd.focus; });
  if (focList.length) {
    /* 変数の名前をならべると、下のスライドバーの名前と二重になって読みにくい
       （先生の指摘・2026-09-05）。「↓」を focus の数だけ出して、
       すぐ下のスライドバーを指させる。 */
    h.push('<div class="focbar">まずここ　' +
      focList.map(function () { return '↓'; }).join(' や ') +
      ' を動かしてみよう</div>');
  }
  h.push('<div class="cvvars' + (twoCol ? ' two' : '') + '" id="cvvars">');
  if (twoCol) h.push(varsTwoColHtml(mainList));
  else mainList.forEach(function (vd) { h.push(varRowHtml(vd, 'a')); });
  h.push('</div>');
  if (d.topActionsBelow) h.push(topActsHtml());
  h.push('</div>');
  h.push('<div class="cvside">');
  if (topSel.length || topTog.length) {
    h.push('<div class="cvopts">');
    topSel.forEach(function (sd) {
      h.push('<label class="cvsel">' + sd.label + '<select data-sel="' + sd.k + '">' +
        sd.options.map(function (o) { return '<option value="' + o.v + '"' + (o.v === s.o[sd.k] ? ' selected' : '') + '>' + o.label + '</option>'; }).join('') +
        '</select></label>');
    });
    topTog.forEach(function (td) {
      h.push('<label><input type="checkbox" data-tog="' + td.k + '"' + (s.o[td.k] ? ' checked' : '') + '> ' + mathHtml(td.label) + '</label>');
    });
    h.push('</div>');
  }
  if (d.vis && d.vis.length) {
    h.push('<div class="opts">');
    d.vis.forEach(function (k) {
      /* d.visGap にキーを書くと、そのチェックの「手前」にすきまを2マスぶん空ける
         （2-1 で「上の図のチェック」と「下の図のチェック」を見分けやすくするため） */
      if (d.visGap && d.visGap.indexOf(k) >= 0) h.push('<span class="visgap" aria-hidden="true"></span>');
      /* まだ押していない「ぜひ押してほしいチェック」は、オレンジで脈打たせて誘導する */
      var focus = (d.visFocus === k) && !s.o['show' + k];
      h.push('<label class="' + (focus ? 'visfocus' : '') + '"><input type="checkbox" data-vis="show' + k + '"' +
        (s.o['show' + k] ? ' checked' : '') + '> ' +
        mathHtml((d.visLabel && d.visLabel[k]) || VIS_LABEL[k]) +
        (focus ? '<span class="vbadge">押してみよう</span>' : '') + '</label>');
    });
    h.push('</div>');
  }
  h.push('</div></div>');

  /* ③ 図（キャンバス） */
  var hasAct = !!(d.actions && d.actions.length);
  var hasRes = !!d.result;
  h.push('<div class="cvstage' + (hasRes ? ' hasres' : (hasAct ? '' : ' nobar')) + '">');
  h.push(cvSlot('mainCv', (d.drag || d.drag3d) ? 'dragcv' : ''));
  h.push('</div>');
  /* ④ オレンジの状況ボタン（1行におさめる） */
  if (hasAct) {
    h.push('<div class="cvbar' + (hasRes ? ' midbar' : '') + '"><div class="acts n' + Math.min(4, d.actions.length) + '">');
    d.actions.forEach(function (a, i) {
      h.push('<button class="warm' + (a.alt ? ' alt' : '') + '" data-act="' + i + '" id="act_' + i + '">' + a.label + '</button>');
    });
    h.push('</div></div>');
  }
  /* ⑤ 計算結果の帯 */
  if (hasRes) h.push('<div class="resbar" id="resbar"></div>');
  /* ⑤b 単位のことわり（AU・太陽質量など、教科書に出てこない単位の説明） */
  h.push(unitNoteHtml(d, s));
  /* ⑥ 補足の文章 → 運動方程式の式 */
  var subTxt = (typeof d.sub === 'function') ? d.sub(V(s)) : d.sub;
  if (subTxt) h.push('<p class="cvsub">' + mathHtml(subTxt) + '</p>');
  if (d.legendBodies) h.push('<div class="plegend" id="plegend"></div>');
  if (d.eq) h.push('<div class="eq" id="eqbox"></div>');
  /* 式の下の注釈（高校で習わない記号の説明など）。d.eqNote に書く */
  if (d.eqNote) h.push('<p class="eqnote">' + mathHtml(d.eqNote) + '</p>');
  h.push('</div><div class="side">');

  /* 右列 ⓪ 入試問題の読み解き（モード3）。★グラフより上に置く★
     d.probs = [{ q:'(1) 問題文', a:'解説', do:'シミュレーションでやってほしいこと' }, …] */
  if (d.probs && d.probs.length) {
    h.push('<div class="card probs">');
    if (d.probsHead) h.push('<div class="probhead">' + mathHtml(d.probsHead) + '</div>');
    /* ★いちばん上に「どんな状況の問題なのか」を必ず書く★
       生徒は問題文を知らないので、状況が分からないと問題文だけ読んでも意味が通らない。
       背景の色を変えた帯（.psetup）にして、問題文（.pq）とはっきり分ける。 */
    if (d.probsSetup) {
      h.push('<div class="psetup"><b class="ptag">どんな状況か</b>' +
        probHtml(d, s, d.probsSetup) + '</div>');
    }
    d.probs.forEach(function (pr) {
      h.push('<div class="prob">');
      /* 小問のとちゅうで状況が変わるときは、その小問の前にもう一度 setup を出す */
      if (pr.setup) {
        h.push('<div class="psetup"><b class="ptag">ここで状況が変わる</b>' +
          probHtml(d, s, pr.setup) + '</div>');
      }
      h.push('<div class="pq">' + probHtml(d, s, pr.q) + '</div>');
      if (pr.a) h.push('<div class="pa"><b>解き方</b>　' + probHtml(d, s, pr.a) + '</div>');
      if (pr.do) h.push('<div class="pd"><b>やってみよう</b>　' + probHtml(d, s, pr.do) + '</div>');
      h.push('</div>');
    });
    h.push('</div>');
  }

  /* 右列 ① まとめて開く＋式を拡大（グラフが1つも無いシムでは出さない） */
  var hasGraph = graphsOf(d, s).length > 0;
  /* d.noOpenRow: true にすると「まとめて開く／式を拡大」の行を出さない
     （1-0 のように、グラフが1つしかない入り口のシムでは、じゃまになるだけ） */
  if (hasGraph && !d.noOpenRow) {
    h.push('<div class="btnrow openrow"><button class="warm" id="bOpenAll">' + openAllLabel() + '</button>' +
      '<button class="sub" id="bBigFml">' + bigFmlLabel() + '</button>' +
      '<span class="ghint1">グラフは ドラッグ＝移動／目盛りの上でドラッグ＝軸の拡大縮小／ホイール＝拡大縮小／ダブルクリック＝自動</span></div>');
  }

  /* 右列 ② 各グラフ */
  graphsOf(d, s).forEach(function (g) {
    var sw = '';
    if (g.sw) {                       /* グラフのすぐ上に置く切りかえ（両対数／両方リニア など） */
      sw = '<div class="gsw">' + (g.sw.label ? '<span>' + g.sw.label + '</span>' : '') +
        g.sw.options.map(function (o) {
          return '<button class="' + (s.o[g.sw.k] === o.v ? 'on' : 'sub') + '" data-gsw="' + g.sw.k +
            '" data-gswv="' + o.v + '">' + o.label + '</button>';
        }).join('') + '</div>';
    }
    h.push('<div class="gsec"><button class="ghead" data-g="' + g.key + '"><span class="tri">' +
      (s.open[g.key] ? '▼' : '▶') + '</span>' +
      mathHtml(typeof g.title === 'function' ? g.title(V(s), s) : g.title) + '</button>' +
      '<div class="gbody' + (s.open[g.key] ? '' : ' hide') + (st.bigFml ? ' bigf' : '') + '" id="gb_' + g.key + '">' +
      '<div class="gleft">' + sw + cvSlot('gc_' + g.key) + '</div>' +
      /* 公式の欄がないグラフには、同じ幅の「見えない場所とり」を置く。
         こうしないと、公式のないグラフだけ横に広がって縦も高くなり、
         並んだグラフの大きさがそろわないため。 */
      (g.fml ? '<div class="gform" id="gf_' + g.key + '"></div>'
        : '<div class="gspacer" aria-hidden="true"></div>') +
      '</div></div>');
  });

  /* 右列 ②b 「見るポイント」の上に置く図（2-3 の静止軌道の見取り図など）。
     グラフより下・見るポイントより上に出したい図はここに書く。 */
  if (d.sideTop) {
    h.push('<div class="sidefig">' + (d.sideTop.title ? '<p class="sftitle">' + mathHtml(d.sideTop.title) + '</p>' : '') +
      cvSlot('sideTopCv') +
      (d.sideTop.note ? '<p class="sfnote">' + mathHtml(d.sideTop.note) + '</p>' : '') + '</div>');
  }

  /* 右列 ③ 見るポイント（d.note を書かないシムでは出さない） */
  if (d.note) h.push('<div class="note" id="notebox"><b>見るポイント</b>：' + mathHtml(d.note) + '</div>');

  /* 右列 ③b 説明の文章（1-6 の読み物） */
  if (d.sideText) h.push('<div class="card sidetext">' + mathHtml(d.sideText) + '</div>');
  /* 右列 ③c 2つ目の図（1-2 の楕円の定義・1-6 の地動説と天動説） */
  if (d.side) {
    h.push('<div class="sidefig">' + (d.side.title ? '<p class="sftitle">' + mathHtml(d.side.title) + '</p>' : '') +
      cvSlot('sideCv') +
      (d.side.note ? '<p class="sfnote">' + mathHtml(d.side.note) + '</p>' : '') + '</div>');
  }
  if (d.sideNote) h.push('<p class="mini sidemini">' + mathHtml(d.sideNote) + '</p>');

  /* 右列 ④ 残りの変数 */
  var restCount = 0, rest = [];
  varsOf(d, s).forEach(function (vd) {
    if (mainKeys.indexOf(vd.k) >= 0) return;
    restCount++;
    rest.push(varRowHtml(vd, 'b'));
  });
  if (restCount) h.push('<div class="ctrl">' + rest.join('') + '</div>');

  /* 右列 ⑤ 読み出しの表（d.info を書かないシムでは出さない） */
  if (d.info) h.push('<table class="read" id="readout"></table>');
  h.push('</div></div>');
  $('simhost').innerHTML = h.join('');
  fillCvSlots();                      /* ★覚えておいた canvas を差しこむ（作り直さない）★ */
  /* 詳しい解説は、パネルを差しかえた「あと」に出す
     （中で renderActive() が走るので、先に呼ぶと運動方程式の欄が空になる） */
  renderLong(d);
  if (d.legendBodies) renderBodyLegend(d, s);

  /* --- イベント --- */
  $('bPlay').addEventListener('click', onPlay);
  $('bSlow').addEventListener('click', function () {
    s.slow = !s.slow;
    $('bSlow').className = s.slow ? '' : 'sub';
    $('bSlow').textContent = s.slow ? 'スロー再生 中' : 'スロー再生';
  });
  $('bReset').addEventListener('click', function () { s.t = 0; s.playing = false; setPlayLabel(); renderActive(); });
  if ($('bProbImg')) {
    $('bProbImg').addEventListener('click', function () { openProbImg(d, 'prob'); });
  }
  if ($('bAnsImg')) {
    $('bAnsImg').addEventListener('click', function () { openProbImg(d, 'ans'); });
  }
  /* 描画対象の共通切りかえ。押したら4つのシムぜんぶに書きこんでから作り直す */
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-sys]'), function (b) {
    b.addEventListener('click', function () {
      if (st.sysKind === b.getAttribute('data-sys')) return;
      applySysKind(b.getAttribute('data-sys'));
      buildPanel(); renderActive(); renderLegend(DEFS[st.cur]);
      autoPlayOn(st.cur);
    });
  });
  $('tBar').addEventListener('input', function (e) {
    s.t = +e.target.value; s.playing = false; setPlayLabel(); renderActive();
  });
  if ($('bOpenAll')) $('bOpenAll').addEventListener('click', function () { toggleAllGraphs(); });
  if ($('bBigFml')) {
    $('bBigFml').addEventListener('click', function () { toggleBigFml(); });
    if (st.bigFml) $('bBigFml').className = '';
  }
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-gsw]'), function (b) {
    b.addEventListener('click', function () {
      s.o[b.getAttribute('data-gsw')] = b.getAttribute('data-gswv');
      buildPanel(); renderActive();
    });
  });

  Array.prototype.forEach.call($('simhost').querySelectorAll('.ghead'), function (b) {
    b.addEventListener('click', function () {
      var k = b.getAttribute('data-g');
      s.open[k] = !s.open[k];
      $('gb_' + k).className = 'gbody' + (s.open[k] ? '' : ' hide') + (st.bigFml ? ' bigf' : '');
      b.querySelector('.tri').textContent = s.open[k] ? '▼' : '▶';
      if ($('bOpenAll')) { $('bOpenAll').innerHTML = openAllLabel(); renderMath($('bOpenAll')); }
      renderActive();
    });
  });
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-tact]'), function (b) {
    b.addEventListener('click', function () {
      var a = d.topActions[+b.getAttribute('data-tact')];
      a.fn(s);
      if (!a.keepT) resetSim();
      if (a.rebuild) { buildPanel(); }
      /* play: true を書いたボタンは、押すと同時に再生も始める
         （「値を変えたのに動かない」と思われないように） */
      if (a.play) { s.playing = true; setPlayLabel(); }
      syncVarVals(); renderActive();
    });
  });
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-act]'), function (b) {
    b.addEventListener('click', function () {
      var a = d.actions[+b.getAttribute('data-act')];
      a.fn(s);
      if (!a.keepT) resetSim();
      if (a.rebuild) { buildPanel(); }
      /* topActions と同じで、play: true のボタンは押すと再生も始まる */
      if (a.play) { s.playing = true; setPlayLabel(); }
      syncVarVals(); renderActive();
    });
  });
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-sel]'), function (el) {
    el.addEventListener('change', function () {
      var sk = el.getAttribute('data-sel');
      s.o[sk] = el.value;
      if (d.onSelect) d.onSelect(s, sk, el.value);
      resetSim();
      buildPanel();            /* 選択でグラフや変数の顔ぶれが変わることがある */
      renderActive();
    });
  });
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-tog]'), function (el) {
    el.addEventListener('change', function () {
      var k = el.getAttribute('data-tog');
      s.o[k] = el.checked;
      if (d.onToggle) d.onToggle(s, k, el.checked);
      renderActive();
    });
  });
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-vis]'), function (el) {
    el.addEventListener('change', function () {
      var k = el.getAttribute('data-vis');
      s.o[k] = el.checked;
      if (d.visFocus && k === 'show' + d.visFocus) buildPanel();   /* 誘導の強調を消す */
      renderActive();
    });
  });
  /* ★右の解説の中の部品は、さわったらそのまま再生を始める★
     右で数値を変えてから、遠くにある「スタート」を押しに行くのは負担が大きいため
     （先生の指示）。図の上のカードのスライドバーは、これまでどおり再生しない。 */
  function inProbs(el) { return !!(el.closest && el.closest('.card.probs')); }
  function autoPlay(el) {
    if (!inProbs(el)) return;
    if (!s.playing) { s.playing = true; setPlayLabel(); }
  }
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-vsl]'), function (r) {
    r.addEventListener('input', function () {
      setVar(r.getAttribute('data-vsl'), +r.value);
      autoPlay(r);
    });
  });
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-var]'), function (b) {
    b.addEventListener('click', function () {
      stepVar(b.getAttribute('data-var'), +b.getAttribute('data-dir'));
      autoPlay(b);
    });
  });
  /* ===== 「入試問題の読み解き」の中の部品 ===== */
  /* ① 「計算結果を表示」の該当する数字まで飛んで光らせる */
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-reskey]'), function (b) {
    b.addEventListener('click', function () {
      jumpToRes(b.getAttribute('data-reskey'));
      /* 押したリンク自身も「いま選んでいる」色にする（どれを見ているか分かるように） */
      Array.prototype.forEach.call($('simhost').querySelectorAll('[data-reskey]'), function (o) {
        o.classList.remove('on');
      });
      b.classList.add('on');
    });
  });
  /* ② 図の左上のオレンジのボタンと同じことをする（id が重ならないよう data-ptact） */
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-ptact]'), function (b) {
    b.addEventListener('click', function () {
      var a = (d.topActions || [])[+b.getAttribute('data-ptact')];
      if (!a) return;
      a.fn(s);
      if (!a.keepT) resetSim();
      /* 解説の中から押したときは、いつでも再生を始める（生徒の手間を減らすため） */
      s.playing = true; setPlayLabel();
      syncVarVals(); renderActive();
      flashEl($('cvtop'));
    });
  });
  /* ③ 変数をその値にする（例 data-pset="x0R=1,v0=0"） */
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-pset]'), function (b) {
    b.addEventListener('click', function () {
      b.getAttribute('data-pset').split(',').forEach(function (kv) {
        var q = kv.split('=');
        if (q.length === 2) s.v[q[0].trim()] = +q[1];
      });
      resetSim(); s.playing = true; setPlayLabel();
      syncVarVals(); renderActive();
      flashEl($('cvtop'));
    });
  });
  /* ④ グラフを開いて、そこまで飛ぶ */
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-pgraph]'), function (b) {
    b.addEventListener('click', function () {
      var gk = b.getAttribute('data-pgraph');
      if (!s.open[gk]) { s.open[gk] = true; buildPanel(); renderActive(); }
      var el = $('gb_' + gk);
      if (el && el.scrollIntoView) el.scrollIntoView({ block: 'center', behavior: 'smooth' });
      flashEl(el && el.parentNode);
    });
  });
  /* ★canvas を使いまわすので、ドラッグの登録は1枚につき1回だけ★
     毎回つけると、タブを移るたびに聞き手が増えていってしまう。
     中では DEFS[st.cur] / st.sims[st.cur] を見るので、シムが変わっても正しく動く。 */
  graphsOf(d, s).forEach(function (g) {
    var gcv = $('gc_' + g.key);
    if (gcv && !gcv._dragOn) { gcv._dragOn = true; attachGraphDrag(gcv, g.key); }
  });
  var mcv = $('mainCv');
  if (mcv && !mcv._dragOn) { mcv._dragOn = true; attachSimDrag(); attach3dDrag(); attachCvHits(); }
  attachYt();

  setPlayLabel();
  $('bSlow').className = s.slow ? '' : 'sub';
  $('bSlow').textContent = s.slow ? 'スロー再生 中' : 'スロー再生';
  syncVarVals();
  renderMath($('simhost'));
}

/* 「よく変える変数」＝図の上のカードに置くもの */
function mainVarKeys(d) {
  var s = st.sims[d.id], list = s ? varsOf(d, s) : (d.vars || []);
  if (!list.length) return [];
  if (d.mainVars === '*') return list.map(function (x) { return x.k; });
  if (d.mainVars) return d.mainVars;
  return list.slice(0, 2).map(function (x) { return x.k; });
}

function varCellsHtml(vd, tag) {
  /* 図の上のカードでは（かっこ書き）を落として短く見せる */
  var lab = (tag === 'a') ? vd.label.replace(/（[^）]*）/g, '') : vd.label;
  /* vd.focus: true … 「まずここを動かしてほしい」変数。うすいオレンジで光らせる。
     ★見た目だけ★（幅は増やさない）。グリッドの列幅が変わると、
     せまい画面で横スクロールが出てしまうため。 */
  var h = '<div class="vrow' + (vd.focus ? ' foc' : '') + '">' +
    '<span class="vlab">' + mathHtml(lab) + '</span>' +
    '<button class="stp" data-var="' + vd.k + '" data-dir="-1">−</button>' +
    '<span class="vval" data-vval="' + vd.k + '"></span>' +
    '<button class="stp" data-var="' + vd.k + '" data-dir="1">＋</button>';
  if (tag === 'a') {
    h += '<input type="range" class="vsl" data-vsl="' + vd.k + '" ' +
      'min="' + vd.min + '" max="' + vd.max + '" step="' + vd.step + '">';
  }
  return h + '</div>';
}

function varRowHtml(vd, tag) {
  var h = varCellsHtml(vd, tag);
  /* vd.hint … その変数が何を表すのかの説明。ラベルの「下」の行に小さく出す */
  if (vd.hint) h = '<div class="vwrap">' + h + '<div class="vhint">' + mathHtml(vd.hint) + '</div></div>';
  return h;
}

/* ★2列（2×2）に並べるときの組み立て★
   1行ぶん（左の変数の5マス → 右の変数の5マス → 左の説明 → 右の説明）の順に出す。
   こうすると grid の自動配置で
     1行目＝左の操作／右の操作、2行目＝左の説明（1〜5列）／右の説明（6〜10列）
   ときれいに並ぶ。説明を grid-column:1/-1 のままにすると行が折れて2列にならない。 */
function varsTwoColHtml(list) {
  var h = [], i;
  for (i = 0; i < list.length; i += 2) {
    var a = list[i], b2 = list[i + 1];
    h.push(varCellsHtml(a, 'a'));
    /* ★左の列と右の列のあいだのすきま（6列目）★
       この場所とりを出さないと、右の変数の1マス目がすきまの列に入ってしまう。 */
    h.push('<span class="vgap" aria-hidden="true"></span>');
    if (b2) h.push(varCellsHtml(b2, 'a'));
    else h.push('<div class="vrow vempty" aria-hidden="true"><span></span><span></span>' +
      '<span></span><span></span><span></span></div>');
    if (a.hint || (b2 && b2.hint)) {
      h.push('<div class="vhint vh2a">' + (a.hint ? mathHtml(a.hint) : '') + '</div>');
      h.push('<div class="vhint vh2b">' + (b2 && b2.hint ? mathHtml(b2.hint) : '') + '</div>');
    }
  }
  return h.join('');
}

/* 天体の凡例（1-1・1-4） */
function renderBodyLegend(d, s) {
  var el = $('plegend');
  if (!el) return;
  var list = d.legendBodies(V(s), s) || [];
  el.innerHTML = list.map(function (b) {
    return '<span><i style="background:' + b.col + '"></i>' + b.name + '</span>';
  }).join('');
}

/* 詳しい解説（ページの下・矢印の凡例の上） */
function renderLong(d) {
  var box = $('longbox');
  if (!box) return;
  if (!d.long) { box.style.display = 'none'; box.innerHTML = ''; return; }
  box.style.display = '';
  box.innerHTML = d.long;
  renderMath(box);
  refitFormulas();
}

/* ===== 再生ボタン ===== */
function onPlay() {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  var T = d.tEnd(V(s), s);
  if (s.t >= T - 1e-9) s.t = 0;
  s.playing = !s.playing;
  setPlayLabel();
  renderActive();
}

/* 図の左上のオレンジのボタンのクラスを決める。
   ★作るとき（topActsHtml）と、毎コマ直すとき（refreshActs）で必ず同じにすること★
   ばらばらだと、1コマ目で光ったボタンが次のコマで消える、といったちらつきが出る。 */
function tactCls(a, v, s, on) {
  var c = a.is ? (on ? 'on' : '') : (a.prim ? 'prim' : '');
  /* ★twrap★ ページ全体の外わくが .wrap なので、同じ名前を使ってはいけない */
  if (a.wrap) c += (c ? ' ' : '') + 'twrap';
  if (a.glow && a.glow(v, s)) c += (c ? ' ' : '') + 'tglow';
  return c;
}

/* いまの状態がすでに条件を満たしているボタンを、少し濃く見せる */
function refreshActs() {
  var d = DEFS[st.cur], s = st.sims[st.cur], v = V(s);
  (d.actions || []).forEach(function (a, i) {
    var b = $('act_' + i);
    if (!b) return;
    var on = a.is ? !!a.is(v, s) : false;
    setCls(b, 'warm' + (a.alt ? ' alt' : '') + (on ? ' on' : ''));
  });
  (d.topActions || []).forEach(function (a, i) {
    var b = $('tact_' + i);
    if (!b) return;
    var on = a.is ? !!a.is(v, s) : false;
    setCls(b, tactCls(a, v, s, on));
    var ds = !!(a.dis && a.dis(v, s));
    if (b.disabled !== ds) b.disabled = ds;
    if (typeof a.label === 'function') setText(b, a.label(v, s));
  });
}

/* ===== 解説から「計算結果を表示」の数字へ飛ぶ =====
   ★毎フレーム描き直すので、DOM に直接クラスをつけても消えてしまう★
   光らせたいキーを st.flashRes にもっておき、renderResult がそれを見てクラスをつける。 */
function jumpToRes(key) {
  var host = $('resbar');
  if (!host) return;
  /* ★光らせたままにする★ 数秒で消すと「どれのことか分からない」ので、
     つぎのリンクが押されるまで、ずっと強調しつづける（先生の指示）。 */
  st.flashRes = key;
  renderResult(DEFS[st.cur], st.sims[st.cur], st.sims[st.cur].t);
  var hit = host.querySelector('.ritem.flash');
  if (hit && hit.scrollIntoView) hit.scrollIntoView({ block: 'center', behavior: 'smooth' });
  else if (host.scrollIntoView) host.scrollIntoView({ block: 'center', behavior: 'smooth' });
}

/* 一瞬だけ枠を光らせる（DOM を作り直さないところで使う） */
function flashEl(el) {
  if (!el || !el.classList) return;
  el.classList.remove('elflash');
  void el.offsetWidth;
  el.classList.add('elflash');
  setTimeout(function () { el.classList.remove('elflash'); }, 1400);
}

/* ===== 「まだ閉じているグラフ」をまとめて開くボタン ===== */
function openAllLabel() {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  var closed = [];
  graphsOf(d, s).forEach(function (g) { if (!s.open[g.key]) closed.push(g.short || g.title); });
  if (!closed.length) return '最初の表示に戻す';
  return mathHtml(closed.join('・') + ' をまとめて開く');
}

function bigFmlLabel() { return st.bigFml ? '式をもとの大きさに' : '式を拡大'; }

function toggleBigFml() {
  st.bigFml = !st.bigFml;
  Array.prototype.forEach.call(document.querySelectorAll('#simhost .gbody'), function (b) {
    b.className = b.className.replace(' bigf', '') + (st.bigFml ? ' bigf' : '');
  });
  var bt = $('bBigFml');
  if (bt) { bt.textContent = bigFmlLabel(); bt.className = st.bigFml ? '' : 'sub'; }
  refitFormulas();
}

function toggleAllGraphs() {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  var closed = graphsOf(d, s).some(function (g) { return !s.open[g.key]; });
  /* 見えていないグラフも一緒に開閉する（選択を変えても状態が続くように） */
  (d.graphs || []).forEach(function (g) { s.open[g.key] = closed ? true : !!g.open; });
  graphsOf(d, s).forEach(function (g) {
    var body = $('gb_' + g.key), head = $('simhost').querySelector('.ghead[data-g="' + g.key + '"]');
    if (body) body.className = 'gbody' + (s.open[g.key] ? '' : ' hide') + (st.bigFml ? ' bigf' : '');
    if (head) head.querySelector('.tri').textContent = s.open[g.key] ? '▼' : '▶';
  });
  if ($('bOpenAll')) { $('bOpenAll').innerHTML = openAllLabel(); renderMath($('bOpenAll')); }
  renderActive();
}

/* ===== グラフのドラッグ（移動・軸の拡大縮小） ===== */
function attachGraphDrag(cv, key) {
  if (!cv) return;
  var drag = null;
  function local(e) {
    var mp = cv._map, r = cv.getBoundingClientRect();
    return { x: (e.clientX - r.left) / r.width * mp.W, y: (e.clientY - r.top) / r.height * mp.H };
  }
  function cur() {
    var s = st.sims[st.cur];
    if (s.gview[key]) return s.gview[key];
    var mp = cv._map;
    return { xmin: mp.xmin, xmax: mp.xmax, ymin: mp.ymin, ymax: mp.ymax };
  }
  cv.addEventListener('pointerdown', function (e) {
    if (!cv._map) return;
    var p = local(e), mp = cv._map;
    var mode = 'pan';
    if (p.x < mp.pad.l) mode = 'sy';
    else if (p.y > mp.pad.t + mp.gh) mode = 'sx';
    drag = { p: p, view: cur(), mode: mode };
    cv.setPointerCapture(e.pointerId);
    e.preventDefault();
  });
  cv.addEventListener('pointermove', function (e) {
    if (!drag || !cv._map) return;
    var s = st.sims[st.cur], mp = cv._map, p = local(e);
    var dx = p.x - drag.p.x, dy = p.y - drag.p.y, v0 = drag.view, nv;
    if (drag.mode === 'pan') {
      var kx = (v0.xmax - v0.xmin) / mp.gw, ky = (v0.ymax - v0.ymin) / mp.gh;
      nv = { xmin: v0.xmin - dx * kx, xmax: v0.xmax - dx * kx, ymin: v0.ymin + dy * ky, ymax: v0.ymax + dy * ky };
    } else if (drag.mode === 'sx') {
      var f = Math.exp(-dx / 110), c = (v0.xmin + v0.xmax) / 2, hh = (v0.xmax - v0.xmin) / 2 * f;
      nv = { xmin: c - hh, xmax: c + hh, ymin: v0.ymin, ymax: v0.ymax };
    } else {
      var f2 = Math.exp(dy / 110), c2 = (v0.ymin + v0.ymax) / 2, h2 = (v0.ymax - v0.ymin) / 2 * f2;
      nv = { xmin: v0.xmin, xmax: v0.xmax, ymin: c2 - h2, ymax: c2 + h2 };
    }
    s.gview[key] = nv;
    renderActive();
    e.preventDefault();
  });
  function end() { drag = null; }
  cv.addEventListener('pointerup', end);
  cv.addEventListener('pointercancel', end);
  cv.addEventListener('wheel', function (e) {
    if (!cv._map) return;
    var s = st.sims[st.cur], mp = cv._map, p = local(e), v0 = cur();
    var f = Math.exp(e.deltaY * 0.0014);
    var px = v0.xmin + (p.x - mp.pad.l) / mp.gw * (v0.xmax - v0.xmin);
    var py = v0.ymax - (p.y - mp.pad.t) / mp.gh * (v0.ymax - v0.ymin);
    s.gview[key] = {
      xmin: px - (px - v0.xmin) * f, xmax: px + (v0.xmax - px) * f,
      ymin: py - (py - v0.ymin) * f, ymax: py + (v0.ymax - py) * f
    };
    renderActive();
    e.preventDefault();
  }, { passive: false });
  cv.addEventListener('dblclick', function () {
    delete st.sims[st.cur].gview[key];
    renderActive();
  });
}

/* ===== 本体キャンバスのクリック・ドラッグ（天体を選ぶ・小球を置く） ===== */
/* ===== 3次元の図をドラッグで見回す（2-1 のすりばち）=====
   姉妹ページ（basics-of-motion-on-plane）の 4-3 と同じ操作にそろえてある。
   ドラッグで向きを変え、ホイールで拡大縮小。仰角 el は 0〜88°（0 が真横）。 */
/* ★canvas は使いまわすので、登録は1回だけ★
   そのかわり、中では「いまのシム」を毎回引きなおすこと（引数で受けとらない）。
   いまのシムにその機能（drag3d / drag）がなければ、何もしないで返る。 */
function attach3dDrag() {
  var cv = $('mainCv'), last = null;
  if (!cv) return;
  /* 1枚の canvas を上下2つの絵に分けて使っているシム（2-1）では、
     ★下（3次元の図）だけをドラッグで回す★。上（軌道の絵）は d.drag にゆずる。
     d.drag3dFrom に「この y より下だけ」を書く（canvas の論理座標）。 */
  function on3d() {
    var d = DEFS[st.cur], s = st.sims[st.cur];
    return (d && d.drag3d && s && s.cam) ? { d: d, s: s } : null;
  }
  function inZone(ev, c) {
    if (c.d.drag3dFrom === undefined) return true;
    /* ★drag3dFrom は関数でもよい★（4-5 は並べ方で 3次元の段の高さが変わる） */
    var lim = (typeof c.d.drag3dFrom === 'function') ? c.d.drag3dFrom(c.s) : c.d.drag3dFrom;
    var r = cv.getBoundingClientRect();
    var ly = (ev.clientY - r.top) / r.height * (cv._ch || chOf(c.d, c.s));
    return ly >= lim;
  }
  cv.addEventListener('pointerdown', function (ev) {
    var c = on3d();
    if (!c || !inZone(ev, c)) return;
    last = { x: ev.clientX, y: ev.clientY };
    cv.setPointerCapture(ev.pointerId); ev.preventDefault();
  });
  cv.addEventListener('pointermove', function (ev) {
    var c = on3d();
    if (!c || !last) return;
    var dx = ev.clientX - last.x, dy = ev.clientY - last.y;
    last = { x: ev.clientX, y: ev.clientY };
    c.s.cam.az = (c.s.cam.az - dx * 0.32 + 540) % 360 - 180;
    c.s.cam.el = clamp(c.s.cam.el - dy * 0.26, 0, 90);   /* 90° ＝ 完全に真上 */
    renderActive(); ev.preventDefault();
  });
  function end() { last = null; }
  cv.addEventListener('pointerup', end);
  cv.addEventListener('pointercancel', end);
  cv.addEventListener('wheel', function (ev) {
    var c = on3d();
    if (!c || !inZone(ev, c)) return;
    c.s.cam.zoom = clamp(c.s.cam.zoom * Math.exp(-ev.deltaY * 0.0012), 0.5, 3.0);
    renderActive(); ev.preventDefault();
  }, { passive: false });
}

/* ===== YouTube の動画（押してから読みこむ）=====
   ★このページは「完全オフラインで動く単一 HTML」★（いちばん大事な決まり）
     なので、ページを開いただけで YouTube を読みにいってはいけない。
     ふだんは自前の「▶ 動画を見る」の板だけを出しておき、
     ★押されたときにはじめて iframe を作る★（これで外部リクエストは 0 のまま）。
   ・youtube-nocookie.com を使う（学校で使うので、追跡クッキーを置かせない）
   ・学校のネットで iframe がふさがれていることもあるので、
     「YouTube で開く」のふつうのリンクも必ず添える。 */
function attachYt() {
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-yt]'), function (b) {
    b.addEventListener('click', function () {
      var id = b.getAttribute('data-yt'), box = b.parentNode;
      var f = document.createElement('iframe');
      f.className = 'ytframe';
      f.src = 'https://www.youtube-nocookie.com/embed/' + id + '?rel=0&modestbranding=1';
      f.title = b.getAttribute('data-yttitle') || 'YouTube';
      f.setAttribute('allow', 'accelerometer; encrypted-media; gyroscope; picture-in-picture');
      f.setAttribute('allowfullscreen', '');
      f.setAttribute('referrerpolicy', 'strict-origin-when-cross-origin');
      box.replaceChild(f, b);
    });
  });
}

/* ===== 図の中に置いたボタン（キャンバスのボタン）=====
   ★ふつうは HTML の <button> を使うこと★
   図の右上のように「絵の一部として置きたい」ボタンだけ、ここで受ける。
   def に cvHits(s, W, H) を書くと、[{x, y, w, h, fn}] の四角を返せる。
   いまは 4-5 の「拡大スイッチ」だけが使っている。
   ★ドラッグ（d.drag）とは別のしくみ★ ドラッグするシムでは cvHits を書かないこと。 */
function attachCvHits() {
  var cv = $('mainCv');
  if (!cv) return;
  function pick(ev) {
    var d = DEFS[st.cur], s = st.sims[st.cur];
    if (!d || !d.cvHits || !s) return null;
    var r = cv.getBoundingClientRect();
    if (!r.width || !r.height) return null;
    var lx = (ev.clientX - r.left) / r.width * cwOf(d, s);
    var ly = (ev.clientY - r.top) / r.height * (cv._ch || chOf(d, s));
    var hits = d.cvHits(s, cwOf(d, s), chOf(d, s)) || [], i, h;
    for (i = 0; i < hits.length; i++) {
      h = hits[i];
      if (lx >= h.x && lx <= h.x + h.w && ly >= h.y && ly <= h.y + h.h) return h;
    }
    return null;
  }
  /* ★ドラッグしたあとの click では押さない★
     3次元の図をぐるぐる回してから指を離した場所が、たまたまボタンの上だと
     押したつもりがないのに切りかわってしまう。 */
  var down = null;
  cv.addEventListener('pointerdown', function (ev) { down = { x: ev.clientX, y: ev.clientY }; });
  cv.addEventListener('click', function (ev) {
    var moved = down && Math.hypot(ev.clientX - down.x, ev.clientY - down.y) > 6;
    down = null;
    if (moved) return;
    var h = pick(ev);
    if (!h) return;
    h.fn(st.sims[st.cur]);
    renderActive();
  });
  /* 押せる場所では指のかたちにする（どこが押せるか分かるように） */
  cv.addEventListener('pointermove', function (ev) {
    var d = DEFS[st.cur];
    if (!d || !d.cvHits) return;
    var want = pick(ev) ? 'pointer' : '';
    if (cv.style.cursor !== want) cv.style.cursor = want;
  });
}

function attachSimDrag() {
  var cv = $('mainCv'), dragging = false;
  if (!cv) return;
  function onDrag() {
    var d = DEFS[st.cur], s = st.sims[st.cur];
    return (d && d.drag && s) ? { d: d, s: s } : null;
  }
  function toWorld(ev, c) {
    var r = cv.getBoundingClientRect();
    var lx = (ev.clientX - r.left) / r.width * cwOf(c.d, c.s);
    var ly = (ev.clientY - r.top) / r.height * (cv._ch || chOf(c.d, c.s));
    if (!c.s.view) return { x: 0, y: 0, lx: lx, ly: ly };
    return { x: c.s.view.invX(lx), y: c.s.view.invY(ly), lx: lx, ly: ly };
  }
  cv.addEventListener('pointerdown', function (ev) {
    var c = onDrag();
    if (!c) return;
    var w = toWorld(ev, c);
    if (c.d.dragDown && !c.d.dragDown(c.s, w.x, w.y, w.lx, w.ly)) return;
    dragging = true; cv.setPointerCapture(ev.pointerId);
    c.d.drag(c.s, w.x, w.y, w.lx, w.ly);
    if (!c.d.dragKeepT) resetSim();
    syncVarVals(); renderActive(); ev.preventDefault();
  });
  cv.addEventListener('pointermove', function (ev) {
    var c = onDrag();
    if (!c || !dragging) return;
    var w = toWorld(ev, c);
    c.d.drag(c.s, w.x, w.y, w.lx, w.ly);
    if (!c.d.dragKeepT) resetSim();
    syncVarVals(); renderActive(); ev.preventDefault();
  });
  function end() { dragging = false; }
  cv.addEventListener('pointerup', end);
  cv.addEventListener('pointercancel', end);
}

function setPlayLabel() {
  var s = st.sims[st.cur], b = $('bPlay');
  if (!b) return;
  b.disabled = false;
  b.className = '';
  b.textContent = s.playing ? '❚❚ 一時停止' : '▶ スタート';
}

function resetSim() {
  var s = st.sims[st.cur];
  s.t = 0; s.playing = false; s.gview = {};
  setPlayLabel();
}

/* スライダーなどから値を直接セットする */
function setVar(k, val) {
  var d = DEFS[st.cur], s = st.sims[st.cur], vd = null;
  (d.vars || []).forEach(function (x) { if (x.k === k) vd = x; });
  if (!vd) return;
  var nv = clamp(Math.round(val / vd.step) * vd.step, vd.min, vd.max);
  if (Math.abs(nv - s.v[k]) < 1e-9) return;
  s.v[k] = +nv.toFixed(6);
  if (!vd.keepT) resetSim();
  if (d.onVar) d.onVar(s, k);
  syncVarVals(); renderActive();
}

function stepVar(k, dir) {
  var d = DEFS[st.cur], s = st.sims[st.cur], vd = null;
  (d.vars || []).forEach(function (x) { if (x.k === k) vd = x; });
  if (!vd) return;
  var nv = s.v[k] + dir * vd.step;
  nv = clamp(Math.round(nv / vd.step) * vd.step, vd.min, vd.max);
  s.v[k] = +nv.toFixed(6);
  if (!vd.keepT) resetSim();
  if (d.onVar) d.onVar(s, k);
  syncVarVals(); renderActive();
}

function syncVarVals() {
  var d = DEFS[st.cur], s = st.sims[st.cur], host = $('simhost');
  if (!host) return;
  (d.vars || []).forEach(function (vd) {
    var txt = (vd.fmt ? vd.fmt(s.v[vd.k]) : fmt(s.v[vd.k], vd.dec)) + vd.unit;
    Array.prototype.forEach.call(host.querySelectorAll('[data-vval="' + vd.k + '"]'), function (el) {
      el.textContent = txt;
    });
    Array.prototype.forEach.call(host.querySelectorAll('[data-vsl="' + vd.k + '"]'), function (r) {
      if (+r.value !== s.v[vd.k]) r.value = s.v[vd.k];
    });
  });
}

/* ===== グラフを描く ===== */
/* 横軸は既定で t。g.xf(m,v,t) を書くと、r や a を横軸にできる。 */
function seriesPts(d, s, g, T) {
  var v = V(s);
  /* ★点の並びは「いまの時刻 t」によらない★（横軸が t のグラフでは、動くのはカーソルだけ）。
     だから、変数（v）と横軸の長さ（T）が同じなら、前の結果をそのまま使える。
     グラフを3つ開くと 1 フレームで 600 回ケプラー方程式を解くことになり、
     それだけでカクカクになる（先生の指摘）。ここで覚えておくのが効く。 */
  var sig = T + '|' + JSON.stringify(v) + '|' + (s.pick || '');
  if (!s._pts) s._pts = {};
  var c = s._pts[g.key];
  if (c && c.sig === sig) return c.pts;
  var N = g.N || 200, out = [], i;
  g.series.forEach(function () { out.push([]); });
  for (i = 0; i <= N; i++) {
    var t = T * i / N;
    var m = d.sample(v, t, s);
    var x = g.xf ? g.xf(m, v, t) : t;
    g.series.forEach(function (se, j) { out[j].push([x, se.f(m, v, t)]); });
  }
  s._pts[g.key] = { sig: sig, pts: out };
  return out;
}

function renderGraphs(d, s, T, t) {
  var v = V(s), m = d.sample(v, t, s);
  graphsOf(d, s).forEach(function (g) {
    if (!s.open[g.key]) return;
    var cv = $('gc_' + g.key);
    if (!cv) return;
    var spec;
    if (g.custom) {
      spec = g.custom(v, s, t) || {};
    } else {
      var pts = seriesPts(d, s, g, T);
      var lo = Infinity, hi = -Infinity, xlo = Infinity, xhi = -Infinity;
      pts.forEach(function (p) {
        p.forEach(function (q) {
          if (isFinite(q[1])) { lo = Math.min(lo, q[1]); hi = Math.max(hi, q[1]); }
          if (isFinite(q[0])) { xlo = Math.min(xlo, q[0]); xhi = Math.max(xhi, q[0]); }
        });
      });
      if (!isFinite(lo)) { lo = -1; hi = 1; }
      /* 距離や速さのように「負にならない量」は、軸を 0 から始める。
         λ のように 0 のまわりを見てもしかたない量は zero:false で範囲を自由にする。 */
      var r = (g.zero === false) ? niceRangeFree(lo, hi) : niceRange(lo, hi);
      if (g.zero !== false && lo >= -1e-12) r.lo = 0;
      var rx = g.xf ? niceRange(xlo, xhi) : { lo: 0, hi: Math.max(0.2, T) * 1.04 };
      if (g.xf && xlo >= -1e-12) rx.lo = 0;
      if (g.xzero === false) { rx = niceRangeFree(xlo, xhi); }
      spec = {
        xmin: rx.lo, xmax: rx.hi, ymin: r.lo, ymax: r.hi,
        series: g.series.map(function (se, j) { return { color: se.color, dash: se.dash, width: se.width, pts: pts[j] }; }),
        cursors: g.series.map(function (se) {
          return { color: se.color, x: g.xf ? g.xf(m, v, t) : t, y: se.f(m, v, t) };
        }),
        legend: g.legend ? g.series.map(function (se) { return { name: se.name, color: se.color }; }) : null
      };
    }
    /* custom グラフで legend:true と書いたら、系列の name から凡例を作る */
    if (spec.legend === true) {
      spec.legend = (spec.series || []).filter(function (se) { return !!se.name; })
        .map(function (se) { return { name: se.name, color: se.color }; });
    }
    /* 軸の名前は関数にもできる（描画対象で単位が 年 ⇔ 時間 と変わる 1-1〜1-4 で使う） */
    function axLab(x) { return (typeof x === 'function') ? x(v, s) : x; }
    spec.xlabel = spec.xlabel || axLab(g.xlabel) || axLab(d.xlabel) || 't';
    spec.ylabel = spec.ylabel || axLab(g.ylabel) || '';
    spec.view = s.gview[g.key];
    if (g.H) spec.H = g.H;          /* そのグラフだけ縦を高くしたいとき */
    plot(cv, spec);
  });
}

/* 式の欄（3段）の組みあがりを、式の並びごとに覚えておく入れもの */
var FMLC = {}, FMLC_N = 0;

/* 各グラフの右に出す3段の式 */
function renderFormulas(d, s) {
  graphsOf(d, s).forEach(function (g) {
    if (!g.fml || !s.open[g.key]) return;
    var box = $('gf_' + g.key);
    if (!box) return;
    var arr = g.fml(V(s), s);
    var key = arr.join('|');
    /* ★★ここで幅（clientWidth）を読んではいけない★★
       すぐ前で buildPanel() が #simhost をまるごと書きかえているので、
       いま幅を読むと<b>ページ全体のレイアウトを計算し直す</b>ことになる
       （強制同期レイアウト）。グラフ3枚で 30 ms——タブを押すと固まって見える原因。
       幅が要るのは「はみ出した式を縮める」ときだけなので、
       それは fitFormula() が つぎのフレームに（レイアウトが済んでから）読む。 */
    if (box._key === key) return;
    box._key = key;
    /* ★箱まるごとの HTML を覚えておく★
       タブを移ると <div id="gf_…"> は作り直されるので、前は毎回
       「3行ぶんの KaTeX を組む → innerHTML を9回書く」をやっていた（1枚 10 ms 以上）。
       式の並びが同じなら組みあがりも同じなので、文字列ごと覚えて1回で入れる。 */
    var html = FMLC[key];
    if (html === undefined) {
      if (FMLC_N > 400) { FMLC = {}; FMLC_N = 0; }
      var names = ['公式', '代入', '数値'];
      html = arr.map(function (x, i) {
        return '<div class="fl f' + (i + 1) + '"><span class="fk">' + (names[i] || '') +
          '</span><span class="fv"><span class="tex" data-done="1">' + texHtml(x) +
          '</span></span></div>';
      }).join('');
      FMLC[key] = html; FMLC_N++;
    }
    box.innerHTML = html;
    /* ★ここで fitFormula を呼ばない★ 直前に innerHTML を書きかえたばかりなので、
       いま幅を読むと必ず強制レイアウトになる。つぎのフレーム（ブラウザが自然に
       レイアウトし終わったあと）に1回だけ縮める。 */
    if (!box._fitQ) {
      box._fitQ = true;
      requestAnimationFrame(function () { box._fitQ = false; fitFormula(box); });
    }
  });
}

/* 式がはみ出すときは、切らずに縮めて全部見せる */
/* 式がはみ出すときは、切らずに縮めて全部見せる。
   ★★「幅を読む」と「縮める」を、はっきり2つに分けること★★
   前は1行ごとに 読む→書く→読む→書く…としていたので、
   式の行の数だけブラウザがレイアウトを計算し直していた（強制同期レイアウト）。
   グラフ3枚＝9行なら9回。タブを移るたびにこれが走るので、実機では固まって見える。
   → ①ぜんぶ読む ②ぜんぶ書く、の2段にすると、レイアウトは1回で済む。 */
function fitFormula(box) {
  var list = box.querySelectorAll('.fv'), i, jobs = [];
  /* ── ① 読むだけ（ここでは1文字も書かない） ── */
  for (i = 0; i < list.length; i++) {
    var fv = list[i], inner = fv.firstElementChild;
    if (!inner) continue;
    var k = inner._k || 1;
    var w = inner.getBoundingClientRect().width / k;
    var avail = fv.clientWidth;
    if (avail < 20 || w < 1) continue;
    var nk = (w > avail) ? Math.max(0.5, (avail - 3) / w) : 1;
    if (Math.abs(nk - k) > 0.004) jobs.push({ el: inner, k: nk });
  }
  /* ── ② 書くだけ ── */
  for (i = 0; i < jobs.length; i++) {
    jobs[i].el._k = jobs[i].k;
    jobs[i].el.style.transform = jobs[i].k < 1 ? 'scale(' + jobs[i].k.toFixed(3) + ')' : '';
  }
}
function refitFormulas() {
  Array.prototype.forEach.call(document.querySelectorAll('.gform'), function (b) { b._key = null; });
  renderActive();
}

/* ===== 単位のことわり（計算結果の帯のすぐ下）=====
   AU や 太陽質量 は、生徒が教科書で見たことのない単位なので、
   その単位を使っているシミュレーションでだけ、短い説明を出す。
   def に d.units = ['AU','Msun'] のように書く（関数にすると、
   「太陽と惑星／地球と人工衛星」の切りかえで出し分けられる）。 */
var UNIT_NOTE = {
  AU: '<b>AU（天文単位）</b>…太陽と地球の平均の距離を 1 とする長さの単位。' +
    '<b>1 AU ＝ 約 1.496×10⁸ km</b>（約 1億5000万 km）。' +
    '太陽系の中の距離を km で書くとけたが大きすぎるので、この単位を使う。',
  Msun: '<b>太陽質量</b>…太陽の質量を 1 とする質量の単位。' +
    '<b>1 太陽質量 ＝ 約 1.99×10³⁰ kg</b>（地球の約 33万倍）。' +
    '天体の質量を kg で書くとけたが大きすぎるので、この単位を使う。',
  Mearth: '<b>地球質量</b>…地球の質量を 1 とする質量の単位。' +
    '<b>1 地球質量 ＝ 約 5.97×10²⁴ kg</b>。',
  year: '<b>年</b>…1 年 ＝ 約 3.156×10⁷ s（約 3160万秒）。'
};
function unitNoteHtml(d, s) {
  var list = (typeof d.units === 'function') ? d.units(V(s)) : d.units;
  if (!list || !list.length) return '';
  var rows = list.map(function (k) {
    return UNIT_NOTE[k] ? ('<li>' + UNIT_NOTE[k] + '</li>') : '';
  }).join('');
  if (!rows) return '';
  return '<div class="unitnote"><b class="unt">この図で使っている単位</b><ul>' + rows + '</ul></div>';
}

/* ===== 計算結果の帯 ===== */
function renderResult(d, s, t) {
  var el = $('resbar');
  if (!el || !d.result) return;
  var r = d.result(V(s), s, t) || {};
  var items = r.items || [], i;

  /* ★★この関数は1秒に60回走る★★
     前は「値まで入れた HTML 全体」をキャッシュのキーにしていたので、
     値が 1 つでも変われば innerHTML を作り直して KaTeX を組みなおしていた。
     ＝ 実質「毎フレーム KaTeX」。項目が 10 個ある画面（1-4 など）では、
     これだけでページ全体がカクカクになる（先生の指摘）。
     → ★「文字（ラベル）の並び」が変わったときだけ作り直す★。
       ふだんは <span class="rv"> の中の文字だけ差しかえる（KaTeX は走らない）。 */
  var keys = items.map(function (it) {
    return rkey(it.k) + '\u0001' + it.k + '\u0001' + (it.kbox ? '1' : '');
  }).join('\u0002') + '\u0003';
  if (r.table) {
    /* 表は「見出し」と「1列目（天体の名前）」だけが文字。ほかは数値なので入れかえるだけ */
    keys += r.table.head.join('\u0001') + '\u0002' + r.table.kcol + '\u0002'
      + r.table.rows.map(function (row) { return row[0]; }).join('\u0001');
  }

  if (el._keys !== keys) {
    var h = ['<p class="rtitle">計算結果を表示</p><div class="rrow">'];
    items.forEach(function (it) {
      /* data-rk … 解説の @@r:…@@ から飛んでくるための目じるし */
      h.push('<div class="ritem' + (it.kbox ? ' kbox' : '') + '" data-rk="' + rkey(it.k) +
        '"><span class="rk">' + mathHtml(it.k) + '</span><span class="rv"></span></div>');
    });
    h.push('</div>');
    if (r.table) {
      /* 表が広いときは、ページごと横スクロールさせずに、表の中だけをスクロールさせる */
      h.push('<div class="ktabwrap"><table class="ktab"><tr>');
      r.table.head.forEach(function (x, i2) {
        h.push('<th class="' + (i2 === r.table.kcol ? 'kcol num' : (i2 ? 'num' : '')) + '">' + x + '</th>');
      });
      h.push('</tr>');
      r.table.rows.forEach(function (row) {
        h.push('<tr>');
        row.forEach(function (x, i2) {
          h.push('<td class="' + (i2 === 0 ? 'nm' : (i2 === r.table.kcol ? 'kcol num' : 'num')) + '">'
            + (i2 === 0 ? x : '') + '</td>');
        });
        h.push('</tr>');
      });
      h.push('</table></div>');
    }
    h.push('<p class="knote"></p>');
    el.innerHTML = h.join('');
    el._keys = keys; el._flash = null; el._note = null;
    renderMath(el);
  }

  /* 光らせる印（@@r:…@@ の飛び先）は、クラスの付けはずしだけ。作り直さない */
  if (el._flash !== st.flashRes) {
    el._flash = st.flashRes;
    Array.prototype.forEach.call(el.querySelectorAll('.ritem'), function (e2) {
      var kk = e2.getAttribute('data-rk') || '';
      var on = !!(st.flashRes && kk.indexOf(st.flashRes) >= 0);
      if (on) e2.classList.add('flash'); else e2.classList.remove('flash');
    });
  }

  /* ここからが毎フレームの仕事。文字を入れかえるだけなので速い */
  var rvs = el.querySelectorAll('.ritem .rv');
  for (i = 0; i < items.length; i++) setText(rvs[i], items[i].v);
  if (r.table) {
    var tds = el.querySelectorAll('.ktab td'), n = 0;
    r.table.rows.forEach(function (row) {
      row.forEach(function (x, i2) {
        if (i2 > 0) setText(tds[n], x);
        n++;
      });
    });
  }

  /* 帯の下の一言。数式を含むことがあるので、ここだけ別にキャッシュする */
  var nb = el.querySelector('.knote');
  if (nb) {
    var nh = r.note ? mathHtml(r.note) : '';
    if (el._note !== nh) {
      el._note = nh;
      nb.innerHTML = nh;
      nb.style.display = nh ? '' : 'none';
      if (nh) renderMath(nb);
    }
  }
}

function renderReadout(d, s, t) {
  var el = $('readout');
  if (!el || !d.info) return;
  var rows = d.info(s, t), i;
  var keys = rows.map(function (r) { return r[0]; }).join('|');
  if (el._keys !== keys) {
    el.innerHTML = rows.map(function (r) {
      return '<tr><td class="k">' + mathHtml(r[0]) + '</td><td class="v"></td></tr>';
    }).join('');
    el._keys = keys;
    renderMath(el);
  }
  var tds = el.querySelectorAll('td.v');
  for (i = 0; i < rows.length; i++) setText(tds[i], rows[i][1]);
}

function renderEq(d, s) {
  var el = $('eqbox');
  if (!el || !d.eq) return;
  var src = d.eq(s);
  if (src === s._eq) return;
  s._eq = src;
  el.textContent = '';
  if (window.katex) {
    try { window.katex.render(src, el, { throwOnError: false, displayMode: false }); }
    catch (e) { el.textContent = src; }
  } else el.textContent = src;
}

/* ===== 画面のはば =====
   ★毎コマ window.innerWidth を読んではいけない★
     読むたびにブラウザがレイアウトを計算し直すので、アニメーションが重くなる
     （→ ハマったところ 93）。最初と、大きさが変わったときだけ覚え直す。
   4-5 が「3つの図を よこ一列 に並べるか たて一列 にするか」を、この値で決めている。 */
var WINW = (typeof window !== 'undefined' && window.innerWidth) || 1280;
function noteWinW() { WINW = window.innerWidth || WINW; }

/* キャンバスの大きさ（def の cw・ch はどちらも関数でよい）。
   ★関数にすると、画面のはばで図の並べ方を変えられる★（4-5） */
function cwOf(d, s) {
  return (typeof d.cw === 'function') ? Math.round(d.cw(V(s), s)) : d.cw;
}
function chOf(d, s) {
  return (typeof d.ch === 'function') ? Math.round(d.ch(V(s), s)) : d.ch;
}

function renderActive() {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  var cv = $('mainCv');
  if (!cv) return;
  var v = V(s);
  /* ★tEnd / rate / sample には s も渡す★
     3-3 のように「プルダウンの選び方で周期そのものが変わる」シムがあるため。
     ほかのシムは 2 つめの引数を見ないので、そのままで動く。 */
  var T = d.tEnd(v, s);
  if (s.t > T) s.t = T;
  var ch = chOf(d, s), cw = cwOf(d, s);
  cv._ch = ch; cv._cw = cw;
  var ctx = prep(cv, cw, ch);
  ctx.save();
  ctx.beginPath(); ctx.rect(0, 0, cw, ch); ctx.clip();
  d.draw(ctx, s, s.t, cw, ch);
  drawEqualTicks(ctx);                       /* 同じ大きさの力・速度に「｜」印 */
  ctx.restore();
  /* 見るポイントの上に置く図（2-3 の静止軌道の見取り図） */
  if (d.sideTop) {
    var tcv = $('sideTopCv');
    if (tcv) {
      var tctx = prep(tcv, d.sideTop.w, d.sideTop.h);
      tctx.save();
      tctx.beginPath(); tctx.rect(0, 0, d.sideTop.w, d.sideTop.h); tctx.clip();
      d.sideTop.draw(tctx, s, s.t, d.sideTop.w, d.sideTop.h);
      tctx.restore();
    }
  }
  /* 右の列の2つ目の図（1-2 の楕円の定義・1-6 の地動説と天動説） */
  if (d.side) {
    var scv = $('sideCv');
    if (scv) {
      var sctx = prep(scv, d.side.w, d.side.h);
      sctx.save();
      sctx.beginPath(); sctx.rect(0, 0, d.side.w, d.side.h); sctx.clip();
      d.side.draw(sctx, s, s.t, d.side.w, d.side.h);
      sctx.restore();
    }
  }
  var Tg = d.tGraph ? d.tGraph(V(s)) : T;
  /* ★再生中は、グラフの描き直しを 30 回/秒までにする★
     グラフで毎フレーム変わるのは「いまの位置」の点と縦線だけ。
     それでも canvas は全部描き直すことになるので、開いているグラフの枚数だけ
     描画の仕事が増える。30 回/秒なら点の動きは目で見て同じで、仕事は半分になる。
     ★止まっているとき（スクラブ・一時停止・自動テスト）は必ず描き直す★ので、
     テストの再現性はこわれない。 */
  var gnow = (window.performance && performance.now) ? performance.now() : Date.now();
  if (!s.playing || gnow - (st._gTs || 0) >= 30) {
    st._gTs = gnow;
    renderGraphs(d, s, Tg, Math.min(s.t, Tg));
  }
  renderFormulas(d, s);
  refreshActs();
  renderResult(d, s, s.t);
  renderReadout(d, s, s.t);
  renderEq(d, s);
  if (d.legendBodies) renderBodyLegend(d, s);
  var bar = $('tBar');
  if (bar) {
    /* ★けた数は tEnd の大きさに合わせる★
       いつも toFixed(3) にしていたので、tEnd が 0.00045 秒（4-3 のブラックホール）の
       ようなシムでは max が "0.000" になり、時間のバーがまったく動かなかった。 */
    var dec = clamp(3 - Math.floor(Math.log(Math.max(1e-12, T)) / Math.LN10), 3, 18);
    var mx = T.toFixed(dec);
    if (bar.max !== mx) { bar.max = mx; bar.step = (T / 1000).toFixed(Math.min(20, dec + 3)); }
    var bv = s.t.toFixed(dec);
    if (bar.value !== bv) bar.value = bv;
    setText($('tVal'), d.tFmt ? d.tFmt(s.t, v) : (fmt(s.t, 2) + ' 年'));
  }
}

/* ===== .tex の中身を KaTeX で組む =====
   ★★組みあがった HTML を式ごとに覚えておいて、2回目からは使い回す★★
   タブを移るたびに `buildPanel()` が #simhost を作り直すので、
   1-4 のように式が 67 個ある画面では、切りかえのたびに 67 個組み直していた。
   KaTeX は1個 0.5〜1 ms かかるので、これだけで切りかえに数十〜数百 ms。
   実機では「タブを押すと固まる」と感じる（先生の指摘）。
   同じ文字列なら組みあがりも同じなので、覚えておけば安全に使い回せる。 */
var KTX = {}, KTX_N = 0;
/* 1つの式を組んだ HTML を返す（2回目からは覚えたものを返すだけ） */
function texHtml(src) {
  var got = KTX[src];
  if (got === undefined) {
    if (!window.katex) return escTex(src);
    /* 数値の入った式（グラフの「数値」の行など）は種類がふえつづけるので、
       ふえすぎたら覚えたものを捨てる。上限は多めにとってある。 */
    if (KTX_N > 900) { KTX = {}; KTX_N = 0; }
    var tmp = document.createElement('span');
    try { window.katex.render(src, tmp, { throwOnError: false }); got = tmp.innerHTML; }
    catch (e) { got = null; }
    KTX[src] = got; KTX_N++;
  }
  return (got === null) ? escTex(src) : got;
}
function renderMath(root) {
  if (!root || !window.katex) return;
  Array.prototype.forEach.call(root.querySelectorAll('.tex'), function (el) {
    if (el.getAttribute('data-done')) return;
    el.setAttribute('data-done', '1');
    el.innerHTML = texHtml(el.textContent);
  });
}

/* ===== 画面の切りかえ（ハッシュ #m1-3 で直接ひらける） ===== */
function hashOf() { return st.cur; }
function parseHash(h) {
  h = (h || '').replace('#', '');
  var i = h.indexOf('!');
  if (i < 0) i = h.indexOf('?');
  if (i >= 0) h = h.slice(0, i);
  return { id: h };
}
function syncHash() {
  var want = '#' + hashOf();
  if (location.hash !== want) {
    st._skipHash = true;
    location.hash = want;
  }
}

/* ★開いた瞬間から動かすシムがある★（先生の指示）
   def に autoplay: true と書くと、そのタブを開いた時点で再生が始まる。
   ケプラーの法則のシムは「まず動きを見る」のが出発点なので、
   スタートを押させる手間をなくしてある。
   ★テストからは TEST.goto() が必ず止めるので、自動テストの再現性はこわれない★ */
function autoPlayOn(id) {
  var d = DEFS[id], s = st.sims[id];
  if (!d || !s || !d.autoplay) return;
  s.t = 0; s.playing = true;
}
function gotoSim(id) {
  if (!DEFS[id]) return;
  st.flashRes = null;          /* シムを変えたら、強調はいったん消す */
  st.cur = id;
  autoPlayOn(id);
  buildTabs();
  buildPanel();
  renderActive();
  syncHash();
  renderLegend(DEFS[st.cur]);
}

/* ===== アニメーション ===== */
var lastTs = null;
function tick(ts) {
  var s = st.sims[st.cur], d = DEFS[st.cur];
  if (lastTs === null) lastTs = ts;
  /* ★時間の進みは「実時間そのもの」を使う★
     前は 0.033 秒（＝30 fps ぶん）で頭を打たせていたので、
     絵が重くて 15 fps しか出ない画面ではアニメーションが半分の速さになり、
     5 fps なら6倍おそくなってしまう（実際にそう見えていた）。
     ★このページは軌道を「閉じた式」で出しているので、1歩が大きくても計算はくるわない★
     （コマが飛んで見えるだけ）。だから頭打ちは「タブを裏にしていた」ときだけに効く
     0.25 秒にしておく。こうすると、おそい機械でも<b>速さは正しいまま</b>になる。 */
  var dt = clamp((ts - lastTs) / 1000, 0, 0.25);
  lastTs = ts;
  /* ★「スタートを押してから何秒たったか」をためておく★
     2-1（補足：ケプラー則の本質）で「2秒たってから帯を出す」ために使う。
     シムの時間 t ではなく〈実時間〉なので、シムごとの rate に左右されない。
     止めるたびに 0 に戻す＝押し直したら、また 2 秒後から。 */
  if (s) {
    if (s.playing) { s._run = (s._wasPlaying ? (s._run || 0) + dt : 0); }
    else { s._run = 0; }
    s._wasPlaying = !!s.playing;
  }
  if (s && s.playing) {
    var v = V(s);
    var T = d.tEnd(v, s);
    var rate = d.rate ? d.rate(v, s) : 1;       /* 1秒の実時間で進む「シムの時間」 */
    s.t = Math.min(T, s.t + dt * rate * (s.slow ? 0.25 : 1));
    if (s.t >= T - 1e-9) {
      /* d.loop は関数にもできる（2-1 の「初速度 0 のときだけ、くり返さない」） */
      var lp = (typeof d.loop === 'function') ? d.loop(v, s) : d.loop;
      if (lp) s.t = 0; else { s.playing = false; setPlayLabel(); }
    }
    renderActive();
  }
  requestAnimationFrame(tick);
}
