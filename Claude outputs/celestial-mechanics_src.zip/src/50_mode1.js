/* 1　ケプラーの法則 */
'use strict';

/* ===== モード1で共通に使う部品 ===== */

/* いま使っている単位系（太陽と惑星／地球と人工衛星） */
function sysOf(v) { return (v.sys === 'earth') ? SYS.earth : SYS.sun; }
/* 半長軸は単位系ごとに別の変数にしてある（AU と km で桁が違うため） */
function aOf(v) { return (v.sys === 'earth') ? v.aE : v.aS; }
/* いまの軌道 */
function orbOf(v) { return P.orb.make(aOf(v), v.e === undefined ? 0 : v.e, sysOf(v)); }

/* 時刻の書き方（太陽系は「年」、地球まわりは「時間」） */
function tText(v, t) {
  return (v.sys === 'earth') ? (fmt(t / 3600, 2) + ' 時間') : (fmt(t, 2) + ' 年');
}
function tUnit(v) { return (v.sys === 'earth') ? '時間' : '年'; }
/* グラフの横軸に出す時刻（地球まわりは時間に直す） */
function tPlot(v, t) { return (v.sys === 'earth') ? t / 3600 : t; }
function tPlotLabel(v) { return (v.sys === 'earth') ? 't [時間]' : 't [年]'; }

/* ===== 「太陽と惑星」⇔「地球と人工衛星」の切りかえ =====
   ★1-1〜1-4 で共通の1つの切りかえにしてある★（先生の指示）
   前はシムごとにプルダウンを置いていたので、タブを移るたびに選び直す必要があった。
   いまは st.sysKind ただ1つが正で、タイトルの横のボタンで切りかえる（d.sysToggle）。
   各シムの中では、これまでどおり v.sys / v.sys14 を見ればよい
   （applySysKind() が4つのシムぜんぶに同じ値を書きこむ）。 */
var SYS_SIMS = ['m1-2', 'm1-3', 'm1-4', 'm1-5'];
function applySysKind(kind) {
  st.sysKind = (kind === 'earth') ? 'earth' : 'sun';
  SYS_SIMS.forEach(function (id) {
    var s = st.sims[id];
    if (!s) return;
    s.o.sys = st.sysKind;
    s.o.sys14 = st.sysKind;      /* 1-3 だけ昔からのキー名を使っている */
    s.t = 0;                     /* 単位（年 ⇔ 時間）が変わるので、時刻は 0 に戻す */
  });
}
/* 半長軸の変数（単位系ごとに2本立て） */
/* 半長軸 a のスライドバー。
   ★はばを広くとりすぎないこと★ この図は縮尺を「いちばん大きい a」に固定してあるので
   （a を大きくすると絵もちゃんと大きくなるようにするため）、はばを広げると
   いちばん小さい a のときに絵が点のように小さくなってしまう。
   いまは「2倍強」までにしてある。 */
var A_MAX_S = 2.4, A_MIN_S = 1.4;
var A_MAX_E = 30000, A_MIN_E = 18000;
function aMaxOf(v) { return (v.sys === 'earth') ? A_MAX_E : A_MAX_S; }
function aVars(defAU, defKM) {
  return [
    {
      k: 'aS', label: '半長軸 $a$（太陽からの距離の目安）', unit: ' AU',
      min: A_MIN_S, max: A_MAX_S, step: 0.1, dec: 1, def: defAU,
      when: function (v) { return v.sys !== 'earth'; }
    },
    {
      k: 'aE', label: '半長軸 $a$（地球の中心からの距離）', unit: ' km',
      min: A_MIN_E, max: A_MAX_E, step: 1000, dec: 0, def: defKM,
      when: function (v) { return v.sys === 'earth'; }
    }
  ];
}

/* 中心の天体（太陽／地球）を描く */
function drawCenterBody(ctx, x, y, sys, rpx, name, spin) {
  if (sys.key === 'earth') {
    earthShape(ctx, x, y, rpx, spin || 0);
    label(ctx, name === undefined ? '地球' : name, x, y + rpx + 12,
      { size: 11.5, color: '#2a5f96', bold: true });
  } else {
    sunShape(ctx, x, y, rpx, name === undefined ? '太陽' : name);
  }
}

/* 楕円軌道1つぶんの座標系をつくる。焦点（中心の天体）が原点、近日点が +x。 */
function orbScene(W, H, o, pad) {
  pad = pad || { l: 46, r: 46, t: 34, b: 34 };
  var box = { x0: -o.ra, x1: o.rp, y0: -o.b, y1: o.b };
  var mx = (box.x1 - box.x0) * 0.06, my = (box.y1 - box.y0) * 0.10;
  box = { x0: box.x0 - mx, x1: box.x1 + mx, y0: box.y0 - my, y1: box.y1 + my };
  return mkView(W, H, pad, box);
}

/* 軌道の楕円を描く（焦点が原点） */
function drawOrbitEllipse(ctx, vw, o, col, dash, lw) {
  var i, pts = [], lo = 1e9, hi = -1e9;
  for (i = 0; i <= 240; i++) {
    var E = TAU * i / 240;
    var px = vw.X(o.a * (Math.cos(E) - o.e)), py = vw.Y(o.b * Math.sin(E));
    if (!isFinite(px) || !isFinite(py)) return;
    lo = Math.min(lo, px, py); hi = Math.max(hi, px, py);
    pts.push([px, py]);
  }
  /* ★安全弁★ 画面から桁ちがいにはみ出すだ円は描かない。
     単位を取りちがえる（AU の図に km の値を渡すなど）と、
     何十万 px のだ円を破線で描こうとして 1フレーム 200 ms かかり、
     アニメーションが「ものすごくおそい」状態になる（実際にそうなった）。
     ここで止めておけば、まちがえても画面が固まることはない。 */
  if (hi - lo > 40000) return;
  ctx.save();
  ctx.strokeStyle = col || COL.orbit; ctx.lineWidth = lw || 1.6;
  if (dash && dash.length) ctx.setLineDash(dash);
  ctx.beginPath();
  pts.forEach(function (p, i2) { if (i2 === 0) ctx.moveTo(p[0], p[1]); else ctx.lineTo(p[0], p[1]); });
  ctx.closePath(); ctx.stroke();
  ctx.restore();
}

/* 離心近点離角 E1〜E2 の扇形（頂点＝焦点）を塗る */
function drawSector(ctx, vw, o, E1, E2, col, alpha) {
  var pts = [], n = 40, i;
  for (i = 0; i <= n; i++) {
    var E = E1 + (E2 - E1) * i / n;
    pts.push([vw.X(o.a * (Math.cos(E) - o.e)), vw.Y(o.b * Math.sin(E))]);
  }
  sectorFill(ctx, vw.X(0), vw.Y(0), pts, col, alpha);
  return pts;
}

/* ============================================================
   1-1　太陽系の様子
   ============================================================ */
/* 再生の速さは「ゆっくり」を既定にする（スロー再生ボタンを押さなくても見やすい速さ） */
/* 再生の速さは「1秒間に 0.5 年」でそろえる（地球が回っているのが目で追える速さ）。
   外側まで出すときに水星を入れないのは、速すぎて点が飛んで見えるだけになるため。 */
/* 内側の4つは「スロー再生のさらに 0.75 倍」（0.5 × 0.25 × 0.75）でゆっくり見せる。
   水星がすぐ1周してしまい、目で追えなかったため。 */
var M11_VIEWS = {
  inner: { ids: ['mercury', 'venus', 'earth', 'mars'], tEnd: 4, rate: 0.09375, log: false },
  all: {
    ids: ['venus', 'earth', 'mars', 'jupiter', 'saturn', 'uranus', 'neptune', 'pluto', 'halley'],
    tEnd: 260, rate: 0.5, log: true
  }
};
function m11View(v) { return M11_VIEWS[v.view] || M11_VIEWS.inner; }
function m11Bodies(v) { return m11View(v).ids.map(planetById); }
/* いま出していない天体が選ばれたままにならないようにする（水星は外側の図に出ないため） */
function m11Pick(v) {
  var ids = m11View(v).ids, id = v.pick || 'earth';
  if (ids.indexOf(id) < 0) id = 'earth';
  return planetById(id);
}

DEFS['m1-1'] = {
  id: 'm1-1', mode: 1, tab: '1-0 太陽系の様子', autoplay: true,
  intro: true,
  units: ['AU'],                      /* 入り口のシム＝タブの色を法則のシムと変える */
  legendKeys: ['sun', 'orbit'],
  title: '1-0　太陽系の様子',
  sub: function (v) {
    var t = '惑星をクリックすると、その天体の<b>半長軸 a・周期 T・離心率 ε・K = T²/a³</b> が下の帯に出て、' +
      '<b>下の表の行</b>と <b>T–a 図</b>の点も いっしょに光ります' +
      '（<b>T–a 図の点をクリック</b>しても選べます）。' +
      'どの惑星でも <b>K がぴったりそろう</b>ことを確かめよう（＝ケプラーの第3法則）。<br>' +
      '地球から空を見上げたときの火星の見かけの動き（逆行）は、<b>「補足：地動説とケプラーの法則の歴史」</b>で見られます。';
    if (v.view === 'all') {
      t += '<br><b>【「対数のものさし」とは】</b>いまの図は、太陽からの距離を<b>対数のものさし</b>で縮めて描いています。' +
        'ふつうのものさしは「1 AU 増えるごとに同じ幅」ですが、対数のものさしは<b>「10倍になるごとに同じ幅」</b>。' +
        'つまり <b>1 → 10 → 100 AU</b> が同じ間隔になります。' +
        'そうしないと、冥王星（39 AU）に合わせたとたん地球（1 AU）が点になって見えなくなるからです。' +
        '<b>回る角度はそのまま</b>なので、「遠い天体ほどゆっくり」はこの図のまま読みとれます。';
    }
    return t;
  },
  /* このシムは「読み物」の入り口にする。
     見るポイント（note）と読み出しの表（info）は出さず、右の列は短い案内だけにする。
     歴史のコラムは「補足：地動説とケプラーの法則の歴史」へまとめて移した。 */
  sideText:
    '<span class="q">毎夜の惑星の観測から、宇宙の秘密が解き明かされていった</span>' +
    '左の図のような<b>惑星の動きを、先人たちが観測してまとめていった結果</b>として、' +
    '1-1 からの<b>ケプラーの第1〜第3法則</b>が発見されました。' +
    /* ★法則の3行と注は、四角で囲んでほかの文と区別する★（先生の指示） */
    '<div class="lawbox">' +
    '<ul class="lawlist">' +
    '<li><b>第1法則</b>　' + LAW.k1 + '</li>' +
    '<li><b>第2法則</b>　惑星と太陽を結ぶ線分が単位時間あたりに通過する面積は一定である</li>' +
    '<li><b>第3法則</b>　惑星の周期の2乗は半長軸の3乗に比例する</li>' +
    '</ul>' +
    '<p class="lawnote"><b>注</b>：現代では、惑星（＝太陽の周りをまわる天体）だけでなく' +
    '<b>人工衛星（＝地球の周りをまわる天体）にも成り立つ法則</b>であることが分かっています。' +
    'つまり、<b>「ある天体」が「かなり大きな質量を持つ天体」の周りをまわるときに' +
    '成り立つ法則</b>です。' +
    'シミュレーション 1-1 から 1-4 では、<b>右上の描画対象を選ぶスイッチ</b>で' +
    '<b>「太陽と惑星について」・「地球と人工衛星について」を選べる</b>ようになっています。</p>' +
    '</div>' +
    '現在は当たり前になっている地動説も、観測した結果を科学的に検討していく中で唱えられていったものです。' +
    '詳しくは、<b><a href="#m1-6" data-goto="m1-6">「補足：地動説とケプラーの法則の歴史」</a></b>を見てみてください。<br>' +
    'そして、惑星の動きを<b>説明し予測する</b>ために、' +
    '<b><a href="#m2-2" data-goto="m2-2">2-1</a></b> からの' +
    '<b>万有引力や天体のエネルギーの理論</b>を学んでください。<br>' +
    'この理論の先に、<b>ブラックホールの半径の分析</b>、<b>宇宙の運命の計算</b>など、' +
    '<b><a href="#m4-4" data-goto="m4-4">4-3</a></b> に示す' +
    '<b>現代物理学の領域</b>があります。' +
    colImg('kepler_only', 'ヨハネス・ケプラー',
      'ヨハネス・ケプラー（1571−1630）。ティコ・ブラーエが残した膨大な観測記録から、' +
      '惑星の運動に関する三法則を見つけ出した。'),
  cw: 560, ch: 424,
  loop: true,
  consts: { view: 'inner', pick: 'earth' },
  vars: [],
  vis: ['O', 'T'],
  visLabel: { O: '軌道を表示', T: '通ってきた道すじ' },
  legendBodies: function (v) {
    return m11Bodies(v).map(function (p) { return { name: p.name, col: p.col }; });
  },
  /* ★どちらのボタンも、押したらそのまま動きだす（play: true）★（先生の指示） */
  actions: [
    { label: '火星まで（内側の4つ）', fn: function (s) { s.o.view = 'inner'; }, is: function (v) { return v.view === 'inner'; }, rebuild: true, play: true },
    { label: '冥王星・ハレー彗星まで', fn: function (s) { s.o.view = 'all'; }, is: function (v) { return v.view === 'all'; }, rebuild: true, play: true }
  ],
  tEnd: function (v) { return m11View(v).tEnd; },
  rate: function (v) { return m11View(v).rate; },
  tFmt: function (t) { return fmt(t, 2) + ' 年'; },
  xlabel: 't [年]',
  tGraph: function (v) { return Math.min(m11View(v).tEnd, m11Pick(v).T * 3); },
  sample: function (v, t) {
    var p = m11Pick(v), q = planetXY(p, t);
    return { r: q.r, v: q.v, x: q.x, y: q.y };
  },
  graphs: [
    {
      /* ★はじめから開いておく★（先生の指示・2026-09-05 で表のすぐ下へ移したため）
         「アニメで選ぶ → 表の行が光る → T–a 図の点が光る」を見せるのがねらいなので、
         たたんだままだと、いちばん見てほしいつながりが見えない。 */
      key: 'ta', short: '$T$–$a$ 図', title: '$T$–$a$ 図（両対数）　※ケプラーの第3法則', open: true,
      custom: function (v) {
        var list = m11Bodies(v), i;
        var line = [];
        for (i = 0; i <= 60; i++) {
          var a = 0.3 * Math.pow(60 / 0.3, i / 60);
          line.push([a, Math.pow(a, 1.5)]);
        }
        return {
          logx: true, logy: true,
          xmin: 0.3, xmax: 60, ymin: 0.1, ymax: 1000,
          xlabel: 'a [AU]', ylabel: 'T [年]',
          series: [{ color: COL.orbit, dash: [6, 4], width: 1.6, pts: line }],
          /* 点が近いところは、文字を左右・上下に振り分けて重ならないようにする */
          /* ★id を書くと、その点が押せるようになる★（80_ui.js の attachGraphPick）
             押されると d.pickMark が呼ばれて、左のアニメでその天体が選ばれる。 */
          marks: list.map(function (p, j) {
            var left = p.a > 12, on = (p.id === (v.pick || 'earth'));
            return {
              id: p.id,
              x: p.a, y: p.T, color: p.col, name: p.name, r: on ? 7 : 5, ring: on,
              lx: left ? -11 : 11, align: left ? 'right' : 'left',
              ly: (j % 2 ? 13 : -12)
            };
          })
        };
      }
    }
  ],
  /* ★グラフは左の列（表のすぐ下）に置く★（先生の指示・2026-09-05）
     「アニメで選ぶ → 表の行が光る → T–a 図の点が光る」を、目を動かさずに追えるようにする。 */
  graphsInMain: true,
  /* T–a 図の点を押したときに呼ばれる（80_ui.js の attachGraphPick）。
     アニメの中で天体を選ぶのと、まったく同じことをする。 */
  pickMark: function (s, id) { s.o.pick = id; },
  drag: function (s, x, y, lx, ly) {
    var dots = (s.ui && s.ui.dots) || [], i, best = null, bd = 20;
    for (i = 0; i < dots.length; i++) {
      var dd = Math.hypot(dots[i].px - lx, dots[i].py - ly);
      if (dd < bd) { bd = dd; best = dots[i].id; }
    }
    if (best) s.o.pick = best;
  },
  dragKeepT: true,
  draw: function (ctx, s, t, W, H) { m11DrawTop(ctx, s, t, W, H); },
  result: function (v, s, t) {
    var list = m11Bodies(v), p = m11Pick(v), o = pElems(p);
    var Kv = p.T * p.T / (p.a * p.a * p.a);
    return {
      items: [
        resItem('選んだ天体', p.name),
        resItem('半長軸 $a$', fmt(p.a, 3) + ' AU'),
        resItem('周期 $T$', fmt(p.T, 3) + ' 年'),
        resItem('離心率 $\\varepsilon$', fmt(p.e, 3)),
        resItem('$K = T^2/a^3$', fmt(Kv, 4) + ' 年²/AU³', true)
      ],
      /* pick に名前を書くと、その行が光る（80_ui.js の renderResult）。
         アニメや T–a 図で選んだ天体が、表の中でもすぐ分かるようにするため。 */
      table: (function () {
        var tb = kTable(list.map(function (q) {
          return [q.name, fmt(q.a, 3), fmt(q.T, 3), fmt(q.T * q.T / (q.a * q.a * q.a), 4)];
        }), SYS.sun);
        tb.pick = p.name;
        return tb;
      })(),
      note: '右端の列が <b>K = T²/a³</b>。どの天体でも <b>ほぼ 1.000</b> でそろう（太陽系では a を AU、T を年で測ると K = 1）。'
    };
  },
  /* 読み出しの表は出さない（このシムは「見て読む」入り口にするため）。
     天体ごとの数値は、図のすぐ下の「計算結果を表示」の帯と表で読める。 */
  eq: function (s) {
    return EQM + 'm\\vec{a} = -G\\dfrac{mM}{r^2}\\,\\vec{e}_r \\quad\\Rightarrow\\quad ' +
      '\\dfrac{T^2}{a^3} = \\dfrac{4\\pi^2}{GM}\\;(\\text{一定})';
  },
  /* ★高校で習わない記号は、かならず式のすぐ下で説明する★ */
  eqNote: '※ <b>$\\vec{e}_r$</b> は<b>「太陽から惑星へ向かう向き」の長さ 1 のベクトル</b>' +
    '（単位ベクトル）で、大学で習う書き方です。' +
    '<b>向きだけを表す矢印</b>だと思ってください。' +
    '$-G\\dfrac{mM}{r^2}\\vec{e}_r$ は「大きさが $G\\dfrac{mM}{r^2}$ で、' +
    '向きは $\\vec{e}_r$ の<b>逆</b>（＝惑星から太陽へ向かう向き）の力」という意味。' +
    'マイナスがついているのは、<b>万有引力がいつも引っぱる力（＝中心を向く力）</b>だからです。<br>' +
    '※ <b>$\\vec{a}$</b> は加速度、<b>$m$</b> は惑星の質量、<b>$M$</b> は太陽の質量、' +
    '<b>$r$</b> は太陽と惑星の距離、<b>$G$</b> は万有引力定数です。',
  /* グラフが1つだけなので「まとめて開く／式を拡大」の行は出さない */
  noOpenRow: true
};

/* 1-1 上から見た太陽系 */
function m11DrawTop(ctx, s, t, W, H) {
  var v = V(s), view = m11View(v), list = m11Bodies(v), i;
  /* 背景は宇宙（濃紺＋星）。「補足：地球と月の太陽まわりの運動」と同じ見た目にそろえる。
     暗い背景なので、文字はすべて明るい色＋濃いハロー（HALO）で書くこと。 */
  var HALO = 'rgba(13,22,38,.92)';
  ctx.save(); ctx.fillStyle = '#0d1626'; ctx.fillRect(0, 0, W, H); ctx.restore();
  starField(ctx, 0, 0, W, H, 90, 20260905);
  var cx = W / 2, cy = H / 2 + 6;
  var Rpx = Math.min(W - 40, H - 46) / 2;
  var rmax = 0;
  list.forEach(function (p) { rmax = Math.max(rmax, p.a * (1 + p.e)); });
  var lg = view.log;
  var LMIN = 0.25;
  function rpx(r) {
    if (!lg) return r / rmax * Rpx;
    var a = Math.log(LMIN) / Math.LN10, b = Math.log(rmax) / Math.LN10;
    var q = (Math.log(Math.max(1e-3, r)) / Math.LN10 - a) / (b - a);
    return clamp(q, 0.045, 1) * Rpx;
  }
  function map(x, y) {
    var r = Math.hypot(x, y);
    var k = (r > 1e-9) ? rpx(r) / r : 0;
    return [cx + x * k, cy - y * k];
  }
  /* ものさし（うすい円） */
  var rings = lg ? [0.4, 1, 5, 10, 30, 50] : (rmax > 12 ? [1, 5, 10, 20, 30] : [0.5, 1, 1.5]);
  ctx.save();
  ctx.strokeStyle = 'rgba(180,198,220,.30)'; ctx.lineWidth = 1;
  rings.forEach(function (r) {
    if (r > rmax * 1.02) return;
    ctx.beginPath(); ctx.arc(cx, cy, rpx(r), 0, TAU); ctx.stroke();
  });
  ctx.restore();
  rings.forEach(function (r) {
    if (r > rmax * 1.02 || rpx(r) < 56) return;   /* 中心に近い目盛りの文字は天体の名前と重なる */
    /* 1.5 を「2」と書いてしまわないよう、整数でないものは小数1けたで出す */
    label(ctx, fmt(r, (r % 1 === 0) ? 0 : 1) + ' AU', cx - rpx(r) * 0.707, cy - rpx(r) * 0.707,
      { size: 9.5, color: '#9fb0c4', haloColor: HALO });
  });

  /* 軌道 */
  if (s.o.showO) {
    list.forEach(function (p) {
      /* 対数のものさしでは近日点のあたりで向きが急に変わるので、点を多くとる
         （240 点だとハレー彗星の軌道がカクカクの折れ線になった） */
      var pts = planetOrbitPts(p, 1440);
      ctx.save();
      /* 暗い背景では 0.55 だと軌道が沈んで見えないので、少し濃くする */
      ctx.strokeStyle = fade(p.col, 0.8); ctx.lineWidth = 1.2;
      if (p.comet) ctx.setLineDash([7, 4]);
      ctx.beginPath();
      pts.forEach(function (q, j) {
        var sp = map(q[0], q[1]);
        if (j === 0) ctx.moveTo(sp[0], sp[1]); else ctx.lineTo(sp[0], sp[1]);
      });
      ctx.closePath(); ctx.stroke();
      ctx.restore();
    });
  }

  drawCenterBody(ctx, cx, cy, SYS.sun, 9, '太陽');

  /* 天体（クリックできるように画面座標を覚えておく） */
  s.ui.dots = [];
  var pick = m11Pick(v).id;
  list.forEach(function (p) {
    var q = planetXY(p, t);
    var sp = map(q.x, q.y);
    var rr = clamp(p.r * (lg ? 0.72 : 1), 2.4, 11);
    /* 通ってきた道すじ */
    if (s.o.showT && t > 1e-6) {
      /* 時間で等分すると、ハレー彗星の近日点のあたりが折れ線になる（planetTrailPts のコメント参照） */
      var tp = planetTrailPts(p, t, trailN(p, t));
      ctx.save();
      ctx.strokeStyle = fade(p.col, 0.85); ctx.lineWidth = 2.2; ctx.lineCap = 'round';
      ctx.beginPath();
      tp.forEach(function (qq, jj) {
        var pp = map(qq[0], qq[1]);
        if (jj === 0) ctx.moveTo(pp[0], pp[1]); else ctx.lineTo(pp[0], pp[1]);
      });
      ctx.stroke();
      ctx.restore();
    }
    if (p.comet) cometShape(ctx, sp[0], sp[1], rr, cx, cy);
    else planetShape(ctx, sp[0], sp[1], rr, p.col, p.id === 'saturn');
    if (p.id === pick) {
      /* 暗い背景なので、選んだ印は明るい水色にする（青＝速度 の意味では使っていない） */
      ctx.save();
      ctx.strokeStyle = '#9fd0ff'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(sp[0], sp[1], rr + 5.5, 0, TAU); ctx.stroke();
      ctx.restore();
      dashLine(ctx, cx, cy, sp[0], sp[1], '#9fd0ff', [4, 4], 1.2);
    }
    label(ctx, p.name, sp[0], sp[1] - rr - 9,
      { size: p.id === pick ? 12 : 10.5, bold: p.id === pick,
        color: p.id === pick ? '#9fd0ff' : '#c9d6e4', haloColor: HALO });
    s.ui.dots.push({ id: p.id, px: sp[0], py: sp[1] });
  });

  drawClock(ctx, W, 't = ' + fmt(t, 2) + ' 年', undefined,
    { color: '#e8eef4', haloColor: HALO });
  label(ctx, '惑星をクリックすると値が下に出ます', 10, H - 12,
    { align: 'left', size: 10.5, color: '#9fb0c4', haloColor: HALO });
  if (lg) label(ctx, '※ 距離は対数のものさし', W - 10, H - 12,
    { align: 'right', size: 10.5, color: '#9fb0c4', haloColor: HALO });
  if (hintOn(s, t)) {
    /* COL.bound（濃い緑）は暗い背景では読めないので、同じ緑の明るい方を使う */
    label(ctx, '内側の惑星ほど速く回る＝遠いほど周期が長い（第3法則）', W - 10, 36,
      { align: 'right', size: 11.5, color: '#7fe0a0', bold: true, haloColor: HALO });
  }
}

/* ============================================================
   1-2　ケプラーの第1法則（楕円軌道）
   ============================================================ */
DEFS['m1-2'] = {
  id: 'm1-2', mode: 1, tab: '1-1 第1法則（楕円軌道）', autoplay: true,
  units: function (v) { return (v.sys === 'earth') ? [] : ['AU']; },
  legendKeys: ['sun', 'vel', 'dim', 'bound'],
  title: function () { return '1-1　ケプラーの第1法則　—　' + lawTxt('k1'); },
  sub: '<b>第1法則</b>：' + LAW.k1 + '。<br>' +
    '楕円は「2つの焦点からの距離の和 <b>r₁ + r₂</b> がいつも同じ（＝ 2a）」になる点の集まりです。' +
    '下の帯で、動かしても和が変わらないことを確かめよう。<b>離心率 ε を 0 にすると2つの焦点が重なり、円になります。</b>',
  note: '惑星（人工衛星）は常に<b>楕円軌道</b>を描いています。<b>ε = 0</b> にすると焦点が1点に重なって' +
    '<b>円運動</b>になります。太陽との距離次第で速くなったり遅くなったりすることをまとめたのが<b>第2法則</b>です。',
  cw: 560, ch: 400,
  vis: ['R', 'V'],
  visDef: { V: false, R: false },
  visLabel: { R: '$r_1$・$r_2$ を表示', V: '速度を表示' },
  vars: aVars(1.6, 20000).concat([
    {
      k: 'e', label: '離心率 $\\varepsilon$（0 で円）', unit: '',
      min: 0, max: 0.8, step: 0.05, dec: 2, def: 0.50,
      hint: '$\\varepsilon$ とは「どれくらい円からつぶれるか」の値（正確な定義は右の「数学では・・・」）'
    }
  ]),
  mainVars: ['aS', 'aE', 'e'],
  /* いちばん見せたいボタンは、図の左上（.topacts）に置く */
  topActions: [
    {
      label: '離心率 ε を大きくする →', prim: true,
      fn: function (s) { stepUp(DEFS['m1-2'], s, 'e', 0.10); }
    },
    {
      label: '等速円運動に戻す（ε＝0）', fn: function (s) { s.v.e = 0; },
      is: function (v) { return v.e < 1e-9; }
    }
  ],
  sysToggle: true,               /* 描画対象はタイトルの横の共通ボタンで切りかえる */
  tEnd: function (v) { return orbOf(v).T; },
  rate: function (v) { return orbOf(v).T / 9; },
  loop: true,                       /* 1周したら t=0 に戻って回りつづける */
  tFmt: function (t, v) { return tText(v, t); },
  xlabel: 't',
  sample: function (v, t) {
    var o = orbOf(v);
    var q = K.state(o, t, 0, false);
    q.o = o;
    return q;
  },
  graphs: [
    {
      key: 'r', short: '$r$–$t$ 図', title: '$r$–$t$ 図（中心の天体からの距離）', open: false,
      ylabel: 'r', xf: function (m, v, t) { return tPlot(v, t); },
      series: [{ color: COL.bound, f: function (m) { return m.r; } }],
      fml: function (v) {
        var o = orbOf(v), sy = sysOf(v);
        return [
          'r_{\\text{近}} = a(1-\\varepsilon),\\quad r_{\\text{遠}} = a(1+\\varepsilon)',
          'a = ' + fmtLen(o.a) + '\\,\\mathrm{' + sy.uL + '},\\; \\varepsilon = ' + fmt(o.e, 2),
          'r_{\\text{近}} = ' + fmtLen(o.rp) + ',\\;\\; r_{\\text{遠}} = ' + fmtLen(o.ra) + '\\;[\\mathrm{' + sy.uL + '}]'
        ];
      }
    },
    {
      key: 'v', short: '$v$–$t$ 図', title: '$v$–$t$ 図（速さ）', open: false,
      ylabel: 'v', xf: function (m, v, t) { return tPlot(v, t); },
      series: [{ color: COL.vel, f: function (m) { return m.v; } }],
      fml: function (v) {
        var o = orbOf(v), sy = sysOf(v);
        return [
          'v = \\sqrt{GM\\left(\\dfrac{2}{r}-\\dfrac{1}{a}\\right)}',
          'v_{\\text{近}} = \\sqrt{\\dfrac{GM(1+\\varepsilon)}{a(1-\\varepsilon)}},\\quad v_{\\text{遠}} = \\sqrt{\\dfrac{GM(1-\\varepsilon)}{a(1+\\varepsilon)}}',
          'v_{\\text{近}} = ' + fmtAuto(o.vp, 3) + ',\\;\\; v_{\\text{遠}} = ' + fmtAuto(o.va, 3) + '\\;[\\mathrm{' + sy.uV + '}]'
        ];
      }
    }
  ],
  draw: function (ctx, s, t, W, H) {
    var v = V(s), o = orbOf(v), sy = sysOf(v);
    /* ★縮尺は「a がいちばん大きいとき」に合わせて固定する★
       もとは「いまの軌道がぴったり入る」ように自動で決めていたので、半長軸 a を変えても
       絵の大きさがまったく変わらず、スライドバーが効いていないように見えていた。
       いまは「同じ離心率 ε で a を最大にした軌道」が入る大きさに固定してあるので、
       a を大きくすると絵もちゃんと大きくなる。
       （そのかわり a のはばは広げすぎないこと。aVars のコメントを見ること。） */
    var oRef = P.orb.make(aMaxOf(v), o.e, sy);
    var vw = orbScene(W, H, oRef, { l: 54, r: 54, t: LAW_BAND + 16, b: 56 });
    s.view = vw;
    var q = K.state(o, t, 0, false);
    var F1 = { x: vw.X(0), y: vw.Y(0) };                   /* 太陽（焦点1） */
    var F2 = { x: vw.X(-2 * o.c), y: vw.Y(0) };            /* もう1つの焦点 */
    var C = { x: vw.X(-o.c), y: vw.Y(0) };                 /* 楕円の中心 */
    var px = vw.X(q.x), py = vw.Y(q.y);

    /* 軌道 */
    drawOrbitEllipse(ctx, vw, o, o.e < 1e-9 ? COL.bound : COL.bound, [], 1.8);

    /* 長軸・短軸 */
    dashLine(ctx, vw.X(-o.ra), vw.Y(0), vw.X(o.rp), vw.Y(0), COL.dim, [4, 4], 1);
    dashLine(ctx, C.x, vw.Y(-o.b), C.x, vw.Y(o.b), COL.dim, [4, 4], 1);
    /* a と b の寸法（a は長軸から少し上にずらして、太陽の絵と重ならないようにする） */
    var aY = C.y - 22;
    dashLine(ctx, C.x, C.y, C.x, aY, COL.dim, [3, 3], 1);
    dashLine(ctx, vw.X(o.rp), vw.Y(0), vw.X(o.rp), aY, COL.dim, [3, 3], 1);
    arrow(ctx, C.x, aY, vw.X(o.rp), aY, 'dim');
    label(ctx, 'a', (C.x + vw.X(o.rp)) / 2, aY - 10, { size: 12.5, color: COL.dim });
    arrow(ctx, C.x, C.y, C.x, vw.Y(o.b), 'dim');
    label(ctx, 'b', C.x - 15, C.y + (vw.Y(o.b) - C.y) * 0.62, { size: 12.5, color: COL.dim });

    /* 焦点 */
    drawCenterBody(ctx, F1.x, F1.y, sy, sy.key === 'earth' ? 11 : 9, sy.key === 'earth' ? '地球' : '太陽（焦点1）');
    ctx.save();
    ctx.fillStyle = COL.cg;
    ctx.beginPath(); ctx.arc(F2.x, F2.y, 3.6, 0, TAU); ctx.fill();
    ctx.restore();
    if (o.e < 1e-9) {
      /* 焦点が重なっているときは、中心の天体の絵と文字がぶつかるので下に書く */
      label(ctx, '2つの焦点が重なった＝円の中心', 10, H - 42,
        { size: 11, color: COL.cg, align: 'left' });
    } else {
      label(ctx, 'もう1つの焦点', F2.x, F2.y + 15, { size: 11, color: COL.cg });
    }
    if (o.e > 1e-9) {
      /* 「中心」は、両どなりの「太陽（焦点1）」「もう1つの焦点」より2行下に書き、
         細い引き出し線でつなぐ。同じ高さにそろえると、a を小さくしたときに
         3つの文字がくっついて読めなくなるため。 */
      label(ctx, '中心', C.x, C.y + 42, { size: 10.5, color: COL.sub });
      ctx.save();
      ctx.fillStyle = COL.sub;
      ctx.beginPath(); ctx.arc(C.x, C.y, 2.4, 0, TAU); ctx.fill();
      ctx.restore();
      dashLine(ctx, C.x, C.y + 5, C.x, C.y + 34, COL.dim, [3, 3], 1);
    }

    /* 円のときは a と b が同じ長さになることを、はっきり書く */
    if (o.e < 1e-9) {
      /* 中心のあたりは r1・r2 の文字が来るので、この文は図の左上（帯のすぐ下）に置く */
      label(ctx, 'a = b（＝円の半径）', 10, LAW_BAND + 14,
        { size: 12, color: COL.bound, bold: true, align: 'left' });
    }

    /* 近日点・遠日点 */
    label(ctx, sy.key === 'earth' ? '近地点' : '近日点', vw.X(o.rp) + 6, vw.Y(0) - 13,
      { size: 11, color: COL.sub, align: 'left' });
    label(ctx, sy.key === 'earth' ? '遠地点' : '遠日点', vw.X(-o.ra) - 6, vw.Y(0) - 13,
      { size: 11, color: COL.sub, align: 'right' });

    /* r1・r2 */
    if (s.o.showR) {
      ctx.save();
      ctx.strokeStyle = COL.sect1; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(F1.x, F1.y); ctx.lineTo(px, py); ctx.stroke();
      if (o.e > 1e-9) {
        ctx.strokeStyle = COL.sect3;
        ctx.beginPath(); ctx.moveTo(F2.x, F2.y); ctx.lineTo(px, py); ctx.stroke();
      }
      ctx.restore();
      /* 焦点が重なっているときは線も1本になるので、文字も1つにする */
      if (o.e > 1e-9) {
        lineLabel(ctx, 'r_1', F1.x, F1.y, px, py, 13, COL.sect1);
        lineLabel(ctx, 'r_2', F2.x, F2.y, px, py, -13, COL.sect3);
      } else {
        lineLabel(ctx, 'r_1 = r_2', F1.x, F1.y, px, py, 15, COL.sect1);
      }
    }

    /* 惑星と速度 */
    planetShape(ctx, px, py, 6.5, sy.key === 'earth' ? '#c7ced6' : '#3f7f5f');
    label(ctx, sy.key === 'earth' ? '人工衛星' : '惑星', px, py - 14, { size: 11, color: COL.ink });
    if (s.o.showV) {
      var vsc = 0.30 * Math.min(W, H) / Math.max(1e-9, o.vp);
      velArrow(ctx, px, py, q.vx, q.vy, vsc,
        'v = ' + fmtAuto(q.v, 2) + ' ' + sy.uV, 10, -10);
    }

    /* r1 + r2 = 2a の帯（長さで見せる） */
    if (s.o.showR) {
      var by = H - 20, bx0 = 60, bw = W - 120;
      var f1 = q.r / (2 * o.a);
      ctx.save();
      ctx.strokeStyle = COL.sect1; ctx.lineWidth = 7; ctx.lineCap = 'butt';
      ctx.beginPath(); ctx.moveTo(bx0, by); ctx.lineTo(bx0 + bw * f1, by); ctx.stroke();
      ctx.strokeStyle = COL.sect3;
      ctx.beginPath(); ctx.moveTo(bx0 + bw * f1, by); ctx.lineTo(bx0 + bw, by); ctx.stroke();
      ctx.restore();
      label(ctx, 'r_1', bx0 + bw * f1 / 2, by - 11, { size: 10.5, color: COL.sect1 });
      label(ctx, 'r_2', bx0 + bw * (f1 + 1) / 2, by - 11, { size: 10.5, color: COL.sect3 });
      label(ctx, 'r_1+r_2 = 2a', bx0 - 6, by, { size: 11, color: COL.ink, align: 'right' });
    }

    /* 図の上の帯に、第1法則そのものを大きく書く（時刻や予告の文は置かない） */
    drawLawBanner(ctx, W, '第1法則', lawTxt('k1n'));
  },
  result: function (v, s, t) {
    var o = orbOf(v), sy = sysOf(v);
    var q = K.state(o, t, 0, false);
    var Tsh = (sy.key === 'earth') ? (fmt(o.T / 3600, 3) + ' 時間') : (fmt(o.T, 3) + ' 年');
    var Kv = o.T * o.T / (o.a * o.a * o.a);
    return {
      /* K = T²/a³ は太陽系のときだけ出す（地球まわりでは 0.0001 と丸まって意味がないため） */
      items: [
        resItem('半長軸 $a$', fmtLen(o.a) + ' ' + sy.uL),
        resItem('半短軸 $b$', fmtLen(o.b) + ' ' + sy.uL + (o.e < 1e-9 ? '（a = b）' : '')),
        resItem('周期 $T$', Tsh)
      ].concat(sy.key === 'sun'
        ? [resItem('$K = T^2/a^3$', fmt(Kv, 4) + ' 年²/AU³', true)] : []).concat([
          resItem('離心率 $\\varepsilon$', fmt(o.e, 2)),
          resItem('$r_1 + r_2$', fmtLen(2 * o.a) + ' ' + sy.uL + '（＝2a で一定）')
        ]),
      note: '$r_1 = ' + fmtLen(q.r) + '$、$r_2 = ' + fmtLen(2 * o.a - q.r) + '$ ' + sy.uL +
        '。惑星が動いても、<b>2つの焦点までの距離の和はいつも 2a</b> のまま。' +
        (o.e < 1e-9 ? '<b>いまは ε = 0 なので a と b が同じ長さ（＝円）</b>です。' : '')
    };
  },
  info: function (s, t) {
    var v = V(s), o = orbOf(v), sy = sysOf(v);
    var q = K.state(o, t, 0, false);
    return [
      ['距離 $r_1$（焦点1から）', fmtLen(q.r) + ' ' + sy.uL],
      ['距離 $r_2$（焦点2から）', fmtLen(2 * o.a - q.r) + ' ' + sy.uL],
      ['速さ $v$', fmtAuto(q.v, 3) + ' ' + sy.uV],
      ['近点距離 $a(1-\\varepsilon)$', fmtLen(o.rp) + ' ' + sy.uL],
      ['遠点距離 $a(1+\\varepsilon)$', fmtLen(o.ra) + ' ' + sy.uL],
      ['中心から焦点まで $c = a\\varepsilon$', fmtLen(o.c) + ' ' + sy.uL],
      ['時刻 $t$', tText(v, t)]
    ];
  },
  eq: function (s) {
    return 'r_1 + r_2 = 2a\\;(\\text{一定}) \\qquad b = a\\sqrt{1-\\varepsilon^2},\\qquad c = a\\varepsilon';
  },
  side: {
    w: 420, h: 250,
    title: '数学では・・・',
    note: 'だ円は、ある決まった2点 $F_1$, $F_2$ からの距離の和が等しい点 $P$ の集まりである。' +
      'この2点をだ円の<b>焦点</b>という。' +
      '左の図の<b>太陽は、2つの焦点のうちの1つ</b>にあたる。<br>' +
      '<b>【離心率 $\\varepsilon$ の定義】</b>　半長軸を $a$、中心から焦点までの距離を $c$ として<br>' +
      '<b>$\\varepsilon = \\dfrac{c}{a}$</b>　（$0 \\le \\varepsilon < 1$）<br>' +
      'つまり<b>「半長軸に対して、焦点が中心からどれだけずれているか」の割合</b>。' +
      '$\\varepsilon = 0$ なら2つの焦点が重なって<b>円</b>、' +
      '$\\varepsilon$ が 1 に近いほど<b>細長い</b>だ円になる。<br>' +
      '短半軸は $b = a\\sqrt{1-\\varepsilon^2}$、近日点は $a(1-\\varepsilon)$、遠日点は $a(1+\\varepsilon)$。<br>' +
      '<span class="mini">※ 焦点を原点にとると $r=\\dfrac{a(1-\\varepsilon^2)}{1+\\varepsilon\\cos\\theta}$ '
      + 'と書ける（これが「だ円軌道の式」）。$\\varepsilon=1$ で放物線、$\\varepsilon>1$ で双曲線になる。</span>',
    draw: function (ctx, s, t, W, H) { m12DrawMath(ctx, s, t, W, H); }
  }
};

/* 1-2 の右に出す「数学のだ円」の図（教科書の作図をなぞる） */
function m12DrawMath(ctx, s, t, W, H) {
  var v = V(s), o = orbOf(v), i;
  var box = { x0: -o.ra, x1: o.rp, y0: -o.b, y1: o.b };
  var mx = (box.x1 - box.x0) * 0.10, my = (box.y1 - box.y0) * 0.18;
  var vw = mkView(W, H, { l: 34, r: 34, t: 30, b: 34 },
    { x0: box.x0 - mx, x1: box.x1 + mx, y0: box.y0 - my, y1: box.y1 + my });
  /* だ円 */
  drawOrbitEllipse(ctx, vw, o, COL.ink, [], 1.6);
  var F1 = { x: vw.X(0), y: vw.Y(0) };                  /* 太陽のある焦点 */
  var F2 = { x: vw.X(-2 * o.c), y: vw.Y(0) };
  var C = { x: vw.X(-o.c), y: vw.Y(0) };
  /* 軸 */
  dashLine(ctx, vw.X(-o.ra), vw.Y(0), vw.X(o.rp), vw.Y(0), COL.sub, [4, 4], 1);
  dashLine(ctx, C.x, vw.Y(-o.b), C.x, vw.Y(o.b), COL.sub, [4, 4], 1);
  /* 点 P は決まった位置に置く（教科書の作図と同じ。動かすと文字が重なるため） */
  var E0 = 2.25;
  var px = vw.X(o.a * (Math.cos(E0) - o.e)), py = vw.Y(o.b * Math.sin(E0));
  ctx.save();
  ctx.strokeStyle = COL.sect1; ctx.lineWidth = 1.8;
  ctx.beginPath(); ctx.moveTo(F1.x, F1.y); ctx.lineTo(px, py); ctx.stroke();
  ctx.strokeStyle = COL.sect3;
  ctx.beginPath(); ctx.moveTo(F2.x, F2.y); ctx.lineTo(px, py); ctx.stroke();
  ctx.restore();
  /* ε = 0 のときは2つの焦点が1点に重なるので、文字も1つにまとめる（重なりを防ぐため） */
  var one = (o.e < 1e-9);
  if (one) {
    lineLabel(ctx, 'F_1P = F_2P', F1.x, F1.y, px, py, -13, COL.sect1, 11.5);
  } else {
    lineLabel(ctx, 'F_1P', F1.x, F1.y, px, py, -13, COL.sect1, 11.5);
    lineLabel(ctx, 'F_2P', F2.x, F2.y, px, py, -13, COL.sect3, 11.5);
  }
  /* 焦点と中心 */
  (one ? [[F1, 'F_1 = F_2（円の中心）', COL.sunRim]]
       : [[F1, 'F_1（太陽）', COL.sunRim], [F2, 'F_2', COL.cg]]).forEach(function (f) {
    ctx.save();
    ctx.fillStyle = f[2];
    ctx.beginPath(); ctx.arc(f[0].x, f[0].y, 3.4, 0, TAU); ctx.fill();
    ctx.restore();
    label(ctx, f[1], f[0].x, f[0].y + 15, { size: 10.5, color: f[2] });
  });
  ctx.save();
  ctx.fillStyle = COL.ink;
  ctx.beginPath(); ctx.arc(px, py, 3.6, 0, TAU); ctx.fill();
  ctx.restore();
  label(ctx, 'だ円上の点 P', px, py - 13, { size: 10.5, color: COL.ink });
  /* 半長軸・半短軸 */
  var aY = C.y - 20;
  dashLine(ctx, C.x, C.y, C.x, aY, COL.dim, [3, 3], 1);
  dashLine(ctx, vw.X(o.rp), vw.Y(0), vw.X(o.rp), aY, COL.dim, [3, 3], 1);
  arrow(ctx, C.x, aY, vw.X(o.rp), aY, 'dim');
  label(ctx, '半長軸 a', (C.x + vw.X(o.rp)) / 2, aY - 9, { size: 10.5, color: COL.dim });
  arrow(ctx, C.x, C.y, C.x, vw.Y(o.b), 'dim');
  /* 「半長軸 a」の文字は軸の右上、「半短軸 b」は軸の左に置く（重ならないようにするため） */
  label(ctx, '半短軸 b', C.x - 9, C.y + (vw.Y(o.b) - C.y) * 0.62,
    { size: 10.5, color: COL.dim, align: 'right' });
  label(ctx, 'F_1P + F_2P = 一定（＝ 2a）', W - 8, H - 12,
    { size: 12, bold: true, color: COL.ink, align: 'right' });
}

/* ============================================================
   1-3　ケプラーの第2法則（面積速度一定）
   ============================================================ */
/* はじめの位置（ここから速さと向きを決めて投げ出す）。位置は固定し、速さと向きだけを変える。 */
function m13R0(v) { return (v.sys === 'earth') ? 10000 : 1.0; }   /* km ／ AU */

/* はじめの速さ（円軌道の何倍か）と、速度の向き（動径に垂直な向きから測った角）から軌道を作る。
   数値積分はしない。位置と速度から軌道要素を出し、あとはケプラー方程式で解く。 */
function m13Orb(v) {
  var sys = sysOf(v), r0 = m13R0(v);
  var vc = Math.sqrt(sys.GM / r0);                    /* この距離での円軌道の速さ */
  var vv = (v.kv === undefined ? 1 : v.kv) * vc;
  var ph = (v.phi === undefined ? 0 : v.phi) * DEG;
  var vr = vv * Math.sin(ph), vt = vv * Math.cos(ph);
  var f = K.fromRV(r0, vr, vt, sys.GM);
  var o = K.elems(f.a, f.e, sys.GM);
  o.sys = sys; o.r0 = r0; o.v0 = vv; o.vc = vc; o.vr0 = vr; o.vt0 = vt; o.phi = ph;
  /* はじめの位置の離心近点離角 E0（動径方向の速さの符号で、近点の前か後かが決まる） */
  var E0 = 0;
  if (f.e > 1e-9) E0 = Math.acos(clamp((1 - r0 / f.a) / f.e, -1, 1)) * (vr >= 0 ? 1 : -1);
  o.E0 = E0;
  o.M0 = E0 - f.e * Math.sin(E0);                     /* t=0 で「はじめの位置」にいるようにする */
  return o;
}

/* 3つの扇形を掃く時刻（近点・その中間・遠点から、それぞれ同じ Δt だけ）。時刻は近点を 0 とする。 */
function m13Windows(o) {
  var dt = o.T / 12;
  return [
    { t0: 0, t1: dt, col: COL.sect1, name: 'S_1', where: '近点のあたり' },
    { t0: o.T * 0.25 - dt / 2, t1: o.T * 0.25 + dt / 2, col: COL.sect2, name: 'S_2', where: 'その中間' },
    { t0: o.T * 0.5 - dt / 2, t1: o.T * 0.5 + dt / 2, col: COL.sect3, name: 'S_3', where: '遠点のあたり' }
  ];
}
function m13Ecc(o, t) { return K.ecc(TAU * t / o.T, o.e); }
/* いまの時刻を「近点を 0 とした時刻」に直す（扇形の中にいるかの判定に使う） */
function m13Tperi(o, t) {
  var M = o.M0 + TAU * t / o.T;
  M = M % TAU; if (M < 0) M += TAU;
  return M / TAU * o.T;
}

DEFS['m1-3'] = {
  id: 'm1-3', mode: 1, tab: '1-2 第2法則（面積速度一定）', autoplay: true,
  units: function (v) { return (v.sys === 'earth') ? [] : ['AU']; },
  legendKeys: ['sun', 'orbit', 'vel', 'dim', 'sect'],
  title: function () { return '1-2　ケプラーの第2法則　—　' + lawTxt('k2'); },
  sub: '<b>第2法則</b>：' + LAW.k2 + '。　' + LAW.n2 + '。<br>' +
    '左上の2本のスライドバーで、<b>はじめの位置での速さ</b>（その場所の円軌道の何倍か）と' +
    '<b>速度の向き</b>（動径に垂直な向きから測った角）を変えると、軌道の形が変わります。' +
    'どんな形にしても、近点・中間・遠点でぬり分けた<b>3つの扇形の面積はいつも等しい</b>ことを確かめよう。',
  note: '<b>' + LAW.k2 + '</b>（' + LAW.n2 + '）——これが第2法則です。' +
    '近いところでは<b>動径が速く</b>、遠いところでは<b>動径がゆっくり</b>動くので、面積が等しい。' +
    'だから $r$ が小さいほど $v$ は大きく、$\\tfrac{1}{2}rv\\sin\\theta$（＝面積速度）は<b>ずっと一定</b>です。',
  cw: 560, ch: 400,
  vis: ['V', 'R'],
  visLabel: { V: '速度を表示', R: '動径を表示' },
  consts: { cmp: false },
  topActions: [
    {
      /* オン／オフのトグル。押すと文字が変わるので、いまどちらなのかが分かる */
      label: function (v) { return v.cmp ? '面積速度の比較をやめる' : '面積速度を比較'; },
      prim: true,
      fn: function (s) { s.o.cmp = !s.o.cmp; },
      is: function (v) { return !!v.cmp; }
    }
  ],
  sysToggle: true,               /* 描画対象はタイトルの横の共通ボタンで切りかえる */
  vars: [
    {
      k: 'kv', label: 'はじめの速さ（円軌道の何倍か）', unit: ' 倍',
      min: 0.55, max: 1.35, step: 0.05, dec: 2, def: 0.75
    },
    {
      k: 'phi', label: '速度の向き（動径に垂直な向きから）', unit: '°',
      min: -60, max: 60, step: 5, dec: 0, def: 0
    }
  ],
  mainVars: ['kv', 'phi'],
  tEnd: function (v) { return m13Orb(v).T; },
  rate: function (v) { return m13Orb(v).T / 10; },
  loop: true,
  tFmt: function (t, v) { return tText(v, t); },
  xlabel: 't',
  sample: function (v, t) {
    var o = m13Orb(v);
    var q = K.state(o, t, o.M0, false);
    q.dS = o.dS;
    return q;
  },
  graphs: [
    {
      key: 'vr', short: '$v$–$r$ 図', title: '$v$–$r$ 図（速さ と 中心の天体からの距離）', open: false,
      ylabel: 'v', xlabel: 'r',
      xf: function (m) { return m.r; },
      series: [{ color: COL.vel, f: function (m) { return m.v; } }],
      fml: function (v) {
        var o = m13Orb(v), sy = sysOf(v);
        return [
          'v = \\sqrt{GM\\left(\\dfrac{2}{r}-\\dfrac{1}{a}\\right)}',
          '\\text{遠いほど遅い}\\;(r\\uparrow \\Rightarrow v\\downarrow)',
          'v_{\\text{近}} = ' + fmtAuto(o.vp, 3) + ',\\;\\; v_{\\text{遠}} = ' + fmtAuto(o.va, 3) + '\\;[\\mathrm{' + sy.uV + '}]'
        ];
      }
    },
    {
      key: 'sr', short: '$S$–$r$ 図', title: '$dS/dt$–$r$ 図（面積速度 と 距離）　※水平な直線になる', open: true,
      ylabel: 'dS/dt', xlabel: 'r',
      xf: function (m) { return m.r; },
      series: [{ color: COL.sect1, f: function (m) { return m.dS; } }],
      fml: function (v) {
        var o = m13Orb(v), sy = sysOf(v);
        return [
          '\\dfrac{dS}{dt} = \\dfrac{1}{2} r v \\sin\\theta = \\dfrac{L}{2m}\\;(\\text{一定})',
          '\\dfrac{dS}{dt} = \\dfrac{1}{2} r_0 v_0 \\sin\\theta_0 \\;\\;(\\theta_0 = 90^\\circ - \\varphi)',
          '\\dfrac{dS}{dt} = ' + fmtAuto(o.dS, 4) + '\\;[\\mathrm{' + sy.uL + '^2/' + (sy.key === 'earth' ? 's' : '年') + '}]'
        ];
      }
    },
    {
      key: 'r', short: '$r$–$t$ 図', title: '$r$–$t$ 図（距離）', open: false,
      ylabel: 'r', xf: function (m, v, t) { return tPlot(v, t); },
      series: [{ color: COL.bound, f: function (m) { return m.r; } }]
    }
  ],
  draw: function (ctx, s, t, W, H) {
    var v = V(s), o = m13Orb(v), sy = sysOf(v), i;
    var vw = orbScene(W, H, o, { l: 52, r: 52, t: LAW_BAND + 26, b: 46 });
    s.view = vw;
    var wins = m13Windows(o), tp = m13Tperi(o, t);
    drawOrbitEllipse(ctx, vw, o, COL.orbit, [], 1.5);

    /* 3つの扇形（同じ Δt で掃くぶん）。
       「面積速度を比較」を押しているときは、3つの動径を同時に Δt だけ動かして、
       ぬられていく面積がぴったり同じになるところを見せる。 */
    var dtw = o.T / 12;
    var tau = s.o.cmp ? dtw * ((t / (o.T / 3)) % 1) : 0;
    wins.forEach(function (w) {
      var E1 = m13Ecc(o, w.t0), E2 = m13Ecc(o, w.t1);
      if (s.o.cmp) {
        drawSector(ctx, vw, o, E1, E2, w.col, 0.13);            /* Δt でぬられる予定のぶん */
        drawSector(ctx, vw, o, E1, m13Ecc(o, w.t0 + tau), w.col, 0.62);   /* いままでにぬったぶん */
      } else {
        var live = (tp >= w.t0 - 1e-9 && tp <= w.t1 + 1e-9);
        drawSector(ctx, vw, o, E1, E2, w.col, live ? 0.52 : 0.28);
      }
      var Em = (E1 + E2) / 2;
      var lx = vw.X(o.a * (Math.cos(Em) - o.e) * 0.72), ly = vw.Y(o.b * Math.sin(Em) * 0.72);
      label(ctx, w.name, lx, ly, { size: 13, bold: true, color: w.col });
    });

    var q = K.state(o, t, o.M0, false);
    var px = vw.X(q.x), py = vw.Y(q.y);
    drawCenterBody(ctx, vw.X(0), vw.Y(0), sy, sy.key === 'earth' ? 11 : 9);
    /* ★「面積速度を比較」の間は、ふつうの惑星（と動径・速度）は描かない★
       比べたいのは3本の動径が同じ時間に掃く面積なので、
       べつに動く惑星がいると、どれを見ればよいのか分からなくなるため。 */
    if (!s.o.cmp) {
      if (s.o.showR) radiusLine(ctx, vw.X(0), vw.Y(0), px, py, 'r = ' + fmtLen(q.r) + ' ' + sy.uL);
      planetShape(ctx, px, py, 6.5, sy.key === 'earth' ? '#c7ced6' : '#3f7f5f');
      label(ctx, sy.key === 'earth' ? '人工衛星' : '惑星', px, py - 14,
        { size: 11.5, bold: true, color: COL.ink });
    }
    /* どんな天体を考えているのかを、図のすみに書いておく */
    label(ctx, sy.key === 'earth'
      ? '※ 地球から 10000 km（高度 3600 km あたり）を回る人工衛星を考えています'
      : '※ 太陽から 1 AU（地球と同じくらい）のところを回る惑星を考えています',
      10, LAW_BAND + 14, { align: 'left', size: 10.5, color: COL.sub });
    if (s.o.showV && !s.o.cmp) {
      var vsc = 0.26 * Math.min(W, H) / Math.max(1e-9, o.vp);
      velArrow(ctx, px, py, q.vx, q.vy, vsc, 'v = ' + fmtAuto(q.v, 2) + ' ' + sy.uV, 10, -10);
      /* 速度の向き（動径に垂直な向きから測った角 φ）を、はじめの位置に書く */
      if (Math.abs(v.phi) > 2 && t < 1e-9) {
        var ur = { x: q.x, y: q.y }, rr = Math.hypot(ur.x, ur.y) || 1;
        var perp = Math.atan2(-(ur.x / rr), -(ur.y / rr));      /* 画面での「動径に垂直」な向き */
        var vang = Math.atan2(-q.vy, q.vx);
        angArc(ctx, px, py, 26, Math.min(perp, vang), Math.max(perp, vang),
          'φ = ' + fmt(v.phi, 0) + '°', null, 40);
      }
    }
    /* 「面積速度を比較」のときの3つの動径と球（惑星より前に描くと隠れるので、ここで描く） */
    if (s.o.cmp) {
      wins.forEach(function (w) {
        var Et = m13Ecc(o, w.t0 + tau);
        var bx = vw.X(o.a * (Math.cos(Et) - o.e)), by = vw.Y(o.b * Math.sin(Et));
        ctx.save();
        ctx.strokeStyle = w.col; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(vw.X(0), vw.Y(0)); ctx.lineTo(bx, by); ctx.stroke();
        ctx.restore();
        planetShape(ctx, bx, by, 5.2, w.col);
      });
      label(ctx, '3本の動径を、同じ時間 Δt = ' + tText(v, dtw) + ' だけ動かしています（ゆっくり再生）',
        W / 2, LAW_BAND + 32, { size: 11, bold: true, color: COL.sect1 });
    }

    drawLawBanner(ctx, W, '第2法則', lawTxt('k2n'));
    drawClock(ctx, W, 't = ' + tText(v, t), LAW_BAND + 14);
    label(ctx, 'それぞれの扇形を掃く時間 Δt = ' + tText(v, o.T / 12) + '（3つとも同じ）',
      10, H - 12, { align: 'left', size: 10.5, color: COL.sub });
    if (hintOn(s, t)) {
      /* 図の右上は速度の矢印が来ることがあるので、この文は右下に置く */
      label(ctx, '面積速度　S_1 = S_2 = S_3',
        W - 10, H - 30, { align: 'right', size: 12.5, color: COL.sect1, bold: true });
    }
  },
  result: function (v, s, t) {
    var o = m13Orb(v), sy = sysOf(v);
    var wins = m13Windows(o), dt = o.T / 12;
    var uA = sy.uL + '²/' + (sy.key === 'earth' ? 's' : '年');
    return {
      items: (sy.key === 'sun' ? resAT(o, sy, 3) : resAT(o, sy, 3).slice(0, 2)).concat([
        resItem('離心率 $\\varepsilon$', fmt(o.e, 3)),
        resItem('はじめの距離 $r_0$', fmtLen(o.r0) + ' ' + sy.uL),
        resItem('はじめの速さ $v_0$', fmtAuto(o.v0, 3) + ' ' + sy.uV),
        resItem('近点の速さ $v_{\\text{近}}$', fmtAuto(o.vp, 3) + ' ' + sy.uV),
        resItem('面積速度 $dS/dt$', fmtAuto(o.dS, 4) + ' ' + uA)
      ]),
      table: {
        head: ['扇形', 'どこで', '掃いた面積 [' + sy.uL + '²]', '掃いた時間'],
        rows: wins.map(function (w) {
          var E1 = m13Ecc(o, w.t0), E2 = m13Ecc(o, w.t1);
          return [w.name.replace('_', ''), w.where, fmtAuto(P.m13.sector(o, E1, E2), 4),
          (sy.key === 'earth' ? fmt(dt / 3600, 3) + ' 時間' : fmt(dt, 3) + ' 年')];
        }),
        kcol: 2
      },
      note: '3つの面積は<b>ぴったり同じ</b>（＝ 面積速度 × Δt = ' + fmtAuto(o.dS * dt, 4) + ' ' + sy.uL + '²）。' +
        'これがケプラーの第2法則です。スライドバーで軌道の形を変えても、3つは必ずそろいます。'
    };
  },
  info: function (s, t) {
    var v = V(s), o = m13Orb(v), sy = sysOf(v);
    var q = K.state(o, t, o.M0, false);
    return [
      ['距離 $r$', fmtLen(q.r) + ' ' + sy.uL],
      ['速さ $v$', fmtAuto(q.v, 3) + ' ' + sy.uV],
      ['動径方向の速さ $v_r$', fmtAuto(q.vr, 3) + ' ' + sy.uV],
      ['垂直方向の速さ $v_\\perp$', fmtAuto(q.vt, 3) + ' ' + sy.uV],
      ['$\\tfrac{1}{2}rv\\sin\\theta$（＝面積速度）', fmtAuto(0.5 * q.r * q.vt, 4)],
      ['面積速度 $dS/dt$', fmtAuto(o.dS, 4)],
      ['円軌道になる速さ $\\sqrt{GM/r_0}$', fmtAuto(o.vc, 3) + ' ' + sy.uV],
      ['時刻 $t$', tText(v, t)]
    ];
  },
  eq: function (s) {
    return '\\dfrac{dS}{dt} = \\dfrac{1}{2}\\,r\\,v\\sin\\theta = \\dfrac{L}{2m}\\;(\\text{一定})' +
      '\\qquad r_{\\text{近}}v_{\\text{近}} = r_{\\text{遠}}v_{\\text{遠}}';
  }
};

/* ============================================================
   1-4　ケプラーの第3法則（T² ∝ a³）
   ============================================================ */
/* ★1-3 は「太陽と惑星」「地球と人工衛星」の2つを切りかえられる★
   第3法則は「同じ天体のまわりをまわるもの同士」でしか成り立たない。
   それをいちばんはっきり見せるには、2つの系を見比べるのがよい
   （K の値は系ごとにまったく違うのに、同じ系の中ではきれいにそろう）。
   衛星のデータは 30_physics.js の SATS。惑星と同じ形にしてあるので、
   planetXY などの関数はそのまま使える。 */
var M14_SETS = {
  sun: {
    ids: ['mercury', 'earth', 'uranus'],
    body: function (id) { return planetById(id); },
    all: function () { return PLANETS.filter(function (p) { return !p.comet; }); },
    center: '太陽', uL: 'AU', uT: '年', uK: '年²/AU³',
    lmin: 0.05, rmax: 25, rings: [0.5, 1, 5, 10, 20], ringLab: [1, 5, 20],
    tEnd: 90, rate: 0.42,
    aFmt: function (a) { return fmt(a, 3); },
    tFmt: function (T) { return fmt(T, 2) + ' 年'; },
    clock: function (t) { return fmt(t, 2) + ' 年'; },
    kFmt: function (k) { return fmt(k, 4); },
    gx: { lo: 0.3, hi: 60, ylo: 0.1, yhi: 1000, linHi: 25, linYhi: 110 },
    gLab: { x: 'a [AU]', y: 'T [年]' },
    tPlot: function (t) { return t; }, tPlotLab: 't [年]',
    note: '半長軸 a は <b>0.39 : 1 : 19.2</b> なのに、周期 T は <b>0.24 : 1 : 84</b>。' +
      '（a が 49 倍で T は 349 倍＝ 49<sup>3/2</sup> 倍）それでも <b>T²/a³</b> の列は3つともそろいます。'
  },
  earth: {
    ids: ['iss', 'hst', 'gps', 'himawari', 'moon'],
    body: function (id) { return satById(id); },
    all: function () { return SATS; },
    center: '地球', uL: 'km', uT: 's', uK: 's²/km³',
    lmin: 2500, rmax: 700000, rings: [7000, 20000, 50000, 200000, 500000], ringLab: [7000, 50000, 400000],
    tEnd: 2400000, rate: 2400000 / 214,
    aFmt: function (a) { return fmt(a, 0); },
    tFmt: function (T) {
      if (T < 7200) return fmt(T / 60, 1) + ' 分';
      if (T < 200000) return fmt(T / 3600, 2) + ' 時間';
      return fmt(T / 86400, 2) + ' 日';
    },
    clock: function (t) { return fmt(t / 86400, 2) + ' 日'; },
    kFmt: function (k) { return fmtE(k, 3); },
    gx: { lo: 5000, hi: 600000, ylo: 3000, yhi: 5e6, linHi: 400000, linYhi: 2.6e6 },
    gLab: { x: 'a [km]', y: 'T [s]' },
    tPlot: function (t) { return t / 86400; }, tPlotLab: 't [日]',
    note: '半長軸 a は <b>ISS の 6771 km</b> から <b>月の 384400 km</b> まで <b>57 倍</b>も違い、' +
      '周期はそのぶん <b>92 分から 27 日</b>（426 倍＝ 57<sup>3/2</sup> 倍）までひらきます。' +
      'それでも <b>T²/a³</b> の列はきれいにそろいます（月だけ 1 % ほどずれるのは、' +
      '太陽の引力を受けて軌道が少しゆがむため）。'
  }
};
function m14Set(v) { return M14_SETS[v.sys14] || M14_SETS.sun; }
function m14Bodies(v) { var S = m14Set(v); return S.ids.map(S.body); }
/* ★いま選んでいる天体★（1-0 と同じしくみ。T–a 図の点か、図の中の天体を押すと決まる）
   描画対象を切りかえると、選んでいた天体が画面から消えることがある。
   そのときは「選んでいない」に戻す（表の行も、図の輪も出さない）。 */
function m14Pick(v) {
  var id = v.pick14 || '', S = m14Set(v);
  if (!id || S.ids.indexOf(id) < 0) return null;
  return S.body(id);
}

DEFS['m1-4'] = {
  id: 'm1-4', mode: 1, tab: '1-3 第3法則（T²/a³=一定）', autoplay: true,
  legendKeys: ['sun', 'orbit'],
  units: function (v) { return (v.sys14 === 'earth') ? [] : ['AU']; },
  title: function () { return '1-3　ケプラーの第3法則　—　' + lawTxt('k3') + '　T²/a³=K（一定）'; },
  sub: function (v) {
    var e = (v.sys14 === 'earth');
    return '<b>第3法則</b>：' + LAW.k3 + '（<b>T² / a³ = K</b>）。　' + LAW.n3 + '。<br>' +
      (e ? '<b>ISS・ハッブル宇宙望遠鏡・GPS衛星・ひまわり・月</b>を同時に回してみると、'
        : '<b>水星・地球・天王星</b>を同時に回してみると、') +
      '遠いものほどゆっくりで、1周にかかる時間が長いことが分かります。' +
      '下の表の右端の列（K）が<b>全部そろう</b>ことを確かめよう。<br>' +
      '<b>図の中の天体か、$T$–$a$ 図の点をクリック</b>すると、その天体の $a$・$T$・$K$ が' +
      '上の帯に出て、<b>下の表の行</b>もいっしょに光ります。<br>' +
      '<b>「描画対象」を切りかえて、太陽系と地球のまわりを見比べよう。</b>' +
      'K の値は<b>系が違えばまったく違う</b>のに、<b>同じ系の中ではそろう</b>——' +
      'これが「※ 同じ天体の周りをまわるもの同士で成り立つ」の意味です。<br>' +
      '※ この図も、' + m14Set(v).center + 'からの距離は<b>対数のものさし</b>（10倍ごとに同じ幅）で縮めています。回る角度はそのままです。';
  },
  /* ★「比例する」だけでは、何がうれしいのか生徒に伝わらない★（先生の指示）
     法則の文（LAW.k3）のすぐあとに、その意味を言いかえた一言を足す。 */
  note: '<b>' + LAW.k3 + '、つまり軌道が大きいほど周期が長い</b>（' + LAW.n3 +
    '）——これが第3法則です。' +
    'だから $T^2/a^3$（＝ $K$）は、<b>同じ天体のまわりを回るもの同士なら同じ値</b>になります' +
    '（太陽系では 1.00 年²/AU³、地球のまわりでは 9.90×10⁻⁵ s²/km³）。' +
    '$T$–$a$ 図を<b>両対数</b>にすると $\\log T = \\tfrac{3}{2}\\log a$ となり、<b>傾き 3/2 の直線</b>にのることが見えます。',
  cw: 560, ch: 400,
  consts: { logmode: 'log', sys14: 'sun', pick14: '' },
  vis: ['O', 'T'],
  visLabel: { O: '軌道を表示', T: '通ってきた道すじ' },
  vars: [],
  sysToggle: true,               /* 描画対象はタイトルの横の共通ボタンで切りかえる */
  legendBodies: function (v) {
    return m14Bodies(v).map(function (p) { return { name: p.name, col: p.col }; });
  },
  tEnd: function (v) { return m14Set(v).tEnd; },
  /* スタートしたときの速さ＝これまでの「スロー再生」のさらに 0.75 倍（2.25 × 0.25 × 0.75） */
  rate: function (v) { return m14Set(v).rate; },
  loop: true,
  tFmt: function (t, v) { return m14Set(v || { sys14: 'sun' }).clock(t); },
  xlabel: 't',
  tGraph: function (v) { return m14Set(v).tEnd / 7.5; },
  sample: function (v, t) {
    var S = m14Set(v), out = { t: t };
    S.ids.forEach(function (id) { out[id] = planetXY(S.body(id), t); });
    out.r = out[S.ids[1]].r; out.v = out[S.ids[1]].v;
    return out;
  },
  graphs: [
    {
      key: 'ta', short: '$T$–$a$ 図', title: '$T$–$a$ 図（ケプラーの第3法則）', open: true,
      sw: {
        k: 'logmode', label: '軸の目もり：',
        options: [{ v: 'log', label: '両対数' }, { v: 'lin', label: '両方リニア' }]
      },
      custom: function (v) {
        var S = m14Set(v), g = S.gx;
        var lg = (v.logmode === 'log'), i, line = [];
        /* 「T² = K a³」の線。K はその系の値（＝いちばん内側の天体から出す） */
        var b0 = S.body(S.ids[0]);
        var Kc = b0.T * b0.T / (b0.a * b0.a * b0.a);
        var amax = lg ? g.hi : g.linHi, amin = lg ? g.lo : 0;
        for (i = 0; i <= 80; i++) {
          var a = lg ? (amin * Math.pow(amax / amin, i / 80)) : (amax * i / 80);
          line.push([a, Math.sqrt(Kc * a * a * a)]);
        }
        var on = S.ids, pk = m14Pick(v);
        var marks = S.all().map(function (p, j) {
          var hit = on.indexOf(p.id) >= 0;
          /* ★左のはしにある天体は、名前を「右がわ」に出す★
             左に出すとグラフの枠の外に行ってしまい、
             水星の名前がまったく見えなくなっていた（先生の指摘）。 */
          var frac = lg ? (Math.log(p.a / amin) / Math.log(amax / amin)) : (p.a / amax);
          var left = (frac > 0.3) && (j % 2 === 0);
          /* ★青い輪は「いま選んでいる天体」だけ★（1-0 とそろえた・2026-09-05）
             前は「いま描いている天体」ぜんぶに輪を付けていたが、
             それは色（灰色か色つきか）・大きさ・名前の有無でもう分かるので、
             輪は選んだ1つのためにあけておく。
             ★id を書いた点だけが押せる★（80_ui.js の attachGraphPick）。 */
          return {
            id: hit ? p.id : '',
            x: p.a, y: p.T, color: hit ? p.col : '#c3cbd3',
            r: hit ? ((pk && pk.id === p.id) ? 7 : 6) : 3.4,
            name: hit ? p.name : '', ring: !!(pk && pk.id === p.id),
            lx: left ? -11 : 11, align: left ? 'right' : 'left',
            ly: (j % 2 ? 13 : -13)
          };
        });
        return {
          logx: lg, logy: lg,
          xmin: lg ? g.lo : 0, xmax: lg ? g.hi : g.linHi,
          ymin: lg ? g.ylo : 0, ymax: lg ? g.yhi : g.linYhi,
          xlabel: S.gLab.x, ylabel: S.gLab.y,
          series: [{ color: COL.orbit, dash: [6, 4], width: 1.6, pts: line }],
          marks: marks
        };
      },
      fml: function (v) {
        return [
          'T^2 = K a^3 \\quad\\Rightarrow\\quad T = \\sqrt{K}\\,a^{3/2}',
          '\\log T = \\dfrac{3}{2}\\log a + \\text{(定数)}\\;\\;(\\text{両対数だと傾き } 3/2 \\text{ の直線})',
          (v.logmode === 'log') ? '\\text{いまは両対数（直線になる）}' : '\\text{いまはリニア（曲線になる）}'
        ];
      }
    },
    {
      /* 天体の顔ぶれが「描画対象」で変わるので、series は custom の中で組み立てる */
      key: 'rt', short: '$r$–$t$ 図', title: '$r$–$t$ 図（それぞれの距離）', open: false,
      custom: function (v) {
        var S = m14Set(v), N = 400, T = S.tEnd / 7.5, i;
        var series = S.ids.map(function (id) {
          var p = S.body(id), pts = [];
          for (i = 0; i <= N; i++) {
            var tt = T * i / N;
            pts.push([S.tPlot(tt), planetXY(p, tt).r]);
          }
          return { color: p.col, name: p.name, width: 1.8, pts: pts };
        });
        var last = S.body(S.ids[S.ids.length - 1]);
        return {
          xmin: 0, xmax: S.tPlot(T), ymin: 0, ymax: last.a * 1.12,
          xlabel: S.tPlotLab, ylabel: 'r [' + S.uL + ']',
          legend: true, series: series
        };
      }
    }
  ],
  /* ★T–a 図の点を押すと、その天体が選ばれる★（1-0 と同じ・先生の指示・2026-09-05）
     選ぶと「計算結果」の帯・下の表の行・図の中の輪が、いっしょにその天体に変わる。 */
  pickMark: function (s, id) { s.o.pick14 = id; },
  /* 図の中の天体を押しても選べる（1-0 と同じ）。s.ui.dots は draw が覚えている。 */
  drag: function (s, x, y, lx, ly) {
    var dots = (s.ui && s.ui.dots) || [], i, best = null, bd = 20;
    for (i = 0; i < dots.length; i++) {
      var dd = Math.hypot(dots[i].px - lx, dots[i].py - ly);
      if (dd < bd) { bd = dd; best = dots[i].id; }
    }
    /* ★「もう一度押したら選択を消す」にしてはいけない★
       drag はドラッグ中に何度も呼ばれるので、1回のクリックで
       付いたり消えたりをくり返してしまう（1-0 と同じく「入れるだけ」にする）。 */
    if (best) s.o.pick14 = best;
  },
  dragKeepT: true,
  draw: function (ctx, s, t, W, H) {
    var v = V(s), S = m14Set(v), i;
    var cx = W / 2, cy = LAW_BAND + 10 + (H - LAW_BAND - 10 - 40) / 2;
    var Rpx = Math.min(W - 44, H - LAW_BAND - 52) / 2;
    var rmax = S.rmax, LMIN = S.lmin;   /* ものさしの内側の端。小さくするほど内側の軌道が大きく描ける */
    function rpx(r) {
      var a = Math.log(LMIN) / Math.LN10, b = Math.log(rmax) / Math.LN10;
      var q = (Math.log(Math.max(1e-3, r)) / Math.LN10 - a) / (b - a);
      return clamp(q, 0, 1) * Rpx;
    }
    /* ★天体ごとに「1つの縮尺」を使う★
       点ごとに対数のものさしを当てると、水星のように内側の天体では
       ものさしの下限で頭打ちになり、軌道がでこぼこの折れ線に見えてしまう。
       そこで「その天体の半長軸 a を対数のものさしに置いた大きさ」から縮尺を1つ決め、
       軌道はその縮尺で相似に縮めて描く。こうすると、どの天体の軌道もきれいな楕円になる。
       （天体どうしの距離の比は正確でなくなるが、回る角度と速さの比は正しいままなので、
         第3法則を見るという目的には差しつかえない。） */
    function kOf(p) { return rpx(p.a) / p.a; }
    function mapP(p, x, y) { var k = kOf(p); return [cx + x * k, cy - y * k]; }
    ctx.save();
    ctx.strokeStyle = COL.grid; ctx.lineWidth = 1;
    S.rings.forEach(function (r) {
      ctx.beginPath(); ctx.arc(cx, cy, rpx(r), 0, TAU); ctx.stroke();
    });
    ctx.restore();
    /* 目もりの文字は、対数のものさしだと近づきすぎるので3つだけにする */
    S.ringLab.forEach(function (r) {
      label(ctx, fmt(r, 0) + ' ' + S.uL, cx - rpx(r) * 0.707, cy - rpx(r) * 0.707,
        { size: 9.5, color: '#b3bcc5' });
    });

    m14Bodies(v).forEach(function (p) {
      if (s.o.showO) {
        var pts = planetOrbitPts(p, 480);
        ctx.save();
        ctx.strokeStyle = fade(p.col, 0.6); ctx.lineWidth = 1.3;
        ctx.beginPath();
        pts.forEach(function (q, j) {
          var sp = mapP(p, q[0], q[1]);
          if (j === 0) ctx.moveTo(sp[0], sp[1]); else ctx.lineTo(sp[0], sp[1]);
        });
        ctx.closePath(); ctx.stroke();
        ctx.restore();
      }
      if (s.o.showT && t > 1e-6) {
        var tp2 = planetTrailPts(p, t, trailN(p, t));
        ctx.save();
        ctx.strokeStyle = fade(p.col, 0.9); ctx.lineWidth = 2.4; ctx.lineCap = 'round';
        ctx.beginPath();
        tp2.forEach(function (qq, jj) {
          var pp = mapP(p, qq[0], qq[1]);
          if (jj === 0) ctx.moveTo(pp[0], pp[1]); else ctx.lineTo(pp[0], pp[1]);
        });
        ctx.stroke();
        ctx.restore();
      }
    });
    if (S.center === '地球') {
      earthShape(ctx, cx, cy, 10, 0);
      label(ctx, '地球', cx, cy + 22, { size: 11.5, color: '#2a5f96', bold: true });
    } else {
      sunShape(ctx, cx, cy, 9, '太陽');
    }
    /* 天体（先に丸を描いて、そのあとで周期の吹き出しを上にのせる） */
    var bl = m14Bodies(v), pk = m14Pick(v);
    s.ui.dots = [];                       /* クリックで選べるように、画面の位置を覚えておく */
    bl.forEach(function (p) {
      var q = planetXY(p, t), sp = mapP(p, q.x, q.y);
      var rr = clamp(p.r, 3.4, 7);
      planetShape(ctx, sp[0], sp[1], rr, p.col);
      /* いま選んでいる天体には青い輪をつける（T–a 図の点と、下の表の行と同じ天体） */
      if (pk && pk.id === p.id) {
        ctx.save();
        ctx.strokeStyle = COL.accentRing || '#1663b5'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(sp[0], sp[1], rr + 5.5, 0, TAU); ctx.stroke();
        ctx.restore();
      }
      s.ui.dots.push({ id: p.id, px: sp[0], py: sp[1] });
    });
    /* ===== 名前と周期の出し方 =====
       ★太陽と惑星のときは、1-0 と同じく「吹き出しなしで星についていく名前」★（先生の指示）
       ただし いちばん内側の水星だけは、軌道が小さくて名前が太陽と重なるので、
       太陽のすぐ上に「水星」とだけ置いて動かさない。
       ★地球と人工衛星のときは、内側の4つ（ISS・ハッブル・GPS・ひまわり）が
         全部中心に集まってしまうので、これまでどおり左下の吹き出しにする。★ */
    if (v.sys14 === 'sun') {
      bl.forEach(function (p, j) {
        if (j === 0) {
          /* 水星：太陽のすぐ上に、名前だけ */
          label(ctx, p.name, cx, cy - 26,
            { size: 11, bold: true, color: p.col });
          return;
        }
        var q3 = planetXY(p, t), sp3 = mapP(p, q3.x, q3.y);
        var rr3 = clamp(p.r, 3.4, 7);
        label(ctx, p.name + ' T = ' + S.tFmt(p.T),
          clamp(sp3[0], 60, W - 60), clamp(sp3[1] - rr3 - 10, LAW_BAND + 30, H - 46),
          { size: 11, bold: true, color: p.col });
      });
    } else {
      var inner = bl.slice(0, bl.length - 1), outer = bl[bl.length - 1];
      inner.forEach(function (p, j) {
        var by = H - 44 - (inner.length - 1 - j) * 23, bx = 92;
        var R0 = rpx(p.a);
        var ax = cx - R0 * 0.707, ay = cy + R0 * 0.707;   /* 軌道の左下（45°）の点 */
        ctx.save();
        ctx.strokeStyle = fade(p.col, 0.8); ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(bx, by - 8); ctx.lineTo(ax, ay); ctx.stroke();
        ctx.restore();
        bubble(ctx, (p.short || p.name) + ' T = ' + S.tFmt(p.T), bx, by,
          { size: 10.5, bg: '#ffffff', border: p.col, color: p.col, up: true });
      });
      (function () {
        var q2 = planetXY(outer, t), sp2 = mapP(outer, q2.x, q2.y);
        bubble(ctx, (outer.short || outer.name) + ' T = ' + S.tFmt(outer.T),
          clamp(sp2[0], 82, W - 82), Math.max(LAW_BAND + 44, sp2[1] - 10),
          { size: 10.5, bg: '#ffffff', border: outer.col, color: outer.col });
      })();
    }
    drawLawBanner(ctx, W, '第3法則', lawTxt('k3n'));
    drawClock(ctx, W, 't = ' + S.clock(t), LAW_BAND + 14);
    label(ctx, '※ ' + S.center + 'からの距離は対数のものさし（回る角度はそのまま）', 10, H - 12,
      { align: 'left', size: 10.5, color: COL.sub });
    if (hintOn(s, t)) {
      label(ctx, '遠いものほど1周に時間がかかる（T² ∝ a³）', W - 10, H - 30,
        { align: 'right', size: 11.5, color: COL.bound, bold: true });
    }
  },
  result: function (v, s, t) {
    var S = m14Set(v);
    var bl = m14Bodies(v);
    var rows = bl.map(function (p) {
      return [p.name, S.aFmt(p.a), S.tFmt(p.T), S.kFmt(p.T * p.T / (p.a * p.a * p.a)),
        fmt(t / p.T, 2) + ' 周'];
    });
    /* ★選んだ天体があれば、その天体の値を帯に出す★（T–a 図か図の中を押して選ぶ）
       選んでいないときは、これまでどおり2番目の天体（地球／ハッブル）を出す。 */
    var pk = m14Pick(v), e = pk || bl[1];
    return {
      items: [
        resItem('半長軸 $a$（' + e.name + '）', S.aFmt(e.a) + ' ' + S.uL),
        resItem('周期 $T$（' + e.name + '）', S.tFmt(e.T)),
        resItem('$K = T^2/a^3$', S.kFmt(e.T * e.T / (e.a * e.a * e.a)) + ' ' + S.uK, true)
        /* ★「経過した時間」は消した★ 時間のバー・図の中の時計・グラフの横軸と
           まったく同じことを4か所目に書いていて、帯を長くするだけだった。 */
      ],
      table: {
        head: ['天体', '半長軸 a [' + S.uL + ']', '周期 T', 'K = T²/a³ [' + S.uK + ']', 'いままでに回った数'],
        rows: rows, kcol: 3,
        /* pick に名前を書くと、その行が光る（80_ui.js の renderResult） */
        pick: pk ? pk.name : null
      },
      note: S.note
    };
  },
  info: function (s, t) {
    var v = V(s), S = m14Set(v);
    return m14Bodies(v).map(function (p) {
      var q = planetXY(p, t);
      return [p.name + 'の距離 $r$', S.aFmt(q.r) + ' ' + S.uL];
    }).concat([['経過した時間 $t$', S.clock(t)]]);
  },
  eq: function () {
    return EQM + 'm\\dfrac{4\\pi^2 r}{T^2} = G\\dfrac{mM}{r^2} \\;\\Rightarrow\\; ' +
      '\\dfrac{T^2}{r^3} = \\dfrac{4\\pi^2}{GM}\\;(\\text{一定})';
  }
};

/* ============================================================
   1-5　ひとつの星で見る第1〜第3法則
   ============================================================ */
/* ★速さの決め方は 2-2（軌道の種類と宇宙速度）とそろえてある★
   近地点での速さを $v_0 = \\sqrt{k\\,GM/r_0}$ と書き、その **k** をスライドバーで変える。
   k = 1 が円軌道、k = 2 が脱出（第二宇宙速度）。
   ページの中で「速さの表し方」が2通りあると生徒が混乱するので、必ずこの形にそろえること。 */
/* 1-4 も「太陽と惑星／地球と人工衛星」を選べる（先生の指示）。
   近点の距離は単位が違う（AU と km）ので、1-1・1-2 と同じく変数を2本立てにしてある。 */
function r0Of(v) { return (v.sys === 'earth') ? v.r0 : v.r0S; }
function m15Orb(v) {
  var sys = sysOf(v);
  return P.m15.boost(r0Of(v), Math.sqrt(v.k), sys);
}
/* 近点・遠点の呼び名（太陽まわりは近日点／地球まわりは近地点） */
function periName(v) { return (v.sys === 'earth') ? '近地点' : '近日点'; }
function apoName(v) { return (v.sys === 'earth') ? '遠地点' : '遠日点'; }
DEFS['m1-5'] = {
  id: 'm1-5', mode: 1, tab: '1-4 まとめ：ひとつの天体で第1〜3法則',
  legendKeys: ['sun', 'vel', 'dim', 'bound', 'sect'],
  title: '1-4　まとめ：ひとつの天体でみる、ケプラーの第1〜第3法則',
  sysToggle: true,               /* 描画対象はタイトルの横の共通ボタンで切りかえる */
  units: function (v) { return (v.sys === 'earth') ? [] : ['AU', 'year']; },
  sub: function (v) {
    var e = (v.sys === 'earth');
    return 'はじめは<b>等速円運動</b>している' + (e ? '人工衛星' : '惑星') + 'です。'
      + (e ? '近地点' : '近日点') + 'での速さを '
      + '$v_0 = \\sqrt{k\\,GM/r_0}$ と書き、その <b>k</b> を大きくしていきます'
      + '（2-2 と同じ書き方です。<b>k = 1 が円軌道</b>、<b>k = 2 が脱出</b>）。<br>'
      + '<b>「軌道を大きくする →」</b>を押すたびに' + (e ? '近地点' : '近日点') + 'で少しだけ加速して'
      + '<b>力学的エネルギー E が上がり</b>、軌道が<b>楕円にふくらんで周期も長くなります</b>'
      + '（＝第1法則と第3法則）。<b>「面積速度を見る」</b>にチェックを入れると、運動中ずっと'
      + '<b>単位時間あたりに通過する面積が同じ</b>ことが見えます（＝第2法則）。<br>'
      + '<b>タイトルの横の「描画対象」で、太陽と惑星／地球と人工衛星を切りかえられます。</b>'
      + '<b>どちらでも、まったく同じ3つの法則が成り立つ</b>ことを確かめよう。';
  },
  note: '<b>この1つの図で、ケプラーの3つの法則が全部確かめられます。</b><br>' +
    '① 軌道はいつも<b>楕円</b>で、中心の天体はその<b>焦点</b>にある（第1法則）。<br>' +
    '② <b>「面積速度を見る」</b>にチェックを入れると、同じ時間ごとにぬり分けた扇形が' +
    '<b>どこでも同じ面積</b>になる（第2法則）。<br>' +
    '③ k を大きくすると <b>a が大きくなり、T も長くなる</b>（第3法則。$T^2/a^3$ は変わりません）。' +
    '<br>' +
    '<span class="q2">なぜ $v$ を上げると $T$ が長くなるのか</span>' +
    'ここでいう <b>$E$ は力学的エネルギー</b>のことで、' +
    '<b>$E = \\dfrac{1}{2}mv^2 - G\\dfrac{Mm}{r}$</b>（運動エネルギー＋位置エネルギー）。' +
    '軌道のどこで計算しても同じ値になります。<br>' +
    '出発点（近地点）の距離 $r_0$ は k を変えても動かないので、' +
    '<b>$v$ を上げれば $E$ が上がります</b>。そして楕円軌道では' +
    '<b>$E = -\\dfrac{GMm}{2a}$</b> が成り立つので、$E$ が上がると $a$ が大きくなり、' +
    '第3法則 $T^2 \\propto a^3$ より $T$ が長くなります。つまり<br>' +
    '<b>$v$ を上げる　→　$E$ が上がる　→　$a$ が大きくなる　→　$T$ が長くなる</b><br>' +
    '<span class="mini">※ ここで $E$ をはさむのは、<b>楕円だと「速さ」が場所ごとに違う</b>からです。' +
    '円軌道なら $v=\\sqrt{GM/r}$、$T=2\\pi r/v$ と、$v$ だけで話が終わります。' +
    'でも楕円では、近地点で速く遠地点で遅い——どの $v$ のことか決まりません。' +
    'いっぽう <b>$E$ は軌道のどこで測っても同じ</b>で、しかも $a$ とだけ結びつく。' +
    'だから「$v$ → $E$ → $a$ → $T$」と、$E$ を通すのがいちばん見通しがよいのです。</span><br>' +
    'なお<b>近地点（出発点）は k を変えても動きません</b>。遠くなるのは反対側（遠地点）だけです。' +
    '$k = 2$ にすると軌道は閉じなくなります（＝第二宇宙速度）。' +
    '宇宙速度について詳しくは ' +
    '<b><a href="#m2-3" data-goto="m2-3">2-2 軌道の種類と宇宙速度</a></b> を見てください。',
  cw: 560, ch: 408,
  vis: ['V', 'R', 'S'],
  visLabel: { V: '速度を表示', R: '動径を表示', S: '面積速度を見る' },
  visDef: { S: false },
  visFocus: 'S',                    /* まだ押していないうちは、オレンジで脈打たせて誘導する */
  vars: [
    {
      k: 'k', label: '近地点の速さ $v_0=\\sqrt{k\\,GM/r_0}$ の $k$', unit: '',
      /* ★説明は1行に収めること★（長いとスライドバーの欄がふくらんで読みにくくなる） */
      hint: '<b>円軌道の速さの $\\sqrt{k}$ 倍</b>という意味（2-1・2-2 と同じ）',
      min: 1.0, max: 1.9, step: 0.1, dec: 1, def: 1.0
    },
    {
      k: 'r0', label: '近地点の距離 $r_0$（地球の中心から）', unit: ' km',
      min: 7000, max: 12000, step: 500, dec: 0, def: 7000,
      when: function (v) { return v.sys === 'earth'; }
    },
    {
      k: 'r0S', label: '近日点の距離 $r_0$（太陽から）', unit: ' AU',
      min: 0.8, max: 1.4, step: 0.1, dec: 1, def: 0.8,
      when: function (v) { return v.sys !== 'earth'; }
    }
  ],
  mainVars: ['k', 'r0', 'r0S'],
  /* いちばん見せたい2つは、図の左上（.topacts）に置く */
  topActions: [
    {
      label: '軌道を大きくする →', prim: true, play: true,
      fn: function (s) { stepUp(DEFS['m1-5'], s, 'k', 0.1); }
    },
    {
      label: '等速円運動に戻す（k = 1）',
      fn: function (s) { s.v.k = 1.0; },
      is: function (v) { return Math.abs(v.k - 1) < 1e-9; }
    }
  ],

  tEnd: function (v) { return m15Orb(v).T; },
  rate: function (v) { return m15Orb(v).T / 10; },
  loop: true,
  tFmt: function (t, v) { return tText(v || { sys: 'earth' }, t); },
  xlabel: function (v) { return tPlotLabel(v); },
  sample: function (v, t) {
    var o = m15Orb(v);
    var q = K.state(o, t, 0, false);
    q.dS = o.dS; q.Em = o.Em;
    return q;
  },
  graphs: [
    {
      key: 'r', short: '$r$–$t$ 図', open: true,
      title: function (v) {
        return '$r$–$t$ 図（' + ((v.sys === 'earth') ? '地球の中心' : '太陽') + 'からの距離）';
      },
      ylabel: function (v) { return 'r [' + sysOf(v).uL + ']'; },
      xf: function (m, v, t) { return tPlot(v, t); },
      series: [{ color: COL.bound, f: function (m) { return m.r; } }],
      fml: function (v) {
        var o = m15Orb(v);
        return [
          'r_{\\text{近}} = a(1-\\varepsilon),\\quad r_{\\text{遠}} = a(1+\\varepsilon)',
          'a = -\\dfrac{GM}{2E}\\;\\;(E\\text{ は単位質量あたり})',
          'r_{\\text{近}} = ' + fmtLen(o.rp) + ',\\;\\; r_{\\text{遠}} = ' + fmtLen(o.ra)
            + '\\;[\\mathrm{' + sysOf(v).uL + '}]'
        ];
      }
    },
    {
      key: 'v', short: '$v$–$t$ 図', title: '$v$–$t$ 図（速さ）', open: false,
      ylabel: function (v) { return 'v [' + sysOf(v).uV + ']'; },
      xf: function (m, v, t) { return tPlot(v, t); },
      series: [{ color: COL.vel, f: function (m) { return m.v; } }]
    },
    {
      key: 'ds', short: '$dS/dt$–$t$ 図', title: '$dS/dt$–$t$ 図（面積速度）　※ずっと一定', open: false,
      ylabel: function (v) { return 'dS/dt [' + sysOf(v).uL + '²/' + sysOf(v).uT + ']'; },
      xf: function (m, v, t) { return tPlot(v, t); },
      series: [{ color: COL.sect1, f: function (m) { return m.dS; } }],
      fml: function (v) {
        var o = m15Orb(v);
        return [
          '\\dfrac{dS}{dt} = \\dfrac{1}{2} r v \\sin\\theta\\;(\\text{一定})',
          '\\dfrac{dS}{dt} = \\dfrac{1}{2} r_0 v_0\\;\\;(\\text{' + periName(v) + 'では }\\theta = 90^\\circ)',
          '\\dfrac{dS}{dt} = ' + fmtE(o.dS, 3) + '\\;[\\mathrm{' + sysOf(v).uL + '^2/' + sysOf(v).uT + '}]'
        ];
      }
    }
  ],
  draw: function (ctx, s, t, W, H) {
    var v = V(s), sys = sysOf(v), i;
    var o = m15Orb(v);
    /* 縮尺は「いちばん大きくしたときの軌道」に合わせて固定する（ふくらむのが見えるように） */
    var oMax = P.m15.boost(r0Of(v), 1.30, sys);
    /* もし（テストなどで）上限より大きい軌道になっても絵がこわれないよう、大きい方に合わせる */
    var Ra = Math.max(oMax.ra, o.ra), Rb = Math.max(oMax.b, o.b);
    var vwBox = { x0: -Ra, x1: oMax.rp, y0: -Rb, y1: Rb };
    var mx = (vwBox.x1 - vwBox.x0) * 0.05, my = (vwBox.y1 - vwBox.y0) * 0.08;
    var vw = mkView(W, H, { l: 46, r: 46, t: LAW_LIST + 14, b: 44 },
      { x0: vwBox.x0 - mx, x1: vwBox.x1 + mx, y0: vwBox.y0 - my, y1: vwBox.y1 + my });
    s.view = vw;

    /* いちばん大きい軌道（めやす） */
    drawOrbitEllipse(ctx, vw, oMax, COL.grid, [4, 4], 1.2);
    /* ★近点の距離は r0Of(v) で取ること★（v.r0 は「地球と人工衛星」用の km の変数）。
       ここだけ v.r0 のままだったので、「太陽と惑星」を選ぶと
       a = 7000 AU（本当は 0.8 AU）の巨大なだ円を破線で描こうとして、
       1フレーム 200 ms かかっていた（＝アニメーションが6倍おそく見えた）。 */
    drawOrbitEllipse(ctx, vw, P.m15.boost(r0Of(v), 1.0, sys), COL.orbit, [3, 3], 1.2);
    drawOrbitEllipse(ctx, vw, o, orbColor(K.kind(o.Em, o.e)), orbDash(K.kind(o.Em, o.e)), 2.2);

    /* 面積速度：これまでに掃いた扇形を、同じ Δt ごとに色をかえて塗る */
    if (s.o.showS) {
      var dt = o.T / 16;
      for (i = 0; i < 16; i++) {
        var ta = dt * i, tb2 = Math.min(t, dt * (i + 1));
        if (tb2 <= ta + 1e-9) break;
        drawSector(ctx, vw, o, K.ecc(TAU * ta / o.T, o.e), K.ecc(TAU * tb2 / o.T, o.e),
          (i % 2 === 0) ? COL.sect1 : COL.sect2, 0.30);
      }
      label(ctx, '同じ時間 Δt = '
        + ((v.sys === 'earth') ? (fmt(o.T / 16 / 60, 1) + ' 分') : (fmt(o.T / 16, 3) + ' 年'))
        + 'ごとに色をかえています', 10, H - 12,
        { align: 'left', size: 10.5, color: COL.sub });
    }

    /* 地球（自転も描く）。
       面積速度を見ているときは、扇形が地球にかくれてしまうので半透明にする。 */
    var Rearth = Math.max(6, (vw.X(sys.R) - vw.X(0)));
    ctx.save();
    if (s.o.showS) ctx.globalAlpha = 0.33;
    /* ★自転（模様の回転）は描かない★（先生の指摘）
       前は t/86164·2π で地球を回していた。物理としては本当の自転だが、
       このシムは軌道の話しかしていないので「なぜ模様が動くのか」という別の疑問を生むだけ。
       自転を見せたいのは 2-3 と「補足：地球と月」だけにする。 */
    drawCenterBody(ctx, vw.X(0), vw.Y(0), sys, Rearth, undefined, 0);
    ctx.restore();

    var q = K.state(o, t, 0, false);
    var px = vw.X(q.x), py = vw.Y(q.y);
    if (s.o.showR) radiusLine(ctx, vw.X(0), vw.Y(0), px, py,
      'r = ' + fmtLen(q.r) + ' ' + sys.uL);
    planetShape(ctx, px, py, 5.2, '#c7ced6');
    label(ctx, sys.body, px + (q.x < 0 ? -10 : 10), py - 11,
      { size: 11, color: COL.ink, align: q.x < 0 ? 'right' : 'left' });
    if (s.o.showV) {
      var vsc = 0.22 * Math.min(W, H) / Math.max(1e-9, oMax.vp);
      velArrow(ctx, px, py, q.vx, q.vy, vsc, 'v = ' + fmt(q.v, 2) + ' ' + sys.uV, 10, -10);
    }
    /* 近地点の目印 */
    /* 近地点の目印（エネルギーを上げても、ここだけは動かない） */
    ctx.save();
    ctx.strokeStyle = COL.sub; ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(vw.X(o.rp), vw.Y(0) - 7); ctx.lineTo(vw.X(o.rp), vw.Y(0) + 7);
    ctx.stroke();
    ctx.restore();
    label(ctx, periName(v), vw.X(o.rp) + 12, vw.Y(0) + 13,
      { size: 10.5, color: COL.sub, align: 'left' });
    /* この図だけで第1〜第3法則を全部確かめられるので、3つとも上に書いておく */
    drawLawList(ctx, W, [
      ['第1法則', lawTxt('k1')],
      ['第2法則', lawTxt('k2')],
      ['第3法則', lawTxt('k3')]
    ]);
    drawClock(ctx, W, 't = ' + tText(v, t), LAW_LIST + 14);
    if (hintOn(s, t)) {
      var kd = K.kind(o.Em, o.e);
      label(ctx, 'いまの軌道：' + K.kindName(kd) + '（E/m = ' + fmt(o.Em, 2)
        + ((v.sys === 'earth') ? ' MJ/kg）' : '）'),
        W - 10, H - 14, { align: 'right', size: 11.5, color: orbColor(kd), bold: true });
    }
  },
  result: function (v, s, t) {
    var o = m15Orb(v), sys = sysOf(v), e = (v.sys === 'earth');
    var Kv = o.T * o.T / (o.a * o.a * o.a);
    return {
      items: [
        resItem(periName(v) + 'の速さ $v_0$',
          fmt(o.v0, 3) + ' ' + sys.uV + '（k = ' + fmt(v.k, 1) + '）'),
        resItem('半長軸 $a$', fmtLen(o.a) + ' ' + sys.uL),
        resItem('周期 $T$', e ? (fmt(o.T / 3600, 3) + ' 時間') : (fmt(o.T, 3) + ' 年')),
        resItem('$K = T^2/a^3$',
          e ? (fmtE(Kv, 4) + ' s²/km³') : (fmt(Kv, 4) + ' 年²/AU³'), true),
        resItem('離心率 $\\varepsilon$', fmt(o.e, 3)),
        resItem(apoName(v) + ' $r_a$', fmtLen(o.ra) + ' ' + sys.uL),
        resItem('力学的エネルギー $E/m$',
          fmt(o.Em, 3) + (e ? ' MJ/kg' : ' AU²/年²')),
        resItem('面積速度 $dS/dt$', fmtE(o.dS, 3) + ' ' + sys.uL + '²/' + sys.uT)
      ],
      note: '$E$ が上がると $a$ が大きくなり、$T$ も長くなります（$E = -GMm/2a$、$T^2 = Ka^3$）。' +
        'それでも <b>K = T²/a³ は変わりません</b>（同じ' + sys.center + 'のまわりだから）。'
    };
  },
  info: function (s, t) {
    var v = V(s), o = m15Orb(v), sys = sysOf(v), e = (v.sys === 'earth');
    var q = K.state(o, t, 0, false);
    var rows = [
      [sys.center + 'からの距離 $r$', fmtLen(q.r) + ' ' + sys.uL]
    ];
    if (e) rows.push(['高度（地表から）', fmt(q.r - SYS.earth.R, 0) + ' km']);
    rows.push(
      ['速さ $v$', fmt(q.v, 3) + ' ' + sys.uV],
      [periName(v) + 'の速さ $v_0$', fmt(o.vp, 3) + ' ' + sys.uV],
      ['円軌道の速さ $\\sqrt{GM/r_0}$', fmt(o.vc, 3) + ' ' + sys.uV],
      ['脱出速度 $\\sqrt{2GM/r_0}$', fmt(P.m15.vEsc(r0Of(v), sys), 3) + ' ' + sys.uV],
      ['軌道の種類', K.kindName(K.kind(o.Em, o.e))],
      ['時刻 $t$', tText(v, t)]
    );
    return rows;
  },
  eq: function (s) {
    return 'E = \\dfrac{1}{2}mv^2 - G\\dfrac{mM}{r} = -\\dfrac{GmM}{2a} \\quad\\Rightarrow\\quad ' +
      'E\\uparrow \\;\\Rightarrow\\; a\\uparrow \\;\\Rightarrow\\; T\\uparrow';
  }
};

/* ============================================================
   1-6　補足：地動説の「発見」
   ============================================================ */
var M16_IDS = ['mercury', 'venus', 'earth', 'mars'];

/* 地球から見た空（天球）のようす。横軸＝黄経 λ（0〜360°）、縦軸＝黄緯 β。 */
function m16DrawSky(ctx, s, t, W, H) {
  var i, mars = planetById('mars');
  var pd = { l: 42, r: 14, t: 30, b: 216 };  /* 下の 216px は「上から見た位置関係」の図の場所 */
  var B = 11;                                  /* 黄緯の表示範囲 ±B [°] */
  function SX(lam) { return pd.l + (W - pd.l - pd.r) * lam / 360; }
  function SY(bet) { return pd.t + (H - pd.t - pd.b) * (B - bet) / (2 * B); }

  ctx.save();
  ctx.fillStyle = COL.sky;
  ctx.fillRect(0, 0, W, H);
  ctx.restore();
  starField(ctx, 0, 0, W, H, 120, 20260827);

  /* 目盛り（黄経） */
  ctx.save();
  ctx.strokeStyle = 'rgba(255,255,255,.16)'; ctx.lineWidth = 1;
  for (i = 0; i <= 360; i += 60) {
    ctx.beginPath(); ctx.moveTo(SX(i), pd.t); ctx.lineTo(SX(i), H - pd.b); ctx.stroke();
  }
  ctx.strokeStyle = 'rgba(255,255,255,.28)';
  ctx.beginPath(); ctx.moveTo(pd.l, SY(0)); ctx.lineTo(W - pd.r, SY(0)); ctx.stroke();
  ctx.restore();
  for (i = 0; i <= 360; i += 60) {
    label(ctx, i + '°', SX(i), H - pd.b + 12,
      { size: 9.5, color: '#b9c6d6', haloColor: 'rgba(34,48,74,.9)' });
  }
  label(ctx, '黄経 λ（空を東へ一周すると 360°）→', W - 12, H - pd.b + 27,
    { size: 10.5, color: '#cfd9e6', align: 'right', haloColor: 'rgba(34,48,74,.9)' });
  label(ctx, 'β ↑', 8, SY(0) - 13, { size: 10.5, color: '#cfd9e6', align: 'left', haloColor: 'rgba(34,48,74,.9)' });
  label(ctx, '黄道（太陽の通り道）', W - 12, SY(0) - 9,
    { size: 9.5, color: 'rgba(230,240,255,.55)', align: 'right', haloColor: 'rgba(34,48,74,.85)' });

  /* いままでの見かけの道すじ（λ が 360° をまたぐところで線を切る） */
  function trail(get, col, wdt, dash) {
    var n = 520, prev = null;
    ctx.save();
    ctx.strokeStyle = col; ctx.lineWidth = wdt; ctx.lineCap = 'round';
    if (dash) ctx.setLineDash(dash);
    ctx.beginPath();
    for (i = 0; i <= n; i++) {
      var tk = t * i / n;
      if (t <= 1e-9) break;
      var q = get(tk);
      var px = SX(q.lam), py = SY(q.bet);
      if (prev === null || Math.abs(q.lam - prev) > 180) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
      prev = q.lam;
    }
    ctx.stroke();
    ctx.restore();
  }
  trail(function (tk) { return P.m16.sunSky(tk); }, 'rgba(255,214,102,.85)', 1.6, [6, 5]);
  trail(function (tk) { return P.m16.planetSky(mars, tk); }, COL.skyMars, 3.0, null);

  /* 3つの色の凡例（左上） */
  [['太陽（破線）', 'rgba(255,214,102,.95)'], ['火星（太い線）', COL.skyMars]
  ].forEach(function (lg, j) {
    var ly = 34 + j * 15;
    ctx.save();
    ctx.strokeStyle = lg[1]; ctx.lineWidth = 2.4;
    if (j === 0) ctx.setLineDash([5, 4]);
    ctx.beginPath(); ctx.moveTo(10, ly); ctx.lineTo(30, ly); ctx.stroke();
    ctx.restore();
    label(ctx, lg[0], 35, ly, { size: 9.5, color: '#cfd9e6', align: 'left', haloColor: 'rgba(34,48,74,.9)' });
  });

  /* いまの太陽と火星 */
  var qs = P.m16.sunSky(t), qm = P.m16.planetSky(mars, t);
  var sux = SX(qs.lam), suy = SY(qs.bet);
  sunShape(ctx, sux, suy, 7);
  label(ctx, '太陽', sux, suy + 18, { size: 10.5, color: '#ffe0a0', bold: true, haloColor: 'rgba(34,48,74,.9)' });
  var mx = SX(qm.lam), my = SY(qm.bet);
  planetShape(ctx, mx, my, 5.6, COL.skyMars);
  label(ctx, '火星', mx, my - 14, { size: 11, bold: true, color: COL.skyMars, haloColor: 'rgba(34,48,74,.9)' });

  label(ctx, '地球から毎日同じ時間・同じ方角を観測して見える景色', 10, 16,
    { align: 'left', size: 11.5, bold: true, color: '#e7eef7', haloColor: 'rgba(34,48,74,.9)' });
  label(ctx, 't = ' + fmt(t, 2) + ' 年', W - 12, 16,
    { align: 'right', size: 12.5, bold: true, color: '#ffffff', haloColor: 'rgba(34,48,74,.9)' });
  if (hintOn(s, t)) {
    var back = P.m11.retroNow(mars, t);
    label(ctx, back ? '← 火星はいま逆行中（西へ戻っている）'
      : 'まわりの星は動かず、太陽はまっすぐ進む。火星だけ行きつ戻りつする',
      W / 2, H - pd.b - 18,
      { size: 11.5, bold: true, color: back ? '#ffd479' : '#bfe6c9', haloColor: 'rgba(34,48,74,.92)' });
  }

  /* 下の帯：同じ時刻の「太陽・地球・火星の位置関係」を上から見た図 */
  m16DrawTop(ctx, 10, H - pd.b + 58, 206, 148, t);
  m16TopCaption(ctx, 230, H - pd.b + 66, W - 242, t);
}

/* 左下の小さな図：太陽・地球・火星を「上から」見た位置関係。
   空の図（上）と同じ時刻を描くので、「空でこう見えるのは、上から見るとこの位置だから」
   というつながりが目で追える。 */
function m16DrawTop(ctx, x0, y0, w, h, t) {
  var earth = planetById('earth'), mars = planetById('mars');
  var box = 1.85, i;
  var cx = x0 + w / 2, cy = y0 + h / 2;
  var R = Math.min(w, h) / 2 - 14;
  function map(x, y) { return [cx + x / box * R, cy - y / box * R]; }

  ctx.save();
  ctx.fillStyle = '#101a2e';
  ctx.fillRect(x0, y0, w, h);
  ctx.strokeStyle = 'rgba(255,255,255,.30)'; ctx.lineWidth = 1;
  ctx.strokeRect(x0 + 0.5, y0 + 0.5, w - 1, h - 1);
  ctx.restore();

  /* 枠の外にはみ出さないようにする（軌道と視線の破線） */
  ctx.save();
  ctx.beginPath(); ctx.rect(x0, y0, w, h); ctx.clip();

  /* 2つの軌道（火星は上の図と同じすみれ色にそろえる） */
  [earth, mars].forEach(function (p) {
    var pts = planetOrbitPts(p, 480);
    ctx.save();
    ctx.strokeStyle = fade(p.id === 'mars' ? COL.skyMars : p.col, 0.55); ctx.lineWidth = 1.2;
    ctx.beginPath();
    pts.forEach(function (q, j) {
      var sp = map(q[0], q[1]);
      if (j === 0) ctx.moveTo(sp[0], sp[1]); else ctx.lineTo(sp[0], sp[1]);
    });
    ctx.closePath(); ctx.stroke();
    ctx.restore();
  });

  var qe = planetXY(earth, t), qm2 = planetXY(mars, t);
  var pe = map(qe.x, qe.y), pm = map(qm2.x, qm2.y);

  /* 地球から火星を見る向き（この向きが、上の図の黄経 λ にあたる） */
  var dx = qm2.x - qe.x, dy = qm2.y - qe.y, dd = Math.hypot(dx, dy) || 1;
  var far = map(qe.x + dx / dd * 6, qe.y + dy / dd * 6);
  dashLine(ctx, pe[0], pe[1], far[0], far[1], fade(COL.skyMars, 0.75), [5, 4], 1.3);
  ctx.restore();

  /* 天体の名前は「太陽から見て外向き」にずらす（太陽の文字と重ならないようにするため） */
  function outLabel(txt, pt, col) {
    var ox = pt[0] - cx, oy = pt[1] - cy, od = Math.hypot(ox, oy) || 1;
    label(ctx, txt, pt[0] + ox / od * 15, pt[1] + oy / od * 15,
      { size: 10.5, bold: true, color: col, haloColor: 'rgba(16,26,46,.92)' });
  }
  sunShape(ctx, cx, cy, 6);
  label(ctx, '太陽', cx, cy + 16, { size: 10, color: '#ffe0a0', haloColor: 'rgba(16,26,46,.92)' });
  planetShape(ctx, pe[0], pe[1], 4.6, earth.col);
  outLabel('地球', pe, '#a9e2c2');
  planetShape(ctx, pm[0], pm[1], 4.6, COL.skyMars);
  outLabel('火星', pm, COL.skyMars);

  label(ctx, '上から見た位置関係（太陽・地球・火星）', x0 + w / 2, y0 - 9,
    { size: 10.5, bold: true, color: '#cfd9e6', haloColor: 'rgba(34,48,74,.9)' });
}

/* 上から見た図のとなりに置く説明（いまの距離と、順行・逆行のわけ） */
function m16TopCaption(ctx, x0, y0, w, t) {
  var mars = planetById('mars');
  var qm3 = P.m16.planetSky(mars, t);
  var back = P.m11.retroNow(mars, t);
  var lines = [
    '破線は「地球から火星を見る向き」。',
    'この向きが上の図の黄経 λ になります。',
    '地球は火星より内側を速く回るので、',
    '追いこすときだけ、火星は空を西へ',
    '戻るように見えます（＝逆行）。',
    '',
    'いまの地球―火星の距離：' + fmt(qm3.d, 2) + ' AU',
    'いまの火星：' + (back ? '逆行中' : '順行中')
  ];
  lines.forEach(function (ln, j) {
    if (!ln) return;
    label(ctx, ln, x0, y0 + j * 17, {
      align: 'left', size: 11, color: (j >= 6 ? '#ffd479' : '#cfd9e6'),
      bold: j >= 6, haloColor: 'rgba(34,48,74,.9)'
    });
  });
}

/* 右下の図：同じ運動を「太陽を中心に見る」と「地球を中心に見る」 */
function m16DrawModels(ctx, s, t, W, H) {
  var i, half = W / 2;
  var list = M16_IDS.map(planetById);
  var earth = planetById('earth');
  ctx.save();
  ctx.fillStyle = '#f7f9fb';
  ctx.fillRect(0, 0, W, H);
  ctx.restore();
  ctx.save();
  ctx.strokeStyle = '#cfd8e0'; ctx.lineWidth = 1; ctx.setLineDash([4, 4]);
  ctx.beginPath(); ctx.moveTo(half, 8); ctx.lineTo(half, H - 8); ctx.stroke();
  ctx.restore();

  function panel(x0, box, geo, title) {
    var cx = x0 + half / 2, cy = H / 2 + 6;
    var R = Math.min(half / 2 - 12, (H - 40) / 2);
    function map(x, y) { return [cx + x / box * R, cy - y / box * R]; }
    /* 中心の天体 */
    if (geo) {
      planetShape(ctx, cx, cy, 5.5, earth.col);
      label(ctx, '地球', cx, cy + 15, { size: 10, color: '#2f6b4f' });
    } else {
      sunShape(ctx, cx, cy, 6);
    }
    /* それぞれの道すじ（いままで通った跡） */
    list.forEach(function (p) {
      if (geo && p.id === 'earth') return;
      if (!geo && p.id === 'earth') { /* 地球も描く */ }
      var n = Math.round(clamp(90 * t / p.T, 120, 1600));
      ctx.save();
      ctx.strokeStyle = fade(p.col, 0.85); ctx.lineWidth = 1.4;
      ctx.beginPath();
      for (i = 0; i <= n; i++) {
        var tk = t * i / n;
        var q = planetXY(p, tk), e0 = planetXY(earth, tk);
        var pt = geo ? map(q.x - e0.x, q.y - e0.y) : map(q.x, q.y);
        if (i === 0) ctx.moveTo(pt[0], pt[1]); else ctx.lineTo(pt[0], pt[1]);
      }
      ctx.stroke();
      ctx.restore();
      var qn = planetXY(p, t), en = planetXY(earth, t);
      var pn = geo ? map(qn.x - en.x, qn.y - en.y) : map(qn.x, qn.y);
      planetShape(ctx, pn[0], pn[1], 3.6, p.col);
    });
    /* 地球中心のときは「太陽」も回って見える */
    if (geo) {
      var n2 = Math.round(clamp(90 * t, 120, 1600));
      ctx.save();
      ctx.strokeStyle = fade(COL.sun, 0.85); ctx.lineWidth = 1.6;
      ctx.beginPath();
      for (i = 0; i <= n2; i++) {
        var tk2 = t * i / n2, e2 = planetXY(earth, tk2);
        var p2 = map(-e2.x, -e2.y);
        if (i === 0) ctx.moveTo(p2[0], p2[1]); else ctx.lineTo(p2[0], p2[1]);
      }
      ctx.stroke();
      ctx.restore();
      var e3 = planetXY(earth, t), p3 = map(-e3.x, -e3.y);
      sunShape(ctx, p3[0], p3[1], 5);
    }
    /* パネル名は「…」（三点リーダ）で、まわりの文字より一回り小さく */
    label(ctx, title, x0 + half / 2, 15, { size: 10.5, bold: true, color: COL.ink });
  }
  panel(0, 1.75, false, '太陽が中心と仮定する（地動説）と…');
  panel(half, 2.75, true, '地球が中心と仮定する（天動説）と…');
  label(ctx, 'きれいな円', half / 2, H - 8, { size: 10.5, color: COL.bound, bold: true });
  label(ctx, 'ぐるぐる複雑', half + half / 2, H - 8, { size: 10.5, color: COL.force, bold: true });
}

DEFS['m1-6'] = {
  id: 'm1-6', mode: 1, tab: '補足：地動説とケプラーの法則の歴史', read: true, autoplay: true,
  units: ['AU'],
  legendKeys: ['sun', 'orbit'],
  title: '補足：地動説とケプラーの法則の歴史　—　なぜ火星や土星を「惑星」と呼ぶのか',
  sub: '上の図は<b>地球から毎日同じ時間・同じ方角を観測して見える景色</b>です。横が<b>黄経 λ</b>（空を東へ一周すると 360°）、' +
    '縦が<b>黄緯 β</b>。<b>太陽</b>と<b>火星</b>が、それぞれどう動くかを見比べよう。<br>' +
    'まわりの星（恒星）は<b>まったく動かず</b>、太陽は黄道の上を<b>まっすぐ一定の速さで</b>進みます。' +
    'ところが<b>火星だけは、ときどき止まって逆戻りします</b>。<br>' +
    '<b>左下の小さな図</b>は、同じ時刻の<b>太陽・地球・火星の位置関係を上から見た</b>ものです。' +
    '地球が火星を内側から追いこすときに逆行が起きることを、見比べて確かめよう。',
  note: 'まわりの星は動かず、太陽はまっすぐ。<b>火星だけが行きつ戻りつする</b>——これが' +
    '「惑（まど）う星」＝<b>惑星</b>という名前の由来です。' +
    '左下の図で<b>地球が火星を追いこす</b>タイミングと、空で<b>逆行</b>が起きるタイミングを見比べよう。' +
    'さらに下の図では、同じ動きを「太陽を中心に見た場合」と「地球を中心に見た場合」で比べられます。',
  sideText:
    '<span class="q">なぜ火星や土星を惑星と呼ぶのか？</span>' +
    '左の図のように、火星は一方向に進まず、<b>惑っているように見える</b>からである。' +
    'こういった太陽系の惑星の軌道を天動説で説明すると<b>複雑に見える軌道</b>となってしまうが、' +
    '<b>地動説だと各惑星の軌道をきれいに説明できる</b>。これが地動説が有力となった根拠である。',
  side: {
    w: 420, h: 232,
    title: '左図の観測結果を説明するには、星はどう動かなくてはいけないか',
    note: '左（地動説）は<b>きれいな円</b>が並ぶだけ。右（天動説）は同じ動きなのに、' +
      '<b>ぐるぐる巻いた複雑な軌道</b>になってしまう。' +
      '※ どちらも「間違い」ではなく、<b>どこを中心に見るか</b>の違い。' +
      'ただし、単純に説明できる方が自然だと考えるのがふつうである。',
    draw: function (ctx, s, t, W, H) { m16DrawModels(ctx, s, t, W, H); }
  },
  sideNote: 'なお、恒星の元々の意味は「<b>動かずに常にある星</b>」という意味で、' +
    '「常に光る星」という意味ではない。',
  /* ページの下に、左右にまたがって置く読み物（#longbox）。
     もとは 1-0 の右の列にあった「ミニコラム」を、ここへまとめて移した。
     生徒には「観測の話（上）→ 歴史の話（下）」と続けて読んでもらう。 */
  long:
    '<h3>【物理ミニコラム】地動説・ケプラーの法則の歴史</h3>' +
    '<p>高校物理で学ぶ「ケプラーの法則」と「万有引力の法則」。これらが誕生する背景には、' +
    '<b>天動説から地動説へと宇宙観がひっくり返る、約150年にわたる科学者たちのドラマ</b>がありました。</p>' +
    '<img class="colimg" src="' + IMG.kepler_portraits + '" ' +
    'alt="ニコラウス・コペルニクス（1473–1543）とヨハネス・ケプラー（1571–1630）の肖像">' +
    '<h4>1. コペルニクスの予言（1543年）</h4>' +
    '<p>それまで主流だった「地球が中心」という<b>天動説</b>に対し、コペルニクスが' +
    '<b>「太陽が中心である」という地動説</b>を唱えました。しかし当時は' +
    '「惑星は完璧な正円の軌道で動く」と信じられていたため、実際の天体観測データと計算が合わず、' +
    '多くの科学者を納得させることはできませんでした。</p>' +
    '<h4>2. ケプラーの法則の発見（1609年・1619年）</h4>' +
    '<p>ここで登場するのが<b>ヨハネス・ケプラー</b>です。彼は師匠（ティコ・ブラーエ）が残した' +
    '膨大な観測データを分析し、それまでの常識をくつがえす' +
    '<b>「' + LAW.k1 + '」</b>という事実（第1法則）に気づきました。' +
    'この発見により観測データと計算がぴたりと一致し、地動説の正しさが科学的に示されました。</p>' +
    '<h4>3. ニュートンによる地動説の確立（1687年）</h4>' +
    '<p>ケプラーは「どう動くか」を発見しましたが、「<b>なぜ</b>そう動くか」までは説明できませんでした。' +
    'それを解決したのが<b>アイザック・ニュートン</b>です。ニュートンはケプラーの第3法則などをヒントに' +
    '<b>「万有引力の法則」</b>を導き出し、天体の運動を数式で説明しきりました。' +
    '天体の動きが物理法則として裏づけられたことで、地動説は揺るぎないものとして完全に' +
    '<b>「確立」</b>したのです。</p>' +
    colImg('newton_portrait', 'アイザック・ニュートン（1643–1727）の肖像',
      'アイザック・ニュートン（1643–1727）　—　万有引力の法則で、天体の運動を数式にした。') +
    '<h4>■ まとめ</h4>' +
    '<ul>' +
    '<li><b>コペルニクス</b>が地動説を「予言」した。</li>' +
    '<li><b>ケプラー</b>が「楕円軌道」を発見し、地動説がリアルなものになった。</li>' +
    '<li><b>ニュートン</b>が「万有引力」で裏づけ、地動説が決定的なもの（確立）になった。</li>' +
    '</ul>' +
    '<p>わたした違いま学ぶ「ケプラーの法則」は、' +
    '<b>天文学を「物理学」へと進化させた歴史的な大発見</b>なのです。' +
    '創作部分も多数ありますが、<b>「チ。-地球の運動について-」</b>は面白いです。' +
    'ぜひ読んでみて、昔の人たちの感動を追体験してみてください。</p>',
  cw: 560, ch: 510,
  loop: true,
  vars: [],
  tEnd: function () { return 4.4; },
  /* スタートしたときの速さ＝これまでの「スロー再生」と同じ（0.44 × 0.25） */
  rate: function () { return 0.11; },
  tFmt: function (t) { return fmt(t, 2) + ' 年'; },
  xlabel: 't [年]',
  sample: function (v, t) {
    var m = P.m16.planetSky(planetById('mars'), t);
    return { r: m.d, v: 0, lam: m.lam, bet: m.bet };
  },
  graphs: [],
  draw: function (ctx, s, t, W, H) { m16DrawSky(ctx, s, t, W, H); },
  info: function (s, t) {
    var mars = planetById('mars');
    var qs = P.m16.sunSky(t), qm = P.m16.planetSky(mars, t);
    return [
      ['太陽の見かけの位置 $\\lambda$', fmt(qs.lam, 1) + '°'],
      ['火星の見かけの位置 $\\lambda$', fmt(qm.lam, 1) + '°'],
      ['火星の見かけの位置 $\\beta$', fmt(qm.bet, 2) + '°'],
      ['地球から火星までの距離', fmt(qm.d, 3) + ' AU'],
      ['いまの火星', P.m11.retroNow(mars, t) ? '逆行中（西へ戻っている）' : '順行中（東へ進んでいる）'],
      ['経過した時間 $t$', fmt(t, 2) + ' 年']
    ];
  }
};
