/* =========================================================================
   サイト全体へのナビ（第 28 回）
   ・ホーム（楽楽高校物理のトップページ）へのリンク：ヒーローのパンくずと、上に固定したタブ列の左はし（家のアイコン）。
   ・「ページ一覧」：タブ列の左はしのボタンで、左から引き出すパネル（ドロワー）を開く。分野ごとに全ページのリンク。
   ・一覧のもとはトップページ（index.html）の SITE・EXPSITE。
       - この中に「写し」を持つ（オフラインでも出る）。
       - 公開先（https://physics-chiba.github.io）で開いたときは、トップページを読みこんで最新の一覧に置きかえる
         （トップページにページを足せば、このページの一覧にも自動で出る）。
   ========================================================================= */
const SITE_HOME = "https://physics-chiba.github.io/physics-site/";
const SITE_FORM = "https://docs.google.com/forms/d/e/1FAIpQLScU1DzFTmUDGSvP3UE5Lr7RY8NvjukkzBHmQYtmOac44twPwQ/viewform";
/* 写し（2026-10-02 のトップページから）。g＝大きな見出し（シミュレーション／実験／作成後記） */
const SITE_SNAPSHOT = [
  { g:"シミュレーション", id:"mechanics", name:"力学", color:"#1663b5", items:[
    { t:"一次元と平面の運動　～v-tグラフで理解する～", u:"mechanics/basics-of-motion-on-plane.html" },
    { t:"力学的エネルギーと非保存力の仕事の関係", u:"mechanics/mechanical-energy.html" },
    { t:"剛体と力のモーメント", u:"mechanics/rigid-body-dynamics.html" },
    { t:"箱の回転　～傾くのが先か滑るのが先か～", u:"mechanics/rotation-box_tip-or-slip.html" },
    { t:"運動量と力積、2物体の衝突と反発係数", u:"mechanics/momentum-and-collision.html" },
    { t:"保存則クイズ　基本編", u:"mechanics/conservation-quiz-basic.html" },
    { t:"保存則クイズ　難関大受験編", u:"mechanics/conservation-quiz-advanced.html" },
    { t:"上級者向け解説・重心ミニ実験室", u:"mechanics/conservation-quiz-advanced.html#advbox" },
    { t:"円運動：円筒面のループ運動", u:"mechanics/circular-motion-loop.html" },
    { t:"単振動：ばねで打ち出される小球の運動", u:"mechanics/spring-launch.html" },
    { t:"万有引力とケプラーの法則", u:"mechanics/celestial-mechanics.html" },
    { t:"2026年8月 校内模試の力学の問題　動く台の上のばねと円弧面上の運動", u:"mechanics/cart-spring-arc.html" } ]},
  { g:"シミュレーション", id:"wave", name:"波動", color:"#3ea0e0", items:[
    { t:"光の干渉①　ヤングの実験", u:"wave/youngs-experiment.html" },
    { t:"光の干渉②　回折格子", u:"wave/diffraction_grating.html" },
    { t:"光の干渉③　薄膜の干渉", u:"wave/Light-interference-thin-film.html" } ]},
  { g:"シミュレーション", id:"elemag", name:"電磁気", color:"#7b5bd6", items:[
    { t:"電気回路３次元シミュレーター", u:"elemag/circuit-water-model-3d.html" } ]},
  { g:"実験", id:"movie", name:"動画をつかう", color:"#0e7490", items:[
    { t:"動画解析・トラッキングツール", u:"experiment/motion-analysis.html" } ]},
  { g:"作成後記", id:"note", name:"作成後記", color:"#1c8f4a", items:[
    { t:"動画解析アプリができるまで　AIとの共同作業の記録", u:"AI_log/motion-analysis_AI-collaboration.html" },
    { t:"薄膜の干渉ができるまで　AIとの共同作業の記録", u:"AI_log/Light-interference-thin-film_AI-collaboration.html" } ]}
];

/* トップページの文字列から SITE・EXPSITE の中身を取り出す（失敗したら null） */
function parseSiteIndex(txt){
  try{
    const grab = (name)=>{ const i = txt.indexOf("const "+name+" = ["); if(i<0) return "";
      const j = txt.indexOf("\nconst ", i+10); return txt.slice(i, j<0? undefined : j); };
    const out = [];
    [["SITE","シミュレーション"],["EXPSITE","実験"]].forEach(([nm, g])=>{
      const src = grab(nm); if(!src) return;
      src.split(/\{\s*\n\s*id:"/).slice(1).forEach(chunk=>{
        const id = (chunk.match(/^([\w-]+)"/)||[])[1], name = (chunk.match(/name:"([^"]+)"/)||[])[1], color = (chunk.match(/color:"(#[0-9a-fA-F]{3,8})"/)||[])[1];
        const items = []; const re = /\bt:"([^"]+)"[\s\S]*?\bu:BASE\+"([^"]+)"/g; let m;
        while((m = re.exec(chunk))) items.push({ t:m[1], u:m[2] });
        if(id && name && items.length) out.push({ g:(id==="note"? "作成後記" : g), id, name, color:color||"#5b6672", items });
      });
    });
    const ORD = {"シミュレーション":0, "実験":1, "作成後記":2};
    out.sort((a,b)=>(ORD[a.g]||0)-(ORD[b.g]||0));       // 見出しの順（シミュレーション → 実験 → 作成後記）。同じ見出しの中はトップページの順のまま
    const n = out.reduce((a,s)=>a+s.items.length, 0);
    return (n >= 5)? out : null;               // 取り出しが明らかにおかしいときは写しのまま
  }catch(e){ return null; }
}

function buildSiteDrawer(){
  /* ★このページのタブの帯は #tabbar★（見本は #tabs。class 名の読みかえ表のとおり） */
  const nav = document.getElementById("tabbar"); if(!nav) return;
  const dr = document.createElement("aside");
  dr.id = "siteDrawer"; dr.className = "drawer"; dr.setAttribute("role","dialog"); dr.setAttribute("aria-modal","true");
  dr.setAttribute("aria-label","楽楽（らくらく）高校物理のページ一覧"); dr.hidden = true;
  const scrim = document.createElement("div"); scrim.className = "drawer-scrim"; scrim.hidden = true;
  document.body.appendChild(scrim); document.body.appendChild(dr);
  const here = (location.pathname.match(/physics-site\/(.+)$/) || [])[1] || "mechanics/celestial-mechanics.html";
  const esc = (s)=>String(s).replace(/[&<>"']/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const render = (data)=>{
    let h = '<div class="dr-head"><a class="dr-brand" href="'+SITE_HOME+'">'+(document.querySelector("#hero .atom")? document.querySelector("#hero .atom").outerHTML : "")+
      '<span>楽楽（らくらく）高校物理</span></a><button type="button" class="dr-x" aria-label="閉じる">×</button></div>'+
      '<a class="dr-home" href="'+SITE_HOME+'"><span class="dr-hi" aria-hidden="true">'+(nav.querySelector(".navhome svg")||{outerHTML:""}).outerHTML+'</span>'+
      '<span><b>ホーム</b><small>トップページ（分野ごとの一覧・検索・更新履歴）</small></span><span class="dr-go" aria-hidden="true">→</span></a>';
    let lastG = "";
    data.forEach(sec=>{
      if(sec.g !== lastG){ h += '<p class="dr-g">'+esc(sec.g)+'</p>'; lastG = sec.g; }
      h += '<section class="dr-sec" style="--c:'+esc(sec.color)+'"><h3><i></i>'+esc(sec.name)+'</h3><ul>';
      sec.items.forEach(it=>{
        const cur = (it.u === here);
        h += '<li><a href="'+esc(SITE_HOME+it.u)+'"'+(cur? ' aria-current="page" class="cur"' : '')+'>'+esc(it.t)+(cur? '<em>いま見ているページ</em>' : '')+'</a></li>';
      });
      h += '</ul></section>';
    });
    h += '<a class="dr-form" href="'+SITE_FORM+'" target="_blank" rel="noopener">感想・励ましの言葉・要望・バグ報告はこちら<span aria-hidden="true">↗</span></a>';
    dr.innerHTML = h;
    dr.querySelector(".dr-x").addEventListener("click", ()=>close());
  };
  render(SITE_SNAPSHOT);
  const btn = document.getElementById("bPages");
  let lastFocus = null;
  function open(){ lastFocus = document.activeElement; dr.hidden = false; scrim.hidden = false;
    requestAnimationFrame(()=>{ dr.classList.add("on"); scrim.classList.add("on"); });
    document.documentElement.classList.add("drawer-open"); if(btn) btn.setAttribute("aria-expanded","true");
    const cur = dr.querySelector("a.cur") || dr.querySelector("a"); if(cur) setTimeout(()=>{ cur.focus({preventScroll:true}); cur.scrollIntoView({block:"center"}); }, 60); }
  function close(){ if(dr.hidden) return; dr.classList.remove("on"); scrim.classList.remove("on");
    document.documentElement.classList.remove("drawer-open"); if(btn) btn.setAttribute("aria-expanded","false");
    setTimeout(()=>{ dr.hidden = true; scrim.hidden = true; }, 260); if(lastFocus && lastFocus.focus) lastFocus.focus({preventScroll:true}); }
  if(btn) btn.addEventListener("click", ()=>{ dr.hidden? open() : close(); });
  scrim.addEventListener("click", close);
  document.addEventListener("keydown", (ev)=>{
    if(dr.hidden) return;
    if(ev.key === "Escape"){ ev.preventDefault(); close(); return; }
    if(ev.key === "Tab"){                                  // パネルの中だけでフォーカスを回す
      const f = dr.querySelectorAll("a[href],button"); if(!f.length) return;
      const a = f[0], z = f[f.length-1];
      if(ev.shiftKey && document.activeElement === a){ ev.preventDefault(); z.focus(); }
      else if(!ev.shiftKey && document.activeElement === z){ ev.preventDefault(); a.focus(); }
    }
  });
  window.SITENAV = { open, close, render };
  /* 公開先で開いたときだけ、トップページから最新の一覧を読みこむ（失敗したら写しのまま） */
  if(location.protocol === "https:" && /physics-chiba\.github\.io$/.test(location.hostname) && window.fetch){
    fetch(SITE_HOME + "index.html", {cache:"no-cache"}).then(r=> r.ok? r.text() : "").then(txt=>{
      const d = txt && parseSiteIndex(txt); if(d) render(d);
    }).catch(()=>{});
  }
}
document.addEventListener("DOMContentLoaded", ()=>{ buildSiteDrawer(); });

