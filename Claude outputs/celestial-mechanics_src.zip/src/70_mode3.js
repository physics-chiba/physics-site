/* 3　入試物理
   ねらい：万有引力の問題は、けっきょく
     ① 力学的エネルギー保存　② 面積速度一定（＝角運動量保存）
   の2本立てで解ける、ということを手で確かめさせる。
   ★3本とも「実際の入試問題」をそのまま動かせるようにしてある★
   （出典は、シミュレーションのタイトルにも出す。） */
'use strict';

/* ============================================================
   3-1　等速円運動から楕円軌道への遷移（出典：大阪市立大）
   ------------------------------------------------------------
   地上から鉛直上方へ打ち上げ、中心から 2R の点 A でちょうど速さ 0。
   その瞬間に OA に垂直な向きへエネルギー E'（＝½mv²）を加える。
   ★E' をスライドバーで変えると、軌道が「落下 → だ円 → 円 → だ円 → 放物線 → 双曲線」
     と変わっていく★のが、このシミュレーションの中心。
   ============================================================ */
var M31 = { GM: 398600.4418, R: 6371 };

function m31Orb(v) { return P.m31.make(v.eq); }

/* ★スタートを押したら、まず「打ち上げ」から★（先生の指示）
   問題ではいちばんはじめに「地表から鉛直上方へ打ち上げる」ことが起こる。
   そこで時刻を
     0 〜 TL      … 打ち上げ（地表 → 点 A・まっすぐ上がって速さ 0 になる）
     TL 〜 tEnd   … 点 A で E′ を加えたあとの軌道
   の2段にする。TL は約 34.5 分。 */
function m31TL() { return P.m31.tLaunch(); }
function m31State(v, t) {
  var TL = m31TL();
  if (t < TL) {
    var q = P.m31.launchAt(t);
    q.launch = true;
    return q;
  }
  var q2 = P.m31.at(m31Orb(v), t - TL);
  q2.launch = false;
  return q2;
}

/* E' のめやすの値（すべて mgR を単位とする）。左上の凡例に出す。 */
var M31_ROWS = [
  { eq: P.m31.EQ_MIN, name: 'E′ = mgR/6', note: '近地点が地表（ぎりぎり）', col: COL.sub },
  { eq: P.m31.EQ_CIRC, name: 'E′ = mgR/4', note: '半径 2R の円', col: COL.bound },
  { eq: P.m31.EQ_AB, name: 'E′ = 3mgR/8', note: 'B が 6R のだ円（問題の(4)）', col: COL.bound },
  { eq: P.m31.EQ_ESC, name: 'E′ = mgR/2', note: '放物線（脱出）', col: COL.para }
];

/* 図の左上に置く「E′ の目やす」の表。いまの E′ にいちばん近い行を太字にする。 */
function m31Legend(ctx, eq) {
  var x0 = 8, y0 = 8, w = 226, h = 22 + M31_ROWS.length * 16;
  ctx.save();
  ctx.fillStyle = 'rgba(255,255,255,.9)'; ctx.strokeStyle = COL.grid; ctx.lineWidth = 1;
  if (ctx.roundRect) { ctx.beginPath(); ctx.roundRect(x0, y0, w, h, 7); ctx.fill(); ctx.stroke(); }
  else { ctx.fillRect(x0, y0, w, h); ctx.strokeRect(x0, y0, w, h); }
  ctx.restore();
  label(ctx, '加えるエネルギー E′ のめやす', x0 + 9, y0 + 12,
    { size: 10.5, bold: true, color: COL.sub, align: 'left' });
  M31_ROWS.forEach(function (r, i) {
    var on = Math.abs(eq - r.eq) < 0.013;
    label(ctx, r.name, x0 + 9, y0 + 28 + i * 16,
      { size: 10.5, bold: on, color: on ? r.col : COL.sub, align: 'left' });
    label(ctx, r.note, x0 + w - 9, y0 + 28 + i * 16,
      { size: 10, bold: on, color: on ? r.col : '#9aa5b1', align: 'right' });
  });
}

DEFS['m3-1'] = {
  id: 'm3-1', mode: 3, tab: '3-1 等速円運動から楕円軌道への遷移',
  legendKeys: ['force', 'vel', 'dim', 'orbit', 'bound', 'para', 'hyper'],
  title: '3-1　等速円運動から楕円軌道への遷移　—　（出典：大阪市立大）',
  probImg: 'prob_m31', ansImg: 'ans_m31',
  sub: '地上の1点から<b>鉛直上方</b>へ小物体を打ち上げると、' +
    '中心から <b>2R</b> の点 A でちょうど速さが 0 になりました（打ち上げの速さは $v_0=\\sqrt{gR}$）。<br>' +
    'その瞬間に、<b>OA に垂直な向き</b>へエネルギー <b>$E\'$</b>（＝$\\frac{1}{2}mv^2$）を加えます。' +
    '<b>$E\'$ をスライドバーで変えると、軌道が変わります。</b>' +
    '落ちる → だ円 → <b>半径 2R の円</b> → だ円 → <b>放物線（脱出）</b> → 双曲線。<br>' +
    '$E\'$ は<b>$mgR$ の何倍か</b>で表しています（$gR$ は $GM/R$ のこと）。',
  probsHead: '入試問題を読み解く　—　大阪市立大（一部やさしく書きかえています）',
  probsSetup:
    '地球は<b>半径 $R$・質量 $M$ の一様な球</b>とし、地球の自転・公転は考えません。'
    + '打ち上げるのは<b>質量 $m$ の小物体</b>で、地球からの万有引力だけを受けます。<br>'
    + '<b>① まず、地上の1点から「まっすぐ上へ」打ち上げます。</b>'
    + '速さをうまく選ぶと、上がっていって<b>中心から $2R$ の点 A でちょうど止まり</b>ます'
    + '（ここまでが (1)）。<br>'
    + '<b>② 止まったその瞬間に、$OA$ に垂直な向き（横向き）へ「ポン」と速さ $v$ を与えます。</b>'
    + 'ここから先は、$v$ の大きさしだいで、円になったり、だ円になったり、'
    + '飛び去ったりします（(2) 以降）。<br>'
    + 'このページのスライドバーは、そのとき<b>加えるエネルギー $E′=\\frac{1}{2}mv^2$</b> です。<br>'
    + '<b>「スタート」を押すと、まず ① の打ち上げ（地表 → 点 A・約 34.5 分）から動きます。</b>'
    + 'A に着いたところで $E′$ が加わり、そこから ② の軌道になります。',
  probs: [
    {
      q: '<b>(1)</b> 中心 $O$ から $2R$ の点 A で速度が 0 になるには、'
        + '打ち上げの速さ $v_0$ をどれだけにすればよいか。$g$・$R$ で表せ。',
      a: '地表と点 A で<b>力学的エネルギー保存</b>：'
        + '$\\dfrac{1}{2}mv_0^2 - G\\dfrac{Mm}{R} = 0 - G\\dfrac{Mm}{2R}$。'
        + '$GM=gR^2$ を入れて $v_0=\\sqrt{gR}$。'
        + '<b>これは第一宇宙速度と同じ 7.9 km/s</b>——おもしろいところです。',
      do: '@@r:打ち上げの速さ|打ち上げの速さ $v_0=\\sqrt{gR}$ ＝ 7.910 km/s@@ で確かめよう。'
        + '<br>この $v_0$ で打ち上げると、ちょうど $2R$ の点 A で止まります。'
        + '<b>そのあと横向きに与えるエネルギー $E′$ は、ここで変えられます</b>：@@v:eq@@'
    },
    {
      setup: '<b>ここから ② の場面です。</b>点 A（中心から $2R$）で速さが 0 になった瞬間に、'
        + '$OA$ に<b>垂直な向き</b>へ速さ $v$ を与えます。'
        + '与えた運動エネルギーが $E′=\\dfrac{1}{2}mv^2$。'
        + '<b>点 A の位置と向きは変えず、$v$ の大きさだけを変えます。</b>',
      q: '<b>(2)</b> 点 A で $OA$ に垂直に速さ $v$ を与える。'
        + '$O$ を中心とする等速円運動になる $v$ と、その周期を求めよ。',
      a: '<b>向心力＝万有引力</b>：$\\dfrac{mv^2}{2R}=G\\dfrac{Mm}{(2R)^2}$ より '
        + '$v=\\sqrt{\\dfrac{gR}{2}}$。周期は $T=\\dfrac{2\\pi(2R)}{v}=4\\pi\\sqrt{\\dfrac{2R}{g}}$。',
      do: '@@b:1|半径 2R の円にする（E′ = mgR/4）@@ を押そう。'
        + '@@r:離心率|離心率 $\\varepsilon$ ＝ 0.000@@ と '
        + '@@r:点 A での速さ|点 A での速さ $v$ ＝ 5.593 km/s@@、'
        + '周期は @@r:周期|$T$ ＝ 238.6 分@@。'
        + '<br>$E′$ をここで少しずつ動かして、円からどうずれていくか見よう：@@v:eq@@'
    },
    {
      q: '<b>(3)</b> $AB$ を長軸とするだ円を描くとき（B は中心から $6R$）。'
        + '<b>(a)</b> 点 B での速さ $V$ を $v$ で。<b>(b)</b> $v$ を $g,R$ で。<b>(c)</b> 周期を $g,R$ で。',
      a: '<b>(a) 面積速度一定</b>：近点・遠点では速度が動径に垂直なので $2Rv = 6RV$、つまり $V=\\dfrac{v}{3}$。<br>'
        + '<b>(b) エネルギー保存</b>：$\\dfrac{1}{2}v^2-\\dfrac{gR^2}{2R}=\\dfrac{1}{2}\\left(\\dfrac{v}{3}\\right)^2-\\dfrac{gR^2}{6R}$ '
        + 'を解いて $v=\\dfrac{\\sqrt{3gR}}{2}$。<br>'
        + '<b>(c) ケプラー第3法則</b>：$a=\\dfrac{2R+6R}{2}=4R$ を $T^2=\\dfrac{4\\pi^2}{GM}a^3$ へ入れて '
        + '$T=16\\pi\\sqrt{\\dfrac{R}{g}}$。',
      do: '@@b:2|B が 6R のだ円にする（E′ = 3mgR/8）@@ を押そう。'
        + '@@r:遠地点|遠地点 ＝ 6.000 R@@、'
        + '@@r:点 B の速さ|点 B の速さ $V$ ＝ $v$ の 1/3@@、'
        + '@@r:半長軸|半長軸 $a$ ＝ 4.000 R@@ を確かめよう。'
    },
    {
      q: '<b>(4)</b> 地球に衝突もせず、無限遠へ飛び去りもせず、だ円を描き続けるための $v$ の範囲は。',
      a: '<b>下の限界</b>：近地点がちょうど地表（$R$）になるとき。'
        + '$2Rv=R\\,V_{\\text{地表}}$ と エネルギー保存から $v=\\sqrt{\\dfrac{gR}{3}}$。<br>'
        + '<b>上の限界</b>：$E=0$（放物線）になるとき、$\\dfrac{1}{2}v^2=\\dfrac{gR^2}{2R}$ より $v=\\sqrt{gR}$。<br>'
        + 'よって $\\sqrt{\\dfrac{gR}{3}}<v<\\sqrt{gR}$、$E′$ でいえば '
        + '$\\dfrac{mgR}{6}<E′<\\dfrac{mgR}{2}$。'
        + '<b>下の限界そのもの（$=$）では、近地点がちょうど地表なので「かする」＝衝突</b>です。',
      do: 'ここで $E′$ を動かして、境目をさがそう：@@v:eq@@'
        + '<br>@@s:eq=0.15|E′ = 0.15（落ちる）@@ '
        + '@@s:eq=0.175|E′ = 0.175（ぎりぎり）@@ '
        + '@@s:eq=0.5|E′ = 0.5（放物線）@@ '
        + '@@s:eq=0.6|E′ = 0.6（双曲線）@@'
        + '<br>@@g:eqr|$E′$ と軌道の関係のグラフを見る@@ '
        + 'で、近地点の線が地表 $R$ を切る場所を見よう。'
        + '@@r:軌道の種類|いまの軌道の種類@@ も見ながら。'
    }
  ],
  sideText:
    '<span class="q">この問題の解き方（2本立て）</span>' +
    'この手の問題は、つぎの2本だけで全部とけます。' +
    '<table class="mini">' +
    '<tr><th>使う道具</th><th>式</th></tr>' +
    '<tr><td><b>力学的エネルギー保存</b></td>' +
    '<td>$\\dfrac{1}{2}mv^2-G\\dfrac{Mm}{r}=$ 一定</td></tr>' +
    '<tr><td><b>面積速度一定</b><br>（＝角運動量保存）</td>' +
    '<td>$\\dfrac{1}{2}rv\\sin\\theta=$ 一定<br>近点・遠点では $rv=$ 一定</td></tr>' +
    '<tr><td><b>円運動のとき</b></td>' +
    '<td>$\\dfrac{mv^2}{r}=G\\dfrac{Mm}{r^2}$</td></tr>' +
    '<tr><td><b>ケプラー第3法則</b></td>' +
    '<td>$T^2=\\dfrac{4\\pi^2}{GM}a^3$</td></tr>' +
    '</table>' +
    '<div class="colh">この問題での使いどころ</div>' +
    '<ul class="colul">' +
    '<li><b>打ち上げの $v_0$</b>：地表と点 A でエネルギー保存 → $v_0=\\sqrt{gR}$。' +
    '<b>第一宇宙速度と同じ 7.9 km/s</b> になるのがおもしろいところ。</li>' +
    '<li><b>点 B の速さ $V$</b>：面積速度一定（$2Rv=6RV$）だけで $V=v/3$。' +
    'エネルギー保存を使う前に、まずこれ。</li>' +
    '<li><b>速さ $v$</b>：$V=v/3$ をエネルギー保存に代入して $v=\\dfrac{\\sqrt{3gR}}{2}$。</li>' +
    '<li><b>周期</b>：$a=\\dfrac{2R+6R}{2}=4R$ を第3法則へ入れて ' +
    '$T=16\\pi\\sqrt{\\dfrac{R}{g}}$。</li>' +
    '</ul>' +
    '<b>「エネルギーは向きを問わない・面積速度は向きも込み」</b>——' +
    'この2つを組み合わせると、軌道の形が決まります。' +
    '万有引力による位置エネルギーのイメージは ' +
    '<a href="#m2-2" data-goto="m2-2">2-1</a>、' +
    '軌道の種類の見分け方は <a href="#m2-3" data-goto="m2-3">2-2</a> にあります。',
  cw: 560, ch: 440,
  loop: true,
  vis: ['F', 'V', 'R'],
  visLabel: { F: '万有引力を表示', V: '速度を表示', R: '動径を表示' },
  visDef: { F: false, V: true, R: true },
  vars: [
    {
      k: 'eq', label: '加えるエネルギー $E\'$［$mgR$］', unit: '',
      min: 0.05, max: 0.6, step: 0.025, dec: 3, def: 0.25,
      hint: '$E\'=\\frac{1}{2}mv^2$　1/6 落ちない／1/4 円／3/8 AB／1/2 脱出'
    }
  ],
  mainVars: ['eq'],
  topActionsBelow: true,
  topActions: [
    {
      label: 'E′ を大きくする →', prim: true, play: true,
      fn: function (s) { stepUp(DEFS['m3-1'], s, 'eq', 0.025); }
    },
    {
      label: '半径 2R の円（E′ = mgR/4）', prim: true, play: true,
      fn: function (s) { s.v.eq = P.m31.EQ_CIRC; },
      is: function (v) { return Math.abs(v.eq - P.m31.EQ_CIRC) < 1e-9; }
    },
    {
      label: 'B が 6R のだ円（E′ = 3mgR/8）', prim: true, play: true,
      fn: function (s) { s.v.eq = P.m31.EQ_AB; },
      is: function (v) { return Math.abs(v.eq - P.m31.EQ_AB) < 1e-9; }
    },
    {
      label: '脱出する（E′ = mgR/2）', prim: true, play: true,
      fn: function (s) { s.v.eq = P.m31.EQ_ESC; },
      is: function (v) { return Math.abs(v.eq - P.m31.EQ_ESC) < 1e-9; }
    },
    {
      label: '最初の設定に戻す',
      fn: function (s) { s.v.eq = 0.25; },
      is: function (v) { return Math.abs(v.eq - 0.25) < 1e-9; }
    }
  ],
  tEnd: function (v) {
    var o = m31Orb(v), tOrb;
    if (o.hit) tOrb = P.m31.tHit(o);
    else if (o.bound) tOrb = o.T;
    else tOrb = Math.max(600, o.tTo(9 * M31.R));
    return m31TL() + tOrb;      /* ★はじめの「打ち上げ」の分をたす★ */
  },
  rate: function (v) { return DEFS['m3-1'].tEnd(v) / 16; },
  tFmt: function (t) { return fmt(t / 60, 1) + ' 分'; },
  xlabel: 't [分]',
  sample: function (v, t) {
    var q = m31State(v, t);
    /* 打ち上げ中はまっすぐな運動なので rv⊥ = 0。
       「面積速度が一定」のグラフは、E′ を加えたあと（点 A から）だけ描く。 */
    return { r: q.r, v: q.v, rv: q.launch ? NaN : q.r * q.vt };
  },
  graphs: [
    {
      key: 'eqr', short: '$E\'$ と軌道', title: '$E\'$ と軌道の関係　※加えるエネルギーだけで軌道が決まる',
      open: true, H: 260,
      custom: function (v) {
        var i, apo = [], per = [], eqs = [];
        for (i = 0; i <= 160; i++) {
          var e2 = 0.02 + (0.6 - 0.02) * i / 160;
          var oo = P.m31.make(e2);
          eqs.push(e2);
          apo.push([e2, oo.bound ? oo.ra / M31.R : NaN]);
          per.push([e2, oo.bound ? oo.q / M31.R : (oo.q / M31.R)]);
        }
        var o = m31Orb(v);
        return {
          xmin: 0, xmax: 0.62, ymin: 0, ymax: 14,
          xlabel: "E′ [mgR]", ylabel: 'r [R]', legend: true,
          series: [
            { color: COL.bound, width: 2.4, pts: apo, name: '遠地点 r遠' },
            { color: COL.force, width: 2.2, pts: per, name: '近地点 r近' },
            { color: COL.grid, width: 1.6, dash: [5, 4],
              pts: [[0, 1], [0.62, 1]], name: '地表 R' },
            { color: COL.dim, width: 1.6, dash: [4, 4],
              pts: [[0, 2], [0.62, 2]], name: '点 A（2R）' }
          ],
          marks: [
            { x: P.m31.EQ_CIRC, y: 2, color: COL.bound, r: 5, name: '円', ly: -10 },
            { x: P.m31.EQ_AB, y: 6, color: COL.bound, r: 5, name: 'B（6R）', ly: -10 },
            { x: P.m31.EQ_MIN, y: 1, color: COL.force, r: 5, name: 'ぎりぎり', ly: 13 }
          ],
          vline: { x: v.eq, color: COL.vel, label: "いまの E′ = " + fmt(v.eq, 3) + ' mgR' },
          cursors: o.bound ? [
            { color: COL.vel, x: v.eq, y: o.ra / M31.R, r: 6, name: '遠地点', lx: -10, ly: -11, align: 'right' },
            { color: COL.vel, x: v.eq, y: o.q / M31.R, r: 6, name: '近地点', lx: -10, ly: 13, align: 'right' }
          ] : []
        };
      },
      fml: function (v) {
        var o = m31Orb(v);
        return [
          "E' = \\dfrac{1}{2}mv^2,\\quad v = \\sqrt{2E'/m}",
          'E/m = \\dfrac{1}{2}v^2 - \\dfrac{GM}{2R}\\;\\Rightarrow\\; ' +
          (o.bound ? 'a = -\\dfrac{GM}{2E/m}' : 'E \\ge 0\\;(\\text{戻らない})'),
          "E' = " + fmt(v.eq, 3) + 'mgR \\;\\Rightarrow\\; v = ' + fmt(o.v, 3) +
          '\\,\\mathrm{km/s}\\;(' + K.kindName(o.kind) + ')'
        ];
      }
    },
    {
      key: 'rt', short: '$r$–$t$ 図', title: '$r$–$t$ 図（地球の中心からの距離）', open: false,
      ylabel: 'r [km]',
      series: [{ color: COL.orbit, f: function (m) { return m.r; } }]
    },
    {
      key: 'rvt', short: '$rv_\\perp$–$t$ 図', title: '$rv_\\perp$–$t$ 図　※面積速度が一定であること', open: false,
      ylabel: 'r v⊥ [km²/s]',
      series: [{ color: COL.sect1, f: function (m) { return m.rv; } }]
    }
  ],
  draw: function (ctx, s, t, W, H) {
    var v = V(s), o = m31Orb(v), R = M31.R;
    var q = m31State(v, t);
    /* ★縮尺は固定★ B（6R）が右に入り、A（2R）が左に入るようにとる */
    var vw = mkView(W, H, { l: 30, r: 30, t: 106, b: 34 },
      { x0: -3.4 * R, x1: 7.6 * R, y0: -4.2 * R, y1: 4.2 * R });
    s.view = vw;
    var ox = vw.X(0), oy = vw.Y(0);

    /* めやす：AB を長軸とするだ円（いつもうすく描いておく） */
    (function () {
      var og = P.m31.make(P.m31.EQ_AB);
      var gp = P.m31.path(og, 12 * R, 300);
      ctx.save();
      ctx.strokeStyle = COL.grid; ctx.lineWidth = 1.4; ctx.setLineDash([5, 4]);
      ctx.beginPath();
      gp.forEach(function (p, j) {
        var pp = [vw.X(p[0]), vw.Y(p[1])];
        if (j === 0) ctx.moveTo(pp[0], pp[1]); else ctx.lineTo(pp[0], pp[1]);
      });
      ctx.closePath(); ctx.stroke();
      ctx.restore();
    })();

    /* いまの軌道 */
    var path = P.m31.path(o, 12 * R, 420);
    ctx.save();
    ctx.strokeStyle = orbColor(o.kind); ctx.lineWidth = 2.2;
    var dsh = orbDash(o.kind);
    if (dsh.length) ctx.setLineDash(dsh);
    ctx.beginPath();
    path.forEach(function (p, j) {
      var pp = [vw.X(p[0]), vw.Y(p[1])];
      if (j === 0) ctx.moveTo(pp[0], pp[1]); else ctx.lineTo(pp[0], pp[1]);
    });
    if (o.bound) ctx.closePath();
    ctx.stroke();
    ctx.restore();

    /* 長軸（A と B を結ぶ線）と、点 A・点 B */
    var ax = vw.X(-2 * R), ay = oy;
    dashLine(ctx, vw.X(-3.3 * R), oy, vw.X(7.5 * R), oy, '#c3ccd5', [6, 5], 1);
    /* 地球 */
    var Rpx = Math.max(6, vw.X(R) - ox);
    earthShape(ctx, ox, oy, Rpx, 0);
    /* 地球の名前は「上」に置く。下は、落ちるときの衝突の印が来る場所なので空けておく */
    label(ctx, '地球', ox, oy - Rpx - 12, { size: 10.5, color: '#2a5f96', bold: true });
    label(ctx, 'O', ox + 12, oy + 12,
      { size: 11, color: '#ffffff', bold: true, haloColor: 'rgba(42,95,150,.85)' });

    /* 打ち上げのようす（地表 → 点 A）。いつも描いておき、
       打ち上げ中は「いま通ってきたところ」を濃い実線で見せる。 */
    ctx.save();
    ctx.strokeStyle = fade(COL.sub, 0.7); ctx.lineWidth = 1.4; ctx.setLineDash([3, 3]);
    ctx.beginPath(); ctx.moveTo(vw.X(-R), oy); ctx.lineTo(ax, oy); ctx.stroke();
    ctx.restore();
    if (q.launch) {
      ctx.save();
      ctx.strokeStyle = COL.vel; ctx.lineWidth = 2.4;
      ctx.beginPath(); ctx.moveTo(vw.X(-R), oy); ctx.lineTo(vw.X(-q.r), oy); ctx.stroke();
      ctx.restore();
    }
    /* ★この文字は「絵の左下のすみ」に置く★
       打ち上げの線のそばに置くと、地球の名前や動径の数字と必ず重なる。 */
    label(ctx, '① 地表から v₀ = √(gR) = 7.91 km/s で真上に打ち上げ → A（2R）で速さ 0　'
      + '② その瞬間に E′ を加える', 10, H - 12,
      { size: 10.5, color: COL.sub, align: 'left' });

    /* 点 A */
    ctx.save();
    ctx.fillStyle = '#fff'; ctx.strokeStyle = COL.ink; ctx.lineWidth = 1.6;
    ctx.beginPath(); ctx.arc(ax, ay, 5, 0, TAU); ctx.fill(); ctx.stroke();
    ctx.restore();
    label(ctx, 'A（2R）', ax, ay - 15, { size: 11, color: COL.ink, bold: true });
    /* ★点 B は「長軸の、A の反対がわのはし」★
       A はいつも 2R（−x がわ）なので、B までの距離は 2a − 2R（+x がわ）。
       E′ が小さいと A のほうが遠地点になるので、o.ra を使ってはいけない。
       B が地表より内側に来る（＝地球に落ちる）ときは、印を出さない。 */
    if (o.bound) {
      var rB = 2 * o.a - 2 * R;
      if (rB > R) {
        var bx = vw.X(rB);
        ctx.save();
        ctx.fillStyle = '#fff'; ctx.strokeStyle = COL.bound; ctx.lineWidth = 1.6;
        ctx.beginPath(); ctx.arc(bx, oy, 4.6, 0, TAU); ctx.fill(); ctx.stroke();
        ctx.restore();
        label(ctx, 'B（' + fmt(rB / R, 2) + 'R）', bx, oy - 14,
          { size: 10.5, color: COL.bound, bold: true });
      }
    }

    /* 小物体 */
    var px = vw.X(q.x), py = vw.Y(q.y);
    var inFrame = (px > 6 && px < W - 6 && py > 6 && py < H - 6);
    if (inFrame) {
      if (s.o.showR) radiusLine(ctx, ox, oy, px, py, 'r = ' + fmt(q.r / R, 2) + 'R');
      planetShape(ctx, px, py, 5, '#c7ced6');
      /* ★名前は「速度と垂直な向き」にずらす★
         動径の外向きに置くと、速度の矢印とその数字にかならず重なる。 */
      (function () {
        var vv = Math.max(1e-9, q.v);
        var nx = q.vy / vv, ny = q.vx / vv;
        label(ctx, '小物体 m', px + nx * 25, py + ny * 25,
          { size: 10, bold: true, color: COL.ink });
      })();
      if (s.o.showF) {
        var Fn = M31.GM / (q.r * q.r);
        var FL = clamp(Fn * (64 / (M31.GM / (R * R))), 9, 84);
        gravArrow(ctx, px, py, ox, oy, FL, 'F/m = ' + fmt(Fn * 1000, 2) + ' m/s²', 1);
      }
      if (s.o.showV) {
        var vsc = 46 / Math.max(1e-9, P.m31.vOf(0.6));
        velArrow(ctx, px, py, q.vx, q.vy, vsc, 'v = ' + fmt(q.v, 2) + ' km/s', 10, 16);
      }
    }
    if (o.hit) {
      var qe = P.m31.at(o, DEFS['m3-1'].tEnd(v) - m31TL());
      label(ctx, '★近地点が地表より内側 ＝ 地球に落ちる', W - 10, 72,
        { align: 'right', size: 11.5, bold: true, color: COL.force });
      ctx.save();
      ctx.strokeStyle = COL.force; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(vw.X(qe.x), vw.Y(qe.y), 7, 0, TAU); ctx.stroke();
      ctx.restore();
    }

    m31Legend(ctx, v.eq);
    drawClock(ctx, W, 't = ' + fmt(t / 60, 1) + ' 分');
    /* いまどちらの段なのかを、いつも出しておく */
    label(ctx, q.launch ? '【① 打ち上げ中】まっすぐ上がって、A で速さ 0 になる'
      : '【② A で E′ を加えたあと】', W - 10, 36,
      { align: 'right', size: 11.5, bold: true, color: q.launch ? COL.vel : orbColor(o.kind) });
    if (hintOn(s, t)) {
      label(ctx, 'いまの軌道：' + K.kindName(o.kind) +
        '（v = ' + fmt(o.v, 2) + ' km/s）', W - 10, 54,
        { align: 'right', size: 11.5, bold: true, color: orbColor(o.kind) });
    }
  },
  result: function (v, s, t) {
    var o = m31Orb(v), R = M31.R, gR = P.m31.gR();
    var items = [
      /* ★解説（probs）から参照している項目は、かならずここに置くこと★
         （もとの (1)「地表での g を求めよ」は先生の指示でカットしたので、
           そのためだけに置いていた「地表での F/m」の項目も外した。） */
      resItem('打ち上げの速さ $v_0=\\sqrt{gR}$', fmt(Math.sqrt(gR), 3) + ' km/s'),
      resItem("加えた $E\'$", fmt(v.eq, 3) + ' mgR'),
      resItem('点 A での速さ $v$', fmt(o.v, 3) + ' km/s'),
      resItem('軌道の種類', K.kindName(o.kind) + (o.hit ? '（地球に落ちる）' : '')),
      resItem('力学的エネルギー $E/m$', fmt(o.Em, 3) + ' MJ/kg'),
      resItem('面積速度 $\\frac{1}{2}rv_\\perp$', fmt(0.5 * o.L, 0) + ' km²/s', true)
    ];
    if (o.bound) {
      items = items.concat([
        resItem('近地点 $r_{\\text{近}}$', fmt(o.q / R, 3) + ' R'),
        resItem('遠地点 $r_{\\text{遠}}$', fmt(o.ra / R, 3) + ' R'),
        resItem('点 B の速さ $V$', fmt(o.L / o.ra, 3) + ' km/s'),
        resItem('半長軸 $a$', fmt(o.a / R, 3) + ' R'),
        resItem('周期 $T$', fmt(o.T / 60, 1) + ' 分', true),
        resItem('離心率 $\\varepsilon$', fmt(o.e, 3))
      ]);
    }
    var note;
    if (o.hit) {
      note = '<b>近地点が地表（R）より内側</b>なので、物体は地球に落ちます。' +
        '落ちないための条件は $E\'\\ge\\dfrac{mgR}{6}$（$v\\ge\\sqrt{gR/3}=' +
        fmt(Math.sqrt(gR / 3), 2) + '$ km/s）。';
    } else if (!o.bound) {
      note = '<b>$E\\ge0$ なので、戻ってきません</b>（' + K.kindName(o.kind) + '）。' +
        '境目は $E\'=\\dfrac{mgR}{2}$、つまり $v=\\sqrt{gR}=' + fmt(Math.sqrt(gR), 2) + '$ km/s。';
    } else {
      note = '<b>$2Rv = r_{\\text{遠}}V$（面積速度一定）</b>を確かめよう：' +
        '$2Rv = ' + fmt(2 * R * o.v, 0) + '$、$r_{\\text{遠}}V = ' +
        fmt(o.ra * (o.L / o.ra), 0) + '$ km²/s で、ぴったり同じです。' +
        (Math.abs(v.eq - P.m31.EQ_AB) < 1e-9
          ? '<br>いまは<b>問題の (4)</b> の状態：$a=4R$、$V=v/3$、$T=16\\pi\\sqrt{R/g}$。' : '');
    }
    return { items: items, note: note };
  },
  info: function (s, t) {
    var v = V(s), o = m31Orb(v), q = P.m31.at(o, t);
    return [
      ['加えた $E\'$', fmt(v.eq, 3) + ' mgR'],
      ['点 A での速さ $v$', fmt(o.v, 3) + ' km/s'],
      ['いまの距離 $r$', fmt(q.r / M31.R, 3) + ' R'],
      ['いまの速さ $v$', fmt(q.v, 3) + ' km/s'],
      ['$r\\,v_\\perp$', fmt(q.r * q.vt, 0) + ' km²/s'],
      ['時刻 $t$', fmt(t / 60, 1) + ' 分']
    ];
  },
  eq: function () {
    return "\\tfrac{1}{2}mv^2 - G\\dfrac{Mm}{r} = \\text{一定},\\quad rv_\\perp = \\text{一定}" +
      "\\quad\\Longrightarrow\\quad E' = \\tfrac{1}{4}mgR\\;(\\text{円}),\\;" +
      "\\tfrac{3}{8}mgR\\;(\\text{AB}),\\; \\tfrac{1}{2}mgR\\;(\\text{脱出})";
  }
};

/* ============================================================
   3-2　地球トンネル（出典：名古屋大 2005）
   ------------------------------------------------------------
   中心を通るまっすぐな穴。x 軸上の好きなところから静かに放す。
   ★内側（|x0| ≤ R）で放すと単振動（周期は x0 によらず 84.4 分）★
   ★外側（|x0| > R）で放すと、落ちてきて中を通りぬけ、反対がわの
     同じ高さまで上がって戻る★
   ============================================================ */
var M32 = { GM: 398600.4418, R: 6371 };

function m32H(v) { return P.m32.make(v.x0R * M32.R, v.v0); }

DEFS['m3-2'] = {
  id: 'm3-2', mode: 3, tab: '3-2 地球トンネル',
  legendKeys: ['force', 'vel', 'dim'],
  title: '3-2　地球トンネル　—　（出典：名古屋大 2005）',
  probImg: 'prob_m32', ansImg: 'ans_m32',
  sub: '一様な密度の地球に、<b>中心を通るまっすぐな穴</b>をあけます。' +
    'x 軸上の点 $x_0$ から、小球を<b>初速度 $v_0$（$+x$ の向き）で発射</b>します' +
    '（$v_0=0$ なら「静かに放す」）。<br>' +
    '<b>動く範囲が地球の中におさまるかぎり、いつでも単振動</b>で、' +
    '<b>周期は 84.4 分のまま変わりません</b>（等時性）。' +
    '<b>外まで出ると</b>、外にいるあいだはふつうの万有引力（$1/x^2$）にしたがい、' +
    '中に入ったとたんに<b>変位に比例する力</b>に変わります。' +
    '$v_0$ を<b>その場所の脱出速度</b>より大きくすると、戻ってきません。',
  probsHead: '入試問題を読み解く　—　名古屋大 2005（一部やさしく書きかえています）',
  probsSetup:
    '<b>半径 $R$・質量 $M$ の、密度が一様な球の惑星</b>を考えます'
    + '（このページでは、数字を分かりやすくするために「地球」としています）。<br>'
    + '<b>この惑星の中心を通る、まっすぐな細い穴（トンネル）を掘ります。</b>'
    + '穴にそって $x$ 軸をとり、中心を原点 $O$ とします。'
    + '穴の体積は惑星に比べてごくわずかで、質量は減らないものとします。'
    + '惑星は<b>自転していない</b>とし、空気もないものとします。<br>'
    + 'この穴の中や外に<b>質量 $m$ の小球 A</b> を置いて、静かに放したり、'
    + '$+x$ の向きに速さ $v_0$ で発射したりします。'
    + '<b>「$x$ の正の向きを、力の正の向き」</b>とします。',
  probs: [
    {
      q: '<b>(1)</b> $x$ 軸上の位置 $x\\ge R$ にある質量 $m$ の物体 A にはたらく力 $F$ と、'
        + 'その位置エネルギー $U$（無限遠を基準）を求めよ。',
      a: '地球の外なので、ふつうの万有引力：'
        + '$F=-G\\dfrac{Mm}{x^2}$、$U=-G\\dfrac{Mm}{x}$。'
        + '<b>符号は「$x$ の正の向きを正」</b>にとるので、$x>0$ では力はマイナス（中心向き）。',
      do: '@@g:Fx|$F$–$x$ 図を開く@@　$|x|>R$ のところが $1/x^2$ の形になっている。'
        + '<br>@@r:その場所の脱出速度|その場所の脱出速度@@ も、この $U$ から出た値です。'
    },
    {
      q: '<b>(2)</b> 物体 A を<b>惑星の表面（$x=R$）から $+x$ の向きに発射</b>する。'
        + '$x=3R$ の位置に到達させるために必要な、初速度 $v_0$ の最小値を求めよ。',
      a: '<b>「行き先の $x=3R$ でちょうど速さ 0 になる」のが最小</b>。'
        + 'エネルギー保存 $\\dfrac{1}{2}v_0^2-\\dfrac{GM}{R}=0-\\dfrac{GM}{3R}$ より '
        + '$v_0=\\sqrt{\\dfrac{4GM}{3R}}=\\sqrt{\\dfrac{4gR}{3}}=9.13$ km/s。',
      do: '@@r:x=3R に届く最小の初速度|$x=3R$ に届く最小の初速度 ＝ 9.133 km/s@@ を確かめよう。'
        + '<br>ここで動かして試せます：@@v:x0R@@ @@v:v0@@'
        + '<br>@@s:x0R=1,v0=9.1|$x_0=R$・$v_0=9.1$（ぎりぎり届く）@@ '
        + '@@s:x0R=1,v0=9.2|$v_0=9.2$（こえる）@@ そのあと '
        + '@@r:いちばん遠くまで|いちばん遠くまで $x_{max}$@@ を見よう。'
    },
    {
      setup: '<b>ここからは「穴の中」の話です。</b>'
        + '球の内部では、<b>自分より外側の殻からの引力はぴったり打ち消しあって 0</b> になります。'
        + 'だから、深さ $|x|$ にいる小球には<b>「半径 $|x|$ より内側の部分の質量」だけ</b>が効き、'
        + 'しかもそれが<b>中心に集まっている</b>と考えてよい——これがこの問題の要です。',
      q: '<b>(3)</b> 物体 A が穴の中の位置 $-R<x<R$ にあるとき、A が受ける力 $f$ を求めよ。'
        + '半径 $|x|$ の内側の球の質量 $M_{\\text{内}}$ だけが効き、その質量が中心に集まっていると考えてよい。',
      a: '$M_{\\text{内}}=M\\left(\\dfrac{|x|}{R}\\right)^3$ なので '
        + '$f=-G\\dfrac{mM_{\\text{内}}}{x^2}=-\\dfrac{GMm}{R^3}x$。'
        + '<b>変位に比例して中心へ向かう力</b>——これはばねと同じ形（＝単振動）です。',
      do: '@@g:Fx|$F$–$x$ 図を開く@@　$|x|&lt;R$ のところが<b>まっすぐな直線</b>になっている。'
    },
    {
      q: '<b>(4)</b> $f$ と $x$ の関係のグラフをかけ（$x=R$ での値も書きこむこと）。',
      a: '内は直線・外は $1/x^2$ の<b>折れ線</b>。'
        + 'つなぎ目 $x=R$ で $|f|/m$ は最大の $\\dfrac{GM}{R^2}=g=9.8$ m/s²。'
        + '<b>地表がいちばん重力が強い</b>のがポイント。',
      do: '@@g:Fx|$F$–$x$ 図を開く@@　$x=\\pm R$ の印が山のてっぺんになっている。'
        + '@@r:地表での F/m|地表での $F/m$ ＝ 9.82 m/s²@@ が、その高さです。'
    },
    {
      q: '<b>(5)</b> 地球の表面から初速度 0 で落とすと、物体は単振動する。'
        + 'その理由と、周期を求めよ。',
      a: '(3) より $f=-\\dfrac{GMm}{R^3}x$ ＝ 変位に比例して中心を向く力なので単振動。'
        + '角振動数は $\\omega=\\sqrt{\\dfrac{GM}{R^3}}=\\sqrt{\\dfrac{g}{R}}$、'
        + '周期は $T=2\\pi\\sqrt{\\dfrac{R}{g}}=84.4$ 分。'
        + '<b>地表すれすれの円軌道の周期とまったく同じ</b>です。',
      do: '@@b:0|地表から静かに放す（$x_0=R$）@@ を押してスタート。'
        + '@@r:周期|周期 $T$ ＝ 84.35 分@@ になる。'
        + '<br>そのあと、ここで $x_0$ を小さくしても <b>$T$ が変わらない</b>ことを確かめよう（等時性）：@@v:x0R@@'
        + '<br>@@s:x0R=0.5,v0=0|$x_0=0.5R$@@ @@s:x0R=0.2,v0=0|$x_0=0.2R$@@'
    },
    {
      q: '<b>(6)</b> (5) のとき、表面から中心に最初に到達するまでの時間 $t_1$ と、'
        + '中心での速さ $v_1$ を求めよ。',
      a: '$t_1$ は周期の $\\dfrac{1}{4}$ なので $t_1=\\dfrac{\\pi}{2}\\sqrt{\\dfrac{R}{g}}=21.1$ 分。'
        + '中心では振幅 $R$ の単振動の最大速度なので $v_1=R\\omega=\\sqrt{gR}=7.9$ km/s。'
        + '<b>これも第一宇宙速度と同じ値</b>です。',
      do: '@@b:0|地表から静かに放す@@ にしてから、上の<b>時間バー</b>を $T/4$（約 21 分）まで動かそう。'
        + '$x=0$ で @@r:中心での速さ|中心での速さ ＝ 7.910 km/s@@ になる。'
    },
    {
      q: '<b>(7)</b> 物体 A が<b>中心 $O$ を通過するときの速さ $v_2$</b> が、いくら以上あれば、'
        + '$x=3R$ の位置まで到達できるか。'
        + '（ヒント：穴の中では、復元力を $-kx$（$k$ は比例定数）とすると、'
        + '中心 $O$ を基準にした位置エネルギーが $\\dfrac{1}{2}kx^2$ と書ける。）',
      a: '<b>$x=R$ に出てきたときの速さが、(2) の $v_0$ になっていればよい。</b><br>'
        + '穴の中（$-R\\le x\\le R$）では $k=\\dfrac{GMm}{R^3}$ のばねと同じなので、'
        + '$\\dfrac{1}{2}mv^2+\\dfrac{1}{2}kx^2=$ 一定。中心と表面で比べて<br>'
        + '$\\dfrac{1}{2}mv_2^2+0=\\dfrac{1}{2}mv_0^2+\\dfrac{1}{2}kR^2$。'
        + '$v_0^2=\\dfrac{4}{3}gR$、$\\dfrac{k}{m}R^2=gR$ を入れて '
        + '$v_2^2=\\dfrac{4}{3}gR+gR=\\dfrac{7}{3}gR$、'
        + 'よって $v_2=\\sqrt{\\dfrac{7gR}{3}}=12.08$ km/s。<br>'
        + '<b>(6) の中心での速さ 7.91 km/s より速い</b>——'
        + '穴を出るところまでで、ばねの位置エネルギーぶんを使ってしまうからです。',
      do: '@@s:x0R=0,v0=12.1|中心から $v_2=12.1$ km/s で発射@@ してスタート。'
        + '　@@r:いちばん遠くまで|いちばん遠くまで $x_{max}$@@ が 3R をこえる。'
        + '<br>@@s:x0R=0,v0=12.0|$v_2=12.0$（届かない）@@ と比べよう。'
        + 'ここで $v_0$ を動かして、境目をさがしてもよい：@@v:v0@@'
    }
  ],
  sideText:
    '<span class="q">なぜ「内側だけが効く」のか</span>' +
    '一様な球殻の内部では、<b>殻のどの部分からの引力もぴったり打ち消しあって 0</b> になります。' +
    '近い側は近いぶん強いけれど、立体角で見ると小さい——この2つがちょうど釣り合うためです。<br>' +
    'だから深さ $r$ にいる小球には、<b>「半径 $r$ より内側の質量」だけ</b>が効きます。' +
    '<div class="colh">この問題のポイント</div>' +
    '<ul class="colul">' +
    '<li><b>位置エネルギー</b>は、外側 $U=-G\\dfrac{Mm}{x}$、' +
    '内側 $U=-\\dfrac{GMm}{2R}\\left(3-\\dfrac{x^2}{R^2}\\right)$。' +
    '$x=R$ でつながります。</li>' +
    '<li><b>単振動の周期は振幅によらない</b>（等時性）。' +
    'だから「地表から放す」も「途中から放す」も 84.4 分。</li>' +
    '<li><b>中心での速さ</b>は、地表から放したとき $v=\\sqrt{gR}=7.9$ km/s。' +
    'これも第一宇宙速度と同じ値です。</li>' +
    '<li><b>$x=3R$ まで届く最小の初速度</b>はエネルギー保存から ' +
    '$v=\\sqrt{\\dfrac{4gR}{3}}=9.13$ km/s。</li>' +
    '</ul>' +
    '<b>じつは、地球のどこからどこへ掘っても（中心を通らなくても）' +
    '片道 42 分・往復 84.4 分</b>です。' +
    '重力による位置エネルギーの谷のイメージは ' +
    '<a href="#m2-2" data-goto="m2-2">2-1</a> を見てください。',
  cw: 560, ch: 560,
  loop: true,
  vis: ['F', 'V'],
  visLabel: { F: '万有引力を表示', V: '速度を表示' },
  visDef: { F: true, V: true },
  vars: [
    {
      k: 'x0R', label: '放す位置 $x_0$［$R$］', unit: '',
      min: 0.0, max: 4.0, step: 0.1, dec: 1, def: 1.0,
      hint: 'R = 6371 km（地表）'
    },
    {
      k: 'v0', label: '地球外向きの初速度 $v_0$（$+x$ の向き）', unit: ' km/s',
      /* ★上限は 13.0★ (7) の答え $v_2=\\sqrt{7gR/3}=12.08$ km/s をこえられるように。
         12.0 で頭を打つと、境目をさがす操作ができない。 */
      min: 0, max: 13.0, step: 0.1, dec: 1, def: 0,
      hint: '0 なら「静かに放す」。$\\sqrt{gR}=7.9$ で中心から地表まで届く'
    }
  ],
  mainVars: ['x0R', 'v0'],
  topActionsBelow: true,
  topActions: [
    {
      label: '地表から静かに放す（x₀ = R）', prim: true, play: true,
      fn: function (s) { s.v.x0R = 1.0; s.v.v0 = 0; },
      is: function (v) { return Math.abs(v.x0R - 1) < 1e-9 && Math.abs(v.v0) < 1e-9; }
    },
    {
      label: '真ん中から発射する（v₀ = 7.9 km/s）', prim: true, play: true,
      fn: function (s) { s.v.x0R = 0.0; s.v.v0 = 7.9; },
      is: function (v) { return Math.abs(v.x0R) < 1e-9 && Math.abs(v.v0 - 7.9) < 1e-9; }
    },
    {
      label: '外から静かに放す（x₀ = 3R）', prim: true, play: true,
      fn: function (s) { s.v.x0R = 3.0; s.v.v0 = 0; },
      is: function (v) { return Math.abs(v.x0R - 3) < 1e-9 && Math.abs(v.v0) < 1e-9; }
    },
    {
      label: '最初の設定に戻す',
      fn: function (s) { s.v.x0R = 1.0; s.v.v0 = 0; },
      is: function (v) { return Math.abs(v.x0R - 1) < 1e-9 && Math.abs(v.v0) < 1e-9; }
    }
  ],
  tEnd: function (v) {
    var h = m32H(v);
    /* 脱出してしまうとき（E ≥ 0）は、画面の外（4.4R）まで飛ぶ時間にする */
    if (!h.bound) return Math.max(60, P.m32.phi(h, 4.4 * M32.R) - h.tau0);
    return h.T;
  },
  rate: function (v) { return DEFS['m3-2'].tEnd(v) / 16; },
  tFmt: function (t) { return fmt(t / 60, 1) + ' 分'; },
  xlabel: 't [分]',
  sample: function (v, t) {
    var h = m32H(v), q = P.m32.at(h, t);
    return { x: q.x / M32.R, v: q.v, r: Math.abs(q.x) };
  },
  graphs: [
    {
      key: 'xt', short: '$x$–$t$ 図', title: '$x$–$t$ 図（位置）　※内側だけならサインカーブ', open: true,
      ylabel: 'x [R]',
      series: [{ color: COL.vel, f: function (m) { return m.x; } }]
    },
    {
      key: 'vt', short: '$v$–$t$ 図', title: '$v$–$t$ 図（速度）　※中心で速さが最大', open: false,
      ylabel: 'v [km/s]',
      series: [{ color: COL.acc, f: function (m) { return m.v; } }]
    }
  ],
  draw: function (ctx, s, t, W, H) {
    var v = V(s), h = m32H(v), R = M32.R;
    var q = P.m32.at(h, t);
    var xm = 4.4 * R;
    var vw = mkView(W, H, { l: 26, r: 26, t: 40, b: 310 },
      { x0: -xm, x1: xm, y0: -1.35 * R, y1: 1.35 * R });
    s.view = vw;
    var ox = vw.X(0), oy = vw.Y(0);
    var Rpx = vw.X(R) - ox;

    /* x 軸 */
    ctx.save();
    ctx.strokeStyle = AX.col; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(vw.X(-xm), oy); ctx.lineTo(vw.X(xm) - 8, oy); ctx.stroke();
    ctx.restore();
    arrowHead(ctx, vw.X(xm), oy, 1, 0, AX.col);
    label(ctx, 'x', vw.X(xm) - 4, oy - 14, { size: 11, color: AX.col, bold: true });
    [-4, -3, -2, -1, 1, 2, 3, 4].forEach(function (k) {
      var pxk = vw.X(k * R);
      ctx.save();
      ctx.strokeStyle = AX.col; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(pxk, oy - 4); ctx.lineTo(pxk, oy + 4); ctx.stroke();
      ctx.restore();
      label(ctx, (k > 0 ? '' : '−') + Math.abs(k) + 'R', pxk, oy + 16,
        { size: 9.5, color: AX.col });
    });

    /* 地球（半分に切った図として、うすい断面で描く） */
    ctx.save();
    ctx.beginPath(); ctx.arc(ox, oy, Rpx, 0, TAU);
    ctx.fillStyle = 'rgba(74,134,200,.22)'; ctx.strokeStyle = '#2a5f96'; ctx.lineWidth = 1.6;
    ctx.fill(); ctx.stroke();
    ctx.restore();
    /* トンネル */
    ctx.save();
    ctx.strokeStyle = '#fff'; ctx.lineWidth = 7;
    ctx.beginPath(); ctx.moveTo(ox - Rpx, oy); ctx.lineTo(ox + Rpx, oy); ctx.stroke();
    ctx.strokeStyle = '#9fb0c0'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(ox - Rpx, oy - 3.5); ctx.lineTo(ox + Rpx, oy - 3.5);
    ctx.moveTo(ox - Rpx, oy + 3.5); ctx.lineTo(ox + Rpx, oy + 3.5);
    ctx.stroke();
    ctx.restore();
    label(ctx, '地球（一様な球）', ox, oy - Rpx - 12, { size: 10.5, color: '#2a5f96', bold: true });
    label(ctx, 'O', ox - 13, oy - 12, { size: 11, color: COL.sub, bold: true });

    /* 放す位置 */
    var sx = vw.X(h.x0);
    var q0 = P.m32.at(h, 0);
    ctx.save();
    ctx.strokeStyle = COL.sub; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(sx, oy, 7, 0, TAU); ctx.stroke();
    ctx.restore();
    label(ctx, (v.v0 > 0 ? '発射する位置 x₀ = ' : '放す位置 x₀ = ') + fmt(v.x0R, 1) + 'R',
      sx, oy - 36, { size: 10.5, color: COL.sub, bold: true });
    dashLine(ctx, vw.X(-h.x0), oy - 26, vw.X(-h.x0), oy + 26, fade(COL.sub, 0.6), [3, 3], 1);

    /* 小球 */
    var bx = vw.X(q.x);
    planetShape(ctx, bx, oy, 6, q.zone === 'in' ? '#b5543a' : '#c7ced6');
    label(ctx, '小球 m', bx, oy - 18, { size: 10.5, bold: true, color: COL.ink });
    if (s.o.showV) {
      /* 速さの数字は、目もりの文字（oy+16）より下に置く */
      var vsc = 40 / Math.max(1e-9, h.A * h.w);
      velArrow(ctx, bx, oy, q.v, 0, vsc, 'v = ' + fmt(Math.abs(q.v), 2) + ' km/s', 0, 36);
    }
    if (s.o.showF) {
      var Fn = P.m32.F(q.x);
      var FL = clamp(Fn * (60 / (M32.GM / (R * R) * 1000)), 6, 70);
      if (Math.abs(q.x) > 1e-6) gravArrow(ctx, bx, oy, ox, oy, FL, '', 1);
    }

    /* 下の帯：いまの状態のことば */
    var msg = !h.bound
      ? '★脱出速度をこえた ＝ 二度と戻ってこない'
      : (h.inside
        ? '内側だけを動く ＝ 単振動（周期は x₀ によらず 84.4 分）'
        : (q.zone === 'in' ? '地球の中：単振動と同じ動き（変位に比例する力）'
          : '地球の外：ふつうの万有引力（距離の2乗に反比例）'));
    label(ctx, msg, W / 2, H - 296,
      { size: 11.5, bold: true, color: q.zone === 'in' ? '#b5543a' : COL.sub });

    /* ===== 下半分：U–x 図 と F–x 図 を たてに並べる =====
       ★x の目もりを上下でぴったりそろえる★（先生の指示）
       同じ x のところで「位置エネルギーの谷の深さ」と「力の向き・大きさ」を
       見比べられるようにするため。
       U–x：横軸を U = 0（無限遠が基準）の高さに置く。U はいつも負なので、
             曲線は全部軸より下に来る（2-1 の U–r グラフと同じ約束）。
       F–x：横軸を F = 0 の高さに置く。力は向きで符号が変わるので、
             軸の上下で「＋x 向き／−x 向き」が読める。 */
    (function () {
      var pl = 48, pr = W - 22;
      var uy0 = H - 264, uh = 112;            /* U–x 図の枠（296〜408） */
      var fy0 = H - 124, fh = 104;            /* F–x 図の枠（436〜540） */
      var Umax = 10, Umin = -100;             /* MJ/kg */
      var Fmax = M32.GM / (R * R) * 1000;     /* 地表での F/m ＝ 9.82 m/s² */
      var Flim = Fmax * 1.25;
      function UX(x) { return pl + (x / (2 * xm) + 0.5) * (pr - pl); }
      function UY(u) { return uy0 + (1 - (u - Umin) / (Umax - Umin)) * uh; }
      function FY(f) { return fy0 + fh / 2 - f / Flim * (fh / 2); }

      /* --- 共通：横軸（x）を1本引く。y は「その図での 0 の高さ」--- */
      function xAxis(yz, lab) {
        ctx.save();
        ctx.strokeStyle = AX.col; ctx.lineWidth = 1.2;
        ctx.beginPath(); ctx.moveTo(pl - 6, yz); ctx.lineTo(pr, yz); ctx.stroke();
        ctx.restore();
        arrowHead(ctx, pr + 6, yz, 1, 0, AX.col);
        label(ctx, lab, pr + 4, yz - 12, { size: 10.5, color: AX.col, bold: true, align: 'right' });
        [-4, -3, -2, -1, 1, 2, 3, 4].forEach(function (k) {
          var xk = UX(k * R);
          ctx.save();
          ctx.strokeStyle = AX.col; ctx.lineWidth = 1;
          ctx.beginPath(); ctx.moveTo(xk, yz - 3.5); ctx.lineTo(xk, yz + 3.5); ctx.stroke();
          ctx.restore();
          label(ctx, (k > 0 ? '' : '−') + Math.abs(k), xk, yz + 12,
            { size: 9, color: AX.col });
        });
      }
      /* --- 共通：たて軸を1本引く --- */
      function yAxis(ytop, ybot, lab) {
        ctx.save();
        ctx.strokeStyle = AX.col; ctx.lineWidth = 1.2;
        ctx.beginPath(); ctx.moveTo(pl, ybot); ctx.lineTo(pl, ytop + 8); ctx.stroke();
        ctx.restore();
        arrowHead(ctx, pl, ytop, 0, -1, AX.col);
        /* たて軸の名前は「軸のすぐ右・矢じりの下」に置く。
           図の名前（左上）とぶつからない場所はここしかない。 */
        label(ctx, lab, pl + 7, ytop + 9, { size: 10, color: AX.col, bold: true, align: 'left' });
      }

      /* ===== ① U–x 図 ===== */
      label(ctx, '【U–x 図】位置エネルギー U [MJ/kg]（谷の深さ）', 10, uy0 - 13,
        { size: 11, bold: true, color: COL.sub, align: 'left' });
      yAxis(uy0 - 2, uy0 + uh, 'U');
      xAxis(UY(0), 'x [R]');
      label(ctx, '0', pl - 8, UY(0), { size: 9, color: AX.col, align: 'right' });
      [-50, -100].forEach(function (u) {
        var yy = UY(u);
        if (yy > uy0 + uh) return;
        ctx.save();
        ctx.strokeStyle = AX.col; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(pl - 4, yy); ctx.lineTo(pl + 4, yy); ctx.stroke();
        ctx.restore();
        label(ctx, fmt(u, 0), pl - 8, yy, { size: 9, color: AX.col, align: 'right' });
      });
      /* U の曲線（内は放物線・外は −GM/x） */
      var pts = [], i;
      for (i = -240; i <= 240; i++) {
        var xx = xm * i / 240, ax = Math.abs(xx), u;
        u = (ax <= R) ? -M32.GM / (2 * R) * (3 - (ax * ax) / (R * R)) : -M32.GM / ax;
        pts.push([xx, u]);
      }
      ctx.save();
      ctx.strokeStyle = COL.upot; ctx.lineWidth = 2.2;
      ctx.beginPath();
      pts.forEach(function (p, j) {
        var X1 = UX(p[0]), Y1 = UY(clamp(p[1], Umin, Umax));
        if (j === 0) ctx.moveTo(X1, Y1); else ctx.lineTo(X1, Y1);
      });
      ctx.stroke();
      ctx.restore();
      label(ctx, 'U（外は −GM/x・内は放物線）', pr - 4, uy0 + uh - 5,
        { size: 9.5, color: COL.upot, align: 'right' });
      /* 力学的エネルギー E（一定）＝水平線 */
      var Etot = clamp(h.E, Umin, Umax);
      ctx.save();
      ctx.strokeStyle = COL.cg; ctx.lineWidth = 1.6; ctx.setLineDash([6, 4]);
      ctx.beginPath(); ctx.moveTo(pl, UY(Etot)); ctx.lineTo(pr, UY(Etot)); ctx.stroke();
      ctx.restore();
      label(ctx, 'E（一定）', pr - 4, UY(Etot) - 9,
        { size: 10, color: COL.cg, align: 'right', bold: true });
      /* いまの位置：U の点と、E との差（＝運動エネルギー K） */
      var ux = UX(q.x);
      var un = (Math.abs(q.x) <= R)
        ? -M32.GM / (2 * R) * (3 - (q.x * q.x) / (R * R)) : -M32.GM / Math.abs(q.x);
      dashLine(ctx, ux, UY(Etot), ux, UY(clamp(un, Umin, Umax)), COL.vel, [3, 3], 1.4);
      ctx.save();
      ctx.fillStyle = COL.vel; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.6;
      ctx.beginPath(); ctx.arc(ux, UY(clamp(un, Umin, Umax)), 4.6, 0, TAU); ctx.fill(); ctx.stroke();
      ctx.restore();
      label(ctx, 'K', ux + 8, (UY(Etot) + UY(clamp(un, Umin, Umax))) / 2,
        { size: 10, color: COL.vel, bold: true, align: 'left' });

      /* ===== ② F–x 図（U–x のすぐ下・x の目もりは同じ） ===== */
      /* ★たて軸は F（力そのもの）★（先生の指示）
         小球の質量を m = 1 kg と決めておけば、F [N] の数値は F/m [m/s²] と同じ。 */
      label(ctx, '【F–x 図】万有引力 F [N]（小球を m = 1 kg とする・内は直線・外は 1/x²）',
        10, fy0 - 13, { size: 11, bold: true, color: COL.sub, align: 'left' });
      yAxis(fy0 - 2, fy0 + fh, 'F');
      xAxis(FY(0), 'x [R]');
      [-5, 5].forEach(function (f) {
        var yy = FY(f);
        ctx.save();
        ctx.strokeStyle = AX.col; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(pl - 4, yy); ctx.lineTo(pl + 4, yy); ctx.stroke();
        ctx.restore();
        label(ctx, (f > 0 ? '+' : '−') + Math.abs(f), pl - 8, yy, { size: 9, color: AX.col, align: 'right' });
      });
      /* F の曲線。＋が x の正の向き（中心を向く向きが符号で分かる） */
      var fpts = [];
      for (i = -260; i <= 260; i++) {
        var xf = xm * i / 260, axf = Math.abs(xf);
        var Fv = (axf <= R) ? M32.GM * axf / (R * R * R) * 1000 : M32.GM / (axf * axf) * 1000;
        fpts.push([xf, (xf >= 0 ? -Fv : Fv)]);
      }
      ctx.save();
      ctx.strokeStyle = COL.force; ctx.lineWidth = 2.2;
      ctx.beginPath();
      fpts.forEach(function (p, j) {
        var X2 = UX(p[0]), Y2 = FY(clamp(p[1], -Flim, Flim));
        if (j === 0) ctx.moveTo(X2, Y2); else ctx.lineTo(X2, Y2);
      });
      ctx.stroke();
      ctx.restore();
      /* 地表（±R）の点＝いちばん力が大きいところ */
      [1, -1].forEach(function (sg) {
        ctx.save();
        ctx.fillStyle = COL.sub;
        ctx.beginPath(); ctx.arc(UX(sg * R), FY(-sg * Fmax), 3.4, 0, TAU); ctx.fill();
        ctx.restore();
      });
      label(ctx, '地表（±R）で最大 9.82 N', UX(-3.3 * R), FY(Fmax * 0.72),
        { size: 9, color: COL.sub, align: 'left' });
      /* いまの位置 */
      var Fn2 = P.m32.F(q.x) * (q.x >= 0 ? -1 : 1);
      dashLine(ctx, ux, FY(0), ux, FY(clamp(Fn2, -Flim, Flim)), COL.vel, [3, 3], 1.4);
      ctx.save();
      ctx.fillStyle = COL.vel; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.6;
      ctx.beginPath(); ctx.arc(ux, FY(clamp(Fn2, -Flim, Flim)), 4.6, 0, TAU); ctx.fill(); ctx.stroke();
      ctx.restore();
      /* 2つの図で「いまの x」がそろっていることを、たての線でつなぐ */
      dashLine(ctx, ux, uy0 + uh + 2, ux, fy0 - 6, fade(COL.vel, 0.55), [3, 4], 1);
      label(ctx, 'いまの x = ' + fmt(q.x / R, 2) + 'R', pr - 2, fy0 - 13,
        { size: 9.5, color: COL.vel, bold: true, align: 'right' });
    })();

    drawClock(ctx, W, 't = ' + fmt(t / 60, 1) + ' 分');
    if (hintOn(s, t)) {
      label(ctx, h.bound ? ('周期 T = ' + fmt(h.T / 60, 1) + ' 分')
        : ('脱出（E ≥ 0）　v₀ > ' + fmt(P.m32.vEsc(h.x0), 2) + ' km/s'),
        10, 18, { align: 'left', size: 11.5, bold: true, color: h.bound ? COL.acc : COL.force });
    }
  },
  result: function (v, s, t) {
    var h = m32H(v), R = M32.R, GM = M32.GM;
    var g = GM / (R * R) * 1000;
    var v3R = Math.sqrt(2 * GM * (1 / R - 1 / (3 * R)));
    function spd(x) { return Math.sqrt(Math.max(0, 2 * (h.E - P.m32.U(x)))); }
    var items = [
      resItem('はじめの位置 $x_0$', fmt(h.x0, 0) + ' km（' + fmt(v.x0R, 1) + ' R）'),
      resItem('はじめの速さ $v_0$', fmt(v.v0, 1) + ' km/s'),
      resItem('力学的エネルギー $E/m$', fmt(h.E, 2) + ' MJ/kg', true),
      resItem('その場所の脱出速度', fmt(P.m32.vEsc(h.x0), 3) + ' km/s'),
      resItem('中心での速さ', fmt(spd(0), 3) + ' km/s'),
      resItem('地表（$x=R$）での速さ', fmt(spd(R), 3) + ' km/s'),
      resItem('地表での $F/m$（＝$g$）', fmt(g, 2) + ' m/s²'),
      resItem('$\\sqrt{gR}$（第一宇宙速度）', fmt(Math.sqrt(GM / R), 3) + ' km/s'),
      resItem('$x=3R$ に届く最小の初速度', fmt(v3R, 3) + ' km/s')
    ];
    if (h.bound) {
      items.splice(3, 0, resItem('周期 $T$', fmt(h.T / 60, 2) + ' 分', true));
      items.splice(4, 0, resItem('いちばん遠くまで $x_{max}$',
        fmt(h.inside ? h.A / R : h.xmax / R, 2) + ' R'));
    }
    items.splice(h.bound ? 6 : 4, 0,
      resItem('内側だけの周期 $2\\pi\\sqrt{R/g}$', fmt(P.m32.Tin() / 60, 2) + ' 分', true));
    var note;
    if (!h.bound) {
      note = '<b>$E \\ge 0$ なので、もう二度と戻ってきません。</b>' +
        'この場所の脱出速度は <b>' + fmt(P.m32.vEsc(h.x0), 2) + ' km/s</b>。' +
        '$v_0$ をそれより小さくすると、また往復するようになります。';
    } else if (h.inside) {
      note = '<b>内側だけを動くとき、周期はいつでも 84.4 分</b>です。' +
        '$x_0$ や $v_0$ を変えても、$T$ の値がまったく動かないことを確かめよう' +
        '（＝単振動の等時性）。動く範囲（$x_{max}$）と速さだけが変わります。';
    } else {
      note = '<b>地球の外まで出るので、周期は 84.4 分より長くなります</b>（' +
        fmt(h.T / 60, 1) + ' 分）。外にいるあいだは万有引力（$1/x^2$）、' +
        '地球の中に入ったとたんに<b>変位に比例する力</b>に変わり、' +
        '反対がわの同じところまで行って、また戻ってきます。';
    }
    return { items: items, note: note };
  },
  info: function (s, t) {
    var v = V(s), h = m32H(v), q = P.m32.at(h, t);
    return [
      ['いまの位置 $x$', fmt(q.x / M32.R, 3) + ' R'],
      ['いまの速さ $|v|$', fmt(Math.abs(q.v), 3) + ' km/s'],
      ['いまの $F/m$', fmt(P.m32.F(q.x), 3) + ' m/s²'],
      ['いる場所', q.zone === 'in' ? '地球の中（単振動）' : '地球の外（万有引力）'],
      ['周期 $T$', fmt(h.T / 60, 2) + ' 分'],
      ['時刻 $t$', fmt(t / 60, 2) + ' 分']
    ];
  },
  eq: function () {
    return '|x|\\le R:\\; F=-\\dfrac{GMm}{R^3}x \\;\\Rightarrow\\; ' +
      'T=2\\pi\\sqrt{\\dfrac{R^3}{GM}}=2\\pi\\sqrt{\\dfrac{R}{g}}=84.4\\,\\text{分}\\qquad ' +
      '|x|>R:\\; F=-\\dfrac{GMm}{x^2}';
  }
};

/* ============================================================
   3-3　地球と月（出典：関西学院大）
   ------------------------------------------------------------
   [A] 前半…地球は動かないとみなし、月だけが等速円運動する。
   [B] 後半…地球も月も、共通重心のまわりを同じ角速度で回る。
   ★質量比 μ = m/M を大きくしていくと、[A] と [B] の違いが見えてくる★
   ============================================================ */
var M33 = { GM: 398600.4418, R: 6371, RM: 1737, MU0: 0.0123, R0: 384400 };
var M33_DAY = 86400;

function m33H(v) { return P.m33.make(v.r0, M33.MU0 * v.mk); }
function m33At(h, s, t) {
  return P.m33.atA(h, t);
}

DEFS['m3-3'] = {
  id: 'm3-3', mode: 3, tab: '3-3 地球と月',
  legendKeys: ['force', 'vel', 'dim', 'orbit', 'cg'],
  title: '3-3　地球と月　—　（出典：関西学院大）',
  probImg: 'prob_m33', ansImg: 'ans_m33',
  sub: '月は地球のまわりを、ほぼ等速円運動しています。' +
    '入試ではまず<b>【A】地球は動かないとみなす</b>で解き、' +
    'つぎに<b>【B】地球も月も共通重心のまわりを回る</b>に進みます。<br>' +
    '<b>上の図が【A】、下の図が【B】</b>です。時間は共通なので、見比べてください。<br>' +
    '<b>はじめの画面では、月の質量を本当の 20 倍にしてあります。</b>' +
    'そうしないと共通重心が地球の中に入ってしまい、' +
    '【B】で<b>2つがたがいに回っている</b>ようすが見えないからです' +
    '（<b>「本当の月に戻す」</b>ボタンで ×1 にできます。' +
    'なお【A】の式に $m$ は入らないので、【A】の周期 27.452 日・速さ 1.018 km/s は変わりません）。',
  probsHead: '入試問題を読み解く　—　関西学院大（一部やさしく書きかえています）',
  probsSetup:
    '<b>地球（質量 $M$）と月（質量 $m$）だけ</b>を考えます（太陽やほかの天体は無視）。'
    + '2つの距離は $r_0$ で、万有引力定数を $G$ とします。'
    + '地球も月も<b>大きさの無視できる質点</b>として扱います。<br>'
    + '<b>【A】前半</b>：まず「<b>地球は動かない</b>」と考えて、'
    + '月だけが地球を中心とする<b>半径 $r_0$ の等速円運動</b>をしているとします。'
    + '高校の問題は、ふつうここまでです。<br>'
    + '<b>【B】後半</b>：本当は、地球も月に引かれて動きます。'
    + '2つは<b>共通重心（重さの中心）</b>を通る直線上に並んだまま、'
    + '<b>同じ角速度で</b>それぞれ円運動します。'
    + '共通重心から地球までを $r_1$、月までを $r_2$（$r_1+r_2=r_0$）とします。<br>'
    + '<b>図は、上が【A】・下が【B】</b>。時間 $t$ は共通なので、'
    + '同じ時間でどれだけ進みかたが違うかが見えます。',
  probs: [
    {
      q: '<b>【A】(1)</b> 地球（質量 $M$）のまわりを、月（質量 $m$）が半径 $r_0$ の等速円運動をしている。'
        + '月が受ける万有引力の大きさを $G,M,m,r_0$ で表せ。',
      a: '$F=G\\dfrac{Mm}{r_0^2}$。<b>作用・反作用</b>なので、地球も同じ大きさの力を受けています。',
      do: '「万有引力を表示」をオンにして、<b>上の【A】の図</b>を見よう。'
        + '<b>2本の赤い矢印の長さが同じ</b>であることを確かめよう。'
        + '　@@r:万有引力|万有引力 $F/m$ の値@@'
    },
    {
      q: '<b>【A】(2)(3)</b> 月の運動の周期 $T$ と速さ $v$ を、$G,M,r_0$ で表せ。',
      a: '<b>向心力＝万有引力</b>：$mr_0\\omega^2=G\\dfrac{Mm}{r_0^2}$ より '
        + '$\\omega=\\sqrt{\\dfrac{GM}{r_0^3}}$。'
        + 'よって $T=\\dfrac{2\\pi}{\\omega}=2\\pi\\sqrt{\\dfrac{r_0^3}{GM}}$、'
        + '$v=r_0\\omega=\\sqrt{\\dfrac{GM}{r_0}}$。'
        + '<b>$T^2\\propto r_0^3$ ＝ ケプラー第3法則</b>がここから出ます。',
      do: '@@r:【A】周期|【A】周期 $T$ ＝ 27.452 日@@ '
        + '@@r:月の速さ（【A】）|月の速さ ＝ 1.018 km/s@@ を確かめよう。'
        + '<br>ここで $r_0$ を動かすと、@@g:Tr|$T$–$r_0$ 図@@ の点が線の上を動きます：@@v:r0@@'
    },
    {
      q: '<b>【A】(4)(5)(6)</b> 月の力学的エネルギー $E$ を求めよ。'
        + 'また、<b>(5) $E$ が減少すると半径 $r_0$ はどうなるか。'
        + '(6) $r_0$ が減少すると速さ $v$ はどうなるか。</b>',
      a: '<b>(4)</b> $E=\\dfrac{1}{2}mv^2-G\\dfrac{Mm}{r_0}=\\dfrac{GMm}{2r_0}-\\dfrac{GMm}{r_0}'
        + '=-\\dfrac{GMm}{2r_0}$。<b>「運動エネルギーは位置エネルギーの $-\\frac{1}{2}$ 倍」</b>'
        + 'が円軌道の特徴。<br>'
        + '<b>(5)</b> $E$ は負なので、$E$ が減る＝$\\dfrac{GMm}{2r_0}$ の絶対値が大きくなる。'
        + 'よって $r_0$ は<b>減少</b>する。<br>'
        + '<b>(6)</b> $\\dfrac{1}{2}mv^2=\\dfrac{GMm}{2r_0}$ なので、$r_0$ が減れば $v$ は<b>増加</b>する。<br>'
        + '<b>★エネルギーを失ったのに速くなる★</b>——'
        + '空気の抵抗で落ちてくる人工衛星が、かえって速くなるのはこのためです。',
      do: '@@r:月の E/m|月の $E/m$@@ と @@r:月の脱出速度|月の脱出速度@@ を見よう。'
        + '脱出速度は、いまの速さのちょうど $\\sqrt{2}$ 倍になっている。'
        + '<br>ここで $r_0$ を小さくすると、'
        + '@@r:月の速さ（【A】）|月の速さ@@ が大きくなることを確かめよう：@@v:r0@@'
        + '<br><b>※ここは「円軌道どうしを比べた話」</b>です。'
        + 'いまの月に横向きの加速を与えると円ではなくなり、だ円が<b>大きく</b>なります'
        + '（→ <a href="#m1-5" data-goto="m1-5">1-4</a>・'
        + '<a href="#m2-2" data-goto="m2-2">2-1</a>）。'
        + '<b>「速くする」と「エネルギーを失って落ちる」は、別の話</b>だと気をつけて。'
    },
    {
      setup: '<b>ここから【B】（後半）です。</b>'
        + '「地球は動かない」という仮定をやめ、<b>地球も月も動く</b>ことにします。'
        + '2つをまとめて見ると、その<b>共通重心は動きません</b>（外から力を受けていないから）。'
        + 'そこで<b>共通重心を原点にとって</b>、地球と月がそのまわりを回る、と考えます。',
      q: '<b>【B】(1)(2)</b> 実際には、地球も月も<b>共通重心</b>のまわりを、'
        + '同じ角速度 $\\omega$ で円運動している。'
        + '共通重心から地球までを $r_1$、月までを $r_2$（$r_1+r_2=r_0$）として、'
        + '月の向心力の式を書き、$\\omega$ を求めよ。',
      a: '共通重心の定義から $Mr_1=mr_2$、これと $r_1+r_2=r_0$ より '
        + '$r_1=\\dfrac{m}{M+m}r_0$、$r_2=\\dfrac{M}{M+m}r_0$。<br>'
        + '月について <b>向心力＝万有引力</b>：$mr_2\\omega^2=G\\dfrac{Mm}{r_0^2}$。'
        + '$r_2$ を代入して $\\omega=\\sqrt{\\dfrac{G(M+m)}{r_0^3}}$。'
        + '<b>【A】の $M$ が $M+m$ に変わるだけ</b>です。',
      do: '<b>下の【B】の図</b>には共通重心（×印）が出て、地球も回っている。'
        + '@@r:共通重心|共通重心 $r_1$ が地球の中心から何 km か@@ を見よう。'
        + '<br>月の質量をここで変えると、共通重心が動きます：@@v:mk@@'
    },
    {
      q: '<b>【B】(3)(4)</b> 地球も月と同じ角速度で円運動していることを確かめ、'
        + '円運動の周期 $T$ を $G,M,m,r_0$ で表せ。',
      a: '地球について $Mr_1\\omega^2=G\\dfrac{Mm}{r_0^2}$ を解いても、同じ $\\omega$ が出ます'
        + '（$Mr_1=mr_2$ だから）。<b>だから2つはいつも一直線に並んだまま回る</b>。<br>'
        + '$T=\\dfrac{2\\pi}{\\omega}=2\\pi\\sqrt{\\dfrac{r_0^3}{G(M+m)}}$。'
        + '<b>【A】より少しだけ短い</b>。',
      do: '@@b:0|月を軽くする →@@ を何回か押して、'
        + '@@r:2つの周期の違い|【A】と【B】の周期の違い（%）@@ が小さくなっていくのを見よう。'
        + '<br>@@s:mk=1|本当の月（×1）@@ では <b>0.6 % しか違わない</b>'
        + '——だから高校の問題では【A】でよいのです。'
        + '逆に @@s:mk=15|×15（共通重心が地球の外へ）@@ にすると、'
        + 'もう「地球は動かない」とは言えません。'
    }
  ],
  sideText:
    '<span class="q">【A】と【B】は何が違うのか</span>' +
    '<table class="mini">' +
    '<tr><th></th><th>【A】地球は動かない</th><th>【B】共通重心のまわり</th></tr>' +
    '<tr><td><b>回る中心</b></td><td class="c">地球の中心</td><td class="c">共通重心</td></tr>' +
    '<tr><td><b>月の円の半径</b></td><td class="c">$r_0$</td>' +
    '<td class="c">$r_2=\\dfrac{M}{M+m}r_0$</td></tr>' +
    '<tr><td><b>角速度</b></td><td class="c">$\\sqrt{\\dfrac{GM}{r_0^3}}$</td>' +
    '<td class="c">$\\sqrt{\\dfrac{G(M+m)}{r_0^3}}$</td></tr>' +
    '<tr><td><b>周期</b></td><td class="c">$2\\pi\\sqrt{\\dfrac{r_0^3}{GM}}$</td>' +
    '<td class="c">$2\\pi\\sqrt{\\dfrac{r_0^3}{G(M+m)}}$</td></tr>' +
    '<tr><td><b>地球は</b></td><td class="c">止まっている</td>' +
    '<td class="c">半径 $r_1$ の円を回る</td></tr>' +
    '</table>' +
    '<div class="colh">見どころ</div>' +
    '<ul class="colul">' +
    '<li><b>本当の月（月の質量 ×1）では、共通重心は地球の中にあります</b>' +
    '（中心から約 4670 km ＝ 地球の半径 6371 km の内側）。' +
    'だから「地球は動かない」としてもほとんど合うのです。</li>' +
    '<li>月の質量を <b>×15 ほど</b>にすると、共通重心が<b>地球の外</b>へ出ます。' +
    'こうなると、もう「地球は動かない」とは言えません。' +
    'これが<b>連星</b>の状態です。</li>' +
    '<li>2つの物体にはたらく万有引力は<b>いつも大きさが同じで向きが反対</b>' +
    '（作用・反作用）。図の2本の赤い矢印の長さが同じことを確かめよう。</li>' +
    '<li>周期の式に出てくるのが $M$ ではなく <b>$M+m$</b> であること——' +
    'これがケプラー第3法則の「※同じ天体の周りをまわるもの同士で成り立つ」の正体です。</li>' +
    '<li><b>いつ【A】で済ませてよいのか</b>——' +
    '<b><a href="#m2-1" data-goto="m2-1">補足：ケプラー則の本質</a></b> で確かめられるとおり、' +
    '<b>質量比 $M/m$ が大きいほど共通重心は重い方に寄り、重い方はほとんど動かなくなります</b>。' +
    'だから<b>「大きい側は固定して考えてよい」</b>——これが【A】の正体です。' +
    '地球と月は $M/m=81$ で共通重心が地球の中に入るので【A】でほぼ合い、' +
    '太陽と地球なら $M/m=33$ 万でなおさらです。' +
    '逆に $M/m$ が 1 に近づくと（連星）、この近似はまったく使えません。</li>' +
    '</ul>',
  /* 上下2段（上＝【A】前半・下＝【B】後半）なので、縦を2倍にとる */
  cw: 560, ch: 620,
  loop: true,
  vis: ['F', 'V', 'T'],
  visLabel: { F: '万有引力を表示', V: '速度を表示', T: '軌道を表示' },
  visDef: { F: true, V: true, T: true },
  vars: [
    {
      k: 'mk', label: '本来よりも月の質量を何倍にするか', unit: ' 倍',
      min: 1, max: 80, step: 1, dec: 0, def: 20,
      /* ★はじめは ×20★（先生の指示）
         本当の月（×1）だと共通重心が地球の中に入ってしまい、
         【B】の図で「たがいに回っている」ようすがまったく見えないため。
         【A】の式には m が入らない（地球は動かないとみなす）ので、
         この値を変えても【A】の周期・速さは 27.452 日・1.018 km/s のまま。 */
      hint: '本当は $m/M=0.0123$。15 倍で共通重心が地球の外へ（はじめは ×20 にしてあります）'
    },
    {
      k: 'r0', label: '地球と月の距離 $r_0$', unit: ' km',
      min: 184400, max: 484400, step: 20000, dec: 0, def: 384400,
      hint: '本当の距離は 384400 km（約 38万 km）'
    }
  ],
  mainVars: ['mk', 'r0'],
  topActionsBelow: true,
  topActions: [
    {
      /* ★「重くする」ではなく「軽くする」★（先生の指示）
         はじめが ×20 なので、押していくと 15 → 10 → 5 → 1（本当の月）と、
         「デフォルメをほどいて本当の月に近づけていく」向きになる。 */
      /* ★下限（＝本当の月 ×1）まで来たら、そこで止める★（先生の指示・2026-09-03）
         前は下限から上限（×80）へ一周して戻っていたので、
         押しつづけると「勝手にすごく重くなった」と見えていた。
         いまは noWrap（第5引数 true）で下限に止め、ボタン自体も押せなくする。 */
      label: '月を軽くする →', prim: true, play: true,
      dis: function (v) { return v.mk <= 1 + 1e-9; },
      fn: function (s) { stepDown(DEFS['m3-3'], s, 'mk', 5, true); }
    },
    {
      label: '共通重心が地球の外へ出る（×15）', prim: true, play: true,
      fn: function (s) { s.v.mk = 15; },
      is: function (v) { return v.mk === 15; }
    },
    {
      label: '本当の月に戻す',
      fn: function (s) { s.v.mk = 1; s.v.r0 = 384400; },
      is: function (v) { return v.mk === 1 && v.r0 === 384400; }
    }
  ],
  /* 時間は上下で共通。【A】の1周ぶんを1サイクルにする
     （【B】はそれより少し速いので、1周したとき少し先へ進んでいる） */
  tEnd: function (v) { return m33H(v).TA; },
  rate: function (v) { return DEFS['m3-3'].tEnd(v) / 20; },
  tFmt: function (t) { return fmt(t / M33_DAY, 1) + ' 日'; },
  xlabel: 't [日]',
  sample: function (v, t) {
    var h = m33H(v), a = P.m33.atA(h, t), b = P.m33.atB(h, t);
    return {
      r: h.r0, v: Math.hypot(a.m.vx, a.m.vy),
      thA: (h.wA * t) / DEG, thB: (h.wB * t) / DEG
    };
  },
  graphs: [
    {
      key: 'Tr', short: '$T$–$r_0$ 図', title: '$T$–$r_0$ 図（ケプラー第3法則）　※【A】と【B】の差', open: true,
      H: 250,
      custom: function (v, s) {
        var i, A = [], B = [], mu = M33.MU0 * v.mk;
        for (i = 0; i <= 140; i++) {
          var r = 100000 + (620000 - 100000) * i / 140;
          A.push([r / 1000, TAU * Math.sqrt(r * r * r / M33.GM) / M33_DAY]);
          B.push([r / 1000, TAU * Math.sqrt(r * r * r / (M33.GM * (1 + mu))) / M33_DAY]);
        }
        var h = m33H(v);
        return {
          xmin: 0, xmax: 640, ymin: 0, ymax: 60,
          xlabel: 'r₀ [千km]', ylabel: 'T [日]', legend: true,
          series: [
            { color: COL.orbit, width: 2.4, pts: A, name: '【A】T = 2π√(r₀³/GM)' },
            { color: COL.bound, width: 2.2, dash: [6, 4], pts: B, name: '【B】GM → G(M+m)' }
          ],
          marks: [
            { x: 384.4, y: TAU * Math.sqrt(Math.pow(384400, 3) / M33.GM) / M33_DAY,
              color: COL.sub, r: 4.6, name: '本当の月（27.4 日）', ly: -11 }
          ],
          vline: { x: v.r0 / 1000, color: COL.vel, label: 'いまの r₀ = ' + fmt(v.r0 / 1000, 0) + ' 千km' },
          cursors: [
            { color: COL.vel, x: v.r0 / 1000, y: h.TA / M33_DAY, r: 6,
              name: '【A】' + fmt(h.TA / M33_DAY, 2) + ' 日', lx: -10, ly: -12, align: 'right' },
            { color: COL.bound, x: v.r0 / 1000, y: h.TB / M33_DAY, r: 5.4,
              name: '【B】' + fmt(h.TB / M33_DAY, 2) + ' 日', lx: 10, ly: 13, align: 'left' }
          ]
        };
      },
      fml: function (v, s) {
        var h = m33H(v);
        return [
          '\\text{【A】}\\;T = 2\\pi\\sqrt{\\dfrac{r_0^3}{GM}} = ' + fmt(h.TA / M33_DAY, 3) + '\\,\\text{日}',
          '\\text{【B】}\\;T = 2\\pi\\sqrt{\\dfrac{r_0^3}{G(M+m)}} = ' + fmt(h.TB / M33_DAY, 3) + '\\,\\text{日}',
          '\\text{違い} = ' + fmt((h.TA / h.TB - 1) * 100, 2) + '\\,\\%'
        ];
      }
    },
    {
      key: 'th', short: '回転角–$t$ 図', title: '回転角–$t$ 図　※【B】のほうが少しだけ速い', open: false,
      ylabel: '回転角 [°]',
      series: [
        { color: COL.orbit, f: function (m) { return m.thA; } },
        { color: COL.bound, f: function (m) { return m.thB; } }
      ]
    }
  ],
  /* ★【A】と【B】を上下2つの図に分けて、同時に見せる★
     切りかえ式（プルダウン）だと、生徒は2つを見比べられない（先生の指示）。
     時間は共通の t。周期は【B】のほうが少し短いので、
     1周したときに【B】が少し先へ進んでいるのが、そのまま「違い」の見える化になる。 */
  draw: function (ctx, s, t, W, H) {
    var v = V(s), h = m33H(v);
    var LIM = 500000;                       /* r0 の最大（484400 km）が入る大きさ */
    var HALF = H / 2;

    function panel(y0, y1, isB) {
      var q = isB ? P.m33.atB(h, t) : P.m33.atA(h, t);
      var vw = mkView(W, y1 - y0, { l: 26, r: 26, t: 44, b: 8 },
        { x0: -LIM * 1.5, x1: LIM * 1.5, y0: -LIM, y1: LIM });
      /* mkView は「高さ y1−y0 のキャンバス」として作られるので、y をずらして使う */
      var X = vw.X, Y = function (yy) { return y0 + vw.Y(yy); };
      var cgx = X(0), cgy = Y(0);

      ctx.save();
      ctx.beginPath(); ctx.rect(0, y0, W, y1 - y0); ctx.clip();

      /* 見出しの帯 */
      ctx.save();
      ctx.fillStyle = isB ? 'rgba(63,74,84,.10)' : 'rgba(22,99,181,.09)';
      ctx.fillRect(0, y0, W, 38);
      ctx.restore();
      label(ctx, isB ? '【B】後半：地球も月も、共通重心のまわりを同じ角速度で回る'
        : '【A】前半：地球は動かないとみなし、月だけが等速円運動する',
        W / 2, y0 + 13, { size: 12, bold: true, color: isB ? COL.cg : '#1663b5' });
      label(ctx, isB
        ? 'T = 2π√(r₀³/G(M+m)) = ' + fmt(h.TB / M33_DAY, 2) + ' 日　　共通重心は地球の中心から ' +
        fmtAuto(h.r1, 0) + ' km　　地球の速さ ' + fmt(h.v1 * 1000, 1) + ' m/s'
        : 'T = 2π√(r₀³/GM) = ' + fmt(h.TA / M33_DAY, 2) + ' 日　　月の速さ v = ' + fmt(h.vA, 3) +
        ' km/s　　r₀ = ' + fmtAuto(h.r0, 0) + ' km',
        W / 2, y0 + 29, { size: 10, color: COL.sub });
      /* ★はじめの画面で「たがいに回っている」のが見えるように、月を重くしてある★
         そのことは、かならず画面の中で断っておく。 */
      if (isB && v.mk > 1) {
        label(ctx, '※ 月の質量を本当の ' + fmt(v.mk, 0) + ' 倍にしてあります'
          + '（本当の月では共通重心が地球の中に入り、地球はほとんど動きません）',
          W / 2, y1 - 26, { size: 9.5, color: COL.force });
      }

      /* 軌道の円 */
      if (s.o.showT) {
        var rm = isB ? h.r2 : h.r0;
        ctx.save();
        ctx.strokeStyle = fade(COL.orbit, 0.95); ctx.lineWidth = 1.6; ctx.setLineDash([5, 4]);
        ctx.beginPath(); ctx.arc(cgx, cgy, X(rm) - X(0), 0, TAU); ctx.stroke();
        ctx.restore();
        if (isB && h.r1 > 1) {
          ctx.save();
          ctx.strokeStyle = fade('#2a5f96', 0.8); ctx.lineWidth = 1.4; ctx.setLineDash([4, 3]);
          ctx.beginPath(); ctx.arc(cgx, cgy, Math.max(1.5, X(h.r1) - X(0)), 0, TAU); ctx.stroke();
          ctx.restore();
        }
      }

      var ex = X(q.e.x), ey = Y(q.e.y);
      var mx = X(q.m.x), my = Y(q.m.y);
      var dxm = mx - ex, dym = my - ey, dm = Math.hypot(dxm, dym) || 1;
      dashLine(ctx, ex, ey, mx, my, COL.dim, [5, 4], 1.2);

      var Rpx = Math.max(9, X(M33.R * 8) - X(0));     /* 見やすさのため 8 倍にデフォルメ */
      earthShape(ctx, ex, ey, Rpx, 0);
      /* ★【B】では、地球の名前を「線に垂直な向き」に出す★
         【B】は地球と共通重心がほとんど重なるので、線にそって置くと
         「共通重心（×印）」の文字と必ずぶつかる（垂直方向の反対がわに逃がす）。 */
      if (isB) {
        /* 地球の名前は「地球の真上」に出す。共通重心の文字は×印の真下に固定してあるので、
           上下に分かれてぶつからない。地球が下に来たときも×印にかからないよう、
           cgy - 16 より下へは行かせない。 */
        label(ctx, '地球 M', ex, Math.min(ey - Rpx - 12, cgy - 16),
          { size: 10.5, color: '#2a5f96', bold: true, haloColor: '#fff' });
      } else {
        label(ctx, '地球 M', ex - dxm / dm * (Rpx + 14), ey - dym / dm * (Rpx + 14),
          { size: 10.5, color: '#2a5f96', bold: true });
      }
      var RMpx = Math.max(5, X(M33.RM * 8) - X(0));
      planetShape(ctx, mx, my, RMpx, '#9a8d80');
      label(ctx, '月 m', mx + dxm / dm * (RMpx + 14), my + dym / dm * (RMpx + 14),
        { size: 10.5, color: '#7d7266', bold: true });

      if (s.o.showF) {
        gravArrow(ctx, mx, my, ex, ey, 42, 'F', 1);
        gravArrow(ctx, ex, ey, mx, my, 42, 'F', -1);
      }
      if (s.o.showV) {
        var vmax = Math.max(h.vA, h.v2, h.v1) || 1;
        var vsc = 44 / vmax;
        var vm = Math.hypot(q.m.vx, q.m.vy) || 1;
        velArrow(ctx, mx, my, q.m.vx, q.m.vy, vsc,
          'v = ' + fmt(vm, 3) + ' km/s', q.m.vx / vm * 14 + 8, -q.m.vy / vm * 14 - 4);
        if (isB && h.v1 * vsc > 5) velArrow(ctx, ex, ey, q.e.vx, q.e.vy, vsc, null);
      }
      /* ★共通重心の×印は、天体や矢印より「あと」に描いて前面に出す★
         （「補足：ケプラー則の本質」と同じ作り）
         月の質量が 10 倍以下だと共通重心が地球の絵の中に入るので、
         先に描くと地球にかくれて「どこにあるか分からない」と言われた（先生の指摘）。
         白い太線を下に敷いてから濃いグレーで描くと、地球の上でもはっきり読める。 */
      if (isB) {
        ctx.save();
        ctx.lineCap = 'round';
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 4.5;
        ctx.beginPath();
        ctx.moveTo(cgx - 7, cgy - 7); ctx.lineTo(cgx + 7, cgy + 7);
        ctx.moveTo(cgx + 7, cgy - 7); ctx.lineTo(cgx - 7, cgy + 7);
        ctx.stroke();
        ctx.strokeStyle = COL.cg; ctx.lineWidth = 2.4;
        ctx.beginPath();
        ctx.moveTo(cgx - 7, cgy - 7); ctx.lineTo(cgx + 7, cgy + 7);
        ctx.moveTo(cgx + 7, cgy - 7); ctx.lineTo(cgx - 7, cgy + 7);
        ctx.stroke();
        ctx.restore();
        /* ★文字は動かさない★（先生の指示）
           共通重心は「動かない点」なので、文字も同じ場所に出しつづけたほうが、
           生徒にそのことが伝わる。×印のすぐ下に固定する。 */
        label(ctx, '共通重心（×印）', cgx, cgy + 24,
          { size: 10.5, color: COL.cg, bold: true, haloColor: '#fff' });
      }

      ctx.restore();
      return q;
    }

    var qA = panel(0, HALF, false);
    var qB = panel(HALF, H, true);

    /* 区切り線 */
    ctx.save();
    ctx.strokeStyle = '#cfd8e0'; ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.moveTo(0, HALF); ctx.lineTo(W, HALF); ctx.stroke();
    ctx.restore();

    if (s.o.showF) {
      label(ctx, '2本の F は、いつも大きさが同じで向きが反対（作用・反作用）',
        W / 2, HALF - 10, { size: 10, color: COL.force });
    }
    label(ctx, '※ 地球と月の大きさは 8 倍にデフォルメ。時間 t は上下で共通',
      W / 2, H - 8, { size: 10, color: COL.sub });
    /* 【B】は少し速いので、【A】が1周したとき【B】は少し先へ進んでいる */
    if (hintOn(s, t)) {
      /* ★角度の数字は出さない★（先生の指示）
         「何度違うか」は、下の2つの図を見比べれば分かる。 */
      var inside = h.r1 < M33.R;
      label(ctx, inside
        ? '共通重心は地球の中（' + fmtAuto(h.r1, 0) + ' km ＜ 地球の半径 6371 km）'
        : '共通重心は地球の外（' + fmtAuto(h.r1, 0) + ' km ＞ 6371 km）',
        10, HALF + 46, { align: 'left', size: 11, bold: true,
          color: inside ? COL.sub : COL.force });
    }
    drawClock(ctx, W, 't = ' + fmt(t / M33_DAY, 1) + ' 日', 52);
  },
  result: function (v, s, t) {
    var h = m33H(v);
    return {
      items: [
        resItem('距離 $r_0$', fmtAuto(h.r0, 0) + ' km'),
        resItem('万有引力 $F/m$', fmt(h.Fm, 5) + ' m/s²'),
        resItem('【A】周期 $T$', fmt(h.TA / M33_DAY, 3) + ' 日', true),
        resItem('【B】周期 $T$', fmt(h.TB / M33_DAY, 3) + ' 日', true),
        resItem('2つの周期の違い', fmt((h.TA / h.TB - 1) * 100, 2) + ' %'),
        resItem('月の速さ（【A】）', fmt(h.vA, 3) + ' km/s'),
        resItem('月の速さ（【B】）', fmt(h.v2, 3) + ' km/s'),
        resItem('地球の速さ（【B】）', fmt(h.v1 * 1000, 1) + ' m/s'),
        resItem('共通重心 $r_1$', fmtAuto(h.r1, 0) + ' km' + (h.r1 < M33.R ? '（地球の中）' : '（地球の外）')),
        resItem('月の $E/m$（【A】）', fmt(h.EmA, 3) + ' MJ/kg'),
        resItem('月の脱出速度', fmt(h.vEsc, 3) + ' km/s')
      ],
      note: '<b>【A】と【B】の周期の違いは ' + fmt((h.TA / h.TB - 1) * 100, 2) + ' %。</b>' +
        (h.mu < 0.05
          ? '月の質量が地球に比べてずっと小さいので、ほとんど差がありません。' +
          '<b>だから高校の問題では「地球は動かない」としてよい</b>のです。'
          : '月を重くしたので、もう無視できない違いになりました。' +
          'このとき $T=2\\pi\\sqrt{\\dfrac{r_0^3}{G(M+m)}}$ の <b>$M+m$</b> が効いてきます。') +
        '<br>月の質量を大きくすると、<b>下の【B】の図で地球のほうも大きく振りまわされる</b>' +
        'ことを確かめよう。'
    };
  },
  info: function (s, t) {
    var v = V(s), h = m33H(v);
    var a = P.m33.atA(h, t), b = P.m33.atB(h, t);
    return [
      ['【A】月の速さ $v$', fmt(Math.hypot(a.m.vx, a.m.vy), 3) + ' km/s'],
      ['【B】月の速さ $v$', fmt(Math.hypot(b.m.vx, b.m.vy), 3) + ' km/s'],
      ['【B】地球の速さ', fmt(Math.hypot(b.e.vx, b.e.vy) * 1000, 1) + ' m/s'],
      ['【A】角速度 $\\omega$', fmtE(h.wA, 3) + ' rad/s'],
      ['【B】角速度 $\\omega$', fmtE(h.wB, 3) + ' rad/s'],
      ['経過した時間 $t$', fmt(t / M33_DAY, 2) + ' 日']
    ];
  },
  eq: function () {
    return '\\text{【A】}\\; mr_0\\omega^2 = G\\dfrac{Mm}{r_0^2} \\quad\\Longrightarrow\\quad ' +
      '\\text{【B】}\\; mr_2\\omega^2 = G\\dfrac{Mm}{r_0^2},\\; r_2=\\dfrac{M}{M+m}r_0';
  }
};
