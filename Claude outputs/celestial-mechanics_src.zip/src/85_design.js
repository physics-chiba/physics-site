/* =========================================================================
   デザイン移植の動き（2026-10）
   見本＝momentum-and-collision.html の 85_design.js。
   このページ用に作りかえたのは initStage()（ヒーローのアニメ）だけで、
   作り方の約束（大きさは canvas から決める・ストロボの1枚絵・止める条件・
   window.__hero.frame で決まった瞬間を描かせる）は見本のまま。

   ★ヒーローのアニメ＝「軌道の種類」★（先生の選択・2026-10-03）
     地表から真横に打ち出す速さ v0 = k√(gR) を 1 → 1.5 → 2 → 2.5 と変え、
     円 → だ円 → 放物線 → 双曲線 と変わるのを見せる。
     ★閉じた式だけ★（数値積分はしない）。軌道は円すい曲線の式
       r(θ) = L²/GM / (1 + ε cos θ)
     から出す。2-2（m2-3）とまったく同じ物理。
   ★暗い地なので、物理の色は「同じ色相の明るい版」を使う★（キット 1 章）。
     本文の図の色（COL.*）は1ミリも変えない。
   ========================================================================= */
(function () {
  'use strict';
  var RM = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var SER = '"KaTeX_Main","Times New Roman",serif',
      MATH = '"KaTeX_Math","KaTeX_Main",serif',
      JP = '"Hiragino Sans","Hiragino Kaku Gothic ProN","Yu Gothic",YuGothic,"Noto Sans JP",Meiryo,sans-serif';
  /* 暗い地での色（同じ色相の明るい版）。本文の図は COL.* のまま */
  var C = {
    earth: '#5aa7ff',      /* 地球（本文は earthShape の青） */
    ell:   '#49d18a',      /* 円・だ円  ← COL.bound #1c8f4a の明るい版 */
    para:  '#e8c96a',      /* 放物線    ← COL.para  #b58900 の明るい版 */
    hyp:   '#c3ccd6',      /* 双曲線    ← COL.hyper #3f4a54 の明るい版 */
    vel:   '#7fc0ff',      /* 速度      ← COL.vel   #1663b5 の明るい版 */
    T:     '#f6f2e9', dim: 'rgba(243,239,230,.42)', brand: '#e07b18'
  };
  /* 打ち出す速さ（第一宇宙速度の何倍か）と、そのときの軌道の名前 */
  var KS = [1.0, 1.5, 2.0, 2.5];
  var KNAME = { 1: '円', 1.5: 'だ円', 2: '放物線', 2.5: '双曲線' };
  var KCOL = { 1: C.ell, 1.5: C.ell, 2: C.para, 2.5: C.hyp };

  /* ===== ヒーローのステージ ===== */
  function initStage() {
    var cv = document.getElementById('heroCv'); if (!cv) return;
    var ctx = cv.getContext('2d');
    var W = 0, H = 0, dpr = 1, run = false, raf = 0, last = 0;
    var cyc = 0, t = 0, sc = null, lockK = null, paused = false, rate = 1;

    function setup() {
      var r = cv.getBoundingClientRect();
      dpr = Math.min(2, window.devicePixelRatio || 1);
      W = Math.max(280, r.width); H = Math.max(160, r.height);
      cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var s = Math.max(W < 640 ? 0.86 : 0.72, Math.min(1.15, H / 260));
      /* 地球の半径を R=1 として、画面にどれだけの px を当てるか。
         双曲線（k=2.5）でも画面に収まるよう、canvas の小さいほうの辺から決める */
      /* 地球の半径［px］。いちばん大きい だ円（k=2.5 の手前、k=1.5 の遠地点 r=3）が
         画面に入るように、よこ・たての両方から決める。 */
      var R = Math.min(W * 0.078, H * 0.215);
      sc = { s: s, R: R, cx: W * 0.40, cy: H * 0.52 };
    }
    /* 円すい曲線（閉じた式）。
       ★k の決め方は 2-2（m2-3）とまったく同じ★：$v_0=\sqrt{k\,gR}$。
         k = 1 … 円（第一宇宙速度）／k = 2 … 放物線（第二宇宙速度）
       地表 r = 1 で真横に打ち出すので（GM = R = 1 の単位で）
         L = r v = √k、　半直弦 p = L² = k、　離心率 ε = |k − 1|
       打ち出した点は k>1 なら近地点、k<1 なら遠地点。どちらも θ = 0 に置く。 */
    function orbit(k) {
      return { p: k, e: Math.abs(k - 1), sign: (k < 1 ? -1 : 1) };
    }
    function rOf(o, th) {
      var d = 1 + o.sign * o.e * Math.cos(th);
      return (d > 1e-3) ? o.p / d : Infinity;
    }
    /* その軌道を一周（または画面の外まで）描くための点の列 */
    function path(o, RMAX) {
      var pts = [], i, N = 420;
      var thMax = Math.PI;                       /* 閉じた軌道は 0〜2π、開いた軌道は漸近線まで */
      if (o.e >= 1 - 1e-9) {
        var ca = -1 / o.e;                       /* cos θ∞ = −1/ε */
        thMax = (ca <= -1) ? Math.PI * 0.995 : Math.acos(Math.max(-0.999, ca)) * 0.985;
      }
      for (i = -N; i <= N; i++) {
        var th = thMax * i / N;
        var r = rOf(o, th);
        if (!isFinite(r) || r > RMAX) continue;
        pts.push([r * Math.cos(th), r * Math.sin(th)]);
      }
      return pts;
    }
    /* 時刻 tt での位置（面積速度一定＝ケプラー第2法則を、角度の刻みで積み上げる。
       閉じた式の軌道の上を「等しい面積ずつ」進むので、数値積分はしていない） */
    var TSC = 1.9;                        /* アニメの1秒 ＝ 軌道の時間 1.9（円軌道1周 ≒ 3.3 秒） */
    function posAt(o, tt) {
      /* 面積速度 dA/dt = L/2 は一定（ケプラー第2法則）。だから dθ/dt = L / r²。
         これを細かい角度の刻みで積み上げる（軌道そのものは閉じた式のまま）。 */
      var th = 0, dt = 0.0025, u = 0, L = Math.sqrt(o.p);
      var N = Math.min(6000, Math.round(tt * TSC / dt));
      for (u = 0; u < N; u++) {
        var r = rOf(o, th);
        if (!isFinite(r) || r > 80) break;
        th += L / (r * r) * dt;
      }
      var rr = rOf(o, th);
      return { r: rr, th: th, x: rr * Math.cos(th), y: rr * Math.sin(th) };
    }
    function X(x) { return sc.cx + x * sc.R; }
    function Y(y) { return sc.cy - y * sc.R; }

    /* ===== 右上の読み出し（$v_0=\sqrt{k\,gR}$・軌道の名前・いま何番目か）=====
       ★canvas には描かない★（先生の指示・2026-10-03）
         canvas の fillText で「√」を書くと、根号の横線が中身の上にかからず
         $\sqrt{1.5\,gR}$ に見えない。式は HTML にして KaTeX に組ませる。
       ★KaTeX は重いので、k が変わったときだけ組みなおす★（毎コマ走らせない）。
       点（いま何番目か）は class の付けはずしだけ。 */
    var kbox = null, kboxK = null;
    function makeKbox() {
      var st2 = cv.parentNode;                       /* .stage（figure） */
      if (!st2) return null;
      var b = document.createElement('div');
      b.className = 'stageread';
      b.setAttribute('aria-hidden', 'true');         /* 同じことは figcaption の文が伝えている */
      b.innerHTML = '<span class="sr-e"></span><span class="sr-n"></span>' +
        '<span class="sr-d">' + KS.map(function () { return '<i></i>'; }).join('') + '</span>';
      st2.appendChild(b);
      return b;
    }
    function showK(k, fade) {
      if (!kbox) { kbox = makeKbox(); if (!kbox) return; }
      kbox.style.opacity = (fade < 1 ? Math.max(0, fade).toFixed(2) : '');
      if (kboxK === k) return;
      kboxK = k;
      var e = kbox.querySelector('.sr-e'), n = kbox.querySelector('.sr-n');
      var src = 'v_0=\\sqrt{' + k.toFixed(1) + '\\,gR}';
      if (window.katex) { try { window.katex.render(src, e, { throwOnError: false, displayMode: false }); } catch (x) { e.textContent = src; } }
      else e.textContent = src;
      n.textContent = KNAME[k]; n.style.color = KCOL[k];
      Array.prototype.forEach.call(kbox.querySelectorAll('.sr-d i'), function (d, i2) {
        d.className = (KS[i2] === k ? 'on' : '');
      });
    }

    function draw(tt, k, fade) {
      var s = sc.s, o = orbit(k), i;
      ctx.clearRect(0, 0, W, H);
      ctx.save(); ctx.globalAlpha = fade;
      /* 地球 */
      var R = sc.R;
      var g = ctx.createRadialGradient(X(0) - R * 0.35, Y(0) - R * 0.4, R * 0.1, X(0), Y(0), R);
      g.addColorStop(0, '#9fd0ff'); g.addColorStop(0.25, C.earth); g.addColorStop(1, '#16436f');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(X(0), Y(0), R, 0, 7); ctx.fill();
      ctx.save(); ctx.shadowColor = C.earth; ctx.shadowBlur = 26; ctx.globalAlpha = fade * 0.3;
      ctx.beginPath(); ctx.arc(X(0), Y(0), R, 0, 7); ctx.fill(); ctx.restore();
      ctx.fillStyle = 'rgba(243,239,230,.72)'; ctx.font = '700 ' + Math.round(10.5 * s) + 'px ' + JP;
      ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      ctx.fillText('地球', X(0), Y(0) + R + 5);
      /* これまでの軌道を薄く残す（4つを見くらべられるように） */
      var RMAX = Math.max(W, H) / sc.R;
      KS.forEach(function (kk) {
        if (kk === k) return;
        var oo = orbit(kk), pp = path(oo, RMAX);
        ctx.save(); ctx.globalAlpha = fade * 0.16; ctx.strokeStyle = KCOL[kk]; ctx.lineWidth = 1.2;
        ctx.beginPath();
        pp.forEach(function (q, j) { if (j === 0) ctx.moveTo(X(q[0]), Y(q[1])); else ctx.lineTo(X(q[0]), Y(q[1])); });
        ctx.stroke(); ctx.restore();
      });
      /* いまの軌道 */
      var pts = path(o, RMAX);
      ctx.save(); ctx.strokeStyle = KCOL[k]; ctx.lineWidth = 2.2; ctx.lineCap = 'round';
      if (k >= 2) ctx.setLineDash(k === 2 ? [7, 5] : [10, 4, 2, 4]);
      ctx.beginPath();
      pts.forEach(function (q, j) { if (j === 0) ctx.moveTo(X(q[0]), Y(q[1])); else ctx.lineTo(X(q[0]), Y(q[1])); });
      ctx.stroke(); ctx.restore();
      /* 人工衛星（閉じた式の上を、面積速度一定で進む） */
      var q2 = posAt(o, tt);
      if (isFinite(q2.r) && q2.r < RMAX * 1.2) {
        var px = X(q2.x), py = Y(q2.y);
        ctx.save(); ctx.fillStyle = C.T; ctx.shadowColor = KCOL[k]; ctx.shadowBlur = 14;
        ctx.beginPath(); ctx.arc(px, py, 4.4 * s, 0, 7); ctx.fill(); ctx.restore();
      }
      /* 打ち出す点と、速度の矢印（地表から真横） */
      (function () {
        var x0 = X(1), y0 = Y(0), L0 = Math.min(W * 0.16, 30 + k * 22) * s / 1.0;
        ctx.save(); ctx.strokeStyle = C.vel; ctx.fillStyle = C.vel; ctx.lineWidth = 2.6; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x0, y0 - L0 + 7); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(x0, y0 - L0); ctx.lineTo(x0 - 4.4, y0 - L0 + 9); ctx.lineTo(x0 + 4.4, y0 - L0 + 9);
        ctx.closePath(); ctx.fill();
        ctx.restore();
        ctx.save(); ctx.fillStyle = C.vel; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
        ctx.font = 'italic ' + Math.round(14 * s) + 'px ' + MATH;
        ctx.fillText('v', x0 + 7, y0 - L0 + 6);
        var wv = ctx.measureText('v').width;
        ctx.font = Math.round(10 * s) + 'px ' + SER; ctx.fillText('0', x0 + 7 + wv + 1, y0 - L0 + 10);
        ctx.restore();
      })();
      /* 右上：いまの速さと軌道の名前
         ★式は canvas に手で描かず、上にかぶせた HTML を KaTeX で組む★（先生の指示・2026-10-03）
           canvas の fillText では √ の横線が数式の上にかからず、きれいに出せないため。
           KaTeX は重いので、★k が変わったときだけ★組みなおす（showK の中で見ている）。 */
      showK(k, fade);
      /* 左上：見出し。
         ★せまい画面では出さない★——右上の $v_0$ の読み出しと重なるため（390px で実際に重なった）。 */
      if (W > 620) (function () {
        ctx.save(); ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
        ctx.fillStyle = C.dim; ctx.font = '700 ' + Math.max(11, Math.round(10.5 * s)) + 'px ' + JP;
        ctx.fillText('打ち出す速さで、軌道の形が変わる', 24, 30 * s + 6);
        if (W > 560) {
          var w0 = ctx.measureText('打ち出す速さで、軌道の形が変わる').width;
          ctx.font = 'italic ' + Math.round(10.5 * s) + 'px ' + SER;
          ctx.fillText('conic sections', 24 + w0 + 8, 30 * s + 6);
        }
        ctx.restore();
      })();
      ctx.restore();
    }

    var DUR = 3.4, FADE = 0.45;
    function frame(ts) {
      if (!run) return;
      var dtm = last ? Math.min(0.05, (ts - last) / 1000) : 0; last = ts;
      t += dtm * rate;
      var k = (lockK !== null ? lockK : KS[cyc % KS.length]);
      var fade = 1;
      if (t < FADE * 0.6) fade = t / (FADE * 0.6);
      else if (t > DUR - FADE) fade = Math.max(0, (DUR - t) / FADE);
      draw(t, k, fade);
      if (t >= DUR) { t = 0; cyc++; }
      raf = requestAnimationFrame(frame);
    }
    function start() { if (run || RM || paused) return; run = true; last = 0; raf = requestAnimationFrame(frame); }
    function stop() { run = false; cancelAnimationFrame(raf); }
    function still(k) {
      k = (k === undefined ? (lockK !== null ? lockK : 1.5) : k);
      draw(1.6, k, 1);
    }
    /* ★シムが動いていてもヒーローは止めない★（先生の指示・2026-10-03）
       前は「シムの再生中は止める」ことにしていたが、モード1（1-0）は開いた瞬間に
       動きだす（autoplay）ので、ページを開いた人にはヒーローが「ずっと止まっている」
       ように見えてしまった。止めるのは
         画面の外・タブが非表示・一時停止ボタン・「動きを減らす」設定
       の4つだけにする。ヒーローは画面のいちばん上なので、生徒がシムまで
       スクロールすればどのみち画面の外に出て止まる（重さは増えない）。 */
    /* ★止まっているときは「1枚の絵」を出す★（キットの決まり）
       このページはモード1が開いた瞬間に動きだす（autoplay）ので、
       はじめから止まっている。何も描かないと、ヒーローに黒い板が出るだけになる。 */
    setup(); still();
    /* 自動テストから決まった瞬間の絵を描かせる */
    window.__hero = { frame: function (tt, k) { stop(); draw(tt, k === undefined ? 1 : k, 1); }, start: start, stop: stop, still: still };

    var rz = 0;
    window.addEventListener('resize', function () {
      clearTimeout(rz); rz = setTimeout(function () { setup(); if (RM || paused) still(); }, 120);
    });
    /* 止める条件：画面外・タブが非表示・一時停止・動きを減らす設定 */
    var seen = true;
    function retune() {
      if (seen && !document.hidden && !paused) start();
      else { stop(); if (!document.hidden) still(); }
    }
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (es) {
        es.forEach(function (en) { seen = en.isIntersecting; });
        retune();
      }, { threshold: 0.05 }).observe(cv);
    } else start();
    document.addEventListener('visibilitychange', retune);
    /* ★「シムの再生を見張る 500ms のタイマー」と「#simhost を押したら止める」は
         やめた★（上の説明のとおり）。見張りをやめたぶん、1秒あたりの仕事も減る。 */

    /* 操作：速さをえらぶ（自動＝1 → 1.5 → 2 → 2.5）・スロー・一時停止 */
    var ctl = document.querySelector('#hero .stagectl');
    if (ctl) {
      var SLL = (typeof mathHtml === 'function') ? mathHtml('$v_0$') : 'v<sub>0</sub>';
      ctl.innerHTML = '<span class="sl-l">' + SLL + '</span>' +
        '<button type="button" data-k="auto" aria-pressed="true">自動</button>' +
        KS.map(function (k) { return '<button type="button" data-k="' + k + '" aria-pressed="false">' + k.toFixed(1) + '</button>'; }).join('') +
        '<span class="sep" aria-hidden="true"></span>' +
        '<button type="button" class="slow" aria-pressed="false" title="ゆっくり再生">🐢 スロー</button>' +
        '<button type="button" class="pp" aria-label="一時停止"><i></i></button>';
      if (typeof renderMath === 'function') renderMath(ctl);
      var kb = ctl.querySelectorAll('button[data-k]'), pp = ctl.querySelector('.pp'), sl = ctl.querySelector('.slow');
      if (sl) {
        if (RM) sl.hidden = true;
        sl.addEventListener('click', function () {
          rate = (rate === 1 ? 0.3 : 1); sl.setAttribute('aria-pressed', rate < 1 ? 'true' : 'false');
        });
      }
      Array.prototype.forEach.call(kb, function (b) {
        b.addEventListener('click', function () {
          var v = b.dataset.k; lockK = (v === 'auto' ? null : parseFloat(v));
          Array.prototype.forEach.call(kb, function (x) { x.setAttribute('aria-pressed', x === b ? 'true' : 'false'); });
          t = 0; if (lockK === null) cyc = 0;
          if (RM || paused) still();
        });
      });
      if (pp) {
        if (RM) pp.hidden = true;
        pp.addEventListener('click', function () {
          paused = !paused; pp.classList.toggle('paused', paused);
          pp.setAttribute('aria-label', paused ? '再生' : '一時停止');
          if (paused) { stop(); still(); } else { t = 0; retune(); }
        });
      }
    }
    var cap = document.getElementById('heroCap');
    if (cap) {
      cap.innerHTML = '地表から真横に $v_0=\\sqrt{k\\,gR}$ で打ち出す。$k$ を大きくすると、' +
        '軌道は<b>円 → だ円 → 放物線 → 双曲線</b>と変わる（$k=1$ 円軌道・$k=2$ 脱出）。2-2 と同じ $k$ です。';
      if (typeof mathHtml === 'function') { cap.innerHTML = mathHtml(cap.innerHTML); }
      if (typeof renderMath === 'function') renderMath(cap);
    }
  }

  /* ===== ヒーローの中身（パンくず・要点カード）とタブ列の左、フッター ===== */
  var EN = ["Kepler's Laws", 'Universal Gravitation &amp; Orbits', 'University Entrance Problems', 'Beyond High-School Physics'];
  var PAGE_EN = "Universal Gravitation &amp; Kepler's Laws";
  var PAGE_JA = '万有引力とケプラーの法則のシミュレーション';
  var ATOM = '<svg class="atom" viewBox="0 0 32 32" aria-hidden="true"><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#3ea0e0" stroke-width="2"/><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#7b5bd6" stroke-width="2" transform="rotate(60 16 16)"/><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#e07b18" stroke-width="2" transform="rotate(120 16 16)"/><circle cx="16" cy="16" r="3.6" fill="#5aa7ff"/></svg>';
  var HOMESVG = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3.5 10.8 12 4l8.5 6.8" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M6 9.5V20h4.5v-5.5h3V20H18V9.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>';
  var PAGESSVG = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="3.5" width="7" height="7" rx="1.6" fill="currentColor"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.6" fill="currentColor" opacity=".55"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.6" fill="currentColor" opacity=".55"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.6" fill="currentColor"/></svg>';

  /* 要点カード3枚（先生の選択）。日本語は LAW とタブの名前をそのまま使う */
  var IDEAS = [
    { id: 'm1-3', e: '\\dfrac{dS}{dt} = \\text{一定}', j: '第2法則（面積速度一定）' },
    { id: 'm1-4', e: '\\dfrac{T^2}{a^3} = K', j: '第3法則（周期と半長軸）' },
    /* ★「= 一定」まで書く★（先生の指示・2026-10-03）。保存の法則なので、
       式だけでなく「変わらない」ことが読めないと意味が伝わらない。 */
    { id: 'm2-2', e: 'E = \\dfrac{1}{2}mv^2 - G\\dfrac{mM}{r} = \\text{一定}', j: '力学的エネルギー保存の法則' }
  ];

  function buildHeroParts() {
    var cr = document.getElementById('crumbs');
    if (cr) {
      cr.innerHTML = '<a class="crumb-home" href="' + SITE_HOME + '" title="楽楽（らくらく）高校物理のトップページへ">' + ATOM +
        '<span>楽楽（らくらく）高校物理</span></a><span class="cs" aria-hidden="true">/</span>' +
        '<a class="crumb" href="' + SITE_HOME + '#sec-mechanics">力学</a><span class="cs" aria-hidden="true">/</span>' +
        '<span class="crumb now" aria-current="page">万有引力とケプラーの法則</span>' +
        '<span class="kdot"></span><span class="en">' + PAGE_EN + '</span>';
    }
    var ns = document.getElementById('navsite');
    if (ns) {
      ns.innerHTML = '<a class="navhome" href="' + SITE_HOME + '" aria-label="ホーム（楽楽高校物理のトップページ）" title="ホーム（楽楽高校物理のトップページ）">' + HOMESVG + '</a>' +
        '<button class="navpages" id="bPages" type="button" aria-haspopup="dialog" aria-expanded="false" aria-controls="siteDrawer">' + PAGESSVG + '<span>ページ一覧</span></button>';
    }
    var id = document.getElementById('ideas');
    if (id) {
      id.innerHTML = IDEAS.map(function (x, i) {
        return '<li><a href="#' + x.id + '" data-idea="' + x.id + '"><span class="in" aria-label="' + '①②③'.charAt(i) + '"><b>' + (i + 1) + '</b></span>' +
          '<span class="ie">$' + x.e + '$</span><span class="ij">' + x.j + '</span><span class="ia" aria-hidden="true">→</span></a></li>';
      }).join('');
      if (typeof mathHtml === 'function') id.innerHTML = mathHtml(id.innerHTML);
      if (typeof renderMath === 'function') renderMath(id);
      Array.prototype.forEach.call(id.querySelectorAll('[data-idea]'), function (a) {
        a.addEventListener('click', function (ev) {
          ev.preventDefault();
          if (typeof gotoSim === 'function') gotoSim(a.getAttribute('data-idea'));
          if (typeof scrollSimIntoView === 'function') {
            scrollSimIntoView(true);
            requestAnimationFrame(function () { requestAnimationFrame(function () { scrollSimIntoView(true); }); });
          }
        });
      });
    }
  }

  /* タブ列の下の読み進みの線 */
  function initProgress() {
    var nav = document.getElementById('tabbar'); if (!nav) return;
    var pend = false;
    var upd = function () {
      pend = false;
      var h = document.documentElement, max = h.scrollHeight - innerHeight;
      nav.style.setProperty('--prog', max > 0 ? Math.min(1, Math.max(0, scrollY / max)).toFixed(4) : 0);
    };
    window.addEventListener('scroll', function () { if (!pend) { pend = true; requestAnimationFrame(upd); } }, { passive: true });
    window.addEventListener('resize', upd); upd();
  }

  /* スライドバーの塗り（--p） */
  function syncRange(el) {
    var mn = parseFloat(el.min) || 0, mx = parseFloat(el.max), v = parseFloat(el.value);
    var p = (isFinite(mx) && mx > mn) ? (v - mn) / (mx - mn) * 100 : 0, s = p.toFixed(1) + '%';
    if (el._p !== s) { el._p = s; el.style.setProperty('--p', s); }
  }
  function initRanges() {
    document.addEventListener('input', function (ev) { if (ev.target && ev.target.type === 'range') syncRange(ev.target); }, true);
    var sweep = function () {
      if (document.hidden) return;
      Array.prototype.forEach.call(document.querySelectorAll('input[type=range]'), syncRange);
    };
    sweep(); setInterval(sweep, 150);
  }

  /* フッター（英字の題名・章の目次・ホーム・ページ一覧・上へ） */
  function initFooter() {
    var f = document.getElementById('pagefoot'); if (!f) return;
    var CI = '①②③④⑤⑥⑦⑧⑨';
    var items = (typeof MODES !== 'undefined' ? MODES : []).map(function (m, i) {
      return '<li><a href="#' + m.ids[0] + '" data-fmode="' + m.ids[0] + '"><b>' + CI[i] + '</b>' +
        String(m.label).replace(/^\d+\s*/, '') + '</a></li>';
    }).join('');
    f.innerHTML = '<div class="ft-in"><p class="ft-mark">' + PAGE_EN + '<span>' + PAGE_JA + '</span></p>' +
      '<ul class="ft-nav">' + items + '</ul>' +
      '<div class="ft-base"><span><a class="ft-home" href="' + SITE_HOME + '">⌂ 楽楽（らくらく）高校物理 トップページ</a>　／　高校物理 ・ 力学</span>' +
      '<span class="ft-r"><button type="button" class="ft-pages">ほかのページ一覧</button>' +
      '<a href="#top" class="ft-top">▲ ページの一番上へ</a></span></div></div>';
    Array.prototype.forEach.call(f.querySelectorAll('a[data-fmode]'), function (a) {
      a.addEventListener('click', function (ev) {
        ev.preventDefault();
        if (typeof gotoSim === 'function') gotoSim(a.getAttribute('data-fmode'));
        if (typeof scrollSimIntoView === 'function') scrollSimIntoView(true);
      });
    });
    var fp = f.querySelector('.ft-pages');
    if (fp) fp.addEventListener('click', function () { if (window.SITENAV) window.SITENAV.open(); });
    var tp = f.querySelector('.ft-top');
    if (tp) tp.addEventListener('click', function (ev) { ev.preventDefault(); window.scrollTo(0, 0); });
  }

  document.addEventListener('DOMContentLoaded', function () {
    buildHeroParts(); initFooter(); initStage(); initRanges(); initProgress();
  });
})();
