/* =========================================================================
   デザイン移植の動き（2026-10）
   見本＝momentum-and-collision.html の 85_design.js。
   このページ用に作りかえたのは initStage()（ヒーローのアニメ）だけで、
   作り方の約束（大きさは canvas から決める・ストロボの1枚絵・止める条件・
   window.__hero.frame で決まった瞬間を描かせる）は見本のまま。

   ★ヒーローのアニメ＝「ケプラーの3法則」を3つ横に並べる★（先生の指示・2026-10-11）
     前は「軌道の種類（円→楕円→放物線→双曲線）」だったが、
     このページの主役は 第1〜第3法則 なので、入口でその3つを見せる。
       ① 第1法則　楕円軌道（太陽は焦点のひとつ）
       ② 第2法則　同じ時間に通る面積は等しい（近いと速い・遠いとおそい）
       ③ 第3法則　遠い惑星ほど1周に時間がかかる（T² ∝ a³）
     ★閉じた式だけ★（数値積分はしない）。楕円はケプラー方程式
       E − ε sinE = M（K.ecc）から出す。3つめの円は等速円運動。
     ★3つの法則の名前と式は canvas ではなく HTML（.stagelaws）で出す★
       KaTeX で組めるし、canvas の文字より読みやすい。
       KaTeX は重いので ★1回だけ★ 組む（毎コマ組んではいけない）。
   ★暗い地なので、物理の色は「同じ色相の明るい版」を使う★（キット 1 章）。
     本文の図の色（COL.*）は1ミリも変えない。
   ========================================================================= */
(function () {
  'use strict';
  var RM = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var SER = '"KaTeX_Main","Times New Roman",serif',
      MATH = '"KaTeX_Math","KaTeX_Main",serif',
      JP = '"Hiragino Sans","Hiragino Kaku Gothic ProN","Yu Gothic",YuGothic,"Noto Sans JP",Meiryo,sans-serif';
  /* 暗い地での色（同じ色相の明るい版）。本文の図は COL.* のまま */
  var C = {
    sun:   '#f0b429',      /* 太陽 */
    ell:   '#49d18a',      /* 楕円・円の軌道  ← COL.bound #1c8f4a の明るい版 */
    ell2:  '#7fc0ff',      /* 外がわの軌道    ← COL.vel   #1663b5 の明るい版 */
    sect1: '#e8c96a',      /* 扇形（近日点がわ） */
    sect2: '#c48ce0',      /* 扇形（遠日点がわ） */
    T:     '#f6f2e9', dim: 'rgba(243,239,230,.42)', brand: '#e07b18'
  };

  /* 3つの法則の見出し（HTML で出す。$…$ は KaTeX で組む） */
  var LAWS = [
    { no: '第1法則', tx: '楕円軌道（太陽は焦点のひとつ）' },
    { no: '第2法則', tx: '$\\dfrac{dS}{dt}=$ 一定' },
    { no: '第3法則', tx: '$\\dfrac{T^2}{a^3}=K$' }
  ];

  /* ===== ヒーローのステージ ===== */
  function initStage() {
    var cv = document.getElementById('heroCv'); if (!cv) return;
    var ctx = cv.getContext('2d');
    var W = 0, H = 0, dpr = 1, run = false, raf = 0, last = 0;
    var t = 0, sc = null, paused = false, rate = 1;

    /* ===== 上にかぶせる見出し（HTML・KaTeX）=====
       ★1回だけ作る★。毎コマ KaTeX を走らせると、それだけでページがカクつく。 */
    function buildLaws() {
      var st2 = cv.parentNode; if (!st2) return;
      if (st2.querySelector('.stagelaws')) return;
      var b = document.createElement('div');
      b.className = 'stagelaws';
      b.setAttribute('aria-hidden', 'true');   /* 同じことは figcaption の文が伝えている */
      b.innerHTML = LAWS.map(function (L) {
        var tx = (typeof mathHtml === 'function') ? mathHtml(L.tx) : L.tx;
        return '<div><b>' + L.no + '</b><span>' + tx + '</span></div>';
      }).join('');
      st2.appendChild(b);
      if (typeof renderMath === 'function') renderMath(b);
    }

    function setup() {
      var r = cv.getBoundingClientRect();
      dpr = Math.min(2, window.devicePixelRatio || 1);
      W = Math.max(280, r.width); H = Math.max(160, r.height);
      cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var s = Math.max(W < 640 ? 0.86 : 0.72, Math.min(1.15, H / 260));
      /* ★上の見出し（HTML）の高さぶんを空ける★
         高さを決め打ちにすると、文字の大きさが変わったときに絵と重なる。
         実際の箱の高さを測ってから、絵を描く場所を決めること。 */
      var lw = cv.parentNode && cv.parentNode.querySelector('.stagelaws');
      var topH = lw ? Math.min(H * 0.42, lw.getBoundingClientRect().height + 6) : 46;
      var pw = W / 3, ph = H - topH;
      /* 楕円の半長軸［px］。よこは1枚ぶんの幅、たては残りの高さから決める。
         ★下の小さな見出し（「楕円」など）のぶんを残すこと★——
           0.52/0.40 にしたら、3枚目の円の下の文字が canvas の下で切れた。 */
      var R = Math.max(18, Math.min(pw * 0.36, ph * 0.37));
      sc = { s: s, pw: pw, R: R, cy: topH + ph * 0.47, topH: topH };
    }

    /* ===== 共通の小さな部品 ===== */
    function sun(x, y, r) {
      ctx.save();
      var g = ctx.createRadialGradient(x, y, r * 0.2, x, y, r * 2.1);
      g.addColorStop(0, 'rgba(255,214,102,.55)'); g.addColorStop(1, 'rgba(255,214,102,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r * 2.1, 0, 7); ctx.fill();
      ctx.fillStyle = C.sun; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill();
      ctx.restore();
    }
    function dot(x, y, r, col) {
      ctx.save(); ctx.fillStyle = col;
      ctx.shadowColor = col; ctx.shadowBlur = 10;
      ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill(); ctx.restore();
    }
    /* 楕円を描く（中心が (cx, cy)、半長軸 a・半短軸 b） */
    function ellipse(cx, cy, a, b, col, lw) {
      ctx.save(); ctx.strokeStyle = col; ctx.lineWidth = lw || 1.8;
      ctx.beginPath();
      for (var i = 0; i <= 160; i++) {
        var E = Math.PI * 2 * i / 160, px = cx + a * Math.cos(E), py = cy - b * Math.sin(E);
        if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
      }
      ctx.closePath(); ctx.stroke(); ctx.restore();
    }
    /* 時刻 tt（0〜1 が1周）での、楕円の上の位置。
       ★ケプラー方程式（閉じた式）で出す★ 数値積分はしない。
       返すのは「楕円の中心から見た」座標（画面の px）。 */
    function onEll(tt, a, b, e) {
      var E = K.ecc(Math.PI * 2 * (tt % 1), e);
      return { x: a * Math.cos(E), y: b * Math.sin(E), E: E };
    }
    /* 焦点（太陽）を頂点にした扇形をぬる。E1→E2 のあいだ */
    function sector(cx, cy, a, b, e, E1, E2, col, al) {
      var fx = cx + a * e;                                /* 焦点（近日点がわ）の画面 x */
      ctx.save(); ctx.globalAlpha = al; ctx.fillStyle = col;
      ctx.beginPath(); ctx.moveTo(fx, cy);
      var N = 40;
      for (var i = 0; i <= N; i++) {
        var E = E1 + (E2 - E1) * i / N;
        ctx.lineTo(cx + a * Math.cos(E), cy - b * Math.sin(E));
      }
      ctx.closePath(); ctx.fill(); ctx.restore();
    }
    /* 小さな見出し（絵の下） */
    function cap(x, y, txt, col) {
      ctx.save();
      ctx.fillStyle = col || C.dim;
      ctx.font = '700 ' + Math.max(9.5, Math.round(10 * sc.s)) + 'px ' + JP;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(txt, x, y);
      ctx.restore();
    }

    /* ===== ① 第1法則：楕円軌道（太陽は焦点のひとつ）===== */
    var E1C = 0.5;                        /* 見せる楕円の離心率 */
    function law1(cx, tt) {
      var a = sc.R, b = a * Math.sqrt(1 - E1C * E1C), cy = sc.cy;
      var fx = cx + a * E1C;                             /* 太陽のいる焦点 */
      ellipse(cx, cy, a, b, C.ell, 1.8);
      /* もう1つの焦点（小さな輪だけ） */
      ctx.save(); ctx.strokeStyle = C.dim; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.arc(cx - a * E1C, cy, 2.6, 0, 7); ctx.stroke(); ctx.restore();
      sun(fx, cy, Math.max(4.5, sc.R * 0.12));
      var q = onEll(tt, a, b, E1C);
      dot(cx + q.x, cy - q.y, Math.max(3, sc.R * 0.075), C.T);
      cap(cx, cy + sc.R + 15 * sc.s, '楕円', C.ell);
    }

    /* ===== ② 第2法則：同じ時間に通る面積は等しい ===== */
    var E2C = 0.6, FR = 1 / 7;            /* 扇形が1つぶんの時間（周期の何倍か） */
    function law2(cx, tt) {
      var a = sc.R, b = a * Math.sqrt(1 - E2C * E2C), cy = sc.cy;
      var fx = cx + a * E2C;
      /* 2つの扇形（同じ Δt＝同じ面積）。近日点のあたりと遠日点のあたり */
      var w = [
        { t0: -FR / 2, t1: FR / 2, col: C.sect1 },               /* 近日点のあたり */
        { t0: 0.5 - FR / 2, t1: 0.5 + FR / 2, col: C.sect2 }     /* 遠日点のあたり */
      ];
      var nowT = tt % 1;
      w.forEach(function (x) {
        var Ea = K.ecc(Math.PI * 2 * ((x.t0 + 1) % 1), E2C);
        var Eb = K.ecc(Math.PI * 2 * ((x.t1 + 1) % 1), E2C);
        if (Eb < Ea) Eb += Math.PI * 2;
        /* いま惑星がその扇形の中にいるときは、濃くぬる */
        var inside = (nowT >= (x.t0 + 1) % 1 || nowT <= x.t1) ;
        if (x.t0 > 0) inside = (nowT >= x.t0 && nowT <= x.t1);
        sector(cx, cy, a, b, E2C, Ea, Eb, x.col, inside ? 0.55 : 0.26);
      });
      ellipse(cx, cy, a, b, C.ell, 1.6);
      sun(fx, cy, Math.max(4.5, sc.R * 0.12));
      var q = onEll(tt, a, b, E2C);
      /* 太陽と惑星を結ぶ線（これが「通った面積」をつくる） */
      ctx.save(); ctx.strokeStyle = 'rgba(243,239,230,.5)'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(fx, cy); ctx.lineTo(cx + q.x, cy - q.y); ctx.stroke(); ctx.restore();
      dot(cx + q.x, cy - q.y, Math.max(3, sc.R * 0.075), C.T);
      cap(cx, cy + sc.R + 15 * sc.s, '面積速度が等しい', C.sect1);
    }

    /* ===== ③ 第3法則：遠い惑星ほど1周に時間がかかる ===== */
    var R3 = [0.52, 1.0];                 /* 2つの円の半径（半長軸の何倍か） */
    function law3(cx, tt) {
      var cy = sc.cy, i;
      sun(cx, cy, Math.max(4.5, sc.R * 0.12));
      for (i = 0; i < R3.length; i++) {
        var rr = sc.R * R3[i], col = (i === 0 ? C.ell : C.ell2);
        ctx.save(); ctx.strokeStyle = col; ctx.lineWidth = 1.5; ctx.globalAlpha = 0.75;
        ctx.beginPath(); ctx.arc(cx, cy, rr, 0, 7); ctx.stroke(); ctx.restore();
        /* ★T² ∝ a³ なので、周期は a^1.5 に比例する★（これが第3法則そのもの） */
        var Tn = Math.pow(R3[i], 1.5);
        var th = Math.PI * 2 * ((tt / Tn) % 1) - Math.PI / 2;
        dot(cx + rr * Math.cos(th), cy + rr * Math.sin(th), Math.max(2.8, sc.R * 0.07), col);
      }
      cap(cx, cy + sc.R + 15 * sc.s, '遠いほど おそい', C.ell2);
    }

    /* ===== 1枚ぶんを描く ===== */
    function draw(tt) {
      if (!sc) setup();
      ctx.clearRect(0, 0, W, H);
      /* 3枚のしきり（うすいたて線） */
      ctx.save(); ctx.strokeStyle = 'rgba(243,239,230,.09)'; ctx.lineWidth = 1;
      for (var i = 1; i < 3; i++) {
        ctx.beginPath();
        ctx.moveTo(Math.round(sc.pw * i) + 0.5, sc.topH - 4);
        ctx.lineTo(Math.round(sc.pw * i) + 0.5, H - 8);
        ctx.stroke();
      }
      ctx.restore();
      /* ★1周の時間★ 1・2 は同じ速さ、3 は内がわの円がそれより少しゆっくり */
      law1(sc.pw * 0.5, tt / 3.6);
      law2(sc.pw * 1.5, tt / 3.6);
      law3(sc.pw * 2.5, tt / 3.0);
    }

    function frame(ts) {
      if (!run) return;
      var dtm = last ? Math.min(0.05, (ts - last) / 1000) : 0; last = ts;
      t += dtm * rate;
      if (t > 1e4) t = 0;            /* 長く開きっぱなしでも数が暴れないように */
      draw(t);
      raf = requestAnimationFrame(frame);
    }
    function start() { if (run || RM || paused) return; run = true; last = 0; raf = requestAnimationFrame(frame); }
    function stop() { run = false; cancelAnimationFrame(raf); }
    /* ★止まっているときは「1枚の絵」を出す★（キットの決まり）
       何も描かないと、ヒーローに黒い板が出るだけになる。 */
    function still() { draw(1.1); }

    buildLaws(); setup(); still();
    /* 自動テストから決まった瞬間の絵を描かせる */
    window.__hero = { frame: function (tt) { stop(); draw(tt === undefined ? 1.1 : tt); }, start: start, stop: stop, still: still };

    var rz = 0;
    window.addEventListener('resize', function () {
      clearTimeout(rz); rz = setTimeout(function () { setup(); if (RM || paused) still(); }, 120);
    });
    /* 止める条件：画面外・タブが非表示・一時停止・動きを減らす設定
       ★シムが動いていてもヒーローは止めない★（先生の指示・2026-10-03）。
       ヒーローは画面のいちばん上なので、生徒がシムまでスクロールすれば
       どのみち画面の外に出て止まる（重さは増えない）。 */
    var seen = true;
    function retune() {
      if (seen && !document.hidden && !paused) start();
      else { stop(); if (!document.hidden) still(); }
    }
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (es) {
        es.forEach(function (en) { seen = en.isIntersecting; });
        retune();
      }, { threshold: 0.05 }).observe(cv);
    } else start();
    document.addEventListener('visibilitychange', retune);

    /* 操作：スローと一時停止だけ（★「速さをえらぶ」のボタンは消した★——
       見せるものが「軌道の種類」から「3つの法則」に変わり、えらぶものが無くなったため） */
    var ctl = document.querySelector('#hero .stagectl');
    if (ctl) {
      ctl.innerHTML = '<span class="sl-l">ケプラーの3法則</span>' +
        '<button type="button" class="slow" aria-pressed="false" title="ゆっくり再生">🐢 スロー</button>' +
        '<button type="button" class="pp" aria-label="一時停止"><i></i></button>';
      var pp = ctl.querySelector('.pp'), sl = ctl.querySelector('.slow');
      if (sl) {
        if (RM) sl.hidden = true;
        sl.addEventListener('click', function () {
          rate = (rate === 1 ? 0.3 : 1); sl.setAttribute('aria-pressed', rate < 1 ? 'true' : 'false');
        });
      }
      if (pp) {
        if (RM) pp.hidden = true;
        pp.addEventListener('click', function () {
          paused = !paused; pp.classList.toggle('paused', paused);
          pp.setAttribute('aria-label', paused ? '再生' : '一時停止');
          if (paused) { stop(); still(); } else { retune(); }
        });
      }
    }
    var capEl = document.getElementById('heroCap');
    if (capEl) {
      capEl.innerHTML = 'ケプラーの3法則は ' +
        '<b>①</b> 惑星は太陽を焦点のひとつとする<b>楕円</b>を描く。' +
        '<b>②</b> 同じ時間に通る<b>面積は等しい</b>（近いと速い）。' +
        '<b>③</b> <b>遠い惑星ほど1周が長い</b>。詳しくは 1-1〜1-3。';
      if (typeof mathHtml === 'function') { capEl.innerHTML = mathHtml(capEl.innerHTML); }
      if (typeof renderMath === 'function') renderMath(capEl);
    }
  }

  /* ===== ヒーローの中身（パンくず・要点カード）とタブ列の左、フッター ===== */
  var EN = ["Kepler's Laws", 'Universal Gravitation &amp; Orbits', 'University Entrance Problems', 'Beyond High-School Physics'];
  var PAGE_EN = "Universal Gravitation &amp; Kepler's Laws";
  var PAGE_JA = '万有引力・ケプラーの法則と天体物理学';
  var ATOM = '<svg class="atom" viewBox="0 0 32 32" aria-hidden="true"><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#3ea0e0" stroke-width="2"/><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#7b5bd6" stroke-width="2" transform="rotate(60 16 16)"/><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#e07b18" stroke-width="2" transform="rotate(120 16 16)"/><circle cx="16" cy="16" r="3.6" fill="#5aa7ff"/></svg>';
  var HOMESVG = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3.5 10.8 12 4l8.5 6.8" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M6 9.5V20h4.5v-5.5h3V20H18V9.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>';
  var PAGESSVG = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="3.5" width="7" height="7" rx="1.6" fill="currentColor"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.6" fill="currentColor" opacity=".55"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.6" fill="currentColor" opacity=".55"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.6" fill="currentColor"/></svg>';

  /* 要点カード3枚（先生の選択）。日本語は LAW とタブの名前をそのまま使う */
  var IDEAS = [
    { id: 'm1-3', e: '\\dfrac{dS}{dt} = \\text{一定}', j: '第2法則（面積速度一定）' },
    { id: 'm1-4', e: '\\dfrac{T^2}{a^3} = K', j: '第3法則（周期と半長軸）' },
    /* ★「= 一定」まで書く★（先生の指示・2026-10-03）。保存の法則なので、
       式だけでなく「変わらない」ことが読めないと意味が伝わらない。 */
    { id: 'm2-2', e: 'E = \\dfrac{1}{2}mv^2 - G\\dfrac{mM}{r} = \\text{一定}', j: '力学的エネルギー保存の法則' }
  ];

  function buildHeroParts() {
    var cr = document.getElementById('crumbs');
    if (cr) {
      cr.innerHTML = '<a class="crumb-home" href="' + SITE_HOME + '" title="楽楽（らくらく）高校物理のトップページへ">' + ATOM +
        '<span>楽楽（らくらく）高校物理</span></a><span class="cs" aria-hidden="true">/</span>' +
        '<a class="crumb" href="' + SITE_HOME + '#sec-mechanics">力学</a><span class="cs" aria-hidden="true">/</span>' +
        '<span class="crumb now" aria-current="page">万有引力とケプラーの法則</span>' +
        '<span class="kdot"></span><span class="en">' + PAGE_EN + '</span>';
    }
    var ns = document.getElementById('navsite');
    if (ns) {
      ns.innerHTML = '<a class="navhome" href="' + SITE_HOME + '" aria-label="ホーム（楽楽高校物理のトップページ）" title="ホーム（楽楽高校物理のトップページ）">' + HOMESVG + '</a>' +
        '<button class="navpages" id="bPages" type="button" aria-haspopup="dialog" aria-expanded="false" aria-controls="siteDrawer">' + PAGESSVG + '<span>ページ一覧</span></button>';
    }
    var id = document.getElementById('ideas');
    if (id) {
      id.innerHTML = IDEAS.map(function (x, i) {
        return '<li><a href="#' + x.id + '" data-idea="' + x.id + '"><span class="in" aria-label="' + '①②③'.charAt(i) + '"><b>' + (i + 1) + '</b></span>' +
          '<span class="ie">$' + x.e + '$</span><span class="ij">' + x.j + '</span><span class="ia" aria-hidden="true">→</span></a></li>';
      }).join('');
      if (typeof mathHtml === 'function') id.innerHTML = mathHtml(id.innerHTML);
      if (typeof renderMath === 'function') renderMath(id);
      Array.prototype.forEach.call(id.querySelectorAll('[data-idea]'), function (a) {
        a.addEventListener('click', function (ev) {
          ev.preventDefault();
          if (typeof gotoSim === 'function') gotoSim(a.getAttribute('data-idea'));
          if (typeof scrollSimIntoView === 'function') {
            scrollSimIntoView(true);
            requestAnimationFrame(function () { requestAnimationFrame(function () { scrollSimIntoView(true); }); });
          }
        });
      });
    }
  }

  /* タブ列の下の読み進みの線 */
  function initProgress() {
    var nav = document.getElementById('tabbar'); if (!nav) return;
    var pend = false;
    var upd = function () {
      pend = false;
      var h = document.documentElement, max = h.scrollHeight - innerHeight;
      nav.style.setProperty('--prog', max > 0 ? Math.min(1, Math.max(0, scrollY / max)).toFixed(4) : 0);
    };
    window.addEventListener('scroll', function () { if (!pend) { pend = true; requestAnimationFrame(upd); } }, { passive: true });
    window.addEventListener('resize', upd); upd();
  }

  /* スライドバーの塗り（--p） */
  function syncRange(el) {
    var mn = parseFloat(el.min) || 0, mx = parseFloat(el.max), v = parseFloat(el.value);
    var p = (isFinite(mx) && mx > mn) ? (v - mn) / (mx - mn) * 100 : 0, s = p.toFixed(1) + '%';
    if (el._p !== s) { el._p = s; el.style.setProperty('--p', s); }
  }
  function initRanges() {
    document.addEventListener('input', function (ev) { if (ev.target && ev.target.type === 'range') syncRange(ev.target); }, true);
    var sweep = function () {
      if (document.hidden) return;
      Array.prototype.forEach.call(document.querySelectorAll('input[type=range]'), syncRange);
    };
    sweep(); setInterval(sweep, 150);
  }

  /* フッター（英字の題名・章の目次・ホーム・ページ一覧・上へ） */
  function initFooter() {
    var f = document.getElementById('pagefoot'); if (!f) return;
    var CI = '①②③④⑤⑥⑦⑧⑨';
    var items = (typeof MODES !== 'undefined' ? MODES : []).map(function (m, i) {
      return '<li><a href="#' + m.ids[0] + '" data-fmode="' + m.ids[0] + '"><b>' + CI[i] + '</b>' +
        String(m.label).replace(/^\d+\s*/, '') + '</a></li>';
    }).join('');
    f.innerHTML = '<div class="ft-in"><p class="ft-mark">' + PAGE_EN + '<span>' + PAGE_JA + '</span></p>' +
      '<ul class="ft-nav">' + items + '</ul>' +
      '<div class="ft-base"><span><a class="ft-home" href="' + SITE_HOME + '">⌂ 楽楽（らくらく）高校物理 トップページ</a>　／　高校物理 ・ 力学</span>' +
      '<span class="ft-r"><button type="button" class="ft-pages">ほかのページ一覧</button>' +
      '<a href="#top" class="ft-top">▲ ページの一番上へ</a></span></div></div>';
    Array.prototype.forEach.call(f.querySelectorAll('a[data-fmode]'), function (a) {
      a.addEventListener('click', function (ev) {
        ev.preventDefault();
        if (typeof gotoSim === 'function') gotoSim(a.getAttribute('data-fmode'));
        if (typeof scrollSimIntoView === 'function') scrollSimIntoView(true);
      });
    });
    var fp = f.querySelector('.ft-pages');
    if (fp) fp.addEventListener('click', function () { if (window.SITENAV) window.SITENAV.open(); });
    var tp = f.querySelector('.ft-top');
    if (tp) tp.addEventListener('click', function (ev) { ev.preventDefault(); window.scrollTo(0, 0); });
  }

  document.addEventListener('DOMContentLoaded', function () {
    buildHeroParts(); initFooter(); initStage(); initRanges(); initProgress();
  });
})();
