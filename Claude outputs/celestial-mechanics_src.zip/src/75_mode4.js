/* 4　もっと深く知りたい人へ
   受験には出ないが、知るとおもしろい話。読み物とかんたんなアニメーション。 */
'use strict';

/* ============================================================
   4-1　角運動量とフィギュアスケーター（中の id は m4-2 のまま）
   ============================================================ */
function m42Om(v) { return P.m42.omega(v.arm, 0.85, 2.2); }

/* ===== 横から見たフィギュアスケーター =====
   ★「真上から見た図」だけでは、生徒はスピンだと分からない★（先生の指摘）
   体・スカート・スケート靴は、いただいたイラスト（assets/skater_side.jpg）を使う。
   ★イラストは「腕を消した状態」で切り出してある★ので、腕だけを canvas で描き足す。
   横から見ると腕の先が描く円は「1本の横線」に見え、
   腕の見かけの長さは cos(θ) で伸び縮みする。これで回転しているように見せる。
   イラストの大きさ：87 × 300 px。肩の位置は 左 x=0.195・右 x=0.805、y=0.244（比）。
   身長は 1.6 m とみなすので、絵の高さ Hs = 1.6 × SC にすれば腕の長さと縮尺が合う。
   cx…回転軸、gy…氷の高さ、arm…腕の長さ[m]、th…回転角[rad]、SC…1 m あたりの px */
var SKATER = {
  w: 87, h: 300, shx: 0.305, shy: 0.252, tall: 1.6,
  /* 頭の絵（assets/skater_head.jpg）が、体の絵の中で占める場所（比）。
     体の絵からは頭を白でけしてあるので、頭はここへ重ねて描く。 */
  hx0: 0.15625, hx1: 0.8125, hy0: 0.0, hy1: 0.16667
};

/* ===== 回る頭 =====
   1枚の絵しかないので、つぎの決まりで「回って見える」ようにする。
     ・体の向き（正面を向いている度合い）を f = cos(th) とする。
       th = 0 のとき、腕が画面いっぱいに広がり、顔はこちらを向いている。
     ・横幅を 0.35 + 0.65|f| 倍に縮める（真横を向くと細く見える＝横顔）。
     ・顔の向く左右は −sin(th) の符号。もとの絵は右を向いているので、
       −sin(th) < 0 のときだけ左右を反転する。
     ・f < 0（後ろを向いている）ときは、絵ではなく「金髪の後頭部＋おだんご」を描く。 */
function drawSkaterHead(ctx, cx, gy, Hs, Ws, th) {
  var f = Math.cos(th), turn = -Math.sin(th);
  var hw = (SKATER.hx1 - SKATER.hx0) * Ws;              /* 正面のときの頭の幅 */
  var hh = (SKATER.hy1 - SKATER.hy0) * Hs;
  var hcx = cx - Ws / 2 + (SKATER.hx0 + SKATER.hx1) / 2 * Ws;
  var hcy = gy - Hs + (SKATER.hy0 + SKATER.hy1) / 2 * Hs;
  var sx = 0.55 + 0.45 * Math.abs(f);   /* ★体（drawSkaterSide の bsx）と同じ式にそろえる★ */
  var mir = (turn < 0 ? -1 : 1);
  /* ★体ごと回すので、頭の位置も体と同じように「cx を中心に」つぶす★
     こうしないと、体が細くなったときに頭だけ横へずれてしまう。 */
  hcx = cx + (hcx - cx) * sx * mir;
  ctx.save();
  ctx.translate(hcx, hcy);
  ctx.scale(sx * mir, 1);
  if (f >= 0) {
    var img = canvasImg('skater_head');
    if (img) ctx.drawImage(img, -hw / 2, -hh / 2, hw, hh);
  } else {
    /* 後頭部：金髪の丸と、うしろのおだんご */
    ctx.fillStyle = '#f0e2b4'; ctx.strokeStyle = '#9a8a5e'; ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.ellipse(0, hh * 0.12, hw * 0.30, hh * 0.33, 0, 0, TAU);
    ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.ellipse(0, -hh * 0.24, hw * 0.16, hh * 0.15, 0, 0, TAU);
    ctx.fill(); ctx.stroke();
    /* えり足（首すじ） */
    ctx.strokeStyle = '#c39b78'; ctx.lineWidth = 4; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(0, hh * 0.40); ctx.lineTo(0, hh * 0.50); ctx.stroke();
  }
  ctx.restore();
}

/* ===== 真上から見た体（回る）=====
   肩は腕の向き（th）にそった細長いだ円、顔の向きはそれと垂直（th + 90°）。
   小さな鼻の三角で「どちらを向いているか」を出す。 */
function drawSkaterTop(ctx, cx, cy, th) {
  /* ★画面の y は下向きなので、反時計まわりに見せるには角を反転する★ */
  var fx = -Math.sin(th), fy = -Math.cos(th);         /* 顔の向き（腕と垂直） */
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(-th);
  /* 肩（腕にそった細長いだ円） */
  ctx.fillStyle = '#e7edf3'; ctx.strokeStyle = COL.sub; ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.ellipse(0, 0, 17, 10, 0, 0, TAU); ctx.fill(); ctx.stroke();
  ctx.restore();
  /* 頭（金髪の丸）＋おだんご（顔と反対がわ）＋鼻（顔の向き） */
  ctx.save();
  ctx.fillStyle = '#f0e2b4'; ctx.strokeStyle = '#9a8a5e'; ctx.lineWidth = 1.3;
  ctx.beginPath(); ctx.arc(cx, cy, 8.4, 0, TAU); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.arc(cx - fx * 8.6, cy - fy * 8.6, 3.4, 0, TAU); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#c98f6a';
  ctx.beginPath();
  ctx.moveTo(cx + fx * 10.5, cy + fy * 10.5);
  ctx.lineTo(cx + fx * 6 - fy * 3.2, cy + fy * 6 + fx * 3.2);
  ctx.lineTo(cx + fx * 6 + fy * 3.2, cy + fy * 6 - fx * 3.2);
  ctx.closePath(); ctx.fill();
  ctx.restore();
}

function drawSkaterSide(ctx, cx, gy, arm, th, SC, showV, w) {
  var Hs = SKATER.tall * SC, Ws = Hs * SKATER.w / SKATER.h;
  var shy = gy - Hs + SKATER.shy * Hs;               /* 肩の高さ */
  /* ★体ごと回す★（顔だけ回っていたのを直した・先生の指摘）
     絵は1枚しかないので、頭と同じ決まりで体も横につぶす／左右を反転する。
       ・bsx = 0.35 + 0.65|cos θ| … 真横を向くと細く見える
       ・bmir = −sin θ の符号     … 向きが変わったら左右を反転
     肩はばも同じだけ細くなるので、腕の付け根 shHalf にも bsx をかける。 */
  var bsx = 0.55 + 0.45 * Math.abs(Math.cos(th));   /* 体は 0.55 より細くしない（細すぎると人に見えない） */
  var bmir = (-Math.sin(th) < 0) ? -1 : 1;
  var shHalf = SKATER.shx * Ws * bsx;                /* 中心から肩までの幅 */
  var tuck = arm < 0.55;
  var ink = '#8d8d8d';

  /* 氷 */
  ctx.save();
  ctx.fillStyle = '#f2f7fb';
  ctx.fillRect(cx - 126, gy, 252, 9);
  ctx.strokeStyle = '#9fb6c8'; ctx.lineWidth = 1.4;
  ctx.beginPath(); ctx.moveTo(cx - 126, gy); ctx.lineTo(cx + 126, gy); ctx.stroke();
  ctx.restore();

  /* 回転軸（文字は入れない。【2】の見出しとぶつかるため） */
  dashLine(ctx, cx, gy - Hs - 20, cx, gy + 7, COL.dim, [5, 4], 1);

  /* 腕の先が描く円を「真横から」見たもの＝横の1本線 */
  ctx.save();
  ctx.strokeStyle = fade(COL.vel, 0.4); ctx.lineWidth = 1.2; ctx.setLineDash([4, 4]);
  ctx.beginPath();
  ctx.moveTo(cx - arm * SC, shy); ctx.lineTo(cx + arm * SC, shy); ctx.stroke();
  ctx.restore();

  /* d…奥ゆき（＋が手前）、vx…画面の中での見かけの速さ（左右の成分だけが見える） */
  var hands = [
    { x: cx + arm * SC * Math.cos(th), d: Math.sin(th), vx: -arm * w * Math.sin(th) },
    { x: cx - arm * SC * Math.cos(th), d: -Math.sin(th), vx: arm * w * Math.sin(th) }
  ];
  if (hands[0].d > hands[1].d) { var tmp = hands[0]; hands[0] = hands[1]; hands[1] = tmp; }

  /* 腕は「灰色の太い線＋白い細い線」で、イラストの線画と同じ見え方にする */
  function drawArm(h, front) {
    var sgn = (h.x >= cx) ? 1 : -1;
    var sx = cx + sgn * shHalf;
    var far = Math.abs(h.x - cx) > shHalf + 1.5;
    ctx.save();
    ctx.globalAlpha = front ? 1 : 0.5;
    if (far) {
      ctx.lineCap = 'round';
      ctx.strokeStyle = ink; ctx.lineWidth = 7;
      ctx.beginPath(); ctx.moveTo(sx, shy); ctx.lineTo(h.x, shy); ctx.stroke();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 4.2;
      ctx.beginPath(); ctx.moveTo(sx, shy); ctx.lineTo(h.x, shy); ctx.stroke();
    }
    /* 手（腕が体にかくれる長さのときは、体のふちに出す） */
    var hx = far ? h.x : cx + sgn * (shHalf + 1);
    ctx.fillStyle = '#fff'; ctx.strokeStyle = ink; ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.ellipse(hx, shy, front ? 5.6 : 4.8, front ? 4.4 : 3.8, 0, 0, TAU);
    ctx.fill(); ctx.stroke();
    ctx.restore();
  }

  drawArm(hands[0], false);
  /* 体（いただいたイラスト） */
  var img = canvasImg('skater_side');
  if (img) {
    ctx.save();
    ctx.translate(cx, 0); ctx.scale(bsx * bmir, 1); ctx.translate(-cx, 0);
    ctx.drawImage(img, cx - Ws / 2, gy - Hs, Ws, Hs);
    ctx.restore();
  } else {
    /* 絵がまだ読めていないときの代わり（棒人間） */
    ctx.save();
    ctx.strokeStyle = ink; ctx.lineWidth = 10; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(cx, shy); ctx.lineTo(cx, gy - 6); ctx.stroke();
    ctx.restore();
  }
  /* ★頭は別に描く★（体の絵からは頭を白でけしてある）
     こうすると、顔だけを回転しているように見せられる。 */
  drawSkaterHead(ctx, cx, gy, Hs, Ws, th);
  drawArm(hands[1], true);

  /* ★角運動量ベクトル L★ 回転軸にそって上向き（右ねじの向き）。
     まわる向きの ω の矢印が、この L をとりまくように描いてあるのは、
     「右手の指を回る向き、親指が L の向き」を絵で見せるため。 */
  (function () {
    var y1 = gy - Hs + 2, y2 = gy - Hs - 44;
    ctx.save();
    ctx.strokeStyle = COL.angm; ctx.lineWidth = 2.6; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(cx, y1); ctx.lineTo(cx, y2 + 8); ctx.stroke();
    ctx.restore();
    arrowHead(ctx, cx, y2, 0, -1, COL.angm);
    label(ctx, 'L（一定）', cx + 40, y2 + 6,
      { size: 11, bold: true, color: COL.angm, align: 'left' });
  })();

  /* まわる向きの矢印（頭の上） */
  (function () {
    var ay = gy - Hs - 14, aw = 22;
    ctx.save();
    ctx.strokeStyle = COL.vel; ctx.lineWidth = 1.8;
    ctx.beginPath(); ctx.ellipse(cx, ay, aw, 6, 0, Math.PI * 0.15, Math.PI * 1.85); ctx.stroke();
    ctx.restore();
    arrowHead(ctx, cx + aw * Math.cos(Math.PI * 0.15), ay + 6 * Math.sin(Math.PI * 0.15),
      0.35, 0.94, COL.vel);
    label(ctx, 'ω', cx + aw + 12, ay, { size: 11.5, bold: true, color: COL.vel });
  })();

  if (showV) {
    var h = hands[1];
    var vsc = 40 / Math.max(1e-9, 0.25 * P.m42.omega(0.25, 0.85, 2.2));
    if (Math.abs(h.vx) * vsc > 6) velArrow(ctx, h.x, shy, h.vx, 0, vsc, null);
  }

  /* 寸法 r（腕をいっぱいに広げたときの長さ） */
  var hx2 = cx + arm * SC;
  dashLine(ctx, cx, shy + 26, hx2, shy + 26, COL.dim, [4, 4], 1);
  dashLine(ctx, hx2, shy, hx2, shy + 30, COL.dim, [3, 3], 1);
  label(ctx, 'r = ' + fmt(arm, 2) + ' m', (cx + hx2) / 2, shy + 38,
    { size: 10.5, color: COL.dim, bold: true });
  label(ctx, tuck ? '引きつけた形（速く回る）' : '大きく広げた形（ゆっくり回る）',
    cx, gy + 20, { size: 10.5, bold: true, color: tuck ? COL.vel : COL.sub });
}

/* ===== スケーターの向き（位相）をためる =====
   ★「ω × t」で角度を出すと、腕を変えた瞬間に角度が飛ぶ★
     ω が 2.2 → 11 に変わると、同じ t でも角度が5倍になってしまうため。
   そこで「1コマ進むあいだに ω × Δt だけ足す」という出し方にする。
   こうすると、腕を縮めても向きは変わらず、速さだけがその場で変わる（本物のスピンと同じ）。
   t が戻ったとき（↺リセット、ループの折り返し、時間バーを左へ動かしたとき）は
   角度も 0 に戻して、絵と時計をそろえる。 */
function m42Phase(s, t, w) {
  if (s._phT === undefined || t < s._phT - 1e-9) { s._phT = t; s._ph = w * t; }
  else { s._ph = (s._ph || 0) + w * (t - s._phT); s._phT = t; }
  return s._ph;
}

DEFS['m4-2'] = {
  /* ★このシムだけモード2（万有引力とエネルギー）に置いてある★（先生の指示）
     「2-3 人工衛星の周期・静止衛星」のうしろの補足として読ませたいため。
     ファイルは 75_mode4.js のままだが、mode は 2、並びは MODES[1].ids で決まる。 */
  id: 'm4-2', mode: 2, tab: '補足：なぜ面積速度が一定なのか', read: true,
  legendKeys: ['vel', 'dim', 'force', 'angm'],
  title: '補足：なぜ面積速度が一定なのか（ケプラーⅡの背景）　～角運動量の保存～',
  sub: 'フィギュアスケートのスピンでは、<b>腕を伸ばすとゆっくり、縮めると速く</b>回ります。' +
    'じつはこれ、<b>惑星が「遠いと遅く、近いと速い」（ケプラーの第2法則）のと、まったく同じ現象</b>です。<br>' +
    'スライドバーで腕の長さ $r$ を変えて、$\\omega$ がどれだけ変わるか見てください。' +
    'その理由（<b>角運動量保存則</b>）を、解説で①〜⑨の順に見ていきます。<br>' +
    '※ 再生の速さは腕の長さによらず同じにしてあるので、' +
    '<b>画面で見える回転の速さが、そのまま $\\omega$</b> です' +
    '（0.85 m → 0.25 m で約 11 倍）。',
  note: '<b>中心力しかはたらかない　→　力のモーメントが 0　→　角運動量 $L$ が一定　→　面積速度が一定</b>',
  sideText:
    '<span class="q">【物理ミニコラム】なぜ「面積速度一定」なのか　—　角運動量保存則</span>' +

    '<div class="colh">① ケプラーの第2法則は「遠いと遅い・近いと速い」</div>' +
    '面積速度一定の法則は、かんたんに言えば' +
    '<b>太陽から遠いところではゆっくり、近いところでは速く動く</b>、という法則です' +
    '（→ <a href="#m1-3" data-goto="m1-3">1-2 第2法則</a>）。' +

    '<div class="colh">② 同じことが、スピンでも起きている</div>' +
    'フィギュアスケートのスピンも、<b>腕を伸ばすとゆっくり、縮めると速く</b>回ります。' +
    '図で確かめてください。' +

    '<div class="colh">③ この2つの背景には、同じ1つの法則がある</div>' +
    'それが<b>角運動量保存則</b>——「回転の勢い $L$ が変わらない」という法則です。' +

    '<div class="colh">④ 角運動量を変形すると、面積速度になる</div>' +
    '角運動量は $L = mrv_\\perp$（$v_\\perp$ は動径に垂直な速度）。いっぽう面積速度は<br>' +
    '$\\dfrac{dS}{dt}=\\dfrac{1}{2}rv_\\perp=\\dfrac{L}{2m}$<br>' +
    '質量 $m$ は変わらないので、<b>$L$ が一定 ⟺ 面積速度が一定</b>。<br>' +
    '<b>つまりケプラーの第2法則は、角運動量保存則を書きかえたものにすぎません。</b>' +

    '<div class="colh">⑤ 角運動量は、何があると変わるのか（大学1年の内容）</div>' +
    '角運動量 $L$ は、<b>力のモーメント $N$</b> がはたらくときだけ増えたり減ったりします。<br>' +
    '<span class="eqsame">$\\dfrac{dL}{dt}=N$　（回転の運動方程式）</span><br>' +
    '<span class="mini">大学では「角運動量の原理」、'
    + 'かたまり（剛体）の回転では「オイラーの運動方程式」として習います。</span><br>' +
    '運動方程式 $ma=F$ すなわち ' +
    '<span class="eqsame">$\\dfrac{dp}{dt}=F$（運動方程式）</span>' +
    'と、似ています（$p$ は運動量、つまり運動の勢い）。' +
    '<b>角運動量 ⇔ 運動量</b>、<b>力のモーメント ⇔ 力</b> が対応しています。' +
    '運動方程式から回転の運動方程式を導けますので、ぜひ調べてみてください。<br>' +
    'だから<b>$N=0$ なら $L$ は変わらない</b>——これが角運動量保存則。' +

    '<div class="colh">⑥ 惑星もスケーターも、モーメントが 0</div>' +
    '<ul class="colul">' +
    '<li><b>惑星</b>：万有引力は<b>いつも太陽を向いている（中心力）</b>。' +
    '力が中心を向いていれば、中心まわりのモーメントは 0。</li>' +
    '<li><b>スケーター</b>：腕を<b>回転軸に向かって引くだけ</b>。' +
    'これも軸を向いた力なので、軸まわりのモーメントは 0。</li>' +
    '</ul>' +
    'だから、どちらも角運動量が保存します。' +

    '<div class="colh">⑦ まとめ</div>' +
    '<b>中心力だけ　→　$N=0$　→　$L$ 一定　→　面積速度一定</b><br>' +
    'この道すじを覚えておけば、「面積速度一定」は惑星だけの特別な法則ではないと分かります。' +

    '<hr class="colhr">' +
    '<div class="colh">⑧ 入試ではこう出る　—　ブランコの問題</div>' +
    '近年の東京大学の入試問題に、<b>ブランコをこぎながら立ち上がる</b>運動で、' +
    'とつぜん「面積速度一定の法則が成り立つ」と書かれたものがあります。' +
    '知らないと「なぜ惑星と同じ法則が出てくるの？」と思ってしまうでしょう。<br>' +
    'でも⑦を知っていれば、<b>「立ち上がる瞬間、ひもの張力も自分が体を引き上げる力も、' +
    'どちらも支点を向いている。だから中心力だけ ＝ モーメント 0 ＝ 角運動量が保存し、' +
    '面積速度一定になるのだな」</b>と読めます。' +

    '<div class="colh">⑨ 難関大では、ここまで必要</div>' +
    '角運動量保存則を知っている前提の問題は、難関大でしばしば出ます。' +
    '高校の教科書には出てきませんが、<b>「中心力 → 角運動量保存 → 面積速度一定」</b>' +
    'の道すじだけでも、ぜひ理解しておいてください。<br>' +
    'もっと知りたい人は、大学1年の力学の教科書の<b>「角運動量」「中心力」</b>の章を読んでみよう。' +
    'このページの中では、<a href="#m1-3" data-goto="m1-3">1-2 第2法則</a>と' +
    '<a href="#m3-1" data-goto="m3-1">3-1 等速円運動から楕円軌道への遷移</a>で、' +
    '面積速度一定を実際に使っています。',
  cw: 560, ch: 560,
  noOpenRow: true,
  loop: true,
  vis: ['V'],
  visLabel: { V: '速度を表示' },
  visDef: { V: true },
  vars: [
    {
      k: 'arm', label: '腕の長さ $r$', unit: ' m',
      min: 0.25, max: 0.85, step: 0.05, dec: 2, def: 0.85,
      /* ★keepT★ 腕を変えても時間 t を 0 に戻さない（先生の指示）。
         戻すと、右の惑星のアニメーションまで最初の位置にジャンプしてしまう。
         腕の長さと惑星は何の関係もないので、惑星は途切れず動きつづけるのが正しい。
         スケーター自身も、位相をためる方式（m42Phase）にしてあるので、
         「その場から速さだけ変わる」——本物のスピンと同じ見え方になる。 */
      keepT: true,
      hint: '$L=mr^2\\omega$ は一定。$r$ を小さくすると $\\omega$ は $1/r^2$ で大きくなる'
    }
  ],
  mainVars: ['arm'],
  topActionsBelow: true,
  topActions: [
    {
      /* ★keepT★（先生の指示）
         押しても時間 t を 0 に戻さない。戻すと右の惑星が最初の位置へジャンプする。 */
      label: '腕を縮める →', prim: true, play: true, keepT: true,
      fn: function (s) { stepUp(DEFS['m4-2'], s, 'arm', -0.15); if (s.v.arm < 0.25) s.v.arm = 0.85; }
    },
    {
      label: '腕を広げた状態に戻す', keepT: true,
      fn: function (s) { s.v.arm = 0.85; },
      is: function (v) { return Math.abs(v.arm - 0.85) < 1e-9; }
    }
  ],
  /* ★★ここが大事★★
     以前は tEnd = 3周期・rate = tEnd/9 としていたので、
     腕を縮めて ω が 10 倍になっても「3周を 9 秒で回る」ままで、
     画面の上ではまったく速くならなかった（先生の指摘）。
     → tEnd も rate も「腕の長さによらない一定値」にする。
        こうすると ω がそのまま画面の速さになる。
        いちばん広げたとき（ω = 2.2）で2周ぶんの時間を tEnd にしてある。 */
  tEnd: function () { return TAU / 2.2 * 2; },
  rate: function () { return 0.5; },      /* 実時間1秒あたり、シムの時間 0.5 秒 */
  tFmt: function (t) { return fmt(t, 2) + ' 秒'; },
  xlabel: 't [秒]',
  sample: function (v, t) {
    var w = m42Om(v), m = 2.0;
    return {
      r: v.arm, v: v.arm * w, w: w,
      L: m * v.arm * v.arm * w, KE: P.m42.KE(m, v.arm, w)
    };
  },
  graphs: [
    {
      key: 'wr', short: '$\\omega$–$r$ 図', title: '$\\omega$–$r$ 図（腕の長さと回る速さ）', open: true,
      custom: function (v) {
        var i, pts = [], Lp = [], Sp = [], m = 2.0;
        for (i = 0; i <= 120; i++) {
          var rr = 0.2 + (0.95 - 0.2) * i / 120;
          var w = P.m42.omega(rr, 0.85, 2.2);
          pts.push([rr, w]);
          Lp.push([rr, m * rr * rr * w]);
          /* 面積速度 dS/dt = L/(2m)。L が一定なので、これも一定になる */
          Sp.push([rr, m * rr * rr * w / (2 * m)]);
        }
        var w0 = m42Om(v);
        return {
          xmin: 0, xmax: 1.0, ymin: 0, ymax: P.m42.omega(0.2, 0.85, 2.2) * 1.05,
          xlabel: 'r [m]', ylabel: 'ω [rad/s]', legend: true,
          series: [
            { color: COL.vel, width: 2.4, pts: pts, name: 'ω ∝ 1/r²' },
            { color: COL.sect1, width: 2.0, pts: Lp, name: 'L = mr²ω（一定）' },
            { color: COL.sect2, width: 2.0, dash: [6, 4], pts: Sp, name: '面積速度 L/2m（一定）' }
          ],
          cursors: [{ color: COL.vel, x: v.arm, y: w0, r: 6, name: 'いまの ω', lx: 10, ly: -10, align: 'left' }]
        };
      },
      fml: function (v) {
        var w = m42Om(v);
        return [
          'L = mr^2\\omega = mrv_\\perp\\;(\\text{一定}) \\;\\Rightarrow\\; \\omega = \\dfrac{L}{mr^2}',
          '\\dfrac{dS}{dt} = \\dfrac{1}{2}rv_\\perp = \\dfrac{L}{2m}\\;(\\text{一定}) \\;\\Leftarrow\\; \\text{面積速度一定}',
          'r = ' + fmt(v.arm, 2) + '\\,\\mathrm{m} \\;\\Rightarrow\\; \\omega = ' + fmt(w, 2) +
          '\\,\\mathrm{rad/s}\\;(' + fmt(w / TAU, 2) + '\\,\\text{回転/秒})'
        ];
      }
    }
  ],
  draw: function (ctx, s, t, W, H) {
    var v = V(s), w = m42Om(v);
    /* ★角度は「ω × t」ではなく、位相をためて出す★（先生の指示）
       ω × t だと、腕を縮めた瞬間に ω が変わるので角度が飛び、
       スケーターが一瞬ワープしたように見える。
       いまの ω で少しずつ足していけば、腕を変えても「その場から速さだけ変わる」。
       t が戻ったとき（↺リセット・ループの折り返し）は 0 に戻す。 */
    var th = m42Phase(s, t, w);
    var SC = 104;                         /* 1 m = 104 px（上から見た図・横から見た図で共通） */

    /* ===== 上半分【1】真上から見たようす ===== */
    var cx = 152, cy = 150;
    ctx.save();
    ctx.fillStyle = '#f2f7fb'; ctx.strokeStyle = '#dbe6ef'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(cx, cy, 104, 0, TAU); ctx.fill(); ctx.stroke();
    ctx.restore();
    /* 腕の先が通る円 */
    ctx.save();
    ctx.strokeStyle = fade(COL.vel, 0.35); ctx.lineWidth = 1.2; ctx.setLineDash([4, 4]);
    ctx.beginPath(); ctx.arc(cx, cy, v.arm * SC, 0, TAU); ctx.stroke();
    ctx.restore();

    var ax = Math.cos(th), ay = Math.sin(th);
    /* ★画面の y は下向きなので、反時計まわりにするには sin の符号を反転する★
       （L を ⊙ ＝手前向き と書いているので、右ねじの決まりで反時計まわりが正しい） */
    var h1 = [cx + ax * v.arm * SC, cy - ay * v.arm * SC];
    var h2 = [cx - ax * v.arm * SC, cy + ay * v.arm * SC];
    ctx.save();
    /* ★腕は「もの」なので、力の色（ピンク）では描かない★
       中心力の矢印にピンクを使うので、線と矢印が同じ色だと見分けがつかない。 */
    ctx.strokeStyle = '#8d8d8d'; ctx.lineWidth = 3; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(h1[0], h1[1]); ctx.lineTo(h2[0], h2[1]); ctx.stroke();
    ctx.restore();
    /* ★まるい「体」ではなく、回る体の図にする★
       肩は腕にそった細長いだ円、顔は腕と垂直の向き。鼻の三角で向きが分かる。 */
    /* ★「L（手前向き）」と ⊙ の印は出さない★（先生の指示・2026-09-03）
       ⊙ は「紙面の手前を向いたベクトル」を表す大学の書き方で、
       高校生には意味が分からず、かえって図がごちゃごちゃする。
       L が一定であることは、左上の読み出しと解説の文で伝えている。 */
    drawSkaterTop(ctx, cx, cy, th);
    label(ctx, '体（上から見た図）', cx, cy + 26, { size: 9.5, color: COL.sub });
    [h1, h2].forEach(function (h) { planetShape(ctx, h[0], h[1], 7, '#b5543a'); });
    /* ★中心力★ 腕が手を引く力は、いつも回転軸を向いている（＝中心力）。
       だから軸まわりの力のモーメントが 0 になり、L が変わらない。
       手の力なので色はピンク（COL.hand）。天体の万有引力は赤で描く。 */
    [h1, h2].forEach(function (h, i) {
      var dx = cx - h[0], dy = cy - h[1], dd = Math.hypot(dx, dy);
      if (dd < 20) return;
      var LL = Math.min(26, dd - 12);
      arrow(ctx, h[0], h[1], h[0] + dx / dd * LL, h[1] + dy / dd * LL, 'force', 1, COL.hand);
      if (i === 0) {
        label(ctx, '中心力', h[0] - dx / dd * 17, h[1] - dy / dd * 17,
          { size: 10, bold: true, color: COL.hand });
      }
    });
    /* ★r と v の文字はここには書かない★ 腕を縮めると「体」の丸と重なって読めなくなる。
       数字は左上の読み出しと、下の【2】の寸法線にまとめてある。 */
    dashLine(ctx, cx, cy, h1[0], h1[1], COL.dim, [4, 4], 1);
    if (s.o.showV) {
      var vsc = 40 / Math.max(1e-9, 0.25 * P.m42.omega(0.25, 0.85, 2.2));
      /* 位置が (cx + R cosθ, cy − R sinθ) なので、数学の向き（上が正）での速度は
         (−Rω sinθ, +Rω cosθ)。velArrow はこの向きで受け取る。
         ★ここと位置の式がそろっていないと、矢印が上下さかさまになる★（先生の指摘） */
      velArrow(ctx, h1[0], h1[1], -ay * v.arm * w, ax * v.arm * w, vsc, null);
      velArrow(ctx, h2[0], h2[1], ay * v.arm * w, -ax * v.arm * w, vsc, null);
    }
    label(ctx, '【1】真上から見たようす', cx, cy + 120, { size: 11, color: COL.sub, bold: true });

    /* ===== 上半分（右）惑星のたとえ ===== */
    /* ★だ円と惑星の位置は、同じ縮尺で描くこと★
       K.state が返す (x, y) は「焦点（太陽）を原点」とした座標なので、
       だ円の中心は太陽から −aε のところに来る。ここをそろえ忘れて、
       惑星がだ円の線からはずれて動いていた（先生の指摘）。 */
    (function () {
      var aE = 1, eE = 0.55, SCE = 62;               /* 1 AU = 62 px */
      var bE = aE * Math.sqrt(1 - eE * eE);
      var sunx = 442, suny = 150;                    /* 焦点（太陽）の位置 */
      var ecx = sunx - aE * eE * SCE;                /* だ円の中心 */
      ctx.save();
      ctx.strokeStyle = fade(COL.bound, 0.6); ctx.lineWidth = 1.4;
      ctx.beginPath(); ctx.ellipse(ecx, suny, aE * SCE, bE * SCE, 0, 0, TAU); ctx.stroke();
      ctx.restore();
      sunShape(ctx, sunx, suny, 8);
      var o = K.elems(aE, eE, SYS.sun.GM);
      var q = K.state(o, t * 0.16, 0, false);
      var sx = sunx + q.x * SCE, sy = suny - q.y * SCE;
      /* ★惑星がわの中心力＝万有引力★ いつも太陽を向いている。
         だから太陽まわりのモーメントは 0 で、L が一定＝面積速度が一定になる。 */
      planetShape(ctx, sx, sy, 5, '#3f7f5f');
      dashLine(ctx, sunx, suny, sx, sy, COL.dim, [3, 3], 1);
      (function () {
        var ux2 = sunx - sx, uy2 = suny - sy, ud2 = Math.hypot(ux2, uy2) || 1;
        gravArrow(ctx, sx, sy, sunx, suny, 24, '');
        label(ctx, '中心力', sx - ux2 / ud2 * 17, sy - uy2 / ud2 * 17,
          { size: 10, bold: true, color: COL.force });
      })();
      /* ★惑星の速度ベクトル★（先生の指示）
         K.state が返す (vx, vy) は数学の向き（上が正）なので、そのまま velArrow に渡す。
         いちばん速いのは近日点。そこで矢印が 36 px になるように縮尺をとる。 */
      if (s.o.showV) {
        var vp = Math.sqrt(SYS.sun.GM * (1 + eE) / (aE * (1 - eE)));
        velArrow(ctx, sx, sy, q.vx, q.vy, 36 / vp, null);
      }
      label(ctx, '惑星は近いと速く、遠いと遅い', 424, suny - bE * SCE - 30,
        { size: 11, color: COL.bound, bold: true });
    })();

    /* 読み出し（左上）と時計（右上） */
    label(ctx, 'ω = ' + fmt(w, 2) + ' rad/s（' + fmt(w / TAU, 2) + ' 回転/秒）', 10, 16,
      { align: 'left', size: 11.5, bold: true, color: COL.vel });
    label(ctx, 'L = m r²ω = ' + fmt(2.0 * v.arm * v.arm * w, 3) + ' kg·m²/s（変わらない）', 10, 32,
      { align: 'left', size: 11, bold: true, color: COL.sect1 });
    label(ctx, '手の速さ v = rω = ' + fmt(v.arm * w, 2) + ' m/s', 10, 48,
      { align: 'left', size: 11, bold: true, color: COL.vel });
    drawClock(ctx, W, 't = ' + fmt(t, 2) + ' 秒');

    /* ===== 区切り ===== */
    ctx.save();
    ctx.strokeStyle = '#e2e8ef'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(10, 276); ctx.lineTo(W - 10, 276); ctx.stroke();
    ctx.restore();

    /* ===== 下半分【2】横から見たようす ===== */
    label(ctx, '【2】横から見たようす', 10, 290,
      { align: 'left', size: 11, color: COL.sub, bold: true });
    drawSkaterSide(ctx, 146, 534, v.arm, th, SC, s.o.showV, w);

    /* 右下：スケートの豆知識（canvas なので KaTeX は使えない。ふつうの文字で書く） */
    (function () {
      var tx = 300, ty = 316, dy = 19;
      label(ctx, 'なぜ速くなるのか', tx, ty,
        { align: 'left', size: 11.5, bold: true, color: COL.ink });
      [
        '① 腕を引く力は、回転軸を向いている',
        '② だから 軸まわりの力のモーメントは 0',
        '③ よって 角運動量 L = m r²ω は変わらない',
        '④ r を小さくすると、ω が 1/r² で大きくなる',
        '',
        '惑星が近日点で速くなるのも、まったく同じ理由。'
      ].forEach(function (line, i) {
        if (!line) return;
        label(ctx, line, tx, ty + 22 + i * dy,
          { align: 'left', size: 10.5, color: (i === 5 ? COL.bound : COL.sub), bold: i === 5 });
      });
    })();
    if (hintOn(s, t)) {
      label(ctx, '腕を縮めると ω は 1/r² で大きくなる', W - 10, H - 12,
        { align: 'right', size: 11.5, bold: true, color: COL.vel });
    }
  },
  result: function (v, s, t) {
    var w = m42Om(v), m = 2.0;
    var w0 = 2.2, r0 = 0.85;
    return {
      items: [
        resItem('腕の長さ $r$', fmt(v.arm, 2) + ' m'),
        resItem('角速度 $\\omega$', fmt(w, 3) + ' rad/s'),
        resItem('1秒あたりの回転数', fmt(w / TAU, 2) + ' 回転/秒'),
        resItem('手の速さ $v = r\\omega$', fmt(v.arm * w, 3) + ' m/s'),
        resItem('角運動量 $L = mr^2\\omega$', fmt(m * v.arm * v.arm * w, 4) + ' kg·m²/s', true),
        resItem('はじめの $L$', fmt(m * r0 * r0 * w0, 4) + ' kg·m²/s', true),
        resItem('面積速度 $L/2m$', fmt(v.arm * v.arm * w / 2, 4) + ' m²/s', true)
      ],
      note: '<b>腕の長さ $r$ をどう変えても、$L$ の2つの値はぴったり同じ</b>——' +
        'これが<b>角運動量保存</b>です。<br>' +
        '$L$ が変わらないので、$\\dfrac{dS}{dt}=\\dfrac{L}{2m}$（面積速度）も変わりません。' +
        '<b>惑星の「面積速度一定」と、まったく同じことが起きています。</b>'
    };
  },
  info: function (s, t) {
    var v = V(s), w = m42Om(v), m = 2.0;
    return [
      ['腕の長さ $r$', fmt(v.arm, 2) + ' m'],
      ['角速度 $\\omega$', fmt(w, 3) + ' rad/s'],
      ['手の速さ $v = r\\omega$', fmt(v.arm * w, 3) + ' m/s'],
      ['角運動量 $L$', fmt(m * v.arm * v.arm * w, 4) + ' kg·m²/s'],
      ['面積速度 $L/2m$', fmt(v.arm * v.arm * w / 2, 4) + ' m²/s'],
      ['時刻 $t$', fmt(t, 2) + ' 秒']
    ];
  },
  eq: function () {
    return 'L = mr^2\\omega = mrv\\;(\\text{一定}) \\quad\\Longleftrightarrow\\quad ' +
      '\\dfrac{dS}{dt} = \\dfrac{1}{2}rv\\sin\\theta = \\dfrac{L}{2m}\\;(\\text{一定})';
  }
};

/* ============================================================
   4-2　ハレー彗星とニュートン（中の id は m4-3 のまま）
   ============================================================ */
DEFS['m4-3'] = {
  id: 'm4-3', mode: 4, tab: '4-1 ハレー彗星とニュートン', read: true,
  legendKeys: ['sun', 'orbit', 'vel'],
  units: ['AU'],
  title: '4-1　ハレー彗星とニュートン　—　天と地の法則の融合',
  sub: '彗星は長いあいだ「とつぜん現れる不吉なもの」と思われていました。' +
    'ところが<b>エドモンド・ハレー</b>は、ニュートンの<b>運動方程式と万有引力の法則</b>を使って ' +
    '1531年・1607年・1682年に現れた彗星の軌道を計算し、' +
    '<b>「これは同じ1つの彗星で、1758年ごろにまた帰ってくる」</b>と予言しました。<br>' +
    'ハレーの死後 16 年、<b>1758年のクリスマスに彗星は本当に帰ってきました</b>——' +
    '<b>天（彗星）と地（落ちるリンゴ）が同じ法則にしたがっている</b>ことが、' +
    'だれの目にも見える形で示された瞬間です。',
  /* ★「見るポイント」とグラフは置かない★（先生の指示）
     このシムは読み物（右のコラム）が主役なので、右の列はコラムだけにする。 */
  /* ★ミニコラムは「右の列」に置く★（先生の指示）
     下いっぱいの d.long ではなく sideText にすると、
     図とコラムが同じ高さに並んで、見比べながら読める。 */
  sideText:
    '<span class="q">【物理ミニコラム】ハレー彗星 —— 天と地の法則が同じだと分かった発見</span>' +
    'ハレー彗星の話は、<b>ニュートンの運動方程式と万有引力の法則が「証明された」話</b>です。' +
    '<b>天（惑星や彗星）と地（落ちるリンゴ）が、同じ1つの法則にしたがっている</b>——。' +

    '<div class="colh">1. まず、ケプラーの法則があった</div>' +
    'ケプラーの法則は、惑星の運動を長年観測した<b>ティコ・ブラーエ</b>の膨大な記録を、' +
    '<b>ヨハネス・ケプラー</b>が3つの法則にまとめたものです。' +
    '<ul class="colul">' +
    '<li>① 惑星は<b>楕円軌道</b>を描く</li>' +
    '<li>② 惑星と太陽を結ぶ線分が単位時間に描く<b>面積は一定</b></li>' +
    '<li>③ 惑星の<b>公転周期の2乗</b>は、楕円軌道の<b>長半径の3乗</b>に比例する</li>' +
    '</ul>' +
    '<b>①②は 1609 年、③は 1619 年に発表</b>されました。<br>' +
    '<span class="mini">ただしケプラーの法則は「観測をまとめた規則」であって、' +
    '<b>なぜそうなるのか</b>は分かっていませんでした。</span>' +

    '<div class="colh">2. ハレーが「なぜ？」を持って回った</div>' +
    '<b>エドモンド・ハレー</b>は、この結果を<b>数式で証明できないか</b>と、' +
    '<b>フック</b>など高名な物理学者をたずねて回りました。' +
    'ですが、明確な答えは得られません。<br>' +
    'しかし最後にたどり着いた<b>ニュートン</b>は、<b>「証明可能である」と即答</b>しました。' +
    '「それはなぜですか」と食いつくと、' +
    '<b>「すでに証明済だからだ。ただし計算用紙がどこかにいってしまった」</b>' +
    'と彼は答えます。そして、<b>再計算した結果をハレーに送ることを約束</b>しました。' +

    '<div class="colh">3. 送られてきた計算に、ハレーは驚愕した</div>' +
    'ハレーは首を長くして待ち、やがてニュートンから計算が届きます。それを見て彼は驚きました。' +
    '<ul class="colul">' +
    '<li><b>「運動方程式」</b>と<b>「万有引力の法則」</b>——当時まだ誰も知らない物理法則</li>' +
    '<li><b>「微分積分」</b>——これもまだ世に出ていない数学</li>' +
    '</ul>' +
    'その2つを使って、<b>ケプラーの法則がきちんと証明されていた</b>のです。<br>' +
    'そして何より驚いたのは、<b>ニュートンがその計算結果を放置していた</b>ということでした。' +

    '<div class="colh">4. 『プリンキピア』はハレーの自費出版</div>' +
    'ハレーは強い使命感を抱き、ものぐさなニュートンの背中を押して、' +
    '<b>1687 年に『プリンキピア』（自然哲学の数学的諸原理）を世に出させます</b>。' +
    '出版は困難をきわめ、結局<b>費用はハレーが全額負担する自費出版</b>という形になりました。<br>' +
    '<span class="mini">ニュートンは人類史上まれに見る天才でしたが、性格には難があり、' +
    'いつも周囲と衝突していたと伝えられます。' +
    'もし彼がハレーと出会わなかったら、これらの重大な物理法則と数学は公表されず、' +
    '人類の文明は今よりはるかに遅れていたかもしれません。</span>' +

    '<div class="colh">5. そして「予言」——天と地の法則の融合</div>' +
    'ハレーは<b>自ら運動方程式を使って彗星の軌道を計算</b>しました。' +
    'すると 1531 年・1607 年・1682 年に現れた彗星の軌道が<b>ほとんど同じ</b>で、' +
    '間隔はおよそ 76 年。<b>「これは同じ1つの彗星が、細長い楕円を回って帰ってきているのだ」</b>' +
    'と見ぬき、<b>1758 年ごろの再来を予言</b>したのです。<br>' +
    'ハレー自身は 1742 年に亡くなり、その再来を目にすることはできませんでした。' +
    'それでも<b>1758 年 12 月 25 日、彗星はふたたび姿を現しました。</b>' +

    '<div class="colh">6. 科学史で最初の出来事</div>' +
    'それまで科学は、<b>「起きたことを説明する」</b>ものでした。' +
    'ハレーの予言は、<b>「まだ起きていないことを、何十年も先まで言い当てた」</b>' +
    '最初の大きな例です。<br>' +
    'しかも当たったのは、<b>地上のリンゴを落とすのと同じ法則が、彗星にも成り立っていた</b>から。' +
    '<b>「万有引力」の「万有」——どこでも成り立つ——の意味が、' +
    'だれの目にも見える形で示された瞬間</b>でした。' +

    '<hr class="colhr">' +
    '<div class="colh">■ 数字で見るハレー彗星</div>' +
    '<ul class="colul">' +
    '<li>半長軸 <b>a = 17.8 AU</b>、離心率 <b>ε = 0.967</b>、周期 <b>T = 75.3 年</b></li>' +
    '<li>近日点 <b>0.586 AU</b>（金星より内側）／遠日点 <b>35.1 AU</b>（海王星より外）</li>' +
    '<li>近日点の速さ <b>54.5 km/s</b>／遠日点の速さ <b>0.91 km/s</b>（60倍の違い）</li>' +
    '<li><b>T²/a³ = 1.0002 年²/AU³</b>——惑星とまったく同じ値</li>' +
    '<li>前回の回帰は <b>1986 年</b>、次は <b>2061 年</b>。' +
    'いまの高校生なら、生きているうちに見られます。</li>' +
    '</ul>' +
    'いま彗星は<b>遠日点のあたりでいちばんゆっくり動いています</b>。' +
    '75 年の周期のうち、内側の惑星のあたりにいるのは<b>ほんの数年</b>だけ。' +
    'あとの 70 年あまりは、暗い外側をのろのろと進んでいるのです（＝ケプラーの第2法則）。' +
    refsHtml([
      { t: '1P/Halley（NASA Science）', u: 'https://science.nasa.gov/solar-system/comets/1p-halley/',
        n: 'ハレー彗星の軌道要素・大きさ・歴史のまとめ（英語）。' },
      { t: 'Giotto（NASA Science）', u: 'https://science.nasa.gov/mission/giotto/',
        n: '1986年に彗星の核を初めて間近から撮影した探査機（ヨーロッパ宇宙機関）。' },
      { t: 'さきがけ Sakigake（NASA Science）', u: 'https://science.nasa.gov/mission/sakigake/',
        n: '1985年に打ち上げられた日本初の惑星間探査機。ハレー彗星を観測した。' },
      { t: 'JPL Solar System Dynamics', u: 'https://ssd.jpl.nasa.gov/',
        n: '太陽系の天体の軌道要素の一次資料。このページの数値もここの値に合わせている。' },
      { t: '暦計算室（国立天文台）', u: 'https://eco.mtk.nao.ac.jp/koyomi/',
        n: '日本語で天文の数値を調べたいときに。' },
      { t: 'YouTube チャンネル「ぴーす」のコミュニティ投稿',
        u: 'https://www.youtube.com/channel/UC-BuGM5xGth9UFgYGTbP3Zw/community?lb=UgkxzNNQxjpCpvYqmeOg0ERCns2Jt0pYxZgD',
        n: 'このコラムのもとにした、ハレーとニュートンのエピソードの紹介。' }
    ]),
  cw: 560, ch: 420,
  loop: true,
  vis: ['V', 'T'],
  visLabel: { V: '速度を表示', T: '通ってきた道すじ' },
  visDef: { V: true, T: true },
  vars: [],
  tEnd: function () { return 75.32; },
  rate: function () { return 75.32 / 24; },
  tFmt: function (t) { return fmt(t, 1) + ' 年'; },
  xlabel: 't [年]',
  sample: function (v, t) {
    var p = planetById('halley'), q = planetXY(p, t);
    return { r: q.r, v: q.v };
  },
  graphs: [],
  draw: function (ctx, s, t, W, H) {
    var p = planetById('halley'), i;
    /* 遠日点（−35.1 AU）から近日点（+0.59 AU）までが入るようにとる */
    var vw = mkView(W, H, { l: 30, r: 30, t: 26, b: 34 },
      { x0: -38, x1: 8, y0: -13, y1: 13 });
    s.view = vw;
    /* ★背景を先に暗く塗る★ 白いままだと星（白い点）が見えない */
    ctx.save();
    ctx.fillStyle = '#0d1626';
    ctx.fillRect(0, 0, W, H);
    ctx.restore();
    starField(ctx, 0, 0, W, H, 120, 4321);

    /* 惑星の軌道（内側の目安） */
    [['earth', '地球'], ['jupiter', '木星'], ['neptune', '海王星']].forEach(function (g) {
      var q = planetById(g[0]);
      ctx.save();
      ctx.strokeStyle = fade(q.col, 0.5); ctx.lineWidth = 1.1; ctx.setLineDash([4, 4]);
      ctx.beginPath(); ctx.arc(vw.X(0), vw.Y(0), vw.X(q.a) - vw.X(0), 0, TAU); ctx.stroke();
      ctx.restore();
      label(ctx, g[1], vw.X(0), vw.Y(0) - (vw.X(q.a) - vw.X(0)) - 8,
        { size: 9.5, color: q.col, haloColor: 'rgba(13,22,38,.92)' });
    });
    /* ハレー彗星の軌道（E で等分。時間で等分すると多角形になる） */
    ctx.save();
    ctx.strokeStyle = COL.orbit; ctx.lineWidth = 1.8;
    ctx.beginPath();
    var pts = planetOrbitPts(p, 1440);
    pts.forEach(function (q, j) {
      var sp = [vw.X(q[0]), vw.Y(q[1])];
      if (j === 0) ctx.moveTo(sp[0], sp[1]); else ctx.lineTo(sp[0], sp[1]);
    });
    ctx.closePath(); ctx.stroke();
    ctx.restore();
    if (s.o.showT && t > 1e-6) {
      var tp = planetTrailPts(p, t, trailN(p, t));
      ctx.save();
      ctx.strokeStyle = fade(p.col, 0.95); ctx.lineWidth = 2.6; ctx.lineCap = 'round';
      ctx.beginPath();
      tp.forEach(function (q, j) {
        var sp = [vw.X(q[0]), vw.Y(q[1])];
        if (j === 0) ctx.moveTo(sp[0], sp[1]); else ctx.lineTo(sp[0], sp[1]);
      });
      ctx.stroke();
      ctx.restore();
    }
    sunShape(ctx, vw.X(0), vw.Y(0), 9);
    label(ctx, '太陽', vw.X(0), vw.Y(0) + 20,
      { size: 10.5, color: COL.sun, bold: true, haloColor: 'rgba(13,22,38,.92)' });

    var q2 = planetXY(p, t);
    var px = vw.X(q2.x), py = vw.Y(q2.y);
    planetShape(ctx, px, py, 4.6, '#e8eef4');
    /* 尾（太陽と反対の向き。近いときだけ長い） */
    (function () {
      var rr = Math.max(1e-6, q2.r);
      var L = clamp(60 / (rr * rr), 0, 62);
      if (L < 4) return;
      var ux = (px - vw.X(0)) / Math.hypot(px - vw.X(0), py - vw.Y(0));
      var uy = (py - vw.Y(0)) / Math.hypot(px - vw.X(0), py - vw.Y(0));
      ctx.save();
      ctx.strokeStyle = 'rgba(190,215,235,.75)'; ctx.lineWidth = 4; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(px + ux * L, py + uy * L); ctx.stroke();
      ctx.restore();
    })();
    label(ctx, 'ハレー彗星', px, py - 13,
      { size: 10.5, color: '#e8eef4', bold: true, haloColor: 'rgba(13,22,38,.92)' });
    if (s.o.showV) {
      var vsc = 40 / 10.0;
      velArrow(ctx, px, py, q2.st.vx, q2.st.vy, vsc, 'v = ' + fmt(q2.v * 4.7405, 1) + ' km/s', 12, 15);
    }
    label(ctx, 'ε = 0.967　a = 17.8 AU　T = 75.3 年', 10, 16,
      { align: 'left', size: 11, bold: true, color: '#cfe0f0', haloColor: 'rgba(13,22,38,.92)' });
    label(ctx, '※ 星は動かない（恒星）', 10, H - 12,
      { align: 'left', size: 10, color: '#8ea3b8', haloColor: 'rgba(13,22,38,.92)' });
    label(ctx, 't = ' + fmt(t, 1) + ' 年', W - 10, 16,
      { align: 'right', size: 13.5, bold: true, color: '#e8eef4', haloColor: 'rgba(13,22,38,.92)' });
    if (hintOn(s, t)) {
      label(ctx, (q2.r < 3 ? '太陽の近く：とても速い' : '遠くではとてもゆっくり') +
        '（いま ' + fmt(q2.v * 4.7405, 1) + ' km/s）', W - 10, H - 12,
        { align: 'right', size: 11.5, bold: true, haloColor: 'rgba(13,22,38,.92)',
          color: q2.r < 3 ? '#ffc46b' : '#9fc3e0' });
    }
  },
  result: function (v, s, t) {
    var p = planetById('halley'), o = pElems(p), q = planetXY(p, t);
    return {
      items: [
        resItem('半長軸 $a$', fmt(p.a, 3) + ' AU'),
        resItem('離心率 $\\varepsilon$', fmt(p.e, 4)),
        resItem('周期 $T$', fmt(p.T, 2) + ' 年'),
        resItem('$K = T^2/a^3$', fmt(p.T * p.T / (p.a * p.a * p.a), 4) + ' 年²/AU³', true),
        resItem('近日点 $r_{\\text{近}}$', fmt(o.rp, 3) + ' AU'),
        resItem('遠日点 $r_{\\text{遠}}$', fmt(o.ra, 2) + ' AU'),
        resItem('近日点の速さ', fmt(o.vp * 4.7405, 1) + ' km/s'),
        resItem('遠日点の速さ', fmt(o.va * 4.7405, 2) + ' km/s'),
        resItem('いまの距離 $r$', fmt(q.r, 2) + ' AU')
      ],
      note: '<b>$r_{\\text{近}}v_{\\text{近}} = ' + fmt(o.rp * o.vp, 3) + '$、' +
        '$r_{\\text{遠}}v_{\\text{遠}} = ' + fmt(o.ra * o.va, 3) + '$</b>——ぴったり同じです（面積速度一定）。' +
        'また $K = T^2/a^3$ は惑星の値 1.00 とほぼ同じ。' +
        '<b>彗星も惑星と同じ法則にしたがっている</b>ことが、これで分かります。'
    };
  },
  info: function (s, t) {
    var p = planetById('halley'), q = planetXY(p, t);
    return [
      ['太陽からの距離 $r$', fmt(q.r, 3) + ' AU'],
      ['速さ $v$', fmt(q.v * 4.7405, 2) + ' km/s'],
      ['$r\\,v_\\perp$（面積速度の2倍）', fmt(q.r * q.st.vt, 3) + ' AU²/年'],
      ['経過した時間 $t$', fmt(t, 1) + ' 年']
    ];
  },
  eq: function () {
    return 'T^2 = \\dfrac{4\\pi^2}{GM}a^3 \\;\\Rightarrow\\; ' +
      'T = 75.3\\,\\text{年}\\;(a = 17.8\\,\\mathrm{AU}) \\qquad r_{\\text{近}}v_{\\text{近}} = r_{\\text{遠}}v_{\\text{遠}}';
  }
};

/* ============================================================
   4-3　高校物理の先の現代天文学（id は m4-4）
   ------------------------------------------------------------
   〜万有引力とエネルギーで解き明かす最先端の天体物理学〜
   高校で習う $v=\sqrt{2GM/r}$ と $E=\frac12mv^2-\frac{GMm}{r}$ の2本だけで、
   ①ブラックホールの大きさ ②ダークマターの存在 ③宇宙の運命 まで届くことを見せる。
   ★話題は3つ。オレンジのボタンで切りかえる（変数も話題ごとに出しわける）。
   ★どの話題も、数値積分はしない（閉じた式だけ）。
   ============================================================ */
var M44_TOPIC = ['', 'ブラックホールの境界線', 'ダークマターの正体',
  '宇宙の運命'];

/* 時間の書き方（マイクロ秒から億年まで、話題によってけたが大きく違う） */
function m44Sec(t) {
  if (t >= 1) return fmt(t, 2) + ' 秒';
  if (t >= 1e-3) return fmt(t * 1e3, 2) + ' ミリ秒';
  return fmt(t * 1e6, 1) + ' マイクロ秒';
}
function m44Msun(v) { return Math.pow(10, v.mexp); }
/* ① いまの状態（星の質量・rs・光を出す場所・その光のエネルギー） */
function m44BH(v) {
  var Ms = m44Msun(v), c = P.m44.c;
  var GM = P.m44.GMsun * Ms;
  var rs = P.m44.rs(Ms);
  var r0 = v.r0k * rs;
  /* 光の粒を、まっすぐ外向きに c で打ち出したときの力学的エネルギー／質量 */
  var Em = c * c / 2 - GM / r0;
  var out = Em >= -1e-9 * c * c;
  var a = out ? Infinity : GM / (2 * Math.abs(Em));
  var t0 = P.m44.radT(GM, Em, r0);
  var Trad = TAU * Math.sqrt(a * a * a / GM);   /* まっすぐな往復1周期（r=0 → 外 → r=0） */
  var tBack = out ? Infinity : (Trad - 2 * t0); /* 打ち出した高さ r₀ に戻ってくるまで */
  /* ★時間バーの終わりは「中心に吸いこまれるまで」★（先生の指示）
     r₀ に戻ったところで止めると、まだ動いている途中でバーが端に来てしまう。 */
  var tSink = out ? Infinity : (Trad - t0);
  return { Ms: Ms, GM: GM, rs: rs, r0: r0, Em: Em, out: out, a: a, t0: t0,
    tBack: tBack, tSink: tSink, rmax: out ? Infinity : 2 * a,
    vesc: P.m44.vEsc(Ms, r0) };
}
function m44BHr(h, t) { return P.m44.radR(h.GM, h.Em, h.t0 + Math.max(0, t)); }

DEFS['m4-4'] = {
  id: 'm4-4', mode: 4, tab: '4-3 高校物理の先の現代天文学', read: true,
  legendKeys: ['vel', 'dim', 'orbit'],
  title: '4-3　高校物理の先の現代天文学　～万有引力とエネルギーで解き明かす最先端の天体物理学～',
  sub: 'ここまでで、みなさんは<b>2つの式</b>を手に入れました。<br>' +
    '<b>脱出速度</b> $v=\\sqrt{\\dfrac{2GM}{r}}$　と　' +
    '<b>力学的エネルギー</b> $E=\\dfrac{1}{2}mv^2-\\dfrac{GMm}{r}$。<br>' +
    'じつは、いま世界中の天文学者が使っている道具も、<b>おおもとはこの2つ</b>です。' +
    '上のオレンジのボタンで<b>3つの話題</b>を切りかえて、' +
    '<b>高校の式がどこまで届くのか</b>を見てください。',
  sideText:
    '<span class="q">【物理ミニコラム】高校物理の先の現代天文学</span>' +

    '<div class="colh">① ブラックホールの境界線</div>' +
    '打ち上げた物体が戻ってこないためには、脱出速度 $v=\\sqrt{\\dfrac{2GM}{r}}$ ' +
    'より速く投げなければなりません。<br>' +
    'では、<b>その脱出速度が「光の速さ $c$」になってしまったら</b>どうなるでしょう。' +
    '光でさえ出ていけない——それが<b>ブラックホール</b>です。<br>' +
    '$\\sqrt{\\dfrac{2GM}{r}}=c$ を $r$ について解くと<br>' +
    '<b>$r_s=\\dfrac{2GM}{c^2}$</b>（シュワルツシルト半径）<br>' +
    'これがブラックホールの「境界線（事象の地平面）」の半径です。' +
    '<b>高校で習う式を、$c$ とつなぐだけで出てきます。</b><br>' +
    '<span class="mini">・太陽（1 太陽質量）なら $r_s=2.95$ km。' +
    '・地球なら たったの 8.9 mm。' +
    '・銀河の中心にある巨大ブラックホール（400万太陽質量）なら 約 1200 万 km。<br>' +
    '※ 本当のブラックホールは一般相対性理論で扱いますが、' +
    '$r_s$ の式は 1783 年にミッチェルが「暗い星」としてニュートン力学だけで出したものと、' +
    'ぴったり同じ形になります。</span><br>' +
    'ジェイムズ・ウェッブ宇宙望遠鏡（JWST）は、宇宙のごく初期に' +
    '<b>思ったよりずっと重いブラックホール</b>らしきものを次つぎ見つけています。' +
    '2026年6月には、なぞの天体<b>「リトルレッドドット」</b>が、' +
    '<b>濃いガスにつつまれた巨大ブラックホール（＝「ブラックホール星」）</b>である' +
    'という、これまででいちばん強い証拠が見つかった、と発表されました' +
    '（ビッグバンから約 18 億年後の天体 GLIMPSE-17775 のスペクトル）。<br>' +
    '<span class="mini">※ ブラックホールがどうやってそんなに早く育ったのかは、まだ研究の途中です。' +
    '下の参考文献から、一次情報を読んでみてください。</span>' +

    '<div class="colh">② 目に見えない「ダークマター」の質量をあばく</div>' +
    '円運動している星について、<b>向心力＝万有引力</b>と置くと<br>' +
    '$\\dfrac{mv^2}{r}=G\\dfrac{Mm}{r^2}\\;\\Rightarrow\\;v=\\sqrt{\\dfrac{GM}{r}}$<br>' +
    'つまり<b>速さを測れば、内側にある質量 $M$ が分かる</b>のです。' +
    '中心から遠いほど、$v$ は $1/\\sqrt{r}$ で小さくなるはず——' +
    '太陽系の惑星は、確かにそうなっています。<br>' +
    'ところが銀河を観測すると、<b>外側の星もほとんど速さが落ちません</b>。' +
    'この式に入れなおすと、<b>目に見える星の何倍もの質量が、外側まで広がっている</b>' +
    'ことになります。それが<b>ダークマター</b>です。<br>' +
    '<span class="mini">左の図で「ダークマターの量」を 0 にすると、' +
    '外側の星がゆっくりになり、観測と合わなくなります。</span>' +

    '<div class="colh">③ 「宇宙の運命」を決める位置エネルギー</div>' +
    '万有引力の位置エネルギー $U=-\\dfrac{GMm}{r}$ は、いつも<b>負</b>でした。' +
    'この「負」が、宇宙全体の運命を決めます。<br>' +
    '広がっていく宇宙のふちにある銀河について、力学的エネルギーを書くと<br>' +
    '$E=\\dfrac{1}{2}mv^2-\\dfrac{GMm}{r}$<br>' +
    'これは<b>ボールをまっすぐ投げ上げたときと、まったく同じ式</b>です。だから答えも同じ。' +
    '<ul class="colul">' +
    '<li><b>$E>0$</b>（宇宙の中身が薄い）… 永遠に広がりつづける</li>' +
    '<li><b>$E=0$</b>（ちょうど）… だんだん遅くなりながら、ぎりぎり広がりつづける</li>' +
    '<li><b>$E<0$</b>（中身が濃い）… いつか止まって、逆に縮んでいく（ビッグクランチ）</li>' +
    '</ul>' +
    '左の図の $\\Omega$（オメガ）は、<b>宇宙の中身の濃さが「ちょうど」の何倍か</b>です。' +
    '$\\Omega>1$ にすると、宇宙がふくらんでから縮んでいくのが見えます。<br>' +
    '<span class="mini">※ ここでは高校で扱える「物質だけの宇宙」で計算しています。' +
    '本当の宇宙には<b>ダークエネルギー</b>があって、いまは膨張が加速しています。' +
    'そのため実際の宇宙の年齢（138億年）は、この図の値とはずれます。' +
    '2025 年には、ダークエネルギーが時間とともに弱まっているとすれば' +
    '<b>あと 333 億年ほどで宇宙は縮みに転じる</b>、という研究も出ました。' +
    'まだ決着はついていません。</span>' +

    '<hr class="colhr">' +
    '<div class="colh">■ 教科書の数式は「宇宙の共通言語」</div>' +
    'ブラックホールの半径も、目に見えないダークマターの重さも、宇宙の終わりかたも、' +
    'おおもとは<b>みなさんがいま解いている万有引力とエネルギーの式</b>です。<br>' +
    '公式は「覚えて当てはめるもの」ではなく、<b>宇宙のどこででも通じる言葉</b>です。' +
    'その言葉を1つ覚えるたびに、見える世界がひとつ遠くまで広がります。<br>' +
    '<b>いま解いている1問が、そのまま宇宙の果てにつながっています。</b>' +
    refsHtml([
      { t: "NASA Webb Finds Strongest Evidence Yet for 'Black Hole Stars'（NASA Science, 2026年6月10日）",
        u: 'https://science.nasa.gov/missions/webb/nasa-webb-finds-strongest-evidence-yet-for-black-hole-stars/',
        n: '①で紹介した「ブラックホール星」の発表。40 本以上のスペクトル線からの結論（英語）。' },
      { t: 'James Webb Space Telescope（NASA Science）', u: 'https://science.nasa.gov/mission/webb/',
        n: 'JWST のミッション全体。最新の画像もここから。' },
      { t: 'Dark Matter（NASA Science）', u: 'https://science.nasa.gov/dark-matter/',
        n: '②のダークマター。銀河の回転曲線の話も出てくる（英語）。' },
      { t: 'What is Dark Energy?（NASA Science）', u: 'https://science.nasa.gov/dark-energy/',
        n: '③で「本当の宇宙にはこれがある」と書いたダークエネルギーの解説（英語）。' },
      { t: 'DESI（Dark Energy Spectroscopic Instrument）', u: 'https://www.desi.lbl.gov/',
        n: '「ダークエネルギーは弱まっているかもしれない」という 2025 年の結果を出した観測計画。' },
      { t: '国立天文台', u: 'https://www.nao.ac.jp/',
        n: '日本語で最新の天文の話題を読みたいときに。' }
    ]),
  cw: 560, ch: 470,
  noOpenRow: true,
  /* ★①②③とも、時間バーが端まで行ったら止まる★（先生の指示）
     ①は光が中心に吸いこまれたところ、②は1周したところ、③は宇宙の最後で止まる。 */
  loop: false,
  vis: [],
  vars: [
    {
      /* ★これはスライドバーとしては出さない★（オレンジのボタンで切りかえるため）
         when が false でも、はじめの値 def はちゃんと入る。 */
      k: 'topic', label: '話題', unit: '', min: 1, max: 3, step: 1, dec: 0, def: 1,
      when: function () { return false; }
    },
    {
      k: 'mexp', label: '星の質量 $M$', unit: ' 太陽質量', min: 0, max: 9, step: 0.5, dec: 1, def: 1,
      when: function (v) { return v.topic === 1; },
      fmt: function (x) { return fmtE(Math.pow(10, x), 1); },
      hint: '$r_s=2GM/c^2$ は $M$ に比例する'
    },
    {
      k: 'r0k', label: '光を出す場所 $r_0/r_s$', unit: ' 倍', min: 0.4, max: 3, step: 0.1, dec: 1, def: 2,
      when: function (v) { return v.topic === 1; },
      hint: '1 より内側だと、シュワルツシルト半径以内なので、光の粒でさえ戻ってきてしまう'
    },
    {
      k: 'rk', label: '星のいる半径 $r$', unit: ' kpc', min: 2, max: 24, step: 1, dec: 0, def: 8,
      when: function (v) { return v.topic === 2; },
      hint: '太陽は銀河の中心から約 8 kpc（2.6 万光年）のところ'
    },
    {
      k: 'kdm', label: 'ダークマターの量', unit: '', min: 0, max: 2, step: 0.1, dec: 1, def: 1,
      when: function (v) { return v.topic === 2; },
      hint: '0 にすると「見える星だけ」。観測に合うのは 1 くらい'
    },
    {
      k: 'om', label: '宇宙の中身の濃さ $\\Omega$', unit: '', min: 0.2, max: 2, step: 0.05, dec: 2, def: 0.3,
      when: function (v) { return v.topic === 3; },
      hint: '$\\Omega<1$ で $E>0$（永遠に膨張）、$\\Omega>1$ で $E<0$（いつか縮む）'
    }
  ],
  mainVars: ['mexp', 'r0k', 'rk', 'kdm', 'om'],
  topActionsBelow: true,
  topActions: [
    {
      label: '① ブラックホールの境界線', prim: true, play: true, rebuild: true,
      fn: function (s) { s.v.topic = 1; },
      is: function (v) { return v.topic === 1; }
    },
    {
      label: '② ダークマターの正体', prim: true, play: true, rebuild: true,
      fn: function (s) { s.v.topic = 2; },
      is: function (v) { return v.topic === 2; }
    },
    {
      label: '③ 宇宙の運命', prim: true, play: true, rebuild: true,
      fn: function (s) { s.v.topic = 3; },
      is: function (v) { return v.topic === 3; }
    }
  ],
  tEnd: function (v) {
    if (v.topic === 1) {
      var h = m44BH(v);
      /* 戻ってくるときは「行って帰って」まで。出ていくときは 6rs まで */
      return h.out ? Math.max(1e-9, P.m44.radT(h.GM, h.Em, 6 * h.rs) - h.t0) : h.tSink;
    }
    if (v.topic === 2) return P.m44.Trot(v.rk, 0);       /* 遅いほうが1周する時間 */
    var te = P.m44.tauEnd(v.om);
    return (isFinite(te) ? te : 3.2 * P.m44.tau0(v.om)) * P.m44.tH();
  },
  rate: function (v) { return DEFS['m4-4'].tEnd(v) / 14; },
  tFmt: function (t, v) {
    if (!v || v.topic === 1) return m44Sec(t);
    return fmt(t, 1) + ' 億年';
  },
  xlabel: 't',
  sample: function (v, t) {
    if (v.topic === 1) {
      var h = m44BH(v);
      return { r: m44BHr(h, t) / h.rs };
    }
    if (v.topic === 2) return { r: v.rk, vv: P.m44.vRot(v.rk, v.kdm) };
    return { a: P.m44.aOf(v.om, t / P.m44.tH()) };
  },
  graphs: [
    {
      key: 'bh', short: '$v_{\\text{脱出}}$–$r$ 図', open: true, H: 250,
      title: '$v_{\\text{脱出}}$–$r$ 図　※ 光の速さ $c$ と交わるところが $r_s$',
      when: function (v) { return v.topic === 1; },
      custom: function (v) {
        var h = m44BH(v), i, pts = [];
        for (i = 0; i <= 160; i++) {
          var rk = 0.35 + (5 - 0.35) * i / 160;
          pts.push([rk, P.m44.vEsc(h.Ms, rk * h.rs) / P.m44.c]);
        }
        return {
          xmin: 0, xmax: 5, ymin: 0, ymax: 1.8,
          xlabel: 'r [rs を1とした距離]', ylabel: 'v脱出 / c', legend: true,
          series: [
            { color: COL.bound, width: 2.4, pts: pts, name: 'v脱出 = √(2GM/r)' },
            { color: COL.force, width: 2.0, dash: [6, 4], pts: [[0, 1], [5, 1]], name: '光の速さ c' }
          ],
          vline: { x: 1, color: COL.dim, label: 'r = rs（境界線）' },
          cursors: [{
            color: COL.vel, x: v.r0k, y: h.vesc / P.m44.c, r: 6,
            name: 'いまの r₀', lx: 10, ly: -10, align: 'left'
          }]
        };
      },
      fml: function (v) {
        var h = m44BH(v);
        return [
          'v_{\\text{脱出}} = \\sqrt{\\dfrac{2GM}{r}} = c \\;\\Rightarrow\\; r_s = \\dfrac{2GM}{c^2}',
          'M = 10^{' + fmt(v.mexp, 1) + '}M_\\odot \\;\\Rightarrow\\; r_s = ' + fmtE(h.rs, 3) + '\\,\\mathrm{km}',
          'r_0 = ' + fmt(v.r0k, 1) + 'r_s \\;\\Rightarrow\\; v_{\\text{脱出}} = ' +
          fmt(h.vesc / P.m44.c, 3) + 'c\\;(' + (h.out ? '\\text{光は出ていける}' : '\\text{光でも出られない}') + ')'
        ];
      }
    },
    {
      key: 'rot', short: '$v$–$r$ 図（回転曲線）', open: true, H: 250,
      title: '$v$–$r$ 図（銀河の回転曲線）　※ 外側が落ちないのがダークマターの証拠',
      when: function (v) { return v.topic === 2; },
      custom: function (v) {
        var i, a = [], b = [];
        for (i = 0; i <= 160; i++) {
          var r = 0.4 + (25 - 0.4) * i / 160;
          a.push([r, P.m44.vRot(r, 0)]);
          b.push([r, P.m44.vRot(r, v.kdm)]);
        }
        return {
          xmin: 0, xmax: 25, ymin: 0, ymax: 340,
          xlabel: 'r [kpc]', ylabel: 'v [km/s]', legend: true,
          series: [
            { color: COL.orbit, width: 2.2, dash: [6, 4], pts: a, name: '見える星だけ（予想）' },
            { color: COL.bound, width: 2.6, pts: b, name: 'ダークマターを入れると' }
          ],
          vline: { x: v.rk, color: COL.vel, label: 'いまの r = ' + fmt(v.rk, 0) + ' kpc' },
          cursors: [
            { color: COL.bound, x: v.rk, y: P.m44.vRot(v.rk, v.kdm), r: 6,
              name: fmt(P.m44.vRot(v.rk, v.kdm), 0) + ' km/s', lx: 10, ly: -10, align: 'left' },
            { color: COL.orbit, x: v.rk, y: P.m44.vRot(v.rk, 0), r: 5,
              name: fmt(P.m44.vRot(v.rk, 0), 0) + ' km/s', lx: 10, ly: 14, align: 'left' }
          ]
        };
      },
      fml: function (v) {
        return [
          '\\dfrac{mv^2}{r} = G\\dfrac{Mm}{r^2} \\;\\Rightarrow\\; v = \\sqrt{\\dfrac{GM(<r)}{r}}',
          'M(<r) = M_{\\text{見える}} + M_{\\text{ダーク}} \\;(\\text{ダークは外まで広がる})',
          'r = ' + fmt(v.rk, 0) + '\\,\\mathrm{kpc}:\\; v = ' + fmt(P.m44.vRot(v.rk, v.kdm), 0) +
          '\\,\\mathrm{km/s}\\;(\\text{見える星だけなら } ' + fmt(P.m44.vRot(v.rk, 0), 0) + ')'
        ];
      }
    },
    {
      key: 'uni', short: '$a$–$t$ 図（宇宙の大きさ）', open: true, H: 250,
      title: '$a$–$t$ 図（宇宙の大きさ）　※ 投げ上げたボールの $y$–$t$ 図とそっくり',
      when: function (v) { return v.topic === 3; },
      custom: function (v) {
        var tH = P.m44.tH();
        function curve(Om, tmax) {
          var i, pts = [];
          for (i = 0; i <= 220; i++) {
            var tt = tmax * i / 220;
            pts.push([tt, P.m44.aOf(Om, tt / tH)]);
          }
          return pts;
        }
        var teNow = DEFS['m4-4'].tEnd(v);
        var tmax = Math.max(teNow, 1200);
        return {
          xmin: 0, xmax: tmax, ymin: 0, ymax: 3.2,
          xlabel: 't [億年]', ylabel: 'a（いまの宇宙を1とした大きさ）', legend: true,
          series: [
            { color: COL.hyper, width: 2.0, dash: [5, 4], pts: curve(0.3, tmax), name: 'Ω=0.3（E>0 永遠に膨張）' },
            { color: COL.para, width: 2.0, dash: [7, 4], pts: curve(1.0, tmax), name: 'Ω=1（E=0 ぎりぎり）' },
            { color: COL.bound, width: 2.6, pts: curve(v.om, tmax), name: 'いまの Ω=' + fmt(v.om, 2) }
          ],
          cursors: [{
            color: COL.vel, x: 0, y: 1, r: 5, name: '', lx: 0, ly: 0, align: 'left'
          }]
        };
      },
      fml: function (v) {
        var tH = P.m44.tH(), te = P.m44.tauEnd(v.om);
        return [
          'E = \\dfrac{1}{2}mv^2 - \\dfrac{GMm}{r};(v = Hr,; M = \\tfrac{4}{3}\\pi\\rho r^3)' +
          '\\;\\Rightarrow\\; \\dfrac{E}{m} = \\dfrac{1}{2}H^2r^2(1-\\Omega)',
          '\\Omega = ' + fmt(v.om, 2) + '\\;\\Rightarrow\\; E' +
          (v.om < 1 ? '>0\\;(\\text{永遠に膨張})' : (v.om > 1 ? '<0\\;(\\text{いつか縮む})' : '=0')),
          isFinite(te)
            ? '\\text{いちばん大きくなる } a = ' + fmt(P.m44.aMax(v.om), 2) +
            ',\\;\\text{つぶれるまで } ' + fmt(te * tH, 0) + '\\,\\text{億年}'
            : '\\text{いまの宇宙の年齢（この式では）} ' + fmt(P.m44.tau0(v.om) * tH, 0) + '\\,\\text{億年}'
        ];
      }
    }
  ],
  draw: function (ctx, s, t, W, H) {
    var v = V(s);
    /* 背景は宇宙（濃紺）。文字は明るい色＋濃いハローで読めるようにする */
    var HALO = 'rgba(13,22,38,.92)';
    ctx.save(); ctx.fillStyle = '#0d1626'; ctx.fillRect(0, 0, W, H); ctx.restore();
    starField(ctx, 0, 0, W, H, 130, 20260827);
    label(ctx, '【' + '①②③'.charAt(v.topic - 1) + '】' + M44_TOPIC[v.topic], 10, 16,
      { align: 'left', size: 12.5, bold: true, color: '#cfe0f0', haloColor: HALO });

    if (v.topic === 1) { m44DrawBH(ctx, v, t, W, H, HALO); }
    else if (v.topic === 2) { m44DrawDM(ctx, v, t, W, H, HALO); }
    else { m44DrawUni(ctx, v, t, W, H, HALO); }

    label(ctx, 't = ' + DEFS['m4-4'].tFmt(t, v), W - 10, 16,
      { align: 'right', size: 13, bold: true, color: '#e8eef4', haloColor: HALO });
  },
  result: function (v) {
    var items, note;
    if (v.topic === 1) {
      var h = m44BH(v);
      items = [
        resItem('星の質量 $M$', fmtE(h.Ms, 2) + ' 太陽質量'),
        resItem('シュワルツシルト半径 $r_s$', fmtE(h.rs, 3) + ' km', true),
        resItem('光を出す場所 $r_0$', fmt(v.r0k, 1) + ' rs（' + fmtE(h.r0, 3) + ' km）'),
        resItem('そこでの脱出速度', fmt(h.vesc / P.m44.c, 3) + ' × 光の速さ'),
        resItem('光の粒の $E/m$', fmtE(h.Em, 3) + ' km²/s²'),
        resItem('結果', h.out ? '出ていける（E ≥ 0）' : '戻ってくる（E < 0）', true),
        resItem('太陽の $r_s$', '2.953 km'),
        resItem('地球の $r_s$', '8.87 mm')
      ];
      note = h.out
        ? '<b>$r_0>r_s$ なので、光は出ていけます。</b>' +
          '$r_0$ を 1 より小さくすると、$E<0$ になって光の粒でさえ戻ってきます。'
        : '<b>$r_0<r_s$：光の粒でさえ、$E<0$ で戻ってきてしまいます。</b>' +
          'これが「光さえ出られない」＝ブラックホールということです' +
          '（本当は一般相対性理論の話ですが、$r_s$ の式は高校の式から出せます）。<br>' +
          '<b>時間バーの終わりは、光の粒が中心まで落ちきったところ</b>です。' +
          'そこで再生は止まります。';
    } else if (v.topic === 2) {
      var vd = P.m44.vRot(v.rk, v.kdm), v0 = P.m44.vRot(v.rk, 0);
      items = [
        resItem('半径 $r$', fmt(v.rk, 0) + ' kpc'),
        resItem('見える星だけの $v$', fmt(v0, 0) + ' km/s'),
        resItem('ダークマター込みの $v$', fmt(vd, 0) + ' km/s', true),
        resItem('1周する時間（込み）', fmt(P.m44.Trot(v.rk, v.kdm), 2) + ' 億年'),
        resItem('1周する時間（見える星だけ）', fmt(P.m44.Trot(v.rk, 0), 2) + ' 億年'),
        resItem('内側の質量（見える）', fmt(P.m44.Mvis(v.rk), 1) + ' ×10¹⁰ 太陽質量'),
        resItem('内側の質量（ダーク）', fmt(P.m44.Mdm(v.rk, v.kdm), 1) + ' ×10¹⁰ 太陽質量', true)
      ];
      note = '<b>$v=\\sqrt{GM(<r)/r}$ を逆に読むと、$v$ から $M$ が分かります。</b>' +
        '外側でも $v$ が落ちない＝<b>外側にも質量がある</b>ということ。' +
        '「ダークマターの量」を 0 にして、外の星がどれだけ遅くなるか見比べてください。';
    } else {
      var tH = P.m44.tH(), te = P.m44.tauEnd(v.om);
      items = [
        resItem('$\\Omega$（中身の濃さ）', fmt(v.om, 2)),
        resItem('宇宙の力学的エネルギー $E$', v.om < 1 ? '正（E > 0）' : (v.om > 1 ? '負（E < 0）' : '0'), true),
        resItem('運命', v.om < 1 ? '永遠に広がる' : (v.om > 1 ? 'いつか縮む（ビッグクランチ）' : 'ぎりぎり広がる'), true),
        resItem('この式での宇宙の年齢', fmt(P.m44.tau0(v.om) * tH, 0) + ' 億年'),
        resItem('ハッブル時間 $1/H_0$', fmt(tH, 0) + ' 億年')
      ];
      if (isFinite(te)) {
        items.push(resItem('いちばん大きくなる $a$', fmt(P.m44.aMax(v.om), 2) + ' 倍'));
        items.push(resItem('つぶれるまで', fmt(te * tH, 0) + ' 億年', true));
      }
      note = '<b>$E$ の符号が、そのまま宇宙の運命です。</b>' +
        'まっすぐ投げ上げたボールが、速ければ二度と戻らず、おそければ落ちてくるのと同じ。<br>' +
        '<span class="mini">※ ここでは「物質だけの宇宙」で計算しています。' +
        '本当の宇宙にはダークエネルギーがあるため、実際の年齢（138億年）とはずれます。</span>';
    }
    return { items: items, note: note };
  },
  info: function (s, t) {
    var v = V(s);
    if (v.topic === 1) {
      var h = m44BH(v);
      return [
        ['$r_s = 2GM/c^2$', fmtE(h.rs, 3) + ' km'],
        ['いまの距離 $r$', fmt(m44BHr(h, t) / h.rs, 2) + ' rs'],
        ['そこでの脱出速度', fmt(h.vesc / P.m44.c, 3) + ' c（光の速さ）']
      ];
    }
    if (v.topic === 2) {
      return [
        ['半径 $r$', fmt(v.rk, 0) + ' kpc'],
        ['$v$（ダーク込み）', fmt(P.m44.vRot(v.rk, v.kdm), 0) + ' km/s'],
        ['$v$（見える星だけ）', fmt(P.m44.vRot(v.rk, 0), 0) + ' km/s']
      ];
    }
    return [
      ['$\\Omega$', fmt(v.om, 2)],
      ['宇宙の大きさ $a$', fmt(P.m44.aOf(v.om, t / P.m44.tH()), 3)],
      ['経過した時間', fmt(t, 0) + ' 億年']
    ];
  },
  eq: function (s) {
    var v = V(s);
    if (v.topic === 1) return 'v_{\\text{脱出}} = \\sqrt{\\dfrac{2GM}{r}} = c \\;\\Rightarrow\\; r_s = \\dfrac{2GM}{c^2}';
    if (v.topic === 2) return '\\dfrac{mv^2}{r} = G\\dfrac{Mm}{r^2} \\;\\Rightarrow\\; v = \\sqrt{\\dfrac{GM(<r)}{r}}';
    return 'E = \\dfrac{1}{2}mv^2 - \\dfrac{GMm}{r} \\;\\Rightarrow\\; ' +
      'E>0\\,\\text{永遠に膨張}\\;/\\;E<0\\,\\text{いつか収縮}';
  }
};

/* ===== ① ブラックホールの境界線 =====
   まん中に星（またはブラックホール）、そのまわりに rs の円。
   そこから「光の粒」をまっすぐ外向きに c で打ち出して、
   出ていけるか・戻ってくるかを見せる（ニュートン力学だけの話）。 */
function m44DrawBH(ctx, v, t, W, H, HALO) {
  var h = m44BH(v);
  var cx = W / 2, cy = 224;
  /* ★1 rs の px は、質量によって変える★（先生の指摘）
     光が出られるかどうかは r₀/r_s だけで決まるので、
     r_s を1目もりにすると M を変えても形がまったく変わらない（物理としては正しい）。
     でもそれでは「何も起こらない」ように見えるので、
     r_s の px を log(M) でゆっくり大きくして、事象の地平面の大きさが変わるようにした。
     ★本当は r_s は M に比例する（1000倍なら1000倍）。ここでは対数で誇張している★
     ——このことは図の中に必ず書く。下の「大きさ比べ」のものさしが本当の比例関係。 */
  var SC = clamp(19 + 3.4 * (Math.log(Math.max(1, h.Ms)) / Math.LN10), 19, 52);
  var r = m44BHr(h, t) / h.rs;              /* rs を1とした、いまの距離 */

  /* rs の円（事象の地平面）＝ まっ黒な円 */
  ctx.save();
  ctx.fillStyle = '#000'; ctx.strokeStyle = '#ff9a3c'; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.arc(cx, cy, SC, 0, TAU); ctx.fill(); ctx.stroke();
  ctx.restore();
  label(ctx, 'r_s = ' + fmtE(h.rs, 2) + ' km', cx, cy + SC + 15,
    { size: 11, bold: true, color: '#ff9a3c', haloColor: HALO });
  label(ctx, '境界線（事象の地平面）', cx, cy + SC + 31,
    { size: 10, color: '#c9a06a', haloColor: HALO });
  label(ctx, '※ 円の大きさは、変化が見えるように対数で誇張（本当は r_s は M に比例）',
    cx, cy + SC + 45, { size: 8.5, color: '#7d8fa5', haloColor: HALO });

  /* めやすの円（2rs・3rs） */
  [2, 3].forEach(function (k) {
    ctx.save();
    ctx.strokeStyle = 'rgba(150,175,200,.45)'; ctx.lineWidth = 1; ctx.setLineDash([4, 4]);
    ctx.beginPath(); ctx.arc(cx, cy, SC * k, 0, TAU); ctx.stroke();
    ctx.restore();
    label(ctx, k + ' r_s', cx + SC * k, cy - 8,
      { size: 9.5, color: '#8ea3b8', haloColor: HALO });
  });

  /* 打ち出したところ */
  var y0 = cy - SC * v.r0k;
  ctx.save();
  ctx.strokeStyle = '#9fc3e0'; ctx.lineWidth = 1.2; ctx.setLineDash([3, 3]);
  ctx.beginPath(); ctx.moveTo(cx - 26, y0); ctx.lineTo(cx + 26, y0); ctx.stroke();
  ctx.restore();
  label(ctx, 'r₀ = ' + fmt(v.r0k, 1) + ' r_s から、光を真上へ', cx + 32, y0,
    { size: 10, color: '#9fc3e0', align: 'left', haloColor: HALO });

  /* 光の粒（黄色い点）。行きは上へ、戻りは下へ */
  var py = cy - SC * Math.min(r, (cy - 26) / SC);
  /* 通ってきた道（先に描いて、粒と矢印を上にのせる） */
  ctx.save();
  ctx.strokeStyle = 'rgba(255,226,122,.55)'; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(cx, y0); ctx.lineTo(cx, py); ctx.stroke();
  ctx.restore();
  /* ★光の粒の速度ベクトル★（先生の指示）
     「打ち出している」ことと「重力に引かれて遅くなる」ことを、矢印で見せる。
     速さは力学的エネルギー保存から出す： v² = 2(E/m + GM/r)。
     打ち出した瞬間は v = c（光の速さ）なので、矢印はいちばん長い。 */
  (function () {
    var rr = Math.max(1e-9, r * h.rs);
    var vv = Math.sqrt(Math.max(0, 2 * (h.Em + h.GM / rr)));
    /* 上がっているか下がっているか（少し前の位置と比べる） */
    var dt = Math.max(1e-12, DEFS['m4-4'].tEnd(v) * 1e-3);
    var up = (t <= dt) ? true : (m44BHr(h, t) >= m44BHr(h, t - dt));
    var sc = 46 / P.m44.c;                 /* 光の速さ c で 46 px */
    if (vv * sc > 3) {
      velArrow(ctx, cx, py, 0, (up ? 1 : -1) * vv, sc, null);
      label(ctx, 'v = ' + fmt(vv / P.m44.c, 2) + ' c',
        cx + 14, py - (up ? 1 : -1) * (vv * sc * 0.55),
        { size: 10.5, bold: true, color: '#9fc3e0', align: 'left', haloColor: HALO });
    }
  })();
  ctx.save();
  ctx.fillStyle = '#ffe27a'; ctx.shadowColor = '#ffd24a'; ctx.shadowBlur = 10;
  ctx.beginPath(); ctx.arc(cx, py, 5, 0, TAU); ctx.fill();
  ctx.restore();
  label(ctx, '光の粒', cx - 12, py - 12,
    { size: 10.5, bold: true, color: '#ffe27a', align: 'right', haloColor: HALO });
  /* 中心まで落ちきったら、そのことを書く（時間バーもここで止まる）。
     ★「境界線（事象の地平面）」の文字より下に置くこと★（重なると読めない） */
  if (!h.out && r < 0.02 * v.r0k) {
    label(ctx, '中心まで落ちきりました（もう出てこられません）', cx, cy + SC + 64,
      { size: 11.5, bold: true, color: '#ff8b7a', haloColor: HALO });
  }

  label(ctx, h.out
    ? 'r₀ > r_s：E ≥ 0 なので、光は出ていける'
    : 'r₀ < r_s：E < 0 なので、光の粒でさえ 戻ってきてしまう',
    W / 2, H - 26, { size: 12, bold: true,
      color: h.out ? '#8fe0a8' : '#ff8b7a', haloColor: HALO });
  label(ctx, '※ 本当は一般相対性理論の話。ここは「脱出速度 = c」というニュートン流の見方です',
    W / 2, H - 9, { size: 9.5, color: '#8ea3b8', haloColor: HALO });
  label(ctx, 'M = ' + fmtE(h.Ms, 2) + ' 太陽質量', 10, 34,
    { align: 'left', size: 11, bold: true, color: '#cfe0f0', haloColor: HALO });
  label(ctx, '青い矢印＝光の粒の速度 v。打ち出す瞬間は v = c（光の速さ）で、',
    10, 51, { align: 'left', size: 9.5, color: '#9fc3e0', haloColor: HALO });
  label(ctx, '上がるほど重力に引かれて遅くなる（v² = 2(E/m + GM/r)）',
    10, 64, { align: 'left', size: 9.5, color: '#9fc3e0', haloColor: HALO });

  /* ★大きさ比べの「ものさし」★（先生の指摘「質量を変えても何も起こらない」）
     上の絵は r_s を1目もりにしてあるので、M を変えても形は変わらない。
     でも r_s の「実際の長さ」は M に比例して変わる。それを、
     地球や太陽の大きさと比べられる対数のものさしの上に置いて見せる。 */
  (function () {
    var x0 = 62, x1 = W - 42, yb = 404;
    var LMIN = 0, LMAX = 10;                /* 1 km 〜 10¹⁰ km */
    function X(km) {
      var L = Math.log(Math.max(1e-6, km)) / Math.LN10;
      return x0 + (clamp(L, LMIN, LMAX) - LMIN) / (LMAX - LMIN) * (x1 - x0);
    }
    ctx.save();
    ctx.strokeStyle = '#8ea3b8'; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(x0, yb); ctx.lineTo(x1, yb); ctx.stroke();
    ctx.lineWidth = 1;
    for (var k = 0; k <= 10; k++) {
      var xx = x0 + k / 10 * (x1 - x0);
      ctx.beginPath(); ctx.moveTo(xx, yb - 3); ctx.lineTo(xx, yb + 3); ctx.stroke();
    }
    ctx.restore();
    label(ctx, '大きさ比べ（対数のものさし）', x0 - 4, yb - 26,
      { size: 9.5, color: '#8ea3b8', align: 'left', haloColor: HALO });
    label(ctx, '1 km', x0, yb + 12, { size: 8.5, color: '#8ea3b8', haloColor: HALO });
    label(ctx, '10¹⁰ km', x1, yb + 12, { size: 8.5, color: '#8ea3b8', haloColor: HALO });
    [[6371, '地球の半径'], [695700, '太陽の半径'], [1.496e8, '1 AU']].forEach(function (m2) {
      var xx = X(m2[0]);
      ctx.save();
      ctx.strokeStyle = '#6f8296'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(xx, yb - 6); ctx.lineTo(xx, yb + 6); ctx.stroke();
      ctx.restore();
      label(ctx, m2[1], xx, yb + 14, { size: 8.5, color: '#93a8c8', haloColor: HALO });
    });
    /* r_s の位置（M を変えると、ここが動く） */
    var xr = X(h.rs);
    ctx.save();
    ctx.strokeStyle = '#ff9a3c'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(xr, yb - 11); ctx.lineTo(xr, yb + 11); ctx.stroke();
    ctx.fillStyle = '#ff9a3c';
    ctx.beginPath(); ctx.arc(xr, yb, 3.6, 0, TAU); ctx.fill();
    ctx.restore();
    label(ctx, 'r_s = ' + fmtE(h.rs, 2) + ' km', clamp(xr, x0 + 40, x1 - 40), yb - 14,
      { size: 10, bold: true, color: '#ff9a3c', haloColor: HALO });
  })();
}

/* ===== ② ダークマターの正体 =====
   銀河を真上から見た図。同じ半径に2つの星を置き、
   「見える星だけで計算した速さ」と「ダークマターを入れた速さ」で回す。
   ダークマターがあるほうが速いので、どんどん先へ進んでいく。 */
function m44DrawDM(ctx, v, t, W, H, HALO) {
  var cx = W / 2, cy = H / 2 + 10;
  /* ★縮尺は「いま見ている半径」に合わせる★
     いつも 24 kpc に合わせると、r が小さいときに絵がちいさくなりすぎるため。 */
  var RMAXk = Math.max(14, v.rk * 1.5);
  var SC = 190 / RMAXk;                     /* 1 kpc あたりの px */
  var i;
  /* 銀河（中心が明るい円盤） */
  ctx.save();
  var GR = P.m44.RB * SC * 2.6;
  var g = ctx.createRadialGradient(cx, cy, 2, cx, cy, GR);
  g.addColorStop(0, 'rgba(255,236,190,.95)');
  g.addColorStop(0.25, 'rgba(255,214,140,.35)');
  g.addColorStop(1, 'rgba(255,214,140,0)');
  ctx.fillStyle = g;
  ctx.beginPath(); ctx.arc(cx, cy, GR, 0, TAU); ctx.fill();
  ctx.restore();
  /* ダークマターのハロー（見えないので、うすい輪であらわす） */
  if (v.kdm > 0.001) {
    ctx.save();
    ctx.strokeStyle = 'rgba(150,175,210,' + fmt(0.10 + 0.10 * v.kdm, 2) + ')';
    ctx.lineWidth = 1.2;
    for (i = 1; i <= 5; i++) {
      ctx.beginPath(); ctx.arc(cx, cy, RMAXk * SC * i / 5, 0, TAU); ctx.stroke();
    }
    ctx.restore();
    label(ctx, 'ダークマターのハロー（目に見えない）', cx, cy - RMAXk * SC - 10,
      { size: 10, color: '#93a8c8', haloColor: HALO });
  }
  /* 星の通り道 */
  var R = v.rk * SC;
  ctx.save();
  ctx.strokeStyle = 'rgba(160,180,200,.5)'; ctx.lineWidth = 1; ctx.setLineDash([4, 4]);
  ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.stroke();
  ctx.restore();

  function star(kdm, col, name) {
    var vv = P.m44.vRot(v.rk, kdm);
    var w = vv / (v.rk * P.m44.KPC) * (3.15576e7 * 1e8);   /* rad/億年 */
    var th = -w * t;
    var cs = Math.cos(th), sn = Math.sin(th);
    var px = cx + R * cs, py = cy + R * sn;
    /* 速度は動径に垂直（反時計まわり）。画面の y は下向きなので符号に注意 */
    if (vv > 1) velArrow(ctx, px, py, vv * sn, vv * cs, 40 / 320, null);
    planetShape(ctx, px, py, 5, col);
    /* ★名前は「中心と反対がわ」に出す★ 中心の名前とぶつからないようにするため */
    label(ctx, name, px + cs * 22, py + sn * 22,
      { size: 10, bold: true, color: col, haloColor: HALO });
    return { x: px, y: py, th: th, v: vv };
  }
  var sA = star(v.kdm, '#7fe0a0', 'ダークマター込み');
  var sB = star(0, '#c9b98a', '見える星だけ');

  sunShape(ctx, cx, cy, 7);
  label(ctx, '銀河の中心', cx, cy + 21,
    { size: 9.5, color: COL.sun, bold: true, haloColor: HALO });
  label(ctx, 'r = ' + fmt(v.rk, 0) + ' kpc', 10, 34,
    { align: 'left', size: 11, bold: true, color: '#cfe0f0', haloColor: HALO });
  label(ctx, 'ダークマター込み：v = ' + fmt(sA.v, 0) + ' km/s', 10, 52,
    { align: 'left', size: 11, bold: true, color: '#7fe0a0', haloColor: HALO });
  label(ctx, '見える星だけ　：v = ' + fmt(sB.v, 0) + ' km/s', 10, 70,
    { align: 'left', size: 11, bold: true, color: '#c9b98a', haloColor: HALO });
  label(ctx, v.kdm < 0.05
    ? 'ダークマターなし：外の星はゆっくり — でも観測はそうなっていない'
    : '同じ半径なのに、ダークマターがあるほうが速い（＝観測に合う）',
    W / 2, H - 26, { size: 11.5, bold: true,
      color: v.kdm < 0.05 ? '#ff8b7a' : '#8fe0a8', haloColor: HALO });
  label(ctx, '※ 1 kpc ＝ 約 3260 光年。太陽は中心から約 8 kpc のところ',
    W / 2, H - 9, { size: 9.5, color: '#8ea3b8', haloColor: HALO });
}

/* ===== ③ 宇宙の運命 =====
   「いまの宇宙を 1 とした大きさ a」の円をかき、その上に銀河を並べる。
   Ω>1 なら、ふくらんだあとに縮んでいく。 */
function m44DrawUni(ctx, v, t, W, H, HALO) {
  var cx = W / 2, cy = H / 2 + 12;
  var tH = P.m44.tH();
  var a = P.m44.aOf(v.om, t / tH);
  var SCa = 118;                            /* a = 1 を 118 px にする */
  /* ★頭打ちにしない★（先生の指摘）
     もとは H/2+40 で止めていたので、Ω = 1.15 のように大きくふくらむ宇宙では
     「ある大きさで膨張が止まった」ように見えてしまった。
     いまは画面の外まで素直に広がる（canvas が勝手に切ってくれる）。 */
  var Rpx = Math.min(a * SCa, 20000);
  var i;
  /* いまの宇宙（a = 1）のめやす */
  ctx.save();
  ctx.strokeStyle = 'rgba(160,180,205,.55)'; ctx.lineWidth = 1.2; ctx.setLineDash([5, 4]);
  ctx.beginPath(); ctx.arc(cx, cy, SCa, 0, TAU); ctx.stroke();
  ctx.restore();
  label(ctx, 'いまの宇宙（a = 1）', cx, cy - SCa - 9,
    { size: 10, color: '#9fb4cc', haloColor: HALO });

  /* いまの大きさ。少し前と比べて「広がっている／縮んでいる」を出す */
  var aPrev = P.m44.aOf(v.om, Math.max(0, t - tH * 0.002) / tH);
  var grow = a >= aPrev;
  ctx.save();
  ctx.strokeStyle = v.om > 1 ? '#ffb36b' : '#7fe0a0'; ctx.lineWidth = 2.4;
  ctx.beginPath(); ctx.arc(cx, cy, Math.max(2, Rpx), 0, TAU); ctx.stroke();
  ctx.restore();
  /* 銀河（円の上に並べる）。画面の外に出たら描かない */
  var away = Rpx > 300;
  if (!away) {
    for (i = 0; i < 12; i++) {
      var th = TAU * i / 12 + 0.13;
      planetShape(ctx, cx + Rpx * Math.cos(th), cy + Rpx * Math.sin(th), 3.6, '#dfe8f2');
    }
  }
  planetShape(ctx, cx, cy, 3.6, '#dfe8f2');
  /* ★画面からはみ出したときは、ふちに矢印を出して
     「まだ広がっている／縮んでいる」を見せる★
     （矢印がないと、ただの空っぽの画面になって、止まったように見える） */
  if (away) {
    var col = v.om > 1 ? '#ffb36b' : '#7fe0a0';
    for (i = 0; i < 8; i++) {
      var a2 = TAU * i / 8 + 0.2;
      var ux = Math.cos(a2), uy = Math.sin(a2);
      var r1 = 152, r2 = 192;
      if (!grow) { var tmp = r1; r1 = r2; r2 = tmp; }
      ctx.save();
      ctx.strokeStyle = col; ctx.lineWidth = 2.4; ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(cx + ux * r1, cy + uy * r1);
      ctx.lineTo(cx + ux * (r1 + (r2 - r1) * 0.7), cy + uy * (r1 + (r2 - r1) * 0.7));
      ctx.stroke();
      ctx.restore();
      var sg = grow ? 1 : -1;
      arrowHead(ctx, cx + ux * r2, cy + uy * r2, ux * sg, uy * sg, col);
    }
    label(ctx, grow ? '宇宙は画面の外まで広がっています' : '宇宙は画面の外から縮んできています',
      cx, cy - 30, { size: 11.5, bold: true, color: col, haloColor: HALO });
  }

  label(ctx, 'a = ' + fmt(a, 3), cx, cy + 4,
    { size: 12, bold: true, color: '#e8eef4', haloColor: HALO });
  label(ctx, 'Ω = ' + fmt(v.om, 2) + '（' +
    (v.om < 1 ? 'E > 0：永遠に広がる' : (v.om > 1 ? 'E < 0：いつか縮む' : 'E = 0：ぎりぎり')) + '）',
    10, 34, { align: 'left', size: 11.5, bold: true,
      color: v.om < 1 ? '#7fe0a0' : (v.om > 1 ? '#ffb36b' : '#ffe27a'), haloColor: HALO });
  var te = P.m44.tauEnd(v.om);
  label(ctx, isFinite(te)
    ? 'いちばん大きくなる a = ' + fmt(P.m44.aMax(v.om), 2) + '　つぶれるまで ' +
      fmt(te * tH, 0) + ' 億年'
    : 'この式での宇宙の年齢 ' + fmt(P.m44.tau0(v.om) * tH, 0) + ' 億年（a = 1 になるまで）',
    10, 52, { align: 'left', size: 10.5, color: '#9fb4cc', haloColor: HALO });
  label(ctx, grow ? '広がっている' : '縮んでいる（このままビッグクランチへ）', W / 2, H - 26,
    { size: 11.5, bold: true, color: grow ? '#cfe0f0' : '#ffb36b', haloColor: HALO });
  label(ctx, '※ 物質だけの宇宙で計算。本当の宇宙にはダークエネルギーがあります',
    W / 2, H - 9, { size: 9.5, color: '#8ea3b8', haloColor: HALO });
}

/* ============================================================
   4-2　地球と人工衛星の太陽まわりの運動（id は m4-5）
   ------------------------------------------------------------
   ★ねらい★
     「人工衛星は地球のまわりを回っている」で終わらせず、
     その地球ごと太陽のまわりを回っていること、
     さらに地球自身が回っている（自転）ことを、1つの時計で同時に見せる。
   ★3つの図はどれも縮尺が違う★ので、必ず画面に「1目もり何 km か」を書く。
   ★静止衛星は自転とぴったり同じ周期★なので、地上の目印の真上から動かない。
     これを目で見せるのが、このシミュレーションのいちばんの見どころ。
   ============================================================ */
var M45_SATS = ['iss', 'gps', 'himawari'];      /* 【3】に出す人工衛星 */

/* ===== 3つの図の並べ方 =====
   ★1つの図の大きさは、並べ方が変わっても同じ（336 × 306 px）★
   広い画面（タブレット・パソコン）… よこ一列（3列 × 1段）
   せまい画面（スマホ）………………… たて一列（1列 × 3段）
   よこ一列のままスマホで見ると、キャンバスが 342 px まで縮んで
   中の文字が 3 px ほどになり、まったく読めなくなる。 */
var M45_PW = 336;      /* 1つの図のはば */
var M45_PH = 306;      /* 1つの図の高さ */
var M45_HEAD = 26;     /* いちばん上の、時計を書く帯 */
/* ★3つの図の「中心の高さ」と縮尺は、ここ1か所で決める★
   図を描くかんすう（m45Panel1〜3）だけでなく、
   「拡大していることを示す線」（m45ZoomLines）からも使うため。
   ばらばらに書くと、線が地球からずれてしまう。 */
var M45_CY1 = 144, M45_R1 = 68;          /* 【1】中心の高さ／1 AU = 68 px */
var M45_CY2 = 122, M45_SC2 = 82 / 430000; /* 【2】中心の高さ／1 km あたりの px */
var M45_CY3 = 134;                        /* 【3】中心の高さ */
function m45Cols() { return (typeof WINW !== 'undefined' && WINW < 820) ? 1 : 3; }

/* ===== 3つのわくの置きばしょ =====
   返すのは [{ i, x, y, w, h, k }]。i＝どの図か（0〜2）、k＝引きのばす倍率。
   ★s.o.zoom（1〜3）が入っているときは、その図だけを2倍で1つだけ返す★
     右上の拡大スイッチで切りかえる。もう一度押すと 0 に戻って3つ並びにもどる。
   ★cw / ch もこの決めごとに合わせること★（下の cw: / ch: を見よ） */
var M45_PH3 = 262;     /* 下の段（3次元で見る図）の高さ */
var M45_GAP = 30;      /* 1段目と2段目のあいだの「白い帯」（視点のボタンを置く） */
/* 6つのわくの高さ。0〜2＝上から見た図、3〜5＝3次元の図 */
function m45Hs() { return [M45_PH, M45_PH, M45_PH, M45_PH3, M45_PH3, M45_PH3]; }
/* ★わくの外がわは「白い余白」にする★（先生の指示・2026-09-04）
   いちばん上（M45_HEAD）＝＜自転軸の方向から見た様子＞と時計
   1段目と2段目のあいだ（M45_GAP）＝視点をえらぶボタン
   いちばん下（18 px）＝ことわり書き
   星と濃い地の色は「わくの中だけ」。こうすると、どこからどこまでが1つの図か分かる。 */
function m45Frames(s, W) {
  var z = (s && s.o && s.o.zoom) || 0, hs = m45Hs();
  if (z >= 1 && z <= 6) {
    var zi = z - 1;
    return [{
      i: zi, x: 0, y: M45_HEAD + (zi >= 3 ? M45_GAP : 0),
      w: M45_PW * 2, h: hs[zi] * 2, k: 2
    }];
  }
  var COLS = m45Cols(), CW = W / COLS, a = [], i, y = M45_HEAD;
  for (i = 0; i < 6; i++) {
    if (i === 3 && i % COLS === 0) y += M45_GAP;   /* 2段目の前に白い帯を入れる */
    a.push({ i: i, x: (i % COLS) * CW, y: y, w: CW, h: hs[i], k: 1 });
    if (i % COLS === COLS - 1) y += hs[i];
  }
  return a;
}
/* キャンバスぜんたいの高さ（上の帯＋わく＋下のことわり書き） */
function m45CW(s) { return (s && s.o && s.o.zoom) ? M45_PW * 2 : M45_PW * m45Cols(); }
function m45CH(s, v) {
  var W = m45CW(s);
  var fr = m45Frames(s, W), last = fr[fr.length - 1];
  return last.y + last.h + 8 + m45NoteH(s, v || {}, W);
}
/* ===== 図についてのことわり書き（※ の注釈）=====
   ★注釈は図の中に入れない★（先生の指示・2026-09-04）
     図の中に ※ を並べると、動く絵の上に文字がかぶさって、ごちゃごちゃする。
     ことわり書きは全部ここに集めて、いちばん下の白い余白にまとめて書く。
   ★行の折り返しは「文字の幅を見積もって」自分でやる★
     ことわり書きの高さを ch（キャンバスの高さ）で先に決めないといけないが、
     そこでは ctx が使えない。全角 1.0／半角 0.56 の見積もりで折り返し、
     描くときもまったく同じ見積もりを使う（ずれると下がはみ出す）。 */
function m45CharW(ch, size) {
  var c = ch.charCodeAt(0);
  return ((c < 0x2E80 && c !== 0x3000) ? 0.56 : 1.0) * size;
}
function m45WrapLines(txt, maxW, size) {
  var out = [], line = '', w = 0, i, cw;
  var NG = '、。）」』・％，．%),.';              /* 行のあたまに来てほしくない字（半角も） */
  for (i = 0; i < txt.length; i++) {
    cw = m45CharW(txt.charAt(i), size);
    if (w + cw > maxW && line && NG.indexOf(txt.charAt(i)) < 0) { out.push(line); line = ''; w = 0; }
    line += txt.charAt(i); w += cw;
  }
  if (line) out.push(line);
  return out;
}
var M45_NSZ = 9.5;                              /* ことわり書きの字の大きさ */
function m45NoteList(s, v) {
  var a = [];
  /* いま選んでいる「見る時間の長さ」によって変わるものは、いちばん上に濃く出す */
  if (v.span === 4) {
    a.push({ t: '1日ずつ飛ばしています。毎日「夜12時」に見ているので、太陽と観測者の向きは同じ。'
      + '月だけが 1日 13.2° ずつ動きます', hi: '#a06a00' });
  } else if (v.span === 3) {
    a.push({ t: '1年を選ぶと、自転や人工衛星は速すぎて見えないので、'
      + '「人工衛星を表示」と「地上の観測者」のチェックを外しています。'
      + 'チェックを入れれば出ます（自転のようすを見るなら「1日」を選んでください）', hi: '#a06a00' });
  }
  a.push({ t: '3つの図は縮尺がまったく違います。時間 t だけが共通です（動いている時間 t は3つとも同じ）' });
  a.push({ t: '【1】月の距離だけ大げさに描いています（本当は 1 AU の 0.26 %）。回る速さは本当の値です' });
  a.push({ t: '【2】地球だけ大きく描いています（軌道は本当の縮尺）。月の光っている側は いつも太陽のほう（＝月の満ち欠け）' });
  a.push({ t: '【3】約4.6万 km までを描いています。地球の大きさも軌道と同じ縮尺（実物どおり）' });
  a.push({ t: '2段目（3次元）はドラッグで向きを変えられます。【2】月の軌道の面は、黄道面から 5.1° かたむいています' });
  a.push({ t: '【3】1段目は自転軸の方向から、2段目の「真上から見る」は公転軸の方向から見ています。'
    + 'この2つは 23.4° ちがうので、2段目では人工衛星の軌道が少しつぶれた形に見えます'
    + '（回る向きと位置は、1段目とぴったり同じです）' });
  if (!s.o.showS) a.push({ t: '「人工衛星を表示」を入れると、ISS・GPS・ひまわりが出ます' });
  return a;
}
/* ことわり書きを、折り返したあとの行の配列にする。
   ★「※ 」や字下げのぶんも見こんで、はばを引いておくこと★
     引き忘れると行がキャンバスからはみ出し、label のはみ出し防止が働いて
     その行だけ左へずれる（行の頭がそろわなくなる）。太字は 6 % ほど広い。 */
function m45NoteRows(s, v, W) {
  var maxW = W - 46, rows = [];
  m45NoteList(s, v).forEach(function (nt) {
    var sz = M45_NSZ * (nt.hi ? 1.06 : 1);
    m45WrapLines(nt.t, maxW, sz).forEach(function (ln, k) {
      rows.push({ t: (k === 0 ? '※ ' : '　　') + ln, c: nt.hi || COL.sub, b: !!nt.hi });
    });
  });
  return rows;
}
function m45NoteH(s, v, W) { return m45NoteRows(s, v, W).length * 14 + 12; }

/* 「白い帯」（視点のボタンを置くところ）の上端。3次元のわくが出ていないときは null */
function m45GapY(s, W) {
  var fr = m45Frames(s, W), i;
  for (i = 0; i < fr.length; i++) if (fr[i].i >= 3) return fr[i].y - M45_GAP;
  return null;
}
/* 下の段（3次元）が始まる高さ。ここより下をドラッグすると視点が回る */
function m45Drag3dFrom(s) {
  var fr = m45Frames(s, M45_PW * m45Cols()), i;
  for (i = 0; i < fr.length; i++) if (fr[i].i >= 3) return fr[i].y;
  return 1e9;                                   /* 上の図だけのときは回さない */
}

/* ===== 視点をえらぶボタン（白い帯の中）=====
   ★オレンジのボタンではなく、シンプルな四角にする★（先生の指示・2026-09-04）
   オレンジは「状況を変えるボタン」の色。ここは「見る向きを変えるだけ」なので、
   図のわきに静かに置く。いま選んでいるものだけ、うすい青でぬる。 */
var M45_VIEWS = [
  { lab: '軌道を横から見る', az: 0, el: 0 },
  { lab: '斜め上から見る', az: -32, el: 26 },
  { lab: '真上から見る', az: 0, el: 88 }
];
/* ボタンの四角を計算する（描くのにも、当たり判定にも、同じこれを使うこと） */
function m45ViewBtns(ctx, s, W) {
  var gy = m45GapY(s, W);
  if (gy === null) return [];
  var a = [], x = 10, i, bh = 21, by = gy + (M45_GAP - bh) / 2;
  ctx.save(); ctx.font = '10.5px ' + FONT;
  for (i = 0; i < M45_VIEWS.length; i++) {
    var w = Math.round(ctx.measureText(M45_VIEWS[i].lab).width) + 18;
    a.push({ v: M45_VIEWS[i], x: x, y: by, w: w, h: bh });
    x += w + 6;
  }
  ctx.restore();
  return a;
}
function m45DrawViewBtns(ctx, s, W) {
  var bs = m45ViewBtns(ctx, s, W), c = s.cam || { az: 0, el: 0 };
  bs.forEach(function (b) {
    var on = Math.abs(c.az - b.v.az) < 0.5 && Math.abs(c.el - b.v.el) < 0.5;
    ctx.save();
    ctx.fillStyle = on ? '#e2edfa' : '#ffffff';
    ctx.strokeStyle = on ? '#1663b5' : '#c9d4e0';
    ctx.lineWidth = on ? 1.4 : 1;
    if (ctx.roundRect) { ctx.beginPath(); ctx.roundRect(b.x, b.y, b.w, b.h, 5); ctx.fill(); ctx.stroke(); }
    else { ctx.fillRect(b.x, b.y, b.w, b.h); ctx.strokeRect(b.x, b.y, b.w, b.h); }
    ctx.restore();
    label(ctx, b.v.lab, b.x + b.w / 2, b.y + b.h / 2,
      { size: 10.5, bold: on, color: on ? '#12457f' : '#3d566e' });
  });
}

/* ===== 右上の「拡大スイッチ」 =====
   4本の矢印が外へ広がる印（拡大）／内へ集まる印（もとにもどす）。
   ★大きさは、拡大していてもいつも 20 px★（指で押せる大きさを保つため、
     図といっしょに 2 倍にはしない）。当たり判定は m45Hits() が返す。 */
var M45_BTN = 20;
function m45BtnPos(f) { return { x: f.x + f.w - M45_BTN - 7, y: f.y + 7 }; }
function m45ZoomBtn(ctx, x, y, shrink) {
  var S = M45_BTN, cx = x + S / 2, cy = y + S / 2, a = 2.4, b = 7.4;
  ctx.save();
  ctx.fillStyle = 'rgba(255,255,255,.12)';
  ctx.strokeStyle = 'rgba(190,215,240,.7)'; ctx.lineWidth = 1;
  if (ctx.roundRect) { ctx.beginPath(); ctx.roundRect(x, y, S, S, 5); ctx.fill(); ctx.stroke(); }
  else { ctx.fillRect(x, y, S, S); ctx.strokeRect(x, y, S, S); }
  ctx.strokeStyle = '#dbe8f5'; ctx.lineWidth = 1.7; ctx.lineCap = 'round';
  [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(function (d) {
    var p0 = shrink ? [cx + d[0] * b, cy + d[1] * b] : [cx + d[0] * a, cy + d[1] * a];
    var p1 = shrink ? [cx + d[0] * a, cy + d[1] * a] : [cx + d[0] * b, cy + d[1] * b];
    var ux = p1[0] - p0[0], uy = p1[1] - p0[1], L = Math.hypot(ux, uy) || 1;
    ux /= L; uy /= L;
    ctx.beginPath();
    ctx.moveTo(p0[0], p0[1]); ctx.lineTo(p1[0], p1[1]);
    /* 矢じり（先っぽから、来た向きへ戻る2本のかぎ） */
    ctx.moveTo(p1[0], p1[1]); ctx.lineTo(p1[0] - ux * 4.6, p1[1]);
    ctx.moveTo(p1[0], p1[1]); ctx.lineTo(p1[0], p1[1] - uy * 4.6);
    ctx.stroke();
  });
  ctx.restore();
}

/* ===== 地上の観測者（＝ひまわりの真下）の角 =====
   ★t = 0 で観測者が「夜のまん中」＝夜12時に立つようにそろえてある★（先生の指示）
     地球の真夜中の点は、太陽と反対がわ＝角 thEarth(t)。
     ひまわりの L0 は 40°なので、そのまま使うと t = 0 の観測者は真夜中から 40°ずれる。
     そこで 40°（＝ L0）だけ戻す。こうすると
       ・t = 0 は、どの見方でも「夜12時」
       ・「毎日同じ時間に観測」（1日 86400 秒ずつ飛ばす）では、
         いつまでたっても観測者は夜のまん中にいる
     ということが、図を見ただけで分かる。
   ★観測者とひまわりは必ずこの同じ角で描くこと★
     ずれると「静止衛星は真上から動かない」が崩れて、うそになる。 */
function m45ThObs(t) {
  var geo = m45Sat('himawari');
  return P.m45.thSat(geo, t) - geo.L0 * DEG;
}

/* 図の中と表の中で使う名前。★「ひまわり」だけは（静止衛星）まで書く★（先生の指示）
   ——この補足のいちばんの見どころが「静止衛星」なので、名前だけでそれと分かるようにする。
   ★SATS.short そのものは変えない★（1-3 のグラフの名前にも使っていて、そちらは短いほうがよい） */
function m45Name(x) { return (x.id === 'himawari') ? 'ひまわり（静止衛星）' : x.short; }
function m45Sat(id) {
  var r = null;
  SATS.forEach(function (x) { if (x.id === id) r = x; });
  return r;
}
/* 太陽の方向（地球から見て）。地球は角 thE のところにいるので、太陽は その反対がわ */
function m45SunDir(t) {
  var th = P.m45.thEarth(t) + Math.PI;
  return { x: Math.cos(th), y: Math.sin(th) };
}

DEFS['m4-5'] = {
  /* ★このシムもモード2（万有引力とエネルギー）に置いてある★（先生の指示）
     「補足：ケプラー則の本質」のうしろの補足として読ませたいため。
     並びを決めるのは MODES[1].ids。ファイルの場所とモードは別もの。 */
  id: 'm4-5', mode: 2, tab: '補足：地球と月の太陽まわりの運動', read: true,
  legendKeys: ['vel', 'dim', 'sun', 'orbit'],
  title: '補足：地球と月の太陽まわりの運動　—　多重回転',
  sub: '人工衛星は地球のまわりを回っています。でも、その<b>地球ごと太陽のまわりを回って</b>います。' +
    'しかも<b>地球自身も回っています（自転）</b>。<br>' +
    '3つの図は<b>同じ時計</b>で動いています（縮尺だけが違います）。' +
    '上のオレンジのボタンで<b>見る時間の長さ</b>を変えて、' +
    '「どれがどれくらいの速さで回っているのか」をつかんでください。<br>' +
    '<b>下の段は同じものを3次元にした図</b>です。はじめは<b>軌道面を真横から</b>見ています。' +
    '<b>ドラッグするといろいろな向きから見られます</b>（オレンジのボタンでも切りかえられます）。' +
    '<b>地球の自転軸が、公転の面に対して 23.4° かたむいている</b>ことに注目してください。<br>' +
    '<b>それぞれの図の右上のボタン</b>を押すと、その図だけを<b>2倍の大きさ</b>で見られます。<br>' +
    '<b>いちばんの見どころは、いちばん右の図の「ひまわり（静止衛星）」</b>。' +
    '自転とぴったり同じ 23時間56分で回るので、<b>地上の目印の真上から動きません</b>。',
  sideText:
    '<span class="q">【物理ミニコラム】地球と月の太陽まわりの運動　—　多重回転</span>' +
    'いま、みなさんは<b>「何重」の回転の中</b>にいますか？' +
    '地球の自転、公転による位置関係の変化を考えてみましょう。' +
    '<div class="colh">① 地球の公転（1年）</div>' +
    '$\\dfrac{mv^2}{r}=G\\dfrac{M_\\odot m}{r^2}$ から $v=\\sqrt{\\dfrac{GM_\\odot}{r}}$。<br>' +
    '$r=1\\,\\mathrm{AU}=1.496\\times10^8$ km を入れると <b>$v=29.8$ km/s</b>。' +
    '新幹線の 400 倍以上の速さで、いま動いています。' +
    '<div class="colh">② 月・人工衛星の公転</div>' +
    '同じ式の $M_\\odot$ を<b>地球の質量</b>に変えるだけです。' +
    '<ul class="colul">' +
    '<li><b>ISS</b>（高さ 400 km・$a=6371+400$ km）… $T=92$ 分・$v=7.67$ km/s</li>' +
    '<li><b>GPS衛星</b>（$a=26560$ km）… $T=11.97$ 時間・$v=3.87$ km/s</li>' +
    '<li><b>ひまわり</b>（$a=42164$ km）… $T=23$時間$56$分・$v=3.08$ km/s</li>' +
    '<li><b>月</b>（$a=384400$ km）… $T=27.3$ 日・$v=1.02$ km/s</li>' +
    '</ul>' +
    '<b>遠いものほどゆっくり</b>——これがそのままケプラーの第3法則 $T^2/a^3=$ 一定です' +
    '（→ <a href="#m1-4" data-goto="m1-4">1-3 第3法則</a>）。' +
    '<div class="colh">③ 地球の自転（23時間56分）</div>' +
    '自転は万有引力とは関係なく、地球ができたときの<b>回転の勢い（角運動量）が残っている</b>ものです' +
    '（→ <a href="#m4-2" data-goto="m4-2">補足：角運動量の保存</a>）。' +
    '赤道の上の点は <b>秒速 465 m</b> で東へ動いています。' +
    '<div class="colh">■ 静止衛星が「止まって見える」わけ</div>' +
    '$T=2\\pi\\sqrt{\\dfrac{a^3}{GM}}$ が<b>自転の周期 23時間56分と同じになる $a$</b> を解くと<br>' +
    '$a=\\sqrt[3]{\\dfrac{GMT^2}{4\\pi^2}}=42164$ km（地表からの高さ 35786 km）<br>' +
    'この高さの赤道の上を回る衛星は、地上から見ると<b>いつも同じ方角の空に止まって見えます</b>。' +
    'だからテレビや気象の衛星は、みんなこの高さにいます。' +
    '<span class="mini">※ 1日を「24時間」ではなく「23時間56分」でとるのは、' +
    '地球が自転しているあいだに公転でも少し進むため。' +
    '太陽が同じ位置に戻るまで（＝24時間）より、' +
    '星が同じ位置に戻るまで（＝23時間56分）のほうが少し短いのです。</span>' +
    '<div class="colh">■ 「地球ごと動いている」ことの意味</div>' +
    '人工衛星も月も、地球のまわりを回りながら、' +
    '<b>いっしょに秒速 29.8 km で太陽のまわりを進んでいます</b>。' +
    '月が地球のまわりを回る速さ（1.02 km/s）より、' +
    '太陽のまわりを進む速さのほうが<b>30 倍近く大きい</b>ので、' +
    '太陽から見ると月の道すじは輪をえがかず、<b>少しくねくねした円</b>になります。<br>' +
    '「どこから見るか（＝基準にする物）」を変えると、同じ運動がまったく違う形に見える' +
    '——これは力学のいちばん大事な考え方の1つです。' +
    '<div class="colh">■ 多重回転は、まだ続く</div>' +
    'さて、さらに<b>太陽は銀河系（天の川銀河）の中心のまわりを回っています</b>。' +
    '中心には<b>太陽の約 400 万倍の質量をもつ巨大ブラックホール（いて座A*）</b>があり、' +
    '太陽はそこから約 2.6 万光年離れたところを、<b>秒速 約 220 km</b>で、' +
    '<b>2億年あまりかけて1周</b>しています。<br>' +
    '<span class="mini">※ 太陽をこの速さで回らせているのは、中心のブラックホールだけの重力ではなく、' +
    '内側にある星やダークマターを全部合わせた重力です' +
    '（→ <a href="#m4-4" data-goto="m4-4">4-3 ②ダークマター</a>）。</span><br>' +
    'その銀河系そのものも、となりのアンドロメダ銀河などと引き合いながら動いていて……' +
    'と、<b>「多重回転」はまだまだ続きます</b>。',
  /* ★よこ一列の構成★（先生の指示・2026-09-03）
     3つの図をよこに並べ、ミニコラム（sideText）は図の下へ回す（wide: true）。
     1008 = 336 × 3。336 px は、前のたて3段のときの横はば 560 px の 60 %。
     ※ 文字の大きさは前のまま（9.5〜12.5 px）にしてあるので、
       せまくなったぶんは「文を短く・折り返す」ことで合わせている。縮小はしていない。
     ★スマホ（画面 820 px 未満）では たて一列 に戻す★
       よこ一列のままだと、キャンバスが 342 px までちぢめられて
       中の文字が 3 px ほどになり、まったく読めなくなるため。
       図そのもの（336 px 幅の設計）は同じものを使い、並べ方だけ変える。 */
  cw: function (v, s) {
    return (s && s.o.zoom) ? M45_PW * 2 : M45_PW * m45Cols();
  },
  ch: function (v, s) { return m45CH(s, v); },
  /* ★下の段（3次元）はドラッグで見回せる★（先生の指示）
     はじめは真横から（el = 0）＝軌道面を横から見た図。
     drag3dFrom より下だけがドラッグの対象。上の段（真上から見た図）はさわらない。 */
  drag3d: true,
  cam3d: { az: 0, el: 0, zoom: 1 },
  drag3dFrom: function (s) { return m45Drag3dFrom(s); },
  /* ★図の上の「拡大スイッチ」の当たり判定★
     キャンバスの中のボタンなので、ふつうの <button> のようには押せない。
     cvHits が返した四角の中を押したら fn が呼ばれる（80_ui.js の attachCvHits）。 */
  cvHits: function (s, W) {
    var a = m45Frames(s, W).map(function (f) {
      var p = m45BtnPos(f);
      return {
        x: p.x - 3, y: p.y - 3, w: M45_BTN + 6, h: M45_BTN + 6,
        fn: function (st2) { st2.o.zoom = st2.o.zoom ? 0 : (f.i + 1); }
      };
    });
    /* 白い帯の中の「視点をえらぶボタン」。★描くときと同じ計算を使うこと★ */
    var cv = $('mainCv'), ctx = cv && cv.getContext ? cv.getContext('2d') : null;
    if (ctx) {
      m45ViewBtns(ctx, s, W).forEach(function (b) {
        a.push({
          x: b.x, y: b.y, w: b.w, h: b.h,
          fn: function (st2) {
            st2.cam.az = b.v.az; st2.cam.el = b.v.el; st2.cam.zoom = 1;
          }
        });
      });
    }
    return a;
  },
  wide: true,
  noOpenRow: true,
  loop: true,
  /* ★S＝人工衛星（ISS・GPS・ひまわり）／O＝地上の観測者★（先生の指示）
     どちらも はじめは ON。
     - S を OFF … 【2】【3】の人工衛星と、その軌道の点線が消える。
                  「地球の自転」と「太陽の方向」だけをじっくり見られる。
                  ※ 月は人工衛星ではないので、この切りかえでは消えない。
     - O を OFF … 【2】【3】の棒人間と、観測者からひまわりへの視線が消える。
     ★「昼と夜」は切りかえをやめて、いつも出す★（先生の指示・2026-09-03）
       この補足のねらいが「毎日同じ時間に見る」ことなので、
       昼と夜が見えていないと「同じ時間」がどこなのか分からなくなるため。 */
  vis: ['V', 'T', 'S', 'O'],
  visLabel: { V: '速度を表示', T: '軌道を表示', S: '人工衛星を表示', O: '地上の観測者' },
  visDef: { V: false, T: true, S: true, O: true },
  vars: [
    {
      /* オレンジのボタンで切りかえるので、スライドバーとしては出さない */
      k: 'span', label: '見る時間の長さ', unit: '', min: 1, max: 4, step: 1, dec: 0, def: 1,
      when: function () { return false; }
    }
  ],
  mainVars: [],
  topActionsBelow: true,
  topActions: [
    {
      label: '1日（自転が1回）', prim: true, play: true,
      fn: function (s) { s.v.span = 1; },
      is: function (v) { return v.span === 1; }
    },
    {
      /* gap: true ＝ このボタンの前に、すこし広いすき間を置く（先生の指示）
         「1日」｜「1か月・1か月【毎日同じ時間に観測】」｜「1年」の3つのまとまりに見せる。 */
      label: '1か月（月が1周）', prim: true, play: true, gap: true,
      fn: function (s) { s.v.span = 2; },
      is: function (v) { return v.span === 2; }
    },
    {
      /* ★「毎日同じ時間に観測」★（先生の指示・2026-09-03）
         時間を 0.00 日 → 1.00 日 → 2.00 日 … と、太陽日（86400 秒）ちょうどの
         きざみで飛ばす。こうすると観測者と太陽の向きの関係はまったく変わらない
         （＝毎日「同じ時間」に空を見上げている）のに、
         月だけが 1日あたり 13.2° ずつ動いていく——これがこのボタンの見どころ。 */
      label: '1か月（月が1周）<br>【毎日夜12時に観測】', prim: true, play: true, wrap: true,
      fn: function (s) { s.v.span = 4; },
      is: function (v) { return v.span === 4; }
    },
    {
      /* ★1年を選んだら、人工衛星と観測者は自動で消す★（先生の指示・2026-09-04）
         1年ぶんを 20 秒で流すので、周期 92 分の ISS は 8000 回転してしまう。
         残しておいても「ちらつく点」にしかならず、じゃまなだけ。
         代わりに【3】に「速すぎるので表示を消しています」と出す。
         見たい人はチェックを入れれば出る（勝手には戻さない）。
         ★rebuild: true★ チェックボックスの見た目も作り直さないと、
         中身は消えているのにチェックだけ入ったまま、という食いちがいが起きる。 */
      label: '1年（地球が1周）', prim: true, play: true, gap: true, rebuild: true,
      fn: function (s) { s.v.span = 3; s.o.showS = false; s.o.showO = false; },
      is: function (v) { return v.span === 3; }
    }
    /* ★視点のボタン（横から／斜め上／真上）は、ここには置かない★（先生の指示）
       オレンジは「状況を変えるボタン」の色なので、
       「見る向きを変えるだけ」のボタンは、2段目の左上の白い帯にシンプルな形で置く
       （m45ViewBtns / m45DrawViewBtns）。 */
  ],
  tEnd: function (v) { return P.m45.SPAN[v.span]; },
  /* 「毎日同じ時間に観測」だけは、1秒で1日ぶん進む（＝1日1コマのタイムラプス）。
     ふつうの span と同じ 20 秒で1か月にすると、1コマが 0.7 秒しかなく速すぎる。 */
  rate: function (v) {
    return P.m45.SPAN[v.span] / (v.span === 4 ? 28 : 20);
  },
  tFmt: function (t, v) {
    t = P.m45.snap(v, t);
    if (!v || v.span === 1) return fmt(t / 3600, 2) + ' 時間';
    return fmt(t / 86400, v && v.span === 3 ? 0 : 2) + ' 日';
  },
  xlabel: 't',
  sample: function (v, t) {
    t = P.m45.snap(v, t);
    return {
      spin: (P.m45.thSpin(t) / DEG) % 360,
      rev: (P.m45.thEarth(t) / DEG)
    };
  },
  graphs: [],
  draw: function (ctx, s, t, W, H) {
    var v = V(s);
    /* ★「毎日同じ時間に観測」のときは、ここで時間を1日きざみに丸める★
       この1行から下は、3つの図も時計も、丸めたあとの t だけを見る。 */
    t = P.m45.snap(v, t);
    var HALO = 'rgba(13,22,38,.92)';
    /* ★キャンバスぜんたいは白、濃紺と星は「わくの中だけ」★（先生の指示・2026-09-04）
       こうすると、上の帯・段のあいだ・下の帯が「白い余白」になって、
       どこからどこまでが1つの図なのかが、ひと目で分かる。 */
    ctx.save(); ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, W, H); ctx.restore();
    /* ★3つの図は「よこ一列」に並べる★（先生の指示・2026-09-03）
       前はたて3段だったが、それだとタブレットの画面では下の【3】が画面の外に出てしまい、
       3つを見くらべることができなかった。よこに並べれば一度に3つとも目に入る。
       そのぶん1つあたりの横はばは 1/3（前の 560 px → 336 px ＝ 60 %）になるので、
       長い注釈は m45Wrap() で2〜3行に折り返して入れている。 */
    var HEAD = M45_HEAD, HS = m45Hs();
    var FR = m45Frames(s, W);
    FR.forEach(function (f) {
      ctx.save();
      ctx.beginPath(); ctx.rect(f.x, f.y, f.w, f.h); ctx.clip();
      ctx.fillStyle = '#0d1626'; ctx.fillRect(f.x, f.y, f.w, f.h);
      starField(ctx, f.x, f.y, f.w, f.h, 55, 45120 + f.i * 7919);
      ctx.restore();
    });
    /* 0〜2＝上から見た図、3〜5＝3次元（横から見た図）。どちらも 336 px 幅の設計。 */
    function drawFrame(i, ctx2, y1) {
      if (i < 3) [m45Panel1, m45Panel2, m45Panel3][i](ctx2, s, v, t, M45_PW, 0, y1, HALO);
      else m45Panel3D(ctx2, s, v, t, M45_PW, 0, y1, HALO, i - 2);
    }
    /* ★「ここを拡大したのが次の図」の線は、図より先に引く★
       あとから引くと、軌道や文字の上に線が乗ってしまう。
       1つだけ大きくしているとき（拡大スイッチ）は、次の図が無いので引かない。 */
    if (FR.length === 6) (function () {
      var f0 = FR[0], f1 = FR[1], f2 = FR[2], horiz = (f1.x > f0.x);
      var thE = P.m45.thEarth(t);
      /* 【1】の中の地球（公転しているので、毎コマ位置が変わる）。
         ★【2】が映している範囲（40万 km）は、この縮尺だと 0.2 px しかない★
         それでは囲めないので、四角は大げさにしてある。
         ★大きさは「この図に描いてある月の軌道（19 px）が入る」ように 23 px★
           【2】は月の軌道まで映している図なので、それがはみ出していると話が合わない。 */
      m45ZoomLines(ctx, f0, f1,
        f0.x + f0.w / 2 + M45_R1 * Math.cos(thE),
        f0.y + M45_CY1 - M45_R1 * Math.sin(thE), 23, horiz);
      /* 【2】の中の地球は、いつもわくのまん中。
         ★こちらは本当の縮尺で囲める★（4.6万 km × SC = 8.8 px） */
      m45ZoomLines(ctx, f1, f2,
        f1.x + f1.w / 2, f1.y + M45_CY2, 46000 * M45_SC2, horiz);

      /* ===== 2段目（3次元）にも、同じように拡大の線を引く =====
         ★カメラを「キャンバスの座標」で作り直す★
           図を描くときは translate(f.x, f.y) → scale(f.k) してから
           わくの中の座標（中心 336/2, M45_CY3D）でカメラを作っている。
           線はわくの外に出るので、同じ見え方になるカメラを
           縮尺 S と中心 (cx, cy) をずらして作り直す必要がある。 */
      var g1 = FR[3], g2 = FR[4], g3 = FR[5], hz3 = (g2.x > g1.x);
      var c3 = s.cam || { az: 0, el: 0, zoom: 1 };
      function cam3(f) {
        return mk3d(c3.az * DEG, -c3.el * DEG, M45_S3 * c3.zoom * f.k,
          f.x + f.k * (M45_PW / 2), f.y + f.k * M45_CY3D);
      }
      var pe3 = cam3(g1).p(Math.cos(thE), Math.sin(thE), 0);
      /* 【1】→【2】は 43万 km ＝ 0.21 px にしかならないので、四角は大げさに。
         大きさは「地球と自転軸の矢印（0.26 ＝ 19 px）が入る」ように 23 px。 */
      m45ZoomLines(ctx, g1, g2, pe3.x, pe3.y, 23 * c3.zoom * g1.k, hz3);
      var p03 = cam3(g2).p(0, 0, 0);
      /* 【2】→【3】は本当の縮尺で囲める（4.6万 km ÷ 月の軌道 38.44万 km） */
      m45ZoomLines(ctx, g2, g3, p03.x, p03.y,
        46000 / 384400 * M45_S3 * c3.zoom * g2.k, hz3);
    })();
    FR.forEach(function (f) {
      ctx.save();
      /* ★1つ1つの図を、そのわくの中に閉じこめる★
         （【2】の「太陽の方向」の線が となりまで伸びるのを防ぐ） */
      ctx.beginPath(); ctx.rect(f.x, f.y, f.w, f.h); ctx.clip();
      /* わくの左上を原点にして、拡大スイッチが入っていれば 2 倍に引きのばす。
         図を描くかんすうは「336 × 306 のわく」しか知らないので、これだけで大きくなる。 */
      ctx.translate(f.x, f.y);
      ctx.scale(f.k, f.k);
      drawFrame(f.i, ctx, HS[f.i]);
      ctx.restore();
    });
    /* 拡大スイッチ（図といっしょに引きのばさないよう、わくの外で描く） */
    FR.forEach(function (f) {
      var p = m45BtnPos(f);
      m45ZoomBtn(ctx, p.x, p.y, !!s.o.zoom);
    });
    /* わくの区切り線（わく1つ1つのふちを引く） */
    ctx.save();
    ctx.strokeStyle = 'rgba(150,175,205,.45)'; ctx.lineWidth = 1;
    FR.forEach(function (f) {
      ctx.strokeRect(f.x + 0.5, f.y + 0.5, f.w - 1, f.h - 1);
    });
    ctx.restore();
    label(ctx, 't = ' + DEFS['m4-5'].tFmt(t, v) + '（' + P.m45.spanName(v.span) + '）'
      + (v.span === 4 ? '　※ 夜12時に観測' : ''),
      W - 10, 14, { align: 'right', size: 12.5, bold: true, color: COL.ink });
    /* ★1段目が何なのかを、上の白い帯に書く★（先生の指示・2026-09-04） */
    if (FR.some(function (f) { return f.i < 3; })) {
      label(ctx, '＜公転軸の方向から見た様子＞', 10, 14,
        { align: 'left', size: 12, bold: true, color: '#1b4f8a' });
    }
    /* 白い帯の中の「視点をえらぶボタン」 */
    m45DrawViewBtns(ctx, s, W);
    /* ★ことわり書きは、いちばん下の白い余白にまとめて書く★（先生の指示・2026-09-04）
       図の中に ※ を入れると、動く絵の上に文字がかぶさって読みにくいため。 */
    (function () {
      var rows = m45NoteRows(s, v, W), y = H - m45NoteH(s, v, W) + 12;
      rows.forEach(function (r, k) {
        label(ctx, r.t, 14, y + k * 14,
          { align: 'left', size: M45_NSZ, bold: r.b, color: r.c });
      });
    })();
  },
  result: function (v, s, t) {
    /* ★1つの天体で1行の表にまとめる★（先生の指示）
       前は「ISS の a」「ISS の T」…と項目がばらばらに並んでいて、
       どれがどの天体の値なのか非常に読みにくかった。 */
    var G = P.m45, K = function (a, T) { return T * T / (a * a * a); };
    function tf(T) {
      if (T < 7200) return fmt(T / 60, 1) + ' 分';
      if (T < 200000) return fmt(T / 3600, 2) + ' 時間';
      return fmt(T / 86400, 2) + ' 日';
    }
    var rows = [[
      '地球（太陽のまわり）', fmtE(G.AU, 3), tf(G.TYEAR),
      fmt(G.vC(G.GMS, G.AU), 3), fmtE(K(G.AU, G.TYEAR), 3)
    ]];
    SATS.forEach(function (x) {
      rows.push([m45Name(x), fmtAuto(x.a, 0), tf(x.T),
        fmt(G.vC(G.GME, x.a), 3), fmtE(K(x.a, x.T), 3)]);
    });
    return {
      items: [
        resItem('自転の周期', '23 時間 56 分 4 秒'),
        resItem('赤道の上の速さ', fmt(TAU * G.RE / G.TROT * 1000, 0) + ' m/s')
      ],
      table: {
        /* ★表の見出しは「ふつうの文字」で書く★ 数式（$…$）としては組まれない */
        head: ['天体', 'a [km]', '周期 T', '速さ v [km/s]', 'T²/a³ [s²/km³]'],
        rows: rows, kcol: 4
      },
      note: '<b>地球のまわりを回るもの（ISS 〜 月）は、$T^2/a^3$ がどれもほぼ同じ値</b>になります' +
        '（ケプラーの第3法則）。<br>' +
        '<b>1行目の「地球の公転」だけ値がまったく違う</b>のは、回っている中心が' +
        '地球ではなく<b>太陽</b>だから——これが「同じ天体のまわりを回るもの同士で成り立つ」の意味です。<br>' +
        '<span class="mini">月だけ少しずれるのは、月の質量が地球の 1.2 % もあって' +
        '「地球は止まっている」とみなせないから（→ ' +
        '<a href="#m3-3" data-goto="m3-3">3-3 地球と月</a>）。' +
        'ISS の $a$ は地球の半径 6371 km ＋ 高さ 400 km です。<br>' +
        '<b>ひまわり（静止衛星）の $T$ は 23時間56分＝自転の周期</b>。' +
        'だから地上の観測者の真上から動きません。</span>'
    };
  },
  info: function (s, t) {
    var v = V(s);
    t = P.m45.snap(v, t);
    return [
      ['自転した角', fmt((P.m45.thSpin(t) / DEG) % 360, 1) + ' °'],
      ['公転した角', fmt(P.m45.thEarth(t) / DEG, 3) + ' °'],
      ['自転の回数', fmt(t / P.m45.TROT, 2) + ' 回'],
      ['月が回った回数', fmt(t / m45Sat('moon').T, 3) + ' 回']
    ];
  },
  eq: function () {
    return '\\dfrac{mv^2}{r} = G\\dfrac{Mm}{r^2} \\;\\Rightarrow\\; ' +
      'v = \\sqrt{\\dfrac{GM}{r}},\\quad T = 2\\pi\\sqrt{\\dfrac{r^3}{GM}}';
  }
};

/* ===== 昼と夜（太陽と反対がわを暗く塗る）=====
   (x, y) ＝ 地球の中心、R ＝ 描いてある半径、(sx, sy) ＝ 画面での「太陽の向き」の単位ベクトル
   （sy は数学の向き＝上が正。画面では下向きが正なので、中で符号を直している）。
   ★【1】【2】【3】のどこでも同じ見た目にするために、必ずこの部品を使う★ */
function m45Night(ctx, x, y, R, sx, sy, HALO, lab) {
  var nd = Math.atan2(-sy, sx);              /* 画面での「太陽の向き」の角 */
  ctx.save();
  ctx.beginPath(); ctx.arc(x, y, R, nd + Math.PI / 2, nd + Math.PI * 1.5);
  ctx.closePath();
  ctx.fillStyle = 'rgba(8,14,26,.62)'; ctx.fill();
  ctx.restore();
  if (!lab) return;
  /* ★「昼」「夜」の字は、昼夜の境目の線から少し横（垂直方向）へずらす★
     ずらさないと、真夜中に立っている観測者（棒人間）とちょうど重なる。
     （「毎日同じ時間に観測」では観測者がいつも夜のまん中にいるので、必ず重なった） */
    var ox = sy * 13, oy = sx * 13;            /* 太陽の向きに垂直な、13 px のずらし */
  label(ctx, '夜', x - sx * (R + 9) + ox, y + sy * (R + 9) + oy,
    { size: 9.5, bold: true, color: '#9fb4cc', haloColor: HALO });
  label(ctx, '昼', x + sx * (R + 9) + ox, y - sy * (R + 9) + oy,
    { size: 9.5, bold: true, color: '#ffe9a8', haloColor: HALO });
}

/* ===== 自転の向きを示す弧の矢印 =====
   ★【1】【2】でも、地球が自転していることだけは示す★（先生の指示）
   (x, y) ＝ 地球の中心、R ＝ 弧の半径。地球の自転は北極の側から見て反時計まわりなので、
   弧は右から上を通って左へ進み、矢じりは左はしにつく。
   ※ 画面の y は下向きなので、数学の角 θ の点は (x + R cosθ, y − R sinθ)。 */
function m45Spin(ctx, x, y, R, HALO, lab) {
  var a0 = 0.30, a1 = Math.PI - 0.30;        /* 弧の始まり（右）と終わり（左） */
  ctx.save();
  ctx.strokeStyle = '#7fb0d8'; ctx.lineWidth = 1.4; ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.arc(x, y, R, -a1, -a0);                /* canvas の角は y 下向きなので符号を返す */
  ctx.stroke();
  ctx.restore();
  /* 矢じり（左はしで、弧の接線の向き＝反時計まわりの進む向き）。
     ★共通の arrowHead は、この小さな図には大きすぎる★ので、ここで小さく描く。 */
  var ex = x + R * Math.cos(a1), ey = y - R * Math.sin(a1);
  var ux = -Math.sin(a1), uy = -Math.cos(a1);   /* 画面での進む向き（単位ベクトル） */
  var hh = 6, hw = 2.6;
  ctx.save();
  ctx.fillStyle = '#7fb0d8';
  ctx.beginPath();
  ctx.moveTo(ex, ey);
  ctx.lineTo(ex - ux * hh - uy * hw, ey - uy * hh + ux * hw);
  ctx.lineTo(ex - ux * hh + uy * hw, ey - uy * hh - ux * hw);
  ctx.closePath(); ctx.fill();
  ctx.restore();
  if (lab === false) return;
  label(ctx, '自転', x, y - R - 7,
    { size: 9.5, bold: true, color: '#7fb0d8', haloColor: HALO });
}

/* ===== 地上の観測者（棒人間）=====
   ★天体の図でも「誰がどこから見ているか」は棒人間で描く★（観測者の描き方ルール）
   (x, y) ＝ 足もと（地球の表面）、th ＝ その場所の「地球の中心から見た角」。
   その場所での「上」は動径の外向き (cos th, −sin th)。

   ★2-3「人工衛星の周期・静止衛星」とまったく同じ描き方にそろえる★（先生の指示）
     つまり共通部品 stickman() を、足もと＝地表・頭の向き＝動径の外向き で呼ぶ。
     前は自前で棒を引いていたので、
       ・体の真ん中が地表の上に来ていて「立っている」ように見えない
       ・色（金）も 2-3（COL.hand）と違う
     という2点で 2-3 と食いちがっていた。
   ★背の高さ★ 図によって地球の大きさが違うので、S で指定できるようにしてある。
     【3】は地球が 11.6 px なので 15 px、【2】は 6.5 px しかないので 10 px。
     2-3 の 19 px をそのまま使うと、地球が棒人間にかくれてしまう。 */
function m45Person(ctx, x, y, th, S) {
  /* 画面での「上」＝動径の外向き。画面の y は下向きなので sin の符号を反転する */
  stickman(ctx, x, y, Math.cos(th), -Math.sin(th), S || 15, COL.hand, 2.0);
}

/* ============================================================
   3次元（軌道面を横から見る）の図　——　下の段の【1】【2】【3】
   ------------------------------------------------------------
   ★ねらい★（先生の指示・2026-09-03）
     上の段は「真上から見た図」なので、どうしても平面の話に見えてしまう。
     下の段で同じものを3次元にし、ドラッグで見回せるようにすることで、
       ・軌道は「面」の上にあること
       ・地球の自転軸が、その面に対して 23.4° かたむいていること
       ・月の軌道の面と、人工衛星が回る赤道面が、たがいにかたむいていること
     を目で分からせる。★はじめは真横から（el = 0）★

   ★座標のとりかた★
     黄道面（地球が太陽をまわる面）を z = 0 の面とする。
     地球の自転軸は n = (sin ε, 0, cos ε)（ε = 23.44°）で、
     ★公転しても向きは変わらない★——これが季節ができるわけ。
     長さの単位は図ごとに変える（1 ＝ 地球の軌道半径／月の軌道半径／4.6万 km）。
   ============================================================ */
var M45_EPS = 23.44;                    /* 地軸のかたむき［°］ */
var M45_S3 = 74;                        /* 3次元の図の縮尺（長さ 1 ＝ 74 px） */
var M45_CY3D = 124;                     /* 3次元の図の中心の高さ（わくの上からの px） */
/* 自転軸の向き（黄道座標）。公転しても変わらない */
function m45Axis() {
  var e = M45_EPS * DEG;
  return [Math.sin(e), 0, Math.cos(e)];
}
function m45Cross(a, b) {
  return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
}
function m45Unit(a) {
  var L = Math.hypot(a[0], a[1], a[2]) || 1;
  return [a[0] / L, a[1] / L, a[2] / L];
}
/* 法線 n の面の中で、たがいに垂直な2本の単位ベクトルを作る。
   ★輪や面を「描く」だけのとき用★（円の形は、どの向きから始めても同じなので） */
function m45Basis(n) {
  var a = (Math.abs(n[2]) < 0.9) ? [0, 0, 1] : [1, 0, 0];
  var u = m45Unit(m45Cross(a, n));
  return [u, m45Unit(m45Cross(n, u))];
}
/* ★天体を「置く」ときは、必ずこちらを使うこと★
   軌道の面（法線 n）の中で、**θ = 0 が ＋x の向き**に来る基底を作る。
   1段目（真上から見た図）は
     x = cx + R cos θ,  y = cy − R sin θ
   なので θ = 0 で ＋x にいる。2段目でこれをそろえないと、
   真上から見たときに 1段目と2段目で天体の位置が 90° ずれる（実際にずれていた）。
   u ＝ ＋x を面へ落としたもの、w ＝ n × u（θ が増える向きが、n の側から見て反時計まわり）。 */
function m45OrbBasis(n) {
  var d = n[0];                                  /* ＋x と n の内積 */
  var u = m45Unit([1 - n[0] * d, -n[1] * d, -n[2] * d]);
  return [u, m45Unit(m45Cross(n, u))];
}
/* 中心 c、法線 n、半径 r の円（＝軌道の面のふち）を描く */
function m45Ring(ctx, cam, c, n, r, col, dash, lw) {
  var b = m45Basis(n), u = b[0], w = b[1], i, N = 96;
  ctx.save();
  ctx.strokeStyle = col; ctx.lineWidth = lw || 1.2;
  if (dash) ctx.setLineDash(dash);
  ctx.beginPath();
  for (i = 0; i <= N; i++) {
    var a = i / N * TAU, ca = Math.cos(a) * r, sa = Math.sin(a) * r;
    var q = cam.p(c[0] + u[0] * ca + w[0] * sa,
      c[1] + u[1] * ca + w[1] * sa,
      c[2] + u[2] * ca + w[2] * sa);
    if (i === 0) ctx.moveTo(q.x, q.y); else ctx.lineTo(q.x, q.y);
  }
  ctx.stroke();
  ctx.restore();
}
/* 面そのものを、うすい色でぬる（黄道面・赤道面） */
function m45Disc(ctx, cam, c, n, r, col) {
  var b = m45Basis(n), u = b[0], w = b[1], i, N = 72;
  ctx.save();
  ctx.fillStyle = col;
  ctx.beginPath();
  for (i = 0; i <= N; i++) {
    var a = i / N * TAU, ca = Math.cos(a) * r, sa = Math.sin(a) * r;
    var q = cam.p(c[0] + u[0] * ca + w[0] * sa,
      c[1] + u[1] * ca + w[1] * sa,
      c[2] + u[2] * ca + w[2] * sa);
    if (i === 0) ctx.moveTo(q.x, q.y); else ctx.lineTo(q.x, q.y);
  }
  ctx.closePath(); ctx.fill();
  ctx.restore();
}
/* 3次元の線分 */
function m45Seg3(ctx, cam, a, b, col, dash, lw) {
  var p = cam.p(a[0], a[1], a[2]), q = cam.p(b[0], b[1], b[2]);
  ctx.save();
  ctx.strokeStyle = col; ctx.lineWidth = lw || 1.2;
  if (dash) ctx.setLineDash(dash);
  ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y); ctx.stroke();
  ctx.restore();
}
/* ★自転軸★ 天体の位置 c から、両向きに L だけのばした矢印。
   北（n の向き）がわだけ矢じりを付ける。色は茶（力・速度の色を使わない決まり）。 */
function m45AxisArrow(ctx, cam, c, n, L, HALO, lab) {
  var A = [c[0] - n[0] * L, c[1] - n[1] * L, c[2] - n[2] * L];
  var B = [c[0] + n[0] * L, c[1] + n[1] * L, c[2] + n[2] * L];
  var pa = cam.p(A[0], A[1], A[2]), pb = cam.p(B[0], B[1], B[2]);
  ctx.save();
  ctx.strokeStyle = '#c9a227'; ctx.lineWidth = 2; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(pa.x, pa.y); ctx.lineTo(pb.x, pb.y); ctx.stroke();
  /* 矢じり（北がわ） */
  var dx = pb.x - pa.x, dy = pb.y - pa.y, dd = Math.hypot(dx, dy) || 1;
  var ux = dx / dd, uy = dy / dd, hh = 7, hw = 3.2;
  ctx.fillStyle = '#c9a227';
  ctx.beginPath();
  ctx.moveTo(pb.x, pb.y);
  ctx.lineTo(pb.x - ux * hh - uy * hw, pb.y - uy * hh + ux * hw);
  ctx.lineTo(pb.x - ux * hh + uy * hw, pb.y - uy * hh - ux * hw);
  ctx.closePath(); ctx.fill();
  ctx.restore();
  if (lab) {
    label(ctx, lab, pb.x + 4, pb.y - 8,
      { size: 9.5, bold: true, color: '#e0c257', align: 'left', haloColor: HALO });
  }
}

/* ===== 3次元の中の「太陽の向き」を、画面の向きになおす =====
   m45Night は「画面での太陽の向き（数学の向き・上が正）」を受けとるので、
   3次元の点をいったん2つ投影して、その差から向きを出す。
   at ＝ 昼と夜を描く天体の位置、sunAt ＝ 太陽の位置（遠いときは十分遠い点でよい）。
   ★真正面（見ている向き）に太陽があるときは向きが決まらない★ので、
     そのときは「右が昼」としておく（半分が欠けて見えるだけなので害はない）。 */
function m45SunScr(cam, at, sunAt) {
  var d = [sunAt[0] - at[0], sunAt[1] - at[1], sunAt[2] - at[2]];
  var L = Math.hypot(d[0], d[1], d[2]) || 1;
  var p0 = cam.p(at[0], at[1], at[2]);
  var p1 = cam.p(at[0] + d[0] / L * 0.4, at[1] + d[1] / L * 0.4, at[2] + d[2] / L * 0.4);
  var dx = p1.x - p0.x, dy = p1.y - p0.y, LL = Math.hypot(dx, dy);
  if (LL < 1e-6) return { x: 1, y: 0 };
  return { x: dx / LL, y: -dy / LL };
}

/* ===== 3次元の図（下の段）=====
   which … 1＝太陽のまわり／2＝地球のまわり／3＝地球のすぐそば
   ★上の段とまったく同じ時刻 t で描くこと★（同じ時計で動いている、が売り） */
function m45Panel3D(ctx, s, v, t, W, y0, y1, HALO, which) {
  var c = s.cam || { az: 0, el: 0, zoom: 1 };
  /* ★el の符号を返して mk3d に渡すこと★（先生の指摘・2026-09-04）
     mk3d の el は「下から見上げる」向きなので、そのまま渡すと
     真上（el = 90）にしたとき、1段目（真上から見た図）と回転が逆に見える。
     −el にすると、画面の上が ＋y になって、1段目とぴったり同じ向きになる。 */
  var cam = mk3d(c.az * DEG, -c.el * DEG, M45_S3 * c.zoom, W / 2, y0 + M45_CY3D);
  var n = m45Axis(), ECL = [0, 0, 1];
  var thE = P.m45.thEarth(t);
  var moon = m45Sat('moon'), geo = m45Sat('himawari');

  if (which === 1) {
    label(ctx, '【1】太陽のまわり　地球の軌道と自転軸', 10, y0 + 15,
      { align: 'left', size: 11, bold: true, color: '#cfe0f0', haloColor: HALO });
    /* 黄道面（地球が太陽をまわる面） */
    m45Disc(ctx, cam, [0, 0, 0], ECL, 1.0, 'rgba(120,150,190,.14)');
    m45Ring(ctx, cam, [0, 0, 0], ECL, 1.0, fade(COL.orbit, 0.8), [5, 4], 1.3);
    var E = [Math.cos(thE), Math.sin(thE), 0];
    m45Seg3(ctx, cam, [0, 0, 0], E, '#8ea3b8', [4, 4], 1);
    var ps = cam.p(0, 0, 0), pe = cam.p(E[0], E[1], E[2]);
    sunShape(ctx, ps.x, ps.y, 10);
    label(ctx, '太陽', ps.x, ps.y + 21,
      { size: 10, bold: true, color: COL.sun, haloColor: HALO });
    /* 赤道面（自転軸に垂直）を、小さな輪で見せる */
    m45Ring(ctx, cam, E, n, 0.11, 'rgba(120,190,255,.7)', null, 1.1);
    m45AxisArrow(ctx, cam, E, n, 0.26, HALO, '自転軸');
    earthShape(ctx, pe.x, pe.y, 6, -P.m45.thSpin(t));
    /* ★昼と夜★ 太陽はこの図のまん中（原点）にある */
    (function () {
      var ss = m45SunScr(cam, E, [0, 0, 0]);
      m45Night(ctx, pe.x, pe.y, 6, ss.x, ss.y, HALO, false);
    })();
    label(ctx, '地球', pe.x + 10, pe.y + 15,
      { size: 10, bold: true, color: '#9fd0ff', align: 'left', haloColor: HALO });
    m45Foot(ctx, y1, [
      { t: '★自転軸は、公転しても向きが変わりません', s: 9.5, c: '#e0c257' },
      { t: '　黄道面に垂直な向きから 23.4° かたむいたまま', s: 9.5, c: '#e0c257' },
      { t: '　→ 太陽のほうへ かたむく時期と、反対へ かたむく', s: 9 },
      { t: '　　時期ができる。これが季節のもと', s: 9 }
    ], HALO);

  } else if (which === 2) {
    label(ctx, '【2】地球のまわり　月の軌道と赤道面', 10, y0 + 15,
      { align: 'left', size: 11, bold: true, color: '#cfe0f0', haloColor: HALO });
    /* 月の軌道の面は、黄道面から 5.1° かたむいている */
    var im = 5.1 * DEG;
    var nm = m45Unit([0, -Math.sin(im), Math.cos(im)]);
    m45Disc(ctx, cam, [0, 0, 0], ECL, 1.0, 'rgba(120,150,190,.10)');
    /* ★くらべる相手として、黄道面のふちも出す★
       月の軌道（5.1°）と赤道面（23.4°）が、どちらから何度かたむいているかが分かる。 */
    m45Ring(ctx, cam, [0, 0, 0], ECL, 1.0, 'rgba(140,165,200,.45)', [2, 4], 1);
    m45Ring(ctx, cam, [0, 0, 0], nm, 1.0, fade(COL.orbit, 0.85), [5, 4], 1.3);
    /* 赤道面（自転軸に垂直）。★地球より外へ出る大きさにすること★
       小さくすると、地球の絵にかくれて「かたむき」がまったく見えない。 */
    m45Ring(ctx, cam, [0, 0, 0], n, 0.34, 'rgba(120,190,255,.8)', [3, 3], 1.3);
    /* ★静止軌道は、この図には描かない★（先生の指示・2026-09-04）
       月の軌道を 1 とすると 0.11 しかなく、地球の絵とほとんど同じ大きさになるので、
       「赤道面のかたむき」を見せたいこの図では、かえってじゃまになる。
       静止軌道は 1段目の【2】（〇 の凡例つき）と、2段目の【3】で見せている。 */
    m45AxisArrow(ctx, cam, [0, 0, 0], n, 0.50, HALO, '自転軸');
    var p0 = cam.p(0, 0, 0);
    /* ★地球は 5 px★ 8 px にすると、静止軌道（8 px）がすっぽりかくれる */
    earthShape(ctx, p0.x, p0.y, 5, -P.m45.thSpin(t));
    /* ★昼と夜★ 太陽はこの図の外（1.5 億 km 先）なので、
       黄道面の中の「太陽の方向」へ十分に遠い点を置いて向きを出す。
       月にもまったく同じ向きを使ってよい（40万 km ずれても 0.15° しか変わらない）。 */
    var sd = m45SunDir(t), SUNFAR = [sd.x * 60, sd.y * 60, 0];
    m45Night(ctx, p0.x, p0.y, 5, m45SunScr(cam, [0, 0, 0], SUNFAR).x,
      m45SunScr(cam, [0, 0, 0], SUNFAR).y, HALO, false);
    label(ctx, '地球', p0.x + 12, p0.y + 16,
      { size: 10, bold: true, color: '#9fd0ff', align: 'left', haloColor: HALO });
    /* 月 */
    var thM = P.m45.thSat(moon, t);
    var bm = m45OrbBasis(nm), mu = bm[0], mw = bm[1];
    var M = [mu[0] * Math.cos(thM) + mw[0] * Math.sin(thM),
      mu[1] * Math.cos(thM) + mw[1] * Math.sin(thM),
      mu[2] * Math.cos(thM) + mw[2] * Math.sin(thM)];
    var pm = cam.p(M[0], M[1], M[2]);
    planetShape(ctx, pm.x, pm.y, 5, moon.col);
    (function () {
      var ms = m45SunScr(cam, M, [SUNFAR[0], SUNFAR[1], 0]);
      m45Night(ctx, pm.x, pm.y, 5, ms.x, ms.y, HALO, false);
    })();
    label(ctx, '月', pm.x, pm.y - 13,
      { size: 10, bold: true, color: '#cbbfae', haloColor: HALO });
    m45Foot(ctx, y1, [
      { t: '青い輪＝赤道面（自転軸に垂直）', s: 9.5, c: '#8ec6ff' },
      { t: '灰色の輪＝黄道面（地球が太陽をまわる面）', s: 9.5, c: '#9fb4cc' },
      { t: '白い輪＝月の軌道', s: 9.5, c: '#c9d6e4' }
    ], HALO);

  } else {
    label(ctx, '【3】地球のすぐそば　人工衛星の軌道は赤道面の上', 10, y0 + 15,
      { align: 'left', size: 11, bold: true, color: '#cfe0f0', haloColor: HALO });
    var U3 = 46000;                             /* 長さ 1 ＝ 4.6万 km */
    m45Disc(ctx, cam, [0, 0, 0], n, geo.a / U3 * 1.02, 'rgba(120,190,255,.10)');
    /* 太陽の方向（黄道面の中）——赤道面とのかたむきが見える */
    (function () {
      var d = m45SunDir(t), L = 0.98;
      m45Seg3(ctx, cam, [0, 0, 0], [d.x * L, d.y * L, 0], '#e8c96a', [6, 4], 1.4);
      var q = cam.p(d.x * L, d.y * L, 0);
      label(ctx, '太陽の方向', q.x, q.y - 9,
        { size: 9, bold: true, color: '#e8c96a', haloColor: HALO });
    })();
    if (s.o.showS) {
      M45_SATS.forEach(function (id) {
        var x = m45Sat(id);
        m45Ring(ctx, cam, [0, 0, 0], n, x.a / U3, fade(x.col, 0.8), [4, 4], 1.2);
      });
    }
    m45AxisArrow(ctx, cam, [0, 0, 0], n, 1.02, HALO, '自転軸');
    var pc = cam.p(0, 0, 0), Rp3 = P.m45.RE / U3 * M45_S3 * c.zoom;
    earthShape(ctx, pc.x, pc.y, Rp3, -P.m45.thSpin(t));
    (function () {
      var d2 = m45SunDir(t), ss = m45SunScr(cam, [0, 0, 0], [d2.x * 60, d2.y * 60, 0]);
      m45Night(ctx, pc.x, pc.y, Rp3, ss.x, ss.y, HALO, false);
    })();
    /* 人工衛星（赤道面の上を回る） */
    if (s.o.showS) {
      var be = m45OrbBasis(n), eu = be[0], ew = be[1];
      M45_SATS.forEach(function (id) {
        var x = m45Sat(id), r = x.a / U3;
        var th = (id === 'himawari') ? m45ThObs(t) : P.m45.thSat(x, t);
        var Pp = [ (eu[0] * Math.cos(th) + ew[0] * Math.sin(th)) * r,
          (eu[1] * Math.cos(th) + ew[1] * Math.sin(th)) * r,
          (eu[2] * Math.cos(th) + ew[2] * Math.sin(th)) * r ];
        var q = cam.p(Pp[0], Pp[1], Pp[2]);
        planetShape(ctx, q.x, q.y, x.r * 0.85, x.col);
        /* ★名前は上と下にふりわける★ 3つとも同じ線の上に乗るので、
           同じ側に出すと必ず重なる（ISS は地表すれすれなので名前を出さない）。 */
        if (id === 'himawari') {
          label(ctx, x.short, q.x, q.y - 13,
            { size: 9.5, bold: true, color: x.col, haloColor: HALO });
        } else if (id === 'gps') {
          label(ctx, x.short, q.x, q.y + 14,
            { size: 9.5, bold: true, color: x.col, haloColor: HALO });
        }
      });
    }
    if (v.span === 3 && !s.o.showS) {
      label(ctx, '速すぎるので表示を消しています', W / 2, y0 + M45_CY3D + 50,
        { size: 10.5, bold: true, color: '#ffb36b', haloColor: HALO });
      label(ctx, '（チェックを入れると出ます）', W / 2, y0 + M45_CY3D + 65,
        { size: 9.5, color: '#8ea3b8', haloColor: HALO });
    }
    m45Foot(ctx, y1, [
      { t: '★人工衛星は、どれも赤道面の上を回っています', s: 9.5, c: '#8ec6ff' },
      { t: '　自転軸は、太陽の方向（黄道面）から 23.4° かたむく', s: 9 }
    ], HALO);
  }
}

/* ===== 「ここを拡大したのが次の図」を示す線 =====
   ★教科書の「銀河系 → 太陽のあたり → 太陽系 → 地球」の図と同じやり方★（先生の指示）
   小さな四角で「次の図に映っている範囲」を囲み、その2つの角から
   次の図のわくの2つの角へ線をのばす。こうすると
   「四角の中身を、この大きさまで引きのばしたのが次の図」だと、言葉なしで分かる。

   ★線は図より「先に」引くこと★
     あとから引くと、軌道や文字の上に線が乗ってしまう。
     先に引いておけば、天体や文字（白いふちどり付き）が上から重なって読みやすい。

   f0 … いま囲むほうのわく、f1 … 拡大したほうのわく
   (bx, by) … 四角の中心（地球の位置）、b … 四角の半分の大きさ
   横に並べているときは 右の2角 → 次のわくの左の2角、
   たてに並べているときは 下の2角 → 次のわくの上の2角 へ結ぶ。 */
function m45ZoomLines(ctx, f0, f1, bx, by, b, horiz) {
  ctx.save();
  ctx.strokeStyle = 'rgba(150,175,205,.5)'; ctx.lineWidth = 1;
  /* 「次の図に映っている範囲」の四角 */
  ctx.strokeRect(bx - b, by - b, b * 2, b * 2);
  var p1, p2, q1, q2;
  if (horiz) {
    p1 = [bx + b, by - b]; p2 = [bx + b, by + b];          /* 四角の右の2角 */
    q1 = [f1.x, f1.y];     q2 = [f1.x, f1.y + f1.h];       /* 次のわくの左の2角 */
  } else {
    p1 = [bx - b, by + b]; p2 = [bx + b, by + b];          /* 四角の下の2角 */
    q1 = [f1.x, f1.y];     q2 = [f1.x + f1.w, f1.y];       /* 次のわくの上の2角 */
  }
  ctx.beginPath();
  ctx.moveTo(p1[0], p1[1]); ctx.lineTo(q1[0], q1[1]);
  ctx.moveTo(p2[0], p2[1]); ctx.lineTo(q2[0], q2[1]);
  ctx.stroke();
  ctx.restore();
}

/* ===== 図の下に置く注釈 =====
   ★よこ一列の構成では、1つの図のはばが 336 px しかない★
   前（たて3段）のように1行 60 字の注釈は入らないので、短い行を下から積む。
   lines は上から順に [{ t:文, s:字の大きさ, c:色 }]。空の要素は飛ばす。 */
function m45Foot(ctx, y1, lines, HALO) {
  var n = lines.filter(function (x) { return x; }).length, k = 0;
  lines.forEach(function (ln) {
    if (!ln) return;
    label(ctx, ln.t, 10, y1 - (n - k) * 13 + 5,
      { align: 'left', size: ln.s || 9, color: ln.c || '#7d8fa5', haloColor: HALO });
    k++;
  });
}

/* ===== 【1】太陽のまわり（地球の公転・1 AU）===== */
function m45Panel1(ctx, s, v, t, W, y0, y1, HALO) {
  var cx = W / 2, cy = y0 + M45_CY1;
  var R = M45_R1;                           /* 1 AU = 68 px */
  var th = P.m45.thEarth(t);
  var ex = cx + R * Math.cos(th), ey = cy - R * Math.sin(th);
  label(ctx, '【1】太陽のまわり　地球の軌道', 10, y0 + 15,
    { align: 'left', size: 11.5, bold: true, color: '#cfe0f0', haloColor: HALO });
  if (s.o.showT) {
    ctx.save();
    ctx.strokeStyle = fade(COL.orbit, 0.85); ctx.lineWidth = 1.3; ctx.setLineDash([5, 4]);
    ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.stroke();
    ctx.restore();
  }
  sunShape(ctx, cx, cy, 11);
  label(ctx, '太陽', cx, cy + 23, { size: 10.5, bold: true, color: COL.sun, haloColor: HALO });
  dashLine(ctx, cx, cy, ex, ey, '#8ea3b8', [4, 4], 1);
  /* ★地球のまわりを回る月も、この図の中に描く★（先生の指示）
     本当の月の軌道は 1 AU の 0.26 % しかなく、このままでは 0.2 px で見えない。
     そこで <b>きょりだけを大げさにして 19 px</b> で描き、そのことを図の中に書いておく。
     回る速さ（周期 27.3 日）は本当の値なので、1か月で1周する。 */
  (function () {
    var moon = m45Sat('moon'), RM = 19;
    var thM = P.m45.thSat(moon, t);
    if (s.o.showT) {
      ctx.save();
      ctx.strokeStyle = 'rgba(200,190,175,.6)'; ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
      ctx.beginPath(); ctx.arc(ex, ey, RM, 0, TAU); ctx.stroke();
      ctx.restore();
    }
    var mx = ex + RM * Math.cos(thM), my = ey - RM * Math.sin(thM);
    planetShape(ctx, mx, my, 3.4, moon.col);
    /* ★月にも昼と夜★（先生の指示）。太陽は図の中心にあるので、
       月から見た太陽の向きは「月 → 太陽（cx, cy）」。
       画面の y は下向きなので、数学の向きに直してから渡す。 */
    (function () {
      var dx = cx - mx, dy = cy - my, dd = Math.hypot(dx, dy) || 1;
      m45Night(ctx, mx, my, 3.4, dx / dd, -dy / dd, HALO, false);
    })();
    label(ctx, '月', mx + Math.cos(thM) * 11, my - Math.sin(thM) * 11,
      { size: 9.5, bold: true, color: '#cbbfae', haloColor: HALO });
  })();
  /* ★地球の大きさは【3】＞【2】＞【1】の順にすること★（先生の指摘）
     3つの図は「引いた図 → 寄った図」なので、寄るほど地球が大きく見えないと
     ズームしている感じにならない。いまは【1】3.6 px ＜【2】4.4 px ＜【3】11.6 px。
     （【2】を 6.5 → 4.4 px にしたので、【1】も 4.5 → 3.6 px にそろえ直した） */
  var RE1 = 3.6;
  earthShape(ctx, ex, ey, RE1, -P.m45.thSpin(t));
  /* ★昼と夜はいつも出す★（先生の指示・2026-09-03。チェックボックスは無くした）
     「毎日同じ時間に観測」がこの補足の見どころなので、
     昼と夜が見えていないと「同じ時間」がどこなのか分からなくなるため。 */
  (function () {
    var dsx = (cx - ex), dsy = (cy - ey), dsd = Math.hypot(dsx, dsy) || 1;
    /* 画面の y は下向きなので、数学の向きに直してから渡す */
    m45Night(ctx, ex, ey, RE1, dsx / dsd, -dsy / dsd, HALO, false);
  })();
  m45Spin(ctx, ex, ey, 11, HALO, true);     /* 自転の向き（月の軌道 19 px の内側） */
  /* ★名前は「拡大の四角」（半分 23 px）の外に出す★
     角にかかると、そこから出ている拡大の線と重なって読みにくい。 */
  label(ctx, '地球', ex + 27, ey - 32,
    { size: 10.5, bold: true, color: '#9fd0ff', align: 'left', haloColor: HALO });
  if (s.o.showV) {
    /* 円軌道なので、速度は動径に垂直（反時計まわり） */
    var vk = P.m45.vC(P.m45.GMS, P.m45.AU);
    velArrow(ctx, ex, ey, -vk * Math.sin(th), vk * Math.cos(th), 34 / vk, null);
  }
  m45Foot(ctx, y1, [
    { t: '1 AU = 1.496×10⁸ km', s: 10, c: '#8ea3b8' },
    { t: '地球の速さ 29.8 km/s', s: 10, c: '#8ea3b8' }
  ], HALO);
}

/* ===== 【2】地球のまわり（月まで・40万 km）===== */
function m45Panel2(ctx, s, v, t, W, y0, y1, HALO) {
  var cx = W / 2, cy = y0 + M45_CY2;
  var LIM = 430000;                         /* この図に入れる範囲［km］ */
  var SC = M45_SC2;                        /* 1 km あたりの px（月の軌道が 73 px） */
  var moon = m45Sat('moon'), geo = m45Sat('himawari');
  var thM = P.m45.thSat(moon, t);
  var sun = m45SunDir(t);
  label(ctx, '【2】地球のまわり　月の軌道', 10, y0 + 15,
    { align: 'left', size: 11.5, bold: true, color: '#cfe0f0', haloColor: HALO });
  if (s.o.showT) {
    ctx.save();
    ctx.strokeStyle = fade(COL.orbit, 0.85); ctx.lineWidth = 1.3; ctx.setLineDash([5, 4]);
    ctx.beginPath(); ctx.arc(cx, cy, moon.a * SC, 0, TAU); ctx.stroke();
    ctx.restore();
    /* ★ひまわり（静止衛星）の軌道を、赤い点線で本当の縮尺のまま描く★（先生の指示）
       4.2万 km はこの縮尺だと 8 px しかない。月の軌道（73 px）と比べると、
       「人工衛星は、地球に比べればすぐそばを回っている」ことが目で分かる。
       ★「人工衛星を表示」を OFF にしたときは、これも消す★（人工衛星の軌道なので） */
    if (s.o.showS) {
      /* ★色は【3】とそろえる★（先生の指示・2026-09-03）
         【3】は fade(geo.col, 0.75) で描いている。ここだけ別の赤（#e0503c）だったので、
         同じ「ひまわりの軌道」なのに色が違って見えていた。 */
      ctx.save();
      ctx.strokeStyle = fade(geo.col, 0.75); ctx.lineWidth = 1.2; ctx.setLineDash([3, 3]);
      ctx.beginPath(); ctx.arc(cx, cy, geo.a * SC, 0, TAU); ctx.stroke();
      ctx.restore();
    }
  }
  /* 太陽の方向（ここから昼と夜が決まる） */
  (function () {
    var d = sun, L = 84;
    ctx.save();
    ctx.strokeStyle = '#e8c96a'; ctx.lineWidth = 1.4; ctx.setLineDash([6, 4]);
    ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + d.x * L, cy - d.y * L); ctx.stroke();
    ctx.restore();
    label(ctx, '太陽の方向', cx + d.x * (L + 8), cy - d.y * (L + 8),
      { size: 9.5, bold: true, color: '#e8c96a', haloColor: HALO });
  })();
  /* 地球（見やすさのため大きく描く）
     ★ひまわりの軌道（8.0 px）より、はっきり内側に収める★（先生の指摘・2026-09-03）
       6.5 px にしていたときは、軌道 8.0 px との差が 1.5 px しかなく、
       「静止軌道が地球にはりついている＝小さすぎる」ように見えていた。
       本当は 静止軌道 42164 km ÷ 地球の半径 6371 km ＝ 6.6 倍。
       この図は 40万 km までを 82 px に押しこんでいるので、
       本当の縮尺なら地球は 1.2 px。それでは見えないので大きく描いているが、
       大きくしすぎると今度は軌道が小さく見える——という、ものさしのつごうによるもの。
       4.4 px なら軌道との差が 3.6 px あり、外側を回っていることが目で分かる。
       ★この図で本当の縮尺なのは「軌道」のほう★（月の軌道 73 px との比が 11 % で正しい） */
  var RE2 = 4.4;
  earthShape(ctx, cx, cy, RE2, -P.m45.thSpin(t));
  /* 昼と夜の「文字」は【3】だけに出す。ここで出すと「地球」の名前と重なる */
  m45Night(ctx, cx, cy, RE2, sun.x, sun.y, HALO, false);   /* 昼と夜はいつも出す */
  m45Spin(ctx, cx, cy, 17, HALO, true);     /* 自転の向き（ひまわりの軌道 8 px の外側） */
  /* ★地上の観測者は【2】にも描く★（先生の指示）
     【3】とまったく同じ角（＝ひまわりと同じ向き）に立たせてあるので、
     【2】と【3】に出ている棒人間は「同じ1人の人」。
     この人が地球といっしょに自転しながら、月まで 40万 km のこの図の中では
     ほとんど動いていないように見える——という比べ方ができる。
     ★背は 7 px★ この図の地球は 4.4 px しかないので、これ以上大きくすると
     棒人間のほうが地球より大きくなり、静止軌道（8.0 px）まではみ出してしまう。 */
  if (s.o.showO) (function () {
    var thg = m45ThObs(t);
    m45Person(ctx, cx + RE2 * Math.cos(thg), cy - RE2 * Math.sin(thg), thg, 7);
  })();
  label(ctx, '地球', cx, cy + 23,
    { size: 10, bold: true, color: '#9fd0ff', haloColor: HALO });
  /* 月。★月にも昼と夜を描く★（先生の指示・2026-09-03）
     光っているのは いつも太陽のがわ の半分。
     月が地球のまわりを回ると、地球から見える「光っている部分」の形が変わる
     ——これが月の満ち欠け。この図はそれを真上から見たもの。
     ★太陽の向きは地球のときとまったく同じ★（1.5 億 km 先なので、
       40万 km ぶん横にずれても向きは 0.15°しか変わらない）。 */
  var mx = cx + moon.a * SC * Math.cos(thM), my = cy - moon.a * SC * Math.sin(thM);
  planetShape(ctx, mx, my, 6, moon.col);
  m45Night(ctx, mx, my, 6, sun.x, sun.y, HALO, false);
  label(ctx, '月', mx + Math.cos(thM) * 17, my - Math.sin(thM) * 17,
    { size: 10.5, bold: true, color: '#cbbfae', haloColor: HALO });
  if (s.o.showV) {
    var vm = P.m45.vC(P.m45.GME, moon.a);
    velArrow(ctx, mx, my, -vm * Math.sin(thM), vm * Math.cos(thM), 30 / vm, null);
  }
  /* ★引き出し線の吹き出しはやめて、右下に「〇 は…を表す」と書く★（先生の指示・2026-09-03）
     左下へのびる長い点線を「長さを表す線」と読みちがえられたため。
     ★〇 は本物とまったく同じ色・同じ大きさ（半径 8.0 px）で描く★
     こうすれば「この大きさの円が静止軌道」だと、ひと目で分かる。 */
  if (s.o.showS) (function () {
    var rr = geo.a * SC, txt = 'は ひまわりの静止軌道（4.2万 km）';
    var ty = y1 - 78, tx = W - 10;
    ctx.save(); ctx.font = 'bold 9.5px ' + FONT;
    var tw = ctx.measureText(txt).width;
    ctx.strokeStyle = fade(geo.col, 0.75); ctx.lineWidth = 1.2; ctx.setLineDash([3, 3]);
    ctx.beginPath(); ctx.arc(tx - tw - rr - 7, ty, rr, 0, TAU); ctx.stroke();
    ctx.restore();
    label(ctx, txt, tx, ty,
      { size: 9.5, bold: true, color: geo.col, align: 'right', haloColor: HALO });
  })();
  /* ★下の注釈は5行まで★ 6行にすると、上の「〇 は…」の凡例と重なる。 */
  m45Foot(ctx, y1, [
    { t: '月：a = 38.4万 km　T = 27.3 日　v = 1.02 km/s', s: 9.5, c: '#8ea3b8' },
    s.o.showS ? { t: 'ひまわり：a = 4.2万 km　T = 24 時間（自転と同じ）', s: 9 } : null
  ], HALO);
}

/* ===== 【3】地球のすぐそば（人工衛星と自転・約4.6万 km）===== */
function m45Panel3(ctx, s, v, t, W, y0, y1, HALO) {
  var cx = W / 2, cy = y0 + M45_CY3;
  var LIM = 46000;
  var SC = 84 / LIM;                        /* 1 km あたりの px */
  var Rp = P.m45.RE * SC;                   /* 地球の半径（この図では実物の縮尺） */
  var spin = P.m45.thSpin(t);
  /* ★太陽の向きは【1】【2】と同じ★（先生の指示）
     公転が進むにつれて、太陽は 左 → 左下 → 下 … と、図のふちをなめらかに動く。
     昼と夜も、この向きで決まる。 */
  var sun = m45SunDir(t);
  label(ctx, '【3】地球のすぐそば　自転と人工衛星の軌道', 10, y0 + 15,
    { align: 'left', size: 11.5, bold: true, color: '#cfe0f0', haloColor: HALO });
  /* ★太陽そのものは描かない★（先生の指示）
     この縮尺では太陽は 1.5 億 km 先。近くに描くとうそになるので、
     【2】とまったく同じように「太陽の方向」の線だけを出す。
     公転が進むと、この向きが 左 → 左下 → 下 … となめらかに変わる。 */
  (function () {
    var L = 84;
    ctx.save();
    ctx.strokeStyle = '#e8c96a'; ctx.lineWidth = 1.4; ctx.setLineDash([6, 4]);
    ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + sun.x * L, cy - sun.y * L);
    ctx.stroke();
    ctx.restore();
    label(ctx, '太陽の方向', cx + sun.x * (L + 8) - sun.y * 4, cy - sun.y * (L + 8) - sun.x * 4,
      { size: 9.5, bold: true, color: '#e8c96a', haloColor: HALO });
  })();

  /* 軌道（「人工衛星を表示」が OFF のときは、軌道の点線も出さない） */
  if (s.o.showT && s.o.showS) {
    M45_SATS.forEach(function (id) {
      var x = m45Sat(id);
      ctx.save();
      ctx.strokeStyle = fade(x.col, 0.75); ctx.lineWidth = 1.2; ctx.setLineDash([4, 4]);
      ctx.beginPath(); ctx.arc(cx, cy, x.a * SC, 0, TAU); ctx.stroke();
      ctx.restore();
    });
  }
  /* 地球（自転する）。昼と夜は「太陽の方向」で決まる */
  earthShape(ctx, cx, cy, Rp, -spin);
  m45Night(ctx, cx, cy, Rp, sun.x, sun.y, HALO, true);     /* 昼と夜はいつも出す */
  /* ★地上の観測者（棒人間）★ 自転といっしょに回る。静止衛星と同じ角にしてある。
     ここが「ひまわりは真上から動かない」を目で見せる、いちばん大事なところ。
     「地上の観測者」のチェックを外すと、棒人間も視線の点線も消える。 */
  if (s.o.showO) (function () {
    var geo = m45Sat('himawari');
    var thg = m45ThObs(t);
    var gx = cx + geo.a * SC * Math.cos(thg), gy = cy - geo.a * SC * Math.sin(thg);
    var px = cx + Rp * Math.cos(thg), py = cy - Rp * Math.sin(thg);
    /* 観測者と静止衛星を結ぶ線（いつも一直線＝真上にいる、ということ）。
       人工衛星を消しているときは、指す先が無いので この線も出さない。 */
    if (s.o.showS) {
      ctx.save();
      ctx.strokeStyle = 'rgba(181,84,58,.85)'; ctx.lineWidth = 1.4; ctx.setLineDash([3, 3]);
      ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(gx, gy); ctx.stroke();
      ctx.restore();
    }
    m45Person(ctx, px, py, thg);
  })();
  /* 人工衛星（「人工衛星を表示」が OFF のときは1つも出さない） */
  if (s.o.showS) M45_SATS.forEach(function (id) {
    var x = m45Sat(id);
    /* ★ひまわりだけは m45ThObs（＝観測者と同じ角）で描く★
       ここを P.m45.thSat のままにすると、観測者の真上からずれてしまう。 */
    var th = (id === 'himawari') ? m45ThObs(t) : P.m45.thSat(x, t);
    var sx = cx + x.a * SC * Math.cos(th), sy = cy - x.a * SC * Math.sin(th);
    planetShape(ctx, sx, sy, x.r * 0.9, x.col);
    /* ISS は地表すれすれを回るので、名前は少し遠くに出さないと地球と重なる */
    var lo = (id === 'iss') ? 36 : 17;
    label(ctx, m45Name(x), sx + Math.cos(th) * lo, sy - Math.sin(th) * lo,
      { size: 10, bold: true, color: x.col === '#3f7f5f' ? '#7fe0a0' : x.col, haloColor: HALO });
    if (s.o.showV) {
      var vk = P.m45.vC(P.m45.GME, x.a);
      velArrow(ctx, sx, sy, -vk * Math.sin(th), vk * Math.cos(th), 26 / 7.673, null);
    }
  });
  /* ★「観測者」の名前は、人工衛星より「あと」に書く★
     ISS は地表すれすれを回るので、観測者と同じ向きに来ることが 92 分ごとにある。
     先に書くと ISS の名前に上から重ねられて読めなくなる。
     ★よこ一列の構成では列がせまいので、名前は「観測者」と短くする★
     （前の「地上の観測者」だと ISS や「夜」の字と重なった） */
  if (s.o.showO) (function () {
    var thg = m45ThObs(t);
    var px = cx + Rp * Math.cos(thg), py = cy - Rp * Math.sin(thg);
    /* ★動径の外がわには「ひまわり」の名前がいつも乗っている★（真上にいるので）
       ので、観測者の名前は動径に垂直な向きへ 30 px よけて置く。 */
    label(ctx, '観測者',
      px + Math.cos(thg) * 16 + Math.sin(thg) * 30,
      py - Math.sin(thg) * 16 + Math.cos(thg) * 30,
      { size: 9.5, bold: true, color: COL.hand, haloColor: HALO });
  })();
  /* ★「速すぎるので表示を消しています」★（先生の指示・2026-09-04）
     1年を選ぶと人工衛星と観測者が自動で消えるので、その理由を軌道のあたりに書く。 */
  if (v.span === 3 && !s.o.showS) {
    label(ctx, '速すぎるので表示を消しています', cx, cy + 44,
      { size: 10.5, bold: true, color: '#ffb36b', haloColor: HALO });
    label(ctx, '（チェックを入れると出ます）', cx, cy + 59,
      { size: 9.5, color: '#8ea3b8', haloColor: HALO });
  }
  m45Foot(ctx, y1, [
    /* ★自転の角度は「1日」のときだけ出す★（先生の指示）
       1か月・1年では1コマで何十回も回るので、この数字に意味がない。 */
    v.span === 1 ? { t: '自転 ' + fmt((spin / DEG) % 360, 0) + '°（23時間56分で1回）', s: 10.5, c: '#9fd0ff' } : null,
    s.o.showS ? { t: 'ひまわりは観測者の真上から動かない', s: 10, c: '#e08a72' } : null,
    s.o.showS ? { t: '　　＝ 静止衛星', s: 10, c: '#e08a72' } : null,
    s.o.showS ? { t: 'ISS 6771 km（92分）／GPS 26560 km（11.97時間）', s: 9 } : null,
    s.o.showS ? { t: 'ひまわり 42164 km（23時間56分）', s: 9 } : null
  ], HALO);
}
