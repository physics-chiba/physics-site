/* 2　万有引力とエネルギー */
'use strict';

/* ============================================================
   2-1　万有引力と位置エネルギー（重力場のイメージ）　… id は m2-2
   ============================================================
   上の絵：上から見た太陽（質量 M）と惑星（質量 m）。
   下の絵：太陽が作る位置エネルギー U = −GM/r の「すりばち」を斜めから見た3次元の図。
           惑星をそのすりばちの上に置いて、「重力場の中を動いている」ことを見せる。
   ★ねらい★
     ① 万有引力は距離の2乗に反比例する（矢印の長さで見る）
     ② U = −GM/r は無限遠を 0 とした「谷」で、M が大きいほど深い
     ③ 同じ場所でも「初速度の向き」で、落ちる・回る・ふりきる が分かれる
     ④ このあと学ぶ「電場の中の電荷の運動」と、まったく同じ形の話であること
*/
function gravOrb(v) { return P.grav.make(v.Ms, v.k2, v.th0, v.r02); }
/* 初速度 0（k = 0）＝ まっすぐ落ちて、谷底から出てこられない状態かどうか */
function m22Trap(v) { return Math.abs(v.k2) < 1e-9; }

/* すりばちを描くときの座標のとりかた。
   (x, y) は km、u は位置エネルギー［MJ/kg］。どちらも「1 になるように」わり算してから
   mk3d に渡す。こうすると、視点（方位角 az・仰角 el）を変えても形がくずれない。 */
function gvNorm(Ms, x, y, u) {
  return [x / P.grav.RMAX, y / P.grav.RMAX, u / P.grav.depth(P.grav.MMAX)];
}
function gvCam(s, W, oy) {
  var c = s.cam || { az: 0, el: 0, zoom: 1 };
  return mk3d(c.az * DEG, c.el * DEG, 185 * c.zoom, W / 2, oy);
}
/* 真横から見ているか（＝ふつうの U–r グラフとして読める向きか） */
function gvSideOn(s) { return !s.cam || Math.abs(s.cam.el) < 6; }
/* 真上から見ているか（＝すりばちを真上から見おろした、同心円の図） */
function gvTopOn(s) { return !!s.cam && s.cam.el > 84; }
/* 真横から見た U–r グラフを、たてに どこまで描くか［px］。
   ここから下は欄外の注記の場所なので、グラフも軸もここで打ち切る。 */
function gvFloor(H) { return H - 44; }
function gvPt(cam, Ms, x, y, u) {
  var n = gvNorm(Ms, x, y, u);
  return cam.p(n[0], n[1], n[2]);
}

/* すりばち（U のグラフ）を描く。
   ★真横から見ているときは、ワイヤーフレームではなく「U–r グラフ」を描く★
   （メッシュを真横から見ると、線が重なってただの黒い塊になり、グラフとして読めないため。） */
function gvWell(ctx, cam, Ms, side, W, H) {
  var RMIN = P.grav.RMIN, RMAX = P.grav.RMAX, i, j, p, q;
  var N = 90;
  /* --- U = 0 の面（無限遠が基準）--- */
  ctx.save();
  ctx.strokeStyle = '#c2ccd6'; ctx.lineWidth = 1.2; ctx.setLineDash([5, 4]);
  ctx.beginPath();
  if (side) {
    p = gvPt(cam, Ms, -RMAX, 0, 0); q = gvPt(cam, Ms, RMAX, 0, 0);
    ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y);
  } else {
    for (i = 0; i <= 72; i++) {
      var th0 = TAU * i / 72;
      p = gvPt(cam, Ms, RMAX * Math.cos(th0), RMAX * Math.sin(th0), 0);
      if (i === 0) ctx.moveTo(p.x, p.y); else ctx.lineTo(p.x, p.y);
    }
    ctx.closePath();
  }
  ctx.stroke();
  ctx.restore();

  if (side) {
    /* ===== 真横から見た図＝U–r グラフ =====
       ★たて軸は「絵の枠に入りきる ところまで」★
       U = −GM/r は r → 0 で無限に深いので、いくらでも下へのびてしまう。
       そこで枠の下ぎりぎり（yFloor）でグラフも軸も打ち切り、そこに
       「ここから下は入りきらない」というしるし（破線）を入れる。 */
    var yTop0 = gvPt(cam, Ms, 0, 0, 0).y;          /* U = 0 の高さ［px］ */
    var kpx = (gvPt(cam, Ms, 0, 0, -100).y - yTop0) / 100;  /* U 1 あたりの px */
    var yFloor = gvFloor(H);                        /* 欄外の注記にかからない高さ */
    var uFloor = (kpx > 1e-6) ? -(yFloor - yTop0) / kpx : P.grav.U(Ms, P.grav.RSCALE);
    /* グラフを打ち切る距離（U(rCut) = uFloor）。RMIN より内側には入らない */
    var rCut = Math.max(RMIN, P.grav.gm(Ms) / Math.abs(uFloor));
    var cutOff = rCut > RMIN + 1e-6;                /* 枠に入りきらなかったか */
    ctx.save();
    ctx.strokeStyle = COL.upot; ctx.lineWidth = 2.4;
    [1, -1].forEach(function (sg) {
      ctx.beginPath();
      for (j = 0; j <= N; j++) {
        var rr = rCut * Math.pow(RMAX / rCut, j / N);
        var pp = gvPt(cam, Ms, sg * rr, 0, P.grav.Uwell(Ms, rr));
        if (j === 0) ctx.moveTo(pp.x, pp.y); else ctx.lineTo(pp.x, pp.y);
      }
      ctx.stroke();
    });
    /* 底をつなぐ。打ち切ったときは「この先まだ深い」という意味の破線にする */
    var b1 = gvPt(cam, Ms, -rCut, 0, P.grav.Uwell(Ms, rCut));
    var b2 = gvPt(cam, Ms, rCut, 0, P.grav.Uwell(Ms, rCut));
    if (cutOff) { ctx.setLineDash([4, 4]); ctx.lineWidth = 1.6; }
    ctx.beginPath(); ctx.moveTo(b1.x, b1.y); ctx.lineTo(b2.x, b2.y); ctx.stroke();
    ctx.restore();
    /* 目もり（地球の中心からの距離） */
    [10000, 20000, 30000].forEach(function (rr) {
      [1, -1].forEach(function (sg) {
        var pp = gvPt(cam, Ms, sg * rr, 0, 0);
        ctx.save();
        ctx.strokeStyle = COL.dim; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(pp.x, pp.y - 4); ctx.lineTo(pp.x, pp.y + 4); ctx.stroke();
        ctx.restore();
        if (sg > 0) label(ctx, fmt(rr / 1000, 0) + '千 km', pp.x, pp.y - 12,
          { size: 9.5, color: COL.dim });
      });
    });
    label(ctx, 'r →', gvPt(cam, Ms, RMAX, 0, 0).x - 4, gvPt(cam, Ms, 0, 0, 0).y - 12,
      { size: 10.5, color: COL.dim, align: 'right' });
    /* ★たて軸（U）を書く★ ふつうの U–r グラフとして読めるように、
       0 を上にした目もりつきの軸を左はしに立てる。 */
    (function () {
      var ax = gvPt(cam, Ms, -RMAX * 1.06, 0, 0).x;
      /* ★たて軸は、枠に入りきる いちばん下（yFloor）まで引く★
         こうすると目もりが軸の下のはしまで入り、「軸がとちゅうで切れている」
         ように見えなくなる。 */
      var top = yTop0, bot = yFloor;
      ctx.save();
      ctx.strokeStyle = AX.col; ctx.lineWidth = 1.4;
      ctx.beginPath(); ctx.moveTo(ax, bot); ctx.lineTo(ax, top - 14); ctx.stroke();
      ctx.restore();
      arrowHead(ctx, ax, top - 22, 0, -1, AX.col);
      /* ★単位は「MJ（m = 1 kg として計算）」★ 1kg と決めたので U/m と U の値は同じ */
      label(ctx, 'U [MJ]', ax + 4, top - 30, { size: 11, color: AX.col, align: 'left', bold: true });
      var stp = niceStep(Math.abs(uFloor), 5);
      for (var u = 0; u >= uFloor - 1e-9; u -= stp) {
        var py = gvPt(cam, Ms, 0, 0, u).y;
        if (py > bot + 0.5) break;
        ctx.save();
        ctx.strokeStyle = AX.col; ctx.lineWidth = 1.1;
        ctx.beginPath(); ctx.moveTo(ax - 4, py); ctx.lineTo(ax + 4, py); ctx.stroke();
        ctx.restore();
        label(ctx, fmt(u, 0), ax - 8, py, { size: 9.5, color: AX.col, align: 'right' });
      }
    })();
    return cutOff;
  }

  /* ===== ななめから見た図＝すりばちのワイヤーフレーム ===== */
  var NR = 9;
  ctx.save();
  ctx.lineWidth = 1.2;
  for (j = 0; j <= NR; j++) {
    var r = RMIN * Math.pow(RMAX / RMIN, j / NR);
    var u = P.grav.Uwell(Ms, r);
    ctx.strokeStyle = (j === NR) ? '#8ea3b8' : '#c2ccd6';
    ctx.beginPath();
    for (i = 0; i <= 72; i++) {
      var th1 = TAU * i / 72;
      p = gvPt(cam, Ms, r * Math.cos(th1), r * Math.sin(th1), u);
      if (i === 0) ctx.moveTo(p.x, p.y); else ctx.lineTo(p.x, p.y);
    }
    ctx.closePath(); ctx.stroke();
  }
  ctx.strokeStyle = '#cfd8e2'; ctx.lineWidth = 1;
  for (i = 0; i < 16; i++) {
    var th2 = TAU * i / 16, cs = Math.cos(th2), sn = Math.sin(th2);
    ctx.beginPath();
    for (j = 0; j <= 40; j++) {
      var rr2 = RMIN * Math.pow(RMAX / RMIN, j / 40);
      var pp2 = gvPt(cam, Ms, rr2 * cs, rr2 * sn, P.grav.Uwell(Ms, rr2));
      if (j === 0) ctx.moveTo(pp2.x, pp2.y); else ctx.lineTo(pp2.x, pp2.y);
    }
    ctx.stroke();
  }
  ctx.restore();
}

/* 図の左上に出す「軌道の見分け方」（2-2 の m23Legend と同じ作り）。
   いまの軌道の行だけを太字にして、絵の中の線の色とつなげる。 */
function gvKindLegend(ctx, kind, trap) {
  /* ★canvas に KaTeX は使えない★ 式は素の文字（√ や ₀）で書くこと
     trap … 初速度 0（まっすぐ落ちる）。「楕円」と言うと生徒が混乱するので、
             その行だけ「まっすぐ落ちる」に書きかえる。 */
  var rows = [
    { name: '円', note: 'E < 0・v₀ = √(GM/r₀)', col: COL.bound, dash: [], on: !trap && kind === 'circle' },
    { name: trap ? 'まっすぐ落ちる（v₀ = 0）' : '楕円', note: trap ? '' : 'E < 0',
      col: trap ? COL.force : COL.bound, dash: [], on: kind === 'ellipse' || kind === 'circle' ? !!trap || kind === 'ellipse' : false },
    { name: '放物線', note: 'E = 0', col: COL.para, dash: [8, 5], on: kind === 'para' },
    { name: '双曲線', note: 'E > 0', col: COL.hyper, dash: [12, 4, 3, 4], on: kind === 'hyper' }
  ];
  var x0 = 8, y0 = 8, w = 196, h = 20 + rows.length * 17;
  ctx.save();
  ctx.fillStyle = 'rgba(255,255,255,.90)';
  ctx.strokeStyle = COL.grid; ctx.lineWidth = 1;
  if (ctx.roundRect) { ctx.beginPath(); ctx.roundRect(x0, y0, w, h, 7); ctx.fill(); ctx.stroke(); }
  else { ctx.fillRect(x0, y0, w, h); ctx.strokeRect(x0, y0, w, h); }
  ctx.restore();
  label(ctx, '軌道の見分け方', x0 + 9, y0 + 12, { size: 10.5, bold: true, color: COL.sub, align: 'left' });
  rows.forEach(function (r, i) {
    var y = y0 + 29 + i * 17;
    ctx.save();
    ctx.strokeStyle = r.col; ctx.lineWidth = r.on ? 3 : 2;
    if (r.dash.length) ctx.setLineDash(r.dash);
    ctx.beginPath(); ctx.moveTo(x0 + 9, y); ctx.lineTo(x0 + 39, y); ctx.stroke();
    ctx.restore();
    label(ctx, r.name, x0 + 45, y, { size: 11, bold: r.on, color: r.on ? r.col : COL.sub, align: 'left' });
    label(ctx, r.note, x0 + w - 9, y,
      { size: 10, bold: r.on, color: r.on ? r.col : '#9aa5b1', align: 'right' });
  });
}

DEFS['m2-2'] = {
  id: 'm2-2', mode: 2, tab: '2-1 万有引力と位置エネルギー',
  units: ['Mearth'],
  legendKeys: ['force', 'vel', 'dim', 'sun', 'orbit', 'bound', 'para', 'hyper', 'upot'],
  title: '2-1　万有引力と位置エネルギー　—　人工衛星は「すりばち」の中を動いている',
  /* ★スライドバーの説明は、ここ（欄外）に書く★
     カードの中に説明を並べるとスライドバーが埋もれるので、
     「向き」と「はじめの位置」の説明はこの1行に出している。 */
  sub: '<b>まず、オレンジで光っている2つ——<b>地球の質量 $M$</b> と <b>はじめの位置 $r_0$</b>'
    + '——を動かしてみてください。</b>'
    + '地球の大きさ・すりばちの深さ・万有引力の矢印の長さが、どう変わるかを見よう。<br>' +
    '※ <b>地球の質量 $M$</b> の単位は<b>地球質量</b>（いまの地球が 1.0）。' +
    '<b>初速度の向き</b>は動径から測ります（<b>0°</b>＝地球へ／<b>90°</b>＝横／<b>180°</b>＝外へ）。' +
    '<b>はじめの位置 $r_0$</b> は、<b>上の図の○印をドラッグ</b>しても動かせます。<br>' +
    '※ <b>本当の地球の半径は $R = 6371$ km</b> です。' +
    'このシミュレーションでは、すりばちの形をなるべく深いところまで見せるために ' +
    '<b>$r = 1000$ km までグラフを描いています</b>が、' +
    'これは<b>地球の中</b>にあたる場所で、' +
    '<b>人工衛星が実際にそこまで近づくことはありません</b>' +
    '（地表 $r=6371$ km より内側では、そもそも $U=-GMm/r$ の式が使えません' +
    '　→ <a href="#m3-2" data-goto="m3-2">3-2 地球トンネル</a>）。<br>' +
    '※ 図の中の地球の大きさは、<b>質量 $M$ を変えると変わります</b>' +
    '（違いが分かりやすいように、わざと大きめに変えています）。<br>' +
    '上は<b>上から見た地球と人工衛星</b>、下は地球が作る<b>位置エネルギー ' +
    '$U = -G\\dfrac{mM}{r}$ の「すりばち」</b>です。' +
    '人工衛星は、このすりばちの<b>斜面の上を動くボール</b>だと思ってください。<br>' +
    '<b>地球の質量 M</b> を大きくするとすりばちは<b>深く</b>なり、人工衛星が受ける<b>万有引力も大きく</b>なります。' +
    '<b>初速度</b>（$v_0=\\sqrt{k\\,GM/r_0}$ の <b>k</b>。1-4・2-2 と同じ書き方）とその<b>向き</b>、' +
    'それに<b>はじめの位置 $r_0$</b>（○印をドラッグしても動かせます）を変えると、' +
    'まっすぐ落ちる・楕円を描く・円を描く・<b>すりばちからぬけ出す</b>、と運動が変わります。<br>' +
    '<b>下の図はドラッグで向きを変えられます</b>（ホイールで拡大縮小）。' +
    '図の下のボタンで<b>「真横から」「斜め上から」</b>に戻せます。<br>' +
    '※ <b>図の中には数値を出していません</b>（$r$・$F$・$v$・$U$ の記号だけ）。' +
    '数値は<b>図の下の「計算結果を表示」</b>と<b>右の読み出しの表</b>にまとめてあります。<br>' +
    '※ <b>$F$ と $U$ の値は、人工衛星の質量を $m = 1$ kg と決めて</b>計算しています' +
    '（この値は、数字を読みやすくするために<b>こちらで適当に決めた</b>ものです）。' +
    '$m$ を 2 倍にすれば $F$ も $U$ も 2 倍になりますが、' +
    '<b>軌道の形も周期も $m$ にはよりません</b>（$F=ma$ の両辺から $m$ が消えるため）。',
  note: '<b>$U = -G\\dfrac{mM}{r}$ は「無限遠を 0 とした谷」</b>です。' +
    '地球に近いほど U は低く（マイナスが大きく）、遠いほど 0 に近づきます。<br>' +
    '<b>k = 0</b>（初速度 0）で置くと、ボールは<b>まっすぐ谷底へ</b>落ちて、' +
    '<b>そこで止まります（もう出てこられません）</b>。' +
    '横向きの速さが 0 だと、谷を回れないので、そのまま底へ落ちるしかないのです。' +
    '横向き（90°）の初速度を与えると<b>谷の斜面をぐるぐる回りながら</b>動き、' +
    '<b>k = 1</b>（$v_0 = \\sqrt{GM/r_0}$）のときちょうど<b>円</b>になります。' +
    '<b>k = 2</b>（$v_0 = \\sqrt{2GM/r_0}$＝脱出速度）をこえると <b>$E \\ge 0$</b> になり、' +
    '<b>谷から出て二度と戻ってきません</b>（→ ' +
    '<a href="#m2-3" data-goto="m2-3">2-2 軌道の種類と宇宙速度</a>）。<br>' +
    '★<b>2-2 とまったく同じ $k$ です</b>★　地表から打ち出すとき（$r_0=R$）は ' +
    '$\\dfrac{GM}{R}=gR$ なので、この $v_0=\\sqrt{k\\,GM/r_0}$ は ' +
    '2-2 の $v_0=\\sqrt{k\\,gR}$ と<b>同じ式</b>になります。' +
    '<b>1-4・2-1・2-2 の3つとも、同じやり方で速さを変えています。</b>',
  /* ★このシミュレーションのねらいのひとつ★
     このあと学ぶ「電場の中の電荷の運動」と、式の形がそっくりであることを見せておく。 */
  sideText:
    '<span class="q">重力場と、電場</span>' +
    '左側の U–r グラフをドラッグすると表示される「すりばち」——' +
    'このように、<b>質量のある物体のまわりは空間がゆがんでいます</b>。' +
    'このゆがみを<b>「場」</b>といいます。重力なら<b>重力場</b>で、' +
    '電気の力（静電気力）の場なら<b>電場</b>と言います。<br>' +
    'このあと電磁気で学ぶ<b>「電場の中の電荷の運動」</b>は、' +
    'いまここで見ている<b>「重力場の中の人工衛星や惑星の運動」と同様</b>です。' +
    '式を見比べてみよう。' +
    '<table class="mini">' +
    '<tr><th></th><th>万有引力（作る場は「重力場」）</th>' +
    '<th>静電気力（作る場は「電場」）</th></tr>' +
    '<tr><td><b>力</b></td><td>$F = G\\dfrac{mM}{r^2}$</td><td>$F = k\\dfrac{qQ}{r^2}$</td></tr>' +
    '<tr><td><b>位置エネルギー</b></td><td>$U = -G\\dfrac{mM}{r}$</td><td>$U = k\\dfrac{qQ}{r}$</td></tr>' +
    '<tr><td><b>基準</b></td><td class="c">無限遠で 0</td><td class="c">無限遠で 0</td></tr>' +
    '<tr><td><b>引力／斥力</b></td><td>質量は正だけ<br><b>引力しかない</b></td>' +
    '<td>電荷に正負がある<br><b>引力も斥力もある</b></td></tr>' +
    '<tr><td><b>図の形</b></td><td><b>すりばち（谷）</b></td>' +
    '<td>異符号なら<b>谷</b><br>同符号なら<b>山</b></td></tr>' +
    '</table>' +
    'どちらも<b>距離の2乗に反比例する力</b>で、<b>位置エネルギーは距離に反比例</b>します。' +
    'だから<b>電子が原子核のまわりを回る</b>ようすは、' +
    '<b>人工衛星が地球のまわりを回る</b>ようすとそっくりな式で書けます。<br>' +
    '違うのは、<b>電場の場合は「＋の電荷どうし」のように反発力がありえる</b>点だけ。' +
    '反発力が生じる理由は、この図の<b>すりばちが「山」になる</b>と思えば説明可能です。' +
    '詳しくは<b>電場や等電位線</b>を教科書で読んでみてください。',
  cw: 560, ch: 620,
  drag3d: true,
  cam3d: { az: 0, el: 0, zoom: 1 },     /* 既定は「真横から」＝ふつうの U–r グラフ */
  /* ★上の軌道の図と、下のすりばちの図で、別々にチェックを持たせる★
     （同じ「万有引力」でも、上は平面の矢印・下は斜面にそった矢印で意味が違うため） */
  vis: ['F', 'V', 'FW', 'VW'],
  visLabel: {
    F: '万有引力を表示', V: '速度を表示',
    FW: '下図の万有引力を表示', VW: '下図の速度を表示'
  },
  /* 上の図（軌道）のチェックと、下の図（すりばち）のチェックを見分けやすくするため、
     FW の手前に「2マスぶん」のすきまを空ける */
  visGap: ['FW'],
  visDef: { F: true, V: true, FW: false, VW: false },
  /* ★スライドバーの欄は 2×2 に並べる（varsTwoCol）★
     ★説明（hint）を書いてよいのは、速さの k のところだけ★
     ほかの3つの説明はカードの外（図の下の cvsub）へ出した。
     カードの中に説明を並べると、スライドバーがどこにあるか分からなくなるため。 */
  varsTwoCol: true,
  vars: [
    {
      /* 単位（地球質量）は、値のところにも ラベルにも入れない。
         2×2 に並べると、どちらでも折り返してしまうため。
         単位は「計算結果の帯」の下の単位のことわり（units: ['Mearth']）と、
         図の下の1行に書いてある。 */
      /* ★上限は 2.0 地球質量★（先生の指示・2026-09-03）
         3.0 まで広げても表示は壊れないが、絵の中の地球（R ∝ √M）が 22.5 px までふくらみ、
         人工衛星と万有引力の矢印が地球の絵にくっついてしまう。
         2.0 なら地球は 18.4 px で、いちばん内がわの人工衛星（r₀ = 7000 km ≒ 38 px）
         とのあいだが空いたままになる。
         ★上限を変えたら P.grav.MMAX も同じ値にすること★
           すりばちの深さの目もりを決めるのに使っているので、
           ずれると M を上げたときにグラフが箱からはみ出す。 */
      k: 'Ms', label: '地球の質量 $M$', unit: '', focus: true,
      min: 0.5, max: 2.0, step: 0.1, dec: 1, def: 1.0
    },
    {
      /* ★2-2 とまったく同じ書き方にそろえること★（ラベルも説明も）
         地表（r0 = R）なら GM/r0 = gR なので、2-2 の √(k gR) と同じ式である。
         「2-1 と 2-2 で、同じように速さを変えている」と生徒に分からせるため。 */
      k: 'k2', label: '初速度 $v_0 = \\sqrt{k\\,GM/r_0}$ の $k$', unit: '',
      min: 0, max: 4.0, step: 0.1, dec: 1, def: 0,
      hint: '$\\sqrt{GM/r_0}$＝円軌道の速さ　k = 0 静止／1 円／2 脱出'
    },
    {
      k: 'r02', label: 'はじめの位置 $r_0$', unit: ' km', focus: true,
      min: 7000, max: 15000, step: 500, dec: 0, def: 10000
    },
    {
      k: 'th0', label: '初速度の向き', unit: '°',
      min: 0, max: 180, step: 15, dec: 0, def: 90
    }
  ],
  /* 2×2 の並び：左上 質量 M・右上 速さ k・左下 はじめの位置 r0・右下 向き */
  mainVars: ['Ms', 'k2', 'r02', 'th0'],
  /* ボタンはスライドバーのカードの「下」に置く（値を決めてから押す順になるように） */
  topActionsBelow: true,
  topActions: [
    {
      label: '円軌道になる速さ（k = 1）', prim: true, play: true,
      fn: function (s) { s.v.k2 = 1.0; s.v.th0 = 90; },
      is: function (v) { return Math.abs(v.k2 - 1) < 1e-9 && v.th0 === 90; }
    },
    {
      label: '脱出速度にする（k = 2）', prim: true, play: true,
      fn: function (s) { s.v.k2 = 2.0; s.v.th0 = 90; },
      is: function (v) { return Math.abs(v.k2 - 2) < 1e-9 && v.th0 === 90; }
    },
    {
      label: '最初の設定に戻す',
      fn: function (s) {
        (DEFS['m2-2'].vars || []).forEach(function (vd) { s.v[vd.k] = vd.def; });
      },
      is: function (v) {
        return (DEFS['m2-2'].vars || []).every(function (vd) {
          return Math.abs(v[vd.k] - vd.def) < 1e-9;
        });
      }
    }
  ],
  /* 上の図の○印（はじめの位置）をドラッグして r0 を変える。
     ★下半分（すりばち）は視点を回すドラッグなので、上半分だけを受けとる★ */
  drag3dFrom: 300,
  dragDown: function (s, x, y, lx, ly) { return ly < 300; },
  drag: function (s, x, y) {
    var vd = null;
    (DEFS['m2-2'].vars || []).forEach(function (q) { if (q.k === 'r02') vd = q; });
    var r = Math.hypot(x, y);
    s.v.r02 = clamp(Math.round(r / vd.step) * vd.step, vd.min, vd.max);
  },
  /* 図の下のバーは「すりばちの視点」を切りかえるボタンにあてる */
  actions: [
    {
      label: '真横から見る（U–r グラフ）',
      fn: function (s) { s.cam.az = 0; s.cam.el = 0; s.cam.zoom = 1; },
      is: function (v, s) { return camIs(s, 0, 0, 1); }, keepT: true
    },
    {
      label: '斜め上から見る（3次元）',
      fn: function (s) { s.cam.az = -35; s.cam.el = 26; s.cam.zoom = 0.85; },
      is: function (v, s) { return camIs(s, -35, 26, 0.85); }, keepT: true
    },
    {
      /* ★仰角は 90°（＝完全に真上）★
         もとは 88° にしていたので、押しても少しだけ斜めのままだった（先生の指摘）。
         mk3d は el = 90° でもこわれない（z の項が消えて、ふつうの上から見た図になる）。
         ドラッグの上限（80_ui.js の clamp）も 90 にそろえてある。 */
      label: '真上から見る',
      fn: function (s) { s.cam.az = 0; s.cam.el = 90; s.cam.zoom = 0.85; },
      is: function (v, s) { return camIs(s, 0, 90, 0.85); }, keepT: true
    }
  ],
  tEnd: function (v) {
    var o = gravOrb(v);
    /* ★初速度 0（k = 0）は「まっすぐ谷底へ落ちて、二度と出てこない」★
       もともとは「つぶれただ円」なので、計算上は谷底ではね返って
       もとの高さまで戻ってくる。それでは
       「なぜはね返るの？」と生徒が思ってしまうので（先生の指摘）、
       すりばちの底（RMIN）に着いたところで時間を打ち切り、そこで止める。 */
    if (m22Trap(v)) return Math.max(1, o.T / 2 - o.tOut(P.grav.RMIN));
    if (o.bound) return o.T;
    return Math.max(600, o.tTo(P.grav.RMAX * 1.4));
  },
  /* 初速度 0 のときだけ、くり返さない（谷底で止まる） */
  loop: function (v) { return !m22Trap(v); },
  rate: function (v) { return DEFS['m2-2'].tEnd(v) / 12; },
  tFmt: function (t) { return fmt(t / 60, 1) + ' 分'; },
  xlabel: 't [分]',
  sample: function (v, t) {
    var o = gravOrb(v), q = P.grav.at(o, t);
    var U = P.grav.U(v.Ms, q.r);
    return { r: q.r, v: q.v, U: U, Ke: o.Em - U, E: o.Em, x: q.x, y: q.y };
  },
  graphs: [
    {
      key: 'ur', short: '$U$–$r$ 図', title: '$U$–$r$ 図（万有引力による位置エネルギー）', open: true,
      H: 300,
      custom: function (v, s, t) {
        var o = gravOrb(v), i, U = [], Kk = [], E = [];
        var rmax = 60000, rlo = 2500;
        for (i = 0; i <= 220; i++) {
          var rr = rlo + (rmax - rlo) * i / 220;
          var u = P.grav.U(v.Ms, rr);
          U.push([rr, u]);
          E.push([rr, o.Em]);
          var kk = o.Em - u;
          Kk.push([rr, kk >= 0 ? kk : NaN]);      /* K < 0 のところへは行けない */
        }
        var q = P.grav.at(o, t), qU = P.grav.U(v.Ms, q.r);
        /* ★たての範囲は「地表（R = 6371 km）での U」を目安にしめる★
           前は M がいちばん大きいときに合わせて −120 まで取っていたので、
           いちばん見せたい「r = 1万 km あたり」がグラフの上のほうに寄って、
           下半分が間のびしていた（スマホだと特に読みにくい）。 */
        var yLo = 1.18 * P.grav.U(v.Ms, P.grav.RE);
        var yHi = Math.max(40, (o.Em + P.grav.gm(v.Ms) / 5000) * 0.4);
        return {
          xmin: 0, xmax: rmax,
          ymin: yLo,
          ymax: yHi,
          /* 軸の名前は短く。長いとスマホでたて軸の矢印と重なる */
          xlabel: 'r [km]', ylabel: 'エネルギー [MJ]',
          /* ★E の正負で「閉じこめられる／ぬけ出せる」を塗り分ける★
             ★色はページの決まりどおり、軌道の色を薄くして使う★
             （青＝速度・赤＝力なので、ここには絶対に使わない） */
          bands: [
            { y0: yLo, y1: 0, color: fade(COL.bound, 0.07),
              label: 'E < 0 ＝ 閉じこめられる', lcolor: COL.bound },
            { y0: 0, y1: yHi, color: fade(COL.para, 0.10),
              label: 'E ≥ 0 ＝ ぬけ出せる', lcolor: '#a07a12' }
          ],
          legend: true,
          series: [
            { color: COL.upot, width: 2.4, pts: U, name: 'U' },
            { color: COL.sect2, width: 2.0, pts: Kk, name: 'K' },
            { color: COL.cg, width: 2.0, dash: [7, 4], pts: E, name: 'E' }
          ],
          vline: { x: q.r, color: COL.vel, label: 'いまの人工衛星' },
          /* ★U・K・E の3つとも「いまの値」を出すこと★
             K を出しそこねると「E と U の差が K」という、いちばん見せたい関係が絵から消える。 */
          cursors: [
            { color: COL.vel, x: q.r, y: qU, r: 6.6, name: 'いまの U', lx: 10, ly: 14, align: 'left' },
            { color: COL.vel, x: q.r, y: o.Em - qU, r: 6.6, name: 'いまの K', lx: 10, ly: -13, align: 'left' },
            { color: COL.vel, x: q.r, y: o.Em, r: 5.4, name: 'いまの E', lx: 10, ly: 14, align: 'left' }
          ]
        };
      },
      fml: function (v) {
        var o = gravOrb(v);
        return [
          'U = -G\\dfrac{mM}{r},\\quad E = \\dfrac{1}{2}mv^2 + U\\;(\\text{一定})',
          'E < 0 \\Rightarrow \\text{閉じこめられる},\\quad E \\ge 0 \\Rightarrow \\text{ぬけ出せる}',
          'E = ' + fmt(o.Em, 2) + '\\;\\mathrm{MJ}\\;(m = 1\\,\\mathrm{kg}) \\;\\Rightarrow\\; ' + K.kindName(o.kind)
        ];
      }
    },
    {
      key: 'Fr', short: '$F$–$r$ 図', title: '$F$–$r$ 図（万有引力の大きさ）　※距離の2乗に反比例', open: false,
      custom: function (v, s, t) {
        var pts = [], i, rmax = 60000;
        for (i = 0; i <= 200; i++) {
          var rr = 2500 + (rmax - 2500) * i / 200;
          pts.push([rr, P.grav.gm(v.Ms) / (rr * rr) * 1000]);
        }
        var q = P.grav.at(gravOrb(v), t);
        return {
          xmin: 0, xmax: rmax, ymin: 0, ymax: P.grav.gm(P.grav.MMAX) / (3000 * 3000) * 1000,
          xlabel: 'r [km]', ylabel: 'F [N]（m = 1 kg）',
          series: [{ color: COL.force, width: 2.4, pts: pts }],
          cursors: [{ color: COL.force, x: q.r, y: P.grav.gm(v.Ms) / (q.r * q.r) * 1000 }]
        };
      },
      fml: function (v) {
        return [
          'F = G\\dfrac{mM}{r^2}',
          '\\text{距離が 2 倍になると、力は } \\dfrac{1}{4} \\text{ になる}',
          'GM = ' + fmtE(P.grav.gm(v.Ms), 3) + '\\;[\\mathrm{km^3/s^2}]'
        ];
      }
    },
    {
      key: 'rt', short: '$r$–$t$ 図', title: '$r$–$t$ 図（地球の中心からの距離）', open: false,
      ylabel: 'r [km]', xf: function (m, v, t) { return t / 60; },
      series: [{ color: COL.bound, f: function (m) { return m.r; } }]
    }
  ],
  draw: function (ctx, s, t, W, H) {
    var v = V(s), o = gravOrb(v);
    var q = P.grav.at(o, t);
    var YSP = 300;                       /* 上（上から見た図）と下（すりばち）の境目 */

    /* ============ 上：上から見た地球と人工衛星 ============ */
    /* ★上の絵は上の枠に閉じこめる★ 軌道が大きいと線が下のすりばちの絵まで
       のびてしまい、どちらの図の線なのか分からなくなるため。 */
    ctx.save();
    ctx.beginPath(); ctx.rect(0, 0, W, YSP); ctx.clip();
    /* ★縮尺は固定★ M や初速度を変えたときに、絵の大きさが変わらないようにする */
    var BOX = 18000;
    var vw = mkView(W, YSP, { l: 30, r: 30, t: 26, b: 12 },
      { x0: -BOX, x1: BOX, y0: -BOX, y1: BOX });
    s.view = vw;
    var cx = vw.X(0), cy = vw.Y(0);

    /* 軌道の線（種類で色と形が変わる。2-2 と同じ約束） */
    (function () {
      var path = P.grav.path(o, 60000, 420);
      ctx.save();
      ctx.strokeStyle = fade(orbColor(o.kind), 0.75); ctx.lineWidth = 1.8;
      var dsh = orbDash(o.kind);
      if (dsh.length) ctx.setLineDash(dsh);
      ctx.beginPath();
      path.forEach(function (p, j) {
        var pp = [vw.X(p[0]), vw.Y(p[1])];
        if (j === 0) ctx.moveTo(pp[0], pp[1]); else ctx.lineTo(pp[0], pp[1]);
      });
      if (o.bound) ctx.closePath();
      ctx.stroke();
      ctx.restore();
    })();

    /* はじめの位置（いつも右端。初速度を変えても動かない） */
    var s0x = vw.X(v.r02), s0y = vw.Y(0);
    ctx.save();
    ctx.strokeStyle = COL.sub; ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.arc(s0x, s0y, 8, 0, TAU); ctx.stroke();
    ctx.restore();

    /* ★質量 M を大きくすると、絵の中の地球も大きくなる★
       「重い＝大きい」がひと目で分かるようにするため（下の欄外に断り書きあり） */
    earthShape(ctx, cx, cy, P.grav.Rpx(v.Ms), 0);

    var px = vw.X(q.x), py = vw.Y(q.y);
    var inFrame = (px > 10 && px < W - 10 && py > 40 && py < YSP - 26);
    if (inFrame) {
      /* 地球と人工衛星を結ぶ線に垂直な向き（文字をふり分けるのに使う） */
      var dxs = px - cx, dys = py - cy, dls = Math.hypot(dxs, dys) || 1;
      var nx = -dys / dls, ny = dxs / dls;
      dashLine(ctx, cx, cy, px, py, COL.dim, [5, 4], 1.2);
      /* 文字は「線からの垂直方向のきょり」を全部違えて、重ならないようにする。
         初速度 0 のときは衛星も矢印も1本の直線の上に来るので、
         同じ高さに置くと必ず重なってしまう。 */
      if (dls > 58) {
        /* ★図の中に数値は出さない★（先生の指示。ごちゃごちゃして図が読めなくなる）
           数値は左下の「計算結果を表示」と、右の読み出しの表にまとめてある。 */
        label(ctx, 'r',
          (cx + px) / 2 + nx * 26, (cy + py) / 2 + ny * 26, { size: 12, color: COL.dim, bold: true });
      }
      /* 万有引力（かならず地球の中心を向く）。
         ★長さの決め方★ もとは「力に比例（44 px / Fref）」だったが、
         近づけるほど F は 1/r² で急に大きくなるのに、地球までの画面上の
         きょり dls は逆に短くなるので、上限にぶつかって
         「r₀ を 8000 km より近くしても矢印が長くならない（むしろ短くなる）」
         という状態になっていた（先生の指摘）。
         → 上限 96 px にゆっくり近づく形（飽和する式）にして、
           スライドバーの範囲（7000〜15000 km）では上限にぶつからないようにした。
           r₀ = 10000 km・M = 1 のときちょうど 44 px になるように定数を選んである。 */
      if (s.o.showF) {
        var Fm = P.grav.gm(v.Ms) / (q.r * q.r);
        var Fref = P.grav.gm(1.0) / (10000 * 10000);
        var fr = Fm / Fref;
        var FL = clamp(61 * fr / (fr + 1.01), 8, Math.max(12, dls - 4));
        gravArrow(ctx, px, py, cx, cy, FL, '', 1);
        /* 数字は矢印の「横」に出す。矢じりのそばに置くと、地球の絵に重なって読めない */
        (function () {
          var ux = (cx - px) / Math.max(1e-9, dls), uy = (cy - py) / Math.max(1e-9, dls);
          label(ctx, 'F',
            px + ux * FL * 0.5 + nx * 12, py + uy * FL * 0.5 + ny * 12,
            { size: 12, color: COL.force, bold: true });
        })();
      }
      if (s.o.showV) {
        /* 円軌道の速さ（6.3 km/s）で 46px。1 km/s でも 7px あって、変化が目で分かる。
           ★ただし谷底に近づくと速さが発散するので、矢印の長さは 78px で頭を打たせる★
           （そうしないと、初速度 0 のとき矢印が画面を突きぬける） */
        var vsc = Math.min(46 / Math.max(1e-9, o.vc), 78 / Math.max(1e-9, q.v));
        velArrow(ctx, px, py, q.vx, q.vy, vsc, 'v', 14, 15);
      }
      planetShape(ctx, px, py, 5.6, '#c7ced6');
      label(ctx, '人工衛星', px - nx * 19, py - ny * 19,
        { size: 11, bold: true, color: COL.ink });
      /* ★初速度 0 のときは、谷底に着いたら「出てこれない！」と言う★
         ここで止めないと、計算上は谷底ではね返って戻ってきてしまい、
         「なぜはね返るの？」という別のぎもんを生む。 */
      if (m22Trap(v) && t > DEFS['m2-2'].tEnd(v) * 0.985) {
        bubble(ctx, '谷底に落ちた ＝ 出てこれない！', px, py - 16,
          { size: 13, bg: '#ffffff', border: COL.force, color: COL.force });
      }
    } else {
      /* ★3文字ぶんほど右へ★（先生の指示）左の凡例のカードとぶつかっていたため */
      bubble(ctx, '人工衛星は画面の外へ出ていきました', W / 2 + 38, 74,
        { size: 12.5, bg: '#ffffff', border: orbColor(o.kind), color: orbColor(o.kind) });
    }
    gvKindLegend(ctx, o.kind, m22Trap(v));
    label(ctx, '地球（質量 M）', W - 10, YSP - 30,
      { align: 'right', size: 11, bold: true, color: '#2a5f96' });
    label(ctx, '○印＝はじめの位置 r₀（ドラッグで動かせます）', W - 10, YSP - 12,
      { align: 'right', size: 10.5, color: COL.sub });
    drawClock(ctx, W, 't = ' + fmt(t / 60, 1) + ' 分', 14);
    ctx.restore();                       /* ← 上の絵の clip をここで外す */

    /* さかい目 */
    ctx.save();
    ctx.strokeStyle = COL.grid; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(0, YSP + 0.5); ctx.lineTo(W, YSP + 0.5); ctx.stroke();
    ctx.restore();

    /* ============ 下：位置エネルギーのすりばち（3次元・視点を変えられる） ============ */
    ctx.save();
    var side = gvSideOn(s);
    /* ★真横（U–r グラフ）のときは、下のはしを gvFloor までにしぼる★
       軌道の線やボールが、たて軸の下のはしより下へはみ出さないようにするため。 */
    var yBot = side ? gvFloor(H) : H;
    ctx.beginPath(); ctx.rect(0, YSP + 1, W, yBot - YSP - 1); ctx.clip();
    /* ★真上から見るときは、絵の中心を下の枠のまん中に置く★
       ななめのときと同じ高さ（YSP+96）にすると、いちばん外の輪が上へはみ出す。 */
    var topOn = gvTopOn(s);
    var cam = gvCam(s, W, YSP + (side ? 66 : (topOn ? 155 : 96)));
    var wellCut = gvWell(ctx, cam, v.Ms, side, W, H);

    /* 人工衛星が通る道すじを、すりばちの斜面の上に描く */
    (function () {
      var path = P.grav.path(o, 60000, 300), started = false;
      ctx.save();
      ctx.strokeStyle = orbColor(o.kind); ctx.lineWidth = 2;
      var dsh = orbDash(o.kind);
      if (dsh.length) ctx.setLineDash(dsh);
      ctx.beginPath();
      path.forEach(function (p) {
        var rr = Math.hypot(p[0], p[1]);
        /* すりばちのふちより外は描かない（メッシュのない空中に線が浮いて見えるため） */
        if (rr > P.grav.RMAX * 1.02) { started = false; return; }
        var pp = gvPt(cam, v.Ms, p[0], p[1], P.grav.Uwell(v.Ms, rr));
        if (!started) { ctx.moveTo(pp.x, pp.y); started = true; } else ctx.lineTo(pp.x, pp.y);
      });
      ctx.stroke();
      ctx.restore();
    })();

    /* すりばちの底（地球の位置） */
    (function () {
      var pb = gvPt(cam, v.Ms, 0, 0, P.grav.Uwell(v.Ms, 0));
      earthShape(ctx, pb.x, pb.y, 8, 0);
      label(ctx, '地球', pb.x, pb.y + 17, { size: 10, color: '#2a5f96', bold: true });
    })();

    /* 人工衛星（すりばちの斜面の上）。U = 0 の面までの深さを細い線で結ぶ */
    (function () {
      var rr = Math.max(q.r, 1e-6);
      var uu = P.grav.Uwell(v.Ms, rr);
      var pTop = gvPt(cam, v.Ms, q.x, q.y, 0), pBall = gvPt(cam, v.Ms, q.x, q.y, uu);
      if (pBall.y > H - 6 || pBall.x < 6 || pBall.x > W - 6) return;
      dashLine(ctx, pTop.x, pTop.y, pBall.x, pBall.y, COL.dim, [3, 3], 1);
      /* ★すりばちの上の矢印★ 上の軌道の図とは別のチェックで出す。
         万有引力＝斜面を「下って中心へ向かう」向き、速度＝斜面にそって進む向き。
         どちらも「すりばちの面の上」に貼りついた矢印として描く
         （そうしないと、坂を転がるボールの絵として読めない）。 */
      if (s.o.showFW) {
        /* 力の大きさに比べた「動径方向の伸び」。近いほど長い（逆2乗） */
        var Fw = P.grav.gm(v.Ms) / (rr * rr);
        var Fw0 = P.grav.gm(1.0) / (10000 * 10000);
        var dR = clamp(Fw / Fw0 * 4200, 1200, rr * 0.85);
        var f = (rr - dR) / rr;
        var pF = gvPt(cam, v.Ms, q.x * f, q.y * f, P.grav.Uwell(v.Ms, rr - dR));
        arrow(ctx, pBall.x, pBall.y, pF.x, pF.y, 'force');
        label(ctx, 'F', (pBall.x + pF.x) / 2, (pBall.y + pF.y) / 2 - 12,
          { size: 11.5, color: COL.force, bold: true });
      }
      if (s.o.showVW) {
        /* 少し先（τ 秒後）の位置を、同じすりばちの面の上にとって結ぶ */
        var tau = 900;
        var nx2 = q.x + q.vx * tau, ny2 = q.y + q.vy * tau;
        var nr2 = Math.max(1e-6, Math.hypot(nx2, ny2));
        var pV = gvPt(cam, v.Ms, nx2, ny2, P.grav.Uwell(v.Ms, nr2));
        arrow(ctx, pBall.x, pBall.y, pV.x, pV.y, 'vel');
        label(ctx, 'v', pV.x + 10, pV.y + 10, { size: 11.5, color: COL.vel, bold: true });
      }
      planetShape(ctx, pBall.x, pBall.y, 5.6, '#c7ced6');
      label(ctx, 'U', clamp(pBall.x + 12, 74, W - 74), pBall.y + 14,
        { size: 12, color: COL.upot, bold: true, align: 'left' });
    })();
    ctx.restore();                       /* ← 下の絵の clip をここで外す */

    label(ctx, side ? '【位置エネルギー U のグラフ（真横から見た図）】'
      : (topOn ? '【位置エネルギー U のすりばち（真上から見た図）】'
        : '【位置エネルギー U のすりばち（斜めから見た図）】'), 10, YSP + 16,
      { align: 'left', size: 11, bold: true, color: COL.sub });
    label(ctx, 'U = 0（無限遠が基準）', W - 10, YSP + 16,
      { align: 'right', size: 10.5, color: '#8ea3b8' });
    if (side && wellCut) {
      label(ctx, '破線より下は図に入りきりません（U = −GM/r は r → 0 で無限に深くなる）',
        W / 2, H - 26, { size: 10, color: COL.sub });
    }
    label(ctx, '※ ドラッグで向きを変えられます／地球の半径は ' + fmt(P.grav.RE, 0) +
      ' km です（実際にはここまで近づけません）',
      W / 2, H - 8, { size: 10, color: COL.sub });
    if (hintOn(s, t)) {
      label(ctx, o.bound ? 'E < 0：すりばちから出られない（閉じた軌道）'
        : 'E ≥ 0：すりばちをぬけ出して、戻ってこない',
        W - 10, YSP - 48, { align: 'right', size: 11.5, bold: true, color: orbColor(o.kind) });
    }
  },
  result: function (v, s, t) {
    var o = gravOrb(v);
    var items = [
      resItem('軌道の種類', K.kindName(o.kind)),
      resItem('地球の質量 $M$', fmt(v.Ms, 1) + ' 地球質量'),
      resItem('はじめの距離 $r_0$', fmt(v.r02, 0) + ' km'),
      resItem('初速度 $v_0$', fmt(o.v0km, 3) + ' km/s（k = ' + fmt(v.k2, 1) + '・向き ' + fmt(v.th0, 0) + '°）'),
      resItem('円軌道になる速さ $\\sqrt{GM/r_0}$', fmt(o.vc, 3) + ' km/s'),
      resItem('脱出速度 $\\sqrt{2GM/r_0}$', fmt(o.ve, 3) + ' km/s'),
      resItem('力学的エネルギー $E$', fmt(o.Em, 3) + ' MJ'),
      resItem('はじめの位置エネルギー $U$', fmt(P.grav.U(v.Ms, v.r02), 3) + ' MJ')
    ];
    if (o.bound) {
      items.push(resItem('半長軸 $a$', fmt(o.a, 0) + ' km'));
      items.push(resItem('周期 $T$', fmt(o.T / 60, 1) + ' 分'));
      items.push(resItem('$K = T^2/a^3$', fmtE(o.T * o.T / (o.a * o.a * o.a), 4) + ' s²/km³', true));
    }
    var msg;
    if (o.kind === 'circle') {
      msg = '初速度がちょうど $\\sqrt{GM/r_0}$ で、向きが 90°（動径に垂直）なので<b>円</b>になりました。' +
        'すりばちの<b>同じ深さのところをぐるぐる回っている</b>状態です。';
    } else if (!o.bound) {
      msg = '<b>E ≥ 0 なので、すりばちからぬけ出します</b>。' +
        '無限遠でも運動エネルギーが残るので、二度と戻ってきません。';
    } else if (v.k2 < 1e-9) {
      msg = '初速度が 0 なので、人工衛星は<b>まっすぐ地球へ落ちて</b>いきます。' +
        'ここでは地球を「点」として計算しているので、中心を通りぬけて' +
        '<b>行ったり来たりの振動</b>になります（実際は地面にぶつかります）。';
    } else {
      msg = '<b>E < 0 なので閉じた軌道（楕円）</b>です。' +
        'すりばちの斜面を、深いところ（速い）と浅いところ（遅い）を行き来しながら回っています。';
    }
    return { items: items, note: msg };
  },
  info: function (s, t) {
    var v = V(s), o = gravOrb(v), q = P.grav.at(o, t);
    var U = P.grav.U(v.Ms, q.r);
    return [
      ['地球の中心からの距離 $r$', fmt(q.r, 0) + ' km'],
      ['高度（地表から）', fmt(q.r - P.grav.RE, 0) + ' km'],
      ['速さ $v$', fmt(q.v, 3) + ' km/s'],
      ['万有引力 $F$', fmt(P.grav.gm(v.Ms) / (q.r * q.r) * 1000, 3) + ' N'],
      ['位置エネルギー $U$', fmt(U, 3) + ' MJ'],
      ['運動エネルギー $K$', fmt(o.Em - U, 3) + ' MJ'],
      ['力学的エネルギー $E$', fmt(o.Em, 3) + ' MJ'],
      ['時刻 $t$', fmt(t / 60, 1) + ' 分']
    ];
  },
  eq: function () {
    return 'F = G\\dfrac{mM}{r^2},\\quad U = -G\\dfrac{mM}{r},\\quad ' +
      'E = \\dfrac{1}{2}mv^2 - G\\dfrac{mM}{r}\\;(\\text{一定})';
  }
};

/* ============================================================
   補足：ケプラー則の起源は万有引力（2体問題）　… id は m2-1
   ============================================================ */
/* ★補足（ケプラー則の起源は万有引力）の質量の決め方★
   天体2は「地球くらいの質量」に固定して、天体1だけを重くしていく。
   1倍（＝同じ質量）→ 2倍 → 10倍 → 100倍 → 1太陽質量、の5段階。
   1太陽質量は地球の約33万倍もあるので、なめらかに動かしても途中に意味がない。
   だから「段階を選ぶ」スライドバーにしてある。
   （絵の中の天体の大きさと万有引力の矢印の長さは、けたが違いすぎるのでデフォルメしている。） */
var M21_ME = 3.0034896e-6;          /* 地球質量 ÷ 太陽質量 */
/* P.m21.force が返す力の単位は「太陽質量·AU/年²」。
   これに M21_FN を かけると N（ニュートン）になる。
   1 太陽質量 = 1.98892×10³⁰ kg、1 AU = 1.495979×10¹¹ m、1 年 = 3.15576×10⁷ s。 */
var M21_FN = 1.98892e30 * 1.495979e11 / (3.15576e7 * 3.15576e7);
var M21_STEPS = [
  { r: 1, lab: '1 倍（天体2と同じ）', m1txt: '1 地球質量', short: '1 地球質量', ratxt: '1 : 1' },
  { r: 2, lab: '2 倍', m1txt: '2 地球質量', short: '2 地球質量', ratxt: '2 : 1' },
  { r: 10, lab: '10 倍', m1txt: '10 地球質量', short: '10 地球質量', ratxt: '10 : 1' },
  { r: 100, lab: '100 倍', m1txt: '100 地球質量', short: '100 地球質量', ratxt: '100 : 1' },
  {
    r: 1 / M21_ME, lab: '1 太陽質量（約 33万倍）',
    m1txt: '1 太陽質量（約 33万 地球質量）', short: '1 太陽質量', ratxt: '約 33万 : 1'
  }
];
function m21Step(v) {
  var i = Math.round(v.mi || 0);
  return M21_STEPS[clamp(i, 0, M21_STEPS.length - 1)];
}
/* 図の左上に出す小さな表（天体の色・名前・質量・共通重心の印）。
   質量比を大きくすると天体1が共通重心に重なるので、名前を図の中に書けないため。 */
function m21Legend(ctx, v) {
  var rows = [
    { c: '#c8894a', n: '天体1', t: 'm₁ = ' + m21Step(v).short, col: '#8a5a2b' },
    { c: '#4a86c8', n: '天体2', t: 'm₂ = 1 地球質量', col: '#2a5f96' }
  ];
  var x0 = 8, y0 = 8, w = 232, h = 22 + rows.length * 17;
  ctx.save();
  ctx.fillStyle = 'rgba(255,255,255,.90)';
  ctx.strokeStyle = COL.grid; ctx.lineWidth = 1;
  if (ctx.roundRect) { ctx.beginPath(); ctx.roundRect(x0, y0, w, h, 7); ctx.fill(); ctx.stroke(); }
  else { ctx.fillRect(x0, y0, w, h); ctx.strokeRect(x0, y0, w, h); }
  ctx.restore();
  label(ctx, '質量比 ' + m21Step(v).ratxt, x0 + 9, y0 + 12,
    { size: 10.5, bold: true, color: COL.sub, align: 'left' });
  rows.forEach(function (r, i) {
    var y = y0 + 31 + i * 17;
    planetShape(ctx, x0 + 15, y, 5, r.c);
    label(ctx, r.n, x0 + 26, y, { size: 10.5, bold: true, color: r.col, align: 'left' });
    label(ctx, r.t, x0 + w - 9, y, { size: 10.5, color: r.col, align: 'right' });
  });
}
function m21M1(v) { return m21Step(v).r * M21_ME; }
function m21Orb(v) { return P.m21.make(m21M1(v), M21_ME, v.a2, v.e2); }

DEFS['m2-1'] = {
  id: 'm2-1', mode: 2, tab: '補足：ケプラー則の本質', read: true,
  legendKeys: ['force', 'vel', 'dim', 'bound'],
  units: ['Mearth', 'Msun'],
  title: '補足：ケプラー則の本質　—　万有引力と運動方程式、角運動量保存則、質量比',
  sub: 'ほんとうは「重い天体が止まっていて、軽い天体がそのまわりを回る」のではありません。' +
    '<b>2つの天体は、たがいに万有引力をおよぼし合いながら、共通重心（×印）のまわりを回っています。</b><br>' +
    '天体2は<b>地球くらいの質量</b>に固定してあります。スライドバーで<b>天体1だけを重くしていこう</b>' +
    '（同じ質量 → 2倍 → 10倍 → 100倍 → 1太陽質量）。' +
    '<b>万有引力の2本の矢印はいつも同じ長さ</b>（作用・反作用の法則）で、' +
    '<b>質量の差が大きいほど共通重心が重い方に寄り、軽い方だけが動いて見える</b>ようになります。',
  note: '運動方程式を2つ立てて引き算すると、相対運動は「質量 $m_1+m_2$ の天体が中心にある」' +
    'のと同じ形になります。だから <b>T² = 4π²a³ / G(m₁+m₂)</b>、つまり ' +
    '<b>$K = T^2/a^3$ の値は「中心にある天体の質量」でほぼ決まります</b>。' +
    '天体1を 1 太陽質量にすると K = 1.000（太陽系の惑星と同じ値）になり、' +
    '軽くすると K はどんどん大きくなる。' +
    'だから第3法則は<b>「同じ天体の周りをまわるもの同士」でしか成り立たない</b>のです。',
  /* ★このページの「種明かし」★
     ケプラーの3法則が、それぞれ「何から」出てくるのかを1つの表にまとめる。
     ページ全体でいちばん伝えたいこと（＝惑星だけの特別な法則ではない）なので、
     いちばん論理がはっきりするこのシミュレーションに置く。 */
  sideText:
    '<span class="q">ケプラー3法則の起源</span>' +
    '<table class="mini">' +
    '<tr><th>法則</th><th>成り立つのに必要なもの</th><th>質量比</th></tr>' +
    /* ★3行の書き方をそろえること★（先生の指示・2026-09-03）
       第1法則と第3法則は、どちらも「万有引力の性質」から出てくる。
       だから同じ言い方（万有引力の性質（中心力 ＋ 大きさが距離の逆2乗に比例））で書き、
       第3法則だけは そこに「＋ 中心の天体が圧倒的に重いこと」が足される、
       という形にすると、3つの法則の関係が一目で分かる。 */
    '<tr><td><b>第1法則</b><br>楕円軌道</td>' +
    '<td><b>万有引力の性質</b>（中心力 ＋ <b>大きさが距離の逆2乗に比例</b>）</td>' +
    '<td class="c">関係なし</td></tr>' +
    '<tr><td><b>第2法則</b><br>面積速度一定<br>（＝角運動量保存）</td>' +
    '<td>万有引力が<b>いつも1点を向いている（中心力）</b>こと</td>' +
    '<td class="c">関係なし</td></tr>' +
    '<tr><td><b>第3法則</b><br>$T^2/a^3$ 一定</td>' +
    '<td><b>万有引力の性質</b>（中心力 ＋ <b>大きさが距離の逆2乗に比例</b>） ＋ ' +
    '<b>中心の天体が圧倒的に重いこと</b></td>' +
    '<td class="c"><b>関係あり</b></td></tr>' +
    '</table>' +
    '<b>第2法則の正体は「角運動量保存則」です。</b>' +
    '力がいつも1点（太陽）を向いている（＝中心力）と、その点のまわりの<b>力のモーメントが 0</b> になり、' +
    '<b>角運動量 $L = mrv\\sin\\theta$ が保存します</b>。' +
    '面積速度は $\\dfrac{dS}{dt} = \\dfrac{1}{2}rv\\sin\\theta = \\dfrac{L}{2m}$ なので、' +
    '「面積速度一定」と「角運動量保存」は<b>まったく同じことを別の言い方でいったもの</b>です。' +
    '（角運動量そのものについては ' +
    '<b><a href="#m4-2" data-goto="m4-2">補足：なぜ面積速度が一定なのか</a></b> で詳しく扱います。）<br>' +
    'つまり<b>「惑星だけに用意された特別な法則」があるわけではありません</b>。' +
    '<b>①万有引力の性質</b>と<b>②運動方程式</b>から出てくる結果を、' +
    'ケプラーが観測から先に見つけていた、というだけのことです。<br>' +
    '<b>第3法則だけは「比べる相手」に条件がつきます。</b>正しい式は ' +
    '$T^2 = \\dfrac{4\\pi^2 a^3}{G(m_1+m_2)}$ で、' +
    '$T^2/a^3$ の値は<b>中心にある天体の質量でほぼ決まってしまう</b>からです。' +
    'そろうのは<b>「同じ天体のまわりを回っているもの同士」</b>だけ。' +
    '太陽のまわりの惑星どうしなら 1.00 年²/AU³ でそろいますが、' +
    '地球のまわりの月や人工衛星は、まったく違う値になります。' +
    '（回っている方の質量 $m_2$ も式に入っていますが、惑星は太陽よりずっと軽いので、ふつうは無視できます。）<br>' +
    '左の図で<b>天体1を軽くしていくと、K の値が大きくずれていく</b>のを確かめよう。<br>' +
    'なお<b>力学的エネルギー保存</b>は「3法則が成り立つ理由」ではなく、' +
    '「その軌道が<b>どんな形・どんな大きさ</b>になるか」を決めるときに使います（→ 2-2）。',
  cw: 560, ch: 400,
  loop: true,
  vis: ['F', 'V'],
  visLabel: { F: '万有引力を表示', V: '速度を表示' },
  visDef: { F: true },              /* 万有引力は最初から出す（このシムの主役なので） */
  vars: [
    {
      k: 'mi', label: '天体1の質量（天体2の何倍か）', unit: '',
      min: 0, max: M21_STEPS.length - 1, step: 1, dec: 0, def: 0,
      hint: '天体2は地球質量に固定',
      fmt: function (x) { return m21Step({ mi: x }).lab; }
    },
    { k: 'a2', label: '2天体の間の半長軸 $a$', unit: ' AU', min: 0.6, max: 2.0, step: 0.1, dec: 1, def: 1.2 },
    { k: 'e2', label: '離心率 $\\varepsilon$', unit: '', min: 0, max: 0.6, step: 0.05, dec: 2, def: 0.20 }
  ],
  mainVars: ['mi'],
  topActions: [
    {
      /* ★帯が出るのと同時に、このボタンを光らせる★（先生の指示）
         「動かないのが見えた」→「では重くしてみよう」と手が動くように。
         いちばん重い（1 太陽質量）まで来たら、もう押す先がないので光をやめる。 */
      label: '重い方をより重く →', prim: true, play: true,
      glow: function (v, s) {
        return runOver(s, 2) && Math.round(v.mi) < M21_STEPS.length - 1;
      },
      fn: function (s) { stepUp(DEFS['m2-1'], s, 'mi', 1); }
    },
    {
      label: '質量を同じにする（1 : 1）',
      fn: function (s) { s.v.mi = 0; },
      is: function (v) { return Math.round(v.mi) === 0; }
    }
  ],
  tEnd: function (v) { return m21Orb(v).T; },
  rate: function (v) { return m21Orb(v).T / 9; },
  tFmt: function (t) { return fmt(t, 2) + ' 年'; },
  xlabel: 't [年]',
  sample: function (v, t) {
    var o = m21Orb(v);
    var q = P.m21.state(o, t);
    return {
      r: q.r, v: q.v,
      r1: Math.hypot(q.b1.x, q.b1.y), r2: Math.hypot(q.b2.x, q.b2.y),
      v1: Math.hypot(q.b1.vx, q.b1.vy), v2: Math.hypot(q.b2.vx, q.b2.vy),
      px: o.m1 * q.b1.vx + o.m2 * q.b2.vx,      /* 運動量の和（いつも 0） */
      py: o.m1 * q.b1.vy + o.m2 * q.b2.vy,
      F: P.m21.force(o, q.r)
    };
  },
  /* 右のグラフは出さない（先生の指示。図と計算結果の帯だけで読み取れるようにする） */
  graphs: [],
  draw: function (ctx, s, t, W, H) {
    var v = V(s), o = m21Orb(v), i;
    var q = P.m21.state(o, t);
    /* ★縮尺は固定する★
       「2つの軌道がちょうど入るように」自動で決めていたら、半長軸 a を変えても質量を変えても
       絵の大きさがそろってしまい、「スライドバーが効かない」ように見えていた。
       大きさは「a = 2.0 AU の軌道」がだいたい入るところにとってある。
       ε を大きくすると少しはみ出すが、それは「大きくなった」ことが伝わるので、そのままでよい。 */
    var box = 1.9;
    var vw = mkView(W, H, { l: 40, r: 40, t: 38, b: 40 },
      { x0: -box, x1: box, y0: -box * 0.72, y1: box * 0.72 });
    s.view = vw;

    /* それぞれの軌道（相対軌道を f1・f2 倍したもの） */
    [{ f: -o.f1, col: COL.sect3 }, { f: o.f2, col: COL.bound }].forEach(function (bd) {
      ctx.save();
      ctx.strokeStyle = fade(bd.col, 0.65); ctx.lineWidth = 1.4;
      ctx.beginPath();
      for (i = 0; i <= 220; i++) {
        var E = TAU * i / 220;
        var xx = bd.f * o.a * (Math.cos(E) - o.e), yy = bd.f * o.b * Math.sin(E);
        var pp = [vw.X(xx), vw.Y(yy)];
        if (i === 0) ctx.moveTo(pp[0], pp[1]); else ctx.lineTo(pp[0], pp[1]);
      }
      ctx.closePath(); ctx.stroke();
      ctx.restore();
    });

    var cx = vw.X(0), cy = vw.Y(0);
    var p1 = { x: vw.X(q.b1.x), y: vw.Y(q.b1.y) };
    var p2 = { x: vw.X(q.b2.x), y: vw.Y(q.b2.y) };

    /* 2天体を結ぶ線（距離 r） */
    dashLine(ctx, p1.x, p1.y, p2.x, p2.y, COL.dim, [5, 4], 1.2);
    /* 距離の文字は「線に垂直な向き」にずらす。線の上に置くと万有引力の矢印と重なるし、
       反対がわ（−15）に置くと「共通重心（×印）」の文字とぶつかる。 */
    /* 距離の文字は「線のまん中」ではなく天体2よりに置く。質量比を大きくすると
       天体1が共通重心に重なるので、まん中に置くと「共通重心（×印）」の文字とぶつかる。 */
    (function () {
      var dxr = p2.x - p1.x, dyr = p2.y - p1.y, Lr = Math.hypot(dxr, dyr) || 1;
      var mxr = p1.x + dxr * 0.7, myr = p1.y + dyr * 0.7;
      label(ctx, 'r = ' + fmt(q.r, 3) + ' AU',
        mxr - dyr / Lr * 22, myr + dxr / Lr * 22, { size: 11, color: COL.dim, bold: true });
    })();

    /* 天体（質量に応じて大きさを変える）。
       ★大きさはデフォルメ★ 1倍から33万倍まであるので、そのまま（半径 ∝ 質量^⅓）にすると
       画面に入らない。ここでは「けたが1つ上がるごとに少し大きく」＝対数のものさしにしている。 */
    var rat = m21Step(v).r;
    var s1 = clamp(6 + 1.6 * Math.log(rat) / Math.LN10, 6, 15);
    var s2 = 6;
    planetShape(ctx, p1.x, p1.y, s1, '#c8894a');
    planetShape(ctx, p2.x, p2.y, s2, '#4a86c8');
    /* 名前は天体の「上」に置く。共通重心の文字は下に置いてあるので、
       天体1が重心のすぐそばに来ても重ならない。 */
    /* ★天体の名前と質量は、図の中ではなく左上の小さな表に出す★
       質量比を大きくすると天体1が共通重心にぴったり寄るので、図の中に文字を置くと
       「共通重心（×印）」の文字と必ず重なってしまうため。 */

    /* 万有引力（2本は必ず同じ長さ＝作用・反作用） */
    if (s.o.showF) {
      /* ★矢印の長さは「力の大きさそのもの」に比例させる★
         もとは「そのときの近点の力」で割って正規化していたので、質量をいくら大きくしても
         矢印の長さが変わらなかった（＝スライドバーが効いていないように見えた）。
         いまは決まったものさし（既定の設定でおよそ 50px）で描く。
         画面からはみ出さないよう、上限だけ決めておく。 */
      /* ★矢印の長さは対数のものさし（デフォルメ）★
         質量比が 1倍〜33万倍まであるので、力の大きさは 33万倍も違う。
         長さをそのまま比例させると、1倍のときは 0.0003px（見えない）か、
         1太陽質量のときに画面をはみ出すかのどちらかになってしまう。
         そこで「10倍ごとに同じだけ長くなる」対数のものさしで描く。
         見せたいのは「2本がいつも同じ長さ（作用・反作用）」なので、これで困らない。 */
      var LG = Math.log(rat) / Math.LN10 / (Math.log(1 / M21_ME) / Math.LN10);
      /* 長さの上限は「2天体の間の 0.92」まで。相手の天体を突きぬけると、
         どちらの天体が受けている力なのか分からなくなるため。 */
      var sep = Math.hypot(p2.x - p1.x, p2.y - p1.y);
      var L = clamp(14 + 96 * LG, 5, Math.min(150, sep * 0.92));
      /* F の文字は、天体の名前と反対がわ（距離 r と同じがわ）に出す */
      gravArrow(ctx, p1.x, p1.y, p2.x, p2.y, L, 'F', -1);
      gravArrow(ctx, p2.x, p2.y, p1.x, p1.y, L, 'F', 1);
    }
    /* 速度 */
    if (s.o.showV) {
      var vmax = Math.max(1e-9, o.vp * Math.max(o.f1, o.f2));
      var vsc = 52 / vmax;
      velArrow(ctx, p1.x, p1.y, q.b1.vx, q.b1.vy, vsc, null);
      velArrow(ctx, p2.x, p2.y, q.b2.vx, q.b2.vy, vsc, null);
    }
    /* ★共通重心の×印は、天体や矢印より「あと」に描いて前面に出す★
       重い天体がすぐそばを回るので、先に描くと下にかくれてしまう。
       文字も×印のすぐ下に固定して書く（重心は動かないので、これで十分読める）。 */
    ctx.save();
    ctx.strokeStyle = '#fff'; ctx.lineWidth = 4.5; ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(cx - 7, cy - 7); ctx.lineTo(cx + 7, cy + 7);
    ctx.moveTo(cx + 7, cy - 7); ctx.lineTo(cx - 7, cy + 7);
    ctx.stroke();
    ctx.strokeStyle = COL.cg; ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.moveTo(cx - 7, cy - 7); ctx.lineTo(cx + 7, cy + 7);
    ctx.moveTo(cx + 7, cy - 7); ctx.lineTo(cx - 7, cy + 7);
    ctx.stroke();
    ctx.restore();
    label(ctx, '共通重心（×印）', cx, cy + 18, { size: 11, color: COL.cg, bold: true });

    m21Legend(ctx, v);
    /* ★このシミュレーションでいちばん伝えたいこと★
       図のまん中の目立つところに、うすい白地の帯で2行だけ書く。
       （下のすみに小さく書くと、動く絵にまぎれて読まれないため。） */
    /* ★この帯は「スタートを押して2秒たってから」出す★（先生の指示）
       開いた瞬間から出ていると、まだ何も動いていないので何のことか分からない。
       2秒ぶん動きを見てから出すと、「たしかに天体1は動いていないな」と
       目で確かめたあとに言葉が来るので、すっと入る。
       同時に「重い方をより重く →」のボタンも光らせて、つぎの操作へ誘う。 */
    if (runOver(s, 2)) (function () {
      var by = 76, bh = 40;
      ctx.save();
      ctx.fillStyle = 'rgba(255,255,255,.90)';
      ctx.strokeStyle = fade(COL.cg, 0.5); ctx.lineWidth = 1;
      if (ctx.roundRect) { ctx.beginPath(); ctx.roundRect(10, by, W - 20, bh, 8); ctx.fill(); ctx.stroke(); }
      else { ctx.fillRect(10, by, W - 20, bh); ctx.strokeRect(10, by, W - 20, bh); }
      ctx.restore();
      label(ctx, '天体1の質量が重くなるほど、共通重心と天体1の位置は重なる',
        W / 2, by + 13, { size: 12, bold: true, color: COL.ink });
      label(ctx, '（つまり、天体1は相対的に「動かなく」なる）',
        W / 2, by + 29, { size: 11.5, bold: true, color: COL.cg });
    })();
    drawClock(ctx, W, 't = ' + fmtAuto(t, 2) + ' 年');
    /* 絵の描き方のことわりなので、ヒントではない（いつでも出す） */
    label(ctx, '※ 天体の大きさと矢印の長さは対数のものさし（デフォルメ）', W - 10, H - 12,
      { align: 'right', size: 10, color: COL.sub });
    if (hintOn(s, t)) {
      /* 図の中は天体の名前でこみ合うので、この2行は下にそろえて置く */
      label(ctx, '2本の万有引力はいつも同じ長さ（作用・反作用）', W - 10, H - 28,
        { align: 'right', size: 11.5, color: COL.force, bold: true });
      label(ctx, '重心は動かない（運動量の和はいつも 0）', 10, H - 12,
        { align: 'left', size: 11, color: COL.cg, bold: true });
    }
  },
  result: function (v, s, t) {
    var o = m21Orb(v);
    var Kv = o.T * o.T / (o.a * o.a * o.a);
    return {
      items: [
        resItem('天体1の質量 $m_1$', m21Step(v).m1txt),
        resItem('天体2の質量 $m_2$', '1 地球質量'),
        resItem('質量比 $m_1 : m_2$', m21Step(v).ratxt),
        resItem('半長軸 $a$（2天体の間）', fmt(o.a, 3) + ' AU'),
        resItem('周期 $T$', fmtAuto(o.T, 3) + ' 年'),
        resItem('$K = T^2/a^3$', fmtAuto(Kv, 4) + ' 年²/AU³', true),
        resItem('重心までの距離', fmtAuto(o.a1, 3) + ' : ' + fmtAuto(o.a2, 3) + ' AU')
      ],
      note: '$K = \\dfrac{4\\pi^2}{G(m_1+m_2)}$ なので、<b>K の値は中心にある天体の質量でほぼ決まります</b>。' +
        'いまの合計質量は ' + fmtAuto(o.M / M21_ME, 0) + ' 地球質量で、K = ' + fmtAuto(Kv, 4) + '。' +
        '天体1を 1 太陽質量にすると K = 1.000 になり、太陽系の惑星と同じ値になります。' +
        'だから第3法則は<b>「同じ天体の周りをまわるもの同士」でしか成り立ちません</b>。'
    };
  },
  info: function (s, t) {
    var v = V(s), o = m21Orb(v), m = DEFS['m2-1'].sample(v, t);
    return [
      ['2天体の間の距離 $r$', fmt(m.r, 3) + ' AU'],
      ['重心から天体1まで $r_1$', fmt(m.r1, 3) + ' AU'],
      ['重心から天体2まで $r_2$', fmt(m.r2, 3) + ' AU'],
      ['$m_1 r_1$（地球質量·AU）', fmtAuto(o.m1 / M21_ME * m.r1, 4)],
      ['$m_2 r_2$（同じ値になる）', fmtAuto(o.m2 / M21_ME * m.r2, 4)],
      ['天体1の速さ $v_1$', fmt(m.v1, 3) + ' AU/年'],
      ['天体2の速さ $v_2$', fmt(m.v2, 3) + ' AU/年'],
      ['運動量の和（いつも 0）', fmt(Math.hypot(m.px, m.py), 4)],
      /* 太陽質量・AU・年の単位系のままだと F は 10⁻⁹ ほどの数になって読めないので、
         N（ニュートン）に直して出す（M21_FN 倍する。定義は上のコメントを見ること）。 */
      ['万有引力 $F$', fmtE(m.F * M21_FN, 3) + ' N']
    ];
  },
  eq: function (s) {
    return EQM + 'm_1\\vec{a}_1 = G\\dfrac{m_1m_2}{r^2}\\,\\vec{e},\\quad ' +
      'm_2\\vec{a}_2 = -G\\dfrac{m_1m_2}{r^2}\\,\\vec{e} \\;\\Rightarrow\\; ' +
      'T^2 = \\dfrac{4\\pi^2 a^3}{G(m_1+m_2)}';
  }
};

/* ============================================================
   2-3　惑星の運動と軌道の関係／第一宇宙速度〜第二宇宙速度
   ============================================================ */
var M23 = { R: 6371, GM: 398600.4418, RMAX: 90000 };
function m23Orb(v) {
  /* 打ち出す場所は地表に固定。速さは「√(k gR) の k」で決める（教科書の書き方に合わせる）。
     r = R では vc = √(GM/R) = √(gR) なので、v0 = √k × vc。 */
  var r0 = M23.R, vc = Math.sqrt(M23.GM / r0);
  var k = (v.k3 === undefined ? 1 : v.k3);
  var kv = Math.sqrt(k);
  var o = K.orb(r0, 0, kv * vc, M23.GM);
  o.vc = vc; o.v0 = kv * vc; o.kv = kv; o.k3 = k;
  return o;
}
/* 図の左上に出す「軌道の見分け方」。
   オレンジのボタン（円・楕円・放物線・双曲線）をやめた代わりに、
   「どの k がどの軌道になるか」を、実際の線の色と形の見本つきで置く。
   いまの k にあたる行だけ太字にして、スライドバーとつながるようにする。 */
function m23Legend(ctx, s, k) {
  var rows = [
    { name: '円', k: 'k = 1.0', col: COL.bound, dash: [], on: Math.abs(k - 1) < 0.05 },
    { name: '楕円', k: 'k = 1.1 〜 1.9', col: COL.bound, dash: [], on: k > 1.05 && k < 1.95 },
    { name: '放物線', k: 'k = 2.0', col: COL.para, dash: [8, 5], on: Math.abs(k - 2) < 0.05 },
    { name: '双曲線', k: 'k = 2.1 以上', col: COL.hyper, dash: [12, 4, 3, 4], on: k > 2.05 }
  ];
  var x0 = 8, y0 = 8, w = 208, h = 20 + rows.length * 17;
  ctx.save();
  ctx.fillStyle = 'rgba(255,255,255,.90)';
  ctx.strokeStyle = COL.grid; ctx.lineWidth = 1;
  if (ctx.roundRect) { ctx.beginPath(); ctx.roundRect(x0, y0, w, h, 7); ctx.fill(); ctx.stroke(); }
  else { ctx.fillRect(x0, y0, w, h); ctx.strokeRect(x0, y0, w, h); }
  ctx.restore();
  label(ctx, '軌道の見分け方', x0 + 9, y0 + 12, { size: 10.5, bold: true, color: COL.sub, align: 'left' });
  rows.forEach(function (r, i) {
    var y = y0 + 29 + i * 17;
    ctx.save();
    ctx.strokeStyle = r.col; ctx.lineWidth = r.on ? 3 : 2;
    if (r.dash.length) ctx.setLineDash(r.dash);
    ctx.beginPath(); ctx.moveTo(x0 + 9, y); ctx.lineTo(x0 + 39, y); ctx.stroke();
    ctx.restore();
    label(ctx, r.name, x0 + 45, y, { size: 11, bold: r.on, color: r.on ? r.col : COL.sub, align: 'left' });
    label(ctx, r.k, x0 + w - 9, y, { size: 10.5, bold: r.on, color: r.on ? r.col : '#9aa5b1', align: 'right' });
  });
}

DEFS['m2-3'] = {
  id: 'm2-3', mode: 2, tab: '2-2 軌道の種類と宇宙速度',
  legendKeys: ['force', 'sun', 'vel', 'dim', 'bound', 'para', 'hyper', 'upot'],
  title: '2-2　惑星の運動と軌道の関係　—　第一宇宙速度から第二宇宙速度へ',
  sub: '地表から真横に打ち出す<b>初速度</b>を、$v_0 = \\sqrt{k\\,gR}$ の <b>k</b> で変えてみよう'
    + '（$g$ は地表の重力加速度、$R$ は地球の半径。$k=1$ が第一宇宙速度、$k=2$ が第二宇宙速度）。<br>'
    + '<b>力学的エネルギー $E = \\tfrac{1}{2}mv^2 - G\\dfrac{mM}{r}$ の符号だけで、軌道の形が決まります。</b>'
    + '<b>E&lt;0 なら円・楕円</b>（緑・閉じた軌道）、<b>E=0 ならちょうど放物線</b>（金・破線）、'
    + '<b>E&gt;0 なら双曲線</b>（濃いグレー・一点鎖線）。軌道の線の色と形も、それに合わせて変わります。<br>'
    + '★<b>この $k$ は 1-4・2-1 とまったく同じもの</b>★　'
    + '2-1 の $v_0=\\sqrt{k\\,GM/r_0}$ は、地表（$r_0=R$）では $GM/R=gR$ なので、'
    + 'ここの $v_0=\\sqrt{k\\,gR}$ と同じ式です'
    + '（→ <a href="#m2-2" data-goto="m2-2">2-1 万有引力と位置エネルギー</a>）。',
  /* 図は「横に長い楕円」を入れるので、縦は低めにする（上下のあきを減らすため） */
  cw: 560, ch: 324,
  loop: true,
  /* 万有引力は「人工衛星が受けるぶんだけ」を出す（地球が受ける反作用は、ここでは描かない）。
     見せたいのは「遠ざかるほど力が弱くなるのに、それでも E<0 なら引き戻される」ことなので。 */
  vis: ['F', 'V', 'R'],
  visLabel: { F: '万有引力を表示', V: '速度を表示', R: '動径を表示' },
  visDef: { F: false },
  vars: [
    /* 打ち出す速さは「$v_0=\\sqrt{k\\,gR}$ の k」で決める（教科書と同じ書き方）。
       k = 1 が第一宇宙速度、k = 2 が第二宇宙速度。0.1 きざみで十分。 */
    {
      /* ★2-1 とまったく同じ書き方にそろえること★（下の「ハマったところ」を読むこと）
         ラベル＝「初速度 $v_0=\\sqrt{k\\,〇〇}$ の $k$」、説明＝1行。 */
      k: 'k3', label: '初速度 $v_0 = \\sqrt{k\\,gR}$ の $k$', unit: '',
      hint: '$\\sqrt{gR}$＝第一宇宙速度 7.9 km/s　k = 1 円／2 放物線／2超 双曲線',
      min: 1.0, max: 4.0, step: 0.1, dec: 1, def: 1.0
    }
  ],
  mainVars: ['k3'],
  topActions: [
    {
      label: '速さを上げる →', prim: true, play: true,
      /* ★きざみは「1〜2 は 0.1／2.1 から先は 0.3」★（先生の指示・2026-09-03）
         1 ずつだと、1回押しただけで円 → 脱出まで飛んでしまい、
         「少しずつ速くすると、円 → だ円 → 放物線 → 双曲線 と変わる」ようすが見えない。
         いちばん見せたい 1〜2 のあいだをこまかく、そこから先は大きく進める。
         上限（k = 4.0）で止める。1.0 に戻ると「脱出したのに円に戻った」と見えるため。 */
      dis: function (v) { return v.k3 >= 4.0 - 1e-9; },
      fn: function (s) {
        var k = s.v.k3;
        s.v.k3 = +Math.min(4.0, k + (k <= 2.0 + 1e-9 ? 0.1 : 0.3)).toFixed(1);
      }
    },
    {
      label: '第一宇宙速度（地表すれすれの円）', prim: true,
      fn: function (s) { s.v.k3 = 1.0; },
      is: function (v) { return Math.abs(v.k3 - 1) < 1e-9; }
    },
    {
      label: '第二宇宙速度（脱出）', prim: true,
      fn: function (s) { s.v.k3 = 2.0; },
      is: function (v) { return Math.abs(v.k3 - 2) < 1e-9; }
    }
  ],
  /* 「円・楕円・放物線・双曲線」のボタンは置かない。
     代わりに、図の左上に「どの k がどの軌道になるか」の見分け方を出す（m23Legend）。 */
  tEnd: function (v) {
    var o = m23Orb(v);
    if (o.bound) return o.T;
    return Math.max(60, o.tTo(M23.RMAX));
  },
  rate: function (v) { return DEFS['m2-3'].tEnd(v) / 10; },
  tFmt: function (t) { return fmt(t / 60, 1) + ' 分'; },
  xlabel: 't [分]',
  sample: function (v, t) {
    var o = m23Orb(v), q = o.at(t);
    q.U = -M23.GM / q.r;
    q.K = q.v * q.v / 2;
    q.E = o.Em;
    return q;
  },
  graphs: [
    {
      key: 'en', short: 'エネルギーの図', title: '$U$・$K$・$E$ を重ねた図（横軸は距離 $r$）', open: true,
      /* 3本の線が重なってつぶれるので、この図だけ縦を2倍にする */
      H: 348,
      custom: function (v, s, t) {
        var o = m23Orb(v), i, U = [], Kk = [], E = [], rmax = M23.RMAX;
        var rlo = M23.R;
        for (i = 0; i <= 200; i++) {
          var rr = rlo + (rmax - rlo) * i / 200;
          var u = -M23.GM / rr;
          U.push([rr, u]);
          E.push([rr, o.Em]);
          var kk = o.Em - u;
          Kk.push([rr, kk >= 0 ? kk : NaN]);        /* K<0 のところへは行けない */
        }
        var q = o.at(t);
        /* ★ o.at(t) は軌道の位置と速さしか返さない（U・K は入っていない）★
           ここで計算しないと、いまの U・K の点が「値なし」になって出なくなる。 */
        var qU = -M23.GM / q.r, qK = o.Em - qU;
        return {
          /* たて軸は「地表での運動エネルギー」が入る高さまでとる。
             ここを 20 で止めていたので、K の線が上で切れてしまっていた。 */
          xmin: 0, xmax: rmax, ymin: -70, ymax: Math.max(20, (o.Em + M23.GM / M23.R) * 1.15),
          xlabel: 'r [km]', ylabel: 'E/m [MJ/kg]',
          legend: true,
          series: [
            { color: COL.upot, width: 2.4, pts: U, name: 'U = −GM/r' },
            { color: COL.sect2, width: 2.0, pts: Kk, name: 'K = E − U' },
            { color: COL.cg, width: 2.0, dash: [7, 4], pts: E, name: 'E（一定）' }
          ],
          /* いまの位置（＝いまの高度）がどこかを、たて線と大きめの点で目立たせる */
          vline: { x: q.r, color: COL.vel, label: 'いまの人工衛星（r = ' + fmt(q.r, 0) + ' km）' },
          /* ★左の図の人工衛星が、いまグラフのどこにいるかを点で示す★
             線と同じ色だと線に埋もれて見えないので、青にして名前もそえる
             （1-0 の T–a 図で選んだ天体を青い輪で示すのと同じ約束）。 */
          cursors: [
            { color: COL.vel, x: q.r, y: qU, r: 6.6, name: 'いまの U', lx: 10, ly: 12, align: 'left' },
            { color: COL.vel, x: q.r, y: qK, r: 6.6, name: 'いまの K', lx: 10, ly: -12, align: 'left' },
            { color: COL.vel, x: q.r, y: o.Em, r: 5.2, name: 'いまの E', lx: 10, ly: -11, align: 'left' }
          ],
          marks: o.bound ? [
            { x: o.q, y: o.Em, color: COL.sub, r: 4, name: '近点', lx: -5, ly: 13, align: 'right' },
            { x: o.ra, y: o.Em, color: COL.sub, r: 4, name: '遠点', lx: 5, ly: 13, align: 'left' }
          ] : []
        };
      },
      fml: function (v) {
        var o = m23Orb(v);
        return [
          'E = \\dfrac{1}{2}mv^2 - G\\dfrac{mM}{r}\\;(\\text{一定})',
          'E < 0 \\Rightarrow \\text{円・楕円},\\quad E = 0 \\Rightarrow \\text{放物線},\\quad E > 0 \\Rightarrow \\text{双曲線}',
          'E/m = ' + fmt(o.Em, 3) + '\\;\\mathrm{MJ/kg} \\;\\Rightarrow\\; ' + K.kindName(o.kind)
        ];
      }
    },
    {
      key: 'Fr', short: '$F$–$r$ 図', title: '$F$–$r$ 図（万有引力の大きさ）', open: false,
      custom: function (v, s, t) {
        var pts = [], i, rmax = M23.RMAX;
        for (i = 0; i <= 200; i++) {
          var rr = M23.R + (rmax - M23.R) * i / 200;
          pts.push([rr, M23.GM / (rr * rr) * 1000]);
        }
        var q = m23Orb(v).at(t);
        return {
          xmin: 0, xmax: rmax, ymin: 0, ymax: 11,
          xlabel: 'r [km]', ylabel: 'F/m [m/s²]',
          series: [{ color: COL.force, width: 2.4, pts: pts }],
          cursors: [{ color: COL.force, x: q.r, y: M23.GM / (q.r * q.r) * 1000 }]
        };
      }
    },
    {
      key: 'vt', short: '$v$–$t$ 図', title: '$v$–$t$ 図（速さ）', open: false,
      ylabel: 'v [km/s]', xf: function (m, v, t) { return t / 60; },
      series: [{ color: COL.vel, f: function (m) { return m.v; } }],
      fml: function (v) {
        var o = m23Orb(v);
        return [
          'v = \\sqrt{GM\\left(\\dfrac{2}{r} - \\dfrac{1}{a}\\right)}',
          '\\text{閉じた軌道では } a > 0,\\;\\; \\text{双曲線では } a < 0',
          'v_0 = ' + fmt(o.v0, 3) + '\\;\\mathrm{km/s}\\;\\;(v_c = ' + fmt(o.vc, 3) + ')'
        ];
      }
    }
  ],
  draw: function (ctx, s, t, W, H) {
    var v = V(s), o = m23Orb(v), i;
    var q = o.at(t);
    /* ★縮尺は固定★。地球は画面の「右」に置く。
       打ち出す点（近地点）は地球の右端で、軌道は左へのびるので、
       地球を右に寄せると左のあきを軌道に使える。
       大きさは「k = 1.9（第二宇宙速度の少し手前）の楕円が全部入る」ようにとってある
       （a = R/(2−k) = 10R、遠地点 = 19R）。 */
    var R0 = M23.R;
    var vw = mkView(W, H, { l: 34, r: 34, t: 36, b: 34 },
      { x0: -19.6 * R0, x1: 2.2 * R0, y0: -4.9 * R0, y1: 4.9 * R0 });
    s.view = vw;

    /* めやすの軌道（k = 1.9 のとき）を、うすい破線でいつも描いておく。
       縮尺を固定しているので、これがないと k が小さいときに絵がスカスカに見えるため。
       「どこまで大きくなるのか」の目安にもなる。 */
    (function () {
      var og = K.orb(R0, 0, Math.sqrt(1.9) * Math.sqrt(M23.GM / R0), M23.GM);
      var gp = og.path(46 * R0, 360);
      ctx.save();
      ctx.strokeStyle = COL.grid; ctx.lineWidth = 1.4; ctx.setLineDash([5, 4]);
      ctx.beginPath();
      gp.forEach(function (p2, j) {
        var pp2 = [vw.X(p2[0]), vw.Y(p2[1])];
        if (j === 0) ctx.moveTo(pp2[0], pp2[1]); else ctx.lineTo(pp2[0], pp2[1]);
      });
      ctx.closePath(); ctx.stroke();
      ctx.restore();
      label(ctx, 'めやす：k = 1.9 の楕円', vw.X(-og.ra) + 6, vw.Y(0),
        { size: 10, color: '#b3bcc5', align: 'left' });
    })();

    /* 軌道（種類で色と線の形が変わる） */
    var path = o.path(46 * R0, 480);
    ctx.save();
    ctx.strokeStyle = orbColor(o.kind); ctx.lineWidth = 2.2;
    var dsh = orbDash(o.kind);
    if (dsh.length) ctx.setLineDash(dsh);
    ctx.beginPath();
    path.forEach(function (p, j) {
      var pp = [vw.X(p[0]), vw.Y(p[1])];
      if (j === 0) ctx.moveTo(pp[0], pp[1]); else ctx.lineTo(pp[0], pp[1]);
    });
    if (o.bound) ctx.closePath();
    ctx.stroke();
    ctx.restore();

    /* 地球 */
    var Rpx = Math.max(7, vw.X(M23.R) - vw.X(0));
    earthShape(ctx, vw.X(0), vw.Y(0), Rpx, 0);
    label(ctx, '地球', vw.X(0), vw.Y(0) + Rpx + 12, { size: 11, color: '#2a5f96', bold: true });

    var px = vw.X(q.x), py = vw.Y(q.y);
    /* 軌道が小さいときは、地球のまわりに文字が集まってつぶれるので、値の文字は出さない */
    var farEnough = Math.hypot(px - vw.X(0), py - vw.Y(0)) > 52;
    /* 人工衛星が画面の中にいるかどうか。外に出たら、絵も文字も描かない
       （画面のはしに文字だけが残ると、何の数字なのか分からなくなるため）。 */
    var inFrame = (px > 8 && px < W - 8 && py > 8 && py < H - 8);
    if (inFrame) {
      if (s.o.showR) radiusLine(ctx, vw.X(0), vw.Y(0), px, py, farEnough ? ('r = ' + fmt(q.r, 0) + ' km') : '');
      planetShape(ctx, px, py, 5.2, '#c7ced6');
      /* 名前は「地球から見て外向き」にずらす（地球の絵と重ならないように） */
      (function () {
        var ox = px - vw.X(0), oy = py - vw.Y(0), od = Math.hypot(ox, oy) || 1;
        label(ctx, '人工衛星', px + ox / od * 17, py + oy / od * 17,
          { size: 10.5, bold: true, color: COL.ink });
      })();
      /* 人工衛星が受ける万有引力（かならず地球の中心を向く）。
         長さは力の大きさにそのまま比例させる（地表で 70px）。
         遠ざかるとぐんぐん短くなるのが、逆2乗の法則そのもの。 */
      if (s.o.showF) {
        var Fnow = M23.GM / (q.r * q.r);                 /* [km/s²]（単位質量あたり） */
        var FL = clamp(Fnow * (70 / (M23.GM / (M23.R * M23.R))), 9, 90);
        gravArrow(ctx, px, py, vw.X(0), vw.Y(0), FL,
          farEnough ? ('F/m = ' + fmt(Fnow * 1000, 2) + ' m/s²') : '', 1);
      }
      if (s.o.showV) {
        var vsc = 46 / Math.max(1e-9, o.v0);
        /* 速さの文字は矢印の先の「下」に出す。上に出すと「人工衛星」の名前と重なる */
        velArrow(ctx, px, py, q.vx, q.vy, vsc, 'v = ' + fmt(q.v, 2) + ' km/s', 10, 16);
      }
    }
    /* 打ち出す場所 */
    var s0 = o.at(0);
    ctx.save();
    ctx.strokeStyle = COL.sub; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(vw.X(s0.x), vw.Y(s0.y), 8, 0, TAU); ctx.stroke();
    ctx.restore();
    if (farEnough) label(ctx, '打ち出す場所', vw.X(s0.x), vw.Y(s0.y) + 19,
      { size: 10.5, color: COL.sub });

    /* ★画面の外へ出ていくとき（第二宇宙速度以上）は、吹き出しでお別れを言う★
       だまって消えると「こわれて消えた」と見えてしまうため。 */
    if (!o.bound && !inFrame) {
      /* ★しっぽの先は「人工衛星が出ていった方向」に置く★
         画面のふちのうち、人工衛星にいちばん近い点をしっぽの先にする。
         上のふちから出たときは箱が下に来るように up: true にしないと、
         吹き出しが画面の外に出てしまう。 */
      var tipX = clamp(px, 84, W - 84), tipY = clamp(py, 14, H - 14);
      var up = (py < H / 2);
      /* 左上には「軌道の見分け方」の表があるので、そこだけは避ける */
      if (up) tipY = Math.max(tipY, (tipX < 300) ? 104 : 50);
      bubble(ctx, 'さらば地球！', tipX, tipY,
        { size: 13, up: up, bg: '#ffffff', border: orbColor(o.kind), color: orbColor(o.kind) });
    }

    m23Legend(ctx, s, v.k3);
    drawClock(ctx, W, 't = ' + fmt(t / 60, 1) + ' 分');
    if (hintOn(s, t)) {
      label(ctx, 'いまの軌道：' + K.kindName(o.kind) + '（E/m = ' + fmt(o.Em, 2) + ' MJ/kg）',
        W - 10, 36, { align: 'right', size: 11.5, color: orbColor(o.kind), bold: true });
      if (!o.bound) label(ctx, 'E ≥ 0 なので、もう戻ってこない', 10, H - 12,
        { align: 'left', size: 11.5, color: orbColor(o.kind), bold: true });
    }
  },
  result: function (v, s, t) {
    var o = m23Orb(v);
    var items = [
      resItem('軌道の種類', K.kindName(o.kind)),
      resItem('打ち出す速さ $v_0$', fmt(o.v0, 3) + ' km/s'),
      resItem('$\\sqrt{gR}$（第一宇宙速度）', fmt(o.vc, 3) + ' km/s'),
      resItem('脱出速度 $\\sqrt{2}v_c$', fmt(o.vc * Math.SQRT2, 3) + ' km/s'),
      resItem('力学的エネルギー $E/m$', fmt(o.Em, 3) + ' MJ/kg')
    ];
    if (o.bound) {
      items = items.concat([
        resItem('半長軸 $a$', fmt(o.a, 0) + ' km'),
        resItem('周期 $T$', fmt(o.T / 60, 2) + ' 分'),
        resItem('$K = T^2/a^3$', fmtE(o.T * o.T / (o.a * o.a * o.a), 4) + ' s²/km³', true),
        resItem('離心率 $\\varepsilon$', fmt(o.e, 3))
      ]);
    } else {
      items = items.concat([
        resItem('離心率 $\\varepsilon$', fmt(o.e, 3)),
        resItem('周期 $T$', 'なし（戻ってこない）'),
        resItem('$K = T^2/a^3$', '—（閉じた軌道だけ）', true)
      ]);
    }
    return {
      items: items,
      note: o.bound
        ? '$E<0$ なので<b>閉じた軌道</b>。行ける一番遠いところは $r_{\\text{遠}} = ' + fmt(o.ra, 0) + '$ km で、そこで $K=0$ になります。'
        : '$E \\geq 0$ なので<b>とじない軌道</b>。無限に遠くへ行っても運動エネルギーが残る（$K \\to ' + fmt(Math.max(0, o.Em), 2) + '$ MJ/kg）ので、二度と戻ってきません。'
    };
  },
  info: function (s, t) {
    var v = V(s), o = m23Orb(v), q = o.at(t);
    return [
      ['距離 $r$', fmt(q.r, 0) + ' km'],
      ['高度（地表から）', fmt(q.r - M23.R, 0) + ' km'],
      ['速さ $v$', fmt(q.v, 3) + ' km/s'],
      ['運動エネルギー $K/m$', fmt(q.v * q.v / 2, 3) + ' MJ/kg'],
      ['位置エネルギー $U/m$', fmt(-M23.GM / q.r, 3) + ' MJ/kg'],
      ['力学的エネルギー $E/m$', fmt(o.Em, 3) + ' MJ/kg'],
      ['軌道の種類', K.kindName(o.kind)],
      ['時刻 $t$', fmt(t / 60, 1) + ' 分']
    ];
  },
  eq: function () {
    return 'E = \\dfrac{1}{2}mv^2 - G\\dfrac{mM}{r}\\quad\\Rightarrow\\quad ' +
      'v_1 = \\sqrt{\\dfrac{GM}{R}} = 7.9\\;\\mathrm{km/s},\\quad ' +
      'v_2 = \\sqrt{\\dfrac{2GM}{R}} = 11.2\\;\\mathrm{km/s}';
  }
};

/* ============================================================
   2-4　人工衛星の周期・静止衛星
   ============================================================ */
/* 高度と速さは1対1に対応する（v = √(GM/r)）ので、スライドバーを2本並べて連動させる。
   どちらを動かしても、もう一方が自動で追いかける。 */
/* 高度のきざみ。★「高度を上げる →」を 12 回押すと、ちょうど静止軌道になる★ように決めてある。
   （2950 = (35800 − 400) / 12。1 回ずつ押していってぴったり止まらないと、
     「静止軌道にする」ボタンを押すしかなくなって、手で合わせる楽しさがなくなる。） */
var M24_HMIN = 400;                                          /* ISS の高度 */
var M24_HGEO = Math.round((P.m24.rGeo() - P.m24.R) / 50) * 50;  /* 静止軌道の高度（35800 km） */
var M24_STEP = (M24_HGEO - M24_HMIN) / 12;                   /* 2950 km */
function m24Sync(s, from) {
  var R = P.m24.R, GM = P.m24.GM;
  if (from === 'v4') {
    var r = GM / (s.v.v4 * s.v.v4);
    s.v.h4 = clamp(Math.round((r - R) / 50) * 50, M24_HMIN, 50000);
  }
  s.v.v4 = +(Math.round(P.m24.v(R + s.v.h4) / 0.01) * 0.01).toFixed(2);
}

/* 「見るポイント」の上に出す見取り図：地球・ISS・GPS 衛星の軌道・静止軌道の大きさ比べ。
   いまのシミュレーションの高度も、青い円で重ねて出す。
   ISS（高度 400 km）は地球の半径の 1.06 倍しかなく、この縮尺では地球の輪郭とほぼ重なる。
   それ自体が「ISS は地表すれすれを回っている」という大事な事実なので、
   右下に「拡大」の小窓をつけて、両矢印で 400 km を見せる。 */
var M24_GPS = 26560, M24_ISS = 6771;
function m24Chart(ctx, s, t, W, H) {
  var v = V(s), R = P.m24.R, rgeo = P.m24.rGeo(), r = R + v.h4;
  var cx = 150, cy = H / 2 + 10;
  var Rmax = Math.min(cx, H / 2) - 24;
  function px(x) { return x / (rgeo * 1.06) * Rmax; }
  ctx.save(); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H); ctx.restore();

  /* 静止軌道（オレンジの破線） */
  ctx.save();
  ctx.strokeStyle = COL.acc; ctx.lineWidth = 1.4; ctx.setLineDash([6, 4]);
  ctx.beginPath(); ctx.arc(cx, cy, px(rgeo), 0, TAU); ctx.stroke();
  ctx.restore();
  /* GPS 衛星の軌道（左の図の「衛星の軌道」＝緑とぶつからない色にする） */
  ctx.save();
  ctx.strokeStyle = COL.hyper; ctx.lineWidth = 1.4; ctx.setLineDash([3, 3]);
  ctx.beginPath(); ctx.arc(cx, cy, px(M24_GPS), 0, TAU); ctx.stroke();
  ctx.restore();
  /* ISS の軌道（地球のすぐ外。ほとんど輪郭と重なる） */
  ctx.save();
  ctx.strokeStyle = COL.sect3; ctx.lineWidth = 1.4;
  ctx.beginPath(); ctx.arc(cx, cy, px(M24_ISS), 0, TAU); ctx.stroke();
  ctx.restore();
  /* ★いまの高度★は、左の図の衛星の軌道と同じ緑にそろえる */
  ctx.save();
  ctx.strokeStyle = COL.bound; ctx.lineWidth = 2.2;
  ctx.beginPath(); ctx.arc(cx, cy, px(r), 0, TAU); ctx.stroke();
  ctx.restore();

  /* 中心から静止軌道までの寸法（右上へ） */
  var uax = Math.cos(-Math.PI / 2.7), uay = Math.sin(-Math.PI / 2.7);
  dashLine(ctx, cx, cy, cx + uax * px(rgeo), cy + uay * px(rgeo), COL.dim, [4, 4], 1);
  label(ctx, '42164 km', cx + uax * px(rgeo) * 0.62 + 26, cy + uay * px(rgeo) * 0.62,
    { size: 10, color: COL.dim, align: 'left' });

  /* 地球は「白抜き」にする。中を塗ると、すぐ外を回る ISS の線が見えなくなるため。 */
  ctx.save();
  ctx.fillStyle = '#fff'; ctx.strokeStyle = '#2a5f96'; ctx.lineWidth = 1.6;
  ctx.beginPath(); ctx.arc(cx, cy, Math.max(6, px(R)), 0, TAU); ctx.fill(); ctx.stroke();
  ctx.restore();
  label(ctx, '地球', cx, cy, { size: 10, color: '#2a5f96', bold: true });
  label(ctx, 'R = 6371 km', cx, cy + Math.max(6, px(R)) + 11, { size: 9.5, color: '#2a5f96' });

  /* 中心から「いまの高度」までを両矢印で示す（左下へ）。
     地球のあとに描くのは、中心がわの矢じりが地球にかくれないようにするため。 */
  (function () {
    var ux = Math.cos(Math.PI * 0.72), uy = Math.sin(Math.PI * 0.72);
    var ex = cx + ux * px(r), ey = cy + uy * px(r);
    var mx = cx + ux * px(r) / 2, my = cy + uy * px(r) / 2;
    arrow(ctx, mx, my, ex, ey, 'dim');
    arrow(ctx, mx, my, cx, cy, 'dim');
    label(ctx, fmt(r, 0) + ' km', mx - 7, my + 11,
      { size: 10, bold: true, color: COL.bound, align: 'right' });
  })();

  /* それぞれの名前（右上にそろえて書く） */
  var lx = W - 8, ly0 = 15;
  [['静止軌道（42164 km）', COL.acc],
   ['GPS 衛星の軌道（26560 km）', COL.hyper],
   ['ISS の軌道（6771 km）', COL.sect3],
   ['現在の高度（' + fmt(r, 0) + ' km）', COL.bound]
  ].forEach(function (g, i) {
    label(ctx, g[0], lx, ly0 + i * 15, { size: 10.5, align: 'right', bold: true, color: g[1] });
  });

  /* 「拡大」の小窓：地表と ISS のあいだを両矢印で見せる。
     地球のてっぺんから、さらに「地球 1.5 個分（＝直径の 1.5 倍）」上に置く。
     地球のすぐ横に置くと、いまの高度の円や両矢印とぶつかって読みにくかったため。 */
  (function () {
    var bw = 104, bh = 86;
    var bx = W - bw - 8, by = cy - px(R) - 6 - 1.5 * (2 * px(R));
    if (by < ly0 + 52) by = ly0 + 52;
    ctx.save();
    ctx.fillStyle = '#f7f9fb'; ctx.strokeStyle = COL.grid; ctx.lineWidth = 1;
    if (ctx.roundRect) { ctx.beginPath(); ctx.roundRect(bx, by, bw, bh, 6); ctx.fill(); ctx.stroke(); }
    else { ctx.fillRect(bx, by, bw, bh); ctx.strokeRect(bx, by, bw, bh); }
    ctx.restore();
    label(ctx, '（拡大）ISS の高さ', bx + bw / 2, by + 11, { size: 9, bold: true, color: COL.sub });
    var gy = by + bh - 18;                       /* 地表 */
    var sy2 = gy - 34;                           /* ISS */
    hatchLine(ctx, bx + 10, gy, bx + bw - 10, gy, 1);
    label(ctx, '地球の表面', bx + 10, gy + 10, { size: 8.5, color: COL.sub, align: 'left' });
    planetShape(ctx, bx + 26, sy2, 3.6, '#c7ced6');
    label(ctx, 'ISS', bx + 26, sy2 - 10, { size: 9, bold: true, color: COL.ink });
    var ax2 = bx + 58, mid = (gy + sy2) / 2;
    dashLine(ctx, bx + 31, sy2, ax2, sy2, COL.dim, [3, 3], 1);
    arrow(ctx, ax2, mid, ax2, sy2, 'dim');
    arrow(ctx, ax2, mid, ax2, gy, 'dim');
    label(ctx, '400 km', ax2 + 6, mid, { size: 9.5, bold: true, color: COL.dim, align: 'left' });
  })();
}

DEFS['m2-4'] = {
  id: 'm2-4', mode: 2, tab: '2-3 人工衛星の周期・静止衛星',
  legendKeys: ['force', 'sun', 'vel', 'dim', 'bound'],
  title: '2-3　人工衛星の周期と、静止衛星',
  sub: '高度を上げると周期が長くなります（$T^2 \\propto r^3$）。<br>' +
    '<b>地球の自転（1日）と衛星の周期がぴったり同じ</b>になったとき、衛星は地上から見て' +
    '<b>空の同じところに止まって見えます</b>。これが<b>静止衛星</b>です。' +
    '図の中の細い線が「地上のある地点」を指しています。衛星がその線の上に居つづけるか、見てみよう。',
  note: '<b>地上からの高度を $h$</b> とすると、地球の中心からの距離は $r = R + h$（$R$ は地球の半径 6371 km）。<br>' +
    '運動方程式 $m\\dfrac{v^2}{r} = G\\dfrac{mM}{r^2}$ から <b>$v = \\sqrt{\\dfrac{GM}{r}} = \\sqrt{\\dfrac{GM}{R+h}}$</b>。' +
    'つまり<b>高いところほど、ゆっくり回る</b>（$h$ が大きいほど $v$ は小さい）。<br>' +
    '周期は $T = \\dfrac{2\\pi r}{v} = 2\\pi\\sqrt{\\dfrac{(R+h)^3}{GM}}$。' +
    'これを $T = 1$ 日（正しくは 23 時間 56 分＝恒星日）遠いて解くと ' +
    '<b>r = 42164 km（地表からの高度 h = 35793 km）</b>。日本の「ひまわり」もこの高さにいます。',
  cw: 560, ch: 420,
  loop: true,
  /* 万有引力は「人工衛星が受けるぶんだけ」を出す（地球が受ける反作用は描かない）。
     運動方程式 mv²/r = GmM/r² の左辺（円運動）と右辺（万有引力）を結びつけるため。 */
  vis: ['F', 'V', 'R'],
  visLabel: { F: '万有引力を表示', V: '速度を表示', R: '距離 $r$ を表示' },
  visDef: { F: false },
  vars: [
    /* ★「高度を上げる →」を 12 回押すと、ちょうど静止軌道になるようにしてある★
       min（ISS の 400 km）から M24_HGEO まで 12 等分したのが M24_STEP。
       きざみを変えるときは、この 3 つの数の関係をこわさないこと。 */
    { k: 'h4', label: '地上からの高度', unit: ' km', min: M24_HMIN, max: 50000, step: 50, dec: 0, def: M24_HMIN },
    /* 速さのスライドバー。高度と連動する（どちらを動かしても、もう一方が追いかける） */
    { k: 'v4', label: '速さ $v$（円軌道）', unit: ' km/s', min: 2.60, max: 7.80, step: 0.01, dec: 2, def: 7.67 }
  ],
  mainVars: ['h4', 'v4'],
  init: function (s) { m24Sync(s, 'h4'); },
  onVar: function (s, k) { m24Sync(s, k); },
  sideTop: {
    w: 420, h: 308,
    title: '大きさ比べ：地球・ISS・GPS 衛星の軌道・静止軌道',
    note: '静止軌道は<b>地球の半径の約 6.6 倍</b>のところ。GPS 衛星はその内側（周期 約12時間）を回っています。' +
      '<b>ISS は地球のすぐ上（半径の 1.06 倍）</b>で、この図では地球の輪郭とほとんど重なります。',
    draw: function (ctx, s, t, W, H) { m24Chart(ctx, s, t, W, H); }
  },
  topActions: [
    {
      label: '高度を上げる →', prim: true, play: true,
      fn: function (s) { stepUp(DEFS['m2-4'], s, 'h4', M24_STEP); m24Sync(s, 'h4'); }
    },
    {
      label: 'ISS の高さ（400 km）',
      fn: function (s) { s.v.h4 = M24_HMIN; m24Sync(s, 'h4'); },
      is: function (v) { return v.h4 === M24_HMIN; }
    },
    {
      label: '静止軌道にする',
      fn: function (s) { s.v.h4 = M24_HGEO; m24Sync(s, 'h4'); },
      is: function (v) { return Math.abs(v.h4 - M24_HGEO) < 1; }
    }
  ],
  tEnd: function () { return P.m24.TDAY * 2; },
  /* スタートしたときの速さ＝これまでの「スロー再生」のさらに 0.75 倍
     （TDAY/6 × 0.25 × 0.75 = TDAY/32） */
  rate: function () { return P.m24.TDAY / 32; },
  tFmt: function (t) { return fmt(t / 3600, 2) + ' 時間'; },
  xlabel: 'r [km]',
  sample: function (v, t) {
    var r = P.m24.R + v.h4;
    return { r: r, T: P.m24.T(r), v: P.m24.v(r) };
  },
  graphs: [
    {
      key: 'Tr', short: '$T$–$r$ 図', title: '$T$–$r$ 図（周期と半径）　※横線が地球の自転周期', open: false,
      custom: function (v) {
        var pts = [], i, rmax = 60000;
        for (i = 0; i <= 200; i++) {
          var rr = P.m24.R + (rmax - P.m24.R) * i / 200;
          pts.push([rr, P.m24.T(rr) / 3600]);
        }
        var r = P.m24.R + v.h4;
        return {
          xmin: 0, xmax: rmax, ymin: 0, ymax: 42,
          xlabel: 'r [km]', ylabel: 'T [時間]',
          series: [
            { color: COL.bound, width: 2.4, pts: pts },
            { color: COL.acc, width: 2.0, dash: [7, 4], pts: [[0, P.m24.TDAY / 3600], [rmax, P.m24.TDAY / 3600]] }
          ],
          cursors: [{ color: COL.bound, x: r, y: P.m24.T(r) / 3600 }],
          marks: [{ x: P.m24.rGeo(), y: P.m24.TDAY / 3600, color: COL.acc, r: 5, name: '静止軌道', lx: -10, align: 'right', ly: -12 }]
        };
      },
      fml: function (v) {
        var r = P.m24.R + v.h4;
        return [
          'T = 2\\pi\\sqrt{\\dfrac{r^3}{GM}}',
          'T = 2\\pi\\sqrt{\\dfrac{(' + fmt(r, 0) + ')^3}{3.986\\times10^{5}}}\\;\\mathrm{s}',
          'T = ' + fmt(P.m24.T(r) / 3600, 3) + '\\;\\text{時間}\\;\\;(\\text{自転は } 23.934\\;\\text{時間})'
        ];
      }
    },
    {
      key: 'vr', short: '$v$–$r$ 図', title: '$v$–$r$ 図（速さと半径）', open: false,
      custom: function (v) {
        var pts = [], i, rmax = 60000;
        for (i = 0; i <= 200; i++) {
          var rr = P.m24.R + (rmax - P.m24.R) * i / 200;
          pts.push([rr, P.m24.v(rr)]);
        }
        var r = P.m24.R + v.h4;
        return {
          xmin: 0, xmax: rmax, ymin: 0, ymax: 9,
          xlabel: 'r [km]', ylabel: 'v [km/s]',
          series: [{ color: COL.vel, width: 2.4, pts: pts }],
          cursors: [{ color: COL.vel, x: r, y: P.m24.v(r) }]
        };
      },
      fml: function (v) {
        var r = P.m24.R + v.h4;
        return [
          'm\\dfrac{v^2}{r} = G\\dfrac{mM}{r^2} \\;\\Rightarrow\\; v = \\sqrt{\\dfrac{GM}{r}}',
          '\\text{遠いほど遅い}',
          'v = ' + fmt(P.m24.v(r), 3) + '\\;\\mathrm{km/s}'
        ];
      }
    }
  ],
  draw: function (ctx, s, t, W, H) {
    var v = V(s), i;
    var r = P.m24.R + v.h4, T = P.m24.T(r);
    var rgeo = P.m24.rGeo();
    /* 縮尺は固定（高度を上げても地球の大きさが変わらないように） */
    var box = 60000;
    var vw = mkView(W, H, { l: 34, r: 34, t: 36, b: 34 },
      { x0: -box, x1: box, y0: -box * 0.74, y1: box * 0.74 });
    s.view = vw;
    var cx = vw.X(0), cy = vw.Y(0);

    /* 静止軌道のめやす */
    ctx.save();
    ctx.strokeStyle = fade(COL.acc, 0.5); ctx.lineWidth = 1.3; ctx.setLineDash([6, 4]);
    ctx.beginPath(); ctx.arc(cx, cy, (vw.X(rgeo) - cx), 0, TAU); ctx.stroke();
    ctx.restore();
    label(ctx, '静止軌道（42164 km）', cx, cy + (vw.X(rgeo) - cx) + 12,
      { size: 10, color: COL.acc });

    /* 衛星の軌道 */
    ctx.save();
    ctx.strokeStyle = COL.bound; ctx.lineWidth = 1.8;
    ctx.beginPath(); ctx.arc(cx, cy, (vw.X(r) - cx), 0, TAU); ctx.stroke();
    ctx.restore();

    /* 地球（自転する） */
    var spin = t / P.m24.TDAY * TAU;
    var Rpx = Math.max(9, vw.X(P.m24.R) - cx);
    /* 画面では反時計まわりに回して見せる（地上の目印の動きと合わせる） */
    earthShape(ctx, cx, cy, Rpx, -spin);
    /* 地上の1点と、そこから空へのばした線 */
    var gx = cx + Math.cos(-spin) * Rpx, gy = cy + Math.sin(-spin) * Rpx;
    ctx.save();
    ctx.strokeStyle = COL.hand; ctx.lineWidth = 1.4; ctx.setLineDash([4, 4]);
    ctx.beginPath();
    /* 空へのばす線は、衛星の軌道より少しだけ外まで。高度が低いときに長すぎると、
       何を指している線なのか分からなくなるため。 */
    var sight = clamp(1.35 * r, 0.30 * box, 0.96 * box);
    ctx.moveTo(cx, cy);
    ctx.lineTo(cx + Math.cos(-spin) * (vw.X(sight) - cx), cy + Math.sin(-spin) * (vw.X(sight) - cx));
    ctx.stroke();
    ctx.restore();
    /* 地上に立っている人（棒人間）。頭の向きは、その人にとっての「上」＝地球の外向き。 */
    var ux = Math.cos(-spin), uy = Math.sin(-spin);
    stickman(ctx, gx, gy, ux, uy, 19, COL.hand, 2.2);
    label(ctx, '地上のある地点', gx + ux * 44, gy + uy * 44, { size: 10.5, color: COL.hand });

    /* 衛星 */
    var ang = t / T * TAU;
    var sx = cx + Math.cos(-ang) * (vw.X(r) - cx), sy = cy + Math.sin(-ang) * (vw.X(r) - cx);
    /* 線が短いときは、文字が地球と重なるので出さない */
    if (s.o.showR) radiusLine(ctx, cx, cy, sx, sy,
      (Math.hypot(sx - cx, sy - cy) > 54) ? ('r = ' + fmt(r, 0) + ' km') : '');
    planetShape(ctx, sx, sy, 5.4, '#c7ced6');
    label(ctx, '人工衛星', sx, sy - 13, { size: 10.5, color: COL.ink });
    /* 人工衛星が受ける万有引力（かならず地球の中心を向く＝向心力）。
       長さは力の大きさに比例させる（高度 300 km で 62px）。
       高度を上げると短くなるのに、円運動はゆっくりになるので落ちてこない。 */
    if (s.o.showF) {
      var Fm = P.m24.GM / (r * r);                     /* [km/s²]（単位質量あたり） */
      /* 長さは力の大きさに比例（高度 400 km で 46px）。ただし
         「地球の中心を通りこさない」ように、衛星から中心までの 0.92 までで止める。 */
      var Fref = P.m24.GM / Math.pow(P.m24.R + 400, 2);
      var dSat = Math.hypot(sx - cx, sy - cy);
      var FL = clamp(Fm * (46 / Fref), 8, Math.max(10, dSat * 0.92));
      gravArrow(ctx, sx, sy, cx, cy, FL, 'F/m = ' + fmt(Fm * 1000, 2) + ' m/s²', -1);
    }
    if (s.o.showV) {
      var vv = P.m24.v(r);
      var vsc = 44 / 8;
      /* 位置が (r cosθ, r sinθ) なので、速度は (−v sinθ, v cosθ) */
      /* 文字は地球の反対（外）側へ出す */
      var ovx = Math.cos(ang) * 16, ovy = -Math.sin(ang) * 16;
      velArrow(ctx, sx, sy, -Math.sin(ang) * vv, Math.cos(ang) * vv, vsc,
        'v = ' + fmt(vv, 2) + ' km/s', ovx + 8, ovy - 6);
    }

    drawClock(ctx, W, 't = ' + fmt(t / 3600, 2) + ' 時間');
    label(ctx, '周期 T = ' + fmt(T / 3600, 2) + ' 時間　／　地球の自転 = 23.93 時間',
      10, H - 12, { align: 'left', size: 11, color: COL.sub });
    if (hintOn(s, t)) {
      var diff = Math.abs(T - P.m24.TDAY) / P.m24.TDAY;
      label(ctx, diff < 0.01 ? '衛星は地上の同じ地点の真上から動かない＝静止衛星'
        : (T < P.m24.TDAY ? '衛星のほうが速い（地上から見ると西から東へ動く）'
          : '衛星のほうが遅い（地上から見ると東から西へ動く）'),
        W - 10, 36, { align: 'right', size: 11.5, color: diff < 0.01 ? COL.acc : COL.bound, bold: true });
    }
  },
  result: function (v) {
    var r = P.m24.R + v.h4, T = P.m24.T(r);
    var rgeo = P.m24.rGeo();
    return {
      items: [
        resItem('地上からの高度', fmt(v.h4, 0) + ' km'),
        resItem('半長軸 $a$（＝半径 $r$）', fmt(r, 0) + ' km'),
        resItem('周期 $T$', fmt(T / 3600, 3) + ' 時間'),
        resItem('$K = T^2/a^3$', fmtE(T * T / (r * r * r), 4) + ' s²/km³', true),
        resItem('速さ $v$', fmt(P.m24.v(r), 3) + ' km/s'),
        resItem('地球の自転周期', fmt(P.m24.TDAY / 3600, 3) + ' 時間'),
        resItem('静止軌道までの差', fmt(r - rgeo, 0) + ' km')
      ],
      note: Math.abs(T - P.m24.TDAY) / P.m24.TDAY < 0.01
        ? '<b>周期と自転がそろいました＝静止衛星</b>（r = 42164 km、高度 35793 km）。地上から見ると空の一点に止まって見えます。'
        : '周期 ' + fmt(T / 3600, 2) + ' 時間 と 自転 23.93 時間 がそろうところが静止軌道です。' +
        '「静止軌道にする」ボタンで合わせてみよう。'
    };
  },
  info: function (s, t) {
    var v = V(s), r = P.m24.R + v.h4, T = P.m24.T(r);
    return [
      ['地球の中心からの距離 $r$', fmt(r, 0) + ' km'],
      ['高度', fmt(v.h4, 0) + ' km'],
      ['周期 $T$', fmt(T / 3600, 3) + ' 時間'],
      ['速さ $v$', fmt(P.m24.v(r), 3) + ' km/s'],
      ['向心加速度 $v^2/r$', fmt(P.m24.v(r) * P.m24.v(r) / r * 1000, 4) + ' m/s²'],
      ['その場所の $GM/r^2$', fmt(P.m24.GM / (r * r) * 1000, 4) + ' m/s²'],
      ['1日で回る回数', fmt(P.m24.TDAY / T, 2) + ' 周'],
      ['時刻 $t$', fmt(t / 3600, 2) + ' 時間']
    ];
  },
  eq: function () {
    return EQM + 'm\\dfrac{v^2}{r} = G\\dfrac{mM}{r^2} \\;\\Rightarrow\\; ' +
      'v = \\sqrt{\\dfrac{GM}{r}},\\quad T = 2\\pi\\sqrt{\\dfrac{r^3}{GM}}';
  }
};

/* ============================================================
   2-5　参考：スイングバイ
   ============================================================ */
var M25 = {
  GMp: 1.26687e8,      /* 木星の GM [km³/s²] */
  Rp: 71492,           /* 木星の半径 [km] */
  Vp: 13.06,           /* 木星の公転の速さ [km/s] */
  RFAR: 3.0e7          /* 「じゅうぶん遠く」とみなす距離 [km] */
};
var _m25 = {};
/* 惑星から見た双曲線軌道を、入ってくる向きが thIn になるように回して使う */
function m25Build(v) {
  var key = [v.b5, v.vinf, v.ang].join('/');
  if (_m25.key === key) return _m25.val;
  var h = P.m25.make(M25.GMp, v.vinf, v.b5 === 0 ? 1 : v.b5);
  var o = P.m25.orb(h);
  var Hf = Math.acosh(Math.max(1, (M25.RFAR / o.a + 1) / o.e));
  var T0 = (o.e * Math.sinh(Hf) - Hf) / o.n;      /* 近点までの時間 */
  var q0 = o.at(-T0);
  var rot = v.ang * DEG - Math.atan2(q0.vy, q0.vx);
  var cr = Math.cos(rot), sr = Math.sin(rot);
  var out = {
    h: h, o: o, T0: T0, rot: rot,
    at: function (t) {
      var q = o.at(t - T0);
      var x = q.x * cr - q.y * sr, y = q.x * sr + q.y * cr;
      var vx = q.vx * cr - q.vy * sr, vy = q.vx * sr + q.vy * cr;
      var pxp = M25.Vp * (t - T0);                 /* 惑星の位置（太陽から見て） */
      return {
        r: q.r,
        rel: { x: x, y: y, vx: vx, vy: vy, v: Math.hypot(vx, vy) },
        planet: { x: pxp, y: 0 },
        sun: { x: pxp + x, y: y, vx: vx + M25.Vp, vy: vy, v: Math.hypot(vx + M25.Vp, vy) }
      };
    }
  };
  _m25.key = key; _m25.val = out;
  return out;
}
DEFS['m2-5'] = {
  /* ★このシムはモード4（もっと深く知りたい人へ）に置いてある★（先生の指示）
     並びを決めるのは MODES[3].ids。ファイルの場所とモードは別もの。 */
  id: 'm2-5', mode: 4, tab: '4-2 スイングバイ', read: true,
  legendKeys: ['vel', 'dim', 'hyper'],
  title: '4-2　スイングバイ　—　惑星の重力で探査機を加速する',
  sub: '探査機が惑星のそばを通ると、<b>惑星から見た速さは行きと帰りでまったく同じ</b>（向きが変わるだけ）です。' +
    'ところが<b>太陽から見ると速さが変わります</b>。惑星の速度が足し算されるからです。<br>' +
    '<b>ここでいう「前」「後ろ」は、<u>惑星が進む向き</u>を基準にした前・後ろ</b>です' +
    '（太陽から見てどちら側か、ではありません）。図の中に「惑星が進む向き」の矢印と、' +
    '「前」「後ろ」がどちら側かを書いてあります。<br>' +
    '<b>惑星の「前」を通るか「後ろ」を通るか</b>で、曲がる向きが変わり、加速か減速かが決まります。' +
    '右上の「観測者の立場」を切りかえて、同じ運動が2通りに見えることを確かめよう。',
  note: '惑星から見れば<b>双曲線軌道</b>で、入ってくる速さと出ていく速さは同じ（力学的エネルギーが保存）。' +
    '向きだけが <b>δ = 2 arcsin(1/ε)</b> だけ曲がります。' +
    '太陽から見た速度は「惑星の速度＋惑星から見た速度」なので、' +
    '<b>曲がったぶんだけ、足し算の結果が変わる</b>——これがスイングバイです。' +
    '惑星は探査機に運動エネルギーを分け与え、そのぶんだけほんのわずか公転が遅くなります。',
  sideText:
    '<span class="q">【物理ミニコラム】スイングバイは「ただ取り」ではない</span>' +
    'スイングバイで探査機が速くなるぶんのエネルギーは、どこから来たのでしょうか。' +
    '<div class="colh">1. 惑星から見れば、速さは変わっていない</div>' +
    '惑星から見ると、探査機は<b>双曲線</b>を描いて通りすぎるだけです。' +
    '力学的エネルギー $\\frac{1}{2}mv^2-G\\frac{Mm}{r}$ が保存するので、' +
    '遠くでの速さは<b>行きも帰りもぴったり同じ</b>。変わるのは<b>向きだけ</b>で、' +
    '$\\delta = 2\\arcsin(1/\\varepsilon)$ だけ曲がります。' +
    '<div class="colh">2. 太陽から見ると速さが変わる</div>' +
    '太陽から見た速度は<b>「惑星の速度」＋「惑星から見た速度」</b>のベクトルの足し算です。' +
    '後ろの足す向きが変わるので、<b>合計の大きさが変わります</b>。' +
    'つまり<b>「どこから見るか」を変えただけ</b>で、速さの見え方が変わるのです。' +
    '<div class="colh">3. では、エネルギーはどこから？</div>' +
    '<b>惑星の公転の運動エネルギーです。</b>探査機が引っぱられるとき、' +
    '作用・反作用で惑星も探査機に引っぱられます。' +
    '探査機が得たぶんだけ、惑星の公転は遅くなります。<br>' +
    'ただし惑星の質量は探査機の $10^{20}$ 倍ほどもあるので、' +
    '惑星の速さの変化は<b>まったく測れないほど小さい</b>——だから「ただ取り」に見えるのです。' +
    '<div class="colh">4. 実際に使われている技術です</div>' +
    'ボイジャー1号・2号は、木星と土星のスイングバイをくり返して太陽系の外へ出ました。' +
    '日本の「はやぶさ2」も、2015年12月3日に<b>地球スイングバイ</b>を行い、' +
    '小惑星リュウグウへ向かう軌道に乗りました。' +
    refsHtml([
      { t: 'Basics of Spaceflight: A Gravity Assist Primer（NASA Science）',
        u: 'https://science.nasa.gov/learn/basics-of-space-flight/primer/',
        n: 'スイングバイのしくみを、たとえ話を交えて説明した NASA の入門ページ（英語）。' },
      { t: '「はやぶさ２」地球スイングバイ成功！（JAXA）',
        u: 'https://www.hayabusa2.jaxa.jp/topics/20151214_02/',
        n: '2015年12月3日の地球スイングバイの結果。ねらいとのずれは 43 cm/s だった。' },
      { t: 'JAXA はやぶさ2 プロジェクト', u: 'https://www.hayabusa2.jaxa.jp/',
        n: 'ミッション全体のまとめ（日本語）。' },
      { t: 'Voyager（NASA Science）', u: 'https://science.nasa.gov/mission/voyager/',
        n: '木星・土星のスイングバイで太陽系の外へ出た2機の探査機。' }
    ]),
  cw: 560, ch: 400,
  vis: ['V'],
  visLabel: { V: '速度を表示' },
  selects: [{
    k: 'obs', label: '観測者の立場', def: 'planet',
    options: [{ v: 'planet', label: '惑星から見る' }, { v: 'sun', label: '太陽から見る' }]
  }],
  vars: [
    {
      k: 'b5', label: 'ねらう位置 $b$（＋は惑星の前側・−は後ろ側）', unit: ' 万km',
      min: -1500, max: 1500, step: 100, dec: 0, def: -500
    },
    { k: 'vinf', label: '近づく速さ $v_\\infty$（惑星から見て）', unit: ' km/s', min: 3, max: 12, step: 0.5, dec: 1, def: 8.0 },
    { k: 'ang', label: '近づいてくる向き', unit: '°', min: 100, max: 170, step: 10, dec: 0, def: 140 }
  ],
  mainVars: ['b5', 'vinf'],
  actions: [
    {
      /* 最接近の点が惑星の「後ろ（進行方向の逆側）」に来る＝加速する通り方 */
      label: '後ろ側を通る（加速）', fn: function (s) { s.v.b5 = -(Math.abs(s.v.b5) || 500); },
      is: function (v) { return v.b5 < 0; }
    },
    {
      label: '前側を通る（減速）', fn: function (s) { s.v.b5 = Math.abs(s.v.b5) || 500; },
      is: function (v) { return v.b5 > 0; }
    },
    {
      label: 'もっと近くを通る', fn: function (s) { s.v.b5 = (s.v.b5 >= 0 ? 1 : -1) * Math.max(100, Math.abs(s.v.b5) - 200); }
    }
  ],
  tEnd: function (v) { return m25Build(m25V(v)).T0 * 2; },
  rate: function (v) { return m25Build(m25V(v)).T0 * 2 / 12; },
  tFmt: function (t) { return fmt(t / 86400, 1) + ' 日'; },
  xlabel: 't [日]',
  sample: function (v, t) {
    var B = m25Build(m25V(v));
    var q = B.at(t);
    return { r: q.r, v: q.sun.v, vrel: q.rel.v, vsun: q.sun.v };
  },
  graphs: [
    {
      key: 'vs', short: '太陽から見た速さ', title: '太陽から見た速さ $v$–$t$ 図　※前後で変わる', open: true,
      ylabel: 'v [km/s]', xf: function (m, v, t) { return t / 86400; },
      series: [{ color: COL.vel, f: function (m) { return m.vsun; } }],
      fml: function (v) {
        var B = m25Build(m25V(v));
        var sp = P.m25.sunSpeeds(B.h, M25.Vp, v.ang * DEG);
        return [
          '\\vec{v}_{\\text{太陽}} = \\vec{v}_{\\text{惑星}} + \\vec{v}_{\\text{相対}}',
          '\\text{相対速度は大きさが変わらず、向きだけ } \\delta \\text{ 回る}',
          'v_{\\text{前}} = ' + fmt(sp.vin, 3) + ' \\to v_{\\text{後}} = ' + fmt(sp.vout, 3) +
          '\\;\\mathrm{km/s}\\;(' + (sp.gain >= 0 ? '+' : '') + fmt(sp.gain, 3) + ')'
        ];
      }
    },
    {
      key: 'vr5', short: '惑星から見た速さ', title: '惑星から見た速さ $v$–$t$ 図　※前後で同じ', open: true,
      ylabel: 'v [km/s]', xf: function (m, v, t) { return t / 86400; },
      series: [{ color: COL.sect3, f: function (m) { return m.vrel; } }],
      fml: function (v) {
        var B = m25Build(m25V(v));
        return [
          '\\dfrac{1}{2}v^2 - \\dfrac{GM_{\\text{惑星}}}{r} = \\text{一定}',
          '\\text{遠方では } v \\to v_{\\infty}\\;(\\text{行きも帰りも同じ})',
          'v_{\\infty} = ' + fmt(v.vinf, 1) + '\\;\\mathrm{km/s},\\;\\; \\delta = ' + fmt(B.h.delta / DEG, 1) + '^\\circ'
        ];
      }
    },
    {
      key: 'r5', short: '$r$–$t$ 図', title: '$r$–$t$ 図（惑星からの距離）', open: false,
      ylabel: 'r [万km]', xf: function (m, v, t) { return t / 86400; },
      series: [{ color: COL.bound, f: function (m) { return m.r / 1e4; } }]
    }
  ],
  draw: function (ctx, s, t, W, H) {
    var v = V(s), B = m25Build(m25V(v)), i;
    var sun = (v.obs === 'sun');
    var q = B.at(t);
    /* 軌道の点列（観測者の立場で座標が変わる） */
    var pts = [], N = 200;
    for (i = 0; i <= N; i++) {
      var tt = B.T0 * 2 * i / N, qq = B.at(tt);
      pts.push(sun ? [qq.sun.x, qq.sun.y] : [qq.rel.x, qq.rel.y]);
    }
    var x0 = Infinity, x1 = -Infinity, y0 = Infinity, y1 = -Infinity;
    pts.forEach(function (p) {
      x0 = Math.min(x0, p[0]); x1 = Math.max(x1, p[0]);
      y0 = Math.min(y0, p[1]); y1 = Math.max(y1, p[1]);
    });
    if (sun) { x0 = Math.min(x0, -M25.Vp * B.T0); x1 = Math.max(x1, M25.Vp * B.T0); }
    else { x0 = Math.min(x0, -M25.RFAR * 0.2); x1 = Math.max(x1, M25.RFAR * 0.2); }
    var mx = (x1 - x0) * 0.08, my = (y1 - y0) * 0.12 + (x1 - x0) * 0.02;
    var vw = mkView(W, H, { l: 30, r: 30, t: 40, b: 34 },
      { x0: x0 - mx, x1: x1 + mx, y0: y0 - my, y1: y1 + my });
    s.view = vw;

    /* 惑星の通り道（太陽から見たとき） */
    if (sun) {
      dashLine(ctx, vw.X(-M25.Vp * B.T0), vw.Y(0), vw.X(M25.Vp * B.T0), vw.Y(0), COL.sub, [7, 5], 1.2);
      label(ctx, '惑星の通り道', vw.X(M25.Vp * B.T0), vw.Y(0) - 12,
        { size: 10.5, color: COL.sub, align: 'right' });
    }
    /* 探査機の道すじ */
    ctx.save();
    ctx.strokeStyle = COL.hyper; ctx.lineWidth = 2; ctx.setLineDash([12, 4, 3, 4]);
    ctx.beginPath();
    pts.forEach(function (p, j) {
      var pp = [vw.X(p[0]), vw.Y(p[1])];
      if (j === 0) ctx.moveTo(pp[0], pp[1]); else ctx.lineTo(pp[0], pp[1]);
    });
    ctx.stroke();
    ctx.restore();

    /* 惑星 */
    var ppos = sun ? q.planet : { x: 0, y: 0 };
    var pxp = vw.X(ppos.x), pyp = vw.Y(ppos.y);
    planetShape(ctx, pxp, pyp, 11, '#c99b6a', false);
    label(ctx, '惑星（木星）', pxp, pyp - 20, { size: 11, color: '#8a5a2b', bold: true });
    if (sun && s.o.showV) {
      velArrow(ctx, pxp, pyp, M25.Vp, 0, 46 / 20, fmt(M25.Vp, 1) + ' km/s', 6, 15);
    }

    /* 「前」「後ろ」がどちら側かを、惑星のわきにはっきり書く。
       ここでいう前・後ろは「惑星が進む向き（＋x）」を基準にしたもので、
       太陽がどちらにあるかとは関係がない。 */
    (function () {
      var ay = pyp - 40, ax0 = pxp + 14, aL = 44;
      arrow(ctx, ax0, ay, ax0 + aL, ay, 'dim');
      label(ctx, '惑星が進む向き', ax0 + aL / 2, ay - 12, { size: 10, color: COL.sub });
      label(ctx, 'こちらが「前側」', ax0 + aL + 8, ay,
        { size: 10.5, bold: true, color: COL.sub, align: 'left' });
      label(ctx, 'こちらが「後ろ側」', pxp - 16, ay, { size: 10.5, bold: true, color: COL.sub, align: 'right' });
    })();

    /* 最接近の点に印をつけて、どちら側を通ったのかを書く */
    (function () {
      var qc = B.at(B.T0);
      var mxp = vw.X(sun ? qc.sun.x : qc.rel.x), myp = vw.Y(sun ? qc.sun.y : qc.rel.y);
      ctx.save();
      ctx.strokeStyle = COL.hyper; ctx.lineWidth = 1.6;
      ctx.beginPath(); ctx.arc(mxp, myp, 9, 0, TAU); ctx.stroke();
      ctx.restore();
      label(ctx, '最接近（惑星の' + (v.b5 < 0 ? '後ろ' : '前') + '側）', mxp, myp + 20,
        { size: 10.5, bold: true, color: COL.hyper });
    })();

    /* 探査機 */
    var sxp = vw.X(sun ? q.sun.x : q.rel.x), syp = vw.Y(sun ? q.sun.y : q.rel.y);
    ctx.save();
    ctx.fillStyle = '#dfe7ec'; ctx.strokeStyle = '#4a5560'; ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.arc(sxp, syp, 4.6, 0, TAU); ctx.fill(); ctx.stroke();
    ctx.restore();
    label(ctx, '探査機', sxp, syp + 15, { size: 10.5, color: COL.ink });
    if (s.o.showV) {
      var vv = sun ? q.sun : q.rel;
      velArrow(ctx, sxp, syp, vv.vx, vv.vy, 46 / 20,
        'v = ' + fmt(vv.v, 2) + ' km/s', 10, -10);
    }

    drawClock(ctx, W, 't = ' + fmt((t - B.T0) / 86400, 1) + ' 日（最接近が 0）');
    label(ctx, sun ? '太陽から見たようす（惑星も動く）' : '惑星から見たようす（惑星は止まって見える）',
      10, 20, { align: 'left', size: 11.5, bold: true, color: COL.ink });
    label(ctx, '最接近の距離 ' + fmt(B.h.q / 1e4, 0) + ' 万km（惑星の半径の ' + fmt(B.h.q / M25.Rp, 1) + ' 倍）'
      + '　／　' + (v.b5 < 0 ? '惑星が進む向きの「後ろ側」を通る＝加速' : '惑星が進む向きの「前側」を通る＝減速'),
      10, H - 12, { align: 'left', size: 10.5, color: COL.sub });
    if (hintOn(s, t)) {
      var sp = P.m25.sunSpeeds(B.h, M25.Vp, v.ang * DEG);
      label(ctx, sun
        ? (sp.gain >= 0 ? '太陽から見ると速くなっている（＋' + fmt(sp.gain, 2) + ' km/s）'
          : '太陽から見ると遅くなっている（' + fmt(sp.gain, 2) + ' km/s）')
        : '惑星から見ると、行きと帰りで速さは同じ（向きだけ ' + fmt(B.h.delta / DEG, 0) + '° 曲がる）',
        W - 10, H - 28, { align: 'right', size: 11.5, bold: true, color: sun ? COL.vel : COL.sect3 });
    }
  },
  result: function (v, s, t) {
    var B = m25Build(m25V(v));
    var sp = P.m25.sunSpeeds(B.h, M25.Vp, v.ang * DEG);
    return {
      items: [
        resItem('曲がる角 $\\delta$', fmt(B.h.delta / DEG, 2) + '°'),
        resItem('最接近の距離', fmtE(B.h.q, 3) + ' km（半径の ' + fmt(B.h.q / M25.Rp, 1) + ' 倍）'),
          resItem('太陽から見た速さ（前）', fmt(sp.vin, 3) + ' km/s'),
        resItem('太陽から見た速さ（後）', fmt(sp.vout, 3) + ' km/s'),
        resItem('速さの変化', (sp.gain >= 0 ? '+' : '') + fmt(sp.gain, 3) + ' km/s', true)
      ],
      note: '惑星から見た速さは前も後も <b>' + fmt(v.vinf, 1) + ' km/s</b> のまま（エネルギー保存）。' +
        'それでも太陽から見ると <b>' + fmt(sp.vin, 2) + ' → ' + fmt(sp.vout, 2) + ' km/s</b> に変わります。' +
        '<b>「惑星の後ろを通る／前を通る」で符号が変わる</b>のを確かめよう。'
    };
  },
  info: function (s, t) {
    var v = V(s), B = m25Build(m25V(v)), q = B.at(t);
    var sp = P.m25.sunSpeeds(B.h, M25.Vp, v.ang * DEG);
    return [
      ['惑星からの距離 $r$', fmtE(q.r, 3) + ' km'],
      ['惑星から見た速さ', fmt(q.rel.v, 3) + ' km/s'],
      ['太陽から見た速さ', fmt(q.sun.v, 3) + ' km/s'],
      ['遠方での相対速さ $v_\\infty$', fmt(v.vinf, 1) + ' km/s'],
      ['曲がる角 $\\delta$', fmt(B.h.delta / DEG, 2) + '°'],
      ['最接近の距離', fmtE(B.h.q, 3) + ' km'],
      ['太陽から見た速さの変化', (sp.gain >= 0 ? '+' : '') + fmt(sp.gain, 3) + ' km/s'],
      ['最接近からの時間', fmt((t - B.T0) / 86400, 2) + ' 日']
    ];
  },
  eq: function () {
    return '\\delta = 2\\arcsin\\dfrac{1}{\\varepsilon},\\quad \\varepsilon = \\sqrt{1 + \\dfrac{b^2 v_\\infty^4}{(GM)^2}}' +
      '\\qquad \\vec{v}_{\\text{太陽}} = \\vec{v}_{\\text{惑星}} + \\vec{v}_{\\text{相対}}';
  }
};
/* b は「万km」で持っているので km に直して渡す */
function m25V(v) {
  return { b5: v.b5 * 1e4, vinf: v.vinf, ang: v.ang, obs: v.obs };
}
