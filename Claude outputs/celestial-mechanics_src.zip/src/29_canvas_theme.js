/* =========================================================================
   図の中（canvas）の「UI の色」だけを、ページのデザイン（紙・墨）にそろえる
   -------------------------------------------------------------------------
   ★入れてよいのは UI の色だけ★（先生の確認ずみ・2026-10-03）
     このページの UI のグレーは、COL の中のつぎの4つだけ。
       COL.ink  #1b1f24  文字・寸法の破線
       COL.sub  #5b6672  補足の文字
       COL.grid #e2e6ea  グラフの格子
       COL.axis #8b949e  軸
   ★物理の色は1つも入れない★
     力 #d1352b／垂直抗力 #7b3fd4／摩擦 #0f8a8a／手 #c2367f／速度 #1663b5／
     加速度 #e07b18／太陽 #f0b429・#c07f00／★軌道 #98a2ac（灰色だが物理の色）★／
     束縛 #1c8f4a／放物線 #b58900／双曲線 #3f4a54／扇形 3色／
     星空の図の色（#0d1626・#9fb0c4・#c9d6e4・#9fd0ff・#7fe0a0・#e8eef4・#cfe0f0 …）
   canvas に色を入れる瞬間（fillStyle / strokeStyle）に置きかえるので、
   個々の作図コードは1行も書きかえない。
   ========================================================================= */
(function () {
  'use strict';
  var MAP = {
    '#1b1f24': '#14171c',   /* 墨（文字・寸法の破線） */
    '#5b6672': '#5f6670',   /* 補足の文字 */
    '#e2e6ea': '#ece7de',   /* グラフの格子（あたたかい紙色に） */
    '#8b949e': '#8d9097'    /* 軸 */
  };
  var P2D = (typeof CanvasRenderingContext2D !== 'undefined') ? CanvasRenderingContext2D.prototype : null;
  if (!P2D) return;
  ['fillStyle', 'strokeStyle'].forEach(function (prop) {
    var d = Object.getOwnPropertyDescriptor(P2D, prop);
    if (!d || !d.set) return;
    Object.defineProperty(P2D, prop, {
      configurable: true, enumerable: d.enumerable, get: d.get,
      set: function (v) {
        if (typeof v === 'string') { var k = v.toLowerCase(); if (MAP.hasOwnProperty(k)) v = MAP[k]; }
        d.set.call(this, v);
      }
    });
  });
  window.CANVAS_THEME = { MAP: MAP };
})();
