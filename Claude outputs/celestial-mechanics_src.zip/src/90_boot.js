/* 起動とテスト用フック */
'use strict';
(function () {
  /* まだ作っていないモード・シミュレーションはタブに出さない
     （モード2〜4 ができたら、DEFS に足すだけで自動的に出る） */
  MODES = MODES.filter(function (M) {
    M.ids = M.ids.filter(function (id) { return !!DEFS[id]; });
    return M.ids.length > 0;
  });

  initState();
  drawLegend();
  renderMath(document.body);

  var hp = parseHash(location.hash);
  if (!DEFS[hp.id]) hp.id = 'm1-1';
  st.cur = hp.id;
  applySysKind(st.sysKind);    /* 描画対象（太陽と惑星／地球と人工衛星）を4つのシムにそろえる */
  autoPlayOn(st.cur);          /* ★開いた瞬間に動きだすシム（autoplay: true）★ */
  initProbOverlay();           /* 入試問題の問題文（画像）の重ね窓 */
  buildTabs();
  buildPanel();
  renderActive();
  renderLegend(DEFS[st.cur]);

  window.addEventListener('hashchange', function () {
    if (st._skipHash) { st._skipHash = false; return; }
    var q = parseHash(location.hash);
    if (!DEFS[q.id]) return;
    if (q.id !== st.cur) {
      gotoSim(q.id);
      /* ページの中のリンクで飛んできたとき、図が帯の下にもぐらないようにする。
         ★描き直すと高さが変わるので、もう一度そろえ直す★ */
      scrollSimIntoView(true);
      requestAnimationFrame(function () {
        requestAnimationFrame(function () { scrollSimIntoView(true); });
      });
    }
  });


  if (document.fonts && document.fonts.ready && document.fonts.ready.then) {
    document.fonts.ready.then(function () { refitFormulas(); placeModeTip(); });
  }
  window.addEventListener('resize', function () {
    /* ★画面のはばを覚え直してから描き直す★
       4-5 は、このはばで「3つの図を よこ一列 か たて一列 か」を決めている。 */
    noteWinW();
    refitFormulas(); placeModeTip(); centerTabs(); renderActive();
  });
  requestAnimationFrame(tick);

  /* ===== 自動テスト用のフック ===== */
  window.TEST = {
    sims: function () { return Object.keys(DEFS); },
    state: function () {
      var s = st.sims[st.cur];
      return { sim: st.cur, v: JSON.parse(JSON.stringify(s.v)), o: JSON.parse(JSON.stringify(s.o)), t: +s.t.toFixed(4) };
    },
    /* ★テストは必ず「止まった状態」から始める★
       autoplay のシムをそのままにすると、時刻が進んで結果が毎回変わってしまう。
       ページを開きなおしたとき（location.hash で移動したとき）は
       TEST.pause() を呼ぶこと。 */
    pause: function () {
      var s = st.sims[st.cur];
      s.playing = false; s.t = 0;
      setPlayLabel(); renderActive();
      return st.cur;
    },
    goto: function (id) {
      gotoSim(id);
      return window.TEST.pause();
    },
    gview: function (key, view) {
      var s = st.sims[st.cur];
      if (view === undefined) return s.gview[key] || null;
      if (view === null) delete s.gview[key]; else s.gview[key] = view;
      renderActive();
      return s.gview[key] || null;
    },
    graphMap: function (key) {
      var cv = document.getElementById('gc_' + key);
      if (!cv || !cv._map) return null;
      var m = cv._map;
      return { xmin: +m.xmin.toFixed(4), xmax: +m.xmax.toFixed(4), ymin: +m.ymin.toFixed(4), ymax: +m.ymax.toFixed(4) };
    },
    openAll: function () { toggleAllGraphs(); return window.TEST.graphsOpen(); },
    graphsOpen: function () { return JSON.parse(JSON.stringify(st.sims[st.cur].open)); },
    formulas: function () {
      var d = DEFS[st.cur], s = st.sims[st.cur], out = {};
      graphsOf(d, s).forEach(function (g) { if (g.fml) out[g.key] = g.fml(V(s), s); });
      return out;
    },
    /* 計算結果の帯（DOM の文言） */
    result: function () {
      var el = document.getElementById('resbar');
      if (!el) return null;
      var items = Array.prototype.map.call(el.querySelectorAll('.ritem'), function (x) {
        return x.querySelector('.rk').textContent + '=' + x.querySelector('.rv').textContent;
      });
      var rows = Array.prototype.map.call(el.querySelectorAll('table.ktab tr'), function (tr) {
        return Array.prototype.map.call(tr.children, function (td) { return td.textContent; }).join('|');
      });
      return { items: items, table: rows };
    },
    readout: function () {
      return Array.prototype.map.call(document.querySelectorAll('#readout tr'), function (tr) {
        return tr.children[0].textContent + '=' + tr.children[1].textContent;
      });
    },
    acts: function () {
      return Array.prototype.map.call(document.querySelectorAll('[data-act],[data-tact]'), function (b) {
        return b.textContent + ':' + (b.className.indexOf('on') >= 0 ? 'on' : 'off');
      });
    },
    act: function (i) {
      var b = document.getElementById('act_' + i);
      if (b) b.click();
      return window.TEST.state();
    },
    tact: function (i) {
      var b = document.getElementById('tact_' + i);
      if (b) b.click();
      return window.TEST.state();
    },
    /* 再生を止めて時刻をそろえる。
       play: true のボタン（押すと再生も始まるボタン）を押したあとの状態を
       テストで読むときに使う。止めないと、読む時刻がそのつどずれてしまう。 */
    pause: function (t) {
      var s = st.sims[st.cur];
      s.playing = false;
      s.t = (t === undefined) ? 0 : t;
      setPlayLabel();
      renderActive();
      return window.TEST.state();
    },
    set: function (o) {
      var s = st.sims[st.cur];
      if (o.vars) Object.keys(o.vars).forEach(function (k) { if (k in s.v) s.v[k] = o.vars[k]; });
      if (o.opts) Object.keys(o.opts).forEach(function (k) { s.o[k] = o.opts[k]; });
      if (o.t !== undefined) s.t = o.t; else s.t = 0;
      s.playing = false;
      buildPanel();
      renderActive();
      return window.TEST.state();
    },

    /* ===== 物理の検算（UI の状態によらない固定の計算） ===== */
    check: function () {
      var r = {}, i;

      /* --- ケプラー第3法則：太陽系の全天体で T²/a³ が同じ値 --- */
      var ks = PLANETS.map(function (p) { return p.T * p.T / (p.a * p.a * p.a); });
      r.kepler3_min = +Math.min.apply(null, ks).toFixed(5);
      r.kepler3_max = +Math.max.apply(null, ks).toFixed(5);
      r.kepler3_spread = +(Math.max.apply(null, ks) - Math.min.apply(null, ks)).toFixed(5);
      r.kepler3_each = PLANETS.map(function (p, j) { return p.name + ':' + ks[j].toFixed(4); }).join(' ');
      /* GM☉ = 4π² [AU³/年²] を使うと、計算した周期も観測値と合う */
      r.kepler3_T_calc = PLANETS.map(function (p) {
        return +(TAU * Math.sqrt(p.a * p.a * p.a / SYS.sun.GM) / p.T).toFixed(4);
      }).join(',');

      /* --- ケプラー第2法則：近日点と遠日点で r·v が一致（面積速度一定） --- */
      var o = K.elems(1.5, 0.4, SYS.sun.GM);
      r.k2_rp_vp = +(o.rp * o.vp).toFixed(9);
      r.k2_ra_va = +(o.ra * o.va).toFixed(9);
      r.k2_L = +o.L.toFixed(9);
      /* 軌道上のどこでも r×v（＝角運動量／質量）は一定 */
      var Lmax = 0, Lmin = 1e9;
      for (i = 0; i <= 60; i++) {
        var q = K.state(o, o.T * i / 60, 0, false);
        var L = q.x * q.vy - q.y * q.vx;
        Lmax = Math.max(Lmax, L); Lmin = Math.min(Lmin, L);
      }
      r.k2_L_spread = +(Lmax - Lmin).toFixed(9);
      /* 面積速度 dS/dt = L/2。同じ時間なら掃く面積は同じ（近日点でも遠日点でも） */
      var dt = o.T / 12;
      var s1 = P.m13.sector(o, 0, K.ecc(TAU * dt / o.T, o.e));
      var Ea = K.ecc(Math.PI, o.e), Eb = K.ecc(Math.PI + TAU * dt / o.T, o.e);
      var s2 = P.m13.sector(o, Ea, Eb);
      r.k2_area_peri = +s1.toFixed(9);
      r.k2_area_aph = +s2.toFixed(9);
      r.k2_area_formula = +(o.dS * dt).toFixed(9);

      /* --- 近日点の速さの式 v_p = √(GM(1+e)/(a(1−e))) が数値解と一致 --- */
      var st0 = K.state(o, 0, 0, false);
      r.vperi_state = +st0.v.toFixed(9);
      r.vperi_formula = +Math.sqrt(SYS.sun.GM * (1 + o.e) / (o.a * (1 - o.e))).toFixed(9);
      var stA = K.state(o, o.T / 2, 0, false);
      r.vaph_state = +stA.v.toFixed(9);
      r.vaph_formula = +Math.sqrt(SYS.sun.GM * (1 - o.e) / (o.a * (1 + o.e))).toFixed(9);

      /* --- 力学的エネルギー E = −GMm/2a は軌道上のどこでも一定 --- */
      var emax = -1e9, emin = 1e9;
      for (i = 0; i <= 60; i++) {
        var q2 = K.state(o, o.T * i / 60, 0, false);
        var E = q2.v * q2.v / 2 - SYS.sun.GM / q2.r;
        emax = Math.max(emax, E); emin = Math.min(emin, E);
      }
      r.energy_spread = +(emax - emin).toFixed(9);
      r.energy_value = +emin.toFixed(6);
      r.energy_formula = +(-SYS.sun.GM / (2 * o.a)).toFixed(6);

      /* --- 第一宇宙速度・第二宇宙速度・静止軌道半径 --- */
      var E1 = SYS.earth;
      r.v1_km_s = +Math.sqrt(E1.GM / E1.R).toFixed(3);                 /* ≈7.9 km/s */
      r.v2_km_s = +Math.sqrt(2 * E1.GM / E1.R).toFixed(3);             /* ≈11.2 km/s */
      var Tday = 86164.0905;                                           /* 地球の自転周期（恒星日） */
      r.geo_radius_km = +Math.pow(E1.GM * Tday * Tday / (4 * Math.PI * Math.PI), 1 / 3).toFixed(0);
      r.geo_alt_km = +(Math.pow(E1.GM * Tday * Tday / (4 * Math.PI * Math.PI), 1 / 3) - E1.R).toFixed(0);
      r.geo_T_hours = +(TAU * Math.sqrt(Math.pow(42164, 3) / E1.GM) / 3600).toFixed(4);
      /* 万有引力定数から出した GM が、使っている値と合う */
      r.GM_earth_from_G = +(G_CONST * M_EARTH / 1e9).toFixed(0);       /* km³/s² */
      r.GM_sun_from_G = +(G_CONST * M_SUN * YEAR_S * YEAR_S / Math.pow(AU_KM * 1e3, 3)).toFixed(4);
      r.GM_sun_4pi2 = +(4 * Math.PI * Math.PI).toFixed(4);

      /* --- ケプラー方程式が正しく解けている（E − e sinE = M） --- */
      var worst = 0;
      [0.0, 0.2, 0.5, 0.9, 0.967].forEach(function (e) {
        for (i = 0; i <= 24; i++) {
          var M = TAU * i / 24 % TAU;          /* K.ecc は M を 0〜2π に直してから解く */
          var Ee = K.ecc(M, e);
          worst = Math.max(worst, Math.abs(Ee - e * Math.sin(Ee) - M));
        }
      });
      r.kepler_eq_err = +worst.toExponential(1);

      /* --- 1-5 円軌道→楕円：近地点の速さを上げると a・T・E が上がる --- */
      var sysE = SYS.earth, r0 = 6371 + 400;
      var b1 = P.m15.boost(r0, 1.0, sysE), b2 = P.m15.boost(r0, 1.2, sysE);
      r.boost_circle_e = +b1.e.toFixed(6);
      r.boost_circle_T_min = +(b1.T / 60).toFixed(3);
      r.boost_a_up = (b2.a > b1.a);
      r.boost_T_up = (b2.T > b1.T);
      r.boost_E_up = (b2.Em > b1.Em);
      r.boost_rp_keep = +Math.abs(b2.rp - r0).toFixed(6);       /* 近地点は変わらない */
      r.boost_escape_k = +(Math.sqrt(2)).toFixed(6);            /* √2 倍で脱出 */
      r.boost_escape_bound = P.m15.boost(r0, 1.4142, sysE).bound;
      r.boost_escape_unbound = !P.m15.boost(r0, 1.4143, sysE).bound;

      /* --- 1-1 火星の逆行：地球から見た黄経が減る時期がある --- */
      var mars = planetById('mars');
      var back = 0, N = 800;
      for (i = 0; i < N; i++) if (P.m11.retroNow(mars, 4 * i / N)) back++;
      r.mars_retro_frac = +(back / N).toFixed(3);               /* だいたい 0.09 くらい */
      var tr = P.m11.track(mars, 0, 4, 400);
      var lamMin = Infinity, lamMax = -Infinity;
      tr.forEach(function (p) { lamMin = Math.min(lamMin, p.bet); lamMax = Math.max(lamMax, p.bet); });
      r.mars_beta_range = +(lamMax - lamMin).toFixed(3);        /* 黄緯が動く＝ループになる */
      /* 会合周期（地球と火星が並ぶ間隔）＝ 1/(1/T地 − 1/T火) ≈ 2.135 年 */
      r.mars_synodic = +(1 / (1 / 1.000017 - 1 / 1.880848)).toFixed(4);

      /* ===== モード2 ===== */
      /* --- 補足（ケプラー則の起源）2体問題：重心は動かない・運動量の和は 0・m1r1 = m2r2 --- */
      var o21 = P.m21.make(1.0, 0.3, 1.2, 0.2);
      var cgMax = 0, pMax = 0, mrMax = 0;
      for (i = 0; i <= 60; i++) {
        var q21 = P.m21.state(o21, o21.T * i / 60);
        cgMax = Math.max(cgMax, Math.abs(1.0 * q21.b1.x + 0.3 * q21.b2.x),
          Math.abs(1.0 * q21.b1.y + 0.3 * q21.b2.y));
        pMax = Math.max(pMax, Math.abs(1.0 * q21.b1.vx + 0.3 * q21.b2.vx),
          Math.abs(1.0 * q21.b1.vy + 0.3 * q21.b2.vy));
        mrMax = Math.max(mrMax, Math.abs(1.0 * Math.hypot(q21.b1.x, q21.b1.y)
          - 0.3 * Math.hypot(q21.b2.x, q21.b2.y)));
      }
      r.two_body_cg_fixed = +cgMax.toFixed(12);
      r.two_body_momentum = +pMax.toFixed(12);
      r.two_body_m1r1_m2r2 = +mrMax.toFixed(12);
      r.two_body_T = +o21.T.toFixed(6);
      r.two_body_T_formula = +(TAU * Math.sqrt(Math.pow(1.2, 3) / (4 * Math.PI * Math.PI * 1.3))).toFixed(6);
      r.two_body_K = +(o21.T * o21.T / Math.pow(1.2, 3)).toFixed(6);
      r.two_body_K_formula = +(1 / 1.3).toFixed(6);           /* K = 1/(m1+m2) */

      /* --- 2-2 位置エネルギー：面積（数値積分）が GM/r と一致 --- */
      var rr0 = 20000, sum = 0, rmaxI = 5e10;
      /* 台形則で ∫ GM/r² dr を出し、式 GM/r と比べる。
         1/r² は近いところで急なので、近い側を細かく刻む（2段に分ける）。 */
      [[rr0, rr0 * 100, 400000], [rr0 * 100, rmaxI, 400000]].forEach(function (seg) {
        var dr = (seg[1] - seg[0]) / seg[2], j;
        for (j = 0; j < seg[2]; j++) {
          var ra1 = seg[0] + dr * j, rb1 = ra1 + dr;
          sum += (P.m22.GM / (ra1 * ra1) + P.m22.GM / (rb1 * rb1)) / 2 * dr;
        }
      });
      r.work_numeric = +sum.toFixed(4);
      r.work_formula = +P.m22.work(rr0).toFixed(4);
      r.g_at_surface = +P.m22.F(P.m22.R).toFixed(3);          /* ≈9.82 m/s² */
      r.mgh_vs_dU_100km = +((P.m22.mgh(100) - P.m22.dU(100)) / P.m22.dU(100) * 100).toFixed(3);

      /* --- 2-3 軌道の種類：速さの倍率で円・楕円・放物線・双曲線が切りかわる --- */
      var GMe = 398600.4418, r03 = 8000, vc3 = Math.sqrt(GMe / r03);
      r.kind_1_00 = K.orb(r03, 0, 1.00 * vc3, GMe).kind;
      r.kind_1_20 = K.orb(r03, 0, 1.20 * vc3, GMe).kind;
      r.kind_sqrt2 = K.orb(r03, 0, Math.SQRT2 * vc3, GMe).kind;
      r.kind_1_55 = K.orb(r03, 0, 1.55 * vc3, GMe).kind;
      r.kind_0_80 = K.orb(r03, 0, 0.80 * vc3, GMe).kind;
      /* 開いた軌道でも、エネルギーと角運動量は時刻によらず一定 */
      var oh = K.orb(r03, 0, 1.55 * vc3, GMe), eMax = -1e9, eMin = 1e9, lMax = -1e9, lMin = 1e9;
      for (i = 0; i <= 40; i++) {
        var qh = oh.at(oh.tTo(80000) * i / 40);
        var Eh = qh.v * qh.v / 2 - GMe / qh.r;
        var Lh = qh.x * qh.vy - qh.y * qh.vx;
        eMax = Math.max(eMax, Eh); eMin = Math.min(eMin, Eh);
        lMax = Math.max(lMax, Lh); lMin = Math.min(lMin, Lh);
      }
      r.hyper_E_spread = +(eMax - eMin).toExponential(1);
      r.hyper_L_spread = +(lMax - lMin).toExponential(1);
      /* 放物線でも同じ */
      var op = K.orb(r03, 0, Math.SQRT2 * vc3, GMe), peMax = -1e9, peMin = 1e9;
      for (i = 0; i <= 40; i++) {
        var qp = op.at(op.tTo(80000) * i / 40);
        peMax = Math.max(peMax, qp.v * qp.v / 2 - GMe / qp.r);
        peMin = Math.min(peMin, qp.v * qp.v / 2 - GMe / qp.r);
      }
      r.para_E_spread = +(peMax - peMin).toExponential(1);
      r.para_E_value = +op.Em.toExponential(1);
      /* 楕円の K.orb が K.state と同じ答えを出す */
      var oe = K.orb(r03, 0, 1.20 * vc3, GMe);
      r.orb_ellipse_T = +oe.T.toFixed(4);
      r.orb_ellipse_T_formula = +(TAU * Math.sqrt(Math.pow(oe.a, 3) / GMe)).toFixed(4);

      /* --- 2-4 静止衛星 --- */
      r.geo_r_from_T = +P.m24.rOf(P.m24.TDAY).toFixed(1);
      r.geo_T_check = +(P.m24.T(42164) / 3600).toFixed(4);
      r.iss_T_min = +(P.m24.T(6371 + 400) / 60).toFixed(2);   /* ISS ≈92.5 分 */
      r.iss_v = +P.m24.v(6371 + 400).toFixed(3);

      /* --- 2-5 スイングバイ：惑星から見た速さは前後で同じ、δ = 2arcsin(1/e) --- */
      var h5 = P.m25.make(1.26687e8, 8, 5e6);
      r.swing_e = +h5.e.toFixed(4);
      r.swing_delta_deg = +(h5.delta / DEG).toFixed(3);
      r.swing_delta_formula = +(2 * Math.asin(1 / h5.e) / DEG).toFixed(3);
      var o5 = P.m25.orb(h5);
      var Hf5 = Math.acosh((3e7 / o5.a + 1) / o5.e);
      var T05 = (o5.e * Math.sinh(Hf5) - Hf5) / o5.n;
      r.swing_v_in = +o5.at(-T05).v.toFixed(4);
      r.swing_v_out = +o5.at(T05).v.toFixed(4);               /* 前後で同じ */
      var spA = P.m25.sunSpeeds(h5, 13.06, 140 * DEG);
      var h5b = P.m25.make(1.26687e8, 8, -5e6);
      var spB = P.m25.sunSpeeds(h5b, 13.06, 140 * DEG);
      /* ★名前に注意★ spA は b>0（＝惑星の「前側」を通る）、spB は b<0（＝「後ろ側」）。
         下の swing_back_is_faster が「b<0 で加速・b>0 で減速」をきちんと確かめている。 */
      r.swing_gain_back = +spA.gain.toFixed(4);               /* b>0：前側を通る（減速） */
      r.swing_gain_front = +spB.gain.toFixed(4);              /* b<0：後ろ側を通る（加速） */
      r.swing_sign_flips = (spA.gain * spB.gain < 0);
      /* 最接近の点が惑星の前（+x）か後ろ（−x）か。b<0 で後ろを通り、太陽から見て加速する。 */
      var Bf = m25Build({ b5: 5e6, vinf: 8, ang: 140 });
      var Bb = m25Build({ b5: -5e6, vinf: 8, ang: 140 });
      r.swing_peri_side_bplus = Bf.at(Bf.T0).rel.x > 0 ? '前' : '後ろ';
      r.swing_peri_side_bminus = Bb.at(Bb.T0).rel.x > 0 ? '前' : '後ろ';
      r.swing_back_is_faster =
        (Bb.at(Bb.T0 * 2).sun.v - Bb.at(0).sun.v) > 0 &&
        (Bf.at(Bf.T0 * 2).sun.v - Bf.at(0).sun.v) < 0;
      return r;
    }
  };
})();
