/* 純粋な物理計算だけ（描画を混ぜない）。同じ入力 → 同じ出力。
   ★方針：楕円軌道は数値積分せず、ケプラー方程式から閉じた式で出す。
     M = 2π(t−t₀)/T  →  E − e sinE = M（ニュートン法）  →  r, θ, v
   こうすると、どの時刻でも誤差なく同じ絵になり、テストの再現性も保てる。 */
'use strict';
var DEG = Math.PI / 180;
var TAU = Math.PI * 2;

function clamp(x, a, b) { return x < a ? a : (x > b ? b : x); }
function fmt(x, d) {
  if (d === undefined) d = 1;
  if (!isFinite(x)) return '—';
  var s = x.toFixed(d);
  if (s === '-' + (0).toFixed(d)) s = (0).toFixed(d);   /* −0.0 を出さない */
  return s;
}
/* 大きい数・小さい数は指数で（例：3.99×10⁵） */
function fmtSup(n) {
  var map = { '-': '⁻', '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴', '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹' };
  return String(n).split('').map(function (c) { return map[c] || c; }).join('');
}
function fmtE(x, d) {
  if (!isFinite(x)) return '—';
  if (x === 0) return (0).toFixed(d === undefined ? 2 : d);
  var e = Math.floor(Math.log(Math.abs(x)) / Math.LN10);
  var m = x / Math.pow(10, e);
  if (Math.abs(m) >= 9.9995) { m /= 10; e++; }
  return fmt(m, d === undefined ? 2 : d) + '×10' + fmtSup(e);
}
/* 「ふつうの桁数」で読める数は素直に、けたが離れたら指数で */
function fmtAuto(x, d) {
  if (!isFinite(x)) return '—';
  var dd = (d === undefined) ? 2 : d;
  var a = Math.abs(x);
  if (a >= 1e5) return fmtE(x, 2);
  /* その桁では 0 になる小さい値も、指数ではなく素直に 0.000 と書く
     （4.83×10⁻⁸ のような表示は、生徒には「ほぼ 0」と読めないため）。
     小さい値を細かく見せたいところでは fmtE() を直接使うこと。 */
  return fmt(x, dd);
}

/* 長さの書き方（AU なら小数3けた、km なら整数…と、けたに合わせて自動で選ぶ） */
function fmtLen(x) {
  var a = Math.abs(x);
  if (!isFinite(x)) return '—';
  if (a >= 1e6) return fmtE(x, 3);
  if (a >= 1000) return fmt(x, 0);
  if (a >= 100) return fmt(x, 1);
  return fmt(x, 3);
}

var P = {};

/* ===== 単位系（シムごとに使い分ける。画面には必ず単位を出す） ===== */
var SYS = {
  /* 太陽系：長さ AU・時間 年。GM☉ = 4π² なので K = T²/a³ = 1 がきれいに出る */
  sun: {
    key: 'sun', GM: 4 * Math.PI * Math.PI, uL: 'AU', uT: '年', uV: 'AU/年',
    center: '太陽', body: '惑星', R: 0.00465,          /* 太陽の半径 [AU] */
    Klabel: 'K = T²/a³ [年²/AU³]'
  },
  /* 地球まわり：長さ km・時間 s。GM⊕ = 3.986×10⁵ km³/s² */
  earth: {
    key: 'earth', GM: 398600.4418, uL: 'km', uT: 's', uV: 'km/s',
    center: '地球', body: '人工衛星', R: 6371,          /* 地球の半径 [km] */
    Klabel: 'K = T²/a³ [s²/km³]'
  }
};
var G_CONST = 6.674e-11;      /* 万有引力定数 [N·m²/kg²] */
var M_SUN = 1.989e30;         /* 太陽の質量 [kg] */
var M_EARTH = 5.972e24;       /* 地球の質量 [kg] */
var AU_KM = 1.495978707e8;    /* 1 AU [km] */
var YEAR_S = 3.15576e7;       /* 1 年 [s] */

/* ===== ケプラー軌道の中身 ===== */
var K = {
  /* ケプラー方程式 E − e sinE = M をニュートン法で解く（同じ入力→同じ出力） */
  ecc: function (M, e) {
    M = M % TAU;
    if (M < 0) M += TAU;
    var E = (e < 0.8) ? M : Math.PI, i, f, fp;
    for (i = 0; i < 60; i++) {
      f = E - e * Math.sin(E) - M;
      fp = 1 - e * Math.cos(E);
      if (Math.abs(fp) < 1e-14) break;
      var dE = f / fp;
      if (dE > 0.8) dE = 0.8; else if (dE < -0.8) dE = -0.8;   /* e→1 での暴れ止め */
      E -= dE;
      if (Math.abs(dE) < 1e-14) break;
    }
    return E;
  },

  /* 軌道要素から出る量をまとめて返す（a[長さ]・e・GM） */
  elems: function (a, e, GM) {
    var b = a * Math.sqrt(Math.max(0, 1 - e * e));
    var T = TAU * Math.sqrt(a * a * a / GM);
    return {
      a: a, e: e, b: b, c: a * e, GM: GM,
      T: T,
      rp: a * (1 - e),                       /* 近日点距離 */
      ra: a * (1 + e),                       /* 遠日点距離 */
      vp: Math.sqrt(GM * (1 + e) / (a * (1 - e))),   /* 近日点の速さ */
      va: Math.sqrt(GM * (1 - e) / (a * (1 + e))),   /* 遠日点の速さ */
      L: Math.sqrt(GM * a * (1 - e * e)),    /* 角運動量／質量 = r v⊥ */
      dS: 0.5 * Math.sqrt(GM * a * (1 - e * e)),     /* 面積速度 dS/dt = L/2 */
      Em: -GM / (2 * a),                     /* 力学的エネルギー／質量 */
      Kc: (TAU * TAU) / GM                   /* T²/a³（ケプラー定数） */
    };
  },

  /* 時刻 t での状態。近日点を +x 方向、反時計まわりを正とする。
     M0＝t=0 での平均近点離角[rad]、retro＝true なら時計まわり（ハレー彗星） */
  state: function (o, t, M0, retro) {
    var e = o.e, a = o.a;
    var M = (M0 || 0) + TAU * t / o.T;
    var E = K.ecc(M, e);
    var cE = Math.cos(E), sE = Math.sin(E);
    var r = a * (1 - e * cE);
    /* 軌道面の座標（近日点方向が +x） */
    var x = a * (cE - e), y = o.b * sE;
    /* 速度：位置を t で微分（dE/dt = n/(1−e cosE)） */
    var n = TAU / o.T, dE = n / (1 - e * cE);
    var vx = -a * sE * dE, vy = o.b * cE * dE;
    if (retro) { y = -y; vy = -vy; }
    var th = Math.atan2(y, x);
    return {
      r: r, th: th, x: x, y: y, vx: vx, vy: vy,
      v: Math.hypot(vx, vy), E: E, M: M,
      /* 動径方向・周方向の速度成分 */
      vr: (x * vx + y * vy) / Math.max(1e-12, r),
      vt: (x * vy - y * vx) / Math.max(1e-12, r)
    };
  },

  /* 掃いた面積（近日点からの通過面積）。ケプラー方程式から閉じた式で出す。 */
  area: function (o, E) { return 0.5 * o.a * o.b * (E - o.e * Math.sin(E)); },

  /* 位置と速さから軌道の形を出す（1-5・2-3・3-1 で使う） */
  fromRV: function (r, vr, vt, GM) {
    var v2 = vr * vr + vt * vt;
    var Em = v2 / 2 - GM / r;                 /* 力学的エネルギー／質量 */
    var L = r * vt;
    var a = -GM / (2 * Em);                   /* Em<0 なら正（束縛） */
    var e2 = 1 + 2 * Em * L * L / (GM * GM);
    var e = Math.sqrt(Math.max(0, e2));
    return { a: a, e: e, Em: Em, L: L, bound: Em < 0 };
  },

  /* 軌道の種類（E の符号で決まる）。
     scale＝そのあたりのエネルギーの大きさ（GM/r など）。0 かどうかを相対的に判定する。 */
  kind: function (Em, e, scale) {
    var tol = 1e-9 * (scale || 1);
    if (Em >= -tol && Em <= tol) return 'para';
    if (Em > 0) return 'hyper';
    return (e < 0.005) ? 'circle' : 'ellipse';
  },
  kindName: function (k) {
    return k === 'circle' ? '円' : (k === 'ellipse' ? '楕円' : (k === 'para' ? '放物線' : '双曲線'));
  }
};

/* ===== 太陽系のデータ（元期 J2000.0）=====
   a[AU], e, T[年], inc＝軌道傾斜角[°], node＝昇交点黄経Ω[°],
   peri＝近日点黄経ϖ[°], L0＝元期の平均黄経[°]。
   （平均近点離角 M0 = L0 − ϖ）
   ※逆行の見かけの動きを本当のかたちで出すために、傾斜角まで入れている。 */
var PLANETS = [
  { id: 'mercury', name: '水星', a: 0.387098, e: 0.205630, T: 0.240846, inc: 7.005, node: 48.331, peri: 77.456, L0: 252.251, col: '#9a8d80', r: 3.2 },
  { id: 'venus', name: '金星', a: 0.723332, e: 0.006772, T: 0.615198, inc: 3.395, node: 76.680, peri: 131.533, L0: 181.980, col: '#d8b26a', r: 4.6 },
  { id: 'earth', name: '地球', a: 1.000000, e: 0.016710, T: 1.000017, inc: 0.000, node: 0.000, peri: 102.937, L0: 100.464, col: '#3f7f5f', r: 4.8 },
  { id: 'mars', name: '火星', a: 1.523710, e: 0.093410, T: 1.880848, inc: 1.850, node: 49.558, peri: 336.060, L0: 355.453, col: '#b5543a', r: 3.8 },
  { id: 'jupiter', name: '木星', a: 5.202887, e: 0.048386, T: 11.862615, inc: 1.304, node: 100.464, peri: 14.331, L0: 34.404, col: '#c99b6a', r: 10.5 },
  { id: 'saturn', name: '土星', a: 9.536676, e: 0.053862, T: 29.447498, inc: 2.486, node: 113.666, peri: 93.057, L0: 49.945, col: '#d6c08a', r: 9.2 },
  { id: 'uranus', name: '天王星', a: 19.189165, e: 0.047257, T: 84.016846, inc: 0.773, node: 74.006, peri: 173.005, L0: 313.232, col: '#8fc3c8', r: 7.0 },
  { id: 'neptune', name: '海王星', a: 30.069923, e: 0.008590, T: 164.79132, inc: 1.770, node: 131.784, peri: 48.124, L0: 304.880, col: '#5b7fc4', r: 6.8 },
  { id: 'pluto', name: '冥王星', a: 39.482117, e: 0.248808, T: 247.92065, inc: 17.16, node: 110.299, peri: 224.068, L0: 238.929, col: '#b09a86', r: 3.0, dwarf: true },
  { id: 'halley', name: 'ハレー彗星', a: 17.834, e: 0.96714, T: 75.32, inc: 162.26, node: 58.42, peri: 111.33, L0: 111.33 + 34.0, col: '#8fa3b0', r: 2.6, comet: true }
];
/* ===== 地球のまわりの衛星（1-3 の「地球と人工衛星」用）=====
   惑星と同じ形（a・e・T・inc・node・peri・L0・col・r）にしてあるので、
   planetXY / planetOrbitPts / planetTrailPts などがそのまま使える。
   a は km、T は 秒。人工衛星はどれもほぼ円軌道なので e = 0 としている。
   ★T は a から出した値（T = 2π√(a³/GM)）を使う。月だけは観測値（27.32 日）。★
   月は人工衛星ではないが、a が ISS の 57 倍もあり
   「同じ地球のまわりなら K がそろう」ことがいちばんよく分かるので入れてある。 */
var SATS = [
  /* short … 図の中の吹き出しに使う短い名前（長い名前だと図からはみ出すため） */
  { id: 'iss', name: 'ISS（国際宇宙ステーション）', short: 'ISS', a: 6771, e: 0, T: 5544, inc: 0, node: 0, peri: 0, L0: 0, col: '#3f7f5f', r: 4.2 },
  { id: 'hst', name: 'ハッブル宇宙望遠鏡', short: 'ハッブル', a: 6911, e: 0, T: 5718, inc: 0, node: 0, peri: 0, L0: 120, col: '#8fa3b0', r: 3.6 },
  { id: 'gps', name: 'GPS衛星', short: 'GPS', a: 26560, e: 0, T: 43082, inc: 0, node: 0, peri: 0, L0: 240, col: '#d8b26a', r: 3.8 },
  { id: 'himawari', name: 'ひまわり（静止衛星）', short: 'ひまわり', a: 42164, e: 0, T: 86164, inc: 0, node: 0, peri: 0, L0: 40, col: '#b5543a', r: 4.0 },
  { id: 'moon', name: '月（天然の衛星）', short: '月', a: 384400, e: 0, T: 2360591, inc: 0, node: 0, peri: 0, L0: 200, col: '#9a8d80', r: 5.0 }
];
function satById(id) {
  for (var i = 0; i < SATS.length; i++) if (SATS[i].id === id) return SATS[i];
  return SATS[0];
}

function planetById(id) {
  for (var i = 0; i < PLANETS.length; i++) if (PLANETS[i].id === id) return PLANETS[i];
  return PLANETS[2];
}

/* 惑星の軌道要素（キャッシュつき） */
var _pel = {};
function pElems(p) {
  if (!_pel[p.id]) {
    var o = K.elems(p.a, p.e, SYS.sun.GM);
    o.T = p.T;                                  /* 観測値の周期をそのまま使う */
    o.M0 = (p.L0 - p.peri) * DEG;
    o.retro = p.inc > 90;                       /* 逆行軌道（ハレー彗星） */
    _pel[p.id] = o;
  }
  return _pel[p.id];
}

/* 軌道面の座標（近日点方向が +x）→ 黄道座標。近日点引数 ω = ϖ − Ω */
function orbRotXYZ(p, x, y) {
  var w = (p.peri - p.node) * DEG, N = p.node * DEG, I = p.inc * DEG;
  var cw = Math.cos(w), sw = Math.sin(w), cN = Math.cos(N), sN = Math.sin(N);
  var cI = Math.cos(I), sI = Math.sin(I);
  var xw = x * cw - y * sw, yw = x * sw + y * cw;   /* 近日点引数の回転 */
  var zi = yw * sI, yi = yw * cI;                    /* 傾斜角の回転 */
  return { x: xw * cN - yi * sN, y: xw * sN + yi * cN, z: zi };
}

/* 惑星の「太陽を中心とする3次元の位置」[AU]。黄道面を xy、春分点方向を +x とする。 */
function planetXYZ(p, t) {
  var o = pElems(p);
  var s = K.state(o, t, o.M0, false);
  var q = orbRotXYZ(p, s.x, s.y);
  return { x: q.x, y: q.y, z: q.z, r: s.r, v: s.v, st: s };
}

/* 通ってきた道すじの点列（黄道面に投影）。
   ★時間で等分してはいけない★。ハレー彗星のように離心率が大きい天体は、時間の大半を
   遠日点のあたりで過ごすので、時間で等分すると「向きが一気に変わる近日点のあたり」が
   数点しか取れず、道すじがカクカクの折れ線になる（実際にそうなった）。
   軌道の線と同じ「離心近点離角 E で等分」にすれば、同じなめらかさで描ける。 */
function planetTrailPts(p, t, n) {
  var o = pElems(p), out = [], i;
  /* M（平均近点離角）→ E。まわった回数（2π の何周ぶんか）を保ったまま返す */
  function Efull(M) {
    var k = Math.floor(M / TAU);
    return K.ecc(M - TAU * k, o.e) + TAU * k;
  }
  var E0 = Efull(o.M0), E1 = Efull(o.M0 + TAU * t / o.T);
  if (!(E1 > E0)) return out;
  n = Math.max(2, Math.round(n));
  for (i = 0; i <= n; i++) {
    var E = E0 + (E1 - E0) * i / n;
    var q = orbRotXYZ(p, o.a * (Math.cos(E) - o.e), o.b * Math.sin(E));
    out.push([q.x, q.y]);
  }
  return out;
}

/* 道すじに必要な点の数。離心率が大きいほど細かくする（近日点で向きが急に変わるため） */
function trailN(p, t) {
  var revs = t / p.T;
  return clamp(Math.round((240 + 1200 * p.e * p.e) * revs), 150, 2000);
}

/* 惑星の軌道を黄道面に投影した点列（絵を描くため。キャッシュする） */
var _porb = {};
function planetOrbitPts(p, n) {
  var key = p.id + '_' + n;
  if (_porb[key]) return _porb[key];
  var o = pElems(p), out = [], i;
  for (i = 0; i <= n; i++) {
    var E = TAU * i / n;
    var q = orbRotXYZ(p, o.a * (Math.cos(E) - o.e), o.b * Math.sin(E));
    out.push([q.x, q.y]);
  }
  _porb[key] = out;
  return out;
}

/* 平面（黄道面に投影した）位置。全体図はこれで描く。 */
function planetXY(p, t) { var q = planetXYZ(p, t); return { x: q.x, y: q.y, r: q.r, v: q.v, st: q.st }; }

/* ===== 1-1 太陽系・火星の逆行 ===== */
P.m11 = {
  /* 地球から見た天体の方向（黄経 λ・黄緯 β）[°] */
  sky: function (target, t) {
    var e = planetXYZ(planetById('earth'), t);
    var m = planetXYZ(target, t);
    var dx = m.x - e.x, dy = m.y - e.y, dz = m.z - e.z;
    var d = Math.hypot(dx, dy, dz);
    return {
      lam: Math.atan2(dy, dx) / DEG,
      bet: Math.asin(clamp(dz / Math.max(1e-9, d), -1, 1)) / DEG,
      d: d
    };
  },
  /* 見かけの軌跡（λ を連続にほどいて返す）。逆行のループを描くのに使う。 */
  track: function (target, t0, t1, n) {
    var out = [], i, prev = null, off = 0;
    for (i = 0; i <= n; i++) {
      var t = t0 + (t1 - t0) * i / n;
      var s = P.m11.sky(target, t);
      var lam = s.lam;
      if (prev !== null) {
        while (lam + off - prev > 180) off -= 360;
        while (lam + off - prev < -180) off += 360;
      }
      prev = lam + off;
      out.push({ t: t, lam: prev, bet: s.bet, d: s.d });
    }
    return out;
  },
  /* 「衝」（太陽—地球—火星が一直線に並ぶ）の時刻を探す。
     このころに逆行が起きるので、逆行のビューはこの前後を見せる。 */
  _opp: null,
  oppT: function () {
    if (P.m11._opp !== null) return P.m11._opp;
    var e = planetById('earth'), m = planetById('mars'), i, prev = null, found = 1.0;
    for (i = 0; i <= 3000; i++) {
      var t = i * 0.002;                     /* 0〜6 年を 0.002 年きざみ */
      var pe = planetXYZ(e, t), pm = planetXYZ(m, t);
      var dl = Math.atan2(pm.y, pm.x) - Math.atan2(pe.y, pe.x);
      while (dl > Math.PI) dl -= TAU;
      while (dl < -Math.PI) dl += TAU;
      if (prev !== null && prev > 0 && dl <= 0 && prev < 1.0 && t > 0.8) { found = t; break; }
      prev = dl;
    }
    P.m11._opp = found;
    return found;
  },
  /* 逆行のビューで使う時間の原点（衝の 0.45 年前） */
  geoT0: function () { return Math.max(0, P.m11.oppT() - 0.45); },
  GEO_SPAN: 0.9,
  /* 逆行のビューで見せる天球の窓（黄経・黄緯の範囲）。1度だけ計算してとっておく */
  _box: null,
  geoBox: function () {
    if (P.m11._box) return P.m11._box;
    var m = planetById('mars'), t0 = P.m11.geoT0(), i;
    var l0 = Infinity, l1 = -Infinity, b0 = Infinity, b1 = -Infinity;
    for (i = 0; i <= 200; i++) {
      var q = P.m11.lamAt(m, t0 + P.m11.GEO_SPAN * i / 200);
      l0 = Math.min(l0, q.lam); l1 = Math.max(l1, q.lam);
      b0 = Math.min(b0, q.bet); b1 = Math.max(b1, q.bet);
    }
    var lp = (l1 - l0) * 0.10 + 1, bp = (b1 - b0) * 0.28 + 0.2;
    P.m11._box = { l0: l0 - lp, l1: l1 + lp, b0: b0 - bp, b1: b1 + bp };
    return P.m11._box;
  },

  /* 見かけの黄経を「つながった値」で読むための表（重いのでキャッシュする）。
     0〜TMAX 年を N 等分。同じ入力なら必ず同じ表になる。 */
  TMAX: 8, N: 1600, _tab: {},
  table: function (target) {
    if (P.m11._tab[target.id]) return P.m11._tab[target.id];
    var tb = P.m11.track(target, 0, P.m11.TMAX, P.m11.N);
    P.m11._tab[target.id] = tb;
    return tb;
  },
  /* 表から補間して読む（グラフと図で同じ値になるように） */
  lamAt: function (target, t) {
    var tb = P.m11.table(target);
    var f = clamp(t, 0, P.m11.TMAX) / P.m11.TMAX * P.m11.N;
    var i = Math.min(P.m11.N - 1, Math.floor(f)), g = f - i;
    var a = tb[i], b = tb[i + 1];
    return {
      lam: a.lam + (b.lam - a.lam) * g,
      bet: a.bet + (b.bet - a.bet) * g,
      d: a.d + (b.d - a.d) * g
    };
  },
  /* 逆行している（黄経が減っている）区間かどうか */
  retroNow: function (target, t) {
    var h = 0.004;
    var a = P.m11.sky(target, t - h).lam, b = P.m11.sky(target, t + h).lam;
    var d = b - a;
    while (d > 180) d -= 360;
    while (d < -180) d += 360;
    return d < 0;
  }
};

/* ===== 1-6　地動説の「発見」 =====
   地球から見た「太陽」「恒星」「火星」の見かけの位置。 */
P.m16 = {
  /* 恒星の例：アルデバラン（おうし座）。黄経・黄緯はほとんど動かない。 */
  star: { name: 'アルデバラン', lam: 69.79, bet: -5.47 },
  /* 地球から見た太陽の方向（黄経）。黄緯は 0（黄道の定義） */
  sunSky: function (t) {
    var e = planetXYZ(planetById('earth'), t);
    var lam = Math.atan2(-e.y, -e.x) / DEG;
    if (lam < 0) lam += 360;
    return { lam: lam, bet: 0, d: e.r };
  },
  /* 地球から見た惑星の方向（0〜360° に直したもの） */
  planetSky: function (p, t) {
    var q = P.m11.sky(p, t);
    var lam = q.lam;
    if (lam < 0) lam += 360;
    return { lam: lam, bet: q.bet, d: q.d };
  }
};

/* ===== 1-2〜1-5 で共通に使う「1つの軌道」 ===== */
P.orb = {
  /* a・e・単位系から軌道をつくる */
  make: function (a, e, sys) {
    var o = K.elems(a, e, sys.GM);
    o.sys = sys;
    return o;
  },
  /* 1周を tEnd にそろえる */
  state: function (o, t) { return K.state(o, t, 0, false); }
};

/* ===== 1-3 面積速度（扇形） ===== */
P.m13 = {
  /* 近日点からの離心近点離角 E で区切った扇形の面積 */
  sector: function (o, E1, E2) { return Math.abs(K.area(o, E2) - K.area(o, E1)); },
  /* 時刻 t1〜t2 のあいだに掃く面積（式で出す：面積速度×時間） */
  swept: function (o, t1, t2) { return o.dS * Math.abs(t2 - t1); }
};

/* ===== 1-5 円軌道からエネルギーを上げて楕円へ ===== */
P.m15 = {
  /* 半径 r0 の円軌道で、近地点の速さを k 倍したときの軌道 */
  boost: function (r0, k, sys) {
    var vc = Math.sqrt(sys.GM / r0);
    var v = vc * k;
    var f = K.fromRV(r0, 0, v, sys.GM);
    var o = K.elems(f.a, f.e, sys.GM);
    o.sys = sys; o.v0 = v; o.vc = vc; o.r0 = r0; o.Em = f.Em; o.bound = f.bound;
    return o;
  },
  /* 脱出速度 */
  vEsc: function (r, sys) { return Math.sqrt(2 * sys.GM / r); }
};

/* ============================================================
   ここから モード2「万有引力とエネルギー」で使う計算
   ============================================================ */

/* ===== 円・楕円だけでなく、放物線・双曲線もあつかえる軌道 =====
   位置 r0 と速度（動径方向 vr・垂直方向 vt）から軌道を決め、
   時刻 t での位置・速度を「閉じた式」で返す。数値積分はしない。
   近点を +x 方向、反時計まわりを正とする。t=0 は「はじめの位置」。 */

/* 双曲線ケプラー方程式 M = e sinhH − H をニュートン法で解く */
K.hypSolve = function (M, e) {
  var H = Math.asinh(M / Math.max(1e-9, e)), i, f, fp, dH;
  for (i = 0; i < 90; i++) {
    f = e * Math.sinh(H) - H - M;
    fp = e * Math.cosh(H) - 1;
    if (Math.abs(fp) < 1e-14) break;
    dH = f / fp;
    if (dH > 1) dH = 1; else if (dH < -1) dH = -1;
    H -= dH;
    if (Math.abs(dH) < 1e-13) break;
  }
  return H;
};
/* 放物線（バーカーの式）：D³ + 3D = 3M を3次方程式の解の公式で解く（近似ではない） */
K.parSolve = function (M) {
  var s = Math.sqrt(2.25 * M * M + 1);
  return Math.cbrt(1.5 * M + s) + Math.cbrt(1.5 * M - s);
};

/* r0 の位置で、動径方向 vr・垂直方向 vt の速度をもつ天体の軌道 */
K.orb = function (r0, vr, vt, GM) {
  var f = K.fromRV(r0, vr, vt, GM);
  var o = {
    GM: GM, e: f.e, Em: f.Em, L: f.L, r0: r0, vr0: vr, vt0: vt,
    kind: K.kind(f.Em, f.e, GM / r0)
  };
  /* 閉じた軌道かどうかは「種類」から決める。
     E がちょうど 0 のとき、計算のごくわずかな誤差で Em<0 になることがあり、
     bound だけを Em の符号で決めると「放物線なのに a や T を出そうとする」ことになる。 */
  o.bound = (o.kind === 'circle' || o.kind === 'ellipse');
  o.v0 = Math.hypot(vr, vt);
  if (o.kind === 'para') {
    o.q = f.L * f.L / (2 * GM);                 /* 近点距離 */
    o.a = Infinity; o.T = Infinity;
    o.np = Math.sqrt(GM / (2 * o.q * o.q * o.q));
    var D0 = Math.sqrt(Math.max(0, r0 / o.q - 1)) * (vr >= 0 ? 1 : -1);
    o.t0 = (D0 + D0 * D0 * D0 / 3) / o.np;
  } else if (o.kind === 'hyper') {
    o.a = -f.a;                                  /* 双曲線では a>0 に直す */
    o.q = o.a * (f.e - 1);
    o.T = Infinity;
    o.n = Math.sqrt(GM / (o.a * o.a * o.a));
    var cH = (r0 / o.a + 1) / Math.max(1e-12, f.e);
    var H0 = Math.acosh(Math.max(1, cH)) * (vr >= 0 ? 1 : -1);
    o.t0 = (f.e * Math.sinh(H0) - H0) / o.n;
  } else {
    o.a = f.a;
    o.q = o.a * (1 - f.e);
    o.ra = o.a * (1 + f.e);
    o.b = o.a * Math.sqrt(Math.max(0, 1 - f.e * f.e));
    o.T = TAU * Math.sqrt(o.a * o.a * o.a / GM);
    o.n = TAU / o.T;
    var E0 = 0;
    if (f.e > 1e-9) E0 = Math.acos(clamp((1 - r0 / o.a) / f.e, -1, 1)) * (vr >= 0 ? 1 : -1);
    o.t0 = (E0 - f.e * Math.sin(E0)) / o.n;
  }
  /* 時刻 t（はじめの位置を t=0 とする）での位置と速度 */
  o.at = function (t) {
    var tt = o.t0 + t, x, y, vx, vy, r;
    if (o.kind === 'para') {
      var D = K.parSolve(o.np * tt);
      r = o.q * (1 + D * D);
      x = o.q * (1 - D * D); y = 2 * o.q * D;
      var vpar = Math.sqrt(2 * GM / r);
      var vt1 = o.L / r, vr1 = Math.sqrt(Math.max(0, vpar * vpar - vt1 * vt1)) * (D >= 0 ? 1 : -1);
      var ux = x / r, uy = y / r;
      vx = ux * vr1 - uy * vt1; vy = uy * vr1 + ux * vt1;
    } else if (o.kind === 'hyper') {
      var H = K.hypSolve(o.n * tt, o.e);
      var chH = Math.cosh(H), shH = Math.sinh(H);
      r = o.a * (o.e * chH - 1);
      x = o.a * (o.e - chH); y = o.a * Math.sqrt(o.e * o.e - 1) * shH;
      var dH = o.n / (o.e * chH - 1);
      vx = -o.a * shH * dH; vy = o.a * Math.sqrt(o.e * o.e - 1) * chH * dH;
    } else {
      var E = K.ecc(o.n * tt, o.e);
      var cE = Math.cos(E), sE = Math.sin(E);
      r = o.a * (1 - o.e * cE);
      x = o.a * (cE - o.e); y = o.b * sE;
      var dE = o.n / (1 - o.e * cE);
      vx = -o.a * sE * dE; vy = o.b * cE * dE;
    }
    return {
      x: x, y: y, r: r, vx: vx, vy: vy, v: Math.hypot(vx, vy),
      vr: (x * vx + y * vy) / Math.max(1e-12, r),
      vt: (x * vy - y * vx) / Math.max(1e-12, r)
    };
  };
  /* 近点から外向きに進んで距離 r になるまでの時間（開いた軌道の tEnd を出すのに使う） */
  o.tOut = function (r) {
    if (o.kind === 'para') {
      var D = Math.sqrt(Math.max(0, r / o.q - 1));
      return (D + D * D * D / 3) / o.np;
    }
    if (o.kind === 'hyper') {
      var H = Math.acosh(Math.max(1, (r / o.a + 1) / o.e));
      return (o.e * Math.sinh(H) - H) / o.n;
    }
    var E = Math.acos(clamp((1 - r / o.a) / Math.max(1e-9, o.e), -1, 1));
    return (E - o.e * Math.sin(E)) / o.n;
  };
  /* 「はじめの位置」から測った時間 */
  o.tTo = function (r) { return o.tOut(r) - o.t0; };

  /* 軌道の線（描くための点列）。開いた軌道は rmax まで */
  o.path = function (rmax, n) {
    var out = [], i;
    n = n || 220;
    if (o.kind === 'circle' || o.kind === 'ellipse') {
      for (i = 0; i <= n; i++) {
        var E = TAU * i / n;
        out.push([o.a * (Math.cos(E) - o.e), o.b * Math.sin(E)]);
      }
      return out;
    }
    /* 開いた軌道：真近点角 ν を −νmax〜+νmax まで振る */
    var p = (o.kind === 'para') ? 2 * o.q : o.a * (o.e * o.e - 1);
    var cmax = (p / rmax - 1) / o.e;             /* r = p/(1+e cosν) = rmax となる ν */
    var numax = Math.acos(clamp(cmax, -0.9999, 1)) * 0.999;
    for (i = 0; i <= n; i++) {
      var nu = -numax + 2 * numax * i / n;
      var rr = p / (1 + o.e * Math.cos(nu));
      out.push([rr * Math.cos(nu), rr * Math.sin(nu)]);
    }
    return out;
  };
  return o;
};

/* ===== 補足：ケプラー則の起源は万有引力（2体問題・共通重心のまわりの運動） =====
   質量 m1・m2 が共通重心のまわりを回る。相対運動はケプラー軌道なので、
   数値積分せずに閉じた式で出せる。 */
/* ===== 2-1　万有引力と位置エネルギー（重力場のイメージ）=====
   地球（質量 M）が作る位置エネルギー U = −GM/r の「すりばち」の中を、
   人工衛星（質量 m）が動くようすを見せるためのもの。
   ★2-2・2-3 と同じ「地球と人工衛星」の舞台にそろえてある★（km・秒・km/s）。

   ★数値積分はしない★ 軌道は全部 K.orb（閉じた式）で出す。
   初速度 0（＝角運動量 0）のときも、K.orb は ε = 1・短半径 0 の「つぶれた楕円」として
   ちゃんと解ける。地球の中心を通りぬけて行ったり来たりする振動になる
   （＝すりばちに置いたボールが底を通って左右にゆれるのと同じ）。 */
P.grav = {
  GM1: 398600.4418,   /* 地球（M = 1 地球質量）の GM［km³/s²］ */
  RE: 6371,           /* 地球の半径［km］ */
  R0: 10000,          /* 人工衛星を置く場所の既定値［km］（地球の中心から） */
  RSUN: 13,           /* 絵の中の地球の半径［px］（M = 1.0 のときの値） */
  RE: 6371,           /* 本当の地球の半径［km］。欄外の説明に使う */
  /* ★質量 M を変えたら、絵の中の地球の大きさも変える★
     同じ密度の球とみなして R ∝ M^{1/3} …では見た目の変化が小さすぎるので、
     はっきり分かるように M^{1/2} でふくらませている（図の中に「※」で断っている）。
     ★ただし、ふくらませすぎると人工衛星や力の矢印が地球の絵に埋もれる★
       M = 2 で 18.4 px。人工衛星のいちばん内がわ（r₀ = 7000 km ≒ 38 px）とは
       まだ 20 px 空いているので、ここが上限のめやす（→ 上限 M = 2.0）。 */
  Rpx: function (Ms) { return P.grav.RSUN * Math.sqrt(Ms); },
  RMIN: 1000,         /* ★グラフを描く いちばん内側★［km］。U = −GM/r は r→0 で発散するため */
  RSCALE: 3000,       /* ★たての目もりを決める距離★［km］
                         RMIN まで目もりに入れると、いちばん見せたい「r = 1万 km あたり」が
                         つぶれて読めなくなる。3000 km までを箱の高さにして、
                         それより内側は箱の下へはみ出させる（下半分はクリップしてある）。 */
  RMAX: 40000,        /* すりばちのふちの距離［km］ */
  MMAX: 2.0,          /* 質量 M の上限［地球質量］。すりばちの深さの目盛りを決めるのに使う */
  gm: function (Ms) { return P.grav.GM1 * Ms; },
  /* 半径 r0 の円軌道になる速さ・脱出速度［km/s］。r0 を省くと既定値 R0 を使う */
  vCirc: function (Ms, r0) { return Math.sqrt(P.grav.gm(Ms) / (r0 || P.grav.R0)); },
  vEsc: function (Ms, r0) { return Math.SQRT2 * P.grav.vCirc(Ms, r0); },
  U: function (Ms, r) { return -P.grav.gm(Ms) / Math.max(1e-6, r); },
  /* すりばちを描くための U（底を RMIN で打ち切る。そうしないと絵が無限に深くなる） */
  Uwell: function (Ms, r) { return -P.grav.gm(Ms) / Math.max(P.grav.RMIN, r); },
  /* すりばちの深さ［U の単位・かならず正］。M が大きいほど深い＝くぼみが大きい。
     ★底は RMIN ではなく RSCALE でとる★（上のコメントを読むこと） */
  depth: function (Ms) { return P.grav.Uwell(Ms, P.grav.RMAX) - P.grav.U(Ms, P.grav.RSCALE); },
  /* 初速度の大きさ v0［km/s］と向き th［°］から軌道を作る。
     ★向きの決め方★ th は「人工衛星から地球へ向かう動径」と速度のなす角。
       th = 0°  … 地球へまっすぐ突っこむ向き
       th = 90° … 動径に垂直（横向き。円軌道になりうる向き）
       th = 180°… 地球からまっすぐ遠ざかる向き */
  make: function (Ms, kv, th, r0) {
    var GM = P.grav.gm(Ms);
    r0 = r0 || P.grav.R0;
    /* ★速さの決め方は 1-4・2-2 とそろえて「k」で書く★
       v0 = √(k GM/r0)。k = 1 が円軌道、k = 2 が脱出（第二宇宙速度）。 */
    var v0km = Math.sqrt(kv * GM / r0);
    var a = th * Math.PI / 180;
    /* 動径「外向き」の成分は −cos(th)（th=0 で内向き＝マイナス） */
    var o = K.orb(r0, -v0km * Math.cos(a), v0km * Math.sin(a), GM);
    o.Ms = Ms; o.v0km = v0km; o.th = th; o.r0 = r0; o.kv = kv;
    o.vc = P.grav.vCirc(Ms, r0); o.ve = P.grav.vEsc(Ms, r0);
    /* K.orb は「近点が +x」の座標で返す。はじめの位置がいつも +x（画面の右）に来るように回す。
       こうしておくと、初速度を変えても出発点が動かないので見比べやすい。 */
    var q0 = o.at(0), ph = Math.atan2(q0.y, q0.x);
    o.cph = Math.cos(-ph); o.sph = Math.sin(-ph);
    return o;
  },
  /* 回したあとの位置と速度 */
  at: function (o, t) {
    var q = o.at(t), c = o.cph, s = o.sph;
    return {
      x: q.x * c - q.y * s, y: q.x * s + q.y * c,
      vx: q.vx * c - q.vy * s, vy: q.vx * s + q.vy * c,
      r: q.r, v: q.v, vr: q.vr, vt: q.vt
    };
  },
  /* 回したあとの軌道の線 */
  path: function (o, rmax, n) {
    var c = o.cph, s = o.sph;
    return o.path(rmax, n).map(function (p) {
      return [p[0] * c - p[1] * s, p[0] * s + p[1] * c];
    });
  }
};

P.m21 = {
  /* m1, m2 は太陽質量。a は相対軌道の半長軸[AU]。GM = 4π²(m1+m2) */
  make: function (m1, m2, a, e) {
    var M = m1 + m2;
    var GM = 4 * Math.PI * Math.PI * M;
    var o = K.elems(a, e, GM);
    o.m1 = m1; o.m2 = m2; o.M = M; o.GM = GM;
    o.f1 = m2 / M;                    /* 重心から天体1までの距離 ÷ 相対距離 */
    o.f2 = m1 / M;
    o.a1 = a * o.f1; o.a2 = a * o.f2;
    return o;
  },
  /* 時刻 t での2天体の位置（共通重心が原点） */
  state: function (o, t) {
    var q = K.state(o, t, 0, false);
    return {
      r: q.r, v: q.v,
      b1: { x: -o.f1 * q.x, y: -o.f1 * q.y, vx: -o.f1 * q.vx, vy: -o.f1 * q.vy },
      b2: { x: o.f2 * q.x, y: o.f2 * q.y, vx: o.f2 * q.vx, vy: o.f2 * q.vy }
    };
  },
  /* 万有引力の大きさ F = G m1 m2 / r²（太陽質量・AU・年の単位系） */
  force: function (o, r) { return 4 * Math.PI * Math.PI * o.m1 * o.m2 / (r * r); }
};

/* ===== 2-2　位置エネルギー =====
   地球のまわりで考える。単位質量あたりで U = −GM/r [MJ/kg]。 */
P.m22 = {
  R: 6371, GM: 398600.4418, g: 9.8,
  U: function (r) { return -P.m22.GM / r; },                 /* MJ/kg */
  F: function (r) { return P.m22.GM / (r * r) * 1000; },     /* 単位質量あたりの力 [m/s²] */
  /* 高さ h[km] まで持ち上げる仕事：ほんとうの値と mgh の違い */
  dU: function (h) { return P.m22.U(P.m22.R + h) - P.m22.U(P.m22.R); },
  mgh: function (h) { return P.m22.g * h * 1000 / 1e6; },    /* MJ/kg */
  /* 無限遠まで運ぶ仕事 = GM/r（F–r 図の面積） */
  work: function (r) { return P.m22.GM / r; }
};

/* ===== 2-4　人工衛星の周期・静止衛星 ===== */
P.m24 = {
  R: 6371, GM: 398600.4418,
  TDAY: 86164.0905,                       /* 地球の自転周期（恒星日）[s] */
  T: function (r) { return TAU * Math.sqrt(r * r * r / P.m24.GM); },
  v: function (r) { return Math.sqrt(P.m24.GM / r); },
  /* 周期が T になる半径 */
  rOf: function (T) { return Math.pow(P.m24.GM * T * T / (4 * Math.PI * Math.PI), 1 / 3); },
  rGeo: function () { return P.m24.rOf(P.m24.TDAY); }
};

/* ===== 2-5　スイングバイ =====
   惑星から見ると双曲線軌道。惑星は速さ Vp で +x 方向に等速で動くとする。
   太陽から見た速度 = 惑星の速度 + 惑星から見た速度（ガリレイ変換）。 */
P.m25 = {
  /* GMp＝惑星の重力定数[km³/s²]、vinf＝遠方での相対速さ[km/s]、b＝衝突パラメータ[km]
     b>0 で惑星の「前（進行方向側）」を通る。 */
  make: function (GMp, vinf, b) {
    var ab = GMp / (vinf * vinf);                  /* 双曲線の a（>0） */
    var e = Math.sqrt(1 + (b * b) / (ab * ab));
    var dl = 2 * Math.asin(1 / e);                 /* 曲がる角（偏向角） */
    return { GM: GMp, vinf: vinf, b: b, a: ab, e: e, delta: dl, q: ab * (e - 1) };
  },
  /* 惑星から見た軌道（双曲線）。b の符号で回る向きを変える。 */
  orb: function (h) {
    var sgn = (h.b >= 0) ? 1 : -1;
    var o = { a: h.a, e: h.e, GM: h.GM, n: Math.sqrt(h.GM / (h.a * h.a * h.a)), sgn: sgn };
    o.at = function (t) {
      var H = K.hypSolve(o.n * t, o.e);
      var chH = Math.cosh(H), shH = Math.sinh(H);
      var r = o.a * (o.e * chH - 1);
      var x = o.a * (o.e - chH), y = o.a * Math.sqrt(o.e * o.e - 1) * shH * sgn;
      var dH = o.n / (o.e * chH - 1);
      var vx = -o.a * shH * dH, vy = o.a * Math.sqrt(o.e * o.e - 1) * chH * dH * sgn;
      return { x: x, y: y, r: r, vx: vx, vy: vy, v: Math.hypot(vx, vy) };
    };
    return o;
  },
  /* 太陽から見た「前」と「後」の速さ（惑星の速度 Vp を足す）。
     惑星から見た速度は、遠方では大きさ vinf のまま向きだけ δ だけ回る。 */
  sunSpeeds: function (h, Vp, thIn) {
    var sgn = (h.b >= 0) ? 1 : -1;
    var a1 = thIn;                                  /* 入ってくる向き（惑星から見て） */
    var a2 = thIn + h.delta * sgn;                  /* 出ていく向き */
    var vin = { x: h.vinf * Math.cos(a1) + Vp, y: h.vinf * Math.sin(a1) };
    var vout = { x: h.vinf * Math.cos(a2) + Vp, y: h.vinf * Math.sin(a2) };
    return {
      vin: Math.hypot(vin.x, vin.y), vout: Math.hypot(vout.x, vout.y),
      vinVec: vin, voutVec: vout, gain: Math.hypot(vout.x, vout.y) - Math.hypot(vin.x, vin.y)
    };
  }
};

/* ============================================================
   モード3「入試物理」で使う計算
   ============================================================ */

/* ===== 3-1 等速円運動から楕円軌道への遷移（大阪市立大）=====
   地上の1点から鉛直上方へ打ち上げ、地球の中心から rA = 2R の点 A でちょうど速さ 0 になる。
   その瞬間に、OA に垂直な向きのエネルギー E'（＝½mv²）を加える。
   ★E' の大きさだけで軌道が決まる★
     E' <  mgR/6  … 近地点が地表より内側 → 地球に落ちる
     E' =  mgR/6  … 近地点がちょうど地表（ぎりぎり落ちない）
     E' =  mgR/4  … 半径 2R の等速円運動（v = √(gR/2)）
     E' = 3mgR/8  … AB を長軸とするだ円（B は中心から 6R）
     E' =  mgR/2  … 放物線（脱出）／それ以上は双曲線
   軌道はすべて K.orb（閉じた式）で出す。数値積分はしない。 */
P.m31 = {
  GM: 398600.4418, R: 6371,
  rA: function () { return 2 * P.m31.R; },
  /* gR = GM/R［km²/s²］。E' は「mgR の何倍か」で表す（式がきれいになるため） */
  gR: function () { return P.m31.GM / P.m31.R; },
  vOf: function (eq) { return Math.sqrt(2 * eq * P.m31.gR()); },
  eqOf: function (v) { return v * v / (2 * P.m31.gR()); },
  EQ_MIN: 1 / 6,        /* 近地点がちょうど地表 */
  EQ_CIRC: 0.25,        /* 半径 2R の円 */
  EQ_AB: 0.375,         /* B が 6R のだ円 */
  EQ_ESC: 0.5,          /* 放物線（脱出） */
  make: function (eq) {
    var v = P.m31.vOf(eq), rA = P.m31.rA();
    /* 点 A で動径方向の速さ 0・垂直方向 v */
    var o = K.orb(rA, 0, v, P.m31.GM);
    o.v = v; o.eq = eq; o.rA = rA;
    o.hit = o.bound && (o.q < P.m31.R);            /* 地球に落ちるか */
    /* K.orb は「近点が +x」で返す。点 A を画面の左（−x）に置く（問題の図に合わせる） */
    var q0 = o.at(0), ph = Math.atan2(q0.y, q0.x);
    var rot = Math.PI - ph;
    o.cph = Math.cos(rot); o.sph = Math.sin(rot);
    return o;
  },
  at: function (o, t) {
    var q = o.at(t), c = o.cph, s = o.sph;
    return {
      x: q.x * c - q.y * s, y: q.x * s + q.y * c,
      vx: q.vx * c - q.vy * s, vy: q.vx * s + q.vy * c,
      r: q.r, v: q.v, vr: q.vr, vt: q.vt
    };
  },
  path: function (o, rmax, n) {
    var c = o.cph, s = o.sph;
    return o.path(rmax, n).map(function (p) {
      return [p[0] * c - p[1] * s, p[0] * s + p[1] * c];
    });
  },
  /* 地表（r = R）に落ちるまでの時間。
     t0 は「近点からの時刻」なので、近点を通りすぎて r = R になるのは
     近点から数えて T − tOut(R)。そこから t0 を引けば、いまからの時間になる。 */
  tHit: function (o) {
    return Math.max(1, o.T - o.tOut(P.m31.R) - o.t0);
  },

  /* ===== 打ち上げ（地表 → 点 A）=====
     ★問題でいちばんはじめに起こることなので、スタートを押したらここから動かす★
     地表から鉛直上向きに v₀ = √(gR) で打ち上げる。
       E/m = v₀²/2 − GM/R = GM/2R − GM/R = −GM/(2R)
     なので、まっすぐ上がって r = 2R（点 A）でちょうど速さ 0 になる。
     まっすぐな（動径だけの）運動は、つぶれただ円としてケプラーの式で解ける：
       r = a(1 − cos η),  t = √(a³/GM)(η − sin η),  a = |GM/2E| = R
     数値積分はしない。P.m32 の tOut / rOut がちょうど同じ式なので、それを使う。 */
  Elaunch: function () { return -P.m31.GM / (2 * P.m31.R); },
  /* 地表から点 A までにかかる時間［s］（約 34.5 分） */
  tLaunch: function () {
    var E = P.m31.Elaunch();
    return P.m32.tOut(E, 2 * P.m31.R) - P.m32.tOut(E, P.m31.R);
  },
  /* 打ち上げ中（0 ≤ t ≤ tLaunch）の位置と速度。点 A は画面の左（−x）にある */
  launchAt: function (t) {
    var E = P.m31.Elaunch(), R = P.m31.R;
    var t0 = P.m32.tOut(E, R);
    var r = clamp(P.m32.rOut(E, t0 + Math.max(0, t)), R, 2 * R);
    var v = Math.sqrt(Math.max(0, 2 * (E + P.m31.GM / r)));
    /* 位置は −x 向き、速度は「外向き」＝これも −x 向き */
    return { x: -r, y: 0, vx: -v, vy: 0, r: r, v: v, vr: v, vt: 0 };
  }
};

/* ===== 3-2 地球トンネル（名古屋大 2005）=====
   一様な球の地球に、中心を通るまっすぐな穴をあけて、x 軸上の点 x0 から静かに放す。
     |x| < R … F = −(GMm/R³)x ＝ 変位に比例して中心へ向かう力 ＝ 単振動
     |x| > R … F = −GMm/x²   ＝ ふつうの万有引力
   ★内側で放すと単振動（周期 84.4 分・x0 によらない）★
   ★外側で放すと、落ちてきて中を通りぬけ、反対がわの同じ高さまで上がって戻る★
   外側の落下は「つぶれただ円（e = 1）」のパラメータ表示
     r = a(1 − cos η),  t = √(a³/GM)(η − sin η),  a = x0/2
   で閉じた式に書ける。η は「η − sinη = M」を二分法で解く（単調なので必ず収束）。 */
P.m32 = {
  GM: 398600.4418, R: 6371, g: 9.8,
  w: function () { return Math.sqrt(P.m32.GM / Math.pow(P.m32.R, 3)); },
  Tin: function () { return TAU / P.m32.w(); },        /* 内側の単振動の周期 = 84.4 分 */

  /* 位置エネルギー／質量。外は −GM/x、内は −(GM/2R)(3 − x²/R²) */
  U: function (x) {
    var ax = Math.abs(x), R = P.m32.R, GM = P.m32.GM;
    return (ax <= R) ? -GM / (2 * R) * (3 - (ax * ax) / (R * R)) : -GM / ax;
  },
  /* 位置 x での「単位質量あたりの万有引力」［m/s²］。中心へ向かう向きを正とする */
  F: function (x) {
    var ax = Math.abs(x), R = P.m32.R, GM = P.m32.GM;
    return (ax <= R ? GM * ax / (R * R * R) : GM / (ax * ax)) * 1000;
  },
  /* その場所での脱出速度［km/s］ */
  vEsc: function (x) { return Math.sqrt(2 * Math.max(0, -P.m32.U(x))); },

  /* η − sinη = M（0 ≤ M ≤ π）を二分法で解く（単調なので必ず収束する） */
  etaOf: function (M) {
    if (M <= 0) return 0;
    if (M >= Math.PI) return Math.PI;
    var lo = 0, hi = Math.PI, i, mid;
    for (i = 0; i < 80; i++) {
      mid = (lo + hi) / 2;
      if (mid - Math.sin(mid) < M) lo = mid; else hi = mid;
    }
    return (lo + hi) / 2;
  },

  /* ===== 地球の外側（ふつうの万有引力）での「まっすぐな落下・上昇」 =====
     E<0：r = a(1−cosη),  t = √(a³/GM)(η−sinη),  a = −GM/(2E)
     E=0：t = (2/3)r^{3/2}/√(2GM)
     E>0：r = a(coshη−1), t = √(a³/GM)(sinhη−η),  a =  GM/(2E)
     どれも「中心（r=0）を出発してからの時間」で測る。 */
  tOut: function (E, r) {
    var GM = P.m32.GM;
    if (Math.abs(E) < 1e-12) return (2 / 3) * Math.pow(r, 1.5) / Math.sqrt(2 * GM);
    var a = Math.abs(GM / (2 * E)), n = Math.sqrt(GM / (a * a * a));
    if (E < 0) {
      var eta = Math.acos(clamp(1 - r / a, -1, 1));
      return (eta - Math.sin(eta)) / n;
    }
    var H = Math.acosh(Math.max(1, 1 + r / a));
    return (Math.sinh(H) - H) / n;
  },
  rOut: function (E, t) {
    var GM = P.m32.GM;
    if (t <= 0) return 0;
    if (Math.abs(E) < 1e-12) return Math.pow(1.5 * Math.sqrt(2 * GM) * t, 2 / 3);
    var a = Math.abs(GM / (2 * E)), n = Math.sqrt(GM / (a * a * a)), M = n * t;
    if (E < 0) return a * (1 - Math.cos(P.m32.etaOf(clamp(M, 0, Math.PI))));
    return a * (Math.cosh(P.m32.sinhOf(M)) - 1);
  },
  /* sinhH − H = M を二分法で解く（M ≥ 0・単調） */
  sinhOf: function (M) {
    if (M <= 0) return 0;
    var lo = 0, hi = 1;
    while (Math.sinh(hi) - hi < M && hi < 60) hi *= 2;
    var i, mid;
    for (i = 0; i < 90; i++) {
      mid = (lo + hi) / 2;
      if (Math.sinh(mid) - mid < M) lo = mid; else hi = mid;
    }
    return (lo + hi) / 2;
  },

  /* x0［km］の位置から、+x の向きに v0［km/s］で発射する（v0 = 0 なら「静かに放す」）。
     すべて「中心を +x 向きに通過する瞬間」を基準にして組み立てる。 */
  make: function (x0, v0) {
    var R = P.m32.R, GM = P.m32.GM, w = P.m32.w();
    var E = 0.5 * v0 * v0 + P.m32.U(x0);
    /* 内側の単振動の「見かけの振幅」：½ω²A² = E + 3GM/2R */
    var A = Math.sqrt(Math.max(0, 2 * (E + 3 * GM / (2 * R)))) / w;
    var h = { x0: x0, v0: v0, E: E, A: A, w: w, R: R };
    if (A <= R * (1 + 1e-9)) {
      /* 全部地球の中 ＝ ふつうの単振動。周期は振幅によらない */
      h.inside = true; h.bound = true;
      h.xmax = A; h.T = TAU / w; h.tauR = Infinity;
      h.tau0 = (A > 1e-9) ? Math.asin(clamp(x0 / A, -1, 1)) / w : 0;
      return h;
    }
    h.inside = false;
    h.tauR = Math.asin(clamp(R / A, -1, 1)) / w;      /* 中心 → 地表 の時間 */
    h.tR = P.m32.tOut(E, R);                          /* 外の式での「中心 → 地表」 */
    h.bound = (E < -1e-12);
    h.xmax = h.bound ? (-GM / E) : Infinity;
    if (h.bound) {
      h.quarter = h.tauR + (P.m32.tOut(E, h.xmax) - h.tR);
      h.T = 4 * h.quarter;
    } else {
      h.T = Infinity;
    }
    h.tau0 = P.m32.phi(h, x0);
    return h;
  },
  /* 中心（x=0、+x 向き）から x までにかかる時間 */
  phi: function (h, x) {
    if (x <= 0) return 0;
    if (h.inside || x <= h.R) return Math.asin(clamp(x / h.A, -1, 1)) / h.w;
    return h.tauR + (P.m32.tOut(h.E, x) - h.tR);
  },
  /* その逆（時間 τ → 位置 x、+x 側の外向きの旅） */
  xOf: function (h, tau) {
    if (tau <= 0) return 0;
    if (h.inside || tau <= h.tauR) return h.A * Math.sin(h.w * Math.min(tau, Math.PI / (2 * h.w)));
    return P.m32.rOut(h.E, h.tR + (tau - h.tauR));
  },
  /* 時刻 t での位置 x と速度 v（＝dx/dt） */
  at: function (h, t) {
    var tau = h.tau0 + t, x, sgn;
    if (!h.bound) {
      x = P.m32.xOf(h, tau);
      sgn = 1;
    } else {
      var T = h.T, q = T / 4;
      var tt = ((tau % T) + T) % T;
      if (tt < q) { x = P.m32.xOf(h, tt); sgn = 1; }
      else if (tt < 2 * q) { x = P.m32.xOf(h, 2 * q - tt); sgn = -1; }
      else if (tt < 3 * q) { x = -P.m32.xOf(h, tt - 2 * q); sgn = -1; }
      else { x = -P.m32.xOf(h, 4 * q - tt); sgn = 1; }
    }
    var v = sgn * Math.sqrt(Math.max(0, 2 * (h.E - P.m32.U(x))));
    return { x: x, v: v, zone: (Math.abs(x) <= h.R ? 'in' : 'out') };
  }
};

/* ===== 3-3 地球と月（関西学院大）=====
   [A] 地球は動かないとみなし、月だけが半径 r0 の等速円運動をする。
   [B] 地球も月も、共通重心のまわりを同じ角速度で等速円運動する。
   質量比 μ = m/M が小さいほど [A] と [B] の違いは小さい（実際は μ = 0.0123）。 */
P.m33 = {
  GM: 398600.4418,          /* GM（地球）[km³/s²] */
  R: 6371,                  /* 地球の半径 [km] */
  RMOON: 1737,              /* 月の半径 [km] */
  MU0: 0.0123,              /* 本当の質量比 m/M */
  R0: 384400,               /* 本当の地球〜月の距離 [km] */
  make: function (r0, mu) {
    var GM = P.m33.GM;
    var wA = Math.sqrt(GM / (r0 * r0 * r0));           /* [A] 地球固定 */
    var wB = Math.sqrt(GM * (1 + mu) / (r0 * r0 * r0));/* [B] 共通重心 */
    var r1 = r0 * mu / (1 + mu);                       /* 共通重心から地球まで */
    var r2 = r0 / (1 + mu);                            /* 共通重心から月まで */
    return {
      r0: r0, mu: mu, GM: GM,
      wA: wA, TA: TAU / wA, vA: Math.sqrt(GM / r0),
      wB: wB, TB: TAU / wB, r1: r1, r2: r2,
      v1: r1 * wB, v2: r2 * wB,
      /* 単位質量（月の質量 m あたり）の万有引力 F/m ［m/s²］ */
      Fm: GM / (r0 * r0) * 1000,
      /* 月の力学的エネルギー／m（[A] の場合） */
      EmA: -GM / (2 * r0),
      vEsc: Math.SQRT2 * Math.sqrt(GM / r0)
    };
  },
  /* [A]：地球は原点で静止、月だけが回る */
  atA: function (h, t) {
    var th = h.wA * t;
    return {
      e: { x: 0, y: 0, vx: 0, vy: 0 },
      m: { x: h.r0 * Math.cos(th), y: h.r0 * Math.sin(th),
        vx: -h.vA * Math.sin(th), vy: h.vA * Math.cos(th) },
      w: h.wA, th: th
    };
  },
  /* [B]：共通重心を原点にして、地球と月が向かいあって回る */
  atB: function (h, t) {
    var th = h.wB * t;
    return {
      e: { x: -h.r1 * Math.cos(th), y: -h.r1 * Math.sin(th),
        vx: h.v1 * Math.sin(th), vy: -h.v1 * Math.cos(th) },
      m: { x: h.r2 * Math.cos(th), y: h.r2 * Math.sin(th),
        vx: -h.v2 * Math.sin(th), vy: h.v2 * Math.cos(th) },
      w: h.wB, th: th
    };
  }
};

/* ===== 4-2 角運動量（フィギュアスケーター）=====
   腕を縮めると速く回る。L = m r² ω が一定だから ω = L/(m r²)。
   ケプラーの第2法則（面積速度一定）とまったく同じ話。 */
P.m42 = {
  /* 腕の長さ r［m］と、はじめの状態（r0, ω0）から ω と回転角を出す。
     r をゆっくり変える「準静的な」変化と考える（腕を縮める仕事は考えない）。 */
  omega: function (r, r0, w0) { return w0 * (r0 * r0) / (r * r); },
  KE: function (m, r, w) { return 0.5 * m * r * r * w * w; }
};

/* ============================================================
   4-3　高校物理の先の現代天文学
   ------------------------------------------------------------
   ★方針★ ここでも数値積分はしない。
     ① ブラックホール：脱出速度 v = √(2GM/r) が光速 c になる半径（シュワルツシルト半径）
     ② ダークマター  ：円運動 v = √(GM(<r)/r)。M(<r) を閉じた式で置く
     ③ 宇宙の運命    ：ハッブルの法則で広がる球のふちの運動。
        E/m = ½v² − GM/r は「まっすぐ投げ上げたボール」とまったく同じ形なので、
        2-1・3-1 と同じサイクロイドの式で解ける。
   ============================================================ */
P.m44 = {
  c: 299792.458,               /* 光の速さ［km/s］ */
  GMsun: 1.32712440018e11,     /* 太陽の GM［km³/s²］ */
  Rsun: 695700,                /* 太陽の半径［km］ */
  KPC: 3.0856775814e16,        /* 1 kpc［km］ */
  H0: 70,                      /* ハッブル定数［km/s/Mpc］ */
  /* ハッブル時間 1/H0［億年］。H0 = 70 km/s/Mpc → 139.7 億年 */
  tH: function () {
    var Hs = P.m44.H0 / (1000 * P.m44.KPC);      /* [1/s] */
    return 1 / Hs / (3.15576e7 * 1e8);           /* 億年 */
  },

  /* ===== ① ブラックホール ===== */
  /* 脱出速度［km/s］。質量は太陽質量の Msun 倍、r は km */
  vEsc: function (Msun, r) {
    return Math.sqrt(2 * P.m44.GMsun * Msun / Math.max(1e-12, r));
  },
  /* シュワルツシルト半径［km］＝ 脱出速度が c になる半径 rs = 2GM/c² */
  rs: function (Msun) {
    return 2 * P.m44.GMsun * Msun / (P.m44.c * P.m44.c);
  },
  /* 中性子星くらいの半径［km］のめやす（絵の中の「星の大きさ」に使う） */
  rStar: function (Msun) { return 12 * Math.pow(Msun / 1.4, -1 / 3); },

  /* ===== ② 銀河の回転曲線 =====
     r は kpc、質量は 10¹⁰ 太陽質量、速さは km/s。
       見える星：半径 rb の中に一様に Mv → M(<r) = Mv·min(1,(r/rb)³)
       ダークマター：ρ ∝ 1/r² のハロー → M(<r) = kdm·r（v が一定に近づく形）
     v(r) = √(G M(<r)/r) */
  MV: 8.0,        /* 見える星の質量［10¹⁰ 太陽質量］ */
  RB: 4.0,        /* 見える星がほとんど入っている半径［kpc］ */
  /* 10¹⁰ 太陽質量・kpc の単位での「G」。v² = GG·M/r となるようにしておく */
  GG: function () {
    return P.m44.GMsun * 1e10 / P.m44.KPC;       /* km²/s² */
  },
  Mvis: function (r) {
    var f = Math.min(1, Math.pow(r / P.m44.RB, 3));
    return P.m44.MV * f;
  },
  Mdm: function (r, kdm) { return kdm * r; },
  vRot: function (r, kdm) {
    r = Math.max(0.05, r);
    return Math.sqrt(P.m44.GG() * (P.m44.Mvis(r) + P.m44.Mdm(r, kdm)) / r);
  },
  /* 1周する時間［億年］。r［kpc］／v［km/s］ */
  Trot: function (r, kdm) {
    var v = P.m44.vRot(r, kdm);
    return (TAU * r * P.m44.KPC / v) / (3.15576e7 * 1e8);
  },

  /* ===== ③ 宇宙の運命 =====
     物質だけの宇宙。a は「いまの大きさを 1 とした宇宙の大きさ」、
     時間 τ は「ハッブル時間 1/H0 を 1 とした時間」。
       Ω > 1（E < 0）… a = A(1 − cos η),  τ = A(η − sin η)/√(Ω−1) … いつか縮む
       Ω = 1（E = 0）… a = (3τ/2)^(2/3)                              … ぎりぎり広がりつづける
       Ω < 1（E > 0）… a = B(cosh η − 1), τ = B(sinh η − η)/√(1−Ω) … 永遠に広がる
     （A = Ω/(2(Ω−1))、B = Ω/(2(1−Ω))）
     これは「まっすぐ投げ上げたボール」とまったく同じ式。 */
  /* η − sin η = M を二分法で解く（0 ≤ η ≤ 2π で単調） */
  cycOf: function (M) {
    if (M <= 0) return 0;
    if (M >= TAU) return TAU;
    var lo = 0, hi = TAU, i, mid;
    for (i = 0; i < 90; i++) {
      mid = (lo + hi) / 2;
      if (mid - Math.sin(mid) < M) lo = mid; else hi = mid;
    }
    return (lo + hi) / 2;
  },
  /* 時刻 τ（1/H0 が単位）での宇宙の大きさ a */
  aOf: function (Om, tau) {
    if (tau <= 0) return 0;
    if (Math.abs(Om - 1) < 1e-6) return Math.pow(1.5 * tau, 2 / 3);
    if (Om > 1) {
      var A = Om / (2 * (Om - 1)), s = Math.sqrt(Om - 1);
      var eta = P.m44.cycOf(clamp(tau * s / A, 0, TAU));
      return A * (1 - Math.cos(eta));
    }
    var B = Om / (2 * (1 - Om)), s2 = Math.sqrt(1 - Om);
    var H = P.m32.sinhOf(tau * s2 / B);
    return B * (Math.cosh(H) - 1);
  },
  /* いまの宇宙（a = 1）の年齢 τ0（1/H0 が単位） */
  tau0: function (Om) {
    if (Math.abs(Om - 1) < 1e-6) return 2 / 3;
    if (Om > 1) {
      var A = Om / (2 * (Om - 1));
      var eta = Math.acos(clamp(1 - 1 / A, -1, 1));
      return A * (eta - Math.sin(eta)) / Math.sqrt(Om - 1);
    }
    var B = Om / (2 * (1 - Om));
    var H = Math.acosh(Math.max(1, 1 + 1 / B));
    return B * (Math.sinh(H) - H) / Math.sqrt(1 - Om);
  },
  /* 閉じた宇宙（Ω>1）が つぶれるまでの時間 τ（1/H0 が単位） */
  tauEnd: function (Om) {
    if (Om <= 1 + 1e-9) return Infinity;
    var A = Om / (2 * (Om - 1));
    return TAU * A / Math.sqrt(Om - 1);
  },
  /* いちばん大きくなったときの a（Ω>1 のとき） */
  aMax: function (Om) {
    if (Om <= 1 + 1e-9) return Infinity;
    return Om / (Om - 1);
  },

  /* ===== まっすぐ外向きの運動（GM をひきすうに取れる版）=====
     P.m32 のものは GM が地球に固定されているので、ここで作り直す。
     E<0：r = a(1−cosη)、t = √(a³/GM)(η−sinη)（η は 0〜2π で 行き＋帰り）
     E=0：r = (1.5√(2GM) t)^(2/3)
     E>0：r = a(coshH−1)、t = √(a³/GM)(sinhH−H) */
  radT: function (GM, E, r) {
    if (Math.abs(E) < 1e-12 * GM) return (2 / 3) * Math.pow(r, 1.5) / Math.sqrt(2 * GM);
    var a = Math.abs(GM / (2 * E)), n = Math.sqrt(GM / (a * a * a));
    if (E < 0) {
      var eta = Math.acos(clamp(1 - r / a, -1, 1));
      return (eta - Math.sin(eta)) / n;
    }
    var H = Math.acosh(Math.max(1, 1 + r / a));
    return (Math.sinh(H) - H) / n;
  },
  radR: function (GM, E, t) {
    if (t <= 0) return 0;
    if (Math.abs(E) < 1e-12 * GM) return Math.pow(1.5 * Math.sqrt(2 * GM) * t, 2 / 3);
    var a = Math.abs(GM / (2 * E)), n = Math.sqrt(GM / (a * a * a)), M = n * t;
    if (E < 0) return a * (1 - Math.cos(P.m44.cycOf(clamp(M, 0, TAU))));
    return a * (Math.cosh(P.m32.sinhOf(M)) - 1);
  }
};

/* ============================================================
   4-2　地球と人工衛星の太陽まわりの運動（id は m4-5）
   ------------------------------------------------------------
   ★入れ子になった3つの回転★
     ① 地球が太陽のまわりを回る（公転・1年）
     ② 月や人工衛星が地球のまわりを回る（月は 27.3 日、ISS は 92 分）
     ③ 地球そのものが回る（自転・23時間56分）
   どれも円運動とみなして、閉じた式（v = √(GM/a)、T = 2π√(a³/GM)）で出す。
   ============================================================ */
P.m45 = {
  GMS: 1.32712440018e11,   /* 太陽の GM［km³/s²］ */
  GME: 398600.4418,        /* 地球の GM［km³/s²］ */
  AU: 1.495978707e8,       /* 1 AU［km］ */
  RE: 6371,                /* 地球の半径［km］ */
  TROT: 86164.0905,        /* 自転の周期（恒星日）［s］ */
  TYEAR: 3.15581497632e7,  /* 公転の周期（恒星年）［s］ */
  TILT: 23.44,             /* 地軸のかたむき［°］ */
  /* 円軌道の速さ・周期 */
  vC: function (GM, a) { return Math.sqrt(GM / a); },
  T: function (GM, a) { return TAU * Math.sqrt(a * a * a / GM); },
  /* ★太陽日［s］★ 1回転して太陽が同じ方角に戻るまで。
     恒星日（自転の周期 TROT）より 236 秒ぶん長い——そのあいだに公転でも少し進むため。
       1/86164.0905 − 1/31558149.76 = 1/86400.0
     「毎日同じ時間に観測」は、この 86400 秒ちょうどの刻みで時間を飛ばす。
     こうすると観測者と太陽の向きの関係はぴたりと同じまま、月だけが 1日 13.2° 動く。 */
  DAY: 86400,
  /* 見る時間の長さ［s］。1＝1日（自転1回）／2＝1か月（月が1周）／3＝1年（地球が1周）
     4＝1か月を「毎日同じ時間に観測」（86400 秒ずつ飛ばす・28日ぶん） */
  SPAN: [0, 86164.0905, 2360591.0, 3.15581497632e7, 28 * 86400],
  spanName: function (k) {
    return ['', '1日（自転が1回）', '1か月（月が1周）', '1年（地球が1周）',
      '毎日同じ時間に観測'][k];
  },
  /* ★時間を「1日きざみ」に丸める★（span = 4 のときだけ）
     draw・sample・tFmt・info の入り口で必ずこれを通すこと。
     どれか1つでも忘れると、絵と時計と読み出しがずれる。 */
  snap: function (v, t) {
    if (!v || v.span !== 4) return t;
    return Math.floor(t / P.m45.DAY + 1e-9) * P.m45.DAY;
  },
  /* 地球の公転の角［rad］。t = 0 では +x の向きに置く */
  thEarth: function (t) { return TAU * t / P.m45.TYEAR; },
  /* 自転の角［rad］ */
  thSpin: function (t) { return TAU * t / P.m45.TROT; },
  /* 衛星（SATS の1つ）の角［rad］ */
  thSat: function (sat, t) { return sat.L0 * DEG + TAU * t / sat.T; }
};
