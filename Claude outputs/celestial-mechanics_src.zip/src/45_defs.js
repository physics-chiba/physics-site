/* シミュレーションの登録表。各モードのファイルが DEFS に自分を足していく。
   新しいシミュレーションを足すときは、DEFS に1ブロック書くだけで済むようにしておくこと。 */
'use strict';
var DEFS = {};
var MODES = [
  {
    n: 1, label: '1　ケプラーの法則',
    tip: '惑星の動きの法則',
    ids: ['m1-1', 'm1-2', 'm1-3', 'm1-4', 'm1-5', 'm1-6']
  },
  {
    n: 2, label: '2　万有引力とエネルギー',
    tip: '軌道の形を説明するのは万有引力・万有引力による位置エネルギー',
    ids: ['m2-2', 'm2-3', 'm2-4', 'm4-2', 'm2-1', 'm4-5']
  },
  {
    n: 3, label: '3　入試物理',
    tip: '力学的エネルギー保存とケプラーⅡ（面積速度一定）で、大抵の問題は解けます。',
    ids: ['m3-1', 'm3-2', 'm3-3']
  },
  {
    n: 4, label: '4　もっと深く知りたい人へ',
    tip: '読み物とアニメーション',
    ids: ['m4-3', 'm2-5', 'm4-4']
  }
];

var EQM = '\\text{運動方程式}\\;\\; ';

/* ===== ケプラーの3法則の文（★表記ゆれ防止★）=====
   法則の文をページのあちこちに直接書くと、少しずつ違う言い方になってしまう。
   ページの中で法則の文を出すところは、かならずこの LAW を使うこと。
     LAW.k1 / k2 / k3 … 法則の本体
     LAW.k1n / k2n / k3n … 「※どんなときに成り立つか」までつけた完全な文
   ※以降は「場所がせまいときだけ」省いてよい（そのときは LAW.k2 のほうを使う）。 */
var LAW = {
  k1: '惑星は太陽を1つの焦点とする楕円を描く',
  k2: '惑星と太陽を結ぶ線分が単位時間あたりに通過する面積は一定である（面積速度一定の法則）',
  k3: '周期の2乗は半長軸の3乗に比例する',
  n1: '',
  n2: '※同一軌道中で成り立つ',
  n3: '※同じ天体の周りをまわるもの同士で成り立つ'
};
LAW.k1n = LAW.k1;
LAW.k2n = LAW.k2 + '　' + LAW.n2;
LAW.k3n = LAW.k3 + '　' + LAW.n3;

/* ★「地球と人工衛星」を選んでいるときの言いかえ★（先生の指示）
   ケプラーの法則は「太陽と惑星」だけのものではなく、
   「大きな質量の天体のまわりを回るもの」すべてに成り立つ——それを体で分からせるため、
   描画対象を切りかえたら、図の上の帯（drawLawBanner）とタイトルの文も書きかえる。
   ★書きかえてよいのは、この LAW.sat だけ★ 各シムに直接書かないこと（表記ゆれのもと）。
   右の列（note / sideText）の文は、法則の一般形のまま変えない。 */
LAW.sat = {
  k1: '人工衛星は地球を1つの焦点とする楕円を描く',
  k2: '人工衛星と地球を結ぶ線分が単位時間あたりに通過する面積は一定である（面積速度一定の法則）',
  k3: '周期の2乗は半長軸の3乗に比例する'
};
LAW.sat.k1n = LAW.sat.k1;
LAW.sat.k2n = LAW.sat.k2 + '　' + LAW.n2;
LAW.sat.k3n = LAW.sat.k3 + '　' + LAW.n3;

/* いま選ばれている描画対象に合わせた法則の文を返す。
   key は 'k1' / 'k2' / 'k3' / 'k1n' / 'k2n' / 'k3n'。 */
function lawTxt(key) {
  if (typeof st !== 'undefined' && st.sysKind === 'earth' && LAW.sat[key]) return LAW.sat[key];
  return LAW[key];
}

/* 「$…$」を KaTeX で組む span に変える（添え字をきれいに出すため） */
/* ===== 参考文献（モード4「もっと深く知りたい人へ」の各シムの最後に置く）=====
   ★URL は「リンク」だけでなく「文字」としても出す★
   このページは1つの HTML でオフラインでも動く教材なので、
   印刷したりネットにつながっていない場所で読んだりしても、出典をたどれるようにする。
   list は [{ t: 題名, u: URL, n: ひとこと説明 }] の配列。 */
function refsHtml(list) {
  var h = '<hr class="colhr"><div class="colh">■ 参考文献・もっと知りたい人へ</div>'
    + '<ul class="reflist">';
  list.forEach(function (r) {
    h += '<li><a href="' + r.u + '" target="_blank" rel="noopener">' + r.t + '</a>'
      + (r.n ? '<br><span class="refnote">' + r.n + '</span>' : '')
      + '<br><span class="refurl">' + r.u + '</span></li>';
  });
  return h + '</ul>'
    + '<span class="refnote">※ リンク先はインターネットにつながっているときだけ開けます。'
    + '（最終確認：2026年8月）</span>';
}

function mathHtml(str) {
  var out = '', i = 0;
  str = String(str);
  while (i < str.length) {
    var a = str.indexOf('$', i);
    if (a === -1) { out += str.slice(i); break; }
    out += str.slice(i, a);
    var b = str.indexOf('$', a + 1);
    if (b === -1) { out += str.slice(a); break; }
    /* ★数式の中の < > は、かならず &lt; &gt; に直してから innerHTML に入れる★
       そうしないと「$-R<x<R$」の < 以降がタグと見なされて、文が消える
       （3-2 の問題文で実際に消えた）。KaTeX は textContent を読むので、
       ブラウザが &lt; を < にもどしてくれて、正しく数式になる。 */
    out += '<span class="tex">' +
      str.slice(a + 1, b).replace(/</g, '&lt;').replace(/>/g, '&gt;') + '</span>';
    i = b + 1;
  }
  return out;
}

/* KaTeX に渡す式を innerHTML に入れる前のエスケープ。
   ★数式の中の < > は、かならず &lt; &gt; にしてから入れる★
   そうしないとブラウザがタグの始まりだと思って、そこから先を食べてしまう
   （4-3 の「M(<r)」で実際に起きた：「代入」の行が "M(" だけになった）。 */
function escTex(x) {
  return String(x).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

/* ===== ★毎フレーム走るところで DOM に書くときは、必ずこの2つを通す★ =====
   同じ文字・同じクラスを入れ直すだけでも、ブラウザはその要素の
   スタイル計算 → レイアウト → 描き直し をやり直す。
   1-4 では「中身が1文字も変わっていないのに 1 フレームで 16 か所」書き直していて、
   実機（学校のパソコン）でカクつく原因になっていた（先生の指摘）。
   ★ヘッドレスのテストでは描き直しが起きないので、この無駄は測っても出てこない★ */
function setText(el, txt) {
  if (!el) return;
  txt = String(txt);
  if (el._txt === txt) return;          /* textContent を読み返すより速い */
  el._txt = txt;
  el.textContent = txt;
}
function setCls(el, cls) {
  if (!el) return;
  cls = String(cls);
  if (el.className === cls) return;
  el.className = cls;
}

/* 図の中の「ヒントになる言葉」（答えにつながる説明）を出してよいか。
   スタートを押して動き出してから出す。
   ヒントでないもの（軸名・時刻・距離や力の値・天体の名前・操作の説明）はいつでも出してよい。 */
function hintOn(s, t) { return t > 1e-9; }

/* 「▶スタートを押してから sec 秒たったか」。
   ★シムの時間 t ではなく〈実時間〉で計る★
     シムごとに rate（実時間1秒で進むシムの時間）が違うので、
     t で計ると「2秒後」がシムごとにばらばらになってしまう。
   実時間は tick が s._run にためている（止めると 0 に戻る＝押し直せばまた 2 秒後）。 */
function runOver(s, sec) { return !!s && (s._run || 0) >= sec; }

/* ===== 計算結果の帯（図のすぐ下）=====
   d.result(v, s, t) が返すもの：
     { items:[{k,v,kbox}], table:{head:[…], rows:[[…]], kcol:n}, note:'…' }
   半長軸 a・周期 T・K = T²/a³ は必ず並べる。 */
function resItem(k, v, kbox) { return { k: k, v: v, kbox: !!kbox }; }

/* 1つの軌道について「a・T・K」の3つを作る（どのシムでも同じ書き方にそろえる） */
function resAT(o, sys, dec) {
  var Kv = o.T * o.T / (o.a * o.a * o.a);
  return [
    resItem('半長軸 $a$', fmtAuto(o.a, dec === undefined ? 3 : dec) + ' ' + sys.uL),
    resItem('周期 $T$', fmtAuto(o.T, dec === undefined ? 3 : dec) + ' ' + sys.uT),
    resItem('$K = T^2/a^3$', fmtAuto(Kv, 4) + (sys.key === 'sun' ? ' 年²/AU³' : ' s²/km³'), true)
  ];
}

/* 複数の天体を見比べる表（K の列がそろうことを見せる） */
function kTable(rows, sys) {
  return {
    head: ['天体', '半長軸 a [' + sys.uL + ']', '周期 T [' + sys.uT + ']', 'K = T²/a³'],
    rows: rows, kcol: 3
  };
}

/* ===== 図の共通部品 ===== */

/* 読み物（#longbox）の中に入れる絵。
   assets/ に置いたファイルが build のときに IMG.○○ に入る。
   まだ画像を用意していないときは、何も出さない（画像なしでも文章は読める）。 */
function colImg(key, alt, cap) {
  if (!IMG || !IMG[key]) return '';
  return '<figure class="colfig"><img class="colimg" src="' + IMG[key] + '" alt="' + alt + '">' +
    (cap ? '<figcaption>' + cap + '</figcaption>' : '') + '</figure>';
}

/* 図の右上に時刻を出す（全シミュレーションで位置をそろえる）。
   法則の帯（drawLawBanner）を出す図では、帯の下になるように y を指定する。
   背景が暗い図（星空）では opt に {color:'#e8eef4', haloColor:HALO} をわたす。 */
function drawClock(ctx, W, txt, y, opt) {
  var o = { align: 'right', size: 13.5, bold: true };
  if (opt) { if (opt.color) o.color = opt.color; if (opt.haloColor) o.haloColor = opt.haloColor; }
  label(ctx, txt, W - 10, (y === undefined ? 18 : y), o);
}

/* ===== 法則の帯 =====
   図のいちばん上に「その法則の中身」を大きく書く。ケプラーの第1〜第3法則の
   シミュレーションで使う（生徒が図を見ながら法則の文を読めるようにするため）。
   帯の高さは LAW_BAND px。この帯を出す図では orbScene の pad.t を
   LAW_BAND + 12 以上にして、絵が帯にかからないようにすること。 */
var LAW_BAND = 34;
function drawLawBanner(ctx, W, tag, txt) {
  ctx.save();
  ctx.fillStyle = '#eef3f8';
  ctx.fillRect(0, 0, W, LAW_BAND);
  ctx.strokeStyle = '#c9d4e0'; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(0, LAW_BAND + 0.5); ctx.lineTo(W, LAW_BAND + 0.5); ctx.stroke();
  /* 文字が帯からはみ出さないように、幅を見ながら大きさを決める。
     ※つきの長い法則文は1行に入りきらないので、「　」（※の前）や「（」で2行に折る。 */
  var pad = tag ? 62 : 12, avail = W - pad * 2;
  var size = 17, lines = [String(txt)];
  ctx.font = 'bold ' + size + 'px ' + FONT;
  while (size > 12 && ctx.measureText(lines[0]).width > avail) {
    size -= 0.5;
    ctx.font = 'bold ' + size + 'px ' + FONT;
  }
  if (ctx.measureText(lines[0]).width > avail) {
    var s0 = lines[0], cut = s0.indexOf('　');
    if (cut <= 0) cut = s0.indexOf('（');
    if (cut > 0) lines = [s0.slice(0, cut), s0.slice(cut).replace(/^　/, '')];
    size = 13;
    ctx.font = 'bold ' + size + 'px ' + FONT;
    while (size > 9 && Math.max(ctx.measureText(lines[0]).width,
      ctx.measureText(lines[1] || '').width) > avail) {
      size -= 0.5;
      ctx.font = 'bold ' + size + 'px ' + FONT;
    }
  }
  ctx.restore();
  if (tag) label(ctx, tag, 10, LAW_BAND / 2, { align: 'left', size: 11.5, bold: true, color: COL.sub });
  if (lines.length < 2) {
    label(ctx, lines[0], W / 2, LAW_BAND / 2, { size: size, bold: true, color: COL.ink });
  } else {
    label(ctx, lines[0], W / 2, LAW_BAND / 2 - 8, { size: size, bold: true, color: COL.ink });
    label(ctx, lines[1], W / 2, LAW_BAND / 2 + 8, { size: size - 1, bold: true, color: COL.sub });
  }
}

/* 「→」のついた主役ボタン用：変数を1段ふやす。
   ★上限まで行ったら下限に戻す★。上限で止まると、生徒には
   「ボタンが効かなくなった（こわれた）」と見えてしまうため。 */
function stepUp(d, s, k, step, noWrap) {
  var vd = null, i, list = d.vars || [];
  for (i = 0; i < list.length; i++) if (list[i].k === k) vd = list[i];
  if (!vd) return;
  var nx = s.v[k] + step;
  if (nx > vd.max + 1e-9) nx = noWrap ? vd.max : vd.min;
  s.v[k] = +nx.toFixed(vd.dec === undefined ? 3 : vd.dec);
}

/* stepUp の逆まわり（「◯◯を小さくする →」のボタン）。
   ★きざみで下限を通りこすときは、いったん下限にぴたりと止める★
   （3-3 なら ×5 のつぎが ×1 ＝ 本当の月。ここを飛ばすと、いちばん見せたい値に止まれない）。
   すでに下限にいるときだけ上限に戻す——止まったままだと「こわれた」と見えるため
   （→ ハマったところ 16）。
   ★ただし、一周して上限に戻るのは「勝手に重くなった」と見えることがある★（先生の指示）
     3-3 の「月を軽くする →」がそれで、×1 のつぎに ×80 へ跳んでいた。
     そういうボタンは noWrap（第5引数 true）で下限に止め、
     あわせて topActions に dis:function(v){…} を書いて〈押せない見た目〉にすること。
     止まるだけだと「こわれた」に見えるが、うすくなっていれば「もう終わり」と分かる。 */
function stepDown(d, s, k, step, noWrap) {
  var vd = null, i, list = d.vars || [];
  for (i = 0; i < list.length; i++) if (list[i].k === k) vd = list[i];
  if (!vd) return;
  var nx = s.v[k] - step;
  if (nx < vd.min - 1e-9) {
    nx = (s.v[k] <= vd.min + 1e-9) ? (noWrap ? vd.min : vd.max) : vd.min;
  }
  s.v[k] = +nx.toFixed(vd.dec === undefined ? 3 : vd.dec);
}

/* ===== 3つの法則を並べた帯 =====
   「まとめ」のシミュレーションのように、1本の図で第1〜第3法則を全部確かめるときは、
   1つの法則ではなく3つを左そろえで並べる。帯の高さは LAW_LIST px。
   この帯を出す図では pad.t を LAW_LIST + 10 以上にすること。 */
var LAW_LIST = 58;
function drawLawList(ctx, W, lines) {
  ctx.save();
  ctx.fillStyle = '#eef3f8';
  ctx.fillRect(0, 0, W, LAW_LIST);
  ctx.strokeStyle = '#c9d4e0'; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(0, LAW_LIST + 0.5); ctx.lineTo(W, LAW_LIST + 0.5); ctx.stroke();
  ctx.restore();
  lines.forEach(function (ln, i) {
    var y = 13 + i * 16;
    label(ctx, ln[0], 10, y, { align: 'left', size: 10.5, bold: true, color: COL.sub });
    /* 法則の文は長いので、帯の右端からはみ出さない大きさまで小さくする */
    var size = 12;
    ctx.save();
    ctx.font = 'bold ' + size + 'px ' + FONT;
    while (size > 8.5 && ctx.measureText(String(ln[1])).width > W - 68) {
      size -= 0.5;
      ctx.font = 'bold ' + size + 'px ' + FONT;
    }
    ctx.restore();
    label(ctx, ln[1], 60, y, { align: 'left', size: size, bold: true, color: COL.ink });
  });
}

/* 万有引力の矢印（かならず赤・作用点に「・」）。
   from＝力を受ける天体の中心、to＝相手の天体の中心、L＝矢印の長さ[px] */
function gravArrow(ctx, fx, fy, tx, ty, L, lab, labSide) {
  var dx = tx - fx, dy = ty - fy, d = Math.hypot(dx, dy);
  if (d < 1e-6 || L < 2) return null;
  var ux = dx / d, uy = dy / d;
  var ex = fx + ux * L, ey = fy + uy * L;
  arrow(ctx, fx, fy, ex, ey, 'force');
  if (lab) {
    var sgn = (labSide === undefined) ? 1 : labSide;
    label(ctx, lab, ex - uy * 15 * sgn + ux * 6, ey + ux * 15 * sgn + uy * 6,
      { size: 12, color: COL.force });
  }
  return { x: ex, y: ey, ux: ux, uy: uy };
}

/* 速度の矢印（青の白抜き）。同じ図の中では縮尺をそろえること */
function velArrow(ctx, x, y, vx, vy, sc, lab, dxl, dyl) {
  var L = Math.hypot(vx, vy) * sc;
  if (L < 2) return;
  var ex = x + vx * sc, ey = y - vy * sc;
  arrow(ctx, x, y, ex, ey, 'vel');
  if (lab) label(ctx, lab, ex + (dxl === undefined ? 10 : dxl), ey + (dyl === undefined ? -10 : dyl),
    { size: 12, color: COL.vel });
}

/* 観測者の棒人間。(x,y)＝足もと、(ux,uy)＝画面での「上」の向き（単位ベクトル）。
   s＝背の高さの目安。姉妹ページ・円運動のページと同じ描き方にそろえている。
   天体のページでは「地球の上に立っている人」を描くのに使う（2-4 の自転）。 */
function stickman(ctx, x, y, ux, uy, s, color, lw) {
  var px = -uy, py = ux;
  function P(du, dp) { return [x + ux * du * s + px * dp * s, y + uy * du * s + py * dp * s]; }
  ctx.save();
  ctx.strokeStyle = color || COL.sub; ctx.lineWidth = lw || 2; ctx.lineCap = 'round';
  var hip = P(0.38, 0), sh = P(0.64, 0), hd = P(0.80, 0);
  ctx.beginPath(); ctx.arc(hd[0], hd[1], s * 0.13, 0, Math.PI * 2); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(hip[0], hip[1]); ctx.lineTo(sh[0], sh[1]); ctx.stroke();
  var f1 = P(0, -0.17), f2 = P(0, 0.17);
  ctx.beginPath(); ctx.moveTo(f1[0], f1[1]); ctx.lineTo(hip[0], hip[1]); ctx.lineTo(f2[0], f2[1]); ctx.stroke();
  var a1 = P(0.48, -0.22), a2 = P(0.48, 0.22);
  ctx.beginPath(); ctx.moveTo(a1[0], a1[1]); ctx.lineTo(sh[0], sh[1]); ctx.lineTo(a2[0], a2[1]); ctx.stroke();
  ctx.restore();
}

/* 地面（横一直線＋ハッチ）。いまは使っていない（位置エネルギーの導出のシムを外したため）が、
   地表付近を描くときのために残しておく */
function ground(ctx, x1, x2, y) { hatchLine(ctx, x1, y, x2, y, 1); }

/* 線分のわきに文字を置く（線に垂直な向きに d px ずらす。重なりを防ぐため） */
function lineLabel(ctx, txt, x1, y1, x2, y2, d, col, size) {
  var dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy) || 1;
  var nx = -dy / L, ny = dx / L;
  label(ctx, txt, (x1 + x2) / 2 + nx * d, (y1 + y2) / 2 + ny * d,
    { size: size || 12, color: col, bold: true });
}

/* 距離 r の破線（太陽→惑星）と、その値のラベル */
function radiusLine(ctx, cx, cy, px, py, txt, col) {
  dashLine(ctx, cx, cy, px, py, col || COL.dim, [5, 4], 1.2);
  if (txt) {
    var mx = (cx + px) / 2, my = (cy + py) / 2;
    label(ctx, txt, mx, my - 9, { size: 11.5, color: col || COL.dim });
  }
}
