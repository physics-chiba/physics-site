/* 共通の描画部品。canvas の中は 1 書体（FONT）にそろえる。内部解像度は 2 倍。 */
'use strict';
var FONT = '"Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
var COL = {
  force: '#d1352b',   /* 重力・一般の力＝赤 */
  norm: '#7b3fd4',    /* 垂直抗力＝むらさき */
  fric: '#0f8a8a',    /* 摩擦力＝青緑 */
  hand: '#c2367f',    /* 手・ひもの力＝ピンク */
  vel: '#1663b5',     /* 速度＝青の白抜き */
  velx: '#1f7fd4',    /* 速度の水平成分＝明るい青の破線 */
  vely: '#0d8f7a',    /* 速度の鉛直成分＝緑がかった青の破線 */
  acc: '#e07b18',     /* 加速度＝オレンジ */
  comp: '#d1352b',    /* 分力＝赤の破線・白抜き */
  dim: '#1b1f24',     /* 寸法・変位＝黒の細い破線 */
  A: '#1663b5',
  B: '#c0392b',
  ink: '#1b1f24',
  sub: '#5b6672',
  grid: '#e2e6ea',
  axis: '#8b949e',

  /* ===== ここから「万有引力」のページで足した色 =====
     力（赤・むらさき・青緑・ピンク）と速度（青）と加速度（オレンジ）には
     絶対にぶつけない。空いている「黄・緑・金・茶・濃いグレー」から取っている。 */
  sun: '#f0b429',        /* 太陽（黄） */
  sunRim: '#c07f00',     /* 太陽のフチ */
  orbit: '#98a2ac',      /* 予定の軌道（うすいグレーの線） */
  bound: '#1c8f4a',      /* 束縛軌道（円・楕円）＝力学的エネルギーが負 */
  para: '#b58900',       /* 放物線＝力学的エネルギーが 0 */
  hyper: '#3f4a54',      /* 双曲線＝力学的エネルギーが正 */
  sect1: '#1c8f4a',      /* 面積速度の扇形（1つめ・緑） */
  sect2: '#b58900',      /* 面積速度の扇形（2つめ・金） */
  sect3: '#8a5a2b',      /* 面積速度の扇形（3つめ・茶） */
  /* 位置エネルギー U のグラフ（茶）。
     ★2-1 の U–r グラフを、円・楕円と同じ緑で描いていたので見分けがつかなかった★（先生の指摘）
     力・速度・加速度の色は使えず、黄・緑・金・濃いグレーはこのページですでに
     別の意味で使っているので、残っていた「茶」をあてた。
     扇形（sect3）と同じ色だが、扇形はモード1にしか出てこないので画面の中では混ざらない。 */
  upot: '#8a5a2b',
  cg: '#3f4a54',         /* 共通重心 */
  /* 角運動量 L のベクトル（濃いグレー）。
     力（赤・むらさき・青緑・ピンク）・速度（青）・加速度（オレンジ）にはぶつけない。
     双曲線・共通重心と同じ濃いグレーだが、L を描く 4-1 には
     双曲線も共通重心も出てこないので、画面の中で混ざることはない。 */
  angm: '#3f4a54',
  sky: '#22304a',        /* 星空の地（天球の図） */
  /* 天球の図（補足：地動説）で使う火星の色。
     もとの惑星の色（赤茶）は、となりを通る太陽の黄色と見分けがつきにくかったので、
     この図でだけ「明るいすみれ色」にしている。太陽の黄・地球の緑・力の赤・速度の青の
     どれとも見ま違えない色を選んだ。 */
  skyMars: '#c9a0ff'
};

/* 軌道の種類ごとの色（E の符号で変わる） */
function orbColor(kind) {
  return kind === 'para' ? COL.para : (kind === 'hyper' ? COL.hyper : COL.bound);
}
/* 軌道の種類ごとの線の形（色だけに頼らない） */
function orbDash(kind) {
  return kind === 'para' ? [8, 5] : (kind === 'hyper' ? [12, 4, 3, 4] : []);
}

/* いま描いている canvas の論理サイズ（ラベルのはみ出しを防ぐのに使う） */
var CVW = 0, CVH = 0;

/* canvas を 2 倍解像度で用意して ctx を返す（論理サイズ w×h で描ける） */
function prep(cv, w, h) {
  CVW = w; CVH = h;
  resetArrowOverlap();
  var need = cv.width !== w * 2 || cv.height !== h * 2;
  if (need) { cv.width = w * 2; cv.height = h * 2; cv.style.aspectRatio = w + ' / ' + h; }
  var ctx = cv.getContext('2d');
  ctx.setTransform(2, 0, 0, 2, 0, 0);
  ctx.clearRect(0, 0, w, h);
  ctx.lineJoin = 'round';
  ctx.lineCap = 'butt';
  return ctx;
}

/* 矢印。kind: force / vel / acc / comp / dim / thin */
/* 力の矢印が同じ作用点で重なったとき、少しだけずらして両方見えるようにする。
   キャンバスを描き直すたびに prep() がリセットする。 */
var _fArrows = [];
function resetArrowOverlap() { _fArrows.length = 0; }
function arrowShift(x1, y1, ux, uy, len, k) {
  var step = 5.5 * k, n = 0, i;
  for (i = 0; i < _fArrows.length; i++) {
    var a = _fArrows[i];
    if (a.cat !== 'F') continue;                                   /* ずらすのは力どうしだけ */
    if (Math.abs(a.ux * uy - a.uy * ux) > 0.25) continue;          /* 平行でなければ関係ない */
    var dPerp = Math.abs((a.x - x1) * uy - (a.y - y1) * ux);       /* 直線どうしのへだたり */
    if (dPerp > 6 * k) continue;
    var t0 = (a.x - x1) * ux + (a.y - y1) * uy;                    /* 相手の始点の射影 */
    var t1 = t0 + a.len * ((a.ux * ux + a.uy * uy >= 0) ? 1 : -1); /* 相手の終点の射影 */
    var lo = Math.min(t0, t1), hi = Math.max(t0, t1);
    if (hi > 1 && lo < len - 1) n++;                               /* 線が重なっている */
  }
  var rec = { x: x1, y: y1, ux: ux, uy: uy, len: len, cat: 'F', color: COL.force };
  _fArrows.push(rec);
  var out = { dx: 0, dy: 0, rec: rec };
  if (n) {
    var sgn = (n % 2) ? 1 : -1;                           /* 右・左・右…と交互にずらす */
    var mag = step * Math.ceil(n / 2);
    out.dx = -uy * mag * sgn; out.dy = ux * mag * sgn;
  }
  return out;
}

/* 同じ長さ（＝同じ大きさ）の力の矢印に、等長の印「｜」をつける。
   1組目は1本、2組目は2本…と本数を変える。d.draw のあとに1回だけ呼ぶ。 */
function drawEqualTicks(ctx) {
  ['F', 'V'].forEach(function (cat) {
    var i, j, groups = [];
    for (i = 0; i < _fArrows.length; i++) {
      var a = _fArrows[i];
      if (a.cat.charAt(0) !== cat) continue;              /* 力は力どうし、速度は速度どうし */
      if (a.len < 19) continue;                           /* 短すぎる矢印には付けない */
      var g = null;
      for (j = 0; j < groups.length; j++) {
        if (Math.abs(groups[j].len - a.len) <= 0.8) { g = groups[j]; break; }
      }
      if (!g) { g = { len: a.len, cat: a.cat, items: [] }; groups.push(g); }
      g.items.push(a);
    }
    var eq = [];
    for (i = 0; i < groups.length; i++) if (groups[i].items.length >= 2) eq.push(groups[i]);
    eq.sort(function (p, q) { return q.len - p.len; });    /* 長い組から 1本・2本・3本 */
    for (i = 0; i < eq.length; i++) {
      var n2 = Math.min(3, i + 1);
      for (j = 0; j < eq[i].items.length; j++) equalTick(ctx, eq[i].items[j], n2);
    }
  });
}
function equalTick(ctx, a, n) {
  /* 矢じりにかからないよう、少し手前（40%くらい）に印をつける */
  var pos = Math.max(6, Math.min(a.len * 0.42, a.len - 13));
  var mx = a.x + a.ux * pos, my = a.y + a.uy * pos;
  var px = -a.uy, py = a.ux, i, d, cx, cy;
  ctx.save();
  ctx.strokeStyle = a.color; ctx.lineWidth = 2.1; ctx.lineCap = 'round'; ctx.setLineDash([]);
  for (i = 0; i < n; i++) {
    d = (i - (n - 1) / 2) * 4.6;
    cx = mx + a.ux * d; cy = my + a.uy * d;
    ctx.beginPath();
    ctx.moveTo(cx - px * 5.6, cy - py * 5.6);
    ctx.lineTo(cx + px * 5.6, cy + py * 5.6);
    ctx.stroke();
  }
  ctx.restore();
}

function arrow(ctx, x1, y1, x2, y2, kind, scale, col) {
  var dx = x2 - x1, dy = y2 - y1;
  var len = Math.hypot(dx, dy);
  if (len < 1.5) return;
  var k = scale || 1;
  var ux = dx / len, uy = dy / len;
  if (kind === 'force' || kind === 'comp') {              /* 重なったらずらす */
    var sh = arrowShift(x1, y1, ux, uy, len, k);
    x1 += sh.dx; y1 += sh.dy; x2 += sh.dx; y2 += sh.dy;
    sh.rec.x = x1; sh.rec.y = y1;
    sh.rec.color = col || ((kind === 'comp') ? COL.comp : COL.force);
  } else if (kind === 'vel' || kind === 'velcomp' || kind === 'velx' || kind === 'vely') {
    /* 速度の矢印も「同じ長さ」の印をつけるために記録する（ずらしはしない） */
    _fArrows.push({
      x: x1, y: y1, ux: ux, uy: uy, len: len, cat: 'V',
      color: (kind === 'velx') ? COL.velx : ((kind === 'vely') ? COL.vely : COL.vel)
    });
  }
  var head = (kind === 'dim' ? 8 : (kind === 'vel' || kind === 'comp' || kind === 'velcomp' || kind === 'velx' || kind === 'vely' ? 10 : 12)) * k;
  if (head > len * 0.8) head = len * 0.8;
  var bx = x2 - ux * head, by = y2 - uy * head;

  ctx.save();
  ctx.lineJoin = 'round';
  var FC = col || COL.force;                 /* 力の色（種類ごとに変えられる） */
  if (kind === 'force') { ctx.strokeStyle = FC; ctx.fillStyle = FC; ctx.lineWidth = 3.4 * k; }
  else if (kind === 'acc') { ctx.strokeStyle = COL.acc; ctx.fillStyle = COL.acc; ctx.lineWidth = 3.0 * k; }
  else if (kind === 'vel') { ctx.strokeStyle = COL.vel; ctx.fillStyle = '#ffffff'; ctx.lineWidth = 2.2 * k; }
  else if (kind === 'velcomp') { ctx.strokeStyle = COL.vel; ctx.fillStyle = 'rgba(22,99,181,.35)'; ctx.lineWidth = 2.0 * k; ctx.setLineDash([6 * k, 4 * k]); }
  else if (kind === 'velx') { ctx.strokeStyle = COL.velx; ctx.fillStyle = COL.velx; ctx.lineWidth = 2.2 * k; ctx.setLineDash([7 * k, 4 * k]); }
  else if (kind === 'vely') { ctx.strokeStyle = COL.vely; ctx.fillStyle = COL.vely; ctx.lineWidth = 2.2 * k; ctx.setLineDash([7 * k, 4 * k]); }
  else if (kind === 'comp') { ctx.strokeStyle = FC; ctx.fillStyle = fade(FC, .38); ctx.lineWidth = 2.1 * k; ctx.setLineDash([6 * k, 4 * k]); }
  else { ctx.strokeStyle = COL.dim; ctx.fillStyle = COL.dim; ctx.lineWidth = 1.2 * k; ctx.setLineDash([5 * k, 4 * k]); }

  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(bx, by); ctx.stroke();
  ctx.setLineDash([]);
  if (kind === 'force' || kind === 'comp') {              /* 作用点を「・」ではっきり示す */
    ctx.beginPath();
    ctx.arc(x1, y1, 3.1 * k, 0, Math.PI * 2);
    ctx.fillStyle = FC; ctx.fill();
    if (kind === 'comp') { ctx.lineWidth = 1.2 * k; ctx.strokeStyle = '#fff'; ctx.stroke(); ctx.strokeStyle = FC; }
    ctx.fillStyle = (kind === 'comp') ? fade(FC, .38) : FC;
  }
  var wA = head * 0.5;
  ctx.beginPath();
  ctx.moveTo(x2, y2);
  ctx.lineTo(bx - uy * wA, by + ux * wA);
  ctx.lineTo(bx + uy * wA, by - ux * wA);
  ctx.closePath();
  ctx.fill();
  if (kind === 'vel' || kind === 'comp' || kind === 'velcomp') {
    ctx.lineWidth = Math.max(2.0 * k, ctx.lineWidth);
    ctx.setLineDash([]);
    ctx.stroke();
  }
  ctx.restore();
}

/* 文字列を「ふつうの字」と「添え字」に分ける。v_0 / v_x / v_{y0} と書ける */
function splitSub(text) {
  var segs = [], i = 0, cur = '';
  while (i < text.length) {
    var ch = text.charAt(i);
    if (ch === '_' && i + 1 < text.length) {
      if (cur) { segs.push({ s: cur, sub: false }); cur = ''; }
      if (text.charAt(i + 1) === '{') {
        var end = text.indexOf('}', i + 2);
        if (end === -1) end = text.length;
        segs.push({ s: text.slice(i + 2, end), sub: true });
        i = end + 1;
      } else {
        segs.push({ s: text.charAt(i + 1), sub: true });
        i += 2;
      }
    } else { cur += ch; i++; }
  }
  if (cur) segs.push({ s: cur, sub: false });
  return segs;
}

/* canvas の文字。添え字（v_0 など）に対応し、canvas の外にはみ出さないように寄せる */
function label(ctx, text, x, y, opt) {
  opt = opt || {};
  var size = opt.size || 13;
  var bold = opt.bold ? 'bold ' : '';
  var mainFont = bold + size + 'px ' + FONT;
  var subFont = bold + (size * 0.72).toFixed(1) + 'px ' + FONT;
  var segs = splitSub(String(text));
  var i, sg;
  ctx.save();
  ctx.textBaseline = opt.base || 'middle';
  ctx.textAlign = 'left';
  ctx.lineJoin = 'round';
  var tw = 0;
  for (i = 0; i < segs.length; i++) {
    ctx.font = segs[i].sub ? subFont : mainFont;
    segs[i].w = ctx.measureText(segs[i].s).width;
    tw += segs[i].w;
  }
  var al = opt.align || 'center';
  var left = al === 'right' ? x - tw : (al === 'left' ? x : x - tw / 2);
  if (CVW > 0 && opt.clamp !== false) {
    if (left < 4) left = 4;
    else if (left + tw > CVW - 4) left = Math.max(4, CVW - 4 - tw);
    if (y < 9) y = 9; else if (y > CVH - 7) y = CVH - 7;
  }
  var cx, sy;
  if (opt.halo !== false) {                 /* まず白フチを全部描く */
    ctx.strokeStyle = opt.haloColor || 'rgba(255,255,255,.92)';
    ctx.lineWidth = opt.haloW || 4.5;
    cx = left;
    for (i = 0; i < segs.length; i++) {
      sg = segs[i];
      ctx.font = sg.sub ? subFont : mainFont;
      sy = y + (sg.sub ? size * 0.26 : 0);
      ctx.strokeText(sg.s, cx, sy);
      cx += sg.w;
    }
  }
  ctx.fillStyle = opt.color || COL.ink;
  cx = left;
  for (i = 0; i < segs.length; i++) {
    sg = segs[i];
    ctx.font = sg.sub ? subFont : mainFont;
    sy = y + (sg.sub ? size * 0.26 : 0);
    ctx.fillText(sg.s, cx, sy);
    cx += sg.w;
  }
  ctx.restore();
}

/* 衝突のエフェクト（ギザギザ＋文字）。文字がはみ出さないように星を広げる */
function impact(ctx, x, y, r, text) {
  var i, a, rr;
  text = text || 'ドコッ！';
  var sz = Math.max(12, Math.min(18, r * 0.6));
  ctx.save();
  ctx.font = 'bold ' + sz + 'px ' + FONT;
  var tw = ctx.measureText(text).width;
  ctx.restore();
  r = Math.max(r, tw / 2 + 14);
  ctx.save();
  ctx.beginPath();
  var n = 11;
  for (i = 0; i < n * 2; i++) {
    a = Math.PI * i / n - Math.PI / 2;
    rr = (i % 2 === 0) ? r : r * 0.56;
    if (i === 0) ctx.moveTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr);
    else ctx.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr);
  }
  ctx.closePath();
  ctx.fillStyle = '#ffe27a'; ctx.strokeStyle = '#d1352b'; ctx.lineWidth = 2.4;
  ctx.fill(); ctx.stroke();
  /* まわりに飛び散る線 */
  ctx.lineWidth = 2.2; ctx.strokeStyle = '#d1352b';
  for (i = 0; i < 8; i++) {
    a = Math.PI * 2 * i / 8 + 0.2;
    ctx.beginPath();
    ctx.moveTo(x + Math.cos(a) * (r + 4), y + Math.sin(a) * (r + 4));
    ctx.lineTo(x + Math.cos(a) * (r + 15), y + Math.sin(a) * (r + 15));
    ctx.stroke();
  }
  ctx.restore();
  label(ctx, text, x, y + 1, { size: sz, bold: true, color: '#c0392b', halo: false, clamp: false });
}

/* ===== かんたんな3次元の投影（正射影・方位角と仰角で見回す） ===== */
function mk3d(az, el, S, cx, cy) {
  var ca = Math.cos(az), sa = Math.sin(az), ce = Math.cos(el), se = Math.sin(el);
  return {
    az: az, el: el, S: S,
    p: function (x, y, z) {
      var x1 = x * ca - y * sa, y1 = x * sa + y * ca;
      return {
        x: cx + x1 * S,
        y: cy - (z * ce - y1 * se) * S,
        d: y1 * ce + z * se
      };
    }
  };
}

/* 面のハッチング。ang＝面の向き（rad, 右向きが0）、below＝面の下側にかく */
function hatchLine(ctx, x1, y1, x2, y2, side) {
  ctx.save();
  ctx.strokeStyle = '#333'; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
  var dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy);
  if (L < 1) { ctx.restore(); return; }
  var ux = dx / L, uy = dy / L;
  var nx = -uy * side, ny = ux * side;    /* 面の「内側」向き法線 */
  ctx.lineWidth = 1;
  for (var d = 4; d < L; d += 10) {
    var px = x1 + ux * d, py = y1 + uy * d;
    ctx.beginPath();
    ctx.moveTo(px, py);
    ctx.lineTo(px - ux * 8 + nx * 8, py - uy * 8 + ny * 8);
    ctx.stroke();
  }
  ctx.restore();
}

function ball(ctx, x, y, r, style) {
  ctx.save();
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2);
  if (style === 'faint') { ctx.fillStyle = '#e7eaee'; ctx.strokeStyle = '#aab0b8'; ctx.lineWidth = 1.1; }
  else if (style === 'A') { ctx.fillStyle = '#cfe0f4'; ctx.strokeStyle = COL.A; ctx.lineWidth = 2; }
  else if (style === 'B') { ctx.fillStyle = '#f6d6d2'; ctx.strokeStyle = COL.B; ctx.lineWidth = 2; }
  else { ctx.fillStyle = '#fff'; ctx.strokeStyle = '#111'; ctx.lineWidth = 2; }
  ctx.fill(); ctx.stroke();
  ctx.restore();
}

/* 角度の弧（θ の記号） */
function angArc(ctx, cx, cy, r, a1, a2, text, labAng, labR) {
  ctx.save();
  ctx.strokeStyle = COL.sub; ctx.lineWidth = 1.3;
  ctx.beginPath(); ctx.arc(cx, cy, r, a1, a2, a2 < a1);
  ctx.stroke();
  ctx.restore();
  var am = (labAng === undefined || labAng === null) ? (a1 + a2) / 2 : labAng;
  var rr = labR || (r + 15);
  if (text) label(ctx, text, cx + Math.cos(am) * rr, cy + Math.sin(am) * rr, { size: 12.5, color: COL.sub });
}

/* 手（斜面上向きに引く／押す）。(hx,hy)＝手のひらの中心、ang＝向き（rad） */
/* 色をうすくする（#rrggbb → rgba） */
function fade(hex, a) {
  var h = (hex || '#d1352b').replace('#', '');
  var r = parseInt(h.substring(0, 2), 16), g = parseInt(h.substring(2, 4), 16), b = parseInt(h.substring(4, 6), 16);
  return 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')';
}

/* ===== 小さな効果音（Web Audio。外部ファイルは使わない） ===== */
var _AC = null;
function sfx(kind) {
  try {
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    if (!_AC) _AC = new AC();
    if (_AC.state === 'suspended' && _AC.resume) _AC.resume();
    var t0 = _AC.currentTime, o = _AC.createOscillator(), g = _AC.createGain();
    o.connect(g); g.connect(_AC.destination);
    if (kind === 'bang') {               /* 発射音「ばん！」 */
      o.type = 'square';
      o.frequency.setValueAtTime(260, t0);
      o.frequency.exponentialRampToValueAtTime(60, t0 + 0.16);
      g.gain.setValueAtTime(0.16, t0);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + 0.2);
      o.start(t0); o.stop(t0 + 0.22);
    } else if (kind === 'hit') {         /* 命中音 */
      o.type = 'triangle';
      o.frequency.setValueAtTime(880, t0);
      o.frequency.exponentialRampToValueAtTime(180, t0 + 0.18);
      g.gain.setValueAtTime(0.13, t0);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + 0.22);
      o.start(t0); o.stop(t0 + 0.24);
    } else if (kind === 'win') {         /* 成功の「ぴろりん」 */
      o.type = 'triangle';
      o.frequency.setValueAtTime(784, t0);
      o.frequency.setValueAtTime(1046, t0 + 0.09);
      o.frequency.setValueAtTime(1318, t0 + 0.18);
      g.gain.setValueAtTime(0.12, t0);
      g.gain.setValueAtTime(0.12, t0 + 0.24);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + 0.42);
      o.start(t0); o.stop(t0 + 0.44);
    } else {                             /* 「ピコン」 */
      o.type = 'sine';
      o.frequency.setValueAtTime(660, t0);
      o.frequency.setValueAtTime(990, t0 + 0.07);
      g.gain.setValueAtTime(0.09, t0);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + 0.18);
      o.start(t0); o.stop(t0 + 0.2);
    }
    /* 鳴り終わったノードは切りはなす（何度も鳴らすうちに音のつながりがたまらないように） */
    o.onended = function () { try { o.disconnect(); g.disconnect(); } catch (e2) { } };
  } catch (e) { /* 音が出せない環境では何もしない */ }
}

/* 小球を落とそうとする手（真横やや上から。指先の下に小球が来るように描く）。
   (x,y)＝小球の中心。sc＝大きさ、open＝0〜1（1 で親指と人差し指をひらいた形）、
   alpha＝濃さ。 */
function dropHand(ctx, x, y, sc, open, alpha) {
  sc = sc || 1;
  var o = Math.max(0, Math.min(1, open || 0));
  var INK = '#3f4a54', SKIN = '#ffffff';
  ctx.save();
  ctx.translate(x, y); ctx.scale(sc, sc);
  ctx.globalAlpha = (alpha === undefined) ? 1 : alpha;
  ctx.lineJoin = 'round'; ctx.lineCap = 'round';

  function limb(x0, y0, cx, cy, x1, y1, w) {     /* 指・親指（外枠つきの太い線） */
    ctx.beginPath();
    ctx.moveTo(x0, y0); ctx.quadraticCurveTo(cx, cy, x1, y1);
    ctx.lineWidth = w + 3.4; ctx.strokeStyle = INK; ctx.stroke();
    ctx.lineWidth = w; ctx.strokeStyle = SKIN; ctx.stroke();
  }
  /* 指（奥から手前へ4本）。右から2本目＝人差し指だけ、ひらくときに動く */
  limb(-28, -66, -58, -54, -66, -28, 12);
  limb(-14, -72, -46, -58, -52, -21, 13);
  limb(2, -74, -30, -60, -33, -16, 14);
  limb(16, -72, -10 - 9 * o, -58, -13 - 21 * o, -15 - 9 * o, 14);   /* 人差し指 */
  /* 手の甲 */
  ctx.beginPath();
  ctx.moveTo(-32, -62);
  ctx.bezierCurveTo(-8, -94, 42, -98, 64, -74);
  ctx.bezierCurveTo(80, -58, 62, -40, 34, -40);
  ctx.bezierCurveTo(10, -40, -12, -46, -32, -62);
  ctx.closePath();
  ctx.fillStyle = SKIN; ctx.fill();
  ctx.lineWidth = 3.2; ctx.strokeStyle = INK; ctx.stroke();
  /* 手首・腕 */
  ctx.beginPath();
  ctx.moveTo(56, -84); ctx.lineTo(96, -78);
  ctx.lineTo(96, -50); ctx.lineTo(58, -46);
  ctx.closePath();
  ctx.fillStyle = SKIN; ctx.fill(); ctx.lineWidth = 3.2; ctx.strokeStyle = INK; ctx.stroke();
  /* 親指（右手前）。ひらくときは右へ開く */
  limb(42, -48, 40 + 10 * o, -25, 17 + 24 * o, -12 - 8 * o, 15);
  /* 指のしわ */
  ctx.lineWidth = 1.3; ctx.strokeStyle = INK; ctx.globalAlpha *= 0.75;
  ctx.beginPath(); ctx.moveTo(-46, -47); ctx.lineTo(-38, -44); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(-26, -47); ctx.lineTo(-18, -45); ctx.stroke();
  ctx.restore();
}

/* デコピンする手（物体をはじく）。
   (x,y)＝こぶしの中心、ang＝はじく向き（rad、+x がはじく向き）、
   k＝0…指を曲げた形／1…はじいたあとの形、dir＝+1 か −1（左右の向き）、
   sc＝大きさ、alpha＝濃さ。 */
function flickHand(ctx, x, y, ang, k, dir, sc, alpha) {
  k = Math.max(0, Math.min(1, k || 0));
  sc = sc || 0.45;
  var SKIN = '#fbd7b7', INK = '#4a3730';
  function mix(a, b) { return a + (b - a) * k; }
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(ang);
  if (dir < 0) ctx.scale(-1, 1);
  ctx.scale(sc, sc);
  ctx.globalAlpha = (alpha === undefined) ? 1 : alpha;
  ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  ctx.fillStyle = SKIN; ctx.strokeStyle = INK;

  /* 腕（後ろへ） */
  ctx.lineWidth = 26; ctx.strokeStyle = SKIN;
  ctx.beginPath(); ctx.moveTo(-6, 10); ctx.lineTo(-96, 58); ctx.stroke();
  ctx.lineWidth = 3.4; ctx.strokeStyle = INK;
  ctx.beginPath(); ctx.moveTo(-14, -2); ctx.lineTo(-100, 46); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(-2, 22); ctx.lineTo(-92, 70); ctx.stroke();

  /* こぶし */
  ctx.beginPath(); ctx.arc(0, 0, 30, 0, Math.PI * 2);
  ctx.fillStyle = SKIN; ctx.fill(); ctx.lineWidth = 3.4; ctx.strokeStyle = INK; ctx.stroke();
  /* 折りたたんだ指（3つのふくらみ） */
  ctx.lineWidth = 2.6;
  ctx.beginPath(); ctx.ellipse(24, -18, 15, 11, -0.35, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.ellipse(28, 2, 16, 12, -0.15, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.ellipse(22, 22, 17, 12, 0.15, 0, Math.PI * 2); ctx.fill(); ctx.stroke();

  /* はじく指：曲げた形（Λ）→ まっすぐ */
  var jx = mix(34, 44), jy = mix(-52, -20), tx = mix(52, 80), ty = mix(-16, -12);
  ctx.lineWidth = 15; ctx.strokeStyle = SKIN;
  ctx.beginPath(); ctx.moveTo(16, -20); ctx.lineTo(jx, jy); ctx.lineTo(tx, ty); ctx.stroke();
  ctx.lineWidth = 18; ctx.strokeStyle = INK;
  ctx.beginPath(); ctx.moveTo(16, -20); ctx.lineTo(jx, jy); ctx.lineTo(tx, ty);
  ctx.strokeStyle = INK; ctx.lineWidth = 3.2;
  ctx.stroke();
  ctx.lineWidth = 12; ctx.strokeStyle = SKIN;
  ctx.beginPath(); ctx.moveTo(16, -20); ctx.lineTo(jx, jy); ctx.lineTo(tx, ty); ctx.stroke();

  /* はじいた瞬間の勢いの線 */
  if (k > 0.15 && k < 0.95) {
    ctx.strokeStyle = INK; ctx.lineWidth = 2.4; ctx.globalAlpha *= (1 - k);
    for (var i2 = -1; i2 <= 1; i2++) {
      ctx.beginPath();
      ctx.moveTo(tx + 12, ty + i2 * 14); ctx.lineTo(tx + 30, ty + i2 * 20);
      ctx.stroke();
    }
  }
  ctx.restore();
}

/* 糸（ひも）：物体と手をつなぐ細い線 */
function string(ctx, x1, y1, x2, y2) {
  ctx.save();
  ctx.strokeStyle = '#6b5442'; ctx.lineWidth = 1.6; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
  ctx.restore();
}

function hand(ctx, hx, hy, ang) {
  ctx.save();
  ctx.translate(hx, hy);
  ctx.rotate(ang);
  ctx.fillStyle = '#f6d9bd'; ctx.strokeStyle = '#a97b4c'; ctx.lineWidth = 1.4;
  /* 腕 */
  ctx.beginPath();
  ctx.moveTo(10, -6); ctx.lineTo(40, -7); ctx.lineTo(40, 7); ctx.lineTo(10, 6);
  ctx.closePath(); ctx.fill(); ctx.stroke();
  /* こぶし */
  ctx.beginPath();
  ctx.ellipse(2, 0, 13, 11, 0, 0, Math.PI * 2);
  ctx.fill(); ctx.stroke();
  /* 指の線 */
  ctx.beginPath();
  ctx.moveTo(-8, -5); ctx.lineTo(4, -5);
  ctx.moveTo(-9, 0); ctx.lineTo(5, 0);
  ctx.moveTo(-8, 5); ctx.lineTo(4, 5);
  ctx.stroke();
  ctx.restore();
}

/* 吹き出し。既定では箱が (x, y) の上に来て、しっぽが下（y+8）を指す。
   ★opt.up = true にすると上下が逆になり、箱が下・しっぽが上（y−8）を指す。★
   指したいものが吹き出しより「上」にあるときは、かならず up: true にすること
   （そうしないと、しっぽが指したいものと反対を向いて意味が通らない）。 */
function bubble(ctx, text, x, y, opt) {
  opt = opt || {};
  var up = !!opt.up;
  ctx.save();
  ctx.font = 'bold ' + (opt.size || 14) + 'px ' + FONT;
  var w = ctx.measureText(text).width + 18, h = (opt.size || 14) + 14;
  var bx = x - w / 2, by = up ? y : (y - h);
  var ty = up ? by : (by + h);          /* しっぽの根もとの辺 */
  var tip = up ? (y - 8) : (y + 8);     /* しっぽの先 */
  ctx.fillStyle = opt.bg || '#fff5d6';
  ctx.strokeStyle = opt.border || '#d9a545';
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(bx, by, w, h, 7);
  else ctx.rect(bx, by, w, h);
  ctx.fill(); ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(x - 6, ty); ctx.lineTo(x, tip); ctx.lineTo(x + 6, ty);
  ctx.closePath(); ctx.fillStyle = opt.bg || '#fff5d6'; ctx.fill();
  ctx.strokeStyle = opt.border || '#d9a545';
  ctx.beginPath(); ctx.moveTo(x - 6, ty); ctx.lineTo(x, tip); ctx.lineTo(x + 6, ty); ctx.stroke();
  ctx.fillStyle = opt.color || '#8a5000';
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText(text, x, by + h / 2);
  ctx.restore();
}

/* ===== かんたんな3次元の投影（正射影・方位角 az と仰角 el で見回す）=====
   姉妹ページ（basics-of-motion-on-plane）の 4-3 と同じ作り。
   ★el = 0 にすると「真横から見た図」になる★（＝ふつうの2次元グラフとして読める）。 */
function mk3d(az, el, S, cx, cy) {
  var ca = Math.cos(az), sa = Math.sin(az), ce = Math.cos(el), se = Math.sin(el);
  return {
    az: az, el: el, S: S,
    p: function (x, y, z) {
      var x1 = x * ca - y * sa, y1 = x * sa + y * ca;
      return {
        x: cx + x1 * S,
        y: cy - (z * ce - y1 * se) * S,
        d: y1 * ce + z * se              /* 奥ゆき（前後を並べかえるのに使う） */
      };
    }
  };
}
/* 視点がそのプリセットと同じか（ボタンを塗るのに使う） */
function camIs(s, az, el, zoom) {
  return !!s.cam && Math.abs(s.cam.az - az) < 0.5 && Math.abs(s.cam.el - el) < 0.5 &&
    Math.abs(s.cam.zoom - zoom) < 0.02;
}

/* 世界座標（y 上向き）→ 画面座標。等方スケールで box を pad の内側に収める */
/* ===== canvas にイラストを置く =====
   build.js が assets/ の絵を base64 で IMG に入れてくれるので、
   そこから Image を作ってキャッシュする。読み終わるまでは null を返し、
   読み終わったら renderActive() でもう一度描き直す（1回だけ）。 */
var _cimg = {};
function canvasImg(key) {
  if (typeof IMG === 'undefined' || !IMG || !IMG[key]) return null;
  var e = _cimg[key];
  if (!e) {
    e = _cimg[key] = { img: new Image(), ok: false };
    e.img.onload = function () {
      e.ok = true;
      if (typeof renderActive === 'function') renderActive();
    };
    e.img.src = IMG[key];
  }
  return e.ok ? e.img : null;
}

function mkView(W, H, pad, box) {
  var w = W - pad.l - pad.r, h = H - pad.t - pad.b;
  var bw = Math.max(1e-6, box.x1 - box.x0), bh = Math.max(1e-6, box.y1 - box.y0);
  var s = Math.min(w / bw, h / bh);
  var cx = (box.x0 + box.x1) / 2, cy = (box.y0 + box.y1) / 2;
  var ox = pad.l + w / 2, oy = pad.t + h / 2;
  return {
    s: s,
    X: function (x) { return ox + (x - cx) * s; },
    Y: function (y) { return oy - (y - cy) * s; },
    invX: function (px) { return cx + (px - ox) / s; },
    invY: function (py) { return cy - (py - oy) / s; }
  };
}

/* 「きり」のよい目盛り間隔 */
function niceStep(range, target) {
  var raw = range / Math.max(1, target);
  var p = Math.pow(10, Math.floor(Math.log(raw) / Math.LN10));
  var c = [1, 2, 2.5, 5, 10];
  for (var i = 0; i < c.length; i++) if (raw <= c[i] * p * 1.0001) return c[i] * p;
  return 10 * p;
}

/* 0 を必ず含み、きりのよい端で切った範囲にする（グラフの原点を画面に入れるため） */
function niceRange(lo, hi) {
  var a = Math.min(0, lo), b = Math.max(0, hi);
  if (b - a < 1e-9) { a -= 1; b += 1; }
  var pad = (b - a) * 0.14;
  a -= (lo < -1e-9 ? pad : pad * 0.35);
  b += (hi > 1e-9 ? pad : pad * 0.35);
  var st = niceStep(b - a, 5);
  a = Math.floor(a / st) * st;
  b = Math.ceil(b / st) * st;
  if (b - a < st * 1.5) b = a + st * 2;
  return { lo: a, hi: b };
}

/* 0 を含めなくてよいときの範囲（黄経など、0 のまわりを見てもしかたない量） */
function niceRangeFree(lo, hi) {
  if (!(hi > lo)) { hi = lo + 1; }
  var pad = (hi - lo) * 0.12;
  var a = lo - pad, b = hi + pad;
  var st = niceStep(b - a, 5);
  a = Math.floor(a / st) * st;
  b = Math.ceil(b / st) * st;
  return { lo: a, hi: b };
}

/* ===== 軸の共通スタイル（1-3 の y 軸をベースに全シムでそろえる） =====
   ・軸は細い実線、正の向きの端に太めの矢じり
   ・目盛りは短い線＋数値（等幅っぽい小さめの字）
   ・原点は ● と大きめの「O」で強調
*/
var AX = { tick: 4.5, num: 11, name: 12.5, head: 13, col: '#5b6672' };

/* 原点の強調 */
function originMark(ctx, px, py, ox, oy) {
  ctx.save();
  ctx.fillStyle = AX.col;
  ctx.beginPath(); ctx.arc(px, py, 3.4, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
  label(ctx, 'O', px + (ox === undefined ? -13 : ox), py + (oy === undefined ? 13 : oy),
    { size: AX.name + 2, bold: true, color: AX.col });
}

/* 軸を1本ひく（すべての図で共通）。
   P(値)→{x,y} 画面座標、nrm＝目盛りの数字を置く向き（単位ベクトル）、
   sign>0 で「値が増える向き」が正。opt.numDec で小数桁を固定できる。 */
function axisLine(ctx, P, lo, hi, nrm, name, sign, opt) {
  opt = opt || {};
  var s = opt.step || niceStep(hi - lo, opt.target || 5);
  var pLo = P(lo), pHi = P(hi), i;
  var dx = pHi.x - pLo.x, dy = pHi.y - pLo.y, L = Math.hypot(dx, dy);
  if (L < 2) return;
  var ux = dx / L, uy = dy / L;                       /* 値が増える向き（画面） */
  ctx.save();
  ctx.strokeStyle = AX.col; ctx.lineWidth = 1.4;
  ctx.beginPath(); ctx.moveTo(pLo.x, pLo.y); ctx.lineTo(pHi.x, pHi.y); ctx.stroke();
  ctx.restore();
  var sg = sign >= 0 ? 1 : -1;
  var tip = sg > 0 ? pHi : pLo;
  var tx = ux * sg, ty = uy * sg;
  arrowHead(ctx, tip.x + tx * AX.head, tip.y + ty * AX.head, tx, ty, AX.col);
  var dec = opt.numDec !== undefined ? opt.numDec : (s < 1 ? 1 : 0);
  for (i = Math.ceil(lo / s) * s; i <= hi + 1e-9; i += s) {
    if (Math.abs(i) < 1e-9) continue;
    var p = P(i);
    ctx.save(); ctx.strokeStyle = AX.col; ctx.lineWidth = 1.1;
    ctx.beginPath();
    ctx.moveTo(p.x - nrm.x * AX.tick, p.y - nrm.y * AX.tick);
    ctx.lineTo(p.x + nrm.x * AX.tick, p.y + nrm.y * AX.tick);
    ctx.stroke(); ctx.restore();
    if (!opt.noNum) label(ctx, fmt(i * sg, dec), p.x + nrm.x * 13, p.y + nrm.y * 13,
      { size: AX.num, color: AX.col, align: nrm.x < -0.5 ? 'right' : (nrm.x > 0.5 ? 'left' : 'center') });
  }
  if (name) {
    var nx = tip.x + tx * (AX.head + 8) - nrm.x * 12;
    var ny = tip.y + ty * (AX.head + 8) - nrm.y * 12;
    /* ★たての軸の名前は「矢じりの右がわ」から書き始める★
       まん中ぞろえだと、長い名前（例：エネルギー [MJ]）が矢じりに重なって読めない
       （スマホの細いグラフでとくに目立つ）。よこの軸はこれまでどおり。 */
    if (Math.abs(nrm.x) > 0.5) {
      label(ctx, name, tip.x + 8, ny, { size: AX.name, color: AX.col, align: 'left' });
    } else {
      label(ctx, name, nx, ny, { size: AX.name, color: AX.col });
    }
  }
}

/* 横軸。X(値)→px、ypx＝軸の高さ。sign>0 で右が正 */
function axisX(ctx, X, ypx, lo, hi, name, sign, opt) {
  axisLine(ctx, function (v) { return { x: X(v), y: ypx }; }, lo, hi, { x: 0, y: 1 }, name, sign, opt);
}

/* 縦軸。Y(値)→px、xpx＝軸の横位置。sign>0 で「値が増える向き」が正 */
function axisY(ctx, Y, xpx, lo, hi, name, sign, opt) {
  axisLine(ctx, function (v) { return { x: xpx, y: Y(v) }; }, lo, hi, { x: -1, y: 0 }, name, sign, opt);
}

/* 矢じりだけ描く（軸の先） */
function arrowHead(ctx, x, y, ux, uy, color) {
  var h = AX.head, w = h * 0.42;
  ctx.save();
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.lineTo(x - ux * h - uy * w, y - uy * h + ux * w);
  ctx.lineTo(x - ux * h + uy * w, y - uy * h - ux * w);
  ctx.closePath(); ctx.fill();
  ctx.restore();
}

/* 世界座標の x,y 軸（うすい格子つき）を、共通スタイルで描く */
function worldAxes(ctx, vw, box, xlabel, ylabel, signY) {
  var x0 = vw.X(box.x0), x1 = vw.X(box.x1), y0 = vw.Y(box.y0), y1 = vw.Y(box.y1);
  var sx = niceStep(box.x1 - box.x0, 6), sy = niceStep(box.y1 - box.y0, 5), i;
  ctx.save();
  ctx.strokeStyle = COL.grid; ctx.lineWidth = 1;
  for (i = Math.ceil(box.x0 / sx) * sx; i <= box.x1 + 1e-9; i += sx) {
    ctx.beginPath(); ctx.moveTo(vw.X(i), y1); ctx.lineTo(vw.X(i), y0); ctx.stroke();
  }
  for (i = Math.ceil(box.y0 / sy) * sy; i <= box.y1 + 1e-9; i += sy) {
    ctx.beginPath(); ctx.moveTo(x0, vw.Y(i)); ctx.lineTo(x1, vw.Y(i)); ctx.stroke();
  }
  ctx.restore();
  var ax = vw.Y(0), ay = vw.X(0);
  var hasY0 = (box.y0 <= 0 && box.y1 >= 0), hasX0 = (box.x0 <= 0 && box.x1 >= 0);
  if (hasY0) axisX(ctx, vw.X, ax, box.x0, box.x1 - sx * 0.35, xlabel, 1);
  if (hasX0) axisY(ctx, vw.Y, ay, box.y0, box.y1 - sy * 0.35, ylabel, signY === undefined ? 1 : signY);
  if (hasY0 && hasX0) originMark(ctx, ay, ax);
}

/* ===== 折れ線グラフ ===== */
/* spec: {xlabel,ylabel,xmin,xmax,ymin,ymax,series:[{color,dash,pts,name}],cursors:[{color,x,y}],zeroNote} */
function plot(cv, spec) {
  var W = 320, H = spec.H || 174;    /* spec.H を書くと、そのグラフだけ縦を高くできる */
  var ctx = prep(cv, W, H);
  var pad = { l: 46, r: 16, t: 20, b: 26 };
  var gw = W - pad.l - pad.r, gh = H - pad.t - pad.b;
  var xmin = spec.xmin, xmax = spec.xmax, ymin = spec.ymin, ymax = spec.ymax;
  if (spec.view) { xmin = spec.view.xmin; xmax = spec.view.xmax; ymin = spec.view.ymin; ymax = spec.view.ymax; }
  if (ymax - ymin < 1e-6) { ymax += 0.5; ymin -= 0.5; }
  var lgx = !!spec.logx, lgy = !!spec.logy;
  /* ドラッグ操作のために、いまの対応づけを canvas に覚えさせる
     （両対数のグラフはドラッグしない：軸が 0 をまたげないため） */
  cv._map = (lgx || lgy) ? null
    : { W: W, H: H, pad: pad, gw: gw, gh: gh, xmin: xmin, xmax: xmax, ymin: ymin, ymax: ymax };
  function LG(v) { return Math.log(Math.max(1e-300, v)) / Math.LN10; }
  function X(x) {
    if (!lgx) return pad.l + gw * (x - xmin) / (xmax - xmin || 1);
    return pad.l + gw * (LG(x) - LG(xmin)) / ((LG(xmax) - LG(xmin)) || 1);
  }
  function Y(y) {
    if (!lgy) return pad.t + gh * (ymax - y) / (ymax - ymin || 1);
    return pad.t + gh * (LG(ymax) - LG(y)) / ((LG(ymax) - LG(ymin)) || 1);
  }

  ctx.save();
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, W, H);
  /* 目盛りグリッド */
  var sx = niceStep(xmax - xmin, 5), sy = niceStep(ymax - ymin, 4), i;
  ctx.strokeStyle = COL.grid; ctx.lineWidth = 1;
  if (lgx) {
    logTicks(xmin, xmax).forEach(function (v) {
      ctx.beginPath(); ctx.moveTo(X(v.v), pad.t); ctx.lineTo(X(v.v), pad.t + gh); ctx.stroke();
    });
  } else {
    for (i = Math.ceil(xmin / sx) * sx; i <= xmax + 1e-9; i += sx) {
      ctx.beginPath(); ctx.moveTo(X(i), pad.t); ctx.lineTo(X(i), pad.t + gh); ctx.stroke();
    }
  }
  if (lgy) {
    logTicks(ymin, ymax).forEach(function (v) {
      ctx.beginPath(); ctx.moveTo(pad.l, Y(v.v)); ctx.lineTo(pad.l + gw, Y(v.v)); ctx.stroke();
    });
  } else {
    for (i = Math.ceil(ymin / sy) * sy; i <= ymax + 1e-9; i += sy) {
      ctx.beginPath(); ctx.moveTo(pad.l, Y(i)); ctx.lineTo(pad.l + gw, Y(i)); ctx.stroke();
    }
  }
  ctx.restore();

  /* 軸（本体の図と同じ書き方にそろえる。グラフは小さいので字だけ少し小さく） */
  var axSave = { tick: AX.tick, num: AX.num, name: AX.name, head: AX.head };
  AX.tick = 3.5; AX.num = 9.5; AX.name = 11; AX.head = 10;
  var yName = null;   /* たての軸の名前を、あとで書くばしょ */
  if (lgx || lgy) {
    /* 両対数（第3法則）：軸は枠の左と下に引き、目盛りは 10ⁿ で書く */
    var yz2 = pad.t + gh, xz2 = pad.l;
    ctx.save(); ctx.strokeStyle = AX.col; ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.moveTo(xz2, yz2); ctx.lineTo(pad.l + gw, yz2); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(xz2, yz2); ctx.lineTo(xz2, pad.t); ctx.stroke();
    ctx.restore();
    arrowHead(ctx, pad.l + gw + AX.head, yz2, 1, 0, AX.col);
    arrowHead(ctx, xz2, pad.t - AX.head, 0, -1, AX.col);
    (lgx ? logTicks(xmin, xmax) : []).forEach(function (v) {
      if (!v.major) return;
      ctx.save(); ctx.strokeStyle = AX.col; ctx.lineWidth = 1.1;
      ctx.beginPath(); ctx.moveTo(X(v.v), yz2 - AX.tick); ctx.lineTo(X(v.v), yz2 + AX.tick); ctx.stroke();
      ctx.restore();
      label(ctx, v.txt, X(v.v), yz2 + 12, { size: AX.num, color: AX.col });
    });
    (lgy ? logTicks(ymin, ymax) : []).forEach(function (v) {
      if (!v.major) return;
      ctx.save(); ctx.strokeStyle = AX.col; ctx.lineWidth = 1.1;
      ctx.beginPath(); ctx.moveTo(xz2 - AX.tick, Y(v.v)); ctx.lineTo(xz2 + AX.tick, Y(v.v)); ctx.stroke();
      ctx.restore();
      label(ctx, v.txt, xz2 - 6, Y(v.v), { size: AX.num, color: AX.col, align: 'right' });
    });
    label(ctx, spec.xlabel || '', pad.l + gw + 4, yz2 - 10, { size: AX.name, color: AX.col, align: 'right' });
    label(ctx, spec.ylabel || '', xz2 + 6, pad.t - 4, { size: AX.name, color: AX.col, align: 'left' });
  } else {
    var hasY0 = (ymin <= 0 && ymax >= 0), hasX0 = (xmin <= 0 && xmax >= 0);
    var yz = hasY0 ? Y(0) : pad.t + gh;
    /* yName＝たての軸の名前をあとで書くばしょ（すぐ下で入れる） */
    var xz = hasX0 ? X(0) : pad.l;
    axisX(ctx, X, yz, xmin, xmax - sx * 0.3, spec.xlabel || '', 1);
    /* ★たての軸の名前は「線をひいたあと」に書く★
       ここで書いてしまうと、あとから引く曲線（K や U）が名前の上にかぶさって読めない。
       ばしょだけ覚えておいて、実際に書くのはこのかんすうの終わりのほう。 */
    axisY(ctx, Y, xz, ymin, ymax - sy * 0.3, '', 1);
    yName = { x: xz + 8, y: Y(ymax - sy * 0.3) - (AX.head + 8) };
    if (hasY0 && hasX0) originMark(ctx, xz, yz, -10, 11);
  }
  AX.tick = axSave.tick; AX.num = axSave.num; AX.name = axSave.name; AX.head = axSave.head;
  if (spec.note) label(ctx, spec.note, W - 6, 9, { size: 9.5, color: COL.sub, align: 'right' });

  /* ★凡例のばしょは「先に」決めておく★
     帯（spec.bands）の文字を右上に置くと凡例と重なるので、
     どこに凡例が来るかを、帯をぬる前に知っておく必要がある。
     実際に凡例をかくのは、線をひいたあと（このかんすうの終わり）。 */
  var lgBox = null;
  if (spec.legend && !spec.hide) {
    var lw0 = 0;
    ctx.save(); ctx.font = '10px ' + FONT;
    spec.legend.forEach(function (lg) { lw0 = Math.max(lw0, ctx.measureText(lg.name).width); });
    ctx.restore();
    lgBox = {
      x: pad.l + gw - lw0 - 26, y: pad.t + 8, w: lw0,
      bot: pad.t + 8 + spec.legend.length * 13 - 4
    };
  }

  ctx.save();
  ctx.beginPath(); ctx.rect(pad.l - 1, pad.t - 1, gw + 2, gh + 2); ctx.clip();
  /* ===== よこ一面の帯（spec.bands）=====
     「この高さから上／下」がどんな意味かを、うすい色で示すのに使う。
     いまは 2-1 の U–r 図で「E < 0 ＝ 閉じこめられる／E ≥ 0 ＝ ぬけ出せる」を塗り分けている。
     ★色はページの決まりに従うこと★——青は速度・赤は力の色なので、ここには使わない。
     軌道の色（緑＝円と楕円／金＝放物線）をうすくして使う。
     bands: [{ y0, y1, color, label }] */
  (spec.hide ? [] : (spec.bands || [])).forEach(function (bd) {
    var ya = Y(Math.max(bd.y0, ymin)), yb = Y(Math.min(bd.y1, ymax));
    if (!isFinite(ya) || !isFinite(yb)) return;
    var top = Math.min(ya, yb), hgt = Math.abs(ya - yb);
    if (hgt < 1) return;
    ctx.save();
    ctx.fillStyle = bd.color;
    ctx.fillRect(pad.l, top, gw, hgt);
    ctx.restore();
    /* ★文字は帯のまん中★（上端だと、目もりの数字とぶつかる）。
       ただし、まん中が右上の凡例にかぶるときは、凡例の下までずらす。 */
    if (bd.label && hgt > 26) {
      var lby = top + hgt / 2;
      if (lgBox && lby < lgBox.bot + 10) lby = Math.min(lgBox.bot + 12, top + hgt - 8);
      label(ctx, bd.label, pad.l + gw - 6, lby,
        { align: 'right', size: 9.5, bold: true, color: bd.lcolor || AX.col,
          haloColor: '#fff' });
    }
  });
  /* 曲線の下の面積（仕事＝力×距離の積み重ね）をぬる */
  (spec.hide ? [] : (spec.fills || [])).forEach(function (fl) {
    if (!fl.pts || fl.pts.length < 2) return;
    ctx.save();
    ctx.beginPath();
    var y0 = Y(fl.y0 === undefined ? 0 : fl.y0);
    ctx.moveTo(X(fl.pts[0][0]), y0);
    for (var k = 0; k < fl.pts.length; k++) ctx.lineTo(X(fl.pts[k][0]), Y(fl.pts[k][1]));
    ctx.lineTo(X(fl.pts[fl.pts.length - 1][0]), y0);
    ctx.closePath();
    ctx.fillStyle = fl.color;
    ctx.fill();
    ctx.restore();
  });

  (spec.hide ? [] : (spec.series || [])).forEach(function (se) {
    if (!se.pts || se.pts.length < 2) return;
    ctx.save();
    ctx.strokeStyle = se.color; ctx.lineWidth = se.width || 2.2;
    if (se.dash) ctx.setLineDash(se.dash);
    ctx.beginPath();
    var started = false;
    for (var j = 0; j < se.pts.length; j++) {
      var p = se.pts[j];
      if (!isFinite(p[0]) || !isFinite(p[1])) { started = false; continue; }
      var px = X(p[0]), py = Y(p[1]);
      if (!started) { ctx.moveTo(px, py); started = true; } else ctx.lineTo(px, py);
    }
    ctx.stroke();
    ctx.restore();
  });

  /* 目立たせたい点（第3法則の T–a 図の 3 天体など）
     ★押せる点にするために、画面の座標をおぼえておく★（80_ui.js の attachGraphPick）
       mk.id を書いた点だけが押せる。ここを毎回作りなおすこと（軸を動かすとずれるため）。 */
  cv._marks = [];
  (spec.hide ? [] : (spec.marks || [])).forEach(function (mk) {
    if (!isFinite(mk.x) || !isFinite(mk.y)) return;
    var px = X(mk.x), py = Y(mk.y);
    if (mk.id) cv._marks.push({ id: mk.id, px: px, py: py });
    ctx.save();
    ctx.fillStyle = mk.color; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.8;
    ctx.beginPath(); ctx.arc(px, py, mk.r || 5.2, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    if (mk.ring) {                      /* いま選んでいる天体を目立たせる */
      ctx.strokeStyle = '#1663b5'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(px, py, (mk.r || 5.2) + 4.5, 0, Math.PI * 2); ctx.stroke();
    }
    ctx.restore();
    if (mk.name) label(ctx, mk.name, px + (mk.lx === undefined ? 8 : mk.lx), py + (mk.ly === undefined ? -9 : mk.ly),
      { size: mk.ring ? 11 : 10, bold: !!mk.ring, color: mk.color, align: mk.align || 'left' });
  });

  /* いまの位置を示すたて線（spec.vline）。cursors より先に描いて、点を上にのせる */
  if (!spec.hide && spec.vline && isFinite(spec.vline.x)) {
    var vx = X(spec.vline.x);
    ctx.save();
    ctx.strokeStyle = spec.vline.color || COL.sub; ctx.lineWidth = 1.4;
    ctx.setLineDash([5, 4]);
    ctx.beginPath(); ctx.moveTo(vx, pad.t); ctx.lineTo(vx, pad.t + gh); ctx.stroke();
    ctx.restore();
    if (spec.vline.label) {
      /* 凡例は左上に出るので、この文字は下のほうに置く。
         たて線が左はしに近いときは右へ、右端に近いときは左へ書き出す（切れないように）。 */
      var lft = (vx < pad.l + gw / 2);
      label(ctx, spec.vline.label, vx + (lft ? 5 : -5), pad.t + gh - 8,
        { size: 9.5, bold: true, align: lft ? 'left' : 'right', color: spec.vline.color || COL.sub });
    }
  }
  (spec.hide ? [] : (spec.cursors || [])).forEach(function (c) {
    if (!isFinite(c.x) || !isFinite(c.y)) return;
    ctx.save();
    ctx.fillStyle = c.color; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.8;
    ctx.beginPath(); ctx.arc(X(c.x), Y(c.y), c.r || 4.6, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.restore();
    /* c.name を書くと、その点のそばに名前が出る（「いまの U」など） */
    if (c.name) {
      label(ctx, c.name, X(c.x) + (c.lx === undefined ? 9 : c.lx), Y(c.y) + (c.ly === undefined ? -10 : c.ly),
        { size: 9.5, bold: true, color: c.color, align: c.align || 'left' });
    }
  });
  ctx.restore();   /* clip 解除 */

  /* たての軸の名前（曲線の上に書く。白いふちどりを付けて必ず読めるようにする） */
  if (yName && spec.ylabel) {
    label(ctx, spec.ylabel, yName.x, yName.y,
      { size: 11, color: AX.col, align: 'left', haloColor: '#fff' });
  }

  if (lgBox) {
    /* ★凡例は右上に置く★ 左上に置くと、K = E − U のように
       「左（r が小さいほう）で大きくなる曲線」が凡例にかくれて見えなくなる。 */
    var lx = lgBox.x, ly = lgBox.y;
    var lw = lgBox.w;
    ctx.save();
    ctx.fillStyle = 'rgba(255,255,255,.86)';
    ctx.fillRect(lx - 4, ly - 8, lw + 28, spec.legend.length * 13 + 4);
    ctx.restore();
    spec.legend.forEach(function (lg, k) {
      ctx.save();
      ctx.strokeStyle = lg.color; ctx.lineWidth = 2.4;
      ctx.beginPath(); ctx.moveTo(lx, ly + k * 13); ctx.lineTo(lx + 16, ly + k * 13); ctx.stroke();
      ctx.restore();
      label(ctx, lg.name, lx + 20, ly + k * 13, { size: 10, color: COL.sub, align: 'left' });
    });
  }
}

/* ===== 両対数グラフの目盛り ===== */
/* lo〜hi のあいだの 1,2,…,9 ×10ⁿ を返す。major＝10ⁿ（数字を書くところ） */
function logTicks(lo, hi) {
  var out = [];
  if (!(lo > 0) || !(hi > lo)) return out;
  var e0 = Math.floor(Math.log(lo) / Math.LN10), e1 = Math.ceil(Math.log(hi) / Math.LN10);
  for (var e = e0; e <= e1; e++) {
    for (var m = 1; m <= 9; m++) {
      var v = m * Math.pow(10, e);
      if (v < lo * 0.999 || v > hi * 1.001) continue;
      out.push({ v: v, major: m === 1, txt: logLabel(e) });
    }
  }
  return out;
}
function logLabel(e) {
  if (e === 0) return '1';
  if (e === 1) return '10';
  return '10' + fmtSup(e);
}
/* 対数軸用の「きりのよい」範囲（10ⁿ で切る） */
function niceRangeLog(lo, hi) {
  if (!(lo > 0)) lo = hi / 1000;
  var a = Math.pow(10, Math.floor(Math.log(lo) / Math.LN10));
  var b = Math.pow(10, Math.ceil(Math.log(hi) / Math.LN10));
  if (b / a < 10) b = a * 10;
  return { lo: a, hi: b };
}

/* ===== 天体の絵 ===== */
/* 太陽（光のにじみつき）。r＝画面上の半径 */
function sunShape(ctx, x, y, r, name) {
  ctx.save();
  var g = ctx.createRadialGradient(x, y, r * 0.2, x, y, r * 3.1);
  g.addColorStop(0, 'rgba(240,180,41,.42)');
  g.addColorStop(1, 'rgba(240,180,41,0)');
  ctx.fillStyle = g;
  ctx.beginPath(); ctx.arc(x, y, r * 3.1, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fillStyle = COL.sun; ctx.strokeStyle = COL.sunRim; ctx.lineWidth = 1.4;
  ctx.fill(); ctx.stroke();
  ctx.restore();
  if (name) label(ctx, name, x, y + r + 11, { size: 11.5, color: COL.sunRim, bold: true });
}

/* 惑星（塗りの丸）。col＝天体ごとの色（矢印の色とは別の系統） */
function planetShape(ctx, x, y, r, col, ring) {
  ctx.save();
  if (ring) {                                  /* 土星の環 */
    ctx.strokeStyle = '#c7b184'; ctx.lineWidth = 1.6;
    ctx.beginPath(); ctx.ellipse(x, y, r * 2.0, r * 0.62, -0.34, 0, Math.PI * 2); ctx.stroke();
  }
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fillStyle = col; ctx.strokeStyle = 'rgba(27,31,36,.55)'; ctx.lineWidth = 1.1;
  ctx.fill(); ctx.stroke();
  /* 右上に小さな光（球に見せる） */
  ctx.beginPath(); ctx.arc(x - r * 0.32, y - r * 0.34, r * 0.34, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(255,255,255,.42)'; ctx.fill();
  ctx.restore();
}

/* 地球（自転の目印つき）。ang＝自転角[rad] */
function earthShape(ctx, x, y, r, ang) {
  ctx.save();
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fillStyle = '#4a86c8'; ctx.strokeStyle = '#2a5f96'; ctx.lineWidth = 1.4;
  ctx.fill(); ctx.stroke();
  ctx.save();
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.clip();
  ctx.translate(x, y); ctx.rotate(ang || 0);
  ctx.fillStyle = '#3f8f5f';
  ctx.beginPath(); ctx.ellipse(-r * 0.30, -r * 0.28, r * 0.42, r * 0.30, 0.4, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.ellipse(r * 0.34, r * 0.22, r * 0.36, r * 0.44, -0.3, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.ellipse(r * 0.05, -r * 0.62, r * 0.26, r * 0.18, 0, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
  ctx.restore();
}

/* 彗星（尾は太陽と反対向き） */
function cometShape(ctx, x, y, r, sx, sy) {
  var dx = x - sx, dy = y - sy, L = Math.hypot(dx, dy) || 1;
  var ux = dx / L, uy = dy / L, tail = Math.max(14, Math.min(52, 900 / L));
  ctx.save();
  var g = ctx.createLinearGradient(x, y, x + ux * tail, y + uy * tail);
  g.addColorStop(0, 'rgba(143,163,176,.85)');
  g.addColorStop(1, 'rgba(143,163,176,0)');
  ctx.strokeStyle = g; ctx.lineWidth = r * 2.4; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + ux * tail, y + uy * tail); ctx.stroke();
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fillStyle = '#dfe7ec'; ctx.strokeStyle = '#8fa3b0'; ctx.lineWidth = 1; ctx.fill(); ctx.stroke();
  ctx.restore();
}

/* 楕円軌道の線。cx,cy＝焦点（太陽）の画面座標、sc＝1単位あたりの px、
   rot＝近日点方向の画面上の角[rad]、dash＝破線のパターン */
function orbitPath(ctx, cx, cy, a, e, sc, rot, col, dash, lw, retro) {
  var b = a * Math.sqrt(Math.max(0, 1 - e * e)), c = a * e, i;
  ctx.save();
  ctx.strokeStyle = col || COL.orbit;
  ctx.lineWidth = lw || 1.4;
  if (dash && dash.length) ctx.setLineDash(dash);
  ctx.beginPath();
  for (i = 0; i <= 240; i++) {
    var E = TAU * i / 240;
    var px = a * (Math.cos(E) - e), py = b * Math.sin(E) * (retro ? -1 : 1);
    var qx = px * Math.cos(rot) - py * Math.sin(rot);
    var qy = px * Math.sin(rot) + py * Math.cos(rot);
    var sxp = cx + qx * sc, syp = cy - qy * sc;
    if (i === 0) ctx.moveTo(sxp, syp); else ctx.lineTo(sxp, syp);
  }
  ctx.closePath();
  ctx.stroke();
  ctx.restore();
  return { b: b, c: c };
}

/* 扇形（面積速度）。太陽を頂点に、軌道上の2点までを塗る */
function sectorFill(ctx, cx, cy, pts, col, alpha) {
  if (!pts || pts.length < 2) return;
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(cx, cy);
  for (var i = 0; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
  ctx.closePath();
  ctx.fillStyle = fade(col, alpha === undefined ? 0.30 : alpha);
  ctx.fill();
  ctx.strokeStyle = col; ctx.lineWidth = 1.6; ctx.stroke();
  ctx.restore();
}

/* 星空の点（背景）。同じ種から必ず同じ位置に出す（テストの再現性のため） */
function starField(ctx, x0, y0, w, h, n, seed) {
  var s = seed || 12345, i;
  ctx.save();
  for (i = 0; i < n; i++) {
    s = (s * 1103515245 + 12345) % 2147483648;
    var px = x0 + (s / 2147483648) * w;
    s = (s * 1103515245 + 12345) % 2147483648;
    var py = y0 + (s / 2147483648) * h;
    s = (s * 1103515245 + 12345) % 2147483648;
    var r = 0.6 + (s / 2147483648) * 1.1;
    ctx.fillStyle = 'rgba(255,255,255,' + (0.35 + r * 0.28).toFixed(2) + ')';
    ctx.beginPath(); ctx.arc(px, py, r, 0, Math.PI * 2); ctx.fill();
  }
  ctx.restore();
}

/* 破線の直線（寸法・補助線） */
function dashLine(ctx, x1, y1, x2, y2, col, dash, lw) {
  ctx.save();
  ctx.strokeStyle = col || COL.dim; ctx.lineWidth = lw || 1.2;
  ctx.setLineDash(dash || [5, 4]);
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
  ctx.restore();
}
