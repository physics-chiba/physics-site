#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""各シミュレーションのスクリーンショットを撮る（自分の目で見て確かめるため）。"""
import pathlib
import sys

from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
PAGE = ROOT / "dist" / "celestial-mechanics.html"
OUT = ROOT / "shots"
OUT.mkdir(exist_ok=True)

JOBS = [
    ("m1-1a", "window.TEST.goto('m1-1');window.TEST.set({t:1.6})"),
    ("m1-1b", "window.TEST.goto('m1-1');window.TEST.set({opts:{view:'inner',pick:'mars'},t:2.4})"),
    ("m1-1c", "window.TEST.goto('m1-1');window.TEST.set({opts:{view:'all',pick:'halley'},t:60})"),
    ("m1-6a", "window.TEST.goto('m1-6');window.TEST.set({t:3.2})"),
    ("m1-6b", "window.TEST.goto('m1-6');window.TEST.set({t:4.4})"),
    ("m1-2a", "window.TEST.goto('m1-2');window.TEST.set({opts:{showV:true,showR:true},t:0.35})"),
    ("m1-2b", "window.TEST.goto('m1-2');window.TEST.set({vars:{e:0},opts:{showV:true,showR:true},t:0.4})"),
    ("m1-2c", "window.TEST.goto('m1-2');window.TEST.set({opts:{sys:'earth',showV:true,showR:true},t:9000})"),
    ("m1-3a", "window.TEST.goto('m1-3');window.TEST.set({opts:{showV:true,showR:true},t:0.06})"),
    ("m1-3b", "window.TEST.goto('m1-3');window.TEST.set({vars:{e:0.7},opts:{showV:true,showR:true},t:0.9})"),
    ("m1-4a", "window.TEST.goto('m1-4');window.TEST.set({t:9})"),
    ("m1-4b", "window.TEST.goto('m1-4');window.TEST.set({opts:{logmode:false},t:22})"),
    ("m1-5a", "window.TEST.goto('m1-5');window.TEST.set({opts:{showV:true,showR:true},t:1200})"),
    ("m1-5b", "window.TEST.goto('m1-5');window.TEST.set({vars:{k:1.24},opts:{showV:true,showR:true,showS:true},t:9000})"),
    ("m2-3e", "window.TEST.goto('m2-3');window.TEST.set({vars:{k3:1.8},t:6000})"),
    ("m1-5c", "window.TEST.goto('m1-5');window.TEST.set({vars:{k:1.30},opts:{showV:true,showR:true},t:20000})"),
    ("m1-2law", "window.TEST.goto('m1-2');window.TEST.set({vars:{e:0},t:0.3})"),
    ("m2-2a", "window.TEST.goto('m2-2');window.TEST.set({t:300})"),
    ("m2-2b", "window.TEST.goto('m2-2');window.TEST.set({vars:{k2:1,th0:90},opts:{showFW:true,showVW:true},t:2000})"),
    ("m2-2c", "window.TEST.goto('m2-2');window.TEST.act(1);window.TEST.set({vars:{Ms:1.5,k2:1.4,th0:60,r02:14000},opts:{showFW:true,showVW:true},t:1500})"),
    ("m2-2d", "window.TEST.goto('m2-2');window.TEST.set({vars:{Ms:1.0,k2:2,th0:90},t:900})"),
    ("m2-2e", "window.TEST.goto('m2-2');window.TEST.act(0);window.TEST.set({vars:{Ms:0.5,k2:0.4,th0:0,r02:14000},t:600})"),
    ("m1-4e", "window.TEST.goto('m1-4');window.TEST.set({opts:{sys14:'earth'},t:900000})"),
    ("m2-1a", "window.TEST.goto('m2-1');window.TEST.set({opts:{showF:true,showV:true},t:0.3})"),
    ("m2-1b", "window.TEST.goto('m2-1');window.TEST.set({vars:{mi:2},opts:{showF:true,showV:true},t:20})"),
    ("m2-1c", "window.TEST.goto('m2-1');window.TEST.set({vars:{mi:4},opts:{showF:true,showV:true},t:0.5})"),
    ("m2-3a", "window.TEST.goto('m2-3');window.TEST.set({t:1500})"),
    ("m2-3b", "window.TEST.goto('m2-3');window.TEST.set({vars:{k3:1.4},t:2000})"),
    ("m2-3c", "window.TEST.goto('m2-3');window.TEST.set({vars:{k3:2.0},t:2500})"),
    ("m2-3d", "window.TEST.goto('m2-3');window.TEST.set({vars:{k3:2.4},t:2500})"),
    ("m2-3f", "window.TEST.goto('m2-3');window.TEST.set({vars:{k3:2.2},opts:{showF:true,showV:true},t:5400})"),
    ("m2-3g", "window.TEST.goto('m2-3');window.TEST.set({vars:{k3:2.2},opts:{showF:true,showV:true},t:16000})"),
    ("m1-3cmp", "window.TEST.goto('m1-3');window.TEST.set({opts:{cmp:true,showV:true,showR:true},t:0.5})"),
    ("m1-2big", "window.TEST.goto('m1-2');window.TEST.set({vars:{aS:2.4,e:0.5},opts:{sys:'sun',showV:true,showR:true},t:0.5})"),
    ("m1-2sml", "window.TEST.goto('m1-2');window.TEST.set({vars:{aS:1.4,e:0.5},opts:{sys:'sun',showV:true,showR:true},t:0.5})"),
    ("m2-4a", "window.TEST.goto('m2-4');window.TEST.set({opts:{showF:true,showV:true,showR:true},t:9000})"),
    ("m2-4b", "window.TEST.goto('m2-4');window.TEST.set({vars:{h4:35800},opts:{showV:true,showR:true},t:40000})"),
    ("m2-5a", "window.TEST.goto('m2-5');window.TEST.set({opts:{showV:true},t:0})"),
    ("m2-5b", "window.TEST.goto('m2-5');window.TEST.set({opts:{showV:true},t:1})"),
    ("m2-5c", "window.TEST.goto('m2-5');window.TEST.set({opts:{obs:'sun',showV:true},t:1})"),
    ("m3-1a", "window.TEST.goto('m3-1');window.TEST.set({t:900})"),
    ("m3-1b", "window.TEST.goto('m3-1');window.TEST.set({vars:{eq:0.375},t:6000})"),
    ("m3-1c", "window.TEST.goto('m3-1');window.TEST.set({vars:{eq:0.125},t:1200})"),
    ("m3-1d", "window.TEST.goto('m3-1');window.TEST.set({vars:{eq:0.5},t:4000})"),
    ("m3-2a", "window.TEST.goto('m3-2');window.TEST.set({t:1200})"),
    ("m3-2b", "window.TEST.goto('m3-2');window.TEST.set({vars:{x0R:3.0},t:2600})"),
    ("m3-2c", "window.TEST.goto('m3-2');window.TEST.set({vars:{x0R:0.5},t:600})"),
    ("m3-3a", "window.TEST.goto('m3-3');window.TEST.set({t:400000})"),
    ("m3-3b", "window.TEST.goto('m3-3');window.TEST.set({vars:{mk:20},t:900000})"),
    ("m4-2a", "window.TEST.goto('m4-2');window.TEST.set({t:1.5})"),
    ("m4-2c", "window.TEST.goto('m4-2');window.TEST.set({vars:{arm:0.85},t:0.35})"),
    ("m4-2b", "window.TEST.goto('m4-2');window.TEST.set({vars:{arm:0.35},t:1.0})"),
    ("m4-5a", "window.TEST.goto('m4-5');window.TEST.set({vars:{span:1},t:25000})"),
    ("m4-5b", "window.TEST.goto('m4-5');window.TEST.set({vars:{span:2},t:900000})"),
    ("m4-5c", "window.TEST.goto('m4-5');window.TEST.set({vars:{span:3},t:12000000})"),
    # 「毎日同じ時間に観測」（span 4）。1日きざみに丸まっているか目で見る
    ("m4-5d", "window.TEST.goto('m4-5');window.TEST.set({vars:{span:4},t:260000})"),
    ("m4-5e", "window.TEST.goto('m4-5');window.TEST.set({vars:{span:4},opts:{showO:false},t:600000})"),
    # 下の段（3次元）。既定は真横、ボタンでななめ・真上
    ("m4-5f", "window.TEST.goto('m4-5');window.TEST.set({vars:{span:1},t:25000});"
              "st.sims['m4-5'].cam={az:-32,el:26,zoom:1}"),
    ("m4-5g", "window.TEST.goto('m4-5');window.TEST.set({vars:{span:1},t:25000});"
              "st.sims['m4-5'].cam={az:0,el:88,zoom:1}"),
    ("m4-5h", "window.TEST.goto('m4-5');window.TEST.set({vars:{span:1},t:25000});"
              "st.sims['m4-5'].o.zoom=6"),
    ("m4-3a", "window.TEST.goto('m4-3');window.TEST.set({t:2})"),
    ("m4-3b", "window.TEST.goto('m4-3');window.TEST.set({t:38})"),
    ("m4-4a", "window.TEST.goto('m4-4');window.TEST.set({vars:{topic:1},t:0.0002})"),
    ("m4-4b", "window.TEST.goto('m4-4');window.TEST.set({vars:{topic:2},t:1.0})"),
    ("m4-4c", "window.TEST.goto('m4-4');window.TEST.set({vars:{topic:3},t:160})"),
]

WIDTH = int(sys.argv[1]) if len(sys.argv) > 1 else 1280

with sync_playwright() as pw:
    b = pw.chromium.launch()
    p = b.new_page(viewport={"width": WIDTH, "height": 1000})
    p.goto(PAGE.as_uri())
    p.wait_for_timeout(800)
    for name, js in JOBS:
        p.evaluate("()=>window.TEST.openAll()")
        p.evaluate("(j)=>{eval(j)}", js)
        # t を「割合」で指定したもの（0〜1）は tEnd 倍に直す
        p.evaluate("()=>{const d=DEFS[st.cur],s=st.sims[st.cur];"
                   "if(s.t<=1 && d.tEnd(V(s))>10){s.t=s.t*d.tEnd(V(s));renderActive();}}")
        p.wait_for_timeout(320)
        el = p.query_selector("#simhost")
        el.screenshot(path=str(OUT / f"{name}.png"))
        print("shot:", name)
    b.close()
