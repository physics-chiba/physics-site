#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""簡易チェック：全シミュレーションを開いてエラーが出ないか見る。"""
import json
import pathlib
import sys

from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
PAGE = ROOT / "dist" / "celestial-mechanics.html"

errors = []
external = []
console = []

with sync_playwright() as pw:
    b = pw.chromium.launch()
    p = b.new_page(viewport={"width": 1280, "height": 950})
    p.on("pageerror", lambda e: errors.append(str(e)))
    p.on("console", lambda m: console.append(m.type + ":" + m.text) if m.type == "error" else None)
    p.on("request", lambda r: None if r.url.startswith("file:") else external.append(r.url))
    p.goto(PAGE.as_uri())
    p.wait_for_timeout(900)
    sims = p.evaluate("()=>window.TEST.sims()")
    print("sims:", sims)
    print("check:", json.dumps(p.evaluate("()=>window.TEST.check()"), ensure_ascii=False, indent=1))
    for s in sims:
        p.evaluate("(id)=>window.TEST.goto(id)", s)
        p.wait_for_timeout(200)
        p.evaluate("()=>window.TEST.openAll()")
        p.wait_for_timeout(150)
        n = len(p.evaluate("()=>window.TEST.readout()"))
        res = p.evaluate("()=>window.TEST.result()")
        print(s, "ok, readout rows:", n, "result items:", len(res["items"]) if res else 0)
        # 時間を進めた状態でも描く
        T = p.evaluate("()=>{const d=DEFS[st.cur];return d.tEnd(V(st.sims[st.cur]));}")
        p.evaluate("(t)=>window.TEST.set({t:t})", T * 0.37)
        p.wait_for_timeout(150)
    b.close()

print("pageerrors:", errors)
print("console errors:", console)
print("external:", external)
sys.exit(1 if (errors or external or console) else 0)
