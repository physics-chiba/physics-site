#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""自動テスト。

    python3 test/run_test.py 1
    python3 test/run_test.py 2

を続けて実行し、test/result_1.json と result_2.json が **完全一致** することを確かめる。

チェックするもの
  * ページエラー 0 / コンソールエラー 0
  * 外部リクエスト 0（file:// 以外へ 1 本も飛ばない ＝ 完全オフライン）
  * 物理の検算（ケプラーの3法則・面積速度・第一/第二宇宙速度・静止軌道・力学的エネルギー）
  * 全シミュレーションの既定値・読み出し・計算結果の帯・グラフの開閉
  * オレンジの状況ボタン（押すと状態が変わり、いまの状態のボタンが濃くなる）
  * ハッシュ URL で直接開けること
  * グラフのドラッグ（移動・軸の拡大縮小・ホイール・ダブルクリック）
  * レイアウトの安定（変数を変えて戻すと位置が同じ）
  * 横幅 320〜1440 px で横スクロールが出ない（★スマホ幅では全シムを回して確かめる★）
  * 入試モードの解説の中のリンク（@@r:…@@）の飛び先が、計算結果に実在すること
"""
import json
import pathlib
import sys

from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
PAGE = ROOT / "dist" / "celestial-mechanics.html"
RUN = sys.argv[1] if len(sys.argv) > 1 else "1"
OUT = ROOT / "test" / f"result_{RUN}.json"

# 全シミュレーションの id（画面の並びの順）。新しいシムを足したら、ここにも足すこと。
SIM_IDS = ["m1-1", "m1-2", "m1-3", "m1-4", "m1-5", "m1-6",
           "m2-2", "m2-3", "m2-4", "m4-2", "m2-1", "m4-5",
           "m3-1", "m3-2", "m3-3", "m4-3", "m2-5", "m4-4"]

results = {}
errors = []
external = []
console_errors = []


# ★アクセス数のカウント（GoatCounter）だけは、外部リクエストとして数えない★
#   physics-site の全ページに入れてある共通パーツ（gc.zgo.at）。
#   公開先（https）では動くが、file:// で開くテストでは必ず読みこみに失敗する。
#   ページの中身とは関係のない失敗なので、ここだけ除いて数える。
#   ★これ以外の外部リクエストは 0 でなければならない（教材は完全オフラインで動くこと）★
def counter_noise(u):
    return ("gc.zgo.at" in u) or ("goatcounter" in u)


def box(page):
    return page.evaluate(
        "()=>[...document.querySelectorAll('h1,h2,canvas,.card,.simtitle,.resbar')]"
        ".map(e=>{const r=e.getBoundingClientRect();"
        "return [Math.round(r.x),Math.round(r.y),Math.round(r.width)].join(',')})")


def main():
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        page = browser.new_page(viewport={"width": 1280, "height": 950})
        page.on("pageerror", lambda e: errors.append(str(e)))
        page.on("console", lambda m: console_errors.append(m.text)
                if (m.type == "error" and not counter_noise(m.text)
                    and not counter_noise((m.location or {}).get("url", ""))) else None)
        page.on("request", lambda r: None
                if (r.url.startswith("file:") or counter_noise(r.url))
                else external.append(r.url))
        page.goto(PAGE.as_uri())
        page.wait_for_timeout(800)
        page.evaluate("()=>window.TEST.pause()")

        # --- 1. 物理の検算（UI によらない） ---
        results["physics"] = page.evaluate("()=>window.TEST.check()")

        # --- 2. 全シミュレーションの既定値・読み出し・帯・グラフの開閉 ---
        sims = page.evaluate("()=>window.TEST.sims()")
        results["sim_list"] = sims
        per = {}
        for sid in sims:
            page.goto(PAGE.as_uri() + "#" + sid)
            page.wait_for_timeout(320)
            page.evaluate("()=>window.TEST.pause()")
            per[sid] = {
                "state": page.evaluate("()=>window.TEST.state()"),
                "open": page.evaluate("()=>window.TEST.graphsOpen()"),
                "readout_t0": page.evaluate("()=>window.TEST.readout()"),
                "result_t0": page.evaluate("()=>window.TEST.result()"),
                "acts_t0": page.evaluate("()=>window.TEST.acts()"),
                "formulas": page.evaluate("()=>window.TEST.formulas()"),
                "title": page.evaluate("()=>document.querySelector('.simtitle').textContent"),
            }
            # 時間を 37% 進めた状態
            T = page.evaluate("()=>DEFS[st.cur].tEnd(V(st.sims[st.cur]))")
            page.evaluate("(t)=>window.TEST.set({t:t})", T * 0.37)
            page.wait_for_timeout(160)
            per[sid]["readout_t37"] = page.evaluate("()=>window.TEST.readout()")
            per[sid]["result_t37"] = page.evaluate("()=>window.TEST.result()")
            # まとめて開く → もう一度押すともどる
            per[sid]["open_all"] = page.evaluate("()=>window.TEST.openAll()")
            per[sid]["open_again"] = page.evaluate("()=>window.TEST.openAll()")
        results["per_sim"] = per

        # --- 3. オレンジの状況ボタン ---
        acts = {}
        for sid, idx in [("m1-1", 0), ("m1-1", 1),
                         ("m2-3", 2), ("m2-3", 3), ("m2-5", 0), ("m2-5", 1)]:
            page.goto(PAGE.as_uri() + "#" + sid)
            page.wait_for_timeout(300)
            page.evaluate("()=>window.TEST.pause()")
            before = page.evaluate("()=>window.TEST.acts()")
            page.evaluate("(i)=>window.TEST.act(i)", idx)
            page.wait_for_timeout(280)
            page.evaluate("()=>window.TEST.pause()")
            acts[sid + "_" + str(idx)] = {
                "before": before,
                "after": page.evaluate("()=>window.TEST.acts()"),
                "state": page.evaluate("()=>window.TEST.state()"),
                "result": page.evaluate("()=>window.TEST.result()"),
            }
        results["actions"] = acts

        # --- 3b. 図の左上の「主役のボタン」 ---
        tacts = {}
        for sid, idx in [("m1-2", 0), ("m1-2", 1), ("m1-3", 0), ("m1-5", 0), ("m1-5", 1),
                         ("m2-2", 0), ("m2-2", 1), ("m2-2", 2),
                         ("m2-1", 0), ("m2-3", 0), ("m2-3", 1), ("m2-4", 1),
                         ("m3-1", 1), ("m3-1", 2), ("m3-1", 3),
                         ("m3-2", 0), ("m3-2", 2), ("m3-3", 1)]:
            page.goto(PAGE.as_uri() + "#" + sid)
            page.wait_for_timeout(300)
            page.evaluate("()=>window.TEST.pause()")
            before = page.evaluate("()=>window.TEST.acts()")
            page.evaluate("(i)=>window.TEST.tact(i)", idx)
            page.wait_for_timeout(280)
            page.evaluate("()=>window.TEST.pause()")
            # play:true のボタンは押すと再生も始まるので、読む前に止めて時刻をそろえる
            page.evaluate("()=>window.TEST.pause()")
            page.wait_for_timeout(80)
            tacts[sid + "_t" + str(idx)] = {
                "before": before,
                "after": page.evaluate("()=>window.TEST.acts()"),
                "state": page.evaluate("()=>window.TEST.state()"),
                "result": page.evaluate("()=>window.TEST.result()"),
            }
        results["top_actions"] = tacts

        # --- 3b-2. 「面積速度を比較」がトグルとして働くか（2回押すと off にもどる） ---
        page.goto(PAGE.as_uri() + "#m1-3")
        page.wait_for_timeout(300)
        page.evaluate("()=>window.TEST.pause()")
        tg = [page.evaluate("()=>window.TEST.state().o.cmp"),
              page.evaluate("()=>document.getElementById('tact_0').textContent")]
        for _ in range(2):
            page.evaluate("()=>window.TEST.tact(0)")
            page.wait_for_timeout(200)
            tg.append(page.evaluate("()=>window.TEST.state().o.cmp"))
            tg.append(page.evaluate("()=>document.getElementById('tact_0').textContent"))
        results["cmp_toggle"] = tg

        # --- 3b-2b. 「描画対象」の共通切りかえ（1-1〜1-4 で1つの値を共有する） ---
        #  ★タブを移っても選んだままになっていること★ が、このテストの主目的。
        #  法則の帯とタイトルの文も「人工衛星は地球を…」に変わることを確かめる。
        page.goto(PAGE.as_uri() + "#m1-2")
        page.reload()
        page.wait_for_timeout(500)
        page.evaluate("()=>window.TEST.pause()")
        sysc = {"init": page.evaluate("()=>st.sysKind"),
                "title_sun": page.evaluate("()=>document.querySelector('.simtitle').textContent.trim()")}
        page.click('[data-sys="earth"]')
        page.wait_for_timeout(300)
        page.evaluate("()=>window.TEST.pause()")
        sysc["after_click"] = page.evaluate("()=>st.sysKind")
        sysc["title_earth"] = page.evaluate("()=>document.querySelector('.simtitle').textContent.trim()")
        keep = {}
        for sid in ["m1-3", "m1-4", "m1-5", "m1-2"]:
            page.evaluate("(id)=>window.TEST.goto(id)", sid)
            page.wait_for_timeout(250)
            keep[sid] = [page.evaluate("()=>st.sysKind"),
                         page.evaluate("(id)=>V(st.sims[id]).sys", sid),
                         page.evaluate("()=>[...document.querySelectorAll('.systog button.on')]"
                                       ".map(e=>e.textContent).join('')")]
        sysc["keep"] = keep
        page.click('[data-sys="sun"]')
        page.wait_for_timeout(300)
        page.evaluate("()=>window.TEST.pause()")
        sysc["back_to_sun"] = page.evaluate("()=>st.sysKind")
        results["sys_toggle"] = sysc

        # --- 3b-3. 入試モードの解説の中の「動かせる部品」が、ちゃんとつながっているか ---
        #  ・@@r:…@@ の飛び先が「計算結果を表示」に本当にあるか
        #  ・@@v:…@@ のスライドバー、@@b:…@@ のボタンの数
        probs = {}
        for sid in ["m3-1", "m3-2", "m3-3"]:
            # ★ハッシュだけ変えても読み直されない★ 前のテストで変えた変数が残るので、
            #   かならず reload して「はじめの設定」にもどしてから測ること。
            page.goto(PAGE.as_uri() + "#" + sid)
            page.reload()
            page.wait_for_timeout(500)
            page.evaluate("()=>window.TEST.pause()")
            probs[sid] = page.evaluate("""()=>{
              var links=[...document.querySelectorAll('.card.probs .reslink')]
                .map(e=>e.getAttribute('data-reskey'));
              var keys=[...document.querySelectorAll('.resbar .ritem')]
                .map(e=>e.getAttribute('data-rk'));
              return {
                nsetup: document.querySelectorAll('.card.probs .psetup').length,
                nvar: document.querySelectorAll('.card.probs .pvar').length,
                nact: document.querySelectorAll('.card.probs .pact').length,
                nlink: links.length,
                missing: links.filter(k=>!keys.some(x=>x.indexOf(k)>=0))
              };
            }""")
        results["probs"] = probs

        # --- 3c. グラフの上の切りかえ（1-4 の 両対数／両方リニア） ---
        page.goto(PAGE.as_uri() + "#m1-4")
        page.wait_for_timeout(350)
        page.evaluate("()=>window.TEST.pause()")
        gsw = {"before": page.evaluate("()=>window.TEST.state().o.logmode")}
        page.click('[data-gsw="logmode"][data-gswv="lin"]')
        page.wait_for_timeout(300)
        gsw["after"] = page.evaluate("()=>window.TEST.state().o.logmode")
        gsw["map_lin"] = page.evaluate('()=>window.TEST.graphMap("ta")')
        page.click('[data-gsw="logmode"][data-gswv="log"]')
        page.wait_for_timeout(300)
        gsw["back"] = page.evaluate("()=>window.TEST.state().o.logmode")
        results["graph_switch"] = gsw

        # --- 3d. 「面積速度を見る」チェックボックス（1-5 の誘導） ---
        page.goto(PAGE.as_uri() + "#m1-5")
        page.wait_for_timeout(350)
        page.evaluate("()=>window.TEST.pause()")
        vf = {"before": page.evaluate("()=>window.TEST.state().o.showS"),
              "focus_before": page.evaluate("()=>!!document.querySelector('.opts label.visfocus')")}
        page.click('[data-vis="showS"]')
        page.wait_for_timeout(300)
        vf["after"] = page.evaluate("()=>window.TEST.state().o.showS")
        vf["focus_after"] = page.evaluate("()=>!!document.querySelector('.opts label.visfocus')")
        results["vis_focus"] = vf

        # --- 4. 天体をクリックして選ぶ（1-1） ---
        page.goto(PAGE.as_uri() + "#m1-1")
        page.wait_for_timeout(350)
        page.evaluate("()=>window.TEST.pause()")
        # まず「火星まで」の表示・地球を選んだ状態にそろえてから、火星をクリックする
        page.evaluate("()=>window.TEST.set({opts:{view:'inner',pick:'earth'}})")
        page.wait_for_timeout(250)
        pick = {"init": page.evaluate("()=>window.TEST.state().o.pick")}
        pick["dots"] = page.evaluate(
            "()=>st.sims['m1-1'].ui.dots.map(d=>d.id+':'+Math.round(d.px)+','+Math.round(d.py))")
        cv = page.query_selector("#mainCv")
        cv.scroll_into_view_if_needed()
        page.wait_for_timeout(150)
        bb = cv.bounding_box()
        dot = page.evaluate("()=>{const d=st.sims['m1-1'].ui.dots.find(x=>x.id==='mars');"
                            "const c=document.getElementById('mainCv');"
                            "return {x:d.px/560*c.getBoundingClientRect().width,"
                            "y:d.py/424*c.getBoundingClientRect().height};}")
        page.mouse.click(bb["x"] + dot["x"], bb["y"] + dot["y"])
        page.wait_for_timeout(250)
        pick["after_click"] = page.evaluate("()=>window.TEST.state().o.pick")
        pick["readout"] = page.evaluate("()=>window.TEST.readout()")
        results["pick_planet"] = pick

        # --- 5. グラフのドラッグ（移動・軸の拡大縮小・ホイール・ダブルクリック） ---
        page.goto(PAGE.as_uri() + "#m1-2")
        page.wait_for_timeout(400)
        page.evaluate("()=>window.TEST.pause()")
        page.evaluate("()=>window.TEST.set({})")
        # 1-2 の r-t 図は初期状態でたたんであるので、まず開く
        page.evaluate("()=>window.TEST.openAll()")
        page.wait_for_timeout(200)
        gcv = page.query_selector("#gc_r")
        gcv.scroll_into_view_if_needed()
        page.wait_for_timeout(200)
        bb = gcv.bounding_box()
        drag = {}

        def gmap():
            return page.evaluate('()=>window.TEST.graphMap("r")')

        drag["auto"] = gmap()
        page.mouse.move(bb["x"] + bb["width"] * 0.6, bb["y"] + bb["height"] * 0.5)
        page.mouse.down()
        page.mouse.move(bb["x"] + bb["width"] * 0.4, bb["y"] + bb["height"] * 0.6, steps=5)
        page.mouse.up()
        page.wait_for_timeout(180)
        drag["pan"] = gmap()
        page.dblclick("#gc_r"); page.wait_for_timeout(150)
        page.mouse.move(bb["x"] + bb["width"] * 0.5, bb["y"] + bb["height"] * 0.94)
        page.mouse.down()
        page.mouse.move(bb["x"] + bb["width"] * 0.8, bb["y"] + bb["height"] * 0.94, steps=5)
        page.mouse.up()
        page.wait_for_timeout(180)
        drag["scale_x"] = gmap()
        page.dblclick("#gc_r"); page.wait_for_timeout(150)
        page.mouse.move(bb["x"] + bb["width"] * 0.5, bb["y"] + bb["height"] * 0.5)
        page.mouse.wheel(0, -300)
        page.wait_for_timeout(220)
        drag["wheel"] = gmap()
        page.dblclick("#gc_r"); page.wait_for_timeout(200)
        drag["reset"] = gmap()
        results["graph_drag"] = drag

        # --- 6. ハッシュ URL で直接開ける（画面下の URL 欄は廃止したので、location.hash で見る） ---
        hashes = {}
        for sid in sims:
            page.goto(PAGE.as_uri() + "#" + sid)
            page.wait_for_timeout(320)
            page.evaluate("()=>window.TEST.pause()")
            hashes[sid] = page.evaluate(
                "()=>({sim:window.TEST.state().sim,"
                "title:document.querySelector('.simtitle').textContent,"
                "hash:location.hash.slice(1)})")
        # タブを切りかえると URL のハッシュも変わる
        page.goto(PAGE.as_uri() + "#m1-1")
        page.wait_for_timeout(300)
        page.evaluate("()=>window.TEST.pause()")
        page.evaluate("()=>window.TEST.goto('m1-4')")
        page.wait_for_timeout(250)
        hashes["_after_tab_click"] = page.evaluate("()=>location.hash")
        results["hash_open"] = hashes

        # --- 6b. 矢印の凡例は、そのシムに関係あるものだけ出ているか ---
        lg = {}
        for sid in sims:
            page.goto(PAGE.as_uri() + "#" + sid)
            page.wait_for_timeout(280)
            page.evaluate("()=>window.TEST.pause()")
            lg[sid] = page.evaluate(
                "()=>[...document.querySelectorAll('#legend .lg')]"
                ".filter(e=>e.style.display!=='none').map(e=>e.getAttribute('data-lk')).join(',')")
        results["legend_keys"] = lg

        # --- 7. レイアウトの安定 ---
        page.goto(PAGE.as_uri() + "#m1-2")
        page.wait_for_timeout(420)
        page.evaluate("()=>window.TEST.pause()")
        before = box(page)
        page.evaluate("()=>window.TEST.set({vars:{e:0.8},t:0.4})")
        page.wait_for_timeout(180)
        page.evaluate("()=>window.TEST.set({vars:{e:0.5},t:0})")
        page.wait_for_timeout(180)
        results["layout_stable"] = (before == box(page))

        # --- 8. 横スクロールが出ない ---
        widths = {}
        for w in (320, 360, 390, 768, 1024, 1360, 1440):
            page.set_viewport_size({"width": w, "height": 800})
            page.wait_for_timeout(300)
            widths[str(w)] = page.evaluate(
                "()=>document.documentElement.scrollWidth>window.innerWidth+1")

        # --- 8b. ★スマホの幅で「全シム」に横スクロールが出ない★ ---
        #  （8 は m1-2 しか見ていなかったので、2-1・3-1・3-2・3-3 のはみ出しに
        #    ずっと気づけなかった。かならず全シムを回すこと。）
        narrow = {}
        for w in (320, 390):
            page.set_viewport_size({"width": w, "height": 800})
            page.wait_for_timeout(250)
            ng = []
            for sid in SIM_IDS:
                page.evaluate("(i)=>window.TEST.goto(i)", sid)
                page.wait_for_timeout(280)
                if page.evaluate("()=>document.documentElement.scrollWidth>window.innerWidth+1"):
                    ng.append(sid)
            narrow[str(w)] = ng
        results["h_scroll_all"] = narrow
        # 「式を拡大」中も横スクロールなし
        page.evaluate("()=>toggleBigFml()")
        big = {}
        for w in (320, 768, 1440):
            page.set_viewport_size({"width": w, "height": 800})
            page.wait_for_timeout(300)
            big[str(w)] = page.evaluate(
                "()=>document.documentElement.scrollWidth>window.innerWidth+1")
        page.evaluate("()=>toggleBigFml()")
        results["h_scroll"] = widths
        results["h_scroll_bigfml"] = big

        browser.close()

    results["errors"] = errors
    results["console_errors"] = console_errors
    results["external"] = external
    OUT.write_text(json.dumps(results, ensure_ascii=False, indent=1), encoding="utf-8")

    print(f"--- run {RUN} ---")
    print("pageerrors:", len(errors), " console errors:", len(console_errors),
          " external requests:", len(external))
    print("layout_stable:", results["layout_stable"])
    print("h_scroll:", results["h_scroll"])
    print("h_scroll(式を拡大):", results["h_scroll_bigfml"])
    print("h_scroll(スマホ・全シム):", results["h_scroll_all"])
    print("hash_open:", {k: v.get("sim") for k, v in results["hash_open"].items() if isinstance(v, dict) and "sim" in v})
    print("pick_planet:", results["pick_planet"]["init"], "->", results["pick_planet"]["after_click"])
    print("sys_toggle:", json.dumps(results["sys_toggle"], ensure_ascii=False))
    print("physics:", json.dumps(results["physics"], ensure_ascii=False))


if __name__ == "__main__":
    main()
