#!/usr/bin/env node
/* 単一 HTML ビルドスクリプト（mechanical-energy.html）
 * src/ の部品を決まった順に連結して dist/mechanical-energy.html を作る。
 * KaTeX は CSS / JS / フォント(woff2 を base64) をすべて埋め込み、完全オフラインにする。
 * ※ basics-of-motion-on-plane.html の build.js をそのまま受けついでいる。
 */
'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const SRC = path.join(ROOT, 'src');
const OUT = path.join(ROOT, 'dist', 'mechanical-energy.html');
const KATEX = '/home/claude/.npm-global/lib/node_modules/markdownlint-cli2/node_modules/katex/dist';
const KATEX_VER = '0.16.45';

/* この教材で使う字種に必要なものだけ埋め込む */
const FONT_WHITELIST = [
  'KaTeX_Main-Regular', 'KaTeX_Main-Bold', 'KaTeX_Main-Italic',
  'KaTeX_Math-Italic', 'KaTeX_Math-BoldItalic',
  'KaTeX_Size1-Regular', 'KaTeX_Size2-Regular', 'KaTeX_Size3-Regular', 'KaTeX_Size4-Regular',
  'KaTeX_AMS-Regular'
];

function read(p) { return fs.readFileSync(p, 'utf8'); }

/** KaTeX の CSS を、@font-face ブロック単位で走査して差し替える（一括正規表現置換はしない） */
function inlineKatexCss() {
  const css = read(path.join(KATEX, 'katex.min.css'));
  const out = [];
  let i = 0, kept = 0, dropped = 0;
  while (i < css.length) {
    const at = css.indexOf('@font-face{', i);
    if (at === -1) { out.push(css.slice(i)); break; }
    out.push(css.slice(i, at));
    const end = css.indexOf('}', at);
    if (end === -1) { out.push(css.slice(at)); break; }
    const block = css.slice(at, end + 1);
    const face = rewriteFontFace(block);
    if (face) { out.push(face); kept++; } else { dropped++; }
    i = end + 1;
  }
  console.log(`  @font-face: ${kept} 個を埋め込み / ${dropped} 個を除外`);
  return out.join('');
}

function rewriteFontFace(block) {
  const m = block.indexOf('fonts/');
  if (m === -1) return null;
  const tail = block.slice(m + 'fonts/'.length);
  const dot = tail.indexOf('.');
  if (dot === -1) return null;
  const name = tail.slice(0, dot);
  if (FONT_WHITELIST.indexOf(name) === -1) return null;

  const woff2 = path.join(KATEX, 'fonts', name + '.woff2');
  if (!fs.existsSync(woff2)) return null;
  const b64 = fs.readFileSync(woff2).toString('base64');

  const srcAt = block.indexOf('src:');
  if (srcAt === -1) return null;
  const head = block.slice(0, srcAt);
  return head + `src:url(data:font/woff2;base64,${b64}) format("woff2")}`;
}

const JS_FILES = [
  '30_physics.js',
  '40_draw.js',
  '45_defs.js',
  '47_step.js',
  '50_mode1.js',
  '60_mode2.js',
  '70_mode3.js',
  '80_ui.js',
  '90_boot.js'
];

function build() {
  console.log('ビルド開始');
  const katexCss = inlineKatexCss();
  const katexJs = read(path.join(KATEX, 'katex.min.js'));

  const head = read(path.join(SRC, '00_head.html'));
  const style = read(path.join(SRC, '10_style.css'));
  const body = read(path.join(SRC, '20_body.html'));
  const scripts = JS_FILES
    .map(f => `/* ===== ${f} ===== */\n${read(path.join(SRC, f))}`)
    .join('\n');

  const html = `<!DOCTYPE html>
<html lang="ja">
<head>
${head}
<style>
/* ===== KaTeX ${KATEX_VER} (fonts embedded / offline) ===== */
${katexCss}
</style>
<style>
/* ===== 10_style.css ===== */
${style}
</style>
</head>
<body>
${body}
<script>/* ===== KaTeX ${KATEX_VER} ===== */
${katexJs}
</script>
<script>
${scripts}
</script>
<!-- アクセス数のカウント（GoatCounter・Cookieなし） -->
<!-- ★先生が第18回に手で足したもの。ビルドで消えないよう、ここに入れてある。
     このページで唯一の外部通信。test/run_test.py はこのホストだけ通す。 -->
<script data-goatcounter="https://physics-chiba.goatcounter.com/count"
        async src="https://gc.zgo.at/count.js"></script>
</body>
</html>
`;

  fs.mkdirSync(path.dirname(OUT), { recursive: true });
  fs.writeFileSync(OUT, html, 'utf8');
  const kb = (Buffer.byteLength(html) / 1024).toFixed(0);
  console.log(`出力: ${OUT} (${kb} KB)`);
}

build();
