/* 共通の描画部品。canvas の中は 1 書体（FONT）にそろえる。内部解像度は 2 倍。 */
'use strict';
var FONT = '"Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
var COL = {
  force: '#d1352b',   /* 重力・一般の力＝赤 */
  norm: '#7b3fd4',    /* 垂直抗力＝むらさき */
  fric: '#0f8a8a',    /* 摩擦力＝青緑 */
  hand: '#c2367f',    /* 手・ひもの力＝ピンク */
  vel: '#1663b5',     /* 速度＝青の白抜き */
  velx: '#1f7fd4',    /* 速度の水平成分＝明るい青の破線 */
  vely: '#0d8f7a',    /* 速度の鉛直成分＝緑がかった青の破線 */
  acc: '#e07b18',     /* 加速度＝オレンジ */
  comp: '#d1352b',    /* 分力＝もとの力と同じ色の破線 */
  areaNeg: '#7a8794',   /* グラフの「負の面積」「失われたエネルギー」の塗り＝グレー */
  dim: '#1b1f24',     /* 寸法・変位・高さ＝黒の細い破線 */
  /* ▼ このページで足した3色（エネルギー）。力・速度・加速度の色は流用しない。
     色だけでなく線の形でも区別する：K＝実線／U＝破線／E＝太い実線 */
  eK: '#22a465',      /* 運動エネルギー K＝緑 */
  eU: '#63390c',      /* 位置エネルギー U＝茶（弾性力による位置エネルギーは同じ色の点線） */
  eE: '#38475a',      /* 力学的エネルギー E＝濃い青灰 */
  A: '#1663b5',
  B: '#c0392b',
  ink: '#1b1f24',
  sub: '#5b6672',
  grid: '#e2e6ea',
  axis: '#8b949e'
};

/* いま描いている canvas の論理サイズ（ラベルのはみ出しを防ぐのに使う） */
var CVW = 0, CVH = 0, CVID = '';

/* ★このフレームで描いた「文字の場所」と「物体の場所」★
   点のエネルギーの吹きだしを、点の近くで・何にも重ならない場所に置くために使う。
   prep() で空にし、label() / ball() / blockShape() などが自動で足していく。 */
var _txtBox = [], _objBox = [];
function noteBox(arr, x, y, w, h) { arr.push({ x: x, y: y, w: w, h: h }); }

/* ★「仕事の分析」で図の力をクリックできるようにするための当たり判定★（第5回）
   力の矢印につける文字（mg・N・μ'N…）から、その力の key を決める。
   label() が自動で場所を記録するので、シムの draw を書きかえなくてよい。
   ここに無い文字は「クリックできる力」にならない。 */
var FKEY_BY_TEXT = {
  'mg': 'g', 'N': 'N', 'S': 'T',
  "μ'N": 'fr', '弾性力 kx': 'sp', '手の力 F': 'hand', 'F': 'pull'
};
var _forceHit = [];              /* [{key, x, y, w, h}]（prep でリセット） */
/* 地面の下の「吹きだしの帯」の上はし（px）。ptSide:'row' のシムが ptRow() で教える。 */
var _ptRowY = null;
function ptRow(y) { _ptRowY = y; }
var _lastFArrow = null;          /* 直前に描いた「力の矢印」（文字と合わせて当たり判定にする） */
function forceHits() { return _forceHit; }
function noteForceHit(key, left, top, w, h) {
  var x1 = left - 10, y1 = top - 8, x2 = left + w + 10, y2 = top + h + 8;
  if (_lastFArrow) {
    x1 = Math.min(x1, _lastFArrow.x1 - 7); y1 = Math.min(y1, _lastFArrow.y1 - 7);
    x2 = Math.max(x2, _lastFArrow.x2 + 7); y2 = Math.max(y2, _lastFArrow.y2 + 7);
  }
  _forceHit.push({ key: key, x: x1, y: y1, w: x2 - x1, h: y2 - y1 });
}
function noteObj(x, y, w, h) { noteBox(_objBox, x, y, w, h); }
/* 2つの長方形の重なりの面積（0 なら重なっていない） */
function boxOverlap(a, b) {
  var ox = Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x);
  var oy = Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y);
  return (ox > 0 && oy > 0) ? ox * oy : 0;
}

/* canvas を 2 倍解像度で用意して ctx を返す（論理サイズ w×h で描ける） */
function prep(cv, w, h) {
  CVW = w; CVH = h; CVID = cv.id || '';
  resetArrowOverlap();
  _txtBox.length = 0; _objBox.length = 0;
  _forceHit.length = 0; _lastFArrow = null; _ptRowY = null; _ptMarkAt.length = 0;
  var need = cv.width !== w * 2 || cv.height !== h * 2;
  if (need) { cv.width = w * 2; cv.height = h * 2; cv.style.aspectRatio = w + ' / ' + h; }
  var ctx = cv.getContext('2d');
  ctx.setTransform(2, 0, 0, 2, 0, 0);
  ctx.clearRect(0, 0, w, h);
  ctx.lineJoin = 'round';
  ctx.lineCap = 'butt';
  return ctx;
}

/* ★ベクトル（力・速度・加速度）は「いちばん前面」に描く★（先生の指示・第6回）
   終わりの絵（ゴースト）やとちゅうの姿（midGhost）を、力の矢印のあとに描いていたので
   矢印が隠れてしまった。そこで、ベクトルの矢印と、その名前の文字だけを
   いったん「あとまわしの箱」にためて、ゴーストを描いたあとにまとめて描く。
   ・deferVec(true) … ためはじめる（renderActive が d.draw の前に呼ぶ）
   ・flushVec(ctx)  … たまったものをまとめて描く
       （drawPts がゴーストと midGhost を描いたすぐあと。吹きだしを置く前）
   ためている間も、矢印のずらし（arrowShift）や文字のよけ（avoidSpot）は
   「描くとき」に計算されるので、順番は変わっても結果は正しい。
   ★点の印（A・B・C…）も同じように、あとまわしにする★（第6回の直し）
   ゴーストの物体を印の上に描いてしまい、文字が読めなくなっていた。
   前面のならび順は　ゴースト → 点の印 → ベクトル　。 */
var _defVec = null;
var _defMark = null;
function deferVec(on) { _defVec = on ? [] : null; _defMark = on ? [] : null; }
function flushVec(ctx) {
  var q, i;
  if (_defMark) {                       /* 先に点の印（ベクトルより後ろ） */
    q = _defMark; _defMark = null;
    for (i = 0; i < q.length; i++) q[i]();
  }
  if (!_defVec) return;
  q = _defVec;
  _defVec = null;                       /* 先に外す（flush 中の描画はそのまま描く） */
  for (i = 0; i < q.length; i++) q[i]();
}
/* あとまわしにする矢印の種類と、文字の色 */
var VEC_KIND = { force: 1, comp: 1, vel: 1, velcomp: 1, velx: 1, vely: 1, acc: 1 };
function isVecColor(c) {
  return c === COL.force || c === COL.norm || c === COL.fric || c === COL.hand ||
    c === COL.vel || c === COL.velx || c === COL.vely || c === COL.acc;
}

/* 矢印。kind: force / vel / acc / comp / dim / thin */
/* 力の矢印が同じ作用点で重なったとき、少しだけずらして両方見えるようにする。
   キャンバスを描き直すたびに prep() がリセットする。 */
var _fArrows = [];
function resetArrowOverlap() { _fArrows.length = 0; }
function arrowShift(x1, y1, ux, uy, len, k) {
  var step = 5.5 * k, n = 0, i;
  for (i = 0; i < _fArrows.length; i++) {
    var a = _fArrows[i];
    if (a.cat !== 'F') continue;                                   /* ずらすのは力どうしだけ */
    if (Math.abs(a.ux * uy - a.uy * ux) > 0.25) continue;          /* 平行でなければ関係ない */
    var dPerp = Math.abs((a.x - x1) * uy - (a.y - y1) * ux);       /* 直線どうしのへだたり */
    if (dPerp > 6 * k) continue;
    var t0 = (a.x - x1) * ux + (a.y - y1) * uy;                    /* 相手の始点の射影 */
    var t1 = t0 + a.len * ((a.ux * ux + a.uy * uy >= 0) ? 1 : -1); /* 相手の終点の射影 */
    var lo = Math.min(t0, t1), hi = Math.max(t0, t1);
    if (hi > 1 && lo < len - 1) n++;                               /* 線が重なっている */
  }
  var rec = { x: x1, y: y1, ux: ux, uy: uy, len: len, cat: 'F', color: COL.force };
  _fArrows.push(rec);
  var out = { dx: 0, dy: 0, rec: rec };
  if (n) {
    var sgn = (n % 2) ? 1 : -1;                           /* 右・左・右…と交互にずらす */
    var mag = step * Math.ceil(n / 2);
    out.dx = -uy * mag * sgn; out.dy = ux * mag * sgn;
  }
  return out;
}

/* 同じ長さ（＝同じ大きさ）の力の矢印に、等長の印「｜」をつける。
   1組目は1本、2組目は2本…と本数を変える。d.draw のあとに1回だけ呼ぶ。 */
function drawEqualTicks(ctx) {
  ['F', 'V'].forEach(function (cat) {
    var i, j, groups = [];
    for (i = 0; i < _fArrows.length; i++) {
      var a = _fArrows[i];
      if (a.cat.charAt(0) !== cat) continue;              /* 力は力どうし、速度は速度どうし */
      if (a.len < 19) continue;                           /* 短すぎる矢印には付けない */
      var g = null;
      for (j = 0; j < groups.length; j++) {
        if (Math.abs(groups[j].len - a.len) <= 0.8) { g = groups[j]; break; }
      }
      if (!g) { g = { len: a.len, cat: a.cat, items: [] }; groups.push(g); }
      g.items.push(a);
    }
    var eq = [];
    for (i = 0; i < groups.length; i++) if (groups[i].items.length >= 2) eq.push(groups[i]);
    eq.sort(function (p, q) { return q.len - p.len; });    /* 長い組から 1本・2本・3本 */
    for (i = 0; i < eq.length; i++) {
      var n2 = Math.min(3, i + 1);
      for (j = 0; j < eq[i].items.length; j++) equalTick(ctx, eq[i].items[j], n2);
    }
  });
}
function equalTick(ctx, a, n) {
  /* 矢じりにかからないよう、少し手前（40%くらい）に印をつける */
  var pos = Math.max(6, Math.min(a.len * 0.42, a.len - 13));
  var mx = a.x + a.ux * pos, my = a.y + a.uy * pos;
  var px = -a.uy, py = a.ux, i, d, cx, cy;
  ctx.save();
  ctx.strokeStyle = a.color; ctx.lineWidth = 2.1; ctx.lineCap = 'round'; ctx.setLineDash([]);
  for (i = 0; i < n; i++) {
    d = (i - (n - 1) / 2) * 4.6;
    cx = mx + a.ux * d; cy = my + a.uy * d;
    ctx.beginPath();
    ctx.moveTo(cx - px * 5.6, cy - py * 5.6);
    ctx.lineTo(cx + px * 5.6, cy + py * 5.6);
    ctx.stroke();
  }
  ctx.restore();
}

function arrow(ctx, x1, y1, x2, y2, kind, scale, col) {
  if (_defVec && VEC_KIND[kind]) {
    _defVec.push(function () { arrow(ctx, x1, y1, x2, y2, kind, scale, col); });
    return;
  }
  var dx = x2 - x1, dy = y2 - y1;
  var len = Math.hypot(dx, dy);
  if (len < 1.5) return;
  var k = scale || 1;
  var ux = dx / len, uy = dy / len;
  if (kind === 'force' || kind === 'comp') {              /* 重なったらずらす */
    var sh = arrowShift(x1, y1, ux, uy, len, k);
    x1 += sh.dx; y1 += sh.dy; x2 += sh.dx; y2 += sh.dy;
    sh.rec.x = x1; sh.rec.y = y1;
    sh.rec.color = col || ((kind === 'comp') ? COL.comp : COL.force);
    /* 直後に来る力の名前（label）と合わせて、クリックできる範囲にする */
    if (kind === 'force') {
      _lastFArrow = { x1: Math.min(x1, x2), y1: Math.min(y1, y2),
        x2: Math.max(x1, x2), y2: Math.max(y1, y2) };
    }
  } else if (kind === 'vel' || kind === 'velcomp' || kind === 'velx' || kind === 'vely') {
    /* 速度の矢印も「同じ長さ」の印をつけるために記録する（ずらしはしない） */
    _fArrows.push({
      x: x1, y: y1, ux: ux, uy: uy, len: len, cat: 'V',
      color: (kind === 'velx') ? COL.velx : ((kind === 'vely') ? COL.vely : COL.vel)
    });
  }
  var head = (kind === 'dim' ? 8 : (kind === 'vel' || kind === 'comp' || kind === 'velcomp' || kind === 'velx' || kind === 'vely' ? 10 : 12)) * k;
  if (head > len * 0.8) head = len * 0.8;
  var bx = x2 - ux * head, by = y2 - uy * head;

  ctx.save();
  ctx.lineJoin = 'round';
  var FC = col || COL.force;                 /* 力の色（種類ごとに変えられる） */
  if (kind === 'force') { ctx.strokeStyle = FC; ctx.fillStyle = FC; ctx.lineWidth = 3.4 * k; }
  else if (kind === 'acc') { ctx.strokeStyle = COL.acc; ctx.fillStyle = COL.acc; ctx.lineWidth = 3.0 * k; }
  else if (kind === 'vel') { ctx.strokeStyle = COL.vel; ctx.fillStyle = '#ffffff'; ctx.lineWidth = 2.2 * k; }
  else if (kind === 'velcomp') { ctx.strokeStyle = COL.vel; ctx.fillStyle = 'rgba(22,99,181,.35)'; ctx.lineWidth = 2.0 * k; ctx.setLineDash([6 * k, 4 * k]); }
  else if (kind === 'velx') { ctx.strokeStyle = COL.velx; ctx.fillStyle = COL.velx; ctx.lineWidth = 2.2 * k; ctx.setLineDash([7 * k, 4 * k]); }
  else if (kind === 'vely') { ctx.strokeStyle = COL.vely; ctx.fillStyle = COL.vely; ctx.lineWidth = 2.2 * k; ctx.setLineDash([7 * k, 4 * k]); }
  else if (kind === 'comp') { ctx.strokeStyle = FC; ctx.fillStyle = fade(FC, .38); ctx.lineWidth = 2.1 * k; ctx.setLineDash([6 * k, 4 * k]); }
  else { ctx.strokeStyle = COL.dim; ctx.fillStyle = COL.dim; ctx.lineWidth = 1.2 * k; ctx.setLineDash([5 * k, 4 * k]); }

  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(bx, by); ctx.stroke();
  ctx.setLineDash([]);
  if (kind === 'force' || kind === 'comp') {              /* 作用点を「・」ではっきり示す */
    ctx.beginPath();
    ctx.arc(x1, y1, 3.1 * k, 0, Math.PI * 2);
    ctx.fillStyle = FC; ctx.fill();
    if (kind === 'comp') { ctx.lineWidth = 1.2 * k; ctx.strokeStyle = '#fff'; ctx.stroke(); ctx.strokeStyle = FC; }
    ctx.fillStyle = (kind === 'comp') ? fade(FC, .38) : FC;
  }
  var wA = head * 0.5;
  ctx.beginPath();
  ctx.moveTo(x2, y2);
  ctx.lineTo(bx - uy * wA, by + ux * wA);
  ctx.lineTo(bx + uy * wA, by - ux * wA);
  ctx.closePath();
  ctx.fill();
  if (kind === 'vel' || kind === 'comp' || kind === 'velcomp') {
    ctx.lineWidth = Math.max(2.0 * k, ctx.lineWidth);
    ctx.setLineDash([]);
    ctx.stroke();
  }
  ctx.restore();
}

/* 文字列を「ふつうの字」と「添え字」に分ける。v_0 / v_x / v_{y0} と書ける */
function splitSub(text) {
  var segs = [], i = 0, cur = '';
  while (i < text.length) {
    var ch = text.charAt(i);
    if (ch === '_' && i + 1 < text.length) {
      if (cur) { segs.push({ s: cur, sub: false }); cur = ''; }
      if (text.charAt(i + 1) === '{') {
        var end = text.indexOf('}', i + 2);
        if (end === -1) end = text.length;
        segs.push({ s: text.slice(i + 2, end), sub: true });
        i = end + 1;
      } else {
        segs.push({ s: text.charAt(i + 1), sub: true });
        i += 2;
      }
    } else { cur += ch; i++; }
  }
  if (cur) segs.push({ s: cur, sub: false });
  return segs;
}

/* canvas の文字。添え字（v_0 など）に対応し、canvas の外にはみ出さないように寄せる */
/* この色の文字は「よけてよい文字」（力・速度・加速度・寸法のラベル）。
   図の名前・軸・基準面などは動かさない。 */
var AVOID_COLORS = [COL.force, COL.norm, COL.fric, COL.hand,
  COL.vel, COL.velx, COL.vely, COL.acc, COL.dim];
function isAvoidColor(c) {
  if (!c) return false;
  for (var i = 0; i < AVOID_COLORS.length; i++) if (AVOID_COLORS[i] === c) return true;
  return false;
}
/* すでに置いた文字（_txtBox）とぶつからない場所を、近いところから探す。
   [dx, dy] を返す。見つからなければ、いちばんぶつかりの少ないところ。 */
function avoidSpot(left, y, w, h) {
  var DX = [0, 10, -10, 20, -20, 28, -28];
  var DY = [0, 12, -12, 24, -24];
  var best = [0, 0], bestSc = Infinity, i, j, k;
  for (i = 0; i < DY.length; i++) {
    for (j = 0; j < DX.length; j++) {
      var b = { x: left + DX[j], y: y - h / 2 + DY[i], w: w, h: h }, sc = 0;
      for (k = 0; k < _txtBox.length; k++) sc += boxOverlap(b, _txtBox[k]);
      sc = sc * 4 + Math.abs(DX[j]) + Math.abs(DY[i]);
      if (sc < bestSc) { bestSc = sc; best = [DX[j], DY[i]]; }
    }
  }
  return best;
}

function label(ctx, text, x, y, opt) {
  opt = opt || {};
  if (_defVec && isVecColor(opt.color)) {
    _defVec.push(function () { label(ctx, text, x, y, opt); });
    return;
  }
  var size = opt.size || 13;
  var bold = opt.bold ? 'bold ' : '';
  var mainFont = bold + size + 'px ' + FONT;
  var subFont = bold + (size * 0.72).toFixed(1) + 'px ' + FONT;
  var segs = splitSub(String(text));
  var i, sg;
  ctx.save();
  ctx.textBaseline = opt.base || 'middle';
  ctx.textAlign = 'left';
  ctx.lineJoin = 'round';
  var tw = 0;
  for (i = 0; i < segs.length; i++) {
    ctx.font = segs[i].sub ? subFont : mainFont;
    segs[i].w = ctx.measureText(segs[i].s).width;
    tw += segs[i].w;
  }
  var al = opt.align || 'center';
  var left = al === 'right' ? x - tw : (al === 'left' ? x : x - tw / 2);
  if (CVW > 0 && opt.clamp !== false) {
    if (left < 4) left = 4;
    else if (left + tw > CVW - 4) left = Math.max(4, CVW - 4 - tw);
    if (y < 9) y = 9; else if (y > CVH - 7) y = CVH - 7;
  }
  /* ★力・速度・寸法の文字は、先に置いた文字とぶつかったら少しだけよける★
     （矢印から離れすぎないよう、ずらすのは 28px まで） */
  if (CVW > 0 && opt.clamp !== false && (opt.avoid || isAvoidColor(opt.color))) {
    var sp = avoidSpot(left, y, tw, size);
    left += sp[0]; y += sp[1];
    if (left < 4) left = 4;
    else if (left + tw > CVW - 4) left = Math.max(4, CVW - 4 - tw);
    if (y < 9) y = 9; else if (y > CVH - 7) y = CVH - 7;
  }
  var cx, sy;
  if (opt.halo !== false) {                 /* まず白フチをぜんぶ描く */
    ctx.strokeStyle = opt.haloColor || 'rgba(255,255,255,.92)';
    ctx.lineWidth = opt.haloW || 4.5;
    cx = left;
    for (i = 0; i < segs.length; i++) {
      sg = segs[i];
      ctx.font = sg.sub ? subFont : mainFont;
      sy = y + (sg.sub ? size * 0.26 : 0);
      ctx.strokeText(sg.s, cx, sy);
      cx += sg.w;
    }
  }
  /* 文字の置き場所を記録する（吹きだしの自動配置と、重なりの自動検査に使う） */
  noteBox(_txtBox, left, y - size / 2, tw, size);
  /* 力の名前なら、クリックできる場所としても記録する（「仕事の分析」で使う） */
  if (FKEY_BY_TEXT[String(text)] && opt.fhit !== false) {
    noteForceHit(FKEY_BY_TEXT[String(text)], left, y - size / 2, tw, size);
  }
  if (typeof window !== 'undefined' && window.__labelLog) {
    window.__labelLog.push({ cv: CVID, text: String(text), x: left, y: y, w: tw, h: size });
  }
  ctx.fillStyle = opt.color || COL.ink;
  cx = left;
  for (i = 0; i < segs.length; i++) {
    sg = segs[i];
    ctx.font = sg.sub ? subFont : mainFont;
    sy = y + (sg.sub ? size * 0.26 : 0);
    ctx.fillText(sg.s, cx, sy);
    cx += sg.w;
  }
  ctx.restore();
}

/* 衝突のエフェクト（ギザギザ＋文字）。文字がはみ出さないように星を広げる */
function impact(ctx, x, y, r, text) {
  var i, a, rr;
  text = text || 'ドコッ！';
  var sz = Math.max(12, Math.min(18, r * 0.6));
  ctx.save();
  ctx.font = 'bold ' + sz + 'px ' + FONT;
  var tw = ctx.measureText(text).width;
  ctx.restore();
  r = Math.max(r, tw / 2 + 14);
  ctx.save();
  ctx.beginPath();
  var n = 11;
  for (i = 0; i < n * 2; i++) {
    a = Math.PI * i / n - Math.PI / 2;
    rr = (i % 2 === 0) ? r : r * 0.56;
    if (i === 0) ctx.moveTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr);
    else ctx.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr);
  }
  ctx.closePath();
  ctx.fillStyle = '#ffe27a'; ctx.strokeStyle = '#d1352b'; ctx.lineWidth = 2.4;
  ctx.fill(); ctx.stroke();
  /* まわりに飛び散る線 */
  ctx.lineWidth = 2.2; ctx.strokeStyle = '#d1352b';
  for (i = 0; i < 8; i++) {
    a = Math.PI * 2 * i / 8 + 0.2;
    ctx.beginPath();
    ctx.moveTo(x + Math.cos(a) * (r + 4), y + Math.sin(a) * (r + 4));
    ctx.lineTo(x + Math.cos(a) * (r + 15), y + Math.sin(a) * (r + 15));
    ctx.stroke();
  }
  ctx.restore();
  label(ctx, text, x, y + 1, { size: sz, bold: true, color: '#c0392b', halo: false, clamp: false });
}

/* ===== かんたんな3次元の投影（正射影・方位角と仰角で見回す） ===== */
function mk3d(az, el, S, cx, cy) {
  var ca = Math.cos(az), sa = Math.sin(az), ce = Math.cos(el), se = Math.sin(el);
  return {
    az: az, el: el, S: S,
    p: function (x, y, z) {
      var x1 = x * ca - y * sa, y1 = x * sa + y * ca;
      return {
        x: cx + x1 * S,
        y: cy - (z * ce - y1 * se) * S,
        d: y1 * ce + z * se
      };
    }
  };
}

/* 面のハッチング。ang＝面の向き（rad, 右向きが0）、below＝面の下側にかく */
function hatchLine(ctx, x1, y1, x2, y2, side) {
  ctx.save();
  ctx.strokeStyle = '#333'; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
  var dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy);
  if (L < 1) { ctx.restore(); return; }
  var ux = dx / L, uy = dy / L;
  var nx = -uy * side, ny = ux * side;    /* 面の「内側」向き法線 */
  ctx.lineWidth = 1;
  for (var d = 4; d < L; d += 10) {
    var px = x1 + ux * d, py = y1 + uy * d;
    ctx.beginPath();
    ctx.moveTo(px, py);
    ctx.lineTo(px - ux * 8 + nx * 8, py - uy * 8 + ny * 8);
    ctx.stroke();
  }
  ctx.restore();
}

/* 滑車（軽くてなめらかに回る車輪）。★第20回・モード3で新規★
   (x, y) が軸の中心、r が半径［px］。外わく → みぞ → 軸 の順に描く。 */
function pulleyWheel(ctx, x, y, r) {
  ctx.save();
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fillStyle = '#e3e9ef'; ctx.fill();
  ctx.strokeStyle = '#2c3e50'; ctx.lineWidth = 2; ctx.stroke();
  ctx.beginPath(); ctx.arc(x, y, r * 0.62, 0, Math.PI * 2);
  ctx.strokeStyle = '#9aa4ae'; ctx.lineWidth = 1.2; ctx.stroke();
  ctx.beginPath(); ctx.arc(x, y, r * 0.16, 0, Math.PI * 2);
  ctx.fillStyle = '#5b6672'; ctx.fill();
  ctx.restore();
}

/* 滑車を台のはしに取りつける「支柱」。宙に浮かせない（教科書の図と同じ）。 */
function pulleyArm(ctx, x1, y1, x2, y2) {
  ctx.save(); ctx.lineCap = 'round';
  ctx.strokeStyle = '#5b6672'; ctx.lineWidth = 9;
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
  ctx.strokeStyle = '#e3e9ef'; ctx.lineWidth = 5;
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
  ctx.restore();
}

/* 滑車に巻きついた糸（円弧）。a1 → a2 はキャンバスの角度［rad］。 */
function stringArc(ctx, x, y, r, a1, a2, ccw) {
  ctx.save();
  ctx.strokeStyle = COL.hand; ctx.lineWidth = 1.8; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.arc(x, y, r, a1, a2, !!ccw); ctx.stroke();
  ctx.restore();
}

function ball(ctx, x, y, r, style) {
  noteObj(x - r, y - r, 2 * r, 2 * r);
  ctx.save();
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2);
  if (style === 'faint') { ctx.fillStyle = '#e7eaee'; ctx.strokeStyle = '#aab0b8'; ctx.lineWidth = 1.1; }
  else if (style === 'A') { ctx.fillStyle = '#cfe0f4'; ctx.strokeStyle = COL.A; ctx.lineWidth = 2; }
  else if (style === 'B') { ctx.fillStyle = '#f6d6d2'; ctx.strokeStyle = COL.B; ctx.lineWidth = 2; }
  else { ctx.fillStyle = '#fff'; ctx.strokeStyle = '#111'; ctx.lineWidth = 2; }
  ctx.fill(); ctx.stroke();
  ctx.restore();
}

/* 角度の弧（θ の記号） */
function angArc(ctx, cx, cy, r, a1, a2, text, labAng, labR) {
  ctx.save();
  ctx.strokeStyle = COL.sub; ctx.lineWidth = 1.3;
  ctx.beginPath(); ctx.arc(cx, cy, r, a1, a2, a2 < a1);
  ctx.stroke();
  ctx.restore();
  var am = (labAng === undefined || labAng === null) ? (a1 + a2) / 2 : labAng;
  var rr = labR || (r + 15);
  if (text) label(ctx, text, cx + Math.cos(am) * rr, cy + Math.sin(am) * rr,
    { size: 12.5, color: COL.sub, avoid: true });
}

/* 手（斜面上向きに引く／押す）。(hx,hy)＝手のひらの中心、ang＝向き（rad） */
/* 色をうすくする（#rrggbb → rgba） */
function fade(hex, a) {
  var h = (hex || '#d1352b').replace('#', '');
  var r = parseInt(h.substring(0, 2), 16), g = parseInt(h.substring(2, 4), 16), b = parseInt(h.substring(4, 6), 16);
  return 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')';
}

/* ===== 小さな効果音（Web Audio。外部ファイルは使わない） ===== */
var _AC = null;
function sfx(kind) {
  try {
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    if (!_AC) _AC = new AC();
    if (_AC.state === 'suspended' && _AC.resume) _AC.resume();
    var t0 = _AC.currentTime, o = _AC.createOscillator(), g = _AC.createGain();
    o.connect(g); g.connect(_AC.destination);
    if (kind === 'bang') {               /* 発射音「ばん！」 */
      o.type = 'square';
      o.frequency.setValueAtTime(260, t0);
      o.frequency.exponentialRampToValueAtTime(60, t0 + 0.16);
      g.gain.setValueAtTime(0.16, t0);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + 0.2);
      o.start(t0); o.stop(t0 + 0.22);
    } else if (kind === 'hit') {         /* 命中音 */
      o.type = 'triangle';
      o.frequency.setValueAtTime(880, t0);
      o.frequency.exponentialRampToValueAtTime(180, t0 + 0.18);
      g.gain.setValueAtTime(0.13, t0);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + 0.22);
      o.start(t0); o.stop(t0 + 0.24);
    } else if (kind === 'win') {         /* 成功の「ぴろりん」 */
      o.type = 'triangle';
      o.frequency.setValueAtTime(784, t0);
      o.frequency.setValueAtTime(1046, t0 + 0.09);
      o.frequency.setValueAtTime(1318, t0 + 0.18);
      g.gain.setValueAtTime(0.12, t0);
      g.gain.setValueAtTime(0.12, t0 + 0.24);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + 0.42);
      o.start(t0); o.stop(t0 + 0.44);
    } else {                             /* 「ピコン」 */
      o.type = 'sine';
      o.frequency.setValueAtTime(660, t0);
      o.frequency.setValueAtTime(990, t0 + 0.07);
      g.gain.setValueAtTime(0.09, t0);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + 0.18);
      o.start(t0); o.stop(t0 + 0.2);
    }
    /* 鳴り終わったノードは切りはなす（何度も鳴らすうちに音のつながりがたまらないように） */
    o.onended = function () { try { o.disconnect(); g.disconnect(); } catch (e2) { } };
  } catch (e) { /* 音が出せない環境では何もしない */ }
}

/* 小球を落とそうとする手（真横やや上から。指先の下に小球が来るように描く）。
   (x,y)＝小球の中心。sc＝大きさ、open＝0〜1（1 で親指と人差し指をひらいた形）、
   alpha＝濃さ。 */
function dropHand(ctx, x, y, sc, open, alpha) {
  sc = sc || 1;
  noteObj(x - 70 * sc, y - 100 * sc, 170 * sc, 105 * sc);
  var o = Math.max(0, Math.min(1, open || 0));
  var INK = '#3f4a54', SKIN = '#ffffff';
  ctx.save();
  ctx.translate(x, y); ctx.scale(sc, sc);
  ctx.globalAlpha = (alpha === undefined) ? 1 : alpha;
  ctx.lineJoin = 'round'; ctx.lineCap = 'round';

  function limb(x0, y0, cx, cy, x1, y1, w) {     /* 指・親指（外枠つきの太い線） */
    ctx.beginPath();
    ctx.moveTo(x0, y0); ctx.quadraticCurveTo(cx, cy, x1, y1);
    ctx.lineWidth = w + 3.4; ctx.strokeStyle = INK; ctx.stroke();
    ctx.lineWidth = w; ctx.strokeStyle = SKIN; ctx.stroke();
  }
  /* 指（奥から手前へ4本）。右から2本目＝人差し指だけ、ひらくときに動く */
  limb(-28, -66, -58, -54, -66, -28, 12);
  limb(-14, -72, -46, -58, -52, -21, 13);
  limb(2, -74, -30, -60, -33, -16, 14);
  limb(16, -72, -10 - 9 * o, -58, -13 - 21 * o, -15 - 9 * o, 14);   /* 人差し指 */
  /* 手の甲 */
  ctx.beginPath();
  ctx.moveTo(-32, -62);
  ctx.bezierCurveTo(-8, -94, 42, -98, 64, -74);
  ctx.bezierCurveTo(80, -58, 62, -40, 34, -40);
  ctx.bezierCurveTo(10, -40, -12, -46, -32, -62);
  ctx.closePath();
  ctx.fillStyle = SKIN; ctx.fill();
  ctx.lineWidth = 3.2; ctx.strokeStyle = INK; ctx.stroke();
  /* 手首・腕 */
  ctx.beginPath();
  ctx.moveTo(56, -84); ctx.lineTo(96, -78);
  ctx.lineTo(96, -50); ctx.lineTo(58, -46);
  ctx.closePath();
  ctx.fillStyle = SKIN; ctx.fill(); ctx.lineWidth = 3.2; ctx.strokeStyle = INK; ctx.stroke();
  /* 親指（右手前）。ひらくときは右へ開く */
  limb(42, -48, 40 + 10 * o, -25, 17 + 24 * o, -12 - 8 * o, 15);
  /* 指のしわ */
  ctx.lineWidth = 1.3; ctx.strokeStyle = INK; ctx.globalAlpha *= 0.75;
  ctx.beginPath(); ctx.moveTo(-46, -47); ctx.lineTo(-38, -44); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(-26, -47); ctx.lineTo(-18, -45); ctx.stroke();
  ctx.restore();
}

/* デコピンする手（物体をはじく）。
   (x,y)＝こぶしの中心、ang＝はじく向き（rad、+x がはじく向き）、
   k＝0…指を曲げた形／1…はじいたあとの形、dir＝+1 か −1（左右の向き）、
   sc＝大きさ、alpha＝濃さ。 */
function flickHand(ctx, x, y, ang, k, dir, sc, alpha) {
  k = Math.max(0, Math.min(1, k || 0));
  sc = sc || 0.45;
  noteObj(x - 110 * sc, y - 60 * sc, 220 * sc, 130 * sc);
  var SKIN = '#fbd7b7', INK = '#4a3730';
  function mix(a, b) { return a + (b - a) * k; }
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(ang);
  if (dir < 0) ctx.scale(-1, 1);
  ctx.scale(sc, sc);
  ctx.globalAlpha = (alpha === undefined) ? 1 : alpha;
  ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  ctx.fillStyle = SKIN; ctx.strokeStyle = INK;

  /* 腕（後ろへ） */
  ctx.lineWidth = 26; ctx.strokeStyle = SKIN;
  ctx.beginPath(); ctx.moveTo(-6, 10); ctx.lineTo(-96, 58); ctx.stroke();
  ctx.lineWidth = 3.4; ctx.strokeStyle = INK;
  ctx.beginPath(); ctx.moveTo(-14, -2); ctx.lineTo(-100, 46); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(-2, 22); ctx.lineTo(-92, 70); ctx.stroke();

  /* こぶし */
  ctx.beginPath(); ctx.arc(0, 0, 30, 0, Math.PI * 2);
  ctx.fillStyle = SKIN; ctx.fill(); ctx.lineWidth = 3.4; ctx.strokeStyle = INK; ctx.stroke();
  /* 折りたたんだ指（3つのふくらみ） */
  ctx.lineWidth = 2.6;
  ctx.beginPath(); ctx.ellipse(24, -18, 15, 11, -0.35, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.ellipse(28, 2, 16, 12, -0.15, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.ellipse(22, 22, 17, 12, 0.15, 0, Math.PI * 2); ctx.fill(); ctx.stroke();

  /* はじく指：曲げた形（Λ）→ まっすぐ */
  var jx = mix(34, 44), jy = mix(-52, -20), tx = mix(52, 80), ty = mix(-16, -12);
  ctx.lineWidth = 15; ctx.strokeStyle = SKIN;
  ctx.beginPath(); ctx.moveTo(16, -20); ctx.lineTo(jx, jy); ctx.lineTo(tx, ty); ctx.stroke();
  ctx.lineWidth = 18; ctx.strokeStyle = INK;
  ctx.beginPath(); ctx.moveTo(16, -20); ctx.lineTo(jx, jy); ctx.lineTo(tx, ty);
  ctx.strokeStyle = INK; ctx.lineWidth = 3.2;
  ctx.stroke();
  ctx.lineWidth = 12; ctx.strokeStyle = SKIN;
  ctx.beginPath(); ctx.moveTo(16, -20); ctx.lineTo(jx, jy); ctx.lineTo(tx, ty); ctx.stroke();

  /* はじいた瞬間の勢いの線 */
  if (k > 0.15 && k < 0.95) {
    ctx.strokeStyle = INK; ctx.lineWidth = 2.4; ctx.globalAlpha *= (1 - k);
    for (var i2 = -1; i2 <= 1; i2++) {
      ctx.beginPath();
      ctx.moveTo(tx + 12, ty + i2 * 14); ctx.lineTo(tx + 30, ty + i2 * 20);
      ctx.stroke();
    }
  }
  ctx.restore();
}

/* 糸（ひも）：物体と手をつなぐ細い線 */
function string(ctx, x1, y1, x2, y2) {
  ctx.save();
  ctx.strokeStyle = '#6b5442'; ctx.lineWidth = 1.6; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
  ctx.restore();
}

function hand(ctx, hx, hy, ang) {
  /* 吹きだしがこの手をよけられるように、場所を覚えておく（まわした形のはこ） */
  var ca = Math.cos(ang || 0), sa = Math.sin(ang || 0);
  var cs = [[-15, -13], [43, -13], [43, 13], [-15, 13]], ii, xs = [], ys = [];
  for (ii = 0; ii < 4; ii++) {
    xs.push(hx + cs[ii][0] * ca - cs[ii][1] * sa);
    ys.push(hy + cs[ii][0] * sa + cs[ii][1] * ca);
  }
  var x1 = Math.min.apply(null, xs), y1 = Math.min.apply(null, ys);
  noteObj(x1, y1, Math.max.apply(null, xs) - x1, Math.max.apply(null, ys) - y1);
  ctx.save();
  ctx.translate(hx, hy);
  ctx.rotate(ang);
  ctx.fillStyle = '#f6d9bd'; ctx.strokeStyle = '#a97b4c'; ctx.lineWidth = 1.4;
  /* 腕 */
  ctx.beginPath();
  ctx.moveTo(10, -6); ctx.lineTo(40, -7); ctx.lineTo(40, 7); ctx.lineTo(10, 6);
  ctx.closePath(); ctx.fill(); ctx.stroke();
  /* こぶし */
  ctx.beginPath();
  ctx.ellipse(2, 0, 13, 11, 0, 0, Math.PI * 2);
  ctx.fill(); ctx.stroke();
  /* 指の線 */
  ctx.beginPath();
  ctx.moveTo(-8, -5); ctx.lineTo(4, -5);
  ctx.moveTo(-9, 0); ctx.lineTo(5, 0);
  ctx.moveTo(-8, 5); ctx.lineTo(4, 5);
  ctx.stroke();
  ctx.restore();
}

/* 下から支える手（手のひらを上に向けた線画。添付のイラストに合わせた形）。
   (x, y) ＝ 手のひらのてっぺん（＝ものが乗るところ）、sc＝大きさ、flip＝左右を返す。
   ★物体の下にぴったり接するように置く★（2-3 でおもりを支える手） */
function handUnder(ctx, x, y, sc, flip) {
  sc = sc || 1;
  var INK = '#1b1f24', SKIN = '#ffffff';
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(flip ? -sc : sc, sc);
  ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  function limb(x0, y0, cx2, cy2, x1, y1, w) {      /* 指（外枠つきの太い線） */
    ctx.beginPath();
    ctx.moveTo(x0, y0); ctx.quadraticCurveTo(cx2, cy2, x1, y1);
    ctx.lineWidth = w + 3; ctx.strokeStyle = INK; ctx.stroke();
    ctx.lineWidth = w; ctx.strokeStyle = SKIN; ctx.stroke();
  }
  /* 指（奥から手前へ4本）。手のひらの左はしから左へのびる */
  limb(-4, 16, -26, 20, -44, 12, 7);
  limb(-4, 12, -30, 15, -48, 5, 7.5);
  limb(-4, 8, -30, 9, -46, -3, 7.5);
  limb(-4, 4, -26, 3, -38, -9, 7);
  /* 手のひら（上の面が平ら＝ものが乗る） */
  ctx.beginPath();
  ctx.moveTo(-10, 18);
  ctx.bezierCurveTo(-16, 4, -4, -4, 12, -3);
  ctx.lineTo(26, 6);
  ctx.lineTo(12, 20);
  ctx.closePath();
  ctx.fillStyle = SKIN; ctx.fill();
  ctx.lineWidth = 2.6; ctx.strokeStyle = INK; ctx.stroke();
  /* 親指（上へ折れる） */
  limb(4, -1, -2, -10, -14, -9, 7);
  /* 手首と腕（右下へ） */
  ctx.beginPath(); ctx.moveTo(20, 2); ctx.lineTo(46, 34);
  ctx.lineWidth = 19; ctx.strokeStyle = SKIN; ctx.stroke();
  ctx.lineWidth = 2.6; ctx.strokeStyle = INK;
  ctx.beginPath(); ctx.moveTo(13, -2); ctx.lineTo(39, 30); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(27, 7); ctx.lineTo(53, 39); ctx.stroke();
  ctx.restore();
  noteObj(x - 52 * sc, y - 14 * sc, 108 * sc, 56 * sc);
}

/* 吹き出し。opt.up＝true でしっぽを上向きにする（指したいものが吹き出しより上にあるとき）。
   (x, y) は「しっぽの先」＝指したい場所。 */
/* ★見どころの数値を1つだけ大きく出す小さなパネル★（先生の指示・第11回）
   1-12（手をはなす）と 2-3（手でゆっくり下ろす）で
   「つりあいの位置での速さ」を、生徒が一目で見くらべられるようにするために作った。
   (x, y) は箱の左上。title＝小さい見出し、value＝大きい数値、sub＝そのあとの短い言葉。
   吹きだしと同じように、場所を _txtBox に記録して他の文字が避けられるようにする。 */
function factPanel(ctx, x, y, title, value, sub, opt) {
  opt = opt || {};
  var pad = 11, tSz = 11.5, vSz = 17, sSz = 12;
  ctx.save();
  ctx.font = tSz + 'px ' + FONT;
  var wT = ctx.measureText(title).width;
  ctx.font = 'bold ' + vSz + 'px ' + FONT;
  var wV = ctx.measureText(value).width;
  ctx.font = sSz + 'px ' + FONT;
  var wS = sub ? ctx.measureText(sub).width : 0;
  var w = Math.max(wT, wV + (sub ? wS + 9 : 0)) + pad * 2 + 6;
  var h = 54;
  if (CVW > 0) x = clamp(x, 3, Math.max(3, CVW - w - 3));
  /* 箱 */
  ctx.fillStyle = opt.bg || '#fff8e9';
  ctx.strokeStyle = opt.border || COL.acc;
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(x, y, w, h, 8);
  else ctx.rect(x, y, w, h);
  ctx.fill(); ctx.stroke();
  /* 左のたての帯（見どころの色） */
  ctx.fillStyle = opt.border || COL.acc;
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(x + 4, y + 6, 4, h - 12, 2);
  else ctx.rect(x + 4, y + 6, 4, h - 12);
  ctx.fill();
  ctx.restore();
  label(ctx, title, x + pad + 6, y + 15,
    { size: tSz, color: opt.tcolor || '#8a5000', align: 'left', halo: false });
  label(ctx, value, x + pad + 6, y + 37,
    { size: vSz, bold: true, color: opt.vcolor || '#28323d', align: 'left', halo: false });
  if (sub) {
    label(ctx, sub, x + pad + 6 + wV + 9, y + 39,
      { size: sSz, color: opt.scolor || '#6b7683', align: 'left', halo: false });
  }
  noteBox(_txtBox, x, y, w, h);
  noteObj(x, y, w, h);
  /* ★__labelLog には箱を入れない★ 中の3つの文字は label() が自分で記録するので、
     箱まで入れると「箱と、その中の文字が重なっている」と毎回さわがれてしまう
     （sweep.py が 8 件出した。第11回）。 */
  return { w: w, h: h };
}

function bubble(ctx, text, x, y, opt) {
  opt = opt || {};
  var up = !!opt.up;
  ctx.save();
  ctx.font = 'bold ' + (opt.size || 14) + 'px ' + FONT;
  var w = ctx.measureText(text).width + 18, h = (opt.size || 14) + 14;
  /* opt.dx … しっぽの先はそのままで、箱だけ横にずらす（まわりの文字を避けるため） */
  var bx = x - w / 2 + (opt.dx || 0), by = up ? y + 8 : y - h;
  /* 画面からはみ出さないように、箱だけ横にずらす（しっぽの先は動かさない） */
  if (CVW > 0) bx = clamp(bx, 3, Math.max(3, CVW - w - 3));
  var tipX = clamp(x, bx + 10, bx + w - 10);
  var edge = up ? by : by + h;                    /* しっぽの根もとの高さ */
  var tipY = up ? by - 8 : by + h + 8;
  ctx.fillStyle = opt.bg || '#fff5d6';
  ctx.strokeStyle = opt.border || '#d9a545';
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(bx, by, w, h, 7);
  else ctx.rect(bx, by, w, h);
  ctx.fill(); ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(tipX - 6, edge); ctx.lineTo(tipX, tipY); ctx.lineTo(tipX + 6, edge);
  ctx.closePath(); ctx.fillStyle = opt.bg || '#fff5d6'; ctx.fill();
  ctx.strokeStyle = opt.border || '#d9a545';
  ctx.beginPath(); ctx.moveTo(tipX - 6, edge); ctx.lineTo(tipX, tipY); ctx.lineTo(tipX + 6, edge); ctx.stroke();
  ctx.fillStyle = opt.color || '#8a5000';
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText(text, bx + w / 2, by + h / 2);
  ctx.restore();
  /* 吹きだしの場所も「文字の箱」として記録する（点のエネルギーの吹きだしが避けられるように） */
  noteBox(_txtBox, bx, by, w, h);
  if (typeof window !== 'undefined' && window.__labelLog) {
    window.__labelLog.push({ cv: CVID, text: '吹:' + text, x: bx, y: by + h / 2, w: w, h: h });
  }
}

/* つる巻きばね。(x1,y1)＝固定はし、(x2,y2)＝物体につくはし。
   opt = { coils（コイルの数）, r（コイルの半径 px）, color, lw, lead（両はしのまっすぐな部分 px） } */
/* 指差しマーク（「ここをクリックしてね」の合図）。(x,y)＝指の先。
   人さし指を上に立てた手を、少し右下から出す形。 */
function pointerIcon(ctx, x, y, sc) {
  sc = sc || 1;
  var INK = '#1b1f24', SKIN = '#ffffff';
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(sc, sc);
  ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  ctx.beginPath();
  /* 人さし指 */
  ctx.moveTo(0, 0);
  ctx.lineTo(-3.4, 3.2);
  ctx.lineTo(-3.4, 10);
  /* 手のひら（にぎった指のふくらみ） */
  ctx.quadraticCurveTo(-3.4, 13, -1.2, 13.6);
  ctx.lineTo(7.4, 13.6);
  ctx.quadraticCurveTo(10.2, 13.6, 10.2, 10.8);
  ctx.lineTo(10.2, 7.2);
  ctx.quadraticCurveTo(10.2, 5.2, 8.2, 5.2);
  ctx.lineTo(2.6, 5.2);
  ctx.quadraticCurveTo(3.4, 3.4, 3.4, 0.6);
  ctx.quadraticCurveTo(3.4, -1.6, 1.7, -1.6);
  ctx.quadraticCurveTo(0, -1.6, 0, 0);
  ctx.closePath();
  ctx.fillStyle = SKIN; ctx.fill();
  ctx.strokeStyle = INK; ctx.lineWidth = 1.5; ctx.stroke();
  /* にぎった指の線 */
  ctx.strokeStyle = INK; ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(4.6, 5.2); ctx.lineTo(4.6, 13.6);
  ctx.moveTo(7.0, 5.4); ctx.lineTo(7.0, 13.6);
  ctx.stroke();
  ctx.restore();
}

/* ジェットコースターの車（人が1人乗っている）。
   (x,y)＝車体の中心。ang＝進む向きの角度[rad]（0＝右へ水平、正で反時計まわり）。
   ループの中では上下がひっくり返るので、そのまま回して描く。 */
function coasterCar(ctx, x, y, ang, sc) {
  sc = sc || 1;
  var w = 26 * sc, h = 18 * sc;
  noteObj(x - w * 0.8, y - h * 1.3, w * 1.6, h * 2.6);
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(-ang);
  /* 車体 */
  ctx.fillStyle = '#e8eef5'; ctx.strokeStyle = '#4a5560'; ctx.lineWidth = 1.6;
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(-w / 2, -h / 2, w, h, 4);
  else ctx.rect(-w / 2, -h / 2, w, h);
  ctx.fill(); ctx.stroke();
  /* 前のへり（進む向きを分かりやすく） */
  ctx.beginPath();
  ctx.moveTo(w / 2 - 5, -h / 2); ctx.lineTo(w / 2, 0); ctx.lineTo(w / 2 - 5, h / 2);
  ctx.stroke();
  /* 車輪 */
  ctx.fillStyle = '#4a5560';
  ctx.beginPath(); ctx.arc(-w * 0.26, h / 2 + 2.6, 2.8, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc(w * 0.26, h / 2 + 2.6, 2.8, 0, Math.PI * 2); ctx.fill();
  /* 乗っている人（頭と体） */
  ctx.strokeStyle = '#4a5560'; ctx.lineWidth = 1.5;
  ctx.fillStyle = '#ffffff';
  ctx.beginPath(); ctx.arc(0, -h / 2 - 4.4, 3.4, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(0, -h / 2 - 1); ctx.lineTo(0, -h / 2 + 3); ctx.stroke();
  ctx.restore();
}

function spring(ctx, x1, y1, x2, y2, opt) {
  opt = opt || {};
  var col = opt.color || COL.hand, lw = opt.lw || 2.0;
  var lead = opt.lead === undefined ? 8 : opt.lead;
  var n = opt.coils || 9, r = opt.r || 8;
  var dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy);
  ctx.save();
  ctx.strokeStyle = col; ctx.lineWidth = lw; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  if (L < 2) { ctx.restore(); return; }
  var ux = dx / L, uy = dy / L, px = -uy, py = ux;
  var body = Math.max(6, L - lead * 2);
  /* 吹きだしがばねの上に乗らないように、ばねの場所を「物体」として記録する */
  noteObj(Math.min(x1, x2) - Math.abs(py) * r - 2, Math.min(y1, y2) - Math.abs(px) * r - 2,
    Math.abs(dx) + 2 * Math.abs(py) * r + 4, Math.abs(dy) + 2 * Math.abs(px) * r + 4);
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x1 + ux * lead, y1 + uy * lead);
  var N = n * 2, i;
  for (i = 1; i <= N; i++) {
    var f = i / N, s = lead + body * (i - 0.5) / N;
    var side = (i % 2 === 0) ? -1 : 1;
    var rr = r * (1 - 0.12 * Math.abs(Math.cos(Math.PI * f)));   /* はしを少しすぼめる */
    ctx.lineTo(x1 + ux * s + px * side * rr, y1 + uy * s + py * side * rr);
  }
  ctx.lineTo(x1 + ux * (lead + body), y1 + uy * (lead + body));
  ctx.lineTo(x2, y2);
  ctx.stroke();
  ctx.restore();
}

/* 世界座標（y 上向き）→ 画面座標。等方スケールで box を pad の内側に収める */
function mkView(W, H, pad, box) {
  var w = W - pad.l - pad.r, h = H - pad.t - pad.b;
  var bw = Math.max(1e-6, box.x1 - box.x0), bh = Math.max(1e-6, box.y1 - box.y0);
  var s = Math.min(w / bw, h / bh);
  var cx = (box.x0 + box.x1) / 2, cy = (box.y0 + box.y1) / 2;
  var ox = pad.l + w / 2, oy = pad.t + h / 2;
  return {
    s: s,
    X: function (x) { return ox + (x - cx) * s; },
    Y: function (y) { return oy - (y - cy) * s; },
    invX: function (px) { return cx + (px - ox) / s; },
    invY: function (py) { return cy - (py - oy) / s; }
  };
}

/* 「きり」のよい目盛り間隔 */
function niceStep(range, target) {
  var raw = range / Math.max(1, target);
  var p = Math.pow(10, Math.floor(Math.log(raw) / Math.LN10));
  var c = [1, 2, 2.5, 5, 10];
  for (var i = 0; i < c.length; i++) if (raw <= c[i] * p * 1.0001) return c[i] * p;
  return 10 * p;
}

/* 0 を必ず含み、きりのよい端で切った範囲にする（グラフの原点を画面に入れるため） */
function niceRange(lo, hi) {
  var a = Math.min(0, lo), b = Math.max(0, hi);
  if (b - a < 1e-9) { a -= 1; b += 1; }
  var pad = (b - a) * 0.14;
  a -= (lo < -1e-9 ? pad : pad * 0.35);
  b += (hi > 1e-9 ? pad : pad * 0.35);
  var st = niceStep(b - a, 5);
  a = Math.floor(a / st) * st;
  b = Math.ceil(b / st) * st;
  if (b - a < st * 1.5) b = a + st * 2;
  return { lo: a, hi: b };
}

/* ===== 軸の共通スタイル（1-3 の y 軸をベースに全シムでそろえる） =====
   ・軸は細い実線、正の向きの端に太めの矢じり
   ・目盛りは短い線＋数値（等幅っぽい小さめの字）
   ・原点は ● と大きめの「O」で強調
*/
var AX = { tick: 4.5, num: 11, name: 12.5, head: 13, col: '#5b6672' };

/* 原点の強調 */
function originMark(ctx, px, py, ox, oy) {
  ctx.save();
  ctx.fillStyle = AX.col;
  ctx.beginPath(); ctx.arc(px, py, 3.4, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
  label(ctx, 'O', px + (ox === undefined ? -13 : ox), py + (oy === undefined ? 13 : oy),
    { size: AX.name + 2, bold: true, color: AX.col });
}

/* 軸を1本ひく（すべての図で共通）。
   P(値)→{x,y} 画面座標、nrm＝目盛りの数字を置く向き（単位ベクトル）、
   sign>0 で「値が増える向き」が正。opt.numDec で小数桁を固定できる。 */
function axisLine(ctx, P, lo, hi, nrm, name, sign, opt) {
  opt = opt || {};
  var s = opt.step || niceStep(hi - lo, opt.target || 5);
  var pLo = P(lo), pHi = P(hi), i;
  var dx = pHi.x - pLo.x, dy = pHi.y - pLo.y, L = Math.hypot(dx, dy);
  if (L < 2) return;
  var ux = dx / L, uy = dy / L;                       /* 値が増える向き（画面） */
  ctx.save();
  ctx.strokeStyle = AX.col; ctx.lineWidth = 1.4;
  ctx.beginPath(); ctx.moveTo(pLo.x, pLo.y); ctx.lineTo(pHi.x, pHi.y); ctx.stroke();
  ctx.restore();
  var sg = sign >= 0 ? 1 : -1;
  var tip = sg > 0 ? pHi : pLo;
  var tx = ux * sg, ty = uy * sg;
  arrowHead(ctx, tip.x + tx * AX.head, tip.y + ty * AX.head, tx, ty, AX.col);
  /* 目盛り幅にあわせた小数けた数（0.05 きざみを 1 けたで書くと「0.1・0.1・0.2」と重なる） */
  var dec = opt.numDec !== undefined ? opt.numDec
    : (s >= 1 ? 0 : (s >= 0.1 ? 1 : (s >= 0.01 ? 2 : 3)));
  for (i = Math.ceil(lo / s) * s; i <= hi + 1e-9; i += s) {
    if (Math.abs(i) < 1e-9) continue;
    var p = P(i);
    ctx.save(); ctx.strokeStyle = AX.col; ctx.lineWidth = 1.1;
    ctx.beginPath();
    ctx.moveTo(p.x - nrm.x * AX.tick, p.y - nrm.y * AX.tick);
    ctx.lineTo(p.x + nrm.x * AX.tick, p.y + nrm.y * AX.tick);
    ctx.stroke(); ctx.restore();
    if (!opt.noNum) label(ctx, fmt(i * sg, dec), p.x + nrm.x * 13, p.y + nrm.y * 13,
      { size: AX.num, color: AX.col, align: nrm.x < -0.5 ? 'right' : (nrm.x > 0.5 ? 'left' : 'center') });
  }
  if (name) {
    var nx = tip.x + tx * (AX.head + 8) - nrm.x * 12;
    var ny = tip.y + ty * (AX.head + 8) - nrm.y * 12;
    label(ctx, name, nx, ny, { size: AX.name, color: AX.col });
  }
}

/* 横軸。X(値)→px、ypx＝軸の高さ。sign>0 で右が正 */
function axisX(ctx, X, ypx, lo, hi, name, sign, opt) {
  axisLine(ctx, function (v) { return { x: X(v), y: ypx }; }, lo, hi, { x: 0, y: 1 }, name, sign, opt);
}

/* 縦軸。Y(値)→px、xpx＝軸の横位置。sign>0 で「値が増える向き」が正 */
function axisY(ctx, Y, xpx, lo, hi, name, sign, opt) {
  axisLine(ctx, function (v) { return { x: xpx, y: Y(v) }; }, lo, hi, { x: -1, y: 0 }, name, sign, opt);
}

/* 矢じりだけ描く（軸の先） */
function arrowHead(ctx, x, y, ux, uy, color) {
  var h = AX.head, w = h * 0.42;
  ctx.save();
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.lineTo(x - ux * h - uy * w, y - uy * h + ux * w);
  ctx.lineTo(x - ux * h + uy * w, y - uy * h - ux * w);
  ctx.closePath(); ctx.fill();
  ctx.restore();
}

/* 世界座標の x,y 軸（うすい格子つき）を、共通スタイルで描く */
function worldAxes(ctx, vw, box, xlabel, ylabel, signY) {
  var x0 = vw.X(box.x0), x1 = vw.X(box.x1), y0 = vw.Y(box.y0), y1 = vw.Y(box.y1);
  var sx = niceStep(box.x1 - box.x0, 6), sy = niceStep(box.y1 - box.y0, 5), i;
  ctx.save();
  ctx.strokeStyle = COL.grid; ctx.lineWidth = 1;
  for (i = Math.ceil(box.x0 / sx) * sx; i <= box.x1 + 1e-9; i += sx) {
    ctx.beginPath(); ctx.moveTo(vw.X(i), y1); ctx.lineTo(vw.X(i), y0); ctx.stroke();
  }
  for (i = Math.ceil(box.y0 / sy) * sy; i <= box.y1 + 1e-9; i += sy) {
    ctx.beginPath(); ctx.moveTo(x0, vw.Y(i)); ctx.lineTo(x1, vw.Y(i)); ctx.stroke();
  }
  ctx.restore();
  var ax = vw.Y(0), ay = vw.X(0);
  var hasY0 = (box.y0 <= 0 && box.y1 >= 0), hasX0 = (box.x0 <= 0 && box.x1 >= 0);
  if (hasY0) axisX(ctx, vw.X, ax, box.x0, box.x1 - sx * 0.35, xlabel, 1);
  if (hasX0) axisY(ctx, vw.Y, ay, box.y0, box.y1 - sy * 0.35, ylabel, signY === undefined ? 1 : signY);
  if (hasY0 && hasX0) originMark(ctx, ay, ax);
}

/* ===== 折れ線グラフ ===== */
/* spec: {xlabel,ylabel,xmin,xmax,ymin,ymax,series:[{color,dash,pts,name}],cursors:[{color,x,y}],zeroNote} */
function plot(cv, spec) {
  var W = 320, H = spec.H || 174;
  var ctx = prep(cv, W, H);
  var pad = { l: 46, r: 16, t: 20, b: 26 };
  var gw = W - pad.l - pad.r, gh = H - pad.t - pad.b;
  var xmin = spec.xmin, xmax = spec.xmax, ymin = spec.ymin, ymax = spec.ymax;
  if (spec.view) { xmin = spec.view.xmin; xmax = spec.view.xmax; ymin = spec.view.ymin; ymax = spec.view.ymax; }
  if (ymax - ymin < 1e-6) { ymax += 0.5; ymin -= 0.5; }
  /* ドラッグ操作のために、いまの対応づけを canvas に覚えさせる */
  cv._map = { W: W, H: H, pad: pad, gw: gw, gh: gh, xmin: xmin, xmax: xmax, ymin: ymin, ymax: ymax, xstep: 0 };
  function X(x) { return pad.l + gw * (x - xmin) / (xmax - xmin || 1); }
  function Y(y) { return pad.t + gh * (ymax - y) / (ymax - ymin || 1); }

  ctx.save();
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, W, H);
  /* 目盛りグリッド */
  /* spec.xstep があればそれを使う（運動の長さから決めた目盛り幅。右端を切り上げても
     目盛りが粗くならないようにするため）。ドラッグで範囲を変えたときは計算し直す。 */
  var sx = (!spec.view && spec.xstep) ? spec.xstep : niceStep(xmax - xmin, 5);
  var sy = niceStep(ymax - ymin, 4), i;
  cv._map.xstep = sx;      /* 実際に描いた目盛り幅（テストで確認するため） */
  ctx.strokeStyle = COL.grid; ctx.lineWidth = 1;
  for (i = Math.ceil(xmin / sx) * sx; i <= xmax + 1e-9; i += sx) {
    ctx.beginPath(); ctx.moveTo(X(i), pad.t); ctx.lineTo(X(i), pad.t + gh); ctx.stroke();
  }
  for (i = Math.ceil(ymin / sy) * sy; i <= ymax + 1e-9; i += sy) {
    ctx.beginPath(); ctx.moveTo(pad.l, Y(i)); ctx.lineTo(pad.l + gw, Y(i)); ctx.stroke();
  }
  ctx.restore();

  /* 軸（本体の図と同じ書き方にそろえる。グラフは小さいので字だけ少し小さく） */
  var axSave = { tick: AX.tick, num: AX.num, name: AX.name, head: AX.head };
  AX.tick = 3.5; AX.num = 9.5; AX.name = 11; AX.head = 10;
  var hasY0 = (ymin <= 0 && ymax >= 0), hasX0 = (xmin <= 0 && xmax >= 0);
  var yz = hasY0 ? Y(0) : pad.t + gh;
  var xz = hasX0 ? X(0) : pad.l;
  /* 横軸はグラフの右端までいっぱいに引く（手前で切ると、運動の終わりの時刻に
     目盛りが届かず「どこまで動いたのか」が読めなくなる）。目盛りの間隔はグリッドとそろえる。 */
  axisX(ctx, X, yz, xmin, xmax, spec.xlabel || '', 1, { step: sx });
  axisY(ctx, Y, xz, ymin, ymax - sy * 0.3, spec.ylabel || '', 1);
  if (hasY0 && hasX0) originMark(ctx, xz, yz, -10, 11);
  AX.tick = axSave.tick; AX.num = axSave.num; AX.name = axSave.name; AX.head = axSave.head;
  if (spec.note) label(ctx, spec.note, W - 6, 9, { size: 9.5, color: COL.sub, align: 'right' });

  ctx.save();
  ctx.beginPath(); ctx.rect(pad.l - 1, pad.t - 1, gw + 2, gh + 2); ctx.clip();
  (spec.hide ? [] : (spec.series || [])).forEach(function (se) {
    if (!se.pts || se.pts.length < 2) return;
    /* se.fillTo: 「はじめの E」の高さに、うすい横線を1本だけ引く。
       ★グラフの中はグレーに塗らない★（先生の指示・第7回）
       図のエネルギーの棒でも「失われた分」をグレーで塗っているので、
       グラフの中まで塗ると、どちらのグレーの話か分からなくなる。
       E の線が下がっていくこと自体が「減った」ことを表すので、塗らなくても伝わる。 */
    if (se.fillTo !== undefined && isFinite(se.fillTo)) {
      var y0 = Y(se.fillTo);
      ctx.save();
      ctx.strokeStyle = fade(COL.areaNeg, 0.75); ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
      ctx.beginPath(); ctx.moveTo(X(se.pts[0][0]), y0);
      ctx.lineTo(X(se.pts[se.pts.length - 1][0]), y0); ctx.stroke();
      ctx.restore();
    }
    /* se.area: 曲線と t 軸ではさまれた部分を塗る（面積＝変化量、を目で見せるため）。
       t 軸より上と下を別々にクリップして塗り、正と負を見分けられるようにする。 */
    if (se.area) {
      var yz = Y(0), k;
      var poly = function () {
        ctx.beginPath();
        ctx.moveTo(X(se.pts[0][0]), yz);
        for (k = 0; k < se.pts.length; k++) {
          if (isFinite(se.pts[k][0]) && isFinite(se.pts[k][1])) ctx.lineTo(X(se.pts[k][0]), Y(se.pts[k][1]));
        }
        ctx.lineTo(X(se.pts[se.pts.length - 1][0]), yz);
        ctx.closePath();
      };
      ctx.save();
      ctx.beginPath(); ctx.rect(pad.l - 1, pad.t - 1, gw + 2, Math.max(0, yz - pad.t + 1)); ctx.clip();
      ctx.fillStyle = fade(se.color, 0.20); poly(); ctx.fill();
      ctx.restore();
      ctx.save();
      ctx.beginPath(); ctx.rect(pad.l - 1, yz, gw + 2, Math.max(0, pad.t + gh - yz + 1)); ctx.clip();
      /* 負の面積は色を変える（正＝グラフの色／負＝ニュートラルなグレー） */
      ctx.fillStyle = fade(COL.areaNeg, 0.30); poly(); ctx.fill();
      ctx.strokeStyle = fade(COL.areaNeg, 0.60); ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
      poly(); ctx.stroke();
      ctx.restore();
    }
    ctx.save();
    ctx.strokeStyle = se.color; ctx.lineWidth = se.width || 2.2;
    if (se.dash) ctx.setLineDash(se.dash);
    ctx.beginPath();
    var started = false;
    for (var j = 0; j < se.pts.length; j++) {
      var p = se.pts[j];
      if (!isFinite(p[0]) || !isFinite(p[1])) { started = false; continue; }
      var px = X(p[0]), py = Y(p[1]);
      if (!started) { ctx.moveTo(px, py); started = true; } else ctx.lineTo(px, py);
    }
    ctx.stroke();
    ctx.restore();
  });

  (spec.hide ? [] : (spec.cursors || [])).forEach(function (c) {
    if (!isFinite(c.x) || !isFinite(c.y)) return;
    ctx.save();
    ctx.fillStyle = c.color; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.6;
    ctx.beginPath(); ctx.arc(X(c.x), Y(c.y), 4.6, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.restore();
  });
  ctx.restore();   /* clip 解除 */

  /* 凡例は「右上」に置く（左上に置くと、左で大きくなる曲線が白い箱にかくれる） */
  if (spec.legend && !spec.hide) {
    var lw = 0;
    ctx.save(); ctx.font = '10px ' + FONT;
    spec.legend.forEach(function (lg) { lw = Math.max(lw, ctx.measureText(lg.name).width); });
    ctx.restore();
    /* x 軸（y = 0 の線）がグラフの上のほうに来ると、目盛りの数字と凡例がぶつかる。
       そのときは凡例を下にずらす（2-3 のように U が大きく負になるシム）。 */
    var legTop = !(hasY0 && (yz - pad.t) < gh * 0.45);
    var lx = pad.l + gw - (lw + 22);
    var ly = legTop ? (pad.t + 8) : (pad.t + gh - spec.legend.length * 13 + 2);
    ctx.save();
    ctx.fillStyle = 'rgba(255,255,255,.88)';
    ctx.fillRect(lx - 4, ly - 8, lw + 28, spec.legend.length * 13 + 4);
    ctx.restore();
    spec.legend.forEach(function (lg, k) {
      ctx.save();
      ctx.strokeStyle = lg.color; ctx.lineWidth = lg.width || 2.4;
      if (lg.dash) ctx.setLineDash(lg.dash);
      ctx.beginPath(); ctx.moveTo(lx, ly + k * 13); ctx.lineTo(lx + 16, ly + k * 13); ctx.stroke();
      ctx.restore();
      label(ctx, lg.name, lx + 20, ly + k * 13, { size: 10, color: COL.sub, align: 'left', clamp: false });
    });
  }
}
