/* 状態 st と DOM。render は st だけから描く。
   basics-of-motion-on-plane.html の 80_ui.js を受けついで、
   ・「正の向き」の切りかえと問題モードを外し（エネルギーはスカラーなので向きがない）
   ・計算結果の帯／2点をくらべる式／法則の箱／各点の表 を足したもの。 */
'use strict';

/* allEq … 「3つの式を表示」のチェック。★全シムで共有する★（先生の指示・第4回） */
var st = { cur: 'm1-1', sims: {}, bigFml: false, allEq: false, workMode: false,
  _fHover: null, _fSel: null };   /* _fSel＝右の欄で選ばれている力（図の中で光る・第7回） */

/* 表示チェックボックス（このページは3つだけ） */
var VIS_LABEL = { F: '力を表示', Fc: '分解した力を表示', V: '速度ベクトルを表示',
  A: '加速度ベクトルを表示' };
var VIS_DEF = { F: true, Fc: false, V: true, A: false };   /* 加速度は既定で OFF */

/* 変数（v）と表示オプション（o）をまとめて物理へ渡す */
function V(s) {
  var o = {}, k;
  for (k in s.v) o[k] = s.v[k];
  for (k in s.o) o[k] = s.o[k];
  return o;
}

function $(id) { return document.getElementById(id); }

function graphsOf(d, s) {
  var list = d.graphs || [];
  if (!s) return list;
  var v = V(s);
  return list.filter(function (g) { return !g.when || g.when(v); });
}

/* ===== エネルギーのグラフ（全シム共通の4枚）=====
   K–t 図・U–t 図・E–t 図と、3本を重ねた1枚。
   「K が減った分だけ U が増え、E は水平のまま」が一目で分かるように、
   重ねた1枚を既定で開いておく。 */
function energyGraphs(d) {
  var us = !!d.hasUs;
  function sK(m) { return m.K; }
  function sU(m) { return m.U; }
  function sUg(m) { return m.Ug; }
  function sUs(m) { return m.Us; }
  function sE(m) { return m.E; }
  function E0(v) { return d.sample(v, 0).E; }
  function nums(v) {
    var a = d.sample(v, 0), b = d.sample(v, d.tEnd(v));
    return { a: a, b: b };
  }
  var uSeries = us
    ? [{ name: 'U = U_g + U_k', color: COL.eU, dash: [7, 4], f: sU },
       { name: 'U_g 重力', color: COL.eU, width: 1.5, f: sUg },
       { name: 'U_k ばね', color: COL.eU, width: 1.5, dash: [2, 3], f: sUs }]
    : [{ name: 'U 位置エネルギー', color: COL.eU, dash: [7, 4], f: sU }];

  var g = [];
  g.push({
    key: 'KUE', short: '$K$・$U$・$E$ を重ねた図',
    title: '$K$・$U$・$E$ を重ねた図　※まずここを見る', ylabel: 'エネルギー [J]',
    open: true, H: 208,
    /* ★重なったときに下になる線から先に描く★
       E と K がぴったり重なる（U = 0 の）シムでは、E を先に描かないと K が見えない */
    series: [{ name: 'E = K + U', color: COL.eE, width: 3.2, f: sE, fillTo: E0 }]
      .concat(us ? [{ name: 'U = U_g+U_k', color: COL.eU, dash: [7, 4], f: sU }] : uSeries)
      .concat([{ name: 'K 運動エネルギー', color: COL.eK, f: sK }]),
    /* 凡例は K → U → E の順（式の書き方とそろえる） */
    legend: [{ name: 'K 運動エネルギー', color: COL.eK },
      { name: 'U 位置エネルギー', color: COL.eU, dash: [7, 4] },
      { name: 'E = K + U', color: COL.eE, width: 3.2 }],
    fml: function (v) {
      var n = nums(v);
      if (consOf(d, v)) {
        return ['E = K + U \\;(\\text{一定})',
          'E = \\tfrac{1}{2}mv^2 + ' + (us ? 'mgh + \\tfrac{1}{2}kx^2' : 'mgh'),
          'E = ' + fmtE(n.a.E) + '\\ \\mathrm{J}\\;\\to\\;' + fmtE(n.b.E) + '\\ \\mathrm{J}\\;(\\text{変わらない})'];
      }
      return ['E_2 - E_1 = W_{\\text{非保存}}',
        'E_2 - E_1 = ' + (d.wSym || 'W_{\\text{非保存}}'),
        fmtE(n.b.E) + ' - ' + fmtE(n.a.E) + ' = ' + fmtE(n.b.E - n.a.E) + '\\ \\mathrm{J}'];
    }
  });
  g.push({
    key: 'K', short: '$K$–$t$ 図', title: '$K$–$t$ 図（運動エネルギー）', ylabel: 'K [J]', open: false,
    series: [{ color: COL.eK, f: sK }],
    fml: function (v) {
      var n = nums(v);
      return ['K = \\tfrac{1}{2}mv^2',
        'K = \\tfrac{1}{2}\\times' + fmt(v.m, 1) + '\\times v^2',
        'K:\\;' + fmtE(n.a.K) + '\\ \\mathrm{J}\\;\\to\\;' + fmtE(n.b.K) + '\\ \\mathrm{J}'];
    }
  });
  g.push({
    key: 'U', short: '$U$–$t$ 図', title: '$U$–$t$ 図（位置エネルギー）', ylabel: 'U [J]', open: false,
    legend: us, series: uSeries,
    fml: function (v) {
      var n = nums(v);
      return [us ? 'U = mgh + \\tfrac{1}{2}kx^2' : 'U = mgh',
        'U = ' + fmt(v.m, 1) + '\\times 9.8 \\times h' + (us ? ' + \\tfrac{1}{2}\\times' + fmt(v.k, 0) + '\\times x^2' : ''),
        'U:\\;' + fmtE(n.a.U) + '\\ \\mathrm{J}\\;\\to\\;' + fmtE(n.b.U) + '\\ \\mathrm{J}'];
    }
  });
  g.push({
    key: 'E', short: '$E$–$t$ 図', title: '$E$–$t$ 図（力学的エネルギー）', ylabel: 'E [J]', open: false,
    series: [{ color: COL.eE, width: 3.2, f: sE, fillTo: E0 }],
    fml: function (v) {
      var n = nums(v);
      if (consOf(d, v)) {
        return ['E = K + U', 'E = \\text{一定}（\\text{保存力だけが仕事をしている}）',
          'E = ' + fmtE(n.a.E) + '\\ \\mathrm{J}\\;(\\text{ずっと同じ})'];
      }
      return ['E(t) = E(0) + W_{\\text{非保存}}(t)',
        'E(t) = E(0) + ' + (d.wSym || 'W_{\\text{非保存}}'),
        'E:\\;' + fmtE(n.a.E) + '\\ \\mathrm{J}\\;\\to\\;' + fmtE(n.b.E) +
        '\\ \\mathrm{J}\\;(' + fmtE(n.b.E - n.a.E) + '\\ \\mathrm{J})'];
    }
  });
  return g;
}

function initState() {
  Object.keys(DEFS).forEach(function (id) {
    var d = DEFS[id];
    if (!d.graphs) d.graphs = (d.mode === 3) ? twoBodyGraphs3(d) : energyGraphs(d);
    var s = {
      /* slow … ★ばねのシムは速すぎるので、はじめからスロー再生にする★（先生の指示・第8回）
         DEFS に slow: true と書いたシムだけ、最初からスローで動く。 */
      v: {}, o: {}, t: 0, playing: false, slow: !!d.slow,
      open: {}, gview: {}, _eq: null, _played: false,
      /* 立式の3つの開閉（null＝まだ決めていない＝保存の成否と st.allEq で決める）と、
         「仕事を表示」でいま選んでいる力 */
      eqOpen: null, wkSel: null,
      /* モード3：左下の式の 2（対象）× 3（式の種類）の選び方 */
      eq3: { scope: 'both', kind: 'cons' },
      /* 立式でくらべる2つめの点（null なら最後の点）と、
         「一度でも最後まで進めたか」（仕事の分析の欄を出しておくかどうか） */
      eqPair: null, _wkReady: false
    };
    d.vars.forEach(function (vd) { s.v[vd.k] = vd.def; });
    (d.toggles || []).forEach(function (td) { s.o[td.k] = td.def; });
    (d.selects || []).forEach(function (sd) { s.o[sd.k] = sd.def; });
    (d.vis || []).forEach(function (k) {
      s.o['show' + k] = (d.visDef && d.visDef[k] !== undefined) ? d.visDef[k] : VIS_DEF[k];
    });
    if (d.consts) Object.keys(d.consts).forEach(function (k) { s.o[k] = d.consts[k]; });
    (d.graphs || []).forEach(function (g) { s.open[g.key] = !!g.open; });
    st.sims[id] = s;
  });
}

/* ===== 凡例の小さな線・矢印 ===== */
function drawLegend() {
  var list = document.querySelectorAll('#legend canvas');
  Array.prototype.forEach.call(list, function (cv) {
    var ctx = prep(cv, 56, 16);
    var ck = cv.getAttribute('data-col');
    var kind = cv.getAttribute('data-kind');
    var col = ck ? COL[ck] : null;
    if (kind === 'line') {
      ctx.save();
      ctx.strokeStyle = col; ctx.lineWidth = +(cv.getAttribute('data-w') || 2.4);
      if (cv.getAttribute('data-dash')) ctx.setLineDash([7, 4]);
      ctx.beginPath(); ctx.moveTo(3, 8); ctx.lineTo(53, 8); ctx.stroke();
      ctx.restore();
    } else if (kind === 'band') {
      ctx.save();
      ctx.fillStyle = fade(COL.areaNeg, 0.30); ctx.fillRect(3, 2, 50, 12);
      ctx.strokeStyle = fade(COL.areaNeg, 0.8); ctx.setLineDash([3, 3]); ctx.lineWidth = 1;
      ctx.strokeRect(3, 2, 50, 12);
      ctx.restore();
    } else {
      arrow(ctx, 4, 8, 50, 8, kind, 0.8, col);
    }
  });
}

/* ===== タブ ===== */
function buildTabs() {
  var mt = $('modetabs'), stb = $('simtabs'), cur = DEFS[st.cur];
  mt.innerHTML = '';
  var curBtn = null, curMode = null;
  MODES.forEach(function (M) {
    var b = document.createElement('button');
    b.textContent = M.label;
    if (M.n === cur.mode) { b.className = 'on'; curBtn = b; curMode = M; }
    b.addEventListener('click', function () { if (M.n !== DEFS[st.cur].mode) gotoSim(M.ids[0]); });
    mt.appendChild(b);
  });
  var tip = $('modetip');
  if (!tip) {
    tip = document.createElement('div');
    tip.id = 'modetip';
    mt.parentNode.insertBefore(tip, mt.nextSibling);
  }
  /* ★#modetip は flex なので、中身は必ず1つの span に包む★
     包まないと KaTeX の span が1つずつ flex の子になって、文がバラバラに折り返される */
  tip.innerHTML = (curMode && curMode.tip) ? '<span>' + mathHtml(curMode.tip) + '</span>' : '';
  renderMath(tip);
  st._tipBtn = curBtn;
  placeModeTip();
  stb.innerHTML = '';
  MODES.forEach(function (M) {
    if (M.n !== cur.mode) return;
    M.ids.forEach(function (id) {
      var b = document.createElement('button');
      b.textContent = DEFS[id].tab;
      b.className = (id === st.cur ? 'on' : '');
      b.addEventListener('click', function () { gotoSim(id); });
      stb.appendChild(b);
    });
  });
}

function updateUrlBar() {
  var h = '#' + hashOf();
  setText($('urltext'), (location.protocol === 'file:' || location.origin === 'null')
    ? (location.pathname.split('/').pop() + h)
    : (location.origin + location.pathname + h));
  var msg = $('urlmsg');
  if (msg) setText(msg, '');
}

function placeModeTip() {
  var tip = $('modetip'), b = st._tipBtn, mt = $('modetabs');
  if (!tip || !b || !mt) return;
  var off = b.getBoundingClientRect().left - mt.getBoundingClientRect().left;
  var pad = Math.max(0, off + b.offsetWidth / 2 - 7);
  /* せまい画面ではボタンが横いっぱいになるので、真下に置こうとすると文が右端に寄って読めない */
  tip.style.paddingLeft = Math.min(pad, Math.max(0, mt.clientWidth - 260)) + 'px';
}

/* ===== パネルの組み立て =====
   ★左の列の並び（今回のページの決めごと）★
   ① 再生ボタンと時間バー ② 変数のスライドバー ③ オレンジの状況ボタン
   ④ 表示チェック ⑤ キャンバス ⑥ 計算結果の帯 ⑦ 2点をくらべる式
   （② と ④ は1行に並べて図の上に置く） */
function buildPanel() {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  s._eq = null;
  st._ptSz = null; st._ptPos = null;
  var h = [];
  h.push('<div class="simhead"><div class="simtitle">' + mathHtml(d.title) + '</div></div>');
  h.push('<div class="simgrid"><div class="cv">');

  /* ① 再生ボタンと時間バー */
  h.push('<div class="ctrl playctrl">');
  h.push('<div class="btnrow">');
  h.push('<button id="bPlay">▶ スタート</button>');
  h.push('<button id="bSlow" class="sub">スロー再生</button>');
  h.push('<button id="bReset" class="sub">↺ リセット</button>');
  h.push('<span class="tspan"><label>時間 t</label><input type="range" id="tBar" min="0" max="1" step="0.01" value="0"><span class="tval" id="tVal">0.00 s</span></span>');
  h.push('</div>');
  h.push('<div class="mini" id="qhint"></div>');
  h.push('</div>');

  /* ②④ 変数のカード（左）と表示チェック（右） */
  var mainKeys = mainVarKeys(d);
  var mainList = [];
  mainKeys.forEach(function (k) {
    d.vars.forEach(function (vd) { if (vd.k === k) mainList.push(vd); });
  });
  h.push('<div class="cvtop toprow" id="cvtop">');
  h.push('<div class="cvvars' + (mainList.length > 3 ? ' two' : '') + '" id="cvvars">');
  mainList.forEach(function (vd) {
    h.push(varRowHtml(vd, 'a', focusOn(d, s, vd), d.mainVarFocus === vd.k));
  });
  h.push('</div>');
  h.push('<div class="cvside">');
  if (d.vis && d.vis.length) {
    h.push('<div class="opts">');
    d.vis.forEach(function (k) {
      h.push('<label><input type="checkbox" data-vis="show' + k + '"' + (s.o['show' + k] ? ' checked' : '') + '> ' + mathHtml(VIS_LABEL[k]) + '</label>');
    });
    h.push('</div>');
  }
  h.push('</div></div>');

  /* ③⑤ オレンジの状況ボタン（図の上）＋ キャンバス */
  h.push('<div class="cvstage' + ((d.actions && d.actions.length) ? ' topbar' : ' nobar') + '">');
  if (d.actions && d.actions.length) {
    h.push('<div class="cvbar top"><div class="acts n' + Math.min(4, d.actions.length) + '">');
    d.actions.forEach(function (a, i) {
      h.push('<button class="' + (a.jump ? 'sub jump' : 'warm') + '" data-act="' + i + '" id="act_' + i + '">' + a.label + '</button>');
    });
    h.push('</div></div>');
  }
  h.push('<div class="cvwrap"><canvas id="mainCv"></canvas><div class="ptbubs" id="ptbubs"></div></div>');
  h.push('</div>');

  /* 図のすぐ下の「ひとこと」（スタートを押してから出る） */
  h.push('<div class="cvhint" id="cvhint" hidden></div>');
  /* ⑥ 計算結果の帯 */
  h.push('<div class="resbar" id="resbar"></div>');
  /* ⑦ 立式（3つ）と「仕事を表示」。★図の下・左★（先生の指示・第4回）
        中身は renderEqZone が作る。運動が終わってから出す。 */
  h.push('<div class="eqzone" id="eqzone" hidden></div>');

  if (d.sub) h.push('<p class="cvsub">' + mathHtml(d.sub) + '</p>');
  h.push('<div class="eq" id="eqbox"></div>');
  h.push('</div><div class="side">');

  /* 右の列 */
  /* ★右の欄の切りかえ（先生の指示・第6回）★
     「エネルギーのグラフを表示」と「仕事の分析」を2つとも出し、
     いま選んでいるほうをオレンジに塗る（図の上のオレンジの状況ボタンと同じ作法）。 */
  h.push('<div class="wkbar"><div class="acts n2">' +
    '<button class="warm' + (st.workMode ? '' : ' on') + '" id="bGraphMode">エネルギーのグラフを表示</button>' +
    '<button class="warm' + (st.workMode ? ' on' : '') + '" id="bWork">仕事の分析</button>' +
    '</div><span class="wkbarhint">' + (st.workMode
      ? '力ごとの仕事が出ています。図の中の力をクリックしてみよう'
      : '「仕事の分析」にすると、力ごとの仕事に切りかわります') + '</span></div>');
  /* ★「仕事の分析」モードでは、グラフの欄をまるごとこれに入れかえる★ */
  h.push('<div class="wkpanel" id="wkpanel"' + (st.workMode ? '' : ' hidden') + '></div>');
  h.push('<div id="gwrap"' + (st.workMode ? ' hidden' : '') + '>');
  h.push('<div class="btnrow openrow"><button class="warm" id="bOpenAll">' + openAllLabel() + '</button>' +
    '<button class="sub" id="bBigFml">' + bigFmlLabel() + '</button>' +
    '<span class="ghint1">グラフの右上の <b>＋</b>／<b>－</b>／<b>もどす</b> で大きさを変えられます' +
    '（ドラッグ＝移動／目盛りの上でドラッグ＝その軸だけ拡大縮小／ホイール＝拡大縮小／ダブルクリック＝自動）</span></div>');

  graphsOf(d, s).forEach(function (g) {
    h.push('<div class="gsec"><button class="ghead" data-g="' + g.key + '"><span class="tri">' +
      (s.open[g.key] ? '▼' : '▶') + '</span>' + mathHtml(g.title) + '</button>' +
      '<div class="gbody' + (s.open[g.key] ? '' : ' hide') + (st.bigFml ? ' bigf' : '') + '" id="gb_' + g.key + '">' +
      /* ★グラフの拡大・縮小ボタン★（第9回）
         ドラッグだけだと、はじめて見る生徒やスマホ・タブレットでは分かりにくいので、
         右上に ＋ / － / もどす を出す。 */
      '<div class="gleft"><div class="gzoom"><span class="gzl">グラフの大きさ</span>' +
      '<button type="button" data-gz="in" data-gk="' + g.key + '" title="拡大">＋</button>' +
      '<button type="button" data-gz="out" data-gk="' + g.key + '" title="縮小">－</button>' +
      '<button type="button" class="gzr" data-gz="reset" data-gk="' + g.key +
      '" title="はじめの大きさにもどす">もどす</button></div>' +
      '<canvas id="gc_' + g.key + '"></canvas></div>' +
      (g.fml ? '<div class="gform" id="gf_' + g.key + '"></div>' : '<div class="gspacer"></div>') +
      '</div></div>');
  });

  h.push('</div>');       /* #gwrap ここまで */
  /* ★第4回：右の列にあった「関係の箱」「保存則の箱」は、図の下の立式（#eqzone）へ移した★ */
  h.push('<div class="ptabwrap"><table class="ptab" id="ptab"></table></div>');
  h.push('<div class="note" id="notebox"><b>見るポイント</b>：' + mathHtml(d.note) + '</div>');

  var restCount = 0, rest = [];
  d.vars.forEach(function (vd) {
    if (mainKeys.indexOf(vd.k) >= 0) return;
    if (vd.when && !vd.when(V(s))) return;
    restCount++;
    rest.push(varRowHtml(vd, 'b'));
  });
  if (restCount) h.push('<div class="ctrl">' + rest.join('') + '</div>');
  h.push('<table class="read" id="readout"></table>');
  h.push('</div></div>');
  $('simhost').innerHTML = h.join('');

  /* --- イベント --- */
  $('bPlay').addEventListener('click', onPlay);
  $('bSlow').addEventListener('click', function () {
    s.slow = !s.slow;
    $('bSlow').className = s.slow ? '' : 'sub';
    $('bSlow').textContent = s.slow ? 'スロー再生 中' : 'スロー再生';
  });
  $('bReset').addEventListener('click', function () { s.t = 0; s.playing = false; setPlayLabel(); renderActive(); });
  $('tBar').addEventListener('input', function (e) {
    s.t = +e.target.value; s.playing = false; setPlayLabel(); renderActive();
  });
  /* 仕事の欄のクリック。
     ・「A点 → B点」のボタン … くらべる2点を変える（左下の立式の欄と共通の s.eqPair）
     ・力のカード           … ★図の中のその力が光る★（先生の指示・第7回。図→欄の逆） */
  $('wkpanel').addEventListener('click', function (e) {
    var el = e.target;
    while (el && el !== this) {
      if (el.getAttribute && el.getAttribute('data-pair')) {
        s.eqPair = +el.getAttribute('data-pair');
        st._fSel = null;
        renderActive();
        return;
      }
      if (el.id && el.id.indexOf('wkc_') === 0) { flashWork(el.id.slice(4)); return; }
      el = el.parentNode;
    }
  });

  /* 図の中の力にマウスを乗せる／クリックする（仕事の分析モードのときだけ効く） */
  (function () {
    var cv = $('mainCv');
    cv.addEventListener('mousemove', function (e) {
      if (!st.workMode) { if (cv.style.cursor) cv.style.cursor = ''; return; }
      var pt = cvPoint(cv, d, s, e);
      if (!pt) return;
      var b = hitAt(pt), k = b ? b.key : null;
      var want = b ? 'pointer' : '';
      if (cv.style.cursor !== want) cv.style.cursor = want;
      if (st._fHover !== k) { st._fHover = k; renderActive(); }
    });
    cv.addEventListener('mouseleave', function () {
      cv.style.cursor = '';
      if (st._fHover) { st._fHover = null; renderActive(); }
    });
    cv.addEventListener('click', function (e) {
      if (!st.workMode) return;
      var pt = cvPoint(cv, d, s, e);
      if (!pt) return;
      var b = hitAt(pt);
      if (b) flashWork(b.key);
    });
  })();

  /* 「仕事の分析」⇄「エネルギーのグラフ」の切りかえ（★全シムで共有★） */
  function setWorkMode(on) {
    if (st.workMode === on) return;
    st.workMode = on;
    st._fSel = null;
    buildPanel();
    renderActive();
  }
  $('bWork').addEventListener('click', function () { setWorkMode(true); });
  $('bGraphMode').addEventListener('click', function () { setWorkMode(false); });
  $('bOpenAll').addEventListener('click', function () { toggleAllGraphs(); });
  $('bBigFml').addEventListener('click', function () { toggleBigFml(); });
  if (st.bigFml) $('bBigFml').className = '';

  Array.prototype.forEach.call($('simhost').querySelectorAll('.ghead'), function (b) {
    b.addEventListener('click', function () {
      var k = b.getAttribute('data-g');
      s.open[k] = !s.open[k];
      $('gb_' + k).className = 'gbody' + (s.open[k] ? '' : ' hide') + (st.bigFml ? ' bigf' : '');
      b.querySelector('.tri').textContent = s.open[k] ? '▼' : '▶';
      $('bOpenAll').innerHTML = openAllLabel();
      renderMath($('bOpenAll'));
      renderActive();
    });
  });
  /* 立式の3つの開閉と、くらべる2点の選択。
     #eqzone の中身は作り直されるので、外側の箱に1つだけ付けて委譲する。 */
  $('eqzone').addEventListener('click', function (e) {
    var el = e.target, k = null, pr = null, sc = null, kd = null;
    while (el && el !== this) {
      if (el.getAttribute) {
        if (el.getAttribute('data-sc')) {              /* モード3の 2×3 ボタン */
          sc = el.getAttribute('data-sc'); kd = el.getAttribute('data-kd'); break;
        }
        if (el.getAttribute('data-eqk')) { k = el.getAttribute('data-eqk'); break; }
        if (el.getAttribute('data-pair')) { pr = +el.getAttribute('data-pair'); break; }
      }
      el = el.parentNode;
    }
    if (sc) {
      s.eq3 = { scope: sc, kind: kd };
      $('eqzone')._key = null;
      renderActive();
    } else if (k) {
      var op = eqOpenOf(d, s);
      op[k] = !op[k];
      applyEqOpen(d, s);
      fitFormula($('eqzone'));
    } else if (pr !== null) {
      s.eqPair = pr;
      st._fSel = null;            /* 2点を変えたら、力の選択はいったん解除 */
      renderActive();
    }
  });
  $('eqzone').addEventListener('change', function (e) {
    if (!e.target || e.target.id !== 'cbAllEq') return;
    st.allEq = !!e.target.checked;
    /* ★全シムで共有★ ON にしたら、どのシミュレーションでも3つとも開く */
    Object.keys(st.sims).forEach(function (id) { st.sims[id].eqOpen = null; });
    if (!st.allEq) s.eqOpen = null;
    applyEqOpen(d, s);
    fitFormula($('eqzone'));
  });

  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-act]'), function (b) {
    b.addEventListener('click', function () {
      var a = d.actions[+b.getAttribute('data-act')];
      if (a.jump) { gotoSim(a.jump); return; }      /* 別のシミュレーションへ飛ぶボタン */
      a.fn(s);
      resetSim();
      syncVarVals(); renderActive();
    });
  });
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-vis]'), function (el) {
    el.addEventListener('change', function () { s.o[el.getAttribute('data-vis')] = el.checked; renderActive(); });
  });
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-vsl]'), function (r) {
    r.addEventListener('input', function () { setVar(r.getAttribute('data-vsl'), +r.value); });
  });
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-var]'), function (b) {
    b.addEventListener('click', function () { stepVar(b.getAttribute('data-var'), +b.getAttribute('data-dir')); });
  });
  graphsOf(d, s).forEach(function (g) { attachGraphDrag($('gc_' + g.key), g.key); });
  Array.prototype.forEach.call($('simhost').querySelectorAll('[data-gz]'), function (b) {
    b.addEventListener('click', function (e) {
      e.stopPropagation();
      graphZoom(b.getAttribute('data-gk'), b.getAttribute('data-gz'));
    });
  });

  setPlayLabel();
  $('bSlow').className = s.slow ? '' : 'sub';
  $('bSlow').textContent = s.slow ? 'スロー再生 中' : 'スロー再生';
  syncVarVals();
  renderMath($('simhost'));
}

/* 「よく変える変数」＝図の上のカードに出すもの */
function mainVarKeys(d) {
  if (d.mainVars === '*') return d.vars.map(function (x) { return x.k; });
  if (d.mainVars) return d.mainVars;
  return d.vars.slice(0, 2).map(function (x) { return x.k; });
}

function focusOn(d, s, vd) {
  return !!(d.mainVarFocus && d.mainVarFocus === vd.k && Math.abs(s.v[vd.k] - vd.def) < 1e-9);
}

function varRowHtml(vd, tag, focus, focusable) {
  var lab = (tag === 'a') ? vd.label.replace(/（[^）]*）/g, '') : vd.label;
  if (focusable) lab += ' <span class="tryme"' + (focus ? '' : ' style="display:none"') + '>変えてみよう</span>';
  var h = '<div class="vrow' + (focus ? ' focus' : '') + '" data-vrow="' + vd.k + '">' +
    '<span class="vlab">' + mathHtml(lab) + '</span>' +
    '<button class="stp" data-var="' + vd.k + '" data-dir="-1">−</button>' +
    '<span class="vval" data-vval="' + vd.k + '"></span>' +
    '<button class="stp" data-var="' + vd.k + '" data-dir="1">＋</button>';
  if (tag === 'a') {
    h += '<input type="range" class="vsl" data-vsl="' + vd.k + '" ' +
      'min="' + vd.min + '" max="' + vd.max + '" step="' + vd.step + '">';
  }
  return h + '</div>';
}

/* ===== 再生 ===== */
function onPlay() {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  var T = d.tEnd(V(s));
  if (s.t >= T - 1e-9) s.t = 0;
  s.playing = !s.playing;
  if (s.playing) s._played = true;
  if (s.playing && s.t < 1e-9 && d.startSfx) sfx(d.startSfx);
  setPlayLabel();
  renderActive();
}

/* いまの状態がすでに条件を満たしているボタンを、少し濃く見せる。
   next(s,t,v) を書いておくと「次はこれを押す」ときにオレンジで点滅する。 */
function refreshActs() {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  if (!d.actions) return;
  d.actions.forEach(function (a, i) {
    var b = $('act_' + i);
    if (!b) return;
    if (a.jump) { setCls(b, 'sub jump'); return; }
    var on = a.is ? !!a.is(V(s), s) : false;
    var nx = (!on && a.next) ? !!a.next(s, s.t, V(s)) : false;
    setCls(b, 'warm' + (on ? ' on' : '') + (nx ? ' pulse' : ''));
  });
}

function openAllLabel() {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  var closed = [];
  graphsOf(d, s).forEach(function (g) { if (!s.open[g.key]) closed.push(g.short || g.title); });
  if (!closed.length) return '最初の表示にもどす（重ねた図だけにする）';
  return mathHtml(closed.join('・') + ' をまとめて開く');
}

function bigFmlLabel() { return st.bigFml ? '式をもとの大きさに' : '式を拡大'; }

function toggleBigFml() {
  st.bigFml = !st.bigFml;
  Array.prototype.forEach.call(document.querySelectorAll('#simhost .gbody'), function (b) {
    b.className = b.className.replace(' bigf', '') + (st.bigFml ? ' bigf' : '');
  });
  var bt = $('bBigFml');
  if (bt) { bt.textContent = bigFmlLabel(); bt.className = st.bigFml ? '' : 'sub'; }
  refitFormulas();
}

function toggleAllGraphs() {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  var closed = graphsOf(d, s).some(function (g) { return !s.open[g.key]; });
  (d.graphs || []).forEach(function (g) { s.open[g.key] = closed ? true : !!g.open; });
  graphsOf(d, s).forEach(function (g) {
    var body = $('gb_' + g.key), head = $('simhost').querySelector('.ghead[data-g="' + g.key + '"]');
    if (body) body.className = 'gbody' + (s.open[g.key] ? '' : ' hide') + (st.bigFml ? ' bigf' : '');
    if (head) head.querySelector('.tri').textContent = s.open[g.key] ? '▼' : '▶';
  });
  $('bOpenAll').innerHTML = openAllLabel();
  renderMath($('bOpenAll'));
  renderActive();
}

/* ===== グラフのドラッグ（移動・軸の拡大縮小） ===== */
function attachGraphDrag(cv, key) {
  if (!cv) return;
  var drag = null;
  function local(e) {
    var mp = cv._map, r = cv.getBoundingClientRect();
    return { x: (e.clientX - r.left) / r.width * mp.W, y: (e.clientY - r.top) / r.height * mp.H };
  }
  function cur() {
    var s = st.sims[st.cur];
    if (s.gview[key]) return s.gview[key];
    var mp = cv._map;
    return { xmin: mp.xmin, xmax: mp.xmax, ymin: mp.ymin, ymax: mp.ymax };
  }
  cv.addEventListener('pointerdown', function (e) {
    if (!cv._map) return;
    var p = local(e), mp = cv._map;
    var mode = 'pan';
    if (p.x < mp.pad.l) mode = 'sy';
    else if (p.y > mp.pad.t + mp.gh) mode = 'sx';
    drag = { p: p, view: cur(), mode: mode };
    cv.setPointerCapture(e.pointerId);
    e.preventDefault();
  });
  cv.addEventListener('pointermove', function (e) {
    if (!drag || !cv._map) return;
    var s = st.sims[st.cur], mp = cv._map, p = local(e);
    var dx = p.x - drag.p.x, dy = p.y - drag.p.y, v0 = drag.view, nv;
    if (drag.mode === 'pan') {
      var kx = (v0.xmax - v0.xmin) / mp.gw, ky = (v0.ymax - v0.ymin) / mp.gh;
      nv = { xmin: v0.xmin - dx * kx, xmax: v0.xmax - dx * kx, ymin: v0.ymin + dy * ky, ymax: v0.ymax + dy * ky };
    } else if (drag.mode === 'sx') {
      var f = Math.exp(-dx / 110), c = (v0.xmin + v0.xmax) / 2, hh = (v0.xmax - v0.xmin) / 2 * f;
      nv = { xmin: c - hh, xmax: c + hh, ymin: v0.ymin, ymax: v0.ymax };
    } else {
      var f2 = Math.exp(dy / 110), c2 = (v0.ymin + v0.ymax) / 2, h2 = (v0.ymax - v0.ymin) / 2 * f2;
      nv = { xmin: v0.xmin, xmax: v0.xmax, ymin: c2 - h2, ymax: c2 + h2 };
    }
    s.gview[key] = nv;
    renderActive();
    e.preventDefault();
  });
  function end() { drag = null; }
  cv.addEventListener('pointerup', end);
  cv.addEventListener('pointercancel', end);
  cv.addEventListener('wheel', function (e) {
    if (!cv._map) return;
    var s = st.sims[st.cur], mp = cv._map, p = local(e), v0 = cur();
    var f = Math.exp(e.deltaY * 0.0014);
    var px = v0.xmin + (p.x - mp.pad.l) / mp.gw * (v0.xmax - v0.xmin);
    var py = v0.ymax - (p.y - mp.pad.t) / mp.gh * (v0.ymax - v0.ymin);
    s.gview[key] = {
      xmin: px - (px - v0.xmin) * f, xmax: px + (v0.xmax - px) * f,
      ymin: py - (py - v0.ymin) * f, ymax: py + (v0.ymax - py) * f
    };
    renderActive();
    e.preventDefault();
  }, { passive: false });
  cv.addEventListener('dblclick', function () {
    delete st.sims[st.cur].gview[key];
    renderActive();
  });
}

/* ★グラフの ＋ / － / もどす ★（第9回）
   まん中をそのままにして、たてよこ同じ割合で広げたり縮めたりする。
   「もどす」は自分で決めた見え方を捨てて、自動の目もりにもどす。 */
function graphZoom(key, kind) {
  var s = st.sims[st.cur], cv = $('gc_' + key);
  if (kind === 'reset') { delete s.gview[key]; renderActive(); return; }
  if (!cv || !cv._map) return;
  var mp = cv._map;
  var v0 = s.gview[key] || { xmin: mp.xmin, xmax: mp.xmax, ymin: mp.ymin, ymax: mp.ymax };
  var f = (kind === 'in') ? 1 / 1.4 : 1.4;
  var cxx = (v0.xmin + v0.xmax) / 2, cyy = (v0.ymin + v0.ymax) / 2;
  var hx = (v0.xmax - v0.xmin) / 2 * f, hy = (v0.ymax - v0.ymin) / 2 * f;
  s.gview[key] = { xmin: cxx - hx, xmax: cxx + hx, ymin: cyy - hy, ymax: cyy + hy };
  renderActive();
}

function setPlayLabel() {
  var s = st.sims[st.cur], b = $('bPlay');
  if (!b) return;
  if (s.playing) { setText(b, '❚❚ 一時停止'); setCls(b, ''); return; }
  setText(b, '▶ スタート');
  /* ★止まっているあいだは、いつでもスタートを光らせる★（先生の指示・第11回）
     前は「まだ一度も動かしていないシムだけ」光らせていたので、
     一度でも見たシムにもどるとボタンが光らず、シムによって見え方がちがった。
     押せば（終わっていても）はじめから動きだすので、止まっている＝次に押すところ。 */
  setCls(b, 'pulse');
  var hint = $('qhint');
  if (hint) {
    var d = DEFS[st.cur];
    var txt = mathHtml(s._played ? (d.hint2 || '')
      : '<span class="nextmark">① まず「スタート」</span>：運動を最後まで見ると、図に吹きだしと式が出ます。');
    if (hint.innerHTML !== txt) { hint.innerHTML = txt; renderMath(hint); }
    hint.style.display = txt ? '' : 'none';
  }
}

function resetSim() {
  var s = st.sims[st.cur];
  s.t = 0; s.playing = false; s.gview = {}; s._sfx = null;
  /* 設定を変えたら、仕事の分析も「まだ最後まで進めていない」にもどす */
  s._wkReady = false;
  setPlayLabel();
}

function setVar(k, val) {
  var d = DEFS[st.cur], s = st.sims[st.cur], vd = null;
  d.vars.forEach(function (x) { if (x.k === k) vd = x; });
  if (!vd) return;
  var nv = clamp(Math.round(val / vd.step) * vd.step, vd.min, vd.max);
  if (Math.abs(nv - s.v[k]) < 1e-9) return;
  s.v[k] = +nv.toFixed(6);
  if (d.onVar) d.onVar(s, k);
  resetSim(); syncVarVals(); renderActive();
}

function stepVar(k, dir) {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  var vd = null;
  d.vars.forEach(function (x) { if (x.k === k) vd = x; });
  if (!vd) return;
  var nv = s.v[k] + dir * vd.step;
  nv = clamp(Math.round(nv / vd.step) * vd.step, vd.min, vd.max);
  s.v[k] = +nv.toFixed(6);
  if (d.onVar) d.onVar(s, k);
  resetSim(); syncVarVals(); renderActive();
}

function syncVarVals() {
  var d = DEFS[st.cur], s = st.sims[st.cur], host = $('simhost');
  if (!host) return;
  d.vars.forEach(function (vd) {
    var txt = (vd.fmt ? vd.fmt(s.v[vd.k]) : fmt(s.v[vd.k], vd.dec) + vd.unit);
    Array.prototype.forEach.call(host.querySelectorAll('[data-vval="' + vd.k + '"]'), function (el) {
      setText(el, txt);
    });
    Array.prototype.forEach.call(host.querySelectorAll('[data-vsl="' + vd.k + '"]'), function (r) {
      if (+r.value !== s.v[vd.k]) r.value = s.v[vd.k];
    });
    if (d.mainVarFocus === vd.k) {
      var on = focusOn(d, s, vd);
      Array.prototype.forEach.call(host.querySelectorAll('[data-vrow="' + vd.k + '"]'), function (row) {
        setCls(row, 'vrow' + (on ? ' focus' : ''));
        var tip = row.querySelector('.tryme');
        if (tip) tip.style.display = on ? '' : 'none';
      });
    }
  });
}

/* ===== グラフを描く ===== */
function seriesPts(d, s, g, T) {
  var N = 180, out = [], i, v = V(s);
  g.series.forEach(function () { out.push([]); });
  for (i = 0; i <= N; i++) {
    var t = T * i / N;
    var m = d.sample(v, t);
    g.series.forEach(function (se, j) { out[j].push([t, se.f(m, v, t)]); });
  }
  return out;
}

function niceXMax(T) {
  var Tx = Math.max(0.2, T);
  var st2 = niceStep(Tx, 6);
  var xm = Math.ceil(Tx / st2 - 1e-9) * st2;
  return (xm < Tx * (1 + 1e-9)) ? xm + st2 : xm;
}

function renderGraphs(d, s, T, t) {
  var v = V(s), m = d.sample(v, t);
  graphsOf(d, s).forEach(function (g) {
    if (!s.open[g.key]) return;
    var cv = $('gc_' + g.key);
    if (!cv) return;
    var pts = seriesPts(d, s, g, T);
    var lo = Infinity, hi = -Infinity;
    pts.forEach(function (p) { p.forEach(function (q) { if (isFinite(q[1])) { lo = Math.min(lo, q[1]); hi = Math.max(hi, q[1]); } }); });
    if (!isFinite(lo)) { lo = -1; hi = 1; }
    var r = niceRange(Math.min(0, lo), hi);
    if (lo >= -1e-9) r.lo = 0;                      /* エネルギーは負にならないので 0 から見せる */
    plot(cv, {
      xlabel: 't [s]', ylabel: g.ylabel, H: g.H,
      xmin: 0, xmax: niceXMax(T), xstep: niceStep(Math.max(0.2, T), 6), ymin: r.lo, ymax: r.hi,
      view: s.gview[g.key],
      series: g.series.map(function (se, j) {
        return { color: se.color, dash: se.dash, width: se.width, pts: pts[j],
          fillTo: (typeof se.fillTo === 'function') ? se.fillTo(v) : se.fillTo };
      }),
      cursors: g.series.map(function (se) { return { color: se.color, x: t, y: se.f(m, v, t) }; }),
      legend: (g.legend === true) ? g.series.map(function (se) {
        return { name: se.name, color: se.color, dash: se.dash, width: se.width };
      }) : (g.legend || null)
    });
  });
}

/* 各グラフの右に出す3段の式 */
function renderFormulas(d, s) {
  graphsOf(d, s).forEach(function (g) {
    if (!g.fml || !s.open[g.key]) return;
    var box = $('gf_' + g.key);
    if (!box) return;
    var arr = g.fml(V(s), s);
    var fn = g.fnote ? (typeof g.fnote === 'function' ? g.fnote(V(s), s) : g.fnote) : '';
    var key = arr.join('|') + '||' + fn;
    var bw = box.clientWidth;
    if (box._key === key && box._bw === bw) return;
    box._key = key; box._bw = bw;
    var names = ['公式', '代入', '数値'];
    box.innerHTML = arr.map(function (x, i) {
      return '<div class="fl f' + (i + 1) + '"><span class="fk">' + names[i] + '</span><span class="fv"><span class="tex">' + escTex(x) + '</span></span></div>';
    }).join('') + (fn ? '<div class="fnote">' + fn + '</div>' : '');
    renderMath(box);
    fitFormula(box);
    requestAnimationFrame(function () { fitFormula(box); });
  });
}

function fitFormula(box) {
  Array.prototype.forEach.call(box.querySelectorAll('.fv'), function (fv) {
    var inner = fv.firstElementChild;
    if (!inner) return;
    var k = inner._k || 1;
    var w = inner.getBoundingClientRect().width / k;
    var avail = fv.clientWidth;
    if (avail < 20 || w < 1) return;
    var nk = (w > avail) ? Math.max(0.5, (avail - 3) / w) : 1;
    if (Math.abs(nk - k) > 0.004) {
      inner._k = nk;
      inner.style.transform = nk < 1 ? 'scale(' + nk.toFixed(3) + ')' : '';
    }
  });
}

function refitFormulas() {
  Array.prototype.forEach.call(document.querySelectorAll('.gform'), function (b) { b._key = null; });
  renderActive();
}

/* ===== ⑥ 計算結果の帯 ===== */
function resultItems(d, s, t) {
  var v = V(s), m = d.sample(v, t), out = [];
  out.push({ k: '速さ $v$', v: fmt(m.v, 2) + ' m/s' });
  if (d.showH !== false) out.push({ k: '基準面からの高さ $h$', v: fmt(m.h, 2) + ' m' });
  out.push({ k: '運動エネルギー $K$', v: fmtJ(m.K), col: 'eK' });
  out.push({ k: '位置エネルギー $U$', v: fmtJ(m.U), col: 'eU' });
  out.push({ k: '力学的エネルギー $E$', v: fmtJ(m.E), kbox: true });
  if (!consOf(d, v)) {
    out.push({ k: '非保存力の仕事 $W$', v: fmtJ(m.W) });
    /* W < 0 のときだけ「失われた」。2-5 のように W > 0 のシムでは「増えた」にする */
    out.push(m.W > 1e-9 ? { k: '増えたエネルギー', v: fmtJ(m.W) }
      : { k: '失われたエネルギー', v: fmtJ(-m.W) });
  }
  if (d.resItems) d.resItems(v, s, t).forEach(function (x) { out.push(x); });
  return out;
}

function renderResult(d, s, t) {
  var box = $('resbar');
  if (!box) return;
  var items = resultItems(d, s, t);
  var key = items.map(function (x) { return x.k + (x.kbox ? '!' : '') + (x.col || ''); }).join('|');
  if (box._key !== key) {
    box.innerHTML = items.map(function (x) {
      return '<span class="ritem' + (x.kbox ? ' kbox' : '') + (x.col ? ' c-' + x.col : '') + '">' +
        '<span class="rk">' + mathHtml(x.k) + '</span><span class="rv"></span></span>';
    }).join('');
    box._key = key;
    renderMath(box);
  }
  var vs = box.querySelectorAll('.rv');
  items.forEach(function (x, i) { if (vs[i]) setText(vs[i], x.v); });
}

/* ===== 点のエネルギーの吹きだし（HTML・KaTeX） =====
   ★点のすぐ近くに置く。置き場所は canvas 側（drawPts）が
   　「物体・文字と重ならないところ」を選んで st._ptPos に入れる。★
   文字の大きさは canvas の表示倍率 --ptk に合わせるので、
   どの画面幅でも「図に対する大きさ」が変わらない（＝置き場所の計算がずれない）。 */
function preparePtBubbles(d, s, t) {
  var host = $('ptbubs');
  if (!host) return;
  if (!endOn(d, s, t)) { if (host.style.display !== 'none') host.style.display = 'none'; return; }
  host.style.display = '';
  var v = V(s), ps = bubPts(d, v), cv = $('mainCv');
  var k = (cv && cv.clientWidth) ? cv.clientWidth / d.cw : 1;
  host.style.setProperty('--ptk', k.toFixed(4));
  var key = ps.map(function (p) { return p.name + '|' + ptTex(d, p) + '|' + fmt(p.m.E, 2); }).join('/');
  if (host._key !== key) {
    host._key = key;
    host.innerHTML = ps.map(function (p) {
      return '<div class="ptbub" data-pt="' + p.name + '">' +
        '<span class="pn">' + p.name + '</span>' +
        '<span class="tex">' + escTex(ptTex(d, p)) + '</span>' +
        '<span class="pv">= ' + fmtJ(p.m.E) + '</span></div>';
    }).join('');
    renderMath(host);
    st._ptSz = null;
  }
  if (!st._ptSz) {                         /* 大きさを測るのは中身が変わったときだけ */
    st._ptSz = {};
    Array.prototype.forEach.call(host.children, function (el) {
      st._ptSz[el.getAttribute('data-pt')] = { w: el.offsetWidth / k, h: el.offsetHeight / k };
    });
  }
}

function placePtBubbles(d, ch) {
  var host = $('ptbubs');
  if (!host || !st._ptPos) return;
  st._ptPos.forEach(function (q) {
    var el = host.querySelector('[data-pt="' + q.name + '"]');
    if (!el) return;
    var L = (q.x / d.cw * 100).toFixed(3) + '%', T = (q.y / ch * 100).toFixed(3) + '%';
    if (el.style.left !== L) el.style.left = L;
    if (el.style.top !== T) el.style.top = T;
  });
}

/* 図のすぐ下の「ひとこと」。スタートを押してから出す（先に答えを見せない）。 */
function renderFigHint(d, s, t) {
  var el = $('cvhint');
  if (!el) return;
  var txt = (d.hintFig && hintOn(s, t)) ? d.hintFig : '';
  if (el._key !== txt) {
    el._key = txt;
    el.innerHTML = mathHtml(txt);
    renderMath(el);
  }
  if (el.hidden === !!txt) el.hidden = !txt;
}

/* ===== ⑦ 図の下の「立式」3つ（★先生の指示・第4回／第5回で2点を選べるように★） =====
   ・並びは ① 力学的エネルギー保存則 ② 力学的エネルギーと非保存力の仕事の関係
     ③ 運動エネルギーと仕事の関係。
   ・はじめに開いておくのは、保存するなら①だけ、保存しないなら①と②。
   ・「3つの式を表示」のチェックは st.allEq（★全シム共通★）。ON なら3つとも開く。
   ・見出しは「A点とB点の間で立式する」。点が3つ以上なら
     「A点とB点」「A点とC点」…をボタンで選べる（s.eqPair）。
   ・「仕事を表示」は第5回で右の列（#wkpanel・仕事の分析モード）へ移した。
   ・答えを先に見せないため、運動が終わってから（endOn）出す。 */

/* この図で開いておく式（まだ決めていなければ、保存の成否と st.allEq から決める） */
function eqOpenOf(d, s) {
  if (!s.eqOpen) {
    var ok = consOf(d, V(s));
    s.eqOpen = st.allEq ? { cons: true, rel: true, wk: true }
      : { cons: true, rel: !ok, wk: false };
  }
  return s.eqOpen;
}

/* いま立式している2つめの点の番号 */
function eqPairOf(d, s) {
  return pairJ(d, V(s), s.eqPair);
}

function eqZoneKey(d, s, secs) {
  var a = secs.map(function (q) { return q.badge + '|' + q.sym + '|' + q.num; }).join('#');
  return a + '@' + (st.allEq ? '1' : '0') + '@' + eqPairOf(d, s);
}

/* ===== モード3：2（対象）× 3（式の種類）＝ 6パターンの切りかえ ===== */
function renderEqZone3(d, s, box) {
  var v = V(s), jj = eqPairOf(d, s), sel = s.eq3 || (s.eq3 = { scope: 'both', kind: 'cons' });
  var list = eq3Pick(d, v, jj, sel.scope, sel.kind);
  if (!list.length) return;
  var key = sel.scope + '/' + sel.kind + '/' + st.cur + '/' + JSON.stringify(v) + '/' + jj;
  if (box._key === key) return;
  box._key = key;
  var ps = ptsOf(d, v), h = [];
  h.push('<div class="eqztop"><span class="eqztitle">' +
    ps[0].jp + 'と' + ps[pairJ(d, v, jj)].jp + 'の間で立式する</span></div>');
  /* 2×3 のボタン（列＝対象、行＝式の種類） */
  h.push('<div class="eq3grid"><div class="eq3hd"></div>' +
    '<div class="eq3click">↓をクリック</div>');
  h.push('<div class="eq3hd"></div>');
  EQ3_SCOPES.forEach(function (sc) { h.push('<div class="eq3hd">' + sc.label + '</div>'); });
  EQ3_KINDS.forEach(function (kd, i) {
    h.push('<div class="eq3row"><span class="eq3no">' + '①②③'.charAt(i) + '</span>' +
      mathHtml(kd.label) + '<span class="eq3sub">' + kd.sub + '</span></div>');
    EQ3_SCOPES.forEach(function (sc) {
      var ok = eq3Ok(d, v, sc.k, kd.k);
      var on = (sel.scope === sc.k && sel.kind === kd.k);
      h.push('<button class="eq3b' + (ok ? ' ok' : ' ng') + (on ? ' on' : '') +
        '" data-sc="' + sc.k + '" data-kd="' + kd.k + '">' + (ok ? '○' : '✕') + '</button>');
    });
  });
  h.push('</div>');
  /* 選んだパターンの中身 */
  list.forEach(function (q) {
    h.push('<div class="eqsec ' + (q.ok ? 'ok' : 'ng') + ' open">' +
      '<div class="eqhead eq3head"><span class="badge">' + (q.ok ? '○ 成り立つ' : '✕ 成り立たない') +
      '</span><span class="eqttl">' + q.who + '</span></div>' +
      '<div class="eqbody">' +
      '<div class="enqline symline"><span class="fk">記号</span><span class="fv"><span class="tex">' +
      escTex(q.sym) + '</span></span></div>' +
      '<div class="enqline"><span class="fk">中身</span><span class="fv"><span class="tex">' +
      escTex(q.sym2) + '</span></span></div>' +
      '<div class="enqline"><span class="fk num">数値</span><span class="fv"><span class="tex">' +
      escTex(q.num) + '</span></span></div>' +
      '<div class="eqnote">' + mathHtml(q.note) + '</div></div></div>');
  });
  /* ★千葉さんの指示：この2つのケースの説明を、いつも下に出す★ */
  var cs = case3(d, v);
  h.push('<div class="eq3case"><div class="eq3ct">' +
    '※受験物理で2物体のエネルギーが問われる問題の大半は、以下のケース1。</div>' +
    '<div class="eq3c' + (cs === 1 ? ' now' : '') + '"><b>ケース1</b>　1物体ずつ見ると力学的エネルギーが保存せず、' +
    '2物体全体でみると保存。<span class="eq3cn">（摩擦がないケースが多い）</span>' +
    (cs === 1 ? '<span class="eq3now">← いまの図はこちら</span>' : '') + '</div>' +
    '<div class="eq3c' + (cs === 2 ? ' now' : '') + '"><b>ケース2</b>　1物体ずつ見ると力学的エネルギーが保存せず、' +
    '2物体全体でみても保存しない。<span class="eq3cn">（摩擦があるケースが多い）</span>' +
    (cs === 2 ? '<span class="eq3now">← いまの図はこちら</span>' : '') + '</div></div>');
  box.innerHTML = h.join('');
  renderMath(box);
  fitFormula(box);
  requestAnimationFrame(function () { fitFormula(box); });
}

function renderEqZone(d, s, t) {
  var box = $('eqzone');
  if (!box) return;
  if (!endOn(d, s, t)) {
    if (!box.hidden) { box.hidden = true; box._key = null; }
    return;
  }
  if (d.mode === 3) { box.hidden = false; box.classList.add('eq3pop'); renderEqZone3(d, s, box); return; }
  box.classList.remove('eq3pop');
  var v = V(s), jj = eqPairOf(d, s), secs = eqSections(d, v, jj), prs = pairsOf(d, v);
  if (!secs.length) return;
  box.hidden = false;
  var key = eqZoneKey(d, s, secs);
  if (box._key !== key) {
    box._key = key;
    var h = [];
    /* 見出し：2点が1組だけなら文だけ、2組以上ならボタンで選ばせる */
    h.push('<div class="eqztop"><span class="eqztitle">');
    if (prs.length <= 1) {
      h.push(prs.length ? prs[0].name + 'の間で立式する' : '2点の間で立式する');
    } else {
      h.push('<span class="eqpairs">');
      prs.forEach(function (q) {
        h.push('<button class="eqpair' + (q.j === jj ? ' on' : '') + '" data-pair="' + q.j + '">' +
          q.name + '</button>');
      });
      h.push('</span>の間で立式する');
    }
    h.push('</span><label class="eqzall"><input type="checkbox" id="cbAllEq"' +
      (st.allEq ? ' checked' : '') + '> 3つの式を表示</label></div>');
    secs.forEach(function (q) {
      h.push('<div class="eqsec ' + (q.ok ? 'ok' : 'ng') + '" id="eqs_' + q.key +
        '" data-base="eqsec ' + (q.ok ? 'ok' : 'ng') + '">' +
        '<button class="eqhead" data-eqk="' + q.key + '"><span class="tri">▶</span>' +
        '<span class="badge">' + q.badge + '</span>' +
        '<span class="eqttl">' + q.title + '</span>' +
        '<span class="eqsub">' + mathHtml(q.sub) + '</span></button>' +
        '<div class="eqbody">' +
        /* ★成り立たない式には、記号の行にバツ印を重ねる★（先生の指示・第8回） */
        '<div class="enqline symline"><span class="fk">記号</span><span class="fv"><span class="tex">' +
        escTex(q.sym) + '</span></span></div>' +
        '<div class="enqline"><span class="fk num">数値</span><span class="fv"><span class="tex">' +
        escTex(q.num) + '</span></span></div>' +
        '<div class="eqnote">' + mathHtml(q.note) + '</div></div></div>');
    });
    box.innerHTML = h.join('');
    renderMath(box);
    applyEqOpen(d, s);
    fitFormula(box);
    requestAnimationFrame(function () { fitFormula(box); });
  }
}

/* 開閉のクラスだけを付けかえる（中身は作り直さない） */
function applyEqOpen(d, s) {
  var op = eqOpenOf(d, s);
  ['cons', 'rel', 'wk'].forEach(function (k) {
    var el = $('eqs_' + k);
    if (!el) return;
    var on = !!op[k], base = el.getAttribute('data-base') || 'eqsec';
    setCls(el, base + (on ? ' open' : ''));
    var tri = el.querySelector('.tri');
    if (tri) setText(tri, on ? '▼' : '▶');
  });
}

/* ===== 「仕事の分析」の欄（右の列。グラフと入れかえ）★先生の指示・第5回★ =====
   ・その図ではたらく力の仕事を、★ぜんぶまとめて★出す（1つずつ選ぶのはやめた）。
   ・図の中の力をクリックすると、その力の枠がピカッと光る（.flash）。 */
function wkPanelKey(d, s, fs, jj) {
  return fs.map(function (f) { return f.name + '|' + fmt(f.W, 3); }).join('#') + '@' + jj;
}

function renderWorkPanel(d, s, t) {
  var el = $('wkpanel');
  if (!el || !st.workMode) return;
  var v = V(s), jj = eqPairOf(d, s), ps = ptsOf(d, v);
  var A = ps[0], B = ps[pairJ(d, v, jj)];
  /* ★一度でも最後まで進めたら、時間バーをもどしても表は出したまま★
     こうすると「とちゅうの姿で力をクリックする」ことができる（ばねの力など、
     終わりの瞬間には 0 になっていて図に出ない力があるため）。 */
  if (!s._wkReady) {
    var k0 = 'wait|' + A.name + B.name;
    if (el._key !== k0) {
      el._key = k0;
      el.innerHTML = '<div class="wkhead">仕事の分析</div>' +
        '<div class="wkwait">▶ スタートをおして、運動を最後まで進めてください。<br>' +
        'そのあと、はたらいた力それぞれの<b>仕事</b>がここに出ます。</div>';
    }
    return;
  }
  var fs = forcesOf(d, v, jj), tot = 0, i;
  for (i = 0; i < fs.length; i++) tot += fs[i].W;
  var key = wkPanelKey(d, s, fs, jj);
  if (el._key === key) return;
  el._key = key;
  var h = [], prs = pairsOf(d, v);
  h.push('<div class="wkhead">仕事の分析</div>');
  /* ★どの2点の間の仕事かを、ここでも選べるようにする★（先生の指示・第7回）
     選ぶ場所は左下の立式の欄と共通（s.eqPair）なので、どちらで選んでも両方が動く。
     ボタンの見た目は左下とそろえ、書き方だけ「A点 → B点」にする。 */
  h.push('<div class="wkpairs">');
  if (prs.length > 1) {
    h.push('<span class="eqpairs">');
    prs.forEach(function (q) {
      h.push('<button class="eqpair' + (q.j === jj ? ' on' : '') + '" data-pair="' + q.j + '">' +
        q.flow + '</button>');
    });
    h.push('</span>');
  } else {
    h.push('<span class="wkflow">' + A.name + '点 → ' + B.name + '点</span>');
  }
  h.push('<span class="wksub">で、それぞれの力がした仕事</span></div>');
  h.push('<div class="wkhint2">図の中の力（矢印や記号）をクリックすると、その力の欄が光ります。' +
    '<br>逆に、下の<b>仕事の欄をクリック</b>すると、図の中のその力が光ります。' +
    '<br>その瞬間にはたらいていない力（縮んでいないばねの力など）は図に出ないので、' +
    '<b>時間バーを動かして</b>からクリックしてください。</div>');
  fs.forEach(function (f, j) {
    var sg = workSign(f.W);
    var cls = sg > 0 ? 'pos' : (sg < 0 ? 'neg' : 'zero');
    var tag = sg > 0 ? '正の仕事' : (sg < 0 ? '負の仕事' : '仕事は 0');
    h.push('<div class="wkcard ' + cls + '" id="wkc_' + f.key + '" data-wk="' + j +
      '" style="--wc:' + f.color + '">' +
      '<div class="wkttl"><span class="wkbadge">' + tag + '</span>' +
      f.name + '　<span class="tex">' + escTex(f.sym) + '</span>' +
      '<span class="wkval"><span class="tex">' + escTex('W = ' + fmtE(f.W) + '\\ \\mathrm{J}') +
      '</span></span></div>' +
      '<div class="wkwhy">' + mathHtml(workWhy(f.W, f)) +
      (f.why ? '　' + mathHtml(typeof f.why === 'function' ? f.why(f.W) : f.why) : '') + '</div>' +
      (f.wsym ? '<div class="enqline"><span class="fk">記号</span><span class="fv"><span class="tex">' +
        escTex(f.wsym) + '</span></span></div>' : '') +
      '</div>');
  });
  /* 合計＝運動エネルギーの変化 */
  h.push('<div class="wksum"><div class="wkttl">合計（＝運動エネルギーの変化）</div>' +
    '<div class="enqline"><span class="fk num">数値</span><span class="fv"><span class="tex">' +
    escTex(fs.map(function (f) { return numTerm(f.W); }).join(' + ') + ' = ' + fmtE(tot) +
      '\\ \\mathrm{J} = K_{' + B.name + '} - K_{' + A.name + '}') +
    '</span></span></div></div>');
  el.innerHTML = h.join('');
  renderMath(el);
  fitFormula(el);
  requestAnimationFrame(function () { fitFormula(el); });
}

/* 力の欄と、図の中のその力を、いっしょに光らせる。
   ・図の力をクリック → この関数（欄が光る）
   ・欄をクリック    → この関数（★図のその力が光る★＝ st._fSel。先生の指示・第7回） */
function flashWork(key) {
  var el = $('wkc_' + key);
  if (!el) return;
  if (st._fSel !== key) { st._fSel = key; renderActive(); }
  Array.prototype.forEach.call(document.querySelectorAll('#wkpanel .wkcard'), function (c) {
    c.className = c.className.replace(' flash', '').replace(' sel', '');
  });
  el.className += ' sel flash';
  if (el.scrollIntoView) el.scrollIntoView({ block: 'nearest' });
  if (st._flashT) clearTimeout(st._flashT);
  st._flashT = setTimeout(function () {
    el.className = el.className.replace(' flash', '');
  }, 1100);
}

/* ===== ⑤ 各点の K・U の表 ===== */
function renderPtab(d, s) {
  var el = $('ptab');
  if (!el) return;
  var v = V(s), ps = ptsOf(d, v), us = !!d.hasUs;
  var key = ps.map(function (p) { return p.name + p.jp; }).join('|') + (us ? '|us' : '');
  el.className = us ? 'ptab wide' : 'ptab';   /* ばねがあるときは5列。少し細くして収める */
  if (el._key !== key) {
    el._key = key;
    var head = '<tr><th>点</th><th class="ck">運動エネルギー $K$</th><th class="cu">重力による位置エネルギー $U_g$</th>' +
      (us ? '<th class="cu">弾性力による位置エネルギー $U_k$</th>' : '') + '<th class="ce">合計 $E$</th></tr>';
    var body = ps.map(function (p) {
      return '<tr><td class="pn">' + p.name + '<span class="pj">' + p.jp + '</span></td>' +
        '<td class="ck"><span class="sym"></span><span class="num"></span></td>' +
        '<td class="cu"><span class="sym"></span><span class="num"></span></td>' +
        (us ? '<td class="cu"><span class="sym"></span><span class="num"></span></td>' : '') +
        '<td class="ce"><span class="num"></span></td></tr>';
    }).join('');
    el.innerHTML = mathHtml('<caption>各点の運動エネルギーと位置エネルギー（' +
      (d.datum || '基準面') + 'を基準面にとる）</caption>') + mathHtml(head) + body;
    renderMath(el);
  }
  /* 記号の式（KaTeX）は中身が変わったときだけ組み直す */
  var symKey = ps.map(function (p) { return [p.sym.K, p.sym.Ug, p.sym.Us].join(','); }).join('|');
  var rows = el.querySelectorAll('tr');
  if (el._sym !== symKey) {
    el._sym = symKey;
    ps.forEach(function (p, i) {
      var tr = rows[i + 1];
      if (!tr) return;
      var syms = tr.querySelectorAll('.sym');
      var list = us ? [p.sym.K || '0', p.sym.Ug || '0', p.sym.Us || '0'] : [p.sym.K || '0', p.sym.Ug || '0'];
      list.forEach(function (x, j) {
        if (syms[j]) syms[j].innerHTML = '<span class="tex">' + escTex(x) + '</span>';
      });
    });
    renderMath(el);
  }
  ps.forEach(function (p, i) {
    var tr = rows[i + 1];
    if (!tr) return;
    var ns = tr.querySelectorAll('.num');
    var list = us ? [p.m.K, p.m.Ug, p.m.Us, p.m.E] : [p.m.K, p.m.U, p.m.E];
    list.forEach(function (x, j) { if (ns[j]) setText(ns[j], fmtE(x)); });
  });
}

function renderReadout(d, s, t) {
  var el = $('readout');
  if (!el || !d.info) return;
  var rows = d.info(s, t), i;
  var keys = rows.map(function (r) { return r[0]; }).join('|');
  if (el._keys !== keys) {
    el.innerHTML = rows.map(function (r) {
      return '<tr><td class="k">' + mathHtml(r[0]) + '</td><td class="v"></td></tr>';
    }).join('');
    el._keys = keys;
    renderMath(el);
  }
  var tds = el.querySelectorAll('td.v');
  for (i = 0; i < rows.length; i++) if (tds[i]) setText(tds[i], rows[i][1]);
}

function renderEq(d, s) {
  var el = $('eqbox');
  if (!el) return;
  if (!d.eq) { el.style.display = 'none'; return; }
  el.style.display = '';
  var src = d.eq(s);
  if (src === s._eq) return;
  s._eq = src;
  el.textContent = '';
  if (window.katex) {
    try { window.katex.render(src, el, { throwOnError: false, displayMode: false }); }
    catch (e) { el.textContent = src; }
  } else el.textContent = src;
}

/* ===== 図の中の力を「クリックできる」ようにする（仕事の分析モード）★第5回★ =====
   ・当たり判定は、力の矢印と力の名前（label）から自動でできている（_forceHit）。
   ・いま出ている力のうち、d.forces にあるものだけをクリックできるようにする。 */
function activeForceHits(d, s, t) {
  if (!st.workMode || !s._wkReady) return [];
  var keys = {}, hits = forceHits(), out = [], i;
  forcesOf(d, V(s), eqPairOf(d, s)).forEach(function (f) { keys[f.key] = 1; });
  for (i = 0; i < hits.length; i++) if (keys[hits[i].key]) out.push(hits[i]);
  return out;
}

/* 図の上に、クリックできる場所の合図（うすい枠）と、ホバー中の指差しマークを描く */
function drawForceHints(ctx, d, s, t) {
  var hits = activeForceHits(d, s, t);
  st._fHits = hits;
  if (!hits.length) return;
  var i, hv = st._fHover, sel = st._fSel;
  for (i = 0; i < hits.length; i++) {
    var b = hits[i], on = (b.key === hv), pick = (b.key === sel);
    ctx.save();
    /* ★選ばれている力（右の欄でクリックされた力）はオレンジで太く囲む★（第7回） */
    ctx.strokeStyle = pick ? COL.acc : (on ? COL.acc : fade(COL.eE, 0.26));
    ctx.fillStyle = pick ? fade(COL.acc, 0.18) : (on ? fade(COL.acc, 0.14) : fade(COL.eE, 0.035));
    ctx.lineWidth = pick ? 3 : (on ? 2 : 1);
    if (!on && !pick) ctx.setLineDash([2, 4]);
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(b.x, b.y, b.w, b.h, 6);
    else ctx.rect(b.x, b.y, b.w, b.h);
    ctx.fill(); ctx.stroke();
    if (pick) {                       /* 外がわにもう1本、うすい輪を出して目立たせる */
      ctx.strokeStyle = fade(COL.acc, 0.45); ctx.lineWidth = 2; ctx.setLineDash([]);
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(b.x - 4, b.y - 4, b.w + 8, b.h + 8, 9);
      else ctx.rect(b.x - 4, b.y - 4, b.w + 8, b.h + 8);
      ctx.stroke();
    }
    ctx.restore();
    if (on) pointerIcon(ctx, b.x + b.w - 4, b.y + b.h - 2, 1.15);
  }
}

/* canvas の上の座標（px）→ 図の論理座標 */
function cvPoint(cv, d, s, e) {
  var r = cv.getBoundingClientRect();
  if (!(r.width > 0)) return null;
  var k = d.cw / r.width;
  return { x: (e.clientX - r.left) * k, y: (e.clientY - r.top) * k };
}
function hitAt(pt) {
  var hits = st._fHits || [], i;
  for (i = 0; i < hits.length; i++) {
    var b = hits[i];
    if (pt.x >= b.x && pt.x <= b.x + b.w && pt.y >= b.y && pt.y <= b.y + b.h) return b;
  }
  return null;
}

function chOf(d, s) {
  return (typeof d.ch === 'function') ? Math.round(d.ch(V(s))) : d.ch;
}

function renderActive() {
  var d = DEFS[st.cur], s = st.sims[st.cur];
  var cv = $('mainCv');
  if (!cv) return;
  var T = d.tEnd(V(s));
  if (s.t > T) s.t = T;
  var ch = chOf(d, s);
  if (endOn(d, s, s.t)) s._wkReady = true;
  preparePtBubbles(d, s, s.t);        /* 先に吹きだしの大きさを決めてから図を描く */
  var ctx = prep(cv, d.cw, ch);
  deferVec(true);                     /* ★ベクトルは最後にまとめて描く（前面に出す）★ */
  d.draw(ctx, s, s.t, d.cw, ch);
  flushVec(ctx);                      /* drawPts が呼ばれなかったとき（運動のとちゅう）用 */
  drawEqualTicks(ctx);
  /* ★「仕事の分析」モードのときだけ、力を「クリックできる」ように見せる★ */
  drawForceHints(ctx, d, s, s.t);
  placePtBubbles(d, ch);
  drawStep($('stepCv'));
  /* ★グラフは「ほんとうの運動のあいだ」だけ描く★（第14回）
     2-4 は「止まったあと、もう一度はじめから再生して点 B で止める」ので、
     アニメの長さ（tEnd）はくり返しのぶんだけ長い。そのまま横軸にすると
     グラフが途中でもどってしまうので、d.tGraph があればそちらを使う。 */
  var TG = (d.tGraph ? d.tGraph(V(s)) : T);
  /* グラフのカーソル（いまの時刻の点）も、グラフの横軸に合わせた時刻で打つ。
     2-4 の「2回目の再生」では、カーソルがグラフを右から左へもどる＝
     「いま見ているのは、はじめの所をもう一度」が目で分かる。 */
  var TC = (d.tCursor ? d.tCursor(V(s), s.t) : Math.min(s.t, TG));
  renderGraphs(d, s, TG, TC);
  renderFormulas(d, s);
  renderFigHint(d, s, s.t);
  renderResult(d, s, s.t);
  renderEqZone(d, s, s.t);
  renderWorkPanel(d, s, s.t);
  renderPtab(d, s);
  refreshActs();
  renderReadout(d, s, s.t);
  renderEq(d, s);
  var bar = $('tBar');
  if (bar) {
    var mx = T.toFixed(2);
    if (bar.max !== mx) bar.max = mx;
    var val = s.t.toFixed(2);
    if (bar.value !== val) bar.value = val;
    setText($('tVal'), fmt(s.t, 2) + ' s');
  }
}

/* .tex の中身を KaTeX で組む（1度だけ） */
function renderMath(root) {
  if (!root || !window.katex) return;
  Array.prototype.forEach.call(root.querySelectorAll('.tex'), function (el) {
    if (el.getAttribute('data-done')) return;
    el.setAttribute('data-done', '1');
    var src = el.textContent;
    el.textContent = '';
    try { window.katex.render(src, el, { throwOnError: false }); }
    catch (e) { el.textContent = src; }
  });
}

/* ===== 画面の切りかえ（ハッシュ #m1-3） ===== */
function hashOf() { return st.cur; }
function parseHash(h) {
  h = (h || '').replace('#', '');
  var i = h.indexOf('!');
  if (i < 0) i = h.indexOf('?');
  if (i >= 0) h = h.slice(0, i);
  return { id: h };
}
function syncHash() {
  var want = '#' + hashOf();
  if (location.hash !== want) {
    st._skipHash = true;
    location.hash = want;
  }
}

function gotoSim(id) {
  if (!DEFS[id]) return;
  st.cur = id;
  st._fSel = null; st._fHover = null;    /* 力の選択はシムごとにリセット */
  buildTabs();
  buildPanel();
  renderActive();
  syncHash();
  updateUrlBar();
}

/* ===== アニメーション ===== */
var lastTs = null;
function tick(ts) {
  var s = st.sims[st.cur], d = DEFS[st.cur];
  if (lastTs === null) lastTs = ts;
  var dt = Math.min(0.033, (ts - lastTs) / 1000);
  lastTs = ts;
  if (s && s.playing) {
    var T = d.tEnd(V(s));
    var rate = d.rate ? d.rate(V(s)) : 1;
    s.t = Math.min(T, s.t + dt * rate * (s.slow ? 0.25 : 1));
    if (s.t >= T - 1e-9) {
      if (d.loop) { s.t = 0; }
      else { s.playing = false; setPlayLabel(); }
    }
    renderActive();
  }
  requestAnimationFrame(tick);
}
