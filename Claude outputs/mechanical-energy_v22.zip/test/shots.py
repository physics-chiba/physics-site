#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""全シミュレーションのスクリーンショットを撮る（自分の目で見て確かめるため）。"""
import pathlib
import sys

from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
PAGE = ROOT / "dist" / "mechanical-energy.html"
OUT = ROOT / "shots"
OUT.mkdir(exist_ok=True)

WIDTH = int(sys.argv[1]) if len(sys.argv) > 1 else 1300

JOBS = []
SIMS = ["m1-1", "m1-2", "m1-3", "m1-4", "m1-5", "m1-6", "m1-7", "m1-8", "m1-9", "m1-10",
        "m1-11", "m1-12", "m1-13", "m1-14", "m2-1", "m2-2", "m2-3", "m2-4", "m2-5"]
if len(sys.argv) > 2:
    SIMS = sys.argv[2].split(",")
for sid in SIMS:
    JOBS.append((sid + "-0", sid, "window.TEST.pause()"))
    JOBS.append((sid + "-end", sid, "window.TEST.openAll();window.TEST.toEnd()"))

with sync_playwright() as pw:
    b = pw.chromium.launch()
    p = b.new_page(viewport={"width": WIDTH, "height": 1100}, device_scale_factor=1)
    errs = []
    p.on("pageerror", lambda e: errs.append(str(e)))
    p.goto(PAGE.as_uri())
    p.wait_for_timeout(700)
    for name, sid, js in JOBS:
        p.evaluate("(id)=>window.TEST.goto(id)", sid)
        p.wait_for_timeout(160)
        p.evaluate("(s)=>eval(s)", js)
        p.wait_for_timeout(240)
        p.screenshot(path=str(OUT / (name + ".png")), full_page=True)
    b.close()
print("errors:", errs)
print("saved to", OUT)
