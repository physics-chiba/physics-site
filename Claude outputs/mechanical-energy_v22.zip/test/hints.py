#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""「次は…」のヒントやボタンが、そのシムで**ほんとうにできること**かを確かめる。

★第13回★ 1-11 の「$x_0$ を2倍にすると？」は、既定が 0.75 m・上限が 0.90 m なので
2倍にできなかった（先生の指摘）。2-5 の「F を小さくしていくと動きだせない」も、
F の下限 32 N では止まらないので、できない話だった。

見るところ
  ① ボタンが入れる値が、スライダーの範囲に入っているか（`is()` が true にできるか）
  ② ヒントに書いた数値（「◯ m」「◯ N」など）が、その変数の範囲に入っているか
  ③ 「2倍」と書いたら、範囲の中で 2 倍にできる値があるか
"""
import pathlib
import re
import sys

from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
PAGE = ROOT / "dist" / "mechanical-energy.html"

with sync_playwright() as pw:
    b = pw.chromium.launch()
    p = b.new_page()
    errs = []
    p.on("pageerror", lambda e: errs.append(str(e)))
    p.goto(PAGE.as_uri())
    p.wait_for_timeout(800)
    data = p.evaluate("""()=>{
      return Object.keys(DEFS).map(function(id){
        var d = DEFS[id];
        return {
          id: id,
          vars: d.vars.map(function(x){
            return {k:x.k, min:x.min, max:x.max, step:x.step, def:x.def};
          }),
          hint2: (d.hint2||'').replace(/<[^>]*>/g,''),
          acts: (d.actions||[]).map(function(a){return a.label;})
        };
      });
    }""")
    b.close()

NG = []
for r in data:
    vs = {v["k"]: v for v in r["vars"]}
    txt = r["hint2"] + " ｜ " + " ｜ ".join(r["acts"])

    # ③「2倍」… 範囲の中で 2 倍にできるか（最小値の 2 倍が最大値以下ならできる）
    if "2倍" in r["hint2"]:
        ok = any(v["min"] > 0 and v["min"] * 2 <= v["max"] + 1e-9 for v in r["vars"])
        if not ok:
            NG.append("%s ヒントに「2倍」とあるが、2倍にできる変数がない：%s"
                      % (r["id"], [(v["k"], v["min"], v["max"]) for v in r["vars"]]))

    # ①② 文の中の「記号＝数値」や「（x₀＝0.90 m）」の数値が範囲に入っているか
    #     ざっくり「数値＋単位」を拾い、どの変数の範囲にも入らないものを疑う
    for m in re.finditer(r"([A-Za-zμθ][\w₀'′]*)\s*[＝=]\s*(-?\d+(?:\.\d+)?)", txt):
        name, val = m.group(1), float(m.group(2))
        key = (name.replace("₀", "0").replace("′", "").replace("'", "")
                   .replace("θ", "th").replace("μ", "mu").lower())
        # ★まず完全一致をさがす★（第20回）
        #   3-4 には mu と m の両方があり、「m＝3」が mu に当たって誤検出していた。
        # ★大文字小文字も区別して完全一致 → 区別せず完全一致 → 前方一致★（第21回）
        #   モード3には m（A の質量）と M（B の質量）の両方がある。
        cand = None
        for k, v in vs.items():
            if k == name.replace("₀", "0").replace("′", "").replace("'", ""):
                cand = v
                break
        if cand is None:
            for k, v in vs.items():
                if k.lower() == key:
                    cand = v
                    break
        if cand is None:
            for k, v in vs.items():
                kk = k.lower()
                if kk.startswith(key) or key.startswith(kk):
                    cand = v
                    break
        if cand is None:
            continue
        if not (cand["min"] - 1e-9 <= val <= cand["max"] + 1e-9):
            NG.append("%s 「%s＝%g」は範囲外（%s は %g〜%g）"
                      % (r["id"], name, val, cand["k"], cand["min"], cand["max"]))

print("調べたシム:", len(data), "本")
if errs:
    print("page errors:", errs)
if NG:
    print("NG")
    for x in NG:
        print("  ", x)
    sys.exit(1)
print("OK  ヒントとボタンの数値は、すべてスライダーの範囲の中")
