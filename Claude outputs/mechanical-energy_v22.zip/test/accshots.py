#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""加速度ベクトルの位置を見るためのスクリーンショット。
   力・速度・加速度をすべて ON にして、運動のとちゅう（0.35 T）で止める。"""
import pathlib, sys
from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
PAGE = ROOT / "dist" / "mechanical-energy.html"
OUT = ROOT / "shots_acc"; OUT.mkdir(exist_ok=True)

SIMS = ["m1-1","m1-2","m1-3","m1-4","m1-5","m1-6","m1-7","m1-8","m1-9","m1-10",
        "m1-11","m1-12","m1-13","m1-14","m2-1","m2-2","m2-3","m2-4","m2-5"]
if len(sys.argv) > 1:
    SIMS = sys.argv[1].split(",")
FRAC = float(sys.argv[2]) if len(sys.argv) > 2 else 0.35

with sync_playwright() as pw:
    b = pw.chromium.launch()
    p = b.new_page(viewport={"width": 1300, "height": 1100}, device_scale_factor=1)
    errs = []
    p.on("pageerror", lambda e: errs.append(str(e)))
    p.goto(PAGE.as_uri()); p.wait_for_timeout(700)
    for sid in SIMS:
        p.evaluate("(id)=>window.TEST.goto(id)", sid)
        p.wait_for_timeout(140)
        p.evaluate("""(f)=>{
          var s = st.sims[st.cur], d = DEFS[st.cur];
          window.TEST.set({opts:{showF:true, showV:true, showA:true}});
          s.t = d.tEnd(V(s)) * f; s.playing = false; renderActive();
        }""", FRAC)
        p.wait_for_timeout(220)
        cv = p.query_selector(".cvwrap")
        (cv or p).screenshot(path=str(OUT / (sid + ".png")))
    b.close()
print("errors:", errs)
print("saved to", OUT)
