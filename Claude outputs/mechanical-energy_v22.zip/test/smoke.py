#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""かんたんな動作確認：ページエラー・コンソールエラー・外部リクエストが 0 か、
   全シムを開いて物理の検算とラベルの重なりを見る。"""
import json
import pathlib
import sys

from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
PAGE = ROOT / "dist" / "mechanical-energy.html"

errs, cons, ext = [], [], []
with sync_playwright() as pw:
    b = pw.chromium.launch()
    p = b.new_page(viewport={"width": 1280, "height": 950})
    p.on("pageerror", lambda e: errs.append(str(e)))
    # ★第18回★ 外部リソースは「アクセス数カウンタ」だけ通す（run_test.py と同じ）
    OK_HOSTS = ("file:", "https://physics-chiba.goatcounter.com/", "https://gc.zgo.at/")
    p.on("console", lambda m: cons.append(m.text)
         if (m.type == "error" and not m.text.startswith("Failed to load resource")) else None)
    p.on("request", lambda r: None if r.url.startswith(OK_HOSTS) else ext.append(r.url))
    p.goto(PAGE.as_uri())
    p.wait_for_timeout(800)
    print("physics:", json.dumps(p.evaluate("()=>window.TEST.check()"), ensure_ascii=False, indent=1))
    for sid in p.evaluate("()=>window.TEST.sims()"):
        p.evaluate("(id)=>window.TEST.goto(id)", sid)
        p.wait_for_timeout(150)
        p.evaluate("()=>window.TEST.openAll()")
        p.wait_for_timeout(120)
        p.evaluate("()=>{window.__labelLog=[];window.TEST.toEnd();}")
        p.wait_for_timeout(150)
        ov = p.evaluate("()=>window.TEST.labelOverlap()")
        xt = p.evaluate("()=>window.TEST.xTicks()")
        bad = [k for k, v in xt.items() if not v["ok"]]
        print(f"--- {sid} 目盛りNG={bad} 重なり={len(ov)}")
        for o in ov[:6]:
            print("    重なり:", o["a"], "／", o["b"], o["ox"], o["oy"])
        print("   resbar:", p.evaluate("()=>window.TEST.resbar()"))
        print("   compare:", p.evaluate("()=>window.TEST.compare()")["shown"])
    b.close()
print("pageerrors:", errs)
print("console errors:", cons)
print("external:", ext)
sys.exit(1 if (errs or cons or ext) else 0)
