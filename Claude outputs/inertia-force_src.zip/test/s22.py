import sys
from playwright.sync_api import sync_playwright
from PIL import Image
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    for w in (1440, 390):
        pg = b.new_page(viewport={'width': w, 'height': 900})
        pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto(HTML); pg.wait_for_timeout(900)
        pg.evaluate("TEST.activate('mode2')"); pg.wait_for_timeout(500)
        pg.add_style_tag(content=".sec{content-visibility:visible !important} #tabs{position:static !important}")
        shots = []
        def shot(name):
            pg.evaluate("TEST.setT('m2s3', SIM_BY_ID.m2s3.tEnd()*0.7)"); pg.wait_for_timeout(250)
            f = OUT + '/m23n_%d_%s.png' % (w, name); pg.locator('#m2s3 .cvwrap').screenshot(path=f); shots.append(f)
        pg.click('#m2s3 button.obs >> nth=0'); pg.wait_for_timeout(200); shot('out')
        pg.locator('#m2s3 button.chkb', has_text='水平・鉛直').click(); pg.wait_for_timeout(200); shot('out_hv')
        pg.locator('#m2s3 button.only', has_text='小物体').click(); pg.wait_for_timeout(200); shot('blk')
        pg.locator('#m2s3 button.only', has_text='台の運動').click(); pg.wait_for_timeout(200); shot('wdg')
        pg.locator('#m2s3 button.only', has_text='台の運動').click(); pg.wait_for_timeout(200)
        pg.click('#m2s3 button.obs >> nth=1'); pg.wait_for_timeout(200); shot('rot_hv')
        print(w, 'only btn visible in rot:', pg.locator('#m2s3 button.only').first.is_visible())
        pg.locator('#m2s3 button.chkb', has_text='水平・鉛直').click(); pg.wait_for_timeout(200); shot('rot')
        ims = [Image.open(f) for f in shots]
        Wd = ims[0].width; Ht = max(i.height for i in ims)
        o = Image.new('RGB', (Wd * 2, Ht * 3), 'white')
        for k, im in enumerate(ims): o.paste(im, ((k % 2) * Wd, (k // 2) * Ht))
        o.save(OUT + '/m23n_grid_%d.png' % w)
        if w == 1440: pg.locator('#m2s3').screenshot(path=OUT + '/m23n_full.png')
        pg.close()
    print('errors', errs); b.close()
