import sys
from playwright.sync_api import sync_playwright
from PIL import Image
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    pg = b.new_page(viewport={'width': 1440, 'height': 900})
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(HTML); pg.wait_for_timeout(900)
    pg.add_style_tag(content=".sec{content-visibility:visible !important} #tabs{position:static !important}")
    rows = []
    for sid, sel in [('m1tr', '#m1s1 .pairgrid'), ('m1s2', '#m1s2 .cvwrap'), ('m1s3', '#m1s3 .cvwrap')]:
        for rot in (0, 1):
            pg.evaluate("setRot(SIM_BY_ID.%s, %s); SIM_BY_ID.m1el && setRot(SIM_BY_ID.m1el, %s)" % (sid, 'true' if rot else 'false', 'true' if rot else 'false'))
            ims = []
            for fr in (0.05, 0.5, 0.99):
                pg.evaluate("(function(s){ s.setT(s.tEnd()*%f); if (SIM_BY_ID.m1el && '%s'==='m1tr') SIM_BY_ID.m1el.setT(SIM_BY_ID.m1el.tEnd()*%f); })(SIM_BY_ID.%s)" % (fr, sid, fr, sid)); pg.wait_for_timeout(200)
                f = OUT + '/v1_%s_%d_%d.png' % (sid, rot, int(fr*100)); pg.locator(sel).first.screenshot(path=f); ims.append(Image.open(f))
            W = sum(i.width for i in ims); H = max(i.height for i in ims); o = Image.new('RGB', (W, H), 'white'); x = 0
            for i in ims: o.paste(i, (x, 0)); x += i.width
            o.save(OUT + '/v1_%s_%d.png' % (sid, rot))
    print('V0', pg.evaluate("[SIM_BY_ID.m1tr.def.V0, SIM_BY_ID.m1el.def.V0, SIM_BY_ID.m1s2.def.V0, SIM_BY_ID.m1s3.def.V0, SIM_BY_ID.m1tr.tEnd(), SIM_BY_ID.m1s3.tEnd()]"))
    print('errors', errs); b.close()
