import sys
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    pg = b.new_page(viewport={'width': 1440, 'height': 900})
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.on('console', lambda m: errs.append('console:' + m.text) if m.type == 'error' else None)
    pg.goto(HTML); pg.wait_for_timeout(900)
    pg.evaluate("TEST.activate('mode4')"); pg.wait_for_timeout(500)
    pg.add_style_tag(content=".sec{content-visibility:visible !important}")
    def shot(sid, name, js=None, wait=400):
        if js: pg.evaluate(js)
        pg.wait_for_timeout(wait)
        pg.locator('#' + sid).screenshot(path=OUT + '/' + name + '.png')
    shot('m4s1', 'd_m4s1_rot', "TEST.setVar('m4s1','aA',8); TEST.setT('m4s1',0.8)")
    shot('m4s1', 'd_m4s1_fxy', "setChk(SIM_BY_ID.m4s1,'fxy',true); document.querySelector('#m4s1 details.solbox').open=true")
    shot('m4s1', 'd_m4s1_in', "TEST.rot('m4s1',false); TEST.setT('m4s1',0.8)")
    shot('m4s2', 'd_m4s2', "TEST.setT('m4s2',0.0)")
    shot('m4s2', 'd_m4s2_off', "TEST.setVar('m4s2','L',0.45); TEST.setT('m4s2',0.6); document.querySelector('#m4s2 details.solbox').open=true", 700)
    shot('m4s3', 'd_m4s3', "TEST.setT('m4s3',0.3)")
    shot('m4s3', 'd_m4s3_after', "TEST.rot('m4s3',false); TEST.setT('m4s3',0.9); document.querySelector('#m4s3 details.solbox').open=true", 700)
    for w in (320, 390, 768, 1024, 1440):
        pg.set_viewport_size({'width': w, 'height': 800}); pg.wait_for_timeout(250)
        print('w', w, pg.evaluate('document.documentElement.scrollWidth'))
    print('errors', errs); b.close()
