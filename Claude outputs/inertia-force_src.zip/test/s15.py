import sys
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    pg = b.new_page(viewport={'width': 1440, 'height': 900})
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(HTML); pg.wait_for_timeout(900)
    pg.add_style_tag(content=".sec{content-visibility:visible !important} #tabs{position:static !important}")
    pg.evaluate("TEST.setVar('m1tr','a',9.8); TEST.setT('m1tr',0.8); TEST.setT('m1el',0.8)"); pg.wait_for_timeout(300)
    pg.locator('#m1s1 .pairgrid').screenshot(path=OUT+'/p11.png')
    pg.evaluate("TEST.activate('mode2')"); pg.wait_for_timeout(500)
    pg.add_style_tag(content=".sec{content-visibility:visible !important}")
    pg.locator('#mode2 .modehead').screenshot(path=OUT+'/m2head.png')
    pg.evaluate("TEST.setVar('m2s1','a',5)"); pg.click('#m2s1 button.cut >> nth=1'); pg.wait_for_timeout(1500)
    print('tCut', pg.evaluate("SIM_BY_ID.m2s1.tCut"))
    pg.evaluate("TEST.setT('m2s1',9)"); pg.wait_for_timeout(300); pg.locator('#m2s1 .cvwrap').screenshot(path=OUT+'/cut02.png')
    pg.evaluate("TEST.setT('m2s3',0.5)"); pg.wait_for_timeout(300)
    pg.locator('#m2s3 canvas.vecc[data-v=wk23]').screenshot(path=OUT+'/wk23.png')
    pg.evaluate("TEST.activate('mode3')"); pg.wait_for_timeout(500)
    pg.add_style_tag(content=".sec{content-visibility:visible !important}")
    pg.locator('#simR_m3s1 .qcard.derive').first.screenshot(path=OUT+'/m3der.png')
    pg.evaluate("TEST.activate('mode4')"); pg.wait_for_timeout(800)
    pg.add_style_tag(content=".sec{content-visibility:visible !important}")
    pg.evaluate("TEST.setT('m4s2',0.05)"); pg.wait_for_timeout(300)
    pg.locator('#m4s2 .cvwrap').screenshot(path=OUT+'/m42.png')
    print('errors', errs); b.close()
