import sys, random, json
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]; MODE = sys.argv[2] if len(sys.argv) > 2 else 'desk'; SEED = int(sys.argv[3]) if len(sys.argv) > 3 else 1
random.seed(SEED)
with sync_playwright() as p:
    b = p.chromium.launch()
    if MODE == 'phone':
        ctx = b.new_context(viewport={'width': 390, 'height': 844}, device_scale_factor=3, is_mobile=True, has_touch=True)
    else:
        ctx = b.new_context(viewport={'width': 1440, 'height': 900})
    pg = ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append('page:' + str(e)))
    pg.on('console', lambda m: errs.append('console:' + m.text) if m.type == 'error' else None)
    pg.goto(HTML); pg.wait_for_timeout(1200)
    pg.evaluate("""window.__lt=[];try{new PerformanceObserver(l=>{for(const e of l.getEntries())__lt.push(e.duration)}).observe({entryTypes:['longtask']});}catch(e){}""")
    nact = 0
    for mi, mode in enumerate(['mode1', 'mode2', 'mode3', 'mode4']):
        pg.evaluate(f"TEST.activate('{mode}')"); pg.wait_for_timeout(400)
        for step in range(70):
            # pick a random visible control in this mode
            js = f"""(()=>{{const root=document.getElementById('{mode}');
              const els=[...root.querySelectorAll('button, input[type=range], .vmark.hot, summary, .xlink a')].filter(e=>e.offsetParent && !e.disabled);
              return els.length}})()"""
            n = pg.evaluate(js)
            if not n: break
            i = random.randrange(n)
            r = pg.evaluate(f"""(()=>{{const root=document.getElementById('{mode}');
              const els=[...root.querySelectorAll('button, input[type=range], .vmark.hot, summary, .xlink a')].filter(e=>e.offsetParent && !e.disabled);
              const e=els[{i}]; e.scrollIntoView({{block:'center'}});
              if(e.tagName==='INPUT'){{const mn=+e.min,mx=+e.max,st=+e.step||1; const k=Math.round(({random.random()})*(mx-mn)/st); e.value=String(mn+k*st); e.dispatchEvent(new Event('input',{{bubbles:true}})); e.dispatchEvent(new Event('change',{{bubbles:true}})); return 'range '+(e.getAttribute('aria-label')||'');}}
              if(e.tagName==='A'){{ return 'skip-link'; }}
              e.click(); return (e.textContent||e.className).trim().slice(0,24);}})()""")
            nact += 1
            pg.wait_for_timeout(random.choice([30, 80, 200, 600]))
            # close overlay if open
            pg.evaluate("(()=>{const o=document.getElementById('probov'); if(o) o.hidden=true;})()")
        # NaN / undefined text check
        bad = pg.evaluate(f"""(()=>{{const t=document.getElementById('{mode}').innerText; const m=t.match(/NaN|undefined|Infinity/g); return m?m.length:0}})()""")
        if bad: errs.append(f'{mode}: NaN/undefined text x{bad}')
    # global buttons
    for sel in ['#btnRot', '#btnRot', '#bPages']:
        try: pg.click(sel, timeout=2000); pg.wait_for_timeout(200)
        except Exception as e: errs.append('click ' + sel + ' ' + str(e)[:60])
    pg.keyboard.press('Escape')
    # performance: play every sim in mode2 and measure frame intervals
    perf = pg.evaluate("""(async()=>{TEST.activate('mode2'); await new Promise(r=>setTimeout(r,300));
      const s=SIM_BY_ID.m2s1; s.resetT&&s.resetT(); s.togglePlay();
      const ts=[]; await new Promise(r=>{const f=t=>{ts.push(t); if(ts.length<120) requestAnimationFrame(f); else r();}; requestAnimationFrame(f);});
      const d=ts.slice(1).map((t,i)=>t-ts[i]); d.sort((a,b)=>a-b); return {med:d[d.length>>1], p95:d[Math.floor(d.length*0.95)], max:d[d.length-1]};})()""")
    lt = pg.evaluate("__lt.length? {n:__lt.length, max:Math.max(...__lt)} : {n:0}")
    sw = pg.evaluate("document.documentElement.scrollWidth"); vw = pg.evaluate("innerWidth")
    print(json.dumps({'mode': MODE, 'seed': SEED, 'actions': nact, 'errors': errs[:10], 'nerr': len(errs), 'frame_ms': perf, 'longtasks': lt, 'overflow': sw - vw}, ensure_ascii=False))
    b.close()
