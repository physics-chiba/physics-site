import sys
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    for w in (1440, 390):
        pg = b.new_page(viewport={'width': w, 'height': 900})
        pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto(HTML + '#mode3'); pg.wait_for_timeout(900)
        pg.evaluate("TEST.activate('mode3')"); pg.wait_for_timeout(500)
        pg.add_style_tag(content=".sec{content-visibility:visible !important}")
        pg.evaluate("TEST.setT('m3s1',0.9)"); pg.wait_for_timeout(300)
        pg.locator('#m3s1').screenshot(path=OUT + '/m3_%d.png' % w)
        print(w, pg.evaluate('document.documentElement.scrollWidth'))
    print('errors', errs); b.close()
