import sys
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    pg = b.new_page(viewport={'width': 1440, 'height': 900})
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(HTML); pg.wait_for_timeout(900)
    pg.add_style_tag(content=".sec{content-visibility:visible !important} #tabs{position:static !important}")
    res = {}
    for md in ['mode1','mode2','mode3','mode4']:
        pg.evaluate("TEST.activate('%s')" % md); pg.wait_for_timeout(400)
        for rot in (0,1):
            pg.evaluate("SIMS.forEach(function(s){ if(s.mode==='%s'){ setRot(s, %s); } })" % (md, 'true' if rot else 'false')); pg.wait_for_timeout(200)
            # cut states for 1-2 and 2-1
            res[md+str(rot)] = pg.evaluate("document.querySelectorAll('.katex-error').length")
    # cut 1-2 and 2-1 then check
    pg.evaluate("TEST.activate('mode1')"); pg.wait_for_timeout(300)
    pg.evaluate("var s=SIM_BY_ID.m1s2; s.tCut=0.2; s.t=0.5; setRot(s,true); s.renderRight(); setRot(s,false);")
    pg.evaluate("TEST.activate('mode2')"); pg.wait_for_timeout(300)
    pg.evaluate("var s=SIM_BY_ID.m2s1; TEST.setVar('m2s1','a',5); s.tCut=0.4; s.t=0.8; setRot(s,true); s.renderRight();")
    pg.evaluate("var s=SIM_BY_ID.m2s2; setRot(s,true); s.renderRight();")
    res['afterCut'] = pg.evaluate("document.querySelectorAll('.katex-error').length")
    res['errtext'] = pg.evaluate("Array.from(document.querySelectorAll('.katex-error')).slice(0,3).map(e=>e.textContent)")
    pg.locator('#simR_m2s1').screenshot(path=OUT+'/r21.png')
    pg.evaluate("TEST.activate('mode1')"); pg.wait_for_timeout(300)
    pg.locator('#simR_m1s2').screenshot(path=OUT+'/r12.png')
    print(res, 'errors', errs); b.close()
