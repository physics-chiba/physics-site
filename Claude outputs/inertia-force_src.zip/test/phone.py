import sys
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch(); ctx = b.new_context(viewport={'width': 390, 'height': 844}, device_scale_factor=2, is_mobile=True, has_touch=True)
    pg = ctx.new_page(); errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(HTML); pg.wait_for_timeout(1200)
    pg.add_style_tag(content=".sec{content-visibility:visible !important} #tabs{position:static !important}")
    pg.screenshot(path=OUT+'/p_top.png')
    pg.locator('#m1s4').screenshot(path=OUT+'/p_m1s4.png')
    pg.evaluate("TEST.activate('mode2')"); pg.wait_for_timeout(500)
    pg.evaluate("TEST.setVar('m2s1','a',5); startCut0(SIM_BY_ID.m2s1)"); pg.wait_for_timeout(1300); pg.evaluate("TEST.setT('m2s1',9)"); pg.wait_for_timeout(300)
    pg.locator('#m2s1').screenshot(path=OUT+'/p_m2s1.png')
    pg.evaluate("TEST.activate('mode3')"); pg.wait_for_timeout(500); pg.locator('#m3s1').screenshot(path=OUT+'/p_m3s1.png')
    pg.evaluate("TEST.activate('mode4')"); pg.wait_for_timeout(800); pg.locator('#m4s2 .sL').screenshot(path=OUT+'/p_m4s2.png')
    print('sw', pg.evaluate('document.documentElement.scrollWidth'), 'errors', errs); b.close()
