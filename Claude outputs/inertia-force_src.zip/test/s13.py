import sys
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    pg = b.new_page(viewport={'width': 1440, 'height': 900})
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(HTML); pg.wait_for_timeout(900)
    pg.add_style_tag(content=".sec{content-visibility:visible !important} #tabs{position:static !important}")
    pg.evaluate("TEST.activate('mode2')"); pg.wait_for_timeout(500)
    pg.add_style_tag(content=".sec{content-visibility:visible !important}")
    pg.evaluate("TEST.setT('m2s3',0.5)"); pg.wait_for_timeout(300)
    pg.locator('#m2s3').screenshot(path=OUT+'/m23.png')
    print(pg.evaluate("[...document.querySelectorAll('#mode2 .seclinks a')].map(a=>a.textContent)"))
    print('errors', errs); b.close()
