import sys
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]; which = sys.argv[3] if len(sys.argv)>3 else 'all'
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    pg = b.new_page(viewport={'width': 1440, 'height': 900})
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.on('console', lambda m: errs.append('console:' + m.text) if m.type == 'error' else None)
    pg.goto(HTML); pg.wait_for_timeout(1000)
    for tt,n in ((0.3,'a'),(0.69,'b'),(1.4,'c')):
        pg.evaluate("__hero.frame(%s)"%tt); pg.wait_for_timeout(80)
        pg.locator('#heroCv').screenshot(path=OUT + '/hero_'+n+'.png')
    pg.add_style_tag(content=".sec{content-visibility:visible !important}")
    def shot(sid, name, js=None, wait=400):
        if js: pg.evaluate(js)
        pg.wait_for_timeout(wait)
        pg.locator('#' + sid).screenshot(path=OUT + '/' + name + '.png')
    shot('m1s1', 'm1s1', "TEST.setVar('m1tr','a',9.8); TEST.setT('m1tr',0.8); TEST.setT('m1el',0.5)")
    shot('m1s2', 'm1s2', "TEST.rot('m1s2',true); TEST.setVar('m1s2','a',5); TEST.setT('m1s2',0.9)")
    shot('m1s3', 'm1s3')
    pg.evaluate("TEST.activate('mode2')"); pg.wait_for_timeout(600)
    pg.add_style_tag(content=".sec{content-visibility:visible !important}")
    shot('m2s1', 'm2s1_cut', "TEST.setVar('m2s1','a',5); TEST.setT('m2s1',1.0); startCut(SIM_BY_ID.m2s1, Infinity)", 1300)
    pg.evaluate("TEST.setT('m2s1', 9)"); pg.wait_for_timeout(300); pg.locator('#m2s1').screenshot(path=OUT + '/m2s1_end.png')
    shot('m2s2', 'm2s2', "TEST.setVar('m2s2','a',5); TEST.setT('m2s2',0.6)")
    shot('m2s3', 'm2s3', "TEST.setT('m2s3',0.6)")
    shot('m2s4', 'm2s4', "TEST.setVar('m2s4','a',5); TEST.setT('m2s4',1.0)")
    pg.evaluate("TEST.activate('mode3')"); pg.wait_for_timeout(500)
    pg.add_style_tag(content=".sec{content-visibility:visible !important}")
    pg.locator('#mode3').screenshot(path=OUT + '/mode3.png')
    pg.evaluate("TEST.activate('mode4')"); pg.wait_for_timeout(600)
    pg.add_style_tag(content=".sec{content-visibility:visible !important}")
    shot('m4s1', 'm4s1', "TEST.rot('m4s1',false); TEST.setT('m4s1',0.7)", 800)
    shot('m4s2', 'm4s2', "TEST.setT('m4s2',0.0)", 800)
    shot('m4s3', 'm4s3', "TEST.setT('m4s3',0.0)", 800)
    for w in (320, 390, 768, 1024, 1440):
        pg.set_viewport_size({'width': w, 'height': 800}); pg.wait_for_timeout(250)
        print('w', w, pg.evaluate('document.documentElement.scrollWidth'))
    print('errors', errs); b.close()
