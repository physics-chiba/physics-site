import sys
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    pg = b.new_page(viewport={'width': 1440, 'height': 900})
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.on('console', lambda m: errs.append('console:' + m.text) if m.type == 'error' else None)
    pg.goto(HTML); pg.wait_for_timeout(1000)
    pg.screenshot(path=OUT + '/e_top.png', clip={'x': 0, 'y': 0, 'width': 1440, 'height': 130})
    pg.evaluate("window.__hero && __hero.frame(3.5)"); pg.wait_for_timeout(100)
    pg.locator('#heroCv').screenshot(path=OUT + '/e_hero.png')
    pg.add_style_tag(content=".sec{content-visibility:visible !important}")
    def shot(sid, name, js=None, wait=400):
        if js: pg.evaluate(js)
        pg.wait_for_timeout(wait)
        pg.locator('#' + sid).screenshot(path=OUT + '/' + name + '.png')
    pg.locator('.keybox').screenshot(path=OUT + '/e_keybox.png')
    shot('m1s1', 'e_m1s1_rot', "TEST.setVar('m1tr','a',5); TEST.setT('m1tr',0.5); TEST.setT('m1el',0.5)")
    shot('m1s1', 'e_m1s1_in', "TEST.rot('m1tr',false); TEST.setT('m1tr',0.5); TEST.setT('m1el',0.5)")
    shot('m1s2', 'e_m1s2_rot', "TEST.rot('m1s2',true); TEST.setVar('m1s2','a',5); startCut0(SIM_BY_ID.m1s2)", 1300)
    pg.evaluate("TEST.setT('m1s2', 9)"); pg.wait_for_timeout(300); pg.locator('#m1s2').screenshot(path=OUT + '/e_m1s2_rot_end.png')
    shot('m1s2', 'e_m1s2_in', "TEST.rot('m1s2',false); TEST.setT('m1s2', 9)")
    pg.evaluate("TEST.activate('mode2')"); pg.wait_for_timeout(600)
    pg.add_style_tag(content=".sec{content-visibility:visible !important}")
    shot('m2s1', 'e_m2s1_cut0', "TEST.setVar('m2s1','a',5); startCut0(SIM_BY_ID.m2s1)", 1300)
    pg.evaluate("TEST.setT('m2s1', 9)"); pg.wait_for_timeout(300); pg.locator('#m2s1').screenshot(path=OUT + '/e_m2s1_cut0_end.png')
    shot('m2s2', 'e_m2s2', "TEST.rot('m2s2',false); TEST.setVar('m2s2','a',5); TEST.setT('m2s2',0.3)")
    shot('m2s3', 'e_m2s3', "TEST.setVar('m2s3','th',45); TEST.setT('m2s3',0.3)")
    pg.locator('.card.purpose').screenshot(path=OUT + '/e_purpose.png')
    print('still', pg.evaluate("TEST.still('m2s1'); [SIM_BY_ID.m2s1.v.a, SIM_BY_ID.m2s1.v.still, SIM_BY_ID.m2s1.sl.a.inp.value]"))
    for w in (320, 390, 768, 1024, 1440):
        pg.set_viewport_size({'width': w, 'height': 800}); pg.wait_for_timeout(250)
        print('w', w, pg.evaluate('document.documentElement.scrollWidth'))
    print('errors', errs); b.close()
