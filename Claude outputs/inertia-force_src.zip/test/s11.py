import sys
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    pg = b.new_page(viewport={'width': 1440, 'height': 900})
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(HTML); pg.wait_for_timeout(1000)
    pg.add_style_tag(content=".sec{content-visibility:visible !important} #tabs{position:static !important}")
    pg.locator('#m1s1 .pairtop').screenshot(path=OUT+'/slider.png')
    pg.evaluate("TEST.activate('mode2')"); pg.wait_for_timeout(500)
    pg.add_style_tag(content=".sec{content-visibility:visible !important}")
    for a,tc,n in ((5,1.15,'late5'),(9.8,0.4,'late98'),(-5,1.15,'latem5')):
        pg.evaluate(f"resetCut(SIM_BY_ID.m2s1); TEST.rot('m2s1',false); TEST.setVar('m2s1','a',{a}); TEST.setT('m2s1',{tc}); startCut(SIM_BY_ID.m2s1, Infinity)"); pg.wait_for_timeout(1300)
        pg.evaluate("TEST.setT('m2s1',9)"); pg.wait_for_timeout(300); pg.locator('#m2s1 .cvwrap').screenshot(path=OUT+'/'+n+'.png')
    pg.evaluate("resetCut(SIM_BY_ID.m2s1); TEST.setVar('m2s1','a',9.8); TEST.setT('m2s1',1.5)"); pg.wait_for_timeout(300)
    pg.click('#m2s1 button.cut >> nth=0', force=True); pg.wait_for_timeout(300)
    pg.locator('#m2s1 .cvwrap').screenshot(path=OUT+'/latebtn.png')
    print('tCut after late click', pg.evaluate("SIM_BY_ID.m2s1.tCut"))
    pg.evaluate("TEST.setT('m2s3',0.8)"); pg.wait_for_timeout(300)
    pg.locator('#simR_m2s3').screenshot(path=OUT+'/m2s3R.png')
    print('errors', errs); b.close()
