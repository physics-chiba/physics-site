import sys, json
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={'width': 1440, 'height': 900})
    errs = []; reqs = []
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.on('console', lambda m: errs.append('console:' + m.text) if m.type == 'error' else None)
    pg.on('request', lambda r: reqs.append(r.url) if not r.url.startswith(('file:', 'data:')) else None)
    pg.goto(HTML); pg.wait_for_timeout(1200)
    pg.add_style_tag(content=".sec{content-visibility:visible !important}")
    pg.screenshot(path=OUT + '/hero.png')
    print('check', json.dumps(pg.evaluate('TEST.check()'), ensure_ascii=False))
    def secshot(sid, name, js=None, wait=300):
        if js: pg.evaluate(js)
        pg.wait_for_timeout(wait)
        pg.locator('#' + sid).screenshot(path=OUT + '/' + name + '.png')
    secshot('mode1 .keyrow', 'intro') if False else None
    pg.locator('.keyrow').screenshot(path=OUT + '/intro.png')
    secshot('m1s1', 'm1s1_rot_a0')
    secshot('m1s1', 'm1s1_rot_a2', "TEST.setVar('m1tr','a',2); TEST.setT('m1tr',1.2); TEST.setT('m1el',0.9)")
    secshot('m1s1', 'm1s1_in_a2', "TEST.rot('m1tr',false); TEST.setT('m1tr',1.2); TEST.setT('m1el',0.9)")
    secshot('m1s1', 'm1s1_in_am2', "TEST.setVar('m1tr','a',-2); TEST.setT('m1tr',1.0); TEST.setT('m1el',1.0)")
    secshot('m1s1', 'm1s1_rot_am2', "TEST.rot('m1tr',true); TEST.setT('m1tr',1.0); TEST.setT('m1el',1.0)")
    secshot('m1s2', 'm1s2_rot_pre', "TEST.setVar('m1s2','a',2); TEST.setT('m1s2',0.4)")
    secshot('m1s2', 'm1s2_rot_cut', "TEST.cut('m1s2',0.3); TEST.setT('m1s2',0.55)")
    secshot('m1s2', 'm1s2_in_cut', "TEST.rot('m1s2',false); TEST.setT('m1s2',0.55)")
    secshot('m1s3', 'm1s3_rot', "TEST.setVar('m1s3','a',2); TEST.setT('m1s3',0.8)", 900)
    secshot('m1s3', 'm1s3_in_m2', "TEST.rot('m1s3',false); TEST.setVar('m1s3','a',-2); TEST.setT('m1s3',0.8)", 900)
    print('errors', errs); print('requests', reqs)
    # horizontal scroll
    for w in (320, 360, 390, 768, 1024, 1440):
        pg.set_viewport_size({'width': w, 'height': 800}); pg.wait_for_timeout(250)
        sw = pg.evaluate('document.documentElement.scrollWidth')
        print('w', w, 'scrollW', sw, 'OK' if sw <= w else 'OVERFLOW')
    b.close()
