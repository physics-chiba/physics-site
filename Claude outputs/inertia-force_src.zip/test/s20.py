import sys
from playwright.sync_api import sync_playwright
from PIL import Image
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    for w in (1440, 390):
        pg = b.new_page(viewport={'width': w, 'height': 900})
        pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto(HTML); pg.wait_for_timeout(900)
        pg.evaluate("TEST.activate('mode3')"); pg.wait_for_timeout(500)
        pg.add_style_tag(content=".sec{content-visibility:visible !important} #tabs{position:static !important}")
        om = pg.evaluate("SIM_BY_ID.m3s1.v.w")
        rows = []
        for vi, vt in enumerate([None, '上から見る', '真横から見る']):
            if vt: pg.locator('#m3s1 button', has_text=vt).first.click(force=True); pg.wait_for_timeout(1500)
            ims = []
            for k in range(8):
                pg.evaluate("TEST.setT('m3s1',%f)" % (0.3 + k * 6.2832 / om / 8)); pg.wait_for_timeout(120)
                f = OUT + '/tmp_%d.png' % k
                pg.locator('#m3s1 .cvwrap').screenshot(path=f)
                im = Image.open(f); ims.append(im.crop((0, 0, im.width, im.height // 2)))
            Wt = sum(i.width for i in ims[:4]); Ht = ims[0].height * 2
            o = Image.new('RGB', (Wt, Ht), 'white')
            for k, im in enumerate(ims): o.paste(im, ((k % 4) * im.width, (k // 4) * im.height))
            o.save(OUT + '/m31v_%d_%d.png' % (w, vi))
        pg.close()
    print('om', om, 'errors', errs); b.close()
