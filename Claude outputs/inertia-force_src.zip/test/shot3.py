import sys, json
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={'width': 1440, 'height': 900})
    errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.on('console', lambda m: errs.append('console:' + m.text) if m.type == 'error' else None)
    pg.goto(HTML); pg.wait_for_timeout(1000)
    pg.evaluate("window.__hero && __hero.frame(3.0)"); pg.wait_for_timeout(100)
    pg.locator('#heroCv').screenshot(path=OUT + '/h_hero.png')
    pg.evaluate("TEST.activate('mode2')"); pg.wait_for_timeout(600)
    pg.add_style_tag(content=".sec{content-visibility:visible !important}")
    def shot(sid, name, js=None, wait=400):
        if js: pg.evaluate(js)
        pg.wait_for_timeout(wait)
        pg.locator('#' + sid).screenshot(path=OUT + '/' + name + '.png')
    shot('m2s1', 'a_m2s1_rot', "TEST.setVar('m2s1','a',5); TEST.setT('m2s1',1.6)")
    shot('m2s1', 'a_m2s1_land_rot', "TEST.cut('m2s1',1.6); TEST.setT('m2s1',2.3)")
    shot('m2s1', 'a_m2s1_land_in', "TEST.rot('m2s1',false); TEST.setT('m2s1',9)")
    shot('m2s1', 'a_m2s1_bounce', "TEST.setT('m2s1',0); TEST.rot('m2s1',true); resetCut(SIM_BY_ID.m2s1); TEST.setVar('m2s1','a',-9.8); TEST.setT('m2s1',1.6); TEST.cut('m2s1',1.6); TEST.setT('m2s1',2.39)")
    shot('m2s2', 'a_m2s2_fit', "TEST.setVar('m2s2','a',5); SIM_BY_ID.m2s2.extra.fit.click(); TEST.setT('m2s2',0.6)")
    shot('m2s2', 'a_m2s2_dec', "setChk(SIM_BY_ID.m2s2,'dec',true)")
    shot('m2s2', 'a_m2s2_par', "setChk(SIM_BY_ID.m2s2,'par',true)")
    shot('m2s2', 'a_m2s2_glow', "setChk(SIM_BY_ID.m2s2,'par',false); TEST.setVar('m2s2','th',40); TEST.setT('m2s2',0.4)")
    shot('m2s3', 'a_m2s3', "setChk(SIM_BY_ID.m2s3,'dec',true); TEST.setT('m2s3',0.4)")
    shot('m2s4', 'a_m2s4', "TEST.setVar('m2s4','a',9.8); TEST.setT('m2s4',1.0)")
    print('fit', pg.evaluate("[SIM_BY_ID.m2s2.extra.fit.className, SIM_BY_ID.m2s2.v.th]"))
    print('check', json.dumps(pg.evaluate('TEST.check()'), ensure_ascii=False))
    print('errors', errs)
    for w in (320, 390, 768, 1024, 1440):
        pg.set_viewport_size({'width': w, 'height': 800}); pg.wait_for_timeout(250)
        print('w', w, pg.evaluate('document.documentElement.scrollWidth'))
    b.close()
