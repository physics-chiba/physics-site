import sys
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={'width': 390, 'height': 844}, device_scale_factor=2)
    pg.goto(HTML); pg.wait_for_timeout(1000)
    pg.add_style_tag(content=".sec{content-visibility:visible !important}")
    pg.screenshot(path=OUT + '/n_hero.png')
    pg.evaluate("TEST.setVar('m1tr','a',2); TEST.setT('m1tr',1.0); TEST.setT('m1el',0.8)"); pg.wait_for_timeout(300)
    pg.locator('#m1s1').screenshot(path=OUT + '/n_m1s1.png')
    pg.evaluate("TEST.setVar('m1s3','a',-1); TEST.setT('m1s3',0.8)"); pg.wait_for_timeout(800)
    pg.locator('#m1s3 .sL').screenshot(path=OUT + '/n_m1s3.png')
    b.close()
