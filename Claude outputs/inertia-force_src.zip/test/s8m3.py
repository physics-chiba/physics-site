import sys
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    pg = b.new_page(viewport={'width': 1440, 'height': 900})
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(HTML); pg.wait_for_timeout(900)
    pg.evaluate("TEST.activate('mode3')"); pg.wait_for_timeout(500)
    pg.add_style_tag(content=".sec{content-visibility:visible !important} #tabs{position:static !important}")
    pg.evaluate("TEST.setT('m3s1',0.6)"); pg.wait_for_timeout(300)
    pg.locator('#m3s1 .sL').screenshot(path=OUT+'/m3_obl.png')
    pg.evaluate("SIM_BY_ID.m3s1.extra.vTop.click()"); pg.wait_for_timeout(300)
    pg.locator('#m3s1 .sL').screenshot(path=OUT+'/m3_top.png')
    pg.evaluate("SIM_BY_ID.m3s1.extra.vSide.click()"); pg.wait_for_timeout(300)
    pg.locator('#m3s1 .sL').screenshot(path=OUT+'/m3_side.png')
    for w in (320, 390, 768):
        pg.set_viewport_size({'width': w, 'height': 800}); pg.wait_for_timeout(250)
        print('w', w, pg.evaluate('document.documentElement.scrollWidth'))
    pg.locator('#m3s1 .sL').screenshot(path=OUT+'/m3_768.png')
    print('errors', errs); b.close()
