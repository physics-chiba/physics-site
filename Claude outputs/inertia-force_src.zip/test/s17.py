import sys
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    pg = b.new_page(viewport={'width': 1440, 'height': 900})
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(HTML); pg.wait_for_timeout(900)
    pg.add_style_tag(content=".sec{content-visibility:visible !important} #tabs{position:static !important}")
    pg.evaluate("TEST.activate && TEST.activate('m1s2')"); pg.wait_for_timeout(400)
    pg.add_style_tag(content=".sec{content-visibility:visible !important}")
    btn = pg.locator('#m1s2 button.cut', has_text='発車直後')
    print('buttons', btn.count()); btn.first.click(); pg.wait_for_timeout(1200)
    print('tCut', pg.evaluate("SIM_BY_ID.m1s2.tCut"))
    pg.locator('#m1s2 .cvwrap').first.screenshot(path=OUT+'/m12cut.png')
    pg.locator('#m1s2').screenshot(path=OUT+'/m12all.png')
    print('errors', errs); b.close()
