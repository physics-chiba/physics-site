import sys
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    pg = b.new_page(viewport={'width': 1440, 'height': 900})
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(HTML); pg.wait_for_timeout(900)
    pg.evaluate("TEST.activate('mode4')"); pg.wait_for_timeout(500)
    pg.add_style_tag(content=".sec{content-visibility:visible !important} #tabs{position:static !important}")
    pg.evaluate("TEST.setVar('m4s1','aA',4); TEST.rot('m4s1',true); TEST.setT('m4s1',0.5)"); pg.wait_for_timeout(300)
    pg.locator('#m4s1 .cvwrap').screenshot(path=OUT+'/m4s1_R.png')
    pg.evaluate("TEST.rot('m4s1',false); TEST.setT('m4s1',0.5)"); pg.wait_for_timeout(300)
    pg.locator('#m4s1 .cvwrap').screenshot(path=OUT+'/m4s1_Rin.png')
    pg.locator('#m4s1 .vmark.hot').click(); pg.wait_for_timeout(200)
    print('after mark click aA =', pg.evaluate("TEST.sim('m4s1').v.aA"))
    pg.evaluate("TEST.setVar('m4s2','L',0.4)"); pg.locator('#m4s2 .vmark.hot').click(); pg.wait_for_timeout(200)
    print('m4s2 L =', pg.evaluate("TEST.sim('m4s2').v.L"))
    pg.evaluate("TEST.setVar('m4s3','L',0.2)"); pg.locator('#m4s3 .vmark.hot').click(); pg.wait_for_timeout(200)
    print('m4s3 L =', pg.evaluate("TEST.sim('m4s3').v.L"))
    pg.evaluate("TEST.activate('mode2')"); pg.wait_for_timeout(500)
    pg.evaluate("TEST.setVar('m2s4','a',5); TEST.setT('m2s4',1.0)"); pg.wait_for_timeout(300)
    pg.locator('#m2s4').screenshot(path=OUT+'/m2s4.png')
    pg.click('#m2s4 .xlink a'); pg.wait_for_timeout(700)
    print('hash', pg.evaluate("location.hash"), 'm1s2 top', pg.evaluate("document.getElementById('m1s2').getBoundingClientRect().top"))
    print('errors', errs); b.close()
