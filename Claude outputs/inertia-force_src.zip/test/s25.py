import sys
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    pg = b.new_page(viewport={'width': 1440, 'height': 900})
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(HTML); pg.wait_for_timeout(1500)
    pg.locator('canvas').first.screenshot(path=OUT+'/hero.png')
    pg.add_style_tag(content=".sec{content-visibility:visible !important} #tabs{position:static !important}")
    pg.locator('#mode1 .seclinks').screenshot(path=OUT+'/tabs1.png')
    pg.locator('#m1s4 .sechead').screenshot(path=OUT+'/colhead.png')
    st = "(function(s){return {ride:!!s._ride, on:s.extra.ride.classList.contains('on'), t:+s.t.toFixed(2), a:s.v.a, ended:s.ended, sliderDis:s.sl.a.inp.disabled, resetDis:s.bReset.disabled, playDis:s.bPlay.disabled}})(SIM_BY_ID.m1s3)"
    pg.click('#m1s3 button.ride'); pg.wait_for_timeout(1300)
    print('mid', pg.evaluate(st))
    pg.locator('#m1s3 .cvwrap').screenshot(path=OUT+'/ride_out.png')
    pg.locator('#simR_m1s3 .ridecard').screenshot(path=OUT+'/ride_card.png')
    pg.wait_for_timeout(6500)
    print('end', pg.evaluate(st))
    pg.locator('#m1s3 .cvwrap').screenshot(path=OUT+'/ride_end.png')
    # replay via play
    pg.click('#m1s3 .bplay, #m1s3 button:has-text("最初から")'); pg.wait_for_timeout(1500)
    print('replay', pg.evaluate(st))
    pg.wait_for_timeout(7000)
    pg.click('#m1s3 button.obs >> nth=1'); pg.wait_for_timeout(300)
    print('after obs', pg.evaluate(st))
    pg.click('#m1s3 button.ride'); pg.wait_for_timeout(2600)
    pg.locator('#m1s3 .cvwrap').screenshot(path=OUT+'/ride_rot.png')
    pg.wait_for_timeout(6000)
    pg.evaluate("TEST.setVar('m1s3','a',2)"); pg.wait_for_timeout(300)
    print('after slider', pg.evaluate(st))
    print('errors', errs); b.close()
