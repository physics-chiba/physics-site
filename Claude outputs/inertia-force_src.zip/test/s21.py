import sys
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    for w in (1440, 390):
        pg = b.new_page(viewport={'width': w, 'height': 900})
        pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto(HTML); pg.wait_for_timeout(900)
        pg.evaluate("TEST.activate('mode2')"); pg.wait_for_timeout(500)
        pg.add_style_tag(content=".sec{content-visibility:visible !important} #tabs{position:static !important}")
        for M in (1, 0.1):
            pg.evaluate("TEST.setVar('m2s3','M',%s)" % M); pg.wait_for_timeout(200)
            for rot in (0, 1):
                pg.click('#m2s3 button.obs >> nth=%d' % rot); pg.wait_for_timeout(200)
                pg.evaluate("TEST.setT('m2s3', SIM_BY_ID.m2s3.tEnd()*0.7)"); pg.wait_for_timeout(250)
                pg.locator('#m2s3 .cvwrap').screenshot(path=OUT + '/m23_%d_%s_%d.png' % (w, M, rot))
        if w == 1440:
            pg.locator('#m2s3').screenshot(path=OUT + '/m23_full.png')
        pg.close()
    print('errors', errs); b.close()
