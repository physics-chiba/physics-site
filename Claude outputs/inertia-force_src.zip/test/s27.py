import sys
from playwright.sync_api import sync_playwright
from PIL import Image
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch(); errs=[]
    pg = b.new_page(viewport={'width': 1440, 'height': 900}, device_scale_factor=2)
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(HTML); pg.wait_for_timeout(500)
    cv = pg.locator('canvas').first; cv.screenshot(path=OUT+'/hero3a.png')
    pg.wait_for_timeout(3500); cv.screenshot(path=OUT+'/hero3b.png')
    pg.add_style_tag(content=".sec{content-visibility:visible !important} #tabs{position:static !important}")
    pg.evaluate("setRot(SIM_BY_ID.m1s3, true)")
    pg.click('#m1s3 button.ride'); pg.wait_for_timeout(1600)
    pg.locator('#m1s3 .sL').screenshot(path=OUT+'/ride_rot_acc.png')
    pg.locator('#simR_m1s3 .ridecard').screenshot(path=OUT+'/ride_graphs.png')
    pg.wait_for_timeout(3000)
    pg.locator('#m1s3 .sL').screenshot(path=OUT+'/ride_rot_dec.png')
    pg.wait_for_timeout(3500)
    pg.evaluate("setRot(SIM_BY_ID.m1s3, false)"); pg.click('#m1s3 button.ride'); pg.wait_for_timeout(1600)
    pg.locator('#m1s3 .cvwrap').screenshot(path=OUT+'/ride_out_acc.png')
    pg.evaluate("TEST.activate('mode2')"); pg.wait_for_timeout(800)
    pg.add_style_tag(content=".sec{content-visibility:visible !important}")
    r = pg.evaluate("Array.from(document.querySelectorAll('#mode2 .katex-display')).filter(d=>d.clientWidth && d.scrollWidth>d.clientWidth+1).length")
    print('overflowing displays mode2:', r)
    pg.locator('#simR_m2s3 .qcard.derive >> nth=1').screenshot(path=OUT+'/rv23card.png')
    for md in ['mode1','mode3','mode4']:
        pg.evaluate("TEST.activate('%s')"%md); pg.wait_for_timeout(600)
        print(md, pg.evaluate("Array.from(document.querySelectorAll('#%s .katex-display')).filter(d=>d.clientWidth && d.scrollWidth>d.clientWidth+1).length"%md))
    print('errors', errs); b.close()
