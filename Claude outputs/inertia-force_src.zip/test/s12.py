import sys
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    pg = b.new_page(viewport={'width': 1440, 'height': 900})
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(HTML); pg.wait_for_timeout(1000)
    pg.add_style_tag(content=".sec{content-visibility:visible !important} #tabs{position:static !important}")
    pg.locator('#simR_m1s2').screenshot(path=OUT+'/r12_a0.png')
    pg.click('#simR_m1s2 details.fold summary'); pg.wait_for_timeout(300)
    print('fold open?', pg.evaluate("document.querySelector('#simR_m1s2 details.fold').open"))
    pg.locator('#simR_m1s2').screenshot(path=OUT+'/r12_a0open.png')
    pg.locator('#simR_m1tr').screenshot(path=OUT+'/r11_a0.png')
    pg.evaluate("TEST.activate('mode2')"); pg.wait_for_timeout(500)
    pg.add_style_tag(content=".sec{content-visibility:visible !important}")
    pg.locator('#m2s1').screenshot(path=OUT+'/m21_a0.png')
    pg.evaluate("TEST.setVar('m2s1','a',9.8); TEST.setT('m2s1',2.4)"); pg.wait_for_timeout(300)
    pg.locator('#m2s1 .cvwrap').screenshot(path=OUT+'/m21_pend.png')
    pg.evaluate("TEST.rot('m2s1',true); TEST.setVar('m2s1','a',5); TEST.setT('m2s1',2.3); startCut(SIM_BY_ID.m2s1, Infinity)"); pg.wait_for_timeout(1300)
    pg.evaluate("TEST.setT('m2s1',9)"); pg.wait_for_timeout(300); pg.locator('#m2s1 .cvwrap').screenshot(path=OUT+'/m21_cutrot.png')
    pg.locator('#simR_m2s2').screenshot(path=OUT+'/r22_a0.png')
    pg.evaluate("TEST.activate('mode4')"); pg.wait_for_timeout(700)
    pg.add_style_tag(content=".sec{content-visibility:visible !important}")
    pg.locator('#simR_m4s2').screenshot(path=OUT+'/r42.png')
    pg.locator('#simR_m4s3').screenshot(path=OUT+'/r43.png')
    print('errors', errs); b.close()
