import sys, json
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={'width': 1440, 'height': 900})
    errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.on('console', lambda m: errs.append('console:' + m.text) if m.type == 'error' else None)
    pg.goto(HTML); pg.wait_for_timeout(1000)
    pg.add_style_tag(content=".sec{content-visibility:visible !important}")
    def shot(sid, name, js=None, wait=350):
        if js: pg.evaluate(js)
        pg.wait_for_timeout(wait)
        pg.locator('#' + sid).screenshot(path=OUT + '/' + name + '.png')
    shot('m1s1', 'v_m1s1_rot', "TEST.setVar('m1tr','a',9.8); TEST.setT('m1tr',0.7); TEST.setT('m1el',0.6)")
    shot('m1s1', 'v_m1s1_t0', "TEST.setT('m1tr',0); TEST.setT('m1el',0)")
    shot('m1s2', 'v_m1s2_in', "TEST.rot('m1s2',false); TEST.setVar('m1s2','a',5); TEST.cut('m1s2',0.2); TEST.setT('m1s2',0.5)")
    shot('m1s3', 'v_m1s3', "TEST.setVar('m1s3','a',5); TEST.setT('m1s3',0.5)", 1200)
    pg.evaluate("TEST.activate('mode2')"); pg.wait_for_timeout(600)
    pg.add_style_tag(content=".sec{content-visibility:visible !important}")
    shot('m2s1', 'v_m2s1_rot', "TEST.setVar('m2s1','a',5); TEST.setT('m2s1',1.5)")
    shot('m2s1', 'v_m2s1_cut', "TEST.cut('m2s1',1.5); TEST.setT('m2s1',2.1)")
    shot('m2s1', 'v_m2s1_in', "TEST.rot('m2s1',false); TEST.setT('m2s1',2.1)")
    shot('m2s2', 'v_m2s2', "TEST.setVar('m2s2','a',9.8); TEST.setT('m2s2',0.6)")
    shot('m2s2', 'v_m2s2_in', "TEST.rot('m2s2',false); TEST.setVar('m2s2','th',30); TEST.setVar('m2s2','a',9.8); TEST.setT('m2s2',0.5)")
    shot('m2s3', 'v_m2s3', "TEST.setT('m2s3',0.5)")
    shot('m2s3', 'v_m2s3_in', "TEST.rot('m2s3',false); TEST.setT('m2s3',0.6)")
    shot('m2s4', 'v_m2s4', "TEST.setVar('m2s4','a',9.8); TEST.setT('m2s4',1.0)")
    print('check', json.dumps(pg.evaluate('TEST.check()'), ensure_ascii=False))
    print('errors', errs)
    for w in (320, 390, 768, 1024, 1440):
        pg.set_viewport_size({'width': w, 'height': 800}); pg.wait_for_timeout(250)
        print('w', w, pg.evaluate('document.documentElement.scrollWidth'))
    b.close()
