import sys
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    pg = b.new_page(viewport={'width': 1440, 'height': 900})
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.on('console', lambda m: errs.append('console:' + m.text) if m.type == 'error' else None)
    pg.goto(HTML); pg.wait_for_timeout(1000)
    pg.add_style_tag(content=".sec{content-visibility:visible !important} #tabs{position:static !important}")
    pg.locator('#m1s4').screenshot(path=OUT+'/m1s4.png')
    pg.locator('#simR_m1tr').screenshot(path=OUT+'/m1can.png')
    pg.evaluate("TEST.activate('mode2')"); pg.wait_for_timeout(500)
    pg.locator('#mode2 .modehead').screenshot(path=OUT+'/m2head.png')
    print('seclinks m1', pg.evaluate("[...document.querySelectorAll('#mode1 .seclinks a')].map(a=>a.textContent)"))
    for w in (320, 390, 768, 1024, 1440):
        pg.set_viewport_size({'width': w, 'height': 800}); pg.wait_for_timeout(250)
        print('w', w, pg.evaluate('document.documentElement.scrollWidth'))
    pg.evaluate("TEST.activate('mode1')"); pg.wait_for_timeout(300)
    pg.set_viewport_size({'width': 390, 'height': 800}); pg.wait_for_timeout(300)
    pg.locator('#m1s4').screenshot(path=OUT+'/m1s4_390.png')
    print('errors', errs); b.close()
