import sys
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={'width': 1440, 'height': 900})
    errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(HTML); pg.wait_for_timeout(1200)
    print('glow at load:', pg.evaluate("document.querySelector('#bPlay').classList.contains('sg-glow')"))
    pg.evaluate("document.querySelector('#m1s2').scrollIntoView()")
    s2 = '#m1s2 '
    pg.click(s2 + 'button.cut'); pg.wait_for_timeout(5000)
    print('m1s2 after cut:', pg.evaluate("[TEST.sim('m1s2').tCut, TEST.sim('m1s2').t.toFixed(2), TEST.sim('m1s2').bPlay.textContent]"))
    pg.click('#m1s1 button.b.play >> nth=0'); pg.wait_for_timeout(4500)
    print('m1tr end:', pg.evaluate("TEST.sim('m1tr').bPlay.textContent"))
    pg.evaluate("(()=>{var s=TEST.sim('m1tr'); var q=s.sl.a; q.inp.value='2'; q.inp.dispatchEvent(new Event('input',{bubbles:true}));})()"); pg.wait_for_timeout(200)   # 加速度バーの「0 静止」
    print('still:', pg.evaluate("[TEST.sim('m1tr').v.still, TEST.sim('m1el').v.still, TEST.sim('m1el').v.a]"))
    pg.click('#btnRot'); pg.wait_for_timeout(200)
    print('global off ->', pg.evaluate("[TEST.sim('m1tr').rot, TEST.sim('m1el').rot, TEST.sim('m1s3').rot, document.querySelector('#btnRot').getAttribute('aria-pressed')]"))
    pg.click('#btnRot'); pg.wait_for_timeout(200)
    pg.click('#m1s3 button.obs >> nth=0'); pg.wait_for_timeout(200)
    print('one to 外 -> global', pg.evaluate("document.querySelector('#btnRot').getAttribute('aria-pressed')"))
    pg.goto(HTML + '?rot=0'); pg.wait_for_timeout(800)
    print('?rot=0:', pg.evaluate("[TEST.sim('m1tr').rot, document.querySelector('#btnRot').getAttribute('aria-pressed')]"))
    print('errors', errs); b.close()
