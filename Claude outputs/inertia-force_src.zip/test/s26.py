import sys
from playwright.sync_api import sync_playwright
from PIL import Image
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={'width': 1440, 'height': 900}, device_scale_factor=2)
    pg.goto(HTML); pg.wait_for_timeout(600)
    pg.evaluate("window.scrollTo(0,0)"); pg.wait_for_timeout(300)
    cv = pg.locator('canvas').first
    cv.screenshot(path=OUT+'/hero2a.png')
    pg.wait_for_timeout(3500); cv.screenshot(path=OUT+'/hero2b.png')
    pg.add_style_tag(content=".sec{content-visibility:visible !important} #tabs{position:static !important}")
    pg.evaluate("setRot(SIM_BY_ID.m1s3, false)")
    pg.click('#m1s3 button.ride'); 
    ims=[]
    for w in (900, 2600, 4200, 6800):
        pg.wait_for_timeout(w - (ims and [900,2600,4200,6800][len(ims)-1] or 0))
        f=OUT+'/rideo_%d.png'%w; pg.locator('#m1s3 .cvwrap').screenshot(path=f); ims.append(Image.open(f))
    W=sum(i.width for i in ims);H=max(i.height for i in ims); o=Image.new('RGB',(W,H),'white');x=0
    for i in ims:o.paste(i,(x,0));x+=i.width
    o.save(OUT+'/rideo.png'); b.close()
