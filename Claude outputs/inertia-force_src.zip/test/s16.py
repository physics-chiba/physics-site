import sys
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    pg = b.new_page(viewport={'width': 1440, 'height': 900})
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(HTML); pg.wait_for_timeout(900)
    pg.add_style_tag(content=".sec{content-visibility:visible !important} #tabs{position:static !important}")
    pg.evaluate("TEST.activate('mode4')"); pg.wait_for_timeout(800)
    pg.add_style_tag(content=".sec{content-visibility:visible !important}")
    for sid,t,n in (('m4s1',0.15,'a'),('m4s2',0.05,'b'),('m4s3',0.3,'c')):
        pg.evaluate(f"TEST.rot('{sid}',true); TEST.setT('{sid}',{t})"); pg.wait_for_timeout(300)
        pg.locator(f'#{sid} .cvwrap').screenshot(path=OUT+f'/m4_{n}.png')
    print('errors', errs); b.close()
