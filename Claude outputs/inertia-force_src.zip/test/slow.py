import sys, json
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={'width': 1440, 'height': 900})
    t0 = pg.evaluate("performance.now()")
    pg.goto(HTML); pg.wait_for_timeout(1500)
    print('load', pg.evaluate("performance.timing.loadEventEnd-performance.timing.navigationStart"))
    res = pg.evaluate("""(()=>{const out=[];
      for(const m of ['mode1','mode2','mode3','mode4']){const t=performance.now(); TEST.activate(m); out.push([m+' activate', +(performance.now()-t).toFixed(0)]);}
      for(const id of Object.keys(SIM_BY_ID)){const s=SIM_BY_ID[id]; if(!s.sl) continue;
        for(const k of Object.keys(s.sl)){const q=s.sl[k]; const n=+q.inp.max; let worst=0;
          for(let v=+q.inp.min; v<=n; v+= Math.max(+q.inp.step||1,(n-+q.inp.min)/6)){const t=performance.now(); q.inp.value=String(v); q.inp.dispatchEvent(new Event('input',{bubbles:true})); worst=Math.max(worst,performance.now()-t);}
          out.push([id+'.'+k, +worst.toFixed(0)]);}
        const t=performance.now(); s.setT(s.def.tEnd? s.def.tEnd(s):1); out.push([id+' setT end', +(performance.now()-t).toFixed(0)]);
        const t2=performance.now(); s.renderRight(); out.push([id+' right', +(performance.now()-t2).toFixed(0)]);
      }
      return out.filter(x=>x[1]>=30);})()""")
    for r in res: print(r)
    b.close()
