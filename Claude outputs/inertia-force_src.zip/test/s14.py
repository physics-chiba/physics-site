import sys
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    pg = b.new_page(viewport={'width': 1440, 'height': 900})
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(HTML); pg.wait_for_timeout(900)
    pg.add_style_tag(content=".sec{content-visibility:visible !important} #tabs{position:static !important}")
    pg.evaluate("TEST.activate('mode2')"); pg.wait_for_timeout(500)
    pg.add_style_tag(content=".sec{content-visibility:visible !important}")
    # restart test
    pg.evaluate("TEST.setVar('m2s1','a',5); startCut0(SIM_BY_ID.m2s1)"); pg.wait_for_timeout(1400)
    pg.evaluate("TEST.setT('m2s1',9)"); pg.wait_for_timeout(300)
    print('before', pg.evaluate("document.querySelector('#simR_m2s1 .qsub') && document.querySelector('#simR_m2s1 .qsub').textContent"))
    pg.evaluate("SIM_BY_ID.m2s1.ended=true; SIM_BY_ID.m2s1.togglePlay(); SIM_BY_ID.m2s1.togglePlay()"); pg.wait_for_timeout(300)
    print('after restart', pg.evaluate("[SIM_BY_ID.m2s1.tCut, (document.querySelector('#simR_m2s1 .qsub')||{}).textContent]"))
    print('m2s2 th', pg.evaluate("SIM_BY_ID.m2s2.v.th"))
    pg.evaluate("TEST.setVar('m2s2','a',5); SIM_BY_ID.m2s2.extra.fit.click()"); pg.wait_for_timeout(200)
    print('fit th', pg.evaluate("[SIM_BY_ID.m2s2.v.th, m22Fit(SIM_BY_ID.m2s2)]"))
    pg.locator('#m2s2 .sliders').screenshot(path=OUT+'/m22sl.png')
    pg.evaluate("TEST.setT('m2s3',0.5)"); pg.wait_for_timeout(300)
    pg.locator('#simR_m2s3 canvas.vecc[data-v=rv23]').screenshot(path=OUT+'/rv23.png')
    pg.evaluate("TEST.setVar('m2s4','a',5)"); pg.wait_for_timeout(300)
    pg.locator('#simR_m2s4 table.reltab').screenshot(path=OUT+'/tab24.png')
    pg.evaluate("TEST.activate('mode4')"); pg.wait_for_timeout(1200)
    pg.add_style_tag(content=".sec{content-visibility:visible !important}")
    pg.locator('#simR_m4s2 .m4snaps').screenshot(path=OUT+'/snaps42.png')
    print('errors', errs); b.close()
