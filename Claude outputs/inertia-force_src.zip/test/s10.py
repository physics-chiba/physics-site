import sys
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    pg = b.new_page(viewport={'width': 1440, 'height': 900})
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.on('console', lambda m: errs.append('console:' + m.text) if m.type == 'error' else None)
    pg.goto(HTML); pg.wait_for_timeout(1000)
    pg.evaluate("__hero.frame(1.2)"); pg.wait_for_timeout(80); pg.locator('#heroCv').screenshot(path=OUT+'/hero.png')
    pg.add_style_tag(content=".sec{content-visibility:visible !important} #tabs{position:static !important}")
    pg.evaluate("TEST.activate('mode2')"); pg.wait_for_timeout(500)
    pg.add_style_tag(content=".sec{content-visibility:visible !important}")
    def shot(sid,name,js,w=500):
        pg.evaluate(js); pg.wait_for_timeout(w); pg.locator('#'+sid).screenshot(path=OUT+'/'+name+'.png')
    shot('m2s1','a0rot',"TEST.rot('m2s1',true); TEST.setVar('m2s1','a',0); TEST.setT('m2s1',1.0)")
    shot('m2s1','a0in',"TEST.rot('m2s1',false)")
    shot('m2s1','a5rot',"TEST.rot('m2s1',true); TEST.setVar('m2s1','a',5); TEST.setT('m2s1',2.0)")
    pg.evaluate("TEST.setT('m2s1',2.3); startCut(SIM_BY_ID.m2s1, Infinity)"); pg.wait_for_timeout(1300)
    pg.evaluate("TEST.setT('m2s1',9)"); pg.wait_for_timeout(300); pg.locator('#m2s1').screenshot(path=OUT+'/cutrot.png')
    pg.evaluate("TEST.rot('m2s1',false); TEST.setT('m2s1',9)"); pg.wait_for_timeout(300); pg.locator('#m2s1 .cvwrap').screenshot(path=OUT+'/cutin.png')
    pg.evaluate("resetCut(SIM_BY_ID.m2s1); TEST.setVar('m2s1','a',5); startCut0(SIM_BY_ID.m2s1)"); pg.wait_for_timeout(1300)
    pg.evaluate("TEST.setT('m2s1',9)"); pg.wait_for_timeout(300); pg.locator('#m2s1 .cvwrap').screenshot(path=OUT+'/cut0in.png')
    shot('m2s4','m24rot',"TEST.rot('m2s4',true); TEST.setVar('m2s4','a',5); TEST.setT('m2s4',1.0)")
    shot('m2s2','m22',"TEST.setVar('m2s2','a',5); SIM_BY_ID.m2s2.extra.fit.click(); TEST.setT('m2s2',0.5)")
    print('errors', errs); b.close()
