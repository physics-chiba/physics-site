import sys
from playwright.sync_api import sync_playwright
HTML = "file://" + sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    for w in (1440, 390):
        pg = b.new_page(viewport={'width': w, 'height': 900})
        pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto(HTML); pg.wait_for_timeout(900)
        pg.evaluate("TEST.activate('mode3')"); pg.wait_for_timeout(500)
        pg.add_style_tag(content=".sec{content-visibility:visible !important} #tabs{position:static !important}")
        pg.evaluate("TEST.setT('m3s1',0.7)"); pg.wait_for_timeout(300)
        pg.locator('#m3s1 .cvwrap').screenshot(path=OUT+'/m31_%d_a.png'%w)
        for i,t in enumerate(['上から見る','真横から見る']):
            pg.locator('#m3s1 button', has_text=t).first.click(force=True); pg.wait_for_timeout(1500)
            pg.locator('#m3s1 .cvwrap').screenshot(path=OUT+'/m31_%d_%d.png'%(w,i))
        pg.close()
    print('errors', errs); b.close()
