/* =========================================================================
   50_common.js … どのモードでも使う部品
   ・観測者の切りかえ「外（慣性系）から見る｜一緒に加速運動する観測者（非慣性系）から見る」（対のボタン）
   ・加速度バー（−2・−1・0（等速）・1・2 m/s²）＋「静止」
   ・式の札（運動方程式＝赤／力のつり合いの式＝緑）、図の下の式の箱、右の列の「立式カード」
   ・慣性力は濃いグレーの破線（circular-motion.html の遠心力と同じ）。慣性系には絶対に描かない。
   ========================================================================= */
'use strict';
var DEFS = {};
COL.inert = '#e07b18';                                    /* 慣性力＝加速度と同じオレンジの、太い破線（2026-10-11 千葉さん：黒では見づらい） */
var OBS_IN = '外（慣性系）から見る', OBS_ROT = '一緒に加速運動する観測者（非慣性系）から見る';
var OBS_IN2 = '外（慣性系）<br>から見る', OBS_ROT2 = '一緒に加速運動する観測者<br>（非慣性系）から見る';   /* セクションの中のボタンは 2 行（2026-10-11 千葉さん） */
var NAME_IN = '外の観測者', NAME_ROT = '一緒に加速する観測者';

/* ---------- 式の札 ---------- */
function eqTag(kind) { return kind ? '<span class="eqtag ' + kind + '">' + (kind === 'eom' ? '運動方程式' : '力のつり合いの式') + '</span>' : ''; }
function eqRow(kind, t) { return '<div class="qeqrow">' + eqTag(kind) + '<span class="qeqm">' + tex(t, true) + '</span></div>'; }
var T_EOM = '<span class="t-eom">運動方程式</span>', T_BAL = '<span class="t-bal">力のつり合いの式</span>';
function f1(x) { return fmt(x, 1); }
function f2(x) { return fmt(x, 2); }
function f3(x) { return fmt(x, 3); }
/* 符号つきの数（式に代入するとき） */
function sgnTex(x, d) { var s = fmt(Math.abs(x), d); return (x < 0 ? '(-' + s + ')' : s); }

/* ---------- 加速度バーの表示 ---------- */
var A_STILL = -1e-6;                                      /* 加速度バーの「0（静止）」の目盛り（値としては a = 0。0（等速）と区別するための印） */
function accTxt(a, still) {
  if (a === A_STILL) return '0（静止）';
  if (Math.abs(a) < 1e-9) return still ? '0（静止）' : '0（等速）';
  return (a > 0 ? '＋' : '−') + Math.abs(a) + ' m/s²';
}
/* 「静止」ボタンはやめ、加速度バーの中に 0（静止）・0（等速）の 2 つの目盛りを置く（2026-10-11 千葉さん） */
var ACC_VAR = { k: 'a', label: '加速度 $a$', aria: '加速度', stops: [-9.8, -5, A_STILL, 0, 5, 9.8], stopLabels: ['−9.8', '−5', '0<br>静止', '0<br>等速', '＋5', '＋9.8'], def: 0, cls: 'accrow',
  fmt: function (x, s) { return accTxt(x, s.v.still); } };

/* ---------- セクションの共通の作り（ifBase） ----------
   o.V0：「等速」のときの速さ、o.TW：1 回の再生で見る時間 */
function ifBase(o) {
  var d = Object.assign({ mode: 'mode1', belowCanvas: true, strobe: false, baseRate: 0.35, showFBtn: true,
    height: function (s, w) { return Math.round(clamp(w * 0.66, 300, 420)); } }, o);
  d.vars = (o.noAcc ? [] : [ACC_VAR]).concat(o.vars || []);   /* d.noAcc：加速度バーを使わない場面（2-3） */
  d.varCols = o.varColsK || [d.vars.map(function (q) { return q.k; })];   /* o.varColsK：スライダーを横に並べる（2-2。2026-10-11 千葉さん） */
  var init0 = d.init;
  d.init = function (s) {
    if (s.rot === undefined) s.rot = !!modeState(d.mode).rot;
    s.v.still = false;
    if (init0) init0(s);
  };
  d.tEnd = d.tEnd || function () { return d.TW; };
  d.buttons = [
    { k: 'obsIn', label: o.obsIn || OBS_IN2, cls: 'obs two', seg: 'obs', segLabel: 'どの観測者から見るか', onClick: function (s) { setRot(s, false); } },
    { k: 'obsRot', label: o.obsRot || OBS_ROT2, cls: 'obs rotb two', seg: 'obs', onClick: function (s) { setRot(s, true); } }
  ].concat(o.buttons || []);
  d.disp = function (s, k) { return (k === 'a' && s.v.still) ? A_STILL : s.v[k]; };   /* 静止のときは「0（静止）」の目盛りにつまみを置く */
  var onVar0 = d.onVar;
  d.onVar = function (s, k, x) {
    if (k === 'a') {
      if (d.aLocked && d.aLocked(s)) return false;
      if (x === A_STILL) { s.v.a = 0; s.v.still = true; s.aSeg = null; s._keepA = false; if (d.onPair) d.onPair(s, true); return true; }   /* 0（静止）：最初から */
      applyA(s, x); if (d.onPair) d.onPair(s, false); return true;
    }
    if (onVar0) return onVar0(s, k, x);
    s.v[k] = x; return true;
  };
  var onCh0 = d.onChanged;
  /* 量を変えたら最初にもどす（↺ リセットと同じ）。ただし運動中に加速度 a を変えたときは、そのまま続ける（2026-10-11 千葉さん） */
  d.onChanged = function (s, k) { if (onCh0) onCh0(s, k); if (k === 'a' && s._keepA) { s._keepA = false; return 'keepT'; } return 'stop'; };
  var onRs0 = d.onReset, onRst0 = d.onRestart, onDf0 = d.onDefaults;
  d.onReset = function (s) { s.aSeg = null; if (onRs0) onRs0(s); };
  d.onRestart = function (s) { s.aSeg = null; if (onRst0) onRst0(s); };
  d.onDefaults = function (s) { s.aSeg = null; if (onDf0) onDf0(s); };
  var live0 = d.live;
  d.live = function (s) {
    if (s.extra && s.extra.still) { var on = !!s.v.still; if (s.extra.still._on !== on) { s.extra.still._on = on; s.extra.still.classList.toggle('on', on); s.extra.still.setAttribute('aria-pressed', on ? 'true' : 'false'); } }
    if (s.sl && s.sl.a) {                                     /* 糸を切ったあとなどは、a を変えられない */
      var lk = !!(d.aLocked && d.aLocked(s)), q = s.sl.a;
      if (q._lk !== lk) { q._lk = lk; q.inp.disabled = lk; q.dn.disabled = lk; q.up.disabled = lk; if (s.extra.still) s.extra.still.disabled = lk;
        q.row.classList.toggle('locked', lk); q.row.title = lk ? '糸を切ったあとは加速度を変えられません（↺ リセットで戻せます）' : ''; }
    }
    if (live0) live0(s);
  };
  if (d.eqs) d.below = function (s) { ifEqBox(s, d.eqs(s)); };
  var ab0 = d.afterBuild;
  d.afterBuild = function (s) {
    /* そのセクションのチェックボックス（d.checks）は「力を表示」のとなり */
    s.chk = {};
    (d.checks || []).forEach(function (c) {
      s.chk[c.k] = !!c.def;
      var b = el('button', 'b chkb two' + (c.def ? ' on' : ''), c.label); b.type = 'button'; b.setAttribute('aria-pressed', c.def ? 'true' : 'false');
      b.addEventListener('click', function () { setChk(s, c.k, !s.chk[c.k]); });
      s.row1b.appendChild(b); s.extra['chk_' + c.k] = b;
    });
    setRot(s, s.rot); alignStops(s); if (ab0) ab0(s);
  };
  return d;
}
/* 加速度バーの下の目盛りの文字を、つまみの位置にきっちり合わせる（幅が変わったときだけ測る） */
function alignStops(s) {
  Object.keys(s.sl || {}).forEach(function (kk) { if (s.sl[kk].vd.stops) alignStop1(s.sl[kk]); });
}
function alignStop1(q) {
  var tk = q.row.querySelector('.stoptk'); if (!tk) return;
  tk.classList.add('abs');
  var place = function () {
    var ri = q.inp.getBoundingClientRect(), rt = tk.getBoundingClientRect(); if (ri.width < 10) return;
    var n = tk.children.length;
    for (var i = 0; i < n; i++) tk.children[i].style.left = (ri.left - rt.left + 9 + i / (n - 1) * (ri.width - 18)).toFixed(1) + 'px';
  };
  if (typeof ResizeObserver !== 'undefined') new ResizeObserver(place).observe(q.inp);
  place(); setTimeout(place, 60);
}
/* チェックボックス（d.checks）。o.only を持つものを ON にすると、ほかは全部外れる（「斜面方向の力のみ表示する」） */
function setChk(s, k, on) {
  var cs = s.def.checks || [], me = cs.filter(function (c) { return c.k === k; })[0];
  s.chk[k] = on;
  if (on && me && me.only) { cs.forEach(function (c) { if (c.k !== k) s.chk[c.k] = false; }); if (s.ms.showF) { s.ms.showF = false; syncModeBar(s.mode); } }
  if (on && me && !me.only) cs.forEach(function (c) { if (c.only) s.chk[c.k] = false; });
  if (on && me && me.needF && !s.ms.showF) { s.ms.showF = true; syncModeBar(s.mode); }
  cs.forEach(function (c) { var b = s.extra['chk_' + c.k]; if (b) { b.classList.toggle('on', !!s.chk[c.k]); b.setAttribute('aria-pressed', s.chk[c.k] ? 'true' : 'false'); } });
  s.draw(); s.renderRight();
}
/* ---------- 観測者（電車・エレベーター・台）の運動 ----------
   加速度は区間ごとに一定（運動の途中で a を変えたら、そこから新しい区間）。s.aSeg = [{t0, x0, v0, a}, …] */
function v0Of0(s) { return (s.v.still || Math.abs(s.v.a || 0) > 1e-9) ? 0 : s.def.V0; }   /* 加速するときは止まった状態から（行って戻る動きはしない） */
function segsOf(s) { if (!s.aSeg) s.aSeg = [{ t0: 0, x0: 0, v0: v0Of0(s), a: s.v.a || 0 }]; return s.aSeg; }
function segAt(s, t) { var S = segsOf(s), g = S[0]; for (var i = 1; i < S.length; i++) if (S[i].t0 <= t + 1e-12) g = S[i]; return g; }
function aAt(s, t) { return segAt(s, t).a; }
function v0Of(s) { return segsOf(s)[0].v0; }
function dispOf(s, t) { var g = segAt(s, t), d = t - g.t0; return g.x0 + g.v0 * d + 0.5 * g.a * d * d; }
function velOf(s, t) { var g = segAt(s, t); return g.v0 + g.a * (t - g.t0); }
function rangeOf(s) { var g = segsOf(s)[0]; return P.range(g.v0, g.a, s.def.TWr ? s.def.TWr(s) : s.def.TW); }   /* d.TWr：糸を切ったあと時間がのびるとき（1-2）は、その分まで見えるように */   /* 図の置き場所は、はじめの区間で決める（途中で a を変えても絵が飛ばない） */
/* 加速度を変える：運動の途中なら新しい区間を足して続ける。止まっているとき（t = 0・最後まで行った）は最初から */
function applyA(s, x) {
  s.v.still = false;                                          /* a を変えたら「静止」は解除 */
  if (s.t > 1e-9 && !s.ended) {
    var S = segsOf(s).filter(function (g) { return g.t0 < s.t - 1e-12; });
    var x0 = dispOf(s, s.t), v0 = velOf(s, s.t);
    S.push({ t0: s.t, x0: x0, v0: v0, a: x }); s.aSeg = S; s._keepA = true;
  } else { s.aSeg = null; s._keepA = false; }
  s.v.a = x;
}
/* スタートを押してから加速が始まる：t = 0 では加速度 0 の見え方、少しの間に矢印などが伸びる（見た目だけ） */
function effK(s) { return s.def.noRamp ? 1 : clamp(s.t / 0.08, 0, 1); }   /* d.noRamp：はじめから加速している場面（2-4） */
function aEff(s) { return (s.v.a === undefined ? 0 : aAt(s, s.t)) * effK(s); }
/* 「静止」：速度も加速度も 0（加速度バーも 0 にもどす）。最初から */
function setStill(s) {
  s.v.a = 0; s.v.still = true; s.aSeg = null; s._keepA = false;
  if (s.def.onPair) s.def.onPair(s, true);
  s.changed('still');
}
function setRot(s, on) {
  s.rot = on;
  if (typeof syncGlobalRot === 'function' && document.getElementById('btnRot')) { clearTimeout(setRot._t); setRot._t = setTimeout(syncGlobalRot, 0); }
  if (s.extra && s.extra.obsIn) { s.extra.obsIn.classList.toggle('on', !on); s.extra.obsRot.classList.toggle('on', on); }
  if (s.def.onRot) s.def.onRot(s, on);
  s.draw(); s.renderRight();
}
/* モード全体の切りかえ（モードの上の「全セクション」） */
function setModeRot(mid, on, quiet) {
  var ms = modeState(mid); ms.rot = on;
  SIMS.forEach(function (s) { if (s.mode === mid) setRot(s, on); });
  (PAIRS[mid] || []).forEach(function (p) { p.setRot(on); });
  if (ms._segb) { ms._segb[0].classList.toggle('on', !on); ms._segb[1].classList.toggle('on', on); }
  if (!quiet && typeof syncGlobalRot === 'function') syncGlobalRot();
}
var PAIRS = {};

/* ---------- 図の下の式の箱：慣性系と非慣性系を 2 つ並べる（いまの視点のほうを濃く） ----------
   eq = { in:{h, lines:[{tag,k,t}], num, note, fbd}, rot:{…} }。fbd があれば小さな図（力の図）を式の上に描く */
function ifEqBox(s, eq) {
  if (!s.below) return;
  var now = performance.now();
  if (s.playing && s._eqT && now - s._eqT < 250) return;
  var key = JSON.stringify([eq, s.rot]);
  if (s._eqKey === key) return; s._eqKey = key; s._eqT = now;
  var one = function (q, on, cls) {
    return '<div class="eqcard ' + cls + (on ? ' on' : '') + '"><p class="eqh">' + q.h + (on ? '<span class="now">いまの視点</span>' : '') + '</p>' +
      (q.fbd ? '<canvas class="fbd" data-f="' + cls + '"></canvas>' : '') +
      q.lines.map(function (l) { return '<div class="eql2">' + eqTag(l.tag) + (l.k ? '<span class="eqk">' + l.k + '</span>' : '') + tex(l.t) + '</div>'; }).join('') +
      (q.num ? '<p class="eqnum">' + q.num + '</p>' : '') + (q.note ? '<p class="eqnote">' + q.note + '</p>' : '') + '</div>';
  };
  s.below.innerHTML = mathify('<div class="eqpair">' + one(eq.in, !s.rot, 'in') + one(eq.rot, s.rot, 'rot') + '</div>');
  ['in', 'rot'].forEach(function (k) {
    var q = eq[k], cv = s.below.querySelector('canvas.fbd[data-f="' + k + '"]'); if (!q.fbd || !cv) return;
    var w = Math.max(160, Math.floor(cv.parentNode.clientWidth - 2)), h = q.fbd.h || 150;
    cv.style.width = '100%';
    var ctx = prep(cv, w, h); q.fbd.draw(ctx, w, h, k === 'rot');
  });
}
/* 右の列の「立式カード」：いまの視点の式だけを「方向の名前｜札｜式」の行で出す */
function ifSetup(s, o) {
  var k = s.rot ? 'rot' : 'in';
  return '<div class="qcard setup ' + k + '">' + (o.title ? '<p class="qsub">' + o.title + '</p>' : '') + '<p class="qt">' + (s.rot ? '一緒に加速運動する観測者（非慣性系）から見ると' : '外（慣性系）から見ると') + '<span class="now">いまの視点</span></p>' +
    '<p>' + o.lead[k] + '</p><div class="dirs">' +
    o.rows.map(function (r) { var q = r[k]; return '<div class="dirrow"><span class="dirlab">' + r.dir + '</span>' + eqRow(q[0], q[1]) + '</div>'; }).join('') +
    '</div>' + (o.fig && o.fig[k] ? o.fig[k] : '') + (o.now ? '<p class="qnow"><span class="qtag now">いまの値</span>' + o.now[k] + '</p>' : '') +
    ((o.note && o.note[k]) || frameNote(s.rot)) + '</div>';
}
function frameNote(rot) {
  return rot ? '<p class="qnote">慣性力は、加速度 $\\vec{a}$ で運動する観測者だけが感じる<b>見かけの力</b>。大きさ $ma$、向きは観測者の加速度と<b>逆</b>。</p>'
    : '<p class="qnote">外（慣性系）から見ると物体は加速している（加速度がある）ので' + T_EOM + 'を立てる。<b>慣性系に「慣性力」は存在しない。</b></p>';
}

/* ---------- 描画の部品 ---------- */
/* 「正の向き：右向き →」（図の右上） */
function posNote(ctx, W, word, dir) {
  var b = label(ctx, '正の向き：' + word, W - 34, 15, { size: 11.5, color: COL.ink2, align: 'right' });
  var x0 = W - 26, y0 = 15;
  ctx.save(); ctx.strokeStyle = COL.ink2; ctx.fillStyle = COL.ink2; ctx.lineWidth = 1.6;
  if (dir === 'up') { ctx.beginPath(); ctx.moveTo(x0 + 8, y0 + 8); ctx.lineTo(x0 + 8, y0 - 5); ctx.stroke(); ctx.beginPath(); ctx.moveTo(x0 + 8, y0 - 9); ctx.lineTo(x0 + 4, y0 - 3); ctx.lineTo(x0 + 12, y0 - 3); ctx.closePath(); ctx.fill(); }
  else { ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x0 + 14, y0); ctx.stroke(); ctx.beginPath(); ctx.moveTo(x0 + 19, y0); ctx.lineTo(x0 + 13, y0 - 4); ctx.lineTo(x0 + 13, y0 + 4); ctx.closePath(); ctx.fill(); }
  ctx.restore();
  return b;
}
/* 構想メモの「白抜きの太い矢印」（加速度）。色はページの約束どおりオレンジ（ふちオレンジ・中うすいオレンジ）。(x, y)＝根もと、(ux, uy)＝向き、L＝長さ */
function blockArrow(ctx, x, y, ux, uy, L, txt, lab) {
  var w = 6, hw = 12, hl = 13, px = -uy, py = ux, b = L - hl;
  var P2 = function (u, p) { return [x + ux * u + px * p, y + uy * u + py * p]; };
  var pts = [P2(0, -w), P2(b, -w), P2(b, -hw), P2(L, 0), P2(b, hw), P2(b, w), P2(0, w)];
  ctx.save(); ctx.beginPath(); pts.forEach(function (q, i) { i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]); }); ctx.closePath();
  ctx.fillStyle = '#fde7cf'; ctx.fill(); ctx.strokeStyle = COL.acc; ctx.lineWidth = 2; ctx.lineJoin = 'round'; ctx.stroke(); ctx.restore();
  if (txt) {
    lab = lab || {};
    var lx = lab.x !== undefined ? lab.x : x + ux * L / 2 + px * -22, ly = lab.y !== undefined ? lab.y : y + uy * L / 2 + py * -22;
    String(txt).split('\n').forEach(function (ln, i, all) {     /* 2 行にするときは \n（エレベーターの横など、せまいところ） */
      label(ctx, ln, lx, ly + (i - (all.length - 1) / 2) * 15, { size: 12, bold: true, color: '#9c4e06', align: lab.align || 'center' });
    });
  }
}
/* 速度の矢印（白抜きの青）を (cx, cy) をまん中にして、(ux, uy) の向きに長さ L で描く */
function velAt(ctx, cx, cy, ux, uy, L, labOff) {
  if (L < 4) return null;
  var ar = arrow(ctx, cx - ux * L / 2, cy - uy * L / 2, cx + ux * L / 2, cy + uy * L / 2, 'vel');
  if (ar) sym(ctx, 'v', ar.x2 + ux * 11 + (labOff ? labOff[0] : 0), ar.y2 + uy * 11 + (labOff ? labOff[1] : 0), { size: 16, color: COL.vel });
  return ar;
}
/* 力の矢印＋記号 */
function forceArrow(ctx, x, y, ux, uy, L, col, txt, where, kind) {
  if (L < 1.5) return null;
  var ar = arrow(ctx, x, y, x + ux * L, y + uy * L, kind || 'force', col);
  if (!ar || !txt) return ar;
  var lx, ly;
  if (where === 'below') { lx = ar.x2; ly = ar.y2 + 12; }
  else if (where === 'left') { lx = ar.x2 - (kind === 'fict' ? 20 : 14); ly = ar.y2; }
  else if (where === 'right') { lx = ar.x2 + (kind === 'fict' ? 20 : 14); ly = ar.y2; }
  else { lx = ar.x2 + ux * 13; ly = ar.y2 + uy * 13 - (Math.abs(uy) > 0.5 ? 0 : 10); }
  if (kind === 'fict') label(ctx, txt, lx, ly, { size: 13, bold: true, color: '#b35f0c', align: where === 'left' ? 'right' : (where === 'right' ? 'left' : 'center') });
  else sym(ctx, txt, lx, ly, { size: 16, color: col, align: where === 'left' ? 'right' : (where === 'right' ? 'left' : 'center') });
  return ar;
}
/* 座っている人（右を向く）。(hx, hy)＝おしり（座面に乗っているところ）、s＝座高のめやす［px］ */
function seatedMan(ctx, hx, hy, s, col, lw, alpha) {
  ctx.save(); if (alpha !== undefined) ctx.globalAlpha *= alpha;
  ctx.strokeStyle = col; ctx.lineWidth = lw; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  var sh = [hx - s * 0.03, hy - s * 0.52], hd = [hx - s * 0.01, hy - s * 0.70], knee = [hx + s * 0.30, hy - s * 0.02], foot = [hx + s * 0.32, hy + s * 0.30];
  ctx.beginPath(); ctx.arc(hd[0], hd[1], s * 0.11, 0, TAU); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(sh[0], sh[1]); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(knee[0], knee[1]); ctx.lineTo(foot[0], foot[1]); ctx.stroke();
  var el = [hx + s * 0.08, hy - s * 0.28], hand = [hx + s * 0.24, hy - s * 0.12];   /* 腕はひじで曲げて、ひざの上に */
  ctx.beginPath(); ctx.moveTo(sh[0], sh[1] + s * 0.04); ctx.lineTo(el[0], el[1]); ctx.lineTo(hand[0], hand[1]); ctx.stroke();
  ctx.restore();
  return { x: hd[0], y: hd[1], r: s * 0.11, cx: hx - s * 0.015, cy: hy - s * 0.30, back: [hx - s * 0.06, hy - s * 0.30], seat: [hx, hy], foot: foot };
}
/* 画面の外に出た観測者の目じるし（はしに矢印と名前） */
function offMarker(ctx, W, H, x, y, name, active) {
  var col = active ? COL.vel : '#7c8590';
  var cx = clamp(x, 14, W - 14), cy = clamp(y, 14, H - 14), ux = x - cx, uy = y - cy, L = Math.hypot(ux, uy) || 1; ux /= L; uy /= L;
  ctx.save(); ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(cx + ux * 8, cy + uy * 8); ctx.lineTo(cx - uy * 6, cy + ux * 6); ctx.lineTo(cx + uy * 6, cy - ux * 6); ctx.closePath(); ctx.fill(); ctx.restore();
  label(ctx, name + '（画面の外）', cx - ux * 14 + (Math.abs(ux) > 0.5 ? -ux * 50 : 0), cy - uy * 14 + (Math.abs(uy) > 0.5 ? -uy * 4 : 0), { size: 10.5, color: col, align: 'center' });
}
/* 地面（ハッチつき・ずらせる）。off＝絵全体のずらし［px］ */
/* 背景の柱（地面といっしょに動く目印）。どのシムでも、床から同じくらいの低い高さにそろえる（2-2 に合わせる。2026-10-11 千葉さん）
   sp：柱の間隔［px］、sh：地面のずれ［px］ */
/* 台の上の観測者：台の鉛直な面の上のはしから外へ板を出し、つっかえ棒で支えて、その上に立たせる（2-3 の形。2-2・2-3・モード4 で統一。2026-10-12 千葉さん）
   (xe, yTop)＝台の鉛直な面の上のかど、dir＝板を出す向き（−1 左／＋1 右）、k＝縮尺、s＝人の大きさ［px］ */
function deckObserver(ctx, xe, yTop, dir, k, active, s) {
  var Lp = Math.min(0.36 * k, 50), tp = Math.max(4, Math.min(0.05 * k, 7)), st = Math.min(0.25 * k, 36);
  var x1 = Math.min(xe, xe + dir * Lp);
  ctx.save(); ctx.fillStyle = '#e9e4da'; ctx.strokeStyle = COL.ink; ctx.lineWidth = 1.2;
  ctx.fillRect(x1, yTop - tp, Lp, tp); ctx.strokeRect(x1, yTop - tp, Lp, tp);
  ctx.beginPath(); ctx.moveTo(xe + dir * Lp * 0.56, yTop); ctx.lineTo(xe, yTop + st); ctx.stroke(); ctx.restore();
  return observer(ctx, xe + dir * Lp * 0.5, yTop - tp, 0, -1, '', active, s);
}
function groundPosts(ctx, W, yg, sh, sp) {
  var h = clamp(W * 0.06, 22, 36);
  ctx.save(); ctx.strokeStyle = '#ddd7cb'; ctx.lineWidth = 2; var off = wrapX(sh, sp);
  for (var x = off - sp; x < W + sp; x += sp) { ctx.beginPath(); ctx.moveTo(x, yg); ctx.lineTo(x, yg - h); ctx.stroke(); }
  ctx.restore();
}
function groundShift(ctx, x1, x2, y, off) {
  ctx.save(); ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 1.6;
  ctx.beginPath(); ctx.moveTo(x1, y); ctx.lineTo(x2, y); ctx.stroke();
  ctx.lineWidth = 1; ctx.strokeStyle = '#a9a193';
  ctx.beginPath(); ctx.rect(x1, y, x2 - x1, 10); ctx.clip();
  var ph = ((off % 9) + 9) % 9;
  for (var X = x1 - 9 + ph; X < x2 + 9; X += 9) { ctx.beginPath(); ctx.moveTo(X, y); ctx.lineTo(X - 7, y + 8); ctx.stroke(); }
  ctx.restore();
}
/* はさみ（circular-motion.html と同じ絵） */
function scissors(ctx, px, py, ax, ay, open, k, alpha) {
  ctx.save(); ctx.globalAlpha = alpha; ctx.translate(px, py); ctx.rotate(Math.atan2(ay, ax)); ctx.scale(k, k);
  [-1, 1].forEach(function (sg) {
    ctx.save(); ctx.rotate(sg * open / 2);
    ctx.beginPath(); ctx.moveTo(-6, -4 * sg); ctx.quadraticCurveTo(30, -7 * sg, 66, -1 * sg); ctx.lineTo(66, 0.5 * sg); ctx.quadraticCurveTo(30, 4 * sg, -6, 3 * sg); ctx.closePath();
    var g = ctx.createLinearGradient(0, -6, 0, 6); g.addColorStop(0, '#e9ecef'); g.addColorStop(1, '#a7adb5');
    ctx.fillStyle = g; ctx.fill(); ctx.strokeStyle = '#2b2f35'; ctx.lineWidth = 1.4; ctx.stroke();
    ctx.save(); ctx.rotate(-sg * 0.32);
    ctx.beginPath(); ctx.moveTo(-4, -3 * sg); ctx.lineTo(-22, -6 * sg); ctx.lineTo(-22, 2 * sg); ctx.lineTo(-4, 4 * sg); ctx.closePath();
    ctx.fillStyle = '#1d2024'; ctx.fill();
    ctx.beginPath(); ctx.ellipse(-36, 0, 15, 11, 0, 0, TAU); ctx.fillStyle = '#1d2024'; ctx.fill();
    ctx.beginPath(); ctx.ellipse(-36, 0, 9, 6, 0, 0, TAU); ctx.fillStyle = '#ffffff'; ctx.fill();
    ctx.restore();
    ctx.restore();
  });
  ctx.beginPath(); ctx.arc(0, 0, 4.2, 0, TAU); ctx.fillStyle = '#cfd4da'; ctx.fill(); ctx.strokeStyle = '#2b2f35'; ctx.lineWidth = 1.2; ctx.stroke();
  ctx.restore();
}
/* 糸を切る：はさみが出てきて切る（その間は時刻を止める）。切った瞬間 s.tCut から動く。
   切ってからの時間が足りないときは、最初（t = 0）にもどしてから切る */
var CUT = { inT: 0.35, close: 0.35, fade: 0.45 };
function startCut(s, tMax) {
  if (s.tCut !== null || s.cutAnim) return;
  if (s.t > tMax) s.t = 0;
  s.ended = false;                                            /* 「✂ 糸を切る」はいまの瞬間に切る（最後まで行ったあとでも、そこから続ける） */
  s.playing = false; s.syncPlayLabel();
  s.cutAnim = { t0: performance.now(), snipped: false };
  if (s.extra && s.extra.cut) s.extra.cut.disabled = true;
  if (s.extra && s.extra.cut0) s.extra.cut0.disabled = true;
  var step = function (now) {
    var A = s.cutAnim; if (!A) return;
    var e = (now - A.t0) / 1000; A.e = e;
    if (!A.snipped && e >= CUT.inT + CUT.close) {
      A.snipped = true; s.tCut = s.t;
      SIMS.forEach(function (o) { if (o !== s && o.playing) { o.playing = false; o.syncPlayLabel(); } });
      s.playing = true; s.syncPlayLabel(); s.renderRight(); startLoop();
    }
    if (e >= CUT.inT + CUT.close + CUT.fade) { s.cutAnim = null; s.draw(); return; }
    if (!s.playing) s.draw();
    requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}
/* 「✂ 0 秒で糸を切る」：t = 0 にもどして、動き出す瞬間に糸を切る（2026-10-11 千葉さん） */
function startCut0(s) {
  if (s.tCut !== null || s.cutAnim) return;
  s.endWindow && s.endWindow(); s.t = 0; s.ended = false; s.trail = [];
  startCut(s, Infinity);
}
function resetCut(s) { s.tCut = null; s.cutAnim = null; if (s.extra && s.extra.cut) s.extra.cut.disabled = false; if (s.extra && s.extra.cut0) s.extra.cut0.disabled = false; }
/* はさみの絵（切っている最中・切った直後）。(x, y)＝糸の切るところ */
function drawCutAnim(ctx, s, x, y) {
  var A = s.cutAnim; if (!A) return;
  var e = A.e || 0, inn = clamp(e / CUT.inT, 0, 1), cl = clamp((e - CUT.inT) / CUT.close, 0, 1), fd = A.snipped ? clamp(1 - (e - CUT.inT - CUT.close) / CUT.fade, 0, 1) : 1;
  var open = 0.75 * (1 - cl), dx = (1 - inn) * 60;
  scissors(ctx, x + 34 + dx, y + 2, -1, -0.05, open, 0.55, fd * (0.3 + 0.7 * inn));
}

/* ---------- 右の列のベクトル図（力のつり合い・見かけの重力など） ----------
   o.vecs = [{x, y, col, lab, kind}]（x：右が正、y：上が正。単位はそろっていれば何でもよい）を「つぎつぎにつなげて」描く。
   o.sum：はじめの点から最後の点へ、合成したベクトルを描く（{col, lab}）。o.closed：最後が始点にもどる（つり合い）ことを書きそえる。
   o.title：左上の見出し、o.h：高さ。図は canvas の中にきっちり収める */
function vecDiagram(cv, o) {
  if (!cv) return;
  /* o.lead：図の上に「○○の式の関係を図に表すと」の説明（2026-10-12 千葉さん：ベクトル図には何を表した図かを書く） */
  if (o.lead) { var pl = cv.previousElementSibling; if (!pl || !pl.classList.contains('veclead')) { pl = document.createElement('p'); pl.className = 'veclead'; cv.parentNode.insertBefore(pl, cv); } var lh = mathify(o.lead); if (pl._h !== lh) { pl._h = lh; pl.innerHTML = lh; } }
  var W = Math.max(220, Math.floor((cv.parentNode && cv.parentNode.clientWidth) || 300)), H = o.h || 180;
  var ctx = prep(cv, W, H);
  var pts = [[0, 0]], x = 0, y = 0;
  o.vecs.forEach(function (v) { x += v.x; y += v.y; pts.push([x, y]); });
  /* 矢印がすべて一直線上にあると（a = 0 の 2 力のつり合いなど）、行きと帰りの矢印が完全に重なって見えない。
     そのときは 1 本ずつ横にずらして並べる（2026-10-12 千葉さん） */
  var d0 = null; o.vecs.forEach(function (v) { if (!d0 && Math.hypot(v.x, v.y) > 1e-9) d0 = [v.x / Math.hypot(v.x, v.y), v.y / Math.hypot(v.x, v.y)]; });
  var lin = !!d0 && o.vecs.every(function (v) { return Math.abs(v.x * d0[1] - v.y * d0[0]) < 1e-6 * (1 + Math.hypot(v.x, v.y)); });
  var nv = o.vecs.length + (o.sum ? 1 : 0), STEP = 30;
  var offOf = function (i) { return lin ? (i - (nv - 1) / 2) * STEP : 0; };   /* 画面の px。ずらす向きは矢印に垂直 */
  var xs = pts.map(function (p) { return p[0]; }), ys = pts.map(function (p) { return p[1]; });
  var x0 = Math.min.apply(null, xs), x1 = Math.max.apply(null, xs), y0 = Math.min.apply(null, ys), y1 = Math.max.apply(null, ys);
  var top = o.title ? 40 : 24, bot = o.closed ? 50 : 26;   /* 矢印の名前が見出し・下の説明と重ならないように */
  var sc = Math.min((W - 120 - (lin ? nv * STEP : 0)) / Math.max(1e-6, x1 - x0), (H - top - bot) / Math.max(1e-6, y1 - y0), o.maxSc || 1e9);
  var ox = (W - (x1 - x0) * sc) / 2 - x0 * sc, oy = top + y1 * sc;
  var px = d0 ? -d0[1] : 0, py = d0 ? -d0[0] : 0;                  /* 画面での垂直の向き（y は下向きなので符号に注意） */
  if (d0) { px = d0[1]; py = d0[0]; }
  var X = function (p, off) { return ox + p[0] * sc + (off || 0) * px; }, Y = function (p, off) { return oy - p[1] * sc + (off || 0) * py; };
  var cx = 0, cy = 0; pts.forEach(function (p) { cx += X(p); cy += Y(p); }); cx /= pts.length; cy /= pts.length;   /* 文字は図形の外側に置く */
  if (o.title) label(ctx, o.title, 10, 14, { size: 11.5, bold: true, color: COL.ink2, align: 'left' });
  if (lin && nv > 1) {                                               /* ずらしたことが分かるよう、つなぎ目を細い点線で */
    ctx.save(); ctx.setLineDash([2, 3]); ctx.strokeStyle = '#b9b2a5'; ctx.lineWidth = 1;
    o.vecs.forEach(function (v, i) { if (i === 0) return; var p = pts[i]; ctx.beginPath(); ctx.moveTo(X(p, offOf(i - 1)), Y(p, offOf(i - 1))); ctx.lineTo(X(p, offOf(i)), Y(p, offOf(i))); ctx.stroke(); });
    ctx.restore();
  }
  if (o.sum) {
    var so = offOf(nv - 1);
    var ar0 = arrow(ctx, X(pts[0], so), Y(pts[0], so), X(pts[pts.length - 1], so), Y(pts[pts.length - 1], so), 'comp', o.sum.col || '#2f3a8f', { noShift: true });
    if (ar0 && o.sum.lab) { var mx0 = (ar0.x1 + ar0.x2) / 2, my0 = (ar0.y1 + ar0.y2) / 2, nx0 = -ar0.uy, ny0 = ar0.ux; if ((mx0 - cx) * nx0 + (my0 - cy) * ny0 > 0) { nx0 = -nx0; ny0 = -ny0; }
      /* 名前は線から十分はなし、線と反対がわへ寄せる（mg′ の「′」が線と重ならないように） */
      label(ctx, o.sum.lab, mx0 - nx0 * 14, my0 - ny0 * 14, { size: 13, bold: true, color: o.sum.col || '#2f3a8f', align: Math.abs(nx0) < 0.3 ? 'center' : (nx0 > 0 ? 'right' : 'left') }); }
  }
  o.vecs.forEach(function (v, i) {
    var p = pts[i], q = pts[i + 1], of = offOf(i);
    var ar = arrow(ctx, X(p, of), Y(p, of), X(q, of), Y(q, of), v.kind || 'force', v.col, { noShift: true });
    if (!ar || !v.lab) return;
    var mx = (ar.x1 + ar.x2) / 2, my = (ar.y1 + ar.y2) / 2, nx = -ar.uy, ny = ar.ux;
    if ((mx - cx) * nx + (my - cy) * ny < 0) { nx = -nx; ny = -ny; }
    if (pts.length <= 2) { nx = -ar.uy || 1; ny = ar.ux; }
    if (lin) { var sx = of * px, sy = of * py; if (Math.abs(sx) >= Math.abs(sy)) { nx = sx < 0 ? -1 : (sx > 0 ? 1 : (i === 0 ? -1 : 1)); ny = 0; } else { nx = 0; ny = sy < 0 ? -1 : 1; } }   /* ずらしたときは、ずらした向き（外側）へ */
    var off = v.kind === 'fict' ? 22 : 16;
    label(ctx, v.lab, mx + nx * off, my + ny * off, { size: 13, bold: true, color: v.kind === 'fict' ? '#b35f0c' : (v.col || COL.force), align: Math.abs(nx) < 0.3 ? 'center' : (nx > 0 ? 'left' : 'right') });
  });
  if (o.closed) label(ctx, o.closed === true ? '矢印をつなぐと、もとの点にもどる（合力 0）' : o.closed, W / 2, H - 12, { size: 11, color: COL.sub });
}
