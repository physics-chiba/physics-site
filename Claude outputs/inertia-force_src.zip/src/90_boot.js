/* =========================================================================
   90_boot.js … 自動テスト用の窓口（window.TEST）と検算 check()
   ========================================================================= */
'use strict';
function check() {
  var out = {};
  /* 慣性系（運動方程式）と非慣性系（力のつり合い）で、垂直抗力・張力・座席の力が同じ値になるか */
  var e = 0;
  P.AST.forEach(function (a) {
    var m = P.mP;
    var Nin = m * a + m * G, Nrot = m * G + m * a;                        /* ma = N − mg ／ N − mg − ma = 0 */
    e = Math.max(e, Math.abs(Nin - P.elevN(m, a)), Math.abs(Nrot - P.elevN(m, a)));
    var Fin = m * a, Frot = m * a;                                        /* ma = F ／ F − ma = 0 */
    e = Math.max(e, Math.abs(Fin - P.trainF(m, a)), Math.abs(Frot - P.trainF(m, a)));
    var mb = P.ball.m; e = Math.max(e, Math.abs((mb * a + mb * G) - P.ballS(mb, a)));
  });
  out.m1_in_vs_rot_err = e;
  /* 加速度 0 では慣性力 0。静止と等速で、非慣性系から見た力は同じ */
  out.m1_inert_zero = P.trainF(P.mP, 0) === 0 && P.elevN(P.mP, 0) === P.mP * G;
  /* 糸を切ってから床に着くまで：外から見た 2 つの式（小球 y1 = h + Vt − gt²/2、床 y2 = Vt + at²/2）を数値で解いて、t = √(2h/(g+a)) と比べる */
  var ef = 0, ft = {};
  P.AST.forEach(function (a) {
    [0, 0.5, 1.3].forEach(function (V) {
      var h = P.ball.h, lo = 0, hi = 2;
      for (var i = 0; i < 80; i++) { var md = (lo + hi) / 2, d = (h + V * md - 0.5 * G * md * md) - (V * md + 0.5 * a * md * md); if (d > 0) lo = md; else hi = md; }
      if (isFinite(P.fallTime(h, a))) ef = Math.max(ef, Math.abs(lo - P.fallTime(h, a)));
    });
    ft[a] = +P.fallTime(P.ball.h, a).toFixed(3);
  });
  out.m1_fall_time_err = +ef.toExponential(2);
  out.m1_fall_time = ft;
  /* はかりの読み（N と kg） */
  var sc = {}; P.AST.forEach(function (a) { sc[a] = [+P.scaleN(10, a).toFixed(1), +P.scaleKg(10, a).toFixed(2)]; });
  out.m1_scale = sc;
  /* 2-1：つり合いの角 tanθ = a/g、張力 S = m√(a²+g²)（慣性系の 2 式と非慣性系の 2 式が同じ値） */
  var e21 = 0; P.AST.forEach(function (a) { var m = TR2.m, th = Math.atan2(Math.abs(a), G), S = m * Math.hypot(a, G);
    e21 = Math.max(e21, Math.abs(m * Math.abs(a) - S * Math.sin(th)), Math.abs(S * Math.cos(th) - m * G)); });
  out.m2_s1_balance_err = +e21.toExponential(2);
  /* 2-4：測った周期と T = 2π√(l/√(a²+g²)) */
  var e24 = {}; P.AST.forEach(function (a) { var s = { v: { a: a } }, Tm = m24Period(s), T = 2 * Math.PI * Math.sqrt(TR2.l / Math.hypot(G, a)); e24[a] = [+Tm.toFixed(4), +T.toFixed(4), +((Tm / T - 1) * 100).toFixed(3) + '%']; });
  out.m2_s4_period = e24;
  /* 2-2：a = g tanθ のとき、斜面にそった相対加速度が 0 */
  out.m2_s2_rest_err = +Math.abs(G * Math.sin(Math.PI / 4) - G * Math.tan(Math.PI / 4) * Math.cos(Math.PI / 4)).toExponential(2);
  /* 2-3：はじめの M = 1 kg。非慣性系の垂直方向のつり合い N = m(g cosθ − A sinθ) と、台の運動方程式 MA = N sinθ */
  var q = m23({ v: { M: 1 } });
  out.m2_s3 = { A: +q.A.toFixed(4), aRel: +q.aRel.toFixed(4), N: +q.N.toFixed(4),
    bal_err: +Math.abs(q.N - q.m * (G * Math.cos(q.th) - q.A * Math.sin(q.th))).toExponential(2), wedge_err: +Math.abs(q.M * q.A - q.N * Math.sin(q.th)).toExponential(2) };
  /* 4-3：衝突後の最大の伸び（数値で解いた値）と L' の式。衝突がばねの最大の伸びより前に起きていること。C が斜面から離れないこと（N の最小 > 0） */
  out.m4_s3 = M43.LST.map(function (L) { var C = m43Path({ v: { L: L } }); return { L: L, vC: +C.coll.vC.toFixed(4), Lp_sim: +C.umax.u.toFixed(5), Lp_formula: +C.Lp.toFixed(5), before_max: C.coll.t < C.umax.t, Nmin: +C.Nmin.toFixed(3) }; });
  /* 4-1：a_A = g tanθ のすこし上・下で、B が動き出すかどうか */
  var th41 = Math.PI / 6, gt = G * Math.tan(th41);
  out.m4_s1 = [gt - 0.05, gt + 0.05].map(function (a) { var C = m4PathB({}, 'x' + a, th41, function () { return a; }, 0.5); return { aA: +a.toFixed(3), moves: C.start !== null }; });
  /* 4-2：L の境界（θ = 30°）0.2 tanθ < L ≦ 0.2/tanθ のすこし外と中 */
  var L0 = M4.mA * G / M4.k, lo = L0 * Math.tan(th41), hi = L0 / Math.tan(th41);
  out.m4_s2 = [lo - 0.01, lo + 0.01, hi - 0.01, hi + 0.01].map(function (L) { var om = Math.sqrt(M4.k / M4.mA); var C = m4PathB({}, 'y' + L, th41, function (t) { return L * om * om * Math.cos(om * t); }, 2.0); return { L: +L.toFixed(3), moves: C.start !== null, leaves: C.left !== null }; });
  return out;
}
window.TEST = {
  check: check, sims: SIMS, byId: SIM_BY_ID, modes: MODES,
  activate: function (id) { activateMode(id); },
  sim: function (id) { return SIM_BY_ID[id]; },
  setT: function (id, t) { var s = SIM_BY_ID[id]; s.playing = false; s.setT(t); s.syncPlayLabel(); },
  setVar: function (id, k, x) { var s = SIM_BY_ID[id]; if (s.def.onVar) s.def.onVar(s, k, x); else s.v[k] = x; s.changed(k); },
  still: function (id) { var s = SIM_BY_ID[id]; s.def.onVar(s, 'a', A_STILL); s.changed('a'); },   /* 加速度バーの「0（静止）」を選ぶのと同じ */
  cut: function (id, t) { var s = SIM_BY_ID[id]; s.playing = false; s.t = t || 0; s.tCut = s.t; if (s.extra.cut) s.extra.cut.disabled = true; s.renderRight(); s.draw(); },
  rot: function (id, on) { setRot(SIM_BY_ID[id], on); }
};
