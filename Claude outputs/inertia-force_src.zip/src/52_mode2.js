/* =========================================================================
   52_mode2.js … モード2「平面上の慣性力」
   2-1 電車の中で糸につるされた小球（糸を切る）
   2-2 動かされる斜め台の上の物体（手で台を押す）
   2-3 斜め台をすべる物体（conservation-quiz-basic.html の問7 を移したもの）
   2-4 電車の中で糸につるされた振り子の周期
   ・外（慣性系）から見るとき、電車（台）は画面の右から出たら左から入る（参考動画と同じ）。地面と外の観測者は止まっている。
   ・一緒に加速運動する観測者（非慣性系）から見るとき、電車（台）は画面のまん中に止まり、地面と外の観測者が動く。
   ========================================================================= */
'use strict';
var COL_RES = '#2f3a8f';                 /* 合力（見かけの重力）＝あい色（circular-motion.html の合力と同じ） */
function wrapX(x, p) { return ((x % p) + p) % p; }

/* ---------- 電車の舞台（2-1・2-4） ---------- */
var TR2 = { L: 3.0, Hin: 1.75, lift: 0.3, hookU: 2.1, hookV: 1.45, l: 0.5, m: 0.5, obsU: 0.38, rb: 0.08, wall: 0.05 };   /* rb：小球の半径［m］、wall：電車の壁の厚さ［m］ */
function train2Scene(s, ctx, W, H, inner) {
  var k = Math.min(W / 4.3, (H - 64) / (TR2.Hin + TR2.lift + 0.72)), yg = H - 40, tw = TR2.L * k;
  var a = aEff(s), t = s.t, X = dispOf(s, t);
  var Pw = W + tw + 40;
  var X0 = 0;                                                     /* 外から見るとき、糸を切ったら、小球が床に着く瞬間に電車が画面のまん中に来るように置く（着いたあとの図が見えるように） */
  if (!s.rot && s.tCut !== null && s.tCut !== undefined && s._c21 && s._c21.tc === s.tCut) X0 = dispOf(s, s.tCut + s._c21.tf + 0.05);
  var tx = s.rot ? (W - tw) / 2 : wrapX((X - X0) * k + (W - tw) / 2 + tw + 20, Pw) - tw - 20;
  var sh = s.rot ? -X * k : 0;
  var yb = yg - TR2.lift * k, yt = yb - TR2.Hin * k;
  posNote(ctx, W, '右向き', 'right');
  /* 柱（1.5 m おき） */
  ctx.save(); ctx.strokeStyle = '#ddd7cb'; ctx.lineWidth = 2;
  var sp = 1.5 * k, off = wrapX(sh, sp);
  for (var x = off - sp; x < W + sp; x += sp) { ctx.beginPath(); ctx.moveTo(x, yg); ctx.lineTo(x, yg - 2.9 * k); ctx.stroke(); }
  ctx.restore();
  groundShift(ctx, 0, W, yg, sh);
  /* 外の観測者（地面）：非慣性系では地面といっしょに流れていき、画面の外に出たら目じるしだけ（もどってこない。2026-10-11 千葉さん：2 回出てくるのはおかしい） */
  var ox = 0.45 * k + sh, hdIn = null;
  if (ox > -20 && ox < W + 20) hdIn = observer(ctx, ox, yg, 0, -1, NAME_IN, !s.rot, 1.35 * k);
  else offMarker(ctx, W, H, ox, yg - 0.7 * k, NAME_IN, !s.rot);
  /* 電車 */
  ctx.save(); ctx.fillStyle = 'rgba(255,255,255,.9)'; ctx.strokeStyle = COL.ink; ctx.lineWidth = 2.2;
  ctx.beginPath(); ctx.rect(tx, yt, tw, TR2.Hin * k); ctx.fill(); ctx.stroke();
  ctx.lineWidth = 3; ctx.strokeStyle = '#2b5f8a'; ctx.beginPath(); ctx.moveTo(tx, yb); ctx.lineTo(tx + tw, yb); ctx.stroke();
  ctx.restore();
  [0.55, TR2.L - 0.55].forEach(function (u) { ctx.save(); ctx.beginPath(); ctx.arc(tx + u * k, yg - 0.16 * k, 0.16 * k, 0, TAU); ctx.fillStyle = '#fff'; ctx.fill(); ctx.strokeStyle = COL.ink; ctx.lineWidth = 1.6; ctx.stroke(); ctx.restore(); });
  label(ctx, '電車', tx + 20, yt + 11, { size: 11, color: COL.sub });
  var g = { k: k, tx: tx, tw: tw, yb: yb, yt: yt, yg: yg, a: a,
    SX: function (u) { return tx + u * k; }, SY: function (v) { return yb - v * k; } };
  /* 一緒に加速する観測者（電車の中・左） */
  g.hdRot = observer(ctx, g.SX(TR2.obsU), yb, 0, -1, '', s.rot, 1.3 * k);
  label(ctx, NAME_ROT + (s.rot ? '（いまの視点）' : ''), tx + tw / 2, yg + 22, { size: s.rot ? 11.5 : 10.5, bold: s.rot, color: s.rot ? COL.vel : '#9aa3ac' });
  g.hdIn = hdIn;
  inner(g);
  /* 加速度（太い矢印）・速度 */
  if (Math.abs(a) > 1e-9) { var dir = a > 0 ? 1 : -1, La = 22 + 5 * Math.abs(a);
    blockArrow(ctx, tx + tw * 0.6 - dir * La / 2, yt - 30, dir, 0, La, '電車の加速度 a' + (a > 0 ? '（右向き）' : '（左向き）'), { x: tx + tw * 0.6, y: yt - 50 }); }
  else label(ctx, s.v.still ? '電車は静止している' : '電車は等速で動いている（加速度 0）', tx + tw / 2, yt - 30, { size: 11.5, color: COL.sub });
  if (!s.rot) { var v = velOf(s, t); if (Math.abs(v) > 0.01) velAt(ctx, tx + tw * 0.25, yt - 14, v > 0 ? 1 : -1, 0, Math.min(tw * 0.42, Math.abs(v) * 8 * k / 100 + 6), [0, -2]); }
  return g;
}

/* ---------- 振り子（電車の中から見た角）：θ は鉛直から測り、右（前）が正。つり合いの角 θ0 = −atan(a/g) ----------
   θ'' = −(g'/l) sin(θ − θ0) − c θ'（c：空気などによる減衰）。t = 0 からの数値積分（刻み 1/1200 s）を、時刻が進むぶんだけ足す */
function pendTheta0(a) { return -Math.atan2(a, G); }
/* 運動の途中で a を変えたら（区間が増えたら）、t = 0 から積分しなおす */
function segKey(s) { return segsOf(s).map(function (g) { return g.t0.toFixed(5) + ':' + g.a; }).join('|'); }
function pendState(s, opt) {
  var l = opt.l, c = opt.c;
  var key = [segKey(s), l, c, opt.th0].join(',');
  var P = s._pd;
  if (!P || P.key !== key || s.t < P.t - 1e-9) P = s._pd = { key: key, t: 0, th: opt.th0, om: 0 };
  var h = 1 / 1200, tEnd = Math.min(s.t, opt.tStop === undefined ? s.t : opt.tStop);
  var gp = 0, th0 = 0;
  var acc = function (th, om) { return -(gp / l) * Math.sin(th - th0) - c * om; };
  while (P.t < tEnd - 1e-12) {
    var aa = aAt(s, P.t + 1e-9); gp = Math.hypot(G, aa); th0 = pendTheta0(aa);
    var dt = Math.min(h, tEnd - P.t);
    var k1t = P.om, k1o = acc(P.th, P.om), k2t = P.om + 0.5 * dt * k1o, k2o = acc(P.th + 0.5 * dt * k1t, P.om + 0.5 * dt * k1o);
    var k3t = P.om + 0.5 * dt * k2o, k3o = acc(P.th + 0.5 * dt * k2t, P.om + 0.5 * dt * k2o), k4t = P.om + dt * k3o, k4o = acc(P.th + dt * k3t, P.om + dt * k3o);
    P.th += dt / 6 * (k1t + 2 * k2t + 2 * k3t + k4t); P.om += dt / 6 * (k1o + 2 * k2o + 2 * k3o + k4o); P.t += dt;
  }
  var an = aAt(s, Math.max(0, tEnd - 1e-9)); gp = Math.hypot(G, an); th0 = pendTheta0(an);
  return { th: P.th, om: P.om, th0: th0, gp: gp, a: an, S: opt.m * gp * Math.cos(P.th - th0) + opt.m * l * P.om * P.om };
}
/* 振り子の小球の位置（電車の中の座標：u＝左はしから、v＝床から） */
function bobUV(th, l) { return [TR2.hookU + l * Math.sin(th), TR2.hookV - l * Math.cos(th)]; }
/* 振り子の絵（つり下げ棒・糸・小球・角 θ） */
function drawPend(ctx, g, th, th0, opt) {
  var k = g.k, hx = g.SX(TR2.hookU), hy = g.SY(TR2.hookV), b = bobUV(th, TR2.l), bx = g.SX(b[0]), by = g.SY(b[1]), br = opt.br || 10;
  ctx.save(); ctx.strokeStyle = '#8d9097'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(hx, g.yt); ctx.lineTo(hx, hy); ctx.stroke();
  ctx.beginPath(); ctx.arc(hx, hy, 3, 0, TAU); ctx.fillStyle = COL.ink2; ctx.fill();
  ctx.setLineDash([4, 4]); ctx.lineWidth = 1; ctx.strokeStyle = '#aaa69c'; ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(hx, hy + TR2.l * k + 22); ctx.stroke(); ctx.setLineDash([]);
  if (!opt.cut) { ctx.strokeStyle = '#7a6a55'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(bx - Math.sin(th) * br, by + Math.cos(th) * br); ctx.stroke(); }
  ctx.restore();
  if (!opt.cut && Math.abs(th) > 0.03) {                        /* 角 θ（鉛直と糸のあいだ） */
    var r = Math.min(0.32 * k, 36), a0 = Math.PI / 2, a1 = Math.PI / 2 - th;
    angArc(ctx, hx, hy, r, Math.min(a0, a1), Math.max(a0, a1), COL.ink2);
    var am = (a0 + a1) / 2; sym(ctx, 'θ', hx + Math.cos(am) * (r + 11), hy + Math.sin(am) * (r + 11), { size: 15, color: COL.ink2 });
  }
  return { bx: bx, by: by, br: br, hx: hx, hy: hy };
}

/* ===================== 2-1 電車の中で糸につるされた小球 ===================== */
var M21 = { TW: 2.4, c: 2.6 };
/* 糸を切ったあとの小球（電車の中の座標）。電車の中から見た加速度は（−a, −g）。
   電車の壁に当たったら、はね返る（反発係数 0.6。a = −9.8 などで前の壁まで飛ぶとき。2026-10-11 千葉さん）。床に着いたら止まる */
var M21E = 0.6;
function cut21(s) {
  if (s.tCut === null || s.t < s.tCut) return null;
  var C = s._c21, key = s.tCut + '|' + segKey(s);
  if (!C || C.key !== key) {
    var ps = pendState(s, { l: TR2.l, c: M21.c, th0: 0, m: TR2.m, tStop: s.tCut });   /* 切った瞬間の振り子 */
    var b = bobUV(ps.th, TR2.l), vu = TR2.l * ps.om * Math.cos(ps.th), vv = TR2.l * ps.om * Math.sin(ps.th);
    var uL = TR2.wall + TR2.rb, uR = TR2.L - TR2.wall - TR2.rb, h = 1 / 1000;
    var u = b[0], v = b[1], tt = 0, path = [[0, u, v]], bounced = 0, tf = null;
    while (tt < 4) {
      var aa = aAt(s, s.tCut + tt);
      vu += -aa * h; vv += -G * h; u += vu * h; v += vv * h; tt += h;
      if (u < uL) { u = uL + (uL - u); vu = -vu * M21E; bounced++; }
      if (u > uR) { u = uR - (u - uR); vu = -vu * M21E; bounced++; }
      if (v <= TR2.rb) { v = TR2.rb; tf = tt; path.push([tt, u, v]); break; }
      path.push([tt, u, v]);
    }
    if (tf === null) tf = tt;
    C = s._c21 = { key: key, tc: s.tCut, u0: b[0], v0: b[1], vu0: TR2.l * ps.om * Math.cos(ps.th), vv0: TR2.l * ps.om * Math.sin(ps.th),
      tf: tf, th: ps.th, path: path, bounced: bounced, a: aAt(s, s.tCut), uEnd: u, vEnd: v };
  }
  var tau = Math.min(s.t - s.tCut, C.tf);
  var at = function (t1) { var P = C.path, i = Math.min(P.length - 1, Math.max(0, Math.round(t1 * 1000))); return [P[i][1], P[i][2]]; };
  var q = at(tau);
  return { C: C, tau: tau, landed: s.t - s.tCut >= C.tf - 1e-9, u: q[0], v: q[1], at: at };
}
/* 床に着いたあとの図（構想メモの図と同じ）：切った位置に小球のかげ、そこから力のベクトル、床までの点線、高さ h と ずれ x */
function landFigure(ctx, s, g, ct) {
  var k = g.k, C = ct.C, a = C.a, m = TR2.m, fsc = 9 * k / 100;
  var gx = g.SX(C.u0), gy = g.SY(C.v0), br = clamp(TR2.rb * k, 7, 13);
  var fx = g.SX(C.u0), fy = g.yb;                                 /* 切った位置の真下の床 */
  var lx = g.SX(C.uEnd);                                          /* 落ちた位置 */
  ctx.save(); ctx.setLineDash([4, 4]); ctx.strokeStyle = '#8d9097'; ctx.lineWidth = 1.3;
  ctx.beginPath(); ctx.moveTo(gx, gy); ctx.lineTo(fx, fy); ctx.stroke();               /* 真下への点線 */
  ctx.restore();
  ballShape(ctx, gx, gy, br, '#c9d3de', 0.4);
  label(ctx, '切った位置', gx + (a >= 0 ? 16 : -16), gy - br - 10, { size: 10, color: COL.sub, align: a >= 0 ? 'left' : 'right' });
  /* 高さ h（左に寸法線）と、ずれ x（床の上に寸法線） */
  var hxp = gx + (a >= 0 ? 22 : -22);
  dimLine(ctx, hxp, gy, hxp, fy, COL.ink2); sym(ctx, 'h', hxp + (a >= 0 ? 10 : -10), (gy + fy) / 2, { size: 16, color: COL.ink2, align: a >= 0 ? 'left' : 'right' });
  if (Math.abs(lx - fx) > 6) { dimLine(ctx, fx, fy + 12, lx, fy + 12, COL.ink2); sym(ctx, 'x', (fx + lx) / 2, fy + 24, { size: 16, color: COL.ink2 }); }
  /* 力：重力 mg（下）。中から見るときは慣性力 ma と合力 mg′（見かけの重力）。外から見るときは慣性力は描かない */
  forceArrow(ctx, gx, gy, 0, 1, m * G * fsc, COL.force, 'mg', 'below');
  if (s.rot && Math.abs(a) > 1e-9) {
    forceArrow(ctx, gx, gy, a > 0 ? -1 : 1, 0, m * Math.abs(a) * fsc, COL.inert, 'ma', a > 0 ? 'left' : 'right', 'fict');
    var ex = -a * m * fsc, ey = G * m * fsc;
    var ar = arrow(ctx, gx, gy, gx + ex, gy + ey, 'comp', COL_RES, { noShift: true });
    if (ar) sym(ctx, 'mg′', ar.x2 + (a > 0 ? -16 : 16), ar.y2 + 6, { size: 15, color: COL_RES, align: a > 0 ? 'right' : 'left' });
    if (!C.bounced) {                                             /* 合力の向きに、床までの点線（まっすぐ落ちる道すじ） */
      ctx.save(); ctx.setLineDash([2, 5]); ctx.strokeStyle = COL_RES; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(gx, gy); ctx.lineTo(lx, fy); ctx.stroke(); ctx.restore();
    }
    /* 角 θ（鉛直と mg′ のあいだ） */
    var r = 30, a0 = Math.PI / 2, a1 = Math.atan2(ey, ex);
    angArc(ctx, gx, gy, r, Math.min(a0, a1), Math.max(a0, a1), COL_RES);
    sym(ctx, 'θ', gx + Math.cos((a0 + a1) / 2) * (r + 10), gy + Math.sin((a0 + a1) / 2) * (r + 10), { size: 14, color: COL_RES });
  }
  if (!s.rot) {                                                   /* 外から見ると：切った瞬間の速度 V（水平）で飛び出す＝水平投射 */
    var V = velOf(s, C.tc), Lv = Math.min(1.1 * k, Math.abs(V) * 6 * k / 100 + 10);
    if (Math.abs(V) > 0.05) { var av = arrow(ctx, gx, gy - br - 8, gx + (V > 0 ? 1 : -1) * Lv, gy - br - 8, 'vel'); if (av) sym(ctx, 'V', av.x2 + (V > 0 ? 12 : -12), av.y2, { size: 16, color: COL.vel }); }
  }
  /* 張力 S（切る前にはたらいていた力。うすく。このページでは張力を S と書く） */
  ctx.save(); ctx.globalAlpha = 0.35;
  var hx = g.SX(TR2.hookU), hy = g.SY(TR2.hookV), ux = hx - gx, uy = hy - gy, L = Math.hypot(ux, uy) || 1;
  forceArrow(ctx, gx + ux / L * br, gy + uy / L * br, ux / L, uy / L, TR2.m * Math.hypot(G, a) * fsc, COL.hand, 'S', ux > 0 ? 'right' : 'left');
  ctx.restore();
  label(ctx, '（S は切る前の張力）', hx + (a >= 0 ? 10 : -10), hy - 10, { size: 10, color: '#9aa3ac', align: a >= 0 ? 'left' : 'right' });
}
function drawM21(s, ctx, W, H) {
  var ps = pendState(s, { l: TR2.l, c: M21.c, th0: 0, m: TR2.m, tStop: s.tCut === null ? undefined : s.tCut });
  var ct = cut21(s);
  train2Scene(s, ctx, W, H, function (g) {
    var k = g.k, a = g.a, m = TR2.m;
    var pd = drawPend(ctx, g, ps.th, ps.th0, { cut: !!ct, br: clamp(TR2.rb * k, 7, 13) });
    var bx = pd.bx, by = pd.by, br = pd.br;
    if (ct) {
      /* 落ちていく道すじ（この観測者から見た）。外から見るときは地面に対する道すじ（いまの電車の位置を基準に描く） */
      var Xn = dispOf(s, s.t), n = Math.max(2, Math.round(ct.tau * 200));
      ctx.save(); ctx.setLineDash([3, 4]); ctx.strokeStyle = 'rgba(22,99,181,.75)'; ctx.lineWidth = 1.8; ctx.beginPath();
      for (var i = 0; i <= n; i++) {
        var tt = ct.tau * i / n, q = ct.at(tt), du = s.rot ? 0 : (dispOf(s, ct.C.tc + tt) - Xn);
        var X1 = g.SX(q[0] + du), Y1 = g.SY(q[1]); i ? ctx.lineTo(X1, Y1) : ctx.moveTo(X1, Y1);
      }
      ctx.stroke(); ctx.restore();
      bx = g.SX(ct.u); by = g.SY(ct.v);
      /* 糸の切れはし（つり下げ点に残る） */
      ctx.save(); ctx.strokeStyle = '#7a6a55'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(pd.hx, pd.hy); ctx.lineTo(pd.hx + Math.sin(ct.C.th) * 0.18 * k, pd.hy + Math.cos(ct.C.th) * 0.18 * k); ctx.stroke(); ctx.restore();
      if (ct.landed) landFigure(ctx, s, g, ct);
    }
    ballShape(ctx, bx, by, br, '#c9d3de');
    if (s.cutAnim) drawCutAnim(ctx, s, (pd.hx + pd.bx) / 2, (pd.hy + pd.by) / 2);
    /* 力（床に着いたあとは、切った位置の図に描く） */
    if (s.ms.showF && !(ct && ct.landed)) {
      var fsc = 9 * k / 100;
      forceArrow(ctx, bx, by, 0, 1, m * G * fsc, COL.force, 'mg', 'below');
      if (!ct) { var ux2 = pd.hx - bx, uy2 = pd.hy - by, Lu = Math.hypot(ux2, uy2) || 1; ux2 /= Lu; uy2 /= Lu;
        forceArrow(ctx, bx + ux2 * br, by + uy2 * br, ux2, uy2, ps.S * fsc, COL.hand, 'S', ux2 > 0 ? 'right' : 'left'); }
      if (s.rot && Math.abs(a) > 1e-9) forceArrow(ctx, bx, by + 3, a > 0 ? -1 : 1, 0, m * Math.abs(a) * fsc, COL.inert, '慣性力', a > 0 ? 'left' : 'right', 'fict');
    }
    drawEqualTicks(ctx);
    if (ct && ct.tau < 0.25 && !ct.landed) eventBubble(ctx, 'cut', bx, by - br - 6);
    if (ct && ct.landed) bubble(ctx, ct.C.bounced ? '壁ではね返って床に着いた！' : '床に着いた！', bx, by - br - 6, { size: 13, bg: '#dff2ee', border: '#0f8a8a', color: '#0a5c5c', dx: (ct.C.a >= 0 ? -1 : 1) * 60 });   /* 切った位置の図（mg など）と重ならないよう横へ */
    else if (ct && ct.C.bounced && ct.tau > 0.25) bubble(ctx, '壁ではね返った！', bx, by - br - 6, { size: 12.5 });
    var ae = aEff(s), say;
    if (s.rot) say = ct ? (ct.landed ? (Math.abs(a) < 1e-9 ? 'ちょうど真下に落ちた' : '真下より' + (a > 0 ? '後ろ' : '前') + 'に落ちた！') : 'まっすぐ斜めに落ちていく！') :
      (Math.abs(ae) < 1e-9 ? '振り子はまっすぐ下だなあ' : (ae > 0 ? '振り子が後ろに傾いたなあ' : '振り子が前に傾いたなあ'));
    else say = ct ? (ct.landed ? '小球は放物線をえがいた' : '小球は放物線をえがいてる') : (Math.abs(ae) < 1e-9 ? (s.v.still ? '電車は止まってるなあ' : '一定の速さで進んでるなあ') : '電車も小球も加速してる！');
    if (s.rot) speech(ctx, say, g.hdRot); else speech(ctx, say, g.hdIn);
  });
}
function fbd21(rot) {
  return { h: 200, draw: function (ctx, w, h, isRot) {
    var s = SIM_BY_ID.m2s1, a = s ? s.v.a : 0, m = TR2.m, gp = Math.hypot(G, a), th = Math.atan2(Math.abs(a), G), S = m * gp, fsc = 9;
    var sg = a >= 0 ? 1 : -1, bx = w / 2 + sg * 26, by = 104, br = 9, ux = sg * Math.sin(th), uy = -Math.cos(th);
    /* 糸の向き（鉛直から θ）。分力 S sinθ・S cosθ（破線） */
    ctx.save(); ctx.strokeStyle = '#7a6a55'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(bx + ux * 90, by + uy * 90); ctx.lineTo(bx + ux * br, by + uy * br); ctx.stroke();
    ctx.setLineDash([3, 3]); ctx.strokeStyle = '#aaa69c'; ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(bx, by - 92); ctx.stroke(); ctx.restore();
    ballShape(ctx, bx, by, br, '#c9d3de');
    forceArrow(ctx, bx, by, 0, 1, m * G * fsc, COL.force, 'mg', 'below');
    var as = forceArrow(ctx, bx + ux * br, by + uy * br, ux, uy, S * fsc, COL.hand, 'S', sg > 0 ? 'right' : 'left');
    if (Math.abs(a) > 1e-9) {
      arrow(ctx, bx, by, bx + ux * S * fsc, by, 'comp', COL.hand); arrow(ctx, bx, by, bx, by + uy * S * fsc, 'comp', COL.hand);
      label(ctx, 'S sinθ', bx + ux * S * fsc + sg * 6, by + 14, { size: 11, color: COL.hand, align: sg > 0 ? 'left' : 'right' });
      label(ctx, 'S cosθ', bx - sg * 8, by - S * fsc * Math.cos(th) * 0.6, { size: 11, color: COL.hand, align: sg > 0 ? 'right' : 'left' });
      if (isRot) forceArrow(ctx, bx, by + 4, -sg, 0, m * Math.abs(a) * fsc, COL.inert, '慣性力 ma', sg > 0 ? 'left' : 'right', 'fict');
      else { var ar = arrow(ctx, bx + sg * 20, by + 34, bx + sg * (20 + 10 + 30 * Math.abs(a) / G), by + 34, 'acc'); if (ar) label(ctx, '小球の加速度 a', ar.x2 + sg * 8, ar.y2, { size: 12, bold: true, color: COL.acc, align: sg > 0 ? 'left' : 'right' }); }
    }
    void as;
    drawEqualTicks(ctx);
  } };
}
/* 「静止・等速・加速」の 3 両を並べて見せる（参考動画と同じ見せ方）。外から見た図。加速の電車は、いまの a（0 なら 5 m/s²） */
function drawCmp3(s) {
  var cv = s._cmp; if (!cv || !cv.offsetParent) return;
  var W = Math.max(260, Math.floor(cv.parentNode.clientWidth)), H = 210, ctx = prep(cv, W, H);
  var aa = Math.abs(s.v.a) > 1e-9 ? s.v.a : 5, t = s.t, rows = [['静止', 0, 0], ['等速', 1.5, 0], ['加速（a = ' + accTxt(aa) + '）', 0, aa]];
  label(ctx, 'くらべてみよう：外から見た 3 両の電車（つり下げた振り子）', 8, 12, { size: 11.5, bold: true, color: COL.ink2, align: 'left' });
  rows.forEach(function (r, i) {
    var y0 = 30 + i * 60, yg = y0 + 52, k = 30, tw = 2.2 * k, P2 = W + tw + 20;
    ctx.save(); ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(0, yg); ctx.lineTo(W, yg); ctx.stroke(); ctx.restore();
    var X = r[1] * t + 0.5 * r[2] * t * t, tx = wrapX(X * k + W * 0.35 + tw + 10, P2) - tw - 10, yt = yg - 1.45 * k;
    ctx.save(); ctx.strokeStyle = COL.ink; ctx.lineWidth = 1.4; ctx.strokeRect(tx, yt, tw, 1.3 * k);
    [0.35, 1.85].forEach(function (u) { ctx.beginPath(); ctx.arc(tx + u * k, yg - 0.1 * k, 0.1 * k, 0, TAU); ctx.stroke(); });
    var th = r[2] ? pendTheta0(r[2]) * clamp(t / 0.25, 0, 1) : 0, hx = tx + 1.4 * k, hy = yt, L = 0.75 * k;
    ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(hx + L * Math.sin(th), hy + L * Math.cos(th)); ctx.strokeStyle = '#7a6a55'; ctx.stroke();
    ctx.beginPath(); ctx.arc(hx + L * Math.sin(th), hy + L * Math.cos(th), 4.5, 0, TAU); ctx.fillStyle = '#c9d3de'; ctx.fill(); ctx.strokeStyle = COL.ink2; ctx.stroke();
    ctx.restore();
    label(ctx, r[0], 8, y0 + 8, { size: 11, bold: true, color: r[2] ? '#9c4e06' : COL.ink2, align: 'left' });
  });
}
DEFS.m2s1 = ifBase({
  id: 'm2s1', num: 1, title: '電車の中で糸につるされた小球', mode: 'mode2', V0: P.V0T, TW: M21.TW, baseRate: 0.5,
  height: function (s, w) { return Math.round(clamp(w * 0.62, 300, 420)); },
  desc: '電車の天井から、長さ $l=0.50$ m の糸で小球（質量 $m=0.50$ kg）をつるす。電車が加速すると、糸は鉛直から角 $\\theta$ だけ傾いて止まる。<span class="todo">加速度を選んで「▶ スタート」を押し、傾いたら図の左上の「✂ 糸を切る」を押して、小球がどの向きに落ちるか見よう。</span>',
  buttons: [{ k: 'cut', label: '✂ 糸を切る', cls: 'cut', inCanvas: true, onClick: function (s) { startCut(s, M21.TW - 0.55); } },
            { k: 'cut0', label: '✂ 0 秒で糸を切る', cls: 'cut', inCanvas: true, onClick: function (s) { startCut0(s); } }],
  init: function (s) { s.tCut = null; s.cutAnim = null; s._pd = null; },
  aLocked: function (s) { return s.tCut !== null || !!s.cutAnim; },   /* 糸を切ったあとは a を変えられない */
  /* 糸を切ったら、小球が床に着いた少しあとで止める（外から見ても、着いたところの図が画面に残るように） */
  tEnd: function (s) { if (s.tCut !== null && s.tCut !== undefined) { cut21(s); if (s._c21 && s._c21.tc === s.tCut) return Math.min(M21.TW, s.tCut + s._c21.tf + 0.1); } return M21.TW; },
  onReset: function (s) { resetCut(s); }, onRestart: function (s) { resetCut(s); }, onDefaults: function (s) { resetCut(s); },
  afterBuild: function (s) { s._cmp = el('canvas', 'cmp3'); s.cw.insertAdjacentElement('afterend', s._cmp); drawCmp3(s); },
  live: function (s) { drawCmp3(s); },
  msg: function (s) {
    var a = s.v.a, ct = cut21(s), th = Math.atan2(Math.abs(a), G) * 180 / Math.PI;
    if (s.cutAnim && !s.cutAnim.snipped) return 'はさみで糸を切ります…';
    if (ct && ct.C.bounced) return '小球は電車の' + (a < 0 ? '右' : '左') + 'の壁まで飛んで、はね返った（加速度が大きいので、床に着く前に壁に届いた）。';
    if (ct) return s.rot ? '中から見ると、小球には重力 $mg$ と慣性力 $ma$ だけがはたらく。合力（<b>見かけの重力</b> $mg\'$）の向き＝<b>糸の延長の向き</b>に、まっすぐ落ちる。' :
      '外から見ると、小球は切った瞬間の電車の速度で飛び出し、重力だけで<b>水平投射</b>と同じ放物線をえがく。電車の床は加速して前へ進むので、真下より' + (a > 0 ? '後ろ' : (a < 0 ? '前' : '')) + 'に落ちる。';
    if (Math.abs(a) < 1e-9) return '加速度 0 なので、糸は鉛直のまま（静止でも等速でも同じ）。';
    return '糸は鉛直から $\\theta=' + f1(th) + '^\\circ$ 傾く（$\\tan\\theta = a/g$）。' + (s.rot ? '中から見ると、$S$・$mg$・慣性力 $ma$ がつり合っている。' : '外から見ると、$S$ と $mg$ の合力が、小球を電車と同じ加速度 $a$ で加速させている。');
  },
  eqs: function (s) {
    var a = s.v.a, m = TR2.m, S = m * Math.hypot(G, a);
    return {
      in: { h: '外（慣性系）から見る', fbd: fbd21(false), lines: [{ tag: 'eom', k: '水平方向：', t: 'ma = S\\sin\\theta' }, { tag: 'bal', k: '鉛直方向：', t: '0 = S\\cos\\theta - mg' }, { tag: 'eom', k: 'ベクトル：', t: 'm\\vec{a} = m\\vec{g} + \\vec{S}' }], num: 'いま：' + tex('S = ' + f2(S) + '\\ \\text{N}') },
      rot: { h: '一緒に加速運動する観測者（非慣性系）から見る', fbd: fbd21(true), lines: [{ tag: 'bal', k: '水平方向：', t: 'S\\sin\\theta - ma = 0' }, { tag: 'bal', k: '鉛直方向：', t: 'S\\cos\\theta - mg = 0' }, { tag: 'bal', k: 'ベクトル：', t: 'm\\vec{g} + \\vec{S} + (-m\\vec{a}) = \\vec{0}' }], num: 'いま：' + tex('S = ' + f2(S) + '\\ \\text{N}'), note: '慣性力 ' + tex('-m\\vec{a}') + ' は加速度と逆向き' } };
  },
  draw: drawM21,
  right: function (s, R) {
    var a = s.v.a, m = TR2.m, gp = Math.hypot(G, a), th = Math.atan2(Math.abs(a), G) * 180 / Math.PI, ct = cut21(s);
    var h = ifSetup(s, {
      lead: { in: '外から見ると、小球は電車と一緒に加速度 $a$ で運動している。はたらく力は張力 $S$ と重力 $mg$ だけ。その合力が水平方向（加速度の向き）を向く。',
              rot: '電車の中の観測者には、小球は傾いたまま止まって見える。張力 $S$・重力 $mg$・<b>慣性力 $ma$</b>（加速度と逆向き）の 3 つがつり合う。' },
      rows: [{ dir: '水平方向', in: ['eom', 'ma = S\\sin\\theta'], rot: ['bal', 'S\\sin\\theta - ma = 0'] },
             { dir: '鉛直方向', in: ['bal', 'S\\cos\\theta - mg = 0'], rot: ['bal', 'S\\cos\\theta - mg = 0'] }],
      fig: { in: '<canvas class="vecc" data-v="f21"></canvas>', rot: '<canvas class="vecc" data-v="f21"></canvas>' },
      now: { in: tex('\\tan\\theta = \\frac{a}{g} = \\frac{' + f1(Math.abs(a)) + '}{9.8}\\;\\Rightarrow\\;\\theta = ' + f1(th) + '^\\circ'), rot: tex('\\tan\\theta = \\frac{a}{g}\\;\\Rightarrow\\;\\theta = ' + f1(th) + '^\\circ') }
    });
    h += '<div class="qcard derive"><p class="qt">傾きの角 θ と張力 S、見かけの重力加速度 g′</p><p>2 つの式から（どちらの観測者でも同じ式になる）</p>' +
      '<div class="qeq">' + tex('\\tan\\theta = \\frac{S\\sin\\theta}{S\\cos\\theta} = \\frac{ma}{mg} = \\frac{a}{g}', true) + tex('S = \\sqrt{(ma)^2 + (mg)^2} = m\\sqrt{a^2 + g^2}', true) + '</div>' +
      '<p>電車の中の観測者には、重力 $m\\vec{g}$ と慣性力 $-m\\vec{a}$ がいつも一緒にはたらく。この 2 つの合力を<b>見かけの重力</b> $m\\vec{g}\\,\'$ とよぶ。$\\vec{g}\\,\' = \\vec{g} + (-\\vec{a})$ が<b>見かけの重力加速度</b>で、電車の中は「重力加速度が $g\'$ で、向きが鉛直から $\\theta$ 傾いた世界」と同じになる。糸は、見かけの重力のちょうど逆向きに張る。</p>' +
      '<canvas class="vecc" data-v="g21"></canvas>' +
      '<div class="qeq">' + tex("g' = \\sqrt{a^2+g^2},\\qquad S = mg'", true) + '</div>' +
      '<p class="qnow"><span class="qtag now">いまの値</span>' + tex("g' = \\sqrt{" + f1(Math.abs(a)) + '^2 + 9.8^2} = ' + f2(gp) + '\\ \\text{m/s}^2,\\quad S = ' + f2(m) + '\\times' + f2(gp) + ' = ' + f2(m * gp) + '\\ \\text{N}') + '</p></div>';
    if (ct) {
      var C = ct.C, hh = C.v0 - TR2.rb, tF = Math.sqrt(2 * hh / G), dx = hh * a / G, back = a > 0 ? '後ろ（左）' : (a < 0 ? '前（右）' : '');
      var ca = s.rot ? '' : ' class="on"', cb = s.rot ? ' class="on"' : '';
      h += '<div class="qcard derive"><p class="qt">糸を切ってから、床の高さに着くまでの時間</p>' +
        '<p>切った位置から床までの高さを $h$ とする。<b>鉛直方向だけ</b>に注目すると、どちらの観測者でも同じ式で求まる。</p>' +
        '<table class="cmpt"><thead><tr><th></th><th>外（慣性系）から見る</th><th>一緒に加速する観測者から見る</th></tr></thead><tbody>' +
        '<tr><th>はたらく力</th><td' + ca + '>重力 $mg$ だけ</td><td' + cb + '>重力 $mg$ と慣性力 $ma$（合力は見かけの重力 $mg\'$）</td></tr>' +
        '<tr><th>切った瞬間の速度</th><td' + ca + '>電車と同じ速度 $V$（水平）</td><td' + cb + '>0（止まって見える）</td></tr>' +
        '<tr><th>動き方</th><td' + ca + '><b>水平投射</b>（放物線）</td><td' + cb + '>見かけの重力の向きに<b>まっすぐ</b>（初速度 0 の等加速度運動）</td></tr>' +
        '<tr><th>水平方向</th><td' + ca + '>等速：$x_1 = Vt$</td><td' + cb + '>等加速度：$x = \\tfrac12 a t^2$（後ろ向き）</td></tr>' +
        '<tr><th>鉛直方向</th><td' + ca + '>自由落下：$h = \\tfrac12 g t^2$</td><td' + cb + '>自由落下：$h = \\tfrac12 g t^2$（同じ）</td></tr>' +
        '<tr><th>床に着くまで</th><td' + ca + '>$t = \\sqrt{2h/g}$</td><td' + cb + '>$t = \\sqrt{2h/g}$（同じ）</td></tr>' +
        '<tr><th>落ちる位置</th><td' + ca + '>床の点は $x_2 = Vt + \\tfrac12 a t^2$ まで進むので、真下より $x_2 - x_1 = \\tfrac12 a t^2$ 後ろ</td><td' + cb + '>真下より $x = \\tfrac12 a t^2$ 後ろ</td></tr>' +
        '</tbody></table>' +
        (s.rot ?
          '<p>電車の中から見ると、小球は見かけの重力 $mg\'$ の向き（糸の延長）に、加速度 $g\'$ でまっすぐ落ちる。その道のりは $\\dfrac{h}{\\cos\\theta}$ なので</p>' +
          '<div class="qeq">' + tex("\\frac{h}{\\cos\\theta} = \\frac12 g' t^2 \\;\\Rightarrow\\; t = \\sqrt{\\frac{2h}{g'\\cos\\theta}} = \\sqrt{\\frac{2h}{g}}\\quad(g'\\cos\\theta = g)", true) + '</div>' +
          '<p>と求めても同じ。ずれは ' + tex('x = \\tfrac12 a t^2 = h\\frac{a}{g} = h\\tan\\theta') + '。</p>'
          :
          '<p>外から見ると、糸が切れた瞬間に張力がなくなり、小球には重力 $mg$ だけがはたらく。切った瞬間の小球は電車と同じ速度 $V$ で水平に動いているので、<b>水平投射</b>になる。電車の床の高さは変わらないので、<b>鉛直方向の自由落下</b>だけで床の高さに着く時間が決まる。</p>' +
          '<div class="qeq">' + tex('h = \\frac12 g t^2 \\;\\Rightarrow\\; t = \\sqrt{\\frac{2h}{g}}', true) + '</div>' +
          '<p>そのあいだに、水平方向では小球は等速 $Vt$、床は加速して $Vt + \\tfrac12 a t^2$ 進む。差は ' + tex('\\tfrac12 a t^2 = h\\frac{a}{g} = h\\tan\\theta') + '。</p>') +
        '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('h = ' + f2(hh) + '\\ \\text{m},\\ t = \\sqrt{2\\times' + f2(hh) + '/9.8} = ' + f2(tF) + '\\ \\text{s}') +
        (C.bounced ? '。いまは床に着く前に電車の' + (a < 0 ? '右' : '左') + 'の壁に当たって、はね返った（ずれ $h\\tan\\theta = ' + f2(Math.abs(dx)) + '$ m が、電車の中の場所より大きいため）。' :
          (Math.abs(a) > 1e-9 ? '、真下から ' + tex(f2(Math.abs(dx))) + ' m ' + back + 'に落ちる。' : '、真下に落ちる。')) + '</p>' +
        '<p class="qnote">切る前に振り子が少しゆれていると、小球ははじめの速度をもつので、少しずれる。ゆれが止まってから切ろう。</p></div>';
    } else h += '<div class="qcard intro"><p class="qt">やってみよう</p><p>糸が傾いて止まったら、図の左上の「<b>✂ 糸を切る</b>」を押そう。小球はどの向きに落ちるだろう？　外から見たときと、電車の中から見たときで、道すじはどう違うだろう？　床に着くまでの時間はどうだろう？</p></div>';
    R.innerHTML = mathify(h + '<p class="assume">' + tex('m=0.50') + ' kg、' + tex('l=0.50') + ' m、つり下げ点は床から 1.45 m（糸が鉛直なら小球の中心は床から 0.95 m）、' + tex('g=9.8') + ' m/s²。動き出したときの振れは、空気の抵抗で少しずつ小さくなるとした。</p>');
    /* ベクトル図：中から見ると S・mg・慣性力がつり合う（閉じた三角形）。外から見ると S と mg の合力が ma */
    var fs = R.querySelector('canvas.vecc[data-v="f21"]');
    if (fs) {
      if (s.rot) vecDiagram(fs, { h: 190, title: '力のつり合い（ベクトル図）', closed: Math.abs(a) > 1e-9 ? '3 つの力の矢印をつなぐと、もとの点にもどる（合力 0）' : '2 つの力の矢印をつなぐと、もとの点にもどる（合力 0）',
        vecs: [{ x: 0, y: -m * G, col: COL.force, lab: 'mg' }].concat(Math.abs(a) > 1e-9 ? [{ x: -m * a, y: 0, col: COL.inert, lab: '慣性力 ma', kind: 'fict' }] : []).concat([{ x: m * a, y: m * G, col: COL.hand, lab: 'S' }]) });
      else vecDiagram(fs, { h: 190, title: '力の合成（ベクトル図）：合力が ma', vecs: [{ x: 0, y: -m * G, col: COL.force, lab: 'mg' }, { x: m * a, y: m * G, col: COL.hand, lab: 'S' }],
        sum: Math.abs(a) > 1e-9 ? { col: COL.acc, lab: '合力 ma' } : null, closed: Math.abs(a) > 1e-9 ? '合力は加速度の向き（水平）' : '合力 0（加速度 0）' });
    }
    var gs = R.querySelector('canvas.vecc[data-v="g21"]');
    if (gs) vecDiagram(gs, { h: 180, title: '見かけの重力加速度（ベクトル図）', vecs: [{ x: 0, y: -G, col: COL.force, lab: 'g' }].concat(Math.abs(a) > 1e-9 ? [{ x: -a, y: 0, col: COL.inert, lab: '−a', kind: 'fict' }] : []),
      sum: Math.abs(a) > 1e-9 ? { col: COL_RES, lab: "g′" } : null, closed: Math.abs(a) > 1e-9 ? "g′ = g + (−a)　大きさ √(a²+g²)" : 'a = 0 なら g′ = g' });
  }
});

/* ---------- 斜め台の舞台（2-2・2-3）：左が鉛直の面、右へ下る斜面（conservation-quiz-basic.html の問7 と同じ向き） ---------- */
function wedgeDraw(ctx, x0, yg, base, hgt) {
  ctx.save(); ctx.beginPath(); ctx.moveTo(x0, yg); ctx.lineTo(x0, yg - hgt); ctx.lineTo(x0 + base, yg); ctx.closePath();
  ctx.fillStyle = '#f4f2ec'; ctx.fill(); ctx.strokeStyle = COL.ink; ctx.lineWidth = 2.2; ctx.stroke(); ctx.restore();
}
function blockOnSlope(ctx, cx, cy, th, size) {   /* (cx, cy)＝底のまん中（斜面に接する点） */
  ctx.save(); ctx.translate(cx, cy); ctx.rotate(th); ctx.beginPath(); ctx.rect(-size / 2, -size, size, size);
  ctx.fillStyle = '#ffffff'; ctx.fill(); ctx.strokeStyle = COL.ink; ctx.lineWidth = 2; ctx.stroke(); ctx.restore();
}
/* 台を押す手（左から）。(x, y)＝こぶしの右はし */
function pushHand(ctx, x, y, s, pull) {
  ctx.save(); ctx.lineJoin = 'round'; ctx.fillStyle = '#f6e4d2'; ctx.strokeStyle = '#6d5a49'; ctx.lineWidth = 1.4;
  ctx.beginPath(); ctx.rect(x - s * 2.6, y - s * 0.28, s * 1.9, s * 0.56); ctx.fill(); ctx.stroke();
  rrect(ctx, x - s * 0.8, y - s * 0.45, s * 0.8, s * 0.9, s * 0.26); ctx.fill(); ctx.stroke();
  for (var i = 1; i <= 3; i++) { var yy = y - s * 0.45 + s * 0.225 * i; ctx.beginPath(); ctx.moveTo(x - s * 0.28, yy); ctx.lineTo(x, yy); ctx.stroke(); }
  if (pull) { ctx.beginPath(); ctx.moveTo(x, y - s * 0.3); ctx.quadraticCurveTo(x + s * 0.35, y, x, y + s * 0.3); ctx.stroke(); }
  ctx.restore();
}

/* ---------- 斜面の力：分解・斜面方向のみ（2-2・2-3 共通。2026-10-11 千葉さん） ----------
   チェック「力を斜面方向に分解する」（dec）：力の矢印に加えて、斜面にそった成分と斜面に垂直な成分（破線）を描く。
   チェック「斜面方向の力のみ表示する」（par）：斜面にそった成分だけを描く（ほかのチェックと「力を表示」は外れる）。
   F = [{x0, y0, fx, fy（画面の向き・N）, col, kind, lab, where, lp（斜面にそった成分の名前）, ln（垂直な成分の名前）}] */
var SLOPE_CHECKS = [{ k: 'dec', label: '力を斜面方向に<br>分解する', needF: true }, { k: 'par', label: '斜面方向の力のみ<br>表示する', only: true }];
function slopeForces(ctx, s, P) {
  var th = P.th, d = [Math.cos(th), Math.sin(th)], n = [Math.sin(th), -Math.cos(th)], fsc = P.fsc;
  var par = !!(s.chk && s.chk.par), dec = !!(s.chk && s.chk.dec) && s.ms.showF;
  var used = {};                                                 /* 同じ向きの成分が重なるときは、少しずらす */
  var comp = function (f, u, v, txt, side) {
    var L = Math.abs(v) * fsc; if (L < 3) return;
    var sg = v > 0 ? 1 : -1, ux = u[0] * sg, uy = u[1] * sg, key = ux.toFixed(2) + ',' + uy.toFixed(2), nU = used[key] || 0; used[key] = nU + 1;
    var px = -uy, py = ux, sh = nU ? -side * 10 * Math.ceil(nU / 2) : 0, x0 = P.bc[0] + px * sh, y0 = P.bc[1] + py * sh;
    var ar = arrow(ctx, x0, y0, x0 + ux * L, y0 + uy * L, 'comp', f.col, { noShift: true });
    if (!ar || !txt) return;
    var sd = nU ? -side : side;                                   /* ずらした矢印の名前は反対がわに */
    label(ctx, txt, ar.x2 + ux * 12 + px * sd * 16, ar.y2 + uy * 12 + py * sd * 16, { size: 12, bold: true, color: f.kind === 'fict' ? '#b35f0c' : f.col });
  };
  P.F.forEach(function (f) {
    var L = Math.hypot(f.fx, f.fy); if (L < 1e-9) return;
    if (!par && s.ms.showF) forceArrow(ctx, f.x0, f.y0, f.fx / L, f.fy / L, L * fsc, f.col, f.lab, f.where, f.kind);
    var pp = f.fx * d[0] + f.fy * d[1], pn = f.fx * n[0] + f.fy * n[1];
    if ((par || dec) && f.lp) comp(f, d, pp, f.lp, 1);
    if (dec && !par && f.ln) comp(f, n, pn, f.ln, -1);
  });
  if (par) label(ctx, '斜面にそった向きの力だけを表示中', 10, 34, { size: 11, color: COL.sub, align: 'left' });
}

/* ===================== 2-2 動かされる斜め台の上の物体 ===================== */
var M22 = { h: 1.4, m: 0.5, bs: 0.3, TW: 1.2, s0: 0.5 };
function m22Th(s) { return s.v.th * Math.PI / 180; }
function m22Rel(s, a) { var th = m22Th(s); return G * Math.sin(th) - (a === undefined ? s.v.a : a) * Math.cos(th); }   /* 斜面にそって下向きの相対加速度 */
function m22Th0(a) { return Math.atan2(a, G) * 180 / Math.PI; }
function m22Fit(s) { return s.v.a > 0 && Math.abs(s.v.th - m22Th0(s.v.a)) < 0.06; }   /* 「静止する θ」の状態 */
/* 台に対する小物体の動き：s″ = g sinθ − a(t) cosθ（運動の途中で a を変えてもよい）。斜面のはしに着いたら止める */
function m22Path(s) {
  var th = m22Th(s), L = M22.h / Math.sin(th), key = segKey(s) + '|' + s.v.th, C = s._p22;
  if (C && C.key === key) return C;
  var sMin = M22.bs * 0.6, sMax = L - M22.bs * 0.6, h = 1 / 600, sp = M22.s0 * L, v = 0, t = 0, arr = [[sp, v]], tHit = Infinity;
  while (t < M22.TW + 0.2) {
    var ar = G * Math.sin(th) - aAt(s, t + 1e-9) * Math.cos(th);
    v += ar * h; sp += v * h; t += h;
    if (sp >= sMax) { sp = sMax; v = 0; tHit = t; arr.push([sp, v]); break; }
    if (sp <= sMin) { sp = sMin; v = 0; tHit = t; arr.push([sp, v]); break; }
    arr.push([sp, v]);
  }
  C = s._p22 = { key: key, arr: arr, tHit: tHit, L: L };
  return C;
}
function m22State(s) {
  var th = m22Th(s), C = m22Path(s), t = s.t, i = Math.min(C.arr.length - 1, Math.round(t * 600));
  var aNow = aAt(s, t), ar = m22Rel(s, aNow), end = t >= C.tHit - 1e-9;
  return { th: th, L: C.L, ar: end ? 0 : ar, arNow: ar, sp: C.arr[i][0], end: end, tEnd: C.tHit, vrel: C.arr[i][1] };
}
function drawM22(s, ctx, W, H) {
  var st = m22State(s), th = st.th, base = M22.h / Math.tan(th), a = aEff(s), t = s.t, X = dispOf(s, t);
  var k = Math.min(W / 5.6, (H - 90) / 2.2, W / (base + 2.2)), yg = H - 44, bw = base * k, hp = M22.h * k;
  var Pw = W + bw + 120;
  var x0 = s.rot ? (W - bw) / 2 : wrapX(X * k + (W - bw) / 2 + 60, Pw) - 60;
  var sh = s.rot ? -X * k : 0;
  posNote(ctx, W, '右向き', 'right');
  ctx.save(); ctx.strokeStyle = '#ddd7cb'; ctx.lineWidth = 2; var sp = 1.2 * k, off = wrapX(sh, sp);
  for (var x = off - sp; x < W + sp; x += sp) { ctx.beginPath(); ctx.moveTo(x, yg); ctx.lineTo(x, yg - 0.35 * k); ctx.stroke(); }
  ctx.restore();
  groundShift(ctx, 0, W, yg, sh);
  label(ctx, '床はなめらか', W - 10, yg + 22, { size: 10.5, color: COL.sub, align: 'right' });
  /* 外の観測者：非慣性系では地面と一緒に流れていき、出たら目じるしだけ（もどってこない） */
  var ox = W - 0.35 * k + sh, hdIn = null;
  if (ox > -20 && ox < W + 20) hdIn = observer(ctx, ox, yg, 0, -1, NAME_IN, !s.rot, 1.1 * k);
  else offMarker(ctx, W, H, ox, yg - 0.6 * k, NAME_IN, !s.rot);
  wedgeDraw(ctx, x0, yg, bw, hp);
  /* 台の上（左上のすみ）の観測者 */
  ctx.save(); ctx.fillStyle = '#e9e4da'; ctx.strokeStyle = COL.ink; ctx.lineWidth = 1.2; ctx.fillRect(x0 - 0.02 * k, yg - hp - 0.06 * k, 0.32 * k, 0.06 * k); ctx.strokeRect(x0 - 0.02 * k, yg - hp - 0.06 * k, 0.32 * k, 0.06 * k); ctx.restore();
  var hdRot = observer(ctx, x0 + 0.12 * k, yg - hp - 0.06 * k, 0, -1, '', s.rot, 0.62 * k);
  label(ctx, '台と' + NAME_ROT + (s.rot ? '（いまの視点）' : ''), x0 + 4, yg + 22, { align: 'left', size: s.rot ? 11.5 : 10.5, bold: s.rot, color: s.rot ? COL.vel : '#9aa3ac' });
  /* 手（左から台を押す。a < 0 なら引く） */
  var hy = yg - hp * 0.42, push = Math.abs(a) > 1e-9;
  pushHand(ctx, x0 + 5, hy, 0.34 * k, a < 0);                 /* こぶしを台に少し重ねて、いつも台に触れて見えるように（2026-10-11 千葉さん） */
  if (push) label(ctx, a > 0 ? '手で押す' : '手で引く', x0 - 0.5 * k, hy + 0.3 * k, { size: 11, bold: true, color: '#6d5a49' });
  /* 小物体 */
  var ux = Math.cos(th), uy = Math.sin(th);                    /* 斜面にそって下る向き（画面） */
  var cx = x0 + st.sp * Math.cos(th) * k, cy = yg - hp + st.sp * Math.sin(th) * k;
  blockOnSlope(ctx, cx, cy, th, M22.bs * k);
  var nx = Math.sin(th), ny = -Math.cos(th), bc = [cx + nx * M22.bs * k / 2, cy + ny * M22.bs * k / 2];
  angArc(ctx, x0 + bw, yg, 0.32 * k, Math.PI, Math.PI + th, COL.ink2);
  sym(ctx, 'θ', x0 + bw - 0.45 * k, yg - 0.1 * k, { size: 15, color: COL.ink2 });
  var m = M22.m, fsc = 18 * k / 100, Nv = st.end ? m * G * Math.cos(th) : m * (G * Math.cos(th) + a * Math.sin(th)), F = [];
  F.push({ x0: bc[0] - ux * 7, y0: bc[1] - uy * 7, fx: 0, fy: m * G, col: COL.force, lab: 'mg', where: 'below', lp: 'mg sinθ', ln: 'mg cosθ' });
  if (Nv > 0) F.push({ x0: cx + ux * 6, y0: cy + uy * 6, fx: nx * Nv, fy: ny * Nv, col: COL.norm, lab: 'N', where: 'right' });
  if (s.rot && Math.abs(a) > 1e-9) F.push({ x0: bc[0], y0: bc[1] - 6, fx: -m * a, fy: 0, col: COL.inert, lab: '慣性力', where: a > 0 ? 'left' : 'right', kind: 'fict', lp: 'ma cosθ', ln: 'ma sinθ' });
  slopeForces(ctx, s, { th: th, bc: bc, fsc: fsc, F: F });
  drawEqualTicks(ctx);
  /* 加速度・速度 */
  if (Math.abs(a) > 1e-9) { var dir = a > 0 ? 1 : -1, La = 22 + 5 * Math.abs(a); blockArrow(ctx, x0 + bw * 0.75 - dir * La / 2, yg - hp * 0.95, dir, 0, La, '台の加速度 a' + (a > 0 ? '（右向き）' : '（左向き）'), { x: x0 + bw * 0.75, y: yg - hp * 0.95 - 20 }); }
  if (!s.rot) { var v = velOf(s, t); if (Math.abs(v) > 0.01) velAt(ctx, x0 + bw * 0.6, yg - 12, v > 0 ? 1 : -1, 0, Math.min(bw * 0.6, Math.abs(v) * 8 * k / 100 + 6), [0, -2]); }
  var rest = Math.abs(st.arNow) < 0.05 && !st.end;
  if (t > 0 && Math.abs(a) > 1e-9 && rest) pill(ctx, '斜面に対して静止！', x0 + bw * 0.06, yg - hp * 0.3, { size: 13, bg: '#dff2ee', border: '#0f8a8a', color: '#0a5c5c' });   /* 力の矢印と重ならないよう、台の中に書く */
  else if (st.end && t > 0) bubble(ctx, st.sp > st.L / 2 ? '下のはしに着いた' : '上のはしに着いた', cx, cy - M22.bs * k - 10, { size: 12.5 });
  else if (t > 0.05 && !rest) bubble(ctx, st.arNow > 0 ? 'すべり下りる' : 'すべり上がる', cx, cy - M22.bs * k - 10, { size: 12.5 });
  var say = s.rot ? (t > 0.02 && rest ? '物体は止まって見える' : (t > 0.02 ? (st.arNow > 0 ? '下へすべっていく' : '上へすべっていく') : '台の上から見ているよ')) : (t > 0.02 && rest ? '台と物体が一緒に加速してる' : (Math.abs(a) < 1e-9 ? '台は' + (s.v.still ? '止まってる' : '等速で動いてる') : '台が加速してる'));
  speech(ctx, say, s.rot ? hdRot : hdIn);
}
DEFS.m2s2 = ifBase({
  id: 'm2s2', num: 2, title: '動かされる斜め台の上の物体', mode: 'mode2', V0: 1.0, TW: M22.TW, baseRate: 0.45,
  height: function (s, w) { return Math.round(clamp(w * 0.62, 300, 420)); },
  desc: 'なめらかで水平な床の上に、傾角 $\\theta$ のなめらかな斜面をもつ台を置き、小物体（質量 $m=0.50$ kg）をのせる。手で台を押して、一定の加速度 $a$ で水平に動かす。<span class="todo">小物体が斜面に対して静止するのはどんなときか、加速度 $a$ と傾角 $\\theta$ を変えて確かめよう。</span>',
  vars: [{ k: 'th', label: '傾角 $\\theta$', aria: '傾角', min: 20, max: 60, step: 1, def: 45, dec: 1, unit: '°',
           mark: function (s) { return s.v.a > 0 ? { x: m22Th0(s.v.a), label: '$\\theta_0$' } : null; } }],
  varColsK: [['a'], ['th']],
  checks: SLOPE_CHECKS,
  buttons: [{ k: 'fit', label: '静止する θ にする', cls: 'fitb', inVar: true, onClick: function (s) {
    if (!(s.v.a > 0)) { s._note = '静止する $\\theta$ は、台を右向きに加速させる（$a>0$）ときだけある。加速度を ＋5 か ＋9.8 にしてから押そう。'; s.draw(); return; }
    s.v.th = Math.round(m22Th0(s.v.a) * 10) / 10; s._note = null; s.changed('th'); } }],
  onChanged: function (s) { s._note = null; },
  afterBuild: function (s) {
    /* 「静止する θ にする」は θ のスライダーの行へ。スライダー 2 本は横に並べる */
    var b = s.extra.fit, q = s.sl.th, hd = q && q.row.querySelector('.vhead');
    if (b && hd) { hd.appendChild(b); q.row.classList.add('hasbtn'); }
    if (s.varbox) s.varbox.classList.add('two');
  },
  live: function (s) {
    var b = s.extra.fit; if (!b) return;
    var on = m22Fit(s), gl = s.v.a > 0 && !on;
    if (b._on !== on) { b._on = on; b.classList.toggle('on', on); b.setAttribute('aria-pressed', on ? 'true' : 'false'); }
    if (b._gl !== gl) { b._gl = gl; b.classList.toggle('glow', gl); }
  },
  tEnd: function (s) { return Math.min(M22.TW, m22State(s).tEnd + 0.15); },
  msg: function (s) {
    if (s._note) return s._note;
    var st = m22State(s), a = s.v.a, th0 = m22Th0(a);
    if (Math.abs(st.arNow) < 0.05) return '<b>斜面に対して静止</b>（スライダーの目印 $\\theta_0$）：$a = g\\tan\\theta$ のとき、小物体は台と一緒に加速する。' + (s.rot ? '台の上から見ると、$N$・$mg$・慣性力 $ma$ がつり合っている。' : '外から見ると、$N$ と $mg$ の合力が水平右向き（大きさ $ma$）。');
    return (st.arNow > 0 ? 'すべり下りる' : 'すべり上がる') + '（斜面にそって ' + f2(Math.abs(st.arNow)) + ' m/s²）。' + (a > 0 ? '静止するのは $\\theta=' + f1(th0) + '^\\circ$（$\\tan\\theta=a/g$）のとき。「静止する θ にする」を押してみよう。' : '台を右向きに加速させないと、静止できない。');
  },
  eqs: function (s) {
    var th = m22Th(s), a = s.v.a, m = M22.m, N = m * (G * Math.cos(th) + a * Math.sin(th)), ar = m22Rel(s);
    return {
      in: { h: '外（慣性系）から見る（斜面に対して静止しているとき）', lines: [{ tag: 'eom', k: '小物体・水平：', t: 'ma = N\\sin\\theta' }, { tag: 'bal', k: '小物体・鉛直：', t: '0 = N\\cos\\theta - mg' }], num: 'いま：' + tex('N = ' + f2(N) + '\\ \\text{N}') + (Math.abs(ar) > 0.05 ? '（いまは静止していない）' : '') },
      rot: { h: '一緒に加速運動する観測者（非慣性系）から見る', lines: [{ tag: 'bal', k: '小物体・斜面に垂直：', t: 'N - mg\\cos\\theta - ma\\sin\\theta = 0' }, { tag: Math.abs(ar) > 0.05 ? 'eom' : 'bal', k: '小物体・斜面にそって：', t: Math.abs(ar) > 0.05 ? "ma' = mg\\sin\\theta - ma\\cos\\theta" : 'mg\\sin\\theta - ma\\cos\\theta = 0' }], num: "いま：" + tex("a' = " + f2(ar) + '\\ \\text{m/s}^2') + '（斜面にそって下向き）' } };
  },
  draw: drawM22,
  right: function (s, R) {
    var th = m22Th(s), a = s.v.a, m = M22.m, N = m * (G * Math.cos(th) + a * Math.sin(th)), fit = m22Fit(s), SJ = '<span class="subj">小物体</span>';
    var fig = fit ? '<canvas class="vecc" data-v="f22"></canvas>' : '<p class="qnote">「<b>静止する θ にする</b>」を押すと、ここに力のベクトル図が出る。</p>';
    var h = ifSetup(s, {
      title: '式の主語：小物体',
      lead: { in: '外から見て小物体が斜面に対して静止しているなら、小物体も台と同じ加速度 $a$（水平右向き）で運動している。小物体にはたらく力は重力 $mg$ と垂直抗力 $N$ だけ。',
              rot: '台の上の観測者から見ると、小物体には重力 $mg$・垂直抗力 $N$・<b>慣性力 $ma$</b>（水平左向き）がはたらく。斜面にそった向きと、斜面に垂直な向きに分けて考える。' },
      rows: [{ dir: SJ + '水平／斜面に垂直', in: ['eom', 'ma = N\\sin\\theta'], rot: ['bal', 'N - mg\\cos\\theta - ma\\sin\\theta = 0'] },
             { dir: SJ + '鉛直／斜面にそって', in: ['bal', 'N\\cos\\theta - mg = 0'], rot: ['bal', 'mg\\sin\\theta - ma\\cos\\theta = 0'] }],
      fig: { in: fig, rot: fig },
      now: { in: tex('N = ' + f2(N) + '\\ \\text{N}'), rot: tex('N = ' + f2(N) + '\\ \\text{N}') }
    });
    h += '<div class="qcard derive"><p class="qt">斜面に対して静止する条件</p>' + (s.rot ?
      '<p>斜面にそった向きの' + T_BAL + 'から（「力を斜面方向に分解する」で、成分 $mg\\sin\\theta$ と $ma\\cos\\theta$ を確かめよう）</p><div class="qeq">' + tex('mg\\sin\\theta = ma\\cos\\theta \\;\\Rightarrow\\; a = g\\tan\\theta', true) + '</div>' :
      '<p>2 つの式を割り算すると</p><div class="qeq">' + tex('\\frac{N\\sin\\theta}{N\\cos\\theta} = \\frac{ma}{mg} \\;\\Rightarrow\\; a = g\\tan\\theta', true) + '</div>') +
      '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('g\\tan\\theta = 9.8\\times\\tan' + f1(s.v.th) + '^\\circ = ' + f2(G * Math.tan(th)) + '\\ \\text{m/s}^2') + '（いまの ' + tex('a = ' + f1(a)) + '）</p>' +
      '<p>' + T_BAL + 'がずれると、小物体は斜面にそって ' + tex("a' = g\\sin\\theta - a\\cos\\theta") + ' で' + '（正ならすべり下り、負ならすべり上がる）動く。</p></div>';
    R.innerHTML = mathify(h + '<p class="assume">小物体の質量 ' + tex('m=0.50') + ' kg、台の高さ 1.4 m、' + tex('g=9.8') + ' m/s²。床も斜面もなめらか。手は台を水平に押す（' + tex('a<0') + ' のときは引く）。</p>');
    var cv = R.querySelector('canvas.vecc[data-v="f22"]');
    if (cv) {
      var Nx = N * Math.sin(th), Ny = N * Math.cos(th);
      if (s.rot) vecDiagram(cv, { h: 200, title: '力のつり合い（ベクトル図）', closed: '3 つの力の矢印をつなぐと、もとの点にもどる（合力 0）',
        vecs: [{ x: 0, y: -m * G, col: COL.force, lab: 'mg' }, { x: -m * a, y: 0, col: COL.inert, lab: '慣性力 ma', kind: 'fict' }, { x: Nx, y: Ny, col: COL.norm, lab: 'N' }] });
      else vecDiagram(cv, { h: 200, title: '力の合成（ベクトル図）：合力が ma', closed: '合力は台の加速度と同じ向き（水平右向き）',
        vecs: [{ x: 0, y: -m * G, col: COL.force, lab: 'mg' }, { x: Nx, y: Ny, col: COL.norm, lab: 'N' }], sum: { col: COL.acc, lab: '合力 ma' } });
    }
  }
});

/* ===================== 2-3 斜め台をすべる物体（問7：自由に動ける三角台） ===================== */
var M23 = { m: 1, th: Math.PI / 6, h: 1.4, bs: 0.34, MST: [0.1, 0.5, 1, 2, 10] };   /* 台の質量の選択（2026-10-11 千葉さん：0.1・0.5・1・2・10、はじめは 1） */
function m23(s) {
  var m = M23.m, M = s.v.M, th = (s.v.th === undefined ? 30 : s.v.th) * Math.PI / 180, sn = Math.sin(th), cs = Math.cos(th);   /* θ もスライダーで（2026-10-11 千葉さん） */
  var den = M + m * sn * sn, aRel = G * sn * (M + m) / den, A = m * G * sn * cs / den, N = m * G * M * cs / den;
  var S = M23.h / sn, Send = S - M23.bs, t1 = Math.sqrt(2 * Send / aRel);
  return { m: m, M: M, th: th, aRel: aRel, A: A, N: N, t1: t1 };
}
function drawM23(s, ctx, W, H) {
  var q = m23(s), th = q.th, t = Math.min(s.t, q.t1), base = M23.h / Math.tan(th);
  var k = Math.min(W / (base + 2.5), (H - 90) / 2.0), yg = H - 46, bw = base * k, hp = M23.h * k;   /* 傾角が小さいと台が横に長くなるので、それに合わせて縮める */
  var Xw = -0.5 * q.A * t * t, Vw = -q.A * t, sr = 0.5 * q.aRel * t * t + M23.bs / 2, vr = q.aRel * t;
  var x0 = (W - bw) / 2 + 0.55 * k + (s.rot ? 0 : Xw * k), sh = s.rot ? -Xw * k : 0;
  var on = s.t > 0;
  ctx.save(); ctx.strokeStyle = '#ddd7cb'; ctx.lineWidth = 2; var sp = 0.8 * k, off = wrapX(sh, sp);
  for (var x = off - sp; x < W + sp; x += sp) { ctx.beginPath(); ctx.moveTo(x, yg); ctx.lineTo(x, yg - 0.25 * k); ctx.stroke(); }
  ctx.restore();
  groundShift(ctx, 0, W, yg, sh);
  label(ctx, '床も斜面もなめらか', W - 10, yg + 22, { size: 10.5, color: COL.sub, align: 'right' });
  posNote(ctx, W, '右向き', 'right');
  var ox = W - 0.45 * k + sh, hdIn = null;                    /* 外の観測者：画面の外に出たら目じるしだけ */
  if (ox > -20 && ox < W + 20) hdIn = observer(ctx, ox, yg, 0, -1, NAME_IN, !s.rot, 1.4 * k);
  else offMarker(ctx, W, H, ox, yg - 0.7 * k, NAME_IN, !s.rot);
  wedgeDraw(ctx, x0, yg, bw, hp);
  sym(ctx, 'M', x0 + bw * 0.16, yg - hp * 0.12, { size: 16, color: COL.ink2 });
  ctx.save(); ctx.fillStyle = '#e9e4da'; ctx.strokeStyle = COL.ink; ctx.lineWidth = 1.2; ctx.fillRect(x0 - 0.36 * k, yg - hp - 0.05 * k, 0.36 * k, 0.05 * k); ctx.strokeRect(x0 - 0.36 * k, yg - hp - 0.05 * k, 0.36 * k, 0.05 * k);
  ctx.beginPath(); ctx.moveTo(x0 - 0.2 * k, yg - hp); ctx.lineTo(x0, yg - hp + 0.25 * k); ctx.stroke(); ctx.restore();
  var hdRot = observer(ctx, x0 - 0.18 * k, yg - hp - 0.05 * k, 0, -1, '', s.rot, 0.85 * k);
  label(ctx, '台と' + NAME_ROT + (s.rot ? '（いまの視点）' : ''), x0 + bw * 0.4, yg + 22, { size: s.rot ? 11.5 : 10.5, bold: s.rot, color: s.rot ? COL.vel : '#9aa3ac' });
  angArc(ctx, x0 + bw, yg, 0.32 * k, Math.PI, Math.PI + th, COL.ink2);
  sym(ctx, 'θ', x0 + bw - 0.45 * k, yg - 0.1 * k, { size: 15, color: COL.ink2 });
  var ux = Math.cos(th), uy = Math.sin(th), cx = x0 + sr * ux * k, cy = yg - hp + sr * uy * k;
  blockOnSlope(ctx, cx, cy, th, M23.bs * k);
  var nx = Math.sin(th), ny = -Math.cos(th), bc = [cx + nx * M23.bs * k / 2, cy + ny * M23.bs * k / 2];
  sym(ctx, 'm', bc[0] + nx * 0.34 * k, bc[1] + ny * 0.34 * k, { size: 15, color: COL.ink2 });
  var fsc = 9 * k / 100, m = q.m, F = [];
  F.push({ x0: bc[0] - ux * 7, y0: bc[1] - uy * 7, fx: 0, fy: m * G, col: COL.force, lab: 'mg', where: 'below', lp: 'mg sinθ', ln: 'mg cosθ' });
  F.push({ x0: cx + ux * 7, y0: cy + uy * 7, fx: nx * q.N, fy: ny * q.N, col: COL.norm, lab: 'N', where: 'right' });
  if (s.rot && on) F.push({ x0: bc[0], y0: bc[1] - 7, fx: m * q.A, fy: 0, col: COL.inert, lab: '慣性力', where: 'right', kind: 'fict', lp: 'mA cosθ', ln: 'mA sinθ' });   /* 台の加速度は左向き → 慣性力は右向き */
  slopeForces(ctx, s, { th: th, bc: bc, fsc: fsc, F: F });
  drawEqualTicks(ctx);
  if (on) {                                                    /* 台の加速度（左向き） */
    var La = 22 + 5 * q.A, xa = x0 + bw * 0.3; blockArrow(ctx, xa + La, yg - hp * 0.1, -1, 0, La, '台の加速度 A（左向き）', { x: xa + La / 2, y: yg - hp * 0.1 - 20 });   /* 台の下のほう（斜面の力の矢印とぶつからないように） */
  }
  if (!s.rot) {
    var vbx = Vw + vr * ux, vby = vr * uy, vs = Math.hypot(vbx, vby);
    if (vs > 0.02) velAt(ctx, bc[0] + nx * 0.45 * k, bc[1] + ny * 0.45 * k, vbx / vs, vby / vs, vs * 14 * k / 100 + 4, [6, -6]);
    if (Math.abs(Vw) > 0.02) velAt(ctx, x0 + bw * 0.35, yg - 10, -1, 0, Math.abs(Vw) * 14 * k / 100 + 4, [-6, -4]);
  } else if (vr > 0.02) velAt(ctx, bc[0] + nx * 0.85 * k, bc[1] + ny * 0.85 * k, ux, uy, vr * 14 * k / 100 + 4, [6, -6]);   /* 力の矢印と重ならないよう、少し離して */
  var say = s.rot ? (on ? '斜面にそってまっすぐ下りてくる' : '台の上から見ているよ') : (on ? '台は左へ、物体は右下へ動いてる' : 'まだ動いていない');
  speech(ctx, say, s.rot ? hdRot : hdIn);
  if (s.t >= q.t1 - 1e-9) bubble(ctx, '床に着いた！', cx, cy - M23.bs * k - 10, { size: 13, bg: '#dff2ee', border: '#0f8a8a', color: '#0a5c5c' });
}
DEFS.m2s3 = ifBase({
  id: 'm2s3', num: 3, title: '斜め台をすべる物体', mode: 'mode2', V0: 0, TW: 2, noAcc: true, baseRate: 0.5,
  height: function (s, w) { return Math.round(clamp(w * 0.6, 300, 400)); },
  desc: 'なめらかで水平な床の上に、傾角 $\\theta$ のなめらかな斜面をもつ質量 $M$ の三角台を置く。<b>三角台は床の上を自由に動ける</b>。斜面の頂点（高さ 1.4 m）に質量 $m=1.0$ kg の小物体をそっと置くと、小物体はすべり降り、台は反対向きに動き出す。<span class="todo">「▶ スタート」を押し、台と一緒に加速運動する観測者から見ると小物体がどう動くか見よう。台の質量 $M$ も変えてみよう。</span>',
  vars: [{ k: 'M', label: '台の質量 $M$', aria: '台の質量', stops: M23.MST, stopLabels: ['0.1', '0.5', '1', '2', '10'], def: 1, fmt: function (x) { return x + ' kg'; } },
         { k: 'th', label: '傾角 $\\theta$', aria: '傾角', min: 20, max: 60, step: 1, def: 30, dec: 0, unit: '°' }],
  varColsK: [['M'], ['th']],                                     /* 2-2 と同じく、スライダー 2 本を 1 行に */
  afterBuild: function (s) { if (s.varbox) s.varbox.classList.add('two'); alignStops(s); },
  checks: SLOPE_CHECKS,
  tEnd: function (s) { return m23(s).t1; },
  msg: function (s) {
    var q = m23(s);
    if (s.t <= 0) return '小物体は頂点に静止している。「▶ スタート」を押そう。';
    return s.rot ? '台の上から見ると、小物体には $mg$・$N$・慣性力 $mA$（右向き）がはたらき、斜面にそって $a\'=' + f2(q.aRel) + '$ m/s² でまっすぐすべり降りる。' :
      '外から見ると、台は垂直抗力の反作用で左へ $A=' + f2(q.A) + '$ m/s² で加速し、小物体は斜めの直線にそって動く（斜面の向きとは少しちがう）。';
  },
  eqs: function (s) {
    var q = m23(s);
    return {
      in: { h: '外（慣性系）から見る', lines: [{ tag: 'eom', k: '小物体・水平：', t: 'ma_x = N\\sin\\theta' }, { tag: 'eom', k: '小物体・鉛直：', t: 'ma_y = N\\cos\\theta - mg' }, { tag: 'eom', k: '台・水平：', t: 'MA = N\\sin\\theta' }], num: 'いま：' + tex('A = ' + f2(q.A) + ',\\ N = ' + f2(q.N)) },
      rot: { h: '台と一緒に加速運動する観測者（非慣性系）から見る', lines: [{ tag: 'bal', k: '小物体・斜面に垂直：', t: 'N + mA\\sin\\theta - mg\\cos\\theta = 0' }, { tag: 'eom', k: '小物体・斜面にそって：', t: "ma' = mg\\sin\\theta + mA\\cos\\theta" }, { tag: 'bal', k: '台・水平：', t: 'N\\sin\\theta - MA = 0' }], num: 'いま：' + tex("a' = " + f2(q.aRel) + '\\ \\text{m/s}^2'), note: '慣性力 ' + tex('mA') + '（小物体）・' + tex('MA') + '（台）は、台の加速度（左向き）と逆の右向き' } };
  },
  draw: drawM23,
  right: function (s, R) {
    var q = m23(s), SJ = '<span class="subj">小物体</span>', SW = '<span class="subj w">台</span>';
    var h = ifSetup(s, {
      title: '式の主語：小物体（質量 m）と台（質量 M）',
      lead: { in: '外から見ると、小物体は台からの垂直抗力 $N$ と重力 $mg$ を受けて斜め下へ、台は $N$ の反作用を受けて左へ加速する（加速度の大きさ $A$）。小物体の加速度は斜面の向きと一致しないので、このままでは式が立てにくい（「小物体が斜面からはなれない」という条件を別に考える必要がある）。',
              rot: '台と一緒に加速運動する観測者から見ると、台は止まって見え、小物体は<b>斜面にそってまっすぐ</b>すべり降りる。小物体には $mg$・$N$・<b>慣性力 $mA$</b>（右向き）がはたらく。斜面に垂直な向きはつり合い、斜面にそった向きに加速する。台にも慣性力 $MA$（右向き）がはたらき、台は止まって見えるので水平方向の力はつり合う。' },
      rows: [{ dir: SJ + '水平／斜面に垂直', in: ['eom', 'ma_x = N\\sin\\theta'], rot: ['bal', 'N + mA\\sin\\theta - mg\\cos\\theta = 0'] },
             { dir: SJ + '鉛直／斜面にそって', in: ['eom', 'ma_y = N\\cos\\theta - mg'], rot: ['eom', "ma' = mg\\sin\\theta + mA\\cos\\theta"] },
             { dir: SW + '水平', in: ['eom', 'MA = N\\sin\\theta'], rot: ['bal', 'N\\sin\\theta - MA = 0'] }]
    });
    h += '<div class="qcard derive"><p class="qt">台の加速度 A と、台に対する小物体の加速度 a′</p>' +
      '<p>' + SJ + '台の上から見た、斜面に垂直な' + T_BAL + 'から</p><div class="qeq">' + tex('N = m(g\\cos\\theta - A\\sin\\theta)', true) + '</div>' +
      '<p>' + SW + '台の水平方向の式 $MA = N\\sin\\theta$ に入れると</p>' +
      '<div class="qeq">' + tex('A = \\frac{mg\\sin\\theta\\cos\\theta}{M + m\\sin^2\\theta}', true) + '</div>' +
      '<p>' + SJ + '斜面にそった' + T_EOM + ' $ma\' = mg\\sin\\theta + mA\\cos\\theta$ から</p>' +
      '<div class="qeq">' + tex("a' = \\frac{(M+m)g\\sin\\theta}{M + m\\sin^2\\theta}", true) + '</div>' +
      '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('M = ' + q.M + '\\ \\text{kg}:\\ A = ' + f2(q.A) + ',\\ a\' = ' + f2(q.aRel) + ',\\ N = ' + f2(q.N) + '\\ \\text{N}') + '</p>' +
      '<p>$M$ を大きくすると台は動きにくくなり（$A \\to 0$）、$a\' \\to g\\sin\\theta$ ' + '（いまの ' + tex('\\theta') + ' で ' + f2(G * Math.sin(q.th)) + ' m/s²、台を固定したとき）に近づく。$M$ を小さくすると、台は大きく左へ動く。</p></div>';
    R.innerHTML = mathify(h + '<p class="assume">' + tex('m=1.0') + ' kg、' + tex('\\theta=' + s.v.th + '^\\circ') + '、高さ 1.4 m、' + tex('g=9.8') + ' m/s²。θ = 30°、M = 3 kg にすると、conservation-quiz-basic.html（保存則クイズ 基本編）の問7 と同じ設定。</p>');
  }
});

/* ===================== 2-4 電車の中で糸につるされた振り子の周期 ===================== */
var M24 = { TW: 4.6, d0: 9 * Math.PI / 180 };
function m24Opt(s) { return { l: TR2.l, c: 0, th0: pendTheta0(aAt(s, 0)) + M24.d0, m: TR2.m }; }   /* はじめの a のつり合いの位置から 9° ずらして放す */
/* 測った周期：つり合いの角を同じ向きに通る時刻の間かく */
function m24Period(s) {
  var a = s.v.a, gp = Math.hypot(G, a), th0 = pendTheta0(a), l = TR2.l, d = M24.d0, om = 0, th = th0 + d, t = 0, h = 1 / 2000, cross = [];
  var acc = function (x) { return -(gp / l) * Math.sin(x - th0); };
  while (t < 3.2 && cross.length < 3) {
    var p = th - th0; var k1t = om, k1o = acc(th), k2t = om + 0.5 * h * k1o, k2o = acc(th + 0.5 * h * k1t), k3t = om + 0.5 * h * k2o, k3o = acc(th + 0.5 * h * k2t), k4t = om + h * k3o, k4o = acc(th + h * k3t);
    th += h / 6 * (k1t + 2 * k2t + 2 * k3t + k4t); om += h / 6 * (k1o + 2 * k2o + 2 * k3o + k4o); t += h;
    var q = th - th0; if (p > 0 && q <= 0) cross.push(t - h * q / (q - p));
  }
  return cross.length >= 2 ? cross[1] - cross[0] : NaN;
}
function drawM24(s, ctx, W, H) {
  var ps = pendState(s, m24Opt(s));
  train2Scene(s, ctx, W, H, function (g) {
    var k = g.k, a = ps.a, m = TR2.m;
    /* つり合いの位置（糸の向き）を点線で */
    var hx = g.SX(TR2.hookU), hy = g.SY(TR2.hookV), th0 = ps.th0, L = TR2.l * k;
    ctx.save(); ctx.setLineDash([2, 4]); ctx.strokeStyle = COL_RES; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(hx + Math.sin(th0) * (L + 26), hy + Math.cos(th0) * (L + 26)); ctx.stroke(); ctx.restore();
    label(ctx, 'つり合いの位置', hx + Math.sin(th0) * (L + 34) + (th0 < 0 ? -4 : 4), hy + Math.cos(th0) * (L + 34) + 4, { size: 10, color: COL_RES, align: th0 < 0 ? 'right' : 'left' });
    var pd = drawPend(ctx, g, ps.th, th0, {});
    ballShape(ctx, pd.bx, pd.by, pd.br, '#c9d3de');
    if (s.t < 0.35) dropHand(ctx, pd.bx, pd.by, 0.32, clamp(s.t / 0.12, 0, 1), 1 - clamp((s.t - 0.12) / 0.2, 0, 1));
    if (s.ms.showF) {
      var fsc = 9 * k / 100, bx = pd.bx, by = pd.by;
      forceArrow(ctx, bx, by, 0, 1, m * G * fsc, COL.force, 'mg', 'below');
      var ux = hx - bx, uy = hy - by, Lu = Math.hypot(ux, uy) || 1; ux /= Lu; uy /= Lu;
      if (s.t >= 0.12) forceArrow(ctx, bx + ux * pd.br, by + uy * pd.br, ux, uy, ps.S * fsc, COL.hand, 'S', ux > 0 ? 'right' : 'left');
      if (s.rot && Math.abs(a) > 1e-9) {
        forceArrow(ctx, bx, by + 3, a > 0 ? -1 : 1, 0, m * Math.abs(a) * fsc, COL.inert, '慣性力', a > 0 ? 'left' : 'right', 'fict');
        var gx = -a, gy = G, gl = Math.hypot(gx, gy);           /* 合力 mg′（見かけの重力） */
        var ar = arrow(ctx, bx + 4, by + 4, bx + 4 + gx / gl * m * gl * fsc, by + 4 + gy / gl * m * gl * fsc, 'comp', COL_RES, { noShift: true });
        if (ar) label(ctx, "mg′", ar.x2 + (a > 0 ? -14 : 14), ar.y2 + 8, { size: 13, bold: true, color: COL_RES });
      }
    }
    drawEqualTicks(ctx);
    var say = s.rot ? (s.t < 0.15 ? '少しずらして放すよ' : 'つり合いの位置のまわりで振動してる') : (s.t < 0.15 ? '電車は加速してるな' : '振動しながら一緒に加速してる');
    speech(ctx, say, s.rot ? g.hdRot : g.hdIn);
  });
}
DEFS.m2s4 = ifBase({
  id: 'm2s4', num: 4, title: '電車の中で糸につるされた振り子の周期', mode: 'mode2', V0: P.V0T, TW: M24.TW, noRamp: true, baseRate: 0.6,
  height: function (s, w) { return Math.round(clamp(w * 0.62, 300, 420)); },
  desc: '①の状態（電車が一定の加速度 $a$ で走り、糸が角 $\\theta$ だけ傾いて止まっている）から、小球を少しだけずらして静かに放すと、小球はつり合いの位置のまわりで単振動する。<span class="todo">加速度を変えて、振り子の周期 $T$ がどう変わるか確かめよう。</span>',
  init: function (s) { s._pd = null; },
  tInfo: function (s) { var T = m24Period(s); return '周期（測定）' + (isFinite(T) ? f2(T) : '—') + ' s'; },
  msg: function (s) {
    var a = s.v.a, gp = Math.hypot(G, a), T = 2 * Math.PI * Math.sqrt(TR2.l / gp);
    return '見かけの重力加速度 $g\'=\\sqrt{a^2+g^2}=' + f2(gp) + '$ m/s² なので、周期は $T=2\\pi\\sqrt{l/g\'}=' + f2(T) + '$ s。' + (Math.abs(a) < 1e-9 ? '（$a=0$ なら、もとの周期 $2\\pi\\sqrt{l/g}$）' : '加速度が大きいほど周期は短くなる。');
  },
  eqs: function (s) {
    var a = s.v.a, gp = Math.hypot(G, a), T = 2 * Math.PI * Math.sqrt(TR2.l / gp);
    return {
      in: { h: '外（慣性系）から見る', lines: [{ tag: 'eom', k: 'ベクトル：', t: 'm\\vec{\\alpha} = m\\vec{g} + \\vec{S}' }], num: '小球は電車と一緒に加速しながら振動する（外からの式は立てにくい）' },
      rot: { h: '一緒に加速運動する観測者（非慣性系）から見る', lines: [{ tag: '', k: '見かけの重力：', t: "mg' = m\\sqrt{a^2+g^2}" }, { tag: '', k: '周期：', t: "T = 2\\pi\\sqrt{\\frac{l}{g'}}" }], num: 'いま：' + tex('T = ' + f2(T) + '\\ \\text{s}') } };
  },
  draw: drawM24,
  right: function (s, R) {
    var a = s.v.a, gp = Math.hypot(G, a), T = 2 * Math.PI * Math.sqrt(TR2.l / gp), T0 = 2 * Math.PI * Math.sqrt(TR2.l / G), Tm = m24Period(s);
    var h = '<div class="qcard setup ' + (s.rot ? 'rot' : 'in') + '"><p class="qt">' + (s.rot ? '一緒に加速運動する観測者（非慣性系）から見ると' : '外（慣性系）から見ると') + '<span class="now">いまの視点</span></p>' +
      (s.rot ? '<p>電車の中の観測者には、小球に重力 $mg$ と慣性力 $ma$ がいつもはたらいて見える。この 2 つの合力 $mg\' = m\\sqrt{a^2+g^2}$ は、大きさも向きも変わらない<b>見かけの重力</b>。電車の中は、重力加速度が $g\'$ の「傾いた世界」と同じになる。</p>'
        : '<p>外から見ると、小球は電車と一緒に加速しながら、その上で振動している。運動方程式は $m\\vec{\\alpha} = m\\vec{g} + \\vec{S}$（$\\vec{\\alpha}$ は小球の加速度）だが、このままでは周期を求めにくい。<b>電車の中の観測者の立場（慣性力を使う）</b>で考えると、ふつうの単振り子と同じ形になる。</p>') + frameNote(s.rot) + '</div>';
    h += '<div class="qcard derive"><p class="qt">見かけの重力加速度と周期</p>' +
      '<p>電車の中の観測者には、小球に重力 $m\\vec{g}$（下向き）と慣性力 $-m\\vec{a}$（加速度と逆向き）がいつもはたらく。どちらも質量 $m$ に比例するので、まとめて<b>見かけの重力</b> $m\\vec{g}\\,\'$ と考えられる。</p>' +
      '<canvas class="vecc" data-v="g24"></canvas>' +
      '<p>上の図のように、$\\vec{g}$ と $-\\vec{a}$ をつなぐと、<b>見かけの重力加速度</b> $\\vec{g}\\,\' = \\vec{g} + (-\\vec{a})$ が直角三角形の斜辺になる。向きは鉛直から $\\theta$（$\\tan\\theta = a/g$）傾き、大きさは三平方の定理から $g\' = \\sqrt{a^2+g^2}$。振り子は、この見かけの重力の向き（つり合いの位置）を中心に振動する。</p>' +
      '<p>ふつうの単振り子の周期は $T = 2\\pi\\sqrt{l/g}$。電車の中では $g$ を見かけの重力加速度 $g\'$ におきかえればよい。</p>' +
      '<div class="qeq">' + tex("g' = \\sqrt{a^2+g^2}", true) + tex("T = 2\\pi\\sqrt{\\frac{l}{g'}} = 2\\pi\\sqrt{\\frac{l}{\\sqrt{a^2+g^2}}}", true) + '</div>' +
      '<p class="qnow"><span class="qtag now">いまの値</span>' + tex("g' = " + f2(gp) + ',\\ T = 2\\pi\\sqrt{\\frac{0.50}{' + f2(gp) + '}} = ' + f2(T) + '\\ \\text{s}') + '</p>' +
      '<p>図で測った周期：<b>' + (isFinite(Tm) ? f2(Tm) : '—') + ' s</b>（振れ幅 9° で測定）。$a=0$ のときの周期は ' + tex('2\\pi\\sqrt{l/g} = ' + f2(T0)) + ' s。</p>' +
      '<table class="reltab"><thead><tr><th>加速度 a</th><th>g′ [m/s²]</th><th>T [s]</th></tr></thead><tbody>' +
      [0, 5, 9.8].map(function (aa) { var g2 = Math.hypot(G, aa); return '<tr' + (Math.abs(Math.abs(a) - aa) < 1e-9 ? ' class="on"' : '') + '><th>' + (aa ? '±' + aa : '0') + ' m/s²</th><td class="num">' + f2(g2) + '</td><td class="num">' + f2(2 * Math.PI * Math.sqrt(TR2.l / g2)) + '</td></tr>'; }).join('') +
      '</tbody></table></div>';
    R.innerHTML = mathify(h + '<p class="assume">' + tex('l=0.50') + ' m、' + tex('m=0.50') + ' kg、' + tex('g=9.8') + ' m/s²。つり合いの位置から 9° ずらして放した（振れ幅が小さいとき単振動とみなせる）。</p>');
    var gs = R.querySelector('canvas.vecc[data-v="g24"]');
    if (gs) vecDiagram(gs, { h: 190, title: '見かけの重力加速度（ベクトル図）', vecs: [{ x: 0, y: -G, col: COL.force, lab: 'g' }].concat(Math.abs(a) > 1e-9 ? [{ x: -a, y: 0, col: COL.inert, lab: '−a', kind: 'fict' }] : []),
      sum: Math.abs(a) > 1e-9 ? { col: COL_RES, lab: "g′" } : null, closed: Math.abs(a) > 1e-9 ? "g′ = √(a² + g²) = " + f2(gp) + ' m/s²' : 'a = 0 なら g′ = g = 9.8 m/s²' });
  }
});
