/* =========================================================================
   30_physics.js … 物理だけ（描画を混ぜない・純粋な関数）
   ・観測者（電車・エレベーター）は一定の加速度 a で動く。a はスライダーの値（−9.8・−5・0・5・9.8 m/s²）。
     a ≠ 0 のときは止まった状態から動き出す（行って戻る動きはしない）。a = 0 は「等速」（v0）、「静止」なら v0 = 0。
   ・正の向き：電車は右向き、エレベーターは上向き。
   ========================================================================= */
'use strict';
var G = 9.8;
var TAU = Math.PI * 2;
function clamp(x, a, b) { return x < a ? a : (x > b ? b : x); }
function roundTo(x, step) { return Math.round(x / step) * step; }

var P = {
  TW: 1.0,                 /* 1 回の再生で見る時間［s］（電車） */
  V0T: 1.0,                /* 電車の「等速」の速さ［m/s］ */
  V0E: 0.5,                /* エレベーターの「等速」の速さ［m/s］（上向き） */
  AST: [-9.8, -5, 0, 5, 9.8],  /* 加速度の目盛り［m/s²］（2026-10-11 千葉さん） */
  mP: 50,                  /* 人の質量［kg］ */
  /* 一定の加速度の運動：変位と速度 */
  x: function (v0, a, t) { return v0 * t + 0.5 * a * t * t; },
  v: function (v0, a, t) { return v0 + a * t; },
  /* 0〜T の間の変位の最小・最大（折り返しも含む） */
  range: function (v0, a, T) {
    var xs = [0, P.x(v0, a, T)];
    if (Math.abs(a) > 1e-12) { var ts = -v0 / a; if (ts > 0 && ts < T) xs.push(P.x(v0, a, ts)); }
    return { lo: Math.min.apply(null, xs), hi: Math.max.apply(null, xs) };
  },
  /* 1-1 電車：人が座席から受ける水平な力 F（右向き正）。慣性系：ma = F ／ 非慣性系：F − ma = 0 */
  trainF: function (m, a) { return m * a; },
  /* エレベーターの床から人が受ける垂直抗力（上向き正）。慣性系：ma = N − mg ／ 非慣性系：N − mg − ma = 0 */
  elevN: function (m, a) { return m * (G + a); },

  /* 1-2 糸でつるした小球（m、床からの高さ h） */
  ball: { m: 0.50, h: 1.0, r: 0.07, Lc: 2.3 },        /* Lc：エレベーターの中の高さ */
  ballS: function (m, a) { return m * (G + a); },     /* 張力 S（慣性系：ma = S − mg ／ 非慣性系：S − mg − ma = 0） */
  /* 糸が切れてから床に着くまで（エレベーターの中で見ると、見かけの重力加速度 g + a で落ちる） */
  fallTime: function (h, a) { return (G + a) > 1e-9 ? Math.sqrt(2 * h / (G + a)) : Infinity; },   /* a = −g なら落ちない（無重力） */
  /* 糸を切ったあと：小球のエレベーターに対する高さ（床から）。tau = 切ってからの時間 */
  ballRel: function (h, a, tau) { return Math.max(0, h - 0.5 * (G + a) * tau * tau); },

  /* 1-3 台はかり（おもり 10 kg） */
  scale: { m: 10 },
  scaleN: function (m, a) { return m * (G + a); },    /* はかりの針が示す力＝おもりが受ける垂直抗力（作用反作用） */
  scaleKg: function (m, a) { return m * (G + a) / G; }
};
