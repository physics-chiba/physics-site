/* =========================================================================
   53_mode3.js … モード3「円運動のときの慣性力＝遠心力」
   構想メモ 8 ページ：circular-motion.html?rot=1 へのリンク。ヒーローのように左右に
   「外（慣性系）から見る｜一緒に加速運動する観測者（非慣性系）から見る」を並べ、円運動のようすを描く。
   回転台の上で、ばねの先につけた小球が半径 r の等速円運動をする（構想メモの絵と同じ）。
   ========================================================================= */
'use strict';
var M31 = { m: 0.5, r: 0.4, WST: [1, 2, 3] };   /* 質量［kg］・半径［m］・角速度の選択［rad/s］ */
function m31F(w) { return M31.m * M31.r * w * w; }

/* 回転台を斜め上から見た図。(cx, cy)＝台の中心、R＝台の半径［px］、sq＝たてのつぶれ（見る角度） */
function m31Panel(s, ctx, x0, y0, w, h, rot) {
  var om = s.v.w, t = s.t, sq = 0.42;
  var R = Math.min(w * 0.36, (h - 120) / (2 * sq) * 0.9, 190), cx = x0 + w / 2, cy = y0 + 58 + R * sq + 30;
  var P = function (X, Y) { return [cx + X, cy + Y * sq]; };            /* 台の面の上の点（X 右、Y 手前） */
  var th = rot ? 0 : om * t;                                            /* 台の回転角（外から見たとき） */
  var phB = th, phO = th + Math.PI;                                     /* 小球・台の上の観測者の位置の角 */
  var rr = R * 0.78, ro = R * 0.62;
  /* 見出し */
  label(ctx, rot ? '一緒に回転する観測者（非慣性系）から見る' : '外（慣性系）から見る', cx, y0 + 16, { size: 13, bold: true, color: rot ? '#1d4f86' : COL.ink });
  /* 地面の外の観測者：外から見るときは止まっている。一緒に回転して見ると、反対向きにまわっていく */
  var phE = rot ? Math.PI - om * t : Math.PI, RE = R * 1.22;   /* 外から見るときは台の左の地面に立つ */
  var E = P(RE * Math.cos(phE), RE * Math.sin(phE));
  var drawOuter = function () { var hd = observer(ctx, E[0], E[1], 0, -1, '', !rot, R * 0.42); label(ctx, NAME_IN + (rot ? '' : '（いまの視点）'), E[0], E[1] + 13, { size: rot ? 10 : 11, bold: !rot, color: rot ? '#9aa3ac' : COL.vel }); return hd; };
  var behind = Math.sin(phE) < 0, hdOut = null;
  if (behind) hdOut = drawOuter();
  /* 台（側面と上の面） */
  ctx.save();
  ctx.fillStyle = '#e9e4da'; ctx.strokeStyle = COL.ink; ctx.lineWidth = 1.6;
  ctx.beginPath(); ctx.ellipse(cx, cy + 12, R, R * sq, 0, 0, Math.PI); ctx.lineTo(cx - R, cy); ctx.ellipse(cx, cy, R, R * sq, 0, Math.PI, 0, true); ctx.closePath(); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.ellipse(cx, cy, R, R * sq, 0, 0, TAU); ctx.fillStyle = '#f7f4ee'; ctx.fill(); ctx.stroke();
  /* 台の目じるし（回っているのがわかるように 4 本の線） */
  ctx.strokeStyle = 'rgba(43,50,60,.16)'; ctx.lineWidth = 1;
  for (var i = 0; i < 4; i++) { var q = th + i * Math.PI / 2 + Math.PI / 4, A = P(R * 0.2 * Math.cos(q), R * 0.2 * Math.sin(q)), B = P(R * 0.96 * Math.cos(q), R * 0.96 * Math.sin(q)); ctx.beginPath(); ctx.moveTo(A[0], A[1]); ctx.lineTo(B[0], B[1]); ctx.stroke(); }
  ctx.restore();
  /* 回転の向き（外から見るときだけ、台のふちに回る矢印） */
  if (!rot) { spinArrow(ctx, cx, cy, R * 1.07, R * sq * 1.07 + 4, 0.15 * Math.PI, 0.55 * Math.PI, COL.ink2, 1.6); sym(ctx, 'ω', cx + R * 0.55, cy + R * sq + 26, { size: 15, color: COL.ink2 }); }
  /* 中心の軸・ばね・小球 */
  var C0 = P(0, 0), Bp = P(rr * Math.cos(phB), rr * Math.sin(phB));
  ctx.save(); ctx.fillStyle = COL.ink2; ctx.beginPath(); ctx.arc(C0[0], C0[1], 4, 0, TAU); ctx.fill(); ctx.restore();
  m31Spring(ctx, C0, Bp, 9);
  var br = Math.max(7, R * 0.07);
  /* 台の上の観測者（小球の反対がわ） */
  var Op = P(ro * Math.cos(phO), ro * Math.sin(phO));
  var drawInner = function () { return observer(ctx, Op[0], Op[1], 0, -1, '', rot, R * 0.42); };
  var innerBack = Math.sin(phO) < 0, hdIn = null;
  if (innerBack) hdIn = drawInner();
  ballShape(ctx, Bp[0], Bp[1] - br * 0.6, br, '#c9d3de');
  sym(ctx, 'm', Bp[0] + br + 4, Bp[1] - br * 1.8, { size: 14, color: COL.ink2, align: 'left' });
  var bx = Bp[0], by = Bp[1] - br * 0.6;
  /* 半径 r（中心から小球まで、点線） */
  var u = [Bp[0] - C0[0], Bp[1] - C0[1]], Lu = Math.hypot(u[0], u[1]) || 1; u = [u[0] / Lu, u[1] / Lu];
  /* 力・速度・加速度（台の面の上の向きを、そのまま斜めから見た向きで描く） */
  var F = m31F(om), fsc = R * 0.62 / m31F(M31.WST[M31.WST.length - 1]) * 1.0, Lf = Math.max(14, F * fsc);
  if (s.ms.showF) {
    forceArrow(ctx, bx - u[0] * br, by - u[1] * br, -u[0], -u[1], Lf, COL.hand, '', '');
    label(ctx, '弾性力', bx - u[0] * (br + Lf + 22), by - u[1] * (br + Lf + 6) - 10, { size: 12, bold: true, color: COL.hand });
    if (rot) { forceArrow(ctx, bx + u[0] * br, by + u[1] * br, u[0], u[1], Lf, COL.inert, '', '', 'fict');
      label(ctx, '遠心力', bx + u[0] * (br + Lf + 26), by + u[1] * (br + Lf + 8) - 10, { size: 12.5, bold: true, color: '#b35f0c' }); }
    drawEqualTicks(ctx);
  }
  if (!rot) {
    /* 速度（円の接線の向き）・加速度（中心向き） */
    var tx = -Math.sin(phB), ty = Math.cos(phB) * sq, Lt = Math.hypot(tx, ty) || 1;
    velAt(ctx, bx + tx / Lt * 26 - u[1] * 0, by + ty / Lt * 26 - 18, tx / Lt, ty / Lt, 18 + om * 12, [0, -2]);
    var qx = -u[1] * 20, qy = u[0] * 20;                         /* 弾性力の矢印と重ならないよう、横にずらす */
    var ar = arrow(ctx, bx + qx, by + qy, bx + qx - u[0] * (16 + 9 * om), by + qy - u[1] * (16 + 9 * om), 'acc');
    if (ar) label(ctx, '小球の加速度 a（中心向き）', ar.x2 - u[0] * 10 + qx * 0.6, ar.y2 - u[1] * 10 + qy * 0.6 + 12, { size: 11.5, bold: true, color: COL.acc });
  }
  if (!innerBack) hdIn = drawInner();
  if (!behind) hdOut = drawOuter();
  label(ctx, '台と' + NAME_ROT.replace('加速する', '回転する') + (rot ? '（いまの視点）' : ''), cx, cy + R * sq + 46, { size: rot ? 11 : 10, bold: rot, color: rot ? COL.vel : '#9aa3ac' });
  /* セリフ */
  if (rot) speech(ctx, s.t > 0.05 ? '小球は止まって見える！' : '台の上から見ているよ', hdIn);
  else speech(ctx, s.t > 0.05 ? '小球は円運動してる' : '台はまだ止まってる', hdOut);
  /* 回転の向き（一緒に回転して見ると、外の観測者が逆向きにまわる） */
  if (rot && s.t > 0.05) label(ctx, '外の観測者が反対向きにまわっていく', cx, y0 + 36, { size: 10.5, color: COL.sub });
}
/* ばね（ジグザグ） */
function m31Spring(ctx, A, B, n) {
  var dx = B[0] - A[0], dy = B[1] - A[1], L = Math.hypot(dx, dy) || 1, ux = dx / L, uy = dy / L, px = -uy, py = ux;
  ctx.save(); ctx.strokeStyle = '#6d5a49'; ctx.lineWidth = 1.6; ctx.lineJoin = 'round'; ctx.beginPath(); ctx.moveTo(A[0], A[1]);
  var a0 = 0.12, a1 = 0.88; ctx.lineTo(A[0] + ux * L * a0, A[1] + uy * L * a0);
  for (var i = 1; i < n * 2; i++) { var f = a0 + (a1 - a0) * i / (n * 2), sg = i % 2 ? 1 : -1; ctx.lineTo(A[0] + ux * L * f + px * 5 * sg, A[1] + uy * L * f + py * 5 * sg); }
  ctx.lineTo(A[0] + ux * L * a1, A[1] + uy * L * a1); ctx.lineTo(B[0], B[1]); ctx.stroke(); ctx.restore();
}
function drawM31(s, ctx, W, H) {
  var two = false;                                                /* 左の列の幅では小さくなるので、上下に並べる（上：外から、下：一緒に回転して） */
  if (two) {
    m31Panel(s, ctx, 0, 0, W / 2, H, false);
    ctx.save(); ctx.strokeStyle = 'rgba(43,50,60,.15)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(W / 2, 10); ctx.lineTo(W / 2, H - 10); ctx.stroke(); ctx.restore();
    m31Panel(s, ctx, W / 2, 0, W / 2, H, true);
  } else {
    m31Panel(s, ctx, 0, 0, W, H / 2, false);
    ctx.save(); ctx.strokeStyle = 'rgba(43,50,60,.15)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(10, H / 2); ctx.lineTo(W - 10, H / 2); ctx.stroke(); ctx.restore();
    m31Panel(s, ctx, 0, H / 2, W, H / 2, true);
  }
}
DEFS.m3s1 = {
  id: 'm3s1', num: 1, title: '回転台の上の小球（外から見る・一緒に回転して見る）', mode: 'mode3', baseRate: 0.6, strobe: false, belowCanvas: true, showFBtn: true,
  height: function (s, w) { return Math.round(clamp(w * 1.1, 480, 680)); },
  afterBuild: function (s) { alignStops(s); },
  desc: '水平な回転台の中心に、ばねの一方のはしをとめ、もう一方のはしに小球（質量 $m=0.50$ kg）をつける。台を一定の角速度 $\\omega$ で回すと、小球は半径 $r=0.40$ m の等速円運動をする。<span class="todo">「▶ スタート」を押し、外から見たとき（上）と、台と一緒に回転する観測者から見たとき（下）をくらべよう。</span>',
  varCols: [['w']],
  vars: [{ k: 'w', label: '角速度 $\\omega$', aria: '角速度', stops: M31.WST, stopLabels: ['1', '2', '3'], def: 2, fmt: function (x) { return x + ' rad/s'; } }],
  tEnd: function () { return 12; },
  msg: function (s) {
    var F = m31F(s.v.w);
    return '外から見ると、小球は中心向きの加速度 $a = r\\omega^2$ で円運動していて、ばねの弾性力 ' + f2(F) + ' N が向心力になっている（' + T_EOM + '）。台と一緒に回転する観測者から見ると、小球は止まっていて、弾性力と<b>遠心力</b>（大きさ $mr\\omega^2$、中心から外向き）がつり合っている（' + T_BAL + '）。';
  },
  draw: drawM31,
  right: function (s, R) {
    var om = s.v.w, m = M31.m, r = M31.r, F = m31F(om), v = r * om;
    var h = '<div class="qcard derive"><p class="qt">遠心力の導出</p>' +
      '<p><b>①</b> 直線運動に限らず、<b>加速度運動している観測者</b>は、<u>加速度と逆向き</u>、<u>大きさ $ma$</u> の見かけの力（慣性力）を感じる。</p>' +
      '<p style="text-align:center;margin:.2em 0">⇓</p>' +
      '<p><b>②</b> 円運動では、中心に向かって加速度</p><div class="qeq">' + tex('a = \\frac{v^2}{r} \\quad (= r\\omega^2)', true) + '</div><p>が生じている。</p>' +
      '<p style="text-align:center;margin:.2em 0">⇓</p>' +
      '<p><b>③</b> よって、円運動している観測者が感じる見かけの力（<b>遠心力</b>）は</p>' +
      '<table class="cmpt"><tbody><tr><th>向き</th><td>中心から外側へ（加速度 $a$ と逆向き）</td></tr>' +
      '<tr><th>大きさ</th><td>' + tex('m\\frac{v^2}{r}\\ \\ (= mr\\omega^2)') + '（$ma$ に $a = \\dfrac{v^2}{r}$ を代入）</td></tr></tbody></table>' +
      '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('v = r\\omega = ' + f2(v) + '\\ \\text{m/s},\\quad mr\\omega^2 = ' + f2(m) + '\\times' + f2(r) + '\\times' + om + '^2 = ' + f2(F) + '\\ \\text{N}') + '</p></div>';
    h += '<div class="qcard setup in"><p class="qt">外（慣性系）から見ると</p><p>小球は等速円運動をしている。中心向きの加速度 $r\\omega^2$ があるので、中心向き（半径方向）に' + T_EOM + 'を立てる。ばねの弾性力 $F$ が向心力。</p>' +
      '<div class="dirs"><div class="dirrow"><span class="dirlab">中心向き</span>' + eqRow('eom', 'mr\\omega^2 = F') + '</div></div>' +
      '<p class="qnote">外（慣性系）から見ると、<b>遠心力は存在しない</b>。</p></div>';
    h += '<div class="qcard setup rot"><p class="qt">台と一緒に回転する観測者（非慣性系）から見ると</p><p>小球は止まって見える。弾性力 $F$（中心向き）と遠心力 $mr\\omega^2$（外向き）がつり合っている。</p>' +
      '<div class="dirs"><div class="dirrow"><span class="dirlab">中心向き</span>' + eqRow('bal', 'F - mr\\omega^2 = 0') + '</div></div>' +
      '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('F = mr\\omega^2 = ' + f2(F) + '\\ \\text{N}') + '（どちらの観測者でも同じ）</p>' +
      '<p class="qnote">遠心力は、円運動する観測者だけが感じる<b>見かけの力</b>（慣性力）。</p></div>';
    h += '<div class="qcard intro"><p class="qt">もっとくわしく</p><p>円運動と遠心力は、「円運動」のページで、ひもの張力・角速度・半径を変えながら確かめられる。</p>' +
      '<p><a class="b linkb" href="circular-motion.html?rot=1">円運動のページへ（一緒に回転する観測者から見る）→</a></p></div>';
    R.innerHTML = mathify(h + '<p class="assume">' + tex('m=0.50') + ' kg、' + tex('r=0.40') + ' m。台の面はなめらかで、重力と垂直抗力はつり合っている（図では省略）。</p>');
  }
};
