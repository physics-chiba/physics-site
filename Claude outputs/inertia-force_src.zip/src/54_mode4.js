/* =========================================================================
   54_mode4.js … モード4「入試物理（2016 東北大）」
   斜面をもつ台 A の上の小球（B・C）。台に固定された平板が、小球が点 O より下へ動くのを止める。
   4-1＝問(1)：A を外力で一定の加速度 a_A で動かす
   4-2＝問(2)：A をばねにつなぎ、L だけ縮めて放す（B の影響は無視できる）
   4-3＝問(3)：B を質量 m_C の C にかえる（θ = 30°、C の影響を無視しない）。O に戻って平板と衝突
   ・向き：A の加速度・速度は「左向きが正」（問題と同じ）。x 軸は O から頂点 P へ（斜面にそって上向き）、y 軸は斜面に垂直で上向き。
   ・問題文と解答は、セクションの見出しの右のボタンから（画像の重ね窓）。右の列の「解き方と答え」は、開くまで見せない。
   ========================================================================= */
'use strict';
var M4 = { mA: 1.0, k: 49, mB: 0.2, mC: 0.5, Lb: 0.9, o0: 0.07, Ls: 0.62, H2: 2000 };   /* Lb：台の底の長さ［m］、o0：左のかどから点 O まで、Ls：ばねの自然の長さ */
var OBS_A = '物体 A と一緒に運動する<br>観測者（非慣性系）から見る';
var NAME_A = 'A と一緒に運動する観測者';
function m4Th(s) { return (s.v.th === undefined ? 30 : s.v.th) * Math.PI / 180; }
function m4Om() { return Math.sqrt(M4.k / M4.mA); }

/* ---------- 小球（B）の動き：A の加速度が分かっているとき（問(1)(2)） ----------
   A に固定した座標：ξ＝O から斜面にそって上向き、η＝斜面に垂直で外向き。
   A の加速度 a（左向き正）なら、慣性力は右向き。小球が受ける見かけの加速度は
   a_ξ = a cosθ − g sinθ、a_η = −a sinθ − g cosθ。
   st：0＝平板に当たって止まっている／1＝斜面の上を滑る／2＝斜面から離れて飛ぶ／3＝頂点 P に着いた */
function m4PathB(s, key, th, aOf, tMax) {
  var C = s._p4;
  if (C && C.key === key) return C;
  var c = Math.cos(th), sn = Math.sin(th), h = 1 / M4.H2, xiMax = M4.Lb / c - M4.o0 - 0.12;
  var xi = 0, eta = 0, vx = 0, ve = 0, st = 0, t = 0, arr = [], left = null, top = null, start = null;
  while (t <= tMax + 1e-9) {
    var a = aOf(t), ax = a * c - G * sn, ae = -a * sn - G * c;
    if (st === 0) { if (ae > 0) st = 2; else if (ax > 0) { st = 1; if (start === null) start = t; } }
    else if (st === 1) { if (ae > 0) { st = 2; if (left === null) left = t; } }
    else if (st === 3) { if (ax < 0) st = 1; }
    var N = (st === 0 || st === 1) ? M4.mB * -ae : 0, R = (st === 0 && ax < 0) ? M4.mB * -ax : 0;
    arr.push([xi, eta, st, a, N, R, vx]);
    if (st === 1) { vx += ax * h; xi += vx * h; if (xi <= 0) { xi = 0; vx = 0; st = 0; } else if (xi >= xiMax) { xi = xiMax; vx = 0; st = 3; if (top === null) top = t; } }
    else if (st === 2) {
      vx += ax * h; ve += ae * h; xi += vx * h; eta += ve * h;
      if (xi < 0) { xi = 0; vx = 0; }
      if (eta <= 0) { eta = 0; ve = 0; st = xi <= 0 ? 0 : 1; }
    }
    t += h;
  }
  C = s._p4 = { key: key, arr: arr, left: left, top: top, start: start, xiMax: xiMax };
  return C;
}
function m4At(C, t) { var i = clamp(Math.round(t * M4.H2), 0, C.arr.length - 1), q = C.arr[i]; return { xi: q[0], eta: q[1], st: q[2], a: q[3], N: q[4], R: q[5], vx: q[6] }; }

/* ---------- 舞台：床・台 A・平板・小球・（ばね・壁）・観測者 ----------
   o.u＝A の左向きの変位［m］（ばねが自然の長さのとき 0）、o.spring＝ばねと壁を描くか、o.push＝外力の手を描くか */
function m4Scene(s, ctx, W, H, o) {
  var th = o.th, c = Math.cos(th), sn = Math.sin(th), Hm = M4.Lb * Math.tan(th);
  s._nar = !s._snap && W < 480;                                     /* スマホの幅：図が小さいので、長い文字は省く（2026-10-12） */
  var span = o.spring ? 2.85 : 2.1, k = Math.min(W / span, (H - 96) / (Hm + 0.62)), yg = H - 40;   /* ばねと壁がないとき（4-1）は、台を大きく描く */
  var base = (o.spring ? 0.62 : 0.35) * k;                                            /* u = 0 のときの A の左のかど */
  var u = o.u, xA, sh;
  if (s.rot) { xA = base; sh = u * k; }                            /* 一緒に運動して見ると、A は止まって、床と壁が動く */
  else if (o.wrap) { var hw = 2.7 * Math.min(0.28 * k, 36) + 10, Pw = W + M4.Lb * k + hw; xA = wrapX(base - u * k + M4.Lb * k, Pw) - M4.Lb * k; sh = 0; }   /* 外から見て、どこまでも加速するとき（4-1）は、左から出きったらすぐ右から入る（見えない時間を短く。2026-10-11） */
  else { xA = base - u * k; sh = 0; }
  var xR = xA + M4.Lb * k, yt = yg - Hm * k;
  if (!s._snap) posNote(ctx, W, '左向き（A の加速度・速度）', 'right');   /* コマ図（s._snap）では、吹き出しと正の向きの文字は描かない */
  /* 床（ずれる） */
  groundPosts(ctx, W, yg, sh, 0.5 * k);
  groundShift(ctx, 0, W, yg, sh);
  /* 壁とばね（4-2・4-3） */
  var xW = base + (M4.Lb + M4.Ls) * k + sh;
  if (o.spring) {
    ctx.save(); ctx.fillStyle = '#e9e4da'; ctx.strokeStyle = COL.ink; ctx.lineWidth = 1.6; ctx.fillRect(xW, yg - 0.55 * k, 0.12 * k, 0.55 * k); ctx.strokeRect(xW, yg - 0.55 * k, 0.12 * k, 0.55 * k);
    ctx.strokeStyle = '#a9a193'; ctx.lineWidth = 1; for (var hy = yg - 0.55 * k; hy < yg; hy += 7) { ctx.beginPath(); ctx.moveTo(xW + 0.12 * k, hy); ctx.lineTo(xW + 0.12 * k + 6, hy + 6); ctx.stroke(); }
    ctx.restore();
    var ys = yg - Math.min(0.2, Hm * 0.35) * k;
    m31Spring(ctx, [xR, ys], [xW, ys], 11);
    sym(ctx, 'k', (xR + xW) / 2, ys - 16, { size: 15, color: COL.ink2 });
  }
  /* 外の観測者（床の上・右のほう） */
  var ox = (o.spring ? xW + 0.38 * k : base + (M4.Lb + 0.75) * k + sh), hdIn = null;
  if (s._snap) { }                                                 /* 重要な場面の流れ（コマ図）には外の観測者は描かない（2026-10-12 千葉さん） */
  else if (ox > -20 && ox < W + 20) hdIn = observer(ctx, ox, yg, 0, -1, NAME_IN, !s.rot, Math.min(0.95 * k, 80));   /* 台を大きく描くときも、人は大きくしすぎない */
  else offMarker(ctx, W, H, ox, yg - 0.5 * k, NAME_IN, !s.rot);
  /* 台 A */
  ctx.save(); ctx.beginPath(); ctx.moveTo(xA, yg); ctx.lineTo(xR, yg); ctx.lineTo(xR, yt); ctx.closePath();
  ctx.fillStyle = '#f4f2ec'; ctx.fill(); ctx.strokeStyle = COL.ink; ctx.lineWidth = 2.2; ctx.stroke(); ctx.restore();
  sym(ctx, 'A', xR - 14, yg - Math.min(Hm * k * 0.09, 12), { size: 17, color: COL.ink2 });   /* 「A の加速度」の文字と重ならないよう低めに */
  angArc(ctx, xA, yg, 0.2 * k, -th, 0, COL.ink2);
  sym(ctx, 'θ', xA + 0.27 * k * Math.cos(th / 2), yg - 0.27 * k * Math.sin(th / 2), { size: 14, color: COL.ink2 });
  label(ctx, 'P', xR - 12, yt - 6, { size: 13, bold: true, color: COL.ink2 });
  /* 台の上の観測者（P の右の面から板を出し、つっかえ棒で支える：2-2・2-3 と同じ形） */
  var hdRot = deckObserver(ctx, xR, yt, 1, k, s.rot, Math.min(0.4 * k, 56));
  if (!s._snap) label(ctx, NAME_A + (s.rot ? '（いまの視点）' : ''), xA + 4, yg + 22, { align: 'left', size: s.rot ? 11.5 : 10.5, bold: s.rot, color: s.rot ? COL.vel : '#9aa3ac' });
  /* 外力（4-1）：右の面を左向きに押す */
  if (o.push) {
    var py = yg - Math.min(0.22, Hm * 0.4) * k;
    ctx.save(); ctx.translate(xR - 0.3 * Math.min(0.28 * k, 36), py); ctx.scale(-1, 1); pushHand(ctx, 0, 0, Math.min(0.28 * k, 36), false);   /* 指先を台に少し重ねて、押さえているように見せる（2026-10-12 千葉さん） */   /* 手は 2-2 と同じくらいの大きさに */ ctx.restore();
    label(ctx, '外力', xR + 0.42 * k, py - 0.22 * k, { size: 12, bold: true, color: '#6d5a49' });
  }
  /* 外力（4-2・4-3）：スタートの前は、手が A の左はしを右へ押して、台ごとばねを L だけ縮めている。スタートで手が離れる（2026-10-11 千葉さん） */
  if (o.hold) {
    var hs = Math.min(0.28 * k, 30), hb = (s._nar ? 0.8 : 0.66) * Hm * k, hy = yg - hb - 0.45 * hs;      /* 斜面の上のほうを、水平に右へ押す（下の小球・平板とぶつからないように） */
    pushHand(ctx, xA + (hb + 0.45 * hs) / Math.tan(th) + 0.3 * hs, hy, hs, false);   /* 指先を斜面に重ねる（台を押さえているように見せる。2026-10-12 千葉さん） */
    label(ctx, s._nar ? '外力' : '外力で押さえている', xA + hb / Math.tan(th) - 1.6 * hs, hy - 0.85 * hs, { size: 12, bold: true, color: '#6d5a49' });
  }
  /* 点 O と平板（斜面に垂直） */
  var dx = c, dy = -sn, nx = -sn, ny = -c;                         /* d：斜面にそって上向き、n：斜面に垂直で外向き（画面の向き） */
  var Ox = xA + dx * M4.o0 * k, Oy = yg + dy * M4.o0 * k;
  ctx.save(); ctx.strokeStyle = '#3f4a54'; ctx.lineWidth = 3.2; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(Ox, Oy); ctx.lineTo(Ox + nx * 0.14 * k, Oy + ny * 0.14 * k); ctx.stroke(); ctx.restore();
  label(ctx, 'O', Ox + 2, Oy + 12, { size: 12, bold: true, color: COL.ink2 });
  if (!s._snap && !s._nar) label(ctx, '平板', Ox + nx * 0.14 * k - 8, Oy + ny * 0.14 * k - 9, { size: 10.5, color: COL.sub, align: 'right' });
  if (s._snap) s._g = { k: k, xA: xA, xR: xR, yg: yg, yt: yt, spring: !!o.spring };   /* コマ図で切り取る範囲を決めるため */
  var g = { k: k, xA: xA, xR: xR, yg: yg, yt: yt, Ox: Ox, Oy: Oy, d: [dx, dy], n: [nx, ny], th: th, hdIn: hdIn, hdRot: hdRot, Hm: Hm,
    rb: Math.max(7, 0.045 * k),
    ball: function (xi, eta) { var r = this.rb; return [Ox + dx * (xi * k + r) + nx * (eta * k + r), Oy + dy * (xi * k + r) + ny * (eta * k + r)]; } };
  /* A の加速度（左向き正）と速度 */
  if (o.a !== undefined && Math.abs(o.a) > 1e-6) {
    var dir = o.a > 0 ? -1 : 1, La = 18 + 2.4 * Math.abs(o.a);
    var ay = yg - Hm * k * 0.24, ax = xR - 10 - La / 2;              /* 台の右のほう（左下のかどは小球の力と慣性力の文字でこみあうので。2026-10-12） */
    blockArrow(ctx, ax - dir * La / 2, ay, dir, 0, La, '', null);
    if (!s._snap && !s._nar) { var lxs = xR - 8, ly1 = ay - 40;               /* 「A の加速度 a_A（左向き）」は台の右のほうに 2 行で（左下のかどは小球の力でこみあうので。2026-10-11） */
    label(ctx, 'A の加速度', lxs, ly1, { size: 12, bold: true, color: '#9c4e06', align: 'right' });   /* 右寄せで 2 行：「A の加速度」「a_A（左向き）」 */
    var lb2 = label(ctx, o.a > 0 ? '（左向き）' : '（右向き）', lxs, ly1 + 16, { size: 12, bold: true, color: '#9c4e06', align: 'right' });
    sym(ctx, 'a', lb2.x - 2, ly1 + 16, { size: 15, color: '#9c4e06', sub: 'A', align: 'right' }); }   /* コマ図では矢印だけ（小さい図で文字が重ならないように） */
  }
  if (!s.rot && o.v !== undefined && Math.abs(o.v) > 0.02) velAt(ctx, xA + M4.Lb * k * 0.55, yg - 12, o.v > 0 ? -1 : 1, 0, Math.min(M4.Lb * k * 0.6, Math.abs(o.v) * 0.25 * k + 6), [0, -2]);
  return g;
}
/* m_B g のような記号（斜体の m＋立体の添え字＋斜体の g） */
function m4Sym(ctx, x, y, a, sub, b, col) {
  var w = sym(ctx, a, x - 6, y, { size: 15, color: col, sub: sub, align: 'right' });
  sym(ctx, b, x - 4, y, { size: 15, color: col, align: 'left' });
  void w;
}
/* 手を放す前：ばねが自然の長さより L だけ縮んでいることを、A の右の面の下に寸法で示す */
function m4Ldim(ctx, g, L, snap) {
  var y = g.yg + 12, x1 = g.xR - L * g.k;
  dimLine(ctx, x1, y, g.xR, y, COL.ink2); sym(ctx, 'L', (x1 + g.xR) / 2, y + 12, { size: 14, color: COL.ink2 });
  if (!snap) label(ctx, '自然の長さの位置から', x1 - 4, y, { size: 10, color: COL.sub, align: 'right' });
}
/* 小球にはたらく力（重力・垂直抗力・平板からの力・慣性力）と、合力 F の x・y 成分 */
function m4Forces(s, ctx, g, P, m, a, N, R) {
  var b = P, dx = g.d[0], dy = g.d[1], nx = g.n[0], ny = g.n[1];
  var fsc = 30 * g.k / 200 * (0.2 / m);                             /* 質量がちがっても矢印の長さがそろうように */
  if (s.ms.showF) {
    var ag = forceArrow(ctx, b[0], b[1], 0, 1, m * G * fsc, COL.force, '', '');
    if (ag) m4Sym(ctx, ag.x2, ag.y2 + 13, 'm', m === M4.mC ? 'C' : 'B', 'g', COL.force);
    if (N > 1e-6) forceArrow(ctx, b[0] - nx * g.rb, b[1] - ny * g.rb, nx, ny, N * fsc, COL.norm, 'N', 'right');
    if (R > 1e-6) { var ar0 = forceArrow(ctx, b[0] - dx * g.rb, b[1] - dy * g.rb, dx, dy, R * fsc, '#0f8a8a', '', '');   /* 平板からの力：矢印のとなりに名前を書く（2026-10-11 千葉さん） */
      if (ar0) { ctx.save(); ctx.translate(ar0.x2 + dx * 6 + nx * 10, ar0.y2 + dy * 6 + ny * 10); ctx.rotate(-g.th);   /* 斜面にそって、矢印の先の続きに書く（下の慣性力の文字と重ならないように） */
        label(ctx, (s._snap || s._nar) ? '平板から' : '平板からの力', 0, 0, { size: (s._snap || s._nar) ? 10.5 : 12, bold: true, color: '#0a6f6f', align: 'left' }); ctx.restore(); } }
    if (s.rot && Math.abs(a) > 1e-6) { var arI = forceArrow(ctx, b[0], b[1] + 2, a > 0 ? 1 : -1, 0, m * Math.abs(a) * fsc, COL.inert, '', '', 'fict');   /* 「慣性力 m_B a_A」（どの質量・どの加速度かを書く。2026-10-12 千葉さん） */
      if (arI) { var dI = a > 0 ? 1 : -1, xI = arI.x2 + dI * 8, sb = m === M4.mC ? 'C' : 'B', alI = dI > 0 ? 'left' : 'right';   /* 2 行（せまい台の中に入るように） */
        label(ctx, '慣性力', xI, arI.y2 - 9, { size: 12, bold: true, color: '#b35f0c', align: alI });
        if (dI > 0) { var q1 = sym(ctx, 'm', xI, arI.y2 + 9, { size: 14, color: '#b35f0c', sub: sb, align: 'left' }); sym(ctx, 'a', q1.x + q1.w + 1, arI.y2 + 9, { size: 14, color: '#b35f0c', sub: 'A', align: 'left' }); }
        else { var q2 = sym(ctx, 'a', xI, arI.y2 + 9, { size: 14, color: '#b35f0c', sub: 'A', align: 'right' }); sym(ctx, 'm', q2.x - 1, arI.y2 + 9, { size: 14, color: '#b35f0c', sub: sb, align: 'right' }); }
      } }
  }
  if (s.rot && s.chk && s.chk.fxy) {                               /* 合力 F（重力＋慣性力）と、その x・y 成分 */
    var c = Math.cos(g.th), sn = Math.sin(g.th), Fx = m * (a * c - G * sn), Fy = -m * (G * c + a * sn);
    var vx = a * m, vy = m * G;                                     /* 画面の向き：慣性力は右（a > 0）、重力は下 */
    var ar = arrow(ctx, b[0], b[1], b[0] + vx * fsc, b[1] + vy * fsc, 'comp', COL_RES, { noShift: true });
    if (ar) sym(ctx, 'F', ar.x2 + 11, ar.y2 + 4, { size: 16, color: COL_RES, vec: true });
    var a1 = arrow(ctx, b[0], b[1], b[0] + dx * Fx * fsc, b[1] + dy * Fx * fsc, 'comp', '#7a3fd4', { noShift: true });
    if (a1) sym(ctx, 'F', a1.x2 + dx * 14, a1.y2 + dy * 14 - 8, { size: 15, color: '#7a3fd4', sub: 'x', subItalic: true });
    var a2 = arrow(ctx, b[0], b[1], b[0] + nx * Fy * fsc, b[1] + ny * Fy * fsc, 'comp', '#7a3fd4', { noShift: true });
    if (a2) sym(ctx, 'F', a2.x2 + 12, a2.y2 + 6, { size: 15, color: '#7a3fd4', sub: 'y', subItalic: true });
  }
  drawEqualTicks(ctx);
}
/* 右の列：「解き方と答え」は開くまで見せない（開け閉めは覚えておく） */
function solBox(s, title, html) {
  return '<details class="qcard solbox"' + (s._sol ? ' open' : '') + '><summary>' + title + '<span class="solhint">（まず自分で解いてから開こう）</span></summary><div class="solin">' + html + '</div></details>';
}
function solWire(s, R, after) {
  var d = R.querySelector('details.solbox'); if (!d) return;
  d.addEventListener('toggle', function () { s._sol = d.open; if (d.open && after) after(); });
  if (d.open && after) after();
}
function m4Frame(s, lin, lrot) {
  return '<div class="qcard setup ' + (s.rot ? 'rot' : 'in') + '"><p class="qt">' + (s.rot ? '物体 A と一緒に運動する観測者（非慣性系）から見ると' : '外（慣性系）から見ると') + '<span class="now">いまの視点</span></p><p>' + (s.rot ? lrot : lin) + '</p>' + frameNote(s.rot) + '</div>';
}
var M4_HEAD = '<div class="pbtns"><button type="button" class="b probb" data-pimg="prob">問題はこちら。<br>まず解いてから以下を読もう</button><button type="button" class="b ansb" data-pimg="ans">解答と解き方はこちら</button></div>';   /* モード4 の説明文の右に 1 つだけ（2026-10-11 千葉さん） */

/* ===================== 4-1 問(1)：外力で A を一定の加速度で動かす ===================== */
function m41Path(s) {
  var a = s.v.aA, th = m4Th(s);
  return m4PathB(s, 'a' + a + '|' + s.v.th, th, function () { return a; }, 2.0);
}
function m41TEnd(s) { var C = m41Path(s); return C.top !== null ? Math.min(1.6, C.top + 0.25) : 1.6; }
function drawM41(s, ctx, W, H) {
  var a = s.v.aA * effK(s), t = s.t, C = m41Path(s), q = m4At(C, t);
  var g = m4Scene(s, ctx, W, H, { th: m4Th(s), u: 0.5 * s.v.aA * t * t, wrap: true, push: s.v.aA > 0, a: a, v: s.v.aA * t });
  var P = g.ball(q.xi, q.eta);
  ballShape(ctx, P[0], P[1], g.rb, '#c9d3de');
  sym(ctx, 'B', P[0] - g.n[0] * (g.rb + 12) - 8, P[1] - g.n[1] * (g.rb + 12), { size: 14, color: COL.ink2 });
  m4Forces(s, ctx, g, P, M4.mB, a, t > 0 ? q.N : M4.mB * G * Math.cos(g.th), t > 0 ? q.R : M4.mB * G * Math.sin(g.th));
  var moving = q.st === 1 || q.st === 3;
  if (q.st === 3 && !s._snap) bubble(ctx, '頂点 P に着いた', P[0], P[1] - g.rb - 30, { size: 12.5 });
  var say = s.rot ? (t < 0.05 ? 'A の上から見ているよ' : (moving ? 'B が上がっていく！' : 'B は止まって見える')) : (t < 0.05 ? 'A に外力を加えるよ' : 'A が左へ加速してる');
  if (!s._snap) speech(ctx, say, s.rot ? g.hdRot : g.hdIn);
}
DEFS.m4s1 = ifBase({
  id: 'm4s1', num: 1, title: '問(1)　外力で台 A を加速させる', mode: 'mode4', V0: 0, TW: 1.6, noAcc: true, noRamp: false, baseRate: 0.45, obsRot: OBS_A,
  height: function (s, w) { return Math.round(clamp(w * 0.66, 320, 440)); },
  desc: 'なめらかな床の上に、傾角 $\\theta$ の斜面をもつ台 A（質量 $m_\\mathrm{A}$）を置く。斜面の点 O には斜面に垂直な平板が固定されていて、小球 B（質量 $m_\\mathrm{B}$）は O より下へは動けない。はじめ B は O に静止している。A に左向きの外力を加え、一定の加速度 $a_\\mathrm{A}$（左向きを正）で動かす。$\\theta = 30^\\circ$ とする。<span class="todo">$a_\\mathrm{A}$ を変えて「▶ スタート」を押し、B が斜面を上がり始めるのはどんなときか確かめよう。</span>',
  vars: [{ k: 'aA', label: 'A の加速度 $a_\\mathrm{A}$', aria: 'Aの加速度', min: 0, max: 12, step: 0.5, def: 8, dec: 1, unit: ' m/s²',
    mark: function () { return [{ x: G * Math.tan(Math.PI / 6), label: '$g\\tan\\theta$' }, { x: 8, label: 'おすすめ', hot: true, tip: 'B が斜面を上がっていくようすがよく分かる値（押すとこの値になる）' }]; } }],   /* 問題の状況がよく分かる値に目立つ印（2026-10-11 千葉さん） */   /* はじめは B が斜面を上がっていく 8 m/s²（θ は 30° に固定。2026-10-11 千葉さん） */
  checks: [{ k: 'fxy', label: '合力 F を x・y の<br>成分に分ける', needF: false }],
  tEnd: function (s) { return m41TEnd(s); },
  msg: function (s) {
    var C = m41Path(s), q = m4At(C, s.t);
    if (s.t <= 0) return 'B は点 O で平板に当たって静止している。「▶ スタート」を押そう。';
    if (q.st === 1 || q.st === 3) return 'B が平板から離れて、斜面を<b>上がり始めた</b>。' + (s.rot ? 'A の上から見ると、慣性力の斜面にそった成分が、重力の斜面にそった成分より大きい。' : '外から見ると、B は A より加速度が小さく、A の斜面のほうが B の下にもぐりこむように動く。');
    return 'B は平板に当たったまま、A と一緒に動いている。' + (s.rot ? 'A の上から見ると、B は止まっている（力がつり合っている）。' : '');
  },
  draw: drawM41,
  right: function (s, R) {
    var a = s.v.aA, th = m4Th(s), c = Math.cos(th), sn = Math.sin(th), m = M4.mB, Fx = m * (a * c - G * sn), Fy = -m * (G * c + a * sn), gt = G * Math.tan(th);
    var h = m4Frame(s, 'A は加速度 $a_\\mathrm{A}$（左向き）で動く。B が平板に当たったままなら、B も同じ加速度で動いている。B にはたらく力は重力・斜面からの垂直抗力・平板からの力だけ。慣性力は<b>ない</b>。',
      'A は止まって見える。B には重力 $m_\\mathrm{B}g$ と、A の加速度と逆向き（右向き）の<b>慣性力 $m_\\mathrm{B}a_\\mathrm{A}$</b> がはたらく。この 2 つの合力 $\\vec{F}$ を、$x$ 軸（O から P の向き）と $y$ 軸（斜面に垂直で上向き）に分けて考える。「合力 F を x・y の成分に分ける」で図に出せる。');
    var sol = '<p class="qsub">問(1)(a)</p><p>A の上の観測者から見ると、B に作用する重力と慣性力を $x$・$y$ 成分に分けて</p>' +
      '<table class="cmpt"><thead><tr><th></th><th>$x$ 成分</th><th>$y$ 成分</th></tr></thead><tbody>' +
      '<tr><th>重力</th><td>' + tex('-m_\\mathrm{B}g\\sin\\theta') + '</td><td>' + tex('-m_\\mathrm{B}g\\cos\\theta') + '</td></tr>' +
      '<tr><th>慣性力（右向き）</th><td>' + tex('+m_\\mathrm{B}a_\\mathrm{A}\\cos\\theta') + '</td><td>' + tex('-m_\\mathrm{B}a_\\mathrm{A}\\sin\\theta') + '</td></tr></tbody></table>' +
      '<div class="qeq">' + tex('F_x = m_\\mathrm{B}(a_\\mathrm{A}\\cos\\theta - g\\sin\\theta)', true) + tex('F_y = -m_\\mathrm{B}(g\\cos\\theta + a_\\mathrm{A}\\sin\\theta)', true) + '</div>' +
      '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('m_\\mathrm{B}=0.20\\ \\text{kg}:\\ F_x = ' + f2(Fx) + '\\ \\text{N},\\ F_y = ' + f2(Fy) + '\\ \\text{N}') + '</p>' +
      '<p class="qsub">問(1)(b)</p><p>B が $x$ 軸方向へ動き出すのは、$F_x > 0$ のとき（$F_x\\le 0$ なら、平板が B を押し返してつり合う）。</p>' +
      '<div class="qeq">' + tex('a_\\mathrm{A}\\cos\\theta - g\\sin\\theta > 0 \\;\\Longrightarrow\\; a_\\mathrm{A} > g\\tan\\theta', true) + '</div>' +
      '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('g\\tan' + f1(s.v.th) + '^\\circ = ' + f2(gt) + '\\ \\text{m/s}^2') + '。いまの ' + tex('a_\\mathrm{A} = ' + f1(a)) + ' なので、B は' + (a > gt + 1e-9 ? '<b>動き出す</b>' : '<b>動き出さない</b>') + '。</p>' +
      '<p class="qnote">$F_y$ はいつも負なので、B は斜面に押しつけられる（斜面から離れない）。$y$ 方向は、垂直抗力 $N = -F_y$ とつり合う。</p>';
    R.innerHTML = mathify(h + m4InertCard(1) + solBox(s, '問(1) の解き方と答え', sol) + '<p class="assume">図では ' + tex('m_\\mathrm{B}=0.20') + ' kg、' + tex('g=9.8') + ' m/s²。すべての面はなめらか。A はじめ静止。</p>');
    m4InertGraph(R, s, 1); solWire(s, R); m4SnapsLater(s, R);
  }
});

/* ===================== 4-2 問(2)：ばねにつないだ A（B の影響は無視） ===================== */
function m42Path(s) {
  var L = s.v.L, om = m4Om(), th = m4Th(s);
  return m4PathB(s, 'L' + L + '|' + s.v.th, th, function (t) { return L * om * om * Math.cos(om * t); }, 2.0);
}
function m42U(s, t) { var om = m4Om(); return { u: -s.v.L * Math.cos(om * t), v: s.v.L * om * Math.sin(om * t), a: s.v.L * om * om * Math.cos(om * t) }; }
function drawM42(s, ctx, W, H) {
  var t = s.t, A = m42U(s, t), C = m42Path(s), q = m4At(C, t);
  var g = m4Scene(s, ctx, W, H, { th: m4Th(s), u: A.u, spring: true, a: A.a, v: A.v, hold: t < 0.02 });
  var P = g.ball(q.xi, q.eta);
  ballShape(ctx, P[0], P[1], g.rb, '#c9d3de');
  sym(ctx, 'B', P[0] - g.n[0] * (g.rb + 12) - 8, P[1] - g.n[1] * (g.rb + 12), { size: 14, color: COL.ink2 });
  m4Forces(s, ctx, g, P, M4.mB, A.a, q.N, q.R);
  /* 手を放す前の、ばねの縮み L */
  if (t < 0.02) m4Ldim(ctx, g, s.v.L, s._snap || s._nar);
  if (s._snap) { }
  else if (C.left !== null && t >= C.left) eventBubble(ctx, 'off', P[0], P[1] - g.rb - 6);
  else if (q.st === 3) bubble(ctx, '頂点 P に着いた', P[0], P[1] - g.rb - 30, { size: 12 });
  var say = s.rot ? (t < 0.05 ? 'A の上から見ているよ' : (C.left !== null && t >= C.left ? 'B が浮いた！' : (q.st === 1 ? 'B が動いてる' : 'B は止まって見える'))) : (t < 0.05 ? '外力の手が離れると…' : 'A が単振動してる');   /* 手を放すのは外力。観測者ではない */
  if (!s._snap) speech(ctx, say, s.rot ? g.hdRot : g.hdIn);
}
DEFS.m4s2 = ifBase({
  id: 'm4s2', num: 2, title: '問(2)　ばねにつないだ台 A', mode: 'mode4', V0: 0, TW: 1.8, noAcc: true, noRamp: true, baseRate: 0.3, obsRot: OBS_A,
  height: function (s, w) { return Math.round(clamp(w * 0.66, 320, 440)); },
  desc: 'A の右の面にばね定数 $k$ のばねをつけ、もう一方のはしを床に固定された壁につなぐ。ばねが自然の長さより $L$ だけ短くなるように A を動かし、静かに手を放す。B の質量は A よりずっと小さく、A の運動への B の影響は無視できる。$\\theta = 30^\\circ$ とする。<span class="todo">$L$ を変えて、B が動き出すか、斜面から離れないかを確かめよう。</span>',
  vars: [{ k: 'L', label: 'ばねの縮み $L$', aria: 'ばねの縮み', min: 0.05, max: 0.5, step: 0.01, def: 0.25, dec: 2, unit: ' m',
    mark: function () { var L0 = M4.mA * G / M4.k, tn = Math.tan(Math.PI / 6); return [{ x: L0 * tn, label: '(a)' }, { x: 0.25, label: 'おすすめ', hot: true, tip: 'B が動き出し、しかも斜面から離れない値（押すとこの値になる）' }, { x: L0 / tn, label: '(b)' }]; } }],   /* θ は 30° に固定 */
  checks: [{ k: 'fxy', label: '合力 F を x・y の<br>成分に分ける', needF: false }],
  tEnd: function (s) { return 1.8; },
  msg: function (s) {
    var C = m42Path(s), q = m4At(C, s.t);
    if (s.t <= 0) return '外力（手）が A を押して、ばねを $L$ だけ縮めている。「▶ スタート」を押すと、手が離れる。';
    if (C.left !== null && s.t >= C.left) return 'B が<b>斜面から離れた</b>。A が右向きに大きく加速するとき（ばねが伸びているとき）、斜面が B から「逃げて」しまう。';
    if (C.start === null) return 'B は平板に当たったまま。A の加速度が一番大きい手をはなした直後でも、B は動き出さない。';
    return 'B は斜面を滑り、また O へ戻ってくる。A は単振動（周期 $2\\pi\\sqrt{m_\\mathrm{A}/k}$）をしている。';
  },
  draw: drawM42,
  right: function (s, R) {
    var L = s.v.L, th = m4Th(s), tn = Math.tan(th), L0 = M4.mA * G / M4.k, lo = L0 * tn, hi = L0 / tn, amax = M4.k * L / M4.mA;
    var h = m4Frame(s, 'A はばねの力で単振動をする（振幅 $L$、角振動数 $\\sqrt{k/m_\\mathrm{A}}$）。加速度は時刻とともに変わり、その大きさは手をはなした直後とばねが最も伸びたときに最大 $\\dfrac{kL}{m_\\mathrm{A}}$。',
      'A は止まって見える。A の加速度が変わるので、B にはたらく慣性力も大きさと向きが変わる。問(1) の結果（$F_x$・$F_y$）の $a_\\mathrm{A}$ に、いまの A の加速度を入れればよい。');
    var sol = '<p class="qsub">問(2)(a)</p><p>A の加速度（左向きを正）が一番大きいのは、手をはなした直後：$a_\\mathrm{A} = \\dfrac{kL}{m_\\mathrm{A}}$。問(1)(b) の条件 $a_\\mathrm{A} > g\\tan\\theta$ に入れると</p>' +
      '<div class="qeq">' + tex('L > \\frac{m_\\mathrm{A}g\\tan\\theta}{k}', true) + '</div>' +
      '<p class="qsub">問(2)(b)</p><p>B が斜面に接している間、$y$ 方向は垂直抗力 $N$ とつり合う：$N = m_\\mathrm{B}(g\\cos\\theta + a_\\mathrm{A}\\sin\\theta)$。いつも $N \\ge 0$ であればよい。一番厳しいのは、A の加速度が<b>右向きに最大</b>（$a_\\mathrm{A} = -\\dfrac{kL}{m_\\mathrm{A}}$、ばねが最も伸びたとき）。</p>' +
      '<div class="qeq">' + tex('g\\cos\\theta - \\frac{kL}{m_\\mathrm{A}}\\sin\\theta \\ge 0 \\;\\Longrightarrow\\; L \\le \\frac{m_\\mathrm{A}g}{k\\tan\\theta}', true) + '</div>' +
      '<p class="qsub">問(2)(c)</p><p>(a)(b) をともに満たすには ' + tex('\\dfrac{m_\\mathrm{A}g}{k}\\tan\\theta < L \\le \\dfrac{m_\\mathrm{A}g}{k}\\cdot\\dfrac{1}{\\tan\\theta}') + '。このような $L$ があるのは $\\tan\\theta < \\dfrac{1}{\\tan\\theta}$、つまり $\\tan\\theta < 1$ のとき。</p>' +
      '<div class="qeq">' + tex('\\theta_\\text{max} = 45^\\circ', true) + '</div>' +
      '<p>縦軸を $L$、横軸を $\\tan\\theta$ にとると、直線 $L = \\dfrac{m_\\mathrm{A}g}{k}\\tan\\theta$ と曲線 $L = \\dfrac{m_\\mathrm{A}g}{k}\\cdot\\dfrac{1}{\\tan\\theta}$ の間（$\\tan\\theta<1$）が答えの範囲。● がいまの $L$ と $\\theta$。</p>' +
      '<canvas class="vecc" data-v="g42"></canvas>' +
      '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('\\frac{m_\\mathrm{A}g}{k} = ' + f2(L0) + '\\ \\text{m}') + '、' + tex(f3(lo) + ' < L \\le ' + f3(hi)) + '（いまの ' + tex('L = ' + f2(L)) + '、手をはなした直後の加速度 ' + tex(f1(amax)) + ' m/s²）</p>';
    R.innerHTML = mathify(h + m4InertCard(2) + solBox(s, '問(2) の解き方と答え', sol) + '<p class="assume">図では ' + tex('m_\\mathrm{A}=1.0') + ' kg、' + tex('k=49') + ' N/m（' + tex('m_\\mathrm{A}g/k = 0.20') + ' m）、' + tex('g=9.8') + ' m/s²。B の影響は無視（B の絵の質量は 0.20 kg として力を描いた）。</p>');
    m4InertGraph(R, s, 2); solWire(s, R, function () { m42Graph(s, R.querySelector('canvas.vecc[data-v="g42"]')); }); m4SnapsLater(s, R);
  }
});
/* 慣性力の向きと大きさ（2026-10-12 千葉さん）：4-1 は一定、4-2・4-3 は時刻とともに大きさも向きも変わる。グラフ（右向きを正）つき */
function m4InertCard(n) {
  var t = n === 1 ? '<p>A の加速度 $a_\\mathrm{A}$ は一定なので、A の上から見た慣性力 $m_\\mathrm{B}a_\\mathrm{A}$ も<b>大きさ・向きとも一定</b>（いつも右向き）。重力と同じように一定の力なので、重力と慣性力の合力（見かけの重力）も一定になる。</p>'
    : n === 2 ? '<p>A は単振動をしているので、A の加速度は $a_\\mathrm{A} = \\dfrac{kL}{m_\\mathrm{A}}\\cos\\omega t$（左向きを正、$\\omega = \\sqrt{k/m_\\mathrm{A}}$）のように時刻とともに変わる。よって B にはたらく慣性力（右向きを正）$m_\\mathrm{B}a_\\mathrm{A} = \\dfrac{m_\\mathrm{B}kL}{m_\\mathrm{A}}\\cos\\omega t$ も、<b>大きさも向きも変わる</b>。A の単振動と同じ周期で、cos の形で振動する（右向きに最大 → 0 → 左向きに最大 → …）。</p>'
    : '<p>A の加速度は時刻とともに変わるので、C にはたらく慣性力も<b>大きさも向きも変わる</b>。C が斜面を動いているあいだは、C が A を押すので A の運動は単振動からずれ、慣性力もきれいな cos の形にはならない。衝突のあと（A と C が一体）は単振動になり、慣性力も cos の形で振動する。</p>';
  return '<div class="qcard derive"><p class="qt">A の上から見た慣性力の向きと大きさ</p>' + t + '<canvas class="vecc" data-v="m4f"></canvas></div>';
}
function m4InertGraph(R, s, n) {
  var cv = R.querySelector('canvas.vecc[data-v="m4f"]'); if (!cv) return;
  var W = Math.max(240, Math.floor(cv.parentNode.clientWidth || 300)), H = 170, ctx = prep(cv, W, H);
  var T = n === 1 ? m41TEnd(s) : 1.6, m = n === 3 ? M4.mC : M4.mB, N = 120, ys = [];
  var C3 = n === 3 ? m43Path(s) : null;
  for (var i = 0; i <= N; i++) { var t = T * i / N, aA = n === 1 ? s.v.aA : (n === 2 ? m42U(s, t).a : m43At(C3, t).a); ys.push(m * aA); }
  var Y = Math.max(0.5, Math.max.apply(null, ys.map(Math.abs))) * 1.15, x0 = 40, xw = W - x0 - 30, yc = H / 2 + 6, yh = H / 2 - 30;
  /* 軸（矢印つき。縦軸は負から正まで、0 がまん中） */
  ctx.save(); ctx.strokeStyle = COL.ink; ctx.fillStyle = COL.ink; ctx.lineWidth = 1.3;
  ctx.beginPath(); ctx.moveTo(x0, yc); ctx.lineTo(x0 + xw + 12, yc); ctx.stroke(); ctx.beginPath(); ctx.moveTo(x0 + xw + 18, yc); ctx.lineTo(x0 + xw + 10, yc - 4); ctx.lineTo(x0 + xw + 10, yc + 4); ctx.fill();
  ctx.beginPath(); ctx.moveTo(x0, yc + yh + 6); ctx.lineTo(x0, yc - yh - 8); ctx.stroke(); ctx.beginPath(); ctx.moveTo(x0, yc - yh - 14); ctx.lineTo(x0 - 4, yc - yh - 6); ctx.lineTo(x0 + 4, yc - yh - 6); ctx.fill(); ctx.restore();
  label(ctx, 't', x0 + xw + 20, yc + 12, { size: 12, color: COL.ink2 });
  label(ctx, '慣性力（右向き正）', x0 + 6, 12, { size: 11, bold: true, color: '#b35f0c', align: 'left' });
  label(ctx, '0', x0 - 8, yc, { size: 10.5, color: COL.sub, align: 'right' });
  label(ctx, '右向き', x0 - 6, yc - yh * 0.7, { size: 9.5, color: COL.sub, align: 'right' });
  label(ctx, '左向き', x0 - 6, yc + yh * 0.7, { size: 9.5, color: COL.sub, align: 'right' });
  ctx.save(); ctx.strokeStyle = COL.inert; ctx.lineWidth = 2.2; ctx.beginPath();
  ys.forEach(function (v, i) { var x = x0 + xw * i / N, y = yc - v / Y * yh; i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }); ctx.stroke(); ctx.restore();
  if (C3 && C3.coll) { var xc = x0 + xw * C3.coll.t / T; ctx.save(); ctx.setLineDash([3, 3]); ctx.strokeStyle = '#d1352b'; ctx.beginPath(); ctx.moveTo(xc, yc - yh); ctx.lineTo(xc, yc + yh); ctx.stroke(); ctx.restore(); label(ctx, '衝突', xc + 4, yc + yh - 4, { size: 10, bold: true, color: '#d1352b', align: 'left' }); }
}
/* 問(2)(c) の図：縦軸 L、横軸 tanθ */
function m42Graph(s, cv) {
  if (!cv) return;
  var W = Math.max(240, Math.floor(cv.parentNode.clientWidth || 300)), H = 230, ctx = prep(cv, W, H);
  var L0 = M4.mA * G / M4.k, x0 = 44, y0 = H - 34, xw = W - x0 - 24, yh = y0 - 22, XM = 1.6, YM = 0.5;
  var X = function (t) { return x0 + t / XM * xw; }, Y = function (L) { return y0 - L / YM * yh; };
  /* 範囲（0 < tanθ < 1、直線と曲線の間）を塗る */
  ctx.save(); ctx.beginPath(); var i, t;
  for (i = 0; i <= 60; i++) { t = 1e-3 + (1 - 1e-3) * i / 60; var Lh = Math.min(YM, L0 / t); i ? ctx.lineTo(X(t), Y(Lh)) : ctx.moveTo(X(t), Y(Lh)); }
  for (i = 60; i >= 0; i--) { t = (1) * i / 60; ctx.lineTo(X(t), Y(L0 * t)); }
  ctx.closePath(); ctx.fillStyle = 'rgba(224,123,24,.22)'; ctx.fill();
  ctx.beginPath(); ctx.rect(x0, y0 - yh, xw, yh); ctx.clip();
  ctx.save(); ctx.globalAlpha = 0.5; ctx.strokeStyle = '#e07b18'; ctx.lineWidth = 1;
  for (var d = -2; d < 3; d += 0.08) { ctx.beginPath(); ctx.moveTo(X(d), Y(0)); ctx.lineTo(X(d + 0.5), Y(YM)); ctx.stroke(); }
  ctx.restore(); ctx.restore();
  /* 線 */
  ctx.save(); ctx.lineWidth = 2; ctx.strokeStyle = '#2f3a8f';
  ctx.beginPath(); ctx.moveTo(X(0), Y(0)); ctx.lineTo(X(XM), Y(L0 * XM)); ctx.stroke();
  ctx.strokeStyle = '#c0392b'; ctx.beginPath(); for (i = 0; i <= 120; i++) { t = 0.38 + (XM - 0.38) * i / 120; i ? ctx.lineTo(X(t), Y(L0 / t)) : ctx.moveTo(X(t), Y(L0 / t)); } ctx.stroke();
  ctx.restore();
  /* 軸 */
  ctx.save(); ctx.strokeStyle = COL.ink; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(x0, y0 - yh - 6); ctx.lineTo(x0, y0); ctx.lineTo(x0 + xw + 6, y0); ctx.stroke(); ctx.restore();
  sym(ctx, 'L', x0 - 14, y0 - yh, { size: 15 });
  label(ctx, 'tanθ', x0 + xw - 4, y0 + 18, { size: 12, color: COL.ink2 });
  [0.5, 1, 1.5].forEach(function (v) { label(ctx, String(v), X(v), y0 + 12, { size: 10.5, color: COL.sub }); });
  ctx.save(); ctx.setLineDash([3, 3]); ctx.strokeStyle = COL.ink2; ctx.beginPath(); ctx.moveTo(X(1), y0); ctx.lineTo(X(1), Y(L0)); ctx.lineTo(x0, Y(L0)); ctx.stroke(); ctx.restore();
  label(ctx, 'mAg/k', x0 - 4, Y(L0), { size: 10, color: COL.sub, align: 'right' });
  label(ctx, '45°', X(1) + 4, y0 - 10, { size: 10.5, color: COL.ink2, align: 'left' });
  label(ctx, '(a) 動き出す：L > (mAg/k)tanθ', X(1.05), Y(L0 * 1.3) + 22, { size: 10.5, bold: true, color: '#2f3a8f', align: 'left' });
  label(ctx, '(b) 離れない：L ≦ (mAg/k)/tanθ', X(0.42), Y(0.47), { size: 10.5, bold: true, color: '#c0392b', align: 'left' });
  /* いまの点 */
  var tn = Math.tan(m4Th(s)), L = s.v.L;
  if (tn <= XM) { ctx.save(); ctx.beginPath(); ctx.arc(X(tn), Y(L), 5.5, 0, TAU); ctx.fillStyle = COL.vel; ctx.fill(); ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.stroke(); ctx.restore(); }
}

/* ===================== 4-3 問(3)：C にかえる（C の影響あり、θ = 30°） ===================== */
var M43 = { th: Math.PI / 6, LST: [0.2, 0.25, 0.3, 0.35] };
/* u＝A の左向きの変位、s＝O から斜面にそった C の位置。
   運動エネルギー ½(m_A+m_C)u̇² − m_C cosθ u̇ṡ + ½m_C ṡ²、位置エネルギー ½ku² + m_C g s sinθ から
   ü = (−ku − m_C g sinθ cosθ)/(m_A + m_C sin²θ)、s̈ = cosθ ü − g sinθ。平板に当たったら（e = 0）C は A と一体になる */
function m43Path(s) {
  var L = s.v.L, key = 'c' + L, C = s._p43;
  if (C && C.key === key) return C;
  var mA = M4.mA, mC = M4.mC, k = M4.k, th = M43.th, c = Math.cos(th), sn = Math.sin(th), h = 1 / M4.H2;
  var u = -L, ud = 0, sp = 0, sd = 0, t = 0, st = 0, arr = [], coll = null, umax = null, Nmin = Infinity, tStart = null;
  while (t <= 2.0) {
    var udd, sdd = 0, N = 0;
    if (st === 0) { udd = -k * u / (mA + mC); sdd = c * udd - G * sn; if (sdd > 0) { st = 1; tStart = t; } }
    if (st === 1) { udd = (-k * u - mC * G * sn * c) / (mA + mC * sn * sn); sdd = c * udd - G * sn; }
    if (st === 2) { udd = -k * u / (mA + mC); sdd = 0; }
    N = mC * (G * c + udd * sn); if (st === 1) Nmin = Math.min(Nmin, N);
    arr.push([u, ud, udd, sp, sd, st, N]);
    ud += udd * h; u += ud * h; if (st === 1) { sd += sdd * h; sp += sd * h; }
    t += h;
    if (st === 1 && sp <= 0 && sd < 0) {                           /* 平板と衝突（反発係数 0）：水平方向の運動量保存 */
      var vA = ud, vC = -sd, vAp = vA + mC * c * vC / (mA + mC);
      coll = { t: t, vA: vA, vC: vC, vAp: vAp, u: u };
      ud = vAp; sp = 0; sd = 0; st = 2;
    }
    if (st === 2 && umax === null && ud <= 0) umax = { t: t, u: u };
  }
  var Lp = coll ? Math.sqrt(L * L - (4 * mA + mC) * mC * coll.vC * coll.vC / (4 * k * (mA + mC))) : NaN;
  C = s._p43 = { key: key, arr: arr, coll: coll, umax: umax, Lp: Lp, Nmin: Nmin, tStart: tStart };
  return C;
}
function m43At(C, t) { var i = clamp(Math.round(t * M4.H2), 0, C.arr.length - 1), q = C.arr[i]; return { u: q[0], v: q[1], a: q[2], sp: q[3], sd: q[4], st: q[5], N: q[6] }; }
function drawM43(s, ctx, W, H) {
  var t = s.t, C = m43Path(s), q = m43At(C, t);
  var g = m4Scene(s, ctx, W, H, { th: M43.th, u: q.u, spring: true, a: q.a, v: q.v, hold: t < 0.02 });
  var P = g.ball(q.sp, 0);
  ballShape(ctx, P[0], P[1], g.rb, '#d8c9a8');
  sym(ctx, 'C', P[0] - g.n[0] * (g.rb + 14) - 8, P[1] - g.n[1] * (g.rb + 14), { size: 14, color: COL.ink2 });
  var R = q.st !== 1 ? Math.max(0, M4.mC * -(q.a * Math.cos(M43.th) - G * Math.sin(M43.th))) : 0;
  m4Forces(s, ctx, g, P, M4.mC, q.a, q.N, R);
  /* C の、A に対する速度（A の上から見たとき） */
  if (s.rot && q.st === 1 && Math.abs(q.sd) > 0.05) { var sg = q.sd > 0 ? 1 : -1; velAt(ctx, P[0] + g.n[0] * 26, P[1] + g.n[1] * 26, g.d[0] * sg, g.d[1] * sg, Math.abs(q.sd) * 0.3 * g.k + 6, [8, -6]); }
  if (t < 0.02) m4Ldim(ctx, g, s.v.L, s._snap || s._nar);
  if (!s._snap && C.coll && t >= C.coll.t && t < C.coll.t + 0.12) bubble(ctx, '平板と衝突！', P[0], P[1] - g.rb - 8, { size: 13, bg: '#fde2dc', border: '#d1352b', color: '#9b2418' });
  if (!s._snap && C.umax && t >= C.umax.t) bubble(ctx, 'ばねが最も伸びた', g.xR + 0.3 * g.k, g.yg - 0.55 * g.k, { size: 12.5, bg: '#dff2ee', border: '#0f8a8a', color: '#0a5c5c' });
  var say = s.rot ? (t < 0.05 ? 'A の上から見ているよ' : (q.st === 1 ? (q.sd > 0 ? 'C が上がっていく' : 'C が戻ってくる') : (q.st === 2 ? 'C は平板にくっついた' : 'C は止まって見える'))) : (t < 0.05 ? '外力の手が離れると…' : (q.st === 2 ? 'A と C が一緒に動いてる' : 'A が動いてる'));
  if (!s._snap) speech(ctx, say, s.rot ? g.hdRot : g.hdIn);
}
DEFS.m4s3 = ifBase({
  id: 'm4s3', num: 3, title: '問(3)　小球 C にかえる（衝突）', mode: 'mode4', V0: 0, TW: 1.4, noAcc: true, noRamp: true, baseRate: 0.3, obsRot: OBS_A,
  height: function (s, w) { return Math.round(clamp(w * 0.66, 320, 440)); },
  desc: '小球 B を質量 $m_\\mathrm{C}$ の小球 C にかえる。こんどは C が A の運動に与える影響も考える。$\\theta = 30^\\circ$。ばねを $L$ だけ縮めて手を放すと、C は O から斜面を上がり、斜面から離れずに O へ戻って平板と衝突する（反発係数 0）。<span class="todo">衝突の前後で A の速さがどう変わるか、衝突のあとばねがどこまで伸びるかを見よう。</span>',
  vars: [{ k: 'L', label: 'ばねの縮み $L$', aria: 'ばねの縮み', stops: M43.LST, stopLabels: ['0.20', '0.25', '0.30', '0.35'], def: 0.3, fmt: function (x) { return f2(x) + ' m'; },
    mark: function () { return { x: 0.3, label: 'おすすめ', hot: true, tip: 'C が上がって戻り、平板と衝突するようすがよく分かる値（押すとこの値になる）' }; } }],
  checks: [{ k: 'fxy', label: '合力 F を x・y の<br>成分に分ける', needF: false }],
  afterBuild: function (s) { alignStops(s); },
  tEnd: function (s) { var C = m43Path(s); return C.umax ? Math.min(1.6, C.umax.t + 0.3) : 1.6; },
  tInfo: function (s) { var C = m43Path(s); return C.coll && s.t >= C.coll.t ? '衝突 ' + f2(C.coll.t) + ' s' : ''; },
  msg: function (s) {
    var C = m43Path(s), q = m43At(C, s.t);
    if (s.t <= 0) return '外力（手）が A を押して、ばねを $L$ だけ縮めている。「▶ スタート」を押すと、手が離れる。';
    if (q.st === 2) return 'C は平板にくっつき、A と一体になって動く。衝突は一瞬なので、<b>水平方向の運動量</b>だけが保存する（床が鉛直方向の力積を与えるので、鉛直方向は保存しない）。';
    if (q.st === 1) return s.rot ? 'A の上から見ると、C は斜面にそってまっすぐ上がり、また戻ってくる。' : '外から見ると、A と C は別々に動いている。C の影響で A の単振動はくずれる。';
    return 'C は平板に当たったまま A と一緒に動いている。';
  },
  draw: drawM43,
  right: function (s, R) {
    var C = m43Path(s), L = s.v.L, mA = M4.mA, mC = M4.mC, k = M4.k, cl = C.coll;
    var h = m4Frame(s, '衝突の直前、A と平板の速度は $v_\\mathrm{A}$（左向き正）。C は A に対して斜面にそって下向きに $v_\\mathrm{C}$ で動いているので、床から見た C の速度は「A の速度＋A に対する速度」。',
      'A は止まって見え、C は斜面にそってまっすぐ動く。C は O に戻ってきたとき、A に対して $v_\\mathrm{C}$ の速さで平板に当たり、A に対して止まる（反発係数 0）。');
    var sol = '<p class="qsub">問(3)(a)</p><p>床から見た衝突直前の C の速度：水平（左向き正）' + tex('v_\\mathrm{A} + v_\\mathrm{C}\\cos30^\\circ = v_\\mathrm{A} + \\tfrac{\\sqrt3}{2}v_\\mathrm{C}') + '、鉛直（下向き）' + tex('\\tfrac12 v_\\mathrm{C}') + '。</p>' +
      '<p>衝突は一瞬で、その間水平方向には外から力積がはたらかない（ばねの力は有限、床からの力は鉛直）。だから A・平板・C の<b>水平方向の運動量が保存</b>する。衝突のあと C は A と同じ速度。</p>' +
      '<div class="qeq">' + tex('m_\\mathrm{A}v_\\mathrm{A} + m_\\mathrm{C}\\left(v_\\mathrm{A} + \\tfrac{\\sqrt3}{2}v_\\mathrm{C}\\right) = (m_\\mathrm{A}+m_\\mathrm{C})v_\\mathrm{A}\'', true) + tex("v_\\mathrm{A}' = v_\\mathrm{A} + \\frac{\\sqrt3\\,m_\\mathrm{C}v_\\mathrm{C}}{2(m_\\mathrm{A}+m_\\mathrm{C})}", true) + '</div>' +
      '<p class="qnote">鉛直方向は、床が A を押し返す力積があるので保存しない。</p>' +
      '<p class="qsub">問(3)(b)</p><p>衝突の前と後で、それぞれ力学的エネルギーが保存する（衝突で失われる分だけが変わる）。衝突のときのばねの伸びを $x$ とすると、C は O に戻っているので高さははじめと同じ。</p>' +
      '<div class="qeq">' + tex('\\tfrac12 kL^2 = \\tfrac12 m_\\mathrm{A}v_\\mathrm{A}^2 + \\tfrac12 m_\\mathrm{C}\\left\\{\\left(v_\\mathrm{A}+\\tfrac{\\sqrt3}{2}v_\\mathrm{C}\\right)^2 + \\left(\\tfrac12 v_\\mathrm{C}\\right)^2\\right\\} + \\tfrac12 kx^2', true) +
      tex("\\tfrac12 (m_\\mathrm{A}+m_\\mathrm{C})v_\\mathrm{A}'^2 + \\tfrac12 kx^2 = \\tfrac12 kL'^2", true) + '</div>' +
      '<p>(a) の $v_\\mathrm{A}\'$ を入れて $x$ を消すと、$v_\\mathrm{A}$ をふくむ項は<b>すべて消える</b>。</p>' +
      '<div class="qeq">' + tex("L' = \\sqrt{L^2 - \\frac{(4m_\\mathrm{A}+m_\\mathrm{C})\\,m_\\mathrm{C}v_\\mathrm{C}^2}{4k(m_\\mathrm{A}+m_\\mathrm{C})}}", true) + '</div>' +
      (cl ? '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('v_\\mathrm{A} = ' + f3(cl.vA) + ',\\ v_\\mathrm{C} = ' + f3(cl.vC) + '\\ \\text{m/s}') + ' → ' + tex("v_\\mathrm{A}' = " + f3(cl.vAp) + '\\ \\text{m/s}') + '、' + tex("L' = " + f3(C.Lp) + '\\ \\text{m}') + '（図で測った最大の伸び ' + (C.umax ? f3(C.umax.u) : '—') + ' m）</p>' : '') +
      '<p class="qnote">失われたエネルギーは ' + tex('\\tfrac12 kL^2 - \\tfrac12 kL\'^2 = \\dfrac{(4m_\\mathrm{A}+m_\\mathrm{C})m_\\mathrm{C}v_\\mathrm{C}^2}{8(m_\\mathrm{A}+m_\\mathrm{C})}') + '。C が A に対して止まる（反発係数 0）ことで失われる。</p>';
    R.innerHTML = mathify(h + m4InertCard(3) + solBox(s, '問(3) の解き方と答え', sol) + '<p class="assume">図では ' + tex('m_\\mathrm{A}=1.0') + ' kg、' + tex('m_\\mathrm{C}=0.50') + ' kg、' + tex('k=49') + ' N/m、' + tex('\\theta=30^\\circ') + '、' + tex('g=9.8') + ' m/s²。数値は運動方程式を細かい時間きざみで解いて求めた。</p>');
    m4InertGraph(R, s, 3); solWire(s, R); m4SnapsLater(s, R);
  }
});

/* コマ図は描くのに時間がかかる（1 回 50 ms ほど）ので、右の列を出したあと、手が空いたときに描く（ボタンやスライダーの反応を遅くしない。2026-10-12） */
function m4SnapsLater(s, R) {
  var tok = s._snapTok = (s._snapTok || 0) + 1;
  var run = function () { if (s._snapTok === tok && R.isConnected !== false) m4Snaps(s, R); };
  if (window.requestIdleCallback) requestIdleCallback(run, { timeout: 400 }); else setTimeout(run, 30);
}
/* ---------- 問題文・解答の重ね窓 ---------- */
function m4Overlay(kind) {
  var ov = document.getElementById('probov');
  if (!ov) {
    ov = document.createElement('div'); ov.id = 'probov'; ov.hidden = true;
    ov.innerHTML = '<div class="probov-in" role="dialog" aria-modal="true"><div class="probov-bar"><b class="probov-t"></b><button type="button" class="probov-x" aria-label="閉じる">✕ 閉じる</button></div><div class="probov-body"></div></div>';
    document.body.appendChild(ov);
    ov.addEventListener('click', function (e) { if (e.target === ov || e.target.closest('.probov-x')) ov.hidden = true; });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') ov.hidden = true; });
  }
  var img = (typeof IMG !== 'undefined') ? IMG[kind === 'ans' ? 'm4_ans' : 'm4_prob'] : null;
  ov.querySelector('.probov-t').textContent = kind === 'ans' ? '解答と解き方（2016 東北大・一部やさしく書きかえ）' : '問題（2016 東北大・一部やさしく書きかえ）';
  ov.querySelector('.probov-body').innerHTML = img ? '<img src="' + img + '" alt="' + (kind === 'ans' ? '解答と解き方' : '問題文') + '">' : '<p>画像がありません。</p>';
  ov.hidden = false; ov.querySelector('.probov-body').scrollTop = 0;
}
document.addEventListener('click', function (e) { var b = e.target.closest && e.target.closest('[data-pimg]'); if (b) m4Overlay(b.getAttribute('data-pimg')); });

/* ---------- 右の列の一番下の「コマ図」（circular-motion.html の 3-1 と同じ考え。2026-10-11 千葉さん） ----------
   いまの設定の動きを、大事な瞬間ごとに 3〜5 コマで。いまの観測者（外／A と一緒）で描く。マウスを重ねる（タップする）と拡大 */
var ZOV = null, ZCV = null, ZCX = null;
function zoomInit() {
  if (ZOV) return;
  ZOV = el('div', 'zoomlay hidden'); ZCV = el('canvas'); ZOV.appendChild(ZCV); ZCX = ZCV.getContext('2d');
  document.body.appendChild(ZOV);
  document.addEventListener('click', function () { zoomHide(); });
  window.addEventListener('resize', function () { zoomHide(); });
  window.addEventListener('scroll', function () { zoomHide(); }, { passive: true });
}
function zoomShow(box) {
  var z = box._z; if (!z || !z.w || !z.h) return;
  zoomInit();
  var maxW = Math.min(window.innerWidth - 20, 1180), maxH = window.innerHeight - 20;
  var k = Math.min(maxW / z.w, maxH / z.h, 2.4);
  if (k < 1.12) return;
  var W = z.w * k, H = z.h * k, dpr = Math.min(2, window.devicePixelRatio || 1);
  ZCV.style.width = W + 'px'; ZCV.style.height = H + 'px';
  ZCV.width = Math.round(W * dpr); ZCV.height = Math.round(H * dpr);
  ZCX.setTransform(dpr * k, 0, 0, dpr * k, 0, 0); ZCX.clearRect(0, 0, z.w, z.h);
  z.draw(ZCX);
  var r = box.getBoundingClientRect();
  ZCV.style.left = clamp(r.left + r.width / 2 - W / 2, 8, Math.max(8, window.innerWidth - W - 8)) + 'px';
  ZCV.style.top = clamp(r.top + r.height / 2 - H / 2, 8, Math.max(8, window.innerHeight - H - 8)) + 'px';
  ZOV.classList.remove('hidden');
}
function zoomHide() { if (ZOV) ZOV.classList.add('hidden'); }
function regZoom(box) {
  if (!box || box._zreg) return; box._zreg = 1;
  box.classList.add('zoomable');
  box.addEventListener('mouseenter', function () { zoomShow(box); });
  box.addEventListener('mouseleave', function () { zoomHide(); });
  box.addEventListener('click', function (e) { e.stopPropagation(); zoomShow(box); });
}
/* どの瞬間をコマにするか */
function m4SnapList(s) {
  var id = s.def.id, L = [], end = s.tEnd();
  if (id === 'm4s1') {
    var C = m41Path(s);
    if (C.start === null) return [{ t: 0.12, label: '外力を加える' }, { t: end * 0.5, label: 'B は平板に当たったまま' }, { t: end, label: 'A と一緒に加速し続ける' }];
    L = [{ t: 0.12, label: '外力を加える' }, { t: end * 0.42, label: 'B が斜面を上がる' }, { t: end * 0.72, label: 'さらに上がる' }];
    L.push(C.top !== null ? { t: C.top, label: '頂点 P に着く', ev: true } : { t: end, label: 'まだ上がり続ける' });
    return L;
  }
  if (id === 'm4s2') {
    var T = 2 * Math.PI / m4Om(), C2 = m42Path(s);
    L = [{ t: 0.003, label: '手が離れる（A の加速度は左向きに最大）' }, { t: T / 4, label: 'ばねが自然の長さ（A の加速度 0）' },
         { t: T / 2, label: 'ばねが最も伸びる（A の加速度は右向きに最大）' }, { t: 3 * T / 4, label: '自然の長さに戻る' }];
    if (C2.left !== null) { L = L.filter(function (q) { return q.t < C2.left - 0.02; }); L.push({ t: C2.left, label: 'B が斜面から離れる瞬間', ev: true }); L.push({ t: Math.min(end, C2.left + 0.15), label: '離れたあと' }); }
    return L;
  }
  var C3 = m43Path(s), tTop = 0, best = -1;
  C3.arr.forEach(function (q, i) { if (q[5] === 1 && q[3] > best) { best = q[3]; tTop = i / M4.H2; } });
  L = [{ t: 0.003, label: '手が離れる' }];
  if (best > 0) L.push({ t: tTop, label: 'C が一番高い所' });
  if (C3.coll) L.push({ t: C3.coll.t + 0.002, label: 'C が平板と衝突', ev: true });
  if (C3.umax) L.push({ t: C3.umax.t, label: 'ばねが最も伸びる' });
  return L;
}
var M4SNAP = { pw: 440, k: 2 };
function m4Snaps(s, R) {
  if (!s._snapBox) {
    var box = el('div', 'stagebox m4snaps');
    box.innerHTML = '<p class="stagetitle">重要な場面の流れ（A と一緒に運動する観測者から見た図）<span class="zhint">🔍 マウスを重ねると拡大</span></p>';
    s._snapCv = el('canvas'); box.appendChild(s._snapCv); s._snapBox = box;
    regZoom(box);
  }
  R.appendChild(s._snapBox);
  var BW = Math.floor(s._snapBox.clientWidth - 10); if (BW < 160) return;   /* 箱の内側の幅（はみ出さないように） */
  var list = m4SnapList(s), n = list.length, cols = 2, rows = Math.ceil(n / cols);
  var pw0 = s.W, ph0 = s.H;                                        /* 図と同じ大きさで描いて、台の周りだけを切り取る */
  var key = [BW, s.ms.showF, JSON.stringify(s.v), JSON.stringify(s.chk || {}), list.length].join('|');
  if (s._snapKey === key) return; s._snapKey = key;
  var keep = { t: s.t, cw: CVW, ch: CVH, id: CVID, rot: s.rot }, crop = null;
  s.rot = true;                                                    /* コマ図はいつも A の上から見た図（台が画面から出ていかない） */
  var imgs = list.map(function (sn) {
    var cv = document.createElement('canvas'), K = M4SNAP.k;
    cv.width = pw0 * K; cv.height = ph0 * K;
    var ctx = cv.getContext('2d'); ctx.setTransform(K, 0, 0, K, 0, 0); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, pw0, ph0);
    CVW = pw0; CVH = ph0; CVID = ''; _fArrows.length = 0;
    s.t = clamp(sn.t, 0, s.tEnd()); s._snap = true;
    try { s.def.draw(s, ctx, pw0, ph0); } catch (e) { /* 描けないコマは空白 */ }
    s._snap = false;
    if (!crop && s._g) { var g = s._g, x0 = Math.max(0, g.xA - 0.3 * g.k), x1 = Math.min(pw0, g.xR + (g.spring ? 1.0 : 0.8) * g.k), y0 = Math.max(0, g.yt - 0.5 * g.k), y1 = Math.min(ph0, g.yg + 0.3 * g.k);
      crop = { x: x0, y: y0, w: x1 - x0, h: y1 - y0 }; }
    return { cv: cv, label: sn.label, ev: !!sn.ev };
  });
  s.t = keep.t; s.rot = keep.rot; CVW = keep.cw; CVH = keep.ch; CVID = keep.id;
  if (!crop) crop = { x: 0, y: 0, w: pw0, h: ph0 };
  var Kc = M4SNAP.k, pw = BW / cols, ph = pw * crop.h / crop.w, TH = 22, H = rows * (ph + TH);
  var paint = function (ctx) {
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, BW, H);
    imgs.forEach(function (im, i) {
      var cx = (i % cols) * pw, cy = Math.floor(i / cols) * (ph + TH);
      ctx.drawImage(im.cv, crop.x * Kc, crop.y * Kc, crop.w * Kc, crop.h * Kc, cx + 2, cy + TH, pw - 4, ph - 2);
      ctx.save(); var fz = 12, tx = (i + 1) + '. ' + im.label; ctx.font = '700 ' + fz + 'px ' + FONT;
      while (fz > 8 && ctx.measureText(tx).width > pw - 8) { fz -= 0.5; ctx.font = '700 ' + fz + 'px ' + FONT; }
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = im.ev ? '#b2560c' : '#31465e'; ctx.fillText(tx, cx + pw / 2, cy + 12); ctx.restore();
      if (i % cols) { ctx.save(); ctx.strokeStyle = '#e6eaef'; ctx.beginPath(); ctx.moveTo(cx, cy + 4); ctx.lineTo(cx, cy + TH + ph - 4); ctx.stroke(); ctx.restore(); }
    });
  };
  var dpr = Math.min(2, Math.max(1, window.devicePixelRatio || 1)), cv = s._snapCv;
  cv.width = Math.round(BW * dpr); cv.height = Math.round(H * dpr); cv.style.width = BW + 'px'; cv.style.height = H + 'px';
  var c2 = cv.getContext('2d'); c2.setTransform(dpr, 0, 0, dpr, 0, 0); paint(c2);
  s._snapBox._z = { w: BW, h: H, draw: paint };
}
