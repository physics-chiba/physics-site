/* =========================================================================
   80_page.js … ページの組み立て（ヒーロー・タブ列・章の扉・セクションのカード・コンテンツ一覧・アドレス）
   デザイン統一キット（momentum-and-collision.html）の骨組みと同じ。
   ========================================================================= */
'use strict';
var MODES = [
  { id: 'mode1', name: '直線上の慣性力', secs: ['m1s1', 'm1s2', 'm1s3', 'm1s4'], rotSwitch: true,
    en: 'Inertial Force on a Straight Line',
    lead: '電車やエレベーターが加速すると、中の人は「押される」「重くなる・軽くなる」と感じる。外（慣性系）から見れば<span class="t-eom">運動方程式</span>、一緒に加速運動する観測者（非慣性系）から見れば慣性力を加えた<span class="t-bal">力のつり合いの式</span>になる。' },
  { id: 'mode2', name: '平面上の慣性力', secs: ['m2s1', 'm2s2', 'm2s3', 'm2s4'], rotSwitch: true, fig: '',   /* fig：説明文の右に置くもの（モード2＝3 両の電車の動画） */
    en: 'Inertial Force in a Plane',
    lead: 'モード①では、加速度も慣性力も重力も<b>一直線上</b>にあり、向きは正負の符号だけで表せた。モード②では、水平に加速する電車の中の振り子や、動かされる斜め台の上の物体のように、慣性力（水平）と重力（鉛直）が<b>違う向き</b>にはたらく。そこで、慣性力を<b>ベクトル</b>として考える。',
    pts: ['<b>慣性力ベクトルの特徴</b>：向きは観測者の加速度 $\\vec{a}$ と逆、大きさは $ma$。どの物体にも同じ向きに、質量に比例してはたらく。この点は<b>重力とそっくり</b>である。',
          '<b>力がつり合っているなら、ベクトル図で考えると楽</b>：たとえば重力・張力・慣性力の 3 力がつり合うとき、3 つの矢印をつなぐと閉じた三角形になる。三角形から、糸の傾き $\\tan\\theta = a/g$ や張力の大きさがすぐ求まる。',
          '<b>重力と慣性力の合力を「見かけの重力」とまとめる</b>：$m\\vec{g}\\,\' = m\\vec{g} + (-m\\vec{a})$。電車の中では、重力加速度が $g\'=\\sqrt{a^2+g^2}$ になり、その向きが傾いたのと同じように考えられるので、振り子の周期や糸を切ったあとの運動を、普通の重力の問題と同じように解ける。',
          '<b>斜面の上の物体</b>は、慣性力も重力も斜面に平行・垂直な向きに分けてから式を立てる。'] },   /* モード①との対比（2026-10-11 千葉さん） */
  { id: 'mode3', name: '円運動のときの慣性力＝遠心力', secs: ['m3s1'], rotSwitch: false,
    en: 'Centrifugal Force as an Inertial Force',
    lead: '円運動する観測者も加速度運動をしている。その観測者から見てはたらいているように見える慣性力が「遠心力」である。<br><a class="mhlink" href="circular-motion.html?rot=1">円運動のページへ（一緒に回転する観測者から見る）→</a>' },
  { id: 'mode4', name: '入試物理（2016 東北大）', tab: '入試物理', secs: ['m4s1', 'm4s2', 'm4s3'], rotSwitch: true, fig: M4_HEAD,   /* タブは「入試物理」だけ。問題・解答のボタンは説明文の右に 1 つずつ */
    en: 'Entrance Exam Problem (Tohoku 2016)',
    lead: '斜面をもつ台 A の上の小球の運動を、A と一緒に運動する観測者（非慣性系）の立場で考える。右の「問題」と「解答と解き方」のボタンで、問題文と解答が開く。<b>まず問題を自分で解いてから</b>、図を動かして確かめよう。右の列の「解き方と答え」も、開くまでは見えない。' }
];
/* モード1 の冒頭：「慣性力とは」（構想メモ 1 ページ目の囲み）を横長に 1 枚 */
var INTRO_M1 = '<div class="card keybox wide"><p class="kt">慣性力とは</p>' +
    '<p class="kdef">加速度 $a$ で運動する観測者から見える<br><b class="kbox">見かけの力</b>。慣性が原因で生じる。</p>' +
    '<div class="kgrid"><div class="kcell"><span class="kl">大きさ</span><b>$ma$</b></div><div class="kcell"><span class="kl">向き</span><b>観測者の加速度の向きと<span class="kred">逆</span></b></div></div>' +
    '<p class="knote">※観測者によって運動状態は異なって見える！　加速運動する観測者からは、慣性力がはたらいているように<u>見える</u>。<br>よって、<b>必ず観測者を図の中に書き込んで考える</b>。かつ解答の際は<b>観測者の立場を明言すること</b>。</p></div>';
/* 【目的】はページの一番下に、全モード共通で（兄弟ページ circular-motion.html と同じ。2026-10-11 千葉さん） */
var PURPOSE = '<div class="card purpose"><p class="lead">【目的】</p><ol>' +
    '<li>加速度 $\\vec{a}$ で運動する観測者から見ると、物体には大きさ $ma$・向きが観測者の加速度と逆の「慣性力」がはたらいているように見えることを理解する。</li>' +
    '<li>外（慣性系）から見た' + '<span class="t-eom">運動方程式</span>' + 'と、一緒に加速運動する観測者（非慣性系）から見た' + '<span class="t-bal">力のつり合いの式</span>' + 'が、同じ結果になることを確かめる。</li>' +
    '<li>図の中に観測者を描き、どの観測者の立場で式を立てるのかをはっきりさせて解けるようになる。</li></ol></div>';
var CIRC = '①②③④⑤⑥⑦⑧⑨';
var GLOBAL = { hideEq: false, rot: true };
/* 右上の「全て：一緒に加速運動する観測者（非慣性系）から見る」は既定で ON（このページは非慣性系から見るのが主役）。
   アドレスに ?rot=0 があれば、最初から OFF */
try { if (/(?:^|[?&])rot=(0|off|false)(?:&|$)/i.test(location.search)) GLOBAL.rot = false; } catch (e) { }
var SIM_BY_ID = {}, MODE_BUILT = {};

function buildPage() {
  var wrap = document.getElementById('wrap'), h = '';
  document.getElementById('hero').innerHTML =
    '<div class="hero-in">' +
      '<div class="hero-top">' +
        '<nav class="crumbs" aria-label="現在地"><a class="crumb-home" href="' + SITE_HOME + '" title="楽楽（らくらく）高校物理のトップページへ"><svg class="atom" viewBox="0 0 32 32" aria-hidden="true"><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#3ea0e0" stroke-width="2"/><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#7b5bd6" stroke-width="2" transform="rotate(60 16 16)"/><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#e07b18" stroke-width="2" transform="rotate(120 16 16)"/><circle cx="16" cy="16" r="3.6" fill="#5aa7ff"/></svg><span>楽楽（らくらく）高校物理</span></a><span class="cs" aria-hidden="true">/</span><a class="crumb" href="' + SITE_HOME + '#sec-mechanics">力学</a><span class="cs" aria-hidden="true">/</span><span class="crumb now" aria-current="page">慣性力</span><span class="kdot"></span><span class="en">Inertial Force &amp; Accelerating Observers</span></nav>' +
        '<div class="topbtns" role="group" aria-label="ページ全体の表示"><button id="btnEq" type="button"></button><button id="btnRot" type="button"></button></div>' +
      '</div>' +
      '<h1 class="hero-title"><span class="t1"><span class="nb">慣性力</span></span><span class="t2">〜外から見るか、一緒に加速して見るか〜</span></h1>' +
      '<div class="introrow">' +
        '<p class="lead2">電車が急発進すると、中の人は後ろに押されたように感じる。このように、加速度運動する観測者から見ると、その加速度の逆に力（慣性力）を受けたように感じる。<br>各シミュレーションで起こる現象を、外から見る観測者と、一緒に加速度運動する観測者の２つの観測者の立場で理解しよう。</p>' +   /* 文は千葉さんの指定どおり（2026-10-12） */
        '<button id="bToc" class="tocbtn" type="button" aria-haspopup="true" aria-expanded="false"><span class="ti" aria-hidden="true"></span>コンテンツ一覧</button>' +
      '</div>' +
      '<div id="tocpanel" class="tocpanel" hidden></div>' +
      '<figure class="stage" aria-label="加速する電車の中の振り子を、外の観測者と、一緒に加速する観測者から見たようす">' +
        '<canvas id="heroCv"></canvas>' +
        '<figcaption class="stagecap"><span class="live" aria-hidden="true"></span><span class="sct">左：外（慣性系）から見ると、小球は張力 $S$ と重力 $mg$ の合力で、電車と一緒に加速する。右：一緒に加速運動する観測者（非慣性系）から見ると、小球は止まって見え、$S$・$mg$・慣性力 $ma$ がつり合っている。</span>' +
        '<span class="stagectl" role="group" aria-label="アニメの操作"><button type="button" class="slow" aria-pressed="false" title="ゆっくり再生">🐢 スロー</button><button type="button" class="pp" aria-label="一時停止"><i></i></button></span></figcaption>' +
      '</figure>' +
      '<ol class="ideas">' +
        '<li><a href="#mode1"><span class="in" aria-label="①"><b>1</b></span><span class="ie">大きさ $ma$・向きは $-\\vec{a}$</span><span class="ij">慣性力：観測者の加速度と逆向き</span><span class="ia" aria-hidden="true">→</span></a></li>' +
        '<li><a href="#mode2"><span class="in" aria-label="②"><b>2</b></span><span class="ie">$g\'=\\sqrt{a^2+g^2}$</span><span class="ij">見かけの重力加速度</span><span class="ia" aria-hidden="true">→</span></a></li>' +
        '<li><a href="#mode3"><span class="in" aria-label="③"><b>3</b></span><span class="ie">$m\\dfrac{v^2}{r}$（遠心力）</span><span class="ij">円運動のときの慣性力</span><span class="ia" aria-hidden="true">→</span></a></li>' +
      '</ol>' +
    '</div>';
  document.getElementById('tabs').innerHTML = '<div class="tabs-in"><div class="navsite"><a class="navhome" href="' + SITE_HOME + '" aria-label="ホーム（楽楽高校物理のトップページ）" title="ホーム（楽楽高校物理のトップページ）"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3.5 10.8 12 4l8.5 6.8" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M6 9.5V20h4.5v-5.5h3V20H18V9.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg></a><button class="navpages" id="bPages" type="button" aria-haspopup="dialog" aria-expanded="false" aria-controls="siteDrawer"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="3.5" width="7" height="7" rx="1.6" fill="currentColor"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.6" fill="currentColor" opacity=".55"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.6" fill="currentColor" opacity=".55"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.6" fill="currentColor"/></svg><span>ページ一覧</span></button></div>' +
    MODES.map(function (m, i) { return '<button class="tab" type="button" data-mode="' + m.id + '"><span class="tn">' + CIRC[i] + '</span><span class="tl">' + (m.tab || m.name) + '</span></button>'; }).join('') +
    '</div><span class="tprog" aria-hidden="true"></span>';

  MODES.forEach(function (m, i) {
    h += '<section class="mode" id="' + m.id + '">' +
      '<header class="modehead' + (m.fig !== undefined ? ' hasfig' : '') + '"><div class="mh-num" aria-hidden="true"><span>' + (i + 1) + '</span></div><div class="mh-body"><p class="mh-en">Chapter ' + String(i + 1).padStart(2, '0') + ' — ' + m.en + '</p>' +
      '<h2><span class="mh-c">' + CIRC[i] + '</span>' + m.name + '</h2><p class="mh-lead">' + m.lead + '</p>' + (m.pts ? '<details class="mh-ptsbox"><summary>このチャプターの要点</summary><ul class="mh-pts">' + m.pts.map(function (q) { return '<li>' + q + '</li>'; }).join('') + '</ul></details>' : '') /* はじめは折りたたむ（2026-10-12 千葉さん） */ + '</div>' + (m.fig !== undefined ? '<div class="mh-fig" id="mhfig_' + m.id + '">' + m.fig + '</div>' : '') + '</header>' + (m.id === 'mode1' ? INTRO_M1 : '') +
      (m.secs.filter(function (sid) { return DEFS[sid]; }).length < 2 ? '' :   /* セクションが 1 つだけのモード（モード3）はシムを選ぶタブを出さない */
      '<div class="seclinks">' + m.secs.filter(function (sid) { return DEFS[sid]; }).map(function (sid) {
        return '<a href="#' + (i + 1) + '-' + DEFS[sid].num + '" data-toc="' + sid + '">' + CIRC[i] + '-' + DEFS[sid].num + '　' + (DEFS[sid].short || DEFS[sid].title) + '</a>'; }).join('') + '</div>') +
      '<div class="modebar" id="mbar_' + m.id + '"></div>';
    if (!m.secs.length) h += '<div class="sec soon"><div class="sL"><p class="secdesc">このモードは、モード1 を確認していただいたあとで作ります。</p></div></div>';
    m.secs.forEach(function (sid) {
      var d = DEFS[sid]; if (!d) return;
      if (d.custom) { h += d.html(CIRC[i]); return; }      /* 1-1 など：セクション独自のレイアウト（d.html で中身、d.build で図を作る） */
      h += '<article class="sec" id="' + sid + '"><div class="sL">' +
        '<div class="sechead"><span class="secnum">' + CIRC[i] + '-' + d.num + '</span><h2>' + d.title + '</h2>' + (d.headExtra || '') + '</div>' +   /* d.headExtra：見出しの右のボタン（モード4 の問題・解答） */
        '<div class="secdesc">' + (d.desc || '') + '</div><div class="simhost" id="simL_' + sid + '"></div></div>' +
        '<div class="sR" id="simR_' + sid + '"></div></article>';
    });
    h += '</section>';
  });
  h += PURPOSE;
  h += '<footer></footer>';
  wrap.innerHTML = h;
  document.title = '慣性力';
  wrap.querySelectorAll('.purpose,.keybox,.colbody,.modehead,.secdesc,.sechead h2,.seclinks a,.gnote').forEach(function (e) { e.innerHTML = mathify(e.innerHTML); });
  document.querySelectorAll('#hero .ideas .ie, #hero .stagecap .sct').forEach(function (e) { e.innerHTML = mathify(e.innerHTML); });
  if (GLOBAL.rot) MODES.forEach(function (m) { if (m.rotSwitch) modeState(m.id).rot = true; });
  setupGlobalButtons();
  if (typeof cmp3Init === 'function') cmp3Init();             /* モード2 の説明文の右の 3 両の電車 */
  MODES.forEach(function (m) { buildModeBar(m); });
  buildToc();
  document.querySelectorAll('#tabs .tab').forEach(function (b) {
    b.addEventListener('click', function () {
      activateMode(b.dataset.mode); history.replaceState(null, '', '#' + modeHash(b.dataset.mode));
      window.scrollTo({ top: Math.min(window.pageYOffset, contentTop()), behavior: 'auto' });
    });
  });
  document.querySelectorAll('.seclinks a[data-toc]').forEach(function (a) {
    a.addEventListener('click', function (ev) { ev.preventDefault(); var sid = a.dataset.toc; history.replaceState(null, '', '#' + addrOf(sid)); scrollToSec(sid); });
  });
  window.addEventListener('hashchange', function () { gotoHash(); });
  gotoHash(true);
  if (document.fonts && document.fonts.load) {
    Promise.all(['italic 17px KaTeX_Math', '16px KaTeX_Main'].map(function (f) { return document.fonts.load(f); })).then(function () { SIMS.forEach(function (s) { s.draw(); }); });
  }
}

/* モードの見出しの下：「表示：力を表示」＋（モード2・3）観測者の切りかえスイッチ */
function buildModeBar(m) {
  var bar = document.getElementById('mbar_' + m.id); if (!bar) return;
  var ms = modeState(m.id);
  ms.showF = true;                                       /* 力を表示：既定は ON */
  bar.appendChild(el('span', 'lbl', '表示：'));
  var lab = el('label', 'chk'); var cb = el('input'); cb.type = 'checkbox'; cb.checked = ms.showF; cb.className = 'showf';
  cb.addEventListener('change', function () { ms.showF = cb.checked; SIMS.forEach(function (s) { if (s.mode === m.id) s.draw(); }); });
  lab.appendChild(cb); lab.appendChild(document.createTextNode(' 力を表示')); bar.appendChild(lab);
  ms._cb = cb;
  if (m.rotSwitch) {
    /* モード全体の観測者の切りかえ（各シムと同じ対のボタン。アドレスは #mode2-rot） */
    var rw = el('span', 'rotsw'); rw.appendChild(el('span', 'lbl', '全セクション：'));
    var sg = el('div', 'seg'); sg.setAttribute('role', 'group'); sg.setAttribute('aria-label', '全セクションをどの観測者から見るか');
    var b0 = el('button', 'b obs', OBS_IN), b1 = el('button', 'b obs rotb', OBS_ROT);
    [b0, b1].forEach(function (b, i) { b.type = 'button'; b.addEventListener('click', function () { setModeRot(m.id, i === 1); }); sg.appendChild(b); });
    rw.appendChild(sg); bar.appendChild(rw); ms._segb = [b0, b1];
    b0.classList.toggle('on', !ms.rot); b1.classList.toggle('on', !!ms.rot);
  }
}
function syncModeBar(mid) {
  var ms = modeState(mid); if (ms._cb) ms._cb.checked = ms.showF;
  SIMS.forEach(function (s) { if (s.mode === mid && s.extra && s.extra.showF) { s.extra.showF.classList.toggle('on', ms.showF); s.extra.showF.setAttribute('aria-pressed', ms.showF ? 'true' : 'false'); } });
  SIMS.forEach(function (s) { if (s.mode === mid) s.draw(); });
}

function syncGlobalButtons() {
  var bE = document.getElementById('btnEq');
  bE.innerHTML = '<span class="sw" aria-hidden="true"><i></i></span><span class="swl">式・考え方エリアを閉じる</span><span class="swv">' + (GLOBAL.hideEq ? 'ON' : 'OFF') + '</span>';
  bE.setAttribute('aria-pressed', GLOBAL.hideEq ? 'true' : 'false'); bE.classList.toggle('off', !GLOBAL.hideEq);
  document.body.classList.toggle('hideeq', GLOBAL.hideEq);
  var bR = document.getElementById('btnRot');
  if (bR) {
    bR.innerHTML = '<span class="sw" aria-hidden="true"><i></i></span><span class="swl two">全て：一緒に加速運動する観測者<br>（非慣性系）から見る</span><span class="swv">' + (GLOBAL.rot ? 'ON' : 'OFF') + '</span>';
    bR.setAttribute('aria-pressed', GLOBAL.rot ? 'true' : 'false'); bR.classList.toggle('off', !GLOBAL.rot);
  }
}
function setupGlobalButtons() {
  var bE = document.getElementById('btnEq');
  bE.addEventListener('click', function () {
    GLOBAL.hideEq = !GLOBAL.hideEq; syncGlobalButtons();
    SIMS.forEach(function (s) { if (s.cv.offsetParent) { s.resize(); s.draw(); } });
  });
  var bR = document.getElementById('btnRot');
  bR.addEventListener('click', function () { setGlobalRot(!GLOBAL.rot); });
  syncGlobalButtons();
}
/* 全てのモード（観測者を切りかえられるモード）の切りかえを、まとめて ON／OFF */
function setGlobalRot(on) {
  GLOBAL.rot = on;
  MODES.forEach(function (m) { if (m.rotSwitch) setModeRot(m.id, on, true); });
  syncGlobalButtons();
}
/* どれか 1 つの切りかえを変えたら、右上の表示もそろえる（全部が非慣性系なら ON） */
function syncGlobalRot() {
  var rm = MODES.filter(function (m) { return m.rotSwitch; }).map(function (m) { return m.id; });
  var all = rm.every(function (id) { return !!modeState(id).rot; }) && SIMS.every(function (s) { return rm.indexOf(s.mode) < 0 || !!s.rot; });
  if (GLOBAL.rot !== all) { GLOBAL.rot = all; syncGlobalButtons(); }
}
function modeHash(mid) { var ms = modeState(mid); return mid + (ms.rot ? '-rot' : ''); }
function activateMode(id) {
  var m = MODES.find(function (x) { return x.id === id; }); if (!m) return;
  document.querySelectorAll('#tabs .tab').forEach(function (b) { b.classList.toggle('on', b.dataset.mode === id); });
  document.querySelectorAll('.mode').forEach(function (s) { s.classList.toggle('on', s.id === id); });
  SIMS.forEach(function (s) { if (s.mode !== id && s.playing) { s.playing = false; s.syncPlayLabel(); } });
  if (!MODE_BUILT[id]) {
    MODE_BUILT[id] = 1;
    m.secs.forEach(function (sid) {
      var d = DEFS[sid]; if (!d) return;
      if (d.custom) { d.build(document.getElementById(sid)); return; }
      SIM_BY_ID[sid] = new Sim(d, document.getElementById('simL_' + sid), document.getElementById('simR_' + sid));
    });
  } else SIMS.forEach(function (s) { if (s.mode === id) { s.resize(); s.draw(); } });
}
var hasDef = function (k) { return Object.prototype.hasOwnProperty.call(DEFS, k); };
function addrOf(sid) {
  var i = MODES.findIndex(function (x) { return x.secs.indexOf(sid) >= 0; });
  return (i < 0 || !hasDef(sid)) ? sid : (i + 1) + '-' + DEFS[sid].num;
}
/* アドレス：#mode1／#mode2／#mode2-rot（非慣性系で始める）／#1-1 のようなセクション */
function parseHash(hs) {
  hs = String(hs || '').replace('#', '');
  var m = /^(mode\d)(-rot)?$/.exec(hs);
  if (m) { var mo = MODES.find(function (x) { return x.id === m[1]; }); return mo ? { mode: mo, rot: !!m[2] } : {}; }
  var q = /^(\d+)-(\d+)$/.exec(hs);
  if (q) { var mo2 = MODES[+q[1] - 1]; if (mo2) { var sid = mo2.secs.find(function (s) { return hasDef(s) && String(DEFS[s].num) === q[2]; }); return sid ? { mode: mo2, sec: sid } : { mode: mo2 }; } }
  return {};
}
function contentTop() { var h = document.getElementById('hero'); return h ? h.offsetTop + h.offsetHeight : 0; }
function tabbarH() { var tb = document.getElementById('tabs'); if (!tb) return 0; return (getComputedStyle(tb).position === 'sticky') ? tb.getBoundingClientRect().height : 0; }
function scrollToSec(sid) {
  var go = function () { var e = document.getElementById(sid); if (!e) return; var y = e.getBoundingClientRect().top + window.pageYOffset - tabbarH() - 8; window.scrollTo({ top: Math.max(0, y), behavior: 'auto' }); };
  go(); requestAnimationFrame(function () { requestAnimationFrame(go); }); setTimeout(go, 180);
}
function buildToc() {
  var p = document.getElementById('tocpanel'), b = document.getElementById('bToc'); if (!p || !b) return;
  var h = '<div class="tochead"><b>コンテンツ一覧</b><button type="button" class="tocx" aria-label="閉じる">×</button></div>';
  MODES.forEach(function (m, i) {
    h += '<div class="tocmode">' + CIRC[i] + ' ' + m.name + '</div><ul>';
    m.secs.forEach(function (sid) { var d = DEFS[sid]; if (!d) return;
      h += '<li><a href="#' + addrOf(sid) + '" data-toc="' + sid + '">' + CIRC[i] + '-' + d.num + '　' + mathify(String(d.title).replace(/<[^>]+>/g, '')) + '</a></li>'; });
    if (!m.secs.length) h += '<li><a href="#' + m.id + '" data-tocm="' + m.id + '">（準備中）</a></li>';
    h += '</ul>';
  });
  p.innerHTML = h;
  var close = function () { p.hidden = true; b.setAttribute('aria-expanded', 'false'); };
  b.addEventListener('click', function (ev) { ev.stopPropagation(); p.hidden = !p.hidden; b.setAttribute('aria-expanded', p.hidden ? 'false' : 'true'); });
  p.querySelector('.tocx').addEventListener('click', close);
  document.addEventListener('click', function (ev) { if (!p.hidden && !p.contains(ev.target) && ev.target !== b) close(); });
  document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape') close(); });
  p.querySelectorAll('[data-toc]').forEach(function (a) {
    a.addEventListener('click', function (ev) {
      ev.preventDefault(); close();
      var sid = a.getAttribute('data-toc'), mo = MODES.find(function (x) { return x.secs.indexOf(sid) >= 0; }); if (!mo) return;
      activateMode(mo.id); history.replaceState(null, '', '#' + addrOf(sid)); scrollToSec(sid);
    });
  });
  p.querySelectorAll('[data-tocm]').forEach(function (a) {
    a.addEventListener('click', function (ev) { ev.preventDefault(); close(); activateMode(a.dataset.tocm); history.replaceState(null, '', '#' + a.dataset.tocm); window.scrollTo({ top: contentTop(), behavior: 'auto' }); });
  });
}
function gotoHash(first) {
  var q = parseHash(location.hash);
  if (!q.mode) { if (first) activateMode(MODES[0].id); return; }
  if (first && GLOBAL.rot && q.rot === false) q.rot = true;            /* ?rot=1 のときは、#mode2 などでも非慣性系で始める */
  if (q.rot !== undefined && q.mode.rotSwitch) { modeState(q.mode.id).rot = q.rot; }
  activateMode(q.mode.id);
  if (q.rot !== undefined && q.mode.rotSwitch) setModeRot(q.mode.id, q.rot, true);
  if (q.sec) scrollToSec(q.sec);
  else if (!first) window.scrollTo({ top: contentTop(), behavior: 'auto' });
  else if (location.hash) scrollToSec(q.mode.id);
}

document.addEventListener('DOMContentLoaded', function () { buildPage(); });
