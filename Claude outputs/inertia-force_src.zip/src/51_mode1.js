/* =========================================================================
   51_mode1.js … モード1「直線上の慣性力」
   1-1 電車とエレベーター（図を 2 つ並べる。操作は上で共通、再生は図ごと）
   1-2 エレベーターで上昇・下降する小球（糸を切る）
   1-3 エレベーターで上昇・下降するはかり
   ・非慣性系では、電車（エレベーター）を画面に止め、地面・建物・外の観測者を動かす。
   ・慣性力（オレンジの太い破線）は非慣性系だけに描く。
   ・スタートを押してから加速が始まる（aEff：t = 0 では加速度 0 の見え方）。
   ========================================================================= */
'use strict';

/* ===================== 1-1 左：電車 ===================== */
var TR = { L: 2.8, Hb: 1.55, lift: 0.42, wr: 0.2 };
/* 空き缶（2026-10-11 千葉さん）：人の横の床に置く。床はなめらかで、空き缶は床をすべる（摩擦なし）とする。
   外から見ると、空き缶には水平な力がはたらかないので、はじめの速度のまま（静止なら静止のまま）。
   電車の中から見ると u″ = −a（慣性力で後ろへ動く）。電車の壁に当たったら、壁といっしょに動く（はね返らない） */
var CAN = { u0: 2.05, r: 0.17 };
function canPath(s) {
  var key = segKey(s), C = s._can;
  if (C && C.key === key) return C;
  var h = 1 / 1000, u = CAN.u0, v = 0, t = 0, lo = 0.06 + CAN.r, hi = TR.L - 0.06 - CAN.r, arr = [], wall = 0;
  while (t <= s.def.TW + 1e-9) {
    var a = aAt(s, t + 1e-9);
    arr.push([u, wall, a]);
    if (wall === 0 || (wall < 0 && -a > 0) || (wall > 0 && -a < 0)) { wall = 0; v += -a * h; u += v * h; }
    if (u <= lo) { u = lo; v = 0; wall = -1; } else if (u >= hi) { u = hi; v = 0; wall = 1; }
    t += h;
  }
  C = s._can = { key: key, arr: arr };
  return C;
}
function canAt(s, t) { var C = canPath(s), i = clamp(Math.round(t * 1000), 0, C.arr.length - 1), q = C.arr[i]; return { u: q[0], wall: q[1], a: q[2] }; }
/* 空き缶の絵（横にねかせた缶を、底のほうから見た円） */
function drawCan(ctx, x, y, r) {
  ctx.save(); ctx.beginPath(); ctx.arc(x, y, r, 0, TAU);
  var g = ctx.createRadialGradient(x - r * .3, y - r * .35, r * .1, x, y, r); g.addColorStop(0, '#e6eefa'); g.addColorStop(1, '#8fb0d8');
  ctx.fillStyle = g; ctx.fill(); ctx.strokeStyle = '#3d5f8c'; ctx.lineWidth = 1.6; ctx.stroke();
  ctx.beginPath(); ctx.arc(x, y, r * 0.72, 0, TAU); ctx.strokeStyle = 'rgba(61,95,140,.45)'; ctx.lineWidth = 1; ctx.stroke();
  ctx.restore();
  label(ctx, '空き缶', x, y - r - 9, { size: 10.5, bold: true, color: '#3d5f8c' });
}
function trainSay(s) {
  var a = aEff(s), v = velOf(s, s.t), cn = canAt(s, s.t), v0 = v0Of(s);
  if (s.rot) {
    if (Math.abs(a) < 1e-9) return '何も感じない。空き缶も止まったままだ';
    if (cn.wall) return (a > 0 ? '後ろ' : '前') + '向きの力を感じる。空き缶は壁で止まった';
    return (a > 0 ? '後ろ' : '前') + '向きの力を感じる。空き缶も' + (a > 0 ? '後ろ' : '前') + 'へ動いていく！';
  }
  if (Math.abs(a) < 1e-9) return Math.abs(v) < 1e-9 ? '電車も人も空き缶も止まってるなあ' : '電車も空き缶も一定の速さで進んでるなあ';
  if (cn.wall) return '空き缶は電車の壁に押されて動き出した';
  return Math.abs(v0) < 1e-9 ? '電車は動くけど、空き缶は止まったままだ' : '空き缶は同じ速さのまま。電車だけが速さを変えてる';
}
function drawTrain(s, ctx, W, H) {
  var k = W / 9.4, yg = H - 50, a = aEff(s), t = s.t, X = dispOf(s, t), R = rangeOf(s), WW = W / k;
  var obsLeft = (R.lo + R.hi) >= -1e-9;
  var av = obsLeft ? [1.7, WW - 0.3 - TR.L] : [0.3, WW - 1.7 - TR.L];
  var xL0 = clamp((av[0] + av[1]) / 2 - (R.lo + R.hi) / 2, av[0] - R.lo, av[1] - R.hi);
  var obsX = obsLeft ? 0.85 : WW - 0.85;
  var sh = s.rot ? -X * k : 0, SX = function (xw) { return xw * k + sh; };
  posNote(ctx, W, '右向き', 'right');
  /* 架線の柱（2 m おき）：地面といっしょに動く */
  ctx.save(); ctx.strokeStyle = '#d9d3c7'; ctx.lineWidth = 2;
  for (var q = Math.floor(-sh / k / 2) * 2 - 2; q * k + sh < W + 20; q += 2) {
    var px = SX(q + 0.5); ctx.beginPath(); ctx.moveTo(px, yg); ctx.lineTo(px, yg - 2.35 * k); ctx.lineTo(px + 0.35 * k, yg - 2.35 * k); ctx.stroke();
  }
  ctx.restore();
  groundShift(ctx, 0, W, yg, sh);
  /* 外の観測者（地面に立つ） */
  var hdIn = null, ox = SX(obsX);
  if (ox < -8 || ox > W + 8) offMarker(ctx, W, H, ox, yg + 15, NAME_IN, !s.rot);
  else hdIn = observer(ctx, ox, yg, 0, -1, NAME_IN, !s.rot, 1.7 * k);
  /* 電車 */
  var tx = (xL0 + (s.rot ? 0 : X)) * k, tw = TR.L * k, yb = yg - TR.lift * k, yt = yb - TR.Hb * k;
  ctx.save(); ctx.fillStyle = 'rgba(255,255,255,.93)'; ctx.strokeStyle = COL.ink; ctx.lineWidth = 2.2;
  ctx.beginPath(); ctx.rect(tx, yt, tw, TR.Hb * k); ctx.fill(); ctx.stroke();
  ctx.lineWidth = 3; ctx.strokeStyle = '#2b5f8a'; ctx.beginPath(); ctx.moveTo(tx, yb); ctx.lineTo(tx + tw, yb); ctx.stroke();
  ctx.restore();
  [0.5, TR.L - 0.5].forEach(function (u) { ctx.save(); ctx.beginPath(); ctx.arc(tx + u * k, yg - TR.wr * k, TR.wr * k, 0, TAU); ctx.fillStyle = '#fff'; ctx.fill(); ctx.strokeStyle = COL.ink; ctx.lineWidth = 1.8; ctx.stroke(); ctx.restore(); });
  label(ctx, '電車', tx + 22, yt + 12, { size: 11, color: COL.sub });
  var cn = canAt(s, t), cr = CAN.r * k, cx = tx + cn.u * k, cy = yb - cr - 1.5;
  /* 座席（背もたれは後ろ＝左） */
  var sbx = tx + 0.62 * k, seatY = yb - 0.45 * k;
  ctx.save(); ctx.fillStyle = '#e9e4da'; ctx.strokeStyle = '#8d9097'; ctx.lineWidth = 1.2;
  ctx.beginPath(); ctx.rect(sbx - 0.12 * k, yb - 1.08 * k, 0.12 * k, 1.08 * k); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.rect(sbx, seatY, 0.5 * k, 0.1 * k); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(sbx + 0.25 * k, seatY + 0.1 * k); ctx.lineTo(sbx + 0.25 * k, yb); ctx.stroke();
  ctx.restore();
  var col = s.rot ? COL.vel : '#9aa3ac';
  var pm = seatedMan(ctx, sbx + 0.16 * k, seatY, 1.25 * k, col, s.rot ? 2.4 : 1.7, s.rot ? 1 : OBS_DIM);
  drawCan(ctx, cx, cy, cr);                                   /* 空き缶は人と座席の手前に描く（かくれないように） */
  label(ctx, NAME_ROT + (s.rot ? '（いまの視点）' : ''), tx + tw / 2, yg + 34, { size: s.rot ? 11.5 : 10.5, bold: s.rot, color: col });
  /* 加速度（構想メモの太い矢印）と速度 */
  if (Math.abs(a) > 1e-9) { var dir = a > 0 ? 1 : -1, La = 22 + 5 * Math.abs(a), bx0 = tx + tw * 0.55 - dir * La / 2;
    blockArrow(ctx, bx0, yt - 62, dir, 0, La, '電車の加速度 a' + (a > 0 ? '（右向き）' : '（左向き）'), { x: tx + tw * 0.55, y: yt - 84 }); }
  else label(ctx, s.v.still ? '電車は静止している' : '電車は等速で動いている（加速度 0）', tx + tw / 2, yt - 62, { size: 11.5, color: COL.sub });
  if (!s.rot) { var v = velOf(s, t); if (Math.abs(v) > 0.01) velAt(ctx, tx + tw * 0.5, yt - 16, v > 0 ? 1 : -1, 0, Math.abs(v) * 10 * k / 60, [0, -2]); }
  /* 力（人にはたらく水平な力）：座席からの力 F と、非慣性系だけ慣性力 */
  if (s.ms.showF && Math.abs(a) > 1e-9) {
    var F = P.trainF(P.mP, a), fsc = 0.12 * k / 60;
    if (a > 0) forceArrow(ctx, pm.back[0], pm.back[1], 1, 0, F * fsc, COL.norm, 'F', 'above');
    else forceArrow(ctx, pm.seat[0], pm.seat[1] - 2, -1, 0, -F * fsc, COL.fric, 'F', 'above');
    if (s.rot) forceArrow(ctx, pm.cx, pm.cy - 0.18 * k, a > 0 ? -1 : 1, 0, Math.abs(F) * fsc, COL.inert, '慣性力', a > 0 ? 'left' : 'right', 'fict');
    /* 空き缶にはたらく水平な力：中から見ると慣性力。壁に当たっていれば、壁からの力（外から見ても中から見ても） */
    var Lc = 10 + 0.32 * k * Math.abs(a) / G, dc = a > 0 ? -1 : 1;
    if (s.rot) forceArrow(ctx, cx, cy, dc, 0, Lc, COL.inert, '慣性力', dc < 0 ? 'left' : 'right', 'fict');
    if (cn.wall) forceArrow(ctx, cx - dc * cr, cy + 3, -dc, 0, Lc, COL.norm, '', '');
  }
  if (s.ms.showF && !s.rot && Math.abs(a) > 1e-9 && !cn.wall) label(ctx, '水平な力ははたらかない', cx, cy + cr + 12, { size: 10, color: '#3d5f8c' });
  drawEqualTicks(ctx);
  /* セリフ */
  if (s.rot) speech(ctx, trainSay(s), pm);
  else if (hdIn) speech(ctx, trainSay(s), hdIn);
}
function rightTrain(s, R) {
  var a = s.v.a, F = P.trainF(P.mP, a);
  R.innerHTML = mathify(ifSetup(s, {
    title: '電車の中の人',
    lead: { in: '外から見ると、人は電車と一緒に加速度 $a$ で運動している。人を加速させているのは、座席から受ける水平な力 $F$（$a>0$ なら背もたれが押す力、$a<0$ なら座面の摩擦力）。',
            rot: '電車の中の観測者には、人は止まって見える。人には座席からの力 $F$ と、加速度と逆向きの<b>慣性力 $ma$</b> がはたらき、つり合っている。だから「' + (a > 0 ? '後ろ' : (a < 0 ? '前' : '')) + (a !== 0 ? '向きの力を感じる' : '何も感じない') + '」。' },
    rows: [{ dir: '水平方向（右向き正）', in: ['eom', 'ma = F'], rot: ['bal', 'F - ma = 0'] },
           { dir: '鉛直方向', in: ['bal', 'N - mg = 0'], rot: ['bal', 'N - mg = 0'] }],
    now: { in: tex('F = ma = ' + P.mP + '\\times' + sgnTex(a, 0) + ' = ' + f1(F) + '\\ \\text{N}'),
           rot: tex('F = ma = ' + f1(F) + '\\ \\text{N}') + '（慣性力の大きさも ' + tex(f1(Math.abs(F))) + ' N）' }
  }) + '<div class="qcard derive"><p class="qt">空き缶の動きから分かること</p>' +
    '<p>床はなめらかとする。<b>外から見ると</b>、空き缶には水平な力が何もはたらかないので、電車が加速しても空き缶は<b>止まったまま</b>（はじめの速度のまま）。動いているのは電車のほうである。</p>' +
    '<p><b>電車の中から見ると</b>、空き缶は加速度と逆向きに動き出す。中の観測者には「慣性力 $ma$ に押された」ように見えるが、それを押している物は何もない。慣性力は、加速する観測者から見たときだけ現れる<b>見かけの力</b>である。</p></div>' +
    '<p class="assume">人の質量 ' + tex('m=' + P.mP) + ' kg。鉛直方向の力（重力と座面の垂直抗力）は図では省いた。空き缶は床をすべる（摩擦なし）とし、電車の壁に当たったら壁と一緒に動くとした。</p>');
}
DEFS.m1tr = ifBase({
  id: 'm1tr', V0: P.V0T, TW: P.TW,
  height: function (s, w) { return Math.round(clamp(w * 0.56, 230, 360)); },
  onPair: function (s, still) { var B = SIM_BY_ID.m1el; if (!B) return;
    if (still) { B.v.a = 0; B.v.still = true; B.aSeg = null; B.changed('still'); } else { applyA(B, s.v.a); B.changed('a'); } },
  onRot: function (s, on) { var B = SIM_BY_ID.m1el; if (B && B.rot !== on) setRot(B, on); },
  onDefaults: function (s) { var B = SIM_BY_ID.m1el; if (B) B.toDefaults(); },
  msg: function (s) {
    var a = s.v.a;
    if (Math.abs(a) < 1e-9) return s.rot ? '加速度 0 なので慣性力は 0。電車の中の人は何も感じない（' + (s.v.still ? '静止' : '等速') + 'でも同じ）。' : (s.v.still ? '電車は止まっている。' : '電車は一定の速さで進んでいる（等速直線運動・加速度 0）。');
    return s.rot ? '電車の中から見ると、人には加速度と<b>逆向き</b>の慣性力 $ma$ がはたらいているように見える。' : '外から見ると、人は座席からの力 $F$ で電車と一緒に加速している。慣性力はない。';
  },
  draw: drawTrain, right: rightTrain
});

/* ===================== エレベーター（1-1 右・1-2・1-3 で共通の舞台） ===================== */
var EL = { W: 2.6, H: 2.4, TW: 0.8 };
/* 加速度の目盛りすべて・静止／等速のうち、いちばん大きく動く幅（縮尺を固定するため） */
function maxSpan(V0, TW) { var m = V0 * TW; P.AST.forEach(function (a) { var r = P.range(0, a, TW); m = Math.max(m, r.hi - r.lo); }); return m; }   /* 加速するときは止まった状態から */
function elevScene(s, ctx, W, H, inner) {
  var a = aEff(s), t = s.t, X = dispOf(s, t), R = rangeOf(s);
  /* 縮尺：一緒に動く観測者から見るときは、かごは止まっているのでかごに合わせて大きく。
     外から見るときは、いまの加速度でかごが動く範囲に合わせる（2026-10-11：½gt²・½at² を図に書くので大きく見せる） */
  var span = s.rot ? 0.9 : (R.hi - R.lo) + 0.3;
  var k = Math.min((H - 70) / (span + EL.H), W / 6.3);
  var cxS = clamp(W * 0.56, 0.5 * EL.W * k + 150, W - 0.5 * EL.W * k - 120), cl = cxS - EL.W * k / 2, cr = cxS + EL.W * k / 2;
  var top = 30, bot = H - 40, mid = s.rot ? EL.H / 2 : (R.lo + R.hi + EL.H) / 2, Y0 = (top + bot) / 2 + mid * k;   /* 非慣性系：かごは止まって見えるので、まん中に置く */
  var sh = s.rot ? X * k : 0;                                 /* 非慣性系：建物と外の観測者がずれる */
  var yFloor = Y0 - (s.rot ? 0 : X * k), yCeil = yFloor - EL.H * k;
  posNote(ctx, W, '上向き', 'up');
  /* 昇降路の壁と 1 m ごとの目もり（建物といっしょに動く） */
  ctx.save(); ctx.strokeStyle = '#c4beb2'; ctx.lineWidth = 1.4;
  ctx.beginPath(); ctx.moveTo(cl - 6, 0); ctx.lineTo(cl - 6, H); ctx.moveTo(cr + 6, 0); ctx.lineTo(cr + 6, H); ctx.stroke();
  ctx.lineWidth = 1; for (var q = -12; q <= 12; q++) { var yq = Y0 - q * k + sh; if (yq < -4 || yq > H + 4) continue;
    ctx.beginPath(); ctx.moveTo(cl - 14, yq); ctx.lineTo(cl - 6, yq); ctx.moveTo(cr + 6, yq); ctx.lineTo(cr + 14, yq); ctx.stroke(); }
  ctx.restore();
  /* 外の観測者が立つ床（t = 0 のエレベーターの床の高さ） */
  var yP = Y0 + sh, ox = cl - 0.95 * k, hdIn = null;
  if (yP > -6 && yP < H + 12) { ctx.save(); ctx.beginPath(); ctx.rect(0, 0, cl - 6, H); ctx.clip(); groundShift(ctx, 0, cl - 6, yP, 0); ctx.restore(); }
  if (yP < 8 || yP - 1.7 * k > H - 4) offMarker(ctx, W, H, ox, yP - 0.85 * k, NAME_IN, !s.rot);
  else hdIn = observer(ctx, ox, yP, 0, -1, NAME_IN, !s.rot, 1.65 * k);
  /* ロープ・かご */
  ctx.save(); ctx.strokeStyle = '#8d9097'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(cxS, 0); ctx.lineTo(cxS, yCeil); ctx.stroke();
  ctx.fillStyle = 'rgba(255,255,255,.95)'; ctx.strokeStyle = COL.ink; ctx.lineWidth = 2.4; ctx.beginPath(); ctx.rect(cl, yCeil, cr - cl, EL.H * k); ctx.fill(); ctx.stroke();
  ctx.strokeStyle = '#2b5f8a'; ctx.lineWidth = 3.2; ctx.beginPath(); ctx.moveTo(cl, yFloor); ctx.lineTo(cr, yFloor); ctx.stroke();
  ctx.restore();
  var g = { k: k, cl: cl, cr: cr, cx: cxS, yFloor: yFloor, yCeil: yCeil, hdIn: hdIn, sh: sh };
  var ret = inner(g) || {};
  /* 加速度（太い矢印）・速度（慣性系だけ） */
  var bxA = cr + 0.95 * k, ym = (yFloor + yCeil) / 2;
  if (Math.abs(a) > 1e-9) { var dir = a > 0 ? -1 : 1, La = 22 + 5 * Math.abs(a);
    blockArrow(ctx, bxA, ym - dir * La / 2, 0, dir, La, 'エレベーターの\n加速度 a' + (a > 0 ? '（上向き）' : '（下向き）'), { x: bxA + 14, y: ym + dir * La / 2 + dir * 22, align: 'left' }); }
  else label(ctx, s.v.still ? '静止' : '等速（加速度 0）', bxA - 6, ym, { size: 11.5, color: COL.sub, align: 'left' });
  if (!s.rot) { var v = velOf(s, t); if (Math.abs(v) > 0.01) velAt(ctx, cr + 0.42 * k, ym, 0, v > 0 ? -1 : 1, Math.abs(v) * 12 * k / 60, [10, 0]); }
  g.ret = ret;
  return g;
}
/* かごの中の観測者の名前（かごの天井の上） */
function innerName(ctx, g, s) {
  label(ctx, NAME_ROT + (s.rot ? '（いまの視点）' : ''), g.cx, g.yCeil - 12, { size: s.rot ? 11.5 : 10.5, bold: s.rot, color: s.rot ? COL.vel : '#9aa3ac' });
}

/* ===================== 1-1 右：エレベーターの中の人 ===================== */
function elevSay(s) {
  var a = aEff(s), v = velOf(s, s.t);
  if (s.rot) return a <= -G + 1e-9 ? '無重力だなあ！' : (a < 0 ? 'なんかふわっとしたなあ' : (a > 0 ? 'ずしっと重くなったなあ' : 'いつもと同じ重さだなあ'));
  if (a <= -G + 1e-9) return 'あの人、自由落下してる！';
  if (a < 0) return 'あの人、下に加速してる！';
  if (a > 0) return 'あの人、上に加速してる！';
  return Math.abs(v) < 1e-9 ? 'あの人、止まってる' : 'あの人、一定の速さで上がってる';
}
function drawElev1(s, ctx, W, H) {
  elevScene(s, ctx, W, H, function (g) {
    var k = g.k, px = g.cx - 0.25 * EL.W * k, hgt = 1.65 * k;
    var hd = observer(ctx, px, g.yFloor, 0, -1, '', s.rot, hgt);
    innerName(ctx, g, s);
    if (s.ms.showF) {
      var a = aEff(s), m = P.mP, fsc = 0.11 * k / 63, cy = g.yFloor - hgt * 0.5;
      forceArrow(ctx, px, cy, 0, 1, m * G * fsc, COL.force, 'mg', 'below');
      forceArrow(ctx, px, g.yFloor, 0, -1, P.elevN(m, a) * fsc, COL.norm, 'N', 'right');
      if (s.rot && Math.abs(a) > 1e-9) forceArrow(ctx, px + 16, cy, 0, a > 0 ? 1 : -1, m * Math.abs(a) * fsc, COL.inert, '慣性力', 'right', 'fict');   /* N と重ならないよう横にずらす */
    }
    drawEqualTicks(ctx);
    if (s.rot) speech(ctx, elevSay(s), hd, 'right');
    else if (g.hdIn) speech(ctx, elevSay(s), g.hdIn);
  });
}
/* 重く・軽く感じるわけ（垂直抗力 N の大きさ） */
function elevFeel(a) {
  if (a > 0) return '<p class="qfeel">ずしっと重く感じるのは、床から受ける<b>垂直抗力 $N$ が $mg$ より大きくなった</b>から（$N = m(g+a) > mg$）。</p>';
  if (a < 0) return '<p class="qfeel">ふわっと軽く感じるのは、床から受ける<b>垂直抗力 $N$ が $mg$ より小さくなった</b>から（$N = m(g+a) < mg$）。' + (a <= -G + 1e-9 ? '$a=-g$ では $N=0$（無重力状態）。' : '') + '</p>';
  return '<p class="qfeel">加速度 0 なら $N = mg$。いつもと同じ重さに感じる。</p>';
}
function rightElev1(s, R) {
  var a = s.v.a, m = P.mP, N = P.elevN(m, a);
  R.innerHTML = mathify(ifSetup(s, {
    title: 'エレベーターの中の人',
    lead: { in: '外から見ると、人はエレベーターと一緒に加速度 $a$ で運動している。人にはたらく力は重力 $mg$ と床からの垂直抗力 $N$ だけ。',
            rot: 'エレベーターの中の観測者には、人は止まって見える。重力 $mg$・垂直抗力 $N$ に、加速度と逆向きの<b>慣性力 $ma$</b> が加わってつり合う。' +
              (a > 0 ? '慣性力が下向きなので、床を強く押す（ずしっと重い）。' : (a < 0 ? '慣性力が上向きなので、床を押す力が弱くなる（ふわっとする）。' : '')) },
    rows: [{ dir: '鉛直方向（上向き正）', in: ['eom', 'ma = N - mg'], rot: ['bal', 'N - mg - ma = 0'] }],
    now: { in: tex('N = m(g+a) = ' + m + '\\times(9.8' + (a < 0 ? '-' : '+') + Math.abs(a) + ') = ' + f1(N) + '\\ \\text{N}'),
           rot: tex('N = mg + ma = ' + f1(m * G) + (a < 0 ? '-' : '+') + f1(Math.abs(m * a)) + ' = ' + f1(N) + '\\ \\text{N}') },
    note: { in: elevFeel(a) + frameNote(false), rot: elevFeel(a) + frameNote(true) }
  }) + '<p class="assume">人の質量 ' + tex('m=' + P.mP) + ' kg、' + tex('g=9.8') + ' m/s²。どちらの観測者から見ても ' + tex('N') + ' の値は同じ。</p>');
}
DEFS.m1el = ifBase({
  id: 'm1el', V0: P.V0E, TW: EL.TW, bare: true,
  height: function (s, w) { return Math.round(clamp(w * 0.74, 340, 460)); },
  msg: function (s) {
    var a = s.v.a;
    if (Math.abs(a) < 1e-9) return s.rot ? '加速度 0 なので慣性力は 0。いつもと同じ重さに感じる。' : (s.v.still ? 'エレベーターは止まっている。' : 'エレベーターは一定の速さで上がっている（加速度 0）。');
    return s.rot ? 'エレベーターの中から見ると、人には加速度と<b>逆向き</b>の慣性力 $ma$ がはたらいているように見える（' + (a > 0 ? '下向き' : '上向き') + '）。' :
      '外から見ると、人は $N - mg$ の合力で加速している（$N=' + f1(P.elevN(P.mP, a)) + '$ N）。慣性力はない。';
  },
  draw: drawElev1, right: rightElev1
});

/* 1-1：1 つのセクションに 2 つの図（電車・エレベーター）。上に共通の操作 */
DEFS.m1s1 = {
  id: 'm1s1', num: 1, title: '電車とエレベーター', custom: true,
  html: function (ci) {
    return '<article class="sec secwide pairsec" id="m1s1"><div class="swin">' +
      '<div class="sechead"><span class="secnum">' + ci + '-1</span><h2>電車とエレベーター</h2></div>' +
      '<div class="secdesc">加速度 $a$ で動く電車・エレベーターに、観測者が一緒に乗っている。<span class="todo">加速度を選んで「▶ スタート」を押し、外から見たときと、一緒に加速運動する観測者から見たときを比べよう。</span></div>' +
      '<div class="pairtop" id="pairTop_m1s1"></div>' +
      '<div class="pairgrid"><div class="pfig"><p class="pfh">電車に乗って一緒に加速する観測者（座る人）</p><div class="simhost" id="simL_m1tr"></div></div>' +
      '<div class="pfig"><p class="pfh">エレベーターに乗って一緒に加速する観測者（立つ人）</p><div class="simhost" id="simL_m1el"></div></div></div>' +
      '<div class="sR pairR"><div id="simR_m1tr"></div><div id="simR_m1el"></div></div>' +
      '</div></article>';
  },
  build: function () {
    var A = SIM_BY_ID.m1tr = new Sim(DEFS.m1tr, document.getElementById('simL_m1tr'), document.getElementById('simR_m1tr'));
    var B = SIM_BY_ID.m1el = new Sim(DEFS.m1el, document.getElementById('simL_m1el'), document.getElementById('simR_m1el'));
    var top = document.getElementById('pairTop_m1s1'), sl = A.L.querySelector('.row2.sliders');
    top.appendChild(sl); top.appendChild(A.row1b);
    alignStops(A);
    setRot(B, A.rot);
  }
};

/* ===================== 1-2 エレベーターで上昇・下降する小球 ===================== */
/* 糸を切ったあとの「½gt²」「½at²」を図の中に書く（2026-10-11 千葉さん）。t は糸を切ってからの時間（床に着いたらそこで止める）。
   ・一緒に動く観測者から見ると：切った高さから、重力で ½gt²、慣性力で ½at²、あわせて ½(g+a)t² だけ落ちる。
   ・外から見ると：小球は「切った瞬間の速さのまま動いた場合の位置（点線）」より ½gt² 下、床はそれより ½at² 上にいる。 */
function fall12Marks(s, ctx, g, st, bx, br) {
  var k = g.k, a = s.v.a, tc = s.tCut, tau = st.landed ? st.T : st.tau; if (!(tau > 0.02)) return;
  var dG = 0.5 * G * tau * tau * k, dA = 0.5 * a * tau * tau * k, xa = bx - 0.3 * k, cG = COL.force, cA = '#b35f0c';
  var mark = function (x, y1, y2, col, txt, side) {
    if (Math.abs(y2 - y1) < 3) return;
    arrow(ctx, x, y1, x, y2, 'dim', col);
    label(ctx, txt, x + side * 7, (y1 + y2) / 2, { size: 11.5, bold: true, color: col, align: side > 0 ? 'left' : 'right' });
  };
  var line = function (y, x1, x2, txt) {
    ctx.save(); ctx.setLineDash([4, 4]); ctx.strokeStyle = '#8d9097'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(x1, y); ctx.lineTo(x2, y); ctx.stroke(); ctx.restore();
    if (txt) label(ctx, txt, x2 + 4, y, { size: 10, color: COL.sub, align: 'left' });   /* 名前は線の右はしの先に（かごの中の人と重ならないように） */
  };
  if (s.rot) {
    var y0 = g.yFloor - B12.h * k;                                 /* 切ったときの小球の高さ（かごの中では止まっている） */
    line(y0, g.cl + 4, bx + br + 6, '糸を切ったときの高さ');
    mark(xa, y0, y0 + dG, cG, '½gt²（重力）', -1);
    mark(xa - 0.1 * k, y0 + dG, y0 + dG + dA, cA, '½at²（慣性力）', -1);
  } else {
    var vc = velOf(s, tc), up = vc * tau * k;                        /* 切った瞬間の速さのまま動いたら、上へ vc·t */
    var X1 = dispOf(s, tc + tau), floorNow = g.yFloor + (dispOf(s, s.t) - X1) * k;   /* 着いたときの床（いまの時刻とのずれをもどす） */
    var floorRef = floorNow + dA, ballRef = floorRef - B12.h * k;
    var still = Math.abs(vc) < 1e-6;
    line(ballRef, g.cl + 4, bx + br + 6, still ? '糸を切ったときの小球の高さ' : '切った瞬間の速さのまま動いた場合の小球');
    line(floorRef, g.cl + 4, g.cr - 4, still ? '糸を切ったときの床' : '同じく、床');
    mark(xa, ballRef, ballRef + dG, cG, '小球が落ちた ½gt²', -1);
    mark(bx + 0.28 * k, floorRef, floorRef - dA, cA, '床が上がった ½at²', 1);
    void up;
  }
}
var B12 = P.ball, TW12 = 1.0;
function ballState(s) {
  var a = s.v.a, t = s.t;
  if (s.tCut === null || t < s.tCut) return { cut: false, y: B12.h, tau: 0 };
  var tau = t - s.tCut, y = P.ballRel(B12.h, a, tau), T = P.fallTime(B12.h, a);
  return { cut: true, y: y, tau: tau, landed: tau >= T - 1e-9, T: T };
}
function drawBall12(s, ctx, W, H) {
  var st = ballState(s), a = aEff(s);
  elevScene(s, ctx, W, H, function (g) {
    var k = g.k, bx = g.cx + 0.2 * EL.W * k, br = 8, by = g.yFloor - st.y * k, yc = g.yCeil;
    /* 小さな観測者（かごの左） */
    var px = g.cx - 0.32 * EL.W * k, hd = observer(ctx, px, g.yFloor, 0, -1, '', s.rot, 1.3 * k);
    innerName(ctx, g, s);
    /* 高さ h の寸法（床から） */
    if (!st.cut) { dimLine(ctx, bx - 0.45 * k, g.yFloor, bx - 0.45 * k, by); sym(ctx, 'h', bx - 0.45 * k - 10, (g.yFloor + by) / 2, { size: 15, color: COL.dim }); }
    /* 糸：切る前は天井から小球まで。切ったあとは、上の切れはしと、小球についた切れはし */
    var yCut = (yc + (g.yFloor - B12.h * k - br)) / 2;
    ctx.save(); ctx.strokeStyle = '#7a6a55'; ctx.lineWidth = 1.5; ctx.beginPath();
    if (!st.cut) { ctx.moveTo(bx, yc); ctx.lineTo(bx, by - br); }
    else { ctx.moveTo(bx, yc); ctx.lineTo(bx, yCut - 3); var piece = (g.yFloor - B12.h * k - br) - yCut - 3; ctx.moveTo(bx, by - br - Math.max(0, piece)); ctx.lineTo(bx, by - br); }
    ctx.stroke(); ctx.restore();
    ballShape(ctx, bx, by, br, '#c9d3de');
    sym(ctx, 'm', bx + 13, by - 13, { size: 14, color: COL.ink2, align: 'left' });
    if (s.cutAnim) drawCutAnim(ctx, s, bx, yCut);
    if (st.cut) fall12Marks(s, ctx, g, st, bx, br);
    /* 力 */
    if (s.ms.showF) {
      var fsc = 7 * k / 63, m = B12.m;
      forceArrow(ctx, bx, by, 0, 1, m * G * fsc, COL.force, 'mg', 'below');
      if (!st.cut && P.ballS(m, a) > 1e-6) forceArrow(ctx, bx, by - br, 0, -1, P.ballS(m, a) * fsc, COL.hand, 'S', 'left');
      if (s.rot && Math.abs(a) > 1e-9) forceArrow(ctx, bx + 11, by, 0, a > 0 ? 1 : -1, m * Math.abs(a) * fsc, COL.inert, '慣性力', 'right', 'fict');
    }
    /* 糸を切ったあとの加速度（落ちている間）：慣性系は g、非慣性系は g + a */
    if (st.cut && !st.landed) {
      var ga = s.rot ? G + a : G, La = 34 * ga / G;
      var ar = La < 2 ? null : arrow(ctx, bx - 30, by - La / 2, bx - 30, by + La / 2, 'acc');
      if (ar) { label(ctx, '小球の加速度', bx - 38, by - 3, { size: 11.5, bold: true, color: COL.acc, align: 'right' }); label(ctx, (s.rot ? 'g + a' : 'g') + '（下向き）', bx - 38, by + 12, { size: 12.5, bold: true, color: COL.acc, align: 'right' }); }
    }
    drawEqualTicks(ctx);
    if (st.cut && st.tau < 0.3 && !st.landed) eventBubble(ctx, 'cut', bx, by - br - 6);
    /* 「床に着いた！」は観測者のセリフと下の文で伝える（図の ½gt²・½at² の文字と重ならないように） */
    var say;
    if (s.rot) say = !st.cut ? (a <= -G + 1e-9 ? '無重力だなあ！糸がゆるんでる' : '小球は止まって見えるなあ') : (st.landed ? '床に着いた！' : (G + a < 1e-9 ? '浮いたまま落ちてこない！' : (a > 0 ? '速く落ちてくる！' : (a < 0 ? 'ゆっくり落ちてくる…' : 'ふつうに落ちる'))));
    else say = !st.cut ? (Math.abs(a) < 1e-9 ? (s.v.still ? '止まってるな' : '一定の速さで上がってる') : (a > 0 ? '上に加速してる！' : '下に加速してる！')) : (st.landed ? '小球が床に着いた！' : '小球は重力だけで落ちてる');
    if (s.rot) speech(ctx, say, hd, 'right'); else if (g.hdIn) speech(ctx, say, g.hdIn);
  });
}
/* 糸が切れてから床に着くまでを、時間を横にとって並べた図（ストロボ）。エレベーター（床と天井）と小球の高さ。
   外から見ると、床は上へ動き（加速度 a）、小球は投げ上げのように動く（加速度 −g）→ 2 つの線が出会う時刻が「床に着く」。
   中から見ると、床は止まっていて、小球が g + a で落ちてくる */
function drawFall(cv, s) {
  var a = s.v.a, h = B12.h, T = P.fallTime(h, a), V = velOf(s, s.tCut || 0), rot = s.rot, Hc = EL.H;
  var Tm = isFinite(T) ? T : 0.6, n = 5;
  var y1 = function (t) { return rot ? h - 0.5 * (G + a) * t * t : h + V * t - 0.5 * G * t * t; };
  var y2 = function (t) { return rot ? 0 : V * t + 0.5 * a * t * t; };
  var W = Math.max(260, Math.floor(cv.parentNode.clientWidth - 2)), H = 250;
  cv.style.width = '100%';
  var ctx = prep(cv, W, H);
  var lo = 0, hi = Hc; for (var i = 0; i <= 40; i++) { var t = Tm * i / 40; lo = Math.min(lo, y2(t), y1(t)); hi = Math.max(hi, y2(t) + Hc); }
  var L = 44, Rr = 16, Tp = 22, B = 38, sy = (H - Tp - B) / (hi - lo), sx = (W - L - Rr - 30) / Tm;
  var X = function (t) { return L + 22 + t * sx; }, Y = function (y) { return H - B - (y - lo) * sy; };
  /* 軸（矢印つき） */
  arrow(ctx, L, H - B + 6, W - 6, H - B + 6, 'dim', COL.ink2); arrow(ctx, L, H - B + 6, L, 6, 'dim', COL.ink2);
  label(ctx, '時間 t', W - 8, H - B + 22, { size: 11, color: COL.ink2, align: 'right' });
  label(ctx, '高さ', L + 6, 12, { size: 11, color: COL.ink2, align: 'left' });
  label(ctx, rot ? '（中から見た図）' : '（外から見た図・切った瞬間の床が 0）', L + 40, 12, { size: 10.5, color: COL.sub, align: 'left' });
  /* 線：床・小球 */
  ctx.save(); ctx.lineWidth = 2.4; ctx.strokeStyle = '#2b5f8a'; ctx.beginPath();
  for (i = 0; i <= 60; i++) { var tt = Tm * i / 60; i ? ctx.lineTo(X(tt), Y(y2(tt))) : ctx.moveTo(X(tt), Y(y2(tt))); } ctx.stroke();
  ctx.strokeStyle = COL.ink2; ctx.setLineDash([4, 3]); ctx.lineWidth = 1.6; ctx.beginPath();
  for (i = 0; i <= 60; i++) { tt = Tm * i / 60; i ? ctx.lineTo(X(tt), Y(y1(tt))) : ctx.moveTo(X(tt), Y(y1(tt))); } ctx.stroke(); ctx.restore();
  /* ストロボ：同じ時間ごとのエレベーターと小球 */
  for (i = 0; i < n; i++) {
    tt = Tm * i / (n - 1); var x = X(tt), yf = Y(y2(tt)), yc = Y(y2(tt) + Hc), last = (i === n - 1);
    ctx.save(); ctx.strokeStyle = 'rgba(20,23,28,' + (0.35 + 0.5 * i / (n - 1)) + ')'; ctx.lineWidth = 1.3; ctx.strokeRect(x - 12, yc, 24, yf - yc);
    ctx.strokeStyle = '#2b5f8a'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(x - 12, yf); ctx.lineTo(x + 12, yf); ctx.stroke(); ctx.restore();
    ballShape(ctx, x, Y(y1(tt)) - (last && isFinite(T) ? 5 : 0), 5, '#c9d3de');
    label(ctx, f2(tt) + ' s', x, H - B + 20, { size: 10, color: COL.sub });
  }
  label(ctx, '床', X(Tm * 0.5) + 16, Y(y2(Tm * 0.5)) + 12, { size: 11, bold: true, color: '#2b5f8a', align: 'left' });
  label(ctx, '小球', X(Tm * 0.25) + 14, Y(y1(Tm * 0.25)) - 10, { size: 11, bold: true, color: COL.ink2, align: 'left' });
  if (isFinite(T)) label(ctx, '床に着く', X(T) - 16, Y(y2(T)) - 16, { size: 11, bold: true, color: '#0a5c5c', align: 'right' });
  else label(ctx, '小球は床に近づかない（a = −g）', W / 2, Tp + 6, { size: 11, bold: true, color: '#0a5c5c' });
}
function rightBall12(s, R) {
  var a = s.v.a, m = B12.m, h = B12.h, S = P.ballS(m, a), T = P.fallTime(h, a), st = ballState(s), fin = isFinite(T);
  var aT = (a < 0 ? '-' : '+') + Math.abs(a);
  var h1 = ifSetup(s, {
    title: '糸を切る前',
    lead: { in: '外から見ると、小球はエレベーターと一緒に加速度 $a$ で運動している。はたらく力は張力 $S$ と重力 $mg$。',
            rot: 'エレベーターの中の観測者には、小球は止まって見える。張力 $S$・重力 $mg$・<b>慣性力 $ma$</b>（加速度と逆向き）がつり合う。' },
    rows: [{ dir: '鉛直方向（上向き正）', in: ['eom', 'ma = S - mg'], rot: ['bal', 'S - mg - ma = 0'] }],
    now: { in: tex('S = m(g+a) = ' + f2(m) + '\\times(9.8' + aT + ') = ' + f2(S) + '\\ \\text{N}'), rot: tex('S = mg + ma = ' + f2(S) + '\\ \\text{N}') }
  });
  var h2;
  if (st.cut) {
    h2 = '<div class="qcard derive"><p class="qt">糸が切れてから床に着くまでの時間</p>' + (s.rot ?
      '<p>エレベーターの中から見ると、糸が切れた小球には重力 $mg$ と慣性力 $ma$（' + (a >= 0 ? '下向き' : '上向き') + '）がはたらく。下向きを正とした' + T_EOM + 'は</p>' +
      '<div class="qeq">' + tex("ma' = mg + ma \\;\\Longrightarrow\\; a' = g + a", true) + '</div>' +
      '<p>小球は<b>見かけの重力加速度 $g+a$</b> で、初速度 0 で落ちる（エレベーターの中から見ると、はじめ止まっているから）。床は動かない。</p>' +
      '<canvas class="fallcv"></canvas>' +
      '<div class="qeq">' + tex('h = \\frac{1}{2}(g+a)t^2 \\;\\Longrightarrow\\; t = \\sqrt{\\frac{2h}{g+a}}', true) + '</div>'
      :
      '<p>外から見ると、糸が切れた小球には重力 $mg$ しかはたらかない。小球は加速度 $g$（下向き）で運動する。はじめの速度は、切った瞬間のエレベーターの速度 $V$ と同じ（' + tex('V=' + f2(velOf(s, s.tCut || 0))) + ' m/s）。そのあいだも、<b>エレベーターの床は加速度 $a$ で動き続ける</b>。</p>' +
      '<p>下の図は、同じ時間ごとのエレベーターと小球を横に並べたもの。小球の線と床の線が出会う時刻が「床に着く」時刻。</p>' +
      '<canvas class="fallcv"></canvas>' +
      '<p>上向きを正、切った瞬間の床の位置を原点として、$t$ 秒後の位置は</p>' +
      '<div class="qeq">' + tex('\\text{小球：}\\ y_1 = h + Vt - \\frac{1}{2}gt^2', true) + tex('\\text{床：}\\ y_2 = Vt + \\frac{1}{2}at^2', true) + '</div>' +
      '<p>床に着くのは $y_1 = y_2$ のとき。$Vt$ は両方にあるので消えて</p>' +
      '<div class="qeq">' + tex('h = \\frac{1}{2}(g+a)t^2 \\;\\Longrightarrow\\; t = \\sqrt{\\frac{2h}{g+a}}', true) + '</div>') +
      (fin ? '<p class="qnow"><span class="qtag now">いまの値</span>' + tex('t = \\sqrt{\\frac{2\\times' + f1(h) + '}{9.8' + aT + '}} = ' + f2(T) + '\\ \\text{s}') + '</p>' +
        '<p>どちらの観測者で考えても、同じ時間になる。' + (a > 0 ? '上向きに加速しているときは、止まっているときより<b>速く</b>床に着く。' : (a < 0 ? '下向きに加速しているときは、止まっているときより<b>遅く</b>床に着く。' : '加速度 0 なら、ふつうの自由落下と同じ。')) + '</p>'
        : '<p class="qnow"><span class="qtag now">いまの値</span>$g + a = 0$ なので、小球は<b>床に着かない</b>（エレベーターの中から見ると浮いたまま。無重力状態）。外から見ると、小球も床も同じ加速度 $-g$ で落ちている。</p>') +
      '</div>';
  } else {
    h2 = '<div class="qcard intro"><p class="qt">やってみよう</p><p>図の左上の「<b>✂ 糸を切る</b>」を押すと、糸が切れて小球が落ちる。床に着くまでの時間は、加速度 $a$ によってどう変わるだろう？　切ったあと、ここに解き方が出る。</p></div>';
  }
  R.innerHTML = mathify(h1 + h2 + '<p class="assume">小球の質量 ' + tex('m=' + f2(m)) + ' kg、床からの高さ ' + tex('h=' + f1(h)) + ' m、' + tex('g=9.8') + ' m/s²。小球の大きさは考えない。</p>');
  var cv = R.querySelector('canvas.fallcv'); if (cv) drawFall(cv, s);
}
/* 図の下：外から／一緒に加速運動する観測者から の小さな力の図と式 */
function fbdBall(cut) {
  return { h: 196, draw: function (ctx, w, h, rot) {
    var s = SIM_BY_ID.m1s2, a = s ? s.v.a : 0, m = B12.m, fsc = 9, bx = w / 2, by = 100, br = 9;
    if (!cut) { ctx.save(); ctx.strokeStyle = '#7a6a55'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(bx, 6); ctx.lineTo(bx, by - br); ctx.stroke(); ctx.restore(); }
    ballShape(ctx, bx, by, br, '#c9d3de');
    forceArrow(ctx, bx, by, 0, 1, m * G * fsc, COL.force, 'mg', 'below');
    if (!cut && P.ballS(m, a) > 1e-6) forceArrow(ctx, bx, by - br, 0, -1, P.ballS(m, a) * fsc, COL.hand, 'S', 'left');
    if (rot && Math.abs(a) > 1e-9) forceArrow(ctx, bx + 11, by, 0, a > 0 ? 1 : -1, m * Math.abs(a) * fsc, COL.inert, '慣性力', 'right', 'fict');
    if (!rot) { var aa = cut ? -G : a; if (Math.abs(aa) > 1e-9) { var L = 50 * Math.abs(aa) / G + 6, ar = arrow(ctx, bx + 46, by - (aa > 0 ? -L / 2 : L / 2), bx + 46, by + (aa > 0 ? -L / 2 : L / 2), 'acc'); if (ar) label(ctx, '小球の加速度 ' + (cut ? 'g' : 'a'), bx + 56, by, { size: 12, bold: true, color: COL.acc, align: 'left' }); } }
    drawEqualTicks(ctx);
  } };
}
DEFS.m1s2 = ifBase({
  id: 'm1s2', num: 2, title: 'エレベーターで上昇・下降する小球', V0: P.V0E, TW: TW12,
  height: function (s, w) { return Math.round(clamp(w * 0.86, 360, 520)); },
  desc: 'エレベーターの天井から、糸で小球（質量 $m$）をつるす。小球の床からの高さは $h$。<span class="todo">加速度を選び、図の左上の「✂ 糸を切る」を押して、小球が床に着くまでの時間を比べよう。</span>',
  buttons: [{ k: 'cut', label: '✂ 糸を切る', cls: 'cut', inCanvas: true, onClick: function (s) { var T = P.fallTime(B12.h, s.v.a); startCut(s, isFinite(T) ? TW12 - T - 0.05 : TW12 - 0.2); } },
            { k: 'cut0', label: '✂ 0 秒で糸を切る', cls: 'cut', inCanvas: true, onClick: function (s) { startCut0(s); } }],
  tEnd: function (s) { if (s.tCut !== null && s.tCut !== undefined) { var T = P.fallTime(B12.h, s.v.a); if (isFinite(T)) return Math.min(TW12, s.tCut + T + 0.12); } return TW12; },   /* 床に着いたら少しで止める（図の ½gt²・½at² が着いたときの値のまま見える） */
  init: function (s) { s.tCut = null; s.cutAnim = null; },
  aLocked: function (s) { return s.tCut !== null || !!s.cutAnim; },
  onReset: function (s) { resetCut(s); }, onRestart: function (s) { resetCut(s); }, onDefaults: function (s) { resetCut(s); },
  msg: function (s) {
    var st = ballState(s), a = s.v.a, T = P.fallTime(B12.h, a);
    if (s.cutAnim && !s.cutAnim.snipped) return 'はさみで糸を切ります…';
    if (st.cut && !isFinite(T)) return '$a = -g$ なので、エレベーターの中から見ると小球は<b>浮いたまま</b>（無重力状態）。外から見ると、小球も床も同じ加速度で落ちている。';
    if (st.cut) return st.landed ? '床に着くまで ' + f2(T) + ' s（' + (s.rot ? 'エレベーターの中から見ると、見かけの重力加速度 $g+a=' + f1(G + a) + '$ m/s² で落ちた' : '外から見ると、小球は重力だけで運動し、床が追いついた') + '）。' :
      (s.rot ? '中から見ると、小球は $g+a$ で落ちていく。' : '外から見ると、小球は加速度 $g$ で運動している（はじめの速度はエレベーターと同じ）。');
    return '糸を切る前、小球は ' + (s.rot ? '止まって見える（$S$・$mg$・慣性力がつり合う）。' : 'エレベーターと一緒に加速度 $a$ で運動している。') + '左上の「✂ 糸を切る」を押してみよう。';
  },
  eqs: function (s) {
    var a = s.v.a, st = ballState(s), cut = st.cut;
    var aT = (a < 0 ? '-' : '+') + Math.abs(a);
    if (!cut) return {
      in: { h: '外（慣性系）から見る', fbd: fbdBall(false), lines: [{ tag: 'eom', k: '鉛直（上向き正）：', t: 'ma = S - mg' }], num: 'いま：' + tex('S = m(g+a) = ' + f2(P.ballS(B12.m, a)) + '\\ \\text{N}') },
      rot: { h: '一緒に加速運動する観測者（非慣性系）から見る', fbd: fbdBall(false), lines: [{ tag: 'bal', k: '鉛直（上向き正）：', t: 'S - mg - ma = 0' }], num: 'いま：' + tex('S = ' + f2(P.ballS(B12.m, a)) + '\\ \\text{N}'), note: '慣性力 ' + tex('ma') + ' は加速度と逆向き' } };
    return {
      in: { h: '外（慣性系）から見る（糸が切れたあと）', fbd: fbdBall(true), lines: [{ tag: 'eom', k: '鉛直（上向き正）：', t: "ma_1 = -mg" }], num: '小球の加速度は ' + tex('-g') + '（重力だけ）' },
      rot: { h: '一緒に加速運動する観測者（非慣性系）から見る（糸が切れたあと）', fbd: fbdBall(true), lines: [{ tag: 'eom', k: '鉛直（下向き正）：', t: "ma' = mg + ma" }], num: tex("a' = g + a = 9.8" + aT + ' = ' + f1(Math.abs(G + a) < 1e-9 ? 0 : G + a)) + ' m/s²', note: '見かけの重力加速度 ' + tex('g + a') + ' で落ちる' } };
  },
  draw: drawBall12, right: rightBall12
});

/* ===================== 1-3 エレベーターで上昇・下降するはかり ===================== */
var SC = P.scale;
function dial(ctx, cx, cy, r, kg, big) {
  ctx.save();
  ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.fillStyle = '#fff'; ctx.fill(); ctx.strokeStyle = COL.ink; ctx.lineWidth = big ? 2.2 : 1.4; ctx.stroke();
  var A = function (q) { return -Math.PI / 2 + q / 25 * TAU; };   /* 0〜25 kg で 1 周 */
  for (var q = 0; q < 25; q += (big ? 0.5 : 1)) {
    var maj = Math.abs(q % 5) < 1e-9, a1 = A(q), r1 = r * (maj ? 0.74 : (Math.abs(q % 1) < 1e-9 ? 0.82 : 0.88));
    ctx.strokeStyle = maj ? COL.ink : '#8d9097'; ctx.lineWidth = maj ? 1.6 : 1;
    ctx.beginPath(); ctx.moveTo(cx + Math.cos(a1) * r * 0.96, cy + Math.sin(a1) * r * 0.96); ctx.lineTo(cx + Math.cos(a1) * r1, cy + Math.sin(a1) * r1); ctx.stroke();
    if (big && maj) { ctx.fillStyle = COL.ink2; ctx.font = '600 11px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(String(q), cx + Math.cos(a1) * r * 0.58, cy + Math.sin(a1) * r * 0.58); }
  }
  var an = A(kg);
  ctx.strokeStyle = '#c0392b'; ctx.lineWidth = big ? 2.4 : 1.4; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(cx - Math.cos(an) * r * 0.12, cy - Math.sin(an) * r * 0.12); ctx.lineTo(cx + Math.cos(an) * r * 0.86, cy + Math.sin(an) * r * 0.86); ctx.stroke();
  ctx.beginPath(); ctx.arc(cx, cy, big ? 3.5 : 1.8, 0, TAU); ctx.fillStyle = COL.ink; ctx.fill();
  ctx.restore();
}
function drawScale13(s, ctx, W, H) {
  var a = aEff(s), kg = P.scaleKg(SC.m, a), N = P.scaleN(SC.m, a);
  /* 針は加速度を変えたとき、なめらかに動く（見た目だけ。値は式どおり） */
  var now = performance.now(); if (s._nd === undefined) s._nd = kg;
  var dt = s._ndT ? Math.min(0.1, (now - s._ndT) / 1000) : 0; s._ndT = now;
  s._nd += (kg - s._nd) * Math.min(1, dt * 6); if (Math.abs(kg - s._nd) < 0.005) s._nd = kg;
  if (Math.abs(kg - s._nd) > 0.004) { clearTimeout(s._ndTO); s._ndTO = setTimeout(function () { s.draw(); }, 30); }
  var g0 = elevScene(s, ctx, W, H, function (g) {
    var k = g.k, px = g.cx - 0.3 * EL.W * k, hd = observer(ctx, px, g.yFloor, 0, -1, '', s.rot, 1.65 * k);
    innerName(ctx, g, s);
    /* 台はかり（床の右）とおもり */
    var sx = g.cx + 0.2 * EL.W * k, sw = 0.92 * k, shh = 0.4 * k, ytop = g.yFloor - shh;
    ctx.save(); ctx.fillStyle = '#eef1f4'; ctx.strokeStyle = COL.ink; ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.rect(sx - sw / 2, ytop, sw, shh); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#d6d0c4'; ctx.beginPath(); ctx.rect(sx - sw / 2 - 3, ytop - 4, sw + 6, 4); ctx.fill(); ctx.stroke(); ctx.restore();
    dial(ctx, sx, ytop + shh / 2 + 1, Math.min(shh * 0.4, 10), s._nd, false);
    var ww = 0.62 * k, wh = 0.46 * k, wy = ytop - 4 - wh;
    ctx.save(); ctx.fillStyle = '#ffffff'; ctx.strokeStyle = COL.ink; ctx.lineWidth = 1.8; ctx.beginPath(); ctx.rect(sx - ww / 2, wy, ww, wh); ctx.fill(); ctx.stroke(); ctx.restore();
    label(ctx, 'おもり 10 kg', sx, wy - 10, { size: 11, bold: true, color: COL.ink2 });
    if (s.ms.showF) {
      var fsc = 0.4 * k / 63, cy = wy + wh / 2;
      forceArrow(ctx, sx, cy, 0, 1, SC.m * G * fsc, COL.force, 'mg', 'below');
      forceArrow(ctx, sx + ww * 0.32, wy + wh, 0, -1, N * fsc, COL.norm, 'N', 'right');
      if (s.rot && Math.abs(a) > 1e-9) forceArrow(ctx, sx - ww * 0.3, cy, 0, a > 0 ? 1 : -1, SC.m * Math.abs(a) * fsc, COL.inert, '慣性力', 'left', 'fict');
    }
    drawEqualTicks(ctx);
    var kgNow = fmt(P.scaleKg(SC.m, a), 1);
    var say = s.rot ? (a <= -G + 1e-9 ? '0 kg になった！無重力だ' : (a > 0 ? kgNow + ' kg に増えた！' : (a < 0 ? kgNow + ' kg に減った！' : '10 kg のままだ'))) : (a > 0 ? 'おもりは上に加速してる' : (a < 0 ? 'おもりは下に加速してる' : (s.v.still ? '止まってるな' : '一定の速さで上がってる')));
    if (s.rot) speech(ctx, say, hd, 'right'); else if (g.hdIn) speech(ctx, say, g.hdIn);
  });
  /* 目盛りの拡大（左上） */
  var R0 = 42, cx0 = 14 + R0, cy0 = 30 + R0;
  ctx.save(); ctx.fillStyle = 'rgba(255,255,255,.96)'; ctx.strokeStyle = 'rgba(20,23,28,.15)'; ctx.lineWidth = 1; rrect(ctx, 6, 6, 2 * R0 + 16, 2 * R0 + 66, 12); ctx.fill(); ctx.stroke(); ctx.restore();
  label(ctx, 'はかりの目盛り', cx0, 18, { size: 10.5, bold: true, color: COL.ink2 });
  dial(ctx, cx0, cy0 + 4, R0, s._nd, true);
  label(ctx, fmt(s._nd, 1) + ' kg', cx0, cy0 + R0 + 19, { size: 16, bold: true, color: '#c0392b' });
  label(ctx, '（' + fmt(s._nd * G, 0) + ' N）', cx0, cy0 + R0 + 36, { size: 10.5, color: COL.ink2 });
  void g0;
}
function rightScale13(s, R) {
  var a = s.v.a, m = SC.m, N = P.scaleN(m, a), kg = P.scaleKg(m, a), aT = (a < 0 ? '-' : '+') + Math.abs(a);
  var h = ifSetup(s, {
    title: 'おもり',
    lead: { in: '外から見ると、おもりはエレベーターと一緒に加速度 $a$ で運動している。はたらく力は重力 $mg$ と、台はかりからの垂直抗力 $N$。',
            rot: 'エレベーターの中の観測者には、おもりは止まって見える。重力 $mg$・垂直抗力 $N$・<b>慣性力 $ma$</b>（加速度と逆向き）がつり合う。' },
    rows: [{ dir: '鉛直方向（上向き正）', in: ['eom', 'ma = N - mg'], rot: ['bal', 'N - mg - ma = 0'] }],
    now: { in: tex('N = m(g+a)'), rot: tex('N = mg + ma') }
  });
  h += '<div class="qcard derive"><p class="qt">はかりの針は何 N（何 kg）を示すか</p>' +
    '<p>台はかりがおもりに及ぼす垂直抗力 $N$ と、おもりが台はかりを押す力は、<b>作用反作用の法則</b>により大きさが同じ。はかりの針は、おもりが台はかりを押す力の大きさ $N$ を示す。</p>' +
    '<div class="qeq">' + tex('N = m(g+a) = 10\\times(9.8' + aT + ') = ' + f1(N) + '\\ \\text{N}', true) + '</div>' +
    '<p>目盛りを kg で読むと（静止しているとき 98 N が 10 kg）</p>' +
    '<div class="qeq">' + tex('\\frac{' + f1(N) + '}{9.8} = ' + f2(kg) + '\\ \\text{kg}', true) + '</div>' +
    '<p>' + (a > 0 ? '上向きに加速すると、目盛りは<b>大きく</b>なる。' : (a < 0 ? '下向きに加速すると、目盛りは<b>小さく</b>なる。' : '加速度 0（静止・等速）では、いつもと同じ 98 N（10 kg）。')) + 'どちらの観測者で考えても、同じ値になる。</p></div>';
  R.innerHTML = mathify(h + '<p class="assume">おもりの質量 ' + tex('m=10') + ' kg、' + tex('g=9.8') + ' m/s²。</p>');
}
DEFS.m1s3 = ifBase({
  id: 'm1s3', num: 3, title: 'エレベーターで上昇・下降するはかり', V0: P.V0E, TW: EL.TW,
  desc: 'エレベーターの床に台はかりを置き、おもり（10 kg）をのせる。エレベーターが静止しているとき、目盛りは 98 N（10 kg）。台はかりがおもりに及ぼす垂直抗力は、作用反作用の法則により、はかりの針が示す力と同じ。<span class="todo">加速度を変えて、はかりの針がどう動くか見よう。</span>',
  msg: function (s) {
    var a = s.v.a, N = P.scaleN(SC.m, a);
    return 'はかりの針は ' + f1(N) + ' N（' + f2(N / G) + ' kg）を示す。' + (Math.abs(a) < 1e-9 ? '加速度 0 なので、静止しているときと同じ。' : (s.rot ? '中から見ると、慣性力 $ma$ のぶん ' + (a > 0 ? '重く' : '軽く') + 'なったように見える。' : '外から見ると、$N - mg$ がおもりを加速させている。'));
  },
  eqs: function (s) {
    var a = s.v.a, N = P.scaleN(SC.m, a);
    return {
      in: { h: '外（慣性系）から見る', lines: [{ tag: 'eom', k: '鉛直（上向き正）：', t: 'ma = N - mg' }], num: 'いま：' + tex('N = ' + f1(N) + '\\ \\text{N}') },
      rot: { h: '一緒に加速運動する観測者（非慣性系）から見る', lines: [{ tag: 'bal', k: '鉛直（上向き正）：', t: 'N - mg - ma = 0' }], num: 'いま：' + tex('N = ' + f1(N) + '\\ \\text{N}'), note: '慣性力 ' + tex('ma') + ' は加速度と逆向き' } };
  },
  draw: drawScale13, right: rightScale13
});
