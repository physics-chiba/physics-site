/* =========================================================================
   デザイン試作の動き（2026-10）
   ・ヒーローのステージ：加速する電車の中の振り子を、外の観測者（慣性系）と一緒に加速する観測者（非慣性系）から並べて見せる。
   ・スライドバーの塗り（--p）、タブ列の下の進み具合（--prog）。
   ・画面に見えていないとき・動きを減らす設定のときは動かさない（重くしない：第 21 回の教訓）。
   ========================================================================= */
(function(){
  "use strict";
  const RM = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const MATH = '"KaTeX_Math","KaTeX_Main",serif',
        JP = '"Hiragino Sans","Hiragino Kaku Gothic ProN","Yu Gothic",YuGothic,"Noto Sans JP",Meiryo,sans-serif';

  /* ===== ヒーローのステージ：加速する電車の中の振り子を「外の観測者」と「一緒に加速する観測者」から並べて見せる =====
     加速度は a = 0 → a = 2 m/s² をくり返す（2026-10-11 千葉さん）。左＝慣性系（電車が動き、地面は止まる）。S と mg の合力が小球を加速させる。
     右＝非慣性系（電車は止まって見え、地面と外の観測者が動く）。S・mg・慣性力 ma（濃いグレーの破線＝暗い地では明るいグレー）がつり合う。 */
  function initStage(){
    const cv = document.getElementById("heroCv"); if(!cv) return;
    const ctx = cv.getContext("2d");
    const K = { S:"#ff6aa8", g:"#ff6b5b", v:"#5aa7ff", a:"#ffa64d", in:"#c3ccd6", obsA:"#5aa7ff", obsB:"rgba(243,239,230,.45)", ink:"#f6f2e9" };
    const GG = 9.8, LEN = 1.0, PH = [[0,0.7],[9.8,1.4]], CYC = PH.reduce((q,p)=>q+p[1],0), V0 = 3.5, X0 = -V0*PH[0][1], BASE = 0.35;   /* スローモーション（0.35 倍）：a = 0（等速 v0）を 2 s、a = 9.8 を 4 s 見せる。等速の間に電車が左の図の真ん中まで来て、そこで加速に切りかわる（2026-10-11 千葉さん） */
    let W=0, H=0, dpr=1, run=false, raf=0, last=0, t=0, paused=false, rate=BASE;
    let th=0, om=0, xpos=X0, vel=V0;
    function aAt(tt){ let u = ((tt%CYC)+CYC)%CYC; for(const p of PH){ if(u < p[1]) return p[0]; u -= p[1]; } return 0; }
    function setup(){
      const r = cv.getBoundingClientRect(); dpr = Math.min(2, window.devicePixelRatio||1);
      W = Math.max(280, r.width); H = Math.max(170, r.height);
      cv.width = Math.round(W*dpr); cv.height = Math.round(H*dpr); ctx.setTransform(dpr,0,0,dpr,0,0);
    }
    function arr(x1,y1,x2,y2,col,lw,dash,dot){
      const dx=x2-x1, dy=y2-y1, L=Math.hypot(dx,dy); if(L<2) return;
      const ux=dx/L, uy=dy/L, h=Math.min(10, L*0.6);
      ctx.save(); ctx.strokeStyle=col; ctx.fillStyle=col; ctx.lineWidth=lw||2.6; ctx.lineCap="round";
      if(dash) ctx.setLineDash(dash);
      ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(x2-ux*h*0.8,y2-uy*h*0.8); ctx.stroke(); ctx.setLineDash([]);
      ctx.beginPath(); ctx.moveTo(x2,y2); ctx.lineTo(x2-ux*h-uy*h*0.5,y2-uy*h+ux*h*0.5); ctx.lineTo(x2-ux*h+uy*h*0.5,y2-uy*h-ux*h*0.5); ctx.closePath();
      ctx.fill();
      if(dot){ ctx.beginPath(); ctx.arc(x1,y1,3,0,7); ctx.fillStyle=col; ctx.fill(); }
      ctx.restore();
    }
    function sym(s,x,y,col,size){ ctx.save(); ctx.fillStyle=col; ctx.textAlign="center"; ctx.textBaseline="middle"; ctx.font="italic "+size+"px "+MATH; ctx.fillText(s,x,y); ctx.restore(); }
    /* ベクトルの記号（文字の上に小さな矢印。mg なら g の上だけ：m\vec{g}。2026-10-13 千葉さん） */
    function vsym(s,x,y,col,size,skip){ ctx.save(); ctx.font="italic "+size+"px "+MATH; const W0=ctx.measureText(s).width, ws=skip? ctx.measureText(skip).width : 0; ctx.restore();
      sym(s,x,y,col,size); const xa=x-W0/2+ws+(W0-ws)*0.12, xb=x+W0/2+1, ya=y-size*0.62;
      ctx.save(); ctx.strokeStyle=col; ctx.fillStyle=col; ctx.lineWidth=1.2; ctx.beginPath(); ctx.moveTo(xa,ya); ctx.lineTo(xb-2,ya); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(xb+1,ya); ctx.lineTo(xb-3.5,ya-2.6); ctx.lineTo(xb-3.5,ya+2.6); ctx.closePath(); ctx.fill(); ctx.restore(); }
    function stick(x,y,s,col,lw){
      ctx.save(); ctx.strokeStyle=col; ctx.lineWidth=lw; ctx.lineCap="round";
      const P=(du,dp)=>[x+dp*s, y-du*s], hip=P(.38,0), sh=P(.64,0), hd=P(.8,0);
      ctx.beginPath(); ctx.arc(hd[0],hd[1],s*.13,0,7); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(hip[0],hip[1]); ctx.lineTo(sh[0],sh[1]); ctx.stroke();
      const f1=P(0,-.17), f2=P(0,.17); ctx.beginPath(); ctx.moveTo(f1[0],f1[1]); ctx.lineTo(hip[0],hip[1]); ctx.lineTo(f2[0],f2[1]); ctx.stroke();
      const e1=P(.5,-.17), e2=P(.5,.17), h1=P(.38,-.12), h2=P(.38,.12);
      ctx.beginPath(); ctx.moveTo(h1[0],h1[1]); ctx.lineTo(e1[0],e1[1]); ctx.lineTo(sh[0],sh[1]); ctx.lineTo(e2[0],e2[1]); ctx.lineTo(h2[0],h2[1]); ctx.stroke();
      ctx.restore();
    }
    function text(s,x,y,col,size,al,bold){ ctx.save(); ctx.fillStyle=col; ctx.font=(bold?"700 ":"600 ")+size+"px "+JP; ctx.textAlign=al||"center"; ctx.textBaseline="middle"; ctx.fillText(s,x,y); ctx.restore(); }

    /* 1 枚ぶん。rot＝一緒に加速する観測者から見るか */
    function panel(x0, w, rot, a){
      const narrow = w < 330, ppm = Math.min(w/7, H/3.4), yg = H - 34;
      const per = w + 2.6*ppm;                                   /* 電車が右へ出たら左から入る（参考動画と同じ） */
      const TL = 2.6*ppm, TH = 1.45*ppm, lift = 0.32*ppm;
      const trainX = rot ? x0 + w/2 - TL/2 : x0 - TL + (((xpos*ppm + w/2 + TL/2) % per) + per) % per;   /* xpos = 0（加速に切りかわるとき）に電車の真ん中が図の真ん中 */
      const gsh = rot ? -xpos*ppm : 0;                            /* 非慣性系：地面と外の観測者が動く */
      ctx.save(); ctx.beginPath(); ctx.rect(x0+2, 24, w-4, H-26); ctx.clip();
      /* 地面・柱 */
      ctx.strokeStyle="rgba(243,239,230,.35)"; ctx.lineWidth=1.2; ctx.beginPath(); ctx.moveTo(x0, yg); ctx.lineTo(x0+w, yg); ctx.stroke();
      ctx.strokeStyle="rgba(243,239,230,.12)"; ctx.lineWidth=1;
      const sp = 2*ppm, off = ((gsh % sp) + sp) % sp;
      for(let x = x0 - sp + off; x < x0 + w + sp; x += sp){ ctx.beginPath(); ctx.moveTo(x, yg); ctx.lineTo(x-6, yg+7); ctx.stroke(); ctx.beginPath(); ctx.moveTo(x+sp*0.5, yg); ctx.lineTo(x+sp*0.5, yg-2.2*ppm); ctx.stroke(); }
      /* 外の観測者（地面）：慣性系では止まっている */
      const so = narrow? 24 : 30, oxw = x0 + 0.7*ppm, ox = rot ? oxw + gsh : oxw;   /* 非慣性系では地面と一緒に流れていき、戻ってこない（2 回出てこない） */
      stick(ox, yg, so, rot? K.obsB : K.obsA, rot? 1.6 : 2.4);
      /* 電車（はみ出しの分は反対がわにもう 1 つ） */
      [0, -per].forEach(dd=>{
        const tx = trainX + dd; if(tx > x0 + w || tx + TL < x0) return;
        const yb = yg - lift, yt = yb - TH;
        ctx.save(); ctx.strokeStyle="rgba(243,239,230,.85)"; ctx.lineWidth=1.8; ctx.fillStyle="rgba(255,255,255,.04)";
        ctx.beginPath(); ctx.rect(tx, yt, TL, TH); ctx.fill(); ctx.stroke();
        [0.45, 2.15].forEach(u=>{ ctx.beginPath(); ctx.arc(tx+u*ppm, yg-0.16*ppm, 0.16*ppm, 0, 7); ctx.stroke(); });
        ctx.restore();
        /* 振り子：天井の真ん中から */
        const px = tx + TL*0.58, py = yt + 2, Lp = TH*0.62, bx = px + Lp*Math.sin(th), by = py + Lp*Math.cos(th), rb = Math.max(5, ppm*0.13);
        ctx.strokeStyle="rgba(243,239,230,.12)"; ctx.setLineDash([3,4]); ctx.beginPath(); ctx.moveTo(px,py); ctx.lineTo(px,py+Lp+rb); ctx.stroke(); ctx.setLineDash([]);
        ctx.strokeStyle="#c9a77a"; ctx.lineWidth=1.5; ctx.beginPath(); ctx.moveTo(px,py); ctx.lineTo(bx,by); ctx.stroke();
        const g = ctx.createRadialGradient(bx-rb*.35,by-rb*.4,rb*.1,bx,by,rb); g.addColorStop(0,"#fff"); g.addColorStop(.3,"#c9d3de"); g.addColorStop(1,"#56606c");
        ctx.fillStyle=g; ctx.beginPath(); ctx.arc(bx,by,rb,0,7); ctx.fill();
        /* 力（同じ縮尺）：S は糸にそって、mg は下、慣性力は加速度と逆向き */
        const LG = 0.7*Math.min(H*0.17, 0.95*ppm), ux = Math.sin(th), uy = Math.cos(th), Sm = LG*Math.sqrt(1 + (a/GG)*(a/GG));
        /* 作用点：S は糸と小球の接触点（小球の表面）、mg は小球の中心。糸がまっすぐ下がっているときは同じ作用線の上に一直線（2026-10-13 千葉さん） */
        arr(bx-ux*rb, by-uy*rb, bx-ux*(rb+Sm), by-uy*(rb+Sm), K.S, 2.6, null, true);
        { let px=uy, py=-ux; if(py<0){ px=-px; py=-py; } vsym("S", bx-ux*(rb+Sm*0.55) + px*14 + (Math.abs(ux)<0.05? 13 : 0), by-uy*(rb+Sm*0.55) + py*14, K.S, 15); }   /* 記号は矢印の線からはなす（線と重ねない） */
        arr(bx, by, bx, by+LG, K.g, 2.6, null, true); vsym("mg", bx + 14, by+LG*0.6, K.g, 14, "m");
        if(rot && Math.abs(a) > 0.01){ const L2 = LG*Math.abs(a)/GG; arr(bx, by-1, bx-(a>0?1:-1)*L2*1.0, by-1, K.a, 4.2, [6,3], true); text("慣性力 ma", bx-(a>0?1:-1)*(L2+30), by-14, K.a, narrow? 10 : 11.5, "center", true); }
        /* 一緒に加速する観測者（電車の中・左がわ） */
        stick(tx + 0.5*ppm, yb, so*0.8, rot? K.obsA : K.obsB, rot? 2.4 : 1.6);
        if(!rot){
          if(Math.abs(a) > 0.01){ const La = 16 + 5*Math.abs(a); arr(tx+TL/2 - (a>0?1:-1)*La/2, yt-30, tx+TL/2 + (a>0?1:-1)*La/2, yt-30, K.a, 3); text("電車の加速度 a", tx+TL/2, yt-46, K.a, narrow? 10 : 11.5, "center", true); }
          const Lv = Math.min(TL*0.3, Math.abs(vel)*0.107*ppm); if(Lv > 3){ const xe = tx+TL/2 + Lv/2*Math.sign(vel); arr(tx+TL/2 - Lv/2*Math.sign(vel), yt-12, xe, yt-12, K.v, 2.2); text("電車の速度 v", xe + Math.sign(vel)*8, yt-12, K.v, narrow? 10 : 11.5, vel > 0 ? "left" : "right", true); }   /* 速度の矢印は前の 1/3 の長さ＋名前（2026-10-12 千葉さん） */
        }
      });
      ctx.restore();
      if(!narrow){
        text(rot? "一緒に加速する観測者" : "外の観測者", rot? x0+w/2 : ox, yg+16, K.obsA, 10.5, "center", true);
      }
      const T1 = narrow? (rot? "一緒に加速（非慣性系）" : "外から（慣性系）") : (rot? "一緒に加速運動する観測者（非慣性系）から見る" : "外の観測者（慣性系）から見る");
      text(T1, x0 + w/2, 14, "#f6f2e9", narrow? 11 : 13.5, "center", true);
      if(!narrow) text("加速度 a = " + (a>0? "+" : (a<0? "−" : "")) + Math.abs(a) + " m/s²" + (a===0? "（等速）" : ""), x0 + w - 12, 38, a===0? "rgba(243,239,230,.55)" : K.a, 11.5, "right", true);
    }
    function draw(){
      ctx.clearRect(0,0,W,H);
      const a = aAt(t), half = W/2;
      panel(0, half, false, a);
      ctx.save(); ctx.strokeStyle="rgba(255,255,255,.09)"; ctx.beginPath(); ctx.moveTo(half+.5, 10); ctx.lineTo(half+.5, H-10); ctx.stroke(); ctx.restore();
      panel(half, half, true, a);
    }
    /* 時間を進める：電車は v' = a、振り子は電車の中で θ'' = −(g/l)sin(θ − θ0)・… を小さな刻みで（減衰つき） */
    function adv(dt){
      const n = Math.max(1, Math.ceil(dt/0.004)), h = dt/n;
      for(let i=0;i<n;i++){
        const a = aAt(t), ge = Math.hypot(GG, a), th0 = -Math.atan2(a, GG);
        om += (-(ge/LEN)*Math.sin(th - th0) - 1.6*om)*h; th += om*h;
        const c0 = Math.floor(t/CYC); vel += a*h; xpos += vel*h; t += h;
        if(Math.floor(t/CYC) !== c0){ vel = V0; xpos = X0; th = 0; om = 0; }   /* 1 回りしたら、等速の状態から（振り子もまっすぐ）やりなおす */
      }
    }
    function frame(ts){
      if(!run) return;
      const dtm = last? Math.min(0.05,(ts-last)/1000) : 0; last = ts;
      adv(dtm*rate); draw();
      raf = requestAnimationFrame(frame);
    }
    function start(){ if(run || RM || paused) return; run = true; last = 0; raf = requestAnimationFrame(frame); }
    function stop(){ run = false; cancelAnimationFrame(raf); }
    setup(); adv(3.4); draw();
    window.__hero = { frame:(tt)=>{ stop(); t=0; th=0; om=0; xpos=X0; vel=V0; adv(tt); draw(); }, start, stop };
    let rz = 0; window.addEventListener("resize", ()=>{ clearTimeout(rz); rz = setTimeout(()=>{ setup(); draw(); }, 120); });
    if("IntersectionObserver" in window){
      new IntersectionObserver((es)=>{ es.forEach(en=>{ (en.isIntersecting && !document.hidden)? start() : stop(); }); }, {threshold:0.05}).observe(cv);
    } else start();
    document.addEventListener("visibilitychange", ()=>{ if(document.hidden) stop(); else { const r=cv.getBoundingClientRect(); if(r.bottom>0 && r.top<innerHeight) start(); } });
    const ctl = document.querySelector("#hero .stagectl");
    if(ctl){
      const pp = ctl.querySelector(".pp"), sl = ctl.querySelector(".slow");
      if(sl){ if(RM) sl.hidden = true;
        sl.addEventListener("click", ()=>{ rate = (rate===BASE? BASE*0.3 : BASE); sl.setAttribute("aria-pressed", rate<BASE? "true" : "false"); }); }
      if(pp){ if(RM){ pp.hidden = true; }
        pp.addEventListener("click", ()=>{ paused = !paused; pp.classList.toggle("paused", paused); pp.setAttribute("aria-label", paused? "再生" : "一時停止");
          if(paused){ stop(); draw(); } else { start(); } }); }
    }
    document.addEventListener("click", (ev)=>{ if(ev.target.closest && ev.target.closest("button.b.play")) stop(); }, true);
  }

  /* スライドバーの塗り：値が変わったら --p を書きかえる（プログラムから値を入れたときも、軽い見回りで拾う） */
  function syncRange(el){ const mn = parseFloat(el.min)||0, mx = parseFloat(el.max), v = parseFloat(el.value);
    const p = (isFinite(mx) && mx>mn)? (v-mn)/(mx-mn)*100 : 0; const s = p.toFixed(1)+"%";
    if(el._p !== s){ el._p = s; el.style.setProperty("--p", s); } }
  function initRanges(){
    document.addEventListener("input", (ev)=>{ if(ev.target && ev.target.type === "range") syncRange(ev.target); }, true);
    const sweep = ()=>{ if(document.hidden) return; document.querySelectorAll(".mode.on input[type=range], .modebar input[type=range]").forEach(syncRange); alignTicks(); };
    sweep(); setInterval(sweep, 120);
  }

  /* スライドバーの下の目盛りの文字（e=0・e=0.5・e=1）を、つまみの位置にきっちり合わせる（第 29 回）
     文字の列を「左右の余白」で合わせていたので、ラベルやボタンの幅が変わるとずれていた。
     スライドバーの実際の位置と幅を測り、つまみの中心が来る位置に 1 つずつ置く（等間隔の目盛りとして） */
  function alignTicks(){
    document.querySelectorAll(".mode.on .vrow.ticks, .modebar .vrow.ticks").forEach(tr=>{
      let row = tr.previousElementSibling; while(row && !row.querySelector("input[type=range]")) row = row.previousElementSibling;
      const inp = row && row.querySelector("input[type=range]"); if(!inp) return;
      const ri = inp.getBoundingClientRect(); if(ri.width < 10) return;
      tr.classList.add("tk-on");
      const rt = tr.getBoundingClientRect(), TH = 9, sp = tr.children, n = sp.length;
      const key = Math.round(ri.left - rt.left)+":"+Math.round(ri.width); if(tr._tk === key) return; tr._tk = key;
      for(let i=0; i<n; i++){ const f = n>1? i/(n-1) : 0.5; sp[i].style.left = (ri.left - rt.left + TH + f*(ri.width - 2*TH)).toFixed(1)+"px"; }
    });
  }
  window.addEventListener("resize", ()=>{ document.querySelectorAll(".vrow.ticks").forEach(t=>{ t._tk = null; }); alignTicks(); });

  /* タブ列の下の進み具合 */
  function initProgress(){
    const nav = document.getElementById("tabs"); if(!nav) return;
    let pend = false;
    const upd = ()=>{ pend = false; const h = document.documentElement, max = h.scrollHeight - innerHeight;
      nav.style.setProperty("--prog", max>0? Math.min(1, Math.max(0, scrollY/max)).toFixed(4) : 0); };
    window.addEventListener("scroll", ()=>{ if(!pend){ pend = true; requestAnimationFrame(upd); } }, {passive:true});
    window.addEventListener("resize", upd); upd();
  }

  /* ヒーローの 3 つの要点：その章を開いて、本文の頭までスクロール */
  function initIdeas(){
    document.querySelectorAll("#hero .ideas a").forEach(a=>{
      a.addEventListener("click", (ev)=>{ ev.preventDefault(); const id = a.getAttribute("href").slice(1);
        if(typeof activateMode === "function") activateMode(id);
        history.replaceState(null, "", "#"+id);
        window.scrollTo({top: (typeof contentTop === "function"? contentTop() : 0), behavior:"auto"}); });
    });
  }

  /* 「■ 見出し」の ■ を、色のついた小さな四角にする（文字の■は環境で形がばらつく） */
  function decorate(root){
    if(!root) return;
    root.querySelectorAll(".gtitle span, .stagetitle, .ttl, .mt").forEach(el=>{
      if(el.dataset.sq) return; const n = el.firstChild;
      if(n && n.nodeType === 3 && /^\s*■\s*/.test(n.nodeValue)){ n.nodeValue = n.nodeValue.replace(/^\s*■\s*/, ""); const i = document.createElement("i"); i.className = "sq"; i.setAttribute("aria-hidden","true"); el.insertBefore(i, n); }
      el.dataset.sq = "1";
    });
  }
  function initDecorate(){
    if(typeof activateMode !== "function") return;
    const orig = activateMode;
    const showTab = ()=>{ const row = document.querySelector("#tabs .tabs-in"), on = row && row.querySelector(".tab.on"); if(!on || row.scrollWidth <= row.clientWidth) return;
      const l = on.offsetLeft - 24, r = on.offsetLeft + on.offsetWidth + 24;
      if(l < row.scrollLeft) row.scrollLeft = l; else if(r > row.scrollLeft + row.clientWidth) row.scrollLeft = r - row.clientWidth; };   // スマホ：選んだタブが見えるように横に送る
    const cur = ()=>document.querySelectorAll("#tabs .tab").forEach(b=>{ if(b.classList.contains("on")) b.setAttribute("aria-current","page"); else b.removeAttribute("aria-current"); });
    activateMode = function(id){ const r = orig.apply(this, arguments); decorate(document.getElementById(id)); showTab(); cur(); return r; };   // 章を開いたあと（シムは初めて開いたときに作られる）
    showTab(); cur();
    document.querySelectorAll(".mode.on").forEach(decorate);
  }
  /* タブ列：ヒーローを過ぎたら .stuck */
  function initStuck(){
    const hero = document.getElementById("hero"), nav = document.getElementById("tabs"); if(!hero || !nav || !("IntersectionObserver" in window)) return;
    new IntersectionObserver((es)=>{ es.forEach(en=>nav.classList.toggle("stuck", !en.isIntersecting)); }, {threshold:0}).observe(hero);
    const nb = nav.querySelector(".navbrand"); if(nb) nb.addEventListener("click", (ev)=>{ ev.preventDefault(); window.scrollTo({top:0, behavior:"auto"}); });
  }
  /* フッター：題名と章の目次 */
  function initFooter(){
    const f = document.querySelector("#wrap footer") || document.querySelector("body > footer"); if(!f) return;
    document.body.appendChild(f);
    const C = "①②③④⑤⑥⑦⑧⑨";
    const items = (typeof MODES !== "undefined"? MODES : []).map((m,i)=>'<li><a href="#'+m.id+'" data-mode="'+m.id+'"><b>'+C[i]+'</b>'+m.name+'</a></li>').join("");
    f.innerHTML = '<div class="ft-in"><p class="ft-mark">Inertial Force<span>慣性力 〜外から見るか、一緒に加速して見るか〜</span></p>'+
      '<ul class="ft-nav">'+items+'</ul>'+
      '<div class="ft-base"><span><a class="ft-home" href="'+SITE_HOME+'">⌂ 楽楽（らくらく）高校物理 トップページ</a>　／　高校物理 ・ 力学</span><span class="ft-r"><button type="button" class="ft-pages">ほかのページ一覧</button><a href="#top" class="ft-top">▲ ページの一番上へ</a></span></div></div>';
    f.querySelectorAll("a[data-mode]").forEach(a=>a.addEventListener("click", (ev)=>{ ev.preventDefault(); const id = a.dataset.mode;
      activateMode(id); history.replaceState(null, "", "#"+id); window.scrollTo({top:(typeof contentTop==="function"? contentTop() : 0), behavior:"auto"}); }));
    const fp = f.querySelector(".ft-pages"); if(fp) fp.addEventListener("click", ()=>{ if(window.SITENAV) window.SITENAV.open(); });
    const tp = f.querySelector(".ft-top"); if(tp) tp.addEventListener("click", (ev)=>{ ev.preventDefault(); window.scrollTo({top:0, behavior:"auto"}); });
  }

  document.addEventListener("DOMContentLoaded", ()=>{
    initFooter(); initDecorate(); initStage(); initRanges(); initProgress(); initIdeas(); initStuck();
  });
})();

