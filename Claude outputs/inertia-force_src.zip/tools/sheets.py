# モード4（2016 東北大）の「問題」「解答と解き方」のシートを作る。
# HTML＋インライン SVG（図は新しく描き起こし）＋ KaTeX → Playwright で撮影 → 幅 1100・減色して src/assets/ へ。
# 問題文は著作権に配慮して言いまわしを書きかえている（設定・設問の内容は同じ）。
import math, os, sys
from playwright.sync_api import sync_playwright
from PIL import Image
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KX = 'file://' + os.path.join(ROOT, 'node_modules', 'katex', 'dist')
OUT = os.path.join(ROOT, 'src', 'assets')
TMP = os.path.join(ROOT, 'tools', '_tmp'); os.makedirs(TMP, exist_ok=True)

def wedge(kind):
    """kind: 1＝外力、2＝ばね、3＝ばね＋C（30°）"""
    th = math.radians(30); W = 470 if kind > 1 else 400; H = 215
    g = 178; xL = 40; xR = 290; top = g - (xR - xL) * math.tan(th)
    c, s = math.cos(th), math.sin(th)
    Ox, Oy = xL + 44 * c, g - 44 * s
    nx, ny = -s, -c
    r = 9
    bx, by = Ox + (r + 1) * c + nx * r, Oy - (r + 1) * s + ny * r
    o = ['<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d" font-family="Noto Serif CJK JP, serif">' % (W, H, W, H)]
    o.append('<defs><pattern id="h" width="8" height="8" patternUnits="userSpaceOnUse"><path d="M0 8 L8 0" stroke="#666" stroke-width="1"/></pattern></defs>')
    o.append('<rect x="10" y="%d" width="%d" height="9" fill="url(#h)"/><line x1="10" y1="%d" x2="%d" y2="%d" stroke="#222" stroke-width="1.6"/>' % (g, W - 20, g, W - 10, g))
    o.append('<path d="M%.1f %.1f L%.1f %.1f L%.1f %.1f Z" fill="#f3f1ec" stroke="#222" stroke-width="2"/>' % (xL, g, xR, g, xR, top))
    # 角 θ
    o.append('<path d="M%.1f %.1f A 22 22 0 0 0 %.1f %.1f" fill="none" stroke="#222" stroke-width="1.2"/>' % (xL + 22, g, xL + 22 * c, g - 22 * s))
    o.append('<text x="%.1f" y="%.1f" font-size="13" font-style="italic">%s</text>' % (xL + 25, g - 3, 'θ' if kind < 3 else '30°'))
    # 平板
    o.append('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="#222" stroke-width="4" stroke-linecap="round"/>' % (Ox, Oy, Ox + nx * 30, Oy + ny * 30))
    o.append('<text x="%.1f" y="%.1f" font-size="13" text-anchor="end">平板</text>' % (Ox + nx * 30 - 4, Oy + ny * 30 - 4))
    o.append('<text x="%.1f" y="%.1f" font-size="14">O</text>' % (Ox + 12, Oy + 16))
    o.append('<circle cx="%.1f" cy="%.1f" r="%d" fill="#fff" stroke="#222" stroke-width="1.6"/>' % (bx, by, r))
    # 軸 x, y
    ax0, ay0 = bx + c * 16, by - s * 16
    o.append('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="#222" stroke-width="1.2" marker-end="url(#ar)"/>' % (ax0, ay0, ax0 + c * 50, ay0 - s * 50))
    o.append('<text x="%.1f" y="%.1f" font-size="15" font-style="italic">x</text>' % (ax0 + c * 54 + 2, ay0 - s * 54 - 2))
    o.append('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="#222" stroke-width="1.2" marker-end="url(#ar)"/>' % (bx + nx * 12, by + ny * 12, bx + nx * 46, by + ny * 46))
    o.append('<text x="%.1f" y="%.1f" font-size="15" font-style="italic">y</text>' % (bx + nx * 50 - 8, by + ny * 50))
    o.insert(1, '<defs><marker id="ar" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto"><path d="M0 0 L9 4.5 L0 9 Z" fill="#222"/></marker></defs>')
    nm = 'C' if kind == 3 else 'B'
    o.append('<text x="%.1f" y="%.1f" font-size="14">小球 %s（質量 <tspan font-style="italic">m</tspan><tspan font-size="10" baseline-shift="sub">%s</tspan>）</text>' % (bx + 4, by - 80, nm, nm))
    o.append('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="#444" stroke-width="0.8"/>' % (bx + 2, by - 10, bx + 16, by - 74))
    o.append('<text x="%.1f" y="%.1f" font-size="14">物体 A（質量 <tspan font-style="italic">m</tspan><tspan font-size="10" baseline-shift="sub">A</tspan>）</text>' % (xL + 120, g - 22))
    o.append('<text x="%.1f" y="%.1f" font-size="15">P</text>' % (xR - 4, top - 8))
    if kind == 1:
        y = g - 34; x = xR + 8
        o.append('<path d="M%.1f %.1f l20 -13 v7 h44 v12 h-44 v7 Z" fill="#fff" stroke="#222" stroke-width="1.5"/>' % (x, y))
        o.append('<text x="%.1f" y="%.1f" font-size="14">外力</text>' % (x + 70, y + 5))
    else:
        ys = g - 30; xw = 420
        pts = ['%.1f %.1f' % (xR, ys), '%.1f %.1f' % (xR + 18, ys)]
        n = 12
        for i in range(1, n * 2):
            pts.append('%.1f %.1f' % (xR + 18 + (xw - xR - 36) * i / (n * 2), ys + (7 if i % 2 else -7)))
        pts += ['%.1f %.1f' % (xw - 18, ys), '%.1f %.1f' % (xw, ys)]
        o.append('<polyline points="%s" fill="none" stroke="#222" stroke-width="1.4"/>' % ' '.join(pts))
        o.append('<rect x="%d" y="%d" width="14" height="70" fill="url(#h)" stroke="#222"/>' % (xw, g - 70))
        o.append('<text x="%.1f" y="%.1f" font-size="14">ばね（ばね定数 <tspan font-style="italic">k</tspan>）</text>' % (xR + 14, ys - 16))
    o.append('<text x="%.1f" y="%d" font-size="14" text-anchor="middle">図%d</text>' % (W / 2, H - 6, kind))
    o.append('</svg>')
    return ''.join(o)

def graph():
    W, H = 460, 300; x0, y0 = 60, 250; xw, yh = 360, 220; XM, YM = 1.6, 2.2   # 縦軸は L を m_A g/k 単位
    X = lambda t: x0 + t / XM * xw; Y = lambda L: y0 - L / YM * yh
    o = ['<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" font-family="Noto Serif CJK JP, serif">' % (W, H)]
    o.append('<defs><pattern id="hh" width="7" height="7" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="7" stroke="#d07010" stroke-width="1.3"/></pattern>'
             '<marker id="ar2" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto"><path d="M0 0 L9 4.5 L0 9 Z" fill="#222"/></marker></defs>')
    poly = []
    for i in range(61):
        t = 1e-3 + (1 - 1e-3) * i / 60; poly.append('%.1f,%.1f' % (X(t), Y(min(YM, 1 / t))))
    for i in range(60, -1, -1):
        t = i / 60; poly.append('%.1f,%.1f' % (X(t), Y(t)))
    o.append('<polygon points="%s" fill="url(#hh)" stroke="none"/>' % ' '.join(poly))
    o.append('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="#2f3a8f" stroke-width="2"/>' % (X(0), Y(0), X(XM), Y(XM)))
    pts = ' '.join('%.1f,%.1f' % (X(t), Y(1 / t)) for t in [1 / YM + (XM - 1 / YM) * i / 100 for i in range(101)])
    o.append('<polyline points="%s" fill="none" stroke="#c0392b" stroke-width="2"/>' % pts)
    o.append('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="#222" stroke-width="1.4" marker-end="url(#ar2)"/>' % (x0, y0, x0 + xw + 20, y0))
    o.append('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="#222" stroke-width="1.4" marker-end="url(#ar2)"/>' % (x0, y0, x0, y0 - yh - 20))
    o.append('<text x="%d" y="%d" font-size="16" font-style="italic">L</text>' % (x0 - 22, y0 - yh - 8))
    o.append('<text x="%d" y="%d" font-size="15">tan<tspan font-style="italic">θ</tspan></text>' % (x0 + xw + 6, y0 + 22))
    o.append('<line x1="%.1f" y1="%d" x2="%.1f" y2="%.1f" stroke="#555" stroke-dasharray="4 3"/><line x1="%d" y1="%.1f" x2="%.1f" y2="%.1f" stroke="#555" stroke-dasharray="4 3"/>' % (X(1), y0, X(1), Y(1), x0, Y(1), X(1), Y(1)))
    o.append('<text x="%.1f" y="%d" font-size="14" text-anchor="middle">1</text><text x="%.1f" y="%d" font-size="12" text-anchor="middle">（θ = 45°）</text>' % (X(1), y0 + 18, X(1), y0 + 34))
    o.append('<text x="%d" y="%.1f" font-size="13" text-anchor="end"><tspan font-style="italic">m</tspan><tspan font-size="9" baseline-shift="sub">A</tspan><tspan font-style="italic">g</tspan>/<tspan font-style="italic">k</tspan></text>' % (x0 - 4, Y(1) + 4))
    o.append('<text x="%d" y="%d" font-size="13">O</text>' % (x0 - 14, y0 + 16))
    o.append('<text x="%.1f" y="%.1f" font-size="13" fill="#2f3a8f">(a) の境界 L = (m<tspan font-size="9" baseline-shift="sub">A</tspan>g/k) tanθ</text>' % (X(0.84), Y(1.62)))
    o.append('<text x="%.1f" y="%.1f" font-size="13" fill="#c0392b">(b) の境界 L = (m<tspan font-size="9" baseline-shift="sub">A</tspan>g/k)/tanθ</text>' % (X(0.52), Y(2.12)))
    o.append('<text x="%.1f" y="%.1f" font-size="13" fill="#9c4e06">斜線部が答えの範囲</text>' % (X(0.08), Y(0.62)))
    o.append('</svg>')
    return ''.join(o)

CSS = '''
body{margin:0;background:#fff;font-family:"Noto Serif CJK JP","Noto Sans CJK JP",serif;color:#1b1f24}
.sheet{width:1060px;padding:34px 40px 30px;box-sizing:border-box;font-size:17px;line-height:1.85}
h1{font-size:22px;margin:0 0 4px;font-family:"Noto Sans CJK JP",sans-serif}
.sub{font-size:13px;color:#5b6672;margin:0 0 14px}
.figs{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin:8px 0 6px}
.q{margin:12px 0 4px;font-weight:700;font-family:"Noto Sans CJK JP",sans-serif}
.qq{margin:2px 0 6px 1.6em;text-indent:-1.6em}
.note{font-size:13px;color:#5b6672;border-top:1px solid #ddd;margin-top:18px;padding-top:8px;line-height:1.6}
.box{border:2px solid #3f4a54;border-radius:10px;padding:10px 16px;margin:8px 0 14px}
table.ans{border-collapse:collapse;width:100%;margin:6px 0 14px;font-size:16px}
table.ans th,table.ans td{border:1px solid #bbb;padding:6px 10px;text-align:left}
table.ans th{background:#f3f1ec;width:6em}
.h2{font-size:18px;font-weight:800;margin:18px 0 4px;font-family:"Noto Sans CJK JP",sans-serif;border-left:6px solid #1663b5;padding-left:8px}
.pt{background:#e3eefb;border-radius:8px;padding:6px 12px;margin:6px 0}
.katex{font-size:1.05em}
'''
def page(body):
    return ('<!doctype html><html><head><meta charset="utf-8"><link rel="stylesheet" href="%s/katex.min.css">'
            '<script src="%s/katex.min.js"></script><script src="%s/contrib/auto-render.min.js"></script><style>%s</style></head>'
            '<body><div class="sheet">%s</div><script>renderMathInElement(document.body,{delimiters:[{left:"$$",right:"$$",display:true},{left:"$",right:"$",display:false}]});</script></body></html>') % (KX, KX, KX, CSS, body)

PROB = '''
<h1>入試物理：斜面をもつ台の上の小球（2016 東北大）</h1>
<p class="sub">※ このページ用に、問題文の言いまわしを書きかえ、図を新しく描き起こしたものです（設定と設問の内容は同じ）。</p>
<p>　図1のように、断面が直角三角形で質量 $m_\\mathrm{A}$ の物体 A が水平な床の上に置かれ、A の上に質量 $m_\\mathrm{B}$ の小球 B が置かれている。A の斜面上の点 O には、斜面に垂直な平板が固定されていて、B は O より下へは動けない。O から斜面にそって頂点 P へ向かう向きを $x$ 軸、斜面に垂直で上向きを $y$ 軸とする。物体はすべて紙面内だけで運動し、A の底面が床から離れることはない。小球の大きさ、すべての面の摩擦、空気の抵抗、平板の質量は無視でき、重力加速度の大きさを $g$、A の傾角を $\\theta\\ (0^\\circ<\\theta<90^\\circ)$ とする。</p>
<div class="figs">%(f1)s%(f2)s%(f3)s</div>
<p class="q">(1)</p><p>はじめ重力以外の外力はなく、B は O で静止している。ある時刻から、図1のように A に水平方向の外力を加えた。</p>
<p class="qq">(a)　A は加速度 $a_\\mathrm{A}$ で動き始めた（$a_\\mathrm{A}$ は床に固定した観測点から見た加速度で、図1の左向きを正とする）。A に固定した観測点から見ると、B には A の加速度と逆向きに大きさ $|m_\\mathrm{B}a_\\mathrm{A}|$ の慣性力がはたらいていると考えられる。B にはたらく重力と慣性力の合力 $\\vec{F}$ の $x$ 成分 $F_x$ と $y$ 成分 $F_y$ を、それぞれ $m_\\mathrm{A},\\,m_\\mathrm{B},\\,g,\\,\\theta,\\,a_\\mathrm{A}$ のうち必要なものを用いて表せ。</p>
<p class="qq">(b)　(a) で、B が $x$ 軸方向へ動き出すために $a_\\mathrm{A}$ が満たすべき条件を、$m_\\mathrm{A},\\,m_\\mathrm{B},\\,g,\\,\\theta$ のうち必要なものを用いて表せ。</p>
<p class="q">(2)</p><p>図2のように、A にばね定数 $k$ のばねをつけ、ばねのもう一方のはしを床に固定した壁につなぐ。ばねの質量は無視できる。O から P までは十分に長く、B が P に達することはない。また、B の質量は A に比べて十分に小さく、A の運動を考えるときに B の影響は無視できる。</p>
<p class="qq">(a)　ばねが自然の長さより $L$ だけ短くなるように A を水平に動かし、静かに手をはなす。このとき O にある B が $x$ 軸方向へ動き出すために $L$ が満たすべき条件を、$m_\\mathrm{A},\\,m_\\mathrm{B},\\,g,\\,k,\\,\\theta$ のうち必要なものを用いて表せ。</p>
<p class="qq">(b)　A と B が (a) で動き出したあとの運動を考える。B が A の斜面から離れずに接し続けるために $L$ が満たすべき条件を、$m_\\mathrm{A},\\,m_\\mathrm{B},\\,g,\\,k,\\,\\theta$ のうち必要なものを用いて表せ。</p>
<p class="qq">(c)　(2) の (a)(b) をともに満たす $L$ の範囲は、傾角 $\\theta$ によって変わる。そして、ある傾角 $\\theta_\\mathrm{max}$ 以上では、(a)(b) をともに満たす $L$ は存在しない。$\\theta_\\mathrm{max}$ の値を求めよ。また、(a)(b) をともに満たす $L$ の範囲と $\\theta$ の関係を図に示せ。図は $L$ を縦軸とし、横軸は $\\sin\\theta,\\,\\cos\\theta,\\,\\tan\\theta$ から適切なものを1つ選ぶこと。範囲は斜線でぬること（境界線をふくむかどうかは示さなくてよい）。</p>
<p class="q">(3)</p><p>図3のように、小球 B を質量 $m_\\mathrm{C}$ の小球 C にとりかえる。B と C のちがいは質量だけである。こんどは、A の運動に対する C の影響を無視しない。また $\\theta=30^\\circ$ とする。それ以外の条件は (2) と同じとする。</p>
<p class="qq">(a)　ばねが自然の長さより $L$ だけ短くなるように A を水平に動かし、静かに手をはなすと、C は O から $x$ 軸方向へ動き出し、斜面から離れることなく O にもどってきた。C は O にもどるときに平板と衝突し、衝突直前の平板に対する C の相対速度の大きさは $v_\\mathrm{C}$ であった。一方、衝突直前の A と平板の速度は $v_\\mathrm{A}$、衝突直後の A と平板の速度は $v_\\mathrm{A}'$ であった。$v_\\mathrm{A}$ と $v_\\mathrm{A}'$ は床に固定した観測点から見た速度で、図3の左向きを正とする。衝突直後の A の速度 $v_\\mathrm{A}'$ を、$v_\\mathrm{A},\\,v_\\mathrm{C},\\,m_\\mathrm{A},\\,m_\\mathrm{C},\\,g,\\,k,\\,L$ のうち必要なものを用いて表せ。ただし、C と平板の間の反発係数は 0 で、衝突は一瞬で起こるものとする。</p>
<p class="qq">(b)　(3)(a) の衝突は、A が動き出してからばねが最ものびるまでの間に起こった。そして、衝突のあとばねが最ものびたとき、ばねは自然の長さより $L'$ だけ長かった。$L'$ を、$v_\\mathrm{A},\\,v_\\mathrm{C},\\,m_\\mathrm{A},\\,m_\\mathrm{C},\\,g,\\,k,\\,L$ のうち必要なものを用いて表せ。</p>
<p class="note">※ 2016 年度 東北大学 前期日程「物理」の問題をもとに、教材として使うため、問題文の言いまわしを書きかえ、図を新しく描き起こしました。原典の図・文章をそのまま複製したものではありません。</p>
'''

ANS = '''
<h1>解答と解き方：斜面をもつ台の上の小球（2016 東北大）</h1>
<p class="sub">※ このページ用に作った解答・解説です。向きは問題と同じく、A の加速度・速度は左向きを正、$x$ 軸は O から P へ、$y$ 軸は斜面に垂直で上向き。</p>
<table class="ans"><tbody>
<tr><th>(1)(a)</th><td>$F_x = m_\\mathrm{B}(a_\\mathrm{A}\\cos\\theta - g\\sin\\theta)$、$F_y = -m_\\mathrm{B}(g\\cos\\theta + a_\\mathrm{A}\\sin\\theta)$</td></tr>
<tr><th>(1)(b)</th><td>$a_\\mathrm{A} > g\\tan\\theta$</td></tr>
<tr><th>(2)(a)</th><td>$L > \\dfrac{m_\\mathrm{A}g\\tan\\theta}{k}$</td></tr>
<tr><th>(2)(b)</th><td>$L \\le \\dfrac{m_\\mathrm{A}g}{k\\tan\\theta}$</td></tr>
<tr><th>(2)(c)</th><td>$\\theta_\\mathrm{max} = 45^\\circ$（図は下）</td></tr>
<tr><th>(3)(a)</th><td>$v_\\mathrm{A}' = v_\\mathrm{A} + \\dfrac{\\sqrt3\\,m_\\mathrm{C}v_\\mathrm{C}}{2(m_\\mathrm{A}+m_\\mathrm{C})}$</td></tr>
<tr><th>(3)(b)</th><td>$L' = \\sqrt{L^2 - \\dfrac{(4m_\\mathrm{A}+m_\\mathrm{C})\\,m_\\mathrm{C}v_\\mathrm{C}^2}{4k(m_\\mathrm{A}+m_\\mathrm{C})}}$</td></tr>
</tbody></table>
<div class="box"><b>全体の考え方</b>：どの小問も「<b>A と一緒に運動する観測者（非慣性系）</b>」の立場に立つと、B（C）は斜面にそってまっすぐ動くだけになる。B（C）には、重力のほかに、A の加速度と逆向きの慣性力がはたらいていると考える。<b>どの観測者の立場で式を立てたかを、必ず書くこと。</b></div>
<p class="h2">(1)(a)　重力と慣性力を x・y に分ける</p>
<p>A に固定した観測点から見ると、B には重力 $m_\\mathrm{B}g$（鉛直下向き）と慣性力 $m_\\mathrm{B}a_\\mathrm{A}$（A の加速度と逆向き＝右向き）がはたらく。斜面は右上がりなので、右向きの力の $x$ 成分は $+\\cos\\theta$ 倍、$y$ 成分は $-\\sin\\theta$ 倍（斜面に押しつける向き）。</p>
<p class="pt">重力：$(-m_\\mathrm{B}g\\sin\\theta,\\ -m_\\mathrm{B}g\\cos\\theta)$、慣性力：$(+m_\\mathrm{B}a_\\mathrm{A}\\cos\\theta,\\ -m_\\mathrm{B}a_\\mathrm{A}\\sin\\theta)$<br>
よって $F_x = m_\\mathrm{B}(a_\\mathrm{A}\\cos\\theta - g\\sin\\theta)$、$F_y = -m_\\mathrm{B}(g\\cos\\theta + a_\\mathrm{A}\\sin\\theta)$</p>
<p class="h2">(1)(b)　動き出す条件</p>
<p>平板は B を $+x$ の向きにしか押せない。$F_x \\le 0$ なら平板が押し返してつり合い、$F_x>0$ なら B は $x$ 軸方向へ動き出す。$F_x>0 \\iff a_\\mathrm{A}\\cos\\theta > g\\sin\\theta \\iff a_\\mathrm{A} > g\\tan\\theta$。</p>
<p class="h2">(2)(a)　加速度がいちばん大きい瞬間で考える</p>
<p>A はばねの力で単振動する（B の影響は無視）。A の加速度は手をはなした直後が最大で、$a_\\mathrm{A} = \\dfrac{kL}{m_\\mathrm{A}}$（左向き）。そのあとは小さくなるので、この瞬間に (1)(b) の条件を満たせばよい：$\\dfrac{kL}{m_\\mathrm{A}} > g\\tan\\theta$ より $L > \\dfrac{m_\\mathrm{A}g\\tan\\theta}{k}$。</p>
<p class="h2">(2)(b)　斜面から離れない条件</p>
<p>B が斜面に接しているとき、$y$ 方向は垂直抗力 $N$ と $F_y$ がつり合う：$N = -F_y = m_\\mathrm{B}(g\\cos\\theta + a_\\mathrm{A}\\sin\\theta)$。離れないためには、いつも $N\\ge 0$。単振動なので $a_\\mathrm{A}$ は $-\\dfrac{kL}{m_\\mathrm{A}}$ から $\\dfrac{kL}{m_\\mathrm{A}}$ まで変わり、いちばんきびしいのは右向きに最大のとき（ばねが最ものびたとき）：</p>
<p class="pt">$g\\cos\\theta - \\dfrac{kL}{m_\\mathrm{A}}\\sin\\theta \\ge 0 \;\\Longrightarrow\; L \\le \\dfrac{m_\\mathrm{A}g}{k\\tan\\theta}$</p>
<p class="h2">(2)(c)　両方を満たす範囲</p>
<p>$\\dfrac{m_\\mathrm{A}g}{k}\\tan\\theta < L \\le \\dfrac{m_\\mathrm{A}g}{k}\\cdot\\dfrac{1}{\\tan\\theta}$ をみたす $L$ があるのは、$\\tan\\theta < \\dfrac{1}{\\tan\\theta}$、つまり $\\tan\\theta<1$ のとき。よって $\\theta_\\mathrm{max} = 45^\\circ$。横軸に $\\tan\\theta$ をとると、下の境界が直線、上の境界が反比例の曲線になる。</p>
<div class="figs">%(g)s</div>
<p class="h2">(3)(a)　衝突：水平方向の運動量保存</p>
<p>衝突直前、床から見た C の速度は「A の速度＋A に対する速度」。A に対しては斜面にそって下向きに $v_\\mathrm{C}$ なので、水平（左向き正）$v_\\mathrm{A} + v_\\mathrm{C}\\cos30^\\circ = v_\\mathrm{A} + \\dfrac{\\sqrt3}{2}v_\\mathrm{C}$、鉛直（下向き）$\\dfrac12 v_\\mathrm{C}$。衝突は一瞬で、そのあいだに水平方向の力積を外から受けない（ばねの力は有限、床の力は鉛直）。反発係数 0 なので、衝突後 C は A と同じ速度。</p>
<p class="pt">$m_\\mathrm{A}v_\\mathrm{A} + m_\\mathrm{C}\\left(v_\\mathrm{A} + \\dfrac{\\sqrt3}{2}v_\\mathrm{C}\\right) = (m_\\mathrm{A}+m_\\mathrm{C})v_\\mathrm{A}' \;\\Longrightarrow\; v_\\mathrm{A}' = v_\\mathrm{A} + \\dfrac{\\sqrt3\\,m_\\mathrm{C}v_\\mathrm{C}}{2(m_\\mathrm{A}+m_\\mathrm{C})}$</p>
<p>※ 鉛直方向の運動量は保存しない（床が A に力積を与える）。</p>
<p class="h2">(3)(b)　衝突の前・後で、それぞれ力学的エネルギー保存</p>
<p>衝突のときのばねの伸びを $x$ とする。C は O にもどっているので、高さははじめと同じ。</p>
<p class="pt">衝突前：$\\dfrac12 kL^2 = \\dfrac12 m_\\mathrm{A}v_\\mathrm{A}^2 + \\dfrac12 m_\\mathrm{C}\\left\\{\\left(v_\\mathrm{A}+\\dfrac{\\sqrt3}{2}v_\\mathrm{C}\\right)^2 + \\left(\\dfrac12 v_\\mathrm{C}\\right)^2\\right\\} + \\dfrac12 kx^2$<br>
衝突後：$\\dfrac12 (m_\\mathrm{A}+m_\\mathrm{C})v_\\mathrm{A}'^2 + \\dfrac12 kx^2 = \\dfrac12 kL'^2$</p>
<p>2 式から $kx^2$ を消し、(a) の $v_\\mathrm{A}'$ を入れると、$v_\\mathrm{A}$ をふくむ項はすべて消えて</p>
<p class="pt">$kL'^2 = kL^2 - m_\\mathrm{C}v_\\mathrm{C}^2\\cdot\\dfrac{m_\\mathrm{A} + m_\\mathrm{C}\\sin^2 30^\\circ}{m_\\mathrm{A}+m_\\mathrm{C}} \;\\Longrightarrow\; L' = \\sqrt{L^2 - \\dfrac{(4m_\\mathrm{A}+m_\\mathrm{C})\\,m_\\mathrm{C}v_\\mathrm{C}^2}{4k(m_\\mathrm{A}+m_\\mathrm{C})}}$</p>
<p>シミュレーション（$m_\\mathrm{A}=1.0$ kg、$m_\\mathrm{C}=0.50$ kg、$k=49$ N/m、$L=0.30$ m）で運動方程式を数値で解くと、$v_\\mathrm{C}=1.504$ m/s、衝突後に最ものびたときの伸びは 0.2696 m で、この式の値 0.2696 m と一致する。</p>
<p class="note">※ 2016 年度 東北大学 前期日程「物理」の問題をもとに、このページ用に作った解答・解説です。</p>
'''

def shoot(html, name):
    p = os.path.join(TMP, name + '.html'); open(p, 'w').write(html)
    png = os.path.join(TMP, name + '.png')
    with sync_playwright() as pw:
        b = pw.chromium.launch(); pg = b.new_page(viewport={'width': 1060, 'height': 800}, device_scale_factor=1.25)
        pg.goto('file://' + p); pg.wait_for_timeout(600)
        pg.locator('.sheet').screenshot(path=png); b.close()
    im = Image.open(png).convert('RGB')
    w = 1100; im = im.resize((w, round(im.height * w / im.width)), Image.LANCZOS)
    im = im.quantize(colors=64, method=Image.Quantize.MEDIANCUT)
    out = os.path.join(OUT, name + '.png'); im.save(out, optimize=True)
    print(name, im.size, os.path.getsize(out) // 1024, 'KB')

shoot(page(PROB % {'f1': wedge(1), 'f2': wedge(2), 'f3': wedge(3)}), 'm4_prob')
shoot(page(ANS % {'g': graph()}), 'm4_ans')
