#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ページの骨組み（meter-bridge.html と同じ並び）の自動テスト。光の干渉 3 ページで同じものを使う。

  python3 test/shell_check.py <ページの HTML> <タブの id を順に , 区切り> <ページの場所（wave/○○.html）>

run_test.py から呼ばれ、結果を JSON で標準出力に出す（{"bad": [...], "facts": {...}}）。
facts は 2 回走らせて完全一致を確かめるための値。単独でも実行できる。

確かめること
  1. ページのエラー 0・コンソールのエラー 0・外部への通信 0（file:// ではアクセス数のカウントも読まない）
  2. タブの並び（①実際の波の動きを見る → ②光路差の位置と式の原理 → …）、最初に開くのは ①
  3. どのタブを押しても、章の扉の番号と名前がそのタブと合う／アドレスが #モード名 になる
  4. タブ列が上に固定される／下までスクロールしてタブを押すと、本文の頭までもどる
  5. コンテンツ一覧・ページ一覧（「いま見ているページ」の印が 1 つ）・ホームへのリンク 3 か所・フッター
  6. 共通フッター：開いた直後に ▶ スタートが光る → 押すと消える
  7. 画面の幅と向き（スマホ・小さいタブレット・タブレット・パソコン・横置き）× 全モードで
     横スクロールなし、タブがどれも画面の外に取り残されない、図が画面の幅に収まるか「図だけを大きく表示」が出る
"""
import json
import os
import sys

from playwright.sync_api import sync_playwright

HOME = 'https://physics-chiba.github.io/physics-site/'
# （幅, 高さ, 呼び名）
SIZES = [
    (320, 640, 'スマホ（小）たて'), (360, 740, 'スマホ たて'), (390, 844, 'スマホ たて'), (430, 932, 'スマホ（大）たて'),
    (600, 960, '小さいタブレット たて'), (768, 1024, 'タブレット たて'), (820, 1180, 'タブレット たて'),
    (1024, 768, 'タブレット よこ'), (1180, 820, 'タブレット よこ'), (1280, 800, 'ノート PC'), (1440, 900, 'PC'),
    (844, 390, 'スマホ よこ'), (740, 360, 'スマホ（小）よこ'), (960, 600, '小さいタブレット よこ'),
]


def main():
    page_path, tab_ids, here = sys.argv[1], sys.argv[2].split(','), sys.argv[3]
    bad, facts = [], {}
    html = open(page_path, encoding='utf-8').read()
    for k in ('physics-chiba.goatcounter.com', 'sg-glow', 'id="hero"', 'id="tabs"', 'id="modehead"', 'buildSiteDrawer'):
        if k not in html:
            bad.append('HTML に %s がありません' % k)
    with sync_playwright() as pw:
        br = pw.chromium.launch()
        pg = br.new_page(viewport={'width': 1440, 'height': 900})
        errors, cerr, ext = [], [], []
        pg.on('pageerror', lambda e: errors.append(str(e)))
        pg.on('console', lambda m: cerr.append(m.text) if m.type == 'error' else None)
        pg.on('request', lambda r: None if r.url.startswith(('file:', 'data:', 'blob:')) else ext.append(r.url))
        pg.goto('file://' + page_path)
        pg.wait_for_function('window.SHELL && document.querySelector("#modehead h2")', timeout=15000)
        pg.wait_for_timeout(900)

        # ---- 6. スタートが光る → 押すと消える（開いた直後に見る）
        glow0 = pg.evaluate("() => { const b = document.getElementById('btn-play'); return !!b && b.offsetParent !== null && b.classList.contains('sg-glow'); }")
        if not glow0:
            bad.append('開いた直後に ▶ スタートが光っていません')
        pg.click('#btn-play'); pg.wait_for_timeout(200)
        if pg.evaluate("() => document.getElementById('btn-play').classList.contains('sg-glow')"):
            bad.append('▶ スタートを押しても光が消えません')
        running = pg.evaluate("() => document.getElementById('btn-play').textContent")
        pg.click('#btn-play'); pg.wait_for_timeout(150)          # 止めておく（あとの測定を安定させる）
        facts['play_label_running'] = running

        # ---- 2. タブの並び
        tabs = pg.evaluate("""() => [...document.querySelectorAll('#tabs .tab')].map(b => ({id: b.id.replace('tab-', ''),
            num: b.querySelector('.tn').textContent, name: b.querySelector('.tl').textContent,
            full: b.getAttribute('data-full') || b.querySelector('.tl').textContent, sel: b.getAttribute('aria-selected')}))""")
        facts['tabs'] = tabs
        if [t['id'] for t in tabs] != tab_ids:
            bad.append('タブの並びがちがいます: %s' % [t['id'] for t in tabs])
        if [t['num'] for t in tabs] != list('①②③④⑤⑥⑦⑧⑨'[:len(tabs)]):
            bad.append('タブの番号がちがいます')
        if tabs[0]['name'] != '実際の波の動きを見る' or tabs[1]['name'] != '光路差の位置と式の原理':
            bad.append('① ② の名前がちがいます: %s / %s' % (tabs[0]['name'], tabs[1]['name']))
        if [t['sel'] for t in tabs] != ['true'] + ['false'] * (len(tabs) - 1):
            bad.append('最初に開いているのが ① ではありません')

        # ---- 3. タブを順に押す
        heads = []
        for i, t in enumerate(tabs):
            pg.click('#tab-' + t['id']); pg.wait_for_timeout(200)
            h = pg.evaluate("""() => ({num: document.querySelector('#modehead .mh-num span').textContent,
                name: document.querySelector('#modehead h2').textContent, en: document.querySelector('#modehead .mh-en').textContent,
                lead: document.querySelector('#modehead .mh-lead').textContent.length,
                sel: [...document.querySelectorAll('#tabs .tab')].filter(b => b.getAttribute('aria-selected') === 'true').map(b => b.id),
                hash: location.hash, canvas: (document.querySelector('canvas#view') || {}).offsetWidth || 0})""")
            heads.append(h)
            if h['num'] != str(i + 1) or h['name'] != '①②③④⑤⑥⑦⑧⑨'[i] + t['full']:
                bad.append('章の扉がタブ %s と合いません: %s' % (t['id'], h))
            if h['sel'] != ['tab-' + t['id']] or h['hash'] != '#' + t['id']:
                bad.append('タブ %s：選択中の印かアドレスがちがいます: %s' % (t['id'], h))
            if h['lead'] < 10 or 'Chapter 0%d' % (i + 1) not in h['en']:
                bad.append('タブ %s：章の扉のリード・英字の副題がありません' % t['id'])
            if h['canvas'] < 200:
                bad.append('タブ %s：図（canvas）が出ていません' % t['id'])
        facts['heads'] = heads
        pg.click('#tab-' + tabs[0]['id']); pg.wait_for_timeout(150)

        # ---- 4. 上に固定・本文の頭へもどる
        pg.evaluate('() => window.scrollTo(0, 1400)'); pg.wait_for_timeout(200)
        top = pg.evaluate("() => Math.round(document.getElementById('tabs').getBoundingClientRect().top)")
        if top != 0:
            bad.append('下へスクロールしたとき、タブ列が上に固定されていません（top=%s）' % top)
        pg.click('#tab-' + tabs[1]['id']); pg.wait_for_timeout(250)
        back = pg.evaluate('() => ({y: Math.round(window.pageYOffset), top: Math.round(window.SHELL.contentTop())})')
        if abs(back['y'] - back['top']) > 1:
            bad.append('タブを押しても本文の頭にもどりません: %s' % back)
        facts['back'] = back
        pg.click('#tab-' + tabs[0]['id']); pg.wait_for_timeout(150)

        # ---- 5. コンテンツ一覧
        pg.evaluate('() => window.scrollTo(0, 0)')
        pg.click('#bToc'); pg.wait_for_timeout(150)
        toc = pg.evaluate("""() => { const p = document.getElementById('tocpanel'); const r = p.getBoundingClientRect();
            return {hidden: p.hidden, modes: p.querySelectorAll('a[data-mode]').length, secs: p.querySelectorAll('a[data-sec]').length,
                    inView: r.left >= 0 && r.right <= innerWidth && r.top >= 0}; }""")
        facts['toc'] = toc
        if toc['hidden'] or toc['modes'] != len(tabs) or toc['secs'] < 3 or not toc['inView']:
            bad.append('コンテンツ一覧がおかしい: %s' % toc)
        pg.click('#tocpanel a[data-sec="sec-quiz"]'); pg.wait_for_timeout(450)
        sec = pg.evaluate("""() => ({hidden: document.getElementById('tocpanel').hidden,
            gap: Math.round(document.getElementById('sec-quiz').getBoundingClientRect().top - window.SHELL.tabbarH()), hash: location.hash})""")
        if not sec['hidden'] or abs(sec['gap'] - 8) > 3 or sec['hash'] != '#sec-quiz':
            bad.append('コンテンツ一覧から「練習問題」へ飛んだ位置がおかしい: %s' % sec)
        # ページ一覧
        pg.evaluate('() => window.scrollTo(0, 0)'); pg.wait_for_timeout(100)
        pg.click('#bPages'); pg.wait_for_timeout(450)
        dr = pg.evaluate("""() => { const d = document.getElementById('siteDrawer');
            return {on: d.classList.contains('on') && !d.hidden, links: d.querySelectorAll('.dr-sec a').length,
                    cur: [...d.querySelectorAll('a.cur')].map(a => a.getAttribute('href'))}; }""")
        facts['drawer'] = dr
        if not dr['on'] or dr['links'] < 15 or dr['cur'] != [HOME + here]:
            bad.append('ページ一覧がおかしい（「いま見ているページ」は 1 つのはず）: %s' % dr)
        pg.keyboard.press('Escape'); pg.wait_for_timeout(450)
        if not pg.evaluate("() => document.getElementById('siteDrawer').hidden"):
            bad.append('Esc でページ一覧が閉じません')
        homes = pg.evaluate("() => ['.crumb-home', '.navhome', '.ft-home'].map(s => (document.querySelector(s) || {href: ''}).href)")
        if homes != [HOME] * 3:
            bad.append('ホームへのリンク 3 か所がそろっていません: %s' % homes)
        foot = pg.evaluate("() => { const f = document.querySelector('footer.pagefoot'); return f ? f.querySelectorAll('.ft-nav a').length : -1; }")
        facts['foot'] = foot
        if foot != len(tabs) + 3:
            bad.append('フッターの目次が %d 件（%d 件のはず）' % (foot, len(tabs) + 3))
        # アドレスで直接開く
        pg.goto('file://' + page_path + '#' + tabs[2]['id']); pg.reload()
        pg.wait_for_function('window.SHELL && document.querySelector("#modehead h2")', timeout=15000); pg.wait_for_timeout(500)
        direct = pg.evaluate("() => [...document.querySelectorAll('#tabs .tab')].filter(b => b.getAttribute('aria-selected') === 'true').map(b => b.id)")
        if direct != ['tab-' + tabs[2]['id']]:
            bad.append('アドレス #%s で開いても、そのモードになりません: %s' % (tabs[2]['id'], direct))
        pg.goto('file://' + page_path); pg.reload()
        pg.wait_for_function('window.SHELL && document.querySelector("#modehead h2")', timeout=15000); pg.wait_for_timeout(500)

        # ---- 7. 画面の幅と向き × 全モード
        layout = {}
        for (w, h, label) in SIZES:
            pg.set_viewport_size({'width': w, 'height': h}); pg.wait_for_timeout(260)
            key = '%dx%d' % (w, h); layout[key] = {}
            for t in tabs:
                pg.evaluate("id => window.SHELL.goMode(id, false)", t['id']); pg.wait_for_timeout(160)
                pg.evaluate('() => window.scrollTo(0, 0)')
                m = pg.evaluate("""() => {
                    const de = document.documentElement, row = document.querySelector('#tabs .tabs-in');
                    const tb = [...document.querySelectorAll('#tabs .tab')].map(b => { const r = b.getBoundingClientRect();
                        return {id: b.id, l: Math.round(r.left), r: Math.round(r.right), sel: b.getAttribute('aria-selected') === 'true',
                                clip: b.scrollWidth > b.clientWidth + 1}; });
                    const cv = document.querySelector('canvas#view'), box = cv && cv.closest('.canvas-box'), fb = document.querySelector('.figfull-btn');
                    const over = [...document.querySelectorAll('#hero *, #modehead *, #seclinks *, .blockhead *, footer.pagefoot *')]
                        .filter(e => { const r = e.getBoundingClientRect(); return r.width > 0 && (r.right > innerWidth + 1 || r.left < -1); }).length;
                    return {sw: de.scrollWidth, cw: de.clientWidth, tabsH: Math.round(document.getElementById('tabs').getBoundingClientRect().height),
                            sticky: getComputedStyle(document.getElementById('tabs')).position, rowScroll: row.scrollWidth > row.clientWidth + 1,
                            tabs: tb, over: over, cvW: cv ? Math.round(cv.getBoundingClientRect().width) : 0,
                            boxW: box ? Math.round(box.getBoundingClientRect().width) : 0,
                            figBtn: !!fb && getComputedStyle(fb).display !== 'none', heroH: Math.round(document.getElementById('hero').getBoundingClientRect().height)};
                }""")
                layout[key][t['id']] = {k: m[k] for k in ('sw', 'cw', 'tabsH', 'sticky', 'rowScroll', 'over', 'cvW', 'boxW', 'figBtn', 'heroH')}
                where = '%s %d×%d・%s' % (label, w, h, t['id'])
                if m['sw'] > m['cw']:
                    bad.append('%s：横スクロールが出ます（%d > %d）' % (where, m['sw'], m['cw']))
                if m['over']:
                    bad.append('%s：見出しの帯・章の扉・フッターで、画面からはみ出す要素が %d 個' % (where, m['over']))
                if any(x['clip'] for x in m['tabs']):
                    bad.append('%s：タブの文字が切れています' % where)
                if m['rowScroll']:
                    if w > 640:
                        bad.append('%s：タブ列に、かくれたタブがあります（この幅では折り返すはず）' % where)
                    s = [x for x in m['tabs'] if x['sel']][0]
                    if s['l'] < 0 or s['r'] > w:
                        bad.append('%s：選んだタブが画面の外にあります（%d〜%d）' % (where, s['l'], s['r']))
                else:
                    out = [x['id'] for x in m['tabs'] if x['l'] < 0 or x['r'] > w]
                    if out:
                        bad.append('%s：画面の外にタブがあります: %s' % (where, out))
                if m['tabsH'] > 100:
                    bad.append('%s：タブ列が 3 段以上になっています（高さ %d px）' % (where, m['tabsH']))
                if m['sticky'] == 'sticky' and m['tabsH'] > h * 0.2:
                    bad.append('%s：固定したタブ列が高すぎます（%d px / 画面の高さ %d px）' % (where, m['tabsH'], h))
                if m['cvW'] > m['boxW'] + 1 and not m['figBtn']:
                    bad.append('%s：図が枠より広い（%d > %d）のに「図だけを大きく表示」が出ていません' % (where, m['cvW'], m['boxW']))
            pg.evaluate("id => window.SHELL.goMode(id, false)", tabs[0]['id'])
        facts['layout'] = layout
        if errors:
            bad.append('ページのエラー %d 件: %s' % (len(errors), errors[:3]))
        if cerr:
            bad.append('コンソールのエラー %d 件: %s' % (len(cerr), cerr[:3]))
        if ext:
            bad.append('外部への通信 %d 件（file:// では 0 のはず）: %s' % (len(ext), ext[:3]))
        facts['counts'] = {'errors': len(errors), 'console': len(cerr), 'external': len(ext), 'sizes': len(SIZES)}
        br.close()
    print(json.dumps({'bad': bad, 'facts': facts}, ensure_ascii=False, sort_keys=True))


if __name__ == '__main__':
    main()
