#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""図のスクリーンショットを撮る（自分で見て確かめるため）。
  python3 test/shots.py
"""
import os
import sys
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PAGE = os.path.join(ROOT, 'diffraction_grating.html')
OUT = os.path.join(ROOT, 'shots')
os.makedirs(OUT, exist_ok=True)

SHOTS = [
    ('step1', {'lambda': 600, 'd': 2000, 'L': 1.0, 'm': 1, 'onlyBright': True}, 1),
    ('step2', {'lambda': 600, 'd': 2000, 'L': 1.0, 'm': 1, 'onlyBright': True}, 2),
    ('step3', {'lambda': 600, 'd': 2000, 'L': 1.0, 'm': 1, 'onlyBright': True}, 3),
    ('m0', {'lambda': 600, 'd': 2000, 'L': 1.0, 'm': 0, 'onlyBright': True}, 3),
    ('m2', {'lambda': 600, 'd': 2000, 'L': 1.0, 'm': 2, 'onlyBright': True}, 3),
    ('m3_offscreen', {'lambda': 600, 'd': 2000, 'L': 1.0, 'm': 3, 'onlyBright': True}, 3),
    ('L02', {'lambda': 600, 'd': 2000, 'L': 0.2, 'm': 1, 'onlyBright': True}, 3),
    ('L20', {'lambda': 600, 'd': 2000, 'L': 2.0, 'm': 1, 'onlyBright': True}, 3),
    ('coarse_d', {'lambda': 600, 'd': 3333.33, 'L': 1.0, 'm': 2, 'onlyBright': True}, 3),
    ('no_order', {'lambda': 600, 'd': 500, 'L': 1.0, 'm': 1, 'onlyBright': True}, 2),
    ('violet', {'lambda': 420, 'd': 2000, 'L': 1.0, 'm': 2, 'onlyBright': True}, 1),
    ('free_dir', {'lambda': 600, 'd': 2000, 'L': 1.0, 'sinT': 0.42, 'onlyBright': False}, 2),
]

WHITE_SHOTS = [
    ('white', {'lambda': 600, 'd': 2000, 'L': 1.0, 'm': 1, 'onlyBright': True}, 2),
    ('white_coarse', {'lambda': 600, 'd': 3333.33, 'L': 1.0, 'm': 1, 'onlyBright': True}, 2),
    ('white_L2', {'lambda': 600, 'd': 2000, 'L': 2.0, 'm': 1, 'onlyBright': True}, 2),
]


def main():
    with sync_playwright() as pw:
        b = pw.chromium.launch()
        pg = b.new_page(viewport={'width': 1440, 'height': 1100}, device_scale_factor=1)
        pg.goto('file://' + PAGE)
        pg.wait_for_function('window.DGTEST !== undefined')
        pg.wait_for_timeout(250)
        for name, patch, step in SHOTS:
            pg.evaluate('p => DGTEST.set(p)', patch)
            pg.evaluate('n => DGTEST.setStep(n)', step)
            pg.wait_for_timeout(90)
            pg.locator('#view').screenshot(path=os.path.join(OUT, name + '.png'))
        pg.evaluate("() => DGTEST.setLight('white')")
        for name, patch, step in WHITE_SHOTS:
            pg.evaluate('p => DGTEST.set(p)', patch)
            pg.evaluate('n => DGTEST.setStep(n)', step)
            pg.wait_for_timeout(90)
            pg.locator('#view').screenshot(path=os.path.join(OUT, name + '.png'))
        pg.evaluate("() => DGTEST.setLight('mono')")

        # ② 実際の波の動きを見る
        pg.evaluate("() => DGTEST.setMode('wave')")
        for name, patch in [
            ('wave_m1', {'lambda': 600, 'd': 2000, 'L': 1.0, 'm': 1, 'onlyBright': True, 't': 0.4}),
            ('wave_m0', {'lambda': 600, 'd': 2000, 'L': 1.0, 'm': 0, 'onlyBright': True, 't': 0.4}),
            ('wave_dark', {'lambda': 600, 'd': 2000, 'L': 1.0, 'sinT': 0.45, 'onlyBright': False, 't': 0.4}),
        ]:
            pg.evaluate('p => DGTEST.set(p)', patch)
            pg.wait_for_timeout(120)
            pg.locator('#view').screenshot(path=os.path.join(OUT, name + '.png'))
        pg.evaluate("() => DGTEST.setLight('white')")
        pg.evaluate('p => DGTEST.set(p)', {'lambda': 600, 'd': 2000, 'L': 1.0, 'm': 1, 'onlyBright': True})
        pg.wait_for_timeout(150)
        pg.locator('#view').screenshot(path=os.path.join(OUT, 'wave_white.png'))
        pg.evaluate("() => DGTEST.setLight('mono')")

        # ③ 各場所でどのように波が重なり合うか
        pg.evaluate("() => DGTEST.setMode('field')")
        for name, patch in [
            ('field_m1', {'lambda': 600, 'd': 2000, 'fy': None, 't': 0.3}),
            ('field_dark', {'lambda': 600, 'd': 2000, 't': 0.3}),
            ('field_coarse', {'lambda': 600, 'd': 3333.33, 'fy': None, 't': 0.3}),
            ('field_violet', {'lambda': 420, 'd': 2000, 'fy': None, 't': 0.3}),
        ]:
            pg.evaluate('p => DGTEST.set(p)', patch)
            if name == 'field_dark':
                pg.evaluate("() => { const F = DG.modeField, SP = F.FL.sp, st = DGTEST.state();"
                            "  const lamPx = st.lambda * SP / st.d, c = SP / 2, a = 0.5 * lamPx / 2;"
                            "  const b2 = c * c - a * a, X = F.FL.x1 - F.FL.gx;"
                            "  DGTEST.setPoint(F.FL.cy - a * Math.sqrt(1 + X * X / b2)); }")
            pg.wait_for_timeout(200)
            pg.locator('#view').screenshot(path=os.path.join(OUT, name + '.png'))
        pg.evaluate('p => DGTEST.set(p)', {'lambda': 600, 'd': 2000, 'fy': None})
        pg.evaluate("() => DGTEST.setMode('path')")

        # ページ全体
        pg.evaluate('p => DGTEST.set(p)', {'lambda': 600, 'd': 2000, 'L': 1.0, 'm': 1, 'onlyBright': True})
        pg.evaluate('() => DGTEST.setStep(1)')
        pg.wait_for_timeout(120)
        pg.screenshot(path=os.path.join(OUT, 'page_1440.png'), full_page=False)
        for w in (390, 768):
            pg.set_viewport_size({'width': w, 'height': 900})
            pg.wait_for_timeout(150)
            pg.screenshot(path=os.path.join(OUT, 'page_%d.png' % w), full_page=False)
        b.close()
    print('shots -> ' + OUT)


if __name__ == '__main__':
    main()
