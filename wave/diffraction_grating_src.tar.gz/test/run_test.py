#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""diffraction_grating.html の自動テスト。

  python3 test/run_test.py            … 1 回実行して JSON を吐く
  python3 test/run_test.py --twice    … 2 回実行して結果が完全一致するかを確かめる

確かめること
  1. 物理の数値（明線の角度・スクリーン上の位置・存在しない次数・強度）
  2. 図の描画が x = L tanθ と一致すること（scene の座標を検査）
  3. 展開バンドの波が、図の中の波と同じ関数から出ていること
  4. DOM の文言（読み出し・見る方向の説明）
  5. ページエラー 0・外部リクエスト 0
  6. 320 / 360 / 390 / 768 / 1024 / 1440 px で横スクロールが出ないこと
"""
import json
import os
import sys
import math

from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PAGE = os.path.join(ROOT, 'diffraction_grating.html')
WIDTHS = [320, 360, 390, 768, 1024, 1440]


def approx(v, nd=6):
    """浮動小数の丸め（2 回の実行で完全一致させるため）"""
    if isinstance(v, float):
        if v != v or v in (float('inf'), float('-inf')):
            return str(v)
        return round(v, nd)
    return v


def deep_round(o, nd=6):
    if isinstance(o, dict):
        return {k: deep_round(v, nd) for k, v in o.items()}
    if isinstance(o, list):
        return [deep_round(v, nd) for v in o]
    return approx(o, nd)


def run_once(pw):
    browser = pw.chromium.launch()
    page = browser.new_page(viewport={'width': 1440, 'height': 1000})

    errors = []
    external = []
    page.on('pageerror', lambda e: errors.append('pageerror: ' + str(e)))
    page.on('console', lambda m: errors.append('console.' + m.type + ': ' + m.text)
            if m.type in ('error',) else None)
    page.on('request', lambda r: external.append(r.url)
            if not r.url.startswith('file://') else None)

    page.goto('file://' + PAGE)
    page.wait_for_function('window.DGTEST !== undefined')
    page.wait_for_timeout(250)

    out = {}

    # ---- 1. 物理の数値 -------------------------------------------------
    out['physics'] = page.evaluate(r"""() => {
      const P = DG.phys;
      const r = {};

      // d = 1/500 mm = 2000 nm、λ = 600 nm
      const d = 2000, lam = 600, L = 1.0;
      r.sin1 = P.sinThetaOf(1, lam, d);
      r.theta1deg = P.thetaOf(1, lam, d) * 180 / Math.PI;
      r.x1 = P.xOnScreen(P.thetaOf(1, lam, d), L);
      r.x2 = P.xOnScreen(P.thetaOf(2, lam, d), L);
      r.mMax_2000 = P.maxOrder(lam, d);

      // d = 1/2000 mm = 500 nm → sinθ = 1.2 > 1 なので 1 次は存在しない
      r.sin1_500 = P.sinThetaOf(1, lam, 500);
      r.theta1_500 = P.thetaOf(1, lam, 500);
      r.mMax_500 = P.maxOrder(lam, 500);

      // d/λ がちょうど整数のとき（sinθ = 1 はスクリーンに届かない）
      r.mMax_exact = P.maxOrder(600, 1800);

      // 強度：明線ではちょうど 1、最初の暗点は 1/N ずれたところ
      const th1 = P.thetaOf(1, lam, d);
      r.I_bright = P.intensityN(th1, d, lam, 20);
      const thZero = Math.asin((1 + 1 / 20) * lam / d);
      r.I_firstZero = P.intensityN(thZero, d, lam, 20);
      // 2 スリットと 20 スリットの「半分の明るさになる幅」の比
      function halfWidth(N) {
        const lo = 1.0, hi = 1.0 + 1.0 / N;
        let a = lo, b = hi;
        for (let i = 0; i < 60; i++) {
          const mid = (a + b) / 2;
          const I = P.intensityN(Math.asin(mid * lam / d), d, lam, N);
          if (I > 0.5) a = mid; else b = mid;
        }
        return (a + b) / 2 - 1.0;
      }
      r.halfWidth2 = halfWidth(2);
      r.halfWidth20 = halfWidth(20);
      r.widthRatio = r.halfWidth2 / r.halfWidth20;

      // 経路差
      r.delta1 = P.pathDiff(d, th1);
      r.ratio1 = r.delta1 / lam;
      return r;
    }""")

    # ---- 2. 図の描画が x = L tanθ と一致するか --------------------------
    out['scene'] = page.evaluate(r"""() => {
      DGTEST.set({ lambda: 600, d: 2000, L: 1.0, m: 1, onlyBright: true });
      const sol = DGTEST.solve(), sc = DGTEST.scene();
      const P = DG.phys, Lc = DG.draw.L;
      // P1 の y は「CY − x·ppm」でなければならない
      const expect = Lc.CY - P.xOnScreen(sol.theta, sol.L) * sc.ppm;
      return {
        ppm: sc.ppm, distPx: sc.distPx, gx: sc.gx, halfM: sc.halfM,
        p1y: sc.P1.y, expectY: expect, diff: Math.abs(sc.P1.y - expect),
        // 横は「途中を省略して」一定に描く（＝全体図の見かけの角は θ ではない）
        drawnTanTheta: (Lc.CY - sc.P1.y) / (Lc.SX - sc.gx),
        trueTanTheta: Math.tan(sol.theta),
        // 左の拡大図では、経路差の線の長さが d sinθ に比例していること（角は正しい）
        segPix: sc.segPix, expectSeg: DG.draw.L.LD * Math.sin(sol.theta),
        // 目は図の上の光線の延長線上にあること（向きが線とずれないこと）
        dirDrawn: sc.dirDrawn,
        dirDrawnExpect: (function () {
          const dx = Lc.SX - sc.gx, dy = sc.P1.y - Lc.CY, r = Math.hypot(dx, dy);
          return { x: dx / r, y: dy / r };
        })()
      };
    }""")

    # ---- 3. 展開バンドの波と図の中の波が一致するか ----------------------
    out['band_wave'] = page.evaluate(r"""() => {
      DGTEST.set({ lambda: 600, d: 2000, L: 1.0, m: 1, onlyBright: true, t: 0.37 });
      const P = DG.phys;
      const st = DGTEST.state(), sol = DGTEST.solve();
      // 帯は「経路差 delta を 0〜delta まで刻んで waveAt(s,t,λ) で描く」ことになっている。
      // 同じ式から 32 点をつくり、位相の食いちがいがないことを確かめる。
      const out = [];
      for (let i = 0; i <= 31; i++) {
        const s = Math.abs(sol.delta) * i / 31;
        out.push(P.waveAt(s, st.t, st.lambda));
      }
      // 経路差ちょうどで 1 波長ぶんずれる ＝ 両端の位相差が 2π×ratio
      const ph0 = P.phaseAt(0, st.t, st.lambda);
      const ph1 = P.phaseAt(Math.abs(sol.delta), st.t, st.lambda);
      return {
        samples: out,
        phaseSpanOverTwoPi: (ph1 - ph0) / (2 * Math.PI),
        ratio: Math.abs(sol.ratio),
        endsMatch: Math.abs(out[0] - out[31]) < 1e-9
      };
    }""")

    # ---- 3b. 拡大図の 1 次元の波（sin カーブ）と経路差の強調 ---------------
    out['zoom_wave'] = page.evaluate(r"""() => {
      DGTEST.set({ lambda: 600, d: 2000, L: 1.0, m: 1, onlyBright: true, t: 0.21 });
      const P = DG.phys, Lc = DG.draw.L;
      const st = DGTEST.state(), sol = DGTEST.solve(), sc = DGTEST.scene();
      const nmToPx = Lc.LD / st.d;               // 拡大図の「1 nm が何 px か」
      // 経路差の線 s2→F の長さ [px] を nm になおすと d sinθ になるはず
      const segNm = Math.hypot(sc.F.x - sc.s2.x, sc.F.y - sc.s2.y) / nmToPx;
      // 波面 s1F の上で、光線 1（s1 で s = 0）と 光線 2（F で s = d sinθ）の変位
      const u1 = P.waveAt(0, st.t, st.lambda);
      const u2 = P.waveAt(segNm, st.t, st.lambda);
      // 経路差を半波長ずらした場合（打ち消しあう側）も見る
      const u3 = P.waveAt(segNm + st.lambda / 2, st.t, st.lambda);
      return {
        nmToPx: nmToPx, segNm: segNm, delta: Math.abs(sol.delta),
        u1: u1, u2: u2, u3: u3,
        sameAtWavefront: Math.abs(u1 - u2) < 1e-9,
        oppositeAtHalf: Math.abs(u1 + u3) < 1e-9,
        lambdaPx: st.lambda * nmToPx
      };
    }""")

    # 「⚡ 経路差を強調」ボタンが図の中にあり、押すと光ること
    out['pulse'] = page.evaluate(r"""() => {
      DGTEST.setStep(1);
      const st = DGTEST.state();
      const before = DG.modePath.pathGlow({ mode: 'path', step: 3, nowSec: 0, pulse: null });
      DGTEST.pulse('path');
      const after = DG.modePath.pathGlow({ mode: 'path', step: 3, nowSec: st.nowSec, pulse: st.pulse });
      return { before: before, after: after > 0.3, hasButton: DGTEST.hitButton(20, 60) };
    }""")

    # 図の中の「m = …」ラベルはクリックできる（＝マウスが指マークになる）
    out['chip_click'] = page.evaluate(r"""() => {
      DGTEST.set({ lambda: 600, d: 2000, L: 1.0, m: 0, onlyBright: true });
      const Lc = DG.draw.L, sc = DGTEST.scene();
      const th2 = DG.phys.thetaOf(2, 600, 2000);
      const y = Lc.CY - DG.phys.xOnScreen(th2, 1.0) * sc.ppm;
      const id = DGTEST.hitButton(Lc.SX + Lc.SCR_W + 46, y);
      const before = DGTEST.state().m;
      DGTEST.clickAt(Lc.SX + Lc.SCR_W + 46, y);
      const after = DGTEST.state().m;
      DGTEST.set({ m: 1 });
      return { id: id, before: before, after: after };
    }""")

    # ---- 3c. ② 実際の波の動きを見る -------------------------------------
    out['mode_wave'] = page.evaluate(r"""() => {
      DGTEST.setMode('wave');
      DGTEST.set({ lambda: 600, d: 2000, L: 1.0, m: 1, onlyBright: true, t: 0.11 });
      const P = DG.phys, W = DG.modeWave;
      const N = W.NSUM;
      const r = {};
      // 合成波の振幅：明線の方向なら N、半波長ずれたら 0
      r.ampBright = W.amplitudeOf(N, P.pathDiff(2000, P.thetaOf(1, 600, 2000)), 600);
      r.ampDark = W.amplitudeOf(N, 1.5 * 600, 600);
      // |sin(Nπδ/λ)/sin(πδ/λ)| と一致するか（δ = 0.37λ で確かめる）
      const d37 = 0.37 * 600;
      const b = Math.PI * d37 / 600;
      r.ampCheck = W.amplitudeOf(N, d37, 600);
      r.ampFormula = Math.abs(Math.sin(N * b) / Math.sin(b));
      // 白色光のパターン：1 次の内側は青紫、外側は赤
      const inner = P.spectrumColorAtX(P.xOnScreen(Math.asin(400 / 2000), 1.0), 2000, 1.0, 20, 1);
      const outer = P.spectrumColorAtX(P.xOnScreen(Math.asin(700 / 2000), 1.0), 2000, 1.0, 20, 1);
      r.innerBlue = inner.b > inner.r;
      r.outerRed = outer.r > outer.b;
      r.inner = inner; r.outer = outer;
      // 0 次はすべての波長が同じ方向なので白（3 色がほぼそろう）
      const zero = P.spectrumColorAtX(0, 2000, 1.0, 20, 1);
      r.zero = zero;
      r.zeroWhite = Math.max(zero.r, zero.g, zero.b) - Math.min(zero.r, zero.g, zero.b) < 30;
      // λ や m などの条件は、モードを変えてもそのまま引き継がれること
      DGTEST.set({ lambda: 500, m: 2 });
      DGTEST.setMode('path');
      r.lambdaInPath = DGTEST.state().lambda;
      r.mInPath = DGTEST.state().m;
      DGTEST.setMode('field');
      r.lambdaInField = DGTEST.state().lambda;
      DGTEST.setMode('wave');
      r.lambdaInWave = DGTEST.state().lambda;
      r.mInWave = DGTEST.state().m;
      // ②のスクリーンの上も、クリックして次数を選べる（＝指マークになる）
      DGTEST.setMode('wave');
      const Lw = DG.draw.L;
      r.waveScreenPickable = DGTEST.inScreenZone({ x: Lw.SX + 10, y: Lw.CY - 40 });
      DGTEST.setMode('path');
      DGTEST.set({ lambda: 600, d: 2000, L: 1.0, m: 1, onlyBright: true, t: 0 });
      return r;
    }""")

    # ---- 3d. ③ スクリーン・強弱の線・N 本の合成 -------------------------
    out['field'] = page.evaluate(r"""() => {
      DGTEST.setMode('field');
      DGTEST.set({ lambda: 600, d: 2000, L: 1.0, m: 1, onlyBright: true, fy: null, N: 20 });
      const F = DG.modeField, FL = F.FL, SCR = F.SCR;
      const st = DGTEST.state();
      const r = {
        nMax: FL.nMax, nShow: F.NSHOW, scrX: F.screenX(st), fieldRight: FL.x1,
        nmPerPx: F.nmPerPx(st), lamPx: st.lambda / F.nmPerPx(st),
        lamPxExpect: st.lambda * FL.sp / st.d
      };
      // 強めあいの線の上では、隣りあう波のずれがちょうど mλ
      r.d1 = F.deltaAt(st, F.yOfRatio(st, 1)) / st.lambda;
      r.d2 = F.deltaAt(st, F.yOfRatio(st, 2)) / st.lambda;
      r.dHalf = F.deltaAt(st, F.yOfRatio(st, 0.5)) / st.lambda;
      // 合成振幅：明線なら 1、(m+1/2)λ なら 0
      r.ampMax = F.ampFrac(20, F.deltaAt(st, F.yOfRatio(st, 1)), st.lambda);
      r.ampHalf = F.ampFrac(20, F.deltaAt(st, F.yOfRatio(st, 0.5)), st.lambda);
      // N を増やすと、明線以外はどんどん 0 に近づく（＝先生のご指摘の確認）
      r.decay = [2, 4, 10, 20, 50, 100, 500, 1000].map(
        N => F.ampFrac(N, 0.97 * st.lambda, st.lambda));
      r.atMax = [2, 10, 1000].map(N => F.ampFrac(N, 1.0 * st.lambda, st.lambda));
      // P はスクリーンの上だけを動く
      r.pDefault = F.pointAt(st);
      DGTEST.set({ onlyBright: false });
      DGTEST.setPoint(FL.cy + 40);
      r.pAfterDrag = F.pointAt(DGTEST.state());
      // 「明線の位置のみ選ぶ」を外しても、経路差は 0.05λ きざみで止まる
      r.qStep = [];
      for (var yy = FL.cy + 20; yy < FL.cy + 60; yy += 3) {
        DGTEST.setPoint(yy);
        var q = F.deltaAt(DGTEST.state(), F.pointAt(DGTEST.state()).y) / st.lambda;
        r.qStep.push(Math.abs(q * 20 - Math.round(q * 20)));   // 0.05 の倍数か
      }
      // 「明線の位置のみ選ぶ」なら、経路差はぴったり整数倍
      DGTEST.set({ onlyBright: true });
      r.qSnap = [];
      for (yy = FL.cy - 200; yy < FL.cy - 40; yy += 11) {
        DGTEST.setPoint(yy);
        r.qSnap.push(F.deltaAt(DGTEST.state(), F.pointAt(DGTEST.state()).y) / st.lambda);
      }
      // スクリーンを左右に動かせる（格子に近づきすぎない）
      DGTEST.moveScreen(FL.gx + 40);
      r.scrNear = F.screenX(DGTEST.state()) - FL.gx;
      DGTEST.moveScreen(FL.gx + 9999);
      r.scrFar = F.screenX(DGTEST.state()) - FL.gx;
      DGTEST.moveScreen(FL.gx + 320);
      r.scrMid = F.screenX(DGTEST.state()) - FL.gx;
      // 動かしたあとも、明線の向きは d sinθ = mλ のまま
      DGTEST.set({ onlyBright: true });
      DGTEST.setPoint(F.yOfRatio(DGTEST.state(), 1));
      r.qAfterMove = F.deltaAt(DGTEST.state(), F.pointAt(DGTEST.state()).y) / st.lambda;
      DGTEST.set({ scrX: null });
      r.grabOnScreen = F.inField(st, F.screenX(st) + 4, FL.cy);
      r.grabInside = F.inField(st, FL.gx + 100, FL.cy);
      // 図に描くスリットの本数が N′ に合わせて変わるか（10 本まで）
      r.drawn = [2, 10, 100, 1000].map(function (n) {
        DGTEST.set({ N: n });
        return DGTEST.buttons() && DG.modeField.drawnCount(DGTEST.state());
      });
      // N のスライダーが効くか
      DGTEST.set({ N: 1000 });
      r.nAfter = DGTEST.state().N;
      r.ampMidBigN = F.ampFrac(DGTEST.state().N, 0.97 * st.lambda, st.lambda);
      DGTEST.set({ N: 20, fy: null });
      DGTEST.setMode('path');
      return r;
    }""")

    # ---- 3e. 補足：単スリットの問題 ------------------------------------
    out['slit'] = page.evaluate(r"""() => {
      const before = { N: DGTEST.state().N, d: DGTEST.state().d };
      DGTEST.setMode('slit');
      DGTEST.set({ lambda: 600, slitA: 2000, K: 2, fyS: null, scrXS: null });
      const S = DG.modeSlit, FL = S.FL;
      const st = DGTEST.state();
      const r = {};
      const lam = 600, a = 2000;
      // ほかのモードの設定（N′ や d）に影響しないこと
      r.isoN = DGTEST.state().N === before.N;
      r.isoD = DGTEST.state().d === before.d;
      // K = 2（教科書の「半分ずつ」）：a sinθ = λ で打ち消しあう
      r.amp2dark1 = S.ampK(2, a, lam / a, lam);
      // 偽物の明線：点が 2 個だけだと a sinθ = 2λ でそろってしまう
      r.amp2fake = S.ampK(2, a, 2 * lam / a, lam);
      // K を増やしても、暗線 a sinθ = mλ は暗線のまま
      r.darkAllK = [2, 3, 4, 6, 10, 30, 100].map(K => S.ampK(K, a, lam / a, lam));
      r.dark2 = [4, 10, 100].map(K => S.ampK(K, a, 2 * lam / a, lam));
      // 中央は K によらず 1
      r.center = [2, 10, 100].map(K => S.ampK(K, a, 0, lam));
      // K を増やすと本当の分布（|sinα/α|）に近づく
      const sTest = 0.7 * lam / a;
      const env = S.envAt({ slitA: a, lambda: lam }, sTest);
      r.envTest = env;
      r.envErr = [2, 4, 10, 100].map(K => Math.abs(S.ampK(K, a, sTest, lam) - env));
      // 1 番めの副極大（a sinθ ≒ 1.5λ）は約 21 %（振幅）
      r.sideLobe = S.ampK(100, a, 1.5 * lam / a, lam);
      // 画面：暗線の y は中央について対称
      const y1 = S.yOfSin(st, lam / a), y1m = S.yOfSin(st, -lam / a);
      r.darkSym = (y1 !== null && y1m !== null) ? (y1 + y1m - 2 * FL.cy) : 'null';
      // P のドラッグは a sinθ = 0.05λ きざみ（暗線にぴったり止められる）
      r.qStep = [];
      for (let yy = FL.cy + 20; yy < FL.cy + 60; yy += 3) {
        DGTEST.setPoint(yy);
        const q = S.deltaFullAt(DGTEST.state(), S.pointAt(DGTEST.state()).y) / lam;
        r.qStep.push(Math.abs(q * 20 - Math.round(q * 20)));
      }
      // スクリーンを左右に動かせる（近づきすぎない）
      DGTEST.moveScreen(FL.gx + 40);
      r.scrNear = S.screenX(DGTEST.state()) - FL.gx;
      DGTEST.moveScreen(FL.gx + 9999);
      r.scrFar = S.screenX(DGTEST.state()) - FL.gx;
      DGTEST.set({ scrXS: null, fyS: null });
      // 1 px の縮尺：a を 150 px で描く
      r.nmPerPx = S.nmPerPx(DGTEST.state());
      // UI：問題・解答のボタンとモード専用の操作が出ているか
      r.probShown = !document.getElementById('slitprob').hidden;
      r.KrowShown = !document.getElementById('sl-Krow').hidden;
      r.drowHidden = document.getElementById('sl-drow').hidden;
      // 問題の重ね窓が開閉できるか
      document.getElementById('btn-slit-prob').click();
      r.ovOpen = !document.getElementById('probov-slit').hidden;
      document.querySelector('#probov-slit .probov-x').click();
      r.ovClosed = document.getElementById('probov-slit').hidden;
      DGTEST.setMode('path');
      r.probHidden = document.getElementById('slitprob').hidden;
      r.isoNAfter = DGTEST.state().N === before.N;
      return r;
    }""")

    # ---- 3.5 「実験の概要（実寸）」タブ --------------------------------
    out['scale_out'] = page.evaluate(r"""() => {
      DGTEST.setMode('path');
      DGTEST.set({ lambda: 600, d: 2000, L: 1.0, m: 1, onlyBright: true });
      const S = DG.scaleOut, r = {};
      r.scenes = S.SCENES.length;
      r.titles = S.TITLES.length;
      r.sceneOf = [0, 0.2, 0.3, 0.55, 0.8, 1].map(v => S.sceneOf(v));
      r.grpBefore = document.getElementById('grp-scale').hidden;
      DGTEST.setMode('scale');
      r.mode = DGTEST.state().mode;
      r.grpShown = !document.getElementById('grp-scale').hidden;
      r.sceneBtns = Array.from(document.querySelectorAll('#scale-scenes .ord'))
        .map(b => b.textContent);
      r.boxShown = !document.getElementById('scalebox').hidden;
      r.dirHidden = document.getElementById('dirbox').hidden;
      r.notesShown = !document.getElementById('scalenotes').hidden;
      // 実寸のあいだは、図の中のボタンは押せない
      r.noHit = (DGTEST.buttons().length === 0);
      // ③の場面：扇のひらき方が縮尺どおりか
      DGTEST.scaleTo(0.55);
      const P = DG.phys, st = DGTEST.state();
      const th = P.thetaOf(1, st.lambda, st.d);
      const gx = 220, sx = 1120;
      r.yFromAngle = Math.tan(th) * (sx - gx);
      r.yFromX = P.xOnScreen(th, 1.0) * (sx - gx);
      DGTEST.setMode('path');
      r.grpHidden = document.getElementById('grp-scale').hidden;
      r.scaleCleared = (DGTEST.state().scaleOut === null);
      return r;
    }""")

    # ---- 3.55 次数ラベルの総当たり検査 ------------------------------------
    # 「スクリーンの外の次数がスクリーン上に出てしまう」たぐいのバグを、
    # λ・d・L・見る方向・単色／白色の組みあわせを一通り試して調べる。
    out['chip_sweep'] = page.evaluate(r"""() => {
      const P = DG.phys, Lc = DG.draw.L;
      const LAMS = [380, 520, 600, 780];
      const DS   = [500, 900, 2000, 3340];
      const LS   = [0.20, 1.00, 2.00];
      const MS   = [0, 1, 2, 3, 4];
      const bad = [], seen = {};
      let cases = 0, chipsTotal = 0;

      function chipsOf(mode) {
        DGTEST.setMode(mode);
        return DGTEST.buttons()
          .filter(b => typeof b.id === 'string' && b.id.indexOf('ord:') === 0)
          .map(b => ({ m: parseInt(b.id.slice(4), 10), y: b.y + b.h / 2 }))
          .sort((a, b) => a.m - b.m || a.y - b.y);
      }

      for (const light of ['mono', 'white']) {
        DGTEST.setLight(light);
        for (const lam of LAMS) for (const d of DS) for (const Lm of LS) for (const m of MS) {
          cases++;
          DGTEST.setMode('path');
          DGTEST.set({ lambda: lam, d: d, L: Lm, m: m, onlyBright: true });
          const sc = DGTEST.scene();
          const a = chipsOf('path'), b = chipsOf('wave');
          chipsTotal += a.length;
          const key = light + '|' + lam + '|' + d + '|' + Lm + '|' + m;

          // (1) ①と②でラベルの位置が同じであること
          if (a.length !== b.length ||
              a.some((c, i) => c.m !== b[i].m || Math.abs(c.y - b[i].y) > 0.51)) {
            if (bad.length < 12) bad.push(['mode差', key, JSON.stringify(a), JSON.stringify(b)]);
          }

          // (2) どのラベルもスクリーンの中にあること
          for (const c of a) {
            if (Math.abs(c.y - Lc.CY) > Lc.SH + 0.6) {
              if (bad.length < 12) bad.push(['枠外', key, JSON.stringify(c)]);
            }
          }

          // (3) ラベルの位置が「その次数の明線の位置」と合っていること
          //     単色光 … λ そのもの／白色光 … 帯の内がわのはし（380 nm）
          const lamUse = (light === 'white') ? 380 : lam;
          for (const c of a) {
            const sT = Math.abs(c.m) * lamUse / d;
            if (!(sT < 1)) { if (bad.length < 12) bad.push(['sin>1', key, JSON.stringify(c)]); continue; }
            const th = (c.m < 0 ? -1 : 1) * Math.asin(sT);
            const want = Lc.CY - P.xOnScreen(th, Lm) * sc.ppm;
            if (Math.abs(want - c.y) > 0.6) {
              if (bad.length < 12) bad.push(['位置ちがい', key, JSON.stringify(c), want]);
            }
          }

          // (4) 同じ次数のラベルが 2 つ出ていないこと（上下でわけているので ±で 2 つまで）
          const cnt = {};
          for (const c of a) { cnt[c.m] = (cnt[c.m] || 0) + 1; }
          for (const k in cnt) if (cnt[k] > 1) {
            if (bad.length < 12) bad.push(['重複', key, k, cnt[k]]);
          }

          // (5) ラベルどうしが重なっていないこと
          const ys = a.map(c => c.y).sort((x, y) => x - y);
          for (let i = 1; i < ys.length; i++) if (ys[i] - ys[i - 1] < 18.9) {
            if (bad.length < 12) bad.push(['近すぎ', key, ys[i - 1], ys[i]]);
          }
          seen[light] = (seen[light] || 0) + a.length;
        }
      }
      DGTEST.setLight('mono');
      DGTEST.setMode('path');
      DGTEST.set({ lambda: 600, d: 2000, L: 1.0, m: 1, onlyBright: true });
      return { cases: cases, chips: chipsTotal, byLight: seen, bad: bad };
    }""")

    # ---- 3.6 ＋ − ボタンとラベル ----------------------------------------
    page.evaluate("() => DGTEST.set({ lambda: 600, d: 2000, L: 1.0, m: 1, onlyBright: true })")
    ctl = {}
    ctl['Llabel'] = page.eval_on_selector("label[for='sl-L']", 'e => e.textContent')
    ctl['dLabel'] = page.eval_on_selector("label[for='sl-d']", 'e => e.textContent')
    ctl['d0'] = page.evaluate('() => DGTEST.state().d')
    page.click('#d-up')
    ctl['dUp'] = page.evaluate('() => DGTEST.state().d')
    page.click('#d-dn')
    page.click('#d-dn')
    ctl['dDn'] = page.evaluate('() => DGTEST.state().d')
    page.click('#d-up')
    ctl['lam0'] = page.evaluate('() => DGTEST.state().lambda')
    page.click('#lam-up')
    ctl['lamUp'] = page.evaluate('() => DGTEST.state().lambda')
    page.click('#lam-dn')
    ctl['L0'] = page.evaluate('() => DGTEST.state().L')
    page.click('#L-up')
    ctl['LUp'] = page.evaluate('() => DGTEST.state().L')
    page.click('#L-dn')
    ctl['tabs'] = page.eval_on_selector_all('.tabs .tab', 'es => es.map(e => e.textContent)')
    ctl['steps'] = page.eval_on_selector_all('#steps .stepbox > b', 'es => es.map(e => e.textContent)')
    out['controls'] = ctl

    # ---- 3.7 練習問題 ----------------------------------------------------
    out['quiz'] = page.evaluate(r"""() => {
      const P = DG.phys;
      const qs = DG.quiz.build();
      const r = {
        n: qs.length,
        nOpts: qs.map(q => q.opts.length),
        nCorrect: qs.map(q => q.opts.filter(o => o.ok).length),
        boxes: document.querySelectorAll('.quiz .q').length,
        opts: document.querySelectorAll('.quiz .opt').length
      };
      // 問 1 の解説に出る数値が、物理の関数と合っているか
      const x1 = P.xOnScreen(P.thetaOf(1, 600, 2000), 1.0) * 100;
      const x2 = P.xOnScreen(P.thetaOf(1, 600, 1000), 1.0) * 100;
      r.hasX1 = qs[0].opts[0].fb.indexOf(x1.toFixed(1)) >= 0;
      r.hasX2 = qs[0].opts[0].fb.indexOf(x2.toFixed(1)) >= 0;
      r.wider = (x2 > x1);                       // d を半分 → 外へ広がる
      // まちがえを押すと ✕、正解を押すと ◯ が出るか
      const q1 = document.querySelector('.quiz .q');
      q1.querySelectorAll('.opt')[1].click();
      r.afterWrong = q1.getAttribute('data-answered');
      r.fbWrong = q1.querySelector('.fb').hidden === false;
      r.markedCorrect = q1.querySelectorAll('.opt.correct').length;
      DG.quiz.init();
      const q1b = document.querySelector('.quiz .q');
      r.afterReset = q1b.getAttribute('data-answered');
      q1b.querySelectorAll('.opt')[0].click();
      r.afterRight = q1b.getAttribute('data-answered');
      DG.quiz.init();
      return r;
    }""")

    # ---- 4. DOM の文言 --------------------------------------------------
    out['dom'] = page.evaluate(r"""() => {
      DGTEST.set({ lambda: 600, d: 2000, L: 1.0, m: 1, onlyBright: true, t: 0 });
      const g = id => (document.getElementById(id) || {}).textContent || '';
      const r = {
        sin: g('o-sin'), th: g('o-th'), delta: g('o-delta'), ratio: g('o-ratio'),
        x: g('o-x'), I: g('o-int'), mmax: g('o-mmax'), range: g('o-range'),
        dirNote: (document.getElementById('dir-note') || {}).innerText || '',
        step: g('step-label'),
        orderBtns: Array.from(document.querySelectorAll('#order-btns .ord')).map(b => b.textContent)
      };
      return r;
    }""")

    # d を 1/2000 mm にしたときの表示
    out['dom_no_order'] = page.evaluate(r"""() => {
      DGTEST.set({ lambda: 600, d: 500, L: 1.0, m: 1, onlyBright: true });
      const r = {
        mmax: document.getElementById('o-mmax').textContent,
        dirNote: document.getElementById('dir-note').innerText,
        orderBtns: Array.from(document.querySelectorAll('#order-btns .ord')).map(b => b.textContent)
      };
      DGTEST.set({ lambda: 600, d: 2000, L: 1.0, m: 1 });
      return r;
    }""")

    # L を変えたとき、明線の間隔（px）が広がるか
    out['L_effect'] = page.evaluate(r"""() => {
      const res = {};
      for (const L of [0.2, 0.6, 1.0, 2.0]) {
        DGTEST.set({ lambda: 600, d: 2000, L: L, m: 1, onlyBright: true });
        const sol = DGTEST.solve(), sc = DGTEST.scene();
        res['L' + L.toFixed(1)] = { xPx: sol.x * sc.ppm, xM: sol.x, halfM: sc.halfM, ppm: sc.ppm };
      }
      DGTEST.set({ L: 1.0 });
      return res;
    }""")

    # ---- 5. スクリーンをクリックして見る方向を選ぶ ----------------------
    out['pick'] = page.evaluate(r"""() => {
      DGTEST.set({ lambda: 600, d: 2000, L: 1.0, m: 0, onlyBright: true });
      const Lc = DG.draw.L;
      const sc0 = DGTEST.scene();
      // 1 次の明線の y をクリックしたら m = 1 が選ばれること
      const th1 = DG.phys.thetaOf(1, 600, 2000);
      const y = Lc.CY - DG.phys.xOnScreen(th1, 1.0) * sc0.ppm;
      DGTEST.setDirFromY(y + 3);
      const a = DGTEST.state().m;
      // 「明線の位置のみ」を外すと、中途半端な方向も選べること
      DGTEST.set({ onlyBright: false });
      DGTEST.setDirFromY(y + 22);
      const sol = DGTEST.solve();
      const b = { m: DGTEST.state().m, ratio: sol.ratio, kind: sol.kind };
      DGTEST.set({ onlyBright: true, m: 1 });
      return { snapped: a, free: b };
    }""")

    # ---- 6. 横スクロールが出ないか --------------------------------------
    scroll = {}
    for w in WIDTHS:
        page.set_viewport_size({'width': w, 'height': 900})
        page.wait_for_timeout(120)
        scroll[str(w)] = page.evaluate(
            '() => ({ doc: document.documentElement.scrollWidth, win: window.innerWidth,'
            '  over: document.documentElement.scrollWidth > window.innerWidth + 1 })')
    out['scroll'] = scroll
    page.set_viewport_size({'width': 1440, 'height': 1000})

    out['errors'] = errors
    out['external'] = external

    browser.close()
    return deep_round(out)


def check(out):
    """数値の検算。ずれていたら理由を返す。"""
    bad = []
    p = out['physics']

    def near(name, got, want, tol):
        if abs(got - want) > tol:
            bad.append('%s: %r != %r (tol %r)' % (name, got, want, tol))

    near('sinθ₁', p['sin1'], 0.30, 1e-9)
    near('θ₁[deg]', p['theta1deg'], 17.457603, 1e-4)
    near('x₁[m] (L=1)', p['x1'], 0.3144855, 1e-6)
    near('x₂[m] (L=1)', p['x2'], 0.75, 1e-9)
    near('経路差/λ', p['ratio1'], 1.0, 1e-9)
    if p['mMax_2000'] != 3:
        bad.append('m_max(λ=600,d=2000) = %r != 3' % p['mMax_2000'])
    near('sinθ₁ (d=500)', p['sin1_500'], 1.2, 1e-9)
    if p['theta1_500'] is not None:
        bad.append('d=500 nm では 1 次は存在しないはずが %r' % p['theta1_500'])
    if p['mMax_500'] != 0:
        bad.append('m_max(λ=600,d=500) = %r != 0' % p['mMax_500'])
    if p['mMax_exact'] != 2:
        bad.append('d/λ = 3 ちょうどのとき m_max = %r != 2' % p['mMax_exact'])
    near('明線での I', p['I_bright'], 1.0, 1e-9)
    near('最初の暗点での I', p['I_firstZero'], 0.0, 1e-9)
    if not (8.0 < p['widthRatio'] < 12.0):
        bad.append('2 スリットと 20 スリットの明線の幅の比 %r が 10 前後でない' % p['widthRatio'])

    s = out['scene']
    if s['diff'] > 1e-6:
        bad.append('図の P の位置が x = L tanθ と合わない: 差 %r px' % s['diff'])
    # 全体図は横の途中を省略して描くので、見かけの角は θ より小さくなるのが正しい
    if not (0 < s['drawnTanTheta'] < s['trueTanTheta']):
        bad.append('全体図の見かけの角が想定どおりでない: %r vs %r'
                   % (s['drawnTanTheta'], s['trueTanTheta']))
    if abs(s['distPx'] - 530) > 1e-9:
        bad.append('格子〜スクリーンの描画距離が一定でない: %r' % s['distPx'])
    if abs(s['segPix'] - s['expectSeg']) > 1e-6:
        bad.append('拡大図の経路差の長さが d sinθ に比例していない')
    if (abs(s['dirDrawn']['x'] - s['dirDrawnExpect']['x']) > 1e-9
            or abs(s['dirDrawn']['y'] - s['dirDrawnExpect']['y']) > 1e-9):
        bad.append('目を置く向きが、図の上の光線の向きと一致しない')

    z = out['zoom_wave']
    if abs(z['segNm'] - z['delta']) > 1e-6:
        bad.append('拡大図の経路差の線が d sinθ [nm] と一致しない: %r vs %r'
                   % (z['segNm'], z['delta']))
    if not z['sameAtWavefront']:
        bad.append('経路差が 1λ なのに、波面の上で 2 本の波の変位がそろわない')
    if not z['oppositeAtHalf']:
        bad.append('経路差を半波長ずらしたのに、波が逆向きにならない')
    if abs(z['lambdaPx'] - 600 * 104 / 2000) > 1e-6:
        bad.append('画面上の波長 [px] が縮尺と合わない: %r' % z['lambdaPx'])

    if out['pulse']['before'] != 0:
        bad.append('押していないのに「経路差を強調」が光っている')
    if not out['pulse']['after']:
        bad.append('「経路差を強調」を押しても光らない')
    mw = out['mode_wave']
    if abs(mw['ampBright'] - 6) > 1e-9:
        bad.append('明線の方向なのに合成波の振幅が N でない: %r' % mw['ampBright'])
    if abs(mw['ampDark']) > 1e-9:
        bad.append('半波長ずれているのに合成波が 0 にならない: %r' % mw['ampDark'])
    if abs(mw['ampCheck'] - mw['ampFormula']) > 1e-9:
        bad.append('合成波の振幅が |sin(Nπδ/λ)/sin(πδ/λ)| と一致しない')
    if not mw['innerBlue']:
        bad.append('白色光の 1 次で、内側が青紫になっていない: %r' % (mw['inner'],))
    if not mw['outerRed']:
        bad.append('白色光の 1 次で、外側が赤になっていない: %r' % (mw['outer'],))
    if not mw['zeroWhite']:
        bad.append('白色光の 0 次が白くない: %r' % (mw['zero'],))
    if not (mw['lambdaInPath'] == mw['lambdaInWave'] == mw['lambdaInField'] == 500):
        bad.append('モードを変えると λ が引き継がれない: %r / %r / %r'
                   % (mw['lambdaInPath'], mw['lambdaInField'], mw['lambdaInWave']))
    if not (mw['mInPath'] == mw['mInWave'] == 2):
        bad.append('モードを変えると m が引き継がれない: %r / %r' % (mw['mInPath'], mw['mInWave']))
    if not mw['waveScreenPickable']:
        bad.append('②でスクリーンの上をクリックして次数を選べない')

    fd = out['field']
    if abs(fd['lamPx'] - fd['lamPxExpect']) > 1e-6:
        bad.append('③の場の図で、画面上の波長が縮尺と合わない: %r vs %r'
                   % (fd['lamPx'], fd['lamPxExpect']))
    if fd['nMax'] != 10 or fd['nShow'] != 10:
        bad.append('③のスリット／波が 10 本までになっていない: %r / %r'
                   % (fd['nMax'], fd['nShow']))
    if fd['drawn'] != [2, 10, 10, 10]:
        bad.append('図に描くスリットの本数が N′ に合っていない: %r' % fd['drawn'])
    for key, want in (('d1', 1.0), ('d2', 2.0), ('dHalf', 0.5)):
        if abs(fd[key] - want) > 1e-9:
            bad.append('%s の線の上で、隣りあう波のずれが %s λ になっていない: %r'
                       % (key, want, fd[key]))
    if abs(fd['ampMax'] - 1.0) > 1e-9:
        bad.append('強めあいの線の上なのに合成振幅が 1 でない: %r' % fd['ampMax'])
    if fd['ampHalf'] > 1e-9:
        bad.append('弱めあいの線の上なのに合成振幅が 0 でない: %r' % fd['ampHalf'])
    dec = fd['decay']
    if not all(dec[i] >= dec[i + 1] - 1e-12 for i in range(len(dec) - 1)):
        bad.append('N を増やしても、明線以外の振幅が単調に小さくならない: %r' % dec)
    if dec[0] < 0.9 or dec[-1] > 1e-6:
        bad.append('N = 1000 でも明線以外がほぼ 0 になっていない: %r' % dec)
    if any(abs(v - 1.0) > 1e-9 for v in fd['atMax']):
        bad.append('明線の向きでは N によらず 1 のはず: %r' % fd['atMax'])
    if fd['nAfter'] != 1000 or fd['ampMidBigN'] > 1e-6:
        bad.append('N のスライダーが効いていない: %r / %r' % (fd['nAfter'], fd['ampMidBigN']))
    if fd['scrX'] != fd['fieldRight']:
        bad.append('スクリーンが場の右はしに置かれていない: %r vs %r'
                   % (fd['scrX'], fd['fieldRight']))
    if fd['pDefault']['x'] != fd['scrX'] or fd['pAfterDrag']['x'] != fd['scrX']:
        bad.append('点 P がスクリーンの上から外れている: %r / %r'
                   % (fd['pDefault'], fd['pAfterDrag']))
    if max(fd['qStep']) > 1e-6:
        bad.append('P が 0.05λ きざみになっていない: %r' % fd['qStep'])
    if any(abs(v - round(v)) > 1e-9 for v in fd['qSnap']):
        bad.append('「明線の位置のみ選ぶ」で経路差が整数倍になっていない: %r' % fd['qSnap'])
    # scrFar は SCR.max。強度分布グラフの余白のため 500 → 420 に変更した（Round M）
    if fd['scrNear'] != 200 or fd['scrFar'] != 420 or fd['scrMid'] != 320:
        bad.append('スクリーンの動かせる範囲がおかしい: %r / %r / %r'
                   % (fd['scrNear'], fd['scrFar'], fd['scrMid']))
    if abs(fd['qAfterMove'] - 1.0) > 1e-9:
        bad.append('スクリーンを動かすと明線の向きがずれる: %r' % fd['qAfterMove'])

    if not fd['grabOnScreen'] or fd['grabInside']:
        bad.append('P をつかめる範囲がスクリーンの上になっていない: %r / %r'
                   % (fd['grabOnScreen'], fd['grabInside']))

    # ---- 補足：単スリットの問題 ----------------------------------------
    sl = out['slit']
    if not (sl['isoN'] and sl['isoD'] and sl['isoNAfter']):
        bad.append('単スリットモードがほかのモードの設定を変えてしまう: %r / %r / %r'
                   % (sl['isoN'], sl['isoD'], sl['isoNAfter']))
    if sl['amp2dark1'] > 1e-9:
        bad.append('K = 2 で a sinθ = λ の合成振幅が 0 でない: %r' % sl['amp2dark1'])
    if abs(sl['amp2fake'] - 1.0) > 1e-9:
        bad.append('K = 2 の偽の明線（a sinθ = 2λ）が 1 になっていない: %r' % sl['amp2fake'])
    if any(v > 1e-9 for v in sl['darkAllK']):
        bad.append('暗線 a sinθ = λ が、K によっては暗線でなくなる: %r' % sl['darkAllK'])
    if any(v > 1e-9 for v in sl['dark2']):
        bad.append('暗線 a sinθ = 2λ が、K によっては暗線でなくなる: %r' % sl['dark2'])
    if any(abs(v - 1.0) > 1e-9 for v in sl['center']):
        bad.append('中央（θ = 0）の合成振幅が 1 でない: %r' % sl['center'])
    ee = sl['envErr']
    if not all(ee[i] >= ee[i + 1] - 1e-12 for i in range(len(ee) - 1)):
        bad.append('K を増やしても本当の分布に近づかない: %r' % ee)
    if ee[-1] > 1e-3:
        bad.append('K = 100 で本当の分布とまだ大きくずれている: %r' % ee[-1])
    # 1 番めの副極大は振幅で約 21 %（sinc の 2/3π）
    if abs(sl['sideLobe'] - 2 / (3 * 3.141592653589793)) > 0.01:
        bad.append('副極大（a sinθ = 1.5λ）が約 0.212 でない: %r' % sl['sideLobe'])
    if abs(sl['darkSym']) > 1e-6:
        bad.append('暗線の位置が中央について対称でない: %r' % sl['darkSym'])
    if max(sl['qStep']) > 1e-6:
        bad.append('単スリットの P が 0.05λ きざみになっていない: %r' % sl['qStep'])
    if sl['scrNear'] != 200 or sl['scrFar'] != 420:
        bad.append('単スリットのスクリーンの動かせる範囲がおかしい: %r / %r'
                   % (sl['scrNear'], sl['scrFar']))
    if abs(sl['nmPerPx'] - 2000.0 / 150) > 1e-5:   # 出力は 6 桁で丸められている
        bad.append('単スリットの縮尺（a = 150 px）が合わない: %r' % sl['nmPerPx'])
    if not (sl['probShown'] and sl['KrowShown'] and sl['drowHidden'] and sl['probHidden']):
        bad.append('単スリットモードの UI の出し入れがおかしい: %r' % sl)
    if not (sl['ovOpen'] and sl['ovClosed']):
        bad.append('問題の重ね窓が開閉できない: %r / %r' % (sl['ovOpen'], sl['ovClosed']))

    cc = out['chip_click']
    if cc['id'] != 'ord:2':
        bad.append('「m = 2」のラベルが押せる場所になっていない: %r' % cc['id'])
    if cc['after'] != 2:
        bad.append('「m = 2」を押しても次数が変わらない: %r → %r' % (cc['before'], cc['after']))

    if out['pulse']['hasButton'] != 'pulse-path':
        bad.append('図の中に「経路差を強調」ボタンが無い: %r' % out['pulse']['hasButton'])

    b = out['band_wave']
    if abs(b['phaseSpanOverTwoPi'] - b['ratio']) > 1e-9:
        bad.append('展開バンドの位相差が 経路差/λ と一致しない')
    if not b['endsMatch']:
        bad.append('経路差がちょうど 1λ なのに、帯の両端の変位が一致しない')

    le = out['L_effect']
    xs = [le['L0.2']['xPx'], le['L0.6']['xPx'], le['L1.0']['xPx'], le['L2.0']['xPx']]
    if not all(xs[i] < xs[i + 1] for i in range(len(xs) - 1)):
        bad.append('L を大きくしても 1 次の明線が外へ広がらない: %r' % xs)

    if out['pick']['snapped'] != 1:
        bad.append('1 次の明線をクリックしたのに m = %r が選ばれた' % out['pick']['snapped'])

    for w, v in out['scroll'].items():
        if v['over']:
            bad.append('幅 %s px で横スクロールが出ている (%r > %r)' % (w, v['doc'], v['win']))

    so = out['scale_out']
    if so['scenes'] != 4 or so['titles'] != 4:
        bad.append('実寸の場面が 4 つでない: %r / %r' % (so['scenes'], so['titles']))
    if so['sceneOf'] != [0, 0, 1, 2, 3, 3]:
        bad.append('実寸の場面わけがおかしい: %r' % so['sceneOf'])
    if so['mode'] != 'scale' or not so['grpShown'] or so['grpBefore'] is not True:
        bad.append('実寸タブへの切りかえができていない: %r' % so)
    if not so['grpHidden'] or not so['scaleCleared']:
        bad.append('実寸タブから出たときに後始末できていない: %r' % so)
    if len(so['sceneBtns']) != 4:
        bad.append('場面ジャンプのボタンが 4 つでない: %r' % so['sceneBtns'])
    if not so['boxShown'] or not so['dirHidden'] or not so['notesShown']:
        bad.append('実寸タブの説明カードの出し入れがおかしい: %r' % so)
    if not so['noHit']:
        bad.append('実寸中なのに図の中のボタンが押せる')
    if abs(so['yFromAngle'] - so['yFromX']) > 1e-6:
        bad.append('実寸③が縮尺どおりでない（角度からの y %r ≠ L tanθ からの y %r）'
                   % (so['yFromAngle'], so['yFromX']))

    cs = out['chip_sweep']
    if cs['bad']:
        for row in cs['bad']:
            bad.append('次数ラベルの総当たり検査: %r' % (row,))
    if cs['chips'] < 300:
        bad.append('総当たり検査でラベルがほとんど出ていない: %r' % cs['chips'])

    qz = out['quiz']
    if qz['n'] != 2 or qz['boxes'] != 2:
        bad.append('練習問題が 2 問でない: %r / %r' % (qz['n'], qz['boxes']))
    if any(v != 4 for v in qz['nOpts']) or qz['opts'] != 8:
        bad.append('選択肢が 4 つずつでない: %r / %r' % (qz['nOpts'], qz['opts']))
    if any(v != 1 for v in qz['nCorrect']):
        bad.append('正解がちょうど 1 つでない問題がある: %r' % qz['nCorrect'])
    if not (qz['hasX1'] and qz['hasX2'] and qz['wider']):
        bad.append('問 1 の解説の数値が物理の計算と合わない: %r' % qz)
    if qz['afterWrong'] != 'wrong' or qz['afterRight'] != 'correct':
        bad.append('正誤の判定がおかしい: %r / %r' % (qz['afterWrong'], qz['afterRight']))
    if not qz['fbWrong'] or qz['markedCorrect'] != 1:
        bad.append('解説の出しかたがおかしい: %r / %r' % (qz['fbWrong'], qz['markedCorrect']))
    if qz['afterReset'] is not None:
        bad.append('「もう一度」で答えがリセットされない: %r' % qz['afterReset'])

    ct = out['controls']
    if 'スクリーンまでの距離 L' not in ct['Llabel']:
        bad.append('L のラベルが「スクリーンまでの距離 L」でない: %r' % ct['Llabel'])
    if not (ct['dUp'] > ct['d0'] > ct['dDn']):
        bad.append('d の ＋− ボタンで d が増減しない: %r → %r / %r'
                   % (ct['d0'], ct['dUp'], ct['dDn']))
    if ct['lamUp'] != ct['lam0'] + 1:
        bad.append('λ の ＋ ボタンが効かない: %r → %r' % (ct['lam0'], ct['lamUp']))
    if not (ct['LUp'] > ct['L0']):
        bad.append('L の ＋ ボタンが効かない: %r → %r' % (ct['L0'], ct['LUp']))
    if len(ct['tabs']) != 6:
        bad.append('タブが 6 つでない: %r' % ct['tabs'])
    if '実験の概要' not in ct['tabs'][4]:
        bad.append('5 つめのタブが「実験の概要」でない: %r' % ct['tabs'][4])
    if '単スリット' not in ct['tabs'][5]:
        bad.append('6 つめのタブが「単スリット」でない: %r' % ct['tabs'][5])
    if len(ct['steps']) != 4:
        bad.append('ステップが 4 つでない: %r' % ct['steps'])
    if 'ステップ 1　経路差を求める' not in ct['steps'][0]:
        bad.append('ステップ 1 が「経路差を求める」でない: %r' % ct['steps'][0])
    if any('平行光線とみなせるわけ' in t for t in ct['steps']):
        bad.append('「平行光線とみなせるわけ」のステップが残っている: %r' % ct['steps'])

    if out['errors']:
        bad.append('ページエラー: %r' % out['errors'])
    if out['external']:
        bad.append('外部リクエスト: %r' % out['external'])
    return bad


def main():
    twice = '--twice' in sys.argv
    with sync_playwright() as pw:
        a = run_once(pw)
        b = run_once(pw) if twice else None

    bad = check(a)
    same = True
    if twice:
        same = (json.dumps(a, sort_keys=True, ensure_ascii=False)
                == json.dumps(b, sort_keys=True, ensure_ascii=False))
        if not same:
            bad.append('2 回の実行結果が一致しない')

    print(json.dumps({'result': a, 'identical': same, 'problems': bad},
                     ensure_ascii=False, indent=1))
    print('\n=== %s ===' % ('OK' if not bad else 'NG（%d 件）' % len(bad)))
    for x in bad:
        print(' - ' + x)
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(main())
