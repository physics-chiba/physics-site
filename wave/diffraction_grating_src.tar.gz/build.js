/* 分割ソースを 1 枚の HTML に連結する。
 * KaTeX（CSS / JS / フォント）は base64 で埋めこみずみのものを流しこむので、
 * できあがった HTML は外部リクエスト 0 で動く。
 *   node build.js
 */
'use strict';
var fs = require('fs');
var path = require('path');

var ROOT = __dirname;
function rd(p) { return fs.readFileSync(path.join(ROOT, p), 'utf8'); }

var JS_FILES = [
  'src/30_physics.js',
  'src/40_draw.js',
  'src/45_scale.js',
  'src/50_mode_path.js',
  'src/60_mode_wave.js',
  'src/62_mode_field.js',
  'src/63_mode_slit.js',
  'src/65_mode_deltax.js',
  'src/70_ui.js',
  'src/80_quiz.js',
  'src/90_boot.js'
];

var js = JS_FILES.map(function (f) {
  if (!fs.existsSync(path.join(ROOT, f))) return '';
  return rd(f);
}).join('\n');

var out = rd('src/00_head.html')
  .replace('<!--KATEX_CSS-->', function () { return rd('vendor/katex.css'); })
  .replace('<!--STYLE-->', function () { return rd('src/10_style.css'); })
  .replace('<!--BODY-->', function () { return rd('src/20_body.html'); })
  .replace('<!--KATEX_JS-->', function () { return rd('vendor/katex.js'); })
  .replace('<!--APP_JS-->', function () { return js; });

/* 公開ページ共通の後づけパーツ（アクセスカウンタ・スタートボタンの発光）。
 * 2026-09-02 に公開版へ手で足されたものを、ビルドに取りこんで消えないようにした。 */
if (fs.existsSync(path.join(ROOT, 'src/95_footer.html'))) {
  out = out.replace('</body>', rd('src/95_footer.html') + '</body>');
}

var target = path.join(ROOT, 'diffraction_grating.html');
fs.writeFileSync(target, out);
console.log('built ' + target + '  (' + out.length + ' bytes)');
