/* 分割ソースを 1 枚の HTML に連結する。
 * KaTeX（CSS / JS / フォント）は base64 で埋めこみずみのものを流しこむので、
 * できあがった HTML は外部リクエスト 0 で動く。
 *   node build.js
 */
'use strict';
var fs = require('fs');
var path = require('path');

var ROOT = __dirname;
function rd(p) { return fs.readFileSync(path.join(ROOT, p), 'utf8'); }

var JS_FILES = [
  'src/30_physics.js',
  'src/40_draw.js',
  'src/45_scale.js',
  'src/50_mode_path.js',
  'src/60_mode_wave.js',
  'src/62_mode_field.js',
  'src/63_mode_slit.js',
  'src/65_mode_deltax.js',
  'src/70_ui.js',
  'src/84_sitenav.js',     // ホームとページ一覧（meter-bridge.html と同じもの）
  'src/86_shellcfg.js',    // 見出しの帯・章の扉に出す文
  'src/87_shell.js',       // 見出しの帯・章の扉・コンテンツ一覧・フッターを組み立てる
  'src/90_boot.js'
];

var js = JS_FILES.map(function (f) {
  if (!fs.existsSync(path.join(ROOT, f))) return '';
  return rd(f);
}).join('\n');

var out = rd('src/00_head.html')
  .replace('<!--KATEX_CSS-->', function () { return rd('vendor/katex.css'); })
  /* 10_style.css ＝ もとの見た目、12_shell.css ＝ meter-bridge.html と同じ骨組みと見た目、13_shell_page.css ＝ このページだけの調整 */
  .replace('<!--STYLE-->', function () { return rd('src/10_style.css') + '\n' + rd('src/12_shell.css') + '\n' + rd('src/13_shell_page.css'); })
  .replace('<!--BODY-->', function () { return rd('src/20_body.html'); })
  .replace('<!--KATEX_JS-->', function () { return rd('vendor/katex.js'); })
  .replace('<!--APP_JS-->', function () { return js; });

/* 公開用の共通フッター（アクセス数のカウント＋▶スタートを光らせるしくみ）。
 * 全ページ同じ内容（meter-bridge.html の src/99_footer.html と一字も同じ）。ここでは書きかえない。
 * 2026-11-16：もとの src/95_footer.html（中身は同じ働きの古い書き方）から差しかえた。 */
var FOOTER = rd('src/99_footer.html');
out = out.replace('</body>', function () { return FOOTER + '\n</body>'; });
/* 骨組みと共通フッターが入っていなければ失敗にする（作り直したときに落とさないため） */
['physics-chiba.goatcounter.com', 'sg-glow', 'buildSiteDrawer', 'id="hero"', 'id="tabs"', 'window.SHELL_CFG', 'id="modehead"'].forEach(function (k) {
  if (out.indexOf(k) < 0) { throw new Error('完全性チェックで失敗：' + k + ' がありません'); }
});

var target = path.join(ROOT, 'diffraction_grating.html');
fs.writeFileSync(target, out);
console.log('built ' + target + '  (' + out.length + ' bytes)');
