/* ===== 60_mode_wave.js ===== */
/* ② 実際の波の動きを見る
 *   左           ：スリットから広がる素元波と、選んだ方向の共通の波面
 *   まん中（上）  ：選んだ方向へ進む光線に沿った 1 次元の波（sin カーブ）を並べる
 *   まん中（下）  ：それらの合成波（すべての波の和）
 *   右           ：スクリーンに写る干渉パターン（単色光／白色光）
 *
 * 波は必ず本当の幾何から出した光路長 s を使う： u = sin(2π(s − vt)/λ)
 * 画面の縮尺は「隣りあう光線の間隔 ＝ d」から決めるので、
 * 画面上の波長も経路差も同じものさしになる。
 */
window.DG = window.DG || {};
DG.modeWave = (function () {
  'use strict';
  var D = DG.draw, P = DG.phys;
  var L = D.L, COL = D.COL;

  /* ---------- レイアウト ---------- */
  var LP = { plateX: 112, cy: L.CY, nslit: 3, sp: 92, top: 104, bot: 424 };
  var WV = { x0: 316, y0: 56, x1: 1020, y1: 386, sx: 356, nray: 4, sp: 104 };
  var SM = { x0: 316, y0: 404, x1: 1020, y1: 524 };
  var SCR = { x: 1146, w: 54, cy: L.CY, sh: 200, gamma: 0.45, gammaWhite: 0.62 };

  /* ================= 左：素元波 ================= */
  function wavelets(ctx, st, sol) {
    var nmToPx = LP.sp / st.d;                 // 1 nm が何 px か
    var lamPx = st.lambda * nmToPx;            // 画面上の波長
    var vPx = P.V_NM_PER_S * nmToPx;           // 画面上の速さ [px/s]
    var t = st.t || 0;
    var ph = ((vPx * t) % lamPx + lamPx) % lamPx;   // 波面の進み [px]
    var slits = [];
    for (var i = 0; i < LP.nslit; i++) {
      slits.push(D.vec(LP.plateX, LP.cy + (i - (LP.nslit - 1) / 2) * LP.sp));
    }

    ctx.save();
    ctx.beginPath();
    ctx.rect(6, LP.top - 6, L.DIV - 14, LP.bot - LP.top + 12);
    ctx.clip();

    // 入射側：平面波（縦の波面が右へ進む）
    ctx.strokeStyle = COL.rayDim; ctx.lineWidth = 1.6;
    for (var k = 0; k < 14; k++) {
      var x = LP.plateX - 10 - (lamPx - ph) - k * lamPx;
      if (x < 10) break;
      ctx.beginPath(); ctx.moveTo(x, LP.top); ctx.lineTo(x, LP.bot); ctx.stroke();
    }

    // 各スリットから広がる素元波（半円）
    ctx.strokeStyle = COL.ray; ctx.lineWidth = 1.5;
    ctx.globalAlpha = 0.75;
    for (i = 0; i < slits.length; i++) {
      for (k = 0; k < 10; k++) {
        var r = ph + k * lamPx;
        if (r > 180) break;
        ctx.beginPath();
        ctx.arc(slits[i].x, slits[i].y, r, -Math.PI / 2, Math.PI / 2);
        ctx.stroke();
      }
    }
    ctx.globalAlpha = 1;

    // 選んだ方向の共通の波面（素元波に共通接する線）
    var dir = D.vec(Math.cos(sol.theta), -Math.sin(sol.theta));
    var n = D.nrmOf(dir);
    ctx.strokeStyle = '#6d4a92'; ctx.lineWidth = 1.8;
    ctx.setLineDash([7, 5]);
    for (k = 0; k < 7; k++) {
      var rr = ph + k * lamPx;
      if (rr > 175) break;
      var c = D.add(slits[0], D.mul(dir, rr));   // 上のスリットの素元波に接する点
      ctx.beginPath();
      ctx.moveTo(c.x - n.x * 200, c.y - n.y * 200);
      ctx.lineTo(c.x + n.x * 200, c.y + n.y * 200);
      ctx.stroke();
    }
    ctx.setLineDash([]);
    ctx.restore();

    // 板（筋とスリットが交互）
    ctx.save();
    ctx.fillStyle = COL.plate;
    ctx.fillRect(LP.plateX - 10, LP.top, 20, LP.bot - LP.top);
    ctx.fillStyle = 'rgba(255,255,255,0.92)';
    for (i = 0; i < slits.length; i++) ctx.fillRect(LP.plateX - 10, slits[i].y - 3, 20, 6);
    ctx.strokeStyle = COL.plateEdge; ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(LP.plateX - 10, LP.top); ctx.lineTo(LP.plateX + 10, LP.top);
    ctx.moveTo(LP.plateX - 10, LP.bot); ctx.lineTo(LP.plateX + 10, LP.bot);
    ctx.moveTo(LP.plateX - 10, LP.top); ctx.lineTo(LP.plateX - 10, LP.bot);
    ctx.stroke();
    ctx.strokeStyle = '#3f7ba1'; ctx.lineWidth = 1.2;
    D.gratingFace(ctx, LP.plateX + 10, LP.top, LP.bot, slits[0].y, LP.sp, 3, 6, 7);
    ctx.restore();

    // 見出しと説明
    ctx.save();
    ctx.font = D.font(11.5, true);
    ctx.fillStyle = '#2b5a78';
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText('スリットから広がる素元波', L.DIV / 2, 46);
    ctx.font = D.font(11);
    ctx.fillStyle = '#5b6672';
    ctx.fillText('紫の破線が、選んだ方向の共通の波面', L.DIV / 2, 64);
    ctx.fillText('（縮尺は正しく、画面上の波長も d に合わせています）', L.DIV / 2, 80);
    ctx.restore();
    D.dimLine(ctx, D.vec(LP.plateX - 26, slits[0].y), D.vec(LP.plateX - 26, slits[1].y),
      'd', '#3a4550', 12);
  }

  /* ================= まん中の上：光線に沿った波 ================= */
  function rayWaves(ctx, st, sol) {
    var nmToPx = WV.sp / st.d;
    var dir = D.vec(Math.cos(sol.theta), -Math.sin(sol.theta));
    var n = D.nrmOf(dir);
    var t = st.t || 0;
    var amp = 13;
    var cy = (WV.y0 + WV.y1) / 2;
    var starts = [];
    for (var j = 0; j < WV.nray; j++) {
      starts.push(D.vec(WV.sx, cy + (j - (WV.nray - 1) / 2) * WV.sp));
    }

    ctx.save();
    ctx.beginPath();
    ctx.rect(WV.x0, WV.y0, WV.x1 - WV.x0, WV.y1 - WV.y0);
    ctx.clip();

    var lenPx = 1400;   // クリップされるので十分長くとる
    for (j = 0; j < WV.nray; j++) {
      var from = starts[j];
      D.dashLine(ctx, from, D.add(from, D.mul(dir, lenPx)), 'rgba(120,130,140,0.45)', [4, 4], 1);
      ctx.strokeStyle = COL.ray; ctx.lineWidth = 1.9;
      ctx.lineJoin = 'round'; ctx.lineCap = 'round';
      ctx.beginPath();
      var steps = 700;
      for (var i = 0; i <= steps; i++) {
        var px = lenPx * i / steps;
        var u = P.waveAt(px / nmToPx, t, st.lambda) * amp;
        var x = from.x + dir.x * px + n.x * u;
        var y = from.y + dir.y * px + n.y * u;
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }

    // 共通の波面（光線に垂直な破線）。ここで波がそろえば強めあう
    var lamPx = st.lambda * nmToPx;
    var ph = ((P.V_NM_PER_S * nmToPx * t) % lamPx + lamPx) % lamPx;
    ctx.strokeStyle = 'rgba(109,74,146,0.55)'; ctx.lineWidth = 1.2;
    ctx.setLineDash([7, 5]);
    for (var k = 0; k < 40; k++) {
      var r = ph + k * 2 * lamPx;      // 2 波長ごと（毎波長だと線が多すぎる）
      if (r > 1300) break;
      var c = D.add(starts[0], D.mul(dir, r));
      ctx.beginPath();
      ctx.moveTo(c.x - n.x * 420, c.y - n.y * 420);
      ctx.lineTo(c.x + n.x * 420, c.y + n.y * 420);
      ctx.stroke();
    }
    ctx.setLineDash([]);
    ctx.restore();

    // 枠と見出し
    ctx.save();
    ctx.strokeStyle = '#dbe3ea'; ctx.lineWidth = 1;
    ctx.strokeRect(WV.x0 + 0.5, WV.y0 + 0.5, WV.x1 - WV.x0, WV.y1 - WV.y0);
    ctx.font = D.font(12, true);
    ctx.fillStyle = '#28405c';
    ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
    ctx.fillText('選んだ方向（θ ＝ ' + sol.thetaDeg.toFixed(2) + '°）へ進む波', WV.x0 + 4, WV.y0 - 6);
    ctx.font = D.font(11);
    ctx.fillStyle = '#5b6672';
    ctx.textAlign = 'right';
    ctx.fillText('隣りあう波は d sinθ ＝ ' + Math.round(Math.abs(sol.delta)) + ' nm ＝ '
      + D.about(Math.abs(sol.ratio)) + ' λ ずれています', WV.x1 - 4, WV.y0 - 6);
    ctx.restore();

    // d の寸法（いちばん左）
    D.dimLine(ctx, D.vec(WV.sx - 22, starts[0].y), D.vec(WV.sx - 22, starts[1].y),
      'd', '#3a4550', 12);
  }

  /* ================= まん中の下：合成波 ================= */
  function sumWave(ctx, st, sol) {
    var nmToPx = WV.sp / st.d;
    var t = st.t || 0;
    var N = WV.nray;
    var delta = P.pathDiff(st.d, sol.theta);      // 隣りあう波のずれ [nm]
    var x0 = SM.x0 + 44, x1 = SM.x1 - 210;
    var cy = (SM.y0 + SM.y1) / 2 + 6;
    var unit = 46 / N;                            // 振幅 1 ぶんの px（N 本で 46 px）

    ctx.save();
    D.roundRect(ctx, SM.x0, SM.y0, SM.x1 - SM.x0, SM.y1 - SM.y0, 9);
    ctx.fillStyle = '#faf7fd'; ctx.fill();
    ctx.strokeStyle = '#d6c8e6'; ctx.lineWidth = 1.2; ctx.stroke();

    // 目盛り（0 と ±N）
    ctx.strokeStyle = '#c9c0d6'; ctx.lineWidth = 1;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(x0, cy); ctx.lineTo(x1, cy);
    ctx.moveTo(x0, cy - N * unit); ctx.lineTo(x1, cy - N * unit);
    ctx.moveTo(x0, cy + N * unit); ctx.lineTo(x1, cy + N * unit);
    ctx.stroke();
    ctx.setLineDash([]);

    // もとの 4 つの波（うすく）と、その和（紫）
    var steps = 520;
    var j, i;
    ctx.lineWidth = 1.2; ctx.strokeStyle = 'rgba(232,134,42,0.45)';
    for (j = 0; j < N; j++) {
      ctx.beginPath();
      for (i = 0; i <= steps; i++) {
        var px = (x1 - x0) * i / steps;
        var s = px / nmToPx + j * delta;
        var y = cy - P.waveAt(s, t, st.lambda) * unit;
        if (i === 0) ctx.moveTo(x0 + px, y); else ctx.lineTo(x0 + px, y);
      }
      ctx.stroke();
    }
    if (st.showSum) {
      ctx.strokeStyle = COL.sum; ctx.lineWidth = 2.4;
      ctx.lineJoin = 'round';
      ctx.beginPath();
      for (i = 0; i <= steps; i++) {
        var px2 = (x1 - x0) * i / steps;
        var sum = 0;
        for (j = 0; j < N; j++) sum += P.waveAt(px2 / nmToPx + j * delta, t, st.lambda);
        var y2 = cy - sum * unit;
        if (i === 0) ctx.moveTo(x0 + px2, y2); else ctx.lineTo(x0 + px2, y2);
      }
      ctx.stroke();
    }

    // 合成波の振幅
    var amp = amplitudeOf(N, delta, st.lambda);
    ctx.font = D.font(12, true);
    ctx.fillStyle = '#5a3a7a';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText('合成波（' + N + ' つの波の和）', SM.x0 + 12, SM.y0 + 16);
    ctx.font = D.font(12.5, true);
    var rt = x1 + 22;
    ctx.fillStyle = '#5a3a7a';
    ctx.fillText('合成波の振幅', rt, cy - 16);
    ctx.font = D.font(15, true);
    ctx.fillStyle = amp > N * 0.7 ? '#1b6b34' : (amp < N * 0.3 ? '#a12a1c' : '#8a6d00');
    ctx.fillText(amp.toFixed(2) + ' / ' + N.toFixed(2), rt, cy + 6);
    ctx.font = D.font(11);
    ctx.fillStyle = '#5b6672';
    ctx.fillText(sol.kind === 'strong' ? '→ そろっている（明線）' : '→ 打ち消しあっている', rt, cy + 26);
    ctx.font = D.font(10.5);
    ctx.fillStyle = '#8d8163';
    ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
    ctx.fillText('図では ' + N + ' 本ぶん。実際の回折格子は数千本あるので、'
      + '条件から少しずれただけで完全に打ち消しあいます。', SM.x0 + 12, SM.y1 - 8);
    ctx.restore();
  }

  /** N 個の等振幅・等位相差の波の合成振幅 |sin(Nπδ/λ) / sin(πδ/λ)| */
  function amplitudeOf(N, delta, lambda) {
    var b = Math.PI * delta / lambda;
    var s = Math.sin(b);
    if (Math.abs(s) < 1e-9) return N;
    return Math.abs(Math.sin(N * b) / s);
  }

  /* ================= 右：干渉パターン ================= */
  var cache = { key: '', cv: null };

  function patternKey(st) {
    return [st.d, st.L, st.lambda, st.light, st.gammaOn ? 1 : 0, st.N, SCR.sh].join('|');
  }

  function buildPattern(st) {
    var h = SCR.sh * 2 + 1;
    var cv = document.createElement('canvas');
    cv.width = 1; cv.height = h;
    var g = cv.getContext('2d');
    var img = g.createImageData(1, h);
    var gam = st.gammaOn ? (st.light === 'white' ? SCR.gammaWhite : SCR.gamma) : 1;
    for (var i = 0; i < h; i++) {
      var yPx = i - SCR.sh;                     // 中心からの px（下向きが +）
      var xm = -yPx / L.PPM;                    // スクリーン上の位置 [m]
      var th = P.thetaFromX(xm, st.L);
      var r, gg, b;
      if (st.light === 'white') {
        var c = P.spectrumColorAtX(xm, st.d, st.L, st.N, 1);
        r = 255 * Math.pow(c.r / 255, gam);
        gg = 255 * Math.pow(c.g / 255, gam);
        b = 255 * Math.pow(c.b / 255, gam);
      } else {
        var I = Math.pow(P.intensityN(th, st.d, st.lambda, st.N), gam);
        var pc = D.pureColor(st.lambda);
        r = pc.r * I; gg = pc.g * I; b = pc.b * I;
      }
      img.data[i * 4] = Math.round(r);
      img.data[i * 4 + 1] = Math.round(gg);
      img.data[i * 4 + 2] = Math.round(b);
      img.data[i * 4 + 3] = 255;
    }
    g.putImageData(img, 0, 0);
    return cv;
  }

  function pattern(ctx, st, sol) {
    var key = patternKey(st);
    if (key !== cache.key) { cache.key = key; cache.cv = buildPattern(st); }
    var x = SCR.x, y0 = SCR.cy - SCR.sh;

    ctx.save();
    // 枠（スクリーン）
    ctx.fillStyle = COL.screen;
    ctx.fillRect(x - 4, y0 - 4, SCR.w + 8, SCR.sh * 2 + 8);
    ctx.strokeStyle = COL.screenEdge; ctx.lineWidth = 1.2;
    ctx.strokeRect(x - 4, y0 - 4, SCR.w + 8, SCR.sh * 2 + 8);
    // パターン（1 px の縦帯を引き伸ばす）
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(cache.cv, 0, 0, 1, SCR.sh * 2 + 1, x, y0, SCR.w, SCR.sh * 2 + 1);
    ctx.imageSmoothingEnabled = true;

    // 次数のラベル
    ctx.font = D.font(11);
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    var used = [];
    var mMaxW = (st.light === 'white') ? Math.ceil(st.d / 380 - 1e-12) - 1 : sol.mMax;
    for (var m = -mMaxW; m <= mMaxW; m++) {
      var th = (st.light === 'white')
        ? (Math.abs(m) * 380 / st.d < 1 ? Math.asin(m * 380 / st.d) : null)
        : P.thetaOf(m, st.lambda, st.d);
      if (th === null) continue;
      var yy = SCR.cy - P.xOnScreen(th, st.L) * L.PPM;
      if (Math.abs(yy - SCR.cy) > SCR.sh) continue;
      var ok = true;
      for (var u = 0; u < used.length; u++) if (Math.abs(used[u] - yy) < 17) ok = false;
      if (!ok) continue;
      used.push(yy);
      ctx.fillStyle = '#5b6672';
      ctx.fillText('m = ' + Math.abs(m), x + SCR.w + 10, yy);
    }

    // 見出し
    ctx.font = D.font(12, true);
    ctx.fillStyle = '#28405c';
    ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
    ctx.fillText('スクリーンの見え方', x + SCR.w / 2, y0 - 12);
    ctx.font = D.font(10.5);
    ctx.fillStyle = '#5b6672';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText(st.gammaOn ? '明るさは見やすいように強調（γ = 0.45）' : '明るさは計算そのまま',
      x - 4, y0 + SCR.sh * 2 + 12);
    ctx.fillText('N ＝ ' + st.N + ' 本ぶんで計算', x - 4, y0 + SCR.sh * 2 + 26);
    ctx.restore();

    // いま見ている方向のしるし
    var ys = SCR.cy - sol.x * L.PPM;
    if (Math.abs(ys - SCR.cy) <= SCR.sh) {
      D.arrow(ctx, D.vec(x - 30, ys), D.vec(1, 0), 22, '#1f74d0', 2, 8);
      ctx.save();
      ctx.font = D.font(10.5, true);
      ctx.fillStyle = '#1f74d0';
      ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
      ctx.fillText('見る方向', x - 34, ys);
      ctx.restore();
    }
  }

  /* ================= 本体 ================= */
  function render(ctx, st, sol, sc) {
    D.panels(ctx);
    wavelets(ctx, st, sol);
    rayWaves(ctx, st, sol);
    sumWave(ctx, st, sol);
    pattern(ctx, st, sol);

    // 左上の見出し（①モードと同じ作法）
    ctx.save();
    var t = '波の動きと重ね合わせ';
    ctx.font = D.font(13.5, true);
    var w = ctx.measureText(t).width + 26;
    D.roundRect(ctx, 12, 10, w, 26, 8);
    ctx.fillStyle = '#f3ecfa'; ctx.fill();
    ctx.strokeStyle = '#8b3fa8'; ctx.lineWidth = 1.6; ctx.stroke();
    ctx.fillStyle = '#6d2f86';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(t, 25, 24);
    ctx.restore();
  }

  return { render: render, amplitudeOf: amplitudeOf, WV: WV, SCR: SCR };
})();
