/* ===== 60_mode_wave.js ===== */
/* ② 実際の波の動きを見る
 *
 * レイアウトは ①（光路差の位置と式の原理）とまったく同じ。
 * 変わるのは次の 3 つだけ。
 *   1. 拡大図の sin カーブ・点 P の拡大図・下の帯の波が動く（st.t が進む）
 *      ／光線は破線が流れて、進んでいることを示す
 *   2. スクリーンに、干渉パターンそのもの（＝スクリーンの見え方）を描く
 *   3. 合成波（すべてのスリットからの波の和）のカードを足す
 * 図そのものは 50_mode_path.js の render() を opt.wave 付きで呼んで描く。
 */
window.DG = window.DG || {};
DG.modeWave = (function () {
  'use strict';
  var D = DG.draw, P = DG.phys;
  var L = D.L, COL = D.COL;

  /** 合成波のカード（右パネルの空いているところ） */
  var SUM = { x0: 322, y0: 384, x1: 806, y1: 462 };
  var GAMMA = 0.45, GAMMA_WHITE = 0.62;
  /** 合成波に足しあわせる波の本数（図に描いてあるスリットの本数と同じ） */
  var NSUM = L.NSLIT;

  /* ================= スクリーンの見え方（干渉パターン） ================= */
  var cache = { key: '', cv: null };

  function patternKey(st) {
    return [st.d, st.L, st.lambda, st.light, st.gammaOn ? 1 : 0, st.N].join('|');
  }

  /** 1 px 幅の縦画像として明るさをつくる（重いので、設定が変わったときだけ） */
  function buildPattern(st) {
    var h = L.SH * 2 + 1;
    var cv = document.createElement('canvas');
    cv.width = 1; cv.height = h;
    var g = cv.getContext('2d');
    var img = g.createImageData(1, h);
    var gam = st.gammaOn ? (st.light === 'white' ? GAMMA_WHITE : GAMMA) : 1;
    for (var i = 0; i < h; i++) {
      var yPx = i - L.SH;                       // 中心からの px（下向きが +）
      var xm = -yPx / L.PPM;                    // スクリーン上の位置 [m]
      var r, gg, b;
      if (st.light === 'white') {
        var c = P.spectrumColorAtX(xm, st.d, st.L, st.N, 1);
        r = 255 * Math.pow(c.r / 255, gam);
        gg = 255 * Math.pow(c.g / 255, gam);
        b = 255 * Math.pow(c.b / 255, gam);
      } else {
        var th = P.thetaFromX(xm, st.L);
        var I = Math.pow(P.intensityN(th, st.d, st.lambda, st.N), gam);
        var pc = D.pureColor(st.lambda);
        r = pc.r * I; gg = pc.g * I; b = pc.b * I;
      }
      img.data[i * 4] = Math.round(r);
      img.data[i * 4 + 1] = Math.round(gg);
      img.data[i * 4 + 2] = Math.round(b);
      img.data[i * 4 + 3] = 255;
    }
    g.putImageData(img, 0, 0);
    return cv;
  }

  /* ================= 光の強度分布のグラフ（スクリーンの右わき） =================
   * 横軸＝明るさ（右ほど明るい）、縦軸＝スクリーン上の位置（図と同じものさし）。
   * gamma（見やすさの強調）はかけず、計算した強度そのものを描く。 */
  var GB = { x0: 1216, w: 76 };
  var gCache = { key: '', arr: null };

  function buildIntensityArr(st) {
    var h = L.SH * 2 + 1;
    var arr = [];
    var SS2 = 4;                                 // 1 px の中を 4 点しらべて最大をとる
    for (var i = 0; i < h; i++) {
      var v = 0;
      for (var q = 0; q < SS2; q++) {
        var xm = -(i - L.SH + q / SS2) / L.PPM;
        var th = P.thetaFromX(xm, st.L);
        if (st.light === 'white') {
          var s = 0, n = 0;
          for (var lam = 380; lam <= 780; lam += 8) { s += P.intensityN(th, st.d, lam, st.N); n++; }
          v = Math.max(v, s / n);
        } else {
          v = Math.max(v, P.intensityN(th, st.d, st.lambda, st.N));
        }
      }
      arr.push(v);
    }
    return arr;
  }

  function intensityGraph(ctx, st, sol, sc) {
    var key = [st.d, st.L, st.lambda, st.light, st.N].join('|');
    if (key !== gCache.key) { gCache.key = key; gCache.arr = buildIntensityArr(st); }
    var arr = gCache.arr;
    var x0 = GB.x0, w = GB.w, yTop = L.CY - L.SH;
    ctx.save();
    ctx.fillStyle = 'rgba(255,255,255,0.75)';
    ctx.fillRect(x0 - 4, yTop - 4, L.W - (x0 - 4) - 2, L.SH * 2 + 8);
    ctx.strokeStyle = '#b9c0c8'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(x0 + 0.5, yTop); ctx.lineTo(x0 + 0.5, yTop + L.SH * 2); ctx.stroke();
    // うすい塗り＋赤い曲線
    var i;
    ctx.beginPath();
    ctx.moveTo(x0, yTop);
    for (i = 0; i < arr.length; i++) ctx.lineTo(x0 + arr[i] * w, yTop + i);
    ctx.lineTo(x0, yTop + arr.length - 1);
    ctx.closePath();
    ctx.fillStyle = 'rgba(208,52,44,0.10)'; ctx.fill();
    ctx.beginPath();
    for (i = 0; i < arr.length; i++) {
      var xx = x0 + arr[i] * w;
      if (i === 0) ctx.moveTo(xx, yTop); else ctx.lineTo(xx, yTop + i);
    }
    ctx.strokeStyle = '#d0342c'; ctx.lineWidth = 1.6; ctx.lineJoin = 'round';
    ctx.stroke();
    // 主極大の針。N′ が大きいと山が 1 px より細くなり、サンプリングでは
    // 拾いきれないことがあるので、明線の位置には式から出した針を必ず立てる
    if (st.light !== 'white') {
      ctx.strokeStyle = '#d0342c'; ctx.lineWidth = 1.4;
      for (i = 0; i < sol.orders.length; i++) {
        var yb = L.CY - sol.orders[i].x * sc.ppm;
        if (Math.abs(yb - L.CY) > L.SH) continue;
        ctx.beginPath(); ctx.moveTo(x0, yb); ctx.lineTo(x0 + w, yb); ctx.stroke();
      }
    }
    // 見出し
    ctx.font = D.font(11, true);
    ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
    var t = '光の強度分布';
    var tw2 = ctx.measureText(t).width;
    ctx.fillStyle = 'rgba(255,255,255,0.9)';
    ctx.fillRect(x0 + w / 2 - tw2 / 2 - 3, yTop - 25, tw2 + 6, 16);
    ctx.fillStyle = '#a12a1c';
    ctx.fillText(t, x0 + w / 2, yTop - 10);
    ctx.restore();
  }

  /** スクリーンの面に干渉パターンを描き、次数のラベルを添える */
  function screenPattern(ctx, st, sol, sc, avoidY) {
    var key = patternKey(st);
    if (key !== cache.key) { cache.key = key; cache.cv = buildPattern(st); }

    ctx.save();
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(cache.cv, 0, 0, 1, L.SH * 2 + 1,
      L.SX, L.CY - L.SH, L.SCR_W, L.SH * 2 + 1);
    ctx.imageSmoothingEnabled = true;
    ctx.restore();

    // スクリーンの右わきに、光の強度分布のグラフを添える
    intensityGraph(ctx, st, sol, sc);

    // 次数のラベル（①とまったく同じ関数で位置を出す。
    // モードを切りかえてもラベルの位置がずれないようにするため）
    var chips;
    if (st.light === 'white') {
      chips = DG.modePath.whiteChips(st, sc);
    } else {
      chips = [];
      for (var m = -sol.mMax; m <= sol.mMax; m++) {
        var s = Math.abs(m) * st.lambda / st.d;
        if (!(s < 1)) continue;
        var th = (m < 0 ? -1 : 1) * Math.asin(s);
        var y = L.CY - P.xOnScreen(th, st.L) * sc.ppm;
        if (Math.abs(y - L.CY) > L.SH) continue;
        chips.push({ m: m, y: y, on: (sol.kind === 'strong' && m === sol.m) });
      }
    }
    DG.modePath.orderChips(ctx, chips, avoidY, st.hoverBtn);

    if (st.light === 'white') {
      DG.modePath.addNote('0 次は白、1 次からは');
      DG.modePath.addNote('虹色（紫が内・赤が外）');
    }
    DG.modePath.addNote(st.gammaOn ? '明るさ：強調あり' : '明るさ：計算そのまま');
    DG.modePath.addNote('N ＝ ' + st.N + ' 本で計算');
  }

  /* ================= 合成波 ================= */
  /** N 個の等振幅・位相差一定の波の合成振幅 |sin(Nπδ/λ) / sin(πδ/λ)| */
  function amplitudeOf(N, delta, lambda) {
    var b = Math.PI * delta / lambda;
    var s = Math.sin(b);
    if (Math.abs(s) < 1e-9) return N;
    return Math.abs(Math.sin(N * b) / s);
  }

  function sumCard(ctx, st, sol, sc) {
    var N = NSUM;
    var nmToPx = L.LD / st.d;                 // 拡大図と同じものさし
    var delta = P.pathDiff(st.d, sol.theta);  // 隣りあう波のずれ [nm]
    var t = st.t || 0;
    var x0 = SUM.x0 + 14, x1 = SUM.x1 - 176;
    var cy = (SUM.y0 + SUM.y1) / 2 + 6;
    var unit = 24 / N;                        // 振幅 1 ぶんの px

    ctx.save();
    D.roundRect(ctx, SUM.x0, SUM.y0, SUM.x1 - SUM.x0, SUM.y1 - SUM.y0, 9);
    ctx.fillStyle = '#faf7fd'; ctx.fill();
    ctx.strokeStyle = '#d6c8e6'; ctx.lineWidth = 1.3; ctx.stroke();

    // 見出しはカードの中に入れる（外に出すと上のラベルとぶつかる）
    ctx.font = D.font(11.5, true);
    ctx.fillStyle = '#5a3a7a';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText('合成波（図に描いた ' + N + ' 本の和）', SUM.x0 + 12, SUM.y0 + 14);

    ctx.strokeStyle = '#cfc4de'; ctx.lineWidth = 1;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(x0, cy); ctx.lineTo(x1, cy);
    ctx.moveTo(x0, cy - N * unit); ctx.lineTo(x1, cy - N * unit);
    ctx.moveTo(x0, cy + N * unit); ctx.lineTo(x1, cy + N * unit);
    ctx.stroke();
    ctx.setLineDash([]);

    var steps = 460, i, j;
    ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(232,134,42,0.42)';
    for (j = 0; j < N; j++) {
      ctx.beginPath();
      for (i = 0; i <= steps; i++) {
        var px = (x1 - x0) * i / steps;
        var y = cy - P.waveAt(px / nmToPx + j * delta, t, st.lambda) * unit;
        if (i === 0) ctx.moveTo(x0 + px, y); else ctx.lineTo(x0 + px, y);
      }
      ctx.stroke();
    }
    if (st.showSum) {
      ctx.strokeStyle = COL.sum; ctx.lineWidth = 2.2; ctx.lineJoin = 'round';
      ctx.beginPath();
      for (i = 0; i <= steps; i++) {
        var px2 = (x1 - x0) * i / steps;
        var sum = 0;
        for (j = 0; j < N; j++) sum += P.waveAt(px2 / nmToPx + j * delta, t, st.lambda);
        var y2 = cy - sum * unit;
        if (i === 0) ctx.moveTo(x0 + px2, y2); else ctx.lineTo(x0 + px2, y2);
      }
      ctx.stroke();
    }

    var amp = amplitudeOf(N, delta, st.lambda);
    var rt = x1 + 16;
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.font = D.font(11);
    ctx.fillStyle = '#5a3a7a';
    ctx.fillText('合成波の振幅', rt, cy - 18);
    ctx.font = D.font(15, true);
    ctx.fillStyle = amp > N * 0.7 ? '#1b6b34' : (amp < N * 0.3 ? '#a12a1c' : '#8a6d00');
    ctx.fillText(amp.toFixed(2) + ' / ' + N.toFixed(2), rt, cy + 2);
    ctx.font = D.font(11);
    ctx.fillStyle = '#5b6672';
    ctx.fillText(sol.kind === 'strong' ? '→ そろっている（明線）'
      : (sol.kind === 'weak' ? '→ 打ち消しあう' : '→ 完全にはそろわない'), rt, cy + 20);

    ctx.restore();
  }

  /* ================= 左上の見出し ================= */
  function title(ctx) {
    var t = '実際の波の動きを見る';
    ctx.save();
    ctx.font = D.font(13.5, true);
    var w = ctx.measureText(t).width + 26;
    D.roundRect(ctx, 12, 10, w, 28, 8);
    ctx.fillStyle = '#f3ecfa'; ctx.fill();
    ctx.strokeStyle = '#8b3fa8'; ctx.lineWidth = 1.6; ctx.stroke();
    ctx.fillStyle = '#6d2f86';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(t, 25, 25);
    ctx.restore();
  }

  function render(ctx, st, sol, sc) {
    DG.modePath.render(ctx, st, sol, sc, st.step, { wave: true });
  }

  return {
    render: render, screenPattern: screenPattern, sumCard: sumCard, title: title,
    amplitudeOf: amplitudeOf, NSUM: NSUM, SUM: SUM
  };
})();
