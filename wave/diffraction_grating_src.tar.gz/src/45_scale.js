/* ===== 45_scale.js ===== */
/* 「🔍 実寸」オーバーレイ
 * 図だけを見せる別画面で、装置全体のようすと大きさの実感を 4 場面で見せる。
 *   ① 光源 → スリット → 回折格子 → スクリーン の並び
 *   ② 回折格子の表面の拡大（筋と筋の間がスリット、そこから素元波が広がる）
 *   ③ 引いて見ると、m = 0, 1, 2 の光が扇状に広がってスクリーンに届く
 *   ④ 大きさくらべ（λ・d・髪の毛・1 mm・L を対数の物さしに並べる）
 */
window.DG = window.DG || {};
DG.scaleOut = (function () {
  'use strict';
  var D = DG.draw, P = DG.phys;
  var L = D.L, COL = D.COL;

  var DUR = 24;                 // 4 場面ぜんぶで何秒か
  var SCENES = ['装置全体', '波面の進み方（回折）', '射線の様子', '大きさくらべ'];
  /* ボタンや見出しに出す、長いほうの名まえ */
  var TITLES = [
    '装置全体',
    '格子の表面→スクリーンへの　波面の進み方（「回折」の様子）',
    '格子の表面→スクリーンへの　射線（波の進む向きにひく線）の様子',
    '大きさくらべ（実寸のズームアウト）'
  ];

  /** 3 けたごとにコンマを打つ */
  function comma(n) {
    var s = String(Math.round(n)), out = '';
    for (var i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 === 0) out += ',';
      out += s.charAt(i);
    }
    return out;
  }
  /** 大きい数を「50 万」「120 万」のように読む */
  function man(n) {
    if (n >= 1e8) return (n / 1e8).toFixed(n >= 1e9 ? 0 : 1) + ' 億 ';
    if (n >= 1e4) return Math.round(n / 1e4) + ' 万 ';
    return comma(n) + ' ';
  }

  function sceneOf(prog) { return P.clamp(Math.floor(prog * 4), 0, 3); }
  function localT(prog) { var s = sceneOf(prog); return P.clamp(prog * 4 - s, 0, 1); }

  /* ---------- 共通の飾り ---------- */
  function header(ctx, st, prog) {
    var s = sceneOf(prog);
    ctx.save();
    ctx.font = D.font(16, true);
    ctx.fillStyle = '#1a4e86';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    var head = '🔍 実験の概要　' + (s + 1) + '. ';
    ctx.fillText(head, 24, 18);
    var hx = 24 + ctx.measureText(head).width;
    // 「回折」だけ色を変えて強調する
    var parts = TITLES[s].split('回折');
    for (var q = 0; q < parts.length; q++) {
      if (q > 0) {
        ctx.fillStyle = '#c0392b';
        ctx.fillText('回折', hx, 18);
        hx += ctx.measureText('回折').width;
        ctx.fillStyle = '#1a4e86';
      }
      ctx.fillText(parts[q], hx, 18);
      hx += ctx.measureText(parts[q]).width;
    }
    // 進み具合
    var x0 = 24, x1 = L.W - 24, y = 46;
    ctx.strokeStyle = '#dbe3ea'; ctx.lineWidth = 4; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(x0, y); ctx.lineTo(x1, y); ctx.stroke();
    ctx.strokeStyle = '#1663b5';
    ctx.beginPath(); ctx.moveTo(x0, y); ctx.lineTo(x0 + (x1 - x0) * prog, y); ctx.stroke();
    for (var i = 0; i < 4; i++) {
      var xx = x0 + (x1 - x0) * (i / 4);
      ctx.fillStyle = (i <= s) ? '#1663b5' : '#c9d2da';
      ctx.beginPath(); ctx.arc(xx, y, 5, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
  }

  function caption(ctx, lines, color) {
    var x = 24, w = L.W - 48, h = 12 + lines.length * 19;
    var y = L.H - h - 20;
    ctx.save();
    D.roundRect(ctx, x, y, w, h, 10);
    ctx.fillStyle = '#f7f9fc'; ctx.fill();
    ctx.strokeStyle = color || '#c4d2e2'; ctx.lineWidth = 1.4; ctx.stroke();
    ctx.font = D.font(13);
    ctx.fillStyle = '#28405c';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    var maxW = w - 32;
    for (var i = 0; i < lines.length; i++) {
      // 長すぎる行は、はみ出さないように少しだけ字を小さくする
      var size = 13;
      ctx.font = D.font(size, i === 0);
      while (ctx.measureText(lines[i]).width > maxW && size > 9.5) {
        size -= 0.5;
        ctx.font = D.font(size, i === 0);
      }
      ctx.fillText(lines[i], x + 16, y + 8 + i * 19);
    }
    ctx.restore();
  }

  /** 等角投影ふうの板（前の面＋奥行き） */
  function plate(ctx, x, y0, y1, fill, edge, depth) {
    var dx = depth || 64, dy = -(depth || 64) * 0.55;
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(x, y0); ctx.lineTo(x + dx, y0 + dy);
    ctx.lineTo(x + dx, y1 + dy); ctx.lineTo(x, y1);
    ctx.closePath();
    ctx.fillStyle = fill; ctx.fill();
    ctx.strokeStyle = edge; ctx.lineWidth = 1.4; ctx.stroke();
    ctx.restore();
  }

  /* ================= ① 装置全体 ================= */
  function scene1(ctx, st, t) {
    var cy = 340;
    /* 光源・スリット・回折格子は近くにかためて置き、
       そこからスクリーンまでを大きくあける（実際の装置もそうなっている）。 */
    var xs = { src: 150, slit: 256, gr: 372, scr: 1040 };
    var SLIT_HALF = 9;             // スリットのすきま（光の線がちゃんと通って見える太さに）
    var GR_HALF = 22;             // 回折格子の高さの半分（前の 20 % ほど）
    var dx = 64, dy = -35;
    /* 板は等角投影（右奥へ dx, dy ずらして描く）なので、
       板の「まん中の奥ゆき」は front から (dx/2, dy/2) ずれたところにある。
       光の道すじも、その線の上を通さないと、板から外れて見えてしまう。 */
    var MX = dx / 2, MY = dy / 2;
    var axisY = cy + MY;                       // 光が通る高さ
    var SDX = 74, SDY = -74 * 0.55;            // スクリーンは板が厚い（奥ゆきが大きい）
    var SMX = SDX / 2, SMY = SDY / 2;
    var scrAxisY = cy + SMY;

    // 台（うすいグレーの床）
    ctx.save();
    ctx.fillStyle = '#f2f5f8';
    ctx.beginPath();
    ctx.moveTo(90, 520); ctx.lineTo(90 + dx, 520 + dy);
    ctx.lineTo(1180 + dx, 520 + dy); ctx.lineTo(1180, 520);
    ctx.closePath(); ctx.fill();
    ctx.restore();

    // 光の道すじは従来どおり ▶ で伸びていくアニメーションにする。
    // ただし「まだ一度も再生していない最初の状態（prog=0 で一時停止中）」だけは、
    // 光が何も見えない画面になってしまわないよう、はじめから全部届いた状態で見せる。
    var reach = (st.scaleOut && st.scaleOut.paused && st.scaleOut.prog <= 0)
      ? 1 : P.clamp(t * 1.6, 0, 1);
    var grX = xs.gr + MX;                      // 格子のまん中（光が出ていくところ）
    var srcX0 = xs.src + MX + 26;              // 光の線の始まり
    // 光は等速で進んで見えるように、「進んだ道のり」で 2 区間に分ける。
    // （以前は 光源→格子 と 格子→スクリーン をそれぞれ全体の半分の時間で
    //   進めていたため、格子を通った瞬間に約 3 倍へ加速して見えていた。）
    var d1 = grX - srcX0;                      // 光源 → 格子 の長さ [px]
    var d2 = xs.scr + SMX - grX;               // 格子 → スクリーン の長さ [px]
    var trav = reach * (d1 + d2);              // いままでに進んだ道のり [px]
    var endX = srcX0 + Math.min(trav, d1);     // 光源側の線の先はし
    var fan = P.clamp((trav - d1) / d2, 0, 1); // 扇の伸びぐあい（0〜1）
    var mMax = Math.min(2, P.maxOrder(st.lambda, st.d));
    // 扇のとどく先（スクリーンのまん中の面の上）
    function spotY(m) {
      var th = P.thetaOf(m, st.lambda, st.d);
      if (th === null) return null;
      return scrAxisY - Math.tan(th) * (xs.scr + SMX - grX) * 0.42;
    }
    // スクリーンの板（まん中の面）が実際にある高さの範囲。
    // この外に明線を描くと「スクリーンが無いのに干渉縞がある」ことになってしまう。
    var scrTop = cy - 190 + SMY, scrBot = cy + 190 + SMY;
    function onScreen(yk) { return yk !== null && yk > scrTop + 14 && yk < scrBot - 14; }
    // 板に当たらない光は、板の面（何もない空中）で止めず、図のはしまで自然に伸ばす。
    // ただし、等角投影で描いた板のシルエット（前の面〜奥の面）に見た目上当たる光は、
    // これまでどおり板のところで止める（板を突き抜けて見えると変なので）。
    // 戻り値は「板のまん中の面までの長さを 1 としたときの、その光線の長さ」。
    function extOf(yk) {
      if (yk === null || onScreen(yk)) return 1;
      var full = xs.scr + SMX - grX;
      var s = (yk - axisY) / full;
      function yAtX(x) { return axisY + s * (x - grX); }
      function topE(x) { return (cy - 190) + (x - xs.scr) * (SDY / SDX); }
      function botE(x) { return (cy + 190) + (x - xs.scr) * (SDY / SDX); }
      var xF = xs.scr, xB = xs.scr + SDX;
      if ((yAtX(xF) > topE(xF) && yAtX(xF) < botE(xF)) ||
          (yAtX(xB) > topE(xB) && yAtX(xB) < botE(xB))) return 1;
      var ext = (1245 - grX) / full;                       // 右はしまで
      var yAt = axisY + (yk - axisY) * ext;
      if (yAt < 68) ext = (68 - axisY) / (yk - axisY);     // 上はしで打ち切り
      if (yAt > 512) ext = (512 - axisY) / (yk - axisY);   // 下はしで打ち切り
      return ext;
    }

    // 光の道すじ（光源 → スリット → 格子）
    ctx.save();
    ctx.globalAlpha = 0.5;
    ctx.strokeStyle = COL.ray; ctx.lineWidth = 3; ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(srcX0, axisY); ctx.lineTo(endX, axisY); ctx.stroke();
    ctx.restore();

    // 格子から先は扇状（fan は道のりベースなので、格子の前後で速さが変わらない）
    if (fan > 0) {
      ctx.save();
      ctx.globalAlpha = 0.55;
      ctx.strokeStyle = COL.ray; ctx.lineWidth = 3;
      for (var m = -mMax; m <= mMax; m++) {
        var yy = spotY(m);
        if (yy === null) continue;
        var ex = extOf(yy);
        ctx.beginPath();
        ctx.moveTo(grX, axisY);
        ctx.lineTo(grX + (xs.scr + SMX - grX) * fan * ex, axisY + (yy - axisY) * fan * ex);
        ctx.stroke();
      }
      ctx.restore();
    }

    // 光源
    D.lightBulb(ctx, D.vec(xs.src + MX, axisY), { scale: 1.4, white: st.light === 'white' });
    // スリット板（まん中があいている ＝ 上下 2 枚に分けて、すきまを本当にあける）。
    // すきまの中心は cy ではなく axisY（光の道すじの高さ＝板の奥ゆきのまん中）に合わせる。
    // ここがずれていると、すきまが「板の正面」にしか開いておらず、光の線の高さでは
    // 板の陰に完全に隠れてしまう（光が全く見えなくなる原因だった）。
    plate(ctx, xs.slit, cy - 120, axisY - SLIT_HALF, '#e8ecef', '#98a3ad');
    plate(ctx, xs.slit, axisY + SLIT_HALF, cy + 120, '#e8ecef', '#98a3ad');
    // すきまごしに光が通っているのが分かるよう、すきまの範囲だけ光の線を上から描き直す
    // （格子のところと同じ、板に隠れて途切れないようにする作法）
    ctx.save();
    ctx.beginPath();
    ctx.rect(xs.slit - 4, axisY - SLIT_HALF, dx + 8, SLIT_HALF * 2);
    ctx.clip();
    ctx.globalAlpha = 0.5;
    ctx.strokeStyle = COL.ray; ctx.lineWidth = 3; ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(xs.src + MX + 26, axisY); ctx.lineTo(endX, axisY); ctx.stroke();
    ctx.restore();
    // 回折格子（光が当たるのはごく小さな部分）
    plate(ctx, xs.gr, cy - GR_HALF, cy + GR_HALF, 'rgba(207,230,242,0.92)', COL.plateEdge);
    ctx.save();
    ctx.strokeStyle = 'rgba(40,90,120,0.55)'; ctx.lineWidth = 1;
    for (var y = cy - GR_HALF + 3; y < cy + GR_HALF; y += 4) {
      ctx.beginPath(); ctx.moveTo(xs.gr, y); ctx.lineTo(xs.gr + dx, y + dy); ctx.stroke();
    }
    ctx.restore();

    // 格子の板の陰に隠れて光の道すじが途切れて見えないように、
    // 板の範囲だけ光の線を上から描き直す（入っていく光・出ていく光の両方）
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(xs.gr, cy - GR_HALF); ctx.lineTo(xs.gr + dx, cy - GR_HALF + dy);
    ctx.lineTo(xs.gr + dx, cy + GR_HALF + dy); ctx.lineTo(xs.gr, cy + GR_HALF);
    ctx.closePath(); ctx.clip();
    ctx.lineCap = 'round';
    if (endX > xs.gr) {
      ctx.globalAlpha = 0.5;
      ctx.strokeStyle = COL.ray; ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(xs.gr, axisY); ctx.lineTo(endX, axisY); ctx.stroke();
    }
    if (fan > 0) {
      ctx.globalAlpha = 0.55;
      ctx.strokeStyle = COL.ray; ctx.lineWidth = 3;
      for (var mIn = -mMax; mIn <= mMax; mIn++) {
        var yyIn = spotY(mIn);
        if (yyIn === null) continue;
        var exIn = extOf(yyIn);
        ctx.beginPath();
        ctx.moveTo(grX, axisY);
        ctx.lineTo(grX + (xs.scr + SMX - grX) * fan * exIn, axisY + (yyIn - axisY) * fan * exIn);
        ctx.stroke();
      }
    }
    ctx.restore();

    // 小さいので、引き出し線で「ここ」と示す
    ctx.save();
    ctx.strokeStyle = '#98a3ad'; ctx.lineWidth = 1;
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.moveTo(xs.slit + MX, cy + 8); ctx.lineTo(xs.slit + 32, 528);
    ctx.moveTo(grX, cy + GR_HALF + 4); ctx.lineTo(xs.gr + 32, 528);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();

    // スクリーン（一色の板。明線だけを光らせる）
    plate(ctx, xs.scr, cy - 190, cy + 190, '#efe6d2', '#a89878', SDX);
    if (fan >= 0.999) {
      var spotCol = st.light === 'white' ? '#ffffff' : P.rgbCss(D.pureColor(st.lambda));
      ctx.save();
      ctx.shadowColor = spotCol; ctx.shadowBlur = 10;
      ctx.strokeStyle = spotCol; ctx.lineWidth = 5; ctx.lineCap = 'round';
      for (var k = -mMax; k <= mMax; k++) {
        var yk = spotY(k);
        // 板の外に明線は描かない（板が無いところに縞が出るのは不自然）
        if (!onScreen(yk)) continue;
        ctx.beginPath();
        ctx.moveTo(xs.scr + SMX - 18, yk + 10);
        ctx.lineTo(xs.scr + SMX + 18, yk - 10);
        ctx.stroke();
      }
      ctx.restore();
    }

    // 「レーザーでもよい」の注
    ctx.save();
    var note = ['光源 ＋ スリットの代わりに、', 'レーザー光を直接あててもよい'];
    ctx.font = D.font(12, true);
    var nw = Math.max(ctx.measureText(note[0]).width, ctx.measureText(note[1]).width);
    var nx = xs.src - 34, ny = 168;
    D.roundRect(ctx, nx, ny, nw + 22, 46, 9);
    ctx.fillStyle = '#fffaf0'; ctx.fill();
    ctx.strokeStyle = '#e0a800'; ctx.lineWidth = 1.6; ctx.stroke();
    ctx.fillStyle = '#8a5300';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(note[0], nx + 11, ny + 15);
    ctx.fillText(note[1], nx + 11, ny + 32);
    // 引き出し線（光源とスリットの両方へ）
    ctx.strokeStyle = '#e0a800'; ctx.lineWidth = 1.2;
    ctx.setLineDash([4, 3]);
    ctx.beginPath();
    ctx.moveTo(nx + 26, ny + 46); ctx.lineTo(xs.src + MX, axisY - 26);
    ctx.moveTo(nx + nw - 10, ny + 46); ctx.lineTo(xs.slit + MX, cy - 60);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();

    // 名札
    var names = [['光源', xs.src + MX], ['スリット', xs.slit + 32],
      ['回折格子', xs.gr + 32], ['スクリーン', xs.scr + SMX]];
    ctx.save();
    ctx.font = D.font(13, true);
    ctx.fillStyle = '#3a4550';
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    for (var i = 0; i < names.length; i++) ctx.fillText(names[i][0], names[i][1], 545);
    ctx.restore();

    caption(ctx, [
      '① 装置の並び：光源 → スリット → 回折格子 → スクリーン',
      'スリットで細い光の筋にしてから回折格子にあてます。格子を通った光は、いくつかの決まった向き（m = 0, 1, 2, …）にだけ強く出ていきます。',
      '光源・スリット・回折格子はすぐ近くに並べ、そこからスクリーンまでを大きくあけます。'
        + 'スリットのすきまも、光が当たる格子の部分も、実際はとても小さい部分です。',
      'この図は「置き方」を示すためのもので、大きさの比は正しくありません。② 以降で本当の大きさを見ます。'
    ], '#e0a800');
  }

  /* ================= ② 格子の表面の拡大 ================= */
  function scene2(ctx, st, t) {
    var px = 480, top = 120, bot = 560;      // 板の面の位置
    var nslit = 4, sp = 96;
    var cy = (top + bot) / 2;
    var slits = [];
    for (var i = 0; i < nslit; i++) slits.push(cy + (i - (nslit - 1) / 2) * sp);

    var nmToPx = sp / st.d;                  // 縮尺どおり（d を sp px で描く）
    // 波長だけは、見やすさのために実際の 3 倍くらい離して描く（d の縮尺とは別物。このモードは
    // スリットの数・波長を固定として見せる図なので、正確な縮尺より「見やすさ」を優先する）
    var WAVE_STRETCH = 3;
    var lamPx = st.lambda * nmToPx * WAVE_STRETCH;
    var ph = ((P.V_NM_PER_S * nmToPx * (t * DUR / 4)) % lamPx + lamPx) % lamPx;

    ctx.save();
    ctx.beginPath(); ctx.rect(60, top - 10, L.W - 140, bot - top + 20); ctx.clip();

    // 入射する平面波
    ctx.strokeStyle = COL.rayDim; ctx.lineWidth = 2;
    for (var k = 0; k < 20; k++) {
      var x = px - 14 - (lamPx - ph) - k * lamPx;
      if (x < 66) break;
      ctx.beginPath(); ctx.moveTo(x, top); ctx.lineTo(x, bot); ctx.stroke();
    }
    // 素元波（重なるので細く・うすく）
    ctx.strokeStyle = COL.ray; ctx.lineWidth = 1.3; ctx.globalAlpha = 0.6;
    for (i = 0; i < nslit; i++) {
      for (k = 0; k < 26; k++) {
        var r = ph + k * lamPx;
        if (r > 660) break;
        ctx.beginPath();
        ctx.arc(px, slits[i], r, -Math.PI / 2, Math.PI / 2);
        ctx.stroke();
      }
    }
    ctx.globalAlpha = 1;
    ctx.restore();

    /* 「これが回折」の吹き出し。
       説明は 1 つの箱にまとめる（3 つに分けると図がごちゃごちゃするため）。
       スリットの幅より波長のほうが大きいくらいなので、光は
       まっすぐ進まずに、スリットを中心に円形に広がっていく。 */
    var TIPS = [
      { i: 2, dx: 168, dy: 66, t: [
        'スリットを通った光は、まっすぐ進まずに',
        [{ s: '回折', bold: true }, { s: 'して円形に広がっていく' }],
        '（どのスリットからも同じように広がる）'
      ] }
    ];
    // 1 行ぶんの幅を測る（ふつうの文字列でも、部分ごとに強調する行（配列）でもよい）
    function lineWidth(line) {
      if (!Array.isArray(line)) { ctx.font = D.font(12, true); return ctx.measureText(line).width; }
      var w = 0;
      for (var i2 = 0; i2 < line.length; i2++) {
        ctx.font = D.font(12, !!line[i2].bold);
        w += ctx.measureText(line[i2].s).width;
      }
      return w;
    }
    ctx.save();
    for (var w2 = 0; w2 < TIPS.length; w2++) {
      var tp = TIPS[w2];
      if (tp.i >= nslit) continue;
      var ax = px + 16, ay = slits[tp.i];
      var bx = ax + tp.dx, by = ay + tp.dy;
      var tw = 0, q;
      for (q = 0; q < tp.t.length; q++) tw = Math.max(tw, lineWidth(tp.t[q]));
      var bh = tp.t.length * 17 + 12;
      // 引き出し線
      ctx.strokeStyle = '#c0392b'; ctx.lineWidth = 1.4;
      ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(bx, by); ctx.stroke();
      ctx.beginPath(); ctx.arc(ax, ay, 3.2, 0, Math.PI * 2);
      ctx.fillStyle = '#c0392b'; ctx.fill();
      D.roundRect(ctx, bx, by - bh / 2, tw + 20, bh, 9);
      ctx.fillStyle = 'rgba(255,255,255,0.95)'; ctx.fill();
      ctx.strokeStyle = '#c0392b'; ctx.lineWidth = 1.6; ctx.stroke();
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      for (q = 0; q < tp.t.length; q++) {
        var line = tp.t[q];
        var ly = by - bh / 2 + 6 + 8 + q * 17;
        if (Array.isArray(line)) {
          var lx = bx + 10;
          for (var s2 = 0; s2 < line.length; s2++) {
            var seg = line[s2];
            ctx.fillStyle = seg.bold ? '#c0392b' : '#3a2018';
            ctx.font = D.font(12, !!seg.bold);
            ctx.fillText(seg.s, lx, ly);
            lx += ctx.measureText(seg.s).width;
          }
        } else {
          ctx.fillStyle = (line.indexOf('回折') >= 0) ? '#c0392b' : '#3a2018';
          ctx.font = D.font(12, line.indexOf('回折') >= 0);
          ctx.fillText(line, bx + 10, ly);
        }
      }
    }
    ctx.restore();

    // 板（筋とスリットが交互）
    ctx.save();
    ctx.fillStyle = COL.plate;
    ctx.fillRect(px - 24, top, 24, bot - top);
    ctx.fillStyle = 'rgba(255,255,255,0.95)';
    for (i = 0; i < nslit; i++) ctx.fillRect(px - 24, slits[i] - 10, 24, 20);
    ctx.strokeStyle = COL.plateEdge; ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(px - 24, top); ctx.lineTo(px, top);
    ctx.moveTo(px - 24, bot); ctx.lineTo(px, bot);
    ctx.moveTo(px - 24, top); ctx.lineTo(px - 24, bot);
    ctx.stroke();
    ctx.strokeStyle = '#3f7ba1'; ctx.lineWidth = 1.6;
    D.gratingFace(ctx, px, top, bot, slits[0], sp, 10, 12, 10);
    ctx.restore();

    D.dimLine(ctx, D.vec(px - 44, slits[0]), D.vec(px - 44, slits[1]),
      'd ＝ ' + (st.d / 1000).toFixed(2) + ' μm', '#3a4550', 22);

    // 名札（波の上に置くので、白い箱を敷いて読めるようにする）
    function tag(text, y, color) {
      ctx.font = D.font(12.5, true);
      var w = ctx.measureText(text).width;
      D.roundRect(ctx, px + 22, y - 11, w + 16, 22, 6);
      ctx.fillStyle = 'rgba(255,255,255,0.94)'; ctx.fill();
      ctx.strokeStyle = color; ctx.lineWidth = 1.2; ctx.stroke();
      ctx.fillStyle = color;
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText(text, px + 30, y + 1);
      // 引き出し線
      ctx.strokeStyle = color; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(px + 22, y); ctx.lineTo(px + 4, y); ctx.stroke();
    }
    ctx.save();
    // 上から順に「筋の説明」→「筋と筋の間（スリット）の説明」→（下の赤い箱）「回折した光の説明」
    tag('筋（けずってある）＝ 光は通らない', slits[0] - sp / 2, '#8a6d00');
    tag('筋と筋の間がスリット ＝ ここから波が広がる', slits[1], '#2b5a78');
    ctx.font = D.font(12);
    ctx.fillStyle = '#5b6672';
    ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    ctx.fillText('波長は見やすさのため実際の約 ' + WAVE_STRETCH + ' 倍に離して描いています（d ＝ ' + sp + ' px が正しいものさし）',
      L.W - 40, top - 26);
    ctx.restore();

    caption(ctx, [
      '② 格子の表面 → スクリーンへの 波面の進み方（d の間隔は縮尺どおり。波長は見やすさのため約 ' + WAVE_STRETCH + ' 倍に離して描いています）',
      '筋と筋のあいだ（＝ d ＝ ' + (st.d / 1000).toFixed(2) + ' μm）がスリット。'
        + 'すきまが光の波長 λ ＝ ' + Math.round(st.lambda) + ' nm と同じくらいの大きさなので、'
        + '光はまっすぐ進まず、筋がない平面部分から回折して広がります。',
      'この「回折した波」どうしが重なりあって、決まった向きにだけ波面がそろい、'
        + 'そのままスクリーンへ進んでいきます。'
        + '「回折」してくれないと重なりようがないので、この板は「回折格子」と呼ばれます。'
    ], COL.plateEdge);
  }

  /* ================= ③ 扇状に広がる ================= */
  /* この場面は縦も横も同じ縮尺で描く。
     格子〜スクリーンの距離を 620 px と決めると、1 m が何 px かが決まる。 */
  var S3 = { gx: 460, sx: 1080, cy: 300, half: 225, dist: 620 };

  function scene3(ctx, st, t) {
    var gx = S3.gx, sx = S3.sx, cy = S3.cy, HALF = S3.half;
    var ppm = S3.dist / st.L;                 // 1 m ＝ 何 px か
    var halfM = HALF / ppm;                   // 図に写っている範囲 [m]
    var mMax = P.maxOrder(st.lambda, st.d);
    var reach = P.clamp(t * 1.4, 0, 1);
    var col = P.rgbCss(D.pureColor(st.lambda));

    // スクリーン
    ctx.save();
    ctx.fillStyle = '#efe6d2';
    ctx.fillRect(sx - 5, cy - HALF - 6, 44, HALF * 2 + 12);
    ctx.fillStyle = '#1d1f22';
    ctx.fillRect(sx, cy - HALF, 34, HALF * 2);
    ctx.strokeStyle = '#a89878'; ctx.lineWidth = 1.2;
    ctx.strokeRect(sx - 5, cy - HALF - 6, 44, HALF * 2 + 12);
    ctx.restore();

    /* 扇（角度は本当の θ どおり）。
       スクリーンからはずれる光は、スクリーンの上下をすりぬけて図の外へ出ていく。 */
    var FIELD = 268;                          // 図に描ける上下のはば [px]
    var off = [];                             // スクリーンからはずれた次数
    ctx.save();
    ctx.beginPath();
    ctx.rect(gx - 4, cy - FIELD, L.W - gx, FIELD * 2);
    ctx.clip();
    /* 1 本の光線を引く。白色光のときは波長ごとに細い線を重ねて虹にする */
    function fan(m, lam, width) {
      var th = P.thetaOf(m, lam, st.d);
      if (th === null) return null;
      var tn = Math.tan(th);
      var ey = cy - tn * (sx - gx);           // スクリーンの面に届く高さ
      var onScr = Math.abs(ey - cy) <= HALF;
      var ex = sx;
      if (!onScr) {
        var xLim = gx + FIELD / Math.abs(tn);
        if (xLim < sx) { ex = xLim; ey = cy - (tn > 0 ? FIELD : -FIELD); }
      }
      var c = D.pureColor(lam);
      var grad = ctx.createLinearGradient(gx, cy, ex, ey);
      grad.addColorStop(0, P.rgbCss(c, 0.85));
      grad.addColorStop(1, P.rgbCss(c, onScr ? 0.45 : 0.14));
      ctx.strokeStyle = grad; ctx.lineWidth = width; ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(gx, cy);
      ctx.lineTo(gx + (ex - gx) * reach, cy + (ey - cy) * reach);
      ctx.stroke();
      return { ey: ey, onScr: onScr };
    }

    /* スクリーンに当たったところを光らせる */
    function spot(y, c) {
      ctx.save();
      ctx.shadowColor = c; ctx.shadowBlur = 12;
      ctx.strokeStyle = c; ctx.lineWidth = 5;
      ctx.beginPath(); ctx.moveTo(sx, y); ctx.lineTo(sx + 34, y); ctx.stroke();
      ctx.restore();
    }

    var WHITE_LAMS = [400, 450, 500, 550, 600, 650, 700];
    var WHITE_MMAX = 2;                       // 白色光は本数が多いので 2 次まで描く
    if (st.light === 'white') {
      // 白色光：0 次は白、1 次からは波長ごとに分かれる
      mMax = Math.min(WHITE_MMAX, Math.ceil(st.d / 380 - 1e-12) - 1);
      for (var mw = -mMax; mw <= mMax; mw++) {
        if (mw === 0) {
          ctx.save();
          ctx.strokeStyle = 'rgba(120,128,136,0.30)'; ctx.lineWidth = 8; ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.moveTo(gx, cy); ctx.lineTo(gx + (sx - gx) * reach, cy);
          ctx.stroke();
          ctx.restore();
          if (reach > 0.98) spot(cy, '#ffffff');
          continue;
        }
        var anyOn = false;
        for (var wi = 0; wi < WHITE_LAMS.length; wi++) {
          var rr = fan(mw, WHITE_LAMS[wi], 4);
          if (rr && rr.onScr) {
            anyOn = true;
            if (reach > 0.98) spot(rr.ey, P.rgbCss(D.pureColor(WHITE_LAMS[wi])));
          }
        }
        if (!anyOn && mw > 0) off.push(mw);
      }
    } else
    for (var m = -mMax; m <= mMax; m++) {
      var r0 = fan(m, st.lambda, 7);
      if (r0 === null) continue;
      var ey = r0.ey, onScr = r0.onScr;
      if (!onScr && m > 0) off.push(m);
      if (reach > 0.98 && onScr) {
        spot(ey, col);
        if (m >= 0) {
          ctx.font = D.font(12, true);
          ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
          ctx.fillStyle = '#5b6672';
          ctx.fillText('m = ' + m, sx + 46, ey);
        }
      }
    }
    ctx.restore();

    // 回折格子（縮尺どおりなら d ＝ 0.0004 px。「点」にしか見えないのが正しい）
    ctx.save();
    ctx.fillStyle = COL.plate;
    ctx.fillRect(gx - 6, cy - 46, 11, 92);
    ctx.strokeStyle = COL.plateEdge; ctx.lineWidth = 1.3;
    ctx.strokeRect(gx - 6, cy - 46, 11, 92);
    ctx.strokeStyle = 'rgba(40,90,120,0.5)'; ctx.lineWidth = 1;
    for (var y = cy - 43; y < cy + 45; y += 3.5) {
      ctx.beginPath(); ctx.moveTo(gx - 6, y); ctx.lineTo(gx + 5, y); ctx.stroke();
    }
    // 入射光（格子の高さのぶんだけ）
    for (var i = -1; i <= 1; i++) {
      D.arrow(ctx, D.vec(gx - 250, cy + i * 30), D.vec(1, 0), 236, COL.rayDim, 2, 8);
    }
    // 名札（扇の上に重なるので、白い箱を敷く）
    ctx.font = D.font(12.5, true);
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    function nameTag(text, tx, ty, color) {
      var w = ctx.measureText(text).width;
      D.roundRect(ctx, tx - w / 2 - 7, ty - 11, w + 14, 22, 6);
      ctx.fillStyle = 'rgba(255,255,255,0.94)'; ctx.fill();
      ctx.fillStyle = color; ctx.fillText(text, tx, ty + 1);
    }
    nameTag('回折格子', gx, cy + 64, '#2b5a78');
    nameTag('スクリーン', sx + 17, cy + HALF + 24, '#7a6a48');
    ctx.restore();

    // 寸法（縮尺どおりであることを示す）
    D.dimLine(ctx, D.vec(gx, cy + HALF + 52), D.vec(sx, cy + HALF + 52),
      'L ＝ ' + st.L.toFixed(2) + ' m', '#3a4550', 16);
    D.dimLine(ctx, D.vec(sx + 130, cy), D.vec(sx + 130, cy - HALF),
      D.fmtCm(halfM), '#3a4550', 18);

    caption(ctx, [
      '③ 格子の表面 → スクリーンへの 射線（波の進む向きにひく線）の様子',
      '②で見た「そろった波面」が進む向きにひいた線が射線です。'
        + '射線が残るのは d sinθ ＝ mλ の向きだけ。ほかの向きは打ち消しあって消えます。',
      '縦も横も同じ縮尺（角度も本当の値）。スクリーンは中心から ±' + D.fmtCm(halfM) + '。'
        + (st.light === 'white'
          ? '0 次は白、1 次からは虹色（紫が内・赤が外）。'
          : (mMax === 0
            ? 'いまは 1 次の明線が出ない設定です。'
            : '1 次は θ ＝ ' + (P.thetaOf(1, st.lambda, st.d) * 180 / Math.PI).toFixed(1) + '°。'))
        + (off.length ? '　m = ' + off[0] + ' 以上はスクリーンからはずれます。' : '')
    ], '#1663b5');
  }

  /* ================= ④ 大きさくらべ（実寸のズームアウト） =================
   * 薄膜ページの「実寸」と同じ作法。
   * 格子の表面が見えるところ（視野 ≒ 6d）から、人の大きさ（視野 3 m）まで、
   * 対数で連続にズームアウトする。比べるものは、地面に立てた棒として実寸で描く。
   */
  var Z = {
    groundY: 540,                 // 地面（ものが立っている高さ）
    view1: 8.0e9                  // ズームアウトの終点：8 m（人と L が入りきる）[nm]
  };
  /** 比べるもの（高さ [nm]）。ズームアウト専用なので、はじめの視野（格子 6 本ぶん）より
   *  小さいもの（原子など）は入れない ― 一度も表示されないため。 */
  var ZREF = [
    { h: 2000, name: '大腸菌', c: '#7fb79c' },
    { h: 8e4, name: '髪の毛の太さ', c: '#c9a86a' },
    { h: 1e6, name: '1 mm', c: '#9fb2c8' },
    { h: 2.4e7, name: '硬貨の直径', c: '#a9adb5' },
    { h: 1.7e9, name: '人', c: '#dfe6ee' }
  ];

  function fmtLen(nm) {
    if (nm < 1) return (Math.round(nm * 100) / 100) + ' nm';
    if (nm < 1000) return (Math.round(nm * 10) / 10) + ' nm';
    if (nm < 1e6) return (Math.round(nm / 100) / 10) + ' μm';
    if (nm < 1e9) return (Math.round(nm / 1e5) / 10) + ' mm';
    return (Math.round(nm / 1e8) / 10) + ' m';
  }

  /** 棒人間 */
  function person(ctx, footX, footY, hPx) {
    var head = hPx * 0.13;
    ctx.save();
    ctx.strokeStyle = '#dfe6ee'; ctx.fillStyle = '#dfe6ee';
    ctx.lineWidth = Math.max(1.2, hPx * 0.035);
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.beginPath(); ctx.arc(footX, footY - hPx * 0.925, head, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath();
    ctx.moveTo(footX, footY - hPx * 0.80); ctx.lineTo(footX, footY - hPx * 0.42);
    ctx.moveTo(footX, footY - hPx * 0.72); ctx.lineTo(footX - hPx * 0.16, footY - hPx * 0.50);
    ctx.moveTo(footX, footY - hPx * 0.72); ctx.lineTo(footX + hPx * 0.16, footY - hPx * 0.52);
    ctx.moveTo(footX, footY - hPx * 0.42); ctx.lineTo(footX - hPx * 0.13, footY);
    ctx.moveTo(footX, footY - hPx * 0.42); ctx.lineTo(footX + hPx * 0.13, footY);
    ctx.stroke();
    ctx.restore();
  }

  function scene4(ctx, st, t) {
    var W = L.W, H = L.H;
    var view0 = st.d * 6;                          // はじめの視野 ＝ 格子 6 本ぶん
    var view = Math.exp(Math.log(view0) + (Math.log(Z.view1) - Math.log(view0)) * t);
    var pxPerNm = W / view;
    var groundY = Z.groundY;

    /* ---- 背景（暗くして、光と棒を見やすく） ---- */
    ctx.save();
    var g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, '#0f1216'); g.addColorStop(1, '#1a2028');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);

    /* ---- 回折格子の表面（実寸）。地面のところに寝かせて描く ---- */
    var dpx = st.d * pxPerNm;
    ctx.fillStyle = '#25333d';
    ctx.fillRect(0, groundY, W, H - groundY);
    ctx.strokeStyle = '#3a7f8c'; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(0, groundY); ctx.lineTo(W, groundY); ctx.stroke();
    if (dpx > 6) {                                  // 筋が見えるあいだだけ描く
      ctx.strokeStyle = 'rgba(120,200,230,0.75)'; ctx.lineWidth = Math.min(3, dpx * 0.12);
      for (var gxp = (W / 2) % dpx; gxp < W; gxp += dpx) {
        ctx.beginPath();
        ctx.moveTo(gxp, groundY); ctx.lineTo(gxp, groundY + Math.min(26, dpx * 0.5));
        ctx.stroke();
      }
      ctx.font = D.font(11.5, true);
      ctx.fillStyle = '#8fd3e6';
      ctx.textAlign = 'left'; ctx.textBaseline = 'top';
      ctx.fillText('回折格子の筋（間かく d ＝ ' + fmtLen(st.d) + '）', 18, groundY + 30);
    } else {
      ctx.font = D.font(11.5, true);
      ctx.fillStyle = '#7f8f9a';
      ctx.textAlign = 'left'; ctx.textBaseline = 'top';
      ctx.fillText('回折格子（筋はもう細かすぎて見えない）', 18, groundY + 30);
    }

    /* ---- 比べるもの（実寸の棒） ---- */
    var items = [
      { h: st.lambda, name: '光の波長 λ', c: P.rgbCss(D.pureColor(st.lambda)), keep: true },
      { h: st.d, name: '格子定数 d', c: '#4fd0e0', keep: true }
    ];
    var i;
    for (i = 0; i < ZREF.length; i++) items.push(ZREF[i]);
    items.push({ h: st.L * 1e9, name: 'スクリーンまでの距離 L', c: '#ffd479', keep: true });

    // 小さい順に並べ、画面に入るものだけ描く。
    // 「次に大きいもの」だけは矢印つきで出して、この先に何が来るかを示す。
    items.sort(function (a, b) { return a.h - b.h; });
    var TALL = groundY - 140;
    var shown = [], overOne = null;
    for (i = 0; i < items.length; i++) {
      var hp = items[i].h * pxPerNm;
      if (hp > TALL) { if (!overOne) overOne = items[i]; continue; }
      if (hp < 1.2 && !items[i].keep) continue;
      shown.push(items[i]);
    }
    if (overOne) shown.push(overOne);

    var slotX = 76, k;
    for (k = 0; k < shown.length; k++) {
      var it = shown[k];
      var hpx = it.h * pxPerNm;
      var over = (hpx > TALL);
      var draw = over ? TALL : Math.max(2.5, hpx);
      var bw = Math.max(9, Math.min(22, draw * 0.15));
      var byTop = groundY - draw;
      if (it.name === '人' && !over) { person(ctx, slotX + bw / 2, groundY, hpx); }
      else {
        ctx.fillStyle = it.c;
        D.roundRect(ctx, slotX, byTop, bw, draw, Math.min(4, bw / 2)); ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.6)'; ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(slotX - 4, byTop); ctx.lineTo(slotX + bw + 4, byTop); ctx.stroke();
      }
      // 名まえと長さ
      ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
      var cxL = slotX + bw / 2;
      var lines = [it.name, fmtLen(it.h)];
      if (hpx < 1.2) lines.push('（もう見えない）');
      if (over) lines.push('（画面の外へ）');
      for (var q = 0; q < lines.length; q++) {
        ctx.font = (q === 0) ? D.font(11.5) : (q === 1 ? D.font(11.5, true) : D.font(11));
        ctx.fillStyle = (q === 0) ? '#dfe6ee' : (q === 1 ? it.c : '#9aa3ac');
        ctx.fillText(lines[q], cxL, byTop - 8 - (lines.length - 1 - q) * 14);
      }
      if (over) {
        ctx.strokeStyle = it.c; ctx.fillStyle = it.c; ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(cxL, byTop); ctx.lineTo(cxL, byTop - 12); ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(cxL, byTop - 20); ctx.lineTo(cxL - 5, byTop - 10);
        ctx.lineTo(cxL + 5, byTop - 10); ctx.closePath(); ctx.fill();
      }
      slotX += bw + Math.max(104, ctx.measureText(it.name).width + 26);
      if (slotX > W - 130) break;
    }

    /* ---- ものさし ---- */
    var target = Math.pow(10, Math.round(Math.log(view * 0.22) / Math.LN10));
    var sbH = target * pxPerNm;
    if (sbH > 24 && sbH < H * 0.7) {
      var sx4 = 34;
      ctx.strokeStyle = '#f2f4f7'; ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(sx4, groundY); ctx.lineTo(sx4, groundY - sbH);
      ctx.moveTo(sx4 - 6, groundY); ctx.lineTo(sx4 + 6, groundY);
      ctx.moveTo(sx4 - 6, groundY - sbH); ctx.lineTo(sx4 + 6, groundY - sbH);
      ctx.stroke();
      ctx.save();
      ctx.translate(sx4 - 8, groundY - sbH / 2);
      ctx.rotate(-Math.PI / 2);
      ctx.font = D.font(12, true); ctx.fillStyle = '#f2f4f7';
      ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
      ctx.fillText(fmtLen(target), 0, 0);
      ctx.restore();
    }

    /* ---- 見出しと数値 ---- */
    ctx.font = D.font(15, true); ctx.fillStyle = '#ffd479';
    ctx.textAlign = 'right'; ctx.textBaseline = 'top';
    ctx.fillText('画面の横はば ＝ ' + fmtLen(view), W - 24, 62);
    ctx.font = D.font(12); ctx.fillStyle = '#aab3bd';
    var zoom = view / view0;
    ctx.fillText((zoom >= 1000 ? Math.round(zoom / 1000) + ' 千倍' : Math.round(zoom) + ' 倍')
      + ' ズームアウト', W - 24, 84);
    ctx.restore();

    var times = Math.round(st.L * 1e9 / st.d / 1000) * 1000;
    caption(ctx, [
      '④ 大きさくらべ：格子の表面から、人の大きさまで連続して引いていく',
      '光の波長 λ ＝ ' + fmtLen(st.lambda) + ' と 格子定数 d ＝ ' + fmtLen(st.d)
        + ' は、けたが同じ（だから大きく曲がる）。髪の毛の太さは d の約 '
        + Math.round(8e4 / st.d) + ' 倍もあります。',
      'スクリーンまでの距離 L ＝ ' + st.L.toFixed(2) + ' m は d の約 '
        + String(times).replace(/\B(?=(\d{3})+$)/g, ',') + ' 倍。'
        + 'だから「各スリットから点 P へ向かう光は平行」とみなせるのです。'
    ], '#8b3fa8');
  }

  /* ================= 本体 ================= */
  function render(ctx, st, sol, prog) {
    ctx.save();
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, L.W, L.H);
    ctx.restore();
    var s = sceneOf(prog), t = localT(prog);
    if (s === 0) scene1(ctx, st, t);
    else if (s === 1) scene2(ctx, st, t);
    else if (s === 2) scene3(ctx, st, t);
    else scene4(ctx, st, t);
    header(ctx, st, prog);
  }

  return { render: render, DUR: DUR, SCENES: SCENES, TITLES: TITLES, sceneOf: sceneOf };
})();
