/* ===== 62_mode_field.js ===== */
/* 補足：多数の格子からの波がどう重なり合うか
 *
 * 左：格子のすぐ先の 2 次元の波のようす（縮尺どおり）。
 *     スリットの間隔 d を SP px で描くので、1 px ＝ d/SP [nm]、画面上の波長も λ×SP/d [px]。
 *     Σ sin(k rᵢ − ωt) をそのまま色で塗る（橙＝山／青＝谷）。素元波が広がって重なるようす。
 *
 * 右：スクリーン。その上の点 P を上下にドラッグすると、P の向き θ に進む光について
 *     ・各スリットからの波（10 本まで）
 *     ・N 本ぜんぶの合成波
 *     が右わきにたてに並ぶ。
 *
 * 数の計算は、ページ全体と同じ「平行光線」の考え方で行う（作法どおり）。
 *   隣りあう波のずれ  δ ＝ d sinθ
 *   N 本の合成振幅     |sin(Nπδ/λ) / sin(πδ/λ)|      （そろったとき N）
 * こうすると N を 1000 本にしたとき、明線以外がきちんと 0 になる。
 * 近くの場をそのまま足すやり方では、格子のすぐ先は近接場なので 0 にならない。
 */
window.DG = window.DG || {};
DG.modeField = (function () {
  'use strict';
  var D = DG.draw, P = DG.phys;
  var L = D.L, COL = D.COL;

  var FL = {
    x0: 264, y0: 26, x1: 776, y1: 626,    // 場を描く範囲（右はしはスクリーンの動ける限界。
                                          //   その右に「光の強度分布」グラフの余白をとってある）
    gx: 356,                              // 回折格子の x
    nMax: 10, sp: 40,                     // 図に描くスリット（N′ が多いときは 10 本まで）
    step: 2                               // 場の計算の刻み [px]
  };
  FL.cy = (FL.y0 + FL.y1) / 2;

  /** スクリーン（板）。面の x はドラッグで動かせる（格子に近づきすぎないように下限あり）。
   *  max はスクリーンの右わきに「光の強度分布」のグラフを置く余白ぶんだけ、少し手前にしてある */
  var SCR = { w: 16, min: 200, max: 420 };   // min/max は「格子からの距離 [px]」
  function screenX(st) {
    var v = (st.scrX === undefined || st.scrX === null) ? SCR.max : st.scrX;
    return FL.gx + P.clamp(v, SCR.min, SCR.max);
  }
  /** 右わきの「P に届く波」パネル */
  var PN = { x0: 900, x1: 1288, y0: 34, y1: 626, lam: 44 };
  /** 波を並べて描く本数の上限 */
  var NSHOW = 10;

  var NS = 10, SP = FL.sp;
  /** 図に描くスリットの本数。N′ が 10 より多いときは 10 本だけ描く */
  function drawnCount(st) { return Math.min(FL.nMax, Math.max(2, st.N)); }

  function slitY(i) { return FL.cy + (i - (NS - 1) / 2) * SP; }
  /** 1 px が何 nm か */
  function nmPerPx(st) { return st.d / SP; }

  /* ================= 平行光線としての計算（数はすべてこちら） ================= */

  /** 点 P を見る向き。格子の中心から P へ向かう向き */
  function sinThetaAt(st, y) {
    var dy = FL.cy - y, dx = screenX(st) - FL.gx;
    return dy / Math.hypot(dx, dy);
  }
  /** 隣りあう波のずれ δ ＝ d sinθ [nm] */
  function deltaAt(st, y) { return st.d * sinThetaAt(st, y); }

  /** N 本を足したときの振幅（そろったときを 1 とする） */
  function ampFrac(N, delta, lambda) {
    var b = Math.PI * delta / lambda;
    var s = Math.sin(b);
    if (Math.abs(s) < 1e-12) return 1;
    return Math.abs(Math.sin(N * b) / (N * s));
  }

  /** スクリーン上で「経路差が delta ＝ q λ」になる y。q は負でもよい */
  function yOfRatio(st, q) {
    var s = q * st.lambda / st.d;
    if (!(Math.abs(s) < 0.9999)) return null;
    var t = s / Math.sqrt(1 - s * s);            // tanθ
    return FL.cy - t * (screenX(st) - FL.gx);
  }

  /* ---------- 場のキャッシュ（左の 2 次元の図だけに使う） ---------- */
  var cache = { key: '', A: null, B: null, S: null, w: 0, h: 0 };

  function fieldKey(st) { return [st.d, st.lambda, SP, NS].join('|'); }


  function buildField(st) {
    var w = Math.floor((FL.x1 - FL.x0) / FL.step);
    var h = Math.floor((FL.y1 - FL.y0) / FL.step);
    var A = new Float32Array(w * h), B = new Float32Array(w * h), S = new Float32Array(w * h);
    var lamPx = st.lambda * SP / st.d;
    var k = 2 * Math.PI / lamPx;
    var ys = [];
    for (var i = 0; i < NS; i++) ys.push(slitY(i));
    for (var j = 0; j < h; j++) {
      var y = FL.y0 + j * FL.step;
      for (var ii = 0; ii < w; ii++) {
        var x = FL.x0 + ii * FL.step;
        var a = 0, b = 0, sm = 0;
        for (var s = 0; s < NS; s++) {
          var dx = x - FL.gx, dy = y - ys[s];
          var r = Math.sqrt(dx * dx + dy * dy);
          // 格子より左（入射側）は描かない
          if (dx < 2) { a = 0; b = 0; sm = 0; break; }
          var ph = k * r;
          // 遠いほど弱く（円形に広がるので 1/√r）。近すぎるところは頭打ち
          var amp = 1 / Math.sqrt(Math.max(r, 40) / 40);
          a += amp * Math.cos(ph);
          b += amp * Math.sin(ph);
          sm += amp;
        }
        A[j * w + ii] = a; B[j * w + ii] = b;
        S[j * w + ii] = (sm > 1e-6) ? sm : 1e9;   // 場のないところは 0 になるように
      }
    }
    return { A: A, B: B, S: S, w: w, h: h };
  }

  function ensureField(st) {
    var key = fieldKey(st);
    if (key !== cache.key) {
      var f = buildField(st);
      cache = { key: key, A: f.A, B: f.B, S: f.S, w: f.w, h: f.h };
    }
    return cache;
  }

  var buf = { cv: null, ctx: null, img: null, w: 0, h: 0 };
  function ensureBuf(w, h) {
    if (buf.w !== w || buf.h !== h) {
      buf.cv = document.createElement('canvas');
      buf.cv.width = w; buf.cv.height = h;
      buf.ctx = buf.cv.getContext('2d');
      buf.img = buf.ctx.createImageData(w, h);
      buf.w = w; buf.h = h;
    }
    return buf;
  }

  /** ある瞬間の変位を色で */
  function drawSnapshot(ctx, st) {
    var f = ensureField(st);
    var b = ensureBuf(f.w, f.h);
    var wt = 2 * Math.PI * (P.V_NM_PER_S / st.lambda) * (st.t || 0);
    var cw = Math.cos(wt), sw = Math.sin(wt);
    var dat = b.img.data;
    for (var i = 0; i < f.w * f.h; i++) {
      var v = (-sw * f.A[i] + cw * f.B[i]) / f.S[i];  // −1〜1（距離による弱まりは打ち消す）
      var u = v > 1 ? 1 : (v < -1 ? -1 : v);
      var m = Math.pow(Math.abs(u), 0.75);
      var r, g, bl;
      if (u >= 0) { r = 255 - 23 * m; g = 255 - 121 * m; bl = 255 - 213 * m; }
      else { r = 255 - 224 * m; g = 255 - 139 * m; bl = 255 - 47 * m; }
      dat[i * 4] = r; dat[i * 4 + 1] = g; dat[i * 4 + 2] = bl; dat[i * 4 + 3] = 255;
    }
    b.ctx.putImageData(b.img, 0, 0);
    ctx.save();
    // スクリーンより先には光は行かないので、そこで切る
    ctx.beginPath();
    ctx.rect(FL.x0, FL.y0, screenX(st) - FL.x0, FL.y1 - FL.y0);
    ctx.clip();
    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(b.cv, FL.x0, FL.y0, f.w * FL.step, f.h * FL.step);
    ctx.restore();
  }

  /* ---------- 共通の飾り ---------- */
  function grating(ctx, st) {
    var x = FL.gx;
    ctx.save();
    ctx.fillStyle = COL.plate;
    ctx.fillRect(x - 10, FL.y0, 14, FL.y1 - FL.y0);
    ctx.fillStyle = 'rgba(255,255,255,0.95)';
    for (var i = 0; i < NS; i++) ctx.fillRect(x - 10, slitY(i) - 2, 14, 4);
    ctx.strokeStyle = COL.plateEdge; ctx.lineWidth = 1.2;
    ctx.strokeRect(x - 10, FL.y0, 14, FL.y1 - FL.y0);
    // 入射光（スリットのあるところにだけ）
    for (i = 0; i < NS; i++) {
      D.arrow(ctx, D.vec(FL.x0 + 6, slitY(i)), D.vec(1, 0), x - 32 - FL.x0, COL.rayDim, 1.5, 6);
    }
    ctx.font = D.font(11, true);
    ctx.fillStyle = '#2b5a78';
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText('回折格子', x, FL.y1 + 6);
    // N′ が多くて描ききれないときは、格子のすぐそばにその旨を出す
    if (st.N > NS) {
      var ny = FL.y0 + 22;
      var t1 = '図に描けるのは ' + NS + ' 本まで';
      var t2 = '（計算は N′ ＝ ' + st.N + ' 本）';
      ctx.font = D.font(11, true);
      var tw = Math.max(ctx.measureText(t1).width, ctx.measureText(t2).width);
      var nx = FL.x0 + 10;
      D.roundRect(ctx, nx, ny - 12, tw + 20, 34, 6);
      ctx.fillStyle = 'rgba(255,255,255,0.92)'; ctx.fill();
      ctx.strokeStyle = '#a12a1c'; ctx.lineWidth = 1.2; ctx.stroke();
      ctx.fillStyle = '#a12a1c';
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText(t1, nx + 10, ny - 2);
      ctx.font = D.font(11);
      ctx.fillText(t2, nx + 10, ny + 13);
      // 「上にも下にも、本当はまだ続いている」ことを示す点々
      ctx.fillStyle = 'rgba(161,42,28,0.75)';
      for (var q = 0; q < 3; q++) {
        ctx.beginPath(); ctx.arc(x - 3, slitY(NS - 1) + 14 + q * 8, 1.8, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(x - 3, slitY(0) - 14 - q * 8, 1.8, 0, Math.PI * 2); ctx.fill();
      }
      ctx.textAlign = 'center';
    }
    D.dimLine(ctx, D.vec(x - 20, slitY(0)), D.vec(x - 20, slitY(1)), 'd', '#3a4550', 11);
    ctx.restore();
  }

  /* ---------- スクリーン ---------- */
  var scrCache = { key: '', cv: null };

  /* スクリーンの面の明るさ。
   * N′ が大きいと明線は 1 px よりずっと細くなる。ふつうに平均すると
   * 「本数を増やすほど明線が暗くなる」という、まちがった見た目になってしまう。
   * そこで、その 1 px が「経路差 ＝ λ の整数倍」をまたいでいれば最大（明線）とし、
   * またいでいなければ、その中でいちばん明るい値をとる。 */
  function screenStrip(st) {
    var key = [st.d, st.lambda, st.N, SP, screenX(st)].join('|');
    if (key === scrCache.key) return scrCache.cv;
    var h = FL.y1 - FL.y0;
    var cv = document.createElement('canvas');
    cv.width = 1; cv.height = h;
    var g = cv.getContext('2d');
    var img = g.createImageData(1, h);
    var pc = D.pureColor(st.lambda);
    var SUB = 24;
    for (var i = 0; i < h; i++) {
      var q0 = deltaAt(st, FL.y0 + i) / st.lambda;
      var q1 = deltaAt(st, FL.y0 + i + 1) / st.lambda;
      var lo = Math.min(q0, q1), hi = Math.max(q0, q1);
      var v;
      if (Math.floor(hi) > Math.floor(lo) || lo === Math.floor(lo)) {
        v = 1;                                  // λ の整数倍をまたいだ ＝ 明線
      } else {
        v = 0;
        for (var k = 0; k < SUB; k++) {
          var q = lo + (hi - lo) * (k + 0.5) / SUB;
          v = Math.max(v, ampFrac(st.N, q * st.lambda, st.lambda));
        }
      }
      v = Math.pow(v, 1.1);
      img.data[i * 4] = Math.round(pc.r * v);
      img.data[i * 4 + 1] = Math.round(pc.g * v);
      img.data[i * 4 + 2] = Math.round(pc.b * v);
      img.data[i * 4 + 3] = 255;
    }
    g.putImageData(img, 0, 0);
    scrCache = { key: key, cv: cv };
    return cv;
  }

  /**
   * スクリーンのすぐ右に、光の強度分布のグラフを描く。
   * 横軸＝明るさ（振幅の 2 乗）、縦軸＝スクリーン上の位置（図と同じものさし）。
   * N′ を変えると、このグラフの形がその場で変わる（明線が細くなっていく）。
   */
  function intensityGraph(ctx, st, sx) {
    var x0 = sx + SCR.w + 12, w = 62;
    var y0 = FL.y0, y1 = FL.y1;
    ctx.save();
    ctx.fillStyle = 'rgba(255,255,255,0.88)';
    ctx.fillRect(x0 - 4, y0, w + 14, y1 - y0);
    ctx.strokeStyle = '#b9c0c8'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(x0 + 0.5, y0); ctx.lineTo(x0 + 0.5, y1); ctx.stroke();
    // 曲線（うすい塗りつき）
    var pts = [];
    for (var y = y0; y <= y1; y += 1) {
      var f = ampFrac(st.N, deltaAt(st, y), st.lambda);
      pts.push([x0 + f * f * w, y]);          // 明るさ ＝ 振幅の 2 乗
    }
    var i;
    ctx.beginPath();
    ctx.moveTo(x0, y0);
    for (i = 0; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
    ctx.lineTo(x0, y1);
    ctx.closePath();
    ctx.fillStyle = 'rgba(208,52,44,0.10)'; ctx.fill();
    ctx.beginPath();
    for (i = 0; i < pts.length; i++) {
      if (i === 0) ctx.moveTo(pts[i][0], pts[i][1]); else ctx.lineTo(pts[i][0], pts[i][1]);
    }
    ctx.strokeStyle = '#d0342c'; ctx.lineWidth = 1.6; ctx.lineJoin = 'round';
    ctx.stroke();
    // 主極大の針（N′ が大きいと山が 1 px より細くなるので、式から出した位置に必ず立てる）
    var mMax2 = P.maxOrder(st.lambda, st.d);
    ctx.strokeStyle = '#d0342c'; ctx.lineWidth = 1.4;
    for (var m = -mMax2; m <= mMax2; m++) {
      var yb = yOfRatio(st, m);
      if (yb === null || yb < y0 + 2 || yb > y1 - 2) continue;
      ctx.beginPath(); ctx.moveTo(x0, yb); ctx.lineTo(x0 + w, yb); ctx.stroke();
    }
    // 見出し（グラフの上のすみに入れる）
    ctx.font = D.font(10.5, true);
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    var t = '光の強度分布';
    var tw = ctx.measureText(t).width;
    ctx.fillStyle = 'rgba(255,255,255,0.92)';
    ctx.fillRect(x0 + 3, y0 + 4, tw + 6, 15);
    ctx.fillStyle = '#a12a1c';
    ctx.fillText(t, x0 + 6, y0 + 6);
    ctx.restore();
  }

  function screen(ctx, st) {
    var sx = screenX(st);
    ctx.save();
    ctx.fillStyle = '#15171a';
    ctx.fillRect(sx, FL.y0, SCR.w, FL.y1 - FL.y0);
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(screenStrip(st), 0, 0, 1, FL.y1 - FL.y0,
      sx, FL.y0, SCR.w, FL.y1 - FL.y0);
    ctx.imageSmoothingEnabled = true;
    ctx.strokeStyle = '#8a949e'; ctx.lineWidth = 1.2;
    ctx.strokeRect(sx + 0.5, FL.y0 + 0.5, SCR.w, FL.y1 - FL.y0);
    ctx.font = D.font(11, true);
    ctx.fillStyle = '#7a6a48';
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText('スクリーン', sx + SCR.w / 2, FL.y1 + 6);
    // 格子からの距離（この図は縮尺どおりなので、本当の長さが出せる）
    ctx.font = D.font(11);
    var dnm = (sx - FL.gx) * nmPerPx(st);
    var dtxt = (dnm < 1e6) ? ((dnm / 1000).toFixed(1) + ' μm') : ((dnm / 1e6).toFixed(2) + ' mm');
    D.dimLine(ctx, D.vec(FL.gx, FL.y1 - 6), D.vec(sx, FL.y1 - 6),
      '格子からスクリーンまで ' + dtxt, '#6f6754', 12);
    ctx.restore();
    // スクリーンの大きさの概算は図の中には描かない（欄外の #screen-note に出す）
    // スクリーンのすぐ右に、光の強度分布のグラフを添える
    intensityGraph(ctx, st, sx);
    // ---- 左右に動かすつまみ ----
    var hx = sx + SCR.w / 2, hy = FL.y0 - 13;
    var txt = '◀ スクリーンの位置 ▶';
    ctx.save();
    ctx.font = D.font(11, true);
    var w = ctx.measureText(txt).width + 18;
    D.roundRect(ctx, hx - w / 2, hy - 11, w, 22, 8);
    ctx.fillStyle = st.hoverBtn === 'scrx' ? '#eaf1fa' : 'rgba(255,255,255,0.95)';
    ctx.fill();
    ctx.strokeStyle = '#1663b5'; ctx.lineWidth = 1.4; ctx.stroke();
    ctx.fillStyle = '#1a4e86';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(txt, hx, hy + 1);
    ctx.restore();
    D.addHit(hx - w / 2, hy - 13, w, 26, 'scrx');
  }

  /* ---------- 強めあいの線・弱めあいの線 ----------
   * 平行光線として考えると、強めあうのは d sinθ ＝ mλ の向き、
   * 隣りあう波がちょうど逆になるのは d sinθ ＝ (m+1/2)λ の向き。
   * どちらも格子の中心からのまっすぐな線になる。
   */
  var C_MAX = '#0d7a3f', C_MIN = '#8b3fa8';

  /** sinθ ＝ s の向きの線の、名ふだを置く点（線の 7 割あたり） */
  function rayTip(st, s) {
    var u = D.vec(Math.sqrt(1 - s * s), -s);
    var t = (screenX(st) - FL.gx) / u.x;
    if (u.y < -1e-9) t = Math.min(t, (FL.cy - FL.y0) / -u.y);
    return D.vec(FL.gx + u.x * t * 0.72, FL.cy + u.y * t * 0.72);
  }

  /** 経路差が q λ になる向きへ、格子の中心から線を引く */
  function ray(ctx, st, q, color, dash, width) {
    var s = q * st.lambda / st.d;
    if (!(s < 1)) return null;
    var u = D.vec(Math.sqrt(1 - s * s), -s);     // 上向き
    var t = (screenX(st) - FL.gx) / u.x;
    if (u.y < -1e-9) t = Math.min(t, (FL.cy - FL.y0) / -u.y);
    ctx.save();
    ctx.strokeStyle = color; ctx.lineWidth = width; ctx.lineCap = 'round';
    if (dash) ctx.setLineDash(dash);
    var sgn;
    for (sgn = -1; sgn <= 1; sgn += 2) {
      ctx.beginPath();
      ctx.moveTo(FL.gx, FL.cy);
      ctx.lineTo(FL.gx + u.x * t, FL.cy + sgn * u.y * t);
      ctx.stroke();
    }
    ctx.restore();
    return true;
  }

  function strongWeakLines(ctx, st) {
    var m;
    /* 弱めあいの線 ＝ 隣りあう 2 本がちょうど逆になる向き d sinθ ＝ (m+1/2)λ。
       これがそのまま「暗線」になるのは N′ ＝ 2（＝ ヤングの実験）のときだけ。
       N′ が大きいと、明線以外はすべて暗くなる。 */
    if (st.showMinima) {
      for (m = 0; m < 40; m++) if (!ray(ctx, st, m + 0.5, C_MIN, [7, 5], 1.4)) break;
    }
    if (!st.showMaxima) return;
    for (m = 0; m < 40; m++) if (!ray(ctx, st, m, C_MAX, null, 2.2)) break;
  }

  /** 次数の名ふだ。波の上に来るように、いちばん最後に描く */
  function orderLabels(ctx, st) {
    if (!st.showMaxima) return;
    var m, end;
    ctx.save();
    ctx.font = D.font(11, true);
    for (m = 0; m < 40; m++) {
      var sT = m * st.lambda / st.d;
      if (!(sT < 1)) break;
      end = rayTip(st, sT);
      var txt = 'm = ' + m;
      var w = ctx.measureText(txt).width;
      var lx = P.clamp(end.x - w / 2, FL.gx + 20, screenX(st) - w - 18);
      var ly = P.clamp(end.y - 14, FL.y0 + 12, FL.y1 - 12);
      if (m === 0) ly = FL.cy - 15;
      D.roundRect(ctx, lx - 5, ly - 9, w + 10, 18, 5);
      ctx.fillStyle = 'rgba(255,255,255,0.9)'; ctx.fill();
      ctx.strokeStyle = C_MAX; ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = C_MAX;
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText(txt, lx, ly + 1);
    }
    ctx.restore();
  }

  /** 図の中の凡例 */
  function legend(ctx, st) {
    var x = FL.x0 + 12, y = FL.y1 - 26;
    var items = [];
    if (st.showMaxima) items.push(['強めあいの線　d sinθ ＝ mλ', C_MAX, 0]);
    if (st.showMinima) {
      items.push(['弱めあいの線　d sinθ ＝ (m+½)λ', C_MIN, 1]);
      items.push(['　（となりの 2 本が逆になる向き。ここが暗線に', '#5b6672', 2]);
      items.push(['　なるのは N′ ＝ 2 ＝ ヤングの実験のときだけ）', '#5b6672', 2]);
    }
    if (st.showMaxima) items.push(['N′ が大きいと、強めあいの線の上以外はすべて暗い', '#5b6672', 2]);
    if (!items.length) return;
    ctx.save();
    ctx.font = D.font(11, true);
    var w = 0, i;
    for (i = 0; i < items.length; i++) w = Math.max(w, ctx.measureText(items[i][0]).width);
    D.roundRect(ctx, x, y - items.length * 18 + 4, w + 52, items.length * 18 + 8, 6);
    ctx.fillStyle = 'rgba(255,255,255,0.86)'; ctx.fill();
    ctx.strokeStyle = '#c9d2da'; ctx.lineWidth = 1; ctx.stroke();
    for (i = 0; i < items.length; i++) {
      var yy = y - (items.length - 1 - i) * 18 - 4;
      if (items[i][2] !== 2) {
        ctx.strokeStyle = items[i][1]; ctx.lineWidth = items[i][2] ? 1.4 : 2.2;
        ctx.setLineDash(items[i][2] ? [7, 5] : []);
        ctx.beginPath(); ctx.moveTo(x + 10, yy); ctx.lineTo(x + 40, yy); ctx.stroke();
        ctx.setLineDash([]);
      }
      ctx.fillStyle = items[i][1];
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText(items[i][0], x + 48, yy + 1);
    }
    ctx.restore();
  }

  /* ---------- 点 P（スクリーンの上だけを動く） ---------- */
  function pointAt(st) {
    // はじめは 1 次の「強めあいの線」の上に置く
    var y0 = yOfRatio(st, 1);
    if (y0 === null || y0 < FL.y0 + 8) y0 = FL.cy - 120;
    var y = (st.fy === undefined || st.fy === null) ? y0 : st.fy;
    return D.vec(screenX(st), P.clamp(y, FL.y0 + 8, FL.y1 - 8));
  }

  /** 各スリットから P へ向かう光（平行とみなせるので、向きはみな同じ） */
  function pointWaves(ctx, st, p) {
    var wt = 2 * Math.PI * (P.V_NM_PER_S / st.lambda) * (st.t || 0);
    var lamPx = st.lambda * SP / st.d;
    var k = 2 * Math.PI / lamPx;
    ctx.save();
    ctx.beginPath();
    ctx.rect(FL.gx, FL.y0, screenX(st) - FL.gx, FL.y1 - FL.y0);
    ctx.clip();
    for (var i = 0; i < NS; i++) {
      var from = D.vec(FL.gx + 2, slitY(i));
      var dx = p.x - from.x, dy = p.y - from.y;
      var Lp = Math.hypot(dx, dy);
      var ux = dx / Lp, uy = dy / Lp, nx = -uy, ny = ux;
      ctx.strokeStyle = 'rgba(20,30,45,0.55)'; ctx.lineWidth = 1.1;
      ctx.lineJoin = 'round';
      ctx.beginPath();
      var steps = Math.max(40, Math.round(Lp / 1.5));
      for (var s = 0; s <= steps; s++) {
        var e = Lp * s / steps;
        var u = Math.sin(k * e - wt) * 4;
        var x = from.x + ux * e + nx * u;
        var y = from.y + uy * e + ny * u;
        if (s === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
    ctx.restore();
    // 点 P（スクリーンの面の上）
    ctx.save();
    ctx.beginPath(); ctx.arc(p.x + SCR.w / 2, p.y, 7, 0, Math.PI * 2);
    ctx.fillStyle = '#ffffff'; ctx.fill();
    ctx.strokeStyle = '#d0342c'; ctx.lineWidth = 2.4; ctx.stroke();
    ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    ctx.font = D.font(12, true);
    var tag = 'P（↑↓ ドラッグ）';
    var tw = ctx.measureText(tag).width;
    D.roundRect(ctx, p.x - 12 - tw - 8, p.y - 11, tw + 16, 22, 6);
    ctx.fillStyle = 'rgba(255,255,255,0.92)'; ctx.fill();
    ctx.strokeStyle = '#d0342c'; ctx.lineWidth = 1.2; ctx.stroke();
    ctx.fillStyle = '#d0342c';
    ctx.fillText(tag, p.x - 12, p.y + 1);
    ctx.restore();
  }

  /* ---------- 右わき：P に届く波をたてに並べる ---------- */
  function wavesPanel(ctx, st, p) {
    var x0 = PN.x0, x1 = PN.x1;
    var wx0 = x0 + 66, wx1 = x1 - 14;
    var wt = 2 * Math.PI * (P.V_NM_PER_S / st.lambda) * (st.t || 0);
    var delta = deltaAt(st, p.y);                  // 隣りあう波のずれ [nm]
    var phi = 2 * Math.PI * delta / st.lambda;     // 位相のずれ [rad]
    var N = st.N, nShow = Math.min(NSHOW, N);
    var i, j;
    var top = PN.y0 + 42, gap = 23, ampR = 9;
    var sumCy = 448, full = 72, unit = full;       // 合成波は「そろったとき 1」に正規化

    ctx.save();
    D.roundRect(ctx, x0, PN.y0, x1 - x0, PN.y1 - PN.y0, 10);
    ctx.fillStyle = '#fbfcfe'; ctx.fill();
    ctx.strokeStyle = '#c9d2da'; ctx.lineWidth = 1.3; ctx.stroke();

    ctx.font = D.font(12.5, true);
    ctx.fillStyle = '#1a4e86';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText('点 P に届く波（隣りあう波のずれ ＝ d sinθ）', x0 + 14, PN.y0 + 16);

    // ---- 各スリットからの波（10 本まで） ----
    var steps = 180;
    for (i = 0; i < nShow; i++) {
      var rowY = top + i * gap;
      ctx.strokeStyle = 'rgba(170,170,178,0.45)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(wx0, rowY); ctx.lineTo(wx1, rowY); ctx.stroke();
      ctx.strokeStyle = COL.ray; ctx.lineWidth = 1.5; ctx.lineJoin = 'round';
      ctx.beginPath();
      for (j = 0; j <= steps; j++) {
        var e = (wx1 - wx0) * j / steps;
        var u = Math.sin(2 * Math.PI * e / PN.lam + i * phi - wt);
        if (j === 0) ctx.moveTo(wx0 + e, rowY - u * ampR);
        else ctx.lineTo(wx0 + e, rowY - u * ampR);
      }
      ctx.stroke();
      ctx.font = D.font(10);
      ctx.fillStyle = '#5b6672';
      ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
      ctx.fillText((i + 1) + ' 本め', wx0 - 8, rowY);
    }
    var lastY = top + (nShow - 1) * gap;
    ctx.font = D.font(11);
    ctx.fillStyle = '#6f6754';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText(N > NSHOW
      ? '…このあと ' + (N - NSHOW) + ' 本、同じずれで続きます（ぜんぶで ' + N + ' 本）'
      : 'ぜんぶで ' + N + ' 本', wx0, lastY + 13);

    // ---- 合成波（N 本ぜんぶ） ----
    var sy0 = 318;
    ctx.strokeStyle = '#e6e9ee'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(x0 + 8, sy0); ctx.lineTo(x1 - 8, sy0); ctx.stroke();

    ctx.font = D.font(11.5, true);
    ctx.fillStyle = '#5a3a7a';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText('N′ ＝ ' + N + ' 本ぜんぶ足すと（合成波）', x0 + 14, sy0 + 16);

    // 「全部そろったときの振幅」の目安
    ctx.strokeStyle = 'rgba(120,128,136,0.55)'; ctx.lineWidth = 1;
    ctx.setLineDash([5, 4]);
    ctx.beginPath();
    ctx.moveTo(wx0, sumCy - full); ctx.lineTo(wx1, sumCy - full);
    ctx.moveTo(wx0, sumCy + full); ctx.lineTo(wx1, sumCy + full);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.strokeStyle = 'rgba(170,170,178,0.55)';
    ctx.beginPath(); ctx.moveTo(wx0, sumCy); ctx.lineTo(wx1, sumCy); ctx.stroke();

    ctx.font = D.font(10);
    ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    var gl = '全部そろったときの振幅（' + N + ' 本ぶん）';
    var glw = ctx.measureText(gl).width;
    ctx.fillStyle = '#fbfcfe';
    ctx.fillRect(wx1 - glw - 6, sumCy - full - 8, glw + 8, 16);
    ctx.fillStyle = '#6f6754';
    ctx.fillText(gl, wx1 - 2, sumCy - full);

    /* Σ_{j=0}^{N-1} sin(ψ + jφ) ＝ [sin(Nφ/2)/sin(φ/2)]·sin(ψ + (N−1)φ/2)
       （N が 1000 でも 1 回で出せるので軽い） */
    var half = phi / 2, sh = Math.sin(half);
    var env = (Math.abs(sh) < 1e-12) ? N : Math.sin(N * half) / sh;
    ctx.strokeStyle = COL.sum; ctx.lineWidth = 2.4; ctx.lineJoin = 'round';
    ctx.beginPath();
    for (j = 0; j <= steps; j++) {
      var e2 = (wx1 - wx0) * j / steps;
      var psi = 2 * Math.PI * e2 / PN.lam - wt;
      var v = env * Math.sin(psi + (N - 1) * half) / N;   // そろったとき ±1
      if (j === 0) ctx.moveTo(wx0 + e2, sumCy - v * unit);
      else ctx.lineTo(wx0 + e2, sumCy - v * unit);
    }
    ctx.stroke();

    // ---- 数値 ----
    var frac = ampFrac(N, delta, st.lambda);
    var kind = frac > 0.7 ? '強めあう' : (frac < 0.1 ? 'ほぼ完全に打ち消しあう' : 'その中間');
    var kc = frac > 0.7 ? '#1b6b34' : (frac < 0.1 ? '#a12a1c' : '#8a6d00');
    var ty = 544;
    ctx.font = D.font(11.5);
    ctx.fillStyle = '#5b6672';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText('合成波の振幅（そろったときを 1 とすると）', x0 + 14, ty);
    ctx.font = D.font(17, true);
    ctx.fillStyle = kc;
    ctx.fillText(frac.toFixed(4) + '　→　' + kind, x0 + 14, ty + 27);
    ctx.font = D.font(11);
    ctx.fillStyle = '#6f6754';
    ctx.textBaseline = 'bottom';
    ctx.fillText('※ この枠の中だけ、波長を見やすく拡大しています。', x0 + 14, PN.y1 - 24);
    ctx.fillText('　 波どうしのずれの割合は本当の値です。', x0 + 14, PN.y1 - 9);
    ctx.restore();
  }

  /* ---------- 情報カード ---------- */
  function infoCard(ctx, st, lines, title, color) {
    var x = 10, y = 62, w = FL.x0 - 26;
    ctx.save();
    ctx.font = D.font(11.5);
    var rows = 0, q;
    for (q = 0; q < lines.length; q++) rows += wrap(ctx, lines[q], w - 26).length;
    var h = 20 + rows * 15 + lines.length * 5;
    D.roundRect(ctx, x, y, w, h, 8);
    ctx.fillStyle = '#ffffff'; ctx.fill();
    ctx.strokeStyle = color; ctx.lineWidth = 1.4; ctx.stroke();
    ctx.font = D.font(11.5, true);
    var tw = ctx.measureText(title).width + 18;
    D.roundRect(ctx, x + 12, y - 10, tw, 20, 10);
    ctx.fillStyle = color; ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(title, x + 21, y + 1);
    ctx.font = D.font(11.5);
    ctx.fillStyle = '#28405c';
    ctx.textBaseline = 'top';
    var yy = y + 12;
    for (var i = 0; i < lines.length; i++) {
      var parts = wrap(ctx, lines[i], w - 26);
      for (var j = 0; j < parts.length; j++) { ctx.fillText(parts[j], x + 13, yy); yy += 15; }
      yy += 5;
    }
    ctx.restore();
  }

  /** 幅に収まるように、日本語のテキストを折り返す */
  function wrap(ctx, s, maxw) {
    var out = [], line = '';
    for (var i = 0; i < s.length; i++) {
      var t = line + s.charAt(i);
      if (ctx.measureText(t).width > maxw && line) { out.push(line); line = s.charAt(i); }
      else line = t;
    }
    if (line) out.push(line);
    return out;
  }

  function title(ctx, t, col, bg, edge) {
    ctx.save();
    ctx.font = D.font(13.5, true);
    var w = ctx.measureText(t).width + 26;
    D.roundRect(ctx, 12, 10, w, 28, 8);
    ctx.fillStyle = bg; ctx.fill();
    ctx.strokeStyle = edge; ctx.lineWidth = 1.6; ctx.stroke();
    ctx.fillStyle = col;
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(t, 25, 25);
    ctx.restore();
  }

  /* ================= 本体 ================= */
  function render(ctx, st, sol, sc) {
    NS = drawnCount(st);
    ctx.save();
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, L.W, L.H);
    ctx.restore();

    drawSnapshot(ctx, st);
    ctx.save();
    ctx.strokeStyle = '#c9d2da'; ctx.lineWidth = 1;
    ctx.strokeRect(FL.x0 + 0.5, FL.y0 + 0.5, screenX(st) - FL.x0, FL.y1 - FL.y0);
    ctx.restore();
    strongWeakLines(ctx, st);
    grating(ctx, st);
    screen(ctx, st);
    var p = pointAt(st);
    pointWaves(ctx, st, p);
    orderLabels(ctx, st);
    legend(ctx, st);
    wavesPanel(ctx, st, p);

    var npx = nmPerPx(st);
    var delta = deltaAt(st, p.y);
    var frac = ampFrac(st.N, delta, st.lambda);
    var sinT = sinThetaAt(st, p.y);
    infoCard(ctx, st, [
      'P の向き　sinθ ＝ ' + sinT.toFixed(3),
      '隣りあう波のずれ',
      '　d sinθ ＝ ' + Math.round(Math.abs(delta)) + ' nm',
      '　　　　　＝ ' + D.about(Math.abs(delta) / st.lambda) + ' λ',
      'N′ ＝ ' + st.N + ' 本の合成',
      '　' + frac.toFixed(4) + '　'
        + (frac > 0.7 ? '強めあう' : (frac < 0.1 ? 'ほぼ 0' : 'その中間')),
      'スクリーンの上で P を上下にドラッグ。N′ を大きくすると、明線以外は 0 に近づきます。'
    ], '点 P での重ね合わせ', '#1663b5');

    // 見出しはタブの名前と同じにする（名前が 2 つあると別のものに見えるため）
    title(ctx, '補足：多数の格子からの波がどう重なり合うか', '#1a4e86', '#eef4fb', '#1663b5');

    ctx.save();
    ctx.font = D.font(11);
    ctx.fillStyle = '#6f6754';
    ctx.textAlign = 'right'; ctx.textBaseline = 'top';
    ctx.fillText('左の図は、図に描いた ' + NS + ' 本ぶんを縮尺どおりに足したもの（1 px ＝ '
      + npx.toFixed(0) + ' nm）。数の計算は平行光線として N′ ＝ ' + st.N + ' 本で。',
      PN.x0 - 28, FL.y1 + 22);
    ctx.restore();
  }

  /** スクリーンの上（P をつかめる範囲）か */
  function inField(st, x, y) {
    var sx = screenX(st);
    return x > sx - 26 && x < sx + SCR.w + 26 && y > FL.y0 && y < FL.y1;
  }

  /* 点 P は、なめらかにではなく「経路差の刻み」で動かす。
     こうすると強めあいの位置（λ の整数倍）にぴったり止められる。 */
  var Q_STEP = 0.05;
  function setPoint(st, x, y) {
    var yy = P.clamp(y, FL.y0 + 8, FL.y1 - 8);
    var q = deltaAt(st, yy) / st.lambda;
    q = st.onlyBright ? Math.round(q) : Math.round(q / Q_STEP) * Q_STEP;
    var ny = yOfRatio(st, q);
    st.fy = (ny === null) ? yy : P.clamp(ny, FL.y0 + 8, FL.y1 - 8);
  }

  /** 「明線の位置のみ選ぶ」…いちばん近い強めあいの線の上に寄せる */
  function snap(st) {
    setPoint(st, 0, pointAt(st).y);
  }

  /** スクリーンを左右に動かす */
  function moveScreen(st, x) {
    st.scrX = P.clamp(x - FL.gx, SCR.min, SCR.max);
    if (st.fy !== null && st.fy !== undefined) setPoint(st, 0, st.fy);
  }

  return {
    render: render, FL: FL, SCR: SCR, PN: PN, NSHOW: NSHOW, drawnCount: drawnCount,
    inField: inField, setPoint: setPoint, snap: snap, pointAt: pointAt,
    moveScreen: moveScreen, screenX: screenX,
    sinThetaAt: sinThetaAt, deltaAt: deltaAt, ampFrac: ampFrac,
    yOfRatio: yOfRatio, nmPerPx: nmPerPx
  };
})();
