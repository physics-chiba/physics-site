/* ===== 65_mode_deltax.js ===== */
/* ③ 明線間隔 Δx を導く（ステップ④の続き）
 *   モード①（光路差の位置と式の原理）とほぼ同じレイアウトだが、
 *   「見る方向を選ぶ」欄は無く、d・λ・L はこのモード専用の値に固定する。
 *   m 次と (m+1) 次、2 つの明線の位置 x を同時にスクリーンへ示し、
 *   ステップ③の式 x_m ≒ mλL/d を引き算するだけで Δx ＝ λL/d が出ることを見せる。
 *   波は①と同じく止めたまま（アニメーションはしない）。
 */
window.DG = window.DG || {};
DG.modeDeltax = (function () {
  'use strict';
  var D = DG.draw, P = DG.phys;
  var L = D.L;

  /* このモードだけの固定値（装置の設定は変えられない） */
  var DX_D = 3340;     // 格子定数 d [nm]
  var DX_LAM = 380;    // 波長 λ [nm]
  var DX_L = 0.60;     // スクリーンまでの距離 L [m]
  var DX_M = 3;         // 見せる次数（m と m+1）
  var HALF_M = 0.40;   // このモードだけ、x_m と x_(m+1) がはっきり離れて見えるように少し寄せる

  var SUB_M = 'ₘ';               // ₘ
  var SUB_M1 = 'ₘ₊₁';  // ₘ₊₁

  function fixedSol() {
    return P.solve({ lambda: DX_LAM, d: DX_D, L: DX_L, N: 6, m: DX_M, sinT: 0, onlyBright: true });
  }
  function findOrder(sol, m) {
    for (var i = 0; i < sol.orders.length; i++) {
      if (sol.orders[i].m === m) return sol.orders[i];
    }
    return null;
  }

  /** ①と見た目をそろえた、格子まわりのミニ scene（このモード専用の縮尺） */
  function buildDxScene() {
    var slits = [];
    var n = L.NSLIT, sp = L.SLIT_SP;
    for (var i = 0; i < n; i++) slits.push(D.vec(L.GX, L.CY + (i - (n - 1) / 2) * sp));
    return { gx: L.GX, slits: slits, halfM: HALF_M, ppm: L.SH / HALF_M, P1: D.vec(L.SX, L.CY) };
  }

  function triFill(ctx, a, b, c, fill) {
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.lineTo(c.x, c.y); ctx.closePath();
    ctx.fillStyle = fill; ctx.fill();
    ctx.restore();
  }

  function titleBox(ctx) {
    var t = '③ 明線間隔 Δx を導く（ステップ④）';
    ctx.save();
    ctx.font = D.font(13.5, true);
    var w = ctx.measureText(t).width + 26;
    D.roundRect(ctx, 12, 10, w, 28, 8);
    ctx.fillStyle = '#eef9f1'; ctx.fill();
    ctx.strokeStyle = '#0d7a3f'; ctx.lineWidth = 1.6; ctx.stroke();
    ctx.fillStyle = '#0d5c30';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(t, 25, 25);
    ctx.restore();
  }

  /** 左パネル：③までのふりかえり（かんたんな式だけ） */
  function leftRecap(ctx) {
    ctx.save();
    ctx.font = D.font(12.5, true);
    ctx.fillStyle = '#3a4550';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    var lines = [
      ['① 経路差 ＝ d sinθ', false],
      ['② 明線の条件：d sinθ ＝ mλ', false],
      ['③ x' + SUB_M + ' ≒ mλL / d', false],
      ['　（θ が小さいとき）', false]
    ];
    var y = 56;
    for (var i = 0; i < lines.length; i++) {
      ctx.font = D.font(lines[i][1] ? 13.5 : 12.5, true);
      ctx.fillText(lines[i][0], 24, y);
      y += 24;
    }
    y += 10;
    ctx.font = D.font(12.5);
    ctx.fillStyle = '#5b6672';
    var note = [
      'この式の m を (m ＋ 1) に変えて',
      '引き算すると、明線と明線の',
      '間隔 Δx が求められます。',
      '（右の図と、下の説明を見てください）'
    ];
    for (var j = 0; j < note.length; j++) { ctx.fillText(note[j], 24, y); y += 19; }

    y += 14;
    D.roundRect(ctx, 16, y, 260, 66, 8);
    ctx.fillStyle = '#fff8e6'; ctx.fill();
    ctx.strokeStyle = '#e0a800'; ctx.lineWidth = 1.4; ctx.stroke();
    ctx.fillStyle = '#8a5300';
    ctx.font = D.font(11.5, true);
    ctx.fillText('この モードの装置の設定（固定）', 26, y + 10);
    ctx.font = D.font(12);
    ctx.fillText('d ＝ ' + (DX_D / 1000).toFixed(2) + ' μm', 26, y + 30);
    ctx.fillText('λ ＝ ' + DX_LAM + ' nm　　L ＝ ' + DX_L.toFixed(2) + ' m', 26, y + 48);
    ctx.restore();
  }

  function summaryBox(ctx) {
    var x = 20, y = 548, w = L.W - 40;
    // 式は KaTeX できれいに描く（できあがるまでの一瞬だけ、代わりに文字を出す）
    var tex = 'x_{m+1}-x_m \\fallingdotseq \\dfrac{(m+1)\\lambda L}{d}-\\dfrac{m\\lambda L}{d} = \\dfrac{\\lambda L}{d}';
    var eq = D.texImage(tex, { size: 17, color: '#0d5c30', display: true });
    var eqH = eq.img ? eq.h : 24;
    var h = 30 + eqH + 30;
    ctx.save();
    D.roundRect(ctx, x, y, w, h, 10);
    ctx.fillStyle = '#eef9f1'; ctx.fill();
    ctx.strokeStyle = '#0d7a3f'; ctx.lineWidth = 1.6; ctx.stroke();
    ctx.fillStyle = '#0d5c30';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.font = D.font(13, true);
    ctx.fillText('ステップ③の式で m → m ＋ 1 として引き算すると：', x + 18, y + 12);
    if (eq.img) {
      // D.drawTex を通すと、細い線がつぶれないよう半ピクセルずらしの重ね描きになる
      D.drawTex(ctx, tex, x + 16, y + 28, { size: 17, color: '#0d5c30', display: true });
    } else {
      ctx.font = D.font(16, true);
      ctx.fillText('x' + SUB_M1 + ' － x' + SUB_M + ' ≒ (m＋1)λL/d － mλL/d ＝ λL/d', x + 18, y + 34);
    }
    ctx.font = D.font(12);
    ctx.fillStyle = '#3a4550';
    ctx.fillText('→ m が消えるので、Δx はどの隣りあう明線どうしでも同じ値になります（θ が小さいときに限る）。', x + 18, y + 28 + eqH + 6);
    ctx.restore();
  }

  /** スクリーンの上に、実際の明線らしい短い明るい線を引く（O からここまでは「…」で省略） */
  function brightTick(ctx, scz, y, color) {
    ctx.save();
    ctx.shadowColor = color; ctx.shadowBlur = 8;
    ctx.strokeStyle = color; ctx.lineWidth = 4; ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(L.SX + 3, y); ctx.lineTo(L.SX + L.SCR_W - 3, y);
    ctx.stroke();
    ctx.restore();
  }

  /** KaTeX の式を、白い下敷きの上に描く（吹き出しの枠は使わない） */
  function texLabel(ctx, tex, color, x, yc) {
    var opt = { size: 13.5, color: color };
    var e = D.texImage(tex, opt);
    var iw = e.img ? e.w : 84, ih = e.img ? e.h : 20;
    // 右はしから canvas の外へはみ出さないよう、必要なら左へずらす
    var bx = Math.min(x, L.W - iw - 6), by = yc - ih / 2;
    ctx.save();
    ctx.fillStyle = 'rgba(255,255,255,0.92)';
    ctx.fillRect(bx - 4, by - 3, iw + 8, ih + 6);
    ctx.restore();
    if (e.img) {
      D.drawTex(ctx, tex, bx, by, opt);
    } else {
      // 画像がまだ読み込まれていない最初のフレームだけの代替表示
      ctx.save();
      ctx.font = D.font(12.5, true);
      ctx.fillStyle = color;
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText(tex.indexOf('m+1') >= 0 ? 'xₘ₊₁ ≒ (m+1)λL/d' : 'xₘ ≒ mλL/d', bx, yc);
      ctx.restore();
    }
  }

  /**
   * スクリーンの右側に、O からの高さ xₘ・xₘ₊₁ を「寸法の矢印」で明示する。
   * ・Pₘ・Pₘ₊₁・O の高さから右へ黒い破線をのばす
   * ・O の高さから Pₘ までを青の矢印（xₘ）、Pₘ₊₁ までを橙の矢印（xₘ₊₁）
   * ・それぞれの式は本物の KaTeX で、矢印と重ならない位置に置く
   */
  function xmDims(ctx, Pm, Pm1) {
    var xr = L.SX + L.SCR_W;          // スクリーンの右はし
    var xEnd = L.W - 12;
    var ym = Pm.y, ym1 = Pm1.y, yO = L.CY;
    ctx.save();
    ctx.lineWidth = 1.2;
    ctx.setLineDash([6, 4]);
    ctx.strokeStyle = '#3a4550';
    ctx.beginPath(); ctx.moveTo(xr + 2, ym); ctx.lineTo(xEnd, ym); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(xr + 2, ym1); ctx.lineTo(xEnd, ym1); ctx.stroke();
    ctx.strokeStyle = '#9aa0a6';
    ctx.beginPath(); ctx.moveTo(xr + 2, yO); ctx.lineTo(xEnd, yO); ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();

    function upArrow(x, yTop, color) {
      ctx.save();
      ctx.strokeStyle = color; ctx.fillStyle = color; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(x, yO - 1); ctx.lineTo(x, yTop + 10); ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(x, yTop + 1);
      ctx.lineTo(x - 4.5, yTop + 11);
      ctx.lineTo(x + 4.5, yTop + 11);
      ctx.closePath(); ctx.fill();
      ctx.restore();
    }
    var xA = xr + 34;                 // 青の矢印（xₘ）
    var xB = xr + 56;                 // 橙の矢印（xₘ₊₁）
    upArrow(xA, ym, '#1663b5');
    upArrow(xB, ym1, '#a15200');

    // Δx：2 本の破線（Pₘ₊₁ の高さと Pₘ の高さ）のあいだに、緑の両矢印で明示する。
    // 青の矢印（O→Pₘ）の延長線上に置くと「xₘ の続きの区間」だと読み取りやすい。
    ctx.save();
    ctx.strokeStyle = '#0d7a3f'; ctx.fillStyle = '#0d7a3f'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(xA, ym - 9); ctx.lineTo(xA, ym1 + 9); ctx.stroke();
    function dHead(y, dir) {
      ctx.beginPath();
      ctx.moveTo(xA, y);
      ctx.lineTo(xA - 4.5, y + dir * 10);
      ctx.lineTo(xA + 4.5, y + dir * 10);
      ctx.closePath(); ctx.fill();
    }
    dHead(ym1 + 1, 1);                // 上向きの矢じり（Pₘ₊₁ の破線へ）
    dHead(ym - 1, -1);                // 下向きの矢じり（Pₘ の破線へ）
    ctx.font = D.font(13, true);
    ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    var dxw = ctx.measureText('Δx').width;
    var dlx = xA - 8, dly = (ym + ym1) / 2;
    ctx.fillStyle = 'rgba(255,255,255,0.9)';
    ctx.fillRect(dlx - dxw - 4, dly - 9, dxw + 8, 18);
    ctx.fillStyle = '#0d7a3f';
    ctx.fillText('Δx', dlx, dly + 1);
    ctx.restore();

    // 式：橙は上の破線のさらに上、青は O と Pₘ のあいだの高さ（矢印の右どなり）
    texLabel(ctx, 'x_{m+1} \\fallingdotseq \\dfrac{(m+1)\\lambda L}{d}', '#a15200',
      xB + 16, ym1 - 28);
    texLabel(ctx, 'x_m \\fallingdotseq \\dfrac{m\\lambda L}{d}', '#1663b5',
      xB + 16, (yO + ym) / 2);
  }

  function render(ctx, st, sol) {
    D.panels(ctx);
    leftRecap(ctx);

    var scz = buildDxScene();
    if (DG.modePath && DG.modePath.incoming) DG.modePath.incoming(ctx, st, scz);
    D.gratingPlate(ctx, scz);
    D.screenBar(ctx, scz);

    var om = findOrder(sol, DX_M), om1 = findOrder(sol, DX_M + 1);
    if (!om || !om1) { titleBox(ctx); return; }

    var G = D.vec(L.GX, L.CY), O = D.vec(L.SX, L.CY);
    var ym = L.CY - om.x * scz.ppm, ym1 = L.CY - om1.x * scz.ppm;
    var Pm = D.vec(L.SX, ym), Pm1 = D.vec(L.SX, ym1);
    scz.P1 = D.vec(L.SX, (ym + ym1) / 2);
    D.screenRuler(ctx, scz);

    // G-O・G-Pm・G-Pm1 を引く（この直後に省略記号で「省いている」ことを示す）
    D.dimLine(ctx, G, O, '', '#5b6672', 24);
    D.line(ctx, G, Pm1, '#e07b18', 2.4);
    D.line(ctx, G, Pm, '#1663b5', 2.6);

    // ①②と同じく、L は d にくらべてけた違いに長いので、途中を省略していることを示す
    var yBreakTop = 44, yBreakBot = L.CY + L.SH + 36;
    D.breakMark(ctx, yBreakTop, yBreakBot);
    ctx.save();
    ctx.font = D.font(11);
    ctx.fillStyle = '#6b7580';
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText('L は d にくらべてけた違いに長いので', L.BREAK_X + 13, yBreakBot + 6);
    ctx.fillText('途中を省略しています', L.BREAK_X + 13, yBreakBot + 21);
    ctx.restore();

    // L の値（省略記号の左どなりに置く）
    ctx.save();
    ctx.font = D.font(12.5, true);
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    var lt = 'L ＝ ' + DX_L.toFixed(2) + ' m';
    var lw = ctx.measureText(lt).width;
    var lcx = (G.x + L.BREAK_X) / 2, lyy = L.CY + 24;
    ctx.fillStyle = 'rgba(255,255,255,0.92)';
    ctx.fillRect(lcx - lw / 2 - 5, lyy - 9, lw + 10, 18);
    ctx.fillStyle = '#5b6672';
    ctx.fillText(lt, lcx, lyy);
    ctx.restore();

    // 角の塗り・直角マークは省略記号のあと、上に重ねて描く（①のステップ③三角形と同じ順番）
    triFill(ctx, G, O, Pm1, 'rgba(224,123,24,0.10)');
    triFill(ctx, G, O, Pm, 'rgba(22,99,181,0.16)');
    D.rightAngle(ctx, O, D.vec(-1, 0), D.vec(0, -1), 12, '#5b6672');

    // スクリーンに写る範囲のすべての明線を描く（m ＝ 0, ±1, ±2, …。
    // 注目している m・m＋1 以外にも明線はある、ということが分かるように）
    for (var oi = 0; oi < sol.orders.length; oi++) {
      var ord = sol.orders[oi];
      if (Math.abs(ord.x) > HALF_M) continue;
      brightTick(ctx, scz, L.CY - ord.x * scz.ppm, '#d0342c');
    }
    brightTick(ctx, scz, ym, '#d0342c');
    brightTick(ctx, scz, ym1, '#d0342c');

    D.pointLabel(ctx, Pm, 'P' + SUB_M, -24, 0, '#1663b5');
    D.pointLabel(ctx, Pm1, 'P' + SUB_M1, -26, 0, '#a15200');
    D.pointLabel(ctx, O, 'O', -14, 15, '#3a4550');
    D.pointLabel(ctx, G, 'G', -6, -14, '#28405c');

    ctx.save();
    ctx.font = D.font(11.5, true);
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#1a4e86';
    ctx.fillText('m 次の明線', L.GX + 30, (G.y + Pm.y) / 2 - 10);
    ctx.fillStyle = '#a15200';
    ctx.fillText('(m ＋ 1) 次の明線', L.GX + 30, (G.y + Pm1.y) / 2 - 22);
    ctx.restore();

    // スクリーンの右側に、xm・xm+1 の高さを寸法の矢印＋KaTeX の式で明示する
    xmDims(ctx, Pm, Pm1);

    titleBox(ctx);
    summaryBox(ctx);
  }

  function updateNotes() {
    var sol = fixedSol();
    var om = findOrder(sol, DX_M), om1 = findOrder(sol, DX_M + 1);
    var el = document.getElementById('sv-deltax');
    if (!el || !om || !om1) return;
    var dxActual = om1.x - om.x;
    var dxApprox = DX_LAM * 1e-9 * DX_L / (DX_D * 1e-9);
    el.textContent = 'この図は d ＝ ' + (DX_D / 1000).toFixed(2) + ' μm、λ ＝ ' + DX_LAM + ' nm、L ＝ '
      + DX_L.toFixed(2) + ' m で、m ＝ ' + DX_M + ' と m ＋ 1 ＝ ' + (DX_M + 1) + ' の方向を比べています。'
      + '次数がこれくらい大きいと　θ ＝ ' + (om.theta / P.DEG).toFixed(1) + '°　θ ＝ '
      + (om1.theta / P.DEG).toFixed(1) + '°　と、あまり小さくありません。だから　実際の間隔 '
      + D.fmtCm(dxActual) + '　と　近似の λL/d ＝ ' + D.fmtCm(dxApprox) + '　は少しずれています'
      + '（m ＝ 0 と 1 のように小さい次数どうしなら、θ が小さいのでほとんどずれません）。';
  }

  return {
    render: render, updateNotes: updateNotes,
    DX_D: DX_D, DX_LAM: DX_LAM, DX_L: DX_L, DX_M: DX_M, HALF_M: HALF_M
  };
})();
