/* ===== 40_draw.js ===== */
/* canvas 共通描画部品：レイアウト定数・座標系の組み立て・図の部品
 * 書体は 1 つだけ。大きさと太さだけで区別する。
 */
window.DG = window.DG || {};
DG.draw = (function () {
  'use strict';
  var P = DG.phys;

  /* ---------- レイアウト定数 ----------
   * 図は横 1300 × 縦 700。下 160 px は「経路差をまっすぐ伸ばす」帯。
   *   左パネル（x 0〜300）   ：回折格子の拡大（隣りあう 2 本のスリットと経路差）
   *   右パネル（x 300〜1300）：全体（光源 → 回折格子 →〔省略〕→ スクリーン）
   *
   * 縦（スクリーン上の位置）は物理の縮尺どおり：SH px ＝ HALF_M メートル。
   * 横（格子〜スクリーンの距離 l）は d にくらべてけた違いに長いので、
   * 途中を省略記号で省いて一定の長さに描く。だから図の中の角の見かけは
   * ほんとうの θ ではない（ほんとうの θ は左の拡大図で示す）。
   */
  var L = {
    W: 1300, H: 700,
    BAND_Y: 540,        // 帯の上端（図の描画はここまで）
    DIV: 300,           // 左パネルと右パネルの境目
    CY: 262,            // 光軸の y
    GX: 560,            // 回折格子の x（固定）
    SX: 1090,           // スクリーンの x（固定）
    SCR_W: 30,          // スクリーンの面の幅 [px]（②はここに干渉パターンを描く）
    BREAK_X: 812,       // 省略記号の位置
    SH: 200,            // スクリーンの半分の高さ [px]
    HALF_M: 1.15,       // スクリーンの半分が表す長さ [m]（m = 4 まで写るように）
    STRIP_X0: 1128, STRIP_X1: 1174, // 干渉パターンの帯（②で使う）
    NSLIT: 6,           // 図に描くスリットの本数
    SLIT_SP: 12,        // 図の上のスリット間隔 [px]（実際の d ではない）
    PLATE_H: 161,       // 回折格子の板の高さ [px]
    SRC_X: 356,         // 光源の x
    // 左パネル（拡大図）
    LX: 118,            // 拡大図のスリット板の x
    LD: 104,            // 拡大図で d を何 px に描くか
    AMP: 11             // 波の振幅 [px]
  };
  L.PPM = L.SH / L.HALF_M;   // 縦の縮尺 [px / m]

  var COL = {
    ray: '#e8862a',        // 光線（波長に応じて少し色が変わる）
    rayDim: '#f0c48c',
    sum: '#7b3fa8',        // 合成波
    plate: '#cfe6f2',      // 回折格子（ガラス）
    plateEdge: '#5b93b5',
    screen: '#efe6d2',
    screenEdge: '#a89878',
    line: '#5a5a5a',
    guide: '#9aa0a6',
    geo: '#0f9d58',        // 経路差のハイライト
    ang: '#3d51a8',        // 角 θ
    hi: '#e0a800'
  };

  /* ---- 光線の色：基準のオレンジを、波長の色へ少しだけ寄せる ---- */
  var BASE_RAY = '#e8862a';
  var LAM_REF = 600;

  function hex2rgb(h) {
    return { r: parseInt(h.substr(1, 2), 16), g: parseInt(h.substr(3, 2), 16), b: parseInt(h.substr(5, 2), 16) };
  }
  function rgbHex(c) {
    function h(v) {
      var x = Math.round(P.clamp(v, 0, 255)).toString(16);
      return x.length < 2 ? '0' + x : x;
    }
    return '#' + h(c.r) + h(c.g) + h(c.b);
  }
  function shade(hex, k) {
    var c = hex2rgb(hex);
    return rgbHex({ r: c.r * k, g: c.g * k, b: c.b * k });
  }
  /** 明るさをそろえた波長の色（端の波長でも暗くならないように） */
  function pureColor(lambda) {
    var w = P.wavelengthToRGB(lambda);
    var m = Math.max(w.r, w.g, w.b) || 1;
    return { r: w.r * 255 / m, g: w.g * 255 / m, b: w.b * 255 / m };
  }
  /** λ = 600 nm でちょうど基準のオレンジ。そこからの色のずれぶんだけ寄せる */
  function setLightColor(lambda) {
    var base = hex2rgb(BASE_RAY);
    var cur = pureColor(lambda), ref = pureColor(LAM_REF);
    var k = 0.3;
    COL.ray = rgbHex({
      r: base.r + (cur.r - ref.r) * k,
      g: base.g + (cur.g - ref.g) * k,
      b: base.b + (cur.b - ref.b) * k
    });
    COL.rayDim = shade(COL.ray, 1.28);
  }

  /* ---------- 書体 ---------- */
  /* Windows の canvas では 游ゴシック（Yu Gothic）が細く・うすくにじんで読みづらい。
     読みやすさ優先で、Windows 10/11 標準の UD フォント（BIZ UDPゴシック）を最優先にし、
     無ければ Meiryo → Yu Gothic の順で使う（Mac はこれまでどおりヒラギノ）。 */
  var FONT = '"BIZ UDPGothic","Hiragino Kaku Gothic ProN",Meiryo,"Yu Gothic",sans-serif';
  /* canvas は 1300 px を 1200 px ほどに縮めて表示するので、字は大きめにする。
     教室のプロジェクタでも読めるように、少し強めに（1.10 → 1.24）。 */
  var FONT_K = 1.24;
  function font(px, bold) {
    return (bold ? 'bold ' : '') + (Math.round(px * FONT_K * 10) / 10) + 'px ' + FONT;
  }

  /* ---------- canvas の中に KaTeX の数式をきれいに描く ----------
   * KaTeX は本来 DOM に HTML を差しこんで描くものなので、canvas にそのままは描けない。
   * そこで、KaTeX の HTML を SVG の foreignObject に包んで画像化し、それを canvas に
   * drawImage する。KaTeX の CSS（フォントは base64 で埋めこみずみ＝外部通信なし）を
   * 同じ SVG の中に <style> でそのまま持ちこむので、オフラインのまま使える。
   * 画像の生成は非同期なので、初回は文字だけの代わりの表示にして、
   * できあがったら次の描画フレームから自動的に差しかわる（アニメーションループが毎フレーム呼ぶため）。
   */
  var texCache = {};
  var katexCssText = null;
  function texImage(tex, opt) {
    opt = opt || {};
    var key = tex + '|' + (opt.color || '') + '|' + (opt.size || '') + '|' + (opt.display ? 1 : 0);
    var entry = texCache[key];
    if (entry) return entry;
    entry = { img: null, w: 0, h: 0, loading: true, failed: false };
    texCache[key] = entry;
    try {
      if (typeof katex === 'undefined') { entry.loading = false; entry.failed = true; return entry; }
      if (katexCssText === null) {
        var st = document.getElementById('katex-css');
        katexCssText = st ? st.textContent : '';
      }
      var html = katex.renderToString(tex, { throwOnError: false, displayMode: !!opt.display });
      var fontSize = opt.size || 20;
      var color = opt.color || '#222';
      var probe = document.createElement('div');
      probe.style.cssText = 'position:absolute;left:-9999px;top:-9999px;font-size:' + fontSize
        + 'px;color:' + color + ';white-space:nowrap;line-height:1.15;';
      probe.innerHTML = html;
      document.body.appendChild(probe);
      var w = Math.ceil(probe.offsetWidth) + 6, h = Math.ceil(probe.offsetHeight) + 6;
      document.body.removeChild(probe);
      if (w < 2 || h < 2) { entry.loading = false; entry.failed = true; return entry; }
      // canvas は CSS で縮めて表示される（見た目の解像度が下がる）ので、
      // 「＋」のような細い線がつぶれないよう、実際より大きく（SS 倍）描いてから
      // drawImage で縮小する（縮小はブラウザがきれいに平均してくれる）。
      var SS = 3;
      var W = w * SS, H = h * SS, FS = fontSize * SS;
      var svgStr = '<svg xmlns="http://www.w3.org/2000/svg" width="' + W + '" height="' + H + '">'
        + '<foreignObject width="100%" height="100%"><div xmlns="http://www.w3.org/1999/xhtml" '
        + 'style="font-size:' + FS + 'px;color:' + color + ';line-height:1.15;display:inline-block;">'
        + '<style>' + katexCssText + '</style>' + html
        + '</div></foreignObject></svg>';
      var url = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgStr)));
      var img = new Image();
      img.onload = function () { entry.img = img; entry.w = w; entry.h = h; entry.loading = false; };
      img.onerror = function () { entry.loading = false; entry.failed = true; };
      img.src = url;
    } catch (e) { entry.loading = false; entry.failed = true; }
    return entry;
  }
  /** できていれば画像で、まだなら何も描かずに済ませる（呼び出し側でフォールバックの文字を用意する） */
  function drawTex(ctx, tex, x, y, opt) {
    var e = texImage(tex, opt);
    if (!e.img) return false;
    var s = (opt && opt.scale) || 1;
    ctx.save();
    ctx.imageSmoothingEnabled = true;
    if ('imageSmoothingQuality' in ctx) ctx.imageSmoothingQuality = 'high';
    // canvas 自体が CSS でさらに縮小表示される（1300px のバッファを画面幅へ）ため、
    // ここで 1 回だけ描くと、下つき文字の「＋」の縦棒のような 1px 級の線が
    // ブラウザの最終縮小でつぶれ、「−」に見えてしまうことがある。
    // 半ピクセルずらして 2 回重ね描きし、細い縦線を実質 1.5px に太らせておくと、
    // 最終縮小のあとも確実に残る（SS=3 のスーパーサンプリングだけでは足りなかった）。
    ctx.drawImage(e.img, x, y, e.w * s, e.h * s);
    ctx.drawImage(e.img, x + 0.5, y, e.w * s, e.h * s);
    ctx.restore();
    return true;
  }

  /* ---------- ベクトル小物 ---------- */
  function vec(x, y) { return { x: x, y: y }; }
  function add(a, b) { return vec(a.x + b.x, a.y + b.y); }
  function sub(a, b) { return vec(a.x - b.x, a.y - b.y); }
  function mul(a, k) { return vec(a.x * k, a.y * k); }
  function dot(a, b) { return a.x * b.x + a.y * b.y; }
  function len(a) { return Math.hypot(a.x, a.y); }
  function nrmOf(d) { return vec(-d.y, d.x); }
  function unit(a) { var l = len(a) || 1; return vec(a.x / l, a.y / l); }

  /* ---------- 座標系の組み立て ----------
   * ここが図のかなめ。
   *   ・スクリーンは「physical に決まった高さ」をもつ（半分 = SH px）
   *   ・格子〜スクリーンの距離は L [m] に比例して描く（DIST_MIN〜DIST_MAX で頭打ち）
   *   ・縦横の縮尺 ppm は同じ（＝図の中の角は本当の θ）
   * こうすると L を大きくしたとき、同じ角度の明線がスクリーン上で外へ広がる
   * ＝「L を大きくすると明線の間隔が広がる」が、そのまま図に出る。
   */
  function buildScene(st, sol) {
    var ppm = L.PPM;                            // 縦の縮尺（一定）
    var gx = L.GX, distPx = L.SX - L.GX;        // 横は一定（途中を省略して描く）
    var halfM = L.HALF_M;

    // 図に描くスリット（中央が光軸）
    var slits = [];
    var n = L.NSLIT, sp = L.SLIT_SP;
    for (var i = 0; i < n; i++) {
      slits.push(vec(gx, L.CY + (i - (n - 1) / 2) * sp));
    }

    // 見る方向（＝いま選んでいる方向）
    var theta = sol.theta;
    var dir = vec(Math.cos(theta), -Math.sin(theta));   // ほんとうの向き（左の拡大図で使う）
    var xPx = sol.x * ppm;                              // スクリーン上の位置 [px]
    var pOn = Math.abs(xPx) <= L.SH + 0.5;              // スクリーンに載っているか
    var pY = L.CY - P.clamp(xPx, -L.SH - 300, L.SH + 300);
    var P1 = vec(L.SX, pY);
    var O = vec(L.SX, L.CY);
    // 図の上での光線の向き（横を省略して描いているので、見かけの角はθとちがう）
    var dirDrawn = unit(sub(P1, vec(gx, L.CY)));

    /* ---- 左パネル（拡大図）---- */
    var lx = L.LX, dPix = L.LD;
    var s1 = vec(lx, L.CY - dPix / 2);   // 上のスリット（P に近い）
    var s2 = vec(lx, L.CY + dPix / 2);   // 下のスリット（P から遠い＝ d sinθ ぶん長い）
    var q = dot(sub(s1, s2), dir);       // = dPix sinθ
    var F = add(s2, mul(dir, q));        // s1 から s2 の光線へ下ろした垂線の足

    return {
      distPx: distPx, ppm: ppm, gx: gx, halfM: halfM,
      slits: slits, dir: dir, dirDrawn: dirDrawn, theta: theta,
      P1: P1, O: O, xPx: xPx, pOn: pOn,
      s1: s1, s2: s2, F: F, dPix: dPix, segPix: q
    };
  }

  /* ---------- 基本の図形 ---------- */
  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  function line(ctx, a, b, color, w, dash) {
    ctx.save();
    if (dash) ctx.setLineDash(dash);
    ctx.strokeStyle = color; ctx.lineWidth = w || 1.5; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
    ctx.restore();
  }
  function dashLine(ctx, a, b, color, dash, width) {
    line(ctx, a, b, color, width || 1.2, dash || [5, 4]);
  }

  function arrow(ctx, from, dir, length, color, width, headLen) {
    var to = add(from, mul(dir, length));
    ctx.save();
    ctx.strokeStyle = color; ctx.fillStyle = color;
    ctx.lineWidth = width || 2; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(from.x, from.y); ctx.lineTo(to.x, to.y); ctx.stroke();
    var h = headLen || 8, nn = nrmOf(dir);
    ctx.beginPath();
    ctx.moveTo(to.x, to.y);
    ctx.lineTo(to.x - dir.x * h + nn.x * h * 0.5, to.y - dir.y * h + nn.y * h * 0.5);
    ctx.lineTo(to.x - dir.x * h - nn.x * h * 0.5, to.y - dir.y * h - nn.y * h * 0.5);
    ctx.closePath(); ctx.fill();
    ctx.restore();
  }

  /** 寸法線（両端に矢じり＋まん中にラベル） */
  function dimLine(ctx, a, b, label, color, side) {
    var c = color || '#6b7580';
    var u = unit(sub(b, a));
    ctx.save();
    ctx.strokeStyle = c; ctx.fillStyle = c; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
    function head(p, d) {
      var nn = nrmOf(d);
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(p.x + d.x * 7 + nn.x * 3.2, p.y + d.y * 7 + nn.y * 3.2);
      ctx.lineTo(p.x + d.x * 7 - nn.x * 3.2, p.y + d.y * 7 - nn.y * 3.2);
      ctx.closePath(); ctx.fill();
    }
    head(a, u); head(b, mul(u, -1));
    if (label) {
      var m = mul(add(a, b), 0.5);
      var nn2 = nrmOf(u);
      var off = (side === undefined ? 11 : side);
      var lx = m.x + nn2.x * off, ly = m.y + nn2.y * off;
      ctx.font = font(12.5, true);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      var w = ctx.measureText(label).width;
      ctx.fillStyle = 'rgba(255,255,255,0.88)';
      ctx.fillRect(lx - w / 2 - 3, ly - 8, w + 6, 16);
      ctx.fillStyle = c;
      ctx.fillText(label, lx, ly);
    }
    ctx.restore();
  }

  /** 吹き出し（引き出し線つき）。左上詰めで矩形を返す */
  function callout(ctx, anchor, dx, dy, lines, opt) {
    opt = opt || {};
    ctx.save();
    ctx.font = (opt.font || font(12));
    var pad = 5, lh = 15.5;
    var w = 0;
    for (var i = 0; i < lines.length; i++) w = Math.max(w, ctx.measureText(lines[i]).width);
    var bw = w + pad * 2, bh = lines.length * lh + pad * 2 - 3;
    var bx = anchor.x + dx, by = anchor.y + dy;
    bx = P.clamp(bx, 2, L.W - bw - 2);
    by = P.clamp(by, 2, L.BAND_Y - bh - 12);
    ctx.strokeStyle = opt.line || '#8a8a8a'; ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(anchor.x, anchor.y);
    ctx.lineTo(bx + (dx < 0 ? bw : 0), by + bh / 2);
    ctx.stroke();
    roundRect(ctx, bx, by, bw, bh, 5);
    ctx.fillStyle = opt.bg || 'rgba(255,255,255,0.95)'; ctx.fill();
    ctx.strokeStyle = opt.border || '#b9b9b9'; ctx.lineWidth = 1; ctx.stroke();
    ctx.fillStyle = opt.fg || '#222';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    for (var j = 0; j < lines.length; j++) ctx.fillText(lines[j], bx + pad, by + pad + j * lh);
    ctx.restore();
    return { x: bx, y: by, w: bw, h: bh };
  }

  /**
   * 決まった場所に置く吹き出し（引き出し線は anchor まで伸びる）。
   * 位置を図の内容から計算すると、角度や次数によって別のラベルと重なる。
   * ステップの吹き出しはこれを使い、置き場所を固定して衝突をなくす。
   */
  function calloutAt(ctx, anchor, bx, by, lines, opt) {
    opt = opt || {};
    ctx.save();
    ctx.font = (opt.font || font(12));
    var pad = 6, lh = 15.5;
    var w = 0;
    for (var i = 0; i < lines.length; i++) w = Math.max(w, ctx.measureText(lines[i]).width);
    var bw = w + pad * 2, bh = lines.length * lh + pad * 2 - 3;
    bx = P.clamp(bx, 4, L.W - bw - 4);
    by = P.clamp(by, 4, L.BAND_Y - bh - 12);
    if (anchor) {
      // 引き出し線は、箱のいちばん近い辺から出す
      var hx = P.clamp(anchor.x, bx, bx + bw);
      var hy = (anchor.y < by) ? by : (anchor.y > by + bh ? by + bh : anchor.y);
      if (hx > bx && hx < bx + bw) hx = P.clamp(anchor.x, bx + 8, bx + bw - 8);
      ctx.strokeStyle = opt.border || '#9a9a9a'; ctx.lineWidth = 1;
      ctx.setLineDash([4, 3]);
      ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(anchor.x, anchor.y); ctx.stroke();
      ctx.setLineDash([]);
      ctx.beginPath(); ctx.arc(anchor.x, anchor.y, 3, 0, Math.PI * 2);
      ctx.fillStyle = opt.border || '#8a8a8a'; ctx.fill();
    }
    roundRect(ctx, bx, by, bw, bh, 6);
    ctx.fillStyle = opt.bg || 'rgba(255,255,255,0.97)'; ctx.fill();
    ctx.strokeStyle = opt.border || '#b9b9b9'; ctx.lineWidth = 1.4; ctx.stroke();
    ctx.fillStyle = opt.fg || '#222';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    for (var j = 0; j < lines.length; j++) ctx.fillText(lines[j], bx + pad, by + pad + j * lh);
    ctx.restore();
    return { x: bx, y: by, w: bw, h: bh };
  }

  /** 決まったスロット（左端／右端）に置く吹き出し。図と重ならない */
  function calloutAbs(ctx, anchor, side, y, lines, opt) {
    opt = opt || {};
    ctx.save();
    ctx.font = (opt.font || font(12));
    var pad = 6, lh = 15.5;
    var w = 0;
    for (var i = 0; i < lines.length; i++) w = Math.max(w, ctx.measureText(lines[i]).width);
    var bw = w + pad * 2, bh = lines.length * lh + pad * 2 - 3;
    var bx = (side === 'right') ? (L.W - bw - 8) : 8;
    var by = P.clamp(y, 4, L.BAND_Y - bh - 4);

    if (!opt.noLeader && anchor) {
      var hx = (side === 'right') ? bx : bx + bw, hy = by + bh / 2;
      ctx.strokeStyle = opt.line || (opt.border || '#9a9a9a'); ctx.lineWidth = 1;
      ctx.setLineDash([4, 3]);
      ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(anchor.x, anchor.y); ctx.stroke();
      ctx.setLineDash([]);
      ctx.beginPath(); ctx.arc(anchor.x, anchor.y, 3, 0, Math.PI * 2);
      ctx.fillStyle = opt.border || '#8a8a8a'; ctx.fill();
    }
    roundRect(ctx, bx, by, bw, bh, 6);
    ctx.fillStyle = opt.bg || 'rgba(255,255,255,0.96)'; ctx.fill();
    ctx.strokeStyle = opt.border || '#b9b9b9'; ctx.lineWidth = 1.2; ctx.stroke();
    ctx.fillStyle = opt.fg || '#222';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    for (var j = 0; j < lines.length; j++) ctx.fillText(lines[j], bx + pad, by + pad + j * lh);
    ctx.restore();
    return { x: bx, y: by, w: bw, h: bh };
  }

  /** 観測者の目（見ている向きに回転する）。薄膜ページと同じ形 */
  function eye(ctx, p, gaze, scale, label) {
    var s = scale || 1;
    var ang = Math.atan2(gaze.y, gaze.x);
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.rotate(ang);
    ctx.scale(s, s);
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.ellipse(0, 0, 25, 18, 0, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(255,255,255,0.92)'; ctx.fill();
    ctx.beginPath();
    ctx.moveTo(-19, 0);
    ctx.quadraticCurveTo(0, -16, 19, 0);
    ctx.quadraticCurveTo(0, 16, -19, 0);
    ctx.closePath();
    ctx.fillStyle = '#ffffff'; ctx.fill();
    ctx.strokeStyle = '#2b2118'; ctx.lineWidth = 3.4; ctx.stroke();
    ctx.beginPath(); ctx.arc(6, 0, 5.2, 0, Math.PI * 2);
    ctx.fillStyle = '#ffffff'; ctx.fill();
    ctx.strokeStyle = '#2b2118'; ctx.lineWidth = 2.6; ctx.stroke();
    ctx.strokeStyle = '#2b2118'; ctx.fillStyle = '#2b2118'; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.moveTo(25, 0); ctx.lineTo(38, 0); ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(50, 0); ctx.lineTo(36, -8); ctx.lineTo(36, 8);
    ctx.closePath(); ctx.fill();
    ctx.restore();

    if (label !== false) {
      var txt = (typeof label === 'string') ? label : '見る方向';
      ctx.save();
      ctx.font = font(11.5, true);
      var tw = ctx.measureText(txt).width;
      var lx = P.clamp(p.x, tw / 2 + 6, L.W - tw / 2 - 6);
      var ly = P.clamp(p.y - 30, 12, L.BAND_Y - 8);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      roundRect(ctx, lx - tw / 2 - 5, ly - 9, tw + 10, 18, 5);
      ctx.fillStyle = 'rgba(255,255,255,0.92)'; ctx.fill();
      ctx.strokeStyle = '#b9b3ab'; ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = '#2b2118';
      ctx.fillText(txt, lx, ly);
      ctx.restore();
    }
  }

  /** 作図点のラベル（小さな黒点＋記号） */
  function pointLabel(ctx, p, text, dx, dy, color) {
    ctx.save();
    ctx.beginPath(); ctx.arc(p.x, p.y, 3.2, 0, Math.PI * 2);
    ctx.fillStyle = color || '#222'; ctx.fill();
    ctx.font = font(12.5, true);
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    var w = ctx.measureText(text).width;
    ctx.fillStyle = 'rgba(255,255,255,0.85)';
    ctx.fillRect(p.x + dx - w / 2 - 2, p.y + dy - 8, w + 4, 16);
    ctx.fillStyle = color || '#222';
    ctx.fillText(text, p.x + dx, p.y + dy);
    ctx.restore();
  }

  /** 直角のしるし */
  function rightAngle(ctx, p, d1, d2, size, color) {
    var s = size || 9;
    var a = add(p, mul(d1, s)), b = add(p, mul(d2, s));
    var c = add(a, mul(d2, s));
    ctx.save();
    ctx.strokeStyle = color || '#666'; ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(a.x, a.y); ctx.lineTo(c.x, c.y); ctx.lineTo(b.x, b.y);
    ctx.stroke();
    ctx.restore();
  }

  /** 角の弧（ラベルつき） */
  function angleArc(ctx, center, a0, a1, radius, color, label) {
    var lo = Math.min(a0, a1), hi = Math.max(a0, a1);
    if (hi - lo < 0.02) return;
    ctx.save();
    ctx.strokeStyle = color; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(center.x, center.y, radius, lo, hi); ctx.stroke();
    if (label) {
      var mid = (lo + hi) / 2;
      ctx.fillStyle = color; ctx.font = font(13, true);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      var tx = center.x + Math.cos(mid) * (radius + 15);
      var ty = center.y + Math.sin(mid) * (radius + 15);
      var w = ctx.measureText(label).width;
      ctx.fillStyle = 'rgba(255,255,255,0.85)';
      ctx.fillRect(tx - w / 2 - 2, ty - 8, w + 4, 16);
      ctx.fillStyle = color;
      ctx.fillText(label, tx, ty);
    }
    ctx.restore();
  }

  /* ---------- 図の中のボタン ---------- */
  var uiButtons = [];
  function resetButtons() { uiButtons.length = 0; }
  function canvasButton(ctx, x, y, label, id, hot, on) {
    ctx.save();
    ctx.font = font(12, true);
    var w = ctx.measureText(label).width + 22, h = 26;
    roundRect(ctx, x, y, w, h, 7);
    ctx.fillStyle = on ? '#ffe9c2' : (hot ? '#eaf1fa' : 'rgba(255,255,255,0.94)');
    ctx.fill();
    ctx.strokeStyle = on ? '#c77800' : (hot ? '#1f74d0' : '#b6bcc2');
    ctx.lineWidth = hot || on ? 1.8 : 1.2; ctx.stroke();
    ctx.fillStyle = on ? '#8a5300' : '#28405c';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(label, x + 11, y + h / 2 + 1);
    ctx.restore();
    uiButtons.push({ x: x, y: y, w: w, h: h, id: id });
    return w;
  }
  /** ボタンの見た目を描かずに、当たり判定だけ足す（図の中のラベルなど） */
  function addHit(x, y, w, h, id) { uiButtons.push({ x: x, y: y, w: w, h: h, id: id }); }

  function hitButton(px, py) {
    for (var i = 0; i < uiButtons.length; i++) {
      var b = uiButtons[i];
      if (px >= b.x && px <= b.x + b.w && py >= b.y && py <= b.y + b.h) return b.id;
    }
    return null;
  }

  /* ---------- パルス強調 ---------- */
  function pulseAmount(pulse, kind, nowSec) {
    if (!pulse || pulse.kind !== kind) return 0;
    var t = nowSec - pulse.t0;
    if (t < 0 || t > 1.6) return 0;
    var fade = 1 - t / 1.6;
    return fade * (0.55 + 0.45 * Math.cos(2 * Math.PI * 2.4 * t));
  }
  /** 線を太く光らせる（「⚡ 経路差を強調」で使う） */
  function glowLine(ctx, a, b, color, amount, dash) {
    if (!(amount > 0.01)) return;
    ctx.save();
    ctx.setLineDash(dash || []);
    ctx.strokeStyle = color;
    ctx.globalAlpha = 0.25 + 0.75 * amount;
    ctx.lineWidth = 4 + 11 * amount;
    ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
    ctx.restore();
  }

  function boxGlow(ctx, box, amount, color) {
    if (!box || !(amount > 0.01)) return;
    var g = 3 + 11 * amount;
    ctx.save();
    ctx.strokeStyle = color || '#e0a800';
    ctx.globalAlpha = 0.85 * amount;
    ctx.lineWidth = 2 + 5 * amount;
    roundRect(ctx, box.x - g, box.y - g, box.w + 2 * g, box.h + 2 * g, 8 + g);
    ctx.stroke();
    ctx.restore();
  }

  /* ---------- 光源 ---------- */
  function lightBulb(ctx, p, opt) {
    opt = opt || {};
    var s = opt.scale || 1;
    // 白色光のときは、電球そのものを白く描く
    var glass = opt.white ? '#ffffff' : '#ffe9a8';
    var edge = opt.white ? '#8f979e' : '#b8860b';
    var beam = opt.white ? '#c9cfd4' : '#e0a800';
    ctx.save();
    ctx.translate(p.x, p.y); ctx.scale(s, s);
    ctx.lineCap = 'round';
    ctx.strokeStyle = beam; ctx.lineWidth = 2;
    for (var i = 0; i < 8; i++) {
      var a2 = i * Math.PI / 4;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a2) * 15, Math.sin(a2) * 15);
      ctx.lineTo(Math.cos(a2) * 21, Math.sin(a2) * 21);
      ctx.stroke();
    }
    ctx.fillStyle = '#9aa0a6';
    roundRect(ctx, -5, 6, 10, 10, 2); ctx.fill();
    ctx.beginPath(); ctx.arc(0, 0, 11, 0, Math.PI * 2);
    ctx.fillStyle = glass; ctx.fill();
    ctx.strokeStyle = edge; ctx.lineWidth = 1.6; ctx.stroke();
    ctx.strokeStyle = edge; ctx.lineWidth = 1.3;
    ctx.beginPath();
    ctx.moveTo(-4, 4); ctx.lineTo(-2, -2); ctx.lineTo(0, 3); ctx.lineTo(2, -2); ctx.lineTo(4, 4);
    ctx.stroke();
    ctx.restore();
  }

  /** 波長と色を示す小さな名札 */
  function waveChip(ctx, cx, cy, txt, rgb, dark) {
    ctx.save();
    ctx.font = font(11, true);
    var tw = ctx.measureText(txt).width;
    var bw = tw + 26;
    var bx = P.clamp(cx - bw / 2, 6, Math.max(6, L.W - 6 - bw));
    roundRect(ctx, bx, cy - 9, bw, 18, 5);
    ctx.fillStyle = dark ? 'rgba(0,0,0,0.45)' : 'rgba(255,255,255,0.92)';
    ctx.fill();
    ctx.strokeStyle = dark ? '#6b5a2a' : '#cfd6dd'; ctx.lineWidth = 1; ctx.stroke();
    ctx.fillStyle = rgb || '#888';
    roundRect(ctx, bx + 6, cy - 5, 10, 10, 2); ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 1; ctx.stroke();
    ctx.fillStyle = dark ? '#e8ecf0' : '#3d4a54';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(txt, bx + 21, cy + 1);
    ctx.restore();
  }

  /** 光源の名札に添える「λ = 600 nm（橙色）」 */
  function lightText(st) {
    if (st.light === 'white') return '白色光（すべての波長）';
    return 'λ = ' + Math.round(st.lambda) + ' nm（' + P.colorName(st.lambda) + '色）';
  }

  /* ================= 図の骨組み ================= */

  /** 背景（左パネルをうすく塗り分け、境目に線を引く） */
  function panels(ctx) {
    ctx.save();
    ctx.fillStyle = '#f7fafc';
    ctx.fillRect(0, 0, L.DIV, L.BAND_Y);
    ctx.strokeStyle = '#dbe3ea'; ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(L.DIV + 0.5, 8); ctx.lineTo(L.DIV + 0.5, L.BAND_Y - 8);
    ctx.stroke();
    ctx.restore();
  }

  /** 回折格子の板（多くの筋が入ったガラス）。中央の 6 本が図に描くスリット */
  /**
   * 回折格子の面。教科書 図(b) のように、
   *   「筋（ギザギザ）」と「筋と筋のあいだ（平らな部分＝スリット）」が交互に並ぶ。
   * x: 面の x／y0〜y1: 面の範囲／yc0: あるスリットの中心 y／period: スリットの間隔
   * slitHalf: スリットの半分の幅／amp: ギザギザの深さ／tooth: 歯 1 つの高さ
   */
  function gratingFace(ctx, x, y0, y1, yc0, period, slitHalf, amp, tooth) {
    var k0 = Math.floor((y0 - yc0) / period) - 1;
    var k1 = Math.ceil((y1 - yc0) / period) + 1;
    var cur = y0, tick = 0;
    ctx.beginPath();
    ctx.moveTo(x, y0);
    function zigTo(to) {
      if (to <= cur + 0.01) return;
      var n = Math.max(1, Math.round((to - cur) / tooth));
      for (var i = 1; i <= n; i++) {
        tick++;
        ctx.lineTo(x + (tick % 2 ? amp : 0), cur + (to - cur) * i / n);
      }
      cur = to;
    }
    for (var k = k0; k <= k1; k++) {
      var c = yc0 + k * period;
      var a = c - slitHalf, b = c + slitHalf;
      if (b <= y0 || a >= y1) continue;
      a = Math.max(a, y0); b = Math.min(b, y1);
      zigTo(a);
      ctx.lineTo(x, a);          // 平らな部分（スリット）のはじまり
      ctx.lineTo(x, b);          // 平らな部分（スリット）のおわり
      cur = b; tick = 0;
    }
    zigTo(y1);
    ctx.lineTo(x, y1);
    ctx.stroke();
  }

  function gratingPlate(ctx, sc) {
    var x = sc.gx, y0 = L.CY - L.PLATE_H / 2, y1 = L.CY + L.PLATE_H / 2;
    var yc0 = sc.slits[0].y;
    ctx.save();
    // ガラスの板（左は平ら、右の面に筋が刻んである）
    ctx.fillStyle = COL.plate;
    ctx.fillRect(x - 7, y0, 12, L.PLATE_H);
    ctx.strokeStyle = COL.plateEdge; ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(x - 7, y0); ctx.lineTo(x + 5, y0);
    ctx.moveTo(x - 7, y1); ctx.lineTo(x + 5, y1);
    ctx.moveTo(x - 7, y0); ctx.lineTo(x - 7, y1);
    ctx.stroke();
    // 右の面：筋（ギザギザ）と スリット（平ら）が交互
    ctx.strokeStyle = '#3f7ba1'; ctx.lineWidth = 1.1;
    gratingFace(ctx, x + 5, y0, y1, yc0, L.SLIT_SP, 1.3, 2.8, 3.0);
    // 図に描く 6 本のスリット（光が出ていくところ）を明るく
    ctx.fillStyle = 'rgba(255,255,255,0.9)';
    for (var i = 0; i < sc.slits.length; i++) {
      ctx.fillRect(x - 7, sc.slits[i].y - 1.1, 12, 2.2);
    }
    // 名札
    ctx.font = font(12, true);
    ctx.fillStyle = '#2b5a78';
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText('回折格子', x, y1 + 6);
    ctx.font = font(11);
    ctx.fillStyle = '#5b6672';
    ctx.fillText('（図には中央の ' + L.NSLIT + ' 本ぶんだけ描いています）', x, y1 + 22);
    ctx.restore();
  }

  /**
   * 省略記号。回折格子とスクリーンの距離 l は、格子の間隔 d にくらべて
   * けた違いに長い（d = 2 μm・l = 1 m なら 50 万倍）。そのままの縮尺では
   * 描けないので、途中を波形の線で省いて描いていることを示す。
   */
  function breakMark(ctx, y0, y1) {
    var x = L.BREAK_X, w = 26;
    ctx.save();
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(x, y0, w, y1 - y0);
    ctx.strokeStyle = '#8f979e'; ctx.lineWidth = 1.6;
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    for (var k = 0; k < 2; k++) {
      var bx = x + (k === 0 ? 3 : w - 3);
      ctx.beginPath();
      for (var y = y0; y <= y1; y += 3) {
        var xx = bx + Math.sin((y - y0) / 14) * 5;
        if (y === y0) ctx.moveTo(xx, y); else ctx.lineTo(xx, y);
      }
      ctx.stroke();
    }
    ctx.restore();
  }

  /** スクリーン（縦の板）と目盛り */
  function screenBar(ctx, sc) {
    var x = L.SX, y0 = L.CY - L.SH, y1 = L.CY + L.SH, w = L.SCR_W;
    ctx.save();
    ctx.fillStyle = COL.screen;
    ctx.fillRect(x - 4, y0 - 4, w + 8, y1 - y0 + 8);
    // 明線がはっきり見えるよう、スクリーンの面は暗くしておく（図 1 の写真と同じ見え方）
    ctx.fillStyle = '#1d1f22';
    ctx.fillRect(x, y0, w, y1 - y0);
    ctx.strokeStyle = COL.screenEdge; ctx.lineWidth = 1.2;
    ctx.strokeRect(x - 4, y0 - 4, w + 8, y1 - y0 + 8);
    ctx.font = font(12, true);
    ctx.fillStyle = '#7a6a48';
    ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
    ctx.fillText('スクリーン', x + w / 2, y0 - 14);
    ctx.restore();
    // スクリーンの大きさの概算（約◯◯cm）は図の中には描かない。
    // 図の下の欄外の注記（#screen-note、70_ui.js が更新）に書いてある。
  }

  /** スクリーンのすぐ左に、cm の目盛りを打つ（L を変えると目盛りの間隔が変わる） */
  function screenRuler(ctx, sc) {
    var stepM = niceStep(sc.halfM);
    ctx.save();
    ctx.strokeStyle = '#b3a88c'; ctx.lineWidth = 1;
    ctx.font = font(11);
    ctx.fillStyle = '#6f6754';
    ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    for (var k = -20; k <= 20; k++) {
      var xm = k * stepM;
      if (Math.abs(xm) > sc.halfM + 1e-9) continue;
      var y = L.CY - xm * sc.ppm;
      var big = (k % 2 === 0);
      ctx.beginPath();
      ctx.moveTo(L.SX - (big ? 7 : 4), y); ctx.lineTo(L.SX - 1, y);
      ctx.stroke();
      // 点 P のそばは光線とラベルが混みあうので、目盛りの数字は出さない
      if (big && k !== 0 && Math.abs(y - sc.P1.y) > 22) {
        var t = fmtCm(Math.abs(xm));
        var w = ctx.measureText(t).width;
        ctx.fillStyle = 'rgba(255,255,255,0.86)';
        ctx.fillRect(L.SX - 10 - w, y - 7, w + 3, 14);
        ctx.fillStyle = '#6f6754';
        ctx.fillText(t, L.SX - 9, y);
      }
    }
    ctx.restore();
  }
  function niceStep(halfM) {
    var raw = halfM / 5;
    var cands = [0.01, 0.02, 0.05, 0.1, 0.2, 0.25, 0.5, 1.0];
    for (var i = 0; i < cands.length; i++) if (cands[i] >= raw) return cands[i];
    return 1.0;
  }
  function fmtCm(m) {
    var cm = m * 100;
    return (cm >= 10 ? Math.round(cm) : Math.round(cm * 10) / 10) + ' cm';
  }

  /* ---------- 数値の書き方 ---------- */
  /** 小数 1 桁。丸めで値が動くときだけ「約」を付ける */
  function about(v) {
    var r = Math.round(v * 10) / 10;
    return (Math.abs(v - r) < 0.005 ? '' : '約 ') + r.toFixed(1);
  }
  /** 長さ [m] を読みやすい単位で */
  function fmtLenM(m) {
    var a = Math.abs(m);
    if (a < 0.01) return (m * 1000).toFixed(1) + ' mm';
    if (a < 1) return (m * 100).toFixed(1) + ' cm';
    return m.toFixed(2) + ' m';
  }
  /** 格子定数 [nm] を μm で */
  function fmtD(d) { return (d / 1000).toFixed(2) + ' μm'; }

  /* ================= 経路差をまっすぐ伸ばして見せる帯 =================
   * 上の図でハイライトしている経路差 d sinθ を、1 本の直線に伸ばし、
   * その上に波長 λ の波を並べる。波の個数がそのまま「経路差は λ の何倍か」。
   * 波は飾りではなく、図の中の波とまったく同じ関数 P.waveAt() から描く。
   */
  function unwrapBand(ctx, st, sol, glow) {
    var y0 = L.BAND_Y + 8, h = L.H - y0 - 8;
    var count = Math.abs(sol.ratio);

    ctx.save();
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, L.BAND_Y - 8, L.W, L.H - (L.BAND_Y - 8));

    roundRect(ctx, 10, y0, L.W - 20, h, 10);
    ctx.fillStyle = '#ffffff'; ctx.fill();
    ctx.strokeStyle = COL.geo; ctx.lineWidth = 1.6;
    ctx.setLineDash([7, 5]); ctx.stroke(); ctx.setLineDash([]);

    var chip = '↑ の図の、隣りあうスリットを通った光の経路差（緑の部分）だけを取り出して、まっすぐ伸ばすと';
    ctx.font = font(11.5, true);
    var cw = ctx.measureText(chip).width + 34;
    roundRect(ctx, 24, y0 - 11, cw, 22, 11);
    ctx.fillStyle = COL.geo; ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(chip, 41, y0 + 1);

    var cy = y0 + 54;
    var lx = 48, rightPad = 196;
    var avail = L.W - 16 - rightPad - lx;
    var n = Math.max(count, 0.30);
    var unit = Math.min(420, avail / n);       // 波 1 個ぶんの px
    var lenPx = unit * count;

    // 経路差そのもの（緑の太線）
    ctx.lineCap = 'round';
    ctx.globalAlpha = 0.72;
    ctx.strokeStyle = COL.geo; ctx.lineWidth = 7;
    ctx.beginPath(); ctx.moveTo(lx, cy); ctx.lineTo(lx + lenPx, cy); ctx.stroke();
    ctx.globalAlpha = 1;
    if (glow > 0.01) glowLine(ctx, vec(lx, cy), vec(lx + lenPx, cy), COL.geo, glow);

    // 波（図の中の波と同じ式）。経路 s [nm] を px になおして描く
    var nmToPx = (Math.abs(sol.delta) > 1e-9) ? (lenPx / Math.abs(sol.delta)) : 0;
    var t = st.t || 0;
    ctx.strokeStyle = COL.ray; ctx.lineWidth = 2;
    ctx.lineJoin = 'round';
    ctx.beginPath();
    var steps = 320;
    for (var i = 0; i <= steps; i++) {
      var px = lenPx * i / steps;
      var s = (nmToPx > 0) ? px / nmToPx : 0;
      var yy = cy - L.AMP * P.waveAt(s, t, st.lambda);
      if (i === 0) ctx.moveTo(lx + px, yy); else ctx.lineTo(lx + px, yy);
    }
    ctx.stroke();

    // 端のしるし
    ctx.strokeStyle = '#0b5c34'; ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(lx, cy - 22); ctx.lineTo(lx, cy + 22);
    ctx.moveTo(lx + lenPx, cy - 22); ctx.lineTo(lx + lenPx, cy + 22);
    ctx.stroke();

    // λ 1 個ぶんの目盛り
    if (unit > 26 && count >= 0.5) {
      ctx.strokeStyle = 'rgba(11,92,52,0.45)'; ctx.lineWidth = 1;
      ctx.setLineDash([3, 3]);
      for (var k = 1; k < count - 1e-6; k++) {
        ctx.beginPath();
        ctx.moveTo(lx + unit * k, cy - 18); ctx.lineTo(lx + unit * k, cy + 18);
        ctx.stroke();
      }
      ctx.setLineDash([]);
      dimLine(ctx, vec(lx, cy + 32), vec(lx + unit, cy + 32), 'λ', '#0b5c34', 12);
    }

    // 判定
    var right = L.W - rightPad + 10;
    ctx.font = font(13, true);
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#0b5c34';
    ctx.fillText('経路差 ＝ ' + about(count) + ' λ', right, cy - 14);
    var col = sol.kind === 'strong' ? '#1b6b34' : (sol.kind === 'weak' ? '#a12a1c' : '#8a6d00');
    var bg = sol.kind === 'strong' ? '#e9f6ee' : (sol.kind === 'weak' ? '#fdeeec' : '#fff8e6');
    var txt = sol.kind === 'strong' ? '→ 強めあう（明線）' : (sol.kind === 'weak' ? '→ 弱めあう（暗い）' : '→ 完全には強めあわない');
    var tw = ctx.measureText(txt).width;
    roundRect(ctx, right - 6, cy + 2, tw + 16, 24, 8);
    ctx.fillStyle = bg; ctx.fill();
    ctx.strokeStyle = col; ctx.lineWidth = 1.4; ctx.stroke();
    ctx.fillStyle = col;
    ctx.fillText(txt, right + 2, cy + 15);

    ctx.font = font(11.5);
    ctx.fillStyle = '#5b6672';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText('経路差 ＝ d sinθ ＝ ' + Math.round(Math.abs(sol.delta)) + ' nm　／　λ ＝ '
      + Math.round(st.lambda) + ' nm', lx, cy + 50);
    ctx.restore();
  }

  return {
    L: L, COL: COL,
    font: font, FONT: FONT,
    vec: vec, add: add, sub: sub, mul: mul, dot: dot, len: len, nrmOf: nrmOf, unit: unit,
    texImage: texImage, drawTex: drawTex,
    shade: shade, setLightColor: setLightColor, pureColor: pureColor,
    buildScene: buildScene,
    roundRect: roundRect, line: line, dashLine: dashLine, arrow: arrow, dimLine: dimLine,
    callout: callout, calloutAbs: calloutAbs, calloutAt: calloutAt,
    eye: eye, pointLabel: pointLabel,
    rightAngle: rightAngle, angleArc: angleArc,
    resetButtons: resetButtons, canvasButton: canvasButton, addHit: addHit, hitButton: hitButton,
    buttons: function () { return uiButtons.slice(); },
    pulseAmount: pulseAmount, boxGlow: boxGlow, glowLine: glowLine,
    lightBulb: lightBulb, waveChip: waveChip, lightText: lightText,
    panels: panels, gratingPlate: gratingPlate, gratingFace: gratingFace,
    screenBar: screenBar, screenRuler: screenRuler,
    breakMark: breakMark,
    about: about, fmtLenM: fmtLenM, fmtD: fmtD, fmtCm: fmtCm,
    unwrapBand: unwrapBand
  };
})();
