/* ===== 30_physics.js ===== */
/* 回折格子の物理計算（純関数のみ。DOM に触らない ＝ 自動テストの対象）
 *
 * 単位の決め：
 *   λ・d・経路差 … nm
 *   L・x        … m
 *   角度         … rad（表示のときだけ度になおす）
 *
 * 明線の条件      d sinθ = mλ   (m = 0, ±1, ±2, …)
 * スクリーン上の位置  x = L tanθ   （近似 x ≒ mλL/d ではなく、こちらで描く）
 */
window.DG = window.DG || {};
DG.phys = (function () {
  'use strict';

  var DEG = Math.PI / 180;

  function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }

  /* ---------- 格子定数 ---------- */
  /** 格子定数 d [nm] → 1 cm あたりの本数（教科書の表記「〇本/cm」に合わせる。1 cm = 10⁷ nm） */
  function linesPerCmFromD(d) { return 1e7 / d; }

  /* ---------- 明線 ---------- */
  /** m 次の明線の sinθ ＝ mλ/d */
  function sinThetaOf(m, lambda, d) { return m * lambda / d; }

  /**
   * スクリーンに出うる最大の次数。
   * sinθ = mλ/d が 1 以上になる次数は存在しない（θ = 90° もスクリーンには届かない）。
   *   例：λ = 600 nm、d = 500 nm → d/λ = 0.833 なので m_max = 0（1 次は存在しない）
   *   例：λ = 600 nm、d = 2000 nm → d/λ = 3.33 なので m_max = 3
   *   例：d/λ がちょうど 3 のときは sinθ = 1 になるので m_max = 2
   */
  function maxOrder(lambda, d) {
    var m = Math.ceil(d / lambda - 1e-12) - 1;
    return m < 0 ? 0 : m;
  }

  /** m 次の明線の角度 [rad]。存在しないときは null */
  function thetaOf(m, lambda, d) {
    var s = sinThetaOf(Math.abs(m), lambda, d);
    if (!(s < 1)) return null;
    return (m < 0 ? -1 : 1) * Math.asin(s);
  }

  /** 隣りあうスリットを通った光の経路差 d sinθ [nm] */
  function pathDiff(d, theta) { return d * Math.sin(theta); }

  /** スクリーン上の位置 x ＝ L tanθ [m] */
  function xOnScreen(theta, L) { return L * Math.tan(theta); }

  /** スクリーン上の位置 x [m] → 角度 [rad] */
  function thetaFromX(x, L) { return Math.atan(x / L); }

  /**
   * N 本のスリットによる干渉の強度比 I/I_max（0〜1）
   *   I(θ) = ( sin(N π d sinθ / λ) / (N sin(π d sinθ / λ)) )²
   * β ＝ π d sinθ / λ が mπ に近づくときの極限は 1。
   */
  function intensityN(theta, d, lambda, N) {
    var b = Math.PI * d * Math.sin(theta) / lambda;
    var s = Math.sin(b);
    if (Math.abs(s) < 1e-9) return 1;
    var r = Math.sin(N * b) / (N * s);
    return r * r;
  }

  /* ---------- 波 ---------- */
  /* 画面上の見かけの光速 [nm/s]。実際の c ではなく、波がゆっくり動いて見える速さ。 */
  var V_NM_PER_S = 520;

  /** 光路長 s [nm]・時刻 t [s] における波の位相 [rad] */
  function phaseAt(s, t, lambda) {
    return 2 * Math.PI * (s - V_NM_PER_S * t) / lambda;
  }
  /** 波の変位（振幅 1）。図の中の波も、下の展開バンドの波も、必ずこの関数から描く */
  function waveAt(s, t, lambda) { return Math.sin(phaseAt(s, t, lambda)); }

  /* ---------- 色 ---------- */
  /** 波長 [nm] → RGB（見た目用の近似） */
  function wavelengthToRGB(nm) {
    var R = 0, G = 0, B = 0;
    if (nm >= 380 && nm < 440) { R = -(nm - 440) / 60; B = 1; }
    else if (nm < 490) { G = (nm - 440) / 50; B = 1; }
    else if (nm < 510) { G = 1; B = -(nm - 510) / 20; }
    else if (nm < 580) { R = (nm - 510) / 70; G = 1; }
    else if (nm < 645) { R = 1; G = -(nm - 645) / 65; }
    else if (nm <= 780) { R = 1; }
    var f = 1;
    if (nm >= 380 && nm < 420) f = 0.3 + 0.7 * (nm - 380) / 40;
    else if (nm > 700 && nm <= 780) f = 0.3 + 0.7 * (780 - nm) / 80;
    var g = 0.8;
    function ch(x) { return Math.round(255 * Math.pow(Math.max(0, x) * f, g)); }
    return { r: ch(R), g: ch(G), b: ch(B) };
  }

  /** 波長 [nm] → 色の名前（高校の教科書でよく使う 7 区分） */
  var COLOR_NAMES = [
    { max: 435, name: '紫' },
    { max: 480, name: '青' },
    { max: 500, name: '青緑' },
    { max: 560, name: '緑' },
    { max: 590, name: '黄' },
    { max: 620, name: '橙' },
    { max: 1e9, name: '赤' }
  ];
  function colorName(nm) {
    for (var i = 0; i < COLOR_NAMES.length; i++) {
      if (nm < COLOR_NAMES[i].max) return COLOR_NAMES[i].name;
    }
    return '赤';
  }

  function rgbCss(c, a) {
    // 小数のままだと CSS の色として無効になり、指定が黙って効かなくなるので丸める
    var r = Math.round(c.r), g = Math.round(c.g), b = Math.round(c.b);
    return a === undefined
      ? 'rgb(' + r + ',' + g + ',' + b + ')'
      : 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')';
  }

  /* ===== 白色光の色計算（CIE 1931 等色関数の多ローブ近似：Wyman et al. 2013） ===== */
  function gauss(x, mu, s1, s2) {
    var t = (x - mu) / (x < mu ? s1 : s2);
    return Math.exp(-0.5 * t * t);
  }
  function cieX(l) {
    return 1.056 * gauss(l, 599.8, 37.9, 31.0)
      + 0.362 * gauss(l, 442.0, 16.0, 26.7)
      - 0.065 * gauss(l, 501.1, 20.4, 26.2);
  }
  function cieY(l) {
    return 0.821 * gauss(l, 568.8, 46.9, 40.5) + 0.286 * gauss(l, 530.9, 16.3, 31.1);
  }
  function cieZ(l) {
    return 1.217 * gauss(l, 437.0, 11.8, 36.0) + 0.681 * gauss(l, 459.0, 26.0, 13.8);
  }

  var LMIN = 380, LMAX = 780, LSTEP = 2;
  var WHITE_Y = (function () {
    var s = 0;
    for (var l = LMIN; l <= LMAX; l += LSTEP) s += cieY(l);
    return s;
  })();

  function xyzToSrgb(X, Y, Z) {
    var r = 3.2406 * X - 1.5372 * Y - 0.4986 * Z;
    var g = -0.9689 * X + 1.8758 * Y + 0.0415 * Z;
    var b = 0.0557 * X - 0.2040 * Y + 1.0570 * Z;
    function gam(u) {
      u = Math.max(0, Math.min(1, u));
      return Math.round(255 * (u <= 0.0031308 ? 12.92 * u : 1.055 * Math.pow(u, 1 / 2.4) - 0.055));
    }
    return { r: gam(r), g: gam(g), b: gam(b) };
  }

  /**
   * 白色光をあてたとき、スクリーン上の位置 x [m] に届く光の色。
   * 380〜780 nm の各波長について I(θ) を求め、CIE 等色関数で足しあわせる。
   * gain は表示用の明るさ（1 で「その場所の全波長ぶんの明るさ」）。
   */
  function spectrumColorAtX(x, d, L, N, gain) {
    var th = thetaFromX(x, L);
    var X = 0, Y = 0, Z = 0;
    for (var l = LMIN; l <= LMAX; l += LSTEP) {
      var I = intensityN(th, d, l, N);
      X += I * cieX(l); Y += I * cieY(l); Z += I * cieZ(l);
    }
    var k = (gain === undefined ? 1 : gain) / WHITE_Y;
    return xyzToSrgb(X * k, Y * k, Z * k);
  }

  /* ---------- まとめ ---------- */
  /** 「強めあう」と言ってよい許容幅 [λ]。N 本のスリットの最初の暗点は 1/N なので、その半分 */
  function tolOf(N) { return 0.5 / N; }

  /**
   * いまの設定から、描画・UI・テストが共通で使う値をまとめて求める。
   * st: { lambda, d, L, N, m, sinT, onlyBright }
   */
  function solve(st) {
    var lambda = st.lambda, d = st.d, L = st.L, N = st.N;
    var mMax = maxOrder(lambda, d);

    // 見る方向。「明線の位置のみ」のときは m 次の明線の方向にそろえる。
    // 自由に選べるときは、逆に「いま何次の明線に近いか」を sinθ から決める。
    var m = clamp(Math.round(st.m), -mMax, mMax);
    var sinT;
    if (st.onlyBright) {
      sinT = sinThetaOf(m, lambda, d);
    } else {
      sinT = clamp(st.sinT, -0.995, 0.995);
      m = clamp(Math.round(sinT * d / lambda), -mMax, mMax);
    }
    var theta = Math.asin(clamp(sinT, -1, 1));

    var delta = pathDiff(d, theta);           // 経路差 [nm]
    var ratio = delta / lambda;               // λ 何個ぶんか
    var x = xOnScreen(theta, L);              // スクリーン上の位置 [m]
    var I = intensityN(theta, d, lambda, N);

    var gap = Math.abs(ratio - Math.round(ratio));
    var kind = (gap <= tolOf(N)) ? 'strong' : (I < 0.15 ? 'weak' : 'mid');
    // mid（明るさが中間）を「弱めあう」と言い切ると言い過ぎになるので、
    // 「完全には強めあわない」という事実だけを述べる表現にする
    var label = kind === 'strong' ? '強めあう' : (kind === 'weak' ? '弱めあう' : '完全には強めあわない');

    // スクリーンに出る明線の一覧（0 次から両側へ）
    var orders = [];
    for (var k = -mMax; k <= mMax; k++) {
      var th = thetaOf(k, lambda, d);
      if (th === null) continue;
      orders.push({ m: k, sinT: sinThetaOf(k, lambda, d), theta: th, x: xOnScreen(th, L) });
    }

    return {
      lambda: lambda, d: d, L: L, N: N,
      mMax: mMax, m: m,
      sinT: sinT, theta: theta, thetaDeg: theta / DEG,
      delta: delta, ratio: ratio, x: x, I: I,
      kind: kind, label: label, orders: orders
    };
  }

  return {
    DEG: DEG, clamp: clamp,
    linesPerCmFromD: linesPerCmFromD,
    sinThetaOf: sinThetaOf, maxOrder: maxOrder, thetaOf: thetaOf,
    pathDiff: pathDiff, xOnScreen: xOnScreen, thetaFromX: thetaFromX,
    intensityN: intensityN,
    V_NM_PER_S: V_NM_PER_S, phaseAt: phaseAt, waveAt: waveAt,
    wavelengthToRGB: wavelengthToRGB, colorName: colorName, rgbCss: rgbCss,
    spectrumColorAtX: spectrumColorAtX,
    tolOf: tolOf, solve: solve
  };
})();
