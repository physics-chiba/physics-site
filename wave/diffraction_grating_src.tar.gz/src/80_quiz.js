/* ===== 80_quiz.js ===== */
/* 練習問題（2 問）
 * ・答えは、上のシミュレーションで実際に確かめられるものにする。
 * ・選んだらすぐに正誤と解説が出る。まちがえた選択肢にも「なぜちがうか」を書く。
 * ・数値は 30_physics.js の関数から計算するので、式と図と問題がずれない。
 */
window.DG = window.DG || {};
DG.quiz = (function () {
  'use strict';
  var P = DG.phys;

  /* ---- 問題づくり（数値はここで計算する） ---- */
  function build() {
    var LAM = 600, L = 1.0;
    var d1 = 2000, d2 = 1000;                   // d を半分にする
    var x1 = P.xOnScreen(P.thetaOf(1, LAM, d1), L) * 100;   // cm
    var x2 = P.xOnScreen(P.thetaOf(1, LAM, d2), L) * 100;   // cm
    var s1 = P.sinThetaOf(1, LAM, d1), s2 = P.sinThetaOf(1, LAM, d2);

    return [
      {
        h: '問 1　格子定数 d を半分にすると、1 次の明線 (m = 1) の位置はどうなる？',
        lead: 'λ = ' + LAM + ' nm、L = ' + L.toFixed(2) + ' m のまま、'
          + '格子定数を d = ' + (d1 / 1000).toFixed(2) + ' μm（' + Math.round(P.linesPerCmFromD(d1))
          + ' 本/cm）から d = ' + (d2 / 1000).toFixed(2) + ' μm（'
          + Math.round(P.linesPerCmFromD(d2)) + ' 本/cm）に変えます。',
        opts: [
          {
            t: '中心 O から遠ざかる（明線の間隔が広がる）',
            ok: true,
            fb: '正解。sinθ = mλ/d で、d が小さくなると sinθ は大きくなります。'
              + '実際 sinθ は ' + s1.toFixed(3) + ' → ' + s2.toFixed(3) + '、'
              + 'x = L tanθ は ' + x1.toFixed(1) + ' cm → ' + x2.toFixed(1) + ' cm。'
              + '「筋を細かくするほど、虹は大きく広がる」ということです。'
          },
          {
            t: '中心 O に近づく（明線の間隔がせまくなる）',
            ok: false,
            fb: 'ちがいます。d は分母にあります（sinθ = mλ/d）。'
              + 'd を小さくすると sinθ は<b>大きく</b>なるので、明線は外へ動きます。'
              + '上の図で d のスライダーを動かして確かめてみましょう。'
          },
          {
            t: '変わらない（d は明線の位置に関係ない）',
            ok: false,
            fb: 'ちがいます。d sinθ = mλ には d が入っています。'
              + 'd が変われば、同じ m でも θ が変わります。'
          },
          {
            t: '明線が消えてしまう',
            ok: false,
            fb: 'ちがいます。消えるのは sinθ = mλ/d が 1 をこえるときだけです。'
              + 'ここでは sinθ = ' + s2.toFixed(3) + ' なので、1 次はちゃんと出ます。'
              + '（d をもっと小さく、たとえば ' + LAM + ' nm より小さくすると、1 次も出なくなります。）'
          }
        ]
      },
      {
        h: '問 2　白色光を当てると、まん中（m = 0）だけが白く見えるのはなぜ？',
        lead: '白色光には、紫（約 380 nm）から赤（約 780 nm）までいろいろな波長が混ざっています。'
          + '回折格子に当てると、1 次からは虹色に分かれるのに、まん中だけは白いままです。',
        opts: [
          {
            t: 'm = 0 では経路差が 0 で、波長に関係なくすべての色が同じ向き（θ = 0）に強めあうから',
            ok: true,
            fb: '正解。d sinθ = mλ に m = 0 を入れると d sinθ = 0、つまり θ = 0。'
              + 'この式に λ が残らないので、<b>どの色も同じ向き</b>に出ます。'
              + 'そこで全部の色が重なって白く見えます。'
              + '1 次以上は sinθ = mλ/d が λ に比例するので、'
              + '波長の短い紫が内側、長い赤が外側に分かれます。'
          },
          {
            t: 'まん中には格子を素通りした光だけが来て、干渉していないから',
            ok: false,
            fb: 'ちがいます。m = 0 の光も、ちゃんと全部のスリットからの光が重なった'
              + '<b>干渉の結果</b>です。ただ経路差が 0 なので、どの色もそろうというだけです。'
          },
          {
            t: '白い光だけが回折しにくく、まっすぐ進むから',
            ok: false,
            fb: 'ちがいます。「白い光」という 1 つの波長があるわけではありません。'
              + '白色光はいろいろな波長の混ざりもので、どの波長も同じように回折します。'
          },
          {
            t: 'まん中では紫と赤が打ち消しあって、色が消えるから',
            ok: false,
            fb: 'ちがいます。ちがう波長の光どうしは打ち消しあいません。'
              + 'まん中が白いのは、色が消えたからではなく、<b>全部の色が重なった</b>からです。'
          }
        ]
      }
    ];
  }

  var MARK = ['ア', 'イ', 'ウ', 'エ'];

  function init() {
    var root = document.getElementById('quiz');
    if (!root) return;
    root.innerHTML = '';
    var qs = build();
    for (var i = 0; i < qs.length; i++) render(root, qs[i], i);
  }

  function render(root, q, qi) {
    var box = document.createElement('div');
    box.className = 'q';
    box.setAttribute('data-q', String(qi + 1));

    var h = document.createElement('div');
    h.className = 'qh';
    h.textContent = q.h;
    box.appendChild(h);

    var lead = document.createElement('p');
    lead.className = 'note';
    lead.textContent = q.lead;
    box.appendChild(lead);

    var opts = document.createElement('div');
    opts.className = 'opts';
    var fb = document.createElement('div');
    fb.className = 'fb';
    fb.hidden = true;

    var btns = [];
    for (var k = 0; k < q.opts.length; k++) {
      (function (k) {
        var o = q.opts[k];
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'opt';
        b.setAttribute('data-ok', o.ok ? '1' : '0');
        b.innerHTML = '<span class="mk">' + MARK[k] + '</span>'
          + '<span class="optbody"><span>' + o.t + '</span></span>';
        b.addEventListener('click', function () {
          for (var j = 0; j < btns.length; j++) {
            btns[j].disabled = true;
            btns[j].classList.remove('correct', 'wrong');
            if (q.opts[j].ok) btns[j].classList.add('correct');
          }
          if (!o.ok) b.classList.add('wrong');
          fb.hidden = false;
          fb.className = 'fb ' + (o.ok ? 'ok' : 'ng');
          fb.innerHTML = (o.ok ? '◯　' : '✕　') + o.fb;
          box.setAttribute('data-answered', o.ok ? 'correct' : 'wrong');
        });
        btns.push(b);
        opts.appendChild(b);
      })(k);
    }
    box.appendChild(opts);
    box.appendChild(fb);
    root.appendChild(box);
  }

  return { init: init, build: build };
})();
