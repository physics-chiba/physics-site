/* ===== 70_ui.js ===== */
/* UI：状態管理・スライダー・ボタン・数値表示・解説パネルの更新 */
window.DG = window.DG || {};
DG.ui = (function () {
  'use strict';
  var P = DG.phys, D = DG.draw;
  var L = D.L;

  var RANGE = { lambda: [380, 780], d: [500, 3340], L: [0.20, 2.00] };
  /* スリットの本数 N。2 本から実際の格子なみの 1000 本まで。
     等間隔だと大きいところが粗くなるので、きりのよい値を並べて選ぶ。 */
  var N_STEPS = [2, 10, 100, 1000];

  /* 物理の条件（λ・d・L・見る方向・単色／白色）は、
     どのモードでも同じものを使う。タブを切りかえても引き継がれる。 */

  var st = {
    mode: 'path',                  // 'path' | 'wave' | 'field' | 'scale'
    light: 'mono',                 // 'mono' | 'white'
    lambda: 600, d: 2000, L: 1.00,
    N: 10,                         // 重なりあいを計算するスリットの本数 N′
    NField: 10,                    // 補足モード専用の N′（ほかのモードには影響させない）
    savedNBeforeField: null,       // 補足モードに入る前の N′ の退避場所
    m: 1, sinT: 0.3, onlyBright: false,   // 既定はチェックなし（明線以外も選べる）
    /* 補足：単スリット モード専用の設定（ほかのモードとは独立） */
    slitA: 2000,                   // スリットの幅 a [nm]
    K: 2,                          // スリットの中で考える点の数 K
    fyS: null, scrXS: null,        // 単スリットモードの点 P とスクリーン位置
    showDark: true, showEnv: true, // 暗線の向きの線／本当の分布の重ね描き
    step: 1,
    playing: false, slow: false, t: 0,
    showLabels: true, showSum: true, showWave: true, gammaOn: true,
    showMaxima: true, showMinima: true, fy: null, scrX: null,
    pulse: null, hoverBtn: null,
    figFull: false,
    /* 「🔍 実寸」オーバーレイ。開いていないときは null */
    scaleOut: null,
    stepPulse: null, nowSec: 0, dragging: false
  };

  var el = {}, ctx = null, dpr = 1, lastFrame = 0, lastOrderKey = '';

  function $(id) { return document.getElementById(id); }

  /* ---------- canvas ---------- */
  function setupCanvas() {
    var c = $('view');
    // 図の中の小さな字までくっきり出すため、画面よりも高い解像度で描く。
    // せまい画面ではメモリを食いすぎないように 3 倍でとめる。
    var wide = (window.innerWidth >= 900);
    dpr = Math.min(wide ? 4 : 3, Math.max(wide ? 4 : 3, (window.devicePixelRatio || 1) * 1.5));
    c.width = L.W * dpr;
    c.height = L.H * dpr;
    c.style.aspectRatio = L.W + ' / ' + L.H;
    ctx = c.getContext('2d', { alpha: false });
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.textRendering = 'geometricPrecision';
  }

  /* ---------- 描画 ---------- */
  function render() {
    D.setLightColor(st.lambda);
    var sol = P.solve(st);
    var sc = D.buildScene(st, sol);
    D.resetButtons();
    ctx.save();
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, L.W, L.H);

    if (st.mode === 'scale' && DG.scaleOut) {
      DG.scaleOut.render(ctx, st, sol, P.clamp(st.scaleOut ? st.scaleOut.prog : 0, 0, 1));
      ctx.restore();
      updateReadout(sol);
      return;
    }

    if (st.mode === 'slit' && DG.modeSlit) {
      DG.modeSlit.render(ctx, st);
    } else if (st.mode === 'field' && DG.modeField) {
      DG.modeField.render(ctx, st, sol, sc);
    } else if (st.mode === 'wave' && DG.modeWave) {
      DG.modeWave.render(ctx, st, sol, sc);
    } else if (st.mode === 'deltax' && DG.modeDeltax) {
      DG.modeDeltax.render(ctx, st, sol, sc);
    } else {
      DG.modePath.render(ctx, st, sol, sc, st.step);
    }
    if (st.mode === 'path' || st.mode === 'wave') {
      var glow = (st.mode === 'path' && DG.modePath) ? DG.modePath.pathGlow(st) : 0;
      D.unwrapBand(ctx, st, sol, glow);
    }
    ctx.restore();

    updateReadout(sol);
  }

  function loop(now) {
    var dt = lastFrame ? Math.min(0.05, (now - lastFrame) / 1000) : 0;
    lastFrame = now;
    st.nowSec += dt;
    if (st.playing) st.t += dt * (st.slow ? 0.25 : 1);
    if (st.mode === 'scale' && st.scaleOut && DG.scaleOut && !st.scaleOut.paused) {
      st.scaleOut.prog += dt / DG.scaleOut.DUR * (st.scaleOut.slow ? 0.35 : 1);
      if (st.scaleOut.prog >= 1) {          // 最後まで来たら止める
        st.scaleOut.prog = 1;
        st.scaleOut.paused = true;
        updateScaleBtns();
      } else {
        syncSceneBtns();
      }
    }
    render();
    requestAnimationFrame(loop);
  }

  /* ---------- 図の上での操作（スクリーンをクリック／ドラッグ） ---------- */
  function canvasPos(ev) {
    var c = $('view'), r = c.getBoundingClientRect();
    var pt = (ev.touches && ev.touches[0]) ? ev.touches[0] : ev;
    return { x: (pt.clientX - r.left) * L.W / r.width, y: (pt.clientY - r.top) * L.H / r.height };
  }
  /** スクリーンの上（クリック・ドラッグで見る方向を選べる範囲）か。
      ①②は同じレイアウトなので、判定も同じ。 */
  function inScreenZone(pos) {
    if (st.mode !== 'path' && st.mode !== 'wave') return false;
    return pos.x > L.SX - 60 && pos.x < L.SX + L.SCR_W + 70
      && pos.y > L.CY - L.SH - 10 && pos.y < L.CY + L.SH + 10;
  }
  /** スクリーン上の y から見る方向を決める */
  function setDirFromY(y) {
    var sol0 = P.solve(st);
    var sc = D.buildScene(st, sol0);
    var xm = (L.CY - y) / sc.ppm;                 // スクリーン上の位置 [m]
    var theta = P.thetaFromX(xm, st.L);
    var s = Math.sin(theta);
    if (st.onlyBright) {
      var mMax = P.maxOrder(st.lambda, st.d);
      var k = Math.round(s * st.d / st.lambda);
      st.m = P.clamp(k, -mMax, mMax);
      st.sinT = P.sinThetaOf(st.m, st.lambda, st.d);
    } else {
      st.sinT = P.clamp(s, -0.995, 0.995);
      st.m = Math.round(st.sinT * st.d / st.lambda);
    }
    syncOrderBtns();
  }

  function bindPointer() {
    var c = $('view');
    function down(ev) {
      if (st.mode === 'scale') return;     // 実寸のあいだは図の操作をしない
      var pos = canvasPos(ev);
      var hit = D.hitButton(pos.x, pos.y);
      if (hit) {
        if (hit === 'pulse-path') {
          st.pulse = { kind: 'path', t0: st.nowSec };
        } else if (hit === 'scrx') {
          st.dragging = 'scr';                 // スクリーンを左右に動かす
        } else if (hit.indexOf('ord:') === 0) {
          // スクリーン脇の「m = 1」などのラベルをクリックしたら、その次数を見る
          var k = Math.abs(parseInt(hit.slice(4), 10));
          st.m = k;
          st.sinT = P.sinThetaOf(k, st.lambda, st.d);
          syncOrderBtns();
        }
        render();
        ev.preventDefault();
        return;
      }
      if (st.mode === 'field' && DG.modeField && DG.modeField.inField(st, pos.x, pos.y)) {
        st.dragging = 'p';
        DG.modeField.setPoint(st, pos.x, pos.y);
        render();
        ev.preventDefault();
        return;
      }
      if (st.mode === 'slit' && DG.modeSlit && DG.modeSlit.inField(st, pos.x, pos.y)) {
        st.dragging = 'p';
        DG.modeSlit.setPoint(st, pos.x, pos.y);
        render();
        ev.preventDefault();
        return;
      }
      if (!inScreenZone(pos)) return;
      st.dragging = true;
      setDirFromY(pos.y);
      render();
      ev.preventDefault();
    }
    function move(ev) {
      if (st.mode === 'scale') { c.classList.remove('grab'); return; }
      var pos = canvasPos(ev);
      st.hoverBtn = D.hitButton(pos.x, pos.y);
      var overField = (st.mode === 'field' && DG.modeField && DG.modeField.inField(st, pos.x, pos.y))
        || (st.mode === 'slit' && DG.modeSlit && DG.modeSlit.inField(st, pos.x, pos.y));
      c.classList.toggle('grab', inScreenZone(pos) || overField || !!st.hoverBtn);
      if (!st.dragging) return;
      if (st.dragging === 'scr') {
        (st.mode === 'slit' ? DG.modeSlit : DG.modeField).moveScreen(st, pos.x);
      }
      else if (st.mode === 'field') DG.modeField.setPoint(st, pos.x, pos.y);
      else if (st.mode === 'slit') DG.modeSlit.setPoint(st, pos.x, pos.y);
      else setDirFromY(pos.y);
      render();
      ev.preventDefault();
    }
    function up() { st.dragging = false; }
    c.addEventListener('mousedown', down);
    c.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
    c.addEventListener('touchstart', down, { passive: false });
    c.addEventListener('touchmove', move, { passive: false });
    window.addEventListener('touchend', up);
    c.addEventListener('mouseleave', function () { c.classList.remove('grab'); });
  }

  /* ---------- 数値表示 ---------- */
  function pad(v, digits, width) {
    var s = v.toFixed(digits);
    while (s.length < width) s = ' ' + s;
    return s;
  }

  function updateReadout(sol) {
    el.oSin.textContent = pad(sol.sinT, 3, 6);
    el.oTh.textContent = pad(sol.thetaDeg, 2, 6) + ' °';
    el.oDelta.textContent = pad(sol.delta, 0, 6) + ' nm';
    el.oRatio.textContent = pad(sol.ratio, 2, 6) + ' λ';
    el.oX.textContent = pad(sol.x * 100, 1, 7) + ' cm';
    el.oInt.textContent = pad(sol.I, 3, 5);
    el.oMmax.textContent = pad(sol.mMax, 0, 4);
    var sc = D.buildScene(st, sol);
    el.oRange.textContent = '±' + pad(sc.halfM * 100, 0, 3) + ' cm';
    updateDirNote(sol, sc);
    updateSteps(sol, sc);
    updatePanel(sol);
  }

  /* ---------- ステップの説明（図の下・4 つとも出す） ---------- */
  function comma(n) {
    var s = String(Math.round(n)), out = '';
    for (var i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 === 0) out += ',';
      out += s.charAt(i);
    }
    return out;
  }
  var lastStepKey = '';
  function updateSteps(sol, sc) {
    var key = [st.step, st.lambda, st.d, st.L, sol.sinT.toFixed(5), sol.kind].join('|');
    if (key !== lastStepKey) {
      lastStepKey = key;
      var lines = Math.round(P.linesPerCmFromD(st.d));
      var times = Math.round(st.L * 1e9 / st.d / 1000) * 1000;
      // ① 平行とみなせるわけ ＋ 経路差
      $('sv1').innerHTML = 'd = ' + (st.d / 1000).toFixed(2) + ' μm（' + comma(lines) + ' 本/cm）、'
        + 'L = ' + st.L.toFixed(2) + ' m　→　L は d の約 ' + comma(times) + ' 倍<br>'
        + 'θ = ' + sol.thetaDeg.toFixed(2) + '° のとき　'
        + 'd sinθ = ' + (st.d / 1000).toFixed(2) + ' μm × ' + sol.sinT.toFixed(3)
        + ' = ' + Math.round(Math.abs(sol.delta)) + ' nm';
      var s2 = 'いまは ' + D.about(Math.abs(sol.ratio)) + ' λ　→　'
        + (sol.kind === 'strong' ? 'm = ' + sol.m + ' の明線' : '明線になりません');
      if (sol.mMax === 0) {
        s2 += '<br><span class="ng">sinθ = λ/d = ' + (st.lambda / st.d).toFixed(2)
          + ' > 1 なので、1 次以上の明線は存在しません</span>';
      }
      $('sv2').innerHTML = s2;
      var s3 = 'x = ' + st.L.toFixed(2) + ' m × tan ' + sol.thetaDeg.toFixed(2) + '° = '
        + D.fmtLenM(Math.abs(sol.x));
      if (!sc.pOn) s3 += '（スクリーン ±' + D.fmtCm(sc.halfM) + ' の外）';
      $('sv3').textContent = s3;

      // ここから下（.on の付け替えと #stepnow への複製）も key が変わったときだけ行う。
      // 毎フレームやると innerHTML の作り直しで図の DOM が入れかわり続け、
      // ホバー拡大が効かない・むだな再構築が走る、という不具合になる。
      var boxes = document.querySelectorAll('.stepbox');
      for (var i = 0; i < boxes.length; i++) {
        boxes[i].classList.toggle('on', parseInt(boxes[i].getAttribute('data-step'), 10) === st.step);
      }
      // 図の上にも、いま見ているステップの説明を出す。
      // 下までスクロールしないと読めない、ということがないように、同じ文をここにも置く。
      var cur = document.querySelector('.stepbox[data-step="' + st.step + '"]');
      if (cur) {
        $('sn-title').innerHTML = cur.querySelector('b').innerHTML;
        $('sn-body').innerHTML = cur.querySelector('.sb').innerHTML;
        $('sn-val').innerHTML = cur.querySelector('.sv').innerHTML;
        // ステップに図（.fig）があれば、この右上のカードにも同じ図を出す。
        // 図のあるステップでは hasfig クラスで「図は左に小さく・文章は右」の
        // 2 カラム配置に切りかわる（CSS 側。数値の行もそのとき隠れる）。
        var fig = cur.querySelector('.fig');
        var snFig = $('sn-fig');
        if (snFig) {
          snFig.innerHTML = fig ? fig.innerHTML : '';
          snFig.hidden = !fig;
        }
        $('stepnow').classList.toggle('hasfig', !!fig);
      }
    }
  }

  var lastDirKey = '';
  function updateDirNote(sol, sc) {
    var key = [sol.m, sol.mMax, sol.kind, sol.ratio.toFixed(2), sc.pOn, st.onlyBright].join('|');
    if (key === lastDirKey) return;
    lastDirKey = key;
    var s;
    // 2 行目は、強めあうときも弱めあうときも必ず出す（欄の高さが変わらないように）。
    // 明るさが中間のとき（kind === 'mid'）に「打ち消しあって暗くなる」と言い切るのは
    // 言い過ぎなので、明るさに応じて 3 段階で文言を変える。
    var whyText;
    if (sol.kind === 'strong') {
      whyText = '経路差が λ の整数倍なので、多数のスリットからの波が<b>強め合い、強く光ります</b>。';
    } else if (sol.kind === 'weak') {
      whyText = 'λ の整数倍から大きくずれているので、多数のスリットからの波が少しずつずれて'
        + '<b>打ち消しあい、ほとんど真っ暗になります</b>。';
    } else {
      whyText = 'λ の整数倍からずれているので、波は<b>完全にはそろいません</b>。'
        + '明線よりは暗く、ずれが大きいほど暗くなります。';
    }
    var why = '<span class="why">' + whyText + '</span>';
    if (st.onlyBright) {
      s = 'いまは <b>m = ' + sol.m + '</b> の明線の方向を見ています。'
        + '経路差 ＝ <span class="st">' + D.about(Math.abs(sol.ratio)) + ' λ</span>　'
        + '（θ = ' + sol.thetaDeg.toFixed(2) + '°）';
      s += !sc.pOn
        ? '<br>この明線は<b>スクリーンの外</b>です（x = ' + D.fmtLenM(Math.abs(sol.x)) + '）。'
        : '<br>' + why;
    } else {
      s = '経路差 ＝ <span class="' + (sol.kind === 'strong' ? 'st' : 'wk') + '">'
        + D.about(Math.abs(sol.ratio)) + ' λ</span>　→　<b>' + sol.label + '</b>'
        + '（明るさ ' + (sol.I * 100).toFixed(1) + ' %）';
      s += '<br>' + why;
    }
    if (sol.mMax === 0) {
      s += '<br><b>sinθ = λ/d = ' + (st.lambda / st.d).toFixed(2) + ' > 1</b> なので、1 次以上の明線は存在しません。';
    }
    el.dirNote.innerHTML = s;
  }

  /* ---------- 解説パネル（KaTeX） ---------- */
  var lastPanelKey = '';
  function updatePanel(sol) {
    var key = [sol.m, sol.mMax, sol.ratio.toFixed(3), sol.x.toFixed(4), st.lambda, st.d].join('|');
    if (key === lastPanelKey) return;
    lastPanelKey = key;

    el.condMsg.innerHTML = '<div style="width:100%;text-align:center">'
      + tex('d\\sin\\theta = ' + Math.round(Math.abs(sol.delta)) + '\\,\\mathrm{nm} = '
        + Math.abs(sol.ratio).toFixed(2) + '\\lambda')
      + '<div class="note">→ いまは <b>' + sol.label + '</b></div></div>';

    el.nowMsg.innerHTML = '<div style="width:100%;text-align:center">'
      + tex('x = ' + sol.L.toFixed(2) + '\\times\\tan ' + sol.thetaDeg.toFixed(2) + '^\\circ = '
        + (sol.x * 100).toFixed(1) + '\\,\\mathrm{cm}')
      + '</div>';
  }

  function tex(s) {
    try {
      return katex.renderToString(s, { throwOnError: false, displayMode: false });
    } catch (e) {
      return '<span class="note">' + s + '</span>';
    }
  }
  function renderStaticTex() {
    var nodes = document.querySelectorAll('.eq[data-tex]');
    for (var i = 0; i < nodes.length; i++) {
      nodes[i].innerHTML = tex(nodes[i].getAttribute('data-tex'));
    }
  }

  /* ---------- スライダー ---------- */
  function updateSwatch() {
    var c = P.wavelengthToRGB(st.lambda);
    $('sw-lambda').style.background = P.rgbCss(c);
    $('v-lamcol').textContent = '（' + P.colorName(st.lambda) + '色）';
  }
  var N_NOTE = { 2: '（2 本＝ヤングの実験）', 10: '（まだ明線は太い）',
    100: '（かなり細くなる）', 1000: '（実際の格子なみ）' };
  function syncN() {
    var i = N_STEPS.indexOf(st.N);
    if (i < 0) i = 1;
    $('sl-N').value = i;
    $('v-N').textContent = String(st.N);
    $('v-Nnote').textContent = N_NOTE[st.N] || '';
  }
  function syncD() {
    var lines = Math.round(P.linesPerCmFromD(st.d));
    $('sl-d').value = st.d;
    $('v-d').textContent = (st.d / 1000).toFixed(2);
    $('v-lines').textContent = '（' + comma(lines) + ' 本/cm）';
  }
  /* 単スリットモード：点の数 K は、きりのよい値から選ぶ。
     入試問題の「2N 等分」に合わせて偶数だけ（K ＝ 2N。K = 2 が N = 1、K = 4 が N = 2） */
  var K_STEPS = [2, 4, 6, 10, 30, 100];
  var K_NOTE = { 2: '（問題の N ＝ 1・図9）', 4: '（問題の N ＝ 2・図10）',
    10: '（だいぶ近い）', 30: '（ほぼ本物）', 100: '（本物と見分けがつかない）' };
  function syncK() {
    var i = K_STEPS.indexOf(st.K);
    if (i < 0) i = 0;
    $('sl-K').value = i;
    $('v-K').textContent = String(st.K);
    $('v-Knote').textContent = K_NOTE[st.K] || '';
  }
  function syncA() {
    $('sl-a').value = st.slitA;
    $('v-a').textContent = (st.slitA / 1000).toFixed(2);
    $('v-aLam').textContent = '（＝ ' + (st.slitA / st.lambda).toFixed(1) + ' λ）';
  }
  function syncAll() {
    $('sl-lambda').value = st.lambda;
    $('v-lambda').textContent = String(Math.round(st.lambda));
    $('sl-L').value = st.L;
    $('v-L').textContent = st.L.toFixed(2);
    syncD();
    syncN();
    syncK();
    syncA();
    updateSwatch();
    syncOrderBtns();
    $('ck-only').checked = st.onlyBright;
    $('ck-only3').checked = st.onlyBright;
    $('lb-only').classList.toggle('on', st.onlyBright);
    $('lb-only3').classList.toggle('on', st.onlyBright);
    updateOnlyTapText(st.onlyBright);
    setLight(st.light);
  }
  /* チェックが外れている（＝明線以外も選べる）ときは、
     もう「クリックして」と誘う必要がないので、いまの状態を伝える文に変える */
  function updateOnlyTapText(on) {
    var t = on
      ? '← ここをクリックして、明線以外の点はどうなっているのか見てみよう！'
      : '現在、明線もそれ以外も選べます';
    var a = $('only-tap'), b = $('only3-tap');
    if (a) a.textContent = t;
    if (b) b.textContent = t;
  }

  /* ---------- 見る方向のボタン ---------- */
  var MMAX_BTN = 4;          // ボタンに出す最大の次数
  function buildOrderBtns() {
    var mMax = P.maxOrder(st.lambda, st.d);
    var key = 'm' + mMax + '|' + Math.round(st.lambda) + '|' + Math.round(st.d);
    if (key === lastOrderKey) return;
    lastOrderKey = key;
    var root = $('order-btns');
    root.innerHTML = '';
    for (var k = 0; k <= MMAX_BTN; k++) {
      (function (k) {
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'ctl ord';
        b.textContent = 'm = ' + k;
        b.setAttribute('data-m', String(k));
        if (k > mMax) {
          // sinθ = mλ/d > 1 になる次数は存在しないので押せない
          b.disabled = true;
          b.title = 'sinθ = ' + (k * st.lambda / st.d).toFixed(2) + ' > 1 なので出ません';
        } else {
          b.addEventListener('click', function () {
            st.m = k;
            st.sinT = P.sinThetaOf(k, st.lambda, st.d);
            syncOrderBtns();
            render();
          });
        }
        root.appendChild(b);
      })(k);
    }
    // 注記は右上へ（小さく・目立たなく）
    $('ord-note').textContent = (mMax >= MMAX_BTN)
      ? '（下側にも同じ明線が出ます）'
      : '（m = ' + (mMax + 1) + ' 以上は sinθ > 1 で出ません。d を大きくすると出ます）';
  }

  function syncOrderBtns() {
    buildOrderBtns();
    var bs = $('order-btns').querySelectorAll('.ord');
    for (var i = 0; i < bs.length; i++) {
      var k = parseInt(bs[i].getAttribute('data-m'), 10);
      bs[i].setAttribute('aria-pressed', (k === Math.abs(st.m) && st.onlyBright) ? 'true' : 'false');
    }
  }

  /* ---------- モード ---------- */
  function setMode(m) {
    if (m === st.mode) return;
    var leavingDeltax = (st.mode === 'deltax');
    var leavingField = (st.mode === 'field');
    st.mode = m;
    /* N′ は「補足：多数の格子からの波がどう重なり合うか」専用の設定として扱う。
     * このモードで N′ を変えても、ほかのモード（①②のスクリーンの明るさ・
     * 強度分布・強めあい判定）に影響しないよう、出入りで退避・復元する。
     * このモード自身の選択（st.NField）は次に入ったときのために覚えておく。 */
    if (leavingField) {
      st.NField = st.N;                        // 補足モードでの選択を保存
      if (st.savedNBeforeField != null) {
        st.N = st.savedNBeforeField;           // ほかのモードの N′ に戻す
        st.savedNBeforeField = null;
      }
    }
    if (m === 'field') {
      st.savedNBeforeField = st.N;             // 入る前の N′ を退避
      if (st.NField != null) st.N = st.NField; // 前回の補足モードでの選択を復元
    }
    if (m === 'deltax' && DG.modeDeltax) {
      // このモードは装置の設定を固定する（③ ステップ④の説明に合わせた値）。
      // 入る前の設定を覚えておき、このモードを出るときにそのまま元へ戻す。
      st.savedBeforeDeltax = {
        d: st.d, lambda: st.lambda, L: st.L, m: st.m,
        onlyBright: st.onlyBright, light: st.light, sinT: st.sinT
      };
      st.d = DG.modeDeltax.DX_D;
      st.lambda = DG.modeDeltax.DX_LAM;
      st.L = DG.modeDeltax.DX_L;
      st.m = DG.modeDeltax.DX_M;
      st.onlyBright = true;
      st.light = 'mono';
      st.sinT = P.sinThetaOf(st.m, st.lambda, st.d);
    } else if (leavingDeltax && st.savedBeforeDeltax) {
      var sv = st.savedBeforeDeltax;
      st.d = sv.d; st.lambda = sv.lambda; st.L = sv.L; st.m = sv.m;
      st.onlyBright = sv.onlyBright; st.light = sv.light; st.sinT = sv.sinT;
      st.savedBeforeDeltax = null;
    }
    syncAll();
    applyModeUI(m);
    if (m === 'deltax' && DG.modeDeltax) DG.modeDeltax.updateNotes();
    updateScreenNote();
  }

  /**
   * 図の下の欄外に、「スクリーン」（投影する板）の大きさの概算を書く。
   * 図の中には両矢印も数値も描かない、という方針（ユーザー指示）。
   *   ①② … 板の半分 ＝ L.HALF_M [m]（固定）
   *   ③   … 板の半分 ＝ DG.modeDeltax.HALF_M [m]（固定）
   *   補足（field）… 板の高さ [px] × 縮尺 nmPerPx（d で変わる）
   *   実験の概要 … 縮尺がどんどん変わるモードなので出さない
   */
  function updateScreenNote() {
    var el2 = $('screen-note');
    if (!el2) return;
    var txt = null;
    if (st.mode === 'path' || st.mode === 'wave') {
      txt = '約 ' + Math.round(L.HALF_M * 2 * 100) + ' cm';
    } else if (st.mode === 'deltax' && DG.modeDeltax) {
      txt = '約 ' + Math.round(DG.modeDeltax.HALF_M * 2 * 100) + ' cm';
    } else if (st.mode === 'field' && DG.modeField) {
      var FL2 = DG.modeField.FL;
      var nm = (FL2.y1 - FL2.y0) * DG.modeField.nmPerPx(st);
      txt = (nm < 1e6) ? ('約 ' + Math.round(nm / 1000) + ' μm')
                       : ('約 ' + (nm / 1e6).toFixed(2) + ' mm');
    } else if (st.mode === 'slit' && DG.modeSlit) {
      var FL3 = DG.modeSlit.FL;
      var nm2 = (FL3.y1 - FL3.y0) * DG.modeSlit.nmPerPx(st);
      txt = (nm2 < 1e6) ? ('約 ' + Math.round(nm2 / 1000) + ' μm')
                        : ('約 ' + (nm2 / 1e6).toFixed(2) + ' mm');
    }
    el2.hidden = (txt === null);
    if (txt !== null) {
      el2.textContent = '※ 図の「スクリーン」（投影する板）の大きさは、縦 ' + txt + ' です';
    }
  }

  /* ---------- 入試問題の重ね窓（単スリットモード） ----------
   * celestial-mechanics.html の「問題はこちら／解答と解き方はこちら」と同じ作法。
   * 並び順は「問題 → 解答」。先に解答が目に入らないように、色も分けてある。 */
  function openProbOv(id) {
    closeProbOv();
    var ov = $(id);
    if (ov) ov.hidden = false;
  }
  function closeProbOv() {
    var ids = ['probov-slit', 'probov-slitans'];
    for (var i = 0; i < ids.length; i++) {
      var ov = $(ids[i]);
      if (ov) ov.hidden = true;
    }
  }

  /** モードごとの出し入れ（はじめの 1 回もここを通す） */
  function applyModeUI(m) {
    var TABS = { path: 'tab-path', wave: 'tab-wave', deltax: 'tab-deltax', field: 'tab-field', scale: 'tab-scale', slit: 'tab-slit' };
    for (var kk in TABS) {
      if (Object.prototype.hasOwnProperty.call(TABS, kk)) {
        $(TABS[kk]).setAttribute('aria-selected', m === kk ? 'true' : 'false');
      }
    }
    var anim = (m === 'wave' || m === 'field' || m === 'slit');
    $('grp-path').hidden = (m !== 'path');
    $('toprow').hidden = (m === 'path' || m === 'deltax');   // ①・③では上の操作列に出すものがない
    $('grp-wave').hidden = !anim;
    $('grp-settings').hidden = (m === 'deltax' || m === 'scale');    // ③・実験の概要は装置の設定を固定値として扱うので隠す
    $('grp-light').hidden = (m === 'scale');
    $('grp-seg').hidden = (m === 'scale' || m === 'field' || m === 'slit');
    $('sl-drow').hidden = (m === 'slit');      // 単スリットでは d ではなく幅 a を使う
    $('sl-Lrow').hidden = (m === 'slit');      // 距離はスクリーンのドラッグで変える
    $('sl-Krow').hidden = (m !== 'slit');
    $('sl-arow').hidden = (m !== 'slit');
    $('lb-sum').hidden = (m !== 'wave');
    $('lb-gamma').hidden = (m !== 'wave');
    $('lb-mx').hidden = (m !== 'field');
    $('lb-min').hidden = (m !== 'field');
    $('lb-only3').hidden = (m !== 'field');
    $('lb-dark').hidden = (m !== 'slit');
    $('lb-env').hidden = (m !== 'slit');
    $('lb-lab').hidden = (m === 'scale' || m === 'deltax' || m === 'slit');
    $('sl-Nrow').hidden = (m !== 'field');
    $('lb-wave').hidden = (m !== 'path');
    $('steps').hidden = (m !== 'path');
    $('stepnow').hidden = (m !== 'path');
    $('wavenotes').hidden = (m !== 'wave');
    $('fieldnotes').hidden = (m !== 'field');
    $('slitnotes').hidden = (m !== 'slit');
    $('scalenotes').hidden = (m !== 'scale');
    $('deltaxnotes').hidden = (m !== 'deltax');
    $('dirbox').hidden = (m === 'field' || m === 'scale' || m === 'deltax' || m === 'slit');
    $('nbox').hidden = (m !== 'field');
    $('slitbox').hidden = (m !== 'slit');
    $('slitprob').hidden = (m !== 'slit');
    if (m !== 'slit') closeProbOv();
    $('scalebox').hidden = (m !== 'scale');
    $('deltaxbox').hidden = (m !== 'deltax');
    $('readout').hidden = (m === 'scale' || m === 'deltax' || m === 'slit');
    // 補足モードでは白色光は使わない（重なりあいの計算は単色光で考える）
    $('btn-white').disabled = (m === 'field' || m === 'slit');
    $('btn-white').title = (m === 'field' || m === 'slit')
      ? 'このモードは単色光で考えます' : '';
    if ((m === 'field' || m === 'slit') && st.light === 'white') setLight('mono');
    if (m === 'scale') startScale(); else st.scaleOut = null;
    updateScaleBtns();
    if (!anim) { st.playing = false; updatePlayBtn(); }
  }

  function setLight(l) {
    st.light = l;
    $('btn-mono').setAttribute('aria-pressed', l === 'mono' ? 'true' : 'false');
    $('btn-white').setAttribute('aria-pressed', l === 'white' ? 'true' : 'false');
  }

  /** スマホ用「図だけを大きく表示」 */
  function setFigFull(on) {
    st.figFull = !!on;
    document.body.classList.toggle('fig-full', st.figFull);
    var b = $('btn-figfull');
    if (b) {
      b.textContent = st.figFull ? '✕ 閉じる' : '⛶ 図だけを大きく表示';
      b.setAttribute('aria-pressed', st.figFull ? 'true' : 'false');
    }
    render();
  }

  function updatePlayBtn() {
    var b = $('btn-play');
    b.textContent = st.playing ? '⏸ 一時停止' : '▶ スタート';
    // 動き出したら、もう「押してみよう」の発光は消す
    b.classList.toggle('nextcta', !st.playing);
  }

  function setStep(n) {
    n = P.clamp(Math.round(n), 1, 4);
    if (n !== st.step && n >= 2) st.stepPulse = { step: n, t0: st.nowSec };
    if (n === 1) st.stepPulse = null;
    st.step = n;
    updateStepLabel();
  }
  function updateStepLabel() {
    $('step-label').textContent = 'ステップ ' + st.step + ' / 4';
    $('btn-prev').disabled = (st.step <= 1);
    var atLast = (st.step >= 4);
    var hasDeltax = !!DG.modeDeltax;
    $('btn-next').disabled = atLast && !hasDeltax;
    $('btn-next').textContent = (atLast && hasDeltax) ? '③ Δx を導く ▶' : '次へ ▶';
  }

  /* ---------- 「🔍 実寸」オーバーレイ ---------- */
  var lastSceneKey = '';
  function buildSceneBtns() {
    var root = $('scale-scenes');
    if (!root || root.childNodes.length || !DG.scaleOut) return;
    for (var i = 0; i < DG.scaleOut.SCENES.length; i++) {
      (function (i) {
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'ctl ord';
        // せまい画面では番号だけにする（名まえは CSS で隠す）
        b.innerHTML = (i + 1) + '<span class="sc-name">. '
          + DG.scaleOut.SCENES[i] + '</span>';
        b.setAttribute('data-sc', String(i));
        b.addEventListener('click', function () { jumpScene(i); });
        root.appendChild(b);
      })(i);
    }
  }
  function syncSceneBtns() {
    if (!DG.scaleOut) return;
    var s = st.scaleOut ? DG.scaleOut.sceneOf(P.clamp(st.scaleOut.prog, 0, 1)) : -1;
    if (String(s) === lastSceneKey) return;
    lastSceneKey = String(s);
    var bs = $('scale-scenes').querySelectorAll('.ord');
    for (var i = 0; i < bs.length; i++) {
      var k = parseInt(bs[i].getAttribute('data-sc'), 10);
      bs[i].setAttribute('aria-pressed', k === s ? 'true' : 'false');
    }
  }
  function jumpScene(i) {
    if (!st.scaleOut) return;
    st.scaleOut.prog = i / 4;
    st.scaleOut.paused = false;
    updateScaleBtns(); syncSceneBtns(); render();
  }
  function updateScaleBtns() {
    var on = (st.mode === 'scale' && !!st.scaleOut);
    $('grp-scale').hidden = !on;
    if (!on) return;
    $('btn-scale-pause').textContent = st.scaleOut.paused ? '▶ 再生' : '⏸ 一時停止';
    $('btn-scale-slow').setAttribute('aria-pressed', st.scaleOut.slow ? 'true' : 'false');
  }
  /** 「実験の概要」タブに入ったとき。すぐには動かさず、▶ を押してもらう */
  function startScale() {
    if (!DG.scaleOut) return;
    st.scaleOut = { prog: 0, paused: true, slow: false };
    buildSceneBtns();
    lastSceneKey = '';
    syncSceneBtns();
  }

  /* ---------- 初期化 ---------- */
  function init() {
    el = {
      oSin: $('o-sin'), oTh: $('o-th'), oDelta: $('o-delta'), oRatio: $('o-ratio'),
      oX: $('o-x'), oInt: $('o-int'), oMmax: $('o-mmax'), oRange: $('o-range'),
      dirNote: $('dir-note'), condMsg: $('cond-msg'), nowMsg: $('now-msg')
    };

    setupCanvas();
    renderStaticTex();
    bindPointer();

    $('sl-lambda').addEventListener('input', function () {
      st.lambda = parseFloat(this.value);
      $('v-lambda').textContent = String(Math.round(st.lambda));
      updateSwatch(); syncOrderBtns(); syncA();
    });
    $('sl-N').addEventListener('input', function () {
      st.N = N_STEPS[P.clamp(parseInt(this.value, 10), 0, N_STEPS.length - 1)];
      syncN();
    });
    $('sl-K').addEventListener('input', function () {
      st.K = K_STEPS[P.clamp(parseInt(this.value, 10), 0, K_STEPS.length - 1)];
      syncK();
      if (st.fyS !== null && DG.modeSlit) DG.modeSlit.setPoint(st, 0, st.fyS);
    });
    $('sl-a').addEventListener('input', function () {
      st.slitA = parseFloat(this.value);
      syncA();
      if (st.fyS !== null && DG.modeSlit) DG.modeSlit.setPoint(st, 0, st.fyS);
      updateScreenNote();   // 単スリットモードのスクリーンの実寸は a で変わる
    });
    $('sl-d').addEventListener('input', function () {
      st.d = parseFloat(this.value);
      syncD(); syncOrderBtns();
      updateScreenNote();   // 補足モードのスクリーンの実寸は d で変わる
    });
    $('sl-L').addEventListener('input', function () {
      st.L = parseFloat(this.value);
      $('v-L').textContent = st.L.toFixed(2);
    });

    /* ＋ − ボタン。スライダーの 1 目もりずつ動かす（細かく合わせたいとき用） */
    function nudge(btnId, slId, dir) {
      $(btnId).addEventListener('click', function () {
        var sl = $(slId);
        var stp = parseFloat(sl.step) || 1;
        var v = parseFloat(sl.value) + dir * stp;
        v = P.clamp(v, parseFloat(sl.min), parseFloat(sl.max));
        sl.value = v;
        sl.dispatchEvent(new Event('input', { bubbles: true }));
        render();
      });
    }
    nudge('lam-dn', 'sl-lambda', -1); nudge('lam-up', 'sl-lambda', 1);
    nudge('d-dn', 'sl-d', -1); nudge('d-up', 'sl-d', 1);
    nudge('L-dn', 'sl-L', -1); nudge('L-up', 'sl-L', 1);
    nudge('N-dn', 'sl-N', -1); nudge('N-up', 'sl-N', 1);
    nudge('K-dn', 'sl-K', -1); nudge('K-up', 'sl-K', 1);
    nudge('a-dn', 'sl-a', -1); nudge('a-up', 'sl-a', 1);

    $('tab-path').addEventListener('click', function () { setMode('path'); });
    $('tab-wave').addEventListener('click', function () { setMode('wave'); });
    $('tab-deltax').addEventListener('click', function () { setMode('deltax'); });
    $('tab-field').addEventListener('click', function () { setMode('field'); });
    $('tab-slit').addEventListener('click', function () { setMode('slit'); });
    $('ck-mx').addEventListener('change', function () { st.showMaxima = this.checked; });
    $('ck-min').addEventListener('change', function () { st.showMinima = this.checked; });
    $('ck-dark').addEventListener('change', function () { st.showDark = this.checked; });
    $('ck-env').addEventListener('change', function () { st.showEnv = this.checked; });
    $('btn-mono').addEventListener('click', function () { setLight('mono'); });
    $('btn-white').addEventListener('click', function () { setLight('white'); });

    $('btn-prev').addEventListener('click', function () { setStep(st.step - 1); });
    $('btn-next').addEventListener('click', function () {
      if (st.step >= 4) {
        if (DG.modeDeltax) setMode('deltax');
      } else {
        setStep(st.step + 1);
      }
    });
    $('btn-step-reset').addEventListener('click', function () { setStep(1); });

    $('btn-play').addEventListener('click', function () { st.playing = !st.playing; updatePlayBtn(); });
    $('btn-slow').addEventListener('click', function () {
      st.slow = !st.slow;
      this.setAttribute('aria-pressed', st.slow ? 'true' : 'false');
    });
    $('btn-reset').addEventListener('click', function () { st.t = 0; st.playing = false; updatePlayBtn(); });

    function setOnlyBright(on) {
      st.onlyBright = on;
      $('ck-only').checked = on;
      $('ck-only3').checked = on;
      $('lb-only').classList.toggle('on', on);
      $('lb-only3').classList.toggle('on', on);
      updateOnlyTapText(on);
      if (on) {
        st.sinT = P.sinThetaOf(st.m, st.lambda, st.d);
        // モード③では、点 P を「いちばん近い明線の上」に寄せる
        if (st.mode === 'field' && DG.modeField) DG.modeField.snap(st);
      }
      syncOrderBtns();
      render();
    }
    $('ck-only').addEventListener('change', function () { setOnlyBright(this.checked); });
    $('ck-only3').addEventListener('change', function () { setOnlyBright(this.checked); });
    $('ck-lab').addEventListener('change', function () { st.showLabels = this.checked; });
    $('ck-wave').addEventListener('change', function () { st.showWave = this.checked; });
    $('ck-gamma').addEventListener('change', function () { st.gammaOn = this.checked; });
    $('ck-sum').addEventListener('change', function () { st.showSum = this.checked; });

    var boxes = document.querySelectorAll('.stepbox');
    for (var bi = 0; bi < boxes.length; bi++) {
      (function (b) {
        b.addEventListener('click', function () {
          setStep(parseInt(b.getAttribute('data-step'), 10));
          render();
        });
      })(boxes[bi]);
    }

    $('btn-figfull').addEventListener('click', function () { setFigFull(!st.figFull); });
    document.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape' && st.figFull) setFigFull(false);
    });

    $('tab-scale').addEventListener('click', function () { setMode('scale'); });
    $('btn-scale-pause').addEventListener('click', function () {
      if (!st.scaleOut) return;
      if (st.scaleOut.paused && st.scaleOut.prog >= 1) st.scaleOut.prog = 0;
      st.scaleOut.paused = !st.scaleOut.paused;
      updateScaleBtns();
    });
    $('btn-scale-slow').addEventListener('click', function () {
      if (!st.scaleOut) return;
      st.scaleOut.slow = !st.scaleOut.slow;
      updateScaleBtns();
    });
    $('btn-scale-reset').addEventListener('click', function () { jumpScene(0); });

    /* 「問題はこちら」「解答と解き方はこちら」の重ね窓 */
    $('btn-slit-prob').addEventListener('click', function () { openProbOv('probov-slit'); });
    $('btn-slit-ans').addEventListener('click', function () { openProbOv('probov-slitans'); });
    var xs = document.querySelectorAll('.probov-x');
    for (var xi = 0; xi < xs.length; xi++) {
      xs[xi].addEventListener('click', closeProbOv);
    }
    var ovs = document.querySelectorAll('.probov');
    for (var oi = 0; oi < ovs.length; oi++) {
      ovs[oi].addEventListener('click', function (ev) {
        if (ev.target === this) closeProbOv();   // まわりの暗いところを押したら閉じる
      });
    }
    document.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape') closeProbOv();
    });

    // まだ作っていない機能は押せないようにしておく
    if (!DG.modeField) { $('tab-field').disabled = true; }
    if (!DG.modeSlit) { $('tab-slit').disabled = true; }
    if (!DG.modeDeltax) { $('tab-deltax').disabled = true; }
    if (!DG.scaleOut) { $('tab-scale').disabled = true; }

    syncAll();
    applyModeUI(st.mode);
    updateStepLabel();
    updateScreenNote();
    requestAnimationFrame(loop);
  }

  return {
    init: init, state: st, render: render, RANGE: RANGE, setMode: setMode,
    /** 自動テスト用 */
    api: {
      set: function (patch) {
        for (var k in patch) if (Object.prototype.hasOwnProperty.call(patch, k)) st[k] = patch[k];
        syncAll(); render();
      },
      solve: function () { return P.solve(st); },
      scene: function () { return D.buildScene(st, P.solve(st)); },
      state: function () { return st; },
      setMode: setMode,
      setStep: function (n) { setStep(n); render(); },
      setLight: function (l) { setLight(l); render(); },
      setDirFromY: function (y) { setDirFromY(y); render(); },
      pulse: function (kind) { st.pulse = { kind: kind, t0: st.nowSec }; render(); },
      hitButton: function (x, y) { return D.hitButton(x, y); },
      clickAt: function (x, y) {
        var hit = D.hitButton(x, y);
        if (hit && hit.indexOf('ord:') === 0) {
          var k = Math.abs(parseInt(hit.slice(4), 10));
          st.m = k; st.sinT = P.sinThetaOf(k, st.lambda, st.d);
          syncOrderBtns(); render();
        }
        return hit;
      },
      figFull: function (on) { setFigFull(on); },
      inScreenZone: function (pos) { return inScreenZone(pos); },
      buttons: function () { render(); return D.buttons(); },
      setPoint: function (y) {
        var M = (st.mode === 'slit') ? DG.modeSlit : DG.modeField;
        if (M) { M.setPoint(st, 0, y); render(); }
      },
      moveScreen: function (x) {
        var M = (st.mode === 'slit') ? DG.modeSlit : DG.modeField;
        if (M) { M.moveScreen(st, x); render(); }
      },
      scaleTo: function (prog) {
        setMode('scale');
        st.scaleOut.prog = P.clamp(prog, 0, 1);
        st.scaleOut.paused = true;
        lastSceneKey = '';
        updateScaleBtns(); syncSceneBtns(); render();
      }
    }
  };
})();
