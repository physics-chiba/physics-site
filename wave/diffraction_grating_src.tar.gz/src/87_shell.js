/* =========================================================================
   87_shell.js … ページの骨組み（meter-bridge.html と同じ並び）を組み立てる（2026-11-16）
   ・見出しの帯（パンくず・題名・リード・コンテンツ一覧）
   ・上に固定するタブ列（タブそのものは 20_body.html に書いてある。ここでは見た目と動きだけ）
   ・章の扉（いま開いているモードの番号・英字の副題・名前・リード）
   ・コンテンツ一覧のパネル、暗い地のフッター、スライドバーの塗り、読み進みの線
   ページごとの文は 86_shellcfg.js（window.SHELL_CFG）。
   モードの切りかえそのものは、もとの 70_ui.js の setMode がおこなう。
   ここでは「どのタブが選ばれているか（aria-selected）」を見はって、章の扉などを合わせるだけ。
   ========================================================================= */
(function () {
  'use strict';
  var CFG = window.SHELL_CFG || {};
  var CIRC = '①②③④⑤⑥⑦⑧⑨';
  var HOME = 'https://physics-chiba.github.io/physics-site/';
  function $(id) { return document.getElementById(id); }
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function tabList() { return [].slice.call(document.querySelectorAll('#tabs .tab')); }
  function modeOf(b) { return b.id.replace(/^tab-/, ''); }
  /* 章の扉・目次に出す名前。タブ列では短い名前にしたモードは、data-full に長い名前を持たせてある */
  function nameOf(b) { var f = b.getAttribute('data-full'); if (f) return f; var t = b.querySelector('.tl'); return (t ? t.textContent : b.textContent).trim(); }
  function curTab() { var a = tabList(); for (var i = 0; i < a.length; i++) if (a[i].getAttribute('aria-selected') === 'true') return a[i]; return a[0] || null; }
  function modeCfg(id) { return (CFG.modes && CFG.modes[id]) || {}; }
  function secs() { return (CFG.secs || []).filter(function (s) { return $(s.id); }); }

  /* 本文の始まり（見出しの帯のすぐ下）。タブを押したらここまでもどす */
  function contentTop() { var h = $('hero'); return h ? h.offsetTop + h.offsetHeight : 0; }
  /* 上に固定したタブ列の高さ（固定していないときは 0） */
  function tabbarH() { var tb = $('tabs'); if (!tb) return 0; return (getComputedStyle(tb).position === 'sticky') ? tb.getBoundingClientRect().height : 0; }
  function scrollToEl(el) {
    var go = function () { if (!el) return; var y = el.getBoundingClientRect().top + window.pageYOffset - tabbarH() - 8; window.scrollTo({ top: Math.max(0, y), behavior: 'auto' }); };
    go(); requestAnimationFrame(function () { requestAnimationFrame(go); }); setTimeout(go, 180);
  }

  /* ---------- 見出しの帯 ---------- */
  function buildHero() {
    var hero = $('hero'); if (!hero) return;
    /* 20_body.html の <header id="hero"> の中に書いてある「このページの目的」（#heroAim）と「式の流れの図」（#heroFlow）を、
       いったん外して、組み立てた帯の中へ入れなおす（左＝題名・リード・目的、右上＝流れの図） */
    var aim = $('heroAim'), flow = $('heroFlow');
    if (aim) aim.parentNode.removeChild(aim);
    if (flow) flow.parentNode.removeChild(flow);
    hero.innerHTML =
      '<div class="hero-in">' +
        '<div class="hero-top">' +
          '<nav class="crumbs" aria-label="現在地"><a class="crumb-home" href="' + HOME + '" title="楽楽（らくらく）高校物理のトップページへ"><svg class="atom" viewBox="0 0 32 32" aria-hidden="true"><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#3ea0e0" stroke-width="2"/><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#7b5bd6" stroke-width="2" transform="rotate(60 16 16)"/><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#e07b18" stroke-width="2" transform="rotate(120 16 16)"/><circle cx="16" cy="16" r="3.6" fill="#5aa7ff"/></svg><span>楽楽（らくらく）高校物理</span></a><span class="cs" aria-hidden="true">/</span><a class="crumb" href="' + HOME + '#sec-wave">波動</a><span class="cs" aria-hidden="true">/</span><span class="crumb now" aria-current="page">' + esc(CFG.crumb || '') + '</span><span class="kdot"></span><span class="en">' + esc(CFG.en || '') + '</span></nav>' +
        '</div>' +
        '<div class="hero-cols"><div class="hero-main">' +
          '<h1 class="hero-title"><span class="t1">' + esc(CFG.t1 || '') + '</span><span class="t2">' + esc(CFG.t2 || '') + '</span></h1>' +
          '<div class="introrow"><p class="lead2">' + esc(CFG.lead || '') + '</p>' +
            '<button id="bToc" class="tocbtn" type="button" aria-haspopup="true" aria-expanded="false"><span class="ti" aria-hidden="true"></span>コンテンツ一覧</button></div>' +
          '<div class="hero-aimslot"></div>' +
        '</div><div class="hero-side"></div></div>' +
      '</div>';
    if (aim) hero.querySelector('.hero-aimslot').appendChild(aim);
    if (flow) hero.querySelector('.hero-side').appendChild(flow); else hero.querySelector('.hero-cols').classList.add('noside');
  }

  /* ---------- 章の扉・タブの印 ---------- */
  var lastMode = null;
  function showTab() {                       /* スマホ：選んだタブが見えるように、タブ列だけを横に送る（ページは動かさない） */
    var row = document.querySelector('#tabs .tabs-in'), on = curTab(); if (!row || !on || row.scrollWidth <= row.clientWidth) return;
    var l = on.offsetLeft - 24, r = on.offsetLeft + on.offsetWidth + 44;
    if (l < row.scrollLeft) row.scrollLeft = l; else if (r > row.scrollLeft + row.clientWidth) row.scrollLeft = r - row.clientWidth;
  }
  function syncMode() {
    var a = tabList(), on = curTab(); if (!on) return;
    var id = modeOf(on), i = a.indexOf(on), m = modeCfg(id);
    a.forEach(function (b) { if (b === on) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current'); });
    if (id === lastMode) return;
    var first = (lastMode === null); lastMode = id;
    var mh = $('modehead');
    if (mh) {
      mh.innerHTML = '<div class="mh-num" aria-hidden="true"><span>' + (i + 1) + '</span></div><div class="mh-body">' +
        '<p class="mh-en">Chapter ' + ('0' + (i + 1)).slice(-2) + ' — ' + esc(m.en || '') + '</p>' +
        '<h2><span class="mh-c">' + CIRC.charAt(i) + '</span>' + esc(nameOf(on)) + '</h2>' +
        '<p class="mh-lead">' + esc(m.lead || '') + '</p></div>';
      if (!first) { mh.classList.remove('in'); void mh.offsetWidth; mh.classList.add('in'); }
    }
    document.body.setAttribute('data-shellmode', id);
    showTab();
  }
  /* 図のないタブ（data-page。いまは「補足：もっと深く知りたい人へ」だけ）
     もとの setMode はこのタブを知らないので、選択中の印（aria-selected）はここで付けはずしする。
     開いているあいだは body[data-shellpage] を付け、CSS でシミュレーションをたたんで、その節（#sec-○○）を出す。 */
  function isPage(b) { return !!(b && b.getAttribute('data-page')); }
  function enterPage(b) {
    tabList().forEach(function (x) { x.setAttribute('aria-selected', x === b ? 'true' : 'false'); });
    document.body.setAttribute('data-shellpage', b.getAttribute('data-page'));
    syncMode();
  }
  function leavePage(b) {                    /* b ＝ 押されたモードのタブ */
    if (!document.body.hasAttribute('data-shellpage')) return;
    document.body.removeAttribute('data-shellpage');
    tabList().forEach(function (x) { if (isPage(x)) x.setAttribute('aria-selected', 'false'); });
    /* 同じモードにもどるとき、もとの setMode は何もしないことがあるので、印はここでも付ける */
    setTimeout(function () { if (!document.body.hasAttribute('data-shellpage')) { b.setAttribute('aria-selected', 'true'); syncMode(); window.dispatchEvent(new Event('resize')); } }, 0);
  }
  function goMode(id, scroll) {
    var b = $('tab-' + id); if (!b || b.disabled) return false;
    if (b.getAttribute('aria-selected') !== 'true') b.click();
    else if (scroll) window.scrollTo({ top: Math.min(window.pageYOffset, contentTop()), behavior: 'auto' });
    return true;
  }
  function goSec(id) {
    var e = $(id); if (!e) return false;
    var blk = e.closest ? e.closest('.pageblock') : null;      /* 図のないタブの中にあるなら、先にそのタブを開く */
    if (blk) { var t = $('tab-' + blk.id.replace(/^sec-/, '')); if (t && t.getAttribute('aria-selected') !== 'true') enterPage(t); }
    if (e.tagName === 'DETAILS') e.open = true;
    try { history.replaceState(null, '', '#' + id); } catch (err) { /* file:// で失敗しても動きには関係ない */ }
    scrollToEl(e); return true;
  }
  function initTabs() {
    tabList().forEach(function (b) {
      /* タブを押したら、本文の頭まで一気にもどす（ゆっくりスクロールはしない） */
      b.addEventListener('click', function () {
        if (isPage(b)) enterPage(b); else leavePage(b);
        setTimeout(function () {
          try { history.replaceState(null, '', '#' + modeOf(b)); } catch (e) { /* file:// で失敗しても動きには関係ない */ }
          window.scrollTo({ top: Math.min(window.pageYOffset, contentTop()), behavior: 'auto' });
        }, 0);
      });
    });
    var nav = $('tabs');
    if (nav && 'MutationObserver' in window) {
      new MutationObserver(function () { syncMode(); }).observe(nav, { attributes: true, subtree: true, attributeFilter: ['aria-selected'] });
    }
    syncMode();
  }
  /* アドレス：#wave・#path などのモード、#sec-quiz などの節 */
  function gotoHash(first) {
    var h = String(location.hash || '').replace('#', ''); if (!h) return;
    if ($('tab-' + h)) { goMode(h, !first); if (first) window.scrollTo({ top: contentTop(), behavior: 'auto' }); return; }
    var e = $(h); if (e && e.closest && e.closest('#wrap')) goSec(h);
  }

  /* ---------- 節へのピル（章の扉の下） ---------- */
  function buildSecLinks() {
    var box = $('seclinks'); if (!box) return;
    box.innerHTML = secs().map(function (s) { return '<a href="#' + s.id + '" data-sec="' + s.id + '">' + esc(s.name) + '</a>'; }).join('');
    box.querySelectorAll('a[data-sec]').forEach(function (a) { a.addEventListener('click', function (ev) { ev.preventDefault(); goSec(a.getAttribute('data-sec')); }); });
  }

  /* ---------- コンテンツ一覧 ---------- */
  function subItems(sec) {                   /* 節の中の「補足」の見出し（details の summary）を拾う */
    var out = [], root = $(sec.id); if (!root) return out;
    var list = root.querySelectorAll('details.more');
    [].forEach.call(list, function (d, k) {
      var sm = d.querySelector('summary'); if (!sm) return;
      if (!d.id) d.id = sec.id + '-' + (k + 1);
      var c = sm.cloneNode(true); [].forEach.call(c.querySelectorAll('.katex-mathml,annotation'), function (x) { x.parentNode.removeChild(x); });
      out.push({ id: d.id, name: c.textContent.replace(/\s+/g, ' ').trim() });
    });
    return out;
  }
  function buildToc() {
    var b = $('bToc'); if (!b) return;
    var p = document.createElement('div'); p.id = 'tocpanel'; p.className = 'tocpanel'; p.hidden = true;
    document.body.appendChild(p);            /* 見出しの帯は overflow:hidden なので、その外に置く */
    var built = false;
    var close = function () { p.hidden = true; b.setAttribute('aria-expanded', 'false'); };
    var fill = function () {
      var h = '<div class="tochead"><b>コンテンツ一覧</b><button type="button" class="tocx" aria-label="閉じる">×</button></div>';
      h += '<div class="tocmode">上のタブで切りかえ</div><ul>';
      tabList().forEach(function (t, i) {
        h += '<li><a href="#' + modeOf(t) + '" data-mode="' + modeOf(t) + '">' + CIRC.charAt(i) + '　' + esc(nameOf(t)) + '</a>';
        if (isPage(t)) { var sub = subItems({ id: 'sec-' + modeOf(t) }); if (sub.length) h += '<ul class="tocsub">' + sub.map(function (q) { return '<li><a href="#' + q.id + '" data-sec="' + q.id + '">' + esc(q.name) + '</a></li>'; }).join('') + '</ul>'; }
        h += '</li>';
      });
      h += '</ul>';
      secs().forEach(function (s) {
        h += '<div class="tocmode"><a href="#' + s.id + '" data-sec="' + s.id + '" style="padding:0;display:inline">' + esc(s.name) + '</a></div><ul>';
        subItems(s).forEach(function (q) { h += '<li><a href="#' + q.id + '" data-sec="' + q.id + '">' + esc(q.name) + '</a></li>'; });
        h += '</ul>';
      });
      p.innerHTML = h;
      p.querySelector('.tocx').addEventListener('click', close);
      p.querySelectorAll('a[data-mode]').forEach(function (a) { a.addEventListener('click', function (ev) { ev.preventDefault(); close(); goMode(a.getAttribute('data-mode'), true); window.scrollTo({ top: contentTop(), behavior: 'auto' }); }); });
      p.querySelectorAll('a[data-sec]').forEach(function (a) { a.addEventListener('click', function (ev) { ev.preventDefault(); close(); goSec(a.getAttribute('data-sec')); }); });
    };
    /* 一覧は画面に固定して、ボタンのすぐ下に出す */
    var place = function () { if (p.hidden) return; var r = b.getBoundingClientRect(), top = Math.max(8, r.bottom + 8); p.style.position = 'fixed'; p.style.top = top + 'px'; p.style.maxHeight = (innerHeight - top - 12) + 'px'; };
    b.addEventListener('click', function (ev) { ev.stopPropagation(); if (!built) { fill(); built = true; } p.hidden = !p.hidden; b.setAttribute('aria-expanded', p.hidden ? 'false' : 'true'); place(); });
    window.addEventListener('resize', place); window.addEventListener('scroll', place, { passive: true });
    document.addEventListener('click', function (ev) { if (!p.hidden && !p.contains(ev.target) && ev.target !== b) close(); });
    document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape') close(); });
  }

  /* ---------- フッター（暗い地・目次つき） ---------- */
  function buildFooter() {
    var f = document.createElement('footer'); f.className = 'pagefoot'; f.id = 'pagefoot';
    var items = tabList().map(function (t, i) { return '<li><a href="#' + modeOf(t) + '" data-mode="' + modeOf(t) + '"><b>' + CIRC.charAt(i) + '</b>' + esc(nameOf(t)) + '</a></li>'; }).join('') +
      secs().map(function (s) { return '<li><a href="#' + s.id + '" data-sec="' + s.id + '"><b>—</b>' + esc(s.name) + '</a></li>'; }).join('');
    f.innerHTML = '<div class="ft-in"><p class="ft-mark">' + esc(CFG.en || '') + '<span>' + esc((CFG.t1 || '') + ' ' + (CFG.t2 || '')) + '</span></p>' +
      '<ul class="ft-nav">' + items + '</ul>' +
      '<div class="ft-base"><span><a class="ft-home" href="' + HOME + '">⌂ 楽楽（らくらく）高校物理 トップページ</a>　／　高校物理 ・ 波動</span><span class="ft-r"><button type="button" class="ft-pages">ほかのページ一覧</button><a href="#top" class="ft-top">▲ ページの一番上へ</a></span></div></div>';
    var w = $('wrap'); if (w && w.parentNode) w.parentNode.insertBefore(f, w.nextSibling); else document.body.appendChild(f);
    f.querySelectorAll('a[data-mode]').forEach(function (a) { a.addEventListener('click', function (ev) { ev.preventDefault(); goMode(a.getAttribute('data-mode'), true); window.scrollTo({ top: contentTop(), behavior: 'auto' }); }); });
    f.querySelectorAll('a[data-sec]').forEach(function (a) { a.addEventListener('click', function (ev) { ev.preventDefault(); goSec(a.getAttribute('data-sec')); }); });
    var fp = f.querySelector('.ft-pages'); if (fp) fp.addEventListener('click', function () { if (window.SITENAV) window.SITENAV.open(); });
    var tp = f.querySelector('.ft-top'); if (tp) tp.addEventListener('click', function (ev) { ev.preventDefault(); window.scrollTo({ top: 0, behavior: 'auto' }); });
  }

  /* ---------- スライドバーの塗り（--p）・読み進みの線（--prog）・タブ列の .stuck ---------- */
  function syncRange(e) {
    var mn = parseFloat(e.min) || 0, mx = parseFloat(e.max), v = parseFloat(e.value);
    var p = (isFinite(mx) && mx > mn) ? (v - mn) / (mx - mn) * 100 : 0, s = p.toFixed(1) + '%';
    if (e._p !== s) { e._p = s; e.style.setProperty('--p', s); }
  }
  function initRanges() {
    document.addEventListener('input', function (ev) { if (ev.target && ev.target.type === 'range') syncRange(ev.target); }, true);
    var sweep = function () { if (document.hidden) return; [].forEach.call(document.querySelectorAll('input[type=range]'), syncRange); };
    sweep(); setInterval(sweep, 150);
  }
  function initProgress() {
    var nav = $('tabs'); if (!nav) return;
    var pend = false;
    var upd = function () { pend = false; var h = document.documentElement, max = h.scrollHeight - innerHeight; nav.style.setProperty('--prog', max > 0 ? Math.min(1, Math.max(0, window.pageYOffset / max)).toFixed(4) : 0); };
    window.addEventListener('scroll', function () { if (!pend) { pend = true; requestAnimationFrame(upd); } }, { passive: true });
    window.addEventListener('resize', function () { upd(); showTab(); }); upd();
  }
  function initStuck() {
    var hero = $('hero'), nav = $('tabs'); if (!hero || !nav || !('IntersectionObserver' in window)) return;
    new IntersectionObserver(function (es) { es.forEach(function (en) { nav.classList.toggle('stuck', !en.isIntersecting); }); }, { threshold: 0 }).observe(hero);
  }

  /* 見出しの帯とタブの印は、このスクリプトを読んだ時点で作る（このあとの起動処理より先に、画面の形を決めておく） */
  buildHero(); buildSecLinks(); buildFooter(); initTabs();
  function ready() {
    buildToc(); initRanges(); initProgress(); initStuck();
    window.addEventListener('hashchange', function () { gotoHash(false); });
    setTimeout(function () { syncMode(); gotoHash(true); }, 0);      /* もとの起動処理（最初のモードを開く）が済んでから */
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ready); else ready();
  window.SHELL = { contentTop: contentTop, tabbarH: tabbarH, goMode: goMode, goSec: goSec, sync: syncMode };
})();
