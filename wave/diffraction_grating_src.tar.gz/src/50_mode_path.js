/* ===== 50_mode_path.js ===== */
/* ① 光路差の位置と式の原理（波を止めて、ステップを 1 つずつ進める）
 *   左＝回折格子の拡大（隣りあう 2 本のスリットと経路差 d sinθ）
 *   右＝全体（光源 → 回折格子 →〔途中は省略〕→ スクリーン）
 * ステップごとの文章は canvas の中ではなく、図の下の HTML（4 つの箱）に出す。
 */
window.DG = window.DG || {};
DG.modePath = (function () {
  'use strict';
  var D = DG.draw, P = DG.phys;
  var L = D.L, COL = D.COL;

  var STEPS = [
    '経路差を求める',
    '明線の条件を立てる',
    'スクリーン上の位置を求める',
    '補足：多数のスリットを考えると'
  ];
  var CIRC = ['①', '②', '③', '④'];

  /**
   * ステップの見出し（図の左上）。
   * 薄膜ページと同じ作法：左上に「① …」を出し、図の中の該当する場所には
   * 同じ番号を付けた吹き出しを出して、どこの話かをすぐ結びつけられるようにする。
   */
  function stepTitle(ctx, step) {
    // ステップ 4 は「補足」なので、①②③のような通し番号は付けない
    var t = (step === 4) ? STEPS[step - 1] : (CIRC[step - 1] + ' ' + STEPS[step - 1]);
    ctx.save();
    ctx.font = D.font(13.5, true);
    var w = ctx.measureText(t).width + 26;
    D.roundRect(ctx, 12, 10, w, 28, 8);
    ctx.fillStyle = '#fff8e6'; ctx.fill();
    ctx.strokeStyle = '#e0a800'; ctx.lineWidth = 1.6; ctx.stroke();
    ctx.fillStyle = '#8a5300';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(t, 25, 25);
    ctx.restore();
  }

  var SUB = '₀₁₂₃₄₅₆₇₈₉';
  function sub(n) {
    return String(Math.abs(n)).split('').map(function (c) { return SUB.charAt(+c); }).join('');
  }
  /* x が負の側（m が負）でも、どちらの明線かが分かるように「₋」（下つきマイナス）を付ける */
  function subSigned(n) {
    return (n < 0 ? '₋' : '') + sub(n);
  }

  /* ---------- 右パネル：全体図 ---------- */

  /** 光源（左端）と、そこから来る平行光線 */
  function incoming(ctx, st, sc) {
    var bx = L.SRC_X;
    var white = (st.light === 'white');
    D.lightBulb(ctx, D.vec(bx, L.CY), { scale: 1.05, white: white });

    ctx.save();
    ctx.font = D.font(12, true);
    ctx.fillStyle = '#5b6672';
    ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
    ctx.fillText('光源', bx, L.CY - 30);
    ctx.restore();

    D.waveChip(ctx, bx, L.CY + 42, D.lightText(st),
      P.rgbCss(white ? { r: 252, g: 252, b: 252 } : P.wavelengthToRGB(st.lambda)));
    if (white) {
      ctx.save();
      ctx.font = D.font(11);
      ctx.fillStyle = '#5b6672';
      ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      ctx.fillText('式の説明は λ = ' + Math.round(st.lambda) + ' nm で行います',
        bx + 46, L.CY + 58);
      ctx.restore();
    }

    // 入射光は「図に描いたスリットに当たるぶん」だけ描く。
    // それ以外のところに矢印を描くと、格子を通ったあとに何も出ていない光を
    // 描くことになってしまうため。
    var x0 = bx + 42, x1 = sc.gx - 9;
    for (var i = 0; i < sc.slits.length; i++) {
      var a = D.vec(x0, sc.slits[i].y), b2 = D.vec(x1, sc.slits[i].y);
      ctx.save(); ctx.globalAlpha = 0.3;
      D.line(ctx, a, b2, COL.rayDim, 1);
      ctx.restore();
      // スリットのところ（右端）で位相が 0 になるようにそろえる
      beamWave(ctx, st, a, b2, 0, -2 * Math.PI * (x1 - x0) / LAM_DISP, COL.rayDim, 1.3);
      D.arrow(ctx, D.vec(x1 - 9, sc.slits[i].y), D.vec(1, 0), 9, COL.rayDim, 1.5, 5.5);
    }
    ctx.save();
    ctx.font = D.font(11.5);
    ctx.fillStyle = '#5b6672';
    ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
    ctx.fillText('平行光線', (x0 + x1) / 2, L.CY - 34);
    ctx.restore();
  }

  /* スクリーンの下に出す注記。描く前にためて、最後にまとめて 1 行ずつ並べる */
  var screenNotes = [];
  function addNote(s) { if (screenNotes.length < 5) screenNotes.push(s); }
  function drawNotes(ctx) {
    ctx.save();
    ctx.font = D.font(11);
    ctx.fillStyle = '#6f6754';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    for (var i = 0; i < screenNotes.length; i++) {
      ctx.fillText(screenNotes[i], L.SX + L.SCR_W + 36, L.CY + L.SH + 10 + i * 14);
    }
    ctx.restore();
  }

  /** 次数のラベル（重なるものは省く）。chips = [{m, y, on}] */
  function orderChips(ctx, chips, avoidY, hover) {
    var order = chips.slice().sort(function (a, b) {
      if (a.on !== b.on) return a.on ? -1 : 1;
      return Math.abs(a.m) - Math.abs(b.m);
    });
    var used = [], skipped = 0;
    ctx.save();
    for (var i = 0; i < order.length; i++) {
      var it = order[i], ok = true;
      // 「見る方向」の名札とぶつかるラベルは出さない
      if (!it.on && avoidY !== undefined && Math.abs(avoidY - it.y) < 17) ok = false;
      for (var k = 0; ok && k < used.length; k++) {
        if (Math.abs(used[k] - it.y) < 19) { ok = false; break; }
      }
      if (!ok) { skipped++; continue; }
      used.push(it.y);
      ctx.font = D.font(11.5, it.on);
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      var txt = 'm = ' + it.m;
      var w = ctx.measureText(txt).width;
      var hot = (hover === 'ord:' + it.m);
      D.roundRect(ctx, L.SX + L.SCR_W + 36, it.y - 9, w + 10, 18, 5);
      ctx.fillStyle = it.on ? '#fff3d6' : (hot ? '#eaf1fa' : 'rgba(255,255,255,0.9)'); ctx.fill();
      ctx.strokeStyle = it.on ? '#e0a800' : (hot ? '#1f74d0' : '#cfd6dd');
      ctx.lineWidth = (it.on || hot) ? 1.6 : 1; ctx.stroke();
      ctx.fillStyle = it.on ? '#8a5300' : (hot ? '#28405c' : '#5b6672');
      ctx.fillText(txt, L.SX + L.SCR_W + 41, it.y + 1);
      // クリックでその次数を選べるようにする（当たり判定は少し広めに）
      D.addHit(L.SX + L.SCR_W + 30, it.y - 12, w + 22, 24, 'ord:' + it.m);
    }
    if (skipped > 0) addNote('※ ラベルは一部だけ');
    ctx.restore();
  }

  /**
   * 白色光のときのスクリーン。
   *   0 次 … すべての波長が同じ方向（sinθ = 0）なので白いまま
   *   1 次以降 … sinθ = mλ/d が波長ごとにちがうので虹色に分かれる
   *              （短い波長ほど内側＝紫が内・赤が外）
   */
  /** 白色光のとき、m 次の帯の「内側のはし（紫 380 nm）」がスクリーン上のどこか。
   *  ここに次数のラベルを置く。帯のまん中だと、はみ出した帯が画面のはしに寄ってきて
   *  「m = 3 がスクリーンの外なのに m = 2 のとなりに出る」ように見えてしまう。
   *  ①と②で同じ関数を使うので、モードを切りかえても位置がずれない。 */
  var LAM_LO = 380;
  function whiteChips(st, sc) {
    var out = [], mMaxW = Math.ceil(st.d / LAM_LO - 1e-12) - 1;
    for (var m = -mMaxW; m <= mMaxW; m++) {
      var s = Math.abs(m) * LAM_LO / st.d;
      if (!(s < 1)) continue;
      var th = (m < 0 ? -1 : 1) * Math.asin(s);
      var y = L.CY - P.xOnScreen(th, st.L) * sc.ppm;
      if (Math.abs(y - L.CY) > L.SH) continue;      // スクリーンの外なら出さない
      out.push({ m: m, y: y, on: false });
    }
    return out;
  }

  function whiteOrders(ctx, st, sc, avoidY, hover) {
    var d = st.d, Lm = st.L, ppm = sc.ppm;
    var chips = whiteChips(st, sc);

    // 0 次（白）
    ctx.save();
    ctx.shadowColor = '#ffffff'; ctx.shadowBlur = 8;
    ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.moveTo(L.SX, L.CY); ctx.lineTo(L.SX + L.SCR_W, L.CY); ctx.stroke();
    ctx.restore();

    var LO = LAM_LO, mMaxW = Math.ceil(d / LO - 1e-12) - 1;
    for (var m = 1; m <= mMaxW; m++) {
      var hi = Math.min(780, d / m - 1e-6);       // sinθ < 1 になる波長まで
      if (hi <= LO) continue;
      for (var sgn = 1; sgn >= -1; sgn -= 2) {
        var ys = [], cols = [], n = 90, j;
        for (j = 0; j <= n; j++) {
          var lam = LO + (hi - LO) * j / n;
          var th = Math.asin(m * lam / d);
          ys.push(L.CY - sgn * P.xOnScreen(th, Lm) * ppm);
          cols.push(P.rgbCss(D.pureColor(lam)));
        }
        ctx.save();
        for (j = 0; j < n; j++) {
          var ya = ys[j], yb = ys[j + 1];
          var lo2 = Math.min(ya, yb), hi2 = Math.max(ya, yb);
          if (hi2 < L.CY - L.SH || lo2 > L.CY + L.SH) continue;
          lo2 = Math.max(lo2, L.CY - L.SH); hi2 = Math.min(hi2, L.CY + L.SH);
          ctx.fillStyle = cols[j];
          ctx.fillRect(L.SX, lo2, L.SCR_W, Math.max(0.8, hi2 - lo2 + 0.6));
        }
        ctx.restore();
      }
    }
    orderChips(ctx, chips, avoidY, hover);

    addNote('0 次は白、1 次からは');
    addNote('虹色に分かれる（紫が内・赤が外）');
  }

  /**
   * スクリーン上の明線と、次数のラベル。
   * L が小さいと明線が中央に密集するので、ラベルは重ならないものだけを出す
   * （いま選んでいる次数を最優先、あとは次数の小さい順）。
   */
  function brightLines(ctx, st, sol, sc, selM, avoidY) {
    if (st.light === 'white') { whiteOrders(ctx, st, sc, avoidY, st.hoverBtn); return; }
    var col = P.rgbCss(D.pureColor(st.lambda));
    var vis = [];
    var i, o, px, y;
    ctx.save();
    for (i = 0; i < sol.orders.length; i++) {
      o = sol.orders[i];
      px = o.x * sc.ppm;
      if (Math.abs(px) > L.SH) continue;
      y = L.CY - px;
      var on = (selM !== null && o.m === selM);
      ctx.save();
      ctx.shadowColor = col; ctx.shadowBlur = on ? 10 : 6;
      ctx.strokeStyle = col; ctx.lineWidth = on ? 4.5 : 3;
      ctx.beginPath(); ctx.moveTo(L.SX, y); ctx.lineTo(L.SX + L.SCR_W, y); ctx.stroke();
      ctx.restore();
      vis.push({ m: o.m, y: y, on: on });
    }
    ctx.restore();

    orderChips(ctx, vis, avoidY, st.hoverBtn);
  }

  /* ---------- 図の上の光線に描く波 ----------
   * 右の全体図は横を省略して描いているので、本当の波長では描けない
   * （1 m のあいだに波が 160 万個入る）。そこで
   *   ・画面上の波長は見やすい大きさ（LAM_DISP）にする
   *   ・そのかわり「点 P に届いたときの隣どうしのずれ」は
   *     正しく d sinθ ぶん（＝ extraLam 波長ぶん）になるように、
   *     光線の長さに比例して位相を足していく
   * こうすると、m 次の明線の方向では P で山と山がそろう。
   */
  var LAM_DISP = 26;      // 図の上の見かけの波長 [px]
  var AMP_DISP = 2.3;     // 図の上の見かけの振幅 [px]

  function beamWave(ctx, st, from, to, extraLam, phase0, color, width) {
    var dx = to.x - from.x, dy = to.y - from.y;
    var Lp = Math.hypot(dx, dy);
    if (Lp < 2) return;
    var ux = dx / Lp, uy = dy / Lp, nx = -uy, ny = ux;
    var wt = 2 * Math.PI * (P.V_NM_PER_S / st.lambda) * (st.t || 0);
    var steps = Math.max(40, Math.round(Lp / 1.6));
    ctx.save();
    ctx.strokeStyle = color; ctx.lineWidth = width || 1.3;
    ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    ctx.beginPath();
    for (var i = 0; i <= steps; i++) {
      var e = Lp * i / steps;
      var ph = phase0 + 2 * Math.PI * (e / LAM_DISP + extraLam * e / Lp) - wt;
      var u = Math.sin(ph) * AMP_DISP;
      var x = from.x + ux * e + nx * u;
      var y = from.y + uy * e + ny * u;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.stroke();
    ctx.restore();
  }

  /**
   * 各スリットから点 P へ向かう光線。
   * ② では、波が進んでいることがわかるように破線を流す
   * （右の全体図は横を省略して描いているので、ここに波形は描かない）。
   */
  function rays(ctx, sc, st, sol) {
    var ratio = sol.delta / st.lambda;      // 隣どうしが P で何波長ずれるか
    ctx.save();
    for (var i = 0; i < sc.slits.length; i++) {
      var s = D.vec(sc.slits[i].x + 4, sc.slits[i].y);
      // 進む向きがわかるように、うすい直線を下じきにする
      ctx.globalAlpha = 0.28;
      D.line(ctx, s, sc.P1, COL.ray, 1);
      ctx.globalAlpha = 1;
      beamWave(ctx, st, s, sc.P1, i * ratio, 0, COL.ray, 1.25);
    }
    ctx.restore();
  }

  /**
   * θ の角を、ステップ③の三角形と同じくらい目立つように描く（①②④で使う）。
   * 太い弧＋薄く塗った扇形＋大きなラベルのチップ。ゆっくり光らせて、
   * 「ここが θ」だと自然に目がいくようにする。
   */
  function bigThetaArc(ctx, st, center, aDraw) {
    var glow = 0.35 + 0.65 * pulseProfile((st.nowSec || 0) % 5.0, 2.4);
    var r = 170;
    var lo = Math.min(0, aDraw), hi = Math.max(0, aDraw);
    if (hi - lo < 0.02) return;

    ctx.save();
    ctx.beginPath();
    ctx.moveTo(center.x, center.y);
    ctx.arc(center.x, center.y, r, lo, hi);
    ctx.closePath();
    ctx.fillStyle = 'rgba(61,81,168,' + (0.09 + 0.07 * glow).toFixed(3) + ')';
    ctx.fill();
    ctx.strokeStyle = COL.ang; ctx.lineCap = 'round';
    ctx.lineWidth = 3.2 + 2.2 * glow;
    ctx.beginPath(); ctx.arc(center.x, center.y, r, lo, hi); ctx.stroke();
    ctx.restore();

    var mid = (lo + hi) / 2;
    var tx = center.x + Math.cos(mid) * (r + 26);
    var ty = center.y + Math.sin(mid) * (r + 26);
    ctx.save();
    ctx.font = D.font(18, true);
    var w = ctx.measureText('θ').width;
    D.roundRect(ctx, tx - w / 2 - 11, ty - 16, w + 22, 32, 9);
    ctx.fillStyle = '#eef0fb'; ctx.fill();
    ctx.strokeStyle = COL.ang; ctx.lineWidth = 1.8 + 1.6 * glow; ctx.stroke();
    ctx.fillStyle = COL.ang;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('θ', tx, ty + 1);
    ctx.restore();
  }

  /** 光軸・θ の角・寸法線・省略記号 */
  function axisAndAngles(ctx, st, sol, sc, step) {
    D.dashLine(ctx, D.vec(sc.gx + 4, L.CY), D.vec(L.SX, L.CY), '#9aa0a6', [8, 5], 1);

    // ステップ①・②でも、③の三角形と同じ色の線（青＝基準の向き、オレンジ＝実際の光線）
    // を軽く示しておき、θ がどこの角かをあいまいにしない（L・x の値やラベルはまだ出さない）
    if ((step === 1 || step === 2) && sc.pOn && Math.abs(sol.sinT) > 1e-6) {
      var Glite = D.vec(sc.gx, L.CY);
      var Olite = D.vec(L.SX, L.CY);
      var Plite = D.vec(L.SX, P.clamp(sc.P1.y, L.CY - L.SH, L.CY + L.SH));
      ctx.save();
      ctx.lineCap = 'round';
      ctx.strokeStyle = '#1663b5'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(Glite.x, Glite.y); ctx.lineTo(Olite.x, Olite.y); ctx.stroke();
      ctx.strokeStyle = 'rgba(224,123,24,0.85)'; ctx.lineWidth = 2.4;
      ctx.beginPath(); ctx.moveTo(Glite.x, Glite.y); ctx.lineTo(Plite.x, Plite.y); ctx.stroke();
      ctx.restore();
    }

    // l の寸法線（このあと省略記号でいったん切れる）
    var yl = L.CY + L.SH + 22;
    D.dimLine(ctx, D.vec(sc.gx, yl), D.vec(L.SX, yl), '', '#6b7580', 0);

    // 途中を省略していることを示す
    var yBreakTop = 44, yBreakBot = L.CY + L.SH + 36;
    D.breakMark(ctx, yBreakTop, yBreakBot);
    ctx.save();
    ctx.font = D.font(11);
    ctx.fillStyle = '#6b7580';
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText('L は d にくらべてけた違いに長いので', L.BREAK_X + 13, yBreakBot + 6);
    ctx.fillText('途中を省略しています', L.BREAK_X + 13, yBreakBot + 21);
    ctx.restore();

    // l の値（省略記号の左どなりに置く）
    ctx.save();
    ctx.font = D.font(12.5, true);
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    var lt = 'L ＝ ' + st.L.toFixed(2) + ' m';
    var lw = ctx.measureText(lt).width;
    var lcx = (sc.gx + L.BREAK_X) / 2;
    ctx.fillStyle = 'rgba(255,255,255,0.92)';
    ctx.fillRect(lcx - lw / 2 - 5, yl - 9, lw + 10, 18);
    ctx.fillStyle = '#6b7580';
    ctx.fillText(lt, lcx, yl);
    ctx.restore();

    // θ の角（図の上での光線の向きに合わせて描く）
    // ステップ③では三角形のほうで大きく描くので、ここでは描かない
    var tri3 = (step === 3 && sc.pOn && Math.abs(sol.sinT) > 1e-6);
    if (Math.abs(sol.theta) > 0.02 && !tri3) {
      var aDraw = Math.atan2(sc.dirDrawn.y, sc.dirDrawn.x);
      bigThetaArc(ctx, st, D.vec(sc.gx + 4, L.CY), aDraw);
    }
    D.pointLabel(ctx, sc.O, 'O', -15, 14, '#3a4550');
    if (sc.pOn && Math.abs(sol.sinT) > 1e-6) {
      var nm = (sol.kind === 'strong') ? ('P' + subSigned(sol.m)) : 'P';
      D.pointLabel(ctx, sc.P1, nm, -17, -13, '#3a4550');
    }

    // x の寸法線（ステップ 4）
    if (step >= 3 && sc.pOn && Math.abs(sol.sinT) > 1e-6) {
      // スクリーンの右どなり（目盛りの数字と重ならない側）に引く
      var xd = L.SX + L.SCR_W + 10;
      D.dimLine(ctx, D.vec(xd, L.CY), D.vec(xd, sc.P1.y), '', '#1663b5', 0);
      ctx.save();
      ctx.font = D.font(12.5, true);
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      var ty = (L.CY + sc.P1.y) / 2;
      var xLabel = (sol.kind === 'strong') ? ('x' + subSigned(sol.m)) : 'x';
      var xLabelW = Math.max(14, ctx.measureText(xLabel).width + 6);
      ctx.fillStyle = 'rgba(255,255,255,0.92)';
      ctx.fillRect(xd + 2, ty - 9, xLabelW, 18);
      ctx.fillStyle = '#1663b5';
      ctx.fillText(xLabel, xd + 4, ty);
      ctx.restore();
    }
  }

  /* ---------- ステップ③：x・L・θ の直角三角形をはっきり見せる ----------
   * 教科書の図と同じで、格子 G・スクリーンの中心 O・明線の点 P で直角三角形になる。
   *   ・底辺 GO ＝ L（横は途中を省略して描いている）
   *   ・高さ OP ＝ x
   *   ・G のところの角が θ
   * したがって tanθ ＝ x / L、すなわち x ＝ L tanθ。
   */
  function xTriangle(ctx, st, sol, sc) {
    var G = D.vec(sc.gx, L.CY);
    var O = D.vec(L.SX, L.CY);
    var Pp = D.vec(L.SX, P.clamp(sc.P1.y, L.CY - L.SH, L.CY + L.SH));
    var up = (Pp.y <= L.CY);
    var glow = 0.35 + 0.65 * pulseProfile((st.nowSec || 0) % 5.0, 2.4);

    ctx.save();
    // 面を塗る
    ctx.beginPath();
    ctx.moveTo(G.x, G.y); ctx.lineTo(O.x, O.y); ctx.lineTo(Pp.x, Pp.y); ctx.closePath();
    ctx.fillStyle = 'rgba(226,84,44,' + (0.10 + 0.07 * glow).toFixed(3) + ')';
    ctx.fill();

    // 3 辺（底辺 L と 高さ x を太く）
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#1663b5'; ctx.lineWidth = 3 + 1.6 * glow;
    ctx.beginPath(); ctx.moveTo(G.x, G.y); ctx.lineTo(O.x, O.y); ctx.stroke();
    ctx.strokeStyle = '#c0392b'; ctx.lineWidth = 4 + 2 * glow;
    ctx.beginPath(); ctx.moveTo(O.x, O.y); ctx.lineTo(Pp.x, Pp.y); ctx.stroke();
    ctx.strokeStyle = 'rgba(224,123,24,0.85)'; ctx.lineWidth = 2.4;
    ctx.beginPath(); ctx.moveTo(G.x, G.y); ctx.lineTo(Pp.x, Pp.y); ctx.stroke();

    // 直角の印（O のところ）
    D.rightAngle(ctx, O, D.vec(-1, 0), D.vec(0, up ? -1 : 1), 13, '#1663b5');

    // θ の角（G のところ。図の上の見かけの角に合わせる）
    var aDraw = Math.atan2(Pp.y - L.CY, L.SX - sc.gx);
    D.angleArc(ctx, D.vec(G.x + 4, G.y), Math.min(0, aDraw), Math.max(0, aDraw),
      168, '#8a5300', '');
    ctx.restore();

    // ラベル（L・x・θ を大きく）
    function tag(x, y, txt, col, bg, big) {
      ctx.save();
      ctx.font = D.font(big ? 19 : 13.5, true);
      var w = ctx.measureText(txt).width;
      D.roundRect(ctx, x - w / 2 - 10, y - 15, w + 20, 30, 8);
      ctx.fillStyle = bg; ctx.fill();
      ctx.strokeStyle = col; ctx.lineWidth = 1.6 + 1.2 * glow; ctx.stroke();
      ctx.fillStyle = col;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(txt, x, y + 1);
      ctx.restore();
    }
    tag((G.x + O.x) / 2, L.CY + (up ? 28 : -28), 'L', '#1663b5', '#eef4fb', true);
    var xTriLabel = (sol.kind === 'strong') ? ('x' + subSigned(sol.m)) : 'x';
    tag(L.SX - 62, (L.CY + Pp.y) / 2, xTriLabel, '#c0392b', '#fdeeec', true);
    var aMid = aDraw / 2;
    tag(G.x + Math.cos(aMid) * 190, L.CY + Math.sin(aMid) * 190, 'θ', '#8a5300', '#fff8e6', true);
    D.pointLabel(ctx, O, 'O', -16, up ? 16 : -14, '#3a4550');

  }

  /** 見る方向の目を置く点。図の上の光線の延長線上（線とずれないように） */
  function eyePoint(sc) {
    var d = sc.dirDrawn;
    var anchor = D.vec(L.SX, P.clamp(sc.P1.y, L.CY - L.SH, L.CY + L.SH));
    var t = 150;
    if (d.x > 1e-6) t = Math.min(t, (L.W - 50 - anchor.x) / d.x);
    if (d.y < -1e-6) t = Math.min(t, (anchor.y - 46) / -d.y);
    if (d.y > 1e-6) t = Math.min(t, (L.BAND_Y - 46 - anchor.y) / d.y);
    t = P.clamp(t, 92, 150);
    var p = D.add(anchor, D.mul(d, t));
    return D.vec(P.clamp(p.x, 50, L.W - 50), P.clamp(p.y, 44, L.BAND_Y - 44));
  }

  function observer(ctx, sol, sc, p) {
    var tag = (sol.kind === 'strong')
      ? '見る方向（m = ' + sol.m + '）'
      : '見る方向（明線ではない）';
    D.eye(ctx, p, D.mul(sc.dirDrawn, -1), 0.68, tag);
  }

  /* ---------- 左パネル：格子の拡大 ---------- */

  /**
   * 光線に沿った 1 次元の波（sin カーブ）。
   * 拡大図は正しい縮尺なので、d ＝ LD px から「1 nm が何 px か」が決まる。
   * したがって画面上の波長も、経路差も、すべて同じものさしで描ける。
   *   s0: 始点での光路長 [nm]（スリットを 0 とする）
   */
  function rayWave(ctx, st, from, dir, lenPx, s0, nmToPx, color, amp, width) {
    var n = D.nrmOf(dir);
    var steps = Math.max(60, Math.round(lenPx));
    ctx.save();
    ctx.strokeStyle = color; ctx.lineWidth = width || 2;
    ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    ctx.beginPath();
    for (var i = 0; i <= steps; i++) {
      var px = lenPx * i / steps;
      var u = P.waveAt(s0 + px / nmToPx, st.t || 0, st.lambda) * amp;
      var x = from.x + dir.x * px + n.x * u;
      var y = from.y + dir.y * px + n.y * u;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.stroke();
    ctx.restore();
  }

  /**
   * 「⚡ 経路差を強調」の強さ（0〜1）。
   * 押してから 2.2 秒かけて数回ピクッと光って消える。
   * 暗くなりすぎると何が光っているかわからないので、下限を高めにとってある。
   * ステップ 2 のあいだは、押さなくても 5.5 秒ごとに自動で光る。
   */
  function pulseProfile(t, dur) {
    if (!(t >= 0) || t > dur) return 0;
    var fade = 1 - t / dur;
    return fade * (0.72 + 0.28 * Math.cos(2 * Math.PI * 2.2 * t));
  }
  function pathGlow(st) {
    var amt = 0;
    if (st.pulse && st.pulse.kind === 'path') {
      amt = pulseProfile((st.nowSec || 0) - st.pulse.t0, 2.2);
    }
    if (st.mode === 'path' && st.step === 1) {
      amt = Math.max(amt, pulseProfile((st.nowSec || 0) % 5.5, 2.2));
    }
    return amt;
  }

  function zoomPanel(ctx, st, sol, sc, step) {
    var s1 = sc.s1, s2 = sc.s2, F = sc.F, dir = sc.dir;
    var nmToPx = L.LD / st.d;               // 1 nm が何 px か（拡大図は正しい縮尺）
    var amp = 7;

    ctx.save();
    ctx.font = D.font(11.5, true);
    ctx.fillStyle = '#2b5a78';
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText('回折格子の拡大（隣りあう 2 本のスリット）', L.DIV / 2, 84);
    ctx.font = D.font(11);
    ctx.fillStyle = '#5b6672';
    ctx.fillText('ここでは角も長さも波長も正しい縮尺です', L.DIV / 2, 102);
    ctx.restore();

    // ---- 板（右の面は 筋（ギザギザ）と スリット（平ら）が交互）----
    var plateTop = L.CY - 122, plateBot = L.CY + 122;
    ctx.save();
    ctx.fillStyle = COL.plate;
    ctx.fillRect(L.LX - 10, plateTop, 20, plateBot - plateTop);
    ctx.fillStyle = 'rgba(255,255,255,0.92)';
    ctx.fillRect(L.LX - 10, s1.y - 3, 20, 6);
    ctx.fillRect(L.LX - 10, s2.y - 3, 20, 6);
    ctx.strokeStyle = COL.plateEdge; ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(L.LX - 10, plateTop); ctx.lineTo(L.LX + 10, plateTop);
    ctx.moveTo(L.LX - 10, plateBot); ctx.lineTo(L.LX + 10, plateBot);
    ctx.moveTo(L.LX - 10, plateTop); ctx.lineTo(L.LX - 10, plateBot);
    ctx.stroke();
    ctx.strokeStyle = '#3f7ba1'; ctx.lineWidth = 1.3;
    D.gratingFace(ctx, L.LX + 10, plateTop, plateBot, s1.y, L.LD, 3.4, 7, 8);
    ctx.font = D.font(11);
    ctx.fillStyle = '#5b6672';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText('← 筋', L.LX + 24, s1.y - L.LD / 2);
    ctx.fillText('← 筋と筋の間がスリット', L.LX + 24, s2.y + 18);
    ctx.restore();

    /* ---- 入射光：スリットに当たるぶんだけ描く ----
     * スリットのないところに矢印を描くと、格子を通ったあとに
     * 何も出ていない光を描くことになるので、描かない。 */
    var inX0 = 20, inX1 = L.LX - 12;
    var slitsL = [s1, s2];
    for (var k = 0; k < 2; k++) {
      var sy = slitsL[k].y;
      if (st.showWave) {
        rayWave(ctx, st, D.vec(inX0, sy), D.vec(1, 0), inX1 - inX0,
          (inX0 - L.LX) / nmToPx, nmToPx, COL.rayDim, amp, 1.8);
      }
      D.arrow(ctx, D.vec(inX1 - 12, sy), D.vec(1, 0), 12, COL.rayDim, 1.8, 7);
    }
    ctx.save();
    ctx.font = D.font(11);
    ctx.fillStyle = '#6f6754';
    ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
    ctx.fillText('入射光', inX0 + 2, s1.y - amp - 6);
    ctx.restore();

    // ---- d の寸法 ----
    D.dimLine(ctx, D.vec(L.LX - 26, s1.y), D.vec(L.LX - 26, s2.y), 'd', '#3a4550', 12);

    // ---- 出ていく 2 本の光（軸＋ sin カーブ）----
    // スリットのところから波を描く（すきまを空けると「波が消えている」ように見えるため）
    var rayLen = 168, startPx = 0;
    for (k = 0; k < 2; k++) {
      var sp = slitsL[k];
      var from = D.add(sp, D.mul(dir, startPx));
      D.dashLine(ctx, sp, D.add(sp, D.mul(dir, rayLen)), 'rgba(120,130,140,0.5)', [4, 4], 1);
      if (st.showWave) {
        rayWave(ctx, st, from, dir, rayLen - startPx, startPx / nmToPx, nmToPx, COL.ray, amp, 2);
      } else {
        D.line(ctx, sp, D.add(sp, D.mul(dir, rayLen)), COL.ray, 2);
      }
      D.arrow(ctx, D.add(sp, D.mul(dir, rayLen - 12)), dir, 12, COL.ray, 2, 7);
    }
    D.pointLabel(ctx, s1, '', 0, 0, '#2b2118');
    D.pointLabel(ctx, s2, '', 0, 0, '#2b2118');

    if (step >= 1) {
      // 波面（ここから先は 2 本とも同じ長さ）
      D.dashLine(ctx, s1, F, '#8a8a8a', [5, 4], 1.4);
      // 経路差（緑）
      ctx.save();
      ctx.globalAlpha = 0.82;
      D.line(ctx, s2, F, COL.geo, 6);
      ctx.restore();
      D.glowLine(ctx, s2, F, COL.geo, pathGlow(st));

      if (Math.abs(sol.theta) > 0.05) {
        D.rightAngle(ctx, F, D.unit(D.sub(s1, F)), D.mul(dir, -1), 9, '#666');
        D.angleArc(ctx, s2, Math.min(0, -sol.theta), Math.max(0, -sol.theta), 46, COL.ang, 'θ');
        var aP = Math.PI / 2;
        D.angleArc(ctx, s1, Math.min(aP, aP - sol.theta), Math.max(aP, aP - sol.theta), 34, COL.ang, 'θ');
      }
      // 経路差のラベル
      ctx.save();
      ctx.font = D.font(12.5, true);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      var txt = 'この長さ ＝ d sinθ ＝ ' + Math.round(Math.abs(sol.delta)) + ' nm';
      var w = ctx.measureText(txt).width;
      var lx = L.DIV / 2, ly = L.CY + 162;
      D.roundRect(ctx, lx - w / 2 - 8, ly - 11, w + 16, 22, 6);
      ctx.fillStyle = '#eaf7ef'; ctx.fill();
      ctx.strokeStyle = COL.geo; ctx.lineWidth = 1.2; ctx.stroke();
      ctx.fillStyle = '#0b5c34';
      ctx.fillText(txt, lx, ly + 1);
      ctx.restore();
      var mid = D.mul(D.add(s2, F), 0.5);
      D.dashLine(ctx, mid, D.vec(lx, ly - 11), COL.geo, [3, 3], 1);
      // 強調中は、経路差の線だけでなくラベルも光らせる（線が短いので見落としやすい）
      D.boxGlow(ctx, { x: lx - w / 2 - 8, y: ly - 11, w: w + 16, h: 22 },
        pathGlow(st), COL.geo);
    }

    // ---- 「⚡ 経路差を強調」ボタン ----
    if (step >= 1) {
      D.canvasButton(ctx, 14, 46, '⚡ 経路差を強調', 'pulse-path',
        st.hoverBtn === 'pulse-path', pathGlow(st) > 0.01);
    }
  }

  /* ---------- ステップ①：なぜ「平行」とみなせるのか ----------
   * ことばだけでは伝わらないので、数で示す。
   *   ・図に描いた 6 本のスリットの幅 ＝ 5d（例：10 μm）
   *   ・スクリーンまでの距離 L（例：1 m）は、その 10 万倍
   *   ・だから両端のスリットから点 P へ向かう光の「向きの差」は
   *     Δθ ≒ 5d cos²θ / L ＝ 0.00052°（θ ＝ 17.46° の 3 万分の 1）
   * これを、角の差をわざと大きく描いた小さな図といっしょに出す。
   */
  function comma(n) {
    var t = String(Math.round(n)), out = '';
    for (var i = 0; i < t.length; i++) {
      if (i > 0 && (t.length - i) % 3 === 0) out += ',';
      out += t.charAt(i);
    }
    return out;
  }

  function parallelInset(ctx, st, sol, sc, glow) {
    var x0 = 700, y0 = 292, w = 262, h = 186;
    var spanNm = (L.NSLIT - 1) * st.d;                  // 図に描いた格子の幅 [nm]
    var Lnm = st.L * 1e9;
    // 両端のスリットから同じ点 P を見込む向きの差。θ ＝ atan(x/L) の x を
    // スリットの位置ぶん（span）だけずらしたときの変化なので、
    // Δθ ＝ span・cos²θ / L（dθ/dx ＝ cos²θ/L。cos 1 個では 1 割ほど大きく出る）
    var dth = spanNm * Math.pow(Math.cos(sol.theta), 2) / Lnm;   // 向きの差 [rad]
    var dthDeg = dth * 180 / Math.PI;

    ctx.save();
    D.roundRect(ctx, x0, y0, w, h, 10);
    ctx.fillStyle = '#fffaf0'; ctx.fill();
    ctx.strokeStyle = '#e0a800'; ctx.lineWidth = 1.6; ctx.stroke();
    if (glow > 0.01) D.boxGlow(ctx, { x: x0, y: y0, w: w, h: h }, glow);

    ctx.font = D.font(11.5, true);
    ctx.fillStyle = '#8a5300';
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText('両端のスリットから P へ向かう光', x0 + w / 2, y0 + 9);

    // 角の差をわざと大きく描いた図
    var ax = x0 + 24, ay = y0 + 62, bx = x0 + w - 24, by = y0 + 52;
    ctx.strokeStyle = COL.ray; ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(ax, ay - 16); ctx.lineTo(bx, by);
    ctx.moveTo(ax, ay + 16); ctx.lineTo(bx, by);
    ctx.stroke();
    ctx.fillStyle = '#2b2118';
    ctx.beginPath(); ctx.arc(ax, ay - 16, 2.6, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(ax, ay + 16, 2.6, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(bx, by, 3, 0, Math.PI * 2); ctx.fill();
    ctx.font = D.font(11);
    ctx.fillStyle = '#5b6672';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText('上端', ax - 22, ay - 16);
    ctx.fillText('下端', ax - 22, ay + 16);
    ctx.fillText('P', bx + 7, by);
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText('（角の差は大きく描いています）', x0 + w / 2, y0 + 84);

    // 数で示す
    ctx.font = D.font(11);
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillStyle = '#3a4550';
    var yy = y0 + 104;
    ctx.fillText('格子 6 本ぶんの幅 5d ＝ ' + (spanNm / 1000).toFixed(1) + ' μm', x0 + 12, yy);
    ctx.fillText('L ＝ ' + st.L.toFixed(2) + ' m ＝ その ' + comma(Lnm / spanNm) + ' 倍', x0 + 12, yy + 15);
    ctx.fillStyle = '#8a5300';
    ctx.font = D.font(11, true);
    ctx.fillText('向きの差 ＝ ' + dthDeg.toFixed(5) + '°', x0 + 12, yy + 32);
    ctx.font = D.font(11);
    ctx.fillStyle = '#5b6672';
    if (Math.abs(sol.thetaDeg) > 0.01) {
      ctx.fillText('（θ ＝ ' + sol.thetaDeg.toFixed(2) + '° の '
        + comma(Math.abs(sol.thetaDeg) / dthDeg) + ' 分の 1）', x0 + 12, yy + 48);
    } else {
      ctx.fillText('（θ ＝ 0° のときも同じくらい小さい）', x0 + 12, yy + 48);
    }
    ctx.font = D.font(11.5, true);
    ctx.fillStyle = '#1b6b34';
    ctx.fillText('→ ほとんど平行とみなせる', x0 + 12, yy + 63);
    ctx.restore();
  }

  /**
   * 左の「回折格子の拡大」パネルが、右の全体図のどこを拡大したものかを、
   * ステップ②の点 P の拡大図（pointZoom）と同じ「点線の赤丸＋赤い矢印」で示す。
   * 経路：右の格子の上のほう（隣りあう 2 本のスリット）を点線の丸で囲み、
   * 図の上の空いているところ（見出しの下）を通して、左パネルの丸まで矢印を引く。
   */
  function zoomLinkCallout(ctx, sc) {
    var rx = sc.gx, ry = (sc.slits[0].y + sc.slits[1].y) / 2;   // 右：格子の上の 2 本
    var rr = 40;
    var lx = L.LX, ly = (L.CY - L.LD / 2 + L.CY) / 2 - 6;        // 左：拡大図の板の上のほう
    var lr = 46;

    ctx.save();
    ctx.strokeStyle = '#d0342c'; ctx.lineWidth = 1.6;
    ctx.setLineDash([5, 4]);
    ctx.beginPath(); ctx.arc(rx, ry, rr, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath(); ctx.arc(lx, ly, lr, 0, Math.PI * 2); ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();

    // 矢印：右の丸の上端 → 上の空いているところを通って → 左の丸の上端
    var a0 = D.vec(rx - rr * 0.3, ry - rr * 0.95);
    var a1 = D.vec(lx + lr * 0.5, ly - lr * 0.9);
    var c0 = D.vec(rx - 90, 34);
    var c1 = D.vec(lx + 90, 34);
    ctx.save();
    ctx.strokeStyle = '#d0342c'; ctx.lineWidth = 3; ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(a0.x, a0.y);
    ctx.bezierCurveTo(c0.x, c0.y, c1.x, c1.y, a1.x, a1.y);
    ctx.stroke();
    // 矢じり（左向き）
    var hd = D.unit(D.sub(a1, c1)), hn = D.nrmOf(hd);
    ctx.fillStyle = '#d0342c';
    ctx.beginPath();
    ctx.moveTo(a1.x + hd.x * 11, a1.y + hd.y * 11);
    ctx.lineTo(a1.x + hn.x * 8, a1.y + hn.y * 8);
    ctx.lineTo(a1.x - hn.x * 8, a1.y - hn.y * 8);
    ctx.closePath(); ctx.fill();
    ctx.restore();

    // ラベル（赤い矢印のすぐ下・まんなかあたり。矢印から離すと対応が分かりにくい）
    ctx.save();
    ctx.font = D.font(11.5, true);
    var t = '← 左の図は、この 2 本を拡大したもの';
    var w = ctx.measureText(t).width;
    // 左パネル（x < DIV）の見出しと重ならないよう、少し右に寄せて矢印のすぐ下に置く
    var tx = (rx + lx) / 2 + 100, ty = 132;
    D.roundRect(ctx, tx - w / 2 - 8, ty - 11, w + 16, 22, 6);
    ctx.fillStyle = '#fdeeec'; ctx.fill();
    ctx.strokeStyle = '#d0342c'; ctx.lineWidth = 1.3; ctx.stroke();
    ctx.fillStyle = '#a12a1c';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(t, tx, ty + 1);
    ctx.restore();
  }

  /* ---------- 点 P の拡大図（教科書 図 8 と同じ見せ方） ----------
   * スクリーン上の点 P を赤い丸で囲み、赤い矢印で大きな円に引き出して、
   * 「そこに届く 2 本の波」を並べて見せる。経路差が λ の整数倍なら
   * 山と山がそろい、そうでなければずれていることが一目でわかる。
   */
  function zoomGlow(st) {
    if (st.mode === 'path' && st.step === 2) return pulseProfile((st.nowSec || 0) % 5.5, 2.2);
    return 0;
  }

  function pointZoom(ctx, st, sol, sc) {
    var Py = P.clamp(sc.P1.y, L.CY - L.SH, L.CY + L.SH);
    var above = (Py <= L.CY);                 // P が上側なら拡大図は下側へ
    var c = D.vec(952, above ? 378 : 152);
    var r = 96;
    var sx = L.SX + L.SCR_W / 2;
    var strong = (sol.kind === 'strong');
    var glow = zoomGlow(st);

    // スクリーン上の P を赤い小円で囲む
    ctx.save();
    ctx.strokeStyle = '#d0342c'; ctx.lineWidth = 1.6;
    ctx.setLineDash([5, 4]);
    ctx.beginPath(); ctx.arc(sx, Py, 17, 0, Math.PI * 2); ctx.stroke();
    ctx.setLineDash([]);

    // 赤い矢印（小円 → 大円）
    var a0 = D.vec(sx - 18, Py + (above ? 12 : -12));
    var dirTo = D.unit(D.sub(a0, c));
    var a1 = D.add(c, D.mul(dirTo, r + 10));
    var mid0 = D.mul(D.add(a0, a1), 0.5);
    var bulge = D.mul(D.nrmOf(D.unit(D.sub(a1, a0))), above ? 26 : -26);
    ctx.strokeStyle = '#d0342c'; ctx.lineWidth = 5; ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(a0.x, a0.y);
    ctx.quadraticCurveTo(mid0.x + bulge.x, mid0.y + bulge.y, a1.x, a1.y);
    ctx.stroke();
    var hd = D.unit(D.sub(a1, D.vec(mid0.x + bulge.x, mid0.y + bulge.y)));
    var hn = D.nrmOf(hd);
    ctx.fillStyle = '#d0342c';
    ctx.beginPath();
    ctx.moveTo(a1.x + hd.x * 12, a1.y + hd.y * 12);
    ctx.lineTo(a1.x + hn.x * 9, a1.y + hn.y * 9);
    ctx.lineTo(a1.x - hn.x * 9, a1.y - hn.y * 9);
    ctx.closePath(); ctx.fill();
    ctx.restore();

    // 大きい円
    ctx.save();
    ctx.beginPath(); ctx.arc(c.x, c.y, r, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(255,255,255,0.98)'; ctx.fill();
    if (glow > 0.01) {
      ctx.save();
      ctx.strokeStyle = '#e0a800';
      ctx.globalAlpha = 0.85 * glow;
      ctx.lineWidth = 3 + 12 * glow;
      ctx.beginPath(); ctx.arc(c.x, c.y, r + 4 + 6 * glow, 0, Math.PI * 2); ctx.stroke();
      ctx.restore();
    }
    ctx.strokeStyle = '#d0342c'; ctx.lineWidth = 1.8;
    ctx.setLineDash([6, 5]); ctx.stroke(); ctx.setLineDash([]);
    ctx.beginPath(); ctx.arc(c.x, c.y, r, 0, Math.PI * 2); ctx.clip();

    // 見出し
    var nm = strong ? ('点 P' + subSigned(sol.m) + ' は強めあう') : '点 P は弱めあう';
    ctx.font = D.font(13, true);
    ctx.fillStyle = strong ? '#1b6b34' : '#a12a1c';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(nm, c.x, c.y - r + 22);

    // 届く 2 本の波（下の光線のほうが d sinθ だけ余分に進んでいる）
    var u = D.vec(Math.cos(sol.theta), -Math.sin(sol.theta));
    var n = D.nrmOf(u);
    var nmToPx = L.LD / st.d;
    var len = 112 * (0.55 + 0.45 * Math.cos(sol.theta));
    var mid = D.vec(c.x - 6, c.y - 26);
    var delta = Math.abs(P.pathDiff(st.d, sol.theta));
    for (var k = 0; k < 2; k++) {
      var base = D.add(mid, D.mul(n, k === 0 ? -13 : 11));
      var from = D.add(base, D.mul(u, -len / 2));
      var tip = D.add(base, D.mul(u, len / 2));
      D.line(ctx, from, tip, 'rgba(232,134,42,0.5)', 1.4);
      rayWave(ctx, st, from, u, len, (k === 1 ? delta : 0), nmToPx, COL.ray, 6, 1.8);
      D.pointLabel(ctx, tip, 'P' + (strong ? subSigned(sol.m) : ''), 15, -9, '#3a4550');
    }
    // 到着面
    var tm = D.add(mid, D.mul(u, len / 2));
    D.dashLine(ctx, D.add(tm, D.mul(n, -36)), D.add(tm, D.mul(n, 30)), '#2b2118', [5, 4], 1.3);

    ctx.font = D.font(9.5);
    ctx.fillStyle = '#5b6672';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('注：2 本はずらして描いています', c.x, c.y + r - 38);
    ctx.fillText('（実際には重なります）', c.x, c.y + r - 24);
    ctx.restore();
  }

  /* ---------- ステップの吹き出し ----------
   * 図の左上に「① …」を出すのと同時に、図の中の該当する場所に
   * 同じ番号を付けた吹き出しを出す（薄膜ページと同じ作法）。
   * 置き場所は固定にする。図の内容から計算すると、角度や次数によって
   * ほかのラベルと重なってしまうため。
   */
  var BOX = {
    1: { x: 12, y: 452 },     // 左パネルの下（経路差のカードの下）
    2: { x: 322, y: 388 },    // 光軸の下・格子の手前（点 P の拡大図とぶつからない）
    3: { x: 706, y: 26 },     // 図の右上。x ＝ L tanθ の話なので、スクリーンの近くに置く
    4: { x: 700, y: 118 }     // ③の吹き出しの下・光線の束の上（点 P の拡大図とはぶつからない）
  };
  /* m が負（P が下側）のときは、点 P の拡大円が図の右上（c=(952,152)）へ移るので、
   * ③④の吹き出しは軸の下側の空いたところへ退避させる（そのままだと円と重なる）。
   * x は「L ＝ …」のラベル（〜731px）とぶつからない位置。 */
  var BOX_LOW = {
    3: { x: 736, y: 272 },
    4: { x: 736, y: 366 }
  };
  var BOX_PAR = { x: 578, y: 150 };   // 「平行とみなせる」の吹き出し（ステップ①だけ）

  /** ①〜③の吹き出しを、いまのステップまでぜんぶ描く（進んでも前のは消さない） */
  function stepCallouts(ctx, st, sol, sc, step) {
    var boxes = {};
    var k;
    for (k = 1; k <= step; k++) boxes[k] = oneCallout(ctx, st, sol, sc, k);
    // いま進んだステップだけ光らせる
    var glow = D.pulseAmount(
      st.stepPulse ? { kind: 'step' + st.stepPulse.step, t0: st.stepPulse.t0 } : null,
      'step' + step, st.nowSec || 0);
    if (glow > 0 && boxes[step]) D.boxGlow(ctx, boxes[step], glow);
  }

  function oneCallout(ctx, st, sol, sc, step) {
    var b = BOX[step];
    // P が下側（拡大円が上へ移る）ときは ③④ を下側の空きへ
    if ((step === 3 || step === 4) && sc.pOn && sc.P1.y > L.CY) b = BOX_LOW[step];
    if (step === 1) {
      // ①では、経路差の直角三角形のところに吹き出しを出す。
      // 「d ≪ L だから平行とみなせる」の注は、ステップ①を見ているあいだだけ添える。
      if (st.step === 1) {
        var f = 0.3;
        var a1 = D.vec(sc.gx + (L.SX - sc.gx) * f, L.CY + (sc.P1.y - L.CY) * f);
        D.calloutAt(ctx, a1, BOX_PAR.x, BOX_PAR.y, [
          'd ≪ L なので、各スリットを通った',
          '光は平行とみなせる（右の枠で確かめられます）'
        ], { border: '#e0a800', bg: '#fffaf0' });
      }
      return D.calloutAt(ctx, sc.F, b.x, b.y, [
        '① 隣りあう光の道のりの差（経路差）は',
        '　 いつも同じ　d sinθ ＝ ' + Math.round(Math.abs(sol.delta)) + ' nm',
        '　（下の緑のカードで λ と比べます）'
      ], { border: COL.geo, bg: '#f0faf4' });
    }
    if (step === 2) {
      var lines2 = [
        '② 経路差が λ の整数倍 d sinθ ＝ mλ',
        '　 の方向で、全部の光がそろって明線'
      ];
      lines2.push(sol.kind === 'strong'
        ? '　→ いまは ' + D.about(Math.abs(sol.ratio)) + ' λ ＝ m = ' + sol.m + ' の明線'
        : '　→ いまは ' + D.about(Math.abs(sol.ratio)) + ' λ なので明線ではない');
      var tip2 = sc.pOn
        ? D.vec(856, sc.P1.y <= L.CY ? 378 : 152)          // 点 P の拡大図へ
        : D.vec(L.SX, L.CY);                               // スクリーンの中心へ
      return D.calloutAt(ctx, tip2, b.x, b.y, lines2, { border: '#1663b5', bg: '#f2f7fd' });
    }
    // ③ スクリーン上の位置。スクリーンの外なら、その旨だけを書く
    if (step === 3) {
      if (!sc.pOn) {
        return D.calloutAt(ctx, D.vec(L.SX + L.SCR_W / 2, L.CY - L.SH), b.x, b.y, [
          '③ この方向はスクリーンの外です',
          '　 x ＝ L tanθ ＝ ' + D.fmtLenM(Math.abs(sol.x)) + '（±'
            + D.fmtCm(sc.halfM) + ' の外）',
          '　 図には出せません。L を短くするか d を大きく'
        ], { border: '#a12a1c', bg: '#fdeeec' });
      }
      return D.calloutAt(ctx, D.vec(L.SX, P.clamp(sc.P1.y, L.CY - L.SH, L.CY + L.SH)),
        b.x, b.y, [
          '③ 赤い直角三角形（L・x・θ）から',
          '　 tanθ ＝ x ／ L　→　x ＝ L tanθ',
          '　 x ＝ ' + st.L.toFixed(2) + ' × tan ' + sol.thetaDeg.toFixed(2) + '° ＝ '
            + D.fmtLenM(Math.abs(sol.x))
        ], { border: '#c0392b', bg: '#fdeeec' });
    }
    // ④ N 本ぜんぶで見ると、条件ぴったりでは強め合い、少しずれると弱め合う
    var anchor4 = D.vec(sc.gx + (L.SX - sc.gx) * 0.55, L.CY + (sc.P1.y - L.CY) * 0.55);
    if (sol.kind === 'strong') {
      return D.calloutAt(ctx, anchor4, b.x, b.y, [
        '④ 隣りあうどの 2 本の経路差も',
        '　 ちょうど mλ（③までの条件）だから、',
        '　 N 本ぜんぶがそろって強く光る',
        '　（下の説明の図：少しずれると弱め合う）'
      ], { border: '#c0392b', bg: '#fdeeec' });
    }
    return D.calloutAt(ctx, anchor4, b.x, b.y, [
      '④ 経路差が mλ から少しでもずれると、',
      '　 隣りあうごとに位相が少しずつずれていき、',
      '　 N 本では打ち消しあってほとんど暗くなる',
      '　（下の説明の図：ぴったりだと強め合う）'
    ], { border: '#1663b5', bg: '#f2f7fd' });
  }

  /** ステップ③以外のときに、「スクリーンの外」であることを図の右上に出す */
  function offScreenNote(ctx, st, sol, sc) {
    D.calloutAt(ctx, D.vec(L.SX + L.SCR_W / 2, L.CY - L.SH), BOX[3].x, BOX[3].y, [
      '※ いま選んでいる方向はスクリーンの外です',
      '　 x ＝ ' + D.fmtLenM(Math.abs(sol.x)) + '（スクリーンは ±'
        + D.fmtCm(sc.halfM) + '）'
    ], { border: '#a12a1c', bg: '#fdeeec' });
  }

  /* ---------- 本体 ----------
   * ① と ② は同じレイアウト。②（opt.wave）では
   *   ・拡大図の sin カーブと、下の帯の波が動く（st.t が進む）
   *   ・光線が破線で流れる
   *   ・スクリーンに干渉パターンそのものを描く
   *   ・合成波のカードを足す
   * だけが変わる。
   */
  function render(ctx, st, sol, sc, step, opt) {
    var wave = !!(opt && opt.wave);
    screenNotes.length = 0;
    D.panels(ctx);

    incoming(ctx, st, sc);
    D.screenBar(ctx, sc);
    D.screenRuler(ctx, sc);
    rays(ctx, sc, st, sol);
    D.gratingPlate(ctx, sc);
    axisAndAngles(ctx, st, sol, sc, step);
    // ステップ③では、x ＝ L tanθ の直角三角形をはっきり見せる
    if (!wave && step === 3 && sc.pOn && Math.abs(sol.sinT) > 1e-6) {
      xTriangle(ctx, st, sol, sc);
    }
    var ep = eyePoint(sc);
    if (wave && DG.modeWave) {
      DG.modeWave.screenPattern(ctx, st, sol, sc, ep.y - 30);
    } else {
      brightLines(ctx, st, sol, sc, sol.kind === 'strong' ? sol.m : null, ep.y - 30);
    }
    observer(ctx, sol, sc, ep);
    if (wave || step >= 2) {
      // スクリーンの外の方向を選んでいるときは、点 P の拡大図は描けない
      if (sc.pOn) pointZoom(ctx, st, sol, sc);
      else if (!wave && step === 3) { /* ③の吹き出しがその旨を伝える */ }
      else offScreenNote(ctx, st, sol, sc);
    } else {
      // ステップ①では「なぜ平行とみなせるか」を数で示す枠も同時に出す
      parallelInset(ctx, st, sol, sc, pulseProfile((st.nowSec || 0) % 5.5, 2.2));
      if (!sc.pOn) offScreenNote(ctx, st, sol, sc);
    }

    zoomPanel(ctx, st, sol, sc, wave ? 1 : step);
    // 左の拡大図が、右の全体図のどこの話かを示す（① は最初のステップだけ、② ではずっと表示）
    if (wave || step === 1) zoomLinkCallout(ctx, sc);

    if (wave && DG.modeWave) {
      DG.modeWave.sumCard(ctx, st, sol, sc);
      DG.modeWave.title(ctx);
    } else {
      stepTitle(ctx, step);
      if (st.showLabels) stepCallouts(ctx, st, sol, sc, step);
    }
    ctx.save();
    ctx.font = D.font(11);
    ctx.fillStyle = '#6f6754';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText('※ 波長は見やすく拡大しています', 322, 496);
    ctx.restore();
    drawNotes(ctx);
  }

  return {
    render: render, STEPS: STEPS, CIRC: CIRC, pathGlow: pathGlow,
    orderChips: orderChips, addNote: addNote, whiteChips: whiteChips,
    incoming: incoming
  };
})();
