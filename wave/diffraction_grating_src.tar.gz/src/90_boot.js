/* ===== 90_boot.js ===== */
/* 起動 */
(function () {
  'use strict';
  function boot() {
    DG.ui.init();
    if (DG.quiz) {
      DG.quiz.init();
      var b = document.getElementById('btn-quiz-reset');
      if (b) b.addEventListener('click', function () { DG.quiz.init(); });
    } else {
      var q = document.getElementById('quiz');
      if (q) q.innerHTML = '<div class="q"><div class="qh">練習問題は次の段階で作ります。</div></div>';
      var rb = document.getElementById('btn-quiz-reset');
      if (rb) rb.disabled = true;
    }
    // 自動テストから触れるようにする
    window.DGTEST = DG.ui.api;
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
