/* =========================================================================
   86_shellcfg.js … このページの見出しの帯・章の扉・目次に出す文（87_shell.js が読む）
   タブの名前と並びは 20_body.html の <nav id="tabs"> に書いてある（ここは英字の副題とリードだけ）。
   ========================================================================= */
window.SHELL_CFG = {
  here: 'wave/diffraction_grating.html',
  crumb: '回折格子',
  en: 'Diffraction Grating',
  t1: '光の干渉',
  t2: '〜回折格子〜',
  lead: 'たくさんのスリットを通った光が、どの方向で強めあうのかを確かめよう。',
  modes: {
    wave:   { en: 'Watching the Waves',
              lead: '隣りあうスリットを出た波を動かして見ます。経路差 d sinθ が波長の整数倍になる方向では、波面の上で山と山がそろって強めあいます。' },
    path:   { en: 'Where the Path Difference Appears',
              lead: '隣りあう 2 本の光の経路差 d sinθ を作図で求め、明線の条件 d sinθ ＝ mλ と、スクリーン上の位置 x ≒ mλL/d までを、ステップを追ってたどります。' },
    deltax: { en: 'Deriving the Fringe Spacing',
              lead: 'となりあう明線の位置の差から、明線の間隔 Δx ≒ λL/d を導きます。' },
    field:  { en: 'Adding Up Waves from Many Slits',
              lead: 'スリットの本数 N′ を 2 本から増やしていくと、明線の方向だけが鋭く残り、そのほかの方向では波が打ち消しあうようすを確かめます。' },
    scale:  { en: 'The Real Scale of the Apparatus',
              lead: '装置の並びから格子の表面まで、本当の大きさをたどります。スリットを通った光が回折して広がることが、干渉の出発点です。' },
    slit:   { en: 'Single-Slit Diffraction',
              lead: '幅 D のスリットの中をいくつもの点に分けて考え、暗線の条件 D sinθ ＝ mλ を確かめます。入試問題（改題）と解答つき。' },
    more:   { en: 'Going Deeper',
              lead: 'ここまでの内容を、もう一歩深く知りたい人のための読み物です。見出しを押すと開きます。' }
  },
  secs: []      // タブのほかに、ピルと目次に出す節（いまは無し。目的は見出しの帯へ、補足は最後のタブへ移した）
};
