/* ===== 63_mode_slit.js ===== */
/* 補足：単スリットの問題（難関大頻出）
 *
 * 「補足：多数の格子からの波がどう重なり合うか」（62_mode_field.js）と
 * ほとんど同じレイアウト。違いは次の 2 点だけ：
 *   ・スリットが「多数」ではなく「幅 a の 1 本」
 *   ・その 1 本のスリットの中に、考える点（素元波の源）を K 個とる
 *
 * ねらい：スリットの中を K 個の点に等分割し（それぞれの帯の中央に点を置く）、
 * K を 2 → 3 → … → 100 と増やしていくと、合成振幅が
 *   |sin α / α|（α ＝ π a sinθ / λ）＝ 本当の単スリットの分布
 * に近づくことを見せる。
 *   隣りあう点の間隔 s ＝ a/K なので、K 点の合成振幅は
 *   |sin(Kβ) / (K sinβ)|、β ＝ π s sinθ / λ。
 *   Kβ ＝ π a sinθ / λ だから、暗線 a sinθ ＝ mλ は K がいくつでも暗線のまま。
 *   （K ＝ 2 のときの「半分に分けて対で打ち消す」が、教科書の説明そのもの）
 *
 * 注意：点の数 K が少なすぎると、s sinθ ＝ λ（つまり a sinθ ＝ Kλ）の向きに
 * 「本当はない明線」が現れる（点をとびとびに置いたための偽物）。
 * K を増やすとこの向きは sinθ > 1 になって消える。これも見せどころ。
 */
window.DG = window.DG || {};
DG.modeSlit = (function () {
  'use strict';
  var D = DG.draw, P = DG.phys;
  var L = D.L, COL = D.COL;

  var FL = {
    x0: 264, y0: 26, x1: 776, y1: 626,    // 場を描く範囲（62 と同じ）
    gx: 356,                              // スリット板の x
    aw: 150,                              // スリットの幅 a を描く px 数（縮尺の基準）
    step: 2                               // 場の計算の刻み [px]
  };
  FL.cy = (FL.y0 + FL.y1) / 2;

  /** スクリーン（板）。62 と同じ作り */
  var SCR = { w: 16, min: 200, max: 420 };
  function screenX(st) {
    var v = (st.scrXS === undefined || st.scrXS === null) ? SCR.max : st.scrXS;
    return FL.gx + P.clamp(v, SCR.min, SCR.max);
  }
  /** 右わきの「P に届く波」パネル */
  var PN = { x0: 900, x1: 1288, y0: 34, y1: 626, lam: 44 };
  var NSHOW = 10;
  /** 図の中に点を描くのは 12 個まで（多いときは「…」で示す） */
  var PT_MAX = 12;

  /** 1 px が何 nm か（スリットの幅 a を FL.aw px で描く） */
  function nmPerPx(st) { return st.slitA / FL.aw; }
  /** K 個の点の y（スリットを K 等分し、それぞれの帯の中央） */
  function ptY(st, i) {
    return FL.cy - FL.aw / 2 + FL.aw * (i + 0.5) / st.K;
  }

  /* ================= 平行光線としての計算（数はすべてこちら） ================= */

  /** 点 P を見る向き。スリットの中心から P へ向かう向き */
  function sinThetaAt(st, y) {
    var dy = FL.cy - y, dx = screenX(st) - FL.gx;
    return dy / Math.hypot(dx, dy);
  }
  /** 隣りあう点の波のずれ (a/K) sinθ [nm] */
  function deltaPtAt(st, y) { return (st.slitA / st.K) * sinThetaAt(st, y); }
  /** スリットの両はしの波のずれ a sinθ [nm]（暗線条件に使う） */
  function deltaFullAt(st, y) { return st.slitA * sinThetaAt(st, y); }

  /** K 個の点を足したときの振幅（そろったときを 1 とする） */
  function ampK(K, a, sinT, lambda) {
    var b = Math.PI * (a / K) * sinT / lambda;
    var s = Math.sin(b);
    if (Math.abs(s) < 1e-12) return 1;
    return Math.abs(Math.sin(K * b) / (K * s));
  }
  function ampAt(st, sinT) { return ampK(st.K, st.slitA, sinT, st.lambda); }

  /** K → ∞ の本当の分布 |sin α / α|（α ＝ π a sinθ / λ） */
  function envAt(st, sinT) {
    var al = Math.PI * st.slitA * sinT / st.lambda;
    if (Math.abs(al) < 1e-9) return 1;
    return Math.abs(Math.sin(al) / al);
  }

  /** sinθ ＝ s になるスクリーン上の y */
  function yOfSin(st, s) {
    if (!(Math.abs(s) < 0.9999)) return null;
    var t = s / Math.sqrt(1 - s * s);            // tanθ
    return FL.cy - t * (screenX(st) - FL.gx);
  }

  /* ---------- 場のキャッシュ（左の 2 次元の図だけに使う） ---------- */
  var cache = { key: '', A: null, B: null, S: null, w: 0, h: 0 };
  function fieldKey(st) { return [st.slitA, st.lambda, st.K, FL.aw].join('|'); }

  function buildField(st) {
    var w = Math.floor((FL.x1 - FL.x0) / FL.step);
    var h = Math.floor((FL.y1 - FL.y0) / FL.step);
    var A = new Float32Array(w * h), B = new Float32Array(w * h), S = new Float32Array(w * h);
    var lamPx = st.lambda / nmPerPx(st);
    var k = 2 * Math.PI / lamPx;
    var ys = [];
    for (var i = 0; i < st.K; i++) ys.push(ptY(st, i));
    for (var j = 0; j < h; j++) {
      var y = FL.y0 + j * FL.step;
      for (var ii = 0; ii < w; ii++) {
        var x = FL.x0 + ii * FL.step;
        var a = 0, b = 0, sm = 0;
        for (var s = 0; s < ys.length; s++) {
          var dx = x - FL.gx, dy = y - ys[s];
          var r = Math.sqrt(dx * dx + dy * dy);
          if (dx < 2) { a = 0; b = 0; sm = 0; break; }
          var ph = k * r;
          var amp = 1 / Math.sqrt(Math.max(r, 40) / 40);
          a += amp * Math.cos(ph);
          b += amp * Math.sin(ph);
          sm += amp;
        }
        A[j * w + ii] = a; B[j * w + ii] = b;
        S[j * w + ii] = (sm > 1e-6) ? sm : 1e9;
      }
    }
    return { A: A, B: B, S: S, w: w, h: h };
  }

  function ensureField(st) {
    var key = fieldKey(st);
    if (key !== cache.key) {
      var f = buildField(st);
      cache = { key: key, A: f.A, B: f.B, S: f.S, w: f.w, h: f.h };
    }
    return cache;
  }

  var buf = { cv: null, ctx: null, img: null, w: 0, h: 0 };
  function ensureBuf(w, h) {
    if (buf.w !== w || buf.h !== h) {
      buf.cv = document.createElement('canvas');
      buf.cv.width = w; buf.cv.height = h;
      buf.ctx = buf.cv.getContext('2d');
      buf.img = buf.ctx.createImageData(w, h);
      buf.w = w; buf.h = h;
    }
    return buf;
  }

  function drawSnapshot(ctx, st) {
    var f = ensureField(st);
    var b = ensureBuf(f.w, f.h);
    var wt = 2 * Math.PI * (P.V_NM_PER_S / st.lambda) * (st.t || 0);
    var cw = Math.cos(wt), sw = Math.sin(wt);
    var dat = b.img.data;
    for (var i = 0; i < f.w * f.h; i++) {
      var v = (-sw * f.A[i] + cw * f.B[i]) / f.S[i];
      var u = v > 1 ? 1 : (v < -1 ? -1 : v);
      var m = Math.pow(Math.abs(u), 0.75);
      var r, g, bl;
      if (u >= 0) { r = 255 - 23 * m; g = 255 - 121 * m; bl = 255 - 213 * m; }
      else { r = 255 - 224 * m; g = 255 - 139 * m; bl = 255 - 47 * m; }
      dat[i * 4] = r; dat[i * 4 + 1] = g; dat[i * 4 + 2] = bl; dat[i * 4 + 3] = 255;
    }
    b.ctx.putImageData(b.img, 0, 0);
    ctx.save();
    ctx.beginPath();
    ctx.rect(FL.x0, FL.y0, screenX(st) - FL.x0, FL.y1 - FL.y0);
    ctx.clip();
    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(b.cv, FL.x0, FL.y0, f.w * FL.step, f.h * FL.step);
    ctx.restore();
  }

  /* ---------- スリット板 ---------- */
  function slitPlate(ctx, st) {
    var x = FL.gx;
    var top = FL.cy - FL.aw / 2, btm = FL.cy + FL.aw / 2;
    ctx.save();
    ctx.fillStyle = COL.plate;
    ctx.fillRect(x - 10, FL.y0, 14, top - FL.y0);
    ctx.fillRect(x - 10, btm, 14, FL.y1 - btm);
    ctx.strokeStyle = COL.plateEdge; ctx.lineWidth = 1.2;
    ctx.strokeRect(x - 10, FL.y0, 14, top - FL.y0);
    ctx.strokeRect(x - 10, btm, 14, FL.y1 - btm);
    // 入射光（スリットの高さの範囲にだけ）
    for (var yy = top + 12; yy < btm - 6; yy += 26) {
      D.arrow(ctx, D.vec(FL.x0 + 6, yy), D.vec(1, 0), x - 32 - FL.x0, COL.rayDim, 1.5, 6);
    }
    // 考える点（素元波の源）。多いときは 12 個まで描き、「…」で示す
    var n = Math.min(st.K, PT_MAX);
    for (var i = 0; i < n; i++) {
      var py = (st.K <= PT_MAX) ? ptY(st, i)
        : top + FL.aw * (i + 0.5) / n;         // 13 個以上は等間隔の代表だけ
      ctx.beginPath(); ctx.arc(x - 3, py, 2.6, 0, Math.PI * 2);
      ctx.fillStyle = '#a12a1c'; ctx.fill();
    }
    if (st.K > PT_MAX) {
      ctx.font = D.font(11, true);
      ctx.fillStyle = '#a12a1c';
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText('（点は代表だけ描画。計算は K ＝ ' + st.K + ' 個）', x + 12, top - 12);
    }
    ctx.font = D.font(11, true);
    ctx.fillStyle = '#2b5a78';
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText('単スリット', x, FL.y1 + 6);
    // スリットの幅 a
    D.dimLine(ctx, D.vec(x - 20, top), D.vec(x - 20, btm), 'D', '#3a4550', 11);
    ctx.restore();
  }

  /* ---------- スクリーン ---------- */
  var scrCache = { key: '', cv: null };

  function screenStrip(st) {
    var key = [st.slitA, st.lambda, st.K, screenX(st)].join('|');
    if (key === scrCache.key) return scrCache.cv;
    var h = FL.y1 - FL.y0;
    var cv = document.createElement('canvas');
    cv.width = 1; cv.height = h;
    var g = cv.getContext('2d');
    var img = g.createImageData(1, h);
    var pc = D.pureColor(st.lambda);
    var SUB = 24;
    for (var i = 0; i < h; i++) {
      // 「隣りあう点のずれ ＝ λ の整数倍」（＝K 個ぜんぶそろう向き）をまたぐ px は最大
      var q0 = deltaPtAt(st, FL.y0 + i) / st.lambda;
      var q1 = deltaPtAt(st, FL.y0 + i + 1) / st.lambda;
      var lo = Math.min(q0, q1), hi = Math.max(q0, q1);
      var v;
      if (Math.floor(hi) > Math.floor(lo) || lo === Math.floor(lo)) {
        v = 1;
      } else {
        v = 0;
        for (var k = 0; k < SUB; k++) {
          var y = FL.y0 + i + (k + 0.5) / SUB;
          v = Math.max(v, ampAt(st, sinThetaAt(st, y)));
        }
      }
      v = Math.pow(v, 1.1);
      img.data[i * 4] = Math.round(pc.r * v);
      img.data[i * 4 + 1] = Math.round(pc.g * v);
      img.data[i * 4 + 2] = Math.round(pc.b * v);
      img.data[i * 4 + 3] = 255;
    }
    g.putImageData(img, 0, 0);
    scrCache = { key: key, cv: cv };
    return cv;
  }

  /**
   * スクリーンのすぐ右の、光の強度分布のグラフ。
   * 赤 ＝ いまの K 個での分布。灰の破線 ＝ 本当の単スリットの分布（K → ∞）。
   * K を増やすと赤が灰にぴったり重なっていく——それがこのモードの見せ場。
   */
  function intensityGraph(ctx, st, sx) {
    var x0 = sx + SCR.w + 12, w = 62;
    var y0 = FL.y0, y1 = FL.y1;
    var y, i;
    ctx.save();
    ctx.fillStyle = 'rgba(255,255,255,0.88)';
    ctx.fillRect(x0 - 4, y0, w + 14, y1 - y0);
    ctx.strokeStyle = '#b9c0c8'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(x0 + 0.5, y0); ctx.lineTo(x0 + 0.5, y1); ctx.stroke();
    // 本当の分布（K → ∞）
    if (st.showEnv) {
      ctx.beginPath();
      for (y = y0; y <= y1; y += 1) {
        var fe = envAt(st, sinThetaAt(st, y));
        if (y === y0) ctx.moveTo(x0 + fe * fe * w, y); else ctx.lineTo(x0 + fe * fe * w, y);
      }
      ctx.strokeStyle = '#7a848e'; ctx.lineWidth = 1.4;
      ctx.setLineDash([5, 4]); ctx.stroke(); ctx.setLineDash([]);
    }
    // いまの K 個での分布（うすい塗りつき）
    var pts = [];
    for (y = y0; y <= y1; y += 1) {
      var f = ampAt(st, sinThetaAt(st, y));
      pts.push([x0 + f * f * w, y]);
    }
    ctx.beginPath();
    ctx.moveTo(x0, y0);
    for (i = 0; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
    ctx.lineTo(x0, y1);
    ctx.closePath();
    ctx.fillStyle = 'rgba(208,52,44,0.10)'; ctx.fill();
    ctx.beginPath();
    for (i = 0; i < pts.length; i++) {
      if (i === 0) ctx.moveTo(pts[i][0], pts[i][1]); else ctx.lineTo(pts[i][0], pts[i][1]);
    }
    ctx.strokeStyle = '#d0342c'; ctx.lineWidth = 1.6; ctx.lineJoin = 'round';
    ctx.stroke();
    // 暗線の位置の目もり（a sinθ ＝ mλ）
    if (st.showDark) {
      ctx.strokeStyle = '#8b3fa8'; ctx.lineWidth = 1.2;
      for (var m = 1; m < 40; m++) {
        var sgn;
        var sD = m * st.lambda / st.slitA;
        if (!(sD < 1)) break;
        for (sgn = -1; sgn <= 1; sgn += 2) {
          var yb = yOfSin(st, sgn * sD);
          if (yb === null || yb < y0 + 2 || yb > y1 - 2) continue;
          ctx.beginPath(); ctx.moveTo(x0, yb); ctx.lineTo(x0 + 16, yb); ctx.stroke();
        }
      }
    }
    ctx.font = D.font(10.5, true);
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    var t = '光の強度分布';
    var tw = ctx.measureText(t).width;
    ctx.fillStyle = 'rgba(255,255,255,0.92)';
    ctx.fillRect(x0 + 3, y0 + 4, tw + 6, 15);
    ctx.fillStyle = '#a12a1c';
    ctx.fillText(t, x0 + 6, y0 + 6);
    if (st.showEnv) {
      ctx.font = D.font(10);
      var t2 = '灰の破線＝本当の分布';
      var tw2 = ctx.measureText(t2).width;
      ctx.fillStyle = 'rgba(255,255,255,0.92)';
      ctx.fillRect(x0 + 3, y1 - 20, tw2 + 6, 15);
      ctx.fillStyle = '#5b6672';
      ctx.fillText(t2, x0 + 6, y1 - 18);
    }
    ctx.restore();
  }

  function screen(ctx, st) {
    var sx = screenX(st);
    ctx.save();
    ctx.fillStyle = '#15171a';
    ctx.fillRect(sx, FL.y0, SCR.w, FL.y1 - FL.y0);
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(screenStrip(st), 0, 0, 1, FL.y1 - FL.y0,
      sx, FL.y0, SCR.w, FL.y1 - FL.y0);
    ctx.imageSmoothingEnabled = true;
    ctx.strokeStyle = '#8a949e'; ctx.lineWidth = 1.2;
    ctx.strokeRect(sx + 0.5, FL.y0 + 0.5, SCR.w, FL.y1 - FL.y0);
    ctx.font = D.font(11, true);
    ctx.fillStyle = '#7a6a48';
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText('スクリーン', sx + SCR.w / 2, FL.y1 + 6);
    ctx.font = D.font(11);
    var dnm = (sx - FL.gx) * nmPerPx(st);
    var dtxt = (dnm < 1e6) ? ((dnm / 1000).toFixed(1) + ' μm') : ((dnm / 1e6).toFixed(2) + ' mm');
    D.dimLine(ctx, D.vec(FL.gx, FL.y1 - 6), D.vec(sx, FL.y1 - 6),
      'スリットからスクリーンまで ' + dtxt, '#6f6754', 12);
    ctx.restore();
    intensityGraph(ctx, st, sx);
    // ---- 左右に動かすつまみ ----
    var hx = sx + SCR.w / 2, hy = FL.y0 - 13;
    var txt = '◀ スクリーンの位置 ▶';
    ctx.save();
    ctx.font = D.font(11, true);
    var w = ctx.measureText(txt).width + 18;
    D.roundRect(ctx, hx - w / 2, hy - 11, w, 22, 8);
    ctx.fillStyle = st.hoverBtn === 'scrx' ? '#eaf1fa' : 'rgba(255,255,255,0.95)';
    ctx.fill();
    ctx.strokeStyle = '#1663b5'; ctx.lineWidth = 1.4; ctx.stroke();
    ctx.fillStyle = '#1a4e86';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(txt, hx, hy + 1);
    ctx.restore();
    D.addHit(hx - w / 2, hy - 13, w, 26, 'scrx');
  }

  /* ---------- 暗線の向きの線 ----------
   * 暗線は a sinθ ＝ mλ（m ＝ 1, 2, …）。スリットの中心からのまっすぐな線。
   * 中央（θ ＝ 0）は最も明るい。
   */
  var C_DARK = '#8b3fa8', C_CTR = '#0d7a3f';

  function ray(ctx, st, s, color, dash, width) {
    if (!(Math.abs(s) < 1)) return null;
    var u = D.vec(Math.sqrt(1 - s * s), -s);
    var t = (screenX(st) - FL.gx) / u.x;
    if (u.y < -1e-9) t = Math.min(t, (FL.cy - FL.y0) / -u.y);
    ctx.save();
    ctx.strokeStyle = color; ctx.lineWidth = width; ctx.lineCap = 'round';
    if (dash) ctx.setLineDash(dash);
    for (var sgn = -1; sgn <= 1; sgn += 2) {
      ctx.beginPath();
      ctx.moveTo(FL.gx, FL.cy);
      ctx.lineTo(FL.gx + u.x * t, FL.cy + sgn * u.y * t);
      ctx.stroke();
    }
    ctx.restore();
    return true;
  }

  function darkLines(ctx, st) {
    if (!st.showDark) return;
    for (var m = 1; m < 40; m++) {
      if (!ray(ctx, st, m * st.lambda / st.slitA, C_DARK, [7, 5], 1.4)) break;
    }
    // 中央（最も明るい向き）
    ctx.save();
    ctx.strokeStyle = C_CTR; ctx.lineWidth = 2.2; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(FL.gx, FL.cy); ctx.lineTo(screenX(st), FL.cy); ctx.stroke();
    ctx.restore();
  }

  /** 暗線の次数の名ふだ */
  function darkLabels(ctx, st) {
    if (!st.showDark) return;
    ctx.save();
    ctx.font = D.font(11, true);
    for (var m = 1; m < 40; m++) {
      var s = m * st.lambda / st.slitA;
      if (!(s < 1)) break;
      var u = D.vec(Math.sqrt(1 - s * s), -s);
      var t = (screenX(st) - FL.gx) / u.x;
      if (u.y < -1e-9) t = Math.min(t, (FL.cy - FL.y0) / -u.y);
      var ex = FL.gx + u.x * t * 0.72, ey = FL.cy + u.y * t * 0.72;
      var txt = '暗線 m = ' + m;
      var w = ctx.measureText(txt).width;
      var lx = P.clamp(ex - w / 2, FL.gx + 20, screenX(st) - w - 18);
      var ly = P.clamp(ey - 14, FL.y0 + 12, FL.y1 - 12);
      D.roundRect(ctx, lx - 5, ly - 9, w + 10, 18, 5);
      ctx.fillStyle = 'rgba(255,255,255,0.9)'; ctx.fill();
      ctx.strokeStyle = C_DARK; ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = C_DARK;
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText(txt, lx, ly + 1);
    }
    ctx.restore();
  }

  /** 図の中の凡例 */
  function legend(ctx, st) {
    if (!st.showDark) return;
    var x = FL.x0 + 12, y = FL.y1 - 26;
    var items = [
      ['中央（最も明るい）', C_CTR, 0],
      ['暗線の向き（本当のスリット）　D sinθ ＝ mλ', C_DARK, 1],
      ['　中央の明るい帯の幅は、となりの帯の 2 倍', '#5b6672', 2]
    ];
    ctx.save();
    ctx.font = D.font(11, true);
    var w = 0, i;
    for (i = 0; i < items.length; i++) w = Math.max(w, ctx.measureText(items[i][0]).width);
    D.roundRect(ctx, x, y - items.length * 18 + 4, w + 52, items.length * 18 + 8, 6);
    ctx.fillStyle = 'rgba(255,255,255,0.86)'; ctx.fill();
    ctx.strokeStyle = '#c9d2da'; ctx.lineWidth = 1; ctx.stroke();
    for (i = 0; i < items.length; i++) {
      var yy = y - (items.length - 1 - i) * 18 - 4;
      if (items[i][2] !== 2) {
        ctx.strokeStyle = items[i][1]; ctx.lineWidth = items[i][2] ? 1.4 : 2.2;
        ctx.setLineDash(items[i][2] ? [7, 5] : []);
        ctx.beginPath(); ctx.moveTo(x + 10, yy); ctx.lineTo(x + 40, yy); ctx.stroke();
        ctx.setLineDash([]);
      }
      ctx.fillStyle = items[i][1];
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText(items[i][0], x + 48, yy + 1);
    }
    ctx.restore();
  }

  /* ---------- 点 P（スクリーンの上だけを動く） ---------- */
  function pointAt(st) {
    // はじめは「1 番めの暗線」の少し内側（明るい帯の中）に置く
    var y0 = yOfSin(st, 0.5 * st.lambda / st.slitA);
    if (y0 === null || y0 < FL.y0 + 8) y0 = FL.cy - 120;
    var y = (st.fyS === undefined || st.fyS === null) ? y0 : st.fyS;
    return D.vec(screenX(st), P.clamp(y, FL.y0 + 8, FL.y1 - 8));
  }

  /** 各点から P へ向かう光（平行とみなせるので、向きはみな同じ） */
  function pointWaves(ctx, st, p) {
    var wt = 2 * Math.PI * (P.V_NM_PER_S / st.lambda) * (st.t || 0);
    var lamPx = st.lambda / nmPerPx(st);
    var k = 2 * Math.PI / lamPx;
    var n = Math.min(st.K, PT_MAX);
    ctx.save();
    ctx.beginPath();
    ctx.rect(FL.gx, FL.y0, screenX(st) - FL.gx, FL.y1 - FL.y0);
    ctx.clip();
    for (var i = 0; i < n; i++) {
      var fy = (st.K <= PT_MAX) ? ptY(st, i)
        : FL.cy - FL.aw / 2 + FL.aw * (i + 0.5) / n;
      var from = D.vec(FL.gx + 2, fy);
      var dx = p.x - from.x, dy = p.y - from.y;
      var Lp = Math.hypot(dx, dy);
      var ux = dx / Lp, uy = dy / Lp, nx = -uy, ny = ux;
      ctx.strokeStyle = 'rgba(20,30,45,0.55)'; ctx.lineWidth = 1.1;
      ctx.lineJoin = 'round';
      ctx.beginPath();
      var steps = Math.max(40, Math.round(Lp / 1.5));
      for (var s = 0; s <= steps; s++) {
        var e = Lp * s / steps;
        var u = Math.sin(k * e - wt) * 4;
        var x = from.x + ux * e + nx * u;
        var y = from.y + uy * e + ny * u;
        if (s === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
    ctx.restore();
    ctx.save();
    ctx.beginPath(); ctx.arc(p.x + SCR.w / 2, p.y, 7, 0, Math.PI * 2);
    ctx.fillStyle = '#ffffff'; ctx.fill();
    ctx.strokeStyle = '#d0342c'; ctx.lineWidth = 2.4; ctx.stroke();
    ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    ctx.font = D.font(12, true);
    var tag = 'P（↑↓ ドラッグ）';
    var tw = ctx.measureText(tag).width;
    D.roundRect(ctx, p.x - 12 - tw - 8, p.y - 11, tw + 16, 22, 6);
    ctx.fillStyle = 'rgba(255,255,255,0.92)'; ctx.fill();
    ctx.strokeStyle = '#d0342c'; ctx.lineWidth = 1.2; ctx.stroke();
    ctx.fillStyle = '#d0342c';
    ctx.fillText(tag, p.x - 12, p.y + 1);
    ctx.restore();
  }

  /* ---------- 右わき：P に届く波をたてに並べる ---------- */
  function wavesPanel(ctx, st, p) {
    var x0 = PN.x0, x1 = PN.x1;
    var wx0 = x0 + 66, wx1 = x1 - 14;
    var wt = 2 * Math.PI * (P.V_NM_PER_S / st.lambda) * (st.t || 0);
    var deltaPt = deltaPtAt(st, p.y);              // 隣りあう点の波のずれ [nm]
    var phi = 2 * Math.PI * deltaPt / st.lambda;
    var K = st.K, nShow = Math.min(NSHOW, K);
    var i, j;
    var top = PN.y0 + 42, gap = 23, ampR = 9;
    var sumCy = 448, full = 72, unit = full;

    ctx.save();
    D.roundRect(ctx, x0, PN.y0, x1 - x0, PN.y1 - PN.y0, 10);
    ctx.fillStyle = '#fbfcfe'; ctx.fill();
    ctx.strokeStyle = '#c9d2da'; ctx.lineWidth = 1.3; ctx.stroke();

    ctx.font = D.font(12.5, true);
    ctx.fillStyle = '#1a4e86';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText('点 P に届く波（隣りあう点のずれ ＝ (D/K) sinθ）', x0 + 14, PN.y0 + 16);

    var steps = 180;
    for (i = 0; i < nShow; i++) {
      var rowY = top + i * gap;
      ctx.strokeStyle = 'rgba(170,170,178,0.45)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(wx0, rowY); ctx.lineTo(wx1, rowY); ctx.stroke();
      ctx.strokeStyle = COL.ray; ctx.lineWidth = 1.5; ctx.lineJoin = 'round';
      ctx.beginPath();
      for (j = 0; j <= steps; j++) {
        var e = (wx1 - wx0) * j / steps;
        var u = Math.sin(2 * Math.PI * e / PN.lam + i * phi - wt);
        if (j === 0) ctx.moveTo(wx0 + e, rowY - u * ampR);
        else ctx.lineTo(wx0 + e, rowY - u * ampR);
      }
      ctx.stroke();
      ctx.font = D.font(10);
      ctx.fillStyle = '#5b6672';
      ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
      ctx.fillText((i + 1) + ' 個め', wx0 - 8, rowY);
    }
    var lastY = top + (nShow - 1) * gap;
    ctx.font = D.font(11);
    ctx.fillStyle = '#6f6754';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText(K > NSHOW
      ? '…このあと ' + (K - NSHOW) + ' 個、同じずれで続きます'
      : 'ぜんぶで ' + K + ' 個', wx0, lastY + 13);

    // ---- 合成波（K 個ぜんぶ） ----
    var sy0 = 318;
    ctx.strokeStyle = '#e6e9ee'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(x0 + 8, sy0); ctx.lineTo(x1 - 8, sy0); ctx.stroke();

    ctx.font = D.font(11.5, true);
    ctx.fillStyle = '#5a3a7a';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText('K ＝ ' + K + ' 個ぜんぶ足すと（合成波）', x0 + 14, sy0 + 16);

    ctx.strokeStyle = 'rgba(120,128,136,0.55)'; ctx.lineWidth = 1;
    ctx.setLineDash([5, 4]);
    ctx.beginPath();
    ctx.moveTo(wx0, sumCy - full); ctx.lineTo(wx1, sumCy - full);
    ctx.moveTo(wx0, sumCy + full); ctx.lineTo(wx1, sumCy + full);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.strokeStyle = 'rgba(170,170,178,0.55)';
    ctx.beginPath(); ctx.moveTo(wx0, sumCy); ctx.lineTo(wx1, sumCy); ctx.stroke();

    ctx.font = D.font(10);
    ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    var gl = '全部そろったときの振幅（' + K + ' 個ぶん）';
    var glw = ctx.measureText(gl).width;
    ctx.fillStyle = '#fbfcfe';
    ctx.fillRect(wx1 - glw - 6, sumCy - full - 8, glw + 8, 16);
    ctx.fillStyle = '#6f6754';
    ctx.fillText(gl, wx1 - 2, sumCy - full);

    var half = phi / 2, sh = Math.sin(half);
    var env = (Math.abs(sh) < 1e-12) ? K : Math.sin(K * half) / sh;
    ctx.strokeStyle = COL.sum; ctx.lineWidth = 2.4; ctx.lineJoin = 'round';
    ctx.beginPath();
    for (j = 0; j <= steps; j++) {
      var e2 = (wx1 - wx0) * j / steps;
      var psi = 2 * Math.PI * e2 / PN.lam - wt;
      var v = env * Math.sin(psi + (K - 1) * half) / K;
      if (j === 0) ctx.moveTo(wx0 + e2, sumCy - v * unit);
      else ctx.lineTo(wx0 + e2, sumCy - v * unit);
    }
    ctx.stroke();

    // ---- 数値 ----
    var frac = ampAt(st, sinThetaAt(st, p.y));
    var kind = frac > 0.9 ? 'ほぼそろって強めあう' : (frac < 0.1 ? 'ほぼ完全に打ち消しあう' : '部分的に打ち消しあう');
    var kc = frac > 0.9 ? '#1b6b34' : (frac < 0.1 ? '#a12a1c' : '#8a6d00');
    var ty = 544;
    ctx.font = D.font(11.5);
    ctx.fillStyle = '#5b6672';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText('合成波の振幅（そろったときを 1 とすると）', x0 + 14, ty);
    ctx.font = D.font(17, true);
    ctx.fillStyle = kc;
    ctx.fillText(frac.toFixed(4) + '　→　' + kind, x0 + 14, ty + 27);
    ctx.font = D.font(11);
    ctx.fillStyle = '#6f6754';
    ctx.textBaseline = 'bottom';
    ctx.fillText('※ この枠の中だけ、波長を見やすく拡大しています。', x0 + 14, PN.y1 - 24);
    ctx.fillText('　 波どうしのずれの割合は本当の値です。', x0 + 14, PN.y1 - 9);
    ctx.restore();
  }

  /* ---------- 情報カード（62 と同じ作り） ---------- */
  function infoCard(ctx, st, lines, title2, color) {
    var x = 10, y = 62, w = FL.x0 - 26;
    ctx.save();
    ctx.font = D.font(11.5);
    var rows = 0, q;
    for (q = 0; q < lines.length; q++) rows += wrap(ctx, lines[q], w - 26).length;
    var h = 20 + rows * 15 + lines.length * 5;
    D.roundRect(ctx, x, y, w, h, 8);
    ctx.fillStyle = '#ffffff'; ctx.fill();
    ctx.strokeStyle = color; ctx.lineWidth = 1.4; ctx.stroke();
    ctx.font = D.font(11.5, true);
    var tw = ctx.measureText(title2).width + 18;
    D.roundRect(ctx, x + 12, y - 10, tw, 20, 10);
    ctx.fillStyle = color; ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(title2, x + 21, y + 1);
    ctx.font = D.font(11.5);
    ctx.fillStyle = '#28405c';
    ctx.textBaseline = 'top';
    var yy = y + 12;
    for (var i = 0; i < lines.length; i++) {
      var parts = wrap(ctx, lines[i], w - 26);
      for (var j = 0; j < parts.length; j++) { ctx.fillText(parts[j], x + 13, yy); yy += 15; }
      yy += 5;
    }
    ctx.restore();
  }

  function wrap(ctx, s, maxw) {
    var out = [], line = '';
    for (var i = 0; i < s.length; i++) {
      var t = line + s.charAt(i);
      if (ctx.measureText(t).width > maxw && line) { out.push(line); line = s.charAt(i); }
      else line = t;
    }
    if (line) out.push(line);
    return out;
  }

  function title(ctx, t, col, bg, edge) {
    ctx.save();
    ctx.font = D.font(13.5, true);
    var w = ctx.measureText(t).width + 26;
    D.roundRect(ctx, 12, 10, w, 28, 8);
    ctx.fillStyle = bg; ctx.fill();
    ctx.strokeStyle = edge; ctx.lineWidth = 1.6; ctx.stroke();
    ctx.fillStyle = col;
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(t, 25, 25);
    ctx.restore();
  }

  /* ================= 本体 ================= */
  function render(ctx, st) {
    ctx.save();
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, L.W, L.H);
    ctx.restore();

    drawSnapshot(ctx, st);
    ctx.save();
    ctx.strokeStyle = '#c9d2da'; ctx.lineWidth = 1;
    ctx.strokeRect(FL.x0 + 0.5, FL.y0 + 0.5, screenX(st) - FL.x0, FL.y1 - FL.y0);
    ctx.restore();
    darkLines(ctx, st);
    slitPlate(ctx, st);
    screen(ctx, st);
    var p = pointAt(st);
    pointWaves(ctx, st, p);
    darkLabels(ctx, st);
    legend(ctx, st);
    wavesPanel(ctx, st, p);

    var npx = nmPerPx(st);
    var sinT = sinThetaAt(st, p.y);
    var dFull = deltaFullAt(st, p.y);
    var frac = ampAt(st, sinT);
    infoCard(ctx, st, [
      'P の向き　sinθ ＝ ' + sinT.toFixed(3),
      'スリットの両はしの波のずれ',
      '　D sinθ ＝ ' + Math.round(Math.abs(dFull)) + ' nm',
      '　　　　　＝ ' + D.about(Math.abs(dFull) / st.lambda) + ' λ',
      'K ＝ ' + st.K + ' 個の合成',
      '　' + frac.toFixed(4) + '　'
        + (frac > 0.9 ? 'ほぼそろう' : (frac < 0.1 ? 'ほぼ 0' : '部分的に打ち消す')),
      '暗線は D sinθ ＝ mλ の向き。K を増やすと、グラフが灰の破線（本当の分布）に近づきます。'
    ], '点 P での重ね合わせ', '#8b3fa8');

    // 見出しはタブの名前と同じにする
    title(ctx, '補足：単スリットの問題（難関大頻出）', '#6d2f86', '#faf3fd', '#8b3fa8');

    ctx.save();
    ctx.font = D.font(11);
    ctx.fillStyle = '#6f6754';
    ctx.textAlign = 'right'; ctx.textBaseline = 'top';
    ctx.fillText('左の図は K ＝ ' + st.K + ' 個の点から出る波を縮尺どおりに足したもの（1 px ＝ '
      + npx.toFixed(0) + ' nm' + (st.K > PT_MAX ? '、点の描画は ' + PT_MAX + ' 個まで' : '')
      + '）。スクリーンとグラフは平行光線で計算。', PN.x0 - 28, FL.y1 + 22);
    ctx.restore();
  }

  /** スクリーンの上（P をつかめる範囲）か */
  function inField(st, x, y) {
    var sx = screenX(st);
    return x > sx - 26 && x < sx + SCR.w + 26 && y > FL.y0 && y < FL.y1;
  }

  /* 点 P は「a sinθ ＝ q λ」の q が 0.05 きざみになるように動かす。
     こうすると暗線（q が整数）にぴったり止められる。 */
  var Q_STEP = 0.05;
  function setPoint(st, x, y) {
    var yy = P.clamp(y, FL.y0 + 8, FL.y1 - 8);
    var q = deltaFullAt(st, yy) / st.lambda;
    q = Math.round(q / Q_STEP) * Q_STEP;
    var s = q * st.lambda / st.slitA;
    var ny = yOfSin(st, s);
    st.fyS = (ny === null) ? yy : P.clamp(ny, FL.y0 + 8, FL.y1 - 8);
  }

  /** スクリーンを左右に動かす */
  function moveScreen(st, x) {
    st.scrXS = P.clamp(x - FL.gx, SCR.min, SCR.max);
    if (st.fyS !== null && st.fyS !== undefined) setPoint(st, 0, st.fyS);
  }

  return {
    render: render, FL: FL, SCR: SCR, PN: PN, NSHOW: NSHOW, PT_MAX: PT_MAX,
    inField: inField, setPoint: setPoint, pointAt: pointAt,
    moveScreen: moveScreen, screenX: screenX,
    sinThetaAt: sinThetaAt, deltaPtAt: deltaPtAt, deltaFullAt: deltaFullAt,
    ampK: ampK, ampAt: ampAt, envAt: envAt, yOfSin: yOfSin, nmPerPx: nmPerPx, ptY: ptY
  };
})();
