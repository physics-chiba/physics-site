#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""youngs-experiment.html の自動テスト

  python3 test/run_test.py            … 1 回だけ実行
  python3 test/run_test.py --twice    … 2 回実行して、結果が完全一致するか確かめる

確かめること
  1. 物理の値が、手計算した基準値と合っているか（Δx ＝ 3.0 mm、薄膜 x ＝ −5.0 mm など）
  2. 展開バンドの波と、図の中の波が完全に一致するか
  3. 図に描いた経路差が「λ の何個ぶんか」と厳密に合っているか
  4. ページのエラーが 0 件、外部への通信が 0 件
  5. 320 / 360 / 390 / 768 / 1024 / 1440 px で横スクロールが出ないか
  6. 2 回走らせて、すべての値と DOM の文言が完全一致するか
"""
import asyncio
import json
import math
import os
import sys

from playwright.async_api import async_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
PAGE = os.path.join(os.path.dirname(HERE), 'youngs-experiment.html')
WIDTHS = [320, 360, 390, 768, 1024, 1440]

# ------------------------------------------------------------------ 場面
# 各場面は probe.set() に渡す設定。番号順に実行して snapshot を集める。
SCENES = [
    ('①既定', dict(mode='path', lambda_=600, d=200000, L=1.00, step=1, m=1, onlyBright=True, time=0)),
    ('①m=0', dict(mode='path', step=2, m=0)),
    ('①m=3', dict(mode='path', step=2, m=3)),
    ('①m=-2', dict(mode='path', step=3, m=-2)),
    ('①暗線', dict(mode='path', step=4, onlyBright=False, sinT=0.0015)),
    ('①暗線ボタン', dict(mode='path', step=3, onlyBright=True, m=1.5)),
    ('①短波長', dict(mode='path', lambda_=400, d=400000, L=2.00, step=4, onlyBright=True, m=2)),
    ('①白色光', dict(mode='path', light='white', lambda_=600, d=200000, L=1.00, step=1, m=1)),
    ('②既定', dict(mode='wave', light='mono', lambda_=600, d=200000, L=1.00, m=1, time=0.4)),
    ('②暗線', dict(mode='wave', onlyBright=False, sinT=0.0015, time=0.4)),
    ('③既定', dict(mode='deltax', lambda_=600, d=200000, L=1.00, onlyBright=True, m=1)),
    ('③d半分', dict(mode='deltax', d=100000)),
    ('③L2倍', dict(mode='deltax', d=200000, L=2.00)),
    ('補足入れる前', dict(mode='film', lambda_=600, d=200000, L=1.00, t=2000, n=1.50, inserted=False, time=0)),
    ('補足既定', dict(mode='film', inserted=True, step=4)),
    ('補足t=0', dict(mode='film', t=0)),
    ('補足n=1', dict(mode='film', t=2000, n=1.00)),
    ('補足最大', dict(mode='film', t=5000, n=1.80, step=1)),
    ('②同心円', dict(mode='wave', showCirc=True, m=2, time=0.7)),
    ('液体入れる前', dict(mode='liquid', light='mono', lambda_=600, d=200000, L=1.00, nl=1.30, dipped=False, m=1, time=0)),
    ('液体既定', dict(mode='liquid', dipped=True, step=3)),
    ('液体n=1', dict(mode='liquid', nl=1.00)),
    ('液体n=2', dict(mode='liquid', nl=2.00, step=1, m=2)),
    ('液体白色', dict(mode='liquid', light='white', nl=1.30, m=1)),
]

# ------------------------------------------------------- 手計算した基準値
# d = 0.20 mm, L = 1.0 m, λ = 600 nm  →  Δx = 3.0 mm、x₁ = 3.0 mm
# t = 2.0 μm, n′ = 1.5                →  m = 0 の位置 x = −5.0 mm（Δx は不変）
TOL = 1e-3          # mm 単位の許容（0.001 mm ＝ 1 μm）


def close(a, b, tol=TOL):
    return a is not None and b is not None and abs(a - b) <= tol


def check_numbers(shots):
    """基準値との照合。問題のリストを返す（空なら合格）"""
    bad = []
    by = {name: s for name, s in shots}

    s = by['①既定']['phys']
    if not close(s['dxApprox_mm'], 3.0):
        bad.append('①既定 Δx(式) = %s、期待 3.0 mm' % s['dxApprox_mm'])
    if not close(s['dxMeasured_mm'], 3.0):
        bad.append('①既定 Δx(実測) = %s、期待 3.0 mm' % s['dxMeasured_mm'])
    if not close(s['x_mm'], 3.0):
        bad.append('①既定 x₁ = %s、期待 3.0 mm' % s['x_mm'])
    if s['kind'] != 'strong':
        bad.append('①既定 は明線のはずが %s' % s['kind'])
    if not close(s['I'], 1.0, 1e-6):
        bad.append('①既定 I = %s、期待 1.0' % s['I'])

    s = by['①m=0']['phys']
    if not close(s['x_mm'], 0.0, 1e-9):
        bad.append('m=0 の位置 = %s、期待 0' % s['x_mm'])

    s = by['①暗線']['phys']
    # sinθ = 0.0015 → 経路差 = 300 nm = 0.5λ → 暗線
    if not close(s['ratio'], 0.5, 1e-6):
        bad.append('暗線の 経路差÷λ = %s、期待 0.5' % s['ratio'])
    if not close(s['I'], 0.0, 1e-9):
        bad.append('暗線の I = %s、期待 0' % s['I'])

    s = by['①暗線ボタン']['phys']
    if not (s['sel'] and s['sel']['dark'] and abs(s['sel']['m'] - 1.5) < 1e-9):
        bad.append('暗線ボタン m=1.5 を選んだのに sel = %s' % s['sel'])
    if not close(s['ratio'], 1.5, 1e-6) or not close(s['I'], 0.0, 1e-9):
        bad.append('暗線 m=1.5 の 経路差÷λ = %s、I = %s（期待 1.5、0）' % (s['ratio'], s['I']))
    s = by['①既定']['phys']
    if s['orders'] != [-3, -2, -1, 0, 1, 2, 3]:
        bad.append('既定で写る明線が m = −3〜3 ではありません: %s' % s['orders'])

    s = by['補足既定']['phys']
    if not close(s['extra_nm'], 1000.0, 1e-6):
        bad.append('(n′−1)t = %s nm、期待 1000 nm' % s['extra_nm'])
    if not close(s['x0_mm'], -5.0):
        bad.append('薄膜あり m=0 の位置 = %s、期待 −5.0 mm' % s['x0_mm'])
    if not close(s['x0Approx_mm'], -5.0, 1e-9):
        bad.append('薄膜あり 近似式の m=0 = %s、期待 −5.0 mm' % s['x0Approx_mm'])
    if not close(s['dxApprox_mm'], 3.0):
        bad.append('薄膜あり Δx = %s、期待 3.0 mm（不変）' % s['dxApprox_mm'])
    if not close(s['dxMeasured_mm'], 3.0):
        bad.append('薄膜あり Δx(実測) = %s、期待 3.0 mm（不変）' % s['dxMeasured_mm'])

    for name, want in (('補足t=0', 0.0), ('補足n=1', 0.0), ('補足入れる前', 0.0)):
        s = by[name]['phys']
        if not close(s['x0_mm'], want, 1e-9):
            bad.append('%s の m=0 の位置 = %s、期待 %s' % (name, s['x0_mm'], want))
        if not close(s['extra_nm'], 0.0, 1e-9):
            bad.append('%s の (n′−1)t = %s、期待 0' % (name, s['extra_nm']))
    if by['補足入れる前']['in']['film']['on']:
        bad.append('補足モードの最初の状態で、薄膜が入ったことになっています')

    # 液体モード：λ → λ/n なので Δx′ ＝ λL/(nd) ＝ Δx/n。m ＝ 0 は動かない
    s = by['液体既定']['phys']
    if not close(s['dxApprox_mm'], 3.0 / 1.3):
        bad.append('液体 n=1.3 の Δx′ = %s、期待 %.6f mm' % (s['dxApprox_mm'], 3.0 / 1.3))
    if not close(s['dxMeasured_mm'], 3.0 / 1.3):
        bad.append('液体 n=1.3 の Δx′(実測) = %s、期待 %.6f mm' % (s['dxMeasured_mm'], 3.0 / 1.3))
    if not close(s['x_mm'], 3.0 / 1.3):
        bad.append('液体 n=1.3 の x₁ = %s、期待 %.6f mm' % (s['x_mm'], 3.0 / 1.3))
    if not close(s['dxAir_mm'], 3.0):
        bad.append('液体 n=1.3 の空気中の Δx = %s、期待 3.0 mm' % s['dxAir_mm'])
    if not close(s['x0_mm'], 0.0, 1e-9):
        bad.append('液体 n=1.3 で m=0 が動いています: %s' % s['x0_mm'])
    if abs(s['nMed'] - 1.3) > 1e-9 or by['液体既定']['in']['lambda0'] != 600:
        bad.append('液体 n=1.3 の媒質の値がおかしい: nMed=%s λ₀=%s' % (s['nMed'], by['液体既定']['in']['lambda0']))
    if abs(by['液体既定']['in']['lambda'] - 600 / 1.3) > 1e-9:
        bad.append('液体 n=1.3 の媒質の中の波長 = %s、期待 %.6f' % (by['液体既定']['in']['lambda'], 600 / 1.3))
    s = by['液体n=1']['phys']
    if not close(s['dxApprox_mm'], 3.0) or abs(s['nMed'] - 1.0) > 1e-9:
        bad.append('液体 n=1 で空気中と同じ縞にもどっていません: Δx=%s nMed=%s' % (s['dxApprox_mm'], s['nMed']))
    s = by['液体n=2']['phys']
    if not close(s['dxApprox_mm'], 1.5) or not close(s['x_mm'], 3.0):
        bad.append('液体 n=2 の Δx′ = %s（期待 1.5）、x₂ = %s（期待 3.0）' % (s['dxApprox_mm'], s['x_mm']))
    s = by['液体入れる前']
    if s['in']['medium']['on'] or not close(s['phys']['dxApprox_mm'], 3.0):
        bad.append('液体モードの最初の状態がおかしい: %s / Δx=%s' % (s['in']['medium'], s['phys']['dxApprox_mm']))
    s = by['液体白色']['phys']
    if not close(s['dxApprox_mm'], 3.0 / 1.3):
        bad.append('液体（白色光）の Δx′ = %s、期待 %.6f mm' % (s['dxApprox_mm'], 3.0 / 1.3))

    s = by['③d半分']['phys']
    if not close(s['dxApprox_mm'], 6.0):
        bad.append('d を半分にしたときの Δx = %s、期待 6.0 mm' % s['dxApprox_mm'])
    s = by['③L2倍']['phys']
    if not close(s['dxApprox_mm'], 6.0):
        bad.append('L を 2 倍にしたときの Δx = %s、期待 6.0 mm' % s['dxApprox_mm'])

    # 展開バンドの波と図の中の波が完全一致すること／図に描いた経路差が正しいこと
    for name, shot in shots:
        f = shot['fig']
        if f['waveMatchWorst'] is None or f['waveMatchWorst'] > 1e-9:
            bad.append('%s：帯の波と図の波がずれています（最大 %s）' % (name, f['waveMatchWorst']))
        geo_ratio = shot['phys']['ratio'] - (shot['phys']['extra_nm'] / shot['in']['lambda'])
        if abs(f['sinDraw']) < 0.985 and abs(f['drawnRatio'] - geo_ratio) > 1e-6:
            bad.append('%s：図に描いた経路差 %s λ が、ほんとうの %s λ と合いません'
                       % (name, f['drawnRatio'], round(geo_ratio, 9)))

    # 厳密（tanθ）と近似（mλL/d）の差が、画面上で見えない程度か
    for name, shot in shots:
        p = shot['phys']
        if p['x0_mm'] is not None and p['x0Approx_mm'] is not None:
            ppm = shot['fig']['ppm']          # px / m
            diff_px = abs(p['x0_mm'] - p['x0Approx_mm']) / 1000.0 * ppm
            if diff_px > 0.5:
                bad.append('%s：厳密と近似の差が %.3f px（0.5 px 以内であること）' % (name, diff_px))
    return bad


async def run_once(pw, verbose=False):
    browser = await pw.chromium.launch()
    page = await browser.new_page(viewport={'width': 1400, 'height': 1000},
                                  device_scale_factor=1)
    errors, externals, console_errors, goat = [], [], [], []
    page.on('pageerror', lambda e: errors.append(str(e)))
    def on_console(m):
        if m.type != 'error':
            return
        # file:// で開くと GoatCounter の //gc.zgo.at が file://gc.zgo.at になって読めない。
        # 公開先（https）では正しく読まれるので、これだけは数えない
        loc = (m.location or {}).get('url', '') if hasattr(m, 'location') else ''
        if 'gc.zgo.at' in loc:
            goat.append('console: ' + loc)
            return
        console_errors.append(m.type + ': ' + m.text)
    page.on('console', on_console)

    def on_request(req):
        u = req.url
        if u.startswith('file:') or u.startswith('data:') or u.startswith('blob:'):
            return
        # GoatCounter（アクセス数のカウント）だけは、physics-site の他ページと同じく許す
        if 'gc.zgo.at/count.js' in u or 'goatcounter.com' in u:
            goat.append(u)
            return
        externals.append(u)
    page.on('request', on_request)

    await page.goto('file://' + PAGE)
    await page.wait_for_function('window.YG && YG.probe && YG.ui', timeout=15000)
    await page.wait_for_timeout(1200)     # KaTeX の画像化が終わるのを待つ

    shots = []
    for name, cfg in SCENES:
        js_cfg = dict(cfg)
        if 'lambda_' in js_cfg:
            js_cfg['lambda'] = js_cfg.pop('lambda_')
        await page.evaluate('cfg => YG.probe.set(cfg)', js_cfg)
        await page.wait_for_timeout(60)
        shots.append((name, await page.evaluate('YG.probe.snapshot()')))

    # モードをまたいだ設定の独立（前作で N′ が漏れたバグの再発防止）
    await page.evaluate("() => YG.probe.set({mode:'deltax', lambda:600, d:200000, L:1.00})")
    await page.evaluate("() => YG.probe.set({mode:'film', t:2000, n:1.50})")
    await page.evaluate("() => YG.probe.set({mode:'liquid', nl:1.30, dipped:true})")
    await page.evaluate("() => YG.probe.set({mode:'deltax', d:100000, L:2.00, lambda:450})")
    await page.evaluate("() => YG.probe.set({mode:'liquid'})")
    iso_liquid = await page.evaluate('YG.probe.snapshot()')
    await page.evaluate("() => YG.probe.set({mode:'film'})")
    iso_film = await page.evaluate('YG.probe.snapshot()')
    await page.evaluate("() => YG.probe.set({mode:'path'})")
    iso_path = await page.evaluate('YG.probe.snapshot()')
    await page.evaluate("() => YG.probe.set({mode:'deltax'})")
    iso_deltax = await page.evaluate('YG.probe.snapshot()')
    isolation = {'film': iso_film['in'], 'path': iso_path['in'], 'deltax': iso_deltax['in'],
                 'liquid': iso_liquid['in']}

    # 薄膜を入れるアニメーション：縞が動くのは「薄膜が光線を横切っているあいだ」だけ
    cov = await page.evaluate(
        '() => [0, 0.3, 0.6, 0.76, 0.88, 1].map(p => YG.modeFilm.coverageOf(p))')
    # 液体：満ちていくにつれて n が 1 → n に近づく
    covl = await page.evaluate(
        '() => [0, 0.25, 0.5, 0.75, 1].map(p => YG.modeLiquid.coverageOf(p))')

    # 横スクロールの確認（ふつうの状態と、ステップの図にマウスを乗せた状態の両方）
    await page.evaluate("() => YG.probe.set({mode:'path', step:2})")
    widths = {}
    for w in WIDTHS:
        await page.set_viewport_size({'width': w, 'height': 900})
        await page.wait_for_timeout(220)
        m = {}
        m['plain'] = await page.evaluate(
            '() => ({sw: document.documentElement.scrollWidth,'
            '        cw: document.documentElement.clientWidth})')
        # ホバーで拡大する図（#stepnow の中の SVG）に、実際にマウスを乗せて測る
        el = await page.query_selector('#stepnow .fig svg')
        if el:
            try:
                await el.hover(timeout=2000)
                await page.wait_for_timeout(320)
            except Exception:
                pass
        m['hover'] = await page.evaluate(
            '() => ({sw: document.documentElement.scrollWidth,'
            '        cw: document.documentElement.clientWidth})')
        await page.mouse.move(2, 2)
        await page.wait_for_timeout(120)
        widths[w] = m
    await page.set_viewport_size({'width': 1400, 'height': 1000})

    # 練習問題が 3 問できているか
    quiz = await page.evaluate("() => document.querySelectorAll('#quiz .q').length")
    # KaTeX が描けているか（data-tex の要素がすべて処理されたか）
    katex = await page.evaluate(
        "() => ({total: document.querySelectorAll('.eq[data-tex]').length,"
        "        done: document.querySelectorAll('.eq[data-tex][data-done=\"1\"]').length})")

    await browser.close()
    return {
        'shots': shots, 'widths': widths, 'quiz': quiz, 'katex': katex,
        'isolation': isolation, 'goat': goat, 'cov': cov, 'covl': covl,
        'errors': errors, 'console_errors': console_errors, 'externals': externals
    }


def report(res):
    bad = []
    if res['errors']:
        bad.append('ページのエラー %d 件: %s' % (len(res['errors']), res['errors'][:3]))
    if res['console_errors']:
        bad.append('コンソールのエラー %d 件: %s' % (len(res['console_errors']), res['console_errors'][:3]))
    if res['externals']:
        bad.append('外部への通信 %d 件: %s' % (len(res['externals']), res['externals'][:3]))
    if res['quiz'] != 3:
        bad.append('練習問題が %d 問（3 問のはず）' % res['quiz'])
    k = res['katex']
    if k['total'] == 0 or k['done'] != k['total']:
        bad.append('KaTeX の数式 %d / %d しか描けていません' % (k['done'], k['total']))
    for w, v in res['widths'].items():
        for how, label in (('plain', 'ふつう'), ('hover', '図にマウスを乗せた状態')):
            m = v[how]
            if m['sw'] > m['cw'] + 1:
                bad.append('幅 %d px（%s）で横スクロール（scrollWidth %d > clientWidth %d）'
                           % (w, label, m['sw'], m['cw']))

    # モードをまたいだ設定の独立
    iso = res['isolation']
    if not (iso['film']['d'] == 200000 and abs(iso['film']['L'] - 1.00) < 1e-9
            and iso['film']['lambda'] == 600):
        bad.append('補足モードの設定が③から漏れています: %s' % iso['film'])
    if not (iso['path']['d'] == 200000 and abs(iso['path']['L'] - 1.00) < 1e-9
            and iso['path']['lambda'] == 600):
        bad.append('①の設定が③から漏れています: %s' % iso['path'])
    if not (iso['deltax']['d'] == 100000 and abs(iso['deltax']['L'] - 2.00) < 1e-9
            and iso['deltax']['lambda'] == 450):
        bad.append('③の設定が、タブを行き来したあとに残っていません: %s' % iso['deltax'])
    if not (iso['liquid']['d'] == 200000 and abs(iso['liquid']['L'] - 1.00) < 1e-9
            and iso['liquid']['lambda0'] == 600 and iso['liquid']['medium']['inserted']):
        bad.append('液体モードの設定が③から漏れています: %s' % iso['liquid'])
    if iso['film']['film']['on'] is False or iso['film']['lambda0'] != 600:
        bad.append('薄膜モードの状態が、液体モードに引きずられています: %s' % iso['film'])

    # 薄膜のアニメーション：横切る前は 0、入りきれば 1、その間で単調に増える
    c = res['cov']
    if not (c[0] == 0 and c[1] == 0 and c[2] == 0 and 0 < c[3] < 1 and c[3] < c[4] <= 1 and c[5] == 1):
        bad.append('薄膜のアニメーションの進み方がおかしい: %s' % c)
    cl = res['covl']
    if not (cl[0] == 0 and all(cl[i] <= cl[i + 1] for i in range(4)) and cl[4] == 1 and 0 < cl[2] < 1):
        bad.append('液体のアニメーションの進み方がおかしい: %s' % cl)

    bad += check_numbers(res['shots'])
    return bad


async def main():
    twice = '--twice' in sys.argv
    if not os.path.exists(PAGE):
        print('ページがありません: %s（先に node build.js を実行してください）' % PAGE)
        return 1
    async with async_playwright() as pw:
        r1 = await run_once(pw)
        bad = report(r1)
        same = True
        if twice:
            r2 = await run_once(pw)
            bad += ['(2 回目) ' + b for b in report(r2)]
            a = json.dumps(r1['shots'], ensure_ascii=False, sort_keys=True)
            b = json.dumps(r2['shots'], ensure_ascii=False, sort_keys=True)
            same = (a == b)
            if not same:
                bad.append('2 回の結果が一致しません')
                for (n1, s1), (n2, s2) in zip(r1['shots'], r2['shots']):
                    if json.dumps(s1, sort_keys=True) != json.dumps(s2, sort_keys=True):
                        bad.append('  ちがう場面: ' + n1)
            wa = json.dumps(r1['widths'], sort_keys=True)
            wb = json.dumps(r2['widths'], sort_keys=True)
            if wa != wb:
                bad.append('2 回のレイアウト測定が一致しません')

    print('=' * 64)
    print('場面 %d / 幅 %s' % (len(r1['shots']), WIDTHS))
    print('ページのエラー: %d　コンソールのエラー: %d　外部への通信: %d（GoatCounter を除く。GoatCounter: %d）'
          % (len(r1['errors']), len(r1['console_errors']), len(r1['externals']), len(r1['goat'])))
    print('練習問題: %d 問　KaTeX: %d / %d' % (r1['quiz'], r1['katex']['done'], r1['katex']['total']))
    if twice:
        print('2 回の結果: %s' % ('完全一致' if same else '不一致'))
    print('-' * 64)
    key = dict(r1['shots'])
    for n in ('①既定', '補足既定', '③d半分', '液体既定'):
        p = key[n]['phys']
        print('%-8s Δx=%.4f mm  x=%.4f mm  x0=%.4f mm  I=%.4f'
              % (n, p['dxApprox_mm'], p['x_mm'], p['x0_mm'], p['I']))
    print('-' * 64)
    if bad:
        print('問題 %d 件' % len(bad))
        for b in bad:
            print('  ✗ ' + b)
        return 1
    print('問題 0 件　✓ すべて合格')
    return 0


if __name__ == '__main__':
    sys.exit(asyncio.run(main()))
