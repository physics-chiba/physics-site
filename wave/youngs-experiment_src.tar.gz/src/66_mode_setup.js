/* ===== 66_mode_setup.js ===== */
/* 「実験の概要」モード
 *
 * ①〜③の図は、d を見えるように広げ、λ をさらに誇張して描いている。
 * 生徒はそれを「本当の装置の見た目」だと思ってしまいやすい。
 * そこでこのモードでは、装置全体からダブルスリットへ「カメラで寄っていく」ようすを
 * 連続して見せ、①②③の拡大図が装置のどこを、どれくらい拡大したものなのかを実感させる。
 *
 *   場面 1　装置全体　　　　… 光源 Q → S₀ → ダブルスリット → スクリーン（斜め上から見た図）
 *   場面 2　ダブルスリットへズームアップ … 倍率とものさしが変わり、d ＝ 0.20 mm が見えてくる
 *   場面 3　さらにズームアップ … λ が見えるところまで寄ると、d は画面のはるか外
 *
 * 場面 2 と 3 の「視野の高さ」は 1 本の連続した関数でつないである（＝ずっと寄りつづける）。
 * 縮尺が場面ごとに変わるので、このモードでは①〜③の図の部品（誇張した拡大図）は使わない。
 */
window.YG = window.YG || {};
YG.modeSetup = (function () {
  'use strict';
  var P = YG.phys, D = YG.draw;
  var L = D.L, COL = D.COL;
  var vec = D.vec;

  var DUR = 20;                       // 3 場面ぜんぶで何秒か
  var NS = 3;                         // 場面の数
  var SCENES = ['装置全体', 'ズームアップ', 'さらにズーム'];
  var TITLES = [
    '装置全体',
    'ダブルスリットへズームアップ　－　d ＝ 0.20 mm が見えてくる',
    'さらにズームアップ　－　λ が見えるところまで寄ると、d は画面の外'
  ];

  /* 実際の装置のおおよその値（このモードだけで使う。λ・d・L はスライダーの値を使う） */
  /* スリット 1 本の幅。教科書の図と同じく「λ の数倍」＝ 通りぬけた光が大きく回折して
     広がる細さ、として扱う（そうでないと 2 つの光が重ならず、干渉縞ができない）。 */
  var SLIT_W_MM = 0.002;

  function sceneOf(prog) { return P.clamp(Math.floor(prog * NS), 0, NS - 1); }
  function localT(prog) { var s = sceneOf(prog); return P.clamp(prog * NS - s, 0, 1); }
  function ease(p) { return p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2; }

  /* ================= 共通の飾り ================= */
  function header(ctx, prog) {
    var s = sceneOf(prog);
    ctx.save();
    ctx.font = D.font(16, true);
    ctx.fillStyle = '#1a4e86';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText('🔍 実験の概要　' + (s + 1) + '. ' + TITLES[s], 24, 16);
    var x0 = 24, x1 = L.W - 24, y = 46;
    ctx.strokeStyle = '#dbe3ea'; ctx.lineWidth = 4; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(x0, y); ctx.lineTo(x1, y); ctx.stroke();
    ctx.strokeStyle = '#1663b5';
    ctx.beginPath(); ctx.moveTo(x0, y); ctx.lineTo(x0 + (x1 - x0) * prog, y); ctx.stroke();
    for (var i = 0; i < NS; i++) {
      var xx = x0 + (x1 - x0) * (i / NS);
      ctx.fillStyle = (i <= s) ? '#1663b5' : '#c9d2da';
      ctx.beginPath(); ctx.arc(xx, y, 5, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
  }

  function caption(ctx, lines, color) {
    var x = 24, w = L.W - 48, h = 12 + lines.length * 20;
    var y = L.H - h - 18;
    ctx.save();
    D.roundRect(ctx, x, y, w, h, 10);
    ctx.fillStyle = '#f7f9fc'; ctx.fill();
    ctx.strokeStyle = color || '#c4d2e2'; ctx.lineWidth = 1.4; ctx.stroke();
    ctx.fillStyle = '#28405c';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    var maxW = w - 32;
    for (var i = 0; i < lines.length; i++) {
      var size = 13.5;
      ctx.font = D.font(size, i === 0);
      while (ctx.measureText(lines[i]).width > maxW && size > 9.5) {
        size -= 0.5;
        ctx.font = D.font(size, i === 0);
      }
      ctx.fillText(lines[i], x + 16, y + 8 + i * 20);
    }
    ctx.restore();
  }

  /** 等角投影ふうの板（前の面＋右奥への奥ゆき） */
  function plate(ctx, x, y0, y1, fill, edge, depth) {
    var dx = depth || 64, dy = -(depth || 64) * 0.55;
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(x, y0); ctx.lineTo(x + dx, y0 + dy);
    ctx.lineTo(x + dx, y1 + dy); ctx.lineTo(x, y1);
    ctx.closePath();
    ctx.fillStyle = fill; ctx.fill();
    ctx.strokeStyle = edge; ctx.lineWidth = 1.4; ctx.stroke();
    ctx.restore();
  }

  /** 長さ [mm] を読みやすい文字に */
  function fmtMm(mm) {
    if (mm >= 1000) return (mm / 1000).toFixed(mm >= 10000 ? 0 : 2) + ' m';
    if (mm >= 1) return (mm >= 10 ? mm.toFixed(0) : mm.toFixed(mm >= 3 ? 1 : 2)) + ' mm';
    if (mm >= 0.001) return (mm * 1000).toFixed(mm >= 0.01 ? 0 : 1) + ' μm';
    return Math.round(mm * 1e6) + ' nm';
  }
  /** 倍率を「約 ○○ 倍」に（けたが大きいので万も使う） */
  function fmtMag(k) {
    if (k >= 1e4) return '約 ' + (k / 1e4).toFixed(k >= 1e5 ? 0 : 1) + ' 万倍';
    if (k >= 100) return '約 ' + Math.round(k / 10) * 10 + ' 倍';
    return '約 ' + k.toFixed(k >= 10 ? 0 : 1) + ' 倍';
  }

  /* ================= 場面 1　装置全体 ================= */
  /* 光源・S₀・ダブルスリットは近くにかため、そこからスクリーンまでを大きくあける
     （実際の装置もそうなっている）。板は等角投影で、光は板の奥ゆきのまん中を通る。 */
  var G1 = {
    cy: 316, src: 150, s0: 296, ds: 466, scr: 1074,
    dx: 64, dy: -35, sdx: 74, sdy: -41,
    plateHalf: 108, scrHalf: 176, slitHalf: 6,
    scrHalfM: 0.015                      // スクリーンの上下は実寸で ±15 mm ぶん
  };
  function scene1(ctx, st, t, paused) {
    var g = G1;
    var MX = g.dx / 2, MY = g.dy / 2;
    var SMX = g.sdx / 2, SMY = g.sdy / 2;
    var axisY = g.cy + MY;                 // 光が通る高さ（板の奥ゆきのまん中）
    var scrAxisY = g.cy + SMY;
    var dsX = g.ds + MX, scrX = g.scr + SMX;
    var sep = 13;                          // 図に描く S₁S₂ の間隔の半分 [px]（実際は d ＝ 0.2 mm）

    // 光学台（実験台）と、板をささえる支柱
    var benchY = 470;
    ctx.save();
    ctx.fillStyle = '#eef2f6';
    ctx.beginPath();
    ctx.moveTo(96, benchY); ctx.lineTo(96 + g.dx, benchY + g.dy);
    ctx.lineTo(1176 + g.dx, benchY + g.dy); ctx.lineTo(1176, benchY);
    ctx.closePath(); ctx.fill();
    ctx.strokeStyle = '#c9d2da'; ctx.lineWidth = 1.2; ctx.stroke();
    ctx.fillStyle = '#dfe6ec';
    ctx.fillRect(96, benchY, 1080, 9);
    ctx.fillStyle = '#a9b4bf';
    [g.s0, g.ds].forEach(function (px) {
      ctx.fillRect(px + MX - 3, g.cy + g.plateHalf, 6, benchY + MY - (g.cy + g.plateHalf));
    });
    ctx.fillRect(g.src + MX - 3, axisY + 16, 6, benchY + MY - axisY - 16);
    ctx.fillRect(g.scr + SMX - 4, g.cy + g.scrHalf, 8, benchY + SMY - (g.cy + g.scrHalf));
    ctx.restore();

    // 光の進みぐあい（はじめて開いたときは、最初から全部届いた状態で見せる）
    // 光源 → S₀ → ダブルスリット → スクリーン の 3 区間を、道のりで等速に進める
    var reach = (paused && t <= 0) ? 1 : P.clamp(t * 1.4, 0, 1);
    var srcX0 = g.src + MX + 26, s0X = g.s0 + MX;
    var dA = s0X - srcX0, dB = dsX - s0X, d2 = scrX - dsX;
    var trav = reach * (dA + dB + d2);
    var endX = srcX0 + Math.min(trav, dA);
    var spread = P.clamp((trav - dA) / dB, 0, 1);     // S₀ → ダブルスリットの広がりぐあい
    var fan = P.clamp((trav - dA - dB) / d2, 0, 1);   // ダブルスリット → スクリーン

    // スクリーン上の明線の位置（実寸の縮尺で置く。λ・d・L を変えると間隔も変わる）
    var ppm = g.scrHalf / g.scrHalfM;      // [px / m]
    var fr = [];
    for (var m = -8; m <= 8; m++) {
      var xm = P.xOfOrder(m, st.lambda, st.d, st.L, 0);
      if (xm === null || Math.abs(xm) > g.scrHalfM * 0.94) continue;
      fr.push({ m: m, y: scrAxisY - xm * ppm });
    }

    // 光の道すじ：光源 → S₀ → ダブルスリット
    function beam(x0, x1, y0, y1, alpha) {
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.strokeStyle = COL.ray; ctx.lineWidth = 3; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
      ctx.restore();
    }
    beam(srcX0, endX, axisY, axisY, 0.75);
    // S₀ を出た光は回折して広がり、S₁ と S₂ の両方に当たる
    //（まん中の板に当たる光もあるので、扇形の帯でそのようすを描く）
    if (spread > 0) {
      var bx = s0X + dB * spread;
      var by0 = axisY - (sep + 26) * spread, by1 = axisY + (sep + 26) * spread;
      ctx.save();
      ctx.fillStyle = COL.ray; ctx.globalAlpha = 0.22;
      ctx.beginPath();
      ctx.moveTo(s0X, axisY - 3); ctx.lineTo(bx, by0);
      ctx.lineTo(bx, by1); ctx.lineTo(s0X, axisY + 3);
      ctx.closePath(); ctx.fill();
      ctx.restore();
      // S₁・S₂ へ向かう 2 本は、はっきりした線で描く
      beam(s0X, bx, axisY, axisY - sep * spread, 0.85);
      beam(s0X, bx, axisY, axisY + sep * spread, 0.85);
    }
    // S₁ と S₂ のそれぞれから、明線の位置へ扇状に広がる（2 つの光が重なって縞ができる）
    if (fan > 0) {
      ctx.save();
      ctx.strokeStyle = COL.ray; ctx.lineWidth = 1.8; ctx.globalAlpha = 0.42;
      [axisY - sep, axisY + sep].forEach(function (sy) {
        for (var i = 0; i < fr.length; i++) {
          ctx.beginPath();
          ctx.moveTo(dsX, sy);
          ctx.lineTo(dsX + (scrX - dsX) * fan, sy + (fr[i].y - sy) * fan);
          ctx.stroke();
        }
      });
      ctx.restore();
    }

    // 光源 Q
    D.lightBulb(ctx, vec(g.src + MX, axisY), { scale: 1.4, white: st.light === 'white' });

    // S₀（シングルスリット）の板：すきまを本当にあけるため、上下 2 枚に分けて描く
    plate(ctx, g.s0, g.cy - g.plateHalf, axisY - g.slitHalf, '#e8ecef', '#98a3ad', g.dx);
    plate(ctx, g.s0, axisY + g.slitHalf, g.cy + g.plateHalf, '#e8ecef', '#98a3ad', g.dx);
    // ダブルスリットの板：すきま 2 つ ＝ 3 枚に分ける
    plate(ctx, g.ds, g.cy - g.plateHalf, axisY - sep - g.slitHalf, '#e8ecef', '#98a3ad', g.dx);
    plate(ctx, g.ds, axisY - sep + g.slitHalf, axisY + sep - g.slitHalf, '#cdd5dc', '#98a3ad', g.dx);
    plate(ctx, g.ds, axisY + sep + g.slitHalf, g.cy + g.plateHalf, '#e8ecef', '#98a3ad', g.dx);

    // 板のすきまの範囲だけ、光の線を上から描き直す（板の陰で途切れて見えないように）
    ctx.save();
    ctx.beginPath();
    ctx.rect(g.s0 - 4, axisY - g.slitHalf, g.dx + 8, g.slitHalf * 2);
    ctx.rect(g.ds - 4, axisY - sep - g.slitHalf, g.dx + 8, g.slitHalf * 2);
    ctx.rect(g.ds - 4, axisY + sep - g.slitHalf, g.dx + 8, g.slitHalf * 2);
    ctx.clip();
    // 「まだ届いていない光」を描かないよう、光の先はし endX・bx をそのまま使う
    beam(srcX0, endX, axisY, axisY, 0.75);
    if (spread > 0) {
      beam(s0X, bx, axisY, axisY - sep * spread, 0.85);
      beam(s0X, bx, axisY, axisY + sep * spread, 0.85);
    }
    ctx.restore();

    // スクリーン
    plate(ctx, g.scr, g.cy - g.scrHalf, g.cy + g.scrHalf, '#efe6d2', '#a89878', g.sdx);
    if (fan >= 0.999) {
      var spotCol = (st.light === 'white') ? '#ffffff' : P.rgbCss(D.pureColor(st.lambda));
      ctx.save();
      ctx.shadowColor = spotCol; ctx.shadowBlur = 9;
      ctx.strokeStyle = spotCol; ctx.lineWidth = 5; ctx.lineCap = 'round';
      // 明線は、スクリーンの面の「奥ゆきの向き」にそって引く（等角投影で横一直線に見える向き）
      for (var k = 0; k < fr.length; k++) {
        ctx.beginPath();
        ctx.moveTo(g.scr + 6, fr[k].y - SMY + g.sdy * 0.08);
        ctx.lineTo(g.scr + g.sdx - 6, fr[k].y - SMY + g.sdy * 0.92);
        ctx.stroke();
      }
      ctx.restore();
    }

    // 名札（板の名札は上に、光源とスクリーンの名札は台の下に置いて、重ならないようにする）
    ctx.save();
    ctx.font = D.font(12.5, true);
    ctx.fillStyle = '#41505d';
    ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
    // 2 枚の板の名札は、となりあうと文字がぶつかるので高さをずらす
    ctx.fillText('シングルスリット S₀', g.s0 + MX, g.cy - g.plateHalf - 30);
    D.dashLine(ctx, vec(g.s0 + MX, g.cy - g.plateHalf - 26), vec(g.s0 + MX, g.cy - g.plateHalf - 4), '#b6bcc4', [3, 3], 1);
    ctx.fillText('ダブルスリット S₁・S₂', g.ds + MX, g.cy - g.plateHalf - 8);
    ctx.fillText('スクリーン（干渉縞が写る）', g.scr + SMX, g.cy - g.scrHalf - 8);
    ctx.textBaseline = 'top';
    ctx.fillText('光源 Q', g.src + MX, benchY + 16);
    // S₁・S₂ の名札（すきまのすぐ左）
    ctx.font = D.font(11.5, true);
    ctx.fillStyle = '#1a3350';
    ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    ctx.fillText('S₁', g.ds - 7, axisY - sep - 3);
    ctx.fillText('S₂', g.ds - 7, axisY + sep + 3);
    ctx.restore();

    // L の寸法線
    var ly = benchY + 44;
    D.dimLine(ctx, vec(dsX, ly), vec(scrX, ly), 'L ＝ ' + st.L.toFixed(2) + ' m', '#6b7580', 16);

    // ダブルスリットのところに「ここを拡大します」の赤い丸（場面 2 へのつなぎ）。
    // 光がスクリーンまで届いてから ＝ 場面 1 の最後に出す
    if (fan < 0.999) { captionScene1(); return; }
    var pulse = 0.5 + 0.5 * Math.sin(t * 7);
    ctx.save();
    ctx.strokeStyle = '#d0342c'; ctx.lineWidth = 2 + pulse;
    ctx.setLineDash([6, 5]);
    ctx.beginPath(); ctx.ellipse(dsX, axisY, 40, 34, 0, 0, Math.PI * 2); ctx.stroke();
    ctx.setLineDash([]);
    ctx.font = D.font(12, true);
    ctx.fillStyle = '#c0392b';
    ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
    ctx.fillText('つぎはここを拡大します', dsX, axisY - 44);
    ctx.restore();

    captionScene1();

    function captionScene1() {
    caption(ctx, [
      'S₀ を出た光は回折して広がり、S₁ と S₂ の両方に当たります（まん中に当たった光は板で止まります）。',
      'そこを通った 2 つの光が重なりあって、スクリーンに干渉縞ができます。',
      '実際の装置は、光源・S₀・ダブルスリットが近くにかたまっていて、そこからスクリーンまでが 1 m ほどはなれています。',
      '図では S₁ と S₂ のすきまを見えるように広げています。実際の間隔は d ＝ ' + D.fmtD(st.d)
        + '（この図の　' + Math.round(sep * 2 / (st.d * 1e-6)) + ' 分の 1 ほど）です。'
    ], '#c4d2e2');
    }
  }

  /* ================= 場面 2・3　ズームアップ =================
   * 「視野の高さ [mm]」を 1 本の連続した式で決める。場面 2 と 3 はその前半・後半。
   *   場面 2 … 40 mm（板がまるごと入る）→ 1.0 mm（d ＝ 0.2 mm がはっきり見える）
   *   場面 3 … 1.0 mm → λ の 4 個ぶん（600 nm なら 2.4 μm）
   * カメラの中心は、場面 3 のはじめに S₁S₂ のまん中から S₁ へゆっくり移る。
   */
  var VIEW_PX = 330;                     // 視野の高さ [px]
  var VIEW_CY = 306;                     // 視野の中心の y
  function viewHeightMm(scene, t, st) {
    var lamMm = st.lambda * 1e-6;
    var h0 = 40, h1 = 1.0, h2 = lamMm * 10;
    var e = ease(t);
    return (scene === 1) ? h0 * Math.pow(h1 / h0, e) : h1 * Math.pow(h2 / h1, e);
  }
  /** カメラの中心（S₁S₂ のまん中を 0、S₁ 側を正とする [mm]） */
  function camCenterMm(scene, t, st) {
    if (scene === 1) return 0;
    var dMm = st.d * 1e-6;
    return (dMm / 2) * ease(P.clamp(t / 0.35, 0, 1));
  }

  /** 画面の左下に「いま装置のどこを見ているか」の小さな全体図 */
  function inset(ctx, viewMm, st) {
    var x = 30, y = 402, w = 176, h = 104;
    ctx.save();
    D.roundRect(ctx, x, y, w, h, 8);
    ctx.fillStyle = '#ffffff'; ctx.fill();
    ctx.strokeStyle = '#c4d2e2'; ctx.lineWidth = 1.2; ctx.stroke();
    ctx.font = D.font(10.5, true);
    ctx.fillStyle = '#5b6672';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText('装置全体のどこを見ているか', x + 8, y + 6);
    // ごく簡単な装置の絵
    var cy = y + 62, sx = x + 20, dsx = x + 74, scx = x + 156;
    D.line(ctx, vec(sx, cy), vec(scx, cy), 'rgba(232,134,42,0.5)', 2);
    ctx.fillStyle = '#e0a800';
    ctx.beginPath(); ctx.arc(sx, cy, 5, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#98a3ad';
    ctx.fillRect(x + 46, cy - 22, 4, 44);
    ctx.fillRect(dsx, cy - 22, 4, 44);
    ctx.fillStyle = '#efe6d2'; ctx.strokeStyle = '#a89878'; ctx.lineWidth = 1;
    ctx.fillRect(scx, cy - 30, 6, 60); ctx.strokeRect(scx + 0.5, cy - 29.5, 6, 60);
    // いま見ている範囲を赤い四角で（見えないほど小さいときは最小の大きさで描く）
    var boxH = Math.max(3, 44 * viewMm / 40);
    ctx.strokeStyle = '#d0342c'; ctx.lineWidth = 1.6;
    ctx.strokeRect(dsx - 5, cy - boxH / 2, 14, boxH);
    if (boxH <= 5) {
      ctx.beginPath();
      ctx.moveTo(dsx + 2, cy + 24); ctx.lineTo(dsx + 2, cy + boxH / 2 + 2);
      ctx.strokeStyle = '#d0342c'; ctx.lineWidth = 1.2; ctx.stroke();
      ctx.font = D.font(9.5, true);
      ctx.fillStyle = '#c0392b';
      ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      ctx.fillText('この点の中', dsx + 2, cy + 25);
    }
    ctx.restore();
  }

  /** 右下のものさし（いまの縮尺で「○○ ＝ 何 px か」を示す） */
  function scaleBar(ctx, pxPerMm, viewMm) {
    // 画面の 1/4 くらいの長さになる「きりのよい長さ」を選ぶ
    var want = (L.W * 0.16) / pxPerMm;
    var cands = [1e-4, 2e-4, 5e-4, 1e-3, 2e-3, 5e-3, 0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50];
    var unitMm = cands[0];
    for (var i = 0; i < cands.length; i++) if (cands[i] <= want) unitMm = cands[i];
    var w = unitMm * pxPerMm;
    var x1 = L.W - 52, x0 = x1 - w, y = 470;
    ctx.save();
    D.dimLine(ctx, vec(x0, y), vec(x1, y), null, '#41505d');
    ctx.font = D.font(12, true);
    ctx.fillStyle = '#41505d';
    ctx.textAlign = 'right'; ctx.textBaseline = 'bottom';
    ctx.fillText('この長さ ＝ ' + fmtMm(unitMm), x1, y - 8);
    ctx.font = D.font(11);
    ctx.fillStyle = '#6b7580';
    ctx.textBaseline = 'top';
    ctx.fillText('画面のたて ＝ ' + fmtMm(viewMm), x1, y + 8);
    ctx.restore();
  }

  function zoomScene(ctx, st, scene, t) {
    var viewMm = viewHeightMm(scene, t, st);
    var pxPerMm = VIEW_PX / viewMm;
    var camMm = camCenterMm(scene, t, st);
    var dMm = st.d * 1e-6, lamMm = st.lambda * 1e-6;
    var plateX = 596, plateW = 26;            // 板の位置と厚み（画面の中ほど）
    /** 実寸の位置 [mm]（S₁S₂ のまん中を 0・S₁ 側を正）→ 画面の y */
    function Y(mm) { return VIEW_CY - (mm - camMm) * pxPerMm; }
    var y1 = Y(dMm / 2), y2 = Y(-dMm / 2);    // S₁（上）・S₂（下）
    var halfSlit = (SLIT_W_MM / 2) * pxPerMm;
    var top = 74, bot = 500;

    // ---- 板（すきま 2 つ ＝ 3 枚）。画面からはみ出すぶんは、はみ出したまま描く ----
    ctx.save();
    ctx.beginPath(); ctx.rect(0, top, L.W, bot - top); ctx.clip();
    ctx.fillStyle = '#e8ecef';
    ctx.strokeStyle = '#98a3ad'; ctx.lineWidth = 1.4;
    function bar(ya, yb) {
      if (yb <= ya) return;
      ctx.fillRect(plateX, ya, plateW, yb - ya);
      ctx.strokeRect(plateX + 0.5, ya, plateW - 1, yb - ya);
      // 板の断面らしく、ななめの細い線を入れる
      ctx.save();
      ctx.beginPath(); ctx.rect(plateX, ya, plateW, yb - ya); ctx.clip();
      ctx.strokeStyle = 'rgba(120,135,150,0.45)'; ctx.lineWidth = 1;
      for (var hy = ya - plateW; hy < yb + plateW; hy += 8) {
        ctx.beginPath(); ctx.moveTo(plateX, hy + plateW); ctx.lineTo(plateX + plateW, hy); ctx.stroke();
      }
      ctx.restore();
    }
    bar(top - 40, y1 - halfSlit);
    bar(y1 + halfSlit, y2 - halfSlit);
    bar(y2 + halfSlit, bot + 40);

    // ---- 入ってくる光（左から）と、すきまから広がる光 ----
    var showWave = (viewMm < lamMm * 40);     // λ が見えてくる大きさになったら波で描く
    var lamPx = lamMm * pxPerMm;
    var tw = (st.t || 0) * P.V_NM_PER_S * 1e-6 * pxPerMm;   // 波の進み [px]
    ctx.strokeStyle = COL.ray;
    if (showWave) {
      // 平面波（左から）
      ctx.save();
      ctx.globalAlpha = 0.55; ctx.lineWidth = 1.6;
      for (var xf = plateX - ((tw % lamPx) + lamPx); xf > -lamPx; xf -= lamPx) {
        ctx.beginPath(); ctx.moveTo(xf, top); ctx.lineTo(xf, bot); ctx.stroke();
      }
      ctx.restore();
      // すきまから広がる素元波（半円）
      ctx.save();
      ctx.beginPath(); ctx.rect(plateX + plateW, top, L.W, bot - top); ctx.clip();
      ctx.globalAlpha = 0.5; ctx.lineWidth = 1.6;
      [y1, y2].forEach(function (ys) {
        if (ys < top - 400 || ys > bot + 400) return;
        for (var r = (tw % lamPx); r < 900; r += lamPx) {
          if (r < 2) continue;
          ctx.beginPath();
          ctx.arc(plateX + plateW, ys, r, -Math.PI / 2.05, Math.PI / 2.05);
          ctx.stroke();
        }
      });
      ctx.restore();
    } else {
      // 波が見えない大きさのうちは、光の道すじを「帯」で描く
      // （左から来る光と、すきまから広がっていく光）
      ctx.save();
      ctx.fillStyle = COL.ray; ctx.globalAlpha = 0.16;
      ctx.fillRect(0, top, plateX, bot - top);            // 板ぜんたいに光が当たっている
      var len = L.W - plateX - plateW, spread = Math.tan(0.36) * len;
      [y1, y2].forEach(function (ys) {
        if (ys < top - 600 || ys > bot + 600) return;
        ctx.beginPath();
        ctx.moveTo(plateX + plateW, ys - Math.max(3, halfSlit));
        ctx.lineTo(L.W, ys - spread);
        ctx.lineTo(L.W, ys + spread);
        ctx.lineTo(plateX + plateW, ys + Math.max(3, halfSlit));
        ctx.closePath(); ctx.fill();
      });
      ctx.restore();
    }
    ctx.restore();

    // ---- S₁・S₂ の名札と d の寸法線 ----
    ctx.save();
    ctx.font = D.font(13, true);
    ctx.fillStyle = '#1a3350';
    ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    if (Math.abs(y2 - y1) < 26) {
      // まだ寄りが足りず、2 つのすきまが 1 本に見えている
      ctx.fillText('S₁・S₂', plateX - 12, (y1 + y2) / 2);
      ctx.font = D.font(11);
      ctx.fillStyle = '#8a939c';
      ctx.fillText('（まだ 1 本に見える）', plateX - 12, (y1 + y2) / 2 + 17);
    } else {
      if (y1 > top && y1 < bot) ctx.fillText('S₁', plateX - 12, y1);
      if (y2 > top && y2 < bot) ctx.fillText('S₂', plateX - 12, y2);
    }
    ctx.restore();
    if (y1 > top + 10 && y2 < bot - 10 && (y2 - y1) > 26) {
      D.dimLine(ctx, vec(plateX - 46, y1), vec(plateX - 46, y2), null, '#1663b5');
      ctx.save();
      ctx.font = D.font(13, true);
      ctx.fillStyle = '#1663b5';
      ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
      ctx.fillText('d ＝ ' + D.fmtD(st.d), plateX - 54, (y1 + y2) / 2);
      ctx.restore();
    }
    // S₂ が画面の外に出たら、「どれくらい下か」を矢印で示す
    if (y2 > bot && scene === 2) {
      var nScreen = (dMm / viewMm);
      ctx.save();
      D.arrow(ctx, vec(plateX - 60, bot - 60), vec(0, 1), 46, 'rgba(22,99,181,0.6)', 3, 10);
      ctx.font = D.font(12, true);
      var msg = 'S₂ は ' + D.fmtD(st.d) + ' 下（この画面 '
        + (nScreen >= 10 ? Math.round(nScreen) : nScreen.toFixed(1)) + ' 個ぶん先）';
      var mw = ctx.measureText(msg).width;
      ctx.fillStyle = 'rgba(255,255,255,0.92)';
      ctx.fillRect(plateX - 74 - mw, bot - 47, mw + 8, 22);
      ctx.fillStyle = '#1663b5';
      ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
      ctx.fillText(msg, plateX - 70, bot - 36);
      ctx.restore();
    }
    // λ の目もり（波が見えているとき）
    if (viewMm < lamMm * 40 && lamPx > 12) {
      var ly2 = 118;
      D.dimLine(ctx, vec(plateX + plateW + 24, ly2), vec(plateX + plateW + 24 + lamPx, ly2), null, '#8a5300');
      ctx.save();
      ctx.font = D.font(12.5, true);
      var lt = 'λ ＝ ' + Math.round(st.lambda) + ' nm（波の山と山のへだたり）';
      var lw = ctx.measureText(lt).width;
      ctx.fillStyle = 'rgba(255,255,255,0.92)';
      ctx.fillRect(plateX + plateW + 20, ly2 - 27, lw + 8, 20);
      ctx.fillStyle = '#8a5300';
      ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
      ctx.fillText(lt, plateX + plateW + 24, ly2 - 9);
      ctx.restore();
    }

    // ---- 倍率・ものさし・小さな全体図 ----
    var mag = pxPerMm / (G1.plateHalf * 2 / 40);   // 場面 1 の板（40 mm ぶん）を 1 倍とする
    ctx.save();
    ctx.font = D.font(22, true);
    ctx.fillStyle = '#c0392b';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText('⤢ ' + fmtMag(mag), 30, 74);
    ctx.font = D.font(11.5);
    ctx.fillStyle = '#8a5a52';
    ctx.fillText('（場面 1 の装置全体の図とくらべた倍率）', 30, 104);
    ctx.restore();
    scaleBar(ctx, pxPerMm, viewMm);
    inset(ctx, viewMm, st);

    if (scene === 1) {
      var seen = (Math.abs(y2 - y1) >= 26);
      caption(ctx, [
        'ダブルスリットに、どんどん寄っていきます。ものさし（右下）と倍率（左上）が変わっていくことに注目してください。',
        seen
          ? ('ここまで寄ると、2 つのすきま S₁・S₂ が d ＝ ' + D.fmtD(st.d)
             + ' はなれているのが分かります。①②③の図の「S₁・S₂ のまわりの拡大図」は、このあたりを見ている図です。')
          : ('まだ 2 つのすきまは 1 本に見えています。d ＝ ' + D.fmtD(st.d)
             + ' は、いまの画面のたて（' + fmtMm(viewMm) + '）の ' + (dMm / viewMm * 100).toFixed(1) + ' % しかありません。')
      ], '#e0a24a');
    } else {
      caption(ctx, showWave
        ? ['さらに寄って、光の波長 λ ＝ ' + Math.round(st.lambda) + ' nm が見えるところまで来ました。波の山と山のへだたりが λ です。',
           'ところが λ が見えるこの縮尺では、d ＝ ' + D.fmtD(st.d) + ' は画面のはるか外（λ の約 '
             + Math.round(st.d / st.lambda) + ' 倍）。'
             + 'λ と d を 1 枚の図に正しい縮尺で描くことはできないので、①②の拡大図では λ を誇張して描いています。']
        : ['さらに寄っていきます。d ＝ ' + D.fmtD(st.d) + ' の両矢印が、画面いっぱいに広がっていきます。',
           'このあと λ ＝ ' + Math.round(st.lambda) + ' nm が見えるところまで寄りますが、そのときには d は画面の外に出てしまいます。'],
        '#d0342c');
    }
  }

  /* ================= 本体 ================= */
  function render(ctx, st, sol, sc) {
    var so = st.setup || { prog: 0, paused: true };
    var prog = P.clamp(so.prog, 0, 1);
    var s = sceneOf(prog), t = localT(prog);
    ctx.save();
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, L.W, L.H);
    header(ctx, prog);
    if (s === 0) scene1(ctx, st, t, so.paused);
    else zoomScene(ctx, st, s, t);
    ctx.restore();
  }

  return {
    render: render, DUR: DUR, SCENES: SCENES, TITLES: TITLES,
    sceneOf: sceneOf, viewHeightMm: viewHeightMm
  };
})();
