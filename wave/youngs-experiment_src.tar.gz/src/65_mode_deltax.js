/* ===== 65_mode_deltax.js ===== */
/* ③ 明線間隔 Δx を導く（ステップ④の続き）
 *   モード①とほぼ同じレイアウト。
 *   m 次と (m＋1) 次、2 つの明線の位置 x を同時にスクリーンへ示し、
 *   ステップ④の式 x_m ≒ mλL/d を引き算するだけで Δx ＝ λL/d が出ることを見せる。
 *   d・L・λ のスライダーはこのモードでも生きていて、Δx がその場で変わる。
 *   Δx は 2 本の破線のあいだの緑の両矢印で明示する。
 */
window.YG = window.YG || {};
YG.modeDeltax = (function () {
  'use strict';
  var P = YG.phys, D = YG.draw;
  var L = D.L, COL = D.COL;
  var vec = D.vec, sub = D.sub;

  var SUB_M = 'ₘ', SUB_M1 = 'ₘ₊₁';

  function findOrder(sol, m) {
    for (var i = 0; i < sol.orders.length; i++) if (sol.orders[i].m === m) return sol.orders[i];
    return null;
  }
  /** 見せる 2 本（m と m＋1）。m＋1 が画面の外なら m−1 と m にする */
  function pickPair(sol) {
    // 選んでいる明線（sel）を m にする。端の明線（m＋1 が画面の外）なら m−1 と m を比べる
    var m = (sol.sel && !sol.sel.dark) ? sol.sel.m : sol.m;
    var a = findOrder(sol, m), b = findOrder(sol, m + 1);
    if (a && b && Math.abs(b.x) <= sol.halfM) return { m: m, om: a, om1: b };
    a = findOrder(sol, m - 1); b = findOrder(sol, m);
    if (a && b) return { m: m - 1, om: a, om1: b };
    if (sol.orders.length >= 2) return { m: sol.orders[0].m, om: sol.orders[0], om1: sol.orders[1] };
    return null;
  }

  function triFill(ctx, a, b, c, fill) {
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.lineTo(c.x, c.y); ctx.closePath();
    ctx.fillStyle = fill; ctx.fill();
    ctx.restore();
  }

  /* ================= 左パネル：導出の流れ ================= */
  function drawFlow(ctx, st, sol, sc) {
    var x0 = 18, w = L.DIV - 40;
    ctx.save();
    ctx.font = D.font(12.5, true);
    ctx.fillStyle = '#2b5a78';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText('明線の間隔 Δx を求める', 14, 22);
    var boxes = [
      { t: 'm 番目の明線', tex: 'x_m\\fallingdotseq\\dfrac{m\\lambda L}{d}', fb: 'x_m ≒ mλL/d' },
      { t: 'その 1 つ外側の明線', tex: 'x_{m+1}\\fallingdotseq\\dfrac{(m+1)\\lambda L}{d}', fb: 'x_(m+1) ≒ (m+1)λL/d' },
      { t: '引き算すると', tex: '\\Delta x=x_{m+1}-x_m\\fallingdotseq\\dfrac{\\lambda L}{d}', fb: 'Δx ≒ λL/d' }
    ];
    var y = 56;
    for (var i = 0; i < boxes.length; i++) {
      var h = (i === 2) ? 76 : 68;
      D.roundRect(ctx, x0, y, w, h, 9);
      ctx.fillStyle = (i === 2) ? '#eefaf2' : '#eaf1fa'; ctx.fill();
      ctx.strokeStyle = (i === 2) ? '#0f9d58' : '#9dc0e8';
      ctx.lineWidth = (i === 2) ? 2 : 1.4; ctx.stroke();
      ctx.font = D.font(11, true);
      ctx.fillStyle = (i === 2) ? '#0b5c34' : '#1a4e86';
      ctx.textAlign = 'left'; ctx.textBaseline = 'top';
      ctx.fillText(boxes[i].t, x0 + 12, y + 8);
      var col = (i === 2) ? '#0b5c34' : '#1a3350';
      if (!D.drawTex(ctx, boxes[i].tex, x0 + 12, y + 26, { size: 17, color: col })) {
        ctx.font = D.font(12.5); ctx.fillStyle = '#28405c';
        ctx.fillText(boxes[i].fb, x0 + 12, y + 30);
      }
      if (i < boxes.length - 1) {
        ctx.font = D.font(15, true); ctx.fillStyle = '#8a94a0';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('↓', x0 + w / 2, y + h + 11);
      }
      y += h + 23;
    }
    ctx.font = D.font(12, true);
    ctx.fillStyle = '#0b5c34';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText('いまの Δx ≒ λL/d ＝ ' + (sol.dxApprox * 1000).toFixed(2) + ' mm', x0 + 4, y + 4);
    ctx.font = D.font(11);
    ctx.fillStyle = '#5b6672';
    ctx.fillText('λ ＝ ' + Math.round(st.lambda) + ' nm　d ＝ ' + D.fmtD(st.d) + '　L ＝ ' + st.L.toFixed(2) + ' m', x0 + 4, y + 24);
    ctx.fillText('Δx は λ と L に比例し、d に反比例します。', x0 + 4, y + 42);
    ctx.fillText('スライダーを動かして確かめてみましょう。', x0 + 4, y + 60);
    ctx.restore();
  }

  /* ================= スクリーンの右：xₘ・xₘ₊₁ の寸法と Δx ================= */
  function xmDims(ctx, Pm, Pm1, dxMm) {
    var xr = L.SX + L.SCR_W, xEnd = L.W - 12;
    var ym = Pm.y, ym1 = Pm1.y, yO = L.CY;
    ctx.save();
    ctx.lineWidth = 1.2; ctx.setLineDash([6, 4]);
    ctx.strokeStyle = '#3a4550';
    ctx.beginPath(); ctx.moveTo(xr + 2, ym); ctx.lineTo(xEnd, ym); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(xr + 2, ym1); ctx.lineTo(xEnd, ym1); ctx.stroke();
    ctx.strokeStyle = '#9aa0a6';
    ctx.beginPath(); ctx.moveTo(xr + 2, yO); ctx.lineTo(xEnd, yO); ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();

    function vArrow(x, yTop, color) {
      ctx.save();
      ctx.strokeStyle = color; ctx.fillStyle = color; ctx.lineWidth = 2;
      var dir = (yTop < yO) ? 1 : -1;               // 上向きなら矢じりは上
      ctx.beginPath(); ctx.moveTo(x, yO); ctx.lineTo(x, yTop + dir * 10); ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(x, yTop + dir * 1);
      ctx.lineTo(x - 4.5, yTop + dir * 11);
      ctx.lineTo(x + 4.5, yTop + dir * 11);
      ctx.closePath(); ctx.fill();
      ctx.restore();
    }
    var xA = xr + 34, xB = xr + 56;
    vArrow(xA, ym, '#1663b5');
    vArrow(xB, ym1, '#a15200');

    // Δx：2 本の破線のあいだに、緑の両矢印
    ctx.save();
    ctx.strokeStyle = COL.geo; ctx.fillStyle = COL.geo; ctx.lineWidth = 2;
    var top = Math.min(ym, ym1), bot = Math.max(ym, ym1);
    ctx.beginPath(); ctx.moveTo(xA, top + 9); ctx.lineTo(xA, bot - 9); ctx.stroke();
    function dHead(y, dir) {
      ctx.beginPath();
      ctx.moveTo(xA, y);
      ctx.lineTo(xA - 4.5, y + dir * 10);
      ctx.lineTo(xA + 4.5, y + dir * 10);
      ctx.closePath(); ctx.fill();
    }
    dHead(top + 1, 1); dHead(bot - 1, -1);
    ctx.font = D.font(13, true);
    ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    var lab = 'Δx';
    var dxw = ctx.measureText(lab).width;
    var dlx = xA - 8, dly = (ym + ym1) / 2;
    ctx.fillStyle = 'rgba(255,255,255,0.9)';
    ctx.fillRect(dlx - dxw - 4, dly - 9, dxw + 8, 18);
    ctx.fillStyle = '#0d7a3f';
    ctx.fillText(lab, dlx, dly + 1);
    ctx.restore();

    // 式（KaTeX）。明線の間隔は 30 px ほどしかないので、破線のあいだには置かず、
    //   xₘ₊₁ の式 … 外側の破線のさらに外
    //   Δx の値   … 2 本の破線のあいだ（1 行ぶん）
    //   xₘ の式   … O の反対側（矢印の根もと）
    var up = (ym1 < ym);                        // P が上側（m ≧ 0）か
    var lx = xB + 6;
    var outer = up ? Math.min(ym, ym1) : Math.max(ym, ym1);
    D.drawTex(ctx, 'x_{m+1}\\fallingdotseq\\dfrac{(m+1)\\lambda L}{d}', lx, outer + (up ? -48 : 8), { size: 12, color: '#a15200' });
    D.drawTex(ctx, 'x_m\\fallingdotseq\\dfrac{m\\lambda L}{d}', lx, yO + (up ? 8 : -44), { size: 12, color: '#1663b5' });
    ctx.save();
    ctx.font = D.font(11.5, true);
    ctx.fillStyle = '#0d5c30';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText('Δx ＝ ' + dxMm.toFixed(2) + ' mm', lx, (ym + ym1) / 2);
    ctx.restore();
  }

  /* ================= 帯の位置：まとめの箱 ================= */
  function summaryBox(ctx) {
    var x = 20, y = L.BAND_Y + 8, w = L.W - 40;
    var tex = 'x_{m+1}-x_m \\fallingdotseq \\dfrac{(m+1)\\lambda L}{d}-\\dfrac{m\\lambda L}{d} = \\dfrac{\\lambda L}{d}';
    var eq = D.texImage(tex, { size: 17, color: '#0d5c30', display: true });
    var eqH = eq.img ? eq.h : 24;
    var h = 30 + eqH + 30;
    ctx.save();
    D.roundRect(ctx, x, y, w, h, 10);
    ctx.fillStyle = '#eef9f1'; ctx.fill();
    ctx.strokeStyle = '#0d7a3f'; ctx.lineWidth = 1.6; ctx.stroke();
    ctx.fillStyle = '#0d5c30';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.font = D.font(13, true);
    ctx.fillText('ステップ④の式で m → m ＋ 1 として引き算すると：', x + 18, y + 12);
    if (!D.drawTex(ctx, tex, x + 16, y + 28, { size: 17, color: '#0d5c30', display: true })) {
      ctx.font = D.font(16, true);
      ctx.fillText('x' + SUB_M1 + ' － x' + SUB_M + ' ≒ (m＋1)λL/d － mλL/d ＝ λL/d', x + 18, y + 34);
    }
    ctx.font = D.font(12);
    ctx.fillStyle = '#3a4550';
    ctx.fillText('→ m が消えるので、Δx はどの隣りあう明線どうしでも同じ値になります（θ が小さいときに限る）。', x + 18, y + 28 + eqH + 6);
    ctx.restore();
  }

  function titleBox(ctx) {
    var t = '③ 明線間隔 Δx を導く（ステップ④の続き）';
    ctx.save();
    ctx.font = D.font(13.5, true);
    var w = ctx.measureText(t).width + 26;
    D.roundRect(ctx, L.DIV + 20, 14, w, 28, 8);
    ctx.fillStyle = '#eef9f1'; ctx.fill();
    ctx.strokeStyle = '#0d7a3f'; ctx.lineWidth = 1.6; ctx.stroke();
    ctx.fillStyle = '#0d5c30';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(t, L.DIV + 33, 29);
    ctx.restore();
  }

  /* ================= 本体 ================= */
  function render(ctx, st, sol, sc) {
    D.panels(ctx);
    drawFlow(ctx, st, sol, sc);

    var pair = pickPair(sol);
    var ph = YG.modePath.incoming(ctx, st, sol, sc, {});
    YG.modePath.stage(ctx, st, sol, sc, { labels: false });
    if (!pair) { titleBox(ctx); return; }

    var M = vec(L.GX, L.CY), O = vec(L.SX, L.CY);
    var ym = L.CY - pair.om.x * sc.ppm, ym1 = L.CY - pair.om1.x * sc.ppm;
    var Pm = vec(L.SX, ym), Pm1 = vec(L.SX, ym1);

    // 角の塗り
    triFill(ctx, M, O, Pm1, 'rgba(224,123,24,0.10)');
    triFill(ctx, M, O, Pm, 'rgba(22,99,181,0.16)');
    D.rightAngle(ctx, O, vec(-1, 0), vec(0, ym < L.CY ? -1 : 1), 12, '#5b6672');

    // M → Pₘ・M → Pₘ₊₁ の光（波つき）。位相は S₁・S₂ の平均から続ける
    var phM = (ph.phS1 + ph.phS2) / 2;
    ctx.save(); ctx.globalAlpha = 0.3;
    D.lineSkipGap(ctx, M, Pm1, '#e07b18', 1.2); D.lineSkipGap(ctx, M, Pm, '#1663b5', 1.2);
    ctx.restore();
    D.beamWave(ctx, st, M, Pm1, { phase0: phM, color: '#e07b18', width: 1.6 });
    D.beamWave(ctx, st, M, Pm, { phase0: phM, color: '#1663b5', width: 1.7 });

    // 明線の位置の短い線（すべての明線）＋ 注目の 2 本を強く
    ctx.save();
    for (var oi = 0; oi < sol.orders.length; oi++) {
      var oy = L.CY - sol.orders[oi].x * sc.ppm;
      if (Math.abs(oy - L.CY) > L.SH) continue;
      var main = (sol.orders[oi].m === pair.m || sol.orders[oi].m === pair.m + 1);
      if (!main && !st.showAll) continue;
      D.line(ctx, vec(L.SX - 4, oy), vec(L.SX + L.SCR_W + 4, oy), main ? '#d0342c' : 'rgba(208,52,44,0.45)', main ? 2.4 : 1.2);
      D.addHit(L.SX - 4, oy - 8, L.SCR_W + 8, 16, 'order:' + sol.orders[oi].m);
    }
    ctx.restore();

    D.pointLabel(ctx, Pm, 'P' + SUB_M, -26, 0, '#1663b5');
    D.pointLabel(ctx, Pm1, 'P' + SUB_M1, -28, 0, '#a15200');
    D.pointLabel(ctx, O, 'O', -14, 15, '#3a4550');
    D.pointLabel(ctx, M, 'M', -22, 2, '#28405c');

    ctx.save();
    ctx.font = D.font(11.5, true);
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#1a4e86';
    ctx.fillText('m ＝ ' + pair.m + ' の明線へ', L.GX + 60, (M.y + Pm.y) / 2 - 12);
    ctx.fillStyle = '#a15200';
    ctx.fillText('m ＝ ' + (pair.m + 1) + ' の明線へ', L.GX + 60, (M.y + Pm1.y) / 2 - 26);
    ctx.restore();

    xmDims(ctx, Pm, Pm1, Math.abs(pair.om1.x - pair.om.x) * 1000);
    titleBox(ctx);
    if (st.showLabels) {
      D.calloutAt(ctx, null, L.DIV + 20, 54, [
        '・明線の位置は xₘ ≒ mλL/d。m に比例して並ぶ。',
        '・だから隣りあう明線の間隔 Δx は、どこで測っても同じ。',
        '・見る方向のボタンで m を変えても、Δx は変わらない。'
      ], { bg: '#eefaf2', border: '#0f9d58', fg: '#14442b' });
    }
    summaryBox(ctx);
  }

  return { render: render, pickPair: pickPair };
})();
