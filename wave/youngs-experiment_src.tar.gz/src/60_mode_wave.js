/* ===== 60_mode_wave.js ===== */
/* ② 実際の波の動きを見る
 *
 * レイアウトは ①（光路差の位置と式の原理）とまったく同じ。
 * 変わるのは次の 3 つだけ。
 *   1. 拡大図の sin カーブ・全体図の光線の波・点 P の拡大図・下の帯の波が動く（st.t が進む）
 *   2. スクリーンの右わきに「光の強度分布」のグラフを添える
 *   3. 合成波（S₁ の波 ＋ S₂ の波）のカードを足す
 * 図そのものは 50_mode_path.js の render() を opt.wave 付きで呼んで描く。
 * 「〰 波面（同心円）」ボタンを押したときだけ、素元波の同心円を薄く重ねる（模式図）。
 */
window.YG = window.YG || {};
YG.modeWave = (function () {
  'use strict';
  var P = YG.phys, D = YG.draw;
  var L = D.L, COL = D.COL;
  var vec = D.vec;

  /** 合成波のカードの置き場所は 50_mode_path.js の pointZoomCenter(sc, true) が決める
   *  （点 P の拡大円のすぐ上。円と 1 組で P といっしょに上下する） */
  function sumBox(sc, pz) {
    pz = pz || YG.modePath.pointZoomCenter(sc, true);
    var c = pz.card;
    return { x0: c.x0, y0: c.y0, x1: c.x1, y1: c.y1, pz: pz };
  }
  /** 光の強度分布のグラフ（スクリーンの右わき） */
  var GB = { x0: 1200, w: 84 };

  /* ================= 光の強度分布のグラフ =================
   * 横軸＝明るさ（右ほど明るい）、縦軸＝スクリーン上の位置（図と同じものさし）。
   * 2 スリットの縞はなだらかな cos² なので、そのまま標本化してよい
   * （回折格子の鋭い主極大のように「針を立てる」必要はない）。 */
  function intensityGraph(ctx, st, sol, sc) {
    var x0 = GB.x0, w = GB.w, yTop = L.CY - L.SH, h = L.SH * 2;
    ctx.save();
    ctx.fillStyle = 'rgba(255,255,255,0.75)';
    ctx.fillRect(x0 - 4, yTop - 4, L.W - (x0 - 4) - 2, h + 8);
    ctx.strokeStyle = '#b9c0c8'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(x0 + 0.5, yTop); ctx.lineTo(x0 + 0.5, yTop + h); ctx.stroke();
    var pts = [];
    for (var i = 0; i <= h; i++) {
      var xm = -(i - L.SH) / sc.ppm;
      var th = Math.asin(P.clamp(P.sinThetaFromX(xm, st.L), -1, 1));
      var v;
      if (st.light === 'white') {
        var s = 0, n = 0;
        for (var lam = 380; lam <= 780; lam += 8) { s += P.intensity2(th, st.d, lam / sol.nMed, sol.extra); n++; }
        v = s / n;
      } else {
        v = P.intensity2(th, st.d, st.lambda, sol.extra);
      }
      pts.push(v);
    }
    ctx.beginPath();
    ctx.moveTo(x0, yTop);
    for (i = 0; i < pts.length; i++) ctx.lineTo(x0 + pts[i] * w, yTop + i);
    ctx.lineTo(x0, yTop + h);
    ctx.closePath();
    ctx.fillStyle = 'rgba(208,52,44,0.10)'; ctx.fill();
    ctx.beginPath();
    for (i = 0; i < pts.length; i++) {
      var xx = x0 + pts[i] * w;
      if (i === 0) ctx.moveTo(xx, yTop); else ctx.lineTo(xx, yTop + i);
    }
    ctx.strokeStyle = '#d0342c'; ctx.lineWidth = 1.6; ctx.lineJoin = 'round';
    ctx.stroke();
    // いま見ている位置
    var py = P.clamp(sc.P.y, yTop, yTop + h);
    D.dashLine(ctx, vec(x0, py), vec(x0 + w, py), '#8a3b00', [4, 3], 1.1);
    ctx.beginPath(); ctx.arc(x0 + sol.I * w, py, 3.5, 0, Math.PI * 2);
    ctx.fillStyle = '#8a3b00'; ctx.fill();
    // 見出し
    ctx.font = D.font(11, true);
    ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
    var t = '光の強度分布';
    var tw = ctx.measureText(t).width;
    ctx.fillStyle = 'rgba(255,255,255,0.9)';
    ctx.fillRect(x0 + w / 2 - tw / 2 - 3, yTop - 25, tw + 6, 16);
    ctx.fillStyle = '#a12a1c';
    ctx.fillText(t, x0 + w / 2, yTop - 10);
    ctx.font = D.font(10);
    ctx.fillStyle = '#8a939c';
    ctx.textAlign = 'right'; ctx.textBaseline = 'top';
    ctx.fillText('I ＝ I₀cos²(πd sinθ/λ)', x0 + w, yTop + h + 6);
    ctx.fillText('（スリット 2 本なので、なだらかな縞）', x0 + w, yTop + h + 20);
    ctx.restore();
  }

  /* ================= 合成波のカード ================= */
  function sumCard(ctx, st, sol, sc, pz) {
    var nmPerPx = sc.nmPerPx;                 // 拡大図と同じものさし
    var delta = sol.delta;                    // 2 本の波のずれ [nm]
    var t = st.t || 0;
    var B = sumBox(sc, pz);
    var x0 = B.x0 + 8, x1 = B.x1 - 8;
    var cy = B.y0 + 38;
    var unit = 6.5;                           // 振幅 1 ぶんの px

    ctx.save();
    // 拡大円との「つながり」を点線で示す（円といっしょに動く 1 組であることが分かるように）
    D.dashLine(ctx, vec(B.pz.c.x, B.y1), vec(B.pz.c.x, B.pz.c.y - B.pz.r), '#b39ccf', [3, 3], 1.2);
    D.roundRect(ctx, B.x0, B.y0, B.x1 - B.x0, B.y1 - B.y0, 8);
    ctx.fillStyle = '#faf7fd'; ctx.fill();
    ctx.strokeStyle = '#b39ccf'; ctx.lineWidth = 1.4; ctx.stroke();
    ctx.font = D.font(10.5, true);
    ctx.fillStyle = '#5a3a7a';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText('点 P での合成波', B.x0 + 8, B.y0 + 11);
    ctx.font = D.font(9);
    ctx.fillStyle = '#7a6392';
    ctx.textAlign = 'right';
    ctx.fillText('S₁ ＋ S₂', B.x1 - 8, B.y0 + 11);

    ctx.strokeStyle = '#cfc4de'; ctx.lineWidth = 1;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(x0, cy); ctx.lineTo(x1, cy);
    ctx.moveTo(x0, cy - 2 * unit); ctx.lineTo(x1, cy - 2 * unit);
    ctx.moveTo(x0, cy + 2 * unit); ctx.lineTo(x1, cy + 2 * unit);
    ctx.stroke();
    ctx.setLineDash([]);

    var steps = 300, i;
    var cols = ['rgba(232,134,42,0.6)', 'rgba(31,116,208,0.6)'];
    for (var j = 0; j < 2; j++) {
      ctx.lineWidth = 1.1; ctx.strokeStyle = cols[j];
      ctx.beginPath();
      for (i = 0; i <= steps; i++) {
        var px = (x1 - x0) * i / steps;
        var y = cy - P.waveAt(px * nmPerPx + j * delta, t, st.lambda) * unit;
        if (i === 0) ctx.moveTo(x0 + px, y); else ctx.lineTo(x0 + px, y);
      }
      ctx.stroke();
    }
    if (st.showSum) {
      ctx.strokeStyle = COL.sum; ctx.lineWidth = 2.2; ctx.lineJoin = 'round';
      ctx.beginPath();
      for (i = 0; i <= steps; i++) {
        var px2 = (x1 - x0) * i / steps;
        var sum = P.waveAt(px2 * nmPerPx, t, st.lambda) + P.waveAt(px2 * nmPerPx + delta, t, st.lambda);
        var y2 = cy - sum * unit;
        if (i === 0) ctx.moveTo(x0 + px2, y2); else ctx.lineTo(x0 + px2, y2);
      }
      ctx.stroke();
    }

    var amp = 2 * Math.abs(Math.cos(Math.PI * delta / st.lambda));
    var ty = B.y1 - 11;
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.font = D.font(9.5);
    ctx.fillStyle = '#5a3a7a';
    ctx.fillText('振幅', B.x0 + 8, ty);
    ctx.font = D.font(11, true);
    ctx.fillStyle = amp > 1.4 ? '#1b6b34' : (amp < 0.6 ? '#a12a1c' : '#8a6d00');
    ctx.fillText(amp.toFixed(2) + '/2.00', B.x0 + 36, ty);
    ctx.font = D.font(9.5, true);
    ctx.textAlign = 'right';
    ctx.fillText(sol.kind === 'strong' ? 'そろう（明線）'
      : (sol.kind === 'weak' ? '打ち消す（暗線）' : '完全にはそろわない'), B.x1 - 8, ty);
    ctx.restore();
  }

  /* ================= 素元波（同心円）の模式図（ボタンで表示） ================= */
  function wavelets(ctx, st, sol, sc) {
    var S1 = sc.S1, S2 = sc.S2;
    var xL = L.GX + 6, xR = L.BREAK_X - 6;
    var lam = D.dispLamPx(st);
    var v = P.V_NM_PER_S / st.lambda * lam;      // 見た目の速さ [px/s]（1 次元の波と同じ位相速度）
    var phase = ((st.t || 0) * v) % lam;
    function rings(S, color, x0, x1, rMax) {
      ctx.save();
      ctx.beginPath();
      ctx.rect(x0, L.CY - L.SH, x1 - x0, 2 * L.SH);
      ctx.clip();
      ctx.lineWidth = 1.1;
      ctx.strokeStyle = color;
      for (var r = phase; r < rMax; r += lam) {
        if (r < 1) continue;
        ctx.beginPath();
        ctx.arc(S.x, S.y, r, -Math.PI / 2.1, Math.PI / 2.1);
        ctx.stroke();
      }
      ctx.restore();
    }
    // S₀ から出て、ダブルスリットまで広がる波面（S₀ でも回折している）
    rings(vec(L.S0X + 5, L.CY), 'rgba(160,120,60,0.30)', L.S0X + 6, L.GX - 6, L.GX - L.S0X + 40);
    // S₁・S₂ から出て、重なりあう波面
    rings(S1, 'rgba(232,134,42,0.30)', xL, xR, 700);
    rings(S2, 'rgba(31,116,208,0.28)', xL, xR, 700);
    ctx.save();
    ctx.font = D.font(10.5);
    ctx.fillStyle = '#8a939c';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText('※ 同心円（素元波）は、ようすを見るための模式図です。実際は λ が d の約 1/'
      + Math.round(st.d / st.lambda) + ' なので、この図には描けません。', L.DIV + 26, L.CY + L.SH + 8);
    ctx.restore();
  }

  /* ================= 左上の見出し ================= */
  function title(ctx) {
    var t = '② 実際の波の動きを見る';
    ctx.save();
    ctx.font = D.font(13.5, true);
    var w = ctx.measureText(t).width + 26;
    D.roundRect(ctx, 12, 10, w, 28, 8);
    ctx.fillStyle = '#f3ecfa'; ctx.fill();
    ctx.strokeStyle = '#8b3fa8'; ctx.lineWidth = 1.6; ctx.stroke();
    ctx.fillStyle = '#6d2f86';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(t, 25, 25);
    ctx.restore();
  }

  function render(ctx, st, sol, sc) {
    YG.modePath.render(ctx, st, sol, sc, { wave: true });
  }

  return { render: render, intensityGraph: intensityGraph, sumCard: sumCard, wavelets: wavelets, title: title };
})();
