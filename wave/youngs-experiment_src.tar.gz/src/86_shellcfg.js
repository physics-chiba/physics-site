/* =========================================================================
   86_shellcfg.js … このページの見出しの帯・章の扉・目次に出す文（87_shell.js が読む）
   タブの名前と並びは 20_body.html の <nav id="tabs"> に書いてある（ここは英字の副題とリードだけ）。
   ========================================================================= */
window.SHELL_CFG = {
  here: 'wave/youngs-experiment.html',
  crumb: 'ヤングの実験',
  en: 'Young’s Double-Slit Experiment',
  t1: '光の干渉',
  t2: '〜ヤングの実験〜',
  lead: '2 つのスリットを通った光が、スクリーンのどこで明るくなるのかを確かめよう。まず波の動きを見て、そのあと経路差の作図と式へ進みます。',
  modes: {
    wave:   { en: 'Watching the Waves',
              lead: 'S₁ と S₂ を出た 2 つの波を動かして見ます。スクリーン上の点 P で山と山が重なれば明線、山と谷が重なれば暗線です。' },
    path:   { en: 'Where the Path Difference Appears',
              lead: '経路差 d sinθ が図のどこに現れるのかを、4 つのステップで作図からたどり、明線の位置 x ≒ mλL/d の式まで進みます。' },
    deltax: { en: 'Deriving the Fringe Spacing',
              lead: 'となりあう明線の位置の差から、明線の間隔 Δx ≒ λL/d を導きます。d・L・λ を変えて確かめよう。' },
    setup:  { en: 'The Real Scale of the Apparatus',
              lead: '装置を本当の大きさで見て、スリットのまわりをどこまで拡大して考えているのかを確かめます。' },
    liquid: { en: 'Immersed in a Liquid',
              lead: '装置をまるごと屈折率 n の液体の中に入れると、波長が λ/n に縮み、縞の間隔も 1/n になります。' },
    film:   { en: 'A Thin Film in Front of a Slit',
              lead: 'S₂ の手前に薄膜（厚さ t・屈折率 n′）を置くと、光路差が (n′ − 1)t だけ変わり、縞全体がずれます（入試の典型問題）。' }
  },
  secs: [
    { id: 'sec-purpose', name: 'このページの目的と式の流れ' },
    { id: 'sec-quiz', name: '練習問題' },
    { id: 'sec-more', name: '補足：もっと深く知りたい人へ' }
  ]
};
