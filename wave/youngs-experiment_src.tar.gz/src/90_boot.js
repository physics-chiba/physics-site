/* ===== 90_boot.js ===== */
(function () {
  'use strict';
  function boot() {
    YG.ui.start();
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
