/* ===== 90_boot.js ===== */
(function () {
  'use strict';
  function boot() {
    try { YG.quiz.build(); } catch (e) { /* 練習問題が出なくてもシミュレーションは動く */ }
    YG.ui.start();
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
