/* ===== 80_quiz.js ===== */
/* 練習問題（3 問）。選ぶとすぐに正誤と解説が出る。 */
window.YG = window.YG || {};
YG.quiz = (function () {
  'use strict';

  var QUESTIONS = [
    {
      q: '明線の位置 x<sub>m</sub> ≒ mλL/d を導く途中で、次のうちどの近似を使いましたか。',
      opts: [
        { t: 'θ が小さいので sinθ ≒ tanθ とした', ok: true },
        { t: 'd が小さいので d sinθ ≒ 0 とした', ok: false },
        { t: 'λ が小さいので λ ≒ 0 とした', ok: false },
        { t: '近似はまったく使っていない', ok: false }
      ],
      fb: [
        '正解。d sinθ ＝ mλ の sinθ を、tanθ ＝ x/L で置きかえるところが唯一の近似です。1 次の明線でも θ は 0.2° ほどしかないので、sinθ と tanθ の差は 0.001 % 以下。図でも見分けがつきません。',
        'ちがいます。d sinθ こそが経路差そのもので、これを 0 にしてしまうと干渉が起きなくなります。',
        'ちがいます。λ は明線の間隔を決める主役です。0 にはできません。',
        'いいえ、1 つだけ使っています。「L が d や x よりずっと大きい」ことを根拠にした近似です。'
      ]
    },
    {
      q: 'λ と L はそのままで、スリットの間隔 d だけを<b>半分</b>にしました。明線の間隔 Δx はどうなりますか。',
      opts: [
        { t: '2 倍になる', ok: true },
        { t: '半分になる', ok: false },
        { t: '変わらない', ok: false },
        { t: '4 倍になる', ok: false }
      ],
      fb: [
        '正解。Δx ≒ λL/d で、Δx は d に<b>反比例</b>します。d を半分にすれば Δx は 2 倍。③のタブで d のスライダーを動かして確かめてみましょう。',
        '逆です。d は分母にあるので、d を小さくすると Δx は<b>大きく</b>なります。',
        'いいえ。Δx ≒ λL/d なので、d が変われば Δx も変わります。',
        '比例の関係を 2 回かけてしまっています。Δx は d の 1 乗に反比例するので 2 倍です。'
      ]
    },
    {
      q: '図のように S₀ → S₂ の光路に、厚さ t ＝ 2.0 μm・屈折率 n′ ＝ 1.5 の薄膜を差し入れました。d ＝ 0.20 mm、L ＝ 1.0 m です。もとは O にあった m ＝ 0 の明線は、どちらへどれだけ動きますか。',
      opts: [
        { t: 'S₂ 側（下）へ 5.0 mm', ok: true },
        { t: 'S₁ 側（上）へ 5.0 mm', ok: false },
        { t: 'S₂ 側（下）へ 10 mm', ok: false },
        { t: '動かない（間隔 Δx だけが変わる）', ok: false }
      ],
      fb: [
        '正解。(n′−1)t ＝ 0.5 × 2.0 μm ＝ 1.0 μm。x ＝ −(n′−1)tL/d ＝ −(1.0×10⁻⁶ × 1.0) / (0.20×10⁻³) ＝ −5.0×10⁻³ m ＝ −5.0 mm。負の符号は S₂ 側（下）を意味します。間隔 Δx ＝ 3.0 mm は変わりません。',
        '向きが逆です。S₂ 側の光路が長くなったので、それを取り返せるのは<b>幾何的に S₂ が近くなる側</b>、つまり S₂ 側（下）です。',
        '(n′−1) を n′ と取りちがえていませんか。長くなるのは n′t ではなく (n′−1)t ＝ 1.0 μm のぶんだけです。',
        '動きます。第 2 項 −(n′−1)tL/d は m によらない一定のずれなので、<b>間隔は変えずに縞全体が平行移動</b>します。'
      ]
    }
  ];

  function build() {
    var box = document.getElementById('quiz');
    if (!box) return;
    QUESTIONS.forEach(function (Q, qi) {
      var card = document.createElement('div');
      card.className = 'q';
      var h = document.createElement('div');
      h.className = 'qh';
      h.innerHTML = '問 ' + (qi + 1) + '　' + Q.q;
      card.appendChild(h);

      var opts = document.createElement('div');
      opts.className = 'opts';
      var fb = document.createElement('div');
      fb.className = 'fb';
      fb.textContent = '選んでみましょう。';

      Q.opts.forEach(function (o, oi) {
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'opt';
        b.innerHTML = '<span class="mk">' + 'アイウエ'.charAt(oi) + '</span>'
          + '<span class="optbody"><span>' + o.t + '</span></span>';
        b.addEventListener('click', function () {
          var all = opts.querySelectorAll('.opt');
          for (var i = 0; i < all.length; i++) all[i].classList.remove('correct', 'wrong');
          b.classList.add(o.ok ? 'correct' : 'wrong');
          fb.className = 'fb ' + (o.ok ? 'ok' : 'ng');
          fb.innerHTML = (o.ok ? '◯　' : '✕　') + Q.fb[oi];
          if (YG.ui) YG.ui.renderKatexIn(fb);
        });
        opts.appendChild(b);
      });
      card.appendChild(opts);
      card.appendChild(fb);
      box.appendChild(card);
    });
  }

  return { build: build, QUESTIONS: QUESTIONS };
})();
