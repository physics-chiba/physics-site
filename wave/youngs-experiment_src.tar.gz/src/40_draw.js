/* ===== 40_draw.js ===== */
/* canvas 共通描画部品：レイアウト定数・座標系の組み立て・図の部品
 * 書体は 1 つだけ。大きさと太さだけで区別する。
 */
window.YG = window.YG || {};
YG.draw = (function () {
  'use strict';
  var P = YG.phys;

  /* ---------- レイアウト定数 ----------
   * 図は横 1300 × 縦 700。下 158 px は「経路差をまっすぐ伸ばす」帯。
   *   左パネル（x 0〜336）   ：S₁・S₂ の拡大（教科書 図62ⓑ の作図）
   *   右パネル（x 336〜1300）：全体（光源 Q → S₀ → S₁S₂ →〔省略〕→ スクリーン）
   *
   * 縦（スクリーン上の位置）は物理の縮尺どおり：SH px ＝ halfM メートル。
   * 横（ダブルスリット〜スクリーンの距離 L）は d にくらべてけた違いに長いので、
   * 途中を省略記号で省いて一定の長さに描く。
   */
  var L = {
    W: 1300, H: 700,
    BAND_Y: 542,        // 帯の上端（図の描画はここまで）
    DIV: 336,           // 左パネルと右パネルの境目
    CY: 262,            // 光軸の y
    SH: 200,            // スクリーンの半分の高さ [px]
    SCR_W: 26,          // スクリーンの面の幅 [px]（②はここに干渉パターンを描く）
    SRC_X: 392,         // 光源 Q の x
    S0X: 470,           // S₀ の板の x
    GX: 646,            // ダブルスリットの板の x
    BREAK_X: 852,       // 省略記号の位置
    SX: 1092,           // スクリーンの面の x
    STRIP_X0: 1132, STRIP_X1: 1178,   // 干渉パターンの帯（②で使う）
    GRAPH_X0: 1196, GRAPH_X1: 1292,   // 強度グラフの帯（②で使う）
    PLATE_H: 150,       // 板の高さ [px]
    S0_PLATE_H: 116,
    SLIT_SP: 76,        // 図に描く S₁S₂ の間隔 [px]（実際の d は 2 px ほど。スマホでも見えるよう大きく）
    // 左パネル（拡大図）
    LCY: 268,           // 拡大図の中心の y
    LX: 96,             // 拡大図のスリット板の x
    LD: 140,            // 拡大図で d を何 px に描くか
    RAY: 206,           // 拡大図の光線の長さ [px]
    AMP: 9              // 波の振幅 [px]
  };

  /* 拡大図で波を描くときの決め ----------------------------------------
   * ヤングの実験は d ÷ λ ≒ 330。正しい縮尺で d を 208 px に描くと
   * λ = 0.6 px となり、波はまったく見えない。そこで λ と経路差を
   * そろって大きく描く（教科書 図61 の注記と同じ立場）。
   *   ・λ を lamPx（px）に描く
   *   ・経路差も同じものさしで描く ＝ 経路差 ÷ λ の比は厳密に正しいまま
   *   ・図の中に「λ を実際の約 ○○ 倍に描いています」と常時出す
   *
   * λ は「600 nm のとき 35 px」を基準に、λ に比例した px で描く（λ のスライダーを
   * 動かすと、図の中の波の波長もそのまま伸び縮みする）。すると拡大図の見かけの角は
   *   sinθ_draw ＝（経路差÷λ）× lamPx / LD
   * となり、λ ＝ 600 nm なら m ＝ 1 で約 14.5°、m ＝ 2 で 30°、m ＝ 3 で約 49° と、
   * 教科書の作図に近い読みやすい角になる。
   * 高い次数（sinθ_draw が 0.9 をこえるとき）だけ λ を細めて、角が寝すぎないようにする。 */
  var LAM_PX_REF = 35, LAM_REF_NM = 600, LAM_PX_MIN = 8, SIN_DRAW_MAX = 0.90;

  /** 拡大図で λ を何 px に描くか */
  function lamPxOf(st, sol) {
    var base = LAM_PX_REF * st.lambda / LAM_REF_NM;
    var ratio = Math.abs(sol.ratio - (sol.extra / st.lambda));  // 幾何ぶんの 経路差÷λ
    if (!(ratio > 0.05)) return base;
    return P.clamp(Math.min(base, SIN_DRAW_MAX * L.LD / ratio), LAM_PX_MIN, base);
  }

  /* 全体図（右パネル）に描く波の見かけの波長 [px]。こちらも λ に比例させる。
   * 全体図は横を縮めて描いているので、ここの波は「進んでいるようす」を見せるためのもの。
   * ただし 2 本の光線の位相のずれ（何波長ぶんか）は厳密に正しく描く。 */
  var DISP_LAM_REF = 26, DISP_AMP = 2.4;
  function dispLamPx(st) { return DISP_LAM_REF * st.lambda / LAM_REF_NM; }
  /** λ を実際の何倍に描いているか（＝角 θ を何倍に描いているか） */
  function exaggerationOf(st, lamPx) {
    return lamPx / (L.LD * st.lambda / st.d);
  }

  var COL = {
    ray: '#e8862a',        // 光線（波長に応じて少し色が変わる）
    rayDim: '#f0c48c',
    ray2: '#1f74d0',       // S₂ からの光（2 本を見分けるとき）
    sum: '#7b3fa8',        // 合成波
    plate: '#cfe6f2',      // 板（ガラス）
    plateEdge: '#5b93b5',
    film: '#bfe0c8',       // 薄膜
    filmEdge: '#3f8f5c',
    screen: '#efe6d2',
    screenEdge: '#a89878',
    line: '#5a5a5a',
    guide: '#9aa0a6',
    geo: '#0f9d58',        // 経路差のハイライト
    ang: '#3d51a8',        // 角 θ
    hi: '#e0a800',
    zero: '#d2337c'        // m = 0 の明線を強調する色（補足モード）
  };

  /* ---- 光線の色：基準のオレンジを、波長の色へ少しだけ寄せる ---- */
  var BASE_RAY = '#e8862a';
  var LAM_REF = 600;

  function hex2rgb(h) {
    return { r: parseInt(h.substr(1, 2), 16), g: parseInt(h.substr(3, 2), 16), b: parseInt(h.substr(5, 2), 16) };
  }
  function rgbHex(c) {
    function h(v) {
      var x = Math.round(P.clamp(v, 0, 255)).toString(16);
      return x.length < 2 ? '0' + x : x;
    }
    return '#' + h(c.r) + h(c.g) + h(c.b);
  }
  function shade(hex, k) {
    var c = hex2rgb(hex);
    return rgbHex({ r: c.r * k, g: c.g * k, b: c.b * k });
  }
  /** 明るさをそろえた波長の色（端の波長でも暗くならないように） */
  function pureColor(lambda) {
    var w = P.wavelengthToRGB(lambda);
    var m = Math.max(w.r, w.g, w.b) || 1;
    return { r: w.r * 255 / m, g: w.g * 255 / m, b: w.b * 255 / m };
  }
  /** λ = 600 nm でちょうど基準のオレンジ。そこからの色のずれぶんだけ寄せる */
  function setLightColor(lambda) {
    var base = hex2rgb(BASE_RAY);
    var cur = pureColor(lambda), ref = pureColor(LAM_REF);
    var k = 0.3;
    COL.ray = rgbHex({
      r: base.r + (cur.r - ref.r) * k,
      g: base.g + (cur.g - ref.g) * k,
      b: base.b + (cur.b - ref.b) * k
    });
    COL.rayDim = shade(COL.ray, 1.28);
  }

  /* ---------- 書体 ---------- */
  /* 図の中の文字は「読みやすさ最優先」の書体で描く。
   *   Windows … BIZ UDPゴシック（Windows 10 以降に標準搭載の UD 書体。細い游ゴシックは避ける）→ メイリオ
   *   Mac/iOS … ヒラギノ角ゴ
   *   Android … Noto Sans JP
   * どれも無ければ sans-serif。 */
  var FONT = '"BIZ UDPGothic","BIZ UDPゴシック","Hiragino Sans","Hiragino Kaku Gothic ProN",Meiryo,"メイリオ",'
    + '"Noto Sans JP","Noto Sans CJK JP","Yu Gothic UI","Yu Gothic",sans-serif';
  /* canvas は 1300 px を 1200 px ほどに縮めて表示するので、字は大きめにする。
     教室のプロジェクタやスマホでも読めるように。 */
  var FONT_K = 1.30;
  function font(px, bold) {
    return (bold ? 'bold ' : '') + (Math.round(px * FONT_K * 10) / 10) + 'px ' + FONT;
  }

  /* ---------- canvas の中に KaTeX の数式をきれいに描く ----------
   * KaTeX は本来 DOM に HTML を差しこんで描くものなので、canvas にそのままは描けない。
   * そこで、KaTeX の HTML を SVG の foreignObject に包んで画像化し、それを canvas に
   * drawImage する。KaTeX の CSS（フォントは base64 で埋めこみずみ＝外部通信なし）を
   * 同じ SVG の中に <style> でそのまま持ちこむので、オフラインのまま使える。
   * 画像の生成は非同期なので、初回は文字だけの代わりの表示にして、
   * できあがったら次の描画フレームから自動的に差しかわる。
   */
  var texCache = {};
  var katexCssText = null;
  function texImage(tex, opt) {
    opt = opt || {};
    var key = tex + '|' + (opt.color || '') + '|' + (opt.size || '') + '|' + (opt.display ? 1 : 0);
    var entry = texCache[key];
    if (entry) return entry;
    entry = { img: null, w: 0, h: 0, loading: true, failed: false };
    texCache[key] = entry;
    try {
      if (typeof katex === 'undefined') { entry.loading = false; entry.failed = true; return entry; }
      if (katexCssText === null) {
        var st = document.getElementById('katex-css');
        katexCssText = st ? st.textContent : '';
      }
      var html = katex.renderToString(tex, { throwOnError: false, displayMode: !!opt.display });
      var fontSize = opt.size || 20;
      var color = opt.color || '#222';
      var probe = document.createElement('div');
      probe.style.cssText = 'position:absolute;left:-9999px;top:-9999px;font-size:' + fontSize
        + 'px;color:' + color + ';white-space:nowrap;line-height:1.15;';
      probe.innerHTML = html;
      document.body.appendChild(probe);
      var w = Math.ceil(probe.offsetWidth) + 6, h = Math.ceil(probe.offsetHeight) + 6;
      document.body.removeChild(probe);
      if (w < 2 || h < 2) { entry.loading = false; entry.failed = true; return entry; }
      // canvas は CSS で縮めて表示される（見た目の解像度が下がる）ので、
      // 「＋」のような細い線がつぶれないよう、実際より大きく（SS 倍）描いてから
      // drawImage で縮小する。
      var SS = 3;
      var W = w * SS, H = h * SS, FS = fontSize * SS;
      var svgStr = '<svg xmlns="http://www.w3.org/2000/svg" width="' + W + '" height="' + H + '">'
        + '<foreignObject width="100%" height="100%"><div xmlns="http://www.w3.org/1999/xhtml" '
        + 'style="font-size:' + FS + 'px;color:' + color + ';line-height:1.15;display:inline-block;">'
        + '<style>' + katexCssText + '</style>' + html
        + '</div></foreignObject></svg>';
      var url = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgStr)));
      var img = new Image();
      img.onload = function () { entry.img = img; entry.w = w; entry.h = h; entry.loading = false; };
      img.onerror = function () { entry.loading = false; entry.failed = true; };
      img.src = url;
    } catch (e) { entry.loading = false; entry.failed = true; }
    return entry;
  }
  /** できていれば画像で、まだなら何も描かずに済ませる（呼び出し側でフォールバックの文字を用意する） */
  function drawTex(ctx, tex, x, y, opt) {
    var e = texImage(tex, opt);
    if (!e.img) return false;
    var s = (opt && opt.scale) || 1;
    ctx.save();
    ctx.imageSmoothingEnabled = true;
    if ('imageSmoothingQuality' in ctx) ctx.imageSmoothingQuality = 'high';
    // canvas 自体が CSS でさらに縮小表示されるため、1 回だけ描くと 1px 級の線が
    // つぶれることがある。半ピクセルずらして 2 回重ね描きしておく。
    ctx.drawImage(e.img, x, y, e.w * s, e.h * s);
    ctx.drawImage(e.img, x + 0.5, y, e.w * s, e.h * s);
    ctx.restore();
    return true;
  }

  /* ---------- ベクトル小物 ---------- */
  function vec(x, y) { return { x: x, y: y }; }
  function add(a, b) { return vec(a.x + b.x, a.y + b.y); }
  function sub(a, b) { return vec(a.x - b.x, a.y - b.y); }
  function mul(a, k) { return vec(a.x * k, a.y * k); }
  function dot(a, b) { return a.x * b.x + a.y * b.y; }
  function len(a) { return Math.hypot(a.x, a.y); }
  function nrmOf(d) { return vec(-d.y, d.x); }
  function unit(a) { var l = len(a) || 1; return vec(a.x / l, a.y / l); }

  /* ---------- 座標系の組み立て ----------
   * ・スクリーンは「物理的に決まった高さ」をもつ（半分 = SH px ＝ halfM m）
   * ・ダブルスリット〜スクリーンの距離は途中を省略して一定の長さに描く
   * ・拡大図（左）の角は、λ を見えるように大きく描いたぶんだけ実際より大きい
   */
  function buildScene(st, sol) {
    var ppm = L.SH / sol.halfM;                 // 縦の縮尺 [px / m]

    // 全体図のスリット（実際の d は 2 px ほどにしかならないので、見えるように広げて描く）
    var S1 = vec(L.GX, L.CY - L.SLIT_SP / 2);   // 上（x の正の側）
    var S2 = vec(L.GX, L.CY + L.SLIT_SP / 2);   // 下

    // スクリーン上の点 P
    var py = L.CY - sol.x * ppm;
    var Pp = vec(L.SX, P.clamp(py, L.CY - L.SH, L.CY + L.SH));

    // 拡大図（左パネル）
    var lamPx = lamPxOf(st, sol);
    var exagg = exaggerationOf(st, lamPx);
    var LS1 = vec(L.LX, L.LCY - L.LD / 2);
    var LS2 = vec(L.LX, L.LCY + L.LD / 2);
    // 拡大図での見かけの角：sinθ_draw ＝（経路差÷λ）× lamPx / LD
    //   ⇒ 描いた経路差 LD·sinθ_draw ＝（経路差÷λ）× lamPx（＝λ 何個ぶんか、が図でも正しい）
    var geoRatio = st.d * Math.sin(sol.theta) / st.lambda;   // 幾何ぶんの 経路差÷λ
    var sinDraw = P.clamp(geoRatio * lamPx / L.LD, -0.985, 0.985);
    var thDraw = Math.asin(sinDraw);
    var u = vec(Math.cos(thDraw), -Math.sin(thDraw));        // 光線の向き（上が正）

    // 近いほうのスリットから、遠いほうの光線に下ろした垂線の足 H
    var near = (sinDraw >= 0) ? LS1 : LS2;
    var far = (sinDraw >= 0) ? LS2 : LS1;
    var proj = dot(sub(near, far), u);                       // ＝ LD·|sinθ_draw| ≧ 0
    var H = add(far, mul(u, proj));

    return {
      ppm: ppm, halfM: sol.halfM,
      S1: S1, S2: S2, P: Pp, ppy: py,
      LS1: LS1, LS2: LS2, near: near, far: far, H: H,
      u: u, thDraw: thDraw, sinDraw: sinDraw, proj: proj,
      lamPx: lamPx, exagg: exagg,
      nmPerPx: st.lambda / lamPx      // 拡大図・帯で共通のものさし [nm / px]
    };
  }

  /* ================= 基本の図形 ================= */
  function roundRect(ctx, x, y, w, h, r) {
    var rr = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + rr, y);
    ctx.arcTo(x + w, y, x + w, y + h, rr);
    ctx.arcTo(x + w, y + h, x, y + h, rr);
    ctx.arcTo(x, y + h, x, y, rr);
    ctx.arcTo(x, y, x + w, y, rr);
    ctx.closePath();
  }
  function line(ctx, a, b, color, w, dash) {
    ctx.save();
    if (dash) ctx.setLineDash(dash);
    ctx.strokeStyle = color; ctx.lineWidth = w || 1.5; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
    ctx.restore();
  }
  function dashLine(ctx, a, b, color, dash, width) {
    line(ctx, a, b, color, width || 1.2, dash || [5, 4]);
  }
  function arrow(ctx, from, dir, length, color, width, headLen) {
    var to = add(from, mul(dir, length));
    ctx.save();
    ctx.strokeStyle = color; ctx.fillStyle = color;
    ctx.lineWidth = width || 2; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(from.x, from.y); ctx.lineTo(to.x, to.y); ctx.stroke();
    var h = headLen || 8, nn = nrmOf(dir);
    ctx.beginPath();
    ctx.moveTo(to.x, to.y);
    ctx.lineTo(to.x - dir.x * h + nn.x * h * 0.5, to.y - dir.y * h + nn.y * h * 0.5);
    ctx.lineTo(to.x - dir.x * h - nn.x * h * 0.5, to.y - dir.y * h - nn.y * h * 0.5);
    ctx.closePath(); ctx.fill();
    ctx.restore();
  }
  /* 省略記号（BREAK_X〜BREAK_X＋BREAK_W）の区間。ここは「途中を省いている」場所なので、
   * 光線もその上の波も描かない（全モード共通の決まり。千葉さん指定）。 */
  var BREAK_W = 26;
  var GAP = { x0: L.BREAK_X - 1, x1: L.BREAK_X + BREAK_W + 1 };
  function inGap(x) { return x > GAP.x0 && x < GAP.x1; }
  /** 省略記号の区間を飛ばして直線を引く（区間をまたぐときは 2 本に分ける） */
  function lineSkipGap(ctx, a, b, color, w) {
    var dx = b.x - a.x;
    if (Math.abs(dx) < 1e-6 || (!inGap(a.x) && !inGap(b.x) && (a.x - GAP.x0) * (b.x - GAP.x0) > 0)) {
      line(ctx, a, b, color, w);
      return;
    }
    function at(x) { var k = (x - a.x) / dx; return vec(x, a.y + (b.y - a.y) * k); }
    var lo = Math.min(a.x, b.x), hi = Math.max(a.x, b.x);
    var p0 = (a.x < b.x) ? a : b, p1 = (a.x < b.x) ? b : a;
    if (lo < GAP.x0) line(ctx, p0, at(Math.min(GAP.x0, hi)), color, w);
    if (hi > GAP.x1) line(ctx, at(Math.max(GAP.x1, lo)), p1, color, w);
  }

  /** 寸法線（両端に矢じり＋まん中にラベル） */
  function dimLine(ctx, a, b, label, color, side) {
    var c = color || '#6b7580';
    var u = unit(sub(b, a));
    ctx.save();
    ctx.strokeStyle = c; ctx.fillStyle = c; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
    function head(p, d) {
      var nn = nrmOf(d);
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(p.x + d.x * 7 + nn.x * 3.2, p.y + d.y * 7 + nn.y * 3.2);
      ctx.lineTo(p.x + d.x * 7 - nn.x * 3.2, p.y + d.y * 7 - nn.y * 3.2);
      ctx.closePath(); ctx.fill();
    }
    head(a, u); head(b, mul(u, -1));
    if (label) {
      var m = mul(add(a, b), 0.5);
      var nn2 = nrmOf(u);
      var off = (side === undefined ? 11 : side);
      var lx = m.x + nn2.x * off, ly = m.y + nn2.y * off;
      ctx.font = font(12.5, true);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      var w = ctx.measureText(label).width;
      ctx.fillStyle = 'rgba(255,255,255,0.88)';
      ctx.fillRect(lx - w / 2 - 3, ly - 8, w + 6, 16);
      ctx.fillStyle = c;
      ctx.fillText(label, lx, ly);
    }
    ctx.restore();
  }

  /**
   * 決まった場所に置く吹き出し（引き出し線は anchor まで伸びる）。
   * 位置を図の内容から計算すると、角度や次数によって別のラベルと重なる。
   * ステップの吹き出しはこれを使い、置き場所を固定して衝突をなくす。
   */
  function calloutAt(ctx, anchor, bx, by, lines, opt) {
    opt = opt || {};
    ctx.save();
    ctx.font = (opt.font || font(12));
    var pad = 6, lh = 15.5;
    var w = 0;
    for (var i = 0; i < lines.length; i++) w = Math.max(w, ctx.measureText(lines[i]).width);
    var bw = w + pad * 2, bh = lines.length * lh + pad * 2 - 3;
    bx = P.clamp(bx, 4, L.W - bw - 4);
    by = P.clamp(by, 4, L.BAND_Y - bh - 12);
    if (anchor) {
      var hx = P.clamp(anchor.x, bx, bx + bw);
      var hy = (anchor.y < by) ? by : (anchor.y > by + bh ? by + bh : anchor.y);
      if (hx > bx && hx < bx + bw) hx = P.clamp(anchor.x, bx + 8, bx + bw - 8);
      ctx.strokeStyle = opt.border || '#9a9a9a'; ctx.lineWidth = 1;
      ctx.setLineDash([4, 3]);
      ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(anchor.x, anchor.y); ctx.stroke();
      ctx.setLineDash([]);
      ctx.beginPath(); ctx.arc(anchor.x, anchor.y, 3, 0, Math.PI * 2);
      ctx.fillStyle = opt.border || '#8a8a8a'; ctx.fill();
    }
    roundRect(ctx, bx, by, bw, bh, 6);
    ctx.fillStyle = opt.bg || 'rgba(255,255,255,0.97)'; ctx.fill();
    ctx.strokeStyle = opt.border || '#b9b9b9'; ctx.lineWidth = 1.4; ctx.stroke();
    ctx.fillStyle = opt.fg || '#222';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    for (var j = 0; j < lines.length; j++) ctx.fillText(lines[j], bx + pad, by + pad + j * lh);
    ctx.restore();
    return { x: bx, y: by, w: bw, h: bh };
  }

  /** 図の左上に出す「いまのステップ」の見出し（丸数字つき） */
  function stepHeading(ctx, x, y, text) {
    ctx.save();
    ctx.font = font(13.5, true);
    var w = ctx.measureText(text).width + 24, h = 30;
    roundRect(ctx, x, y, w, h, 8);
    ctx.fillStyle = '#fff6e2'; ctx.fill();
    ctx.strokeStyle = '#e0a24a'; ctx.lineWidth = 1.6; ctx.stroke();
    ctx.fillStyle = '#7a4a06';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(text, x + 12, y + h / 2 + 1);
    ctx.restore();
    return { x: x, y: y, w: w, h: h };
  }

  /** 観測者の目（見ている向きに回転する） */
  function eye(ctx, p, gaze, scale, label, labelBelow, labelDy, labelDx) {
    var s = scale || 1;
    var ang = Math.atan2(gaze.y, gaze.x);
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.rotate(ang);
    ctx.scale(s, s);
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.ellipse(0, 0, 25, 18, 0, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(255,255,255,0.92)'; ctx.fill();
    ctx.beginPath();
    ctx.moveTo(-19, 0);
    ctx.quadraticCurveTo(0, -16, 19, 0);
    ctx.quadraticCurveTo(0, 16, -19, 0);
    ctx.closePath();
    ctx.fillStyle = '#ffffff'; ctx.fill();
    ctx.strokeStyle = '#2b2118'; ctx.lineWidth = 3.4; ctx.stroke();
    ctx.beginPath(); ctx.arc(6, 0, 5.2, 0, Math.PI * 2);
    ctx.fillStyle = '#ffffff'; ctx.fill();
    ctx.strokeStyle = '#2b2118'; ctx.lineWidth = 2.6; ctx.stroke();
    ctx.strokeStyle = '#2b2118'; ctx.fillStyle = '#2b2118'; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.moveTo(25, 0); ctx.lineTo(38, 0); ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(50, 0); ctx.lineTo(36, -8); ctx.lineTo(36, 8);
    ctx.closePath(); ctx.fill();
    ctx.restore();

    if (label !== false) {
      var txt = (typeof label === 'string') ? label : '見る方向';
      ctx.save();
      ctx.font = font(11, true);
      var tw = ctx.measureText(txt).width;
      var lx = P.clamp(p.x + (labelDx || 0), tw / 2 + 4, L.W - tw / 2 - 4);
      var dy = labelDy || 30;
      var ly = P.clamp(p.y + (labelBelow ? dy : -dy), 12, L.BAND_Y - 8);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      roundRect(ctx, lx - tw / 2 - 5, ly - 9, tw + 10, 18, 5);
      ctx.fillStyle = 'rgba(255,255,255,0.92)'; ctx.fill();
      ctx.strokeStyle = '#b9b3ab'; ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = '#2b2118';
      ctx.fillText(txt, lx, ly);
      ctx.restore();
    }
  }

  /** 作図点のラベル（小さな黒点＋記号） */
  function pointLabel(ctx, p, text, dx, dy, color) {
    ctx.save();
    ctx.beginPath(); ctx.arc(p.x, p.y, 3.2, 0, Math.PI * 2);
    ctx.fillStyle = color || '#222'; ctx.fill();
    ctx.font = font(12.5, true);
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    var w = ctx.measureText(text).width;
    ctx.fillStyle = 'rgba(255,255,255,0.85)';
    ctx.fillRect(p.x + dx - w / 2 - 2, p.y + dy - 8, w + 4, 16);
    ctx.fillStyle = color || '#222';
    ctx.fillText(text, p.x + dx, p.y + dy);
    ctx.restore();
  }

  /** 直角のしるし */
  function rightAngle(ctx, p, d1, d2, size, color) {
    var s = size || 9;
    var a = add(p, mul(d1, s)), b = add(p, mul(d2, s));
    var c = add(a, mul(d2, s));
    ctx.save();
    ctx.strokeStyle = color || '#666'; ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(a.x, a.y); ctx.lineTo(c.x, c.y); ctx.lineTo(b.x, b.y);
    ctx.stroke();
    ctx.restore();
  }

  /** 角の弧（ラベルつき） */
  function angleArc(ctx, center, a0, a1, radius, color, label) {
    var lo = Math.min(a0, a1), hi = Math.max(a0, a1);
    if (hi - lo < 0.02) return;
    ctx.save();
    ctx.strokeStyle = color; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(center.x, center.y, radius, lo, hi); ctx.stroke();
    if (label) {
      var mid = (lo + hi) / 2;
      ctx.font = font(13, true);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      var tx = center.x + Math.cos(mid) * (radius + 15);
      var ty = center.y + Math.sin(mid) * (radius + 15);
      var w = ctx.measureText(label).width;
      ctx.fillStyle = 'rgba(255,255,255,0.85)';
      ctx.fillRect(tx - w / 2 - 2, ty - 8, w + 4, 16);
      ctx.fillStyle = color;
      ctx.fillText(label, tx, ty);
    }
    ctx.restore();
  }

  /* ---------- 図の中のボタン ---------- */
  var uiButtons = [];
  function resetButtons() { uiButtons.length = 0; }
  function canvasButton(ctx, x, y, label, id, hot, on) {
    ctx.save();
    ctx.font = font(12, true);
    var w = ctx.measureText(label).width + 22, h = 26;
    roundRect(ctx, x, y, w, h, 7);
    ctx.fillStyle = on ? '#ffe9c2' : (hot ? '#eaf1fa' : 'rgba(255,255,255,0.94)');
    ctx.fill();
    ctx.strokeStyle = on ? '#c77800' : (hot ? '#1f74d0' : '#b6bcc2');
    ctx.lineWidth = hot || on ? 1.8 : 1.2; ctx.stroke();
    ctx.fillStyle = on ? '#8a5300' : '#28405c';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(label, x + 11, y + h / 2 + 1);
    ctx.restore();
    uiButtons.push({ x: x, y: y, w: w, h: h, id: id });
    return w;
  }
  /** ボタンの見た目を描かずに、当たり判定だけ足す（図の中のラベルなど） */
  function addHit(x, y, w, h, id) { uiButtons.push({ x: x, y: y, w: w, h: h, id: id }); }
  function hitButton(px, py) {
    for (var i = 0; i < uiButtons.length; i++) {
      var b = uiButtons[i];
      if (px >= b.x && px <= b.x + b.w && py >= b.y && py <= b.y + b.h) return b.id;
    }
    return null;
  }

  /* ---------- パルス強調 ---------- */
  function pulseAmount(pulse, kind, nowSec) {
    if (!pulse || pulse.kind !== kind) return 0;
    var t = nowSec - pulse.t0;
    if (t < 0 || t > 1.6) return 0;
    var fade = 1 - t / 1.6;
    return fade * (0.55 + 0.45 * Math.cos(2 * Math.PI * 2.4 * t));
  }
  /** 線を太く光らせる（「⚡ 経路差を強調」で使う） */
  function glowLine(ctx, a, b, color, amount, dash) {
    if (!(amount > 0.01)) return;
    ctx.save();
    ctx.setLineDash(dash || []);
    ctx.strokeStyle = color;
    ctx.globalAlpha = 0.25 + 0.75 * amount;
    ctx.lineWidth = 4 + 11 * amount;
    ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
    ctx.restore();
  }
  function boxGlow(ctx, box, amount, color) {
    if (!box || !(amount > 0.01)) return;
    var g = 3 + 11 * amount;
    ctx.save();
    ctx.strokeStyle = color || '#e0a800';
    ctx.globalAlpha = 0.85 * amount;
    ctx.lineWidth = 2 + 5 * amount;
    roundRect(ctx, box.x - g, box.y - g, box.w + 2 * g, box.h + 2 * g, 8 + g);
    ctx.stroke();
    ctx.restore();
  }

  /* ---------- 光源 ---------- */
  function lightBulb(ctx, p, opt) {
    opt = opt || {};
    var s = opt.scale || 1;
    var glass = opt.white ? '#ffffff' : '#ffe9a8';
    var edge = opt.white ? '#8f979e' : '#b8860b';
    var beam = opt.white ? '#c9cfd4' : '#e0a800';
    ctx.save();
    ctx.translate(p.x, p.y); ctx.scale(s, s);
    ctx.lineCap = 'round';
    ctx.strokeStyle = beam; ctx.lineWidth = 2;
    for (var i = 0; i < 8; i++) {
      var a2 = i * Math.PI / 4;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a2) * 15, Math.sin(a2) * 15);
      ctx.lineTo(Math.cos(a2) * 21, Math.sin(a2) * 21);
      ctx.stroke();
    }
    ctx.fillStyle = '#9aa0a6';
    roundRect(ctx, -5, 6, 10, 10, 2); ctx.fill();
    ctx.beginPath(); ctx.arc(0, 0, 11, 0, Math.PI * 2);
    ctx.fillStyle = glass; ctx.fill();
    ctx.strokeStyle = edge; ctx.lineWidth = 1.6; ctx.stroke();
    ctx.strokeStyle = edge; ctx.lineWidth = 1.3;
    ctx.beginPath();
    ctx.moveTo(-4, 4); ctx.lineTo(-2, -2); ctx.lineTo(0, 3); ctx.lineTo(2, -2); ctx.lineTo(4, 4);
    ctx.stroke();
    ctx.restore();
  }

  /** 波長と色を示す小さな名札 */
  function waveChip(ctx, cx, cy, txt, rgb, dark) {
    ctx.save();
    ctx.font = font(11, true);
    var tw = ctx.measureText(txt).width;
    var bw = tw + 26;
    // 右パネルの中の名札は、左パネルにはみ出さない（境目 DIV より右に収める）
    var lo = (cx > L.DIV) ? L.DIV + 6 : 6;
    var bx = P.clamp(cx - bw / 2, lo, Math.max(lo, L.W - 6 - bw));
    roundRect(ctx, bx, cy - 9, bw, 18, 5);
    ctx.fillStyle = dark ? 'rgba(0,0,0,0.45)' : 'rgba(255,255,255,0.92)';
    ctx.fill();
    ctx.strokeStyle = dark ? '#6b5a2a' : '#cfd6dd'; ctx.lineWidth = 1; ctx.stroke();
    ctx.fillStyle = rgb || '#888';
    roundRect(ctx, bx + 6, cy - 5, 10, 10, 2); ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 1; ctx.stroke();
    ctx.fillStyle = dark ? '#e8ecf0' : '#3d4a54';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(txt, bx + 21, cy + 1);
    ctx.restore();
  }

  /** 光源の名札に添える「λ = 600 nm（橙色）」 */
  function lightText(st) {
    if (st.light === 'white') return '白色光（すべての波長）';
    // 媒質の中でも光の色（振動数）は変わらないので、表示するのは空気中の波長 λ₀
    var lam0 = st.lambda0 || st.lambda;
    return 'λ = ' + Math.round(lam0) + ' nm（' + P.colorName(lam0) + '色）';
  }

  /* ================= 図の骨組み ================= */

  /** 背景（左パネルをうすく塗り分け、境目に線を引く） */
  function panels(ctx) {
    ctx.save();
    ctx.fillStyle = '#f7fafc';
    ctx.fillRect(0, 0, L.DIV, L.BAND_Y);
    ctx.strokeStyle = '#dbe3ea'; ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(L.DIV + 0.5, 8); ctx.lineTo(L.DIV + 0.5, L.BAND_Y - 8);
    ctx.stroke();
    ctx.restore();
  }

  /** 1 本スリットの板（S₀）と、ダブルスリットの板（S₁・S₂） */
  function slitPlate(ctx, x, cy, halfH, gaps, label, sub, labelAbove) {
    ctx.save();
    var y0 = cy - halfH, y1 = cy + halfH;
    ctx.fillStyle = '#8d99a5';
    // 板を、すきま（gaps）を避けて縦に塗る
    var segs = [y0], i;
    for (i = 0; i < gaps.length; i++) { segs.push(gaps[i][0], gaps[i][1]); }
    segs.push(y1);
    for (i = 0; i + 1 < segs.length; i += 2) {
      if (segs[i + 1] > segs[i]) ctx.fillRect(x - 4, segs[i], 8, segs[i + 1] - segs[i]);
    }
    ctx.strokeStyle = '#5d6873'; ctx.lineWidth = 1;
    for (i = 0; i + 1 < segs.length; i += 2) {
      if (segs[i + 1] > segs[i]) ctx.strokeRect(x - 4, segs[i], 8, segs[i + 1] - segs[i]);
    }
    if (label) {
      ctx.font = font(12, true);
      ctx.fillStyle = '#41505d';
      ctx.textAlign = 'center';
      if (labelAbove) {
        ctx.textBaseline = 'bottom';
        ctx.fillText(label, x, y0 - 6);
      } else {
        ctx.textBaseline = 'top';
        ctx.fillText(label, x, y1 + 6);
      }
      if (sub && !labelAbove) {
        ctx.font = font(10.5);
        ctx.fillStyle = '#6b7580';
        ctx.fillText(sub, x, y1 + 22);
      }
    }
    ctx.restore();
  }

  /**
   * 省略記号。ダブルスリットとスクリーンの距離 L は、スリットの間隔 d にくらべて
   * けた違いに長い（d = 0.2 mm・L = 1 m なら 5000 倍）。そのままの縮尺では
   * 描けないので、途中を波形の線で省いて描いていることを示す。
   */
  function breakMark(ctx, y0, y1) {
    var x = L.BREAK_X, w = BREAK_W;
    ctx.save();
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(x, y0, w, y1 - y0);
    ctx.strokeStyle = '#8f979e'; ctx.lineWidth = 1.6;
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    for (var k = 0; k < 2; k++) {
      var bx = x + (k === 0 ? 3 : w - 3);
      ctx.beginPath();
      for (var y = y0; y <= y1; y += 3) {
        var xx = bx + Math.sin((y - y0) / 14) * 5;
        if (y === y0) ctx.moveTo(xx, y); else ctx.lineTo(xx, y);
      }
      ctx.stroke();
    }
    ctx.restore();
  }

  /** スクリーン（縦の板） */
  function screenBar(ctx) {
    var x = L.SX, y0 = L.CY - L.SH, y1 = L.CY + L.SH, w = L.SCR_W;
    ctx.save();
    ctx.fillStyle = COL.screen;
    ctx.fillRect(x - 4, y0 - 4, w + 8, y1 - y0 + 8);
    // 明線がはっきり見えるよう、スクリーンの面は暗くしておく
    ctx.fillStyle = '#1d1f22';
    ctx.fillRect(x, y0, w, y1 - y0);
    ctx.strokeStyle = COL.screenEdge; ctx.lineWidth = 1.2;
    ctx.strokeRect(x - 4, y0 - 4, w + 8, y1 - y0 + 8);
    ctx.font = font(12, true);
    ctx.fillStyle = '#7a6a48';
    ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
    ctx.fillText('スクリーン', x + w / 2, y0 - 14);
    ctx.restore();
    // スクリーンの大きさの概算は図の中には描かない（図の下の欄外の注記に書く）
  }

  /** スクリーンのすぐ左に mm の目盛りを打つ。skipY のそば・skipRange [y0,y1] の中は数字を出さない */
  function screenRuler(ctx, sc, skipY, skipRange) {
    var stepM = niceStep(sc.halfM);
    ctx.save();
    ctx.strokeStyle = '#b3a88c'; ctx.lineWidth = 1;
    ctx.font = font(11);
    ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    for (var k = -30; k <= 30; k++) {
      var xm = k * stepM;
      if (Math.abs(xm) > sc.halfM + 1e-9) continue;
      var y = L.CY - xm * sc.ppm;
      ctx.beginPath();
      ctx.moveTo(L.SX - 7, y); ctx.lineTo(L.SX - 1, y);
      ctx.stroke();
      var inRange = skipRange && y > skipRange[0] && y < skipRange[1];
      if (k !== 0 && !inRange && (skipY === undefined || skipY === null || Math.abs(y - skipY) > 22)) {
        var t = fmtMm(Math.abs(xm));
        var w = ctx.measureText(t).width;
        ctx.fillStyle = 'rgba(255,255,255,0.86)';
        ctx.fillRect(L.SX - 10 - w, y - 7, w + 3, 14);
        ctx.fillStyle = '#6f6754';
        ctx.fillText(t, L.SX - 9, y);
      }
    }
    ctx.restore();
  }
  function niceStep(halfM) {
    var raw = halfM / 5;
    var cands = [0.001, 0.002, 0.005, 0.01, 0.02, 0.05];
    for (var i = 0; i < cands.length; i++) if (cands[i] >= raw) return cands[i];
    return 0.05;
  }
  function fmtMm(m) {
    var mm = m * 1000;
    return (mm >= 10 ? Math.round(mm) : Math.round(mm * 10) / 10) + ' mm';
  }

  /* ---------- 数値の書き方 ---------- */
  /** 小数 1 桁。丸めで値が動くときだけ「約」を付ける */
  function about(v) {
    var r = Math.round(v * 10) / 10;
    return (Math.abs(v - r) < 0.005 ? '' : '約 ') + r.toFixed(1);
  }
  /** 長さ [m] を読みやすい単位で */
  function fmtLenM(m) {
    var a = Math.abs(m);
    if (a < 0.01) return (m * 1000).toFixed(2) + ' mm';
    if (a < 1) return (m * 100).toFixed(2) + ' cm';
    return m.toFixed(2) + ' m';
  }
  /** スリットの間隔 d [nm] を mm で */
  function fmtD(d) { return (d / 1e6).toFixed(2) + ' mm'; }
  /** 薄膜の厚さ t [nm] を μm で */
  function fmtT(t) { return (t / 1000).toFixed(1) + ' μm'; }

  /* ================= 経路差をまっすぐ伸ばして見せる帯 =================
   * 上の図でハイライトしている経路差を、1 本の直線に伸ばし、
   * その上に波長 λ の波を並べる。波の個数がそのまま「経路差は λ の何倍か」。
   * 波は飾りではなく、図の中の波とまったく同じ関数 P.waveAt() から描く。
   *
   * 「まっすぐ伸ばした帯」と「図の中の光線」は、どちらも
   *   位置 [px] → 光路 s [nm] → P.waveAt(s, t, λ)
   * という同じ道すじで描く。ものさし（nm/px）が違うだけで、
   * 同じ s に対する変位は完全に一致する（テストで確かめる）。
   */
  function bandGeometry(sol) {
    var count = Math.abs(sol.ratio);
    var lx = 48, rightPad = 210;
    var avail = L.W - 16 - rightPad - lx;
    var n = Math.max(count, 0.30);
    var unit = Math.min(420, avail / n);       // 波 1 個ぶんの px
    return { lx: lx, cy: L.BAND_Y + 8 + 54, unit: unit, count: count, lenPx: unit * count };
  }
  /** 帯の左端から px 進んだ位置の光路 s [nm]（テストでも使う） */
  function bandPathAt(sol, px) {
    var g = bandGeometry(sol);
    var nmPerPx = (g.lenPx > 1e-9) ? (Math.abs(sol.delta) / g.lenPx) : 0;
    return px * nmPerPx;
  }

  function unwrapBand(ctx, st, sol, glow) {
    var y0 = L.BAND_Y + 8, h = L.H - y0 - 8;
    var g = bandGeometry(sol);
    var count = g.count, lx = g.lx, cy = g.cy, unit = g.unit, lenPx = g.lenPx;

    ctx.save();
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, L.BAND_Y - 8, L.W, L.H - (L.BAND_Y - 8));

    roundRect(ctx, 10, y0, L.W - 20, h, 10);
    ctx.fillStyle = '#ffffff'; ctx.fill();
    ctx.strokeStyle = COL.geo; ctx.lineWidth = 1.6;
    ctx.setLineDash([7, 5]); ctx.stroke(); ctx.setLineDash([]);

    var chip = '↑ の図の、S₁ を通った光と S₂ を通った光の経路差（緑の部分）だけを取り出して、まっすぐ伸ばすと';
    ctx.font = font(11.5, true);
    var cw = ctx.measureText(chip).width + 34;
    roundRect(ctx, 24, y0 - 11, cw, 22, 11);
    ctx.fillStyle = COL.geo; ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(chip, 41, y0 + 1);

    // 経路差そのもの（緑の太線）
    ctx.lineCap = 'round';
    ctx.globalAlpha = 0.72;
    ctx.strokeStyle = COL.geo; ctx.lineWidth = 7;
    ctx.beginPath(); ctx.moveTo(lx, cy); ctx.lineTo(lx + lenPx, cy); ctx.stroke();
    ctx.globalAlpha = 1;
    if (glow > 0.01) glowLine(ctx, vec(lx, cy), vec(lx + lenPx, cy), COL.geo, glow);

    // 波（図の中の波と同じ式）。位置 [px] → 光路 s [nm] → P.waveAt()
    var t = st.t || 0;
    ctx.strokeStyle = COL.ray; ctx.lineWidth = 2;
    ctx.lineJoin = 'round';
    ctx.beginPath();
    var steps = 320;
    for (var i = 0; i <= steps; i++) {
      var px = lenPx * i / steps;
      var s = bandPathAt(sol, px);
      var yy = cy - L.AMP * P.waveAt(s, t, st.lambda);
      if (i === 0) ctx.moveTo(lx + px, yy); else ctx.lineTo(lx + px, yy);
    }
    ctx.stroke();

    // 端のしるし
    ctx.strokeStyle = '#0b5c34'; ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(lx, cy - 22); ctx.lineTo(lx, cy + 22);
    ctx.moveTo(lx + lenPx, cy - 22); ctx.lineTo(lx + lenPx, cy + 22);
    ctx.stroke();

    // λ 1 個ぶんの目盛り
    if (unit > 26 && count >= 0.5) {
      ctx.strokeStyle = 'rgba(11,92,52,0.45)'; ctx.lineWidth = 1;
      ctx.setLineDash([3, 3]);
      for (var k = 1; k < count - 1e-6; k++) {
        ctx.beginPath();
        ctx.moveTo(lx + unit * k, cy - 18); ctx.lineTo(lx + unit * k, cy + 18);
        ctx.stroke();
      }
      ctx.setLineDash([]);
      dimLine(ctx, vec(lx, cy + 32), vec(lx + unit, cy + 32), 'λ', '#0b5c34', 12);
    }

    // 判定
    var right = L.W - 210 + 10;
    ctx.font = font(13, true);
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#0b5c34';
    ctx.fillText('経路差 ＝ ' + about(count) + ' λ', right, cy - 14);
    var col = sol.kind === 'strong' ? '#1b6b34' : (sol.kind === 'weak' ? '#a12a1c' : '#8a6d00');
    var bg = sol.kind === 'strong' ? '#e9f6ee' : (sol.kind === 'weak' ? '#fdeeec' : '#fff8e6');
    var txt = sol.kind === 'strong' ? '→ 強めあう（明線）' : (sol.kind === 'weak' ? '→ 弱めあう（暗い）' : '→ 完全には強めあわない');
    var tw = ctx.measureText(txt).width;
    roundRect(ctx, right - 6, cy + 2, tw + 16, 24, 8);
    ctx.fillStyle = bg; ctx.fill();
    ctx.strokeStyle = col; ctx.lineWidth = 1.4; ctx.stroke();
    ctx.fillStyle = col;
    ctx.fillText(txt, right + 2, cy + 15);

    ctx.font = font(11.5);
    ctx.fillStyle = '#5b6672';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText('波が ' + about(count) + ' 個ぶんずれている。整数個ならぴったり重なって明るく、'
      + '半整数個なら山と谷が出あって暗くなる。', lx, cy + 48);
    ctx.restore();
  }

  /* ================= 全体図の光線に沿った波 =================
   * from → to の線分の上に、見かけの波長 dispLamPx の波を描く。
   *   opt.phase0   … 始点での位相 [rad]
   *   opt.extraLam … 終点までに、まっすぐ進むぶんに加えて何波長ぶん余計に進むか
   *                  （線分に沿って一様に配分する。S₂→P に経路差÷λ を渡す）
   *   opt.film     … {e0, e1, extraPx}：線分上の e0〜e1 px のあいだに薄膜があり、
   *                  そこを通るあいだに extraPx px ぶんだけ光路が余計に長くなる
   *                  （＝ 膜の中で波長が縮んで見える）
   * 終点での位相を返す（次の線分の phase0 に渡してつなげる）。
   */
  function beamWave(ctx, st, from, to, opt) {
    opt = opt || {};
    var dx = to.x - from.x, dy = to.y - from.y;
    var Lp = Math.hypot(dx, dy);
    var lam = dispLamPx(st);
    var wt = 2 * Math.PI * (P.V_NM_PER_S / st.lambda) * (st.t || 0);
    var phase0 = opt.phase0 || 0;
    if (Lp < 2) return phase0;
    var ux = dx / Lp, uy = dy / Lp, nx = -uy, ny = ux;
    var extraLam = opt.extraLam || 0;
    var film = opt.film || null;
    function optLen(e) {                       // 光路（見かけ）[px]
      var s = e + extraLam * lam * e / Lp;
      if (film) {
        var f = P.clamp((e - film.e0) / Math.max(1e-6, film.e1 - film.e0), 0, 1);
        s += film.extraPx * f;
      }
      return s;
    }
    var steps = Math.max(40, Math.round(Lp / 1.5));
    ctx.save();
    ctx.strokeStyle = opt.color || COL.ray; ctx.lineWidth = opt.width || 1.4;
    ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    if (opt.alpha !== undefined) ctx.globalAlpha = opt.alpha;
    ctx.beginPath();
    var pen = false;
    for (var i = 0; i <= steps; i++) {
      var e = Lp * i / steps;
      var ph = phase0 + 2 * Math.PI * optLen(e) / lam - wt;
      var u = Math.sin(ph) * (opt.amp || DISP_AMP);
      var x = from.x + ux * e + nx * u;
      var y = from.y + uy * e + ny * u;
      // 省略記号の区間は「途中を省いている」ので、波を描かない（ペンを上げる）
      if (inGap(from.x + ux * e)) { pen = false; continue; }
      if (!pen) { ctx.moveTo(x, y); pen = true; } else ctx.lineTo(x, y);
    }
    ctx.stroke();
    ctx.restore();
    return phase0 + 2 * Math.PI * optLen(Lp) / lam;
  }

  /**
   * 左の「S₁・S₂ のまわりの拡大図」が、右の全体図のどこを拡大したものかを、
   * 点線の赤丸 2 つと赤い矢印で示す（回折格子ページと同じ見せ方）。
   */
  function zoomLinkCallout(ctx, sc) {
    var rx = L.GX, ry = L.CY, rr = 58;                 // 右：ダブルスリット
    var lx = L.LX, ly = L.LCY, lr = 88;                // 左：拡大図の板
    ctx.save();
    ctx.strokeStyle = '#d0342c'; ctx.lineWidth = 1.6;
    ctx.setLineDash([5, 4]);
    ctx.beginPath(); ctx.arc(rx, ry, rr, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath(); ctx.arc(lx, ly, lr, 0, Math.PI * 2); ctx.stroke();
    ctx.setLineDash([]);
    // 矢印：右の丸の上端 → 上の空いているところを通って → 左の丸の上端
    var a0 = vec(rx - rr * 0.3, ry - rr * 0.95);
    var a1 = vec(lx + lr * 0.5, ly - lr * 0.88);
    var c0 = vec(rx - 90, 30), c1 = vec(lx + 110, 30);
    ctx.strokeStyle = '#d0342c'; ctx.lineWidth = 3; ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(a0.x, a0.y);
    ctx.bezierCurveTo(c0.x, c0.y, c1.x, c1.y, a1.x, a1.y);
    ctx.stroke();
    var hd = unit(sub(a1, c1)), hn = nrmOf(hd);
    ctx.fillStyle = '#d0342c';
    ctx.beginPath();
    ctx.moveTo(a1.x + hd.x * 11, a1.y + hd.y * 11);
    ctx.lineTo(a1.x + hn.x * 8, a1.y + hn.y * 8);
    ctx.lineTo(a1.x - hn.x * 8, a1.y - hn.y * 8);
    ctx.closePath(); ctx.fill();
    // ラベル（矢印のすぐ下）
    ctx.font = font(11.5, true);
    var t = '← 左の図は、この 2 本を拡大したもの';
    var w = ctx.measureText(t).width;
    var tx = (rx + lx) / 2 + 110, ty = 62;
    roundRect(ctx, tx - w / 2 - 8, ty - 11, w + 16, 22, 6);
    ctx.fillStyle = '#fdeeec'; ctx.fill();
    ctx.strokeStyle = '#d0342c'; ctx.lineWidth = 1.3; ctx.stroke();
    ctx.fillStyle = '#a12a1c';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(t, tx, ty + 1);
    ctx.restore();
  }

  /* ================= 光線に沿った波 ================= */
  /**
   * スリット S から向き u へ、長さ lenPx の光線を引き、その上に波を描く。
   * 位置 [px] → 光路 s [nm] → P.waveAt(s, t, λ) の順で必ず計算する。
   *   s0     … その光線がスリットを出るまでに進んでいる光路 [nm]（ふつう 0）
   *   nmPerPx… 拡大図のものさし [nm/px]
   */
  function rayWave(ctx, S, u, lenPx, opt) {
    var nmPerPx = opt.nmPerPx, lambda = opt.lambda, t = opt.t || 0;
    var amp = opt.amp || L.AMP, s0 = opt.s0 || 0;
    var n = nrmOf(u);
    ctx.save();
    ctx.strokeStyle = opt.color || COL.ray;
    ctx.lineWidth = opt.width || 2;
    ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    if (opt.alpha !== undefined) ctx.globalAlpha = opt.alpha;
    ctx.beginPath();
    var steps = Math.max(24, Math.round(lenPx / 2));
    for (var i = 0; i <= steps; i++) {
      var px = lenPx * i / steps;
      var s = s0 + px * nmPerPx;
      var w = P.waveAt(s, t, lambda) * amp;
      var x = S.x + u.x * px + n.x * w;
      var y = S.y + u.y * px + n.y * w;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.stroke();
    ctx.restore();
  }

  return {
    L: L, COL: COL,
    font: font, FONT: FONT, GAP: GAP, inGap: inGap, lineSkipGap: lineSkipGap,
    vec: vec, add: add, sub: sub, mul: mul, dot: dot, len: len, nrmOf: nrmOf, unit: unit,
    texImage: texImage, drawTex: drawTex,
    shade: shade, setLightColor: setLightColor, pureColor: pureColor,
    lamPxOf: lamPxOf, exaggerationOf: exaggerationOf, dispLamPx: dispLamPx, DISP_AMP: DISP_AMP,
    buildScene: buildScene, beamWave: beamWave, zoomLinkCallout: zoomLinkCallout,
    roundRect: roundRect, line: line, dashLine: dashLine, arrow: arrow, dimLine: dimLine,
    calloutAt: calloutAt, stepHeading: stepHeading,
    eye: eye, pointLabel: pointLabel,
    rightAngle: rightAngle, angleArc: angleArc,
    resetButtons: resetButtons, canvasButton: canvasButton, addHit: addHit, hitButton: hitButton,
    buttons: function () { return uiButtons.slice(); },
    pulseAmount: pulseAmount, boxGlow: boxGlow, glowLine: glowLine,
    lightBulb: lightBulb, waveChip: waveChip, lightText: lightText,
    panels: panels, slitPlate: slitPlate,
    screenBar: screenBar, screenRuler: screenRuler, breakMark: breakMark,
    about: about, fmtLenM: fmtLenM, fmtD: fmtD, fmtT: fmtT, fmtMm: fmtMm,
    bandGeometry: bandGeometry, bandPathAt: bandPathAt, unwrapBand: unwrapBand,
    rayWave: rayWave
  };
})();
