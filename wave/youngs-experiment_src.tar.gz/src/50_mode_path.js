/* ===== 50_mode_path.js ===== */
/* モード①「光路差の位置と式の原理」（②はこの図がそのまま動く）
 *   1. d ≪ L なので平行光線とみなせる
 *   2. 経路差 ＝ d sinθ（S₁ から S₂P に下ろした垂線の足 H）
 *   3. 明線の条件 d sinθ ＝ mλ
 *   4. スクリーン上の位置 x_m ≒ mλL/d
 *
 * 図の部品（光源→S₀→S₁S₂→スクリーンの全体図、光線の上の波、点 P の拡大図、
 * 左の拡大図）は ③ と補足モードからも使う。
 *
 * 位相のつなぎ方（全体図）
 *   Q→S₀→S₁ の光路の終わり（S₁）で位相 0、S₂ も同じく 0（S₀S₁ ＝ S₀S₂）。
 *   薄膜があるときは S₂ だけ 2π(n′−1)t/λ 遅れる。
 *   S₂→P には「経路差÷λ」ぶんの波を余計に入れるので、点 P での 2 本の位相差は
 *   厳密に 2πΔ/λ になる（全体図は横を縮めて描いているため、線分の長さそのものは
 *   本当の光路ではない。だから位相は線分の長さではなく、この差で決める）。
 *
 * 吹き出しは「決め打ちの座標」に置く（干渉シミュレーションの作法 1）。
 */
window.YG = window.YG || {};
YG.modePath = (function () {
  'use strict';
  var P = YG.phys, D = YG.draw;
  var L = D.L, COL = D.COL;
  var vec = D.vec, add = D.add, sub = D.sub, mul = D.mul, unit = D.unit;

  /* 吹き出しの決め打ち位置 */
  var BOX_MID = { x: 372, y: 96 };     // 全体図の左上（赤い矢印のラベルの下）
  var BOX_TOP = { x: 640, y: 22 };     // 全体図の右上（P が上側のとき。拡大円は右下）
  var BOX_LOW = { x: 372, y: 22 };     // 全体図の左上（P が下側のとき。拡大円は右上）

  var STEP_TITLES = [
    '① 2 本の光は平行とみなせる',
    '② 経路差 ＝ d sinθ',
    '③ 明線の条件　d·x/L ＝ mλ（θ が小さい）',
    '④ 明線の位置　x ≒ mλL/d'
  ];
  function stepTitle(step) { return STEP_TITLES[P.clamp(step, 1, 4) - 1]; }

  /** 「⚡ 経路差を強調」で光る量（ステップ 2 のあいだは押さなくても定期的に光る） */
  function pathGlow(st) {
    var manual = D.pulseAmount(st.pulse, 'path', st.nowSec);
    if (manual > 0) return manual;
    if (st.mode === 'path' && st.step === 2) {
      var w = (Math.sin(st.nowSec * 2.0) + 1) / 2;
      return 0.30 * w * w;
    }
    return 0;
  }

  /* ================= 左パネル：S₁・S₂ のまわりの拡大図 ================= */
  function drawZoom(ctx, st, sol, sc, step) {
    var S1 = sc.LS1, S2 = sc.LS2, u = sc.u, H = sc.H;
    var near = sc.near, far = sc.far;
    var glow = pathGlow(st);

    ctx.save();

    // スリットの板
    var y0 = L.LCY - L.LD / 2 - 58, y1 = L.LCY + L.LD / 2 + 58;
    D.slitPlate(ctx, L.LX, L.LCY, (y1 - y0) / 2, [
      [S1.y - 5, S1.y + 5], [S2.y - 5, S2.y + 5]
    ], null, null);

    // 入ってくる光（スリットのあるところにだけ描く）
    ctx.save();
    ctx.globalAlpha = 0.85;
    D.arrow(ctx, vec(L.LX - 46, S1.y), vec(1, 0), 34, COL.rayDim, 2, 7);
    D.arrow(ctx, vec(L.LX - 46, S2.y), vec(1, 0), 34, COL.rayDim, 2, 7);
    ctx.restore();
    ctx.font = D.font(10.5);
    ctx.fillStyle = '#8a7a5a';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText('S₀ から', 8, (S1.y + S2.y) / 2);

    // d の寸法線
    D.dimLine(ctx, vec(L.LX - 16, S1.y), vec(L.LX - 16, S2.y), 'd', '#41505d', -14);

    // 2 本の光線（＋波）
    var rayLen = L.RAY;
    var wave = st.showWave !== false;
    [S1, S2].forEach(function (S, i) {
      var col = (i === 0) ? COL.ray : COL.ray2;
      D.line(ctx, S, add(S, mul(u, rayLen)), col, 1.6);
      if (wave) {
        D.rayWave(ctx, S, u, rayLen, {
          nmPerPx: sc.nmPerPx, lambda: st.lambda, t: st.t,
          amp: L.AMP, color: col, width: 2, alpha: 0.95
        });
      }
    });

    if (step >= 2) {
      // 垂線（近いスリット → 遠いほうの光線）と、経路差（緑）
      D.dashLine(ctx, near, H, '#5f6b76', [5, 4], 1.3);
      D.glowLine(ctx, far, H, COL.geo, glow);
      D.line(ctx, far, H, COL.geo, 6);
      D.rightAngle(ctx, H, mul(u, -1), unit(sub(near, H)), 9, '#5f6b76');

      // 経路差のラベル（線が短いときは引き出し線をつけて外に出す）
      if (sc.proj > 8) {
        var mid = mul(add(far, H), 0.5);
        var nn = D.nrmOf(u);
        var side = (sc.sinDraw >= 0) ? 1 : -1;
        var lx = mid.x + nn.x * 34 * side, ly = mid.y + nn.y * 34 * side;
        D.line(ctx, mid, vec(lx, ly), '#7fbf9c', 1);
        ctx.font = D.font(12, true);
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        var lab = '経路差 d sinθ';
        var tw = ctx.measureText(lab).width;
        D.roundRect(ctx, lx - tw / 2 - 5, ly - 10, tw + 10, 20, 5);
        ctx.fillStyle = '#f0faf4'; ctx.fill();
        ctx.strokeStyle = '#0f9d58'; ctx.lineWidth = 1.1; ctx.stroke();
        ctx.fillStyle = '#0b5c34';
        ctx.fillText(lab, lx, ly);
      }
    }

    // 三角形 S_near–S_far–H の中の角 θ（＝光線の傾き θ と等しい）
    if (step >= 2 && sc.proj > 6) {
      var aTo = Math.atan2(H.y - near.y, H.x - near.x);
      var aDown = Math.atan2(far.y - near.y, far.x - near.x);
      D.angleArc(ctx, near, Math.min(aTo, aDown), Math.max(aTo, aDown), 34, COL.ang, 'θ');
    }

    // 点の名札
    D.pointLabel(ctx, S1, 'S₁', -20, -10, '#1a3350');
    D.pointLabel(ctx, S2, 'S₂', -20, 12, '#1a3350');
    if (step >= 2) D.pointLabel(ctx, H, 'H', 14, (sc.sinDraw >= 0 ? 12 : -12), '#0b5c34');

    // 見出し（板の下）と、誇張の注記（常時）
    ctx.font = D.font(12, true);
    ctx.fillStyle = '#2b5a78';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText('S₁・S₂ のまわりの拡大図', 12, y1 + 8);
    var K = Math.round(sc.exagg);
    ctx.font = D.font(10.5);
    ctx.fillStyle = '#a3521c';
    ctx.fillText('※ この拡大図では、λ および経路差は d に対して', 10, L.BAND_Y - 40);
    ctx.fillText('　 実際より約 ' + K + ' 倍大きくして描いています。', 10, L.BAND_Y - 25);

    ctx.restore();
  }

  /* ================= 右パネル：光源 → S₀ → ダブルスリット =================
   * opt.film … {e0, e1, extraPx}：S₀→S₂ の線分の上の薄膜（補足モード）
   * opt.filmDraw … 薄膜そのものを描く関数（補足モードが渡す）
   * 返り値：S₁・S₂ を出るときの位相 {phS1, phS2}
   */
  function incoming(ctx, st, sol, sc, opt) {
    opt = opt || {};
    var S1 = sc.S1, S2 = sc.S2;
    var white = (st.light === 'white');
    var lam = D.dispLamPx(st);
    ctx.save();

    // 光源 Q
    D.lightBulb(ctx, vec(L.SRC_X, L.CY), { scale: 1, white: white });
    ctx.font = D.font(12, true);
    ctx.fillStyle = '#7a5a10';
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText('光源 Q', L.SRC_X, L.CY + 26);
    // 光の名札は、S₀ の板の下（板の名札は板の上に出す）。左パネルにはみ出さない
    D.waveChip(ctx, L.SRC_X + 40, L.CY + 74, D.lightText(st),
      white ? '#ffffff' : P.rgbCss(P.wavelengthToRGB(st.lambda0 || st.lambda)));

    // Q → S₀（波）。S₁ で位相が 0 になるよう、さかのぼって始点の位相を決める
    var q0 = vec(L.SRC_X + 24, L.CY), s0 = vec(L.S0X - 5, L.CY);
    var s0b = vec(L.S0X + 5, L.CY);
    var L01 = D.len(sub(S1, s0b));
    var Lq = D.len(sub(s0, q0));
    var phQ = -2 * Math.PI * (Lq + L01) / lam;
    ctx.save(); ctx.globalAlpha = 0.28; D.line(ctx, q0, s0, COL.ray, 1); ctx.restore();
    var ph0 = D.beamWave(ctx, st, q0, s0, { phase0: phQ, color: COL.ray, width: 1.4 });

    // S₀ の板（シングルスリット）。S₀ の名札は穴のすぐそば（S₁・S₂ と同じ流儀）
    D.slitPlate(ctx, L.S0X, L.CY, L.S0_PLATE_H / 2, [[L.CY - 5, L.CY + 5]], 'シングルスリット', null, true);
    D.pointLabel(ctx, vec(L.S0X, L.CY), 'S₀', -20, -12, '#1a3350');

    // S₀ → S₁・S₂（回折して広がる。波で描く）
    ctx.save(); ctx.globalAlpha = 0.25;
    D.line(ctx, s0b, S1, COL.ray, 1); D.line(ctx, s0b, S2, COL.ray2, 1);
    ctx.restore();
    var phS1 = D.beamWave(ctx, st, s0b, S1, { phase0: ph0, color: COL.ray, width: 1.4 });
    var phS2 = D.beamWave(ctx, st, s0b, S2, { phase0: ph0, color: COL.ray2, width: 1.4, film: opt.film || null });
    ctx.font = D.font(10.5);
    ctx.fillStyle = '#8a7a5a';
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText('回折して広がる', (L.S0X + L.GX) / 2 + 26, L.CY - L.SLIT_SP / 2 - 34);

    if (opt.filmDraw) opt.filmDraw(ctx);

    // ダブルスリットの板
    // ダブルスリットの名札は板の上（シングルスリットと同じ並び）。d の文字は両矢印の右
    D.slitPlate(ctx, L.GX, L.CY, L.PLATE_H / 2, [
      [S1.y - 4, S1.y + 4], [S2.y - 4, S2.y + 4]
    ], 'ダブルスリット', null, true);
    D.pointLabel(ctx, S1, 'S₁', -22, -8, '#1a3350');
    D.pointLabel(ctx, S2, 'S₂', -22, 10, '#1a3350');
    D.dimLine(ctx, vec(L.GX + 16, S1.y), vec(L.GX + 16, S2.y), 'd', '#41505d', -14);
    if (opt.dNote !== false) {
      ctx.font = D.font(10);
      ctx.fillStyle = '#8a939c';
      ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      ctx.fillText('（実際の d ＝ ' + D.fmtD(st.d) + '。図では見やすく広げています）',
        L.GX, L.CY + L.PLATE_H / 2 + 38);
    }
    ctx.restore();
    return { phS1: phS1, phS2: phS2 };
  }

  /**
   * S₁→P・S₂→P の光線（波つき）。
   * 点 P での位相差が厳密に 2πΔ/λ になるように、S₂→P に余計な波を配分する。
   * 2 本の線分の見かけの長さのちがい（図は横を縮めて描いている）は差し引く。
   */
  function rays(ctx, st, sol, sc, ph) {
    var S1 = sc.S1, S2 = sc.S2, Pp = sc.P;
    var lam = D.dispLamPx(st);
    var geoRatio = st.d * Math.sin(sol.theta) / st.lambda;
    var Lp1 = D.len(sub(Pp, S1)), Lp2 = D.len(sub(Pp, S2));
    var extra2 = geoRatio - (Lp2 - Lp1) / lam;
    ctx.save();
    ctx.globalAlpha = 0.25;
    D.lineSkipGap(ctx, S1, Pp, COL.ray, 1);
    D.lineSkipGap(ctx, S2, Pp, COL.ray2, 1);
    ctx.restore();
    D.beamWave(ctx, st, S1, Pp, { phase0: ph.phS1, color: COL.ray, width: 1.5 });
    D.beamWave(ctx, st, S2, Pp, { phase0: ph.phS2, extraLam: extra2, color: COL.ray2, width: 1.5 });
  }

  /** l₁・l₂ のラベル（省略記号の左に置く） */
  function rayLabels(ctx, sc) {
    var Pp = sc.P;
    function one(S, txt, col, dy) {
      var k = (L.BREAK_X - 78 - S.x) / (Pp.x - S.x);
      var lx = S.x + (Pp.x - S.x) * k, ly = S.y + (Pp.y - S.y) * k;
      ctx.save();
      ctx.font = D.font(12.5, true);
      var w = ctx.measureText(txt).width;
      ctx.fillStyle = 'rgba(255,255,255,0.88)';
      ctx.fillRect(lx - w / 2 - 3, ly + dy - 9, w + 6, 18);
      ctx.fillStyle = col;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(txt, lx, ly + dy);
      ctx.restore();
    }
    one(sc.S1, 'l₁', COL.ray, -13);
    one(sc.S2, 'l₂', COL.ray2, 13);
  }

  /** 光軸・省略記号・スクリーン・目盛り・L の寸法線 */
  function stage(ctx, st, sol, sc, opt) {
    opt = opt || {};
    ctx.save();
    D.dashLine(ctx, vec(L.GX, L.CY), vec(L.SX, L.CY), '#a9b2ba', [6, 5], 1.1);
    D.breakMark(ctx, L.CY - L.SH - 6, L.CY + L.SH + 6);
    ctx.font = D.font(10.5);
    ctx.fillStyle = '#8f979e';
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText('けた違いに長いので途中を省略', L.BREAK_X + 13, L.CY + L.SH + 16);
    D.screenBar(ctx);
    drawFringes(ctx, st, sol, sc, opt.labels !== false, { dim: !!opt.dimLabels, skipZero: !!opt.skipZero });
    D.screenRuler(ctx, sc, sc.P.y, opt.skipRange || null);
    var ly = L.CY + L.SH + 50;
    D.dimLine(ctx, vec(L.GX, ly), vec(L.SX, ly), 'L ＝ ' + st.L.toFixed(2) + ' m', '#6b7580', 16);
    ctx.restore();
  }

  /** 角 θ（中点 M から）と、横を縮めたぶんの注記 */
  function thetaMark(ctx, st, sol, sc, withNote) {
    var M = vec(L.GX, L.CY), Pp = sc.P;
    var aP = Math.atan2(Pp.y - M.y, Pp.x - M.x);
    D.angleArc(ctx, M, Math.min(0, aP), Math.max(0, aP), 168, COL.ang, 'θ');
    if (withNote === false) return;
    var kAng = sc.ppm / ((L.SX - L.GX) / st.L);
    ctx.save();
    ctx.font = D.font(10.5);
    ctx.fillStyle = '#7c85b8';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText('※ この図の θ は、横を縮めて描いているため', L.DIV + 26, L.CY + L.SH + 8);
    ctx.fillText('　 実際の約 ' + Math.round(kAng) + ' 倍に見えています（実際は '
      + sol.thetaDeg.toFixed(3) + '°）', L.DIV + 26, L.CY + L.SH + 23);
    ctx.restore();
  }

  /** x の寸法線（ステップ④）。スクリーンの左に置く（右は m の名札と目でいっぱい） */
  function xDim(ctx, sol, sc) {
    var Pp = sc.P;
    if (Math.abs(Pp.y - L.CY) <= 14) return;
    var dx = L.SX - 24;
    D.dimLine(ctx, vec(dx, L.CY), vec(dx, Pp.y), null, '#8a3b00');
    D.dashLine(ctx, vec(dx, L.CY), vec(L.SX, L.CY), '#c9a98c', [4, 4], 1);
    D.dashLine(ctx, vec(dx, Pp.y), vec(L.SX, Pp.y), '#c9a98c', [4, 4], 1);
    var tx = 'x ＝ ' + D.fmtLenM(sol.x);
    ctx.save();
    ctx.font = D.font(12.5, true);
    var tw = ctx.measureText(tx).width;
    var ty = (L.CY + Pp.y) / 2;
    D.roundRect(ctx, dx - 12 - tw - 10, ty - 10, tw + 10, 20, 5);
    ctx.fillStyle = 'rgba(255,255,255,0.94)'; ctx.fill();
    ctx.strokeStyle = '#e0c0a4'; ctx.lineWidth = 1; ctx.stroke();
    ctx.fillStyle = '#8a3b00';
    ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    ctx.fillText(tx, dx - 17, ty + 1);
    ctx.restore();
  }

  /** 観測者の目：m の名札のすぐ右に置き、スリット → P の向きに合わせて傾ける */
  function observer(ctx, st, sol, sc) {
    var Pp = sc.P;
    var dir = unit(sub(Pp, vec(L.GX, L.CY)));          // M → P の向き（横を縮めた図の上での向き）
    // 目は P と同じ高さに置く（m の名札の列のすぐ右）。向きは傾きだけで示す
    var p = vec(L.SX + L.SCR_W + 90, P.clamp(Pp.y, 30, L.BAND_Y - 40));
    var tag;
    if (sol.sel && sol.sel.dark) tag = 'm ＝ ' + sol.sel.m + ' の暗線';
    else if (sol.kind === 'strong') tag = 'm ＝ ' + sol.m + ' の明線';
    else tag = 'いま見ている位置';
    // 名札は、m の名札（明線の位置に並ぶ）とぶつからない高さに置く：
    // 明線どうしの間隔の半分だけずらせば、名札の列のすきまに入る。
    // 暗線を見ているとき（P がすきまにいる）は、間隔ぶんずらして次のすきまへ。
    var gap = sol.dxApprox * sc.ppm;
    var dy = 30;
    if (gap >= 30) dy = (sol.sel && sol.sel.dark) ? gap : gap / 2;
    // 名札は目より少し右に寄せて、暗線の名札の列（x 〜1180）と重ねない
    D.eye(ctx, p, mul(dir, -1), 0.58, tag, Pp.y > L.CY, dy, 36);
  }

  /** スクリーン上の明線。withLabels ＝ false なら m の名札を出さない。
   *  opt.dim … 名札を薄く（補足モード：m ＝ 0 が主役なので控えめに）、opt.skipZero … m ＝ 0 の名札は出さない */
  function drawFringes(ctx, st, sol, sc, withLabels, opt) {
    opt = opt || {};
    var x = L.SX, w = L.SCR_W;
    ctx.save();
    if (st.light === 'white') {
      for (var yy = L.CY - L.SH; yy <= L.CY + L.SH; yy += 1) {
        var xm = (L.CY - yy) / sc.ppm;
        var c = P.spectrumColorAtX(xm, st.d, st.L, sol.extra, 1, sol.nMed);
        ctx.fillStyle = P.rgbCss(c);
        ctx.fillRect(x, yy, w, 1.2);
      }
    } else {
      var rgb = P.wavelengthToRGB(st.lambda0 || st.lambda);   // 色は空気中の波長で決まる
      for (var y2 = L.CY - L.SH; y2 <= L.CY + L.SH; y2 += 1) {
        var xm2 = (L.CY - y2) / sc.ppm;
        var th = Math.asin(P.clamp(P.sinThetaFromX(xm2, st.L), -1, 1));
        var I = P.intensity2(th, st.d, st.lambda, sol.extra);
        ctx.fillStyle = P.rgbCss(rgb, Math.pow(I, 0.8));
        ctx.fillRect(x, y2, w, 1.2);
      }
    }
    if (withLabels === false) { ctx.restore(); return; }
    if (opt.dim) ctx.globalAlpha = 0.55;
    // 明線の名札（m の値）。混みすぎるときは間引く
    var orders = sol.orders;
    var minGap = 20;
    var lastY = null;
    ctx.font = D.font(11, true);
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    for (var i = 0; i < orders.length; i++) {
      var oy = L.CY - orders[i].x * sc.ppm;
      if (oy < L.CY - L.SH - 1 || oy > L.CY + L.SH + 1) continue;
      if (lastY !== null && Math.abs(oy - lastY) < minGap) continue;
      lastY = oy;
      if (opt.skipZero && orders[i].m === 0) continue;
      var on = (sol.kind === 'strong' && orders[i].m === sol.m);
      var t = 'm=' + orders[i].m;
      var tw = ctx.measureText(t).width;
      D.roundRect(ctx, x + w + 5, oy - 8, tw + 8, 16, 4);
      ctx.fillStyle = on ? '#fff3d6' : 'rgba(255,255,255,0.9)'; ctx.fill();
      ctx.strokeStyle = on ? '#e0a800' : '#cfd6dd'; ctx.lineWidth = on ? 1.6 : 1; ctx.stroke();
      ctx.fillStyle = on ? '#8a5300' : '#41505d';
      ctx.fillText(t, x + w + 9, oy + 1);
      D.addHit(x + w + 5, oy - 9, tw + 10, 18, 'order:' + orders[i].m);
    }
    // 暗線の名札（m ＝ 0.5, 1.5, …）。明線の名札より少し右にずらして、小さく
    var darks = sol.darks;
    ctx.font = D.font(9.5, true);
    for (var k = 0; k < darks.length; k++) {
      var dy = L.CY - darks[k].x * sc.ppm;
      if (dy < L.CY - L.SH - 1 || dy > L.CY + L.SH + 1) continue;
      if (minGap > 0 && sol.dxApprox * sc.ppm < 26) continue;      // 混みすぎるときは出さない
      var onD = !!(sol.sel && sol.sel.dark && Math.abs(sol.sel.m - darks[k].m) < 1e-9);
      var td = 'm=' + darks[k].m;
      var twd = ctx.measureText(td).width;
      D.roundRect(ctx, x + w + 14, dy - 7, twd + 8, 14, 4);
      ctx.fillStyle = onD ? '#3a4550' : 'rgba(236,238,242,0.92)'; ctx.fill();
      ctx.strokeStyle = onD ? '#3a4550' : '#b6bcc4'; ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = onD ? '#ffffff' : '#4a525c';
      ctx.fillText(td, x + w + 18, dy + 1);
      D.addHit(x + w + 14, dy - 8, twd + 10, 16, 'order:' + darks[k].m);
    }
    ctx.restore();
  }

  /* ================= 点 P の拡大図 =================
   * スクリーン上の P を赤い丸で囲み、赤い矢印で大きな円に引き出して、
   * 「そこに届く 2 本の波」を並べて見せる（回折格子ページと同じ見せ方）。
   * 拡大図（左パネル）と同じものさし nmPerPx で描くので、ずれは厳密に経路差ぶん。
   */
  /* ①：円だけ。P と反対側（上なら下、下なら上）の決め打ちの位置。
   * ②（withCard）：合成波のカードを円のすぐ上に積み、1 組で P といっしょに上下する。
   *   カードと円は、光線 S₁→P・S₂→P と重ならない側に置く：
   *     P が上側 … 光線は P より下に来ない → 光線のすぐ下にカード、その下に円
   *     P が下側 … 光線は P より上に来ない → 光線のすぐ上に円、その上にカード
   *   （円の下端は L の寸法線 512 より上、カードの上端は 8 より下に収める） */
  var ZC = { x: 968, r: 90, rSmall: 70, cardW: 214, cardH: 74, gap: 6, cardX0: 846, bottomMax: 511, topMin: 8 };
  function pointZoomCenter(sc, withCard) {
    var above = (sc.P.y <= L.CY);
    if (!withCard) return { c: vec(ZC.x, above ? 372 : 150), r: ZC.r, above: above, compact: false, card: null };
    var r = ZC.rSmall, k = (ZC.cardX0 - L.GX) / (L.SX - L.GX);
    var cy, cardY0;
    if (above) {
      var rayY = sc.S2.y + (sc.P.y - sc.S2.y) * k;      // カードの左端での S₂→P の高さ（いちばん低い所）
      cardY0 = rayY + 10;
      cy = cardY0 + ZC.cardH + ZC.gap + r;
      if (cy + r > ZC.bottomMax) { cy = ZC.bottomMax - r; cardY0 = cy - r - ZC.gap - ZC.cardH; }
    } else {
      var rayY2 = sc.S1.y + (sc.P.y - sc.S1.y) * k;     // カードの左端での S₁→P の高さ（いちばん高い所）
      cy = rayY2 - 10 - r;
      var cyMin = ZC.topMin + ZC.cardH + ZC.gap + r;
      if (cy < cyMin) cy = cyMin;
      cardY0 = cy - r - ZC.gap - ZC.cardH;
    }
    return { c: vec(ZC.x, cy), r: r, above: above, compact: true,
      card: { x0: ZC.cardX0, x1: ZC.cardX0 + ZC.cardW, y0: cardY0, y1: cardY0 + ZC.cardH } };
  }
  function pointZoom(ctx, st, sol, sc, pz) {
    pz = pz || pointZoomCenter(sc);
    var c = pz.c, r = pz.r, above = pz.above, compact = pz.compact;
    var Py = sc.P.y, sx = L.SX + L.SCR_W / 2;
    var strong = (sol.kind === 'strong');

    ctx.save();
    ctx.strokeStyle = '#d0342c'; ctx.lineWidth = 1.6;
    ctx.setLineDash([5, 4]);
    ctx.beginPath(); ctx.arc(sx, Py, 17, 0, Math.PI * 2); ctx.stroke();
    ctx.setLineDash([]);
    var a0 = vec(sx - 18, Py + (above ? 12 : -12));
    var dirTo = unit(sub(a0, c));
    var a1 = add(c, mul(dirTo, r + 10));
    var mid0 = mul(add(a0, a1), 0.5);
    var bulge = mul(D.nrmOf(unit(sub(a1, a0))), above ? 26 : -26);
    ctx.strokeStyle = '#d0342c'; ctx.lineWidth = 5; ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(a0.x, a0.y);
    ctx.quadraticCurveTo(mid0.x + bulge.x, mid0.y + bulge.y, a1.x, a1.y);
    ctx.stroke();
    var hd = unit(sub(a1, vec(mid0.x + bulge.x, mid0.y + bulge.y)));
    var hn = D.nrmOf(hd);
    ctx.fillStyle = '#d0342c';
    ctx.beginPath();
    ctx.moveTo(a1.x + hd.x * 12, a1.y + hd.y * 12);
    ctx.lineTo(a1.x + hn.x * 9, a1.y + hn.y * 9);
    ctx.lineTo(a1.x - hn.x * 9, a1.y - hn.y * 9);
    ctx.closePath(); ctx.fill();
    ctx.restore();

    ctx.save();
    ctx.beginPath(); ctx.arc(c.x, c.y, r, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(255,255,255,0.98)'; ctx.fill();
    ctx.strokeStyle = '#d0342c'; ctx.lineWidth = 1.8;
    ctx.setLineDash([6, 5]); ctx.stroke(); ctx.setLineDash([]);
    ctx.beginPath(); ctx.arc(c.x, c.y, r, 0, Math.PI * 2); ctx.clip();

    var nm = strong ? (compact ? ('強めあう（m=' + sol.m + '）') : ('強めあう（m ＝ ' + sol.m + '）'))
      : (sol.kind === 'weak' ? '弱めあう' : '完全には強めあわない');
    ctx.font = D.font(compact ? 9.5 : 10.5, true);
    ctx.fillStyle = strong ? '#1b6b34' : (sol.kind === 'weak' ? '#a12a1c' : '#8a6d00');
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(nm, c.x, c.y - r + (compact ? 26 : 30));

    // 届く 2 本の波。下の光線（S₂）のほうが経路差 Δ だけ余分に進んでいる
    var u = sc.u, n = D.nrmOf(u);
    var len = compact ? 88 : 112;
    var mid = vec(c.x + (compact ? 4 : -6), c.y - 10);
    var cols = [COL.ray, COL.ray2];
    for (var k = 0; k < 2; k++) {
      var base = add(mid, mul(n, k === 0 ? -16 : 14));
      var from = add(base, mul(u, -len / 2));
      var tip = add(base, mul(u, len / 2));
      D.line(ctx, from, tip, 'rgba(120,120,120,0.35)', 1.2);
      D.rayWave(ctx, from, u, len, {
        nmPerPx: sc.nmPerPx, lambda: st.lambda, t: st.t,
        // 終点（P）で 2 本の位相差が 2πΔ/λ になるよう、S₂ の波は Δ だけ先に進めておく
        s0: (k === 1 ? sol.delta : 0) - len * sc.nmPerPx,
        amp: 6, color: cols[k], width: 1.9
      });
      // 名札は波の左端のさらに左（波と重ならない）
      ctx.font = D.font(10.5, true);
      ctx.fillStyle = cols[k];
      ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
      ctx.fillText(k === 0 ? 'S₁' : 'S₂', from.x - 4, from.y + (k === 0 ? -2 : 2));
    }
    var tm = add(mid, mul(u, len / 2));
    D.dashLine(ctx, add(tm, mul(n, -34)), add(tm, mul(n, 30)), '#2b2118', [5, 4], 1.3);
    D.pointLabel(ctx, tm, 'P', 12, 0, '#3a4550');

    ctx.font = D.font(9);
    ctx.fillStyle = '#5b6672';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(compact ? '※ 上下にずらした図' : '※ 2 本は上下にずらして描いています', c.x, c.y + r - (compact ? 26 : 34));
    ctx.restore();
  }

  /* ================= ステップの吹き出し ================= */
  function drawCallouts(ctx, st, sol, sc, step) {
    var up = (sc.P.y <= L.CY);
    var box = up ? BOX_TOP : BOX_LOW;   // 点 P の拡大円と反対側に置く
    var rect = null;
    if (step === 1) {
      rect = D.calloutAt(ctx, vec(L.GX + 40, L.CY - L.SLIT_SP / 2 - 12), BOX_MID.x, BOX_MID.y, [
        '① スリットの間隔 d（0.2 mm ほど）にくらべて、',
        '　 スクリーンまでの距離 L（1 m ほど）は 5000 倍も長い。',
        '　 だから S₁ と S₂ から点 P へ向かう 2 本の光は、',
        '　 ほとんど平行と考えてよい。'
      ], { bg: '#fff8ef', border: '#e0a24a', fg: '#5b4420' });
    } else if (step === 2) {
      rect = D.calloutAt(ctx, sc.H, BOX_MID.x, BOX_MID.y, [
        '② 近いほうのスリットから、遠いほうの光線に垂線を下ろし、',
        '　 足を H とする。H より先は 2 本とも同じ長さ。',
        '　 だから道のりの差（経路差）は、緑の部分だけ。',
        '　 直角三角形より　経路差 ＝ d sinθ'
      ], { bg: '#eef8f1', border: '#0f9d58', fg: '#14442b' });
    } else if (step === 3) {
      rect = D.calloutAt(ctx, sc.P, box.x, box.y, [
        '③ 経路差が λ の整数倍なら、山と山が重なって明るい：',
        '　 　d sinθ ＝ mλ　（m ＝ 0, ±1, ±2, …）',
        '　 θ はとても小さいので sinθ ≒ tanθ ＝ x / L。代入して',
        '　 　明線：d · x / L ＝ mλ　　暗線：d · x / L ＝ (m + ½)λ'
      ], { bg: '#fff8ef', border: '#e0a24a', fg: '#5b4420' });
    } else if (step === 4) {
      rect = D.calloutAt(ctx, sc.P, box.x, box.y, [
        '④ ③の式を x について解くと',
        '　 　x ≒ mλL / d　（m に比例して等間隔に並ぶ）',
        '　 いま x ＝ ' + D.fmtLenM(sol.x) + '（m ＝ ' + sol.m + ' の位置）'
      ], { bg: '#f2f7fd', border: '#1663b5', fg: '#1a3f68' });
    }
    // 「次へ」で吹き出しが切りかわった直後は、ピコンと光らせて目を引く
    var amt = D.pulseAmount(st.pulse, 'callout', st.nowSec);
    if (rect && amt > 0.01) D.boxGlow(ctx, rect, amt, '#e0a800');
  }

  /* ================= 本体 =================
   * ① と ② は同じ図。②（opt.wave）では
   *   ・波が動く（st.t が進む）
   *   ・スクリーンの右に「光の強度分布」のグラフと、合成波のカードを足す
   *   ・ステップの吹き出しは出さない
   */
  function render(ctx, st, sol, sc, opt) {
    opt = opt || {};
    var wave = !!opt.wave;
    var step = wave ? 4 : P.clamp(st.step, 1, 4);
    var zoomOn = (wave || step >= 2);
    var pz = pointZoomCenter(sc, wave);       // ②は合成波のカードといっしょに動く

    D.panels(ctx);
    if (wave && st.showCirc && YG.modeWave) YG.modeWave.wavelets(ctx, st, sol, sc);
    var ph = incoming(ctx, st, sol, sc, { dNote: !wave });   // ②は合成波カードを置くので d の注記は省く
    // 目盛りの数字を飛ばす範囲：点 P の拡大円と、ステップ④の x の寸法線
    var skip = null;
    if (zoomOn) skip = [pz.card ? Math.min(pz.card.y0, pz.c.y - pz.r) : pz.c.y - pz.r, pz.c.y + pz.r];
    if (!wave && step >= 4) {
      var lo = Math.min(L.CY, sc.P.y) - 12, hi = Math.max(L.CY, sc.P.y) + 12;
      skip = skip ? [Math.min(skip[0], lo), Math.max(skip[1], hi)] : [lo, hi];
    }
    stage(ctx, st, sol, sc, { labels: true, skipRange: skip });
    rays(ctx, st, sol, sc, ph);
    rayLabels(ctx, sc);
    thetaMark(ctx, st, sol, sc, !wave);
    D.pointLabel(ctx, sc.P, 'P', 22, -12, '#8a3b00');
    D.pointLabel(ctx, vec(L.SX, L.CY), 'O', 22, 12, '#41505d');
    if (!wave && step >= 4) xDim(ctx, sol, sc);
    if (!wave) observer(ctx, st, sol, sc);
    if (zoomOn) pointZoom(ctx, st, sol, sc, pz);

    drawZoom(ctx, st, sol, sc, wave ? 2 : step);
    if (wave || step <= 2) D.zoomLinkCallout(ctx, sc);

    if (wave && YG.modeWave) {
      YG.modeWave.intensityGraph(ctx, st, sol, sc);
      YG.modeWave.sumCard(ctx, st, sol, sc, pz);
      YG.modeWave.title(ctx);
    } else {
      var hb = D.stepHeading(ctx, 12, 14, stepTitle(step));
      if (step >= 2) {
        D.canvasButton(ctx, 12, hb.y + hb.h + 6, '⚡ 経路差を強調', 'glow:path',
          st.hoverBtn === 'glow:path', false);
      }
      if (st.showLabels) drawCallouts(ctx, st, sol, sc, step);
    }
    waveNote(ctx);
  }

  /** 全体図の波についての注記（θ の注記の下） */
  function waveNote(ctx) {
    ctx.save();
    ctx.font = D.font(10);
    ctx.fillStyle = '#8a939c';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText('※ 全体図の波は、波長を見やすく拡大しています', L.DIV + 26, L.CY + L.SH + 35);
    ctx.restore();
  }

  return {
    render: render, pathGlow: pathGlow, stepTitle: stepTitle, STEP_TITLES: STEP_TITLES, waveNote: waveNote,
    drawFringes: drawFringes, incoming: incoming, rays: rays, rayLabels: rayLabels,
    stage: stage, thetaMark: thetaMark, xDim: xDim, pointZoom: pointZoom, pointZoomCenter: pointZoomCenter,
    drawZoom: drawZoom, observer: observer, drawCallouts: drawCallouts
  };
})();
