/* ===== 85_probe.js ===== */
/* 自動テストのための「のぞき窓」。
 * ページの見た目には何も影響しない。物理の値・図の中の値・DOM の文言を
 * JSON にして返すだけ。test/run_test.py がこれを 2 回とって比べる。
 */
window.YG = window.YG || {};
YG.probe = (function () {
  'use strict';
  var P = YG.phys, D = YG.draw;

  function r(v, n) {
    if (v === null || v === undefined || !isFinite(v)) return v;
    var k = Math.pow(10, n === undefined ? 9 : n);
    return Math.round(v * k) / k;
  }
  function txt(id) {
    var e = document.getElementById(id);
    return e ? e.textContent.trim() : null;
  }

  /**
   * 「展開バンドの波」と「図の中の光線の波」が完全に一致するかを確かめる。
   * どちらも  位置[px] → 光路 s[nm] → P.waveAt(s, t, λ)  の順で計算している。
   * ものさし（nm/px）だけが違うので、同じ s に対する変位は完全に一致するはず。
   * 帯の上を等間隔にとり、その s を図の光線上の位置になおして、両方の変位を比べる。
   */
  function waveMatch(v, sol, sc) {
    var g = D.bandGeometry(sol);
    var worst = 0;
    for (var i = 0; i <= 64; i++) {
      var px = g.lenPx * i / 64;
      var s = D.bandPathAt(sol, px);          // 帯の側の光路 [nm]
      var uPx = s / sc.nmPerPx;               // 図の光線上での位置 [px]
      var band = P.waveAt(s, v.t, v.lambda);
      var fig = P.waveAt(uPx * sc.nmPerPx, v.t, v.lambda);
      worst = Math.max(worst, Math.abs(band - fig));
    }
    return worst;
  }

  /** 図に描いた経路差が、ほんとうに「λ の何個ぶんか」と合っているか */
  function drawnRatio(v, sol, sc) {
    // 図に描いた経路差 [px] ＝ LD·sinθ_draw、それを λ の px で割る
    return (D.L.LD * sc.sinDraw) / sc.lamPx;
  }

  function snapshot() {
    var v = YG.ui.view();
    var sol = P.solve(v);
    var sc = D.buildScene(v, sol);
    return {
      in: {
        mode: v.mode, light: v.light,
        lambda: v.lambda, d: v.d, L: r(v.L, 4), halfM: v.halfM,
        step: v.step, fstep: v.fstep, onlyBright: v.onlyBright,
        film: v.film ? { t: v.film.t, n: r(v.film.n, 4), inserted: v.film.inserted, on: v.film.on } : null,
        lambda0: v.lambda0,
        setup: v.setup ? { prog: r(v.setup.prog, 6), paused: v.setup.paused } : null,
        medium: v.medium ? { n: r(v.medium.n, 6), nSet: r(v.medium.nSet, 4), inserted: v.medium.inserted, on: v.medium.on } : null
      },
      phys: {
        thetaDeg: r(sol.thetaDeg, 9),
        delta_nm: r(sol.delta, 6),
        ratio: r(sol.ratio, 9),
        x_mm: r(sol.x * 1000, 9),
        I: r(sol.I, 9),
        kind: sol.kind,
        m: sol.m,
        orders: sol.orders.map(function (o) { return o.m; }),
        darks: sol.darks.map(function (o) { return o.m; }),
        sel: sol.sel ? { m: sol.sel.m, dark: sol.sel.dark } : null,
        x_mm_of_orders: sol.orders.map(function (o) { return r(o.x * 1000, 6); }),
        dxApprox_mm: r(sol.dxApprox * 1000, 9),
        dxMeasured_mm: r(sol.dxMeasured * 1000, 9),
        extra_nm: r(sol.extra, 6),
        x0_mm: r(sol.x0 * 1000, 9),
        x0Approx_mm: r(sol.x0Approx * 1000, 9),
        dxAir_mm: r(sol.dxAir * 1000, 9),
        nMed: r(sol.nMed, 6)
      },
      fig: {
        lamPx: r(sc.lamPx, 6),
        exagg: r(sc.exagg, 6),
        sinDraw: r(sc.sinDraw, 9),
        projPx: r(sc.proj, 6),
        drawnRatio: r(drawnRatio(v, sol, sc), 9),
        ppm: r(sc.ppm, 6),
        waveMatchWorst: r(waveMatch(v, sol, sc), 12)
      },
      dom: {
        theta: txt('r-theta'), delta: txt('r-delta'), ratio: txt('r-ratio'),
        x: txt('r-x'), dx: txt('r-dx'), I: txt('r-I'),
        verdict: txt('verdict'), screenNote: txt('screen-note'),
        snTitle: txt('sn-title'), stepLabel: txt('step-label'),
        vExtra: txt('v-extra'), vX0: txt('v-x0'),
        dxMeas: txt('v-dx-meas'), dxForm: txt('v-dx-form')
      }
    };
  }

  /** テストから状態を決め打ちする */
  function set(o) {
    var st = YG.ui.st;
    if (o.mode) YG.ui.setMode(o.mode);
    var m = st.ms[st.mode];
    if (o.lambda !== undefined) m.lambda = o.lambda;
    if (o.d !== undefined) m.d = o.d;
    if (o.L !== undefined) m.L = o.L;
    if (o.light !== undefined) m.light = o.light;
    if (o.t !== undefined) st.ms.film.t = o.t;
    if (o.n !== undefined) st.ms.film.n = o.n;
    if (o.inserted !== undefined) {
      st.ms.film.inserted = !!o.inserted; st.ms.film.anim = false;
      st.ms.film.prog = o.inserted ? 1 : 0;
    }
    if (o.nl !== undefined) st.ms.liquid.n = o.nl;
    if (o.dipped !== undefined) {
      st.ms.liquid.inserted = !!o.dipped; st.ms.liquid.anim = false;
      st.ms.liquid.prog = o.dipped ? 1 : 0;
    }
    if (o.prog !== undefined) { st.ms.setup.prog = o.prog; st.ms.setup.paused = true; }
    if (o.showCirc !== undefined) m.showCirc = !!o.showCirc;
    if (o.time !== undefined) st.t = o.time;
    if (o.onlyBright !== undefined) m.onlyBright = o.onlyBright;
    if (o.sinT !== undefined) m.sinT = o.sinT;
    if (o.m !== undefined) {
      m.m = o.m;
      var vv = YG.ui.view();          // 液体モードでは媒質の中の波長 λ/n で明線の方向が決まる
      var s = P.sinThetaOfOrder(o.m, vv.lambda, m.d, P.extraOf(vv.film));
      if (s !== null) m.sinT = s;
    }
    if (o.step !== undefined) YG.ui.setStep(o.step);
    st.playing = false;
    YG.ui.syncAll();                // カードやボタンの表示も、実際の操作のあとと同じ状態にそろえる
    YG.ui.render();
    return true;
  }

  return { snapshot: snapshot, set: set };
})();
