/* ===== 68_mode_film.js ===== */
/* 補足モード「ダブルスリットの前に薄膜を置くと」（入試の典型問題）
 *
 * 流れ
 *   1. 最初は「ふつうのヤングの実験装置」だけ（薄膜なし・説明のカードもなし）
 *   2. 「ダブルスリットの下側に薄膜を入れる」ボタンを押すと、薄膜が上からすべりこむ
 *      アニメーションが走り、それにつれてすべての明線が下へ動く
 *   3. 入りきったところで、式変形のステップ（図4）と薄膜の設定カードが現れる
 *
 *   左パネル … 薄膜の中で波長が λ/n′ に縮み、光学距離が n′t になるようす（教科書 図b）
 *   全体図   … S₀→S₂ の光路に薄膜（教科書 図3）。光線の波は膜の中で縮み、S₂ 側だけ遅れる。
 *               m ＝ 0 の明線（ピンク）が x ＝ −(n′−1)tL/d へ移る。もとの O は破線で残す
 *   下の帯   … 点 P での光路差の内訳　(n′−1)t ＋ dx/L
 *
 * 物理はすべて 30_physics.js の solve() から来る（薄膜は film:{on,t,n}）。
 * アニメーションのあいだは t を進みぐあい prog（0→1）倍にして渡す。入りきれば厳密な値。
 */
window.YG = window.YG || {};
YG.modeFilm = (function () {
  'use strict';
  var P = YG.phys, D = YG.draw;
  var L = D.L, COL = D.COL;
  var vec = D.vec, add = D.add, sub = D.sub, mul = D.mul;

  var FSTEP_TITLES = [
    '① 薄膜の中では光学距離が n′t になる',
    '② 点 P での光路差 ＝ (n′−1)t ＋ dx/L',
    '③ m ＝ 0 の明線は「光路差 ＝ 0」の位置',
    '④ x ＝ −(n′−1)tL/d　だけ下へ動く'
  ];
  var ANIM_SEC = 1.7;                       // 薄膜がすべりこむ時間
  var SLIDE_PX = 120;                       // すべりこむ距離（下＝S₂ 側の外から）
  var FILM_HALF = 20;                       // 薄膜の半分の幅 [px]（光の道すじと垂直な向き）
  function ease(p) { return p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2; }
  /** 進みぐあい prog（0→1）のときの、薄膜のずれ [px]（0 で定位置） */
  function slideOf(prog) { return SLIDE_PX * (1 - ease(P.clamp(prog, 0, 1))); }
  /** 薄膜が光の道すじを「どれだけ横切ったか」（0〜1）。
   *  薄膜の先頭のふちが道すじに届いた瞬間に 0、道すじが薄膜のまん中に来たら 1。
   *  縞の移動はこの割合で起こす ＝ 薄膜が光線を横切っているあいだに縞が動く
   *  （まだ届いていないうちは動かず、入りきったあとにも動かない）。 */
  function coverageOf(prog) {
    var slide = slideOf(prog);
    return P.clamp(1 - slide / FILM_HALF, 0, 1);
  }

  /* ---------- 薄膜の置き場所（S₀→S₂ の光路の上、S₂ の手前） ---------- */
  function filmGeom(sc) {
    var from = vec(L.S0X + 5, L.CY), to = sc.S2;
    var u = D.unit(sub(to, from)), nrm = D.nrmOf(u);
    var Lp = D.len(sub(to, from));
    var e0 = Lp * 0.70, e1 = Lp * 0.80;    // 線分上での膜の範囲 [px]
    var c = add(from, mul(u, (e0 + e1) / 2));
    return { from: from, to: to, u: u, nrm: nrm, Lp: Lp, e0: e0, e1: e1, c: c, half: FILM_HALF };
  }

  /* ================= 左パネル ================= */
  function drawIntro(ctx, st) {
    ctx.save();
    ctx.font = D.font(13, true);
    ctx.fillStyle = '#2b5a78';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText('ふつうのヤングの実験装置', 14, 24);
    ctx.font = D.font(12);
    ctx.fillStyle = '#41505d';
    var lines = [
      '右の図は、いままでと同じ装置です。',
      'm ＝ 0 の明線（ピンク）は O にあります。',
      '',
      'この装置の、S₀ → S₂ の光路に',
      '厚さ t・屈折率 n′ の透明な薄膜を、',
      '光の道すじと垂直に差し入れると、',
      '縞はどうなるでしょうか。',
      '',
      '→ 図の上の「ダブルスリットの下側の S₂ の',
      '　 前に薄膜を入れる」ボタンを押してみましょう。'
    ];
    var y = 60;
    for (var i = 0; i < lines.length; i++) { ctx.fillText(lines[i], 16, y); y += 21; }
    ctx.restore();
  }

  function drawFilmZoom(ctx, st, sol, sc) {
    var t = st.film.t, n = st.film.n, lam = st.lambda;
    var x0 = 24, x1 = L.DIV - 22, w = x1 - x0;
    var yTop = 134, yBot = 250, amp = 15;
    var tOverLam = t / lam;
    var lamPx = P.clamp(Math.min(35 * lam / 600, (w * 0.42) / Math.max(0.6, tOverLam)), 6, 46);
    var tPx = tOverLam * lamPx;
    var xa = x0 + 40, xb = xa + tPx;

    ctx.save();
    ctx.font = D.font(12.5, true);
    ctx.fillStyle = '#2b5a78';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText('薄膜の中では、波長が λ/n′ に縮む', 14, 22);
    ctx.font = D.font(10.5);
    ctx.fillStyle = '#6b7580';
    ctx.fillText('（同じ厚さ t のあいだに、波が n′ 倍だけ多く入る）', 14, 42);

    // 薄膜の区間 [xa, xb] を、S₁ 側の波にも S₂ 側の波にも同じ縦線で区切る
    // （S₁ 側は空気のまま t、S₂ 側は薄膜で n′t。同じ区間をくらべているのが分かるように）
    if (tPx > 2) {
      var vy0 = yTop - amp - 4, vy1 = yBot + amp + 4;
      D.line(ctx, vec(xa, vy0), vec(xa, vy1), '#1a3350', 2);
      D.line(ctx, vec(xb, vy0), vec(xb, vy1), '#1a3350', 2);
      // S₁ 側の波の真上に、考えている区間 t を両矢印で示す
      var ay = yTop - amp - 10;
      D.dimLine(ctx, vec(xa, ay), vec(xb, ay), null, '#1a3350');
      ctx.font = D.font(12, true);
      ctx.fillStyle = '#1a3350';
      ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
      ctx.fillText('t', (xa + xb) / 2, ay - 4);
    }

    ctx.font = D.font(11.5, true);
    ctx.fillStyle = COL.ray;
    ctx.textAlign = 'right'; ctx.textBaseline = 'bottom';
    ctx.fillText('薄膜なし（S₁ 側）', x1, yTop - amp - 6);
    D.line(ctx, vec(x0, yTop), vec(x1, yTop), '#e6e9ec', 1);
    drawWave(ctx, x0, x1, yTop, amp, function (px) { return (px - x0) * lam / lamPx; }, st, lam, COL.ray);

    ctx.font = D.font(11.5, true);
    ctx.fillStyle = COL.ray2;
    ctx.textAlign = 'right'; ctx.textBaseline = 'top';
    ctx.fillText('薄膜あり（S₂ 側）', x1, yBot + amp + 6);
    D.line(ctx, vec(x0, yBot), vec(x1, yBot), '#e6e9ec', 1);
    drawWave(ctx, x0, x1, yBot, amp, function (px) {
      var opt;
      if (px <= xa) opt = (px - x0);
      else if (px <= xb) opt = (xa - x0) + (px - xa) * n;
      else opt = (xa - x0) + tPx * n + (px - xb);
      return opt * lam / lamPx;
    }, st, lam, COL.ray2);

    ctx.fillStyle = 'rgba(63,143,92,0.16)';
    ctx.fillRect(xa, yBot - 34, tPx, 68);
    ctx.strokeStyle = COL.filmEdge; ctx.lineWidth = 1.6;
    ctx.strokeRect(xa, yBot - 34, tPx, 68);
    // 薄膜の真下に、同じ区間の光学距離 n′t を両矢印で（上の t と同じ流儀）
    if (tPx > 2) {
      var ay2 = yBot + 44;
      D.dimLine(ctx, vec(xa, ay2), vec(xb, ay2), null, '#1a3350');
      ctx.font = D.font(12, true);
      ctx.fillStyle = '#1a3350';
      ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      ctx.fillText('n′t', (xa + xb) / 2, ay2 + 4);
    }

    // （2 本の波のあいだの「遅れ」の緑の線と説明は、分かりづらいので出さない。結論は下の緑の箱に）

    var by = 352;
    D.roundRect(ctx, x0, by, w, 122, 9);
    ctx.fillStyle = '#f4fbf6'; ctx.fill();
    ctx.strokeStyle = '#a6d3b6'; ctx.lineWidth = 1.4; ctx.stroke();
    ctx.font = D.font(11.5, true);
    ctx.fillStyle = '#1b6b34';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText('区間 t を光学距離（光路長）で数えると', x0 + 12, by + 9);
    ctx.font = D.font(11.5);
    ctx.fillStyle = '#2f4a3a';
    ctx.fillText('・S₁ 側（空気）なら　t', x0 + 12, by + 31);
    ctx.fillText('・S₂ 側（薄膜）なら　n′t', x0 + 12, by + 50);
    ctx.font = D.font(12, true);
    ctx.fillStyle = '#0b5c34';
    ctx.fillText('・差し引き　(n′−1)t だけ S₂ 側が長い', x0 + 12, by + 72);
    ctx.font = D.font(11);
    ctx.fillStyle = '#2b6b45';
    ctx.fillText('いま　t ＝ ' + D.fmtT(t) + '　n′ ＝ ' + n.toFixed(2), x0 + 12, by + 98);

    ctx.font = D.font(10.5);
    ctx.fillStyle = '#a3521c';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText('※ ここも λ を大きく描いています（λ ＝ ' + Math.round(lamPx) + ' px）。', 14, L.BAND_Y - 30);
    ctx.restore();
  }

  function drawWave(ctx, xFrom, xTo, y, amp, optAt, st, lam, color) {
    ctx.save();
    ctx.strokeStyle = color; ctx.lineWidth = 2.2;
    ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    ctx.beginPath();
    var n = Math.max(60, Math.round((xTo - xFrom) / 1.5));
    for (var i = 0; i <= n; i++) {
      var px = xFrom + (xTo - xFrom) * i / n;
      var yy = y - amp * P.waveAt(optAt(px), st.t, lam);
      if (i === 0) ctx.moveTo(px, yy); else ctx.lineTo(px, yy);
    }
    ctx.stroke();
    ctx.restore();
  }

  /* ================= 全体図の薄膜 ================= */
  function drawFilm(ctx, st, sc, g, prog) {
    var thick = 8 + 10 * ((st.film.tSet !== undefined ? st.film.tSet : st.film.t) / 5000);
    var slide = slideOf(prog);                    // 下（S₂ 側）からすべりこむ
    var c = vec(g.c.x, g.c.y + slide);
    var u = g.u, nrm = g.nrm, half = g.half;
    var a1 = add(add(c, mul(nrm, half)), mul(u, -thick / 2));
    var a2 = add(add(c, mul(nrm, -half)), mul(u, -thick / 2));
    var b1 = add(add(c, mul(nrm, half)), mul(u, thick / 2));
    var b2 = add(add(c, mul(nrm, -half)), mul(u, thick / 2));
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(a1.x, a1.y); ctx.lineTo(b1.x, b1.y); ctx.lineTo(b2.x, b2.y); ctx.lineTo(a2.x, a2.y);
    ctx.closePath();
    ctx.fillStyle = 'rgba(63,143,92,0.38)'; ctx.fill();
    ctx.strokeStyle = COL.filmEdge; ctx.lineWidth = 1.8; ctx.stroke();
    // 名札（決め打ちの位置：ダブルスリットの名札の下の行）
    var lx = g.c.x - 10, ly = L.CY + L.PLATE_H / 2 + 50;
    D.dashLine(ctx, vec(c.x, c.y + half + 4), vec(lx, ly - 4), '#7fbf9c', [4, 3], 1);
    ctx.font = D.font(11.5, true);
    ctx.fillStyle = '#2b6b45';
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText('薄膜　t ＝ ' + D.fmtT(st.film.tSet !== undefined ? st.film.tSet : st.film.t)
      + '　n′ ＝ ' + st.film.n.toFixed(2), lx, ly);
    ctx.restore();
  }

  /* ================= 下の帯：点 P での光路差の内訳 =================
   * 光路差（S₂ を通る道 − S₁ を通る道）を 2 つに分けて、0 の縦線を中心に右が正・左が負で描く。
   *   1 段め … ダブルスリット後の光路差　dx/L（x ＜ 0 なら負 ＝ 左向き。S₁ を通る道が長い）
   *   2 段め … ダブルスリット前の光路差　(n′−1)t（薄膜で S₂ 側が長い ＝ 正 ＝ 右向き）
   *   3 段め … 最終的な光路差 ＝ 2 つの和（ピンクの印）。0 なら m ＝ 0 の明線
   * 矢印の上には 1 次元の波を重ねる：波の個数 ＝ その長さが λ の何個ぶんか。
   */
  function pathBand(ctx, st, sol, sc) {
    var y0 = L.BAND_Y + 8, h = L.H - y0 - 8;
    var geo = st.d * Math.sin(sol.theta);          // ダブルスリット後の光路差 dx/L [nm]（符号つき）
    var extra = sol.extra;                         // ダブルスリット前の光路差 (n′−1)t [nm]
    var tot = extra + geo;
    ctx.save();
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, L.BAND_Y - 8, L.W, L.H - (L.BAND_Y - 8));
    D.roundRect(ctx, 10, y0, L.W - 20, h, 10);
    ctx.fillStyle = '#ffffff'; ctx.fill();
    ctx.strokeStyle = '#d2337c'; ctx.lineWidth = 1.6;
    ctx.setLineDash([7, 5]); ctx.stroke(); ctx.setLineDash([]);
    var chip = '点 P（いま見ている位置）での光路差　＝　ダブルスリット後の光路差 dx/L　＋　ダブルスリット前の光路差 (n′−1)t';
    ctx.font = D.font(11.5, true);
    var cw = ctx.measureText(chip).width + 34;
    D.roundRect(ctx, 24, y0 - 11, cw, 22, 11);
    ctx.fillStyle = '#d2337c'; ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(chip, 41, y0 + 1);

    // 0 の縦線の位置と縮尺。矢印は右にも左にも伸びるので、左右 500 px ずつを使う
    var cx = 760, labX = 318;                      // 0 の縦線の x／左の見出しの右端
    var big = Math.max(Math.abs(extra), Math.abs(geo), Math.abs(tot), 1.2 * st.lambda);
    var pxPerNm = Math.min(0.30, Math.min(cx - labX - 30, L.W - 40 - cx) / big);   // 左右どちらにも収まる縮尺
    var lamPx = st.lambda * pxPerNm;               // この帯での λ [px]
    var y1 = y0 + 42, y2 = y0 + 76, y3 = y0 + 108; // 3 段の中心
    var amp = 7;
    // 0 の縦線（3 段をつらぬく）と、正負の向き（いちばん下）。左が正・右が負
    var SGN = -1;                                  // 値 → 画面の向き（正を左に描く）
    D.line(ctx, vec(cx, y1 - 18), vec(cx, y3 + 14), '#8a939c', 1.4);
    ctx.font = D.font(10.5);
    ctx.fillStyle = '#6b7580';
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText('0', cx, y3 + 16);
    ctx.textAlign = 'right';
    ctx.fillText('正（S₂ を通る道が長い）←', cx - 10, y3 + 16);
    ctx.textAlign = 'left';
    ctx.fillText('→ 負（S₁ を通る道が長い）', cx + 10, y3 + 16);

    function waveOn(xs, xe, y, color) {
      if (Math.abs(xe - xs) < 2) return;
      ctx.save();
      ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.lineJoin = 'round';
      ctx.beginPath();
      var n = Math.max(24, Math.round(Math.abs(xe - xs) / 1.5));
      for (var i = 0; i <= n; i++) {
        var x = xs + (xe - xs) * i / n;
        var s = SGN * (x - cx) / pxPerNm;           // 光路 [nm]（0 からの道のり）
        var yy = y - amp * P.waveAt(s, st.t, st.lambda);
        if (i === 0) ctx.moveTo(x, yy); else ctx.lineTo(x, yy);
      }
      ctx.stroke();
      ctx.restore();
    }
    function heading(y, txt, col) {
      ctx.font = D.font(12.5, true);
      ctx.fillStyle = col;
      ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
      ctx.fillText(txt, labX, y);
    }
    function valueText(y, xEnd, txt, col) {
      // 値は矢印の真上に（矢印のまん中に中央ぞろえ。短い矢印でも 0 の線をまたいで読める）
      ctx.font = D.font(11, true);
      ctx.fillStyle = col;
      ctx.textBaseline = 'bottom'; ctx.textAlign = 'center';
      var mid = (cx + xEnd) / 2;
      var tw = ctx.measureText(txt).width;
      mid = P.clamp(mid, labX + 30 + tw / 2, L.W - 30 - tw / 2);
      ctx.fillText(txt, mid, y - amp - 3);
    }

    // 1 段め：ダブルスリット後の光路差 dx/L（P が S₂ 側 ＝ x ＜ 0 なら負）
    var geoCol = (geo >= 0) ? '#1f74d0' : COL.ray;
    var geoColDim = (geo >= 0) ? 'rgba(31,116,208,0.45)' : 'rgba(232,134,42,0.45)';
    var xG = cx + SGN * geo * pxPerNm;
    heading(y1, 'ダブルスリット後の光路差', (geo >= 0) ? '#1a4e86' : '#a34d0c');
    if (Math.abs(geo) > 1) {
      D.arrow(ctx, vec(cx, y1), vec(xG >= cx ? 1 : -1, 0), Math.max(2, Math.abs(geo) * pxPerNm), geoColDim, 3, 10);
      waveOn(cx, xG, y1, geoCol);
    }
    var geoExpr = (geo < -0.5) ? 'dx/L ＝ −d|x|/L（x ＜ 0）' : 'dx/L ＝ ＋d|x|/L（x ≧ 0）';
    valueText(y1, xG, geoExpr + ' ＝ ' + Math.round(geo) + ' nm ＝ ' + (geo / st.lambda).toFixed(2) + ' λ',
      (geo >= 0) ? '#1a4e86' : '#a34d0c');

    // 2 段め：ダブルスリット前の光路差 (n′−1)t（薄膜で S₂ 側が長い ＝ 正）
    var xE = cx + SGN * extra * pxPerNm;
    heading(y2, 'ダブルスリット前の光路差', '#0b5c34');
    if (Math.abs(extra) > 1) {
      D.arrow(ctx, vec(cx, y2), vec(SGN, 0), Math.max(2, extra * pxPerNm), 'rgba(15,157,88,0.45)', 3, 10);
      waveOn(cx, xE, y2, COL.geo);
    }
    valueText(y2, xE, '(n′−1)t ＝ ' + Math.round(extra) + ' nm ＝ ' + (extra / st.lambda).toFixed(2) + ' λ', '#0b5c34');
    // 足し算の印（2 段めの右端）
    ctx.font = D.font(16, true);
    ctx.fillStyle = '#8a939c';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('＋', labX + 26, (y1 + y2) / 2);

    // 3 段め：最終的な光路差 ＝ 和（ピンクの印）。2 段めの終わりから矢印で下ろす
    var xT = cx + SGN * tot * pxPerNm;
    D.arrow(ctx, vec(xT, y2 + 11), vec(0, 1), y3 - y2 - 24, 'rgba(210,51,124,0.55)', 3, 8);
    heading(y3, '最終的な光路差', COL.zero);
    D.line(ctx, vec(cx, y3), vec(xT, y3), 'rgba(210,51,124,0.35)', 3);
    waveOn(cx, xT, y3, COL.zero);                  // 1・2 段めと同じ流儀で、この長さにも波を重ねる
    D.line(ctx, vec(xT, y3 - 13), vec(xT, y3 + 13), COL.zero, 3);
    ctx.font = D.font(12, true);
    ctx.fillStyle = COL.zero;
    ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
    var gTxt = (geo < 0) ? ('(' + Math.round(geo) + ')') : String(Math.round(geo));
    ctx.fillText('＝ ' + gTxt + ' ＋ ' + Math.round(extra) + ' ＝ ' + Math.round(tot) + ' nm ＝ ' + (tot / st.lambda).toFixed(2) + ' λ'
      + (sol.kind === 'strong' ? '　→ 明線（m ＝ ' + sol.m + '）' : (sol.kind === 'weak' ? '　→ 暗線' : '')),
      Math.max(cx, xT) + 10, y3);
    // λ 1 個ぶんの目盛り（右上）
    D.dimLine(ctx, vec(L.W - 50 - lamPx, y0 + 8), vec(L.W - 50, y0 + 8), 'λ', '#0b5c34', 10);
    ctx.restore();
  }

  /* ================= 大きな見出し（ステップ③④の要点） =================
   * 「m ＝ 0 の明線は光路差 0 の位置」「このずれは m を含まないので…」を、
   * 図の幅に入る限界の大きさで出す（2 行まで）。返り値は箱の下端の y。 */
  function bigHeading(ctx, lines) {
    var fs = 26, lh = 34, pad = 14;
    ctx.save();
    ctx.font = D.font(fs, true);
    var w = 0;
    for (var i = 0; i < lines.length; i++) w = Math.max(w, ctx.measureText(lines[i]).width);
    var x = L.DIV + 20, y = 10, bw = w + pad * 2, bh = lines.length * lh + 12;
    D.roundRect(ctx, x, y, bw, bh, 10);
    ctx.fillStyle = '#fdeaf3'; ctx.fill();
    ctx.strokeStyle = COL.zero; ctx.lineWidth = 2.4; ctx.stroke();
    ctx.fillStyle = '#a01f5e';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    for (var j = 0; j < lines.length; j++) ctx.fillText(lines[j], x + pad, y + 6 + lh * (j + 0.5));
    ctx.restore();
    return y + bh;
  }

  /** 4 本の光路に「短」「長」の札を付ける（ステップ③：短＋長 ＝ 長＋短 → 光路差 0） */
  function segTags(ctx, sc, g) {
    var s0 = vec(L.S0X + 5, L.CY), S1 = sc.S1, S2 = sc.S2, Pp = sc.P;
    function tag(a, b, k, txt, dy) {
      var p = vec(a.x + (b.x - a.x) * k, a.y + (b.y - a.y) * k + dy);
      ctx.save();
      ctx.font = D.font(15, true);
      var w = ctx.measureText(txt).width;
      D.roundRect(ctx, p.x - w / 2 - 7, p.y - 12, w + 14, 24, 7);
      ctx.fillStyle = '#fff3d6'; ctx.fill();
      ctx.strokeStyle = '#c77800'; ctx.lineWidth = 1.6; ctx.stroke();
      ctx.fillStyle = '#8a4b00';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(txt, p.x, p.y + 1);
      ctx.restore();
    }
    tag(s0, S1, 0.45, '短', -20);                       // S₀→S₁（空気のまま）
    tag(S1, Pp, (L.BREAK_X - 150 - S1.x) / (Pp.x - S1.x), '長', -20);   // S₁→P（P は S₂ 側にあるので遠い）
    tag(s0, S2, 0.36, '長', 22);                        // S₀→S₂（薄膜で光学距離が長い）
    tag(S2, Pp, (L.BREAK_X - 150 - S2.x) / (Pp.x - S2.x), '短', 22);    // S₂→P（P は S₂ 側にあるので近い）
  }

  /* ================= ステップの吹き出し ================= */
  function drawCallouts(ctx, st, sol, sc, fstep, g, top) {
    var extra = Math.round(sol.extra);
    var zy = L.CY - sol.x0 * sc.ppm;
    var y = top || 60;
    if (fstep === 1) {
      D.calloutAt(ctx, g.c, L.DIV + 20, y, [
        '① 屈折率 n′ の中では、光の波長が λ/n′ に縮む。',
        '　 厚さ t のあいだに入る波の数が n′ 倍になるので、',
        '　 光学距離（光路長）は n′t。空気なら t だったから、',
        '　 S₀→S₂ の光路は (n′−1)t ＝ ' + extra + ' nm だけ長くなる。'
      ], { bg: '#f4fbf6', border: '#3f8f5c', fg: '#1f4a33' });
    } else if (fstep === 2) {
      D.calloutAt(ctx, sc.P, L.DIV + 20, y, [
        '② 点 P（座標 x）での光路差は、2 つの足し算になる。',
        '　 　ダブルスリット後の光路差 dx/L　＋　ダブルスリット前の光路差 (n′−1)t',
        '　 ダブルスリット後の光路差は、薄膜がないときとまったく同じ式。',
        '　 （下の帯に、いまの点 P での内訳が出ています）'
      ], { bg: '#fdf3f8', border: '#d2337c', fg: '#5a3247' });
    } else if (fstep === 3) {
      D.calloutAt(ctx, vec(L.SX, zy), L.DIV + 20, y, [
        '③ (n′−1)t ＋ dx/L ＝ 0　となる位置。',
        '　 S₀→S₂ は薄膜で「長」、その代わり S₂→P が「短」。',
        '　 短 ＋ 長 ＝ 長 ＋ 短 で、2 つの道のりがそろう。',
        '　 だから新しい m ＝ 0 は、S₂ に近い側（下側）にできる。'
      ], { bg: '#fdf3f8', border: '#d2337c', fg: '#5a3247' });
    } else {
      D.calloutAt(ctx, vec(L.SX, zy), L.DIV + 20, y, [
        '④ 解くと　x ＝ −(n′−1)tL/d ＝ −' + Math.abs(sol.x0 * 1000).toFixed(2) + ' mm。',
        '　 ＝ 縞は形も間隔も変えずに、まるごと平行移動する。',
        '　 間隔 Δx ＝ λL/d ＝ ' + (sol.dxApprox * 1000).toFixed(2) + ' mm は変わらない。'
      ], { bg: '#fdf3f8', border: '#d2337c', fg: '#5a3247' });
    }
  }

  /* ================= 本体 ================= */
  function render(ctx, st, sol, sc) {
    var f = st.film;                              // {on, t, n, prog, inserted, anim}
    var fstep = P.clamp(st.fstep, 1, 4);
    var g = filmGeom(sc);
    var lam = D.dispLamPx(st);
    var extraPx = (sol.extra / st.lambda) * lam;  // 膜の中で余計に進む光路 [見かけの px]

    D.panels(ctx);
    if (f.inserted) drawFilmZoom(ctx, st, sol, sc); else drawIntro(ctx, st);

    var ph = YG.modePath.incoming(ctx, st, sol, sc, {
      film: (f.on && extraPx > 0.01) ? { e0: g.e0, e1: g.e1, extraPx: extraPx } : null,
      filmDraw: f.on ? function (c2) { drawFilm(c2, st, sc, g, f.prog); } : null,
      dNote: false
    });
    // スクリーンの右に m の名札（①と同じ）。ただし主役は m ＝ 0 の名札（ピンク）なので、ほかは薄く
    YG.modePath.stage(ctx, st, sol, sc, { labels: true, dimLabels: true, skipZero: true });
    YG.modePath.rays(ctx, st, sol, sc, ph);
    YG.modePath.rayLabels(ctx, sc);

    // もとの O（x ＝ 0）と、m ＝ 0 の明線（ピンク）
    var oy = L.CY, zy = L.CY - sol.x0 * sc.ppm;
    D.dashLine(ctx, vec(L.SX - 40, oy), vec(L.SX + 62, oy), '#8a939c', [5, 4], 1.4);
    D.pointLabel(ctx, vec(L.SX, oy), 'O', -22, -12, '#6b7580');   // 右は m の名札の列なので左に
    if (zy >= L.CY - L.SH && zy <= L.CY + L.SH) {
      D.line(ctx, vec(L.SX - 6, zy), vec(L.SX + L.SCR_W + 6, zy), COL.zero, 3);
      D.line(ctx, vec(L.SX + L.SCR_W + 6, zy), vec(L.SX + 62, zy), COL.zero, 1.6);
      ctx.save();
      ctx.font = D.font(12, true);
      ctx.fillStyle = COL.zero;
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText('m ＝ 0', L.SX + 66, zy);
      ctx.restore();
      if (f.inserted && fstep >= 3 && Math.abs(zy - oy) > 6) {
        var ax = L.SX + 116;
        D.dimLine(ctx, vec(ax, oy), vec(ax, zy), null, COL.zero);
        var tx = '下へ ' + Math.abs(sol.x0 * 1000).toFixed(2) + ' mm';
        ctx.save();
        ctx.font = D.font(12, true);
        var tw = ctx.measureText(tx).width;
        var ty = (oy + zy) / 2;
        var bx = Math.min(ax + 10, L.W - tw - 22);
        D.roundRect(ctx, bx, ty - 12, tw + 14, 24, 6);
        ctx.fillStyle = '#fdeaf3'; ctx.fill();
        ctx.strokeStyle = COL.zero; ctx.lineWidth = 1.4; ctx.stroke();
        ctx.fillStyle = '#a01f5e';
        ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
        ctx.fillText(tx, bx + 7, ty + 1);
        ctx.restore();
      }
    }
    D.pointLabel(ctx, sc.P, 'P', 22, 12, '#8a3b00');

    // 見出し・吹き出し
    if (f.inserted) {
      var top = 60;
      if (fstep === 3) {
        top = bigHeading(ctx, ['m ＝ 0 の明線は、光路差 0 の位置']) + 8;
        // 「短」「長」の札は、m ＝ 0 の明線を見ているときだけ（ほかの m では話が合わない）
        if (sol.kind === 'strong' && sol.m === 0) segTags(ctx, sc, g);
      } else if (fstep === 4) {
        top = bigHeading(ctx, ['このずれは m を含まないので、', 'どの明線も同じく移動']) + 8;
      } else {
        D.stepHeading(ctx, L.DIV + 20, 14, FSTEP_TITLES[fstep - 1]);
      }
      if (st.showLabels) drawCallouts(ctx, st, sol, sc, fstep, g, top);
      pathBand(ctx, st, sol, sc);
    } else {
      D.stepHeading(ctx, L.DIV + 20, 14, f.anim ? '薄膜を入れています…' : 'ふつうのヤングの実験装置（薄膜なし）');
      if (!f.anim) {
        D.calloutAt(ctx, vec(L.SX, oy), L.DIV + 20, 60, [
          'm ＝ 0 の明線（ピンク）は、いまは O にあります。',
          '図の上の「ダブルスリットの下側の S₂ の前に薄膜を入れる」を押すと、',
          'S₀ → S₂ の光路に薄膜が入ります。縞がどう動くか見てみましょう。'
        ], { bg: '#fdf3f8', border: '#d2337c', fg: '#5a3247' });
      }
    }
    YG.modePath.waveNote(ctx);
  }

  return { render: render, FSTEP_TITLES: FSTEP_TITLES, ANIM_SEC: ANIM_SEC, filmGeom: filmGeom,
    slideOf: slideOf, coverageOf: coverageOf };
})();
