/* ===== 67_mode_liquid.js ===== */
/* 補足モード「装置を液体の中に入れる」
 *
 * 流れ
 *   1. 最初は「ふつうのヤングの実験装置」だけ（空気中・説明のカードもなし）
 *   2. 「屈折率 n の媒質（液体）の中に入れる」ボタンを押すと、水色の透明な液体が
 *      下から満ちていくアニメーションが走り、それにつれて縞が O に向かって縮む
 *   3. 満ちきったところで、式変形のステップ（3 つ）と液体の設定カードが現れる
 *
 *   左パネル … 媒質の中で波長が λ/n に縮むようす（空気中の波と並べる）と、式のまとめ
 *   全体図   … 装置がまるごと液体の中（水槽）。空気中での明線の位置は破線で残す
 *   下の帯   … 空気中の縞と、媒質の中の縞を、横にたおして並べてくらべる
 *
 * 物理はすべて 30_physics.js の solve() から来る。70_ui.js の view() が
 * lambda ＝ λ₀/n（媒質の中の波長）と lambda0 ＝ λ₀（空気中）を渡してくるので、
 * ここでは「λ₀ を使うのは色と比較用の値だけ」と決めておけばよい。
 * アニメーションのあいだは n を 1 → n に満ちた割合で近づける（満ちきれば厳密な値）。
 */
window.YG = window.YG || {};
YG.modeLiquid = (function () {
  'use strict';
  var P = YG.phys, D = YG.draw;
  var L = D.L, COL = D.COL;
  var vec = D.vec;

  var LSTEP_TITLES = [
    '① 媒質の中では、波長が λ/n に縮む',
    '② 明線の条件　d·x/L ＝ m·λ/n',
    '③ 明線の間隔　Δx′ ＝ λL/(nd) ＝ Δx/n'
  ];
  var ANIM_SEC = 2.6;                        // 液体が満ちる時間
  function ease(p) { return p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2; }

  /* 水槽：右パネルのほぼ全体（光源 Q からスクリーンまでを入れる） */
  var TANK = { x0: L.DIV + 14, x1: L.SX + L.SCR_W + 6, yTop: 8, yBot: L.BAND_Y - 14 };
  var LIQ_FILL = 'rgba(120,190,235,0.17)', LIQ_EDGE = 'rgba(40,130,190,0.75)', LIQ_TXT = '#1a6a9c';

  /** 進みぐあい prog（0→1）のときの液面の y */
  function levelOf(prog) { return TANK.yBot - (TANK.yBot - TANK.yTop) * ease(P.clamp(prog, 0, 1)); }
  /** 光の通り道（スクリーンの高さ CY±SH）が、液面の下にどれだけ入ったか（0〜1）。
   *  縞の縮みはこの割合で起こす ＝ 液体が満ちていくあいだに縞が縮む */
  function coverageOf(prog) {
    var level = levelOf(prog);
    return P.clamp((L.CY + L.SH - level) / (2 * L.SH), 0, 1);
  }

  /* ================= 左パネル ================= */
  function drawIntro(ctx, st) {
    ctx.save();
    ctx.font = D.font(13, true);
    ctx.fillStyle = '#2b5a78';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText('ふつうのヤングの実験装置（空気中）', 14, 24);
    ctx.font = D.font(12);
    ctx.fillStyle = '#41505d';
    var lines = [
      '右の図は、いままでと同じ装置です。',
      '明線の間隔は Δx ＝ λL/d。',
      '',
      'この装置を、光源からスクリーンまで',
      'まるごと屈折率 n の透明な液体',
      '（水なら n ≒ 1.33）にしずめると、',
      '縞の間隔はどうなるでしょうか。',
      '',
      '→ 図の上の「屈折率 n の媒質（液体）の',
      '　 中に入れる」ボタンを押してみましょう。'
    ];
    var y = 60;
    for (var i = 0; i < lines.length; i++) { ctx.fillText(lines[i], 16, y); y += 21; }
    ctx.restore();
  }

  function drawLiquidZoom(ctx, st, sol) {
    var n = st.medium.nSet, lam0 = st.lambda0, lamN = lam0 / n;
    var x0 = 24, x1 = L.DIV - 22, w = x1 - x0;
    var yTop = 118, yBot = 214, amp = 14;
    var lamPx0 = 42 * lam0 / 600;              // 空気中の λ を何 px に描くか（このパネルだけの縮尺）
    var nmPerPx = lam0 / lamPx0;

    ctx.save();
    ctx.font = D.font(12.5, true);
    ctx.fillStyle = '#2b5a78';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText('媒質の中では、波長が λ/n に縮む', 14, 22);
    ctx.font = D.font(10.5);
    ctx.fillStyle = '#6b7580';
    ctx.fillText('（速さが c/n に。振動数は同じ → 波長だけ 1/n）', 14, 42);

    ctx.font = D.font(11.5, true);
    ctx.fillStyle = COL.ray;
    ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
    ctx.fillText('空気中　λ ＝ ' + Math.round(lam0) + ' nm', x0, yTop - amp - 6);
    D.line(ctx, vec(x0, yTop), vec(x1, yTop), '#e6e9ec', 1);
    drawWave(ctx, x0, x1, yTop, amp, nmPerPx, st.t, lam0, COL.ray);
    D.dimLine(ctx, vec(x0, yTop + amp + 8), vec(x0 + lamPx0, yTop + amp + 8), 'λ', '#8a5300', 10);

    ctx.font = D.font(11.5, true);
    ctx.fillStyle = LIQ_TXT;
    ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
    ctx.fillText('媒質の中（n ＝ ' + n.toFixed(2) + '）　λ′ ＝ λ/n ＝ ' + Math.round(lamN) + ' nm', x0, yBot - amp - 6);
    ctx.fillStyle = LIQ_FILL;
    ctx.fillRect(x0 - 6, yBot - amp - 4, w + 12, 2 * amp + 8);
    D.line(ctx, vec(x0, yBot), vec(x1, yBot), '#e6e9ec', 1);
    drawWave(ctx, x0, x1, yBot, amp, nmPerPx, st.t, lamN, '#1a7ab8');
    D.dimLine(ctx, vec(x0, yBot + amp + 8), vec(x0 + lamPx0 / n, yBot + amp + 8), 'λ/n', LIQ_TXT, 10);

    ctx.font = D.font(10.5);
    ctx.fillStyle = '#6b7580';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText('同じ長さに、波が n 倍（' + n.toFixed(2) + ' 倍）多く入る', x0, yBot + amp + 22);

    // 式のまとめ
    var by = 300, bh = 150;
    D.roundRect(ctx, x0, by, w, bh, 9);
    ctx.fillStyle = '#eef7fd'; ctx.fill();
    ctx.strokeStyle = '#9ccbe6'; ctx.lineWidth = 1.4; ctx.stroke();
    ctx.font = D.font(11.5, true);
    ctx.fillStyle = LIQ_TXT;
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText('明線の条件の λ を λ/n に置きかえるだけ', x0 + 12, by + 9);
    ctx.font = D.font(11.5);
    ctx.fillStyle = '#24485e';
    ctx.fillText('・明線　d·x/L ＝ m·λ/n', x0 + 12, by + 33);
    ctx.fillText('・間隔　Δx′ ＝ λL/(nd) ＝ Δx/n', x0 + 12, by + 53);
    ctx.font = D.font(12, true);
    ctx.fillStyle = '#0d4f7a';
    ctx.fillText('・いま　Δx′ ＝ ' + (sol.dxAir / n * 1000).toFixed(2) + ' mm', x0 + 12, by + 78);
    ctx.font = D.font(11);
    ctx.fillStyle = '#41505d';
    ctx.fillText('　（空気中は Δx ＝ ' + (sol.dxAir * 1000).toFixed(2) + ' mm）', x0 + 12, by + 98);
    ctx.font = D.font(11, true);
    ctx.fillStyle = '#a01f5e';
    ctx.fillText('m ＝ 0 は動かず、縞全体が 1/n 倍に縮む', x0 + 12, by + 122);

    ctx.font = D.font(10.5);
    ctx.fillStyle = '#a3521c';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText('※ ここも λ を大きく描いています（λ ＝ ' + Math.round(lamPx0) + ' px）。', 14, L.BAND_Y - 30);
    ctx.restore();
  }

  function drawWave(ctx, xFrom, xTo, y, amp, nmPerPx, t, lam, color) {
    ctx.save();
    ctx.strokeStyle = color; ctx.lineWidth = 2.2;
    ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    ctx.beginPath();
    var n = Math.max(60, Math.round((xTo - xFrom) / 1.5));
    for (var i = 0; i <= n; i++) {
      var px = xFrom + (xTo - xFrom) * i / n;
      var yy = y - amp * P.waveAt((px - xFrom) * nmPerPx, t, lam);
      if (i === 0) ctx.moveTo(px, yy); else ctx.lineTo(px, yy);
    }
    ctx.stroke();
    ctx.restore();
  }

  /* ================= 全体図の液体（水槽） ================= */
  function drawTank(ctx, st) {
    var md = st.medium;
    var level = levelOf(md.prog);
    ctx.save();
    // 水槽の輪郭（左・右・底）
    ctx.strokeStyle = '#9fb6c6'; ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(TANK.x0, TANK.yTop); ctx.lineTo(TANK.x0, TANK.yBot);
    ctx.lineTo(TANK.x1, TANK.yBot); ctx.lineTo(TANK.x1, TANK.yTop);
    ctx.stroke();
    // 液体（うすい水色・透明）
    ctx.fillStyle = LIQ_FILL;
    ctx.fillRect(TANK.x0, level, TANK.x1 - TANK.x0, TANK.yBot - level);
    // 液面（少しだけ波打たせる）
    ctx.strokeStyle = LIQ_EDGE; ctx.lineWidth = 1.6;
    ctx.beginPath();
    for (var x = TANK.x0; x <= TANK.x1; x += 3) {
      var yy = level + Math.sin((x - TANK.x0) / 18 + (st.nowSec || 0) * 1.5) * 1.6;
      if (x === TANK.x0) ctx.moveTo(x, yy); else ctx.lineTo(x, yy);
    }
    ctx.stroke();
    // 名札（水槽の左下）。全体図の波の注記もここに続けて書く（50_mode_path の waveNote の代わり）
    ctx.font = D.font(12, true);
    ctx.fillStyle = LIQ_TXT;
    ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
    var lab = '屈折率 n ＝ ' + md.nSet.toFixed(2) + ' の液体';
    ctx.fillText(lab, TANK.x0 + 10, TANK.yBot - 8);
    // 全体図の波の注記は、見出しと吹き出しのあいだ（左上）に置く
    ctx.font = D.font(10.5);
    ctx.fillStyle = '#8a939c';
    ctx.textBaseline = 'top';
    ctx.fillText('※ 全体図の波は、波長を見やすく拡大しています', TANK.x0 + 12, 47);
    ctx.restore();
  }

  /** 空気中での明線の位置（スクリーンの面の上の水色の点線）。液体に入れると縞が縮むので、比較のために残す */
  function airMarks(ctx, st, sol, sc) {
    var d = st.d, Lm = st.L, lam0 = st.lambda0;
    var xs = L.SX - 2, xe = L.SX + L.SCR_W + 2;
    ctx.save();
    for (var m = -40; m <= 40; m++) {
      var x = P.xOfOrder(m, lam0, d, Lm, 0);
      if (x === null || Math.abs(x) > sol.halfM) continue;
      var y = L.CY - x * sc.ppm;
      D.dashLine(ctx, vec(xs, y), vec(xe, y), 'rgba(120,225,255,0.95)', [3, 3], 1.3);
    }
    ctx.font = D.font(10.5);
    ctx.fillStyle = '#1a6a9c';
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText('点線 ＝ 空気中の明線の位置', L.SX + L.SCR_W / 2 + 10, L.CY + L.SH + 8);
    ctx.restore();
  }

  /** ステップ③：Δx′ の寸法線（スクリーンの左、m ＝ 0 と m ＝ 1 の間）。y の範囲を返す */
  function dxRange(sol, sc) {
    // 光線 S₁→P・S₂→P と重ならないよう、P が O より上なら m ＝ 0 と −1 の間、下なら 0 と ＋1 の間に引く
    var want = (sc.P.y <= L.CY) ? -1 : 1;
    var o0 = null, o1 = null;
    for (var i = 0; i < sol.orders.length; i++) {
      if (sol.orders[i].m === 0) o0 = sol.orders[i];
      if (sol.orders[i].m === want) o1 = sol.orders[i];
    }
    if (!o0 || !o1) return null;
    return [L.CY - o0.x * sc.ppm, L.CY - o1.x * sc.ppm];
  }
  function dxDim(ctx, st, sol, sc) {
    var r = dxRange(sol, sc);
    if (!r) return;
    var y0 = r[0], y1 = r[1];
    var dx = L.SX - 24;
    D.dimLine(ctx, vec(dx, y0), vec(dx, y1), null, '#0d4f7a');
    var tx = 'Δx′ ＝ ' + (sol.dxApprox * 1000).toFixed(2) + ' mm';
    ctx.save();
    ctx.font = D.font(12, true);
    var tw = ctx.measureText(tx).width;
    var ty = (y0 + y1) / 2;
    D.roundRect(ctx, dx - 12 - tw - 10, ty - 10, tw + 10, 20, 5);
    ctx.fillStyle = 'rgba(255,255,255,0.94)'; ctx.fill();
    ctx.strokeStyle = '#9ccbe6'; ctx.lineWidth = 1; ctx.stroke();
    ctx.fillStyle = '#0d4f7a';
    ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    ctx.fillText(tx, dx - 17, ty + 1);
    ctx.restore();
  }

  /* ================= 下の帯：空気中の縞と媒質の中の縞をくらべる ================= */
  function compareBand(ctx, st, sol, sc) {
    var y0 = L.BAND_Y + 8, h = L.H - y0 - 8;
    var n = st.medium.nSet, lam0 = st.lambda0;
    var xL = 250, xR = L.W - 40, bw = xR - xL;
    var ppx = bw / (2 * sol.halfM);              // 横 [px / m]
    ctx.save();
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, L.BAND_Y - 8, L.W, L.H - (L.BAND_Y - 8));
    D.roundRect(ctx, 10, y0, L.W - 20, h, 10);
    ctx.fillStyle = '#ffffff'; ctx.fill();
    ctx.strokeStyle = '#1a7ab8'; ctx.lineWidth = 1.6;
    ctx.setLineDash([7, 5]); ctx.stroke(); ctx.setLineDash([]);
    var chip = 'スクリーンを横にたおして、空気中の縞と媒質の中の縞を並べてくらべる';
    ctx.font = D.font(11.5, true);
    var cw = ctx.measureText(chip).width + 34;
    D.roundRect(ctx, 24, y0 - 11, cw, 22, 11);
    ctx.fillStyle = '#1a7ab8'; ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(chip, 41, y0 + 1);

    function strip(yc, lam, label, sub, color) {
      var sh = 22;
      var rgb = P.wavelengthToRGB(lam0);
      ctx.fillStyle = '#1d1f22';
      ctx.fillRect(xL, yc - sh / 2, bw, sh);
      for (var px = 0; px <= bw; px += 1) {
        var xm = (px - bw / 2) / ppx;
        var th = Math.asin(P.clamp(P.sinThetaFromX(xm, st.L), -1, 1));
        var I = (st.light === 'white')
          ? null : P.intensity2(th, st.d, lam, 0);
        if (I === null) {
          var c = P.spectrumColorAtX(xm, st.d, st.L, 0, 1, lam0 / lam);
          ctx.fillStyle = P.rgbCss(c);
        } else {
          ctx.fillStyle = P.rgbCss(rgb, Math.pow(I, 0.8));
        }
        ctx.fillRect(xL + px, yc - sh / 2, 1.2, sh);
      }
      ctx.strokeStyle = '#a89878'; ctx.lineWidth = 1;
      ctx.strokeRect(xL - 0.5, yc - sh / 2 - 0.5, bw + 1, sh + 1);
      ctx.font = D.font(11.5, true);
      ctx.fillStyle = color;
      ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
      ctx.fillText(label, xL - 12, yc - 8);
      ctx.font = D.font(10.5);
      ctx.fillStyle = '#5b6672';
      ctx.fillText(sub, xL - 12, yc + 8);
      // m ＝ 0 と m ＝ 1 の印と Δx の寸法線
      var x1 = P.xOfOrder(1, lam, st.d, st.L, 0);
      if (x1 !== null && x1 < sol.halfM) {
        var px0 = xL + bw / 2, px1 = xL + bw / 2 + x1 * ppx;
        D.line(ctx, vec(px0, yc - sh / 2 - 3), vec(px0, yc + sh / 2 + 3), color, 1.2);
        D.line(ctx, vec(px1, yc - sh / 2 - 3), vec(px1, yc + sh / 2 + 3), color, 1.2);
        ctx.font = D.font(10, true);
        ctx.fillStyle = color;
        ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
        ctx.fillText('m=0', px0, yc - sh / 2 - 4);
        ctx.fillText('m=1', px1, yc - sh / 2 - 4);
      }
    }
    var dxA = sol.dxAir, dxN = sol.dxAir / n;
    strip(y0 + 48, lam0, '空気中（n ＝ 1）', 'Δx ＝ ' + (dxA * 1000).toFixed(2) + ' mm', '#8a5300');
    strip(y0 + 104, lam0 / n, '媒質の中（n ＝ ' + n.toFixed(2) + '）', 'Δx′ ＝ ' + (dxN * 1000).toFixed(2) + ' mm', LIQ_TXT);
    // O の位置（両方に共通）
    D.dashLine(ctx, vec(xL + bw / 2, y0 + 22), vec(xL + bw / 2, y0 + 128), '#9aa0a6', [3, 3], 1);
    ctx.font = D.font(10.5);
    ctx.fillStyle = '#6b7580';
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText('O', xL + bw / 2, y0 + 130);
    ctx.textAlign = 'left';
    ctx.fillText('横 ' + Math.round(sol.halfM * 2000) + ' mm ぶん', xR - 90, y0 + 130);
    ctx.restore();
  }

  /* ================= ステップの吹き出し ================= */
  function drawCallouts(ctx, st, sol, sc, lstep) {
    var n = st.medium.nSet;
    var y = 66;
    if (lstep === 1) {
      D.calloutAt(ctx, vec((L.S0X + L.GX) / 2, L.CY - 6), L.DIV + 20, y, [
        '① 屈折率 n の中では光の速さが c/n。振動数は変わらないので、',
        '　 波長が λ′ ＝ λ/n ＝ ' + Math.round(st.lambda0 / n) + ' nm に縮む（色は変わらない）。',
        '　 図の波が「こきざみ」になっているのはそのため。'
      ], { bg: '#eef7fd', border: '#1a7ab8', fg: '#1a3f5a' });
    } else if (lstep === 2) {
      D.calloutAt(ctx, sc.P, L.DIV + 20, y, [
        '② 経路差 ＝ d sinθ ≒ dx/L の式は、媒質の中でもまったく同じ。',
        '　 明線の条件は、λ を λ′ ＝ λ/n に置きかえるだけ：',
        '　 　d·x/L ＝ m·λ/n　　（薄膜のときと違って、m ＝ 0 は O のまま）'
      ], { bg: '#eef7fd', border: '#1a7ab8', fg: '#1a3f5a' });
    } else {
      var r = dxRange(sol, sc);
      var anchor = vec(L.SX - 24, r ? (r[0] + r[1]) / 2 : L.CY);
      D.calloutAt(ctx, anchor, L.DIV + 20, y, [
        '③ 明線の間隔　Δx′ ＝ λ′L/d ＝ λL/(nd) ＝ Δx/n',
        '　 いま Δx′ ＝ ' + (sol.dxApprox * 1000).toFixed(2) + ' mm（空気中は ' + (sol.dxAir * 1000).toFixed(2) + ' mm）。',
        '　 縞全体が O に向かって 1/n 倍に縮む（点線が空気中の明線の位置）。'
      ], { bg: '#eef7fd', border: '#1a7ab8', fg: '#1a3f5a' });
    }
  }

  /* ================= 本体 ================= */
  function render(ctx, st, sol, sc) {
    var md = st.medium;                          // {on, n, nSet, prog, inserted, anim}
    var lstep = P.clamp(st.lstep, 1, 3);

    D.panels(ctx);
    if (md.inserted) drawLiquidZoom(ctx, st, sol); else drawIntro(ctx, st);

    // ステップ③の Δx′ の寸法線と重なる目盛りの数字は飛ばす
    var skip = null;
    if (md.inserted && lstep === 3) {
      var r = dxRange(sol, sc);
      if (r) skip = [Math.min(r[0], r[1]) - 12, Math.max(r[0], r[1]) + 12];
    }
    var ph = YG.modePath.incoming(ctx, st, sol, sc, { dNote: false });
    YG.modePath.stage(ctx, st, sol, sc, { labels: true, skipRange: skip });
    if (md.on) airMarks(ctx, st, sol, sc);
    YG.modePath.rays(ctx, st, sol, sc, ph);
    YG.modePath.rayLabels(ctx, sc);
    YG.modePath.thetaMark(ctx, st, sol, sc, false);
    D.pointLabel(ctx, sc.P, 'P', 22, -12, '#8a3b00');
    D.pointLabel(ctx, vec(L.SX, L.CY), 'O', 22, 12, '#41505d');
    if (md.inserted && lstep === 3) dxDim(ctx, st, sol, sc);
    YG.modePath.observer(ctx, st, sol, sc);
    if (md.on) drawTank(ctx, st); else YG.modePath.waveNote(ctx);

    // 見出し・吹き出し
    if (md.inserted) {
      D.stepHeading(ctx, L.DIV + 20, 14, LSTEP_TITLES[lstep - 1]);
      if (st.showLabels) drawCallouts(ctx, st, sol, sc, lstep);
      compareBand(ctx, st, sol, sc);
    } else {
      D.stepHeading(ctx, L.DIV + 20, 14, md.anim ? '液体を満たしています…' : 'ふつうのヤングの実験装置（空気中）');
      if (!md.anim) {
        D.calloutAt(ctx, vec(L.SX, L.CY), L.DIV + 20, 66, [
          '明線の間隔は Δx ＝ λL/d ＝ ' + (sol.dxAir * 1000).toFixed(2) + ' mm。',
          '図の上の「屈折率 n の媒質（液体）の中に入れる」を押すと、',
          '装置がまるごと液体にしずみます。縞の間隔がどう変わるか見てみましょう。'
        ], { bg: '#eef7fd', border: '#1a7ab8', fg: '#1a3f5a' });
      }
      if (md.anim) compareBand(ctx, st, sol, sc);
    }
  }

  return { render: render, LSTEP_TITLES: LSTEP_TITLES, ANIM_SEC: ANIM_SEC,
    levelOf: levelOf, coverageOf: coverageOf, TANK: TANK };
})();
