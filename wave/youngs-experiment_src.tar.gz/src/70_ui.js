/* ===== 70_ui.js ===== */
/* UI：状態管理・スライダー・ボタン・数値表示・解説パネルの更新
 *
 * モードごとの状態の持ち方（前作で N′ がほかのモードに漏れた反省）
 *   ・設定（λ・d・L・単色/白色・見る方向・ステップ・薄膜の t と n′・チェック類）は
 *     すべて st.ms[モード名] に、モードごとに別々に持つ
 *   ・タブを行き来しても、そのモードで最後に決めた値がそのまま残る
 *   ・描画と計算には、毎フレーム組み立てなおした「view()」だけを渡す
 * 退避・復元をいっさいしないので、値がほかのモードへ漏れることが構造上ありえない。
 * （補足モードがいつも教科書どおりの d ＝ 0.20 mm・L ＝ 1.0 m から始まるのも、この作りのおかげ）
 */
window.YG = window.YG || {};
YG.ui = (function () {
  'use strict';
  var P = YG.phys, D = YG.draw;
  var L = D.L;

  var RANGE = {
    lambda: [380, 780], d: [100000, 500000], L: [0.50, 2.00],
    t: [0, 5000], n: [1.00, 1.80],
    nl: [1.00, 2.00]                       // 液体の屈折率（水 1.33、エタノール 1.36、グリセリン 1.47 …）
  };
  /* スクリーンに描く範囲の半分 [m]。既定の設定で m ＝ ±3 の明線（±9 mm）が写る程度。
     補足モードは m ＝ 0 の明線が下へ動くぶん、少し広くとる */
  var HALF_NORMAL = 0.011, HALF_FILM = 0.016;

  /** どのモードも同じ既定値から始める（値そのものはモードごとに別に持つ） */
  function baseSettings() {
    return {
      lambda: 600, d: 200000, L: 1.00, light: 'mono',
      showWave: true, showLabels: true
    };
  }
  function withBase(extra) {
    var o = baseSettings();
    for (var k in extra) { if (extra.hasOwnProperty(k)) o[k] = extra[k]; }
    return o;
  }

  var st = {
    mode: 'path',
    playing: false, slow: false, t: 0, nowSec: 0,
    pulse: null, hoverBtn: null, dragging: false, figFull: false,
    /* 設定はすべてここ。モードごとに完全に別。ここ以外には置かない */
    ms: {
      path: withBase({ step: 1, sinT: 0.003, m: 1, onlyBright: false }),
      // ②の素元波（同心円）は、ボタンで出したときだけ（既定は 1 次元の波だけが動く）
      wave: withBase({ sinT: 0.003, m: 1, onlyBright: false, showSum: true, showCirc: false }),
      deltax: withBase({ sinT: 0.003, m: 1, onlyBright: true, showAll: true }),
      // 補足（液体）：装置をまるごと屈折率 n の媒質に入れる。最初は空気中（inserted=false）。
      liquid: withBase({ lstep: 1, n: 1.30, sinT: 0.003, m: 1, onlyBright: true,
        inserted: false, anim: false, prog: 0 }),
      // 補足モードは、いつも m ＝ 0 の明線（＝ 薄膜で動く線）を見ている状態にしておく。
      // 薄膜は最初は入っていない（inserted=false）。ボタンで入れると anim → inserted。
      film: withBase({ fstep: 1, t: 2000, n: 1.50, sinT: 0, m: 0, onlyBright: true,
        inserted: false, anim: false, prog: 0 })
    }
  };

  function cur() { return st.ms[st.mode]; }
  function easeP(p) { return p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2; }

  /** そのモードの設定と、時刻などの共通の状態を合成した、描画・計算用のオブジェクト */
  function view() {
    var m = cur();
    var film = null, medium = null;
    var lambda = m.lambda;
    if (st.mode === 'film') {
      var on = !!(m.inserted || m.anim);
      var prog = m.inserted ? 1 : (m.anim ? P.clamp(m.prog, 0, 1) : 0);
      // 縞が動くのは「薄膜が光の道すじを横切っているあいだ」だけ：
      // 薄膜のふちが道すじに届くまでは t ＝ 0、まん中まで入ったら t そのもの
      var cov = m.inserted ? 1 : (YG.modeFilm ? YG.modeFilm.coverageOf(prog) : easeP(prog));
      film = { on: on, t: on ? m.t * cov : 0, tSet: m.t, n: m.n, prog: prog,
        inserted: !!m.inserted, anim: !!m.anim };
    }
    if (st.mode === 'liquid') {
      var onL = !!(m.inserted || m.anim);
      var progL = m.inserted ? 1 : (m.anim ? P.clamp(m.prog, 0, 1) : 0);
      // 液体が満ちていくあいだは、光の通り道が液面の下に入った割合ぶんだけ n を効かせる
      var covL = m.inserted ? 1 : (YG.modeLiquid ? YG.modeLiquid.coverageOf(progL) : easeP(progL));
      var nEff = onL ? 1 + (m.n - 1) * covL : 1;
      medium = { on: onL, n: nEff, nSet: m.n, prog: progL, inserted: !!m.inserted, anim: !!m.anim };
      lambda = m.lambda / nEff;               // 媒質の中の波長 λ/n（物理・波の描画はすべてこれ）
    }
    return {
      mode: st.mode, light: m.light,
      lambda: lambda, lambda0: m.lambda, d: m.d, L: m.L,
      medium: medium,
      t: st.t, nowSec: st.nowSec, playing: st.playing, slow: st.slow,
      pulse: st.pulse, hoverBtn: st.hoverBtn,
      showWave: m.showWave !== false, showLabels: m.showLabels !== false,
      step: m.step || 1, fstep: m.fstep || 1, lstep: m.lstep || 1,
      sinT: m.sinT, m: m.m, onlyBright: !!m.onlyBright,
      showSum: m.showSum !== false, showCirc: !!m.showCirc,
      showAll: m.showAll !== false,
      halfM: (st.mode === 'film') ? HALF_FILM : HALF_NORMAL,
      noDark: (st.mode === 'deltax'),
      film: film
    };
  }

  var el = {}, ctx = null, dpr = 1, lastFrame = 0;
  var lastStepKey = '', lastOrderKey = '';

  function $(id) { return document.getElementById(id); }

  /* ---------- canvas ---------- */
  function setupCanvas() {
    var c = $('view');
    var wide = (window.innerWidth >= 900);
    dpr = wide ? 4 : 3;
    c.width = L.W * dpr;
    c.height = L.H * dpr;
    c.style.aspectRatio = L.W + ' / ' + L.H;
    ctx = c.getContext('2d', { alpha: false });
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    if ('textRendering' in ctx) ctx.textRendering = 'geometricPrecision';
  }

  /* ---------- 描画 ---------- */
  function render() {
    var v = view();
    D.setLightColor(v.lambda0);                 // 光の色は空気中の波長で決まる
    var sol = P.solve(v);
    var sc = D.buildScene(v, sol);
    D.resetButtons();
    ctx.save();
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, L.W, L.H);

    if (v.mode === 'film' && YG.modeFilm) {
      YG.modeFilm.render(ctx, v, sol, sc);
    } else if (v.mode === 'liquid' && YG.modeLiquid) {
      YG.modeLiquid.render(ctx, v, sol, sc);
    } else if (v.mode === 'deltax' && YG.modeDeltax) {
      YG.modeDeltax.render(ctx, v, sol, sc);
    } else if (v.mode === 'wave' && YG.modeWave) {
      YG.modeWave.render(ctx, v, sol, sc);
    } else {
      YG.modePath.render(ctx, v, sol, sc);
    }
    if (v.mode === 'path' || v.mode === 'wave') {
      var glow = (v.mode === 'path') ? YG.modePath.pathGlow(v) : 0;
      D.unwrapBand(ctx, v, sol, glow);
    }
    ctx.restore();

    updateReadout(v, sol);
  }

  function loop(now) {
    var dt = lastFrame ? Math.min(0.05, (now - lastFrame) / 1000) : 0;
    lastFrame = now;
    st.nowSec += dt;
    if (st.playing) st.t += dt * (st.slow ? 0.25 : 1);
    // 補足モード：薄膜がすべりこむアニメーション
    var fm = st.ms.film;
    if (fm.anim) {
      fm.prog += dt / (YG.modeFilm ? YG.modeFilm.ANIM_SEC : 1.1);
      if (fm.prog >= 1) {
        fm.prog = 1; fm.anim = false; fm.inserted = true; fm.fstep = 1;
        syncAll();
      }
    }
    // 補足モード（液体）：液体が満ちていくアニメーション
    var lq = st.ms.liquid;
    if (lq.anim) {
      lq.prog += dt / (YG.modeLiquid ? YG.modeLiquid.ANIM_SEC : 2.0);
      if (lq.prog >= 1) {
        lq.prog = 1; lq.anim = false; lq.inserted = true; lq.lstep = 1;
        syncAll();
      }
    }
    render();
    requestAnimationFrame(loop);
  }

  /* ---------- 図の上での操作（スクリーンをクリック／ドラッグ） ---------- */
  function canvasPos(ev) {
    var c = $('view'), r = c.getBoundingClientRect();
    var pt = (ev.touches && ev.touches[0]) ? ev.touches[0] : ev;
    return { x: (pt.clientX - r.left) * L.W / r.width, y: (pt.clientY - r.top) * L.H / r.height };
  }
  function inScreenZone(pos) {
    return pos.x > L.SX - 60 && pos.x < L.SX + L.SCR_W + 90
      && pos.y > L.CY - L.SH - 10 && pos.y < L.CY + L.SH + 10;
  }
  /** スクリーン上の y から見る方向を決める */
  function setDirFromY(y) {
    var v = view();
    var sol = P.solve(v);
    var ppm = L.SH / v.halfM;
    var xm = (L.CY - y) / ppm;
    var s = P.sinThetaFromX(xm, v.L);
    var m = cur();
    if (m.onlyBright) {
      var best = null, cands = v.noDark ? sol.orders : sol.orders.concat(sol.darks);
      for (var i = 0; i < cands.length; i++) {
        if (!best || Math.abs(cands[i].sinT - s) < Math.abs(best.sinT - s)) best = cands[i];
      }
      if (best) { m.m = best.m; m.sinT = best.sinT; }
    } else {
      m.sinT = P.clamp(s, -sol.sEdge, sol.sEdge);
      m.m = Math.round((sol.extra + v.d * m.sinT) / v.lambda);
    }
    syncOrderBtns();
  }

  function bindPointer() {
    var c = $('view');
    function down(ev) {
      var pos = canvasPos(ev);
      var id = D.hitButton(pos.x, pos.y);
      if (id) {
        onCanvasButton(id);
        ev.preventDefault();
        return;
      }
      if (inScreenZone(pos)) {
        st.dragging = true;
        setDirFromY(pos.y);
        ev.preventDefault();
      }
    }
    function move(ev) {
      var pos = canvasPos(ev);
      if (st.dragging) { setDirFromY(pos.y); ev.preventDefault(); return; }
      var id = D.hitButton(pos.x, pos.y);
      st.hoverBtn = id;
      c.classList.toggle('grab', !!id || inScreenZone(pos));
    }
    function up() { st.dragging = false; }
    c.addEventListener('mousedown', down);
    c.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
    c.addEventListener('mouseleave', function () { st.hoverBtn = null; });
    c.addEventListener('touchstart', down, { passive: false });
    c.addEventListener('touchmove', move, { passive: false });
    window.addEventListener('touchend', up);
  }

  function onCanvasButton(id) {
    if (id.indexOf('glow:') === 0) {
      st.pulse = { kind: id.slice(5), t0: st.nowSec };
    } else if (id.indexOf('order:') === 0) {
      var mm = parseFloat(id.slice(6));
      var m = cur();
      m.m = mm;
      var v = view();
      var s = P.sinThetaOfOrder(mm, v.lambda, v.d, P.extraOf(v.film));
      if (s !== null) m.sinT = s;
      syncOrderBtns();
    }
  }

  /* ---------- タブ ---------- */
  var MODES = ['path', 'wave', 'deltax', 'liquid', 'film'];
  function setMode(mode) {
    if (MODES.indexOf(mode) < 0) return;
    st.mode = mode;
    MODES.forEach(function (k) {
      var b = $('tab-' + k);
      if (b) b.setAttribute('aria-selected', String(k === mode));
    });
    // 図の上：ステップ操作／Δx の欄／薄膜のステップ（薄膜のカードは syncFilmCards で）
    show('grp-path', mode === 'path');
    show('deltaxbox', mode === 'deltax');
    show('stepnow', mode === 'path');
    // 図の下：見る方向／薄膜の設定（液体の設定は syncLiquidCards で）
    show('dirbox', mode !== 'film');
    // ③はいつも明線の位置だけを選ぶ（m と m＋1 を比べるモードなので）
    show('lb-only', mode !== 'deltax');
    // 操作列（中身がないモードでは、帯ごと隠す）
    var anim = (mode === 'wave' || mode === 'film' || mode === 'liquid');
    show('grp-wave', anim);
    show('btn-circ', mode === 'wave');
    // 「取り除く」「取り出す」のボタンは、入れるアニメーションが終わってから出す（syncFilmCards / syncLiquidCards）
    show('toprow', anim);
    // ステップの説明
    show('steps', mode === 'path');
    show('wavenotes', mode === 'wave');
    show('deltaxnotes', mode === 'deltax');
    show('filmnotes', mode === 'film');
    show('liqnotes', mode === 'liquid');
    // チェックボックス
    show('lb-sum', mode === 'wave');
    show('lb-all', mode === 'deltax');
    show('lb-wave', mode === 'path');
    if (mode === 'deltax') st.ms.deltax.onlyBright = true;
    st.playing = anim ? st.playing : false;
    lastStepKey = ''; lastOrderKey = '';
    syncAll();
  }
  /** 補足モードのカード：薄膜が入る前は「入れる」ボタンのカードだけ、入ったら説明のカード */
  function syncFilmCards() {
    var fm = st.ms.film, on = (st.mode === 'film');
    show('filmintro', on && !fm.inserted && !fm.anim);
    show('grp-film', on && fm.inserted);
    show('filmstep', on && fm.inserted);
    show('filmbox', on && fm.inserted);
    show('filmnotes', on && fm.inserted);
    show('btn-remove', on && fm.inserted);
    var b = $('btn-insert');
    if (b) b.disabled = !!fm.anim;
  }
  /** 補足モード（液体）のカード：入れる前は「入れる」ボタンのカードだけ、入ったら説明のカード */
  function syncLiquidCards() {
    var lq = st.ms.liquid, on = (st.mode === 'liquid');
    show('liqintro', on && !lq.inserted && !lq.anim);
    show('grp-liquid', on && lq.inserted);
    show('liqstep', on && lq.inserted);
    show('liqbox', on && lq.inserted);
    show('liqnotes', on && lq.inserted);
    show('btn-drain', on && lq.inserted);
    var b = $('btn-dip');
    if (b) b.disabled = !!lq.anim;
  }
  function dipLiquid() {
    var lq = st.ms.liquid;
    if (lq.inserted || lq.anim) return;
    lq.anim = true; lq.prog = 0;
    st.playing = true;
    syncAll();
  }
  /** 液体から取り出して、補足モード（液体）を完全に最初の状態へもどす */
  function drainLiquid() {
    var lq = st.ms.liquid;
    lq.inserted = false; lq.anim = false; lq.prog = 0; lq.lstep = 1;
    lq.n = 1.30;
    lq.m = 1; lq.sinT = 0.003; lq.onlyBright = true;
    st.t = 0;
    syncAll();
  }
  function insertFilm() {
    var fm = st.ms.film;
    if (fm.inserted || fm.anim) return;
    fm.anim = true; fm.prog = 0;
    st.playing = true;
    syncAll();
  }
  /** 薄膜を取り除いて、補足モードを完全に最初の状態へもどす */
  function removeFilm() {
    var fm = st.ms.film;
    fm.inserted = false; fm.anim = false; fm.prog = 0; fm.fstep = 1;
    fm.t = 2000; fm.n = 1.50;
    fm.m = 0; fm.sinT = 0; fm.onlyBright = true;
    st.t = 0;
    syncAll();
  }
  function show(id, on) {
    var e = $(id);
    if (e) e.hidden = !on;
  }

  /* ---------- スライダー ---------- */
  function bindSlider(id, key, toState, fromState, after) {
    var s = $(id);
    if (!s) return;
    s.addEventListener('input', function () {
      toState(parseFloat(s.value));
      if (after) after();
      syncAll();
    });
  }
  function bindStep(idDown, idUp, get, set, delta) {
    var dn = $(idDown), up = $(idUp);
    if (dn) dn.addEventListener('click', function () { set(get() - delta); syncAll(); });
    if (up) up.addEventListener('click', function () { set(get() + delta); syncAll(); });
  }

  function setLambda(v) { cur().lambda = P.clamp(Math.round(v), RANGE.lambda[0], RANGE.lambda[1]); }
  function setD(v) { cur().d = P.clamp(Math.round(v / 5000) * 5000, RANGE.d[0], RANGE.d[1]); }
  function setL(v) { cur().L = P.clamp(Math.round(v * 20) / 20, RANGE.L[0], RANGE.L[1]); }
  function setT(v) { st.ms.film.t = P.clamp(Math.round(v / 50) * 50, RANGE.t[0], RANGE.t[1]); }
  function setN(v) { st.ms.film.n = P.clamp(Math.round(v * 100) / 100, RANGE.n[0], RANGE.n[1]); }
  function setNl(v) { st.ms.liquid.n = P.clamp(Math.round(v * 100) / 100, RANGE.nl[0], RANGE.nl[1]); }
  /** 屈折率の値から、身近な液体の名前を添える（目安） */
  function liquidName(n) {
    if (n < 1.005) return '（空気と同じ）';
    if (n >= 1.295 && n < 1.345) return '（水 ≒ 1.33）';
    if (n >= 1.345 && n < 1.375) return '（エタノール ≒ 1.36）';
    if (n >= 1.455 && n < 1.485) return '（グリセリン ≒ 1.47）';
    if (n >= 1.495 && n < 1.525) return '（ガラスなみ）';
    return '';
  }

  /* ---------- 「見る方向」ボタン ---------- */
  function syncOrderBtns() {
    var v = view();
    var sol = P.solve(v);
    var box = $('order-btns');
    if (!box) return;
    var key = sol.orders.map(function (o) { return o.m; }).join(',') + '|'
      + sol.darks.map(function (o) { return o.m; }).join(',') + '|' + st.mode;
    if (key !== lastOrderKey) {
      lastOrderKey = key;
      box.innerHTML = '';
      // 明線の行と暗線の行。本数が多いときは間引いて並べる
      function row(list, dark, label) {
        var wrap = document.createElement('div');
        wrap.className = 'ordrow';
        var lab = document.createElement('span');
        lab.className = 'ordlab';
        lab.textContent = label;
        wrap.appendChild(lab);
        var stepBy = Math.ceil(list.length / 13);
        for (var i = 0; i < list.length; i++) {
          if (stepBy > 1 && (Math.round(list[i].m - (dark ? 0.5 : 0)) % stepBy !== 0)) continue;
          (function (o) {
            var b = document.createElement('button');
            b.className = 'ctl ord' + (dark ? ' dark' : '');
            b.type = 'button';
            b.textContent = 'm = ' + o.m;
            b.setAttribute('data-m', String(o.m));
            b.addEventListener('click', function () {
              var m = cur();
              m.m = o.m; m.sinT = o.sinT;
              syncAll();
            });
            wrap.appendChild(b);
          })(list[i]);
        }
        box.appendChild(wrap);
      }
      row(sol.orders, false, '明線');
      if (!v.noDark) row(sol.darks, true, '暗線');   // ③は明線だけ
    }
    var btns = box.querySelectorAll('button');
    var selM = sol.sel ? sol.sel.m : null;
    for (var j = 0; j < btns.length; j++) {
      var mv = parseFloat(btns[j].getAttribute('data-m'));
      btns[j].setAttribute('aria-pressed', String(selM !== null && Math.abs(mv - selM) < 1e-9));
    }
  }

  /* ---------- ステップ ---------- */
  function setStep(n) {
    var m = cur();
    if (st.mode === 'film') {
      m.fstep = P.clamp(n, 1, 4);
      // ステップ③④は「m ＝ 0 の明線」の話なので、見る方向を m ＝ 0 にもどす
      if (m.fstep >= 3) { m.m = 0; m.sinT = 0; m.onlyBright = true; }
    } else if (st.mode === 'liquid') {
      m.lstep = P.clamp(n, 1, 3);
    } else {
      m.step = P.clamp(n, 1, 4);
    }
    syncAll();
  }
  function stepOf() {
    var m = cur();
    return (st.mode === 'film') ? m.fstep : ((st.mode === 'liquid') ? (m.lstep || 1) : (m.step || 1));
  }
  function stepMax() { return (st.mode === 'liquid') ? 3 : 4; }

  /** 図の上の「いまのステップ」カード（下のステップ一覧のミラー）
   *  毎フレーム作りなおすと :hover が効かなくなるので、変わったときだけ作りなおす */
  function syncStepNow() {
    if (st.mode !== 'path') return;
    var step = stepOf();
    var key = 'path:' + step;
    if (key === lastStepKey) return;
    lastStepKey = key;
    var src = document.querySelector('#steps .stepbox[data-step="' + step + '"]');
    if (!src) return;
    var title = src.querySelector('b'), body = src.querySelector('.sb'), fig = src.querySelector('.fig');
    $('sn-title').innerHTML = (title ? title.innerHTML : '') + '　<span class="mini">（' + step + ' / 4）</span>';
    $('sn-body').innerHTML = body ? body.innerHTML : '';
    var snf = $('sn-fig');
    if (fig) {
      snf.innerHTML = fig.innerHTML;
      snf.hidden = false;
      $('stepnow').classList.add('hasfig');
    } else {
      snf.innerHTML = '';
      snf.hidden = true;
      $('stepnow').classList.remove('hasfig');
    }
    var boxes = document.querySelectorAll('#steps .stepbox');
    for (var i = 0; i < boxes.length; i++) {
      boxes[i].classList.toggle('on', boxes[i].getAttribute('data-step') === String(step));
    }
    renderKatexIn($('stepnow'));
  }

  function syncFilmStep() {
    if (st.mode !== 'film') return;
    var s = stepOf();
    for (var i = 1; i <= 4; i++) {
      var e = $('fs' + i);
      if (!e) continue;
      e.classList.toggle('on', i === s);
      e.classList.toggle('dim', i > s);
    }
    $('fstep-label').textContent = 'ステップ ' + s + ' / 4';
  }

  function syncLiquidStep() {
    if (st.mode !== 'liquid') return;
    var s = stepOf();
    for (var i = 1; i <= 3; i++) {
      var e = $('ls' + i);
      if (!e) continue;
      e.classList.toggle('on', i === s);
      e.classList.toggle('dim', i > s);
    }
    txt('lstep-label', 'ステップ ' + s + ' / 3');
  }

  /* ---------- 数値表示 ---------- */
  function updateReadout(v, sol) {
    txt('r-theta', (sol.thetaDeg).toFixed(3) + ' °');
    txt('r-delta', Math.round(sol.delta) + ' nm');
    txt('r-ratio', (sol.ratio).toFixed(3) + ' λ');
    txt('r-x', D.fmtLenM(sol.x));
    txt('r-dx', D.fmtLenM(sol.dxApprox));
    txt('r-I', (sol.I).toFixed(3));
    var bar = $('bar-I');
    if (bar) bar.style.width = (sol.I * 100).toFixed(1) + '%';
    var vd = $('verdict');
    if (vd) {
      vd.textContent = sol.label;
      vd.className = 'verdict' + (sol.kind === 'strong' ? ' strong' : (sol.kind === 'weak' ? ' weak' : ''));
    }
    // ステップ一覧の数値
    txt('sv1', 'いま　d ＝ ' + D.fmtD(v.d) + '　L ＝ ' + v.L.toFixed(2) + ' m　→　L は d の約 '
      + Math.round(v.L / (v.d * 1e-9) / 100) * 100 + ' 倍');
    txt('sv2', 'いま　θ ＝ ' + sol.thetaDeg.toFixed(3) + '°　経路差 ＝ d sinθ ＝ ' + Math.round(sol.delta) + ' nm');
    txt('sv3', 'いま　経路差 ÷ λ ＝ ' + sol.ratio.toFixed(3) + '　→　' + sol.label);
    txt('sv4', 'いま　x ＝ ' + D.fmtLenM(sol.x) + '（m ＝ ' + sol.m + '）　Δx ≒ λL/d ＝ ' + D.fmtLenM(sol.dxApprox));
    // 図の上のミラー（#stepnow）の数値行だけは、毎フレーム文字を入れかえる
    // （DOM を作りなおすと :hover が効かなくなるので、textContent だけ更新する）
    if (v.mode === 'path') {
      var srcSv = document.getElementById('sv' + (v.step || 1));
      txt('sn-val', srcSv ? srcSv.textContent : '');
    }
    // 欄外：スクリーンの大きさの概算
    txt('screen-note', '※ 図のスクリーンは、たて約 ' + Math.round(v.halfM * 2000) + ' mm の範囲を表しています'
      + '（明線の間隔は約 ' + (sol.dxApprox * 1000).toFixed(1) + ' mm）。横方向（L）は、けた違いに長いので途中を省略しています。');
    // ③の Δx の検算
    if (v.mode === 'deltax' && sol.dxMeasured !== null) {
      txt('v-dx-meas', (sol.dxMeasured * 1000).toFixed(4) + ' mm');
      txt('v-dx-form', (sol.dxApprox * 1000).toFixed(4) + ' mm');
      var diff = Math.abs(sol.dxMeasured - sol.dxApprox) * 1e6;
      var e = $('v-dx-diff');
      if (e) {
        e.textContent = diff.toFixed(2) + ' μm（' +
          (100 * diff * 1e-6 / sol.dxApprox).toFixed(4) + ' %）';
        e.className = 'v ok';
      }
    }
    // 補足モード（液体）の数値
    if (v.mode === 'liquid') {
      txt('v-laml', Math.round(v.lambda0 / (v.medium ? v.medium.nSet : 1)) + ' nm');
      txt('v-dxl', (sol.dxAir / (v.medium ? v.medium.nSet : 1) * 1000).toFixed(2) + ' mm');
      txt('v-dx0', (sol.dxAir * 1000).toFixed(2) + ' mm');
      var lz = $('liq-zero');
      if (lz) lz.hidden = !(v.medium && v.medium.inserted && v.medium.nSet < 1.0001);
    }
    // 補足モードの数値
    if (v.mode === 'film') {
      txt('v-extra', Math.round(sol.extra) + ' nm');
      txt('v-x0', (sol.x0 * 1000).toFixed(3) + ' mm');
      var z = $('film-zero');
      if (z) z.hidden = !(sol.extra < 1e-9);
    }
    // 見る方向の説明
    var dn = $('dir-note');
    if (dn) {
      dn.innerHTML = '<span class="why">いま見ているのは θ ＝ <b>' + sol.thetaDeg.toFixed(3)
        + '°</b> の方向。経路差は <b>' + Math.round(sol.delta) + ' nm</b>＝ <b>' + sol.ratio.toFixed(2)
        + ' λ</b> なので、<span class="' + (sol.kind === 'strong' ? 'st' : (sol.kind === 'weak' ? 'wk' : ''))
        + '">' + sol.label + '</span>。</span>';
    }
    var on = $('ord-note');
    if (on) on.textContent = 'スクリーンに写る明線：m ＝ ' + (sol.orders.length ? (sol.orders[0].m + ' 〜 ' + sol.orders[sol.orders.length - 1].m) : '—');
  }
  function txt(id, s) { var e = $(id); if (e) e.textContent = s; }

  /* ---------- すべてを同期 ---------- */
  function syncAll() {
    var v = view(), m = cur();
    // スライダーの値
    val('sl-lambda', m.lambda); txt('v-lambda', String(m.lambda));
    val('sl-d', m.d); txt('v-d', (m.d / 1e6).toFixed(2));
    val('sl-L', m.L); txt('v-L', m.L.toFixed(2));
    txt('v-lamcol', '（' + P.colorName(m.lambda) + '色）');
    var sw = $('sw-lambda');
    if (sw) sw.style.background = P.rgbCss(P.wavelengthToRGB(m.lambda));
    txt('v-dnote', '（L / d ＝ ' + Math.round(m.L / (m.d * 1e-9) / 100) * 100 + ' 倍）');
    if (st.mode === 'film') {
      val('sl-t', m.t); txt('v-t', (m.t / 1000).toFixed(1));
      val('sl-n', m.n); txt('v-n', m.n.toFixed(2));
    }
    if (st.mode === 'liquid') {
      val('sl-nl', m.n); txt('v-nl', m.n.toFixed(2)); txt('v-nlname', liquidName(m.n));
    }
    // 単色／白色
    press('btn-mono', m.light === 'mono');
    press('btn-white', m.light === 'white');
    // チェック
    chk('ck-wave', m.showWave !== false);
    chk('ck-lab', m.showLabels !== false);
    chk('ck-sum', m.showSum !== false);
    chk('ck-all', m.showAll !== false);
    chk('ck-only', !!m.onlyBright);
    var lb = $('lb-only');
    if (lb) {
      lb.classList.toggle('on', !!m.onlyBright);
      txt('only-tap', m.onlyBright ? '現在、明線・暗線の位置だけを選べます' : '現在、明線・暗線もそれ以外も選べます');
    }
    // ステップ
    var s = stepOf();
    txt('step-label', 'ステップ ' + s + ' / 4');
    dis('btn-prev', s <= 1);
    dis('btn-lprev', s <= 1); dis('btn-lnext', s >= stepMax());
    // ①の最後のステップでは「次へ」が ③ へのジャンプになる（回折格子ページと同じ）
    var nb = $('btn-next');
    if (nb) { nb.disabled = false; nb.textContent = (st.mode === 'path' && s >= 4) ? '③ Δx を導く ▶' : '次へ ▶'; }
    dis('btn-fprev', s <= 1); dis('btn-fnext', s >= 4);
    syncStepNow();
    syncFilmStep();
    syncLiquidStep();
    syncFilmCards();
    syncLiquidCards();
    syncOrderBtns();
    // 再生ボタン
    var pb = $('btn-play');
    if (pb) pb.textContent = st.playing ? '⏸ 一時停止' : '▶ スタート';
    press('btn-slow', st.slow);
    press('btn-circ', !!m.showCirc);
  }
  function val(id, v) { var e = $(id); if (e) e.value = String(v); }
  function press(id, on) { var e = $(id); if (e) e.setAttribute('aria-pressed', String(!!on)); }
  function chk(id, on) { var e = $(id); if (e) e.checked = !!on; }
  function dis(id, on) { var e = $(id); if (e) e.disabled = !!on; }

  /* ---------- KaTeX ---------- */
  function renderKatexIn(root) {
    if (typeof katex === 'undefined' || !root) return;
    var list = root.querySelectorAll('.eq[data-tex]');
    for (var i = 0; i < list.length; i++) {
      var e = list[i];
      if (e.getAttribute('data-done') === '1') continue;
      try {
        katex.render(e.getAttribute('data-tex'), e, { throwOnError: false, displayMode: e.tagName === 'DIV' });
        e.setAttribute('data-done', '1');
      } catch (err) { /* 数式が描けなくても本文は読める */ }
    }
  }

  /* ---------- 組み立て ---------- */
  function bind() {
    MODES.forEach(function (k) {
      var b = $('tab-' + k);
      if (b) b.addEventListener('click', function () { setMode(k); });
    });

    bindSlider('sl-lambda', 'lambda', setLambda);
    bindSlider('sl-d', 'd', setD);
    bindSlider('sl-L', 'L', setL);
    bindSlider('sl-t', 't', setT);
    bindSlider('sl-n', 'n', setN);
    bindSlider('sl-nl', 'nl', setNl);
    bindStep('lam-dn', 'lam-up', function () { return cur().lambda; }, setLambda, 5);
    bindStep('d-dn', 'd-up', function () { return cur().d; }, setD, 5000);
    bindStep('L-dn', 'L-up', function () { return cur().L; }, setL, 0.05);
    bindStep('t-dn', 't-up', function () { return st.ms.film.t; }, setT, 50);
    bindStep('n-dn', 'n-up', function () { return st.ms.film.n; }, setN, 0.01);
    bindStep('nl-dn', 'nl-up', function () { return st.ms.liquid.n; }, setNl, 0.01);

    on('btn-mono', function () { cur().light = 'mono'; syncAll(); });
    on('btn-white', function () { cur().light = 'white'; syncAll(); });

    on('btn-prev', function () { setStep(stepOf() - 1); });
    on('btn-next', function () {
      if (st.mode === 'path' && stepOf() >= 4) setMode('deltax');
      else setStep(stepOf() + 1);
    });
    on('btn-step-reset', function () { setStep(1); });
    on('btn-fprev', function () { setStep(stepOf() - 1); });
    on('btn-fnext', function () { setStep(stepOf() + 1); });
    on('btn-freset', function () { setStep(1); });
    on('btn-insert', insertFilm);
    on('btn-remove', removeFilm);
    on('btn-lprev', function () { setStep(stepOf() - 1); });
    on('btn-lnext', function () { setStep(stepOf() + 1); });
    on('btn-lreset', function () { setStep(1); });
    on('btn-dip', dipLiquid);
    on('btn-drain', drainLiquid);

    on('btn-play', function () { st.playing = !st.playing; syncAll(); });
    on('btn-slow', function () { st.slow = !st.slow; syncAll(); });
    on('btn-reset', function () { st.t = 0; syncAll(); });
    on('btn-circ', function () { cur().showCirc = !cur().showCirc; syncAll(); });

    ck('ck-wave', function (v) { cur().showWave = v; });
    ck('ck-lab', function (v) { cur().showLabels = v; });
    ck('ck-sum', function (v) { cur().showSum = v; });
    ck('ck-all', function (v) { cur().showAll = v; });
    ck('ck-only', function (v) {
      var m = cur();
      m.onlyBright = v;
      if (v) {
        var sol = P.solve(view());
        var best = null, cands = sol.orders.concat(sol.darks);
        for (var i = 0; i < cands.length; i++) {
          if (!best || Math.abs(cands[i].sinT - m.sinT) < Math.abs(best.sinT - m.sinT)) best = cands[i];
        }
        if (best) { m.m = best.m; m.sinT = best.sinT; }
      }
    });

    var boxes = document.querySelectorAll('#steps .stepbox');
    for (var i = 0; i < boxes.length; i++) {
      (function (b) {
        b.addEventListener('click', function () { setStep(parseInt(b.getAttribute('data-step'), 10)); });
      })(boxes[i]);
    }

    on('btn-figfull', function () {
      st.figFull = !st.figFull;
      document.body.classList.toggle('fig-full', st.figFull);
      var b = $('btn-figfull');
      b.setAttribute('aria-pressed', String(st.figFull));
      b.textContent = st.figFull ? '✕ 閉じる' : '⛶ 図だけを大きく表示';
    });

    window.addEventListener('resize', function () { setupCanvas(); });
    bindProblem();
  }

  /* ---------- 入試問題の重ね窓（問題文／解答と解き方） ---------- */
  var probKind = 'q';
  function openProb(kind) {
    var ov = $('probov');
    if (!ov) return;
    probKind = kind;
    show('prob-q', kind === 'q');
    show('prob-a', kind === 'a');
    txt('probovTtl', kind === 'a' ? 'ヤングの実験と薄膜　解答と解き方' : 'ヤングの実験と薄膜　問題文');
    ov.hidden = false;
    ov.querySelector('.probov-body').scrollTop = 0;
    renderKatexIn(ov);
    var x = $('bProbClose');
    if (x) x.focus();
  }
  function closeProb() {
    var ov = $('probov');
    if (!ov || ov.hidden) return;
    ov.hidden = true;
    var b = $(probKind === 'a' ? 'bAns' : 'bProb');
    if (b) b.focus();
  }
  function bindProblem() {
    var ov = $('probov');
    if (!ov) return;
    on('bProb', function () { openProb('q'); });
    on('bAns', function () { openProb('a'); });
    on('bProbClose', closeProb);
    ov.addEventListener('click', function (e) { if (e.target === ov) closeProb(); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeProb(); });
  }
  function on(id, fn) { var e = $(id); if (e) e.addEventListener('click', fn); }
  function ck(id, fn) {
    var e = $(id);
    if (e) e.addEventListener('change', function () { fn(e.checked); syncAll(); });
  }

  function start() {
    setupCanvas();
    bind();
    bindPointer();
    renderKatexIn(document.body);
    setMode('path');
    requestAnimationFrame(loop);
  }

  return {
    start: start, st: st, view: view, setMode: setMode, setStep: setStep, render: render,
    renderKatexIn: renderKatexIn, insertFilm: insertFilm, removeFilm: removeFilm, syncAll: syncAll,
    dipLiquid: dipLiquid, drainLiquid: drainLiquid,
    openProb: openProb, closeProb: closeProb
  };
})();
