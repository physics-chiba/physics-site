/* ===== 30_physics.js ===== */
/* ヤングの実験の物理計算（純関数のみ。DOM に触らない ＝ 自動テストの対象）
 *
 * 単位の決め：
 *   λ・d・経路差・薄膜の厚さ t … nm
 *   L・x                      … m
 *   角度                       … rad（表示のときだけ度になおす）
 *
 * 装置の向き（図2・図3 に合わせる）
 *   S₁ が上、S₂ が下。スクリーン上の位置 x は O から S₁ 側（上）を正。
 *
 * 経路差（S₂ を通る道 － S₁ を通る道）
 *   薄膜なし   Δ = d sinθ                （x > 0 のとき S₂ 側が長い ＝ Δ > 0）
 *   薄膜あり   Δ = (n′−1)t + d sinθ      （S₀→S₂ の途中に厚さ t・屈折率 n′ の板）
 *
 * 明線：Δ = mλ　　暗線：Δ = (m + 1/2)λ
 * スクリーン上の位置は x = L tanθ（近似 x ≒ mλL/d ではなく、こちらで描く）
 */
window.YG = window.YG || {};
YG.phys = (function () {
  'use strict';

  var DEG = Math.PI / 180;

  function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }

  /* ---------- 薄膜による光路差の増分 ---------- */
  /** 厚さ t [nm]・屈折率 n′ の板を通ると、光学距離は n′t。空気のときより (n′−1)t [nm] 長くなる。 */
  function filmExtra(t, nf) { return (nf - 1) * t; }

  /**
   * いまの薄膜の設定から (n′−1)t [nm] を返す。
   * film が無い（null / off）ときは 0。t = 0 でも n′ = 1 でも 0 になる（＝もとの縞にもどる）。
   */
  function extraOf(film) {
    if (!film || !film.on) return 0;
    return filmExtra(film.t, film.n);
  }

  /* ---------- 角度・位置 ---------- */
  /** 経路差 Δ [nm] を与える方向の sinθ。Δ = (n′−1)t + d sinθ より */
  function sinThetaOfDelta(delta, d, extra) { return (delta - extra) / d; }

  /** m 次の明線の sinθ。存在しない（|sinθ| ≥ 1）ときは null */
  function sinThetaOfOrder(m, lambda, d, extra) {
    var s = (m * lambda - extra) / d;
    return (s > -1 && s < 1) ? s : null;
  }

  /** sinθ → θ [rad] */
  function thetaOfSin(s) { return Math.asin(clamp(s, -1, 1)); }

  /** スクリーン上の位置 x ＝ L tanθ [m]（近似ではなく tan の厳密値） */
  function xOnScreen(theta, L) { return L * Math.tan(theta); }

  /** スクリーン上の位置 x [m] → その方向の sinθ（厳密：x/√(x²+L²)） */
  function sinThetaFromX(x, L) { return x / Math.hypot(x, L); }

  /** m 次の明線のスクリーン上の位置 x [m]。存在しないときは null */
  function xOfOrder(m, lambda, d, L, extra) {
    var s = sinThetaOfOrder(m, lambda, d, extra);
    if (s === null) return null;
    return xOnScreen(thetaOfSin(s), L);
  }

  /** 近似式による m 次の明線の位置 x ≒ (mλ − (n′−1)t) L / d [m]（教科書の式・比較用） */
  function xOfOrderApprox(m, lambda, d, L, extra) {
    return (m * lambda - extra) * 1e-9 * L / (d * 1e-9);
  }

  /** 明線の間隔の近似式 Δx ≒ λL/d [m]（薄膜があっても変わらない） */
  function deltaXApprox(lambda, d, L) { return lambda * L / d; }

  /** 経路差 Δ [nm]（方向 θ・薄膜 extra [nm]） */
  function pathDiff(d, theta, extra) { return extra + d * Math.sin(theta); }

  /* ---------- 強度 ---------- */
  /**
   * 2 つのスリットによる干渉の強度比 I/I_max（0〜1）
   *   I(θ) = cos²( π Δ / λ ),  Δ = (n′−1)t + d sinθ
   * 回折格子（N 本）の I = (sin(Nβ)/(N sinβ))² で N = 2 としたものと同じ
   * （cos²β ＝ (sin2β/(2sinβ))²）。なだらかな縞になるのはこのため。
   */
  function intensity2(theta, d, lambda, extra) {
    var c = Math.cos(Math.PI * pathDiff(d, theta, extra) / lambda);
    return c * c;
  }

  /* ---------- 波 ---------- */
  /* 画面上の見かけの光速 [nm/s]。実際の c ではなく、波がゆっくり動いて見える速さ。 */
  var V_NM_PER_S = 520;

  /** 光路長 s [nm]・時刻 t [s] における波の位相 [rad] */
  function phaseAt(s, t, lambda) {
    return 2 * Math.PI * (s - V_NM_PER_S * t) / lambda;
  }
  /** 波の変位（振幅 1）。図の中の波も、下の展開バンドの波も、必ずこの関数から描く */
  function waveAt(s, t, lambda) { return Math.sin(phaseAt(s, t, lambda)); }

  /* ---------- 色 ---------- */
  /** 波長 [nm] → RGB（見た目用の近似） */
  function wavelengthToRGB(nm) {
    var R = 0, G = 0, B = 0;
    if (nm >= 380 && nm < 440) { R = -(nm - 440) / 60; B = 1; }
    else if (nm < 490) { G = (nm - 440) / 50; B = 1; }
    else if (nm < 510) { G = 1; B = -(nm - 510) / 20; }
    else if (nm < 580) { R = (nm - 510) / 70; G = 1; }
    else if (nm < 645) { R = 1; G = -(nm - 645) / 65; }
    else if (nm <= 780) { R = 1; }
    var f = 1;
    if (nm >= 380 && nm < 420) f = 0.3 + 0.7 * (nm - 380) / 40;
    else if (nm > 700 && nm <= 780) f = 0.3 + 0.7 * (780 - nm) / 80;
    var g = 0.8;
    function ch(x) { return Math.round(255 * Math.pow(Math.max(0, x) * f, g)); }
    return { r: ch(R), g: ch(G), b: ch(B) };
  }

  /** 波長 [nm] → 色の名前（高校の教科書でよく使う 7 区分） */
  var COLOR_NAMES = [
    { max: 435, name: '紫' },
    { max: 480, name: '青' },
    { max: 500, name: '青緑' },
    { max: 560, name: '緑' },
    { max: 590, name: '黄' },
    { max: 620, name: '橙' },
    { max: 1e9, name: '赤' }
  ];
  function colorName(nm) {
    for (var i = 0; i < COLOR_NAMES.length; i++) {
      if (nm < COLOR_NAMES[i].max) return COLOR_NAMES[i].name;
    }
    return '赤';
  }

  function rgbCss(c, a) {
    // 小数のままだと CSS の色として無効になり、指定が黙って効かなくなるので丸める
    var r = Math.round(c.r), g = Math.round(c.g), b = Math.round(c.b);
    return a === undefined
      ? 'rgb(' + r + ',' + g + ',' + b + ')'
      : 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')';
  }

  /* ===== 白色光の色計算（CIE 1931 等色関数の多ローブ近似：Wyman et al. 2013） ===== */
  function gauss(x, mu, s1, s2) {
    var t = (x - mu) / (x < mu ? s1 : s2);
    return Math.exp(-0.5 * t * t);
  }
  function cieX(l) {
    return 1.056 * gauss(l, 599.8, 37.9, 31.0)
      + 0.362 * gauss(l, 442.0, 16.0, 26.7)
      - 0.065 * gauss(l, 501.1, 20.4, 26.2);
  }
  function cieY(l) {
    return 0.821 * gauss(l, 568.8, 46.9, 40.5) + 0.286 * gauss(l, 530.9, 16.3, 31.1);
  }
  function cieZ(l) {
    return 1.217 * gauss(l, 437.0, 11.8, 36.0) + 0.681 * gauss(l, 459.0, 26.0, 13.8);
  }

  var LMIN = 380, LMAX = 780, LSTEP = 2;
  var WHITE_Y = (function () {
    var s = 0;
    for (var l = LMIN; l <= LMAX; l += LSTEP) s += cieY(l);
    return s;
  })();

  function xyzToSrgb(X, Y, Z) {
    var r = 3.2406 * X - 1.5372 * Y - 0.4986 * Z;
    var g = -0.9689 * X + 1.8758 * Y + 0.0415 * Z;
    var b = 0.0557 * X - 0.2040 * Y + 1.0570 * Z;
    function gam(u) {
      u = Math.max(0, Math.min(1, u));
      return Math.round(255 * (u <= 0.0031308 ? 12.92 * u : 1.055 * Math.pow(u, 1 / 2.4) - 0.055));
    }
    return { r: gam(r), g: gam(g), b: gam(b) };
  }

  /**
   * 白色光をあてたとき、スクリーン上の位置 x [m] に届く光の色。
   * 380〜780 nm の各波長について I(θ) を求め、CIE 等色関数で足しあわせる。
   * gain は表示用の明るさ（1 で「その場所の全波長ぶんの明るさ」）。
   * 薄膜の (n′−1)t は波長によらない長さなので、extra はそのまま渡す。
   */
  function spectrumColorAtX(x, d, L, extra, gain, nMed) {
    var th = Math.asin(clamp(sinThetaFromX(x, L), -1, 1));
    var X = 0, Y = 0, Z = 0;
    var nm = (nMed && nMed > 0) ? nMed : 1;   // 媒質の中では、どの色も波長が 1/n になる（色は変わらない）
    for (var l = LMIN; l <= LMAX; l += LSTEP) {
      var I = intensity2(th, d, l / nm, extra);
      X += I * cieX(l); Y += I * cieY(l); Z += I * cieZ(l);
    }
    var k = (gain === undefined ? 1 : gain) / WHITE_Y;
    return xyzToSrgb(X * k, Y * k, Z * k);
  }

  /* ---------- まとめ ---------- */
  /** 「強めあう」と言ってよい許容幅 [λ]。2 つのスリットの最初の暗点は 1/2 なので、その半分の半分 */
  var TOL = 0.125;

  /**
   * いまの設定から、描画・UI・テストが共通で使う値をまとめて求める。
   * st: { lambda, d, L, m, sinT, onlyBright, halfM, film:{on,t,n} }
   *   m は明線なら整数、暗線なら 0.5, 1.5, … の半整数（onlyBright のときの「ねらい」）
   *
   * halfM … スクリーンに描く範囲の半分 [m]（±20 mm なら 0.020）
   */
  function solve(st) {
    var lambda = st.lambda, d = st.d, L = st.L;   // lambda は「いまの媒質の中での波長」（液体なら λ₀/n）
    var extra = extraOf(st.film);
    var halfM = st.halfM;
    var nMed = (st.medium && st.medium.on) ? st.medium.n : 1;
    var lambda0 = st.lambda0 || lambda;

    // スクリーンに写る明線の一覧（画面の外は入れない）
    var orders = [];
    var sEdge = sinThetaFromX(halfM, L);            // 画面の端の方向
    // Δ = mλ が [extra − d·sEdge, extra + d·sEdge] に入る m を全部ひろう
    var mLo = Math.ceil((extra - d * sEdge) / lambda - 1e-9);
    var mHi = Math.floor((extra + d * sEdge) / lambda + 1e-9);
    // 念のため上限（λ が短く d が大きいと本数が増える）
    if (mHi - mLo > 400) mHi = mLo + 400;
    for (var k = mLo; k <= mHi; k++) {
      var s = sinThetaOfOrder(k, lambda, d, extra);
      if (s === null) continue;
      var th = thetaOfSin(s);
      orders.push({ m: k, sinT: s, theta: th, x: xOnScreen(th, L), dark: false });
    }
    // スクリーンに写る暗線の一覧（Δ ＝ (m + ½)λ。m の値は 0.5, 1.5, … と半整数で持つ）
    var darks = [];
    for (var kd = mLo - 1; kd <= mHi; kd++) {
      var sd = sinThetaOfOrder(kd + 0.5, lambda, d, extra);
      if (sd === null) continue;
      var thd = thetaOfSin(sd);
      var xd = xOnScreen(thd, L);
      if (Math.abs(xd) > halfM) continue;
      darks.push({ m: kd + 0.5, sinT: sd, theta: thd, x: xd, dark: true });
    }

    // 見る方向。「明線・暗線の位置のみ」のときは、いちばん近い明線か暗線の方向にそろえる。
    // 自由に選べるときは、逆に「いま何次の明線に近いか」を経路差から決める。
    var sinT, m, sel = null;
    // ③（Δx を導く）は明線どうしを比べるモードなので、暗線には吸着させない
    var cands = st.noDark ? orders.slice() : orders.concat(darks);
    if (st.onlyBright && cands.length) {
      var want = st.m, best = cands[0];
      for (var i = 0; i < cands.length; i++) {
        if (Math.abs(cands[i].m - want) < Math.abs(best.m - want)) best = cands[i];
      }
      sel = best; sinT = best.sinT;
      m = Math.round((extra + d * sinT) / lambda);
    } else {
      sinT = clamp(st.sinT, -sEdge, sEdge);
      m = Math.round((extra + d * sinT) / lambda);
    }
    var theta = thetaOfSin(sinT);

    var delta = pathDiff(d, theta, extra);    // 経路差 [nm]
    var ratio = delta / lambda;               // λ 何個ぶんか
    var x = xOnScreen(theta, L);              // スクリーン上の位置 [m]
    var I = intensity2(theta, d, lambda, extra);

    var gap = Math.abs(ratio - Math.round(ratio));
    var kind = (gap <= TOL) ? 'strong' : (I < 0.15 ? 'weak' : 'mid');
    // mid（明るさが中間）を「弱めあう」と言い切ると言い過ぎになるので、
    // 「完全には強めあわない」という事実だけを述べる表現にする
    var label = kind === 'strong' ? '強めあう' : (kind === 'weak' ? '弱めあう' : '完全には強めあわない');

    // 明線の間隔：隣りあう 2 本の実測（厳密な x）と、式の値
    var dxMeasured = null;
    if (orders.length >= 2) {
      // 画面の中央に近いところの隣りあう 2 本で測る
      var ci = 0;
      for (var j = 0; j < orders.length; j++) {
        if (Math.abs(orders[j].x) < Math.abs(orders[ci].x)) ci = j;
      }
      var cj = (ci + 1 < orders.length) ? ci + 1 : ci - 1;
      dxMeasured = Math.abs(orders[cj].x - orders[ci].x);
    }

    return {
      lambda: lambda, d: d, L: L, extra: extra, halfM: halfM,
      m: m, sinT: sinT, theta: theta, thetaDeg: theta / DEG,
      delta: delta, ratio: ratio, x: x, I: I,
      kind: kind, label: label,
      orders: orders, darks: darks,
      sel: sel,                               // 選んでいる明線・暗線（自由に選んでいるときは null）
      dxApprox: deltaXApprox(lambda, d, L),   // λL/d [m]
      dxMeasured: dxMeasured,                 // 図から測った間隔 [m]
      x0: xOfOrder(0, lambda, d, L, extra),   // m = 0 の明線の位置（薄膜で動く）
      x0Approx: xOfOrderApprox(0, lambda, d, L, extra),
      sEdge: sEdge,
      nMed: nMed, lambda0: lambda0,           // 媒質の屈折率と、空気中の波長
      dxAir: deltaXApprox(lambda0, d, L)      // 空気中での明線の間隔 λ₀L/d [m]（液体モードの比較用）
    };
  }

  return {
    DEG: DEG, clamp: clamp,
    filmExtra: filmExtra, extraOf: extraOf,
    sinThetaOfDelta: sinThetaOfDelta, sinThetaOfOrder: sinThetaOfOrder,
    thetaOfSin: thetaOfSin, xOnScreen: xOnScreen, sinThetaFromX: sinThetaFromX,
    xOfOrder: xOfOrder, xOfOrderApprox: xOfOrderApprox, deltaXApprox: deltaXApprox,
    pathDiff: pathDiff, intensity2: intensity2,
    V_NM_PER_S: V_NM_PER_S, phaseAt: phaseAt, waveAt: waveAt,
    wavelengthToRGB: wavelengthToRGB, colorName: colorName, rgbCss: rgbCss,
    spectrumColorAtX: spectrumColorAtX,
    TOL: TOL, solve: solve
  };
})();
