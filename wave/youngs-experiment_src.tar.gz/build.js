/* build.js
 * src/ に分けて書いたソースを、1 枚の HTML（youngs-experiment.html）に連結する。
 * KaTeX の CSS / JS は vendor/ に置いた「<style>…</style> / <script>…</script> ごと」の
 * ブロックをそのまま差しこむ（フォントは base64 で埋めこみずみ ＝ 外部通信 0）。
 *
 *   node build.js
 */
'use strict';
var fs = require('fs');
var path = require('path');

var ROOT = __dirname;
var SRC = path.join(ROOT, 'src');
var VENDOR = path.join(ROOT, 'vendor');
var OUT = path.join(ROOT, 'youngs-experiment.html');

function read(p) { return fs.readFileSync(p, 'utf8'); }

/* JS は番号順に連結する。番号を飛ばして足せるように、ディレクトリを読んで並べる。 */
var jsFiles = fs.readdirSync(SRC)
  .filter(function (f) { return /^\d+_.*\.js$/.test(f); })
  .sort();

if (!jsFiles.length) { throw new Error('src に .js が 1 つもありません'); }

var js = jsFiles.map(function (f) {
  return read(path.join(SRC, f));
}).join('\n\n');

/* 本文の {{fig:名前}} を src/fig_名前.svg の中身に置きかえる。
 * 図の SVG を本文に直接書くと 20_body.html が読めなくなるので、外に出しておく。 */
function inlineFigs(html) {
  return html.replace(/\{\{fig:([a-z0-9_]+)\}\}/g, function (_, name) {
    var p = path.join(SRC, 'fig_' + name + '.svg');
    if (!fs.existsSync(p)) throw new Error('図が見つかりません: ' + p);
    return read(p).trim();
  });
}

/* 公開用の共通フッター（アクセス数のカウント＋▶スタートを光らせるしくみ）。
 * 全ページ同じ内容（meter-bridge.html の src/99_footer.html と一字も同じ）。ここでは書きかえない。
 * file:// で開いたときはカウントを読みこまないので、オフライン利用・自動テストでは外部通信 0 のまま。 */
var FOOTER = read(path.join(SRC, '99_footer.html'));

/* CSS は番号順に連結する（10_style.css ＝ もとの見た目、12_shell.css ＝ meter-bridge.html と同じ骨組みと見た目、
 * 13_shell_page.css ＝ このページだけの調整）。 */
var cssFiles = fs.readdirSync(SRC)
  .filter(function (f) { return /^\d+_.*\.css$/.test(f); })
  .sort();
var css = cssFiles.map(function (f) { return read(path.join(SRC, f)); }).join('\n');

var out = ''
  + read(path.join(SRC, '00_head.html'))
  + read(path.join(VENDOR, 'katex.css.block')) + '\n\n'
  + '<style>\n' + css + '\n</style>\n'
  + '</head>\n<body id="top">\n'
  + inlineFigs(read(path.join(SRC, '20_body.html')))
  + '\n'
  + read(path.join(VENDOR, 'katex.js.block')) + '\n'
  + '<script>\n' + js + '\n</script>\n'
  + FOOTER + '\n'
  + '</body>\n</html>\n';

/* 外部を読みにいく書き方が混ざっていないか、ここで機械的に止める。
 * 唯一の例外は共通フッターの GoatCounter（アクセス数のカウント。https で開いたときだけ読む）。 */
var outCheck = out.replace(FOOTER, '');
/* 骨組みと共通フッターが入っていなければ失敗にする（作り直したときに落とさないため） */
['physics-chiba.goatcounter.com', 'sg-glow', 'buildSiteDrawer', 'id="hero"', 'id="tabs"', 'window.SHELL_CFG', 'id="modehead"'].forEach(function (k) {
  if (out.indexOf(k) < 0) { throw new Error('完全性チェックで失敗：' + k + ' がありません'); }
});
var bad = [
  [/<script[^>]+\bsrc\s*=/i, '<script src=…> が残っています'],
  [/<link[^>]+\bhref\s*=\s*["']?https?:/i, '外部の <link> が残っています'],
  [/<img[^>]+\bsrc\s*=\s*["']?https?:/i, '外部の <img> が残っています'],
  [/@import\s+url\(\s*["']?https?:/i, '外部の @import が残っています'],
  [/url\(\s*["']?https?:\/\//i, 'CSS から外部 URL を読んでいます']
];
bad.forEach(function (r) {
  if (r[0].test(outCheck)) { throw new Error('オフライン違反：' + r[1]); }
});

fs.writeFileSync(OUT, out, 'utf8');
console.log('書き出し: ' + path.basename(OUT)
  + '  ' + (Buffer.byteLength(out, 'utf8') / 1024).toFixed(0) + ' KB'
  + '  (JS: ' + jsFiles.join(', ') + ')');
