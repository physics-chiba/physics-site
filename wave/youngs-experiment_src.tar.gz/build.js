/* build.js
 * src/ に分けて書いたソースを、1 枚の HTML（youngs-experiment.html）に連結する。
 * KaTeX の CSS / JS は vendor/ に置いた「<style>…</style> / <script>…</script> ごと」の
 * ブロックをそのまま差しこむ（フォントは base64 で埋めこみずみ ＝ 外部通信 0）。
 *
 *   node build.js
 */
'use strict';
var fs = require('fs');
var path = require('path');

var ROOT = __dirname;
var SRC = path.join(ROOT, 'src');
var VENDOR = path.join(ROOT, 'vendor');
var OUT = path.join(ROOT, 'youngs-experiment.html');

function read(p) { return fs.readFileSync(p, 'utf8'); }

/* JS は番号順に連結する。番号を飛ばして足せるように、ディレクトリを読んで並べる。 */
var jsFiles = fs.readdirSync(SRC)
  .filter(function (f) { return /^\d+_.*\.js$/.test(f); })
  .sort();

if (!jsFiles.length) { throw new Error('src に .js が 1 つもありません'); }

var js = jsFiles.map(function (f) {
  return read(path.join(SRC, f));
}).join('\n\n');

/* 本文の {{fig:名前}} を src/fig_名前.svg の中身に置きかえる。
 * 図の SVG を本文に直接書くと 20_body.html が読めなくなるので、外に出しておく。 */
function inlineFigs(html) {
  return html.replace(/\{\{fig:([a-z0-9_]+)\}\}/g, function (_, name) {
    var p = path.join(SRC, 'fig_' + name + '.svg');
    if (!fs.existsSync(p)) throw new Error('図が見つかりません: ' + p);
    return read(p).trim();
  });
}

/* アクセス数のカウント（physics-site の各ページと同じ記述・Cookie なし） */
var GOATCOUNTER = '<!-- アクセス数のカウント（GoatCounter・Cookieなし） -->\n'
  + '<script data-goatcounter="https://physics-chiba.goatcounter.com/count"\n'
  + '        async src="//gc.zgo.at/count.js"></script>\n';

var out = ''
  + read(path.join(SRC, '00_head.html'))
  + read(path.join(VENDOR, 'katex.css.block')) + '\n\n'
  + '<style>\n' + read(path.join(SRC, '10_style.css')) + '\n</style>\n'
  + '</head>\n<body>\n'
  + inlineFigs(read(path.join(SRC, '20_body.html')))
  + '\n'
  + read(path.join(VENDOR, 'katex.js.block')) + '\n'
  + '<script>\n' + js + '\n</script>\n'
  + GOATCOUNTER
  + '</body>\n</html>\n';

/* 外部を読みにいく書き方が混ざっていないか、ここで機械的に止める。
 * 唯一の例外は GoatCounter（アクセス数のカウント）。physics-site の他のページと同じ 1 行で、
 * つながらなくてもページの動きには影響しない（async・失敗しても何も起きない）。 */
var outCheck = out.replace(GOATCOUNTER, '');
var bad = [
  [/<script[^>]+\bsrc\s*=/i, '<script src=…> が残っています'],
  [/<link[^>]+\bhref\s*=\s*["']?https?:/i, '外部の <link> が残っています'],
  [/<img[^>]+\bsrc\s*=\s*["']?https?:/i, '外部の <img> が残っています'],
  [/@import\s+url\(\s*["']?https?:/i, '外部の @import が残っています'],
  [/url\(\s*["']?https?:\/\//i, 'CSS から外部 URL を読んでいます']
];
bad.forEach(function (r) {
  if (r[0].test(outCheck)) { throw new Error('オフライン違反：' + r[1]); }
});

fs.writeFileSync(OUT, out, 'utf8');
console.log('書き出し: ' + path.basename(OUT)
  + '  ' + (Buffer.byteLength(out, 'utf8') / 1024).toFixed(0) + ' KB'
  + '  (JS: ' + jsFiles.join(', ') + ')');
