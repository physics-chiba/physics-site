/* =========================================================================
   86_shellcfg.js … このページの見出しの帯・章の扉・目次に出す文（87_shell.js が読む）
   タブの名前と並びは 20_body.html の <nav id="tabs"> に書いてある（ここは英字の副題とリードだけ）。
   ========================================================================= */
window.SHELL_CFG = {
  here: 'wave/Light-interference-thin-film.html',
  crumb: '薄膜の干渉',
  en: 'Thin-Film Interference',
  t1: '光の干渉',
  t2: '〜薄膜の場合〜',
  lead: '上から進んできた光が薄膜で 2 つに分かれ、強めあうか弱めあうかを確かめよう。まず波の動きを見て、そのあと経路差の作図と式へ進みます。',
  modes: {
    wave:   { en: 'Watching the Waves',
              lead: '薄膜の上の面で反射した光と、下の面で反射した光を、それぞれ 1 本の波として動かして見ます。山と山が重なれば強めあい、山と谷が重なれば弱めあいます。' },
    path:   { en: 'Where the Path Difference Appears',
              lead: '2 つの光の経路差が図のどこに現れるのかを、教科書と同じ作図で 4 つのステップに分けてたどり、光路差 2n₁d cos r の式まで進みます。' },
    bubble: { en: 'Why Thin Films Look Rainbow-Colored',
              lead: 'シャボン玉や油の膜が虹色に見えるのは、見る角度によって強めあう波長が変わるからです。白色光に切りかえて確かめよう。' }
  },
  secs: [
    { id: 'sec-purpose', name: 'このページの目的' },
    { id: 'sec-quiz', name: '練習問題' },
    { id: 'sec-more', name: '補足：もっと深く知りたい人へ' }
  ]
};
