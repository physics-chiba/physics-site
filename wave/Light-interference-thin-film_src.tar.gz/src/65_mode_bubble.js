/* ===== 65_mode_bubble.js ===== */
/* 「薄膜が虹色に見える原理」モード（m = 0 で考える）
 *
 *   強めあう条件 2n₁d cos r =(m + 1/2)λ  で m = 0 とおくと
 *        λ₀ = 4 n₁ d cos r
 *   これが「その角度でいちばん強く目に飛びこむ波長」。
 *   見る角度 i が変わると cos r が変わるので λ₀ が変わる ＝ 色が変わる ＝ 虹色。
 *   （内部のモードキーは 'bubble' のまま）
 */
window.TF = window.TF || {};
TF.modeBubble = (function () {
  'use strict';
  var D = TF.draw, P = TF.phys;
  var L = D.L;
  var JP = '"Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';

  /* ---- 配置 ---- */
  var CS = { surfY: 198, scale: 0.12, botMax: 268 };      // 断面図
  var SRC = { x: 30, y: 18 };                             // 光源
  var FAN = { thMin: 5, thMax: 60, n: 15, len: 150 };     // 扇の角度・本数・反射光の長さ
  var SEEN = { x: 424, y: 6, w: 268, h: 100 };            // 「見える色」パネル
  var GR = { x0: 76, x1: 664, y0: 308, y1: 648, iMax: 60, lamMin: 400, lamMax: 720 };
  /* 旧レイアウトとの互換（テスト等が参照する） */
  var STRIP = { x0: GR.x0, x1: GR.x1, thMax: GR.iMax };

  var cache = { key: '', map: null };

  function keyOf(st) {
    return [st.n1, st.n2, st.d].join('|');
  }

  /** m = 0（最低次）で強めあう波長。干渉しないときは null */
  function peak(st, thetaDeg) {
    if (!P.interferes(st.n1, st.n2)) return null;
    return P.peakLambda(st.d, st.n1, st.n2,
      thetaDeg === undefined ? st.theta : thetaDeg);
  }

  /** その角度の反射光の色 */
  function colorAt(st, thetaDeg) {
    if (!P.interferes(st.n1, st.n2)) {
      // 干渉しない：色はつかない（当てた光がそのまま弱く返るだけ）
      if (st.light === 'white') return { r: 205, g: 205, b: 205 };
      var c0 = P.wavelengthToRGB(st.lambda);
      return { r: Math.round(c0.r * 0.45), g: Math.round(c0.g * 0.45), b: Math.round(c0.b * 0.45) };
    }
    if (st.light !== 'white') {
      var I = P.intensityAt(st.lambda, st.d, st.n1, st.n2, thetaDeg);
      var c = P.wavelengthToRGB(st.lambda);
      return { r: Math.round(c.r * I), g: Math.round(c.g * I), b: Math.round(c.b * I) };
    }
    // 白色光：m = 0 で強めあう波長の色（可視域の外なら実際の混色にもどす）
    var pk = peak(st, thetaDeg);
    if (pk && pk.visible) return P.wavelengthToRGB(pk.lam);
    return P.whiteLightColor(st.d, st.n1, st.n2, thetaDeg, 1.0);
  }

  /* ---------------- 断面図＋扇 ---------------- */
  function filmPx(st) {
    return P.clamp(st.d * CS.scale, 3, CS.botMax - CS.surfY - 8);
  }

  function crossSection(ctx, st, sol) {
    var surfY = CS.surfY, dpx = filmPx(st), botY = surfY + dpx;
    var white = (st.light === 'white');

    // 背景
    ctx.save();
    ctx.fillStyle = '#eef3fa'; ctx.fillRect(0, 0, L.W, surfY);
    ctx.fillStyle = '#d7eef6'; ctx.fillRect(0, surfY, L.W, dpx);
    ctx.fillStyle = '#eceff3'; ctx.fillRect(0, botY, L.W, CS.botMax - botY);
    ctx.strokeStyle = '#6f8b97'; ctx.lineWidth = 1.3;
    ctx.beginPath(); ctx.moveTo(0, surfY + .5); ctx.lineTo(L.W, surfY + .5); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0, botY + .5); ctx.lineTo(L.W, botY + .5); ctx.stroke();
    ctx.font = '11.5px ' + JP; ctx.fillStyle = '#4a4a4a'; ctx.textBaseline = 'middle';
    ctx.fillText('空気', 8, surfY - 12);
    ctx.fillText('薄膜 n₁ = ' + st.n1.toFixed(2) + '　厚み d = ' + Math.round(st.d) + ' nm',
      8, botY + 15);
    ctx.fillText('下の物質 n₂ = ' + st.n2.toFixed(2), 8, botY + 32);
    ctx.restore();

    // 当たる点と角度
    var drop = surfY - SRC.y;
    var S = D.vec(SRC.x, SRC.y);
    var hit = [], i;
    for (i = 0; i < FAN.n; i++) {
      var th = FAN.thMin + (FAN.thMax - FAN.thMin) * i / (FAN.n - 1);
      var x = S.x + drop * Math.tan(th * Math.PI / 180);
      if (x > L.W - 150) continue;
      var thr = th * Math.PI / 180;
      var dir = D.vec(Math.sin(thr), -Math.cos(thr));
      var p = D.vec(x, surfY);
      hit.push({ th: th, p: p, dir: dir, end: D.add(p, D.mul(dir, FAN.len)) });
    }

    // 入射光（白色光／単色光）
    ctx.save();
    ctx.lineCap = 'round';
    for (i = 0; i < hit.length; i++) {
      ctx.strokeStyle = 'rgba(110,110,110,0.5)'; ctx.lineWidth = 3.4;
      ctx.beginPath(); ctx.moveTo(S.x, S.y); ctx.lineTo(hit[i].p.x, hit[i].p.y); ctx.stroke();
      ctx.strokeStyle = white ? 'rgba(255,255,255,0.95)'
        : P.rgbCss(P.wavelengthToRGB(st.lambda), 0.75);
      ctx.lineWidth = 1.8;
      ctx.beginPath(); ctx.moveTo(S.x, S.y); ctx.lineTo(hit[i].p.x, hit[i].p.y); ctx.stroke();
    }
    ctx.restore();

    // 反射光（その角度で強めあう色）。選んだ角度のものは最後に太く描く。
    // 選んだ 1 本は「扇の中でいちばん近いもの」ではなく、いま指定されている角度そのもので作る
    // （そうしないと、パネルの「見る角度 i」と太い光線の角度が最大 2°ほどずれる）
    var sel = null;
    var selTh = P.clamp(st.theta, 0, FAN.thMax);
    var selX = S.x + drop * Math.tan(selTh * Math.PI / 180);
    if (selX <= L.W - 150) {
      var selR = selTh * Math.PI / 180;
      var selDir = D.vec(Math.sin(selR), -Math.cos(selR));
      var selP = D.vec(selX, surfY);
      sel = { th: selTh, p: selP, dir: selDir, end: D.add(selP, D.mul(selDir, FAN.len)) };
    } else {
      var selD = 1e9;
      for (i = 0; i < hit.length; i++) {
        var dth = Math.abs(hit[i].th - st.theta);
        if (dth < selD) { selD = dth; sel = hit[i]; }
      }
    }
    // 選んだ角度の入射光も 1 本描く（扇の中になければ光源から線が出ていないように見えるため）
    if (sel && hit.indexOf(sel) === -1) {
      ctx.save();
      ctx.lineCap = 'round';
      ctx.strokeStyle = 'rgba(110,110,110,0.5)'; ctx.lineWidth = 3.4;
      ctx.beginPath(); ctx.moveTo(S.x, S.y); ctx.lineTo(sel.p.x, sel.p.y); ctx.stroke();
      ctx.strokeStyle = white ? 'rgba(255,255,255,0.95)'
        : P.rgbCss(P.wavelengthToRGB(st.lambda), 0.75);
      ctx.lineWidth = 1.8;
      ctx.beginPath(); ctx.moveTo(S.x, S.y); ctx.lineTo(sel.p.x, sel.p.y); ctx.stroke();
      ctx.restore();
    }
    function drawRefl(h, big) {
      ctx.save();
      ctx.lineCap = 'round';
      ctx.strokeStyle = 'rgba(70,70,70,0.85)'; ctx.lineWidth = big ? 8 : 5.2;
      ctx.beginPath(); ctx.moveTo(h.p.x, h.p.y); ctx.lineTo(h.end.x, h.end.y); ctx.stroke();
      ctx.strokeStyle = P.rgbCss(colorAt(st, h.th)); ctx.lineWidth = big ? 6 : 3.6;
      ctx.beginPath(); ctx.moveTo(h.p.x, h.p.y); ctx.lineTo(h.end.x, h.end.y); ctx.stroke();
      ctx.restore();
    }
    for (i = 0; i < hit.length; i++) if (hit[i] !== sel) drawRefl(hit[i], false);
    if (sel) drawRefl(sel, true);

    // 光源
    ctx.save();
    ctx.beginPath(); ctx.arc(S.x, S.y, 10, 0, Math.PI * 2);
    ctx.fillStyle = white ? '#ffffff' : P.rgbCss(P.wavelengthToRGB(st.lambda));
    ctx.fill();
    ctx.strokeStyle = '#555'; ctx.lineWidth = 1.8; ctx.stroke();
    ctx.font = 'bold 11.5px ' + JP; ctx.fillStyle = '#333'; ctx.textBaseline = 'top';
    ctx.fillText(white ? '白色光（いろいろな波長が混ざった光）'
      : 'λ = ' + Math.round(st.lambda) + ' nm（' + P.colorName(st.lambda) + '色）',
      S.x + 15, S.y - 6);
    ctx.restore();

    // 選んだ角度：入射角と反射角（｜｜ で等しいことを示す）＋観測者
    if (sel) {
      var thr2 = sel.th * Math.PI / 180;
      var rr = P.refractAngle(sel.th, st.n1);
      var scLike = { u: D.vec(Math.sin(thr2), Math.cos(thr2)), v: D.vec(Math.sin(rr), Math.cos(rr)) };
      if (sel.th < 1.8) {
        // 真上から見ているとき。共通の angleSet は断面図の位置（薄膜の説明文）に重なるので、
        // このモード用に短い名札だけを光線のそばに置く。
        ctx.save();
        ctx.font = 'bold 11.5px ' + JP;
        var zt = 'i = 0°（真上から見ている）';
        var zw = ctx.measureText(zt).width;
        D.roundRect(ctx, sel.p.x + 10, surfY - 40, zw + 14, 20, 6);
        ctx.fillStyle = 'rgba(255,255,255,0.92)'; ctx.fill();
        ctx.strokeStyle = '#b9c9de'; ctx.lineWidth = 1; ctx.stroke();
        ctx.fillStyle = '#1f5fa8';
        ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
        ctx.fillText(zt, sel.p.x + 17, surfY - 30);
        ctx.restore();
      } else {
        D.angleSet(ctx, scLike, { thetaRad: thr2 }, null, sel.p, null);
      }
      // 目は光線の延長線上に置く。「見える色」パネルに重なるときは手前へ下げる
      var t = FAN.len + 24;
      // 「見える色」パネル（右上）と、光源の名札（左上）のどちらにも重ならない位置まで手前へ下げる
      var hitsSeen = function (q) {
        return q.x > SEEN.x - 34 && q.y < SEEN.y + SEEN.h + 42;
      };
      var hitsSrc = function (q) {         // 見る角度 0° 付近で光源の λ 表示に重なるのを防ぐ
        return q.x < SRC.x + 215 && q.y < SRC.y + 52;
      };
      for (; t > 50; t -= 3) {
        var q = D.add(sel.p, D.mul(sel.dir, t));
        if (!hitsSeen(q) && !hitsSrc(q)) break;
      }
      var ep = D.add(sel.p, D.mul(sel.dir, t));
      ep = D.vec(P.clamp(ep.x, 26, L.W - 26), P.clamp(ep.y, 34, L.H - 26));
      D.eye(ctx, ep, D.mul(sel.dir, -1), 0.92, '見る方向');
    }
    seenColor(ctx, st, sol);

    // m = 0 の山の広さについての注意（誤解しやすいので図の中にも出す）
    if (P.interferes(st.n1, st.n2)) {
      ctx.save();
      ctx.font = '10.5px ' + JP; ctx.fillStyle = '#8a8a8a';
      ctx.textAlign = 'left'; ctx.textBaseline = 'top';
      ctx.fillText('※ m = 0 の山は幅がとても広いので、λ₀ から多少ずれた波長もかなり強く返ります'
        + '（だから薄い膜の色は、純色ではなく淡い色に見えます）。', 8, CS.botMax - 14);
      ctx.restore();
    }
  }

  /* ---------------- 「見える色」パネル ---------------- */
  function swatch(ctx, x, y, w, h, col) {
    ctx.fillStyle = P.rgbCss(col);
    ctx.fillRect(x, y, w, h);
    ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = 1;
    ctx.strokeRect(x + .5, y + .5, w - 1, h - 1);
  }

  function seenColor(ctx, st, sol) {
    var x = SEEN.x, y = SEEN.y, w = SEEN.w, h = SEEN.h;
    var pk = peak(st);
    ctx.save();
    D.roundRect(ctx, x, y, w, h, 9);
    ctx.fillStyle = '#20242a'; ctx.fill();
    ctx.strokeStyle = '#4a5158'; ctx.lineWidth = 1; ctx.stroke();
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';

    if (!pk) {
      ctx.fillStyle = '#eef0f3'; ctx.font = 'bold 12px ' + JP;
      ctx.fillText('この屈折率では反射が片方しか起きず、', x + 12, y + 26);
      ctx.fillText('干渉しません（色はつきません）。', x + 12, y + 48);
      ctx.restore(); return;
    }

    ctx.fillStyle = '#eef0f3'; ctx.font = 'bold 12px ' + JP;
    ctx.fillText('見る角度 i = ' + Math.round(st.theta) + '° のとき', x + 12, y + 8);

    if (st.light === 'white') {
      // 条件式 → λ₀
      ctx.font = '11.5px ' + JP; ctx.fillStyle = '#aeb6bf';
      ctx.fillText(pk.half
        ? 'm = 0：2n₁d cos r ＝ (1/2)λ'
        : 'm = 1：2n₁d cos r ＝ λ', x + 12, y + 28);

      ctx.font = 'bold 13px ' + JP; ctx.fillStyle = '#ffffff';
      ctx.fillText('λ₀ ＝ ' + (pk.half ? '4' : '2') + 'n₁d cos r', x + 12, y + 48);
      ctx.font = 'bold 15px ' + JP;
      ctx.fillText('＝ ' + Math.round(pk.lam) + ' nm', x + 12, y + 68);

      if (pk.visible) {
        swatch(ctx, x + w - 92, y + 46, 80, 34, P.wavelengthToRGB(pk.lam));
        ctx.font = '10px ' + JP; ctx.fillStyle = '#c9ced5'; ctx.textAlign = 'center';
        ctx.fillText('この色が目に入る', x + w - 52, y + 32);
      } else {
        ctx.font = '10.5px ' + JP; ctx.fillStyle = '#e0a0a0'; ctx.textAlign = 'center';
        ctx.fillText('可視光の外なので', x + w - 52, y + 46);
        ctx.fillText('色はつきません', x + w - 52, y + 62);
      }
      ctx.textAlign = 'left';
      ctx.restore();
      return;
    }

    // 単色光：λ₀ と、いま当てている λ をならべて比べる
    ctx.font = '11.5px ' + JP; ctx.fillStyle = '#aeb6bf';
    ctx.fillText('m = 0 で強めあう λ₀ ＝ ' + Math.round(pk.lam) + ' nm', x + 12, y + 30);
    ctx.fillStyle = '#eef0f3';
    ctx.fillText('いま当てている λ ＝ ' + Math.round(st.lambda) + ' nm', x + 12, y + 54);
    if (pk.visible) swatch(ctx, x + w - 76, y + 26, 64, 20, P.wavelengthToRGB(pk.lam));
    swatch(ctx, x + w - 76, y + 50, 64, 20, colorAt(st, st.theta));
    ctx.font = 'bold 12.5px ' + JP;
    ctx.fillStyle = (sol && sol.verdict.key === 'strong') ? '#8ee6a8'
      : ((sol && sol.verdict.key === 'weak') ? '#f0a09a' : '#e8d78a');
    ctx.fillText('→ ' + (sol ? sol.verdict.label : '')
      + (sol ? '（明るさ ' + Math.round(sol.I * 1000) / 10 + ' %）' : ''), x + 12, y + 76);
    ctx.restore();
  }

  /* ---------------- 角度 × 波長の強さマップ ---------------- */
  function buildMap(st) {
    var w = Math.round(GR.x1 - GR.x0), h = Math.round(GR.y1 - GR.y0);
    var cv = document.createElement('canvas');
    cv.width = w; cv.height = h;
    var g = cv.getContext('2d');
    var img = g.createImageData(w, h);
    var dat = img.data;
    var nf = P.flipCount(st.n1, st.n2);
    var ok = P.interferes(st.n1, st.n2);
    // 行ごとの波長と色をあらかじめ用意
    var lams = [], cols = [], k;
    for (k = 0; k < h; k++) {
      var lam = GR.lamMax - (GR.lamMax - GR.lamMin) * k / (h - 1);
      lams.push(lam); cols.push(P.wavelengthToRGB(lam));
    }
    for (var j = 0; j < w; j++) {
      var th = GR.iMax * j / (w - 1);
      var r = P.refractAngle(th, st.n1);
      var delta = P.opticalPathDiff(st.d, st.n1, r);
      for (k = 0; k < h; k++) {
        // 強めあう帯を見やすくするため、明るさは I を強調して描く（γ = 2.5）
        var I = ok ? Math.pow(P.intensityRatio(delta, lams[k], nf), 2.5) : 0;
        var c = cols[k];
        var o = (k * w + j) * 4;
        dat[o] = c.r * I; dat[o + 1] = c.g * I; dat[o + 2] = c.b * I; dat[o + 3] = 255;
      }
    }
    g.putImageData(img, 0, 0);
    return cv;
  }

  function ensureCache(st) {
    var key = keyOf(st);
    if (cache.key === key && cache.map) return;
    cache.key = key;
    cache.map = buildMap(st);
  }

  function gx(i) { return GR.x0 + (GR.x1 - GR.x0) * P.clamp(i / GR.iMax, 0, 1); }
  function gy(lam) {
    return GR.y1 - (GR.y1 - GR.y0) * P.clamp((lam - GR.lamMin) / (GR.lamMax - GR.lamMin), 0, 1);
  }

  /** λ₀ = λ となる見る角度 i [°]（無ければ null）。単色光モードで使う */
  function angleForLambda(st, lam) {
    var prev = null, prevV = 0;
    for (var th = 0; th <= GR.iMax; th += 0.25) {
      var pk = P.peakLambda(st.d, st.n1, st.n2, th);
      var v = pk.lam - lam;
      if (prev !== null && ((prevV >= 0 && v <= 0) || (prevV <= 0 && v >= 0))) {
        var t = (prevV === v) ? 0 : prevV / (prevV - v);
        return prev + t * 0.25;
      }
      prev = th; prevV = v;
    }
    return null;
  }

  function graph(ctx, st) {
    var x0 = GR.x0, x1 = GR.x1, y0 = GR.y0, y1 = GR.y1;
    var w = x1 - x0, h = y1 - y0;
    var ok = P.interferes(st.n1, st.n2);

    ctx.save();
    ctx.font = 'bold 12.5px ' + JP; ctx.fillStyle = '#1a4e86';
    ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
    ctx.fillText('見る角度 i と、m = 0 で強めあう波長 λ₀ ＝ 4n₁d cos r', x0, y0 - 9);

    ctx.drawImage(cache.map, 0, 0, cache.map.width, cache.map.height, x0, y0, w, h);
    ctx.strokeStyle = '#8a9099'; ctx.lineWidth = 1;
    ctx.strokeRect(x0 + .5, y0 + .5, w, h);

    // 目盛り
    ctx.font = '11px ' + JP; ctx.textBaseline = 'middle'; ctx.textAlign = 'right';
    for (var lv = GR.lamMin; lv <= GR.lamMax; lv += 50) {
      var yy = gy(lv);
      ctx.strokeStyle = 'rgba(255,255,255,.18)';
      ctx.beginPath(); ctx.moveTo(x0, yy); ctx.lineTo(x1, yy); ctx.stroke();
      ctx.fillStyle = '#5f6a72'; ctx.fillText(String(lv), x0 - 7, yy);
    }
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    for (var t = 0; t <= GR.iMax; t += 10) {
      ctx.fillStyle = '#5f6a72'; ctx.fillText(String(t), gx(t), y1 + 5);
    }
    ctx.fillText('見る角度 i [°]', (x0 + x1) / 2, y1 + 22);
    ctx.save();
    ctx.translate(x0 - 44, (y0 + y1) / 2); ctx.rotate(-Math.PI / 2);
    ctx.textBaseline = 'middle'; ctx.fillStyle = '#5f6a72';
    ctx.fillText('波長 λ [nm]', 0, 0);
    ctx.restore();

    if (!ok) {
      ctx.fillStyle = '#a12a1c'; ctx.font = 'bold 13px ' + JP;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText('干渉しない条件です（n₁ = 1.00、または n₂ = n₁）', (x0 + x1) / 2, (y0 + y1) / 2);
      ctx.restore(); return;
    }

    // λ₀(i) の曲線
    ctx.beginPath();
    for (var i = 0; i <= 120; i++) {
      var th = GR.iMax * i / 120;
      var pk = P.peakLambda(st.d, st.n1, st.n2, th);
      var px = gx(th), py = gy(pk.lam);
      if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
    }
    ctx.strokeStyle = 'rgba(0,0,0,.55)'; ctx.lineWidth = 4.6; ctx.stroke();
    ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 2; ctx.stroke();

    // 単色光：その波長の水平線と、強めあう角度
    if (st.light !== 'white') {
      var yl = gy(st.lambda);
      ctx.strokeStyle = 'rgba(255,255,255,.9)'; ctx.lineWidth = 1.4;
      ctx.setLineDash([5, 4]);
      ctx.beginPath(); ctx.moveTo(x0, yl); ctx.lineTo(x1, yl); ctx.stroke();
      ctx.setLineDash([]);
      var ia = angleForLambda(st, st.lambda);
      if (ia !== null) {
        var mx = gx(ia), my = gy(st.lambda);
        ctx.beginPath(); ctx.arc(mx, my, 5, 0, Math.PI * 2);
        ctx.fillStyle = '#fff'; ctx.fill();
        ctx.strokeStyle = '#222'; ctx.lineWidth = 1.4; ctx.stroke();
        label(ctx, mx, my - 26, 'λ = ' + Math.round(st.lambda) + ' nm が強めあうのは i = '
          + ia.toFixed(0) + '°', '#fff', '#222');
      }
    }

    // いまの角度
    var pkNow = P.peakLambda(st.d, st.n1, st.n2, st.theta);
    var cx = gx(st.theta), cy = gy(pkNow.lam);
    ctx.strokeStyle = 'rgba(255,255,255,.85)'; ctx.lineWidth = 1.6;
    ctx.beginPath(); ctx.moveTo(cx, y0); ctx.lineTo(cx, y1); ctx.stroke();
    if (pkNow.lam >= GR.lamMin && pkNow.lam <= GR.lamMax) {
      ctx.beginPath(); ctx.arc(cx, cy, 6.5, 0, Math.PI * 2);
      ctx.fillStyle = P.rgbCss(P.wavelengthToRGB(pkNow.lam)); ctx.fill();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.stroke();
      label(ctx, cx, cy + (cy < y0 + 40 ? 26 : -26),
        'i = ' + Math.round(st.theta) + '° → λ₀ = ' + Math.round(pkNow.lam) + ' nm',
        '#222', '#fff');
    }
    ctx.restore();
  }

  /** 小さなラベル（中央そろえ） */
  function label(ctx, cx, cy, text, bg, fg) {
    ctx.save();
    ctx.font = 'bold 11.5px ' + JP;
    var w = ctx.measureText(text).width + 14;
    var x = P.clamp(cx - w / 2, GR.x0 + 2, GR.x1 - w - 2);
    D.roundRect(ctx, x, cy - 10, w, 20, 5);
    ctx.fillStyle = bg; ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.lineWidth = 1; ctx.stroke();
    ctx.fillStyle = fg; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(text, x + w / 2, cy);
    ctx.restore();
  }

  function render(ctx, st, sol) {
    ensureCache(st);
    ctx.save();
    ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, L.W, L.H);
    crossSection(ctx, st, sol);
    graph(ctx, st);
    ctx.font = '11px ' + JP; ctx.fillStyle = '#8a8a8a';
    ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
    ctx.fillText('※ 見る角度 i が大きいほど cos r は小さくなり、λ₀ ＝ 4n₁d cos r も短くなる（赤 → 青へ）。',
      10, L.H - 22);
    ctx.fillText('　 角度ごとにちがう色が目に届くので、1 枚の薄膜が虹色に見えます。', 10, L.H - 6);
    ctx.restore();
  }

  return {
    render: render, CS: CS, FAN: FAN, GR: GR, STRIP: STRIP,
    colorAt: colorAt, angleForLambda: angleForLambda,
    invalidate: function () { cache.key = ''; }
  };
})();

