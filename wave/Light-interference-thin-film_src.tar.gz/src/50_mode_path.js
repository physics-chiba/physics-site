/* ===== 50_mode_path.js ===== */
/* 光路差モード：波は止めたまま、経路差 → 光路差 → 位相変化 → 条件式 を段階表示する */
window.TF = window.TF || {};
TF.modePath = (function () {
  'use strict';
  var D = TF.draw, P = TF.phys;
  var L = D.L, COL = D.COL;
  var HI_GEO = '#0f9d58';   // 経路差 B₂C + CB₁ のハイライト
  var HI_EQ = '#d35400';    // 光路が等しい 2 区間（A₁B₁ と A₂B₂）
  var FONT = '12px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';

  var STEPS = [
    { id: 1, title: '① 経路差を求める' },
    { id: 2, title: '② 光路差になおす' },
    { id: 3, title: '③ 反射による位相の変化を調べる' },
    { id: 4, title: '④ 干渉の条件式を立てる' }
  ];

  /** ステップ n の吹き出しが「いま出たばかり」なら 1 → 0 に減る強さを返す */
  function stepAmt(st, n) {
    var sp = st.stepPulse;
    if (!sp || sp.step !== n) return 0;
    return D.pulseAmount({ kind: 'step', t0: sp.t0 }, 'step', st.nowSec || 0);
  }

  /** ① のあいだ、経路差の緑ハイライトをときどき自動で光らせる */
  function autoPathPulse(st) {
    var per = 3.6, ph = ((st.nowSec || 0) % per) / per;   // 0〜1
    return ph < 0.45 ? 0.85 * Math.sin(ph / 0.45 * Math.PI) : 0;
  }

  function thick(ctx, pts, color, width) {
    ctx.save();
    ctx.strokeStyle = color; ctx.lineWidth = width || 5;
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.globalAlpha = 0.72;
    ctx.beginPath();
    ctx.moveTo(pts[0].x, pts[0].y);
    for (var i = 1; i < pts.length; i++) ctx.lineTo(pts[i].x, pts[i].y);
    ctx.stroke();
    ctx.restore();
  }

  function thickConn(ctx, c, color, width) {
    var mid = D.mul(D.add(c.from, c.to), 0.5);
    var d = D.sub(c.to, c.from);
    var l = D.len(d) || 1;
    var n = D.nrmOf(D.vec(d.x / l, d.y / l));
    var ctrl = D.add(mid, D.mul(n, c.bulge));
    ctx.save();
    ctx.strokeStyle = color; ctx.lineWidth = width || 5;
    ctx.lineCap = 'round'; ctx.globalAlpha = 0.72;
    ctx.beginPath();
    ctx.moveTo(c.from.x, c.from.y);
    ctx.quadraticCurveTo(ctrl.x, ctrl.y, c.to.x, c.to.y);
    ctx.stroke();
    ctx.restore();
  }

  /**
   * 教科書（図 88）の作図。
   *   A₁A₂ … 入射波の波面／B₁B₂ … 屈折波の波面
   *   A₁B₁（空気）と A₂B₂（薄膜）は光路が等しいので、B₁B₂ 上で光①と光②は同位相。
   *   D は下面に関する B₁ の対称点。∠CDB₁ = r、B₁D = 2d、∠B₂ = 90° なので
   *   経路差 = B₂C + CB₁ = B₂C + CD = B₂D = B₁D cos r = 2d cos r
   */
  function construction(ctx, st, sol, sc, withOptical) {
    var p = sc.pts;
    var lab = st.showLabels;

    D.dashLine(ctx, p.A1, p.A2, '#8e6bb5', [6, 4], 1.6);
    if (lab) D.rightAngle(ctx, p.A1, sc.u, D.mul(D.nrmOf(sc.u), -1), 9, '#8e6bb5');
    D.dashLine(ctx, p.B1, p.B2, '#8e6bb5', [6, 4], 1.6);
    if (lab) D.rightAngle(ctx, p.B2, sc.v, D.nrmOf(sc.v), 9, '#8e6bb5');
    D.dashLine(ctx, p.C, p.D, '#7a7a7a', [4, 4], 1.2);
    D.dashLine(ctx, p.B1, p.D, '#7a7a7a', [4, 4], 1.4);

    if (lab) {
      // ∠CDB₁ = r（屈折角と同じ ｜ 印）
      var ar = Math.atan2(-sc.v.y, -sc.v.x);      // D → B₂ の向き
      D.tickArc(ctx, p.D, ar, -Math.PI / 2, 40, D.COL_R, 'r', 1);

      // B₁D = 2d の寸法
      var xd = p.D.x + 26;
      D.dashLine(ctx, p.B1, D.vec(xd + 6, p.B1.y), '#7a7a7a', [3, 3], 1);
      D.dashLine(ctx, p.D, D.vec(xd + 6, p.D.y), '#7a7a7a', [3, 3], 1);
      var h2d = p.D.y - p.B1.y;
      D.arrow(ctx, D.vec(xd, p.B1.y), D.vec(0, 1), h2d, '#5a5a5a', 1.3, 6);
      D.arrow(ctx, D.vec(xd, p.D.y), D.vec(0, -1), h2d, '#5a5a5a', 1.3, 6);
      ctx.save();
      ctx.font = D.font(12.5, true); ctx.fillStyle = '#3a3a3a';
      ctx.textBaseline = 'middle';
      ctx.fillText('2d', xd + 8, (p.B1.y + p.D.y) / 2);
      ctx.restore();

      ctx.save();
      ctx.font = '11.5px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
      ctx.fillStyle = '#6d4a92'; ctx.textBaseline = 'bottom';
      ctx.fillText('入射波の波面', p.A1.x - 84, p.A1.y - 6);
      ctx.fillText('屈折波の波面', p.B2.x - 88, p.B2.y - 4);
      ctx.restore();
    }

    thick(ctx, [p.B2, p.C], HI_GEO, 6);
    thick(ctx, [p.C, p.B1], HI_GEO, 6);

    if (withOptical) {
      thick(ctx, [p.A1, p.B1], HI_EQ, 4);
      thick(ctx, [p.A2, p.B2], HI_EQ, 4);
    }

    if (lab) {
      D.pointLabel(ctx, p.A1, 'A₁', -15, -12);
      D.pointLabel(ctx, p.A2, 'A₂', -16, -12);
      D.pointLabel(ctx, p.B1, 'B₁', 15, -12);
      D.pointLabel(ctx, p.B2, 'B₂', -17, 6);
      D.pointLabel(ctx, p.C, 'C', -14, 14);
      D.pointLabel(ctx, p.D, 'D', 13, 12);
    }
  }

  function render(ctx, st, sol, sc, step) {
    var lg = sc.legs;
    var t = 0; // 時間を止める
    var A = L.AMP;
    var noInt = sol.noInterference;
    var a1Alpha = sol.reflects.top ? 1 : 0.14;
    var a2Alpha = sol.reflects.bottom ? 1 : 0.14;

    D.background(ctx, st, sc);
    D.thicknessHandle(ctx, sc, !!st.dragHot);
    if (sc.dpx > 6) D.thicknessDim(ctx, sc, st);

    TF.modeWave.axis(ctx, lg.i1, 0.55 * a1Alpha);
    TF.modeWave.axis(ctx, lg.i2, 0.55);
    TF.modeWave.axis(ctx, lg.f1, 0.55);
    TF.modeWave.axis(ctx, lg.f2, 0.55 * a2Alpha);
    TF.modeWave.axis(ctx, lg.o1, 0.55 * a1Alpha);
    TF.modeWave.axis(ctx, lg.o2, 0.55 * a2Alpha);

    D.waveLine(ctx, lg.i1, st, t, A, { width: 2, alpha: 0.78 * a1Alpha });
    D.waveLine(ctx, lg.i2, st, t, A, { width: 2, alpha: 0.78 });
    D.waveLine(ctx, lg.f1, st, t, A, { width: 2, alpha: 0.78 });
    D.waveLine(ctx, lg.f2, st, t, A, { width: 2, alpha: 0.78 * a2Alpha });
    D.waveLine(ctx, lg.o1, st, t, A, { width: 1.9, alpha: 0.7 * a1Alpha });
    D.waveLine(ctx, lg.o2, st, t, A, { width: 1.9, alpha: 0.7 * a2Alpha });

    for (var k = 0; k < sc.conns.length; k++) {
      if (k === 0 && !sol.reflects.top) continue;
      if (k === 1 && !sol.reflects.bottom) continue;
      D.curveConn(ctx, sc.conns[k]);
    }

    if (st.showWavefront) {
      D.wavefronts(ctx, lg.i1, st, t, 12, { alpha: 0.5 * a1Alpha });
      D.wavefronts(ctx, lg.i2, st, t, 12, { alpha: 0.5 });
      D.wavefronts(ctx, lg.f1, st, t, 12, { alpha: 0.5 });
      D.wavefronts(ctx, lg.f2, st, t, 12, { alpha: 0.5 * a2Alpha });
    }

    if (st.showVelocity) {
      TF.modeWave.velocity(ctx, lg.i2, 'c', 0.30, 38);
      TF.modeWave.velocity(ctx, lg.f1, 'c/n₁', 0.55, 38);
      TF.modeWave.velocity(ctx, lg.i1, 'c', 0.30, -38);
      // 反射したあと（膜の中の上り・空気中へ出ていく 2 本）も同じように描く
      TF.modeWave.velocity(ctx, lg.f2, 'c/n₁', 0.42, -30);
      TF.modeWave.velocity(ctx, lg.o2, 'c', 0.62, 24);
      TF.modeWave.velocity(ctx, lg.o1, 'c', 0.62, -24);
    }

    D.sourceMark(ctx, sc, st);        // 光源は背面（重なったらバッジやボタンが上に見える）
    if (!noInt) TF.modeWave.observer(ctx, st, sol, sc);

    if (st.showLabels) angles(ctx, st, sol, sc);
    var oblique = (sc.offK < 0.02 && sol.thetaRad > 0.02);

    // ①②の起点は、緑でハイライトしている経路差の「ちょうど真ん中」
    var anchor = oblique
      ? midOfPath([sc.pts.B2, sc.pts.C, sc.pts.B1])
      : D.vec((lg.f1.a.x + lg.f2.b.x) / 2, (sc.surfY + sc.bottomY) / 2);
    var y1 = Math.min(sc.bottomY + 22, L.BAND_Y - 148);   // ①
    var y2 = y1 + 72;                                 // ②（①の下）

    if (step >= 1) {
      if (oblique) {
        construction(ctx, st, sol, sc, true);
        D.calloutAbs(ctx, anchor, 'left', y1,
          ['① 経路差 ＝ B₂C + CB₁ ＝ B₂D',
            '　 ∠B₂ = 90°、∠CDB₁ = r、B₁D = 2d',
            '　 → 2d cos r ＝ ' + fmt(sol.geomPath) + ' nm'],
          { border: HI_GEO, fg: '#0b5c34' });
      } else {
        thick(ctx, [lg.f1.a, lg.f1.b], HI_GEO, 6);
        thick(ctx, [lg.f2.a, lg.f2.b], HI_GEO, 6);
        if (st.showLabels) {
          D.pointLabel(ctx, D.vec(sc.xc, sc.surfY), 'A₂=B₁=B₂', 0, -14);
          D.pointLabel(ctx, sc.dpts.Cdown, 'C', -14, 14);
        }
        D.calloutAbs(ctx, anchor, 'left', y1,
          ['① 経路差 ＝ B₂C + CB₁ ＝ 2d cos r',
            '　 i = 0° では単純な往復',
            '　 → 2d ＝ ' + fmt(sol.geomPath) + ' nm'],
          { border: HI_GEO, fg: '#0b5c34' });
      }
    }

    if (step >= 2) {
      var box2 = D.calloutAbs(ctx, anchor, 'left', y2,
        ['② 光路差 ＝ n₁ ×（経路差）',
          '　 ＝ 2 n₁ d cos r ＝ ' + fmt(sol.delta) + ' nm',
          '　 ＝ ' + sol.ratio.toFixed(2) + ' × λ'],
        { border: '#444', fg: '#222', noLeader: true });
      D.boxGlow(ctx, box2, stepAmt(st, 2));
    }

    if (step >= 3) piMarks(ctx, st, sol, sc, y1, y2);
    if (step >= 4 && !noInt) conditionBadge(ctx, st, sol, sc);

    TF.modeWave.highlightButtons(ctx, st, sc, sol,
      (step === 1) ? autoPathPulse(st) : 0);
    rayLabels(ctx, sc);
    TF.modeWave.offsetNote(ctx, sc);
    D.unwrapBand(ctx, st, sol, sc);
    stepTitle(ctx, step);
    if (noInt) D.noInterferenceBanner(ctx, sol);
  }

  /** 入射角 i・反射角 i・屈折角 r（共通部品） */
  function angles(ctx, st, sol, sc) {
    D.angleSet(ctx, sc, sol, sc.dpts.A2, sc.dpts.B1refl, sc.dpts.B1);
  }

  function piMarks(ctx, st, sol, sc, y1, y2) {
    // ①② は左、π の 2 つは右。上下 2 段にそろえて重ならないようにする
    var b1 = D.piCallout(ctx, sc.refl1Pt, 'right', y1,
      '③ 上面 B₁ での反射 (1 → n₁)', sol.flips.top);
    var b2 = D.piCallout(ctx, sc.dpts.Cdown, 'right', y2,
      '③ 下面 C での反射 (n₁ → n₂)', sol.flips.bottom);
    var amt = stepAmt(st, 3);
    D.boxGlow(ctx, b1, amt); D.boxGlow(ctx, b2, amt);
  }

  function conditionBadge(ctx, st, sol, sc) {
    var half = (sol.kind === 'half');
    var lines = [
      '④ 干渉の条件式（π ずれ ' + sol.nFlip + ' 回 → 正味 ' + (sol.nFlip % 2) + ' 回）',
      half ? '強めあう： 2n₁d cos r = (m + 1/2) λ' : '強めあう： 2n₁d cos r = m λ',
      half ? '弱めあう： 2n₁d cos r = m λ' : '弱めあう： 2n₁d cos r = (m + 1/2) λ',
      'いまは ' + sol.ratio.toFixed(2) + ' λ → ' + sol.verdict.label
    ];
    ctx.save();
    ctx.font = '12px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
    var w = 0;
    for (var i = 0; i < lines.length; i++) w = Math.max(w, ctx.measureText(lines[i]).width);
    var bw = w + 18, bh = lines.length * 16 + 14;
    // 右上へ。出射光線を深めに切ってあるので、目や観測者バッジとは重ならない
    var bx = L.W - bw - 10, by = 6;
    D.roundRect(ctx, bx, by, bw, bh, 7);
    ctx.fillStyle = 'rgba(255,255,255,0.94)'; ctx.fill();
    ctx.strokeStyle = '#444'; ctx.lineWidth = 1.2; ctx.stroke();
    ctx.textBaseline = 'top';
    for (var j = 0; j < lines.length; j++) {
      ctx.fillStyle = (j === 0) ? '#1a4e86' : '#222';
      ctx.font = (j === 0 ? 'bold 12.5px ' : '12px ')
        + '"Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
      ctx.fillText(lines[j], bx + 9, by + 8 + j * 16);
    }
    ctx.restore();
    D.boxGlow(ctx, { x: bx, y: by, w: bw, h: bh }, stepAmt(st, 4));
  }

  function stepTitle(ctx, step) {
    var s = STEPS[P.clamp(step, 1, 4) - 1];
    ctx.save();
    ctx.font = 'bold 14px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
    var w = ctx.measureText(s.title).width + 22;
    D.roundRect(ctx, 10, 12, w, 26, 6);
    ctx.fillStyle = 'rgba(255,255,255,0.92)'; ctx.fill();
    ctx.strokeStyle = '#c8c8c8'; ctx.stroke();
    ctx.fillStyle = '#333'; ctx.textBaseline = 'middle';
    ctx.fillText(s.title, 21, 25);
    ctx.restore();
  }

  /** 光線の説明を、境界面の近く（光線1＝右、光線2＝左）に置く */
  function rayLabels(ctx, sc) {
    var y = sc.surfY - 44;
    ctx.save();
    ctx.font = 'bold 12.5px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
    ctx.textBaseline = 'middle';

    var t2 = '光線2：薄膜・下の物質の境界で反射した光';
    var w2 = ctx.measureText(t2).width;
    ctx.fillStyle = 'rgba(255,255,255,0.88)';
    ctx.fillRect(8, y - 9, w2 + 30, 18);
    ctx.strokeStyle = COL.ray2; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(12, y); ctx.lineTo(32, y); ctx.stroke();
    ctx.fillStyle = '#12447a'; ctx.fillText(t2, 38, y);

    var t1 = '光線1：空気-薄膜の境界で反射した光';
    var w1 = ctx.measureText(t1).width;
    var x1 = L.W - w1 - 38;
    ctx.fillStyle = 'rgba(255,255,255,0.88)';
    ctx.fillRect(x1 - 26, y - 9, w1 + 34, 18);
    ctx.strokeStyle = COL.ray1; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(x1 - 22, y); ctx.lineTo(x1 - 2, y); ctx.stroke();
    ctx.fillStyle = '#7a2b12'; ctx.fillText(t1, x1 + 4, y);
    ctx.restore();
  }

  /** 折れ線の「長さの半分」の位置を返す */
  function midOfPath(pts) {
    var total = 0, i;
    for (i = 1; i < pts.length; i++) total += D.len(D.sub(pts[i], pts[i - 1]));
    var half = total / 2, acc = 0;
    for (i = 1; i < pts.length; i++) {
      var seg = D.len(D.sub(pts[i], pts[i - 1]));
      if (acc + seg >= half) {
        var f = seg > 0 ? (half - acc) / seg : 0;
        return D.vec(pts[i - 1].x + (pts[i].x - pts[i - 1].x) * f,
          pts[i - 1].y + (pts[i].y - pts[i - 1].y) * f);
      }
      acc += seg;
    }
    return pts[pts.length - 1];
  }

  function fmt(v) { return (Math.round(v * 10) / 10).toFixed(1); }

  return { render: render, STEPS: STEPS };
})();

