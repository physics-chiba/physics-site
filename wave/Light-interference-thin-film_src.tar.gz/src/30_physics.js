/* ===== 30_physics.js ===== */
/* 薄膜干渉の物理計算（純関数のみ。DOM に触らない＝自動テストの対象） */
window.TF = window.TF || {};
TF.phys = (function () {
  'use strict';

  var DEG = Math.PI / 180;
  var N0 = 1.0; // 上側（空気）の屈折率

  function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }

  /** 膜内の屈折角 r [rad]  sinθ = n1 sin r */
  function refractAngle(thetaDeg, n1) {
    return Math.asin(clamp(Math.sin(thetaDeg * DEG) / n1, -1, 1));
  }

  /**
   * 経路差 [nm]（教科書 図 88 の定義）
   *   屈折波の波面 B₁B₂ から先を比べるので
   *   経路差 = B₂C + CB₁ = B₂C + CD = B₂D = 2d cos r
   *   （A₁B₁（空気）と A₂B₂（薄膜）は光路が等しいので、そこまでは同位相）
   *   薄膜内の道のり 2d/cos r ではないことに注意。
   */
  function geomPath(d, rRad) {
    return 2 * d * Math.cos(rRad);
  }

  /** 参考：薄膜の中を実際に進む長さ A₂C + CB₁ = 2d / cos r  [nm] */
  function filmPathLength(d, rRad) {
    return 2 * d / Math.cos(rRad);
  }

  /** 光路差 = n₁ ×（経路差）= 2 n1 d cos r  [nm] */
  function opticalPathDiff(d, n1, rRad) {
    return n1 * geomPath(d, rRad);
  }

  /** 反射での位相反転（屈折率が小→大の反射で π ずれる） */
  function flips(n1, n2) {
    return { top: n1 > N0, bottom: n2 > n1 };
  }

  function flipCount(n1, n2) {
    var f = flips(n1, n2);
    return (f.top ? 1 : 0) + (f.bottom ? 1 : 0);
  }

  /** 2 波の位相差 δ [rad] = 2π・光路差/λ + (π ずれの回数)・π */
  function phaseDiff(delta, lambda, nFlip) {
    return 2 * Math.PI * delta / lambda + (nFlip % 2) * Math.PI;
  }

  /** 等振幅 2 波の合成強度比 I/Imax = cos^2(δ/2)  (0〜1) */
  function intensityRatio(delta, lambda, nFlip) {
    var c = Math.cos(phaseDiff(delta, lambda, nFlip) / 2);
    return c * c;
  }

  /** 強めあう条件式が m λ か (m+1/2)λ か */
  function conditionKind(nFlip) {
    // π ずれが奇数回 → 強めあう条件は (m+1/2)λ
    return (nFlip % 2 === 1) ? 'half' : 'integer';
  }

  /** 反射がそもそも起こるか（屈折率が同じ境界では反射しない＝干渉しない） */
  function reflects(n1, n2) {
    return { top: Math.abs(n1 - N0) > 1e-6, bottom: Math.abs(n2 - n1) > 1e-6 };
  }
  function interferes(n1, n2) {
    var f = reflects(n1, n2);
    return f.top && f.bottom;
  }

  /**
   * 判定ラベル。
   * 「光路差が条件式の値から λ の ±5%（＝ ±0.05λ）以内なら、ぴったりと見なす」
   * という 1 つの基準で決める。膜厚を合わせるボタンの強調もこれと同じ基準を使うので、
   * 観測者バッジとボタンの判定がずれることはない。
   */
  var TOL = 0.05;          // 許容するずれ [λ]

  /** 光路差が、強めあう／弱めあう条件から λ 何個ぶんずれているか */
  function conditionGap(delta, lambda, nFlip, want) {
    var ratio = delta / lambda;
    var half = (nFlip % 2 === 1);
    var base = (want === 'weak') ? (half ? 0.0 : 0.5) : (half ? 0.5 : 0.0);
    var m = Math.round(ratio - base);
    if (m + base < 0) m = Math.ceil(-base);
    return Math.abs(ratio - (m + base));
  }

  function verdict(delta, lambda, nFlip, noInt) {
    if (noInt) return { key: 'none', label: '干渉しない', I: 0 };
    var I = intensityRatio(delta, lambda, nFlip);
    if (conditionGap(delta, lambda, nFlip, 'strong') <= TOL) {
      return { key: 'strong', label: '強めあう', I: I };
    }
    if (conditionGap(delta, lambda, nFlip, 'weak') <= TOL) {
      return { key: 'weak', label: '弱めあう', I: I };
    }
    if (I >= 0.5) return { key: 'mid-strong', label: 'やや強めあう', I: I };
    return { key: 'mid-weak', label: 'やや弱めあう', I: I };
  }

  /**
   * ちょうど強めあう / 弱めあう膜厚 d [nm] のうち、
   * 現在の d に最も近く [dMin, dMax] に入るものを返す（無ければ null）。
   * want: 'strong' | 'weak'
   */
  function targetThickness(want, dNow, lambda, n1, n2, thetaDeg, dMin, dMax) {
    var r = refractAngle(thetaDeg, n1);
    var k = 2 * n1 * Math.cos(r);
    if (!(k > 0)) return null;
    var nFlip = flipCount(n1, n2);
    var half = (nFlip % 2 === 1);
    // 強めあう: δ = 2πm → delta/λ = m - nFlip/2
    // 弱めあう: δ = (2m+1)π → delta/λ = m + 1/2 - nFlip/2
    var base = half ? 0.5 : 0.0;         // 強めあうときの delta/λ の小数部
    if (want === 'weak') base = half ? 0.0 : 0.5;
    var best = null, bestDiff = Infinity;
    for (var m = 0; m <= 40; m++) {
      var ratio = m + base;
      if (ratio <= 0) continue;
      var d = ratio * lambda / k;
      if (d < dMin - 1e-9 || d > dMax + 1e-9) continue;
      var diff = Math.abs(d - dNow);
      if (diff < bestDiff) { bestDiff = diff; best = d; }
    }
    return best;
  }

  /**
   * 強めあう／弱めあう膜厚 d [nm] のうち
   *   nearest … いまの d にいちばん近いもの
   *   next    … その次数 m を 1 つ増やしたもの
   * を返す（範囲外なら null）。
   *   強めあう：delta/λ = m + base、base は π ずれが正味 1 回なら 0.5、0 回なら 0
   *   弱めあう：その逆
   */
  function thicknessSet(want, dNow, lambda, n1, n2, thetaDeg, dMin, dMax) {
    var r = refractAngle(thetaDeg, n1);
    var k = 2 * n1 * Math.cos(r);
    if (!(k > 0)) return { nearest: null, next: null };
    var half = (flipCount(n1, n2) % 2 === 1);
    var base = (want === 'weak') ? (half ? 0.0 : 0.5) : (half ? 0.5 : 0.0);
    function dOf(m) { return (m + base) * lambda / k; }
    function ok(d) { return d >= dMin - 1e-9 && d <= dMax + 1e-9; }
    // いまの d にいちばん近い次数（範囲に入るものの中から）
    var best = null, bestDiff = Infinity;
    for (var m = 0; m <= 200; m++) {
      if (m + base <= 0) continue;             // 厚さ 0 は意味がない
      var d = dOf(m);
      if (d > dMax + 1e-9) break;
      if (!ok(d)) continue;
      var diff = Math.abs(d - dNow);
      if (diff < bestDiff) { bestDiff = diff; best = { m: m, d: d }; }
    }
    var next = null;
    if (best) {
      var m2 = best.m + 1, d2 = dOf(m2);
      if (ok(d2)) next = { m: m2, d: d2 };
    }
    return { nearest: best, next: next };
  }

  /**
   * いちばん低い次数（＝いちばん長い波長）で強めあう波長 λ₀ [nm]。
   *   π ずれが正味 1 回：2n₁d cos r =(m + 1/2)λ → m = 0 で λ₀ = 4n₁d cos r
   *   π ずれが正味 0 回：2n₁d cos r = mλ      → m = 0 は無意味なので m = 1、λ₀ = 2n₁d cos r
   * 次数が上がるほど λ は短くなるので、m = 0（または 1）の波長がいちばん目に入りやすい。
   */
  function peakLambda(d, n1, n2, thetaDeg) {
    var r = refractAngle(thetaDeg, n1);
    var delta = opticalPathDiff(d, n1, r);
    var half = (flipCount(n1, n2) % 2 === 1);
    var m = half ? 0 : 1;
    var lam = delta / (m + (half ? 0.5 : 0));
    return {
      lam: lam, m: m, half: half, delta: delta,
      visible: (lam >= LMIN && lam <= LMAX)
    };
  }

  /** 波長 [nm] → 表示色 (可視域の近似スペクトル) */
  function wavelengthToRGB(nm) {
    var R = 0, G = 0, B = 0;
    if (nm >= 380 && nm < 440) { R = -(nm - 440) / 60; B = 1; }
    else if (nm < 490) { G = (nm - 440) / 50; B = 1; }
    else if (nm < 510) { G = 1; B = -(nm - 510) / 20; }
    else if (nm < 580) { R = (nm - 510) / 70; G = 1; }
    else if (nm < 645) { R = 1; G = -(nm - 645) / 65; }
    else if (nm <= 780) { R = 1; }
    var f = 1;
    if (nm >= 380 && nm < 420) f = 0.3 + 0.7 * (nm - 380) / 40;
    else if (nm > 700 && nm <= 780) f = 0.3 + 0.7 * (780 - nm) / 80;
    var g = 0.8;
    function ch(x) { return Math.round(255 * Math.pow(Math.max(0, x) * f, g)); }
    return { r: ch(R), g: ch(G), b: ch(B) };
  }

  /** 波長 [nm] → 色の名前（高校の教科書でよく使う 7 区分） */
  var COLOR_NAMES = [
    { max: 435, name: '紫' },
    { max: 480, name: '青' },
    { max: 500, name: '青緑' },
    { max: 560, name: '緑' },
    { max: 590, name: '黄' },
    { max: 620, name: '橙' },
    { max: 1e9, name: '赤' }
  ];
  function colorName(nm) {
    for (var i = 0; i < COLOR_NAMES.length; i++) {
      if (nm < COLOR_NAMES[i].max) return COLOR_NAMES[i].name;
    }
    return '赤';
  }

  function rgbCss(c, a) {
    return a === undefined
      ? 'rgb(' + c.r + ',' + c.g + ',' + c.b + ')'
      : 'rgba(' + c.r + ',' + c.g + ',' + c.b + ',' + a + ')';
  }

  /* ===== 白色光の色計算（CIE 1931 等色関数の多ローブ近似：Wyman et al. 2013） ===== */
  function gauss(x, mu, s1, s2) {
    var t = (x - mu) / (x < mu ? s1 : s2);
    return Math.exp(-0.5 * t * t);
  }
  function cieX(l) {
    return 1.056 * gauss(l, 599.8, 37.9, 31.0)
      + 0.362 * gauss(l, 442.0, 16.0, 26.7)
      - 0.065 * gauss(l, 501.1, 20.4, 26.2);
  }
  function cieY(l) {
    return 0.821 * gauss(l, 568.8, 46.9, 40.5) + 0.286 * gauss(l, 530.9, 16.3, 31.1);
  }
  function cieZ(l) {
    return 1.217 * gauss(l, 437.0, 11.8, 36.0) + 0.681 * gauss(l, 459.0, 26.0, 13.8);
  }

  var LMIN = 380, LMAX = 780, LSTEP = 5;
  var WHITE_Y = (function () {
    var s = 0;
    for (var l = LMIN; l <= LMAX; l += LSTEP) s += cieY(l);
    return s;
  })();

  function xyzToSrgb(X, Y, Z) {
    var r = 3.2406 * X - 1.5372 * Y - 0.4986 * Z;
    var g = -0.9689 * X + 1.8758 * Y + 0.0415 * Z;
    var b = 0.0557 * X - 0.2040 * Y + 1.0570 * Z;
    function gam(u) {
      u = Math.max(0, Math.min(1, u));
      return Math.round(255 * (u <= 0.0031308 ? 12.92 * u : 1.055 * Math.pow(u, 1 / 2.4) - 0.055));
    }
    return { r: gam(r), g: gam(g), b: gam(b) };
  }

  /** 波長 λ における反射光の強度比（0〜1） */
  function intensityAt(lambda, d, n1, n2, thetaDeg) {
    var r = refractAngle(thetaDeg, n1);
    var delta = opticalPathDiff(d, n1, r);
    return intensityRatio(delta, lambda, flipCount(n1, n2));
  }

  /** 白色光を当てたときに見える反射光の色（equal-energy 白色を仮定） */
  function whiteLightColor(d, n1, n2, thetaDeg, gain) {
    var X = 0, Y = 0, Z = 0;
    var r = refractAngle(thetaDeg, n1);
    var delta = opticalPathDiff(d, n1, r);
    var nf = flipCount(n1, n2);
    for (var l = LMIN; l <= LMAX; l += LSTEP) {
      var I = intensityRatio(delta, l, nf);
      X += I * cieX(l); Y += I * cieY(l); Z += I * cieZ(l);
    }
    var k = (gain === undefined ? 1 : gain) / WHITE_Y;
    return xyzToSrgb(X * k, Y * k, Z * k);
  }

  /** 状態からまとめて求める（描画・UI・テストが共通で使う） */
  function solve(st) {
    var r = refractAngle(st.theta, st.n1);
    var geom = geomPath(st.d, r);
    var delta = opticalPathDiff(st.d, st.n1, r);
    var f = flips(st.n1, st.n2);
    var nFlip = (f.top ? 1 : 0) + (f.bottom ? 1 : 0);
    var refl = reflects(st.n1, st.n2);
    var noInt = !(refl.top && refl.bottom);
    return {
      thetaRad: st.theta * DEG,
      rRad: r,
      rDeg: r / DEG,
      geomPath: geom,          // 経路差 B₂C+CB₁ = 2d cos r [nm]
      filmPath: filmPathLength(st.d, r),  // 膜内を実際に進む長さ 2d/cos r [nm]
      delta: delta,            // 光路差 [nm]
      ratio: delta / st.lambda,// 波長の何倍か
      flips: f,
      reflects: refl,
      noInterference: noInt,
      nFlip: nFlip,
      kind: conditionKind(nFlip),
      phase: phaseDiff(delta, st.lambda, nFlip),
      I: noInt ? 0 : intensityRatio(delta, st.lambda, nFlip),
      verdict: verdict(delta, st.lambda, nFlip, noInt),
      lambdaInFilm: st.lambda / st.n1,
      vRatio: 1 / st.n1
    };
  }

  return {
    N0: N0,
    DEG: DEG,
    clamp: clamp,
    refractAngle: refractAngle,
    geomPath: geomPath,
    filmPathLength: filmPathLength,
    opticalPathDiff: opticalPathDiff,
    flips: flips,
    flipCount: flipCount,
    phaseDiff: phaseDiff,
    intensityRatio: intensityRatio,
    conditionKind: conditionKind,
    reflects: reflects,
    interferes: interferes,
    verdict: verdict,
    conditionGap: conditionGap, TOL: TOL,
    targetThickness: targetThickness,
    thicknessSet: thicknessSet,
    peakLambda: peakLambda,
    wavelengthToRGB: wavelengthToRGB,
    colorName: colorName,
    intensityAt: intensityAt,
    whiteLightColor: whiteLightColor,
    LMIN: LMIN, LMAX: LMAX, LSTEP: LSTEP,
    rgbCss: rgbCss,
    solve: solve
  };
})();

