/* ===== 40_draw.js ===== */
/* canvas 共通描画部品：座標系、光路の組み立て、正弦波・波面・速度ベクトル・ラベル */
window.TF = window.TF || {};
TF.draw = (function () {
  'use strict';
  var P = TF.phys;

  /* ---------- レイアウト定数 ---------- */
  var L = {
    W: 700, H: 732,
    BAND_Y: 606,        // 下部「経路差をまっすぐ伸ばす」帯の上端（図の描画はここまで）
    SURF_Y: 344,        // 薄膜の上面 y
    SCALE: 0.12,        // px / nm
    AMP: 12,            // 波の振幅 [px]
    PAD: 8,
    // 表示上のズレ（水平方向 px）。境界面上の点が面から浮かないよう、必ず水平に与える。
    OFF: { in2: -72, filmDown: -72, filmUp: -36, out2: -36, sum: 0, out1: 36, in1: 72 }
  };

  var COL = {
    ray1: '#e2542c',      // 上面で反射した光（波長に応じて少し色が変わる）
    ray2: '#1f74d0',      // 薄膜を通った光（同上）
    sum: '#7b3fa8',      // 合成波
    air: '#fdf8e6',
    film: '#dff0f7',
    under: '#f3ece4',
    line: '#5a5a5a',
    guide: '#9aa0a6',
    hi: '#e0a800'
  };

  /* ---- 光線の色：2 本を見分けられるようにしつつ、光の波長の色へ少し寄せる ---- */
  var BASE_RAY = { ray1: '#e2542c', ray2: '#1f74d0', sum: '#7b3fa8' };
  var MIX = { ray1: 0.18, ray2: 0.18, sum: 0.12 };
  var LAM_REF = 550;      // この波長のとき、いつもの朱色・青色ちょうど

  function hex2rgb(h) {
    return {
      r: parseInt(h.substr(1, 2), 16),
      g: parseInt(h.substr(3, 2), 16),
      b: parseInt(h.substr(5, 2), 16)
    };
  }
  function rgbHex(c) {
    function h(v) {
      var x = Math.round(P.clamp(v, 0, 255)).toString(16);
      return x.length < 2 ? '0' + x : x;
    }
    return '#' + h(c.r) + h(c.g) + h(c.b);
  }
  function shade(hex, k) {
    var c = hex2rgb(hex);
    return rgbHex({ r: c.r * k, g: c.g * k, b: c.b * k });
  }

  /** 明るさをそろえた波長の色（端の波長でも暗くならないように） */
  function pureColor(lambda) {
    var w = P.wavelengthToRGB(lambda);
    var m = Math.max(w.r, w.g, w.b) || 1;
    return { r: w.r * 255 / m, g: w.g * 255 / m, b: w.b * 255 / m };
  }

  /**
   * 光の波長 λ [nm] に合わせて COL.ray1 / ray2 / sum を少しだけ変える。
   * λ = 550 nm のときちょうど基準の朱色・青色になり、そこからの「色のずれ」ぶんだけ
   * 寄せるので、2 本の光線の見分け（朱／青）は保ったまま、波長の変化が色に出る。
   */
  function setLightColor(lambda) {
    var w = pureColor(lambda), w0 = pureColor(LAM_REF);
    var dR = w.r - w0.r, dG = w.g - w0.g, dB = w.b - w0.b;
    for (var k in BASE_RAY) {
      if (!Object.prototype.hasOwnProperty.call(BASE_RAY, k)) continue;
      var c = hex2rgb(BASE_RAY[k]), t = MIX[k];
      COL[k] = rgbHex({ r: c.r + dR * t, g: c.g + dG * t, b: c.b + dB * t });
    }
  }

  /**
   * 屈折率ごとの色。同じ屈折率なら同じ色になるので、
   * 「境目が見えない＝反射が起こらない」ことが直観的にわかる。
   */
  var MAT = [
    { n: 1.00, bg: '#fdf8e6', name: '空気' },
    { n: 1.33, bg: '#d7eefa', name: '水' },
    { n: 1.50, bg: '#ebe4f8', name: 'ガラス' }
  ];
  function matColor(n) {
    for (var i = 0; i < MAT.length; i++) if (Math.abs(MAT[i].n - n) < 0.005) return MAT[i].bg;
    return '#eef1ec';
  }
  function matName(n) {
    for (var i = 0; i < MAT.length; i++) if (Math.abs(MAT[i].n - n) < 0.005) return MAT[i].name;
    return '';
  }

  /* ---------- 図の中の文字 ----------
   * 書体は 1 つだけ。大きさと太さだけで区別して、ごちゃごちゃしないようにする。
   */
  var FONT = '"Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
  function font(px, bold) { return (bold ? 'bold ' : '') + px + 'px ' + FONT; }

  /* ---------- ベクトル小物 ---------- */
  function vec(x, y) { return { x: x, y: y }; }
  function add(a, b) { return vec(a.x + b.x, a.y + b.y); }
  function sub(a, b) { return vec(a.x - b.x, a.y - b.y); }
  function mul(a, k) { return vec(a.x * k, a.y * k); }
  function dot(a, b) { return a.x * b.x + a.y * b.y; }
  function len(a) { return Math.hypot(a.x, a.y); }
  function nrmOf(d) { return vec(-d.y, d.x); }

  /** 点 p から方向 dir に進んで矩形 rect を出るまでの最大 t */
  function clipT(p, dir, rect) {
    var t = Infinity;
    if (Math.abs(dir.x) > 1e-9) {
      t = Math.min(t, ((dir.x > 0 ? rect.x1 : rect.x0) - p.x) / dir.x);
    }
    if (Math.abs(dir.y) > 1e-9) {
      t = Math.min(t, ((dir.y > 0 ? rect.y1 : rect.y0) - p.y) / dir.y);
    }
    return Math.max(0, isFinite(t) ? t : 0);
  }

  /* ---------- 光路の組み立て ---------- */
  /**
   * 表示上のズレ（offset）は「水平方向」だけに与える。
   *   - 境界面上の点（上面の反射点・下面の反射点）が面から浮かない
   *   - θ = 0° では水平 = 波面に沿った向き なので、位相をまったく変えない
   * θ が付くと水平ズレは位相をわずかに歪めるので、角度がついたら
   * ズレを 0 に収束させる（offK）。θ ≧ 25° では完全に真の幾何になる。
   * なお位相計算はつねに「真の幾何」から求めた光路長 s [nm] だけを使うので、
   * 表示上のズレが数値に影響することはない。
   */
  function buildScene(st, sol) {
    var th = sol.thetaRad, r = sol.rRad;
    var u = vec(Math.sin(th), Math.cos(th));       // 入射（下向き）
    var uUp = vec(Math.sin(th), -Math.cos(th));      // 出射（上向き）
    var v = vec(Math.sin(r), Math.cos(r));        // 膜内（下向き）
    var perp = vec(Math.cos(th), -Math.sin(th));      // 入射波面の向き

    var dpx = st.d * L.SCALE;
    var dxt = st.d * Math.tan(r) * L.SCALE;          // 上面での横ずれ（片側）
    var xc = L.W * 0.5;

    // 自然に離れている分／角度が付いた分だけ、表示上のズレを減らす。
    // 光路差モードは教科書どおりの作図（B₂ などの垂線）を正しく描く必要があるので、
    // θ が少しでも付いたらすぐ 0 にして真の幾何にする。
    var fade = (st.mode === 'path') ? 4 : 25;
    var offK = P.clamp(Math.min(1 - (2 * dxt) / 50, 1 - st.theta / fade), 0, 1);
    var OF = {};
    for (var kk in L.OFF) if (Object.prototype.hasOwnProperty.call(L.OFF, kk)) OF[kk] = L.OFF[kk] * offK;

    var A1 = vec(xc + dxt, L.SURF_Y);   // 上面で反射する点（＝薄膜を通った光が出てくる点 C）
    var A2 = vec(xc - dxt, L.SURF_Y);   // 薄膜に入る点
    var B = vec(xc, L.SURF_Y + dpx);   // 下面で反射する点

    function O(p, off) { return vec(p.x + off, p.y); }   // ズレは水平方向のみ
    var sOf = function (p) { return dot(p, u) / L.SCALE; };   // nm
    var sA1 = sOf(A1), sA2 = sOf(A2);

    // 上端は光源のマークを置くぶんだけ空ける
    var srcBar = (offK > 0.15);      // 2 本を離して描いているときは「1 つの光源」を横長で描く
    var airRect = { x0: L.PAD, y0: 42, x1: L.W - L.PAD, y1: L.SURF_Y };
    // 出射側は観測者の目を置く余白を上に残す（光源バーがあるときはさらに下げる）。
    // 光路差モードでは右上に「④ 干渉の条件式」の箱を置くので、目がそこに来ないよう深めに切る。
    var outTop = (st.mode === 'path') ? 165 : (srcBar ? 126 : 96);
    var airRectOut = { x0: 60, y0: outTop, x1: L.W - 60, y1: L.SURF_Y };
    // 膜の中を実際に往復する光路長 2n₁d/cos r [nm]。
    // （経路差 2n₁d cos r とは別物。ここを取りちがえると、斜め入射のときに
    //   C のところで波がつながらず、出ていく波の位相差も合わなくなる。）
    var optIn = st.n1 * sol.filmPath;

    // --- 光線1（上面で反射） ---
    var a1d = O(A1, OF.in1);
    var t1 = clipT(a1d, mul(u, -1), airRect);
    var leg_i1 = mkLeg(add(a1d, mul(u, -t1)), a1d, u, 1, sA1 - t1 / L.SCALE, COL.ray1);

    var out1 = O(A1, OF.out1), out2 = O(A1, OF.out2), outS = O(A1, OF.sum);
    var tO1 = clipT(out1, uUp, airRectOut);
    var tO2 = clipT(out2, uUp, airRectOut);
    var tOS = clipT(outS, uUp, airRectOut);
    var ph1 = sol.flips.top ? Math.PI : 0;
    var ph2 = sol.flips.bottom ? Math.PI : 0;
    var s1o = sA1, s2o = sA2 + optIn;

    var leg_o1 = mkLeg(out1, add(out1, mul(uUp, tO1)), uUp, 1, s1o, COL.ray1, ph1);

    // --- 光線2（薄膜を通る） ---
    var a2d = O(A2, OF.in2);
    var t2 = clipT(a2d, mul(u, -1), airRect);
    var leg_i2 = mkLeg(add(a2d, mul(u, -t2)), a2d, u, 1, sA2 - t2 / L.SCALE, COL.ray2);
    var leg_f1 = mkLeg(a2d, O(B, OF.filmDown), v, st.n1, sA2, COL.ray2);
    var leg_f2 = mkLeg(O(B, OF.filmUp), O(A1, OF.filmUp), vec(v.x, -v.y), st.n1,
      sA2 + optIn / 2, COL.ray2, ph2);
    var leg_o2 = mkLeg(out2, add(out2, mul(uUp, tO2)), uUp, 1, s2o, COL.ray2, ph2);

    // --- 合成波を描く共通軸（真の出射光線そのもの） ---
    var leg_s1 = mkLeg(outS, add(outS, mul(uUp, tOS)), uUp, 1, s1o, COL.ray1, ph1);
    var leg_s2 = mkLeg(outS, add(outS, mul(uUp, tOS)), uUp, 1, s2o, COL.ray2, ph2);

    // --- つなぎ（1点を表すので波は描かない）。両端とも境界面上にある。 ---
    var conns = [
      {
        from: a1d, to: out1, bulge: -11, color: COL.ray1,
        at: A1, flip: sol.flips.top, kind: 'reflect-top'
      },
      {
        from: O(B, OF.filmDown), to: O(B, OF.filmUp), bulge: 11, color: COL.ray2,
        at: B, flip: sol.flips.bottom, kind: 'reflect-bottom'
      }
    ];

    /* ---- 教科書（図 88）の作図に必要な点 ----
     * A₂ : 光②が薄膜に入る点            （= A2）
     * B₁ : 光①が上面で反射する点＝光②が出てくる点（= A1）
     * C  : 光②が下面で反射する点        （= B）
     * A₁ : A₂ を通る入射波の波面が、光①の光線と交わる点（A₂A₁ ⊥ 入射方向）
     * B₂ : B₁ から屈折光線 A₂C に下ろした垂線の足（B₁B₂ = 屈折波の波面）
     * D  : B₁ の、下面に関する対称点（A₂, C, D は一直線。CD = CB₁）
     * → 経路差 = B₂C + CB₁ = B₂C + CD = B₂D = 2d cos r
     */
    var ptB2 = add(A2, mul(v, dot(sub(A1, A2), v)));
    var ptA1 = sub(A1, mul(u, dot(sub(A1, A2), u)));
    var ptD = vec(A1.x, L.SURF_Y + 2 * dpx);

    // 「実際に描かれている図」の上での同じ作図点（表示ズレを反映）
    var dB1 = O(A1, OF.filmUp);                                  // 光②が出てくる点
    var dB2 = add(a2d, mul(v, dot(sub(dB1, a2d), v)));
    var dA1 = sub(a1d, mul(u, dot(sub(a1d, a2d), u)));
    var dD = vec(dB1.x, L.SURF_Y + 2 * dpx);

    return {
      u: u, uUp: uUp, v: v, perp: perp, offK: offK, OF: OF, srcBar: srcBar,
      A1: A1, A2: A2, B: B, xc: xc, dpx: dpx, dxt: dxt,
      pts: { A1: ptA1, A2: A2, B1: A1, B2: ptB2, C: B, D: ptD },
      dpts: {
        A1: dA1, A2: a2d, B1: dB1, B2: dB2, D: dD,
        Cdown: O(B, OF.filmDown), Cup: O(B, OF.filmUp),
        B1refl: vec(A1.x + (OF.in1 + OF.out1) / 2, L.SURF_Y)
      },
      surfY: L.SURF_Y, bottomY: L.SURF_Y + dpx,
      legs: {
        i1: leg_i1, o1: leg_o1, i2: leg_i2, f1: leg_f1, f2: leg_f2, o2: leg_o2,
        s1: leg_s1, s2: leg_s2
      },
      conns: conns,
      airRect: airRect,
      entryPt: a2d, refl1Pt: a1d, outPt: outS
    };
  }

  /**
   * 光路の 1 区間。
   * 波の「横ゆれ」を描く向き nrm は、境界面で鏡のように折り返す向きにそろえる。
   *   （そろえないと、上りの区間で図が左右反転し、位相が π ずれていないのに
   *     ずれたように見えてしまう。例：水の膜／下が空気のとき、下面 C の反射は
   *     位相が変化しないのに、反転して見える。）
   * 上へ進む区間（dir.y < 0）では nrmOf(dir) の符号を反転させる。これは
   * 水平な境界面での鏡映（x, y）→(x, −y) と同じ向きになる。
   */
  function mkLeg(a, b, dir, n, s0, color, extra) {
    var pxLen = len(sub(b, a));
    var nr = nrmOf(dir);
    if (dir.y < -1e-9) nr = mul(nr, -1);
    return {
      a: a, b: b, dir: dir, nrm: nr, n: n,
      s0: s0, optLen: n * pxLen / L.SCALE, pxLen: pxLen,
      color: color, extra: extra || 0
    };
  }

  /* ---------- 波の描画 ---------- */
  var V_NM_PER_S = 520; // 真空中の見かけの速さ [nm/s]

  function phaseAt(leg, f, st, t) {
    var k0 = 2 * Math.PI / st.lambda;
    var s = leg.s0 + f * leg.optLen;
    return k0 * (V_NM_PER_S * t - s) + leg.extra;
  }

  function waveLine(ctx, leg, st, t, amp, style) {
    if (leg.pxLen < 1) return;
    var steps = Math.max(2, Math.round(leg.pxLen / 2));
    ctx.save();
    ctx.beginPath();
    for (var i = 0; i <= steps; i++) {
      var f = i / steps;
      var disp = amp * Math.sin(phaseAt(leg, f, st, t));
      var x = leg.a.x + (leg.b.x - leg.a.x) * f + leg.nrm.x * disp;
      var y = leg.a.y + (leg.b.y - leg.a.y) * f + leg.nrm.y * disp;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.strokeStyle = style.color || leg.color;
    ctx.lineWidth = style.width || 2;
    ctx.globalAlpha = style.alpha === undefined ? 1 : style.alpha;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    ctx.stroke();
    ctx.restore();
  }

  /** 2 つの波の和（出射側の共通軸に描く） */
  function sumWaveLine(ctx, legA, legB, st, t, amp, style) {
    var steps = Math.max(2, Math.round(legA.pxLen / 2));
    if (legA.pxLen < 1) return;
    ctx.save();
    ctx.beginPath();
    for (var i = 0; i <= steps; i++) {
      var f = i / steps;
      var disp = amp * (Math.sin(phaseAt(legA, f, st, t)) + Math.sin(phaseAt(legB, f, st, t)));
      var x = legA.a.x + (legA.b.x - legA.a.x) * f + legA.nrm.x * disp;
      var y = legA.a.y + (legA.b.y - legA.a.y) * f + legA.nrm.y * disp;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.strokeStyle = style.color;
    ctx.lineWidth = style.width || 3;
    ctx.globalAlpha = style.alpha === undefined ? 1 : style.alpha;
    ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    ctx.stroke();
    ctx.restore();
  }

  /** 波面（山の位置に、進行方向と垂直な短い線分） */
  function wavefronts(ctx, leg, st, t, half, style) {
    if (leg.pxLen < 2 || leg.optLen <= 0) return;
    var k0 = 2 * Math.PI / st.lambda;
    var base = V_NM_PER_S * t + (leg.extra - Math.PI / 2) / k0;
    var lam = st.lambda;
    var mLo = Math.ceil((base - leg.s0 - leg.optLen) / lam);
    var mHi = Math.floor((base - leg.s0) / lam);
    if (mHi - mLo > 400) return;
    ctx.save();
    ctx.strokeStyle = style.color || leg.color;
    ctx.lineWidth = style.width || 1.6;
    ctx.globalAlpha = style.alpha === undefined ? 0.85 : style.alpha;
    for (var m = mLo; m <= mHi; m++) {
      var s = base - lam * m;
      var f = (s - leg.s0) / leg.optLen;
      if (f < 0 || f > 1) continue;
      var x = leg.a.x + (leg.b.x - leg.a.x) * f;
      var y = leg.a.y + (leg.b.y - leg.a.y) * f;
      ctx.beginPath();
      ctx.moveTo(x - leg.nrm.x * half, y - leg.nrm.y * half);
      ctx.lineTo(x + leg.nrm.x * half, y + leg.nrm.y * half);
      ctx.stroke();
    }
    ctx.restore();
  }

  /* ---------- 図形の小物 ---------- */
  function arrow(ctx, from, dir, length, color, width, headLen) {
    var to = add(from, mul(dir, length));
    ctx.save();
    ctx.strokeStyle = color; ctx.fillStyle = color;
    ctx.lineWidth = width || 2;
    ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(from.x, from.y); ctx.lineTo(to.x, to.y); ctx.stroke();
    var h = headLen || 8;
    var n = nrmOf(dir);
    ctx.beginPath();
    ctx.moveTo(to.x, to.y);
    ctx.lineTo(to.x - dir.x * h + n.x * h * 0.5, to.y - dir.y * h + n.y * h * 0.5);
    ctx.lineTo(to.x - dir.x * h - n.x * h * 0.5, to.y - dir.y * h - n.y * h * 0.5);
    ctx.closePath(); ctx.fill();
    ctx.restore();
  }

  function curveConn(ctx, c) {
    var mid = mul(add(c.from, c.to), 0.5);
    var d = sub(c.to, c.from);
    var n = nrmOf(vec(d.x / (len(d) || 1), d.y / (len(d) || 1)));
    var ctrl = add(mid, mul(n, c.bulge));
    ctx.save();
    ctx.strokeStyle = c.color; ctx.lineWidth = 2.4; ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(c.from.x, c.from.y);
    ctx.quadraticCurveTo(ctrl.x, ctrl.y, c.to.x, c.to.y);
    ctx.stroke();
    ctx.restore();
  }

  function dashLine(ctx, a, b, color, dash, width) {
    ctx.save();
    ctx.setLineDash(dash || [5, 4]);
    ctx.strokeStyle = color; ctx.lineWidth = width || 1.2;
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
    ctx.restore();
  }

  /** 吹き出しラベル（引き出し線つき）。左上詰めで矩形を返す */
  function callout(ctx, anchor, dx, dy, lines, opt) {
    opt = opt || {};
    ctx.save();
    ctx.font = (opt.font || font(12));
    var pad = 5, lh = 15;
    var w = 0;
    for (var i = 0; i < lines.length; i++) w = Math.max(w, ctx.measureText(lines[i]).width);
    var bw = w + pad * 2, bh = lines.length * lh + pad * 2 - 3;
    var bx = anchor.x + dx, by = anchor.y + dy;
    bx = P.clamp(bx, 2, L.W - bw - 2);
    by = P.clamp(by, 2, L.BAND_Y - bh - 2);
    // 引き出し線
    ctx.strokeStyle = opt.line || '#8a8a8a';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(anchor.x, anchor.y);
    ctx.lineTo(bx + (dx < 0 ? bw : 0), by + bh / 2);
    ctx.stroke();
    // 箱
    roundRect(ctx, bx, by, bw, bh, 5);
    ctx.fillStyle = opt.bg || 'rgba(255,255,255,0.94)';
    ctx.fill();
    ctx.strokeStyle = opt.border || '#b9b9b9';
    ctx.lineWidth = 1; ctx.stroke();
    ctx.fillStyle = opt.fg || '#222';
    ctx.textBaseline = 'top';
    for (var j = 0; j < lines.length; j++) ctx.fillText(lines[j], bx + pad, by + pad + j * lh);
    ctx.restore();
    return { x: bx, y: by, w: bw, h: bh };
  }

  /**
   * 決まった位置（左端／右端の縦スロット）に置く吹き出し。
   * 光線と重ならないので、ラベル同士もラベルと図も衝突しない。
   */
  function calloutAbs(ctx, anchor, side, y, lines, opt) {
    opt = opt || {};
    ctx.save();
    ctx.font = (opt.font || font(12));
    var pad = 6, lh = 15;
    var w = 0;
    for (var i = 0; i < lines.length; i++) w = Math.max(w, ctx.measureText(lines[i]).width);
    var bw = w + pad * 2, bh = lines.length * lh + pad * 2 - 3;
    var bx = (side === 'right') ? (L.W - bw - 10) : 10;
    var by = P.clamp(y, 4, L.BAND_Y - bh - 4);

    if (!opt.noLeader) {
      // 引き出し線（箱の内側の辺の中点から）
      var hx = (side === 'right') ? bx : bx + bw;
      var hy = by + bh / 2;
      ctx.strokeStyle = opt.line || (opt.border || '#9a9a9a');
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 3]);
      ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(anchor.x, anchor.y); ctx.stroke();
      ctx.setLineDash([]);
      ctx.beginPath(); ctx.arc(anchor.x, anchor.y, 3, 0, Math.PI * 2);
      ctx.fillStyle = opt.border || '#8a8a8a'; ctx.fill();
    }

    roundRect(ctx, bx, by, bw, bh, 6);
    ctx.fillStyle = opt.bg || 'rgba(255,255,255,0.96)';
    ctx.fill();
    ctx.strokeStyle = opt.border || '#b9b9b9';
    ctx.lineWidth = 1.2; ctx.stroke();
    ctx.fillStyle = opt.fg || '#222';
    ctx.textBaseline = 'top';
    for (var j = 0; j < lines.length; j++) ctx.fillText(lines[j], bx + pad, by + pad + j * lh);
    ctx.restore();
    return { x: bx, y: by, w: bw, h: bh };
  }

  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  /**
   * 観測者の目（見ている向きに回転する）。
   * gaze: 視線の向き（単位ベクトル）。目の形はその向きを向き、矢印が視線を示す。
   */
  function eye(ctx, p, gaze, scale, label) {
    var s = scale || 1;
    var ang = Math.atan2(gaze.y, gaze.x);
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.rotate(ang);
    ctx.scale(s, s);
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';

    // 白い下地。背景がにぎやかでも、目のかたちがはっきり見えるようにする
    ctx.beginPath();
    ctx.ellipse(0, 0, 25, 18, 0, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(255,255,255,0.92)'; ctx.fill();

    // 目のかたち（先のとがった木の葉形）。視線方向 = +x
    ctx.beginPath();
    ctx.moveTo(-19, 0);
    ctx.quadraticCurveTo(0, -16, 19, 0);
    ctx.quadraticCurveTo(0, 16, -19, 0);
    ctx.closePath();
    ctx.fillStyle = '#ffffff'; ctx.fill();
    ctx.strokeStyle = '#2b2118'; ctx.lineWidth = 3.4; ctx.stroke();

    // ひとみ（白抜きの丸）
    ctx.beginPath(); ctx.arc(6, 0, 5.2, 0, Math.PI * 2);
    ctx.fillStyle = '#ffffff'; ctx.fill();
    ctx.strokeStyle = '#2b2118'; ctx.lineWidth = 2.6; ctx.stroke();

    // 視線の矢印
    ctx.strokeStyle = '#2b2118'; ctx.fillStyle = '#2b2118'; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.moveTo(25, 0); ctx.lineTo(38, 0); ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(50, 0); ctx.lineTo(36, -8); ctx.lineTo(36, 8);
    ctx.closePath(); ctx.fill();
    ctx.restore();

    // 「見る方向」のラベル（読みやすさのため回転させず、目の真上に置く）
    if (label !== false) {
      var txt = (typeof label === 'string') ? label : '見る方向';
      ctx.save();
      ctx.font = 'bold 11.5px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
      var tw = ctx.measureText(txt).width;
      var lx = P.clamp(p.x, tw / 2 + 6, L.W - tw / 2 - 6);
      var ly = P.clamp(p.y - 26, 10, L.BAND_Y - 8);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      roundRect(ctx, lx - tw / 2 - 5, ly - 9, tw + 10, 18, 5);
      ctx.fillStyle = 'rgba(255,255,255,0.92)'; ctx.fill();
      ctx.strokeStyle = '#b9b3ab'; ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = '#2b2118';
      ctx.fillText(txt, lx, ly);
      ctx.restore();
    }
  }

  /** 作図点のラベル（小さな黒点＋記号） */
  function pointLabel(ctx, p, text, dx, dy, color) {
    ctx.save();
    ctx.beginPath(); ctx.arc(p.x, p.y, 3.2, 0, Math.PI * 2);
    ctx.fillStyle = color || '#222'; ctx.fill();
    ctx.font = font(12.5, true);
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    var w = ctx.measureText(text).width;
    ctx.fillStyle = 'rgba(255,255,255,0.85)';
    ctx.fillRect(p.x + dx - w / 2 - 2, p.y + dy - 8, w + 4, 16);
    ctx.fillStyle = color || '#222';
    ctx.fillText(text, p.x + dx, p.y + dy);
    ctx.restore();
  }

  /** 直角のしるし（点 p で、方向 d1 と d2 のあいだ） */
  function rightAngle(ctx, p, d1, d2, size, color) {
    var s = size || 9;
    var a = add(p, mul(d1, s)), b = add(p, mul(d2, s));
    var c = add(a, mul(d2, s));
    ctx.save();
    ctx.strokeStyle = color || '#666'; ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(a.x, a.y); ctx.lineTo(c.x, c.y); ctx.lineTo(b.x, b.y);
    ctx.stroke();
    ctx.restore();
  }

  /**
   * 等しい角どうしを示す弧。nTicks 本の短い線（｜、｜｜）を弧の上に描く。
   * 入射角と反射角には ｜｜、屈折角には ｜ を付けて「等しい」ことを示す。
   */
  function tickArc(ctx, center, a0, a1, radius, color, label, nTicks) {
    var lo = Math.min(a0, a1), hi = Math.max(a0, a1);
    if (hi - lo < 0.03) return;
    ctx.save();
    ctx.strokeStyle = color; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(center.x, center.y, radius, lo, hi); ctx.stroke();

    var mid = (lo + hi) / 2, n = nTicks || 1, half = (n - 1) / 2;
    ctx.lineWidth = 1.8;
    for (var i = 0; i < n; i++) {
      var a = mid + (i - half) * 0.085;
      ctx.beginPath();
      ctx.moveTo(center.x + Math.cos(a) * (radius - 5), center.y + Math.sin(a) * (radius - 5));
      ctx.lineTo(center.x + Math.cos(a) * (radius + 5), center.y + Math.sin(a) * (radius + 5));
      ctx.stroke();
    }
    if (label) {
      ctx.fillStyle = color;
      ctx.font = font(13, true);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(label, center.x + Math.cos(mid) * (radius + 16),
        center.y + Math.sin(mid) * (radius + 16));
    }
    ctx.restore();
  }

  /** 法線（一点鎖線） */
  function normalLine(ctx, p, up, down) {
    ctx.save();
    ctx.setLineDash([9, 4, 2, 4]);
    ctx.strokeStyle = '#9aa0a6'; ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(p.x, p.y - (up || 70)); ctx.lineTo(p.x, p.y + (down || 70));
    ctx.stroke();
    ctx.restore();
  }

  var COL_I = '#3d51a8';   // 入射角・反射角
  var COL_R = '#1f7a35';   // 屈折角

  /**
   * 入射角 i・反射角 i・屈折角 r をまとめて描く（全モード共通）。
   *   pIn  : 入射／屈折を示す点（A₂）
   *   pRef : 入射／反射を示す点（B₁：表示ズレがあるときは U ターンの中央）
   *   pOut : 膜内から出てくる光線の r を示す点（B₁）
   */
  function angleSet(ctx, sc, sol, pIn, pRef, pOut) {
    if (sol.thetaRad < 0.03) {
      ctx.save();
      ctx.font = '12px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
      ctx.fillStyle = COL_I; ctx.textBaseline = 'middle';
      ctx.fillText('i = 0°（垂直入射）', 14, L.SURF_Y - 92);
      ctx.fillText('入射角 i = 反射角 i = 0°、屈折角 r = 0°', 14, L.SURF_Y - 74);
      ctx.restore();
      return;
    }
    var u = sc.u, v = sc.v;
    var aBack = Math.atan2(-u.y, -u.x);         // 入射光線をさかのぼる向き
    var aUpN = -Math.PI / 2;                    // 上向き法線
    var aDownN = Math.PI / 2;                   // 下向き法線
    var aRefl = Math.atan2(-u.y, u.x);          // 反射光線
    var aV = Math.atan2(v.y, v.x);              // 屈折光線（下向き）
    var aVup = Math.atan2(v.y, -v.x);           // 膜内を上ってくる光線をさかのぼる向き

    if (pIn) {
      normalLine(ctx, pIn, 76, 76);
      tickArc(ctx, pIn, aBack, aUpN, 40, COL_I, 'i', 2);
      tickArc(ctx, pIn, aV, aDownN, 40, COL_R, 'r', 1);
    }
    if (pRef) {
      normalLine(ctx, pRef, 82, 40);
      tickArc(ctx, pRef, aBack, aUpN, 42, COL_I, 'i', 2);   // 入射角
      tickArc(ctx, pRef, aUpN, aRefl, 42, COL_I, 'i', 2);   // 反射角（｜｜ が同じ＝等しい）
    }
    if (pOut) {
      tickArc(ctx, pOut, aDownN, aVup, 48, COL_R, 'r', 1);
    }
  }

  /** 角度の弧 */
  function angleArc(ctx, center, a0, a1, radius, color, label) {
    ctx.save();
    ctx.strokeStyle = color; ctx.lineWidth = 1.3;
    ctx.beginPath(); ctx.arc(center.x, center.y, radius, a0, a1); ctx.stroke();
    if (label) {
      var mid = (a0 + a1) / 2;
      ctx.fillStyle = color;
      ctx.font = font(12.5);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(label, center.x + Math.cos(mid) * (radius + 11), center.y + Math.sin(mid) * (radius + 11));
    }
    ctx.restore();
  }


  /* ================= 図の中のボタン ================= */
  var uiButtons = [];
  function resetButtons() { uiButtons.length = 0; }
  function canvasButton(ctx, x, y, label, id, hot, on) {
    ctx.save();
    ctx.font = 'bold 12px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
    var w = ctx.measureText(label).width + 22, h = 26;
    roundRect(ctx, x, y, w, h, 7);
    ctx.fillStyle = on ? '#ffe9c2' : (hot ? '#eaf1fa' : 'rgba(255,255,255,0.94)');
    ctx.fill();
    ctx.strokeStyle = on ? '#c77800' : (hot ? '#1f74d0' : '#b6bcc2');
    ctx.lineWidth = hot || on ? 1.8 : 1.2; ctx.stroke();
    ctx.fillStyle = on ? '#8a5300' : '#28405c';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(label, x + 11, y + h / 2 + 1);
    ctx.restore();
    uiButtons.push({ x: x, y: y, w: w, h: h, id: id });
    return w;
  }
  function hitButton(px, py) {
    for (var i = 0; i < uiButtons.length; i++) {
      var b = uiButtons[i];
      if (px >= b.x && px <= b.x + b.w && py >= b.y && py <= b.y + b.h) return b.id;
    }
    return null;
  }

  /* ================= パルス強調 ================= */
  /** 0〜1 の強調度。押してから約 1.6 秒かけて 3 回ピクッと光って消える */
  function pulseAmount(pulse, kind, nowSec) {
    if (!pulse || pulse.kind !== kind) return 0;
    var t = nowSec - pulse.t0;
    if (t < 0 || t > 1.6) return 0;
    var fade = 1 - t / 1.6;
    return fade * (0.55 + 0.45 * Math.cos(2 * Math.PI * 2.4 * t));
  }
  /** 吹き出しが出たときの「ピカッ」。箱の外側に広がる輪を描く */
  function boxGlow(ctx, box, amount, color) {
    if (!box || !(amount > 0.01)) return;
    var g = 3 + 11 * amount;
    ctx.save();
    ctx.strokeStyle = color || '#e0a800';
    ctx.globalAlpha = 0.85 * amount;
    ctx.lineWidth = 2 + 5 * amount;
    roundRect(ctx, box.x - g, box.y - g, box.w + 2 * g, box.h + 2 * g, 8 + g);
    ctx.stroke();
    ctx.globalAlpha = 0.5 * amount;
    ctx.lineWidth = 2;
    roundRect(ctx, box.x - 2, box.y - 2, box.w + 4, box.h + 4, 8);
    ctx.stroke();
    ctx.restore();
  }

  function glowLine(ctx, a, b, color, amount, dash) {
    if (amount <= 0.01) return;
    ctx.save();
    ctx.setLineDash(dash || []);
    ctx.strokeStyle = color;
    ctx.globalAlpha = 0.25 + 0.75 * amount;
    ctx.lineWidth = 2 + 8 * amount;
    ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
    ctx.restore();
  }

  /* ================= ルーペ（光路差のあたりを拡大） ================= */
  function magnifier(ctx, canvas, dpr, cx, cy, zoom, radius) {
    var r = radius || 76, z = zoom || 2.6;
    var gx = P.clamp(cx, r + 6, L.W - r - 6);
    var gy = cy - r - 74;
    if (gy < r + 6) gy = cy + r + 74;
    gy = P.clamp(gy, r + 6, L.BAND_Y - r - 6);
    var half = r / z;
    ctx.save();
    ctx.beginPath(); ctx.arc(gx, gy, r, 0, Math.PI * 2); ctx.clip();
    ctx.fillStyle = '#fff'; ctx.fillRect(gx - r, gy - r, 2 * r, 2 * r);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(canvas,
      (cx - half) * dpr, (cy - half) * dpr, 2 * half * dpr, 2 * half * dpr,
      gx - r, gy - r, 2 * r, 2 * r);
    ctx.restore();
    ctx.save();
    ctx.beginPath(); ctx.arc(gx, gy, r, 0, Math.PI * 2);
    ctx.strokeStyle = '#3a3a3a'; ctx.lineWidth = 3; ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.8)'; ctx.lineWidth = 1; ctx.stroke();
    // 元の位置を示す小さな円と線
    ctx.setLineDash([4, 3]); ctx.strokeStyle = '#6a6a6a'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(cx, cy, half, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(gx, gy); ctx.stroke();
    ctx.setLineDash([]);
    ctx.font = 'bold 11px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
    ctx.fillStyle = '#3a3a3a'; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText('×' + z.toFixed(1), gx, gy + r + 4);
    ctx.restore();
  }

  /* ================= 干渉が起こらないときの表示 ================= */
  function noInterferenceBanner(ctx, sol) {
    var why = !sol.reflects.top
      ? '空気と薄膜の屈折率が同じ（n₁ = 1.00）なので、上面で反射が起こりません'
      : '薄膜と下の物質の屈折率が同じ（n₂ = n₁）なので、下面で反射が起こりません';
    ctx.save();
    ctx.font = 'bold 13px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
    var t1 = '干渉は起こりません';
    var w = Math.max(ctx.measureText(t1).width, 0) + 40;
    ctx.font = '12px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
    w = Math.max(w, ctx.measureText(why).width + 40);
    var bx = (L.W - w) / 2, by = 54, bh = 52;
    roundRect(ctx, bx, by, w, bh, 9);
    ctx.fillStyle = 'rgba(255,240,238,0.97)'; ctx.fill();
    ctx.strokeStyle = '#a12a1c'; ctx.lineWidth = 2; ctx.stroke();
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillStyle = '#a12a1c';
    ctx.font = 'bold 13.5px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
    ctx.fillText('⚠ 干渉は起こりません', L.W / 2, by + 7);
    ctx.font = '12px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
    ctx.fillStyle = '#7a2b12';
    ctx.fillText(why, L.W / 2, by + 27);
    ctx.restore();
  }

  /* ---------- 背景 ---------- */
  function background(ctx, st, sc) {
    var cAir = matColor(1.00), cFilm = matColor(st.n1), cUnder = matColor(st.n2);
    var sameTop = (cAir === cFilm), sameBot = (cFilm === cUnder);
    ctx.save();
    ctx.fillStyle = cAir; ctx.fillRect(0, 0, L.W, sc.surfY);
    ctx.fillStyle = cFilm; ctx.fillRect(0, sc.surfY, L.W, sc.dpx);
    ctx.fillStyle = cUnder; ctx.fillRect(0, sc.bottomY, L.W, L.BAND_Y - 10 - sc.bottomY);

    // 屈折率がちがえば実線、同じなら点線（境目はあるが反射は起こらない）
    ctx.strokeStyle = '#7f8c93';
    ctx.lineWidth = sameTop ? 1.1 : 1.4;
    ctx.setLineDash(sameTop ? [5, 5] : []);
    ctx.beginPath(); ctx.moveTo(0, sc.surfY + 0.5); ctx.lineTo(L.W, sc.surfY + 0.5); ctx.stroke();
    ctx.lineWidth = sameBot ? 1.1 : 1.4;
    ctx.setLineDash(sameBot ? [5, 5] : []);
    ctx.beginPath(); ctx.moveTo(0, sc.bottomY + 0.5); ctx.lineTo(L.W, sc.bottomY + 0.5); ctx.stroke();
    ctx.setLineDash([]);

    ctx.font = '13px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
    ctx.fillStyle = '#4a4a4a'; ctx.textBaseline = 'middle';
    ctx.fillText('空気  n = 1.00', 10, sc.surfY - 14);
    var nm1 = matName(st.n1), nm2 = matName(st.n2);
    var t1 = '薄膜  n₁ = ' + st.n1.toFixed(2) + (nm1 ? '（' + nm1 + '）' : '');
    var t2 = '下の物質  n₂ = ' + st.n2.toFixed(2) + (nm2 ? '（' + nm2 + '）' : '');
    // 薄膜のラベルは、膜が薄くても必ず「膜の帯の上」に置く（下の物質側へ逃がさない）
    var ty1 = sc.surfY + sc.dpx / 2;
    if (sc.dpx < 20) {
      var w1 = ctx.measureText(t1).width;
      roundRect(ctx, 6, ty1 - 10, w1 + 10, 20, 5);
      ctx.fillStyle = cFilm; ctx.globalAlpha = 0.94; ctx.fill(); ctx.globalAlpha = 1;
      ctx.strokeStyle = '#8fa3ac'; ctx.lineWidth = 1; ctx.setLineDash([]); ctx.stroke();
      ctx.fillStyle = '#4a4a4a';
    }
    ctx.fillText(t1, 11, ty1);
    ctx.fillText(t2, 10, sc.bottomY + 16);
    if (sameTop) {
      ctx.fillStyle = '#a12a1c'; ctx.font = 'bold 12px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
      ctx.fillText('↑ 同じ屈折率（点線）＝反射しない', 430, sc.surfY - 14);
    }
    if (sameBot) {
      ctx.fillStyle = '#a12a1c'; ctx.font = 'bold 12px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
      ctx.fillText('↑ 同じ屈折率（点線）＝反射しない', 430, sc.bottomY + 16);
    }
    ctx.restore();
  }

  /** 膜厚 d の寸法線 */
  function thicknessDim(ctx, sc, st) {
    var x = L.W - 150;
    ctx.save();
    ctx.strokeStyle = '#6b6b6b'; ctx.lineWidth = 1;
    dashLine(ctx, vec(x - 8, sc.surfY), vec(x + 26, sc.surfY), '#9a9a9a', [3, 3]);
    dashLine(ctx, vec(x - 8, sc.bottomY), vec(x + 26, sc.bottomY), '#9a9a9a', [3, 3]);
    arrow(ctx, vec(x, sc.surfY), vec(0, 1), Math.max(2, sc.dpx), '#6b6b6b', 1.2, 6);
    arrow(ctx, vec(x, sc.bottomY), vec(0, -1), Math.max(2, sc.dpx), '#6b6b6b', 1.2, 6);
    ctx.fillStyle = '#3a3a3a';
    ctx.font = 'bold 12px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
    ctx.textBaseline = 'middle';
    var label = '薄膜の厚み d = ' + Math.round(st.d) + ' nm';
    var ty = sc.dpx > 30 ? sc.surfY + sc.dpx / 2 : sc.surfY - 14;
    var wlab = ctx.measureText(label).width;
    ctx.fillStyle = 'rgba(255,255,255,0.8)';
    ctx.fillRect(x + 5, ty - 8, wlab + 4, 16);
    ctx.fillStyle = '#3a3a3a';
    ctx.fillText(label, x + 7, ty);
    ctx.restore();
  }

  /** 下面のドラッグ用ハンドル（膜厚を変えられることを示す。境界線の「下」に置く） */
  function thicknessHandle(ctx, sc, hot) {
    var y = sc.bottomY, cx = L.W - 60;
    ctx.save();
    ctx.strokeStyle = hot ? '#c77800' : '#a8adb2';
    ctx.lineWidth = hot ? 3 : 1.6;
    ctx.globalAlpha = hot ? 1 : 0.75;
    ctx.setLineDash([7, 5]);
    ctx.beginPath(); ctx.moveTo(8, y); ctx.lineTo(L.W - 8, y); ctx.stroke();
    ctx.setLineDash([]);
    ctx.globalAlpha = 1;

    var label = hot ? '⇕ ドラッグで厚さを変える' : '⇕ 厚さ';
    ctx.font = '11px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
    var w = ctx.measureText(label).width + 16;
    var bx = P.clamp(cx - w / 2, 6, L.W - w - 6);
    roundRect(ctx, bx, y + 5, w, 18, 9);
    ctx.fillStyle = hot ? '#ffe9c2' : 'rgba(255,255,255,0.92)';
    ctx.fill();
    ctx.strokeStyle = hot ? '#c77800' : '#a8adb2'; ctx.lineWidth = 1.2; ctx.stroke();
    ctx.fillStyle = hot ? '#8a5300' : '#6b7176';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(label, bx + w / 2, y + 14);
    ctx.textAlign = 'left';
    ctx.restore();
  }

  /**
   * 位相 π ずれの吹き出し（上面・下面で見た目をそろえた対のデザイン）。
   * ずれるときは琥珀色＋太枠＋「π」バッジ、ずれないときは灰色。
   */
  function piCallout(ctx, anchor, side, y, title, flip) {
    var on = !!flip;
    var badge = on ? 'π' : '0';
    var lines = [title, on ? '位相が π ずれる' : '位相は変化しない'];
    ctx.save();
    ctx.font = 'bold 12.5px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
    var w = 0, i;
    for (i = 0; i < lines.length; i++) w = Math.max(w, ctx.measureText(lines[i]).width);
    var padL = 34, bw = w + padL + 12, bh = 40;
    // side が 'at' のときは y を {x,y} として、その位置に箱を置く
    var bx, by;
    if (side === 'at') {
      bx = P.clamp(y.x, 6, L.W - bw - 6);
      by = P.clamp(y.y, 4, L.BAND_Y - bh - 4);
    } else {
      bx = (side === 'right') ? (L.W - bw - 10) : 10;
      by = P.clamp(y, 4, L.BAND_Y - bh - 4);
    }

    var bd = on ? '#d97706' : '#9aa0a6';
    var bg = on ? '#fff4d6' : '#f2f4f6';
    var fg = on ? '#8a4b00' : '#5f6a72';

    // 引き出し線
    ctx.strokeStyle = bd; ctx.lineWidth = 1.4; ctx.setLineDash([4, 3]);
    ctx.beginPath();
    var hx = (side === 'right') ? bx : (side === 'left' ? bx + bw
      : (anchor.x < bx ? bx : bx + bw));
    ctx.moveTo(hx, by + bh / 2);
    ctx.lineTo(anchor.x, anchor.y); ctx.stroke();
    ctx.setLineDash([]);
    ctx.beginPath(); ctx.arc(anchor.x, anchor.y, 4, 0, Math.PI * 2);
    ctx.fillStyle = bd; ctx.fill();

    roundRect(ctx, bx, by, bw, bh, 8);
    ctx.fillStyle = bg; ctx.fill();
    ctx.strokeStyle = bd; ctx.lineWidth = on ? 2.4 : 1.4; ctx.stroke();

    // 「π」バッジ（形と色をそろえて対に見せる）
    ctx.beginPath(); ctx.arc(bx + 19, by + bh / 2, 12, 0, Math.PI * 2);
    ctx.fillStyle = on ? '#d97706' : '#c8cdd2'; ctx.fill();
    ctx.fillStyle = '#fff';
    ctx.font = font(14, true);
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(badge, bx + 19, by + bh / 2 + 1);

    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillStyle = fg;
    ctx.font = '11.5px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
    ctx.fillText(lines[0], bx + padL, by + 6);
    ctx.font = 'bold 12.5px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
    ctx.fillText(lines[1], bx + padL, by + 21);
    ctx.restore();
    return { x: bx, y: by, w: bw, h: bh };
  }

  /* ================= 光源のマーク ================= */
  /** 電球のマーク。p を中心に描く */
  function lightBulb(ctx, p, opt) {
    opt = opt || {};
    var s = opt.scale || 1;
    var JP = '"Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
    ctx.save();
    ctx.translate(p.x, p.y); ctx.scale(s, s);
    ctx.lineCap = 'round';
    // 光のすじ
    ctx.strokeStyle = '#e0a800'; ctx.lineWidth = 2;
    for (var i = 0; i < 8; i++) {
      var a2 = i * Math.PI / 4;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a2) * 15, Math.sin(a2) * 15);
      ctx.lineTo(Math.cos(a2) * 21, Math.sin(a2) * 21);
      ctx.stroke();
    }
    // 口金
    ctx.fillStyle = '#9aa0a6';
    roundRect(ctx, -5, 6, 10, 10, 2); ctx.fill();
    // ガラス球
    ctx.beginPath(); ctx.arc(0, 0, 11, 0, Math.PI * 2);
    ctx.fillStyle = '#ffe9a8'; ctx.fill();
    ctx.strokeStyle = '#b8860b'; ctx.lineWidth = 1.6; ctx.stroke();
    // フィラメント
    ctx.strokeStyle = '#b8860b'; ctx.lineWidth = 1.3;
    ctx.beginPath();
    ctx.moveTo(-4, 4); ctx.lineTo(-2, -2); ctx.lineTo(0, 3); ctx.lineTo(2, -2); ctx.lineTo(4, 4);
    ctx.stroke();
    ctx.restore();

    if (opt.label !== false) {
      var txt = opt.label || '光源';
      var ly = p.y + 20 * s + 9;
      // 波長つきのときは「■ 光源　λ = 550 nm（緑色）」の 1 枚にまとめる
      // （名札を 2 段にすると、入射角が大きいときに左のボタンと重なるため）
      if (opt.sub) {
        ctx.save();
        ctx.font = 'bold 11.5px ' + JP;
        var t2 = txt + '　' + opt.sub;
        var w2 = ctx.measureText(t2).width + 32;
        var x2 = P.clamp(p.x - w2 / 2, 6, Math.max(6, L.W - 6 - w2));
        // 左の「⚡ 波面を強調 / ⚡ 経路差を強調」ボタン（14,128〜186）に重なるときは右へ逃がす
        var moved = false;
        if (ly > 116 && ly < 198 && x2 < 176) {
          x2 = Math.min(176, Math.max(6, L.W - 6 - w2));
          moved = true;
        }
        // 逃がしたときは、電球とのつながりを細い点線で示す
        if (moved && x2 > p.x + 6) {
          dashLine(ctx, vec(p.x, ly), vec(x2 - 3, ly), 'rgba(184,134,11,0.5)', [3, 3], 1);
        }
        roundRect(ctx, x2, ly - 9, w2, 18, 5);
        ctx.fillStyle = opt.dark ? 'rgba(0,0,0,0.45)' : 'rgba(255,255,255,0.9)';
        ctx.fill();
        ctx.strokeStyle = opt.dark ? '#6b5a2a' : '#d9c98a'; ctx.lineWidth = 1; ctx.stroke();
        ctx.fillStyle = opt.subColor || '#888';
        roundRect(ctx, x2 + 7, ly - 5, 10, 10, 2); ctx.fill();
        ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 1; ctx.stroke();
        ctx.fillStyle = opt.dark ? '#ffe9a8' : '#8a6d00';
        ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
        ctx.fillText(t2, x2 + 23, ly);
        ctx.restore();
        return;
      }
      ctx.save();
      ctx.font = 'bold 11.5px ' + JP;
      var tw = ctx.measureText(txt).width;
      roundRect(ctx, p.x - tw / 2 - 5, ly - 9, tw + 10, 18, 5);
      ctx.fillStyle = opt.dark ? 'rgba(0,0,0,0.45)' : 'rgba(255,255,255,0.88)';
      ctx.fill();
      ctx.strokeStyle = opt.dark ? '#6b5a2a' : '#d9c98a'; ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = opt.dark ? '#ffe9a8' : '#8a6d00';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(txt, p.x, ly);
      ctx.restore();
    }
  }

  /** 波長と色を示す小さな名札（色の四角つき） */
  function waveChip(ctx, cx, cy, txt, rgb, dark) {
    var JP = '"Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
    ctx.save();
    ctx.font = 'bold 11px ' + JP;
    var tw = ctx.measureText(txt).width;
    var bw = tw + 26;
    var bx = P.clamp(cx - bw / 2, 6, Math.max(6, L.W - 6 - bw));   // 画面からはみ出さない
    roundRect(ctx, bx, cy - 9, bw, 18, 5);
    ctx.fillStyle = dark ? 'rgba(0,0,0,0.45)' : 'rgba(255,255,255,0.92)';
    ctx.fill();
    ctx.strokeStyle = dark ? '#6b5a2a' : '#cfd6dd'; ctx.lineWidth = 1; ctx.stroke();
    // 色の四角
    ctx.fillStyle = rgb || '#888';
    roundRect(ctx, bx + 6, cy - 5, 10, 10, 2); ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 1; ctx.stroke();
    ctx.fillStyle = dark ? '#e8ecf0' : '#3d4a54';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(txt, bx + 21, cy + 1);
    ctx.restore();
  }

  /** 2 本の光線を離して描いているときの「1 つの光源」（角丸長方形） */
  function lightBar(ctx, x0, x1, y, sub, subColor) {
    var JP = '"Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
    var pad = 30, h = 30;
    var bx = Math.min(x0, x1) - pad, bw = Math.abs(x1 - x0) + pad * 2;
    ctx.save();
    roundRect(ctx, bx, y, bw, h, 15);
    ctx.fillStyle = '#fff6d8'; ctx.fill();
    ctx.strokeStyle = '#b8860b'; ctx.lineWidth = 1.6; ctx.stroke();
    var cx = bx + bw / 2;
    lightBulb(ctx, vec(cx - 34, y + h / 2), { scale: 0.62, label: false });
    ctx.font = 'bold 13px ' + JP; ctx.fillStyle = '#8a6d00';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText('光源', cx - 16, y + h / 2 + 1);
    ctx.restore();
    if (sub) waveChip(ctx, cx, y + h + 11, sub, subColor);
  }

  /** 光源の名札に添える「λ = 550 nm（緑色）」 */
  function lightText(st) {
    return 'λ = ' + Math.round(st.lambda) + ' nm（' + P.colorName(st.lambda) + '色）';
  }

  /** 光路差モード・波動モード共通：光源を置く */
  function sourceMark(ctx, sc, st) {
    var a1 = sc.legs.i1.a, a2 = sc.legs.i2.a;
    var sub = st ? lightText(st) : null;
    var subCol = st ? P.rgbCss(P.wavelengthToRGB(st.lambda)) : null;
    if (sc.srcBar) {
      lightBar(ctx, a1.x, a2.x, 4, sub, subCol);
      return;
    }
    // 斜め入射：2 本の入射光線のあいだ（左上）に電球を置き、細い点線でつなぐ
    var mid = vec((a1.x + a2.x) / 2, (a1.y + a2.y) / 2);
    var p = add(mid, mul(sc.u, -15));
    // 左上にはステップ名の見出しがあるので、そこは避ける
    p = vec(P.clamp(p.x, 26, L.W - 26),
      P.clamp(p.y, (p.x < 190 ? 56 : 22), L.SURF_Y - 40));
    dashLine(ctx, p, a1, 'rgba(184,134,11,0.55)', [3, 3], 1);
    dashLine(ctx, p, a2, 'rgba(184,134,11,0.55)', [3, 3], 1);
    lightBulb(ctx, p, { sub: sub, subColor: subCol });
  }

  /* ================= 経路差をまっすぐ伸ばして見せる帯 =================
   * 緑でハイライトしている経路差 B₂C + CB₁（＝ 2d cos r）を、
   * 折り返さずに 1 本の直線に伸ばして、その上に「膜の中の波（波長 λ/n₁）」を並べる。
   *   経路差 ÷（λ/n₁）＝ 2n₁d cos r ÷ λ ＝ 光路差 ÷ λ
   * なので、並んだ波の個数がそのまま「光路差は λ の何倍か」になる。
   * 断面図とは別の「取り出した図」だとわかるよう、白いすき間を空けて
   * 白いカード（緑の破線わく）に載せ、上辺に見出しチップを重ねる。
   */
  var HI_GEO = '#0f9d58';

  /** 小数 1 桁。丸めで値が動くときだけ「約」を付ける */
  function about(v) {
    var r = Math.round(v * 10) / 10;
    return (Math.abs(v - r) < 0.005 ? '' : '約 ') + r.toFixed(1);
  }

  function unwrapBand(ctx, st, sol, sc) {
    var JP = '"Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
    var y0 = L.BAND_Y + 6, h = L.H - y0 - 6;
    var count = sol.ratio;                 // 波の個数 ＝ 光路差 / λ
    var lamF = st.lambda / st.n1;          // 膜の中の波長 [nm]

    ctx.save();
    // 断面図と切り離すための白いすき間
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, L.BAND_Y - 10, L.W, L.H - (L.BAND_Y - 10));

    // カード
    roundRect(ctx, 10, y0, L.W - 20, h, 10);
    ctx.fillStyle = '#ffffff'; ctx.fill();
    ctx.strokeStyle = HI_GEO; ctx.lineWidth = 1.6;
    ctx.setLineDash([7, 5]); ctx.stroke(); ctx.setLineDash([]);

    // 見出しチップ（カードの上辺に重ねて「別の図」だと示す）
    var chip = '↑ の図の薄膜中の、経路差（緑線の部分）だけを取り出して、まっすぐ伸ばすと';
    ctx.font = 'bold 11.5px ' + JP;
    var cw = ctx.measureText(chip).width + 20;
    roundRect(ctx, 26, y0 - 10, cw, 20, 10);
    ctx.fillStyle = HI_GEO; ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(chip, 36, y0 + 1);

    var cy = y0 + 56;
    var lx = 44, rightPad = 176;
    var avail = L.W - 16 - rightPad - lx;
    var n = Math.max(count, 0.35);
    var unit = Math.min(112, avail / n);        // 波 1 個ぶんの px
    var lenPx = unit * count;

    // 経路差そのもの（緑の太線）
    ctx.lineCap = 'round';
    ctx.globalAlpha = 0.72;
    ctx.strokeStyle = HI_GEO; ctx.lineWidth = 7;
    ctx.beginPath(); ctx.moveTo(lx, cy); ctx.lineTo(lx + lenPx, cy); ctx.stroke();
    ctx.globalAlpha = 1;

    // 端の点（B₂ と B₁）
    ctx.font = font(12, true); ctx.fillStyle = '#0b5c34';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('B₂', lx - 16, cy);
    ctx.fillText('B₁', lx + lenPx + 16, cy);

    // 折り返しの点 C。B₂C = 2d cos r − d/cos r（残りが CB₁ = d/cos r）
    var b2c = 2 * st.d * Math.cos(sol.rRad) - st.d / Math.cos(sol.rRad);
    var fC = (sol.geomPath > 1e-9) ? (b2c / sol.geomPath) : 0.5;

    /* 波：上の図の薄膜の中を進んでいる波（黄色の部分）そのものを、
     * まっすぐ伸ばして描く。折れ曲がり C で経路をのばすと、
     * 図の中の横ゆれの向き（法線）はちょうどつながる（鏡映になっているため）。
     * したがって、時刻 t・入射角・厚さを変えると、この波の形もそのまま変わる。
     *   A₂B₂ ＝ 2d/cos r − 2d cos r（A₂C − B₂C）
     *   B₂ から距離 g の点の光路長 s ＝ s(A₂) + n₁ ×（A₂B₂ ＋ g）
     *   下面 C で位相が π ずれる場合は、C から先だけ π を足す（＝図と同じ）
     */
    if (sc && sc.legs && sc.legs.f1) {
      var a2b2 = sol.filmPath - 2 * st.d * Math.cos(sol.rRad);   // 2d/cos r − 2d cos r
      var sB2 = sc.legs.f1.s0 + st.n1 * a2b2;
      var k0 = 2 * Math.PI / st.lambda;
      var phC = sc.legs.f2.extra || 0;                           // 下面の反射で π ずれるか
      var tNow = st.t || 0;
      var nm2px = (sol.geomPath > 1e-9) ? (lenPx / sol.geomPath) : 0;
      var xCut = lenPx * fC;                                     // 図の上での C の位置
      ctx.strokeStyle = COL.ray2; ctx.lineWidth = 2;
      ctx.lineJoin = 'round'; ctx.lineCap = 'round';
      var segs = (Math.abs(phC) > 1e-9) ? [[0, xCut], [xCut, lenPx]] : [[0, lenPx]];
      for (var sgi = 0; sgi < segs.length; sgi++) {
        var pa = segs[sgi][0], pb = segs[sgi][1];
        if (pb - pa < 0.5) continue;
        ctx.beginPath();
        for (var px = pa; px <= pb + 1e-6; px = Math.min(px + 1, pb)) {
          var gnm = (nm2px > 0) ? (px / nm2px) : 0;              // B₂ からの距離 [nm]
          var ex = (px > xCut + 1e-9) ? phC : 0;
          var yy = cy + 13 * Math.sin(k0 * (V_NM_PER_S * tNow - (sB2 + st.n1 * gnm)) + ex);
          if (px === pa) ctx.moveTo(lx + px, yy); else ctx.lineTo(lx + px, yy);
          if (px >= pb) break;
        }
        ctx.stroke();
      }
    }

    if (fC > 0.03 && fC < 0.97) {
      var xC = lx + lenPx * fC;
      ctx.save();
      ctx.strokeStyle = '#0b5c34'; ctx.lineWidth = 1.4;
      ctx.setLineDash([4, 3]);
      ctx.beginPath(); ctx.moveTo(xC, cy - 24); ctx.lineTo(xC, cy + 24); ctx.stroke();
      ctx.setLineDash([]);
      ctx.beginPath(); ctx.arc(xC, cy, 5, 0, Math.PI * 2);
      ctx.fillStyle = '#0b5c34'; ctx.fill();
      ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 1.6; ctx.stroke();
      // 「C（下面での反射）」のラベル
      ctx.font = font(12, true);
      var lab = (sc && sc.legs && Math.abs(sc.legs.f2.extra || 0) > 1e-9)
        ? 'C（下面で反射 → π ずれる）' : 'C（下面で反射）';
      var lw2 = ctx.measureText(lab).width;
      var lxC = P.clamp(xC - lw2 / 2, 16, L.W - 20 - lw2);
      roundRect(ctx, lxC - 6, cy + 18, lw2 + 12, 19, 5);
      ctx.fillStyle = 'rgba(255,255,255,0.92)'; ctx.fill();
      ctx.strokeStyle = '#bfe2cd'; ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = '#0b5c34';
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText(lab, lxC, cy + 28);
      ctx.restore();
    }

    // 1 個ずつの区切りと番号
    var whole = Math.floor(count + 1e-9);
    var frac = count - whole;
    if (frac > 0.95) { whole += 1; frac = 0; }      // 小数 1 桁で 1.0 になる端数は 1 個ぶんにする
    ctx.font = 'bold 11.5px ' + JP;
    for (var i = 0; i <= whole; i++) {
      var x = lx + unit * i;
      ctx.strokeStyle = 'rgba(60,90,70,0.45)'; ctx.lineWidth = 1;
      ctx.setLineDash([3, 3]);
      ctx.beginPath(); ctx.moveTo(x, cy - 20); ctx.lineTo(x, cy + 22); ctx.stroke();
      ctx.setLineDash([]);
      if (i >= 1) {
        ctx.fillStyle = '#0b5c34';
        ctx.fillText(String(i), x - unit / 2, cy - 28);
      }
    }
    if (frac >= 0.05) {
      ctx.fillStyle = '#8a6d00';
      ctx.fillText('+' + frac.toFixed(1), lx + unit * whole + unit * frac / 2, cy - 28);
    }

    // 数値
    ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
    ctx.font = '11.5px ' + JP; ctx.fillStyle = '#4a5a50';
    ctx.fillText('経路差 2d cos r ＝ ' + (Math.round(sol.geomPath * 10) / 10).toFixed(1)
      + ' nm　／　膜の中の波長 λ/n₁ ＝ ' + (Math.round(lamF * 10) / 10).toFixed(1)
      + ' nm　／　波の個数 ＝ ' + about(count) + ' 個', 24, L.H - 12);

    // 右：現在の光路差
    var bx = L.W - rightPad + 4, bw = rightPad - 24;
    roundRect(ctx, bx, y0 + 18, bw, 54, 8);
    var vk = sol.verdict.key;
    ctx.fillStyle = (vk === 'strong') ? '#e6f4ea' : (vk === 'weak' ? '#fdecea' : '#fff6e0');
    ctx.fill();
    ctx.strokeStyle = (vk === 'strong') ? '#1b6b34' : (vk === 'weak' ? '#a12a1c' : '#c99a00');
    ctx.lineWidth = 1.4; ctx.stroke();
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.font = 'bold 14px ' + JP;
    ctx.fillStyle = (vk === 'strong') ? '#1b6b34' : (vk === 'weak' ? '#a12a1c' : '#7a5a00');
    ctx.fillText('現在 光路差 ＝ ' + about(count) + ' λ', bx + bw / 2, y0 + 36);
    ctx.font = '11.5px ' + JP;
    ctx.fillText('→ ' + sol.verdict.label, bx + bw / 2, y0 + 58);

    ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
    ctx.restore();
  }

  return {
    L: L, COL: COL, unwrapBand: unwrapBand, FONT: FONT, font: font,
    setLightColor: setLightColor, shade: shade, hex2rgb: hex2rgb, rgbHex: rgbHex,
    lightBulb: lightBulb, lightBar: lightBar, sourceMark: sourceMark, waveChip: waveChip,
    vec: vec, add: add, sub: sub, mul: mul, dot: dot, len: len, nrmOf: nrmOf,
    buildScene: buildScene, mkLeg: mkLeg,
    phaseAt: phaseAt, waveLine: waveLine, sumWaveLine: sumWaveLine, wavefronts: wavefronts,
    arrow: arrow, curveConn: curveConn, dashLine: dashLine, callout: callout, calloutAbs: calloutAbs,
    roundRect: roundRect, eye: eye, angleArc: angleArc, piCallout: piCallout,
    pointLabel: pointLabel, rightAngle: rightAngle,
    resetButtons: resetButtons, canvasButton: canvasButton, hitButton: hitButton,
    pulseAmount: pulseAmount, glowLine: glowLine, boxGlow: boxGlow, magnifier: magnifier,
    noInterferenceBanner: noInterferenceBanner,
    tickArc: tickArc, normalLine: normalLine, angleSet: angleSet,
    COL_I: COL_I, COL_R: COL_R,
    background: background, thicknessDim: thicknessDim, thicknessHandle: thicknessHandle,
    matColor: matColor, matName: matName, MAT: MAT,
    V_NM_PER_S: V_NM_PER_S
  };
})();

