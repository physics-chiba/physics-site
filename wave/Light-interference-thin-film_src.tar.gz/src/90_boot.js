/* ===== 90_boot.js ===== */
/* 起動 */
(function () {
  'use strict';
  function boot() {
    TF.ui.init();
    TF.quiz.init();
    document.getElementById('btn-quiz-reset').addEventListener('click', function () {
      TF.quiz.init();
    });
    // 自動テストから触れるようにする
    window.TFTEST = TF.ui.api;
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
