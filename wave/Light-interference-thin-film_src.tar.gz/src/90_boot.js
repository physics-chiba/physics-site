/* ===== 90_boot.js ===== */
/* 起動 */
(function () {
  'use strict';
  function boot() {
    TF.ui.init();
    // 練習問題は 2026-11-17 に外した（cut/80_quiz.js）
    // 自動テストから触れるようにする
    window.TFTEST = TF.ui.api;
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
