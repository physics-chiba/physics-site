/* ===== 70_ui.js ===== */
/* UI：状態管理・スライダー・ボタン・数値表示・解説パネルの更新 */
window.TF = window.TF || {};
TF.ui = (function () {
  'use strict';
  var P = TF.phys, D = TF.draw;

  var RANGE = {
    lambda: [380, 780], d: [50, 1200], n1: [1.10, 2.50], n2: [1.00, 2.50], theta: [0, 60]
  };

  // m = 0 で強めあう λ₀ = 4n₁d cos r が、i = 0〜60° でちょうど可視光を横切る厚さ
  var THETA_DEMO = 46;      // 「46°へ」ボタン（d = 620 nm で光路差 2.5λ ＝ 強めあう）
  var BUBBLE_PRESET = { lambda: 550, n1: 1.33, n2: 1.00, theta: 30, d: 120 };
  var MAIN_PRESET = { lambda: 550, n1: 1.33, n2: 1.00, theta: 0, d: 620 };
  var N_CHOICES = [1.00, 1.33, 1.50];

  /* 虹色モードは目的がちがうので、パラメータを別に持つ。
     モードを行き来しても、それぞれの設定（波長・膜厚・屈折率・角度）が保たれる。 */
  var PKEYS = ['lambda', 'd', 'n1', 'n2', 'theta'];
  var saved = {
    main: copyParams(MAIN_PRESET),
    bubble: copyParams(BUBBLE_PRESET)
  };
  function copyParams(src) {
    var o = {};
    for (var i = 0; i < PKEYS.length; i++) o[PKEYS[i]] = src[PKEYS[i]];
    return o;
  }
  function groupOf(m) { return (m === 'bubble') ? 'bubble' : 'main'; }

  var st = {
    mode: 'wave',                       // 'wave' | 'path' | 'bubble'。最初に開くのは ①実際の波の動きを見る（2026-11-16 タブの順を入れかえ）
    light: 'mono',                      // 'mono' | 'white'（シャボン玉モード）
    lambda: 550, d: 620, n1: 1.33, n2: 1.00, theta: 0,
    playing: false, slow: false, speed: 1.0, t: 0,
    showWavefront: true, showVelocity: true, showLabels: true, showSum: true,
    step: 1,
    dragHot: false,
    pulse: null, stepPulse: null, hoverBtn: null, nowSec: 0,
    pointer: null, scaleOut: null
  };

  var el = {};
  var ctx = null, dpr = 1;
  var lastFrame = 0;
  var dragging = false;

  function $(id) { return document.getElementById(id); }

  /* ---------- canvas ---------- */
  function setupCanvas() {
    var c = $('view');
    // 図を鮮明にするため、実機の画素比より高めのバッキングストアを使う
    dpr = Math.min(3, Math.max(2, (window.devicePixelRatio || 1) * 1.5));
    c.width = D.L.W * dpr;
    c.height = D.L.H * dpr;
    c.style.aspectRatio = D.L.W + ' / ' + D.L.H;
    ctx = c.getContext('2d', { alpha: false });
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.textRendering = 'geometricPrecision';
  }

  /* ---------- 描画 ---------- */
  function render() {
    D.setLightColor(st.lambda);       // 光線の色を波長に合わせる
    var sol = P.solve(st);
    D.resetButtons();
    ctx.save();
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, D.L.W, D.L.H);

    if (st.scaleOut) {
      TF.scaleOut.render(ctx, st, sol, P.clamp(st.scaleOut.prog, 0, 1));
      ctx.restore();
      updateReadout(sol);
      return;
    }

    var sc = null;
    if (st.mode === 'bubble') {
      TF.modeBubble.render(ctx, st, sol);
    } else {
      sc = D.buildScene(st, sol);
      if (st.mode === 'wave') TF.modeWave.render(ctx, st, sol, sc, st.t);
      else TF.modePath.render(ctx, st, sol, sc, st.step);
    }
    ctx.restore();

    // 光路差のあたりにカーソルが来たら拡大して見せる
    if (sc && st.pointer && !st.dragHot) {
      var py = st.pointer.y;
      if (py > sc.surfY - 80 && py < sc.bottomY + 80 &&
          st.pointer.x > 30 && st.pointer.x < D.L.W - 30) {
        D.magnifier(ctx, $('view'), dpr, st.pointer.x, st.pointer.y, 2.13, 96);
      }
    }
    updateReadout(sol);
  }

  function loop(now) {
    st.nowSec = now / 1000;
    if (!lastFrame) lastFrame = now;
    var dt = Math.min(0.05, (now - lastFrame) / 1000);
    lastFrame = now;
    if (st.mode === 'wave' && st.playing) {
      st.t += dt * st.speed * (st.slow ? 0.25 : 1);
    }
    if (st.scaleOut && !st.scaleOut.paused) {
      st.scaleOut.prog = Math.min(1,
        st.scaleOut.prog + dt / TF.scaleOut.DUR * (st.scaleOut.slow ? 0.32 : 1));
    }
    render();
    requestAnimationFrame(loop);
  }

  /* ---------- 膜厚のドラッグ ---------- */
  /** モードごとの「上面 y」と「px/nm」 */
  function filmGeom() {
    if (st.mode === 'bubble') {
      return { surfY: TF.modeBubble.CS.surfY, scale: TF.modeBubble.CS.scale, xMax: 470 };
    }
    return { surfY: D.L.SURF_Y, scale: D.L.SCALE, xMax: D.L.W };
  }

  function canvasPos(ev) {
    var c = $('view'), r = c.getBoundingClientRect();
    var p = (ev.touches && ev.touches[0]) ? ev.touches[0] : ev;
    return {
      x: (p.clientX - r.left) * D.L.W / r.width,
      y: (p.clientY - r.top) * D.L.H / r.height
    };
  }

  function nearBottom(pos) {
    var g = filmGeom();
    var bottomY = g.surfY + st.d * g.scale;
    return pos.x < g.xMax && Math.abs(pos.y - bottomY) <= 11;
  }

  function setThicknessFromY(y) {
    var g = filmGeom();
    var d = (y - g.surfY) / g.scale;
    st.d = Math.round(P.clamp(d, RANGE.d[0], RANGE.d[1]));
    syncSlider('d', 'd', 0);
    TF.modeBubble.invalidate();
  }

  function bindDrag() {
    var c = $('view');
    function down(ev) {
      var pos = canvasPos(ev);
      if (!nearBottom(pos)) return;
      dragging = true; st.dragHot = true;
      setThicknessFromY(pos.y);
      ev.preventDefault();
    }
    function move(ev) {
      var pos = canvasPos(ev);
      var inside = pos.x >= 0 && pos.x <= D.L.W && pos.y >= 0 && pos.y <= D.L.H;
      st.pointer = inside ? pos : null;
      st.hoverBtn = inside ? D.hitButton(pos.x, pos.y) : null;
      if (dragging) { setThicknessFromY(pos.y); ev.preventDefault(); return; }
      var hot = nearBottom(pos);
      if (hot !== st.dragHot) {
        st.dragHot = hot;
        c.classList.toggle('grab', hot);
      }
    }
    function up() { dragging = false; }
    // 図の中のボタン
    c.addEventListener('click', function (ev) {
      var pos = canvasPos(ev);
      var id = D.hitButton(pos.x, pos.y);
      if (id === 'pulse-wf') st.pulse = { kind: 'wavefront', t0: st.nowSec };
      else if (id === 'pulse-path') st.pulse = { kind: 'path', t0: st.nowSec };
    });
    c.addEventListener('mousedown', down);
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
    c.addEventListener('mouseleave', function () {
      if (!dragging) { st.dragHot = false; st.pointer = null; st.hoverBtn = null; c.classList.remove('grab'); }
    });
    c.addEventListener('touchstart', down, { passive: false });
    c.addEventListener('touchmove', move, { passive: false });
    window.addEventListener('touchend', up);
  }

  /* ---------- 数値表示 ---------- */
  function pad(v, digits, width) {
    var s = v.toFixed(digits);
    while (s.length < width) s = ' ' + s;
    return s;
  }

  function updateReadout(sol) {
    el.oR.textContent = pad(sol.rDeg, 2, 6) + ' °';
    el.oLamf.textContent = pad(sol.lambdaInFilm, 1, 6) + ' nm';
    el.oGeo.textContent = pad(sol.geomPath, 1, 7) + ' nm';
    el.oV.textContent = pad(sol.vRatio, 3, 5) + ' c';
    el.oOpt.textContent = pad(sol.delta, 1, 7) + ' nm';
    el.oInt.textContent = pad(sol.I, 3, 5);

    updateFlipBox(sol);
    updateFitBtns(sol);
    updatePanel(sol);
  }

  /**
   * 「光線1・光線2 の π ずれ」→「同位相／逆位相の 2 波源に読みかえた干渉条件」。
   * 正味 0 回なら同位相の 2 波源、1 回なら逆位相の 2 波源と同じ扱いになる。
   */
  var lastFlipKey = '';
  function updateFlipBox(sol) {
    var key = [sol.flips.top, sol.flips.bottom, sol.noInterference].join('|');
    if (key === lastFlipKey) return;
    lastFlipKey = key;

    el.oFlip1.textContent = (sol.flips.top ? 1 : 0) + ' 回';
    el.oFlip2.textContent = (sol.flips.bottom ? 1 : 0) + ' 回';

    if (sol.noInterference) {
      el.oCond.innerHTML = '⇒ この屈折率では片方の反射が起こらないので、干渉しません。';
      return;
    }
    var half = (sol.kind === 'half');       // 正味 1 回 → 逆位相の 2 波源
    el.oCond.innerHTML =
      '⇒ よって 2 つの光の干渉条件は、<b>' + (half ? '逆' : '同') + '位相</b>で振動する'
      + ' 2 波源の干渉条件を用いて、<br>'
      + '光路差 ＝ <span class="st">' + (half ? '(m + 1/2) λ' : 'm λ') + '</span> で強めあい、'
      + '光路差 ＝ <span class="wk">' + (half ? 'm λ' : '(m + 1/2) λ') + '</span> で弱めあい。'
      + '<span class="note">（m = 0, 1, 2, …）</span>';
  }

  /* ---------- 解説パネル（KaTeX） ---------- */
  var lastPanelKey = '';
  function updatePanel(sol) {
    var key = [sol.flips.top, sol.flips.bottom, sol.kind, sol.ratio.toFixed(2), sol.verdict.key].join('|');
    if (key === lastPanelKey) return;
    lastPanelKey = key;

    var t = sol.flips.top, b = sol.flips.bottom;
    el.phaseMsg.innerHTML =
      '<div style="font-size:13px;line-height:1.6">' +
      '<div>上面 (1 → n₁)：' + (t ? '<b style="color:#a12a1c">π ずれる</b>' : '<b>変化しない</b>') + '</div>' +
      '<div>下面 (n₁ → n₂)：' + (b ? '<b style="color:#a12a1c">π ずれる</b>' : '<b>変化しない</b>') +
      '　→ 正味 <b>' + (sol.nFlip % 2) + '</b> 回</div></div>';

    var half = (sol.kind === 'half');
    var strong = half ? '2n_1 d\\cos r = \\left(m+\\tfrac{1}{2}\\right)\\lambda' : '2n_1 d\\cos r = m\\lambda';
    var weak = half ? '2n_1 d\\cos r = m\\lambda' : '2n_1 d\\cos r = \\left(m+\\tfrac{1}{2}\\right)\\lambda';
    el.condMsg.innerHTML =
      '<div style="width:100%">' +
      '<div class="eq" style="margin:2px 0">' + tex('\\text{強めあう：}\\;' + strong) + '</div>' +
      '<div class="eq" style="margin:2px 0">' + tex('\\text{弱めあう：}\\;' + weak) + '</div>' +
      '<div class="note" style="text-align:center">(m = 0, 1, 2, …)</div></div>';

    el.nowMsg.innerHTML = '<div style="width:100%;text-align:center">' +
      tex('2n_1 d\\cos r = ' + sol.delta.toFixed(1) + '\\,\\mathrm{nm} = ' + sol.ratio.toFixed(2) + '\\lambda') +
      '<div class="note">→ いまは <b>' + sol.verdict.label + '</b></div></div>';
  }

  function tex(s) {
    try {
      return katex.renderToString(s, { throwOnError: false, displayMode: false });
    } catch (e) {
      return '<span class="note">' + s + '</span>';
    }
  }

  function renderStaticTex() {
    var nodes = document.querySelectorAll('.eq[data-tex]');
    for (var i = 0; i < nodes.length; i++) {
      nodes[i].innerHTML = tex(nodes[i].getAttribute('data-tex'));
    }
  }

  /* ---------- スライダー ---------- */
  function bindSlider(id, key, decimals, onDone) {
    var input = $('sl-' + id), out = $('v-' + id);
    input.addEventListener('input', function () {
      st[key] = parseFloat(input.value);
      out.textContent = decimals === 0 ? String(Math.round(st[key])) : st[key].toFixed(decimals);
      if (onDone) onDone();
    });
    out.textContent = decimals === 0 ? String(Math.round(st[key])) : st[key].toFixed(decimals);
  }

  function syncSlider(id, key, decimals) {
    $('sl-' + id).value = st[key];
    $('v-' + id).textContent = decimals === 0 ? String(Math.round(st[key])) : st[key].toFixed(decimals);
  }

  function syncAll() {
    syncSlider('lambda', 'lambda', 0); syncSlider('d', 'd', 0);
    syncSlider('theta', 'theta', 0);
    syncSeg('n1', 'n1'); syncSeg('n2', 'n2');
    updateSwatch(); updateThetaButton();
  }

  /* ---------- 屈折率の 3 択 ---------- */
  function bindSeg(id, key) {
    var wrap = $('seg-' + id);
    var btns = wrap.querySelectorAll('.seg-b');
    for (var i = 0; i < btns.length; i++) {
      (function (b) {
        b.addEventListener('click', function () {
          st[key] = parseFloat(b.getAttribute('data-v'));
          syncSeg(id, key);
          TF.modeBubble.invalidate();
        });
      })(btns[i]);
    }
    syncSeg(id, key);
  }

  function syncSeg(id, key) {
    var wrap = $('seg-' + id);
    if (!wrap) return;
    var btns = wrap.querySelectorAll('.seg-b');
    for (var i = 0; i < btns.length; i++) {
      var on = Math.abs(parseFloat(btns[i].getAttribute('data-v')) - st[key]) < 1e-6;
      btns[i].setAttribute('aria-pressed', on ? 'true' : 'false');
    }
  }

  function updateSwatch() {
    var c = P.wavelengthToRGB(st.lambda);
    $('sw-lambda').style.background = P.rgbCss(c);
    $('v-lamcol').textContent = '（' + P.colorName(st.lambda) + '色）';
  }

  /** 「もとの角度へ」ボタンの行き先。虹色モードは 30°（プリセット）、ほかは 0° */
  function homeTheta() {
    return (st.mode === 'bubble') ? BUBBLE_PRESET.theta : 0;
  }

  function updateThetaButton() {
    var home = homeTheta();
    $('btn-theta0').textContent = home + '°へ';
    $('slot-reset0').classList.toggle('on', st.theta !== home);
    // 46° は「d = 620 nm で 2.5λ」を見せるためのボタンなので、虹色モードでは出さない
    $('slot-reset46').classList.toggle('on',
      st.mode !== 'bubble' && st.theta !== THETA_DEMO);
  }

  /* ---------- モード ---------- */
  function setMode(m) {
    // モードの系統（通常モード ⇄ 虹色モード）が変わるときだけ、変数を入れかえる
    var from = groupOf(st.mode), to = groupOf(m);
    if (from !== to) {
      saved[from] = copyParams(st);
      for (var i = 0; i < PKEYS.length; i++) st[PKEYS[i]] = saved[to][PKEYS[i]];
      syncAll();
      TF.modeBubble.invalidate();
    }
    st.mode = m;
    $('tab-path').setAttribute('aria-selected', m === 'path' ? 'true' : 'false');
    $('tab-wave').setAttribute('aria-selected', m === 'wave' ? 'true' : 'false');
    $('tab-bubble').setAttribute('aria-selected', m === 'bubble' ? 'true' : 'false');
    $('grp-wave').hidden = (m !== 'wave');
    $('grp-path').hidden = (m !== 'path');
    $('grp-bubble').hidden = (m !== 'bubble');
    $('panel-main').hidden = (m === 'bubble');
    $('panel-bubble').hidden = (m !== 'bubble');
    $('checks-row').hidden = (m === 'bubble');
    $('lb-sum').hidden = (m !== 'wave');       // 合成波は波動モードだけ
    $('lbl-theta').textContent = (m === 'bubble') ? '見る角度 i' : '入射角 i';
    st.scaleOut = null; updateScaleBtn();
    if (m !== 'wave') { st.playing = false; updatePlayBtn(); }
    updateThetaButton();
  }

  function setLight(l) {
    st.light = l;
    $('btn-mono').setAttribute('aria-pressed', l === 'mono' ? 'true' : 'false');
    $('btn-white').setAttribute('aria-pressed', l === 'white' ? 'true' : 'false');
  }

  /** スマホ用「図だけを大きく表示」。図を画面いっぱいに広げ、ほかは隠す */
  function setFigFull(on) {
    st.figFull = !!on;
    document.body.classList.toggle('fig-full', st.figFull);
    var b = $('btn-figfull');
    if (b) {
      b.textContent = st.figFull ? '✕ 閉じる' : '⛶ 図だけを大きく表示';
      b.setAttribute('aria-pressed', st.figFull ? 'true' : 'false');
    }
    render();
  }

  function updateScaleBtn() {
    var b = $('btn-scale');
    if (b) b.textContent = st.scaleOut ? '← もどる' : '🔍 実寸';
    var g = $('grp-scale');
    if (g) g.hidden = !st.scaleOut;
    var sb = $('btn-scale-slow');
    if (sb) sb.setAttribute('aria-pressed', (st.scaleOut && st.scaleOut.slow) ? 'true' : 'false');
    var zin = !!st.scaleOut && st.scaleOut.dir === 'in';
    var word = zin ? 'ズームイン' : 'ズームアウト';
    var pb = $('btn-scale-pause');
    if (pb) {
      var started = !!st.scaleOut && st.scaleOut.prog > 0;
      pb.textContent = (st.scaleOut && st.scaleOut.paused)
        ? (started ? '▶ 再開' : '▶ ' + word + '開始') : '⏸ 一時停止';
      pb.classList.toggle('primary', !!st.scaleOut && st.scaleOut.paused && !started);
      var hs = $('hint-scale');
      if (hs) {
        hs.textContent = word + '開始をクリック！';
        hs.hidden = !(st.scaleOut && st.scaleOut.paused && !started);
      }
    }
    var db = $('btn-scale-dir');
    if (db) db.textContent = zin ? '🔭 ズームアウト' : '🔬 ズームイン';
    // 実寸のあいだは図だけを見せる
    document.body.classList.toggle('scale-only', !!st.scaleOut);
    // 実寸のあいだはモードごとのボタンと角度の操作を隠して、操作列を 1 行に保つ
    var ga = $('grp-angle');
    if (ga) ga.hidden = !!st.scaleOut;
    var m = st.mode;
    $('grp-wave').hidden = st.scaleOut ? true : (m !== 'wave');
    $('grp-path').hidden = st.scaleOut ? true : (m !== 'path');
    $('grp-bubble').hidden = st.scaleOut ? true : (m !== 'bubble');
  }

  function updatePlayBtn() {
    $('btn-play').textContent = st.playing ? '⏸ 一時停止' : '▶ スタート';
  }

  /** ステップを変える。②〜④ は出たときに吹き出しを「ピカッ」と光らせる */
  function setStep(n) {
    n = P.clamp(Math.round(n), 1, 4);
    if (n !== st.step && n >= 2) st.stepPulse = { step: n, t0: st.nowSec };
    if (n === 1) st.stepPulse = null;
    st.step = n;
    updateStepLabel();
  }

  function updateStepLabel() {
    $('step-label').textContent = 'ステップ ' + st.step + ' / 4';
    $('btn-prev').disabled = (st.step <= 1);
    $('btn-next').disabled = (st.step >= 4);
  }

  /* ---------- 初期化 ---------- */
  function init() {
    el = {
      oR: $('o-r'), oLamf: $('o-lamf'), oGeo: $('o-geo'), oV: $('o-v'),
      oOpt: $('o-opt'), oInt: $('o-int'),
      oFlip1: $('o-flip1'), oFlip2: $('o-flip2'), oCond: $('o-cond'),
      phaseMsg: $('phase-msg'), condMsg: $('cond-msg'), nowMsg: $('now-msg')
    };

    setupCanvas();
    renderStaticTex();
    bindDrag();

    bindSlider('lambda', 'lambda', 0, function () { updateSwatch(); TF.modeBubble.invalidate(); });
    bindSlider('d', 'd', 0, function () { TF.modeBubble.invalidate(); });
    bindSeg('n1', 'n1');
    bindSeg('n2', 'n2');
    bindSlider('theta', 'theta', 0, updateThetaButton);
    updateSwatch();
    updateThetaButton();

    $('btn-theta0').addEventListener('click', function () {
      st.theta = homeTheta(); syncSlider('theta', 'theta', 0); updateThetaButton();
    });
    $('btn-theta46').addEventListener('click', function () {
      st.theta = THETA_DEMO; syncSlider('theta', 'theta', 0); updateThetaButton();
    });

    $('tab-path').addEventListener('click', function () { setMode('path'); });
    $('tab-wave').addEventListener('click', function () { setMode('wave'); });
    $('tab-bubble').addEventListener('click', function () { setMode('bubble'); });
    $('btn-mono').addEventListener('click', function () { setLight('mono'); });
    $('btn-white').addEventListener('click', function () { setLight('white'); });
    $('btn-scale').addEventListener('click', function () {
      st.scaleOut = st.scaleOut ? null : { prog: 0, slow: false, paused: true, dir: 'out' };
      updateScaleBtn();
    });
    // スマホ用：図だけを画面いっぱいに表示する
    $('btn-figfull').addEventListener('click', function () { setFigFull(!st.figFull); });
    document.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape' && st.figFull) setFigFull(false);
    });
    $('btn-scale-pause').addEventListener('click', function () {
      if (st.scaleOut) { st.scaleOut.paused = !st.scaleOut.paused; updateScaleBtn(); }
    });
    $('btn-scale-dir').addEventListener('click', function () {
      if (!st.scaleOut) return;
      st.scaleOut.dir = (st.scaleOut.dir === 'in') ? 'out' : 'in';
      st.scaleOut.prog = 0; st.scaleOut.paused = false;
      updateScaleBtn();
    });
    $('btn-scale-slow').addEventListener('click', function () {
      if (st.scaleOut) { st.scaleOut.slow = !st.scaleOut.slow; updateScaleBtn(); }
    });
    $('btn-scale-reset').addEventListener('click', function () {
      if (st.scaleOut) { st.scaleOut.prog = 0; st.scaleOut.paused = true; updateScaleBtn(); }
    });
    $('btn-play').addEventListener('click', function () {
      st.playing = !st.playing; updatePlayBtn();
    });
    $('btn-slow').addEventListener('click', function () {
      st.slow = !st.slow;
      $('btn-slow').setAttribute('aria-pressed', st.slow ? 'true' : 'false');
    });
    $('btn-reset').addEventListener('click', function () {
      st.t = 0; st.playing = false; updatePlayBtn();   // スローは解除しない
    });

    $('btn-prev').addEventListener('click', function () { setStep(st.step - 1); });
    $('btn-next').addEventListener('click', function () { setStep(st.step + 1); });
    $('btn-step-reset').addEventListener('click', function () { setStep(1); });

    $('ck-wf').addEventListener('change', function () { st.showWavefront = this.checked; });
    $('ck-vel').addEventListener('change', function () { st.showVelocity = this.checked; });
    $('ck-lab').addEventListener('change', function () { st.showLabels = this.checked; });
    $('ck-sum').addEventListener('change', function () { st.showSum = this.checked; });

    $('btn-fit-strong').addEventListener('click', function () { fit('strong', 'nearest'); });
    $('btn-fit-weak').addEventListener('click', function () { fit('weak', 'nearest'); });
    $('btn-fit-strong-next').addEventListener('click', function () { fit('strong', 'next'); });
    $('btn-fit-weak-next').addEventListener('click', function () { fit('weak', 'next'); });

    // 既定は d = 620 nm：i = 0° で光路差 3λ、46° で 2.5λ になる（授業の導入用）
    syncAll();                // スライダーのつまみを既定値に合わせる
    setMode('wave');
    setLight('mono');
    updatePlayBtn();
    updateScaleBtn();
    updateStepLabel();

    requestAnimationFrame(loop);
  }

  function fitSet(want) {
    return P.thicknessSet(want, st.d, st.lambda, st.n1, st.n2, st.theta,
      RANGE.d[0], RANGE.d[1]);
  }

  function fit(want, which) {
    var hit = fitSet(want)[which || 'nearest'];
    if (!hit) return;
    st.d = hit.d;           // 波がぴったり合うよう、丸めずに使う
    syncSlider('d', 'd', 0);
    TF.modeBubble.invalidate();
  }

  /** 4 つの膜厚ボタンのラベルと強調を更新する */
  function updateFitBtns(sol) {
    var ok = !sol.noInterference;
    var sets = { strong: fitSet('strong'), weak: fitSet('weak') };
    var defs = [
      ['btn-fit-strong', 'lb-fit-strong', sets.strong.nearest, '強めあい d'],
      ['btn-fit-weak', 'lb-fit-weak', sets.weak.nearest, '弱めあい d'],
      ['btn-fit-strong-next', 'lb-fit-strong-next', sets.strong.next, '強めあい d'],
      ['btn-fit-weak-next', 'lb-fit-weak-next', sets.weak.next, '弱めあい d']
    ];
    for (var i = 0; i < defs.length; i++) {
      var b = $(defs[i][0]), lb = $(defs[i][1]), hit = ok ? defs[i][2] : null;
      lb.textContent = hit
        ? defs[i][3] + ' ＝ ' + Math.round(hit.d) + ' nm（m = ' + hit.m + '）'
        : defs[i][3] + ' ＝ ―（範囲外）';
      b.disabled = !hit;
    }
    // 強調の基準は「観測者に見える判定」とそろえる
    $('btn-fit-strong').classList.toggle('fit-on', ok && sol.verdict.key === 'strong');
    $('btn-fit-weak').classList.toggle('fit-on', ok && sol.verdict.key === 'weak');
    $('btn-fit-strong-next').classList.remove('fit-on');
    $('btn-fit-weak-next').classList.remove('fit-on');
  }

  return {
    init: init, state: st, render: render, RANGE: RANGE,
    setMode: setMode, setLight: setLight,
    /** 自動テスト用 */
    api: {
      set: function (patch) {
        for (var k in patch) if (Object.prototype.hasOwnProperty.call(patch, k)) st[k] = patch[k];
        syncAll();
        TF.modeBubble.invalidate();
        render();
      },
      solve: function () { return P.solve(st); },
      state: function () { return st; },
      setMode: setMode,
      setLight: setLight,
      /** ドラッグの当たり判定テスト用 */
      nearBottom: function (x, y) { return nearBottom({ x: x, y: y }); },
      pulse: function (kind) { st.pulse = { kind: kind, t0: st.nowSec }; },
      dragTo: function (y) { setThicknessFromY(y); render(); },
      figFull: function (on) { setFigFull(on); }
    }
  };
})();

