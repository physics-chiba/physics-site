/* ===== 45_scale.js ===== */
/* 「実寸」ズームアウト
 * いま見ている「薄膜で反射した光を人が見ている」状態から、
 * 実際の人のスケール（1〜2 m）まで連続的にズームアウトする。
 * 光の波長や薄膜の厚さが、人の大きさに比べてどれほど小さいかを実感させるのが目的。
 * 物理計算は概算でよい。
 */
window.TF = window.TF || {};
TF.scaleOut = (function () {
  'use strict';
  var D = TF.draw, P = TF.phys;
  var L = D.L;
  var JP = '"Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';

  var VIEW0 = L.W / L.SCALE;   // シミュレーションの視野幅 ≒ 5833 nm
  var VIEW1 = 2.6e9;           // ズームアウトの終点：2.6 m（人のスケール）
  var VIEW_IN = 0.5;           // ズームインの終点：0.5 nm（原子が数個見える）
  var DUR = 6.0;               // かける秒数

  var ATOM_D = 0.1;            // 原子の大きさ 約 0.1 nm（10⁻¹⁰ m）
  var ATOM_SP = 0.16;          // 原子の間かく（ざっくり）[nm]

  var WAVE_VIEW_MAX = 5e4;     // 画面の横幅がこれ（50 μm）を超えたら、波としては描かない
  var EYE_H = 1.55e9;          // 目の高さ 1.55 m [nm]
  var BODY_H = 1.70e9;         // 身長 1.70 m [nm]

  /* 薄膜の厚さは「縦方向」の長さなので、比べるものもすべて縦に立てて描く */
  var REFS = [
    { h: 100, name: 'ウイルス', c: '#8fa2c8' },
    { h: 2000, name: '細菌', c: '#7fb79c' },
    { h: 8e4, name: '髪の毛の太さ', c: '#c9a86a' },
    { h: 2.4e7, name: '硬貨の直径', c: '#a9adb5' },
    { h: ATOM_D, name: '原子', c: '#f0a6c0' }
  ];

  function fmtLen(nm) {
    if (nm < 1000) return (Math.round(nm * 10) / 10) + ' nm';
    if (nm < 1e6) return (Math.round(nm / 100) / 10) + ' μm';
    if (nm < 1e9) return (Math.round(nm / 1e5) / 10) + ' mm';
    return (Math.round(nm / 1e8) / 10) + ' m';
  }

  /** dir: 'out'（人のスケールへ）／'in'（原子のスケールへ） */
  function viewWidth(prog, dir) {
    var v1 = (dir === 'in') ? VIEW_IN : VIEW1;
    return Math.exp(Math.log(VIEW0) + (Math.log(v1) - Math.log(VIEW0)) * prog);
  }

  /**
   * 薄膜の中の原子（模式図）。
   * 原子核と電子は、見やすいように実際よりずっと大きく描いている。
   */
  function atoms(ctx, pxPerNm, topY, groundY, W, nowSec) {
    var sp = ATOM_SP * pxPerNm;              // 原子の間かく [px]
    if (sp < 12) return null;                // これより細かいと、ただのもやになる
    var r = ATOM_D * 0.5 * pxPerNm;          // 電子雲の半径 [px]
    var big = (sp >= 150);                   // 原子核と電子まで描くか
    var center = null;
    ctx.save();
    ctx.beginPath(); ctx.rect(0, 58, W, groundY - 58); ctx.clip();   // 見出しの下だけ
    var rows = Math.min(70, Math.ceil((groundY - Math.max(0, topY)) / sp) + 2);
    var cols = Math.min(70, Math.ceil(W / sp) + 2);
    for (var j = 0; j < rows; j++) {
      var cy = groundY - sp * 0.6 - j * sp;
      if (cy < -sp) break;
      for (var i = 0; i < cols; i++) {
        var cx = i * sp + (j % 2 ? sp * 0.5 : 0) - sp * 0.25;
        if (cx > W + sp) break;
        if (big) {
          var gr = ctx.createRadialGradient(cx, cy, r * 0.15, cx, cy, r);
          gr.addColorStop(0, 'rgba(150,205,255,0.38)');
          gr.addColorStop(1, 'rgba(90,140,220,0.04)');
          ctx.fillStyle = gr;
        } else {
          ctx.fillStyle = 'rgba(150,205,255,0.22)';
        }
        ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.fill();
        if (big) {
          // 電子の軌道と電子（アニメ）
          var ph = (i * 1.7 + j * 2.3);
          ctx.save();
          ctx.translate(cx, cy); ctx.rotate(0.4 + j * 0.5);
          ctx.strokeStyle = 'rgba(255,255,255,0.26)'; ctx.lineWidth = 1.1;
          ctx.beginPath(); ctx.ellipse(0, 0, r * 0.78, r * 0.3, 0, 0, Math.PI * 2); ctx.stroke();
          var a2 = nowSec * 1.6 + ph;
          var ex = Math.cos(a2) * r * 0.78, ey = Math.sin(a2) * r * 0.3;
          ctx.beginPath(); ctx.arc(ex, ey, Math.max(3, r * 0.055), 0, Math.PI * 2);
          ctx.fillStyle = '#9fe8ff'; ctx.fill();
          ctx.restore();
          // 原子核
          ctx.beginPath(); ctx.arc(cx, cy, Math.max(3.5, r * 0.075), 0, Math.PI * 2);
          ctx.fillStyle = '#ff8a6b'; ctx.fill();
          if (!center && cx > W * 0.46 && cx < W * 0.82 && cy > 190 && cy < groundY - 150) {
            center = { x: cx, y: cy, r: r };
          }
        }
      }
    }
    ctx.restore();
    return center;
  }

  /** 棒人間（目の位置を返す） */
  function person(ctx, footX, footY, hPx) {
    var head = hPx * 0.13, eyeY = footY - hPx * 0.91;
    ctx.save();
    ctx.strokeStyle = '#dfe6ee'; ctx.fillStyle = '#dfe6ee';
    ctx.lineWidth = Math.max(1.2, hPx * 0.035);
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    // 頭
    ctx.beginPath(); ctx.arc(footX, footY - hPx * 0.925, head, 0, Math.PI * 2); ctx.fill();
    // 胴と手足
    ctx.beginPath();
    ctx.moveTo(footX, footY - hPx * 0.80); ctx.lineTo(footX, footY - hPx * 0.42);
    ctx.moveTo(footX, footY - hPx * 0.72); ctx.lineTo(footX - hPx * 0.16, footY - hPx * 0.50);
    ctx.moveTo(footX, footY - hPx * 0.72); ctx.lineTo(footX + hPx * 0.16, footY - hPx * 0.52);
    ctx.moveTo(footX, footY - hPx * 0.42); ctx.lineTo(footX - hPx * 0.13, footY);
    ctx.moveTo(footX, footY - hPx * 0.42); ctx.lineTo(footX + hPx * 0.13, footY);
    ctx.stroke();
    ctx.restore();
    return { x: footX, y: eyeY };
  }

  function render(ctx, st, sol, prog) {
    var W = L.W, H = L.H;
    var dir = (st.scaleOut && st.scaleOut.dir === 'in') ? 'in' : 'out';
    var zin = (dir === 'in');
    var view = viewWidth(prog, dir);
    var pxPerNm = W / view;

    var srcPt = null;
    var groundY = H - 78;          // 薄膜（水面・シャボン膜など）の高さ
    var filmX = W * 0.34;          // 光が当たっている点

    ctx.save();
    // 背景（ズームアウトにつれて空気の色 → 部屋の色）
    var g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, '#0f1216'); g.addColorStop(1, '#1a2028');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);

    /* ---- 薄膜（実寸） ---- */
    var dpx = st.d * pxPerNm;
    ctx.fillStyle = '#25333d';
    ctx.fillRect(0, groundY - Math.max(0.5, dpx), W, Math.max(1, dpx) + 26);
    ctx.strokeStyle = '#4fd0e0'; ctx.lineWidth = Math.max(0.8, Math.min(2.5, dpx));
    ctx.beginPath();
    ctx.moveTo(0, groundY - dpx); ctx.lineTo(W, groundY - dpx);
    ctx.stroke();
    ctx.strokeStyle = '#3a7f8c'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(0, groundY); ctx.lineTo(W, groundY); ctx.stroke();

    /* ---- 光線（入射と反射）と観測者 ---- */
    var eyePx = EYE_H * pxPerNm;                 // 目の高さ [px]
    var eyeX = filmX + eyePx * 0.42;
    var eyeY = groundY - eyePx;
    var hit = { x: filmX, y: groundY - dpx };

    var bodyPx0 = BODY_H * pxPerNm;
    if (bodyPx0 < H * 0.85 && bodyPx0 > 12) person(ctx, eyeX, groundY, bodyPx0);

    ctx.save();
    ctx.lineCap = 'round';
    var c = P.wavelengthToRGB(st.lambda);
    // 目が画面の外でも「向き」は変えず、画面の上端で切る
    function clipUp(from, to) {
      var dx = to.x - from.x, dy = to.y - from.y;
      var len = Math.hypot(dx, dy) || 1;
      dx /= len; dy /= len;
      var t = len;
      if (dy < -1e-6) t = Math.min(t, (from.y - (-20)) / -dy);
      if (dx > 1e-6) t = Math.min(t, (W + 20 - from.x) / dx);
      if (dx < -1e-6) t = Math.min(t, (from.x + 20) / -dx);
      return { x: from.x + dx * t, y: from.y + dy * t };
    }
    var eyePt = { x: eyeX, y: eyeY };
    var inPt = { x: 2 * hit.x - eyeX, y: eyeY };
    var showRay = (hit.y > -10);        // 反射点が画面の中にあるあいだだけ光線を描く
    ctx.strokeStyle = 'rgba(255,255,255,0.55)'; ctx.lineWidth = 2.4;
    var s0 = clipUp(hit, inPt);
    if (showRay) { ctx.beginPath(); ctx.moveTo(s0.x, s0.y); ctx.lineTo(hit.x, hit.y); ctx.stroke(); }
    // 光源は入射光の線の上（見出しと重ならないところ）に置く
    var tSrc = (hit.y - s0.y) > 1 ? (76 - s0.y) / (hit.y - s0.y) : 0;
    tSrc = P.clamp(tSrc, 0.04, 0.5);
    srcPt = {
      x: P.clamp(s0.x + (hit.x - s0.x) * tSrc, 30, W - 30),
      y: P.clamp(s0.y + (hit.y - s0.y) * tSrc, 76, H - 90)
    };
    ctx.strokeStyle = P.rgbCss(c, 0.95); ctx.lineWidth = 3;
    var e0 = clipUp(hit, eyePt);
    if (showRay) { ctx.beginPath(); ctx.moveTo(hit.x, hit.y); ctx.lineTo(e0.x, e0.y); ctx.stroke(); }
    ctx.restore();

    // 光源（電球）：入射光がやってくるところ＝左上
    if (showRay) D.lightBulb(ctx, srcPt, { dark: true });

    // 薄膜の中の原子（ズームインのとき）
    var atomC = zin ? atoms(ctx, pxPerNm, groundY - dpx, groundY, W, st.nowSec || 0) : null;
    if (atomC) {
      ctx.save();
      ctx.font = 'bold 12px ' + JP; ctx.fillStyle = '#dfe6ee';
      ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
      ctx.fillText('原子（大きさ 約 0.1 nm ＝ 10⁻¹⁰ m）', atomC.x, atomC.y - atomC.r - 10);
      ctx.textAlign = 'right'; ctx.textBaseline = 'bottom';
      ctx.font = '10.5px ' + JP; ctx.fillStyle = '#8c949d';
      ctx.fillText('※ 原子核と電子は、見やすいように大きく描いています', W - 18, groundY - 6);
      ctx.restore();
    }

    var bodyPx = bodyPx0;
    if (zin) {
      // ズームイン中は人・目の表示はしない
    } else if (bodyPx < H * 0.85 && bodyPx > 12) {
      ctx.save();
      ctx.font = '12px ' + JP; ctx.fillStyle = '#dfe6ee';
      ctx.textBaseline = 'middle';
      ctx.fillText('人（1.7 m）', eyeX + bodyPx * 0.22, groundY - bodyPx * 0.5);
      ctx.restore();
    } else if (bodyPx >= H * 0.85) {
      // まだ人が入りきらない：反射光の線の上に「見る方向」の目を置いて向きを示す
      var vx = hit.x - e0.x, vy = hit.y - e0.y;
      var vl = Math.hypot(vx, vy) || 1; vx /= vl; vy /= vl;
      var q = { x: e0.x + vx * 40, y: e0.y + vy * 40 };
      for (var tt = 40; tt < 460; tt += 6) {
        q = { x: e0.x + vx * tt, y: e0.y + vy * tt };
        if (q.x > 46 && q.x < W - 46 && q.y > 108 && q.y < groundY - 60) break;
      }
      D.eye(ctx, q, { x: vx, y: vy }, 0.78, '見る方向');
      ctx.save();
      ctx.font = '12px ' + JP; ctx.fillStyle = '#8c949d';
      ctx.textBaseline = 'top';
      ctx.textAlign = 'center';
      ctx.fillText('人の目はまだずっと先（画面に入りきりません）',
        P.clamp(q.x, 170, W - 170), q.y + 30);
      ctx.textAlign = 'left';
      ctx.restore();
    }

    /* ---- 見出しと数値 ---- */
    ctx.font = 'bold 16px ' + JP; ctx.fillStyle = '#f2f4f7';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText(zin ? '原子の大きさまで拡大すると' : '実物の大きさで見ると', 18, 14);
    ctx.font = '12.5px ' + JP; ctx.fillStyle = '#aab3bd';
    ctx.fillText(zin
      ? '「薄膜で反射した光を人が見ている」ところから、薄膜の中へ入っていきます'
      : '「薄膜で反射した光を人が見ている」ところから、そのまま引いていきます', 18, 38);

    ctx.textAlign = 'right';
    ctx.font = 'bold 15px ' + JP; ctx.fillStyle = '#ffd479';
    ctx.fillText('画面の横幅 ＝ ' + fmtLen(view), W - 18, 14);
    ctx.font = '12px ' + JP; ctx.fillStyle = '#aab3bd';
    if (zin) {
      ctx.fillText(Math.round(VIEW0 / view) + ' 倍 ズームイン', W - 18, 36);
    } else {
      var zoom = view / VIEW0;
      ctx.fillText((zoom >= 1000 ? Math.round(zoom / 1000) + ' 千倍' : Math.round(zoom) + ' 倍')
        + ' ズームアウト', W - 18, 36);
    }
    ctx.textAlign = 'left';

    /* ---- 光の波長：縦向きの波として、図の右側に ---- */
    var lpx = st.lambda * pxPerNm;
    var wx = W - 108;
    // 下端は比べる棒（地面）とそろえる
    var wTop = 132, wBot = groundY;
    var asWave = (view <= WAVE_VIEW_MAX);   // これより広い視野では、波としては描けない
    ctx.save();
    if (asWave) {
      ctx.strokeStyle = P.rgbCss(c); ctx.lineWidth = 2;
      ctx.beginPath();
      for (var yy = wTop; yy <= wBot; yy += 1.5) {
        var xx = wx + 13 * Math.sin(2 * Math.PI * (wBot - yy) / lpx);
        if (yy === wTop) ctx.moveTo(xx, yy); else ctx.lineTo(xx, yy);
      }
      ctx.stroke();
      // 1 波長ぶんの目印
      if (lpx > 14 && lpx < (wBot - wTop)) {
        ctx.strokeStyle = 'rgba(255,255,255,0.75)'; ctx.lineWidth = 1;
        ctx.setLineDash([3, 3]);
        ctx.beginPath();
        ctx.moveTo(wx - 20, wBot); ctx.lineTo(wx + 34, wBot);
        ctx.moveTo(wx - 20, wBot - lpx); ctx.lineTo(wx + 34, wBot - lpx);
        ctx.stroke(); ctx.setLineDash([]);
      }
    } else {
      // 実際の高さ（λ）の棒として、ほかの比べる棒と同じように縮めていく
      var hb = Math.max(2.5, lpx), bwv = Math.max(9, Math.min(20, hb * 0.16));
      ctx.fillStyle = P.rgbCss(c);
      D.roundRect(ctx, wx - bwv / 2, wBot - hb, bwv, hb, Math.min(4, bwv / 2));
      ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.6)'; ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(wx - bwv / 2 - 4, wBot - hb); ctx.lineTo(wx + bwv / 2 + 4, wBot - hb);
      ctx.stroke();
    }
    // 見出しは横書きで
    ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
    if (asWave) {
      ctx.font = '12px ' + JP; ctx.fillStyle = P.rgbCss(c);
      ctx.fillText('光の波長 λ = ' + Math.round(st.lambda) + ' nm（'
        + P.colorName(st.lambda) + '色）', wx, wTop - 20);
      if (lpx > (wBot - wTop)) {
        ctx.font = '11px ' + JP; ctx.fillStyle = '#9aa3ac';
        ctx.fillText('（1 波長は画面よりずっと長い）', wx, wTop - 5);
      }
    } else {
      var ly2 = wBot - Math.max(2.5, lpx) - 8;
      ctx.font = '11.5px ' + JP; ctx.fillStyle = P.rgbCss(c);
      ctx.fillText('光の波長 λ', wx, ly2 - 28);
      ctx.font = 'bold 11.5px ' + JP;
      ctx.fillText(Math.round(st.lambda) + ' nm', wx, ly2 - 14);
      ctx.font = '10.5px ' + JP; ctx.fillStyle = '#9aa3ac';
      ctx.fillText('（細かすぎて、もはや波に見えない）', wx, ly2);
    }
    ctx.textAlign = 'left';
    ctx.restore();

    /* ---- 縦に並べて比べる（薄膜の厚さは縦方向の長さなので） ---- */
    var items = [{ h: st.d, name: '薄膜の厚さ d', c: '#4fd0e0', keep: true }];
    // 波として描いているあいだだけ、左の並びにも λ を入れて d と見くらべられるようにする
    // （波として描けなくなってからは、右の柱が縮んで同じ役目をするので重複させない）
    if (asWave) items.push({ h: st.lambda, name: '光の波長 λ', c: P.rgbCss(c), keep: true });
    for (var i = 0; i < REFS.length; i++) items.push(REFS[i]);

    var slotX = 96, drawn = 0;
    ctx.save();
    for (var k = 0; k < items.length; k++) {
      var it = items[k];
      var hpx = it.h * pxPerNm;
      var tall = (hpx > H * 0.6);
      if (!it.keep && (hpx < 2 || tall)) continue;
      if (it.keep && tall && !zin) continue;
      // ズームイン中は、画面より高くなったものは「画面の外へ」と示す
      var over = (it.keep && tall && zin);
      var draw = over ? (groundY - 96) : Math.max(it.keep ? 2.5 : 2, hpx);
      var bw = Math.max(9, Math.min(20, draw * 0.16));
      var bx = slotX, byTop = groundY - draw;
      ctx.globalAlpha = 1;
      ctx.fillStyle = it.c;
      D.roundRect(ctx, bx, byTop, bw, draw, Math.min(4, bw / 2)); ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.6)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(bx - 4, byTop); ctx.lineTo(bx + bw + 4, byTop); ctx.stroke();
      // 説明は横書き。名前と長さを改行して 2〜3 行で書く
      ctx.save();
      ctx.font = '11.5px ' + JP; ctx.fillStyle = '#dfe6ee';
      ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
      var cxL = bx + bw / 2;
      var lines = [it.name, fmtLen(it.h)];
      if (hpx < 1) lines.push('（もう見えない）');
      if (over) lines.push('（画面の外へ）');
      for (var q = 0; q < lines.length; q++) {
        if (q === 1) { ctx.font = 'bold 11.5px ' + JP; ctx.fillStyle = it.c; }
        if (q === 2) { ctx.font = '10.5px ' + JP; ctx.fillStyle = '#9aa3ac'; }
        ctx.fillText(lines[q], cxL, byTop - 8 - (lines.length - 1 - q) * 14);
      }
      if (over) {   // 上へ続いていることを示す矢印
        ctx.strokeStyle = it.c; ctx.fillStyle = it.c; ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(bx + bw / 2, byTop); ctx.lineTo(bx + bw / 2, byTop - 12); ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(bx + bw / 2, byTop - 20); ctx.lineTo(bx + bw / 2 - 5, byTop - 10);
        ctx.lineTo(bx + bw / 2 + 5, byTop - 10); ctx.closePath(); ctx.fill();
      }
      ctx.restore();
      slotX += bw + 92;
      drawn++;
      if (slotX > W * 0.64) break;
    }
    ctx.restore();

    /* ---- ものさし（縦） ---- */
    var target = Math.pow(10, Math.round(Math.log(view * 0.22) / Math.LN10));
    var sbH = target * pxPerNm;
    if (sbH > 24 && sbH < H * 0.7) {
      var sx = 34;
      ctx.save();
      ctx.strokeStyle = '#f2f4f7'; ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(sx, groundY); ctx.lineTo(sx, groundY - sbH);
      ctx.moveTo(sx - 6, groundY); ctx.lineTo(sx + 6, groundY);
      ctx.moveTo(sx - 6, groundY - sbH); ctx.lineTo(sx + 6, groundY - sbH);
      ctx.stroke();
      ctx.save();
      ctx.translate(sx - 8, groundY - sbH / 2);
      ctx.rotate(-Math.PI / 2);
      ctx.font = 'bold 12px ' + JP; ctx.fillStyle = '#f2f4f7';
      ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
      ctx.fillText(fmtLen(target), 0, 0);
      ctx.restore();
      ctx.restore();
    }

    /* ---- まとめ ---- */
    ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
    if (prog > 0.96) {
      ctx.font = 'bold 13px ' + JP; ctx.fillStyle = '#ffd479';
      if (zin) {
        ctx.fillText('薄膜の厚さ ' + Math.round(st.d) + ' nm は、原子（約 0.1 nm）が約 '
          + Math.round(st.d / ATOM_D) + ' 個ぶん。'
          + '光の波長 ' + Math.round(st.lambda) + ' nm も約 '
          + Math.round(st.lambda / ATOM_D) + ' 個ぶん。', W / 2, H - 30);
        ctx.fillText('薄膜も光の波長も、原子にくらべればずっと大きいのです。', W / 2, H - 12);
      } else {
        ctx.fillText('薄膜の厚さ ' + Math.round(st.d) + ' nm は、人の身長 1.7 m の約 '
          + Math.round(BODY_H / st.d / 1e5) / 10 + ' 百万分の 1', W / 2, H - 30);
        ctx.fillText('だから薄膜は、目には見えないほど薄いのです。', W / 2, H - 12);
      }
    } else if (prog <= 0) {
      ctx.font = 'bold 12.5px ' + JP; ctx.fillStyle = '#ffd479';
      ctx.fillText(zin
        ? '「▶ ズームイン開始」を押すと、薄膜の中の原子の大きさまで拡大していきます'
        : '「▶ ズームアウト開始」を押すと、ここから実際の大きさまで引いていきます', W / 2, H - 14);
    } else {
      ctx.font = '12px ' + JP; ctx.fillStyle = '#8c949d';
      ctx.fillText((zin ? 'ズームイン中…（' : 'ズームアウト中…（')
        + Math.round(prog * 100) + '%）', W / 2, H - 14);
    }
    ctx.textAlign = 'left';
    ctx.restore();
  }

  return { render: render, DUR: DUR, VIEW0: VIEW0, VIEW1: VIEW1, viewWidth: viewWidth, fmtLen: fmtLen };
})();

