/* ===== 60_mode_wave.js ===== */
/* 波動モード：光路に沿って 1 次元の波が進む様子を描く（本体レンダラ） */
window.TF = window.TF || {};
TF.modeWave = (function () {
  'use strict';
  var D = TF.draw, P = TF.phys;
  var L = D.L, COL = D.COL;

  var FONT = '12px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';

  /** 光線の軸（細い線）を引く */
  function axis(ctx, leg, alpha) {
    if (leg.pxLen < 1) return;
    ctx.save();
    ctx.strokeStyle = leg.color;
    ctx.globalAlpha = alpha === undefined ? 0.28 : alpha;
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(leg.a.x, leg.a.y); ctx.lineTo(leg.b.x, leg.b.y); ctx.stroke();
    ctx.restore();
  }

  /* 速度ベクトルは、それぞれの光線と同系色（濃いめ）にする。
     光線の色は波長で少し変わるので、その色をそのまま暗くして使う。 */
  function velColor(leg) { return D.shade(leg.color, 0.72); }

  /** 進行方向の速度ベクトル（offPx で光線からの横方向の離し量を指定） */
  function velocity(ctx, leg, label, at, offPx) {
    if (leg.pxLen < 44) return;
    var col = velColor(leg);
    var f = at === undefined ? 0.5 : at;
    var p = D.vec(leg.a.x + (leg.b.x - leg.a.x) * f, leg.a.y + (leg.b.y - leg.a.y) * f);
    var base = D.add(p, D.mul(leg.nrm, offPx === undefined ? 30 : offPx));
    var lenPx = 34 / leg.n;
    D.arrow(ctx, base, leg.dir, lenPx, col, 2.4, 7);
    ctx.save();
    ctx.font = 'bold ' + FONT; ctx.fillStyle = col;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    var lp = D.add(base, D.mul(leg.dir, lenPx / 2));
    lp = D.add(lp, D.mul(leg.nrm, offPx > 0 ? 15 : -15));
    ctx.fillText(label, lp.x, lp.y);
    ctx.restore();
  }

  /** 反射の吹き出しを、それぞれの反射点のすぐ近くに置く（光線と重ならない側へ） */
  function events(ctx, st, sol, sc) {
    // 上面の反射 B₁ … 光線は右上へ抜けるので、境界のすぐ下・右側へ
    var b1 = sc.refl1Pt;
    D.piCallout(ctx, b1, 'at', D.vec(b1.x + 30, sc.bottomY + 34),
      '上面 B₁ での反射 (1 → n₁)', sol.flips.top);
    // 下面の反射 C … 下の物質側（空いている左下）へ
    var cpt = D.vec(sc.B.x + L.OFF.filmDown * sc.offK, sc.B.y);
    D.piCallout(ctx, cpt, 'at', D.vec(cpt.x - 254, sc.bottomY + 58),
      '下面 C での反射 (n₁ → n₂)', sol.flips.bottom);
  }

  /** 観測者の目（合成波の先で、光線に沿って下を見る向き） */
  function drawEye(ctx, sc) {
    var o = sc.legs.s1;
    if (o.pxLen < 40) return null;
    var gaze = D.mul(o.dir, -1);                    // 視線は光線をさかのぼる向き
    var ep = D.add(o.b, D.mul(o.dir, 40));          // 光線の延長上（先）に立つ
    ep = D.vec(P.clamp(ep.x, 30, L.W - 30), P.clamp(ep.y, 38, L.BAND_Y - 26));
    D.eye(ctx, ep, gaze, 0.9, '見る方向');
    return ep;
  }

  /** 判定バッジ */
  function observer(ctx, st, sol, sc) {
    var o = sc.legs.s1;
    if (o.pxLen < 40) return;
    var ep = drawEye(ctx, sc);
    if (!ep) return;

    var v = sol.verdict;
    var bg = (v.key === 'strong') ? '#e6f4ea' : (v.key === 'weak' ? '#fdecea' : '#fff6e0');
    var fg = (v.key === 'strong') ? '#1b6b34' : (v.key === 'weak' ? '#a12a1c' : '#7a5a00');
    var bd = (v.key === 'strong') ? '#1b6b34' : (v.key === 'weak' ? '#a12a1c' : '#c99a00');

    ctx.save();
    ctx.font = 'bold 15px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
    var txt = '観測者方向で ' + v.label;
    var w = ctx.measureText(txt).width + 44;
    // 目のすぐ横（余白のある側）に置く
    var bx = (ep.x > L.W / 2) ? (ep.x - 34 - w) : (ep.x + 34);
    bx = P.clamp(bx, 6, L.W - w - 6);
    var by = P.clamp(ep.y - 14, 6, L.BAND_Y - 34);
    D.roundRect(ctx, bx, by, w, 28, 7);
    ctx.fillStyle = bg; ctx.fill();
    ctx.strokeStyle = bd; ctx.lineWidth = 1.4; ctx.stroke();
    // 実際に見える色（波長の色 × 明るさ）
    var c = P.wavelengthToRGB(st.lambda);
    ctx.fillStyle = '#ffffff'; ctx.fillRect(bx + 7, by + 7, 14, 14);
    ctx.fillStyle = P.rgbCss(c, 0.15 + 0.85 * sol.I);
    ctx.fillRect(bx + 7, by + 7, 14, 14);
    ctx.strokeStyle = '#8a8a8a'; ctx.lineWidth = 1;
    ctx.strokeRect(bx + 7.5, by + 7.5, 13, 13);
    ctx.fillStyle = fg; ctx.textBaseline = 'middle';
    ctx.fillText(txt, bx + 28, by + 15);
    ctx.restore();
  }

  /** 表示上のズレについての注記 */
  function offsetNote(ctx, sc) {
    if (sc.offK < 0.06) return;
    ctx.save();
    ctx.font = '11px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
    ctx.fillStyle = '#8a8a8a'; ctx.textBaseline = 'bottom';
    ctx.fillText('※ 重なって見えないよう、2 つの光を表示上わずかに横へずらしています', 10, L.BAND_Y - 24);
    ctx.restore();
  }

  /** 凡例（pos: 'br' 右下 ／ 'tl' 左上） */
  function legend(ctx, st, noSum, pos) {
    var items = [
      { c: COL.ray1, t: '光線1：空気-薄膜の境界で反射' },
      { c: COL.ray2, t: '光線2：薄膜-下の物質の境界で反射' },
      { c: COL.sum, t: '合成波（2 つの重ね合わせ）' }
    ];
    if (noSum) items.pop();
    ctx.save();
    ctx.font = FONT; ctx.textBaseline = 'middle';
    // 箱の幅は中身に合わせる（薄膜の右上に置いても B₁ にかからないように）
    var tw = 0, q;
    for (q = 0; q < items.length; q++) tw = Math.max(tw, ctx.measureText(items[q].t).width);
    var bw = tw + 46, bh = items.length * 18 + 12;
    var x = (pos === 'tl') ? 20 : (L.W - bw - 2);
    // 薄膜のすぐ上（右寄り）に置く。箱の下端を境界面の 10px 上にそろえる
    var y = (pos === 'tl') ? 60 : (L.SURF_Y - 10 - bh + 12);
    D.roundRect(ctx, x - 8, y - 12, bw, bh, 6);
    ctx.fillStyle = 'rgba(255,255,255,0.94)'; ctx.fill();
    ctx.strokeStyle = '#d8d8d8'; ctx.lineWidth = 1; ctx.stroke();
    for (var i = 0; i < items.length; i++) {
      ctx.strokeStyle = items[i].c; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(x, y + i * 18); ctx.lineTo(x + 22, y + i * 18); ctx.stroke();
      ctx.fillStyle = '#333'; ctx.fillText(items[i].t, x + 30, y + i * 18);
    }
    ctx.restore();
  }

  /** 「波面を強調」「経路差を強調」ボタンと、そのパルス表示（光路差／波動モード共通） */
  function highlightButtons(ctx, st, sc, sol, autoPath) {
    var now = st.nowSec || 0;
    var pw = D.pulseAmount(st.pulse, 'wavefront', now);
    // autoPath：ボタンを押さなくても定期的に光らせたいときの強さ（① のステップで使う）
    var pp = Math.max(D.pulseAmount(st.pulse, 'path', now), autoPath || 0);
    var dp = sc.dpts;

    if (pw > 0.01) {
      D.glowLine(ctx, dp.A1, dp.A2, '#8e6bb5', pw, [6, 4]);
      D.glowLine(ctx, dp.B1, dp.B2, '#8e6bb5', pw, [6, 4]);
      ctx.save();
      ctx.globalAlpha = Math.min(1, 0.4 + pw);
      ctx.font = 'bold 12px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
      ctx.fillStyle = '#6d4a92'; ctx.textBaseline = 'bottom';
      ctx.fillText('A₁A₂：入射波の波面', Math.min(dp.A1.x, dp.A2.x) - 6, Math.min(dp.A1.y, dp.A2.y) - 10);
      ctx.fillText('B₁B₂：屈折波の波面', Math.min(dp.B1.x, dp.B2.x) - 6, Math.max(dp.B1.y, dp.B2.y) + 26);
      ctx.restore();
    }
    if (pp > 0.01) {
      // 経路差は「下りの B₂C」と「上りの CB₁」だけ。
      // 表示上ずらして描いた折返し（C の横線）は経路差ではないので光らせない。
      D.glowLine(ctx, dp.B2, dp.Cdown, '#0f9d58', pp);
      D.glowLine(ctx, dp.Cup, dp.B1, '#0f9d58', pp);
      // ラベルは白いチップに載せて、光路の左どなり（膜の中）に置く
      ctx.save();
      ctx.globalAlpha = Math.min(1, 0.4 + pp);
      ctx.font = 'bold 12px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
      var txt = '経路差 B₂C + CB₁';
      var tw = ctx.measureText(txt).width;
      var lx = Math.min(dp.B2.x, dp.Cdown.x) - 10 - tw;
      lx = Math.max(8, lx);
      var ly = (sc.dpx >= 60) ? (sc.surfY + sc.bottomY) / 2 + 20 : sc.surfY - 24;
      D.roundRect(ctx, lx - 6, ly - 10, tw + 12, 20, 5);
      ctx.fillStyle = 'rgba(255,255,255,0.9)'; ctx.fill();
      ctx.strokeStyle = '#0f9d58'; ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = '#0b5c34'; ctx.textBaseline = 'middle';
      ctx.fillText(txt, lx, ly);
      ctx.restore();
    }

    var hot = st.hoverBtn;
    D.canvasButton(ctx, 14, 128, '⚡ 波面を強調', 'pulse-wf', hot === 'pulse-wf', pw > 0.01);
    D.canvasButton(ctx, 14, 160, '⚡ 経路差を強調', 'pulse-path', hot === 'pulse-path', pp > 0.01);
  }

  /** 作図：入射波の波面 A₁A₂・屈折波の波面 B₁B₂ と、経路差 B₂C + CB₁ の緑ハイライト */
  function construction(ctx, sc) {
    var dp = sc.dpts;
    D.dashLine(ctx, dp.A1, dp.A2, '#8e6bb5', [6, 4], 1.6);
    D.dashLine(ctx, dp.B1, dp.B2, '#8e6bb5', [6, 4], 1.6);
    ctx.save();
    ctx.strokeStyle = '#0f9d58'; ctx.lineWidth = 7;
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.globalAlpha = 0.55;
    ctx.beginPath();
    ctx.moveTo(dp.B2.x, dp.B2.y); ctx.lineTo(dp.Cdown.x, dp.Cdown.y);
    ctx.moveTo(dp.Cup.x, dp.Cup.y); ctx.lineTo(dp.B1.x, dp.B1.y);
    ctx.stroke();
    ctx.restore();
  }

  /** 出射側：成分 2 本＋合成波（合成波の軸には両方の波面を重ねて描く） */
  function outgoing(ctx, st, sc, t, A, withSum, a1A, a2A) {
    var lg = sc.legs;
    a1A = a1A === undefined ? 1 : a1A; a2A = a2A === undefined ? 1 : a2A;
    axis(ctx, lg.o1, 0.22 * a1A); axis(ctx, lg.o2, 0.22 * a2A);
    D.waveLine(ctx, lg.o1, st, t, A, { width: 2, alpha: a1A });
    D.waveLine(ctx, lg.o2, st, t, A, { width: 2, alpha: a2A });
    if (!withSum) return;
    axis(ctx, lg.s1, 0.18);
    D.waveLine(ctx, lg.s1, st, t, A, { width: 1.4, alpha: 0.3 });
    D.waveLine(ctx, lg.s2, st, t, A, { width: 1.4, alpha: 0.3 });
    D.sumWaveLine(ctx, lg.s1, lg.s2, st, t, A, { color: COL.sum, width: 3.4, alpha: 0.96 });
  }

  /** 本体 */
  function render(ctx, st, sol, sc, t, opt) {
    opt = opt || {};
    var noInt = sol.noInterference;
    var a1A = sol.reflects.top ? 1 : 0.14;
    var a2A = sol.reflects.bottom ? 1 : 0.14;
    var showSum = (opt.showSum !== false) && !noInt && (st.showSum !== false);
    var A = L.AMP;
    var lg = sc.legs;
    var mains = [lg.i1, lg.i2, lg.f1, lg.f2];

    D.background(ctx, st, sc);
    D.thicknessHandle(ctx, sc, !!st.dragHot);
    if (sc.dpx > 6) D.thicknessDim(ctx, sc, st);

    for (var i = 0; i < mains.length; i++) axis(ctx, mains[i]);
    // 波面と経路差は波の下に敷く（波の動きが見えるように）
    if (st.showLabels) construction(ctx, sc);

    if (st.showWavefront) {
      for (var j = 0; j < mains.length; j++) D.wavefronts(ctx, mains[j], st, t, 13, { alpha: 0.8 });
      D.wavefronts(ctx, lg.o1, st, t, 13, { alpha: 0.85, width: 1.8 });
      D.wavefronts(ctx, lg.o2, st, t, 13, { alpha: 0.85, width: 1.8 });
      // 合成波の軸には 2 つの波面を長さ違いで重ねる（そろえば強めあう、ずれれば弱めあう）
      if (showSum) {
        D.wavefronts(ctx, lg.s1, st, t, 15, { alpha: 0.95, width: 2 });
        D.wavefronts(ctx, lg.s2, st, t, 24, { alpha: 0.95, width: 2 });
      }
    }

    // つなぎ（1 点を表すので波は描かない）
    for (var k = 0; k < sc.conns.length; k++) {
      if (k === 0 && !sol.reflects.top) continue;
      if (k === 1 && !sol.reflects.bottom) continue;
      D.curveConn(ctx, sc.conns[k]);
    }

    D.waveLine(ctx, lg.i1, st, t, A, { width: 2.2, alpha: a1A });
    D.waveLine(ctx, lg.i2, st, t, A, { width: 2.2 });
    D.waveLine(ctx, lg.f1, st, t, A, { width: 2.2 });
    D.waveLine(ctx, lg.f2, st, t, A, { width: 2.2, alpha: a2A });
    outgoing(ctx, st, sc, t, A, showSum, a1A, a2A);

    if (st.showVelocity) {
      velocity(ctx, lg.i2, 'c', 0.30, 38);      // nrm = (-dir.y, dir.x) なので正は左側
      velocity(ctx, lg.f1, 'c/n₁', 0.55, 38);
      velocity(ctx, lg.i1, 'c', 0.30, -38);
      // 反射したあと（膜の中の上り・空気中へ出ていく 2 本）も同じように描く
      velocity(ctx, lg.f2, 'c/n₁', 0.42, -30);
      velocity(ctx, lg.o2, 'c', 0.62, 24);
      velocity(ctx, lg.o1, 'c', 0.62, -24);
    }

    if (st.showLabels) {
      events(ctx, st, sol, sc);
      var dp = sc.dpts;
      D.pointLabel(ctx, dp.Cdown, 'C', -14, 14);
      if (sc.offK < 0.02) {
        D.pointLabel(ctx, dp.A2, 'A\u2082', -16, -12);
        D.pointLabel(ctx, dp.B1, 'B\u2081', 15, -12);
        D.pointLabel(ctx, dp.A1, 'A\u2081', -15, -12);
        D.pointLabel(ctx, dp.B2, 'B\u2082', -17, 8);
      } else {
        D.pointLabel(ctx, D.vec(sc.xc, sc.surfY), 'A\u2081=A\u2082=B\u2081=B\u2082', 0, -14);
      }
    }
    D.sourceMark(ctx, sc, st);        // 光源は背面（重なったらバッジやボタンが上に見える）
    if (!noInt) observer(ctx, st, sol, sc);
    highlightButtons(ctx, st, sc, sol);
    legend(ctx, st, !showSum);
    offsetNote(ctx, sc);
    D.unwrapBand(ctx, st, sol, sc);
    if (noInt) D.noInterferenceBanner(ctx, sol);
  }

  return {
    render: render, axis: axis, velocity: velocity, events: events,
    legend: legend, observer: observer, offsetNote: offsetNote, drawEye: drawEye,
    highlightButtons: highlightButtons,
    outgoing: outgoing
  };
})();

