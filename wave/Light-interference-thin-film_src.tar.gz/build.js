/* build.js — 薄膜の干渉（Light-interference-thin-film.html）
 *
 * src/ に分けて書いたソースを、1 枚の HTML に連結する。
 *
 *   node build.js
 *
 * ★このソース一式について（2026-11-16）
 *   薄膜ページのもとのソース（v33・2026-08-20）は残っていなかった。
 *   公開中の HTML（2026-09-02 版：GoatCounter と ▶スタート発光の共通パーツを手で足したもの）を、
 *   中に残っていた「/* ===== 30_physics.js ===== *\/」などの区切りで分けなおして復元したもの。
 *   このビルドの出力は、公開中の HTML とバイト単位で一致することを確かめてある。
 *
 *   ・JS は番号順に「そのまま」連結する（各ファイルの末尾の改行も中身の一部として保存してある）
 *   ・KaTeX の CSS / JS は vendor/ に「<style>…</style> / <script>…</script> ごと」置いてある
 *   ・src/99_footer.html は公開用の共通パーツ（アクセス数のカウント＋▶スタート発光）。
 *     ビルドで必ず最後に入るので、消えることはない
 */
'use strict';
var fs = require('fs');
var path = require('path');

var ROOT = __dirname;
var SRC = path.join(ROOT, 'src');
var VENDOR = path.join(ROOT, 'vendor');
var OUT = path.join(ROOT, 'Light-interference-thin-film.html');

function read(p) { return fs.readFileSync(p, 'utf8'); }

var jsFiles = fs.readdirSync(SRC)
  .filter(function (f) { return /^\d+_.*\.js$/.test(f); })
  .sort();
if (!jsFiles.length) { throw new Error('src に .js が 1 つもありません'); }
var js = jsFiles.map(function (f) { return read(path.join(SRC, f)); }).join('');

/* CSS は番号順に連結する（10_style.css ＝ もとの見た目、12_shell.css ＝ meter-bridge.html と同じ骨組みと見た目、
 * 13_shell_page.css ＝ このページだけの調整）。 */
var cssFiles = fs.readdirSync(SRC)
  .filter(function (f) { return /^\d+_.*\.css$/.test(f); })
  .sort();
var css = cssFiles.map(function (f) { return read(path.join(SRC, f)); }).join('\n');

var out = ''
  + read(path.join(SRC, '00_head.html'))
  + read(path.join(VENDOR, 'katex.css.block')) + '\n'
  + '<style>\n' + css + '\n</style>\n'
  + '</head>\n<body id="top">\n'
  + read(path.join(SRC, '20_body.html'))
  + read(path.join(VENDOR, 'katex.js.block')) + '\n'
  + '<script>\n' + js + '\n</script>\n'
  + read(path.join(SRC, '99_footer.html'))
  + '</body>\n</html>\n';

/* 外部を読みにいく書き方が混ざっていないか、機械的に止める。
 * 例外は 99_footer.html の GoatCounter（アクセス数のカウント）だけ。 */
var outCheck = out.replace(read(path.join(SRC, '99_footer.html')), '');
var bad = [
  [/<script[^>]+\bsrc\s*=/i, '<script src=…> が残っています'],
  [/<link[^>]+\bhref\s*=\s*["']?https?:/i, '外部の <link> が残っています'],
  [/<img[^>]+\bsrc\s*=\s*["']?https?:/i, '外部の <img> が残っています'],
  [/@import\s+url\(\s*["']?https?:/i, '外部の @import が残っています'],
  [/url\(\s*["']?https?:\/\//i, 'CSS から外部 URL を読んでいます']
];
bad.forEach(function (r) {
  if (r[0].test(outCheck)) { throw new Error('オフライン違反：' + r[1]); }
});

/* 骨組みと共通フッターが入っていなければ失敗にする（作り直したときに落とさないため） */
['physics-chiba.goatcounter.com', 'sg-glow', 'buildSiteDrawer', 'id="hero"', 'id="tabs"', 'window.SHELL_CFG', 'id="modehead"'].forEach(function (k) {
  if (out.indexOf(k) < 0) { throw new Error('完全性チェックで失敗：' + k + ' がありません'); }
});

fs.writeFileSync(OUT, out, 'utf8');
console.log('書き出し: ' + path.basename(OUT)
  + '  ' + (Buffer.byteLength(out, 'utf8') / 1024).toFixed(0) + ' KB'
  + '  (JS: ' + jsFiles.join(', ') + ')');
