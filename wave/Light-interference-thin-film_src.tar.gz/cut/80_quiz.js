/* ===== 80_quiz.js ===== */
/* 練習問題：選択式・即時フィードバック */
window.TF = window.TF || {};
TF.quiz = (function () {
  'use strict';
  var P = TF.phys;

  /* ---------- 問 2 用のミニ図（入射角 40° の薄膜） ---------- */
  var MW = 236, MH = 148;

  function miniGeom() {
    var th = 40 * Math.PI / 180, n1 = 1.5;
    var r = P.refractAngle(40, n1);
    var surfY = 52, dpx = 44, botY = surfY + dpx;
    var dxt = dpx * Math.tan(r);
    var A2 = { x: 84 - dxt, y: surfY };
    var B1 = { x: 84 + dxt, y: surfY };
    var C = { x: 84, y: botY };
    var u = { x: Math.sin(th), y: Math.cos(th) };
    var v = { x: Math.sin(r), y: Math.cos(r) };
    // A₁：A₂ を通る入射波面と光線1 の交点／B₂：B₁ から A₂C に下ろした垂線の足
    var q = (B1.x - A2.x) * u.x + (B1.y - A2.y) * u.y;
    var A1 = { x: B1.x - u.x * q, y: B1.y - u.y * q };
    var p2 = (B1.x - A2.x) * v.x + (B1.y - A2.y) * v.y;
    var B2 = { x: A2.x + v.x * p2, y: A2.y + v.y * p2 };
    return { th: th, r: r, surfY: surfY, botY: botY, A2: A2, B1: B1, C: C, A1: A1, B2: B2, u: u, v: v };
  }

  function drawMini(cv, kind) {
    var g = cv.getContext('2d');
    var dpr = Math.min(3, Math.max(2, (window.devicePixelRatio || 1) * 1.5));
    cv.width = MW * dpr; cv.height = MH * dpr;
    cv.style.width = MW + 'px'; cv.style.height = MH + 'px';
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.textRendering = 'geometricPrecision';

    var m = miniGeom();
    g.fillStyle = '#fdf8e6'; g.fillRect(0, 0, MW, m.surfY);
    g.fillStyle = '#ebe4f8'; g.fillRect(0, m.surfY, MW, m.botY - m.surfY);
    g.fillStyle = '#fdf8e6'; g.fillRect(0, m.botY, MW, MH - m.botY);
    g.strokeStyle = '#7f8c93'; g.lineWidth = 1;
    g.beginPath(); g.moveTo(0, m.surfY + .5); g.lineTo(MW, m.surfY + .5);
    g.moveTo(0, m.botY + .5); g.lineTo(MW, m.botY + .5); g.stroke();

    function line(a, b, col, w, dash) {
      g.save(); g.setLineDash(dash || []); g.strokeStyle = col; g.lineWidth = w;
      g.lineCap = 'round';
      g.beginPath(); g.moveTo(a.x, a.y); g.lineTo(b.x, b.y); g.stroke(); g.restore();
    }
    var uUp = { x: m.u.x, y: -m.u.y };
    var back = function (p, k) { return { x: p.x - m.u.x * k, y: p.y - m.u.y * k }; };
    var fwd = function (p, k) { return { x: p.x + uUp.x * k, y: p.y + uUp.y * k }; };

    // 光線
    line(back(m.B1, 62), m.B1, '#e2542c', 1.8);
    line(m.B1, fwd(m.B1, 58), '#e2542c', 1.8);
    line(back(m.A2, 62), m.A2, '#1f74d0', 1.8);
    line(m.A2, m.C, '#1f74d0', 1.8);
    line(m.C, m.B1, '#1f74d0', 1.8);
    line(m.B1, fwd(m.B1, 58), '#1f74d0', 1.2);
    // 波面（薄い破線）
    line(m.A1, m.A2, '#b9a8d0', 1, [4, 3]);
    line(m.B1, m.B2, '#b9a8d0', 1, [4, 3]);

    // ハイライト
    g.save(); g.lineCap = 'round'; g.globalAlpha = 0.85;
    g.strokeStyle = '#0f9d58'; g.lineWidth = 5;
    if (kind === 'correct') {          // B₂C + CB₁
      g.beginPath(); g.moveTo(m.B2.x, m.B2.y); g.lineTo(m.C.x, m.C.y); g.lineTo(m.B1.x, m.B1.y); g.stroke();
    } else if (kind === 'full') {      // A₂C + CB₁
      g.beginPath(); g.moveTo(m.A2.x, m.A2.y); g.lineTo(m.C.x, m.C.y); g.lineTo(m.B1.x, m.B1.y); g.stroke();
    } else if (kind === 'air') {       // A₁B₁ + A₂B₂
      g.beginPath(); g.moveTo(m.A1.x, m.A1.y); g.lineTo(m.B1.x, m.B1.y); g.stroke();
      g.beginPath(); g.moveTo(m.A2.x, m.A2.y); g.lineTo(m.B2.x, m.B2.y); g.stroke();
    }
    g.restore();

    // 点の名前
    function pt(p, t, dx, dy) {
      g.save();
      g.beginPath(); g.arc(p.x, p.y, 2.6, 0, Math.PI * 2); g.fillStyle = '#222'; g.fill();
      g.font = TF.draw.font(11, true); g.textAlign = 'center'; g.textBaseline = 'middle';
      g.fillStyle = 'rgba(255,255,255,.85)';
      var w = g.measureText(t).width;
      g.fillRect(p.x + dx - w / 2 - 2, p.y + dy - 7, w + 4, 14);
      g.fillStyle = '#222'; g.fillText(t, p.x + dx, p.y + dy);
      g.restore();
    }
    pt(m.A1, 'A₁', -13, -10);
    pt(m.A2, 'A₂', -14, -10);
    pt(m.B1, 'B₁', 14, -10);
    pt(m.B2, 'B₂', -15, 7);
    pt(m.C, 'C', -13, 12);

    g.font = '10.5px "Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';
    g.fillStyle = '#666'; g.textAlign = 'left'; g.textBaseline = 'bottom';
    g.fillText('θ = 40°', 6, MH - 6);
  }

  /* ---------- 問題 ---------- */
  var QS = [
    {
      q: '屈折率 n₁、厚さ d の薄膜に、光を垂直に当てます。上面で反射した光と、薄膜を通って下面で反射してきた光の【光路差】はどれですか。',
      opts: [{ t: '2d' }, { t: '2n₁d' }, { t: '2d / n₁' }],
      row: true,
      ans: 1,
      why: '薄膜の中を「下って上る」ので、実際に進んだ道のり（経路差）は 2d です。'
        + 'ただし膜の中は屈折率 n₁ なので、光路差になおすときは n₁ 倍して 2n₁d となります。'
        + '（斜めに入射するときは 2n₁d cos r です。）'
    },
    {
      q: '入射角 40° で光を当てました。光路差 2n₁d cos r のもとになっている部分（緑で示した経路差）を正しく表しているのはどれですか。',
      opts: [
        { t: 'A₂C + CB₁（薄膜の中を実際に進んだ長さ）', fig: 'full' },
        { t: 'B₂C + CB₁（屈折波の波面 B₁B₂ から先）', fig: 'correct' },
        { t: 'A₁B₁ と A₂B₂（境界に着くまでの部分）', fig: 'air' }
      ],
      ans: 1,
      why: 'A₁B₁（空気）と A₂B₂（薄膜）は光路が等しいので、屈折波の波面 B₁B₂ の上では光①と光②は同位相です。'
        + 'つまり位相差をもたらすのは、そこから先の B₂C + CB₁ だけ。'
        + '下面に関する B₁ の対称点を D とすると CB₁ = CD なので、B₂C + CB₁ = B₂D = 2d cos r。'
        + 'これを n₁ 倍したものが光路差 2n₁d cos r です。'
        + '「A₂C + CB₁ = 2d / cos r」は膜の中を実際に進んだ長さで、経路差ではありません。'
    },
    {
      q: '白色光を当てると、薄膜が虹色に見えます。その理由として最も適切なものはどれですか。',
      opts: [
        { t: '薄膜の材質が光を色ごとに吸収し、残った色が見えるから' },
        { t: '白色光には色んな波長が含まれており、薄膜の干渉の結果強めあう角度は波長ごとに異なるため、人の目には色が分かれて見えるから' },
        { t: '薄膜の中で屈折率が波長ごとにちがい、プリズムと同じしくみで光が分かれるから' }
      ],
      ans: 1,
      why: '強めあう条件 2n₁d cos r =（m + 1/2）λ には cos r が入っているので、'
        + '同じ膜でも見る角度がちがえば強めあう波長がちがいます。'
        + '白色光にはあらゆる波長が含まれるので、角度ごとにちがう色が強く反射され、全体としては虹色に見えます。'
        + '色素による吸収ではありません。また、プリズムの虹は屈折率の波長依存（分散）によるもので、'
        + 'しくみが別です（薄膜は干渉）。'
    }
  ];

  var answered = [];

  function init() {
    var root = document.getElementById('quiz');
    root.innerHTML = '';
    answered = QS.map(function () { return null; });

    QS.forEach(function (item, qi) {
      var card = document.createElement('div');
      card.className = 'q';

      var h = document.createElement('div');
      h.className = 'qh';
      h.textContent = '問' + (qi + 1) + '　' + item.q;
      card.appendChild(h);

      var opts = document.createElement('div');
      opts.className = 'opts' + (item.opts[0].fig ? ' opts-fig' : (item.row ? ' opts-row' : ''));
      item.opts.forEach(function (o, oi) {
        var b = document.createElement('button');
        b.className = 'opt' + (o.fig ? ' opt-fig' : '');
        b.type = 'button';
        var mk = document.createElement('span');
        mk.className = 'mk';
        mk.textContent = 'アイウエ'.charAt(oi);
        b.appendChild(mk);
        var body = document.createElement('span');
        body.className = 'optbody';
        if (o.fig) {
          var cv = document.createElement('canvas');
          cv.className = 'minifig';
          body.appendChild(cv);
          setTimeout(function () { drawMini(cv, o.fig); }, 0);
        }
        var sp = document.createElement('span');
        sp.textContent = o.t;
        body.appendChild(sp);
        b.appendChild(body);
        b.addEventListener('click', function () { choose(qi, oi, card, item); });
        opts.appendChild(b);
      });
      card.appendChild(opts);

      var fb = document.createElement('div');
      fb.className = 'fb fixed-quiz';
      fb.textContent = '選択肢を選んでください。';
      card.appendChild(fb);

      root.appendChild(card);
    });
  }

  function choose(qi, oi, card, item) {
    if (answered[qi] !== null) return;
    answered[qi] = oi;
    var buttons = card.querySelectorAll('.opt');
    for (var i = 0; i < buttons.length; i++) {
      buttons[i].disabled = true;
      if (i === item.ans) {
        buttons[i].classList.add('correct');
        buttons[i].querySelector('.mk').textContent = '○';
      } else if (i === oi) {
        buttons[i].classList.add('wrong');
        buttons[i].querySelector('.mk').textContent = '×';
      }
    }
    var fb = card.querySelector('.fb');
    var ok = (oi === item.ans);
    fb.className = 'fb fixed-quiz ' + (ok ? 'ok' : 'ng');
    fb.textContent = (ok ? '正解！　' : 'おしい。正解は「' + 'アイウエ'.charAt(item.ans) + '」です。　') + item.why;
  }

  return { init: init, QS: QS, drawMini: drawMini };
})();

