# 外した部品

- `80_quiz.js` … 練習問題（2026-11-17 千葉さんの指示でページから外した）。
  もどすときは `src/` に入れ、`20_body.html` に `<div class="quiz" id="quiz"></div>` を置き、`90_boot.js` で起動する。

## 外したときの本文（20_body.html）

```html
<section class="block" id="sec-quiz">
<header class="blockhead"><p class="mh-en">Practice</p><h2>練習問題</h2><p class="mini hide-on-scale">選んだらすぐに正誤と解説が出ます。シミュレーションで確かめながら答えてみましょう。</p></header>
<div class="quiz" id="quiz"></div>
<p class="hide-on-scale" style="text-align:center;margin-top:14px">
  <button class="ctl" id="btn-quiz-reset">もう一度</button>
</p>
</section>

```
