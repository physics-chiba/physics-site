#!/usr/bin/env python3
"""薄膜の干渉（Light-interference-thin-film.html）の自動テスト（2026-11-16 に作り直した最小版）

もとの v33 のテスト（57 項目：band_wave・wave_phase・color_name・bubble_angles・fig_full など）は
ソースとともに失われた。これは、復元したソースで「壊していないか」を確かめるための最小のテスト。
カスタマイズで直した所があれば、そのつど項目を足していくこと。

  python3 test/run_test.py           … 1 回
  python3 test/run_test.py --twice   … 2 回走らせて結果が完全一致するかも見る

見ること
  1. 物理：経路差 Δ ＝ 2 n₁ d cos r（sin θ ＝ n₁ sin r）、膜の中の波長 λ/n₁、反射での位相の反転の回数
  2. 4 つのモード（光路差・波・虹色・実寸）を開いて、ページのエラー 0・コンソールのエラー 0
  3. 外部への通信 0（アクセス数のカウント gc.zgo.at だけは別に数える）
  4. 320〜1440 px で横スクロールが出ない
  5. 2 回走らせて、物理の値と画面の文言が完全一致
"""
import asyncio, json, math, os, sys
from playwright.async_api import async_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
PAGE = 'file://' + os.path.join(HERE, '..', 'Light-interference-thin-film.html')
WIDTHS = [320, 360, 390, 768, 1024, 1440]


# ---------------------------------------------------------------- 骨組みのテスト
# ページの骨組み（meter-bridge.html と同じ並び：見出しの帯・上に固定するタブ列・章の扉・コンテンツ一覧・
# ページ一覧・フッター・共通フッター）と、スマホ／小さいタブレット／タブレット／PC／横置きでの収まりは、
# test/shell_check.py が確かめる（光の干渉 3 ページで同じもの）。別プロセスで走らせて結果だけ受けとる。
SHELL_TABS = 'wave,path,bubble,more'          # タブの並び（① 実際の波の動きを見る → ② 光路差の位置と式の原理 → …）
SHELL_HERE = 'wave/Light-interference-thin-film.html'
SHELL_DIR = os.path.dirname(os.path.abspath(__file__))
SHELL_PAGE = os.path.join(os.path.dirname(SHELL_DIR), SHELL_HERE.split('/')[-1])


def shell_check():
    import subprocess
    r = subprocess.run([sys.executable, os.path.join(SHELL_DIR, 'shell_check.py'), SHELL_PAGE, SHELL_TABS, SHELL_HERE],
                       capture_output=True, text=True)
    try:
        d = json.loads(r.stdout)
    except Exception:
        return None, ['［骨組み］テストが動きません: ' + (r.stderr or r.stdout)[-600:]]
    return d['facts'], ['［骨組み］' + b for b in d['bad']]


def shell_report(twice):
    """骨組みのテストを 1 回（--twice なら 2 回）走らせて、問題の一覧と 1 行の要約を返す。"""
    f1, bad = shell_check()
    same = True
    if twice:
        f2, bad2 = shell_check()
        same = (json.dumps(f1, sort_keys=True, ensure_ascii=False) == json.dumps(f2, sort_keys=True, ensure_ascii=False))
        if not same:
            bad.append('［骨組み］2 回の結果が一致しません')
        bad += [x for x in bad2 if x not in bad]
    c = (f1 or {}).get('counts', {})
    line = ('骨組み（タブ %d 個 × 画面 %d 通り）: エラー %s・外部への通信 %s%s'
            % (len(SHELL_TABS.split(',')), c.get('sizes', 0), c.get('errors', '?'), c.get('external', '?'),
               ('・2 回の結果 ' + ('完全一致' if same else '不一致')) if twice else ''))
    return bad, line

# (名前, モード, 状態の書きかえ)
SCENES = [
    ('既定',        'path',   dict(light='mono', **{'lambda': 550}, d=620, n1=1.33, n2=1.0, theta=0, step=1)),
    ('斜め30°',     'path',   dict(theta=30, step=4)),
    ('下が高屈折率', 'path',   dict(theta=0, n2=1.5, n1=1.33, step=4)),
    ('波',          'wave',   dict(n2=1.0, theta=20, t=0.4)),
    ('虹色・単色',   'bubble', dict(light='mono')),
    ('虹色・白色',   'bubble', dict(light='white')),
]


def r9(v):
    return round(v, 9) if isinstance(v, (int, float)) and math.isfinite(v) else v


async def one_run():
    bad, shots = [], []
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page(viewport={'width': 1440, 'height': 900})
        errors, console_errors, external, goat = [], [], [], []
        pg.on('pageerror', lambda e: errors.append(str(e)))
        # 99_footer.html の GoatCounter は file:// でも読みにいき、「//gc.zgo.at/…」が
        # file://gc.zgo.at/… になって ERR_INVALID_URL が 1 つ出る（公開先の https では出ない）。
        # これだけはカウントの失敗として別に数える。
        def on_console(m):
            if m.type != 'error':
                return
            if 'gc.zgo.at' in m.text or 'ERR_INVALID_URL' in m.text:
                goat_console.append(m.text)
            else:
                console_errors.append(m.text)
        goat_console = []
        pg.on('console', on_console)

        def on_req(req):
            u = req.url
            if 'gc.zgo.at' in u:
                goat.append(u)
            elif not (u.startswith('file:') or u.startswith('data:') or u.startswith('blob:') or u.startswith('about:')):
                external.append(u)
        pg.on('request', on_req)

        await pg.goto(PAGE)
        await pg.wait_for_timeout(800)

        for name, mode, patch in SCENES:
            await pg.evaluate('m => TFTEST.setMode(m)', mode)
            await pg.evaluate('p => TFTEST.set(p)', patch)
            await pg.wait_for_timeout(250)
            sol = await pg.evaluate("""() => { const s = TFTEST.solve(), st = TFTEST.state(), o = {};
                for (const k in s) { const v = s[k]; if (typeof v !== 'object' || v === null) o[k] = v; }
                o._n1 = st.n1; o._n2 = st.n2; o._d = st.d; o._theta = st.theta; o._lambda = st.lambda; o._mode = st.mode;
                return o; }""")
            sol = {k: r9(v) for k, v in sol.items()}
            shots.append((name, sol))
            # 物理の検算
            n1, d, th, lam = sol['_n1'], sol['_d'], sol['_theta'], sol['_lambda']
            r = math.asin(math.sin(math.radians(th)) / n1)
            want = 2 * n1 * d * math.cos(r)
            if abs(sol['delta'] - want) > 1e-6:
                bad.append('%s：経路差 %s（期待 2n₁d cos r ＝ %.6f）' % (name, sol['delta'], want))
            if abs(sol['lambdaInFilm'] - lam / n1) > 1e-6:
                bad.append('%s：膜の中の波長 %s（期待 λ/n₁ ＝ %.6f）' % (name, sol['lambdaInFilm'], lam / n1))
            flips = (1 if n1 > 1.0 else 0) + (1 if sol['_n2'] > n1 else 0)
            if sol.get('nFlip') != flips:
                bad.append('%s：反射で位相が反転する回数 %s（期待 %s）' % (name, sol.get('nFlip'), flips))

        # 実寸モード（ボタンで開く）
        await pg.evaluate("() => TFTEST.setMode('path')")
        await pg.click('#btn-scale')
        await pg.wait_for_timeout(400)
        await pg.click('#btn-scale-pause')
        await pg.wait_for_timeout(800)

        # 横スクロール
        widths = {}
        for w in WIDTHS:
            await pg.set_viewport_size({'width': w, 'height': 900})
            await pg.wait_for_timeout(200)
            sw = await pg.evaluate('() => [document.documentElement.scrollWidth, document.documentElement.clientWidth]')
            widths[w] = sw
            if sw[0] > sw[1]:
                bad.append('幅 %d px で横スクロールが出ます（%s）' % (w, sw))
        katex = await pg.evaluate("() => document.querySelectorAll('.katex').length")
        await b.close()

    if errors:
        bad.append('ページのエラー: %s' % errors[:3])
    if console_errors:
        bad.append('コンソールのエラー: %s' % console_errors[:3])
    if external:
        bad.append('外部への通信: %s' % external[:3])
    return dict(shots=shots, widths=widths, katex=katex, errors=len(errors),
                console=len(console_errors), external=len(external), goat=len(goat)), bad


def main():
    twice = '--twice' in sys.argv
    r1, bad = asyncio.run(one_run())
    same = None
    if twice:
        r2, bad2 = asyncio.run(one_run())
        same = json.dumps(r1, sort_keys=True, ensure_ascii=False) == json.dumps(r2, sort_keys=True, ensure_ascii=False)
        if not same:
            bad.append('2 回の結果が一致しません')
        bad += [x for x in bad2 if x not in bad]
    sbad, sline = shell_report(twice)
    bad += sbad
    print('=' * 64)
    print('場面 %d / 幅 %s' % (len(SCENES), WIDTHS))
    print(sline)
    print('ページのエラー: %d　コンソールのエラー: %d　外部への通信: %d（GoatCounter を除く。GoatCounter: %d）'
          % (r1['errors'], r1['console'], r1['external'], r1['goat']))
    print('KaTeX の数式: %d 個' % r1['katex'])
    if twice:
        print('2 回の結果: ' + ('完全一致' if same else '不一致'))
    print('-' * 64)
    for name, s in r1['shots']:
        print('%-10s Δ=%10.4f nm  λ/n₁=%9.4f nm  反転 %s 回  %s'
              % (name, s['delta'], s['lambdaInFilm'], s.get('nFlip'), s.get('kind')))
    print('-' * 64)
    if bad:
        print('問題 %d 件' % len(bad))
        for x in bad:
            print('  ✗ ' + x)
        sys.exit(1)
    print('問題 0 件　✓ すべて合格')


if __name__ == '__main__':
    main()
