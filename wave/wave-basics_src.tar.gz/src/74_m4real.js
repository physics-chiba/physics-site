/* =====================================================================
   ④-2 非整数次倍音が強い楽器の音色 ～ピアノ・ギター・鉄琴～（36 回目。35 回目に ④-1・④-3・④-4 に付けた切りかえを、この節 1 つにまとめた）
   ・「整数倍音のみ」と「非整数倍音を考慮（より本物に近い）」を切りかえて、音とスペクトルを比べる。custom の節（Sim は使わない。id m4ih）
   ・弦（ギター・ピアノ）：硬さのため、n 番目の成分は f_n = n f₁ √(1 + B n²) と整数倍より少し高い（インハーモニシティ）
       B：ピアノ 0.0004、ギター 0.0001。高い成分ほど早く消える。ギターは胴（ボディ）の共鳴を掛ける
   ・鉄琴：板の振動は 1 : 2.756 : 5.404 : 8.933（両端が自由な一様な棒）で、整数倍ではない
   ・はじく・たたく瞬間の短い雑音（アタック）も入れる
   ・音は、ここで作ったデータを 1 回だけ鳴らす（AUDIO.pluck の data）。スペクトルは、同じ成分の表（m4rParts）から描く
   ・「整数倍音のみ」は、これまでの章 ④ の音（m4Note：M4_TIM の倍音がそろって減る）
   ===================================================================== */
var M4R_DEF = {
  guitar: { B: 0.0001, n: 12, dk: 0.18, dur: 2.6, tau: 0.8, body: [[100, 25, 0.8], [205, 30, 0.7], [400, 60, 0.35], [560, 80, 0.2]], atk: 0.25, atkT: 0.006 },
  mono: { B: 0.0001, n: 10, dk: 0.15, dur: 3 * M3S4.tau + 0.5, tau: M3S4.tau, body: [[150, 30, 0.6], [310, 50, 0.35]], atk: 0.2, atkT: 0.006 },
  piano: { B: 0.0004, n: 12, dk: 0.25, dur: 1.8, tau: 0.55, body: null, atk: 0.15, atkT: 0.015, low: true,
    amp: [1, 0.45, 0.25, 0.14, 0.08, 0.05, 0.035, 0.025, 0.018, 0.013, 0.01, 0.008] },
  glock: { modes: [[1, 1], [2.756, 0.25], [5.404, 0.08], [8.933, 0.03]], dk: 1.2, dur: 2.2, tau: 0.6, body: null, atk: 0.3, atkT: 0.003 }
};
var M4R_SR = 32000;
/* 胴の共鳴：H(f) = 1 + Σ（山の高さ w の共鳴）。山どうしは逆向きに足す（m3BankRes と同じ作り） */
function m4rBody(d) {
  if (!d.body) return null;
  if (!d._R) d._R = d.body.map(function (p, i) {
    var C = -Math.exp(-TAU * p[1] / M4R_SR), B = 2 * Math.exp(-Math.PI * p[1] / M4R_SR) * Math.cos(TAU * p[0] / M4R_SR), r = { A: 1 - B - C, B: B, C: C }, g = m4rCx(r, p[0]);
    r.A *= p[2] / Math.sqrt(g[0] * g[0] + g[1] * g[1]) * (i % 2 ? -1 : 1); return r;
  });
  return d._R;
}
function m4rCx(r, f) { var w = TAU * f / M4R_SR, re = 1 - r.B * Math.cos(w) - r.C * Math.cos(2 * w), im = r.B * Math.sin(w) + r.C * Math.sin(2 * w), dd = re * re + im * im; return [r.A * re / dd, -r.A * im / dd]; }
function m4rGain(d, f) { var R = m4rBody(d); if (!R) return 1; var re = 1, im = 0; R.forEach(function (r) { var c = m4rCx(r, f); re += c[0]; im += c[1]; }); return Math.sqrt(re * re + im * im); }
/* 成分の表 [[f₁ の何倍（整数とは限らない）, 強さ]]。base（整数倍音の表）のいちばん大きい強さにそろえる */
function m4rParts(inst, f1, base) {
  var d = M4R_DEF[inst], out = [], bm = 0;
  (base || []).forEach(function (p) { bm = Math.max(bm, Math.abs(p[1])); }); if (!bm) bm = 1;
  if (d.modes) out = d.modes.map(function (m) { return [m[0], m[1]]; });
  else {
    var amp = d.amp || null, src = base && base.length ? base : [[1, 1]], N = d.n;
    for (var n = 1; n <= N; n++) {
      var a = amp ? amp[n - 1] : (src[n - 1] ? Math.abs(src[n - 1][1]) : 0); if (!a) continue;
      var r = n * Math.sqrt(1 + d.B * n * n); out.push([r, a * m4rGain(d, r * f1)]);
    }
  }
  var mx = 0; out.forEach(function (p) { mx = Math.max(mx, p[1]); });
  return out.map(function (p) { return [p[0], p[1] / mx * bm]; });
}
/* 音のデータ（1 回だけ鳴らす）。成分ごとに時定数 τₖ = τ / (1 + dk(k − 1)) で減る＋アタックの雑音（胴があれば胴を鳴らす） */
var _m4rBuf = {};
function m4rBuf(inst, f1, base) {
  var key = inst + '|' + Math.round(f1 * 100) + '|' + JSON.stringify(base || []); if (_m4rBuf[key]) return _m4rBuf[key];
  var d = M4R_DEF[inst], P = m4rParts(inst, f1, base), sr = M4R_SR, L = Math.round(d.dur * sr), out = new Float32Array(L), k, i;
  P.forEach(function (p, j) {
    var f = p[0] * f1; if (f > 15000) return;
    var tau = d.tau / (1 + d.dk * j), dec = Math.exp(-1 / (tau * sr)), e = p[1], w = TAU * f / sr, ph = j * 1.7;
    for (k = 0; k < L; k++) { out[k] += e * Math.sin(w * k + ph); e *= dec; if (e < 1e-5) break; }
  });
  /* アタック：短い雑音。ピアノは低めのにぶい音、ほかは明るい音 */
  var r = 777, nA = Math.round(d.atkT * sr), lp = 0, mxP = 0; P.forEach(function (p) { mxP = Math.max(mxP, p[1]); });
  var R = m4rBody(d), st = R ? R.map(function () { return [0, 0]; }) : null;
  for (k = 0; k < L; k++) {
    var x = 0;
    if (k < nA) { r = (r * 1103515245 + 12345) & 0x7fffffff; x = ((r / 0x7fffffff) * 2 - 1) * d.atk * mxP * (1 - k / nA); if (d.low) { lp += 0.15 * (x - lp); x = lp * 3; } }
    var y = x;
    if (R) for (i = 0; i < R.length; i++) { var q = R[i], yy = q.A * (x + out[k]) + q.B * st[i][0] + q.C * st[i][1]; st[i][1] = st[i][0]; st[i][0] = yy; y += yy; }   /* 胴は弦の振動とアタックの両方で鳴る */
    out[k] += y;
  }
  var mx = 0; for (k = 0; k < L; k++) mx = Math.max(mx, Math.abs(out[k]));
  var fo = Math.round(0.05 * sr); for (k = 0; k < L; k++) { var g = k > L - fo ? (L - k) / fo : 1; out[k] = out[k] / mx * 0.9 * g; }
  _m4rBuf[key] = out; return out;
}
/* 鳴らす（m4Note・④-1 から） */
function m4rPlay(owner, inst, f1, base, vol) {
  var d = M4R_DEF[inst];
  return AUDIO.pluck(owner, { f: f1, data: m4rBuf(inst, f1, base), sr: M4R_SR }, vol === undefined ? 0.9 : vol, d.dur);
}
/* ---------- ④-2 の節 ---------- */
var M4IH_INS = [['piano', 'ピアノ'], ['guitar', 'ギター'], ['glock', '鉄琴']];
var M4IH_NOTE = [[60, 'ド'], [64, 'ミ'], [67, 'ソ'], [72, '高いド']];
var M4IH_TAU = { guitar: [2.6, 0.8], piano: [1.8, 0.55], glock: [2.2, 0.6] };   /* 整数倍音のみの音（m4Note と同じ）：[長さ, 時定数] */
DEFS.m4ih = {
  id: 'm4ih', mode: 'mode4', num: 2, custom: true,
  title: '非整数次倍音が強い楽器の音色 ～ピアノ・ギター・鉄琴～', short: '非整数次倍音が強い楽器',
  html: function () { return '<div class="ihhost"></div>'; },
  build: function (art) { M4IH_S = { ins: 'piano', nm: 60, real: false }; m4ihBuild(M4IH_S, art.querySelector('.ihhost')); }
};
var M4IH_S = null;
function m4ihBuild(S, host) {
  host.innerHTML = mathify('<p class="voxlead">ピアノ・ギター・鉄琴の音には、基本振動の整数倍からずれた成分（<b>非整数次倍音</b>）が含まれている。この「ずれ」が楽器らしい音色をつくる。</p>' +
    '<p class="todo voxtodo">楽器を選び、「整数倍音のみ」と「非整数倍音を考慮」を切りかえて、音とスペクトルを比べよう。「続けて聞き比べ」で 2 つを続けて鳴らせる。</p>');
  var c1 = el('div', 'voxctl'), c2 = el('div', 'voxctl'), c3 = el('div', 'voxctl');
  var mkSeg = function (row, lbl, items, get, set) {
    var sg = el('div', 'seg'), bs = [];
    items.forEach(function (q) { var b = el('button', 'b', q[1]); b.type = 'button'; b.addEventListener('click', function () { set(q[0]); }); sg.appendChild(b); bs.push([q[0], b]); });
    row.appendChild(el('span', 'seglbl', lbl)); row.appendChild(sg);
    return function () { bs.forEach(function (x) { x[1].classList.toggle('on', get() === x[0]); }); };
  };
  var syncs = [];
  syncs.push(mkSeg(c1, '楽器', M4IH_INS, function () { return S.ins; }, function (k) { S.ins = k; m4ihChanged(S); }));
  syncs.push(mkSeg(c1, '音の高さ', M4IH_NOTE.map(function (q) { return [q[0], q[1] + '（' + Math.round(MUS.fET(q[0])) + ' Hz）']; }), function () { return S.nm; }, function (k) { S.nm = k; m4ihChanged(S); }));
  syncs.push(mkSeg(c2, '音の成分', [[false, '整数倍音のみ'], [true, '非整数倍音を考慮（より本物に近い）']], function () { return S.real; }, function (k) { S.real = k; m4ihChanged(S); }));
  var spk = el('button', 'b spk', '🔊 音を鳴らす'); spk.type = 'button';
  spk.addEventListener('click', function () { if (AUDIO.owner() === 'm4ih') { m4ihStop(S); return; } m4ihPlay(S, S.real); });
  var cmp = el('button', 'b', '▶ 続けて聞き比べ（整数倍音のみ → 非整数倍音を考慮）'); cmp.type = 'button';
  cmp.addEventListener('click', function () { m4ihCompare(S); });
  c3.appendChild(spk); spkVol(spk, 'm4ih'); c3.appendChild(cmp);
  host.appendChild(c1); host.appendChild(c2); host.appendChild(c3);
  var body = el('div', 'voxbody ihbody'), L = el('div', 'voxL'), R = el('div', 'voxR'), cw = el('div', 'cvwrap'), cv = el('canvas');
  cw.appendChild(cv); L.appendChild(cw); body.appendChild(L); body.appendChild(R); host.appendChild(body);
  S.cv = cv; S.R = R; S.spk = spk; S.cmp = cmp; S.syncs = syncs;
  cv.addEventListener('click', function (ev) {   /* スペクトルの枠をクリックすると、その音を選ぶ */
    var r = cv.getBoundingClientRect(), y = ev.clientY - r.top;
    (S._boxes || []).forEach(function (b) { if (y >= b[0] && y <= b[1] && S.real !== b[2]) { S.real = b[2]; m4ihChanged(S); } });
  });
  AUDIO.onChange(function () { m4ihSync(S); if (AUDIO.owner() !== 'm4ih') S.pm = null; m4ihDraw(S); });
  window.addEventListener('resize', function () { m4ihDraw(S); });
  m4ihSync(S); m4ihDraw(S);
}
function m4ihChanged(S) { if (AUDIO.owner() === 'm4ih') m4ihStop(S); m4ihSync(S); m4ihDraw(S); }
function m4ihStop(S) { clearTimeout(S._seq); S._seq = null; S.pm = null; AUDIO.stop(); }
function m4ihPlay(S, real) {
  var f = MUS.fET(S.nm), ok = real ? m4rPlay('m4ih', S.ins, f, M4_TIM[S.ins]) : m4Note('m4ih', f, S.ins);
  if (!ok) return false;
  S.pm = real; S.t0 = performance.now(); if (S.real !== real) { S.real = real; m4ihSync(S); }
  var loop = function () { if (AUDIO.owner() !== 'm4ih' || S.pm === null) { m4ihDraw(S); return; } m4ihDraw(S); requestAnimationFrame(loop); };
  requestAnimationFrame(loop);
  return true;
}
function m4ihCompare(S) {
  m4ihStop(S);
  if (!m4ihPlay(S, false)) return;
  var d = M4IH_TAU[S.ins][0];
  S._seq = setTimeout(function () { S._seq = null; m4ihPlay(S, true); }, (d + 0.35) * 1000);
}
function m4ihSync(S) {
  S.syncs.forEach(function (f) { f(); });
  var on = AUDIO.owner() === 'm4ih';
  S.spk.textContent = on ? '■ 音を止める' : '🔊 音を鳴らす'; S.spk.classList.toggle('on', on); S.spk.classList.toggle('glow', !on);
  var nm = { piano: 'ピアノ', guitar: 'ギター', glock: '鉄琴' }[S.ins];
  S.R.innerHTML = mathify('<div class="qcard"><p class="qt">整数倍音と非整数次倍音</p>' +
    '<p>弦や板の振動は、理想的には基本振動の整数倍（2 倍・3 倍 …）の成分でできている。本物の楽器では、その振動数が少しずれる。</p>' +
    '<table class="reltab grid1 voxtab"><thead><tr><th>楽器</th><th>なぜずれるか</th><th>ずれ方</th></tr></thead><tbody>' +
    '<tr' + (S.ins === 'piano' ? ' class="on"' : '') + '><th>ピアノ</th><td class="l">太くて硬い鋼の弦。曲げにくさのため、高い成分ほど振動数が高くなる</td><td class="l">第 $n$ 成分は $n\\sqrt{1 + Bn^2}$ 倍（$B \\fallingdotseq 0.0004$）。第 12 成分で約 50 セント高い</td></tr>' +
    '<tr' + (S.ins === 'guitar' ? ' class="on"' : '') + '><th>ギター</th><td class="l">弦の硬さ（ピアノより小さい）と、胴（ボディ）の共鳴</td><td class="l">少し高くなる（$B \\fallingdotseq 0.0001$）。100〜600 Hz の成分が胴で強まる</td></tr>' +
    '<tr' + (S.ins === 'glock' ? ' class="on"' : '') + '><th>鉄琴</th><td class="l">板（棒）の振動は、弦とは違う式に従う</td><td class="l">$1 : 2.76 : 5.40 : 8.93$。整数倍から大きく離れる</td></tr></tbody></table>' +
    '<p class="qnote">鳴らしている間、スペクトルの線の長さが変わる。本物に近い音では、高い成分ほど早く消える。はじく・たたく瞬間の雑音も音色の一部。</p>' +
    '<p class="qnote">④-1 のつまみは、整数倍音だけで音を作る。楽器らしさには、非整数次倍音と、音の大きさの時間変化も効いている。</p>' +
    '<p class="qnote">いま：' + nm + '・' + MUS.jp(S.nm) + '（' + Math.round(MUS.fET(S.nm)) + ' Hz）・' + (S.real ? '非整数倍音を考慮' : '整数倍音のみ') + '</p></div>');
}
/* 成分の表と、成分ごとの時定数 */
function m4ihParts(S, real) {
  var f = MUS.fET(S.nm), d = M4R_DEF[S.ins];
  if (!real) { var tI = M4IH_TAU[S.ins][1]; return M4_TIM[S.ins].map(function (p) { return { r: p[0], a: Math.abs(p[1]), tau: tI }; }); }
  return m4rParts(S.ins, f, M4_TIM[S.ins]).map(function (p, j) { return { r: p[0], a: p[1], tau: d.tau / (1 + d.dk * j) }; });
}
function m4ihDraw(S) {
  var cv = S.cv; if (!cv || !cv.offsetParent) return;
  var W = Math.max(280, Math.floor(cv.parentNode.clientWidth || 300)), nar = W < 560, WH = 120, SH = nar ? 160 : 185, G = 12, H = 10 + WH + G + (SH + G) * 2 + 14;
  var ctx = prep(cv, W, H); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H);
  var f = MUS.fET(S.nm), FM = f * (S.ins === 'glock' ? 10 : 13.5), t = S.pm !== null && S.pm !== undefined ? (performance.now() - S.t0) / 1000 : -1;
  /* 波形（いま選んでいる音。減衰は入れず、成分の重なりだけ） */
  var P = m4ihParts(S, S.real), y0 = 10;
  ctx.save(); ctx.fillStyle = '#0d1a14'; rrect(ctx, 0, y0, W, WH, 8); ctx.fill(); ctx.restore();
  label(ctx, '波形（' + (S.real ? '非整数倍音を考慮' : '整数倍音のみ') + '、横 15 ms）', 10, y0 + 12, { size: 10.5, bold: true, color: 'rgba(190,240,215,.95)', align: 'left', halo: false });
  var span = 0.015, mxA = 0; P.forEach(function (p) { mxA += p.a; });
  ctx.save(); ctx.strokeStyle = '#7dffb4'; ctx.lineWidth = 1.8; ctx.shadowColor = '#7dffb4'; ctx.shadowBlur = 4; ctx.beginPath();
  for (var i = 0; i <= 600; i++) {
    var tt = span * i / 600, y = 0; P.forEach(function (p, j) { y += p.a * Math.sin(TAU * p.r * f * tt + (S.real ? j * 1.7 : 0)); });
    var X = 10 + (W - 20) * i / 600, Y = y0 + WH / 2 + 10 - y / mxA * (WH / 2 - 16); if (i) ctx.lineTo(X, Y); else ctx.moveTo(X, Y);
  }
  ctx.stroke(); ctx.restore();
  /* スペクトル 2 つ（上：整数倍音のみ、下：非整数倍音を考慮）。整数倍の位置に、2 つを通す点線 */
  var fx0 = 14, fx1 = W - 14, XF = function (fr) { return fx0 + fr / FM * (fx1 - fx0); }, ys = [y0 + WH + G, y0 + WH + G + SH + G];
  S._boxes = [];
  [false, true].forEach(function (real, bi) {
    var y = ys[bi], sel = S.real === real, Q = m4ihParts(S, real), am = 0, by1 = y + SH - 22, by0 = y + 46;
    Q.forEach(function (q) { am = Math.max(am, q.a); });
    S._boxes.push([y, y + SH, real]);
    ctx.save(); ctx.fillStyle = '#0d1a14'; rrect(ctx, 0, y, W, SH, 8); ctx.fill();
    if (sel) { ctx.strokeStyle = '#ffb347'; ctx.lineWidth = 2.5; rrect(ctx, 1.5, y + 1.5, W - 3, SH - 3, 8); ctx.stroke(); }
    ctx.restore();
    label(ctx, real ? '非整数倍音を考慮（より本物に近い）' : '整数倍音のみ', 10, y + 13, { size: 11.5, bold: true, color: sel ? '#ffd27a' : 'rgba(190,240,215,.85)', align: 'left', halo: false });
    if (sel) label(ctx, nar ? '選んでいる音' : '選んでいる音（🔊 で鳴る）', W - 10, y + 13, { size: 10, bold: true, color: '#ffd27a', align: 'right', halo: false });
    else label(ctx, nar ? 'クリックで選ぶ' : 'ここをクリックで選ぶ', W - 10, y + 13, { size: 9.5, color: 'rgba(190,240,215,.6)', align: 'right', halo: false });
    /* 整数倍の位置（点線） */
    ctx.save(); ctx.strokeStyle = 'rgba(200,210,205,.35)'; ctx.setLineDash([3, 3]); ctx.lineWidth = 1;
    for (var k = 1; k * f <= FM; k++) { var gx = Math.round(XF(k * f)) + 0.5; ctx.beginPath(); ctx.moveTo(gx, by0 - 4); ctx.lineTo(gx, by1); ctx.stroke(); }
    ctx.restore();
    ctx.save(); ctx.strokeStyle = 'rgba(120,220,170,.35)'; ctx.beginPath(); ctx.moveTo(fx0, by1 + 0.5); ctx.lineTo(fx1, by1 + 0.5); ctx.stroke(); ctx.restore();
    for (k = 0; k <= 4; k++) { var fk = Math.round(FM * k / 4 / 100) * 100; label(ctx, fk + (k === 4 ? ' Hz' : ''), XF(fk), by1 + 10, { size: 9, color: 'rgba(190,240,215,.75)', align: k === 4 ? 'right' : 'center', halo: false }); }
    var gap = XF(f) - XF(0);
    Q.forEach(function (q, j) {
      var fr = q.r * f; if (fr > FM) return;
      var dec = t >= 0 && S.pm === real ? Math.exp(-t / q.tau) : (t >= 0 ? 0.25 : 1);   /* 鳴らしている方は時間とともに減る。鳴らしていない方はうすく */
      var h = q.a / am * (by1 - by0) * dec, X = Math.round(XF(fr)) + 0.5;
      ctx.save(); ctx.strokeStyle = sel ? '#7dffb4' : 'rgba(125,255,180,.45)'; ctx.lineWidth = nar ? 2.4 : 3.2; ctx.shadowColor = '#7dffb4'; ctx.shadowBlur = sel ? 6 : 0;
      ctx.beginPath(); ctx.moveTo(X, by1); ctx.lineTo(X, by1 - Math.max(h, 1.5)); ctx.stroke(); ctx.restore();
      var frac = Math.abs(q.r - Math.round(q.r)) > 1e-6, room = gap >= (frac ? 34 : 18) || j === 0 || S.ins === 'glock';
      if (room) label(ctx, Math.abs(q.r - 1) < 0.01 ? '基音' : '×' + m3Rt(q.r), X, by0 - 16, { size: 9.5, bold: true, color: 'rgba(255,214,120,.95)', halo: false });
      if (real && frac && S.ins !== 'glock' && gap >= 34 && j > 0) { var ct = Math.round(1200 * Math.log2(q.r / Math.round(q.r))); if (ct) label(ctx, '+' + ct + ' セント', X, by0 - 4, { size: 8.5, color: 'rgba(255,190,120,.85)', halo: false }); }
    });
  });
  label(ctx, '点線：整数倍（2 倍・3 倍 …）の位置', W / 2, H - 8, { size: 9.5, color: '#5b6470' });
}
