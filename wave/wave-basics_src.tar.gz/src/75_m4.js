/* ===== 75_m4.js ===== */
/* =========================================================================
   章 ④ 音波（芸術の範囲）— 2026-11-05 千葉さん 8 回目
   ④-1 倍音と楽器ごとの音色 ～自由に音を作ろう～ … 77_m4h.js（id は m4h）
   ④-2 波長（長さ）の違いを手で作る楽器（リコーダー・オーボエ・モノコード（ギター））… id m4s1
   ④-3 波長（長さ）の違いが最初からある楽器（試験管の笛・ピアノ・鉄琴）… 76_m4p.js（id は m4p）
   ④-4 倍音のみで演奏する楽器（ナチュラルトランペット・ブランデンブルク協奏曲）… id m4s2
   ④-5 和音（コード）とは何か … id m4s3
   ④-6 純正律とは何か・平均律とは何か … id m4s4
   ④-7 純正律と平均律を聞き比べよう … id m4s5
   （15 回目に ④-2、16 回目に ④-1 を入れたので、番号はずれた。id はそのまま）
   ★ 音と図は同じ値から：音色は倍音の表 [[n, aₙ], …]。図・オシロスコープ・スペクトル・音（AUDIO）に同じ表を渡す
   ★ 音はボタン（音符・鍵盤のクリックも）を押したときだけ。同時に 1 つ。章を切りかえると止まる
   ========================================================================= */
'use strict';
var M4_TEND = 1e6;
/* 音色（倍音の表）。値は「それらしい」大きさ（実際の楽器は音の高さ・吹き方で変わる） */
var M4_TIM = {
  guitar: (function () { var p = 0.2, a = []; for (var n = 1; n <= 12; n++) a.push([n, Math.abs(2 * Math.sin(n * Math.PI * p) / (n * n * Math.PI * Math.PI * p * (1 - p)))]); return a; })(),
  recorder: [[1, 1], [2, 0.10], [3, 0.08], [4, 0.02]],
  oboe: [[1, 0.55], [2, 1], [3, 0.85], [4, 0.6], [5, 0.48], [6, 0.32], [7, 0.22], [8, 0.14], [9, 0.08]],
  trumpet: [[1, 1], [2, 0.8], [3, 0.65], [4, 0.5], [5, 0.38], [6, 0.26], [7, 0.16], [8, 0.1]],
  piano: [[1, 1], [2, 0.45], [3, 0.25], [4, 0.14], [5, 0.08], [6, 0.05]],
  soft: [[1, 1], [2, 0.5], [3, 0.33], [4, 0.25], [5, 0.2], [6, 0.17]],          /* ④-6：倍音をふくむ音（うなりが聞こえるように） */
  tube: [[1, 1], [3, 0.06], [5, 0.02]],                                            /* ④-2 試験管の笛（閉管なので奇数倍の倍音） */
  glock: [[1, 1], [3, 0.12], [6, 0.05]]                                            /* ④-2 鉄琴（本物の板の倍音は整数倍ではない。ここでは近い整数倍で） */
};
var M4_C4 = 261.63;
/* 音を出す：楽器の 1 音（ギター＝はじく・減衰、ほか＝1.3 秒） */
function m4Note(owner, f, tim) {
  var so = typeof SIM_BY_ID !== 'undefined' && SIM_BY_ID[owner]; if (so && so.snd === false) return false;   /* 音が OFF のときは鳴らさない */
  if (tim === 'guitar') return AUDIO.pluck(owner, { f: f, partials: M4_TIM.guitar }, 0.9, 2.6, 0.8);
  if (tim === 'piano') return AUDIO.pluck(owner, { f: f, partials: M4_TIM.piano }, 0.9, 1.8, 0.55);
  if (tim === 'glock') return AUDIO.pluck(owner, { f: f, partials: M4_TIM.glock }, 0.9, 2.2, 0.6);
  return AUDIO.pluck(owner, { f: f, partials: M4_TIM[tim] || [[1, 1]] }, 0.85, 1.3);
}
/* キャンバスの中のボタン（音符・鍵盤など）：draw のときに s._h4 に登録し、クリックで act を呼ぶ */
function m4Hits(s) {
  var pos = function (ev) { var r = s.cv.getBoundingClientRect(); return { x: ev.clientX - r.left, y: ev.clientY - r.top }; };
  var find = function (p) { var hs = s._h4 || []; for (var i = hs.length - 1; i >= 0; i--) { var h = hs[i]; if (p.x >= h.x && p.x <= h.x + h.w && p.y >= h.y && p.y <= h.y + h.h) return h; } return null; };
  s.cv.addEventListener('pointermove', function (ev) { s.cv.style.cursor = find(pos(ev)) ? 'pointer' : 'default'; });
  s.cv.addEventListener('click', function (ev) { var h = find(pos(ev)); if (h) { h.act(); s.draw(); } });
}
function m4Hit(s, x, y, w, h, act) { (s._h4 = s._h4 || []).push({ x: x, y: y, w: w, h: h, act: act }); }
/* 🔊 音を鳴らす：章 ④ では ON／OFF の切りかえ（既定 ON。2026-11-06 千葉さん 11 回目）
   ON のとき、音符・鍵盤・和音などを押すとその音が鳴る。OFF→ON にしたときは、いまの音を 1 回鳴らす。ON→OFF で止める */
function m4SndToggle(s, play) {
  s.snd = true; s._m4play = play;
  var sp = el('span', 'spkrow'), b = el('button', 'b spk m4snd', ''); b.type = 'button';
  var sync = function () { b.textContent = s.snd ? '🔊 音を鳴らす：ON' : '🔇 音を鳴らす：OFF'; b.classList.toggle('on', s.snd); b.setAttribute('aria-pressed', s.snd ? 'true' : 'false'); };
  b.addEventListener('click', function () { s.snd = !s.snd; sync(); if (s.snd) { play(); s.draw(); } else if (AUDIO.owner() === s.def.id) AUDIO.stop(); });
  sp.appendChild(b); s.row1b.appendChild(sp); s.spk = b; sync();
}
/* 和音などを決まった時間だけ鳴らす（ON のときだけ） */
var M4_TOK = {};
function m4Chord(s, voices, dur) {
  if (s.snd === false) return false;
  var tok = {}; M4_TOK[s.def.id] = tok;
  AUDIO.play(s.def.id, voices, 0.9);
  setTimeout(function () { if (M4_TOK[s.def.id] === tok && AUDIO.owner() === s.def.id) AUDIO.stop(); }, dur * 1000);
  return true;
}
/* スタート・スロー・リセットを出さない（図が動かない節。2026-11-07 千葉さん 15 回目） */
function m4NoPlay(s) { [s.bPlay, s.bSlow, s.bReset].forEach(function (b) { if (b) b.style.display = 'none'; }); var pb = s.L.querySelector('.playbar'); if (pb) pb.style.display = 'none'; }
/* アニメを動かす（止まっていれば） */
function m4Go(s) { if (!s.playing) { SIMS.forEach(function (o) { if (o !== s && o.playing) { o.playing = false; o.syncPlayLabel(); } }); s.playing = true; s.syncPlayLabel(); startLoop(); } }
/* 右の列：スライダーなし。上にオシロスコープ＋スペクトル、下に説明 */
function m4Right(s, title) {
  s.R.innerHTML = '';
  s.scope = new Scope(s.R, title || 'オシロスコープ');
  s.specCv = el('canvas', 'scopecv speccv'); s.scope.cap.insertAdjacentElement('beforebegin', s.specCv);
  m3SpecPick(s, s.specCv, function () { s._sk = null; s.draw(); });
  s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);
}
/* オシロスコープ（10 ms）とスペクトル（横軸 0〜FM Hz）。parts：倍音の表、f：基音 */
function m4Scope(s, f, parts, cap, FM, span) {
  var sc = s.scope; if (!sc || !sc.cv.offsetParent) return;
  var W = Math.max(240, Math.floor(sc.cv.clientWidth || 300)), H = Math.round(clamp(W * 0.5, 140, 190));
  var key = [W, f, JSON.stringify(parts), s._spSel, FM, span].join('|'); if (s._sk === key) return; s._sk = key;
  var ctx = prep(sc.cv, W, H); ctx.clearRect(0, 0, W, H);
  var sp = span || 0.010;
  if (f) { var wv = m3Wave(parts); sc.screen(ctx, 0, 0, W, H, { t0: 0, span: sp, yMax: 1, traces: [{ f: function (t) { return (s._absK !== undefined ? 0.5 * s._absK : 0.85) * wv.f(f * t); }, fmax: f * wv.nMax }], label: '横 1 目盛り ' + divTxt(sp / 10), labelR: sig(f, 4) + ' Hz' }); }
  else { sc.screen(ctx, 0, 0, W, H, { t0: 0, span: sp, yMax: 1, traces: [], label: '横 1 目盛り ' + divTxt(sp / 10) }); label(ctx, s._emptyMsg || '音符をクリックすると、ここに映る', W / 2, H / 2 + 16, { size: 11.5, color: 'rgba(190,240,215,.8)', halo: false }); }
  var sv = s.specCv, SH = Math.round(clamp(W * 0.3, 90, 120)), c2 = prep(sv, W, SH);
  c2.clearRect(0, 0, W, SH); c2.fillStyle = '#0d1a14'; rrect(c2, 0, 0, W, SH, 6); c2.fill();
  var fx0 = 12, fx1 = W - 12, fy0 = 22, fy1 = SH - 20, XF = function (x) { return fx0 + x / FM * (fx1 - fx0); };
  c2.save(); c2.strokeStyle = 'rgba(120,220,170,.25)'; c2.lineWidth = 1;
  for (var k = 0; k <= 5; k++) { var gx = Math.round(XF(k * FM / 5)) + 0.5; c2.beginPath(); c2.moveTo(gx, fy0); c2.lineTo(gx, fy1); c2.stroke(); }
  c2.beginPath(); c2.moveTo(fx0, fy1 + 0.5); c2.lineTo(fx1, fy1 + 0.5); c2.stroke(); c2.restore();
  c2.save(); c2.font = '600 10px ' + FONT; c2.fillStyle = 'rgba(190,240,215,.85)'; c2.textBaseline = 'top'; c2.fillText('振動数のスペクトル（線をクリックすると振動数を表示）', 6, 5);
  c2.textAlign = 'center'; for (var k2 = 0; k2 <= 5; k2++) c2.fillText(k2 === 5 ? FM + ' Hz' : String(k2 * FM / 5), Math.min(fx1 - 18, XF(k2 * FM / 5)), fy1 + 4); c2.restore();
  if (f) m3SpecBars(c2, s, parts, f, 1, XF, fy0, fy1, FM, true); else s._spHits = [];
  if (sc.cap._h !== cap) { sc.cap._h = cap; sc.cap.innerHTML = mathify(cap); }
}

/* =====================================================================
   ④-1 色んな楽器
   ===================================================================== */
var M4S1_INS = [['recorder', 'リコーダー'], ['oboe', 'オーボエ'], ['guitar', 'モノコード（ギター）']];   /* 順番を変えた（2026-11-07 千葉さん 14 回目） */
var M4S1_NOTES = [60, 62, 64, 65, 67, 69, 71, 72, 74, 76, 77, 79, 81, 83, 84];   /* C4〜C6 の白鍵 */
DEFS.m4s1 = {
  id: 'm4s1', mode: 'mode4', num: 2,
  title: '波長（長さ）の違いを手で作る楽器', short: '長さを手で変える楽器',
  desc: '楽器は、弦や管の<b>長さ</b>を変えて音の高さ（振動数）を変える。<span class="todo">楽器を選び、穴・フレットか五線譜の音符をクリック。<b>Enter キー</b>（または弦・管をクリック）で音を出そう。</span>',
  strobe: false, stepDiv: 16,
  vars: [],
  init: function (s) { s.ins = 'recorder'; s.nm = null; s.tN = 0; },
  onDefaults: function (s) { s.ins = 'recorder'; s.nm = null; m4s1Sync(s); },
  buttons: M4S1_INS.map(function (p) { return { k: 'i_' + p[0], label: p[1], seg: 'ins', segLabel: '楽器', onClick: function (s) { s.ins = p[0]; m4s1Sync(s); if (s.nm !== null) m4Note('m4s1', MUS.fET(s.nm), p[0]); s.draw(); } }; }),
  tEnd: function () { return M4_TEND; },
  tInfo: function () { return ''; },
  gT: function () { return 1; },
  height: function (s, w) { return w < 620 ? 400 : Math.round(clamp(w * 0.62, 380, 430)); },
  afterBuild: function (s) {
    m4Right(s, 'オシロスコープ（楽器の音）');
    m4SndToggle(s, function () { if (s.nm === null) s.nm = 60; s.tN = s.t; m4Note('m4s1', MUS.fET(s.nm), s.ins); m4Go(s); m4s1Sync(s); });
    var segs = s.row1b.querySelectorAll('.seg'); if (segs[0]) { var lb = el('span', 'seglbl', '楽器'); segs[0].insertAdjacentElement('beforebegin', lb); lblSeg(lb, segs[0]); }
    m3TimeBar(s, false); m4Hits(s); m4s1Sync(s);
    /* Enter キーで音を出す（③-4 と同じ。入力欄・ボタンの上では使わない。画面に見えているときだけ） */
    document.addEventListener('keydown', function (ev) {
      if (ev.key !== 'Enter' || ev.repeat) return;
      var a = document.activeElement, tg = a && a.tagName;
      if (tg === 'INPUT' || tg === 'TEXTAREA' || tg === 'BUTTON' || tg === 'SELECT' || tg === 'A') return;
      if (!s.cv.offsetParent) return;
      var r = s.cv.getBoundingClientRect(); if (r.bottom < 0 || r.top > window.innerHeight) return;
      m4s1Play(s); s.draw(); ev.preventDefault();
    });
  },
  draw: function (s, ctx, W, H) { drawM4S1(s, ctx, W, H); var f = s.nm === null ? 0 : MUS.fET(s.nm); m4Scope(s, f, M4_TIM[s.ins], m4s1Cap(s, f), 5000); },
  right: function (s, R) { rightM4S1(s, R); }
};
function m4s1Sync(s) { m2Sync(s, M4S1_INS.map(function (p) { return ['i_' + p[0], s.ins === p[0]]; })); if (s.Rdyn) s.renderRight(); }
function m4s1Cap(s, f) { return f ? MUS.jp(s.nm) + '（' + MUS.en(s.nm) + '）$f = ' + sig(f, 4) + '$ Hz。同じ高さでも、楽器によって波形（倍音のまざり方）がちがう＝<b>音色</b>がちがう' : '楽器を選んで、音符をクリック'; }
/* 楽器の長さ：弦・管とも基本振動で l = v/(2f)（図のための値：v = 340 m/s。モノコードは C4 で 0.65 m になる速さ） */
function m4s1Len(f) { return 340 / (2 * f); }
/* 管楽器の穴（2026-11-06 千葉さん 12 回目：穴をクリックすると、そこまでふさぐ）
   吹き口に近い順に、C5・B4・A4・G4・F4・E4・D4 の管の長さの位置に穴。ふさいだ数 c → 最初に開いている穴までが管の長さ（c = 7 なら全体＝C4）
   D5 より高い音は、同じ指で息を強く吹いて 2 倍振動（1 オクターブ上）にする */
var M4S1_HOLE = [72, 71, 69, 67, 65, 64, 62];
function m4s1Wind(m) {                                                /* 音 → { c：ふさぐ穴の数, n：何倍振動, base：指づかいの音 } */
  var n = m >= 74 ? 2 : 1, base = n === 2 ? m - 12 : m, c = base === 60 ? 7 : M4S1_HOLE.indexOf(base);
  return { c: c, n: n, base: base };
}
function m4s1Play(s) { if (s.nm === null) s.nm = 60; s.tN = s.t; m4Note('m4s1', MUS.fET(s.nm), s.ins); m4Go(s); m4s1Sync(s); }
function drawM4S1(s, ctx, W, H) {
  s._h4 = [];
  var nar = W < 620, Hi = Math.round(H * 0.5);
  /* 上：楽器（横はばいっぱい） */
  var on = s.nm !== null, m = on ? s.nm : 60, f = MUS.fET(m), Lmax = 0.7, ax0 = 30, ax1 = W - 20, ay = Math.round(Hi * 0.46);
  var SX = (ax1 - ax0 - 26) / Lmax, X = function (x) { return ax0 + 20 + x * SX; };
  var tp = s.t - (s.tN || 0), fS = 0.7, A = on ? Math.cos(TAU * fS * tp) * Math.exp(-tp / (s.ins === 'guitar' ? 3 : 1e9)) : 0;
  label(ctx, s.ins === 'guitar' ? 'モノコード（ギター）：フレットをクリックで音を選ぶ、弦をクリックではじく' : (s.ins === 'recorder' ? 'リコーダー' : 'オーボエ') + '：穴をクリックすると、そこまでふさぐ。管をクリックで吹く', 8, 12, { size: nar ? 10 : 11.5, bold: true, color: COL.ink2, align: 'left' });
  var l, nMode = 1;
  if (s.ins === 'guitar') {
    l = m4s1Len(f);
    ctx.save(); ctx.fillStyle = '#d9b98a'; rrect(ctx, X(0) - 16, ay + 18, (X(Lmax) - X(0)) + 34, 30, 5); ctx.fill(); ctx.restore();
    /* フレット（各音の弦の長さの位置）。クリックでその音 */
    M4S1_NOTES.forEach(function (mm) {
      var px = X(m4s1Len(MUS.fET(mm))), sel = mm === s.nm;
      ctx.save(); ctx.strokeStyle = sel ? '#e07b18' : 'rgba(90,60,30,.55)'; ctx.lineWidth = sel ? 3 : 1.6; ctx.beginPath(); ctx.moveTo(px, ay + 18); ctx.lineTo(px, ay + 48); ctx.stroke(); ctx.restore();
      if (!nar || mm % 12 === 0) label(ctx, MUS.jp(mm), px, ay + 58, { size: 9.5, color: sel ? '#c9670c' : COL.sub, bold: sel });
      m4Hit(s, px - 6, ay + 16, 12, 50, function () { s.nm = mm; m4s1Play(s); });
    });
    ctx.save(); ctx.fillStyle = '#6b4a2a'; ctx.beginPath(); ctx.moveTo(X(0) - 6, ay + 18); ctx.lineTo(X(0), ay); ctx.lineTo(X(0) + 6, ay + 18); ctx.closePath(); ctx.fill(); ctx.restore();
    ctx.save(); ctx.strokeStyle = 'rgba(122,59,18,.45)'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(X(l), ay); ctx.lineTo(X(Lmax) + 14, ay); ctx.stroke(); ctx.restore();
    plotF(ctx, function (x) { return Math.sin(Math.PI * x / l) * A; }, 0, l, X, function (y) { return ay - y * 20; }, '#7a3b12', 2.4);
    /* こま（③-4 と同じ形。ギターでは指でフレットをおさえるのと同じはたらき） */
    ctx.save(); ctx.fillStyle = '#e07b18'; ctx.strokeStyle = '#9c4e06'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(X(l) - 9, ay + 18); ctx.lineTo(X(l), ay - 1); ctx.lineTo(X(l) + 9, ay + 18); ctx.closePath(); ctx.fill(); ctx.stroke(); ctx.restore();
    label(ctx, 'こま（ギターでは指でおさえる所）', clamp(X(l), 110, ax1 - 110), ay - 28, { size: 10.5, bold: true, color: '#9c4e06' });
    m4Hit(s, X(0) + 4, ay - 16, X(l) - X(0) - 10, 30, function () { m4s1Play(s); });     /* 弦をクリック：はじく */
  } else {
    var wd = m4s1Wind(m), tr = 13, cone = s.ins === 'oboe';
    nMode = wd.n; l = wd.c >= 7 ? m4s1Len(MUS.fET(60)) : m4s1Len(MUS.fET(M4S1_HOLE[wd.c]));
    ctx.save(); ctx.fillStyle = cone ? '#3a2f2a' : '#efe6d6'; ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.5; ctx.beginPath();
    ctx.moveTo(X(0), ay - (cone ? 6 : tr)); ctx.lineTo(X(Lmax), ay - (cone ? tr + 7 : tr)); ctx.lineTo(X(Lmax), ay + (cone ? tr + 7 : tr)); ctx.lineTo(X(0), ay + (cone ? 6 : tr)); ctx.closePath(); ctx.fill(); ctx.stroke(); ctx.restore();
    if (cone) { ctx.save(); ctx.fillStyle = '#c9a979'; ctx.fillRect(X(0) - 18, ay - 2.5, 18, 5); ctx.restore(); label(ctx, 'リード（2 枚）', X(0) - 4, ay + 26, { size: 10, color: COL.ink2 }); }
    else { ctx.save(); ctx.fillStyle = '#efe6d6'; ctx.strokeStyle = '#3a414c'; rrect(ctx, X(0) - 20, ay - 10, 20, 20, 4); ctx.fill(); ctx.stroke(); ctx.restore(); label(ctx, '吹き口', X(0) - 10, ay + 24, { size: 10, color: COL.ink2 }); }
    /* 管の中の定在波（両はしが腹）。2 倍振動なら節が 2 つ */
    [1, -1].forEach(function (sg) { plotF(ctx, function (x) { return sg * Math.cos(nMode * Math.PI * x / l); }, 0, l, X, function (y) { return ay - y * (tr - 4); }, 'rgba(22,99,181,.35)', 1, [3, 3]); });
    plotF(ctx, function (x) { return Math.cos(nMode * Math.PI * x / l) * A; }, 0, l, X, function (y) { return ay - y * (tr - 4); }, '#1663b5', 2.2);
    /* 穴：ふさいだ穴は茶色、開いた穴は白。クリックでそこまでふさぐ（ふさいだ穴をもう一度押すと、その穴を開ける） */
    M4S1_HOLE.forEach(function (hm, j) {
      var px = X(m4s1Len(MUS.fET(hm))), closed = j < wd.c;
      ctx.save(); ctx.beginPath(); ctx.arc(px, ay - 1, 4.6, 0, TAU); ctx.fillStyle = closed ? '#a8743f' : '#fff'; ctx.fill(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.4; ctx.stroke(); ctx.restore();
      m4Hit(s, px - 6, ay - 15, 12, 28, function () {
        var c = (wd.c === j + 1) ? j : j + 1;                         /* 新しくふさぐ数 */
        var base = c >= 7 ? 60 : M4S1_HOLE[c];
        s.nm = base + (wd.n === 2 && base + 12 <= 84 ? 12 : 0); m4s1Play(s);
      });
    });
    dotted(ctx, X(l), ay - tr - 14, X(l), ay + tr + 14, '#e07b18', [3, 3]);
    label(ctx, nMode === 2 ? '息を強く吹く → 2 倍振動（1 オクターブ上）' : 'ここから先の穴が開いている（管の終わり）', clamp(X(l), 150, ax1 - 150), ay - tr - 22, { size: 10.5, bold: true, color: '#9c4e06' });
    m4Hit(s, X(0) - 20, ay - tr, 18, 2 * tr, function () { m4s1Play(s); });     /* 吹き口をクリック：吹く */
  }
  dimH(ctx, X(0), X(l), ay + (s.ins === 'guitar' ? 80 : 52), '#3a414c', 'l', { ticks: false });
  label(ctx, '= ' + sig(l * 100, 3) + ' cm' + (on ? '　' + MUS.jp(m) + '（' + MUS.en(m) + '）' + sig(f, 4) + ' Hz' : ''), (X(0) + X(l)) / 2 + 9, ay + (s.ins === 'guitar' ? 69 : 41), { size: 11, color: '#3a414c', align: 'left' });
  /* 下：五線譜（横はばいっぱい）。音符をクリックでその音 */
  ctx.save(); ctx.strokeStyle = '#e3e6ea'; ctx.beginPath(); ctx.moveTo(8, Hi + 4); ctx.lineTo(W - 8, Hi + 4); ctx.stroke(); ctx.restore();
  label(ctx, '五線譜（音符をクリック）', 8, Hi + 18, { size: 11.5, bold: true, color: COL.ink2, align: 'left' });
  var sp = nar ? 10 : 13, yTop = Hi + 30 + 3 * sp, x0 = 8, x1 = W - 8, Y = staff(ctx, x0, x1, yTop, sp), nx0 = x0 + sp * 4, dx = (x1 - nx0 - 6) / M4S1_NOTES.length;
  M4S1_NOTES.forEach(function (mm, i) {
    var x = nx0 + dx * (i + 0.5), sel = s.nm === mm;
    noteHead(ctx, x, MUS.step(mm), Y, sp, sel ? '#e07b18' : '#14171c', false, !sel);
    label(ctx, MUS.jp(mm), x, Y(-4) + 6, { size: nar ? 9.5 : 11, bold: sel, color: sel ? '#c9670c' : COL.ink2 });
    m4Hit(s, x - dx / 2, yTop - 3 * sp, dx, Y(-4) + 14 - (yTop - 3 * sp), function () { s.nm = mm; m4s1Play(s); });
  });
}
function rightM4S1(s, R) {
  var h = '<div class="qcard"><p class="qt">楽器の音の高さと音色</p>' +
    '<p>弦楽器も管楽器も、振動する部分の長さ $l$ で基本振動数が決まる（基本振動では $l = \\dfrac{\\lambda}{2}$）。</p>' +
    '<div class="qeq">$$f = \\frac{v}{2l}$$</div>' +
    '<table class="reltab grid1"><tbody><tr><th>リコーダー</th><td class="l">指で穴をふさぐ・開けて、管の長さを変える（開いた穴の所で管が終わったのと同じ）</td></tr>' +
    '<tr><th>オーボエ</th><td class="l">リードの振動を、円すい形の管で鳴らす。倍音が多く、明るい音色</td></tr>' +
    '<tr><th>モノコード（ギター）</th><td class="l">こまを動かして、振動する弦の長さを変える（ギターでは指でフレットをおさえる）</td></tr></tbody></table>' +
    '<p class="qnote">同じ高さの音でも、楽器によって倍音のまざり方（スペクトル）がちがうので、音色がちがう。図の長さは、両はしが開いた管・弦として計算したおよその値。</p></div>';
  R.innerHTML = mathify(h);
}

/* =====================================================================
   ④-2 倍音とは何か（ナチュラルトランペット）
   ・バルブのないトランペット（ナチュラルトランペット）は、管の長さが変えられない。唇の振動のさせ方で、
     管の固有振動（基本振動数 f₁ の 2 倍・3 倍・4 倍 …）を選んで音を出す
   ・f₁ = 130.8 Hz（C3）とする。n = 2〜8：C4・G4・C5・E5・G5・（B♭5 より少し低い）・C6
   ===================================================================== */
var M4S2_F1 = M4_C4 / 2;
DEFS.m4s2 = {
  id: 'm4s2', mode: 'mode4', num: 4,
  title: '倍音のみで演奏する楽器', short: '倍音のみの楽器',
  desc: '基本振動数 $f_1$ の整数倍の振動数の音を<b>倍音</b>という。ナチュラルトランペットは ④-2 で見た現代の楽器と違い、穴（バルブ）もピストンも持たない古楽器であり、倍音のみで演奏する。<span class="todo">出せる音を五線譜からクリックしよう。</span>',
  strobe: false, stepDiv: 16,
  vars: [],
  init: function (s) { s.n = null; s.tN = 0; },
  onDefaults: function (s) { s.n = null; s.renderRight(); },
  buttons: [],
  tEnd: function () { return M4_TEND; },
  tInfo: function () { return ''; },
  gT: function () { return 1; },
  height: function (s, w) { return w < 620 ? 520 : Math.round(clamp(w * 0.46, 300, 360)); },
  afterBuild: function (s) {
    m4Right(s, 'オシロスコープ（トランペットの音）'); m3TimeBar(s, false); m4Hits(s);
    m4SndToggle(s, function () { if (!s.n) s.n = 2; s.tN = s.t; m4Note('m4s2', s.n * M4S2_F1, 'trumpet'); m4Go(s); s.renderRight(); });
    m4s2BwvBuild(s);
  },
  draw: function (s, ctx, W, H) {
    drawM4S2(s, ctx, W, H); m4s2BwvDraw(s);
    var f = s.n ? s.n * M4S2_F1 : 0;
    m4Scope(s, f, M4_TIM.trumpet, f ? s.n + ' 倍振動の音 $f = ' + s.n + 'f_1 = ' + sig(f, 4) + '$ Hz。この音にも、さらにその 2 倍・3 倍 … の倍音がまざっている（スペクトル）' : '五線譜の音符をクリック', 6000);
  },
  right: function (s, R) { rightM4S2(s, R); }
};
function drawM4S2(s, ctx, W, H) {
  s._h4 = [];
  var nar = W < 620, sw = nar ? W - 16 : Math.round(W * 0.46), sp = 9, yTop = 50;
  label(ctx, '出せる音（音符をクリック）', 8, 14, { size: 11.5, bold: true, color: COL.ink2, align: 'left' });
  var x0 = 8, x1 = x0 + sw, Y = staff(ctx, x0, x1, yTop, sp), nx0 = x0 + 42, dx = (x1 - nx0 - 6) / 7;
  for (var n = 2; n <= 8; n++) {
    (function (n) {
      var f = n * M4S2_F1, nr = MUS.near(f), x = nx0 + dx * (n - 2 + 0.5), on = s.n === n, fl = n === 7;   /* 7 倍はシ♭（B♭5）より少し低い：♭で書く */
      noteHead(ctx, x, MUS.step(fl ? nr.m + 1 : nr.m), Y, sp, on ? '#e07b18' : '#14171c', fl ? '♭' : MUS.black(nr.m), !on);
      label(ctx, n + ' 倍', x, Y(-4) + 4, { size: 10.5, bold: true, color: on ? '#c9670c' : COL.ink2 });
      label(ctx, fl ? 'シ♭↓' : MUS.jp(nr.m), x, Y(-4) + 18, { size: 10, color: COL.ink2 });
      m4Hit(s, x - dx / 2, yTop - 3 * sp, dx, Y(-4) + 30 - (yTop - 3 * sp), function () { s.n = n; s.tN = s.t; m4Note('m4s2', n * M4S2_F1, 'trumpet'); m4Go(s); s.renderRight(); });
    })(n);
  }
  label(ctx, '↓：7 倍の音は、平均律のシ♭より少し低い', x0 + 4, Y(-4) + 38, { size: 10, color: COL.sub, align: 'left' });
  /* 右：のばした管の定在波と、振動数のはしご */
  var ax0 = nar ? 18 : x1 + 30, ax1 = W - 14, ay = nar ? Y(-4) + 96 : 70, Lp = 340 / (2 * M4S2_F1);   /* 管の長さ（両はしが開いた管とみなす） */
  label(ctx, 'ナチュラルトランペット（管をまっすぐにのばした図）', ax0, ay - 40, { size: 11, bold: true, color: COL.ink2, align: 'left' });
  var X = function (x) { return ax0 + 22 + x / Lp * (ax1 - ax0 - 40); }, tr = 10;
  ctx.save(); ctx.fillStyle = '#e8c766'; ctx.strokeStyle = '#8a6a1a'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(X(0), ay - 5); ctx.lineTo(X(Lp * 0.85), ay - tr); ctx.quadraticCurveTo(X(Lp), ay - tr, X(Lp) + 6, ay - 26); ctx.lineTo(X(Lp) + 6, ay + 26); ctx.quadraticCurveTo(X(Lp), ay + tr, X(Lp * 0.85), ay + tr); ctx.lineTo(X(0), ay + 5); ctx.closePath(); ctx.fill(); ctx.stroke(); ctx.restore();
  ctx.save(); ctx.fillStyle = '#c9a33a'; rrect(ctx, X(0) - 14, ay - 7, 14, 14, 4); ctx.fill(); ctx.restore();
  label(ctx, 'マウスピース（唇）', X(0) - 6, ay + 22, { size: 10, color: COL.ink2, align: 'left' });
  if (s.n) {
    var th = TAU * 0.7 * (s.t - s.tN);
    [1, -1].forEach(function (sg) { plotF(ctx, function (x) { return sg * Math.cos(s.n * Math.PI * x / Lp); }, 0, Lp, X, function (y) { return ay - y * (tr - 2); }, 'rgba(22,99,181,.4)', 1, [3, 3]); });
    plotF(ctx, function (x) { return Math.cos(s.n * Math.PI * x / Lp) * Math.cos(th); }, 0, Lp, X, function (y) { return ay - y * (tr - 2); }, '#1663b5', 2.2);
    label(ctx, s.n + ' 倍振動（管の長さは同じ）', (X(0) + X(Lp)) / 2, ay + 34, { size: 11, bold: true, color: '#1663b5' });
  }
  /* 振動数のはしご：f₁ の 1〜8 倍 */
  var ly0 = nar ? ay + 70 : ay + 64, ly1 = H - 20, lx = ax0 + 30, FX = function (f) { return ly1 - (f / (9 * M4S2_F1)) * (ly1 - ly0); };
  axisArrow(ctx, lx, ly1, lx, ly0 - 6);
  label(ctx, '振動数', lx + 6, ly0 - 4, { size: 10, color: COL.sub, align: 'left' });
  for (var k = 1; k <= 8; k++) {
    var yy = FX(k * M4S2_F1), sel = s.n === k, nr2 = MUS.near(k * M4S2_F1);
    ctx.save(); ctx.strokeStyle = sel ? '#e07b18' : (k === 1 ? '#9aa1ab' : '#5b7a90'); ctx.lineWidth = sel ? 3 : 1.6; ctx.beginPath(); ctx.moveTo(lx, yy); ctx.lineTo(lx + 60, yy); ctx.stroke(); ctx.restore();
    label(ctx, (k === 1 ? 'f₁' : k + 'f₁') + ' = ' + Math.round(k * M4S2_F1) + ' Hz　' + (k === 7 ? 'シ♭（B♭5）より少し低い' : MUS.jp(nr2.m) + '（' + MUS.en(nr2.m) + '）') + (k === 1 ? '　基音（ふつうは出さない）' : ''), lx + 66, yy, { size: 10, bold: sel, color: sel ? '#c9670c' : COL.ink2, align: 'left' });
  }
}
/* ---------------------------------------------------------------------
   ブランデンブルク協奏曲 第 2 番 ヘ長調 BWV 1047 第 1 楽章、トランペットの最初の登場（第 13 小節〜）の 1 フレーズ
   （2026-11-08 千葉さん 16 回目。音名の並びは千葉さんからもらったもの）
   ・F 管のナチュラルトランペット：基本振動数 f₁ = F2 = 87.31 Hz（管の長さ約 2 m）。楽譜は C 管として書く（記音）
   ・記音 ド・ミ・ソ・ド・レ・シ♭・ド・シ♭・ラ・ソ・ファ ＝ 第 8・10・12・16・18・14・16・14・13・12・11 倍音
   ・実音 ファ・ラ・ド・ファ・ソ・ミ♭・ファ・ミ♭・レ・ド・シ♭（F5〜G6）。倍音そのままの振動数で鳴らす
     （11・13・14 倍音は平均律から少しずれる。奏者は唇で少し直して吹く）
   ・リズムは簡単にした（8 分音符で並べ、最後だけ長く）
   --------------------------------------------------------------------- */
var M4_BWV = { f1: 87.307, notes: [[8, 77], [10, 81], [12, 84], [16, 89], [18, 91], [14, 87, '♭'], [16, 89], [14, 87, '♭'], [13, 86], [12, 84], [11, 82, '♭']], dt: 0.3, last: 0.9 };
function m4s2BwvBuild(s) {
  var bx = el('div', 'bwvbox'), hd = el('div', 'bwvh');
  hd.appendChild(el('span', 'bwvt', 'ブランデンブルク協奏曲 第 2 番 ヘ長調 BWV 1047（J. S. バッハ）より'));
  var b = el('button', 'b bwvplay glow', '▶ このフレーズを吹く'); b.type = 'button';
  b.addEventListener('click', function () { if (s.bwI !== null && s.bwI !== undefined) m4s2BwvStop(s); else m4s2BwvPlay(s); });
  hd.appendChild(b); bx.appendChild(hd);
  var cv = el('canvas'); cv.setAttribute('aria-label', 'ブランデンブルク協奏曲 第 2 番のトランペットのフレーズの楽譜。音符をクリックするとその音が鳴る'); bx.appendChild(cv);
  bx.appendChild(el('p', 'bwvn', '第 1 楽章で、トランペットが最初に出てくる所（第 13 小節〜）。F 管のナチュラルトランペット（基本振動数 f₁ = 87.3 Hz、管の長さ約 2 m）は、上の図より長い管で、高い倍音（8 倍〜18 倍）を使って音階のように吹く。リズムは簡単にしてある。'));
  s.cw.insertAdjacentElement('afterend', bx);
  s.bwBtn = b; s.bwCv = cv; s.bwI = null;
  cv.addEventListener('click', function (ev) { var r = cv.getBoundingClientRect(), x = ev.clientX - r.left, h = (s._bwH || []).filter(function (o) { return x >= o.x0 && x < o.x1; })[0]; if (h) { m4s2BwvStop(s); s.bwSel = h.i; m4Note('m4s2', h.n * M4_BWV.f1, 'trumpet'); s._bwk = null; m4s2BwvDraw(s); } });
  cv.addEventListener('pointermove', function (ev) { var r = cv.getBoundingClientRect(), x = ev.clientX - r.left; cv.style.cursor = (s._bwH || []).some(function (o) { return x >= o.x0 && x < o.x1; }) ? 'pointer' : 'default'; });
  AUDIO.onChange(function (o) { if (o !== 'm4s2' && s.bwI !== null && !s._bwSwitch) m4s2BwvStop(s); });   /* ほかの音を鳴らしたら止める */
}
function m4s2BwvSync(s) { var on = s.bwI !== null; s.bwBtn.textContent = on ? '■ 止める' : '▶ このフレーズを吹く'; s.bwBtn.classList.toggle('glow', !on); s.bwBtn.classList.toggle('on', on); s._bwk = null; m4s2BwvDraw(s); }
function m4s2BwvStop(s) { s.bwTok = null; if (s.bwI !== null) { s.bwI = null; if (AUDIO.owner() === 'm4s2') AUDIO.stop(); } m4s2BwvSync(s); }
function m4s2BwvPlay(s) {
  var tok = {}; s.bwTok = tok; s.bwSel = null;
  var step = function (i) {
    if (s.bwTok !== tok) return;
    if (i >= M4_BWV.notes.length || document.hidden) { s.bwTok = null; s.bwI = null; m4s2BwvSync(s); return; }
    var nt = M4_BWV.notes[i], last = i === M4_BWV.notes.length - 1;
    s.bwI = i; s._bwSwitch = true;
    AUDIO.pluck('m4s2', { f: nt[0] * M4_BWV.f1, partials: M4_TIM.trumpet }, 0.85, last ? M4_BWV.last + 0.3 : M4_BWV.dt + 0.12);
    s._bwSwitch = false; m4s2BwvSync(s);
    setTimeout(function () { step(i + 1); }, (last ? M4_BWV.last + 0.3 : M4_BWV.dt) * 1000);
  };
  step(0);
}
function m4s2BwvDraw(s) {
  var cv = s.bwCv; if (!cv || !cv.offsetParent) return;
  var W = Math.max(260, Math.floor(cv.clientWidth || 300)), H = 190, key = [W, s.bwI, s.bwSel].join('|');
  if (s._bwk === key) return; s._bwk = key;
  var ctx = prep(cv, W, H); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H);
  var nar = W < 520, sp = nar ? 8 : 9, yTop = 16 + 5 * sp, Y = staff(ctx, 4, W - 4, yTop, sp), nx0 = 4 + sp * 3.6, dx = (W - 8 - nx0) / M4_BWV.notes.length;
  label(ctx, '実音（ヘ長調）', W - 6, 8, { size: 10, bold: true, color: COL.sub, align: 'right' });
  s._bwH = [];
  M4_BWV.notes.forEach(function (nt, i) {
    var x = nx0 + dx * (i + 0.5), cur = s.bwI === i || (s.bwI === null && s.bwSel === i), fl = nt[2] === '♭', m = nt[1];
    noteHead(ctx, x, MUS.step(fl ? m + 1 : m), Y, sp, cur ? '#e07b18' : '#14171c', fl ? '♭' : false, false);
    var nr = { cent: 1200 * Math.log(nt[0] * M4_BWV.f1 / MUS.fET(m)) / Math.LN2 }, yb = Y(MUS.step(77)) + 4 * sp + 8;
    label(ctx, (fl ? MUS.jp(m + 1) + '♭' : MUS.jp(m)), x, yb, { size: nar ? 9.5 : 11, bold: cur, color: cur ? '#c9670c' : COL.ink2 });
    label(ctx, nt[0] + (nar ? '' : ' 倍'), x, yb + 16, { size: nar ? 9.5 : 10.5, bold: true, color: cur ? '#c9670c' : '#1663b5' });
    if (Math.abs(nr.cent) > 15) label(ctx, (nr.cent > 0 ? '高め' : '低め'), x, yb + 31, { size: nar ? 8.5 : 9.5, color: '#9b2418' });
    s._bwH.push({ x0: x - dx / 2, x1: x + dx / 2, i: i, n: nt[0] });
  });
  if (nar) { label(ctx, '数字：何倍の倍音か', 4, H - 20, { size: 8.5, color: COL.sub, align: 'left' }); label(ctx, '「高め」「低め」：平均律から少しずれる（唇で直して吹く）', 4, H - 7, { size: 8.5, color: COL.sub, align: 'left' }); }
  else label(ctx, '数字：何倍の倍音か。「高め」「低め」：平均律の音から少しずれる倍音（奏者は唇で少し直して吹く）', 4, H - 7, { size: 9.5, color: COL.sub, align: 'left' });
}
function rightM4S2(s, R) {
  var h = '<div class="qcard"><p class="qt">倍音</p>' +
    '<p>管や弦の固有振動数は、基本振動数 $f_1$ の整数倍になる（開管・弦）。$2f_1, 3f_1, 4f_1, \\cdots$ の音を<b>倍音</b>という（$f_1$ の音は<b>基音</b>）。</p>' +
    '<div class="qeq">$$f_n = n f_1\\quad(n = 1, 2, 3, \\cdots)$$</div>' +
    '<p>バルブのないトランペットは、管の長さを変えられない。唇の振動を変えて、どの固有振動で鳴らすかを選ぶので、出せるのは倍音の列（ド・ソ・ド・ミ・ソ …）だけ。</p>' +
    '<p>となりの倍音の振動数の比は $2:3$（完全 5 度）、$3:4$（完全 4 度）、$4:5$（長 3 度）、$5:6$（短 3 度）… と、だんだん音程がせまくなる。</p>';
  if (s.n) h += '<p class="qnow"><span class="qtag now">いま</span>$f_' + s.n + ' = ' + s.n + ' \\times ' + sig(M4S2_F1, 4) + ' = ' + sig(s.n * M4S2_F1, 4) + '$ Hz</p>';
  h += '<p class="qnote">楽器の 1 つの音にも、基音とその倍音がまざっている（右のスペクトル）。倍音のまざり方が音色を決める。</p></div>';
  R.innerHTML = mathify(h);
}

/* =====================================================================
   ④-3 和音（コード）とは何か（2026-11-07 千葉さん 14 回目に 2 段に）
   ・上の段：2 つの音。ドド（オクターブ上 1 : 2）・ドミ（長 3 度 4 : 5）・ドファ（4 度 3 : 4）・ドソ（5 度 2 : 3）
   ・下の段：3 つの音。ドミソ（長 3 和音 4 : 5 : 6）・ドファラ（3 : 4 : 5）・ソシレ（長 3 和音 4 : 5 : 6）・ド・ド♯・レ（にごった和音）
   ・各段：左＝五線譜とピアノの鍵盤（どれをひいているか）、右＝オシロスコープ（それぞれの音と合成した波）
   ・振動数はちょうど整数比（純正律）。ドは 261.63 Hz
   ===================================================================== */
var M4S3_IV = [
  { k: 'CC', nm: 'ド・ド（オクターブ上）', r: [1, 2], m: [60, 72], good: true },
  { k: 'CE', nm: 'ド・ミ（長 3 度）', r: [4, 5], m: [60, 64], good: true },
  { k: 'CF', nm: 'ド・ファ（4 度）', r: [3, 4], m: [60, 65], good: true },
  { k: 'CG', nm: 'ド・ソ（5 度）', r: [2, 3], m: [60, 67], good: true },
  { k: 'CCs', nm: 'ド・ド♯', r: [15, 16], m: [60, 61], good: false }   /* 16 回目の後（17 回目）に追加：半音。純正律の半音 16/15 */
];
var M4S3_CH = [
  { k: 'CEG', nm: 'ド・ミ・ソ（長 3 和音）', r: [4, 5, 6], m: [60, 64, 67], good: true },
  { k: 'CFA', nm: 'ド・ファ・ラ', r: [3, 4, 5], m: [60, 65, 69], good: true },
  { k: 'GBD', nm: 'ソ・シ・レ（長 3 和音）', r: [4, 5, 6], m: [67, 71, 74], good: true, base: 3 / 2 },
  { k: 'CCD', nm: 'ド・ド♯・レ', r: [120, 128, 135], m: [60, 61, 62], good: false }
];
var M4S3_COL = ['#ff9fb0', '#9fc8ff', '#ffd678'];
function m4s3Qc(c) { var f0 = M4_C4 * (c.base || 1) / c.r[0]; return { c: c, f: c.r.map(function (r) { return r * f0; }), f0: f0 }; }
function m4s3Q(s) { return m4s3Qc(M4S3_CH[s.ci]); }
function m4s3Qi(s) { return m4s3Qc(M4S3_IV[s.ii]); }
DEFS.m4s3 = {
  id: 'm4s3', mode: 'mode4', num: 5,
  title: '和音（コード）とは何か', short: '和音（コード）',
  desc: '高さのちがう音を同時に鳴らしたものを<b>和音</b>（コード）という。振動数の比が簡単な整数比だと、よく調和して聞こえる。<span class="todo">2 つの音・3 つの音を選ぶと音が鳴る。合成した波を比べよう。</span>なお、ここでは振動数をちょうど整数比にしている（純正律）。',
  strobe: false, stepDiv: 16,
  vars: [],
  init: function (s) { s.ci = 0; s.ii = 1; s.last = 'ch'; },
  onDefaults: function (s) { s.ci = 0; s.ii = 1; s.last = 'ch'; m4s3Sync(s); },
  buttons: M4S3_IV.map(function (c, i) { return { k: 'v' + i, label: c.nm, seg: 'iv', segLabel: '2 つの音', onClick: function (s) { s.ii = i; s.last = 'iv'; m4s3Sync(s); s.resound(); s.draw(); } }; })
    .concat(M4S3_CH.map(function (c, i) { return { k: 'c' + i, label: c.nm, seg: 'ch', segLabel: '和音', onClick: function (s) { s.ci = i; s.last = 'ch'; m4s3Sync(s); s.resound(); s.draw(); } }; })),
  tEnd: function () { return M4_TEND; },
  tInfo: function () { return ''; },
  gT: function () { return 1; },
  height: function (s, w) { return w < 380 ? 330 : 236; },
  afterBuild: function (s) {
    document.getElementById('m4s3').classList.add('wide1');
    var box = el('div', 'brows'); s.cw.insertAdjacentElement('beforebegin', box);
    var segs = s.row1b.querySelectorAll('.seg');
    s.bRows = [['2 つの音（重音）', 0], ['3 つの音（和音）', 1]].map(function (p) {
      var row = el('div', 'brow'), hd = el('div', 'browh m4hd'), lc = el('div', 'browl'), rc = el('div', 'browr');
      hd.appendChild(el('span', 'm4hdt', p[0])); if (segs[p[1]]) hd.appendChild(segs[p[1]]);
      row.appendChild(hd); row.appendChild(lc); row.appendChild(rc); box.appendChild(row);
      return { row: row, L: lc, R: rc };
    });
    s.bRows[0].L.appendChild(s.cw);
    var cw2 = el('div', 'cvwrap'), cv2 = el('canvas'); cw2.appendChild(cv2); s.bRows[1].L.appendChild(cw2); s.cv2 = cv2;
    s.sc1 = new Scope(s.bRows[0].R, 'オシロスコープ（2 つの音と合成した音）');
    s.scope = new Scope(s.bRows[1].R, 'オシロスコープ（3 つの音と合成した音）');
    s.Rdyn = el('div', 'rdyn brcard'); box.insertAdjacentElement('afterend', s.Rdyn); s.R.innerHTML = '';
    s.resound = function () { var q = s.last === 'iv' ? m4s3Qi(s) : m4s3Q(s); m4Chord(s, q.f.map(function (f) { return { f: f, partials: M4_TIM.piano }; }), 2.5); };   /* 選ぶと鳴る */
    m4SndToggle(s, s.resound);
    m3TimeBar(s, false); m4NoPlay(s); m4s3Sync(s);
  },
  draw: function (s, ctx, W, H) {
    drawM4S3Row(s, ctx, W, H, m4s3Qi(s));
    if (s.cv2 && s.cv2.offsetParent) { var w2 = Math.max(240, Math.floor(s.cv2.clientWidth || 300)), c2 = prep(s.cv2, w2, H); c2.fillStyle = '#fff'; c2.fillRect(0, 0, w2, H); drawM4S3Row(s, c2, w2, H, m4s3Q(s)); }
    m4s3ScopeQ(s.sc1, m4s3Qi(s)); m4s3ScopeQ(s.scope, m4s3Q(s));
  },
  right: function (s, R) { rightM4S3(s, R); }
};
function m4s3Sync(s) { m2Sync(s, M4S3_IV.map(function (c, i) { return ['v' + i, s.ii === i]; }).concat(M4S3_CH.map(function (c, i) { return ['c' + i, s.ci === i]; }))); if (s.Rdyn) s.renderRight(); }
/* ピアノの鍵盤（lo〜hi）。on：ひいている鍵（色つき）。④-4 の鍵盤と同じ形 */
function m4Keys(ctx, x0, y, w, h, lo, hi, on, cols) {
  var whites = [], blacks = [];
  for (var m = lo; m <= hi; m++) (MUS.black(m) ? blacks : whites).push(m);
  var ww = w / whites.length, xOf = function (m) { return MUS.black(m) ? x0 + whites.indexOf(m - 1) * ww + ww : x0 + whites.indexOf(m) * ww + ww / 2; };
  whites.forEach(function (m, i) {
    var k = on.indexOf(m), x = x0 + i * ww;
    ctx.save(); ctx.fillStyle = k >= 0 ? cols[k] : '#fff'; ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.1; rrect(ctx, x + 1, y, ww - 2, h, 3); ctx.fill(); ctx.stroke(); ctx.restore();
    label(ctx, MUS.jp(m), x + ww / 2, y + h - 10, { size: ww < 22 ? 8.5 : 10, bold: k >= 0, color: COL.ink });
  });
  blacks.forEach(function (m) {
    var k = on.indexOf(m), x = xOf(m), bw = ww * 0.58;
    ctx.save(); ctx.fillStyle = k >= 0 ? cols[k] : '#20242b'; ctx.strokeStyle = '#20242b'; rrect(ctx, x - bw / 2, y, bw, h * 0.6, 3); ctx.fill(); ctx.stroke(); ctx.restore();
  });
}
/* 1 段の図：左に五線譜、右にピアノの鍵盤（せまい画面では上下） */
function drawM4S3Row(s, ctx, W, H, q) {
  var nar = W < 380, sp = nar ? 11 : 13, kcol = ['#ffb3bf', '#a9cdfa', '#ffdf8a'], ncol = ['#d1353f', '#1663b5', '#c9970c'];
  label(ctx, q.c.nm, 8, 12, { size: 12.5, bold: true, color: COL.ink, align: 'left' });
  var sw = nar ? W - 16 : Math.round(W * 0.36), yTop = 34 + 2 * sp, Y = staff(ctx, 8, 8 + sw, yTop, sp), cx = 8 + sw * 0.66;
  q.c.m.forEach(function (m, i) { noteHead(ctx, cx + (i > 0 && MUS.step(m) === MUS.step(q.c.m[i - 1]) ? sp * 2.4 : 0), MUS.step(m), Y, sp, ncol[i], MUS.black(m)); });   /* 同じ段（ド・ド♯）はずらす */
  var kx = nar ? 8 : 8 + sw + 14, kw = W - kx - 8, ky = nar ? Y(-2) + 14 : yTop - 2 * sp + 4, kh = nar ? 84 : Math.round(Y(-2) - ky + 6);
  m4Keys(ctx, kx, ky, kw, kh, 60, 74, q.c.m, kcol);
  var ty = Math.max(Y(-2), ky + kh) + 20;
  /* 振動数の比は大きく（2026-11-07 千葉さん 15 回目：2 倍の大きさ） */
  label(ctx, '振動数の比　' + q.c.r.join(' : '), W / 2, ty + 6, { size: nar ? 20 : 23, bold: true, color: COL.ink });
  var l1 = '（' + q.f.map(function (f, i) { return MUS.jp(q.c.m[i]) + ' ' + sig(f, 4) + ' Hz'; }).join('、') + '）',
    l2 = q.c.good ? ['ドが ' + q.c.r[0] + ' 回振動する間に、ほかの音は ' + q.c.r.slice(1).join(' 回・') + ' 回', '→ 合成した波は同じ形をくり返す'] : (q.c.r.length === 2 ? ['振動数が近い（半音）ので、合成した波の大きさがゆれる', '→ うなりが生じて、にごって聞こえる'] : ['比が複雑なので、なかなかそろわない', '→ 合成した波の形が定まらない（にごった響き）']),
    lines = nar ? [[l1, 0], [l2[0], 1], [l2[1], 1]] : [[l1, 0], [l2.join(' '), 1]];
  lines.forEach(function (ln, k) { label(ctx, ln[0], W / 2, ty + 30 + k * (nar ? 16 : 18), { size: nar ? 10 : (ln[1] ? 11 : 10.5), bold: !!ln[1], color: ln[1] ? (q.c.good ? '#14653a' : '#9b2418') : COL.ink2 }); });
}
/* オシロスコープ：それぞれの音と合成した波。そろう時間（いちばん低い音が r₀ 回振動する時間）の 2 くぎり分 */
function m4s3ScopeQ(sc, q) {
  if (!sc || !sc.cv.offsetParent) return;
  var W = Math.max(240, Math.floor(sc.cv.clientWidth || 300)), n = q.f.length, lh = Math.round(clamp(W * 0.1, 38, 52)), key = [W, q.c.k].join('|');
  if (sc._k === key) return; sc._k = key;
  var H = (n + 1) * (15 + lh + 3) + 20, ctx = prep(sc.cv, W, H); ctx.clearRect(0, 0, W, H);
  var Tc = 1 / q.f0, span = q.c.good ? 2 * Tc : (n === 2 ? 1.2 / (q.f[1] - q.f[0]) : 4 / q.f[0]);   /* ド・ド♯：うなりが 1 回分見える長さ */
  var lanes = q.f.map(function (f, i) { return { f: function (t) { return 0.8 * Math.sin(TAU * f * t); }, col: M4S3_COL[i], name: MUS.jp(q.c.m[i]) + '（' + sig(f, 4) + ' Hz）' }; });
  lanes.push({ f: function (t) { var y = 0; q.f.forEach(function (f) { y += Math.sin(TAU * f * t); }); return 0.8 * y / n; }, col: '#7dffb4', name: '合成した波（聞こえる音）' });
  var y = 0;
  lanes.forEach(function (ln) { label(ctx, ln.name, 6, y + 7.5, { size: 10.5, bold: true, color: ln.col, align: 'left', halo: false }); sc.screen(ctx, 0, y + 15, W, lh, { t0: 0, span: span, yMax: 1, traces: [{ f: ln.f, col: ln.col, fmax: 2000 }] }); y += 15 + lh + 3; });
  if (q.c.good) {
    for (var k = 0; k <= 2; k++) {
      var px = clamp(k * Tc / span * W, 1, W - 1);
      ctx.save(); ctx.strokeStyle = 'rgba(255,214,120,.9)'; ctx.setLineDash([4, 3]); ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(px, 15); ctx.lineTo(px, y - 3); ctx.stroke(); ctx.restore();
      label(ctx, 'そろう', clamp(px, 20, W - 20), y + 8, { size: 10, bold: true, color: '#ffd678', halo: false });
    }
  }
  var cap = q.c.good ? '横はば：' + sig(span * 1000, 3) + ' ms。黄色の線の所で ' + n + ' つの音の振動がそろい、合成した波は同じ形をくり返す' : (n === 2 ? '横はば：' + sig(span * 1000, 3) + ' ms。振動数が近すぎるので、合成した波の大きさがゆれて（うなり 1 秒に ' + Math.round(q.f[1] - q.f[0]) + ' 回）、にごって聞こえる' : '') || '横はば：' + sig(span * 1000, 3) + ' ms。' + n + ' つの音の振動がなかなかそろわないので、合成した波の形がくり返さない';
  if (sc.cap._h !== cap) { sc.cap._h = cap; sc.cap.innerHTML = mathify(cap); }
}
function rightM4S3(s, R) {
  var q = s.last === 'iv' ? m4s3Qi(s) : m4s3Q(s), c = q.c;
  var h = '<div class="qcard"><p class="qt">和音と振動数の比</p>' +
    '<p>ド・ミ・ソ（長 3 和音）の振動数の比は $4:5:6$。ドが 4 回振動する間に、ミは 5 回、ソは 6 回振動するので、合成した波は短い時間でもとの形にもどる（くり返す）。このような和音は、よく調和して（<b>協和して</b>）聞こえる。</p>' +
    '<table class="reltab grid1"><thead><tr><th>音・和音</th><th>振動数の比</th><th>響き</th></tr></thead><tbody>' +
    '<tr><td>ド・ド（オクターブ上）</td><td>$1:2$</td><td>とけ合って 1 つの音のよう</td></tr><tr><td>ド・ソ（5 度）</td><td>$2:3$</td><td>よく協和する</td></tr><tr><td>ド・ファ（4 度）</td><td>$3:4$</td><td>協和する</td></tr><tr><td>ド・ミ（長 3 度）</td><td>$4:5$</td><td>明るく協和する</td></tr><tr><td>ド・ド♯（半音）</td><td>$15:16$</td><td>にごる（不協和）</td></tr>' +
    '<tr><td>ド・ミ・ソ、ソ・シ・レ</td><td>$4:5:6$</td><td>明るい（長 3 和音）</td></tr><tr><td>ド・ファ・ラ</td><td>$3:4:5$</td><td>協和する</td></tr><tr><td>ド・ド♯・レ</td><td>$120:128:135$</td><td>にごる（不協和）</td></tr></tbody></table>' +
    '<p class="qnow"><span class="qtag now">いま</span>' + c.nm + '：' + q.f.map(function (f) { return sig(f, 4) + ' Hz'; }).join('・') + '（比 $' + c.r.join(':') + '$）</p>' +
    '<p class="qnote">ここでは振動数をちょうど整数比にしている（純正律）。ピアノなどの平均律では少しずれる（④-6）。</p></div>';
  R.innerHTML = mathify(h);
}

/* =====================================================================
   ④-4 平均律とは何か・純正律とは何か（2026-11-06 千葉さん 12 回目に名前を変え、純正律も）
   ・平均律：1 オクターブ（2 倍）を 12 の半音に等しい比で分ける。半音 = 2^(1/12) ≒ 1.0595 倍。A4 = 440 Hz を基準に f = 440 × 2^(n/12)
   ・純正律（ハ長調）：ドを 1 として 1, 9/8, 5/4, 4/3, 3/2, 5/3, 15/8, 2（簡単な整数比）。ここではドを平均律と同じ 261.63 Hz にする
   ===================================================================== */
var M4_JUST = [[60, 1, 1, '1'], [62, 9, 8, '9/8'], [64, 5, 4, '5/4'], [65, 4, 3, '4/3'], [67, 3, 2, '3/2'], [69, 5, 3, '5/3'], [71, 15, 8, '15/8'], [72, 2, 1, '2']];
function m4Just(m) { for (var i = 0; i < M4_JUST.length; i++) if (M4_JUST[i][0] === m) return MUS.fET(60) * M4_JUST[i][1] / M4_JUST[i][2]; return null; }
DEFS.m4s4 = {
  id: 'm4s4', mode: 'mode4', num: 6,
  title: '純正律とは何か・平均律とは何か', short: '純正律・平均律とは',
  desc: '<b>純正律</b>は振動数の比を簡単な整数比にした音階、<b>平均律</b>は 1 オクターブを 12 の半音に等しい比で分けた音階。<span class="todo">鍵盤をクリックして、2 つの音階の振動数を比べよう。</span>',
  strobe: false, stepDiv: 16,
  vars: [],
  init: function (s) { s.km = null; s.tune = 'just'; s.chord = null; },
  onDefaults: function (s) { s.km = null; s.tune = 'just'; s.chord = null; m4s4Sync(s); },
  /* 鳴らす音階：平均律／純正律／平均律・純正律を同時に鳴らす（どれか 1 つ）。和音（ドミソ・ドファラ・ソシレ）も鳴らせる（2026-11-07 千葉さん 13 回目） */
  /* 純正律 → 平均律の順（2026-11-07 千葉さん 15 回目） */
  buttons: [{ k: 'tj', label: '純正律', seg: 'tn', segLabel: '鳴らす音階', onClick: function (s) { m4s4Tune(s, 'just'); } },
            { k: 'te', label: '平均律', seg: 'tn', onClick: function (s) { m4s4Tune(s, 'et'); } },
            { k: 'tb', label: '純正律・平均律を<br>同時に鳴らす', cls: 'two', onClick: function (s) { m4s4Tune(s, 'both'); } }]
    .concat(M4S3_CH.slice(0, 3).map(function (c, i) { return { k: 'c' + i, label: c.nm, seg: 'chd', segLabel: '和音を鳴らす', onClick: function (s) { s.chord = i; s.km = null; m4s4Sync(s); m4s4Play(s); s.draw(); } }; })),   /* m4s4Sync を忘れていて、ボタンが選ばれた形にならないことがあった（15 回目に直した） */
  tEnd: function () { return M4_TEND; },
  tInfo: function () { return ''; },
  gT: function () { return 1; },
  height: function (s, w) { return Math.round(clamp(w * 0.62, 360, 430)); },
  afterBuild: function (s) {
    s.R.innerHTML = ''; s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);   /* 右はオシロスコープ・スペクトルなし（説明と表だけ） */
    var segs = s.row1b.querySelectorAll('.seg');
    [['鳴らす音階', 0], ['和音を鳴らす', 1]].forEach(function (p) { if (segs[p[1]]) { var lb = el('span', 'seglbl', p[0]); segs[p[1]].insertAdjacentElement('beforebegin', lb); lblSeg(lb, segs[p[1]]); } });
    if (segs[0] && s.extra.tb) segs[0].insertAdjacentElement('afterend', s.extra.tb);   /* 「同時に鳴らす」は平均律・純正律の右に独立して */
    m3TimeBar(s, false); m4NoPlay(s); m4Hits(s);
    m4SndToggle(s, function () { if (s.km === null && s.chord === null) s.km = 60; m4s4Play(s); s.renderRight(); });
    m4s4Sync(s);
  },
  draw: function (s, ctx, W, H) { drawM4S4(s, ctx, W, H); },
  right: function (s, R) { rightM4S4(s, R); }
};
function m4s4Sync(s) { m2Sync(s, [['tj', s.tune === 'just'], ['te', s.tune === 'et'], ['tb', s.tune === 'both']].concat([0, 1, 2].map(function (i) { return ['c' + i, s.chord === i]; }))); if (s.Rdyn) s.renderRight(); }
function m4s4Tune(s, t) { s.tune = t; m4s4Sync(s); if (s.km !== null || s.chord !== null) m4s4Play(s); s.draw(); }
/* 振動数：純正律は白鍵だけ（黒鍵は平均律）。ソシレのレ（D5）は 9/4 */
function m4s4FJ(m) { if (m === 74) return MUS.fET(60) * 9 / 4; return m4Just(m) || MUS.fET(m); }
function m4s4Fs(s, m) { return s.tune === 'et' ? [MUS.fET(m)] : (s.tune === 'just' ? [m4s4FJ(m)] : [MUS.fET(m), m4s4FJ(m)]); }
/* 鳴らす：鍵盤 1 つ、または和音。同時に鳴らすときは 平均律と純正律の両方を重ねる（ずれがうなりになって聞こえる） */
function m4s4Play(s) {
  var ms = s.chord !== null ? M4S3_CH[s.chord].m : [s.km], fs = [];
  ms.forEach(function (m) { fs = fs.concat(m4s4Fs(s, m)); });
  if (fs.length === 1) m4Note('m4s4', fs[0], 'piano');
  else m4Chord(s, fs.map(function (f) { return { f: f, partials: M4_TIM.piano }; }), 3);
}
function drawM4S4(s, ctx, W, H) {
  s._h4 = [];
  var nar = W < 620, kx0 = 10, kx1 = W - 10, kh = 104, ky = H - kh - 6, whites = [], blacks = [];
  for (var m = 60; m <= 72; m++) (MUS.black(m) ? blacks : whites).push(m);
  var ww = (kx1 - kx0) / whites.length;
  var xOf = function (m) { if (!MUS.black(m)) return kx0 + whites.indexOf(m) * ww + ww / 2; return kx0 + whites.indexOf(m - 1) * ww + ww; };
  /* 上：振動数の棒。白鍵は 平均律（青）と 純正律（緑）をならべる */
  var gy0 = 44, gy1 = ky - 40, FY = function (f) { return gy1 - (f - 220) / (540 - 220) * (gy1 - gy0); };
  label(ctx, '振動数〔Hz〕', 10, 12, { size: 11, bold: true, color: COL.ink2, align: 'left' });
  ctx.save(); ctx.fillStyle = '#3aa26a'; ctx.fillRect(W - (nar ? 170 : 230), 6, 12, 10); ctx.fillStyle = '#5b8fd6'; ctx.fillRect(W - (nar ? 88 : 120), 6, 12, 10); ctx.restore();
  label(ctx, '純正律', W - (nar ? 154 : 214), 11, { size: 10.5, color: COL.ink2, align: 'left' }); label(ctx, '平均律', W - (nar ? 72 : 104), 11, { size: 10.5, color: COL.ink2, align: 'left' });
  [250, 300, 350, 400, 450, 500].forEach(function (f) { var y = FY(f); ctx.save(); ctx.strokeStyle = '#eef0f2'; ctx.beginPath(); ctx.moveTo(kx0, y); ctx.lineTo(kx1, y); ctx.stroke(); ctx.restore(); label(ctx, String(f), kx0, y - 7, { size: 9, color: COL.sub, align: 'left' }); });
  for (var m2 = 60; m2 <= 72; m2++) {
    var fe = MUS.fET(m2), fj = m4Just(m2), x = xOf(m2), sel = s.km === m2 || (s.chord !== null && M4S3_CH[s.chord].m.indexOf(m2) >= 0), bw = Math.min(12, ww * 0.26);
    if (fj) { ctx.save(); ctx.fillStyle = sel && s.tune !== 'et' ? '#e07b18' : '#3aa26a'; ctx.fillRect(x - bw - 1, FY(fj), bw, gy1 - FY(fj)); ctx.restore(); }   /* 左に純正律、右に平均律 */
    ctx.save(); ctx.fillStyle = sel && s.tune !== 'just' ? '#e07b18' : (MUS.black(m2) ? '#7f9cc4' : '#5b8fd6'); ctx.fillRect(fj ? x + 1 : x - bw / 2, FY(fe), bw, gy1 - FY(fe)); ctx.restore();
    if (sel && s.chord === null) label(ctx, (fj ? '純正律 ' + sig(fj, 5) + '　' : '') + '平均律 ' + sig(fe, 5) + ' Hz', clamp(x, 120, W - 120), 32, { size: 11.5, bold: true, color: '#c9670c' });
  }
  /* 鍵盤（C4〜C5） */
  whites.forEach(function (m3, i) {
    var x = kx0 + i * ww, sel = s.km === m3 || (s.chord !== null && M4S3_CH[s.chord].m.indexOf(m3) >= 0);
    ctx.save(); ctx.fillStyle = sel ? '#fde3c4' : '#fff'; ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.2; rrect(ctx, x + 1, ky, ww - 2, kh, 4); ctx.fill(); ctx.stroke(); ctx.restore();
    label(ctx, MUS.jp(m3), x + ww / 2, ky + kh - 26, { size: 11, bold: sel, color: sel ? '#c9670c' : COL.ink });
    label(ctx, MUS.en(m3), x + ww / 2, ky + kh - 11, { size: 9, color: COL.sub });
    var go = function () { s.km = m3; s.chord = null; m4s4Sync(s); m4s4Play(s); };
    m4Hit(s, x, ky + kh * 0.62, ww, kh * 0.38, go); m4Hit(s, x + ww * 0.3, ky, ww * 0.4, kh, go);
  });
  blacks.forEach(function (m4) {
    var x = xOf(m4), bw = ww * 0.58, sel = s.km === m4;
    ctx.save(); ctx.fillStyle = sel ? '#e07b18' : '#20242b'; rrect(ctx, x - bw / 2, ky, bw, kh * 0.6, 3); ctx.fill(); ctx.restore();
    m4Hit(s, x - bw / 2, ky, bw, kh * 0.6, function () { s.km = m4; s.chord = null; m4s4Sync(s); m4s4Play(s); });
  });
  label(ctx, s.chord !== null ? M4S3_CH[s.chord].nm + '（' + (s.tune === 'et' ? '平均律' : s.tune === 'just' ? '純正律' : '純正律と平均律を同時に') + '）' : (s.tune === 'just' ? '鍵盤を押すと純正律の音（黒鍵は平均律）' : s.tune === 'both' ? '鍵盤を押すと、純正律と平均律の音を同時に鳴らす（ずれがうなりになる）' : '鍵盤を押すと平均律の音'), W / 2, gy1 + 16, { size: 10.5, color: COL.sub, bold: s.chord !== null });
}
function rightM4S4(s, R) {
  var rows = M4_JUST.map(function (j) {
    var fe = MUS.fET(j[0]), fj = MUS.fET(60) * j[1] / j[2], c = Math.round(1200 * Math.log(fe / fj) / Math.LN2 * 10) / 10, on = s.km === j[0];
    var n = j[0] - 60, er = n === 0 ? '1' : (n === 12 ? '2' : '2^{' + n + '/12}');   /* 平均律の比：ドから半音 n 個上は 2^(n/12) 倍（純正律の比と同じくドから） */
    var bg = [64, 69, 71].indexOf(j[0]) >= 0 ? ' big' : '';   /* ミ・ラ・シは純正律から大きくずれる（色をつける。19 回目） */
    return '<tr' + (on ? ' class="on"' : '') + '><th>' + MUS.jp(j[0]) + '</th><td class="vl">' + sig(fj, 5) + '</td><td>$' + j[3] + '$</td><td class="vl' + bg + '">' + sig(fe, 5) + '</td><td class="' + bg.trim() + '">$' + er + '$</td><td class="vl' + bg + '">' + (c > 0 ? '+' : '') + c + '</td></tr>';
  }).join('');
  var h = '<div class="qcard"><p class="qt">純正律と平均律</p>' +
    '<p><b>純正律</b>：ドの振動数を 1 として、ほかの音を簡単な整数比（ミ $\\frac{5}{4}$、ソ $\\frac{3}{2}$ など）で決める。和音がよく調和するが、ほかの調に移ると比がくずれる。</p>' +
    '<p><b>平均律</b>：1 オクターブ上の音は振動数がちょうど 2 倍。これを 12 の半音に<b>等しい比</b>で分ける。半音 1 つで $2^{\\frac{1}{12}} \\fallingdotseq 1.0595$ 倍。基準はラ（A4）＝ 440 Hz で、A4 から半音 $n$ 個上の音は $f = 440 \\times 2^{\\frac{n}{12}}$ Hz（例：ド（C5）＝ $440 \\times 2^{\\frac{3}{12}} \\fallingdotseq 523.25$ Hz）。<br>表のように、ミ・ラ・シが純正律から大きくずれており、平均律の場合はこれらを含む和音（例えばド・ミ・ソの和音）でうなりが生じてしまう。ゆえに、「長 3 度の音（ドに対するミの音）は下げ気味で」歌う・演奏するのが、きれいな和音を響かせるコツとなる。</p>' +
    '<table class="reltab grid1 m4tune"><thead><tr><th>音名</th><th class="vl">純正律〔Hz〕</th><th>純正律の比</th><th class="vl">平均律〔Hz〕</th><th>平均律の比</th><th class="vl">ずれ〔セント〕</th></tr></thead><tbody>' + rows + '</tbody></table>' +
    '<p class="qnote">ドはどちらも 261.63 Hz とした。比はどちらもドの振動数に対する比。ずれ＝平均律が純正律より何セント高いか（1 セント＝半音の 1/100）。</p></div>';
  R.innerHTML = mathify(h);
}

/* =====================================================================
   ④-5 平均律と純正律を聞き比べよう（2026-11-06 千葉さん 12 回目に作り直し）
   伝えたいこと：
     ① 楽器の音には倍音がふくまれる（ドの 2 倍・3 倍 …）
     ② 長 3 度（ド・ミ）では、ドの 5 倍音とミの 4 倍音がほぼ同じ高さになる
        純正律（5/4）ならぴったり重なる → うならない／平均律（2^(4/12)）では 10 Hz ほどずれる → 1 秒に約 10 回うなる（音がゆれる）
     ③ 完全 5 度（ド・ソ）は、ドの 3 倍音とソの 2 倍音。平均律でもずれは 1 Hz 以下（ほとんど気にならない）
   図：左＝倍音のはしご（2 つの音の倍音の振動数をならべ、近いものを結ぶ）、右＝オシロスコープ（近い倍音どうしを重ねた 2 s 間）
   ===================================================================== */
var M4S5_IV = [
  { k: 'M3', nm: '長 3 度（ド・ミ）', m: [60, 64], just: [1, 5 / 4], et: [0, 4] },
  { k: 'P5', nm: '完全 5 度（ド・ソ）', m: [60, 67], just: [1, 3 / 2], et: [0, 7] },
  { k: 'MT', nm: '長 3 和音（ド・ミ・ソ）', m: [60, 64, 67], just: [1, 5 / 4, 3 / 2], et: [0, 4, 7] }
];
var M4S5_COL = ['#d1353f', '#1663b5', '#c9970c'];
function m4s5Q(s) {
  var iv = M4S5_IV[s.ii], fC = M4_C4;
  var f = s.tune === 'just' ? iv.just.map(function (r) { return fC * r; }) : iv.et.map(function (n) { return fC * Math.pow(2, n / 12); });
  return { iv: iv, f: f };
}
/* 近い倍音の組（6 倍音まで、差 30 Hz 未満） */
function m4s5Pairs(q) {
  var P = [];
  for (var a = 0; a < q.f.length; a++) for (var b = a + 1; b < q.f.length; b++)
    for (var i = 1; i <= 6; i++) for (var j = 1; j <= 6; j++) { var d = j * q.f[b] - i * q.f[a]; if (Math.abs(d) < 30 && i * q.f[a] < 2000) P.push({ a: a, b: b, i: i, j: j, fa: i * q.f[a], fb: j * q.f[b], d: Math.abs(d) }); }
  P.sort(function (x, y) { return x.fa - y.fa; });
  return P;
}
/* いちばん目立つ組（オシロスコープに出す）：長 3 度は 5 倍音と 4 倍音、完全 5 度は 3 倍音と 2 倍音 */
function m4s5Main(q, P) { var want = q.iv.k === 'P5' ? [3, 2] : [5, 4]; for (var k = 0; k < P.length; k++) if (P[k].a === 0 && P[k].i === want[0] && P[k].j === want[1]) return P[k]; return P[0]; }
DEFS.m4s5 = {
  id: 'm4s5', mode: 'mode4', num: 7,
  title: '純正律と平均律を聞き比べよう', short: '純正律・平均律聞き比べ',
  desc: '楽器の音には<b>倍音</b>がふくまれる。2 つの音の倍音どうしが少しだけずれると、<b>うなり</b>が生じて音がゆれる。<span class="todo">音程と調律を切りかえて聞き比べよう（切りかえると 4 秒鳴る）。</span>',
  strobe: false, stepDiv: 16,
  vars: [],
  init: function (s) { s.ii = 0; s.tune = 'just'; },
  onDefaults: function (s) { s.ii = 0; s.tune = 'just'; m4s5Sync(s); },
  onChanged: function () { return 'keepT'; },
  buttons: M4S5_IV.map(function (iv, i) { return { k: 'v' + i, label: iv.nm, seg: 'iv', segLabel: '音程', onClick: function (s) { s.ii = i; m4s5Sync(s); s.resound(); s.draw(); } }; })
    .concat([{ k: 'tj', label: '純正律', seg: 'tn', segLabel: '調律', onClick: function (s) { s.tune = 'just'; m4s5Sync(s); s.resound(); s.draw(); } },
             { k: 'te', label: '平均律', seg: 'tn', onClick: function (s) { s.tune = 'et'; m4s5Sync(s); s.resound(); s.draw(); } }]),
  tEnd: function () { return M4_TEND; },
  tInfo: function () { return ''; },
  gT: function () { return 1; },
  height: function (s, w) { return Math.round(clamp(w * 0.7, 360, 420)); },
  afterBuild: function (s) {
    s.R.innerHTML = '';
    s.scope = new Scope(s.R, 'オシロスコープ（近い倍音どうしを重ねた音・2 s 間）');
    s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);
    var segs = s.row1b.querySelectorAll('.seg');
    [['音程', 0], ['調律', 1]].forEach(function (p) { if (segs[p[1]]) { var lb = el('span', 'seglbl', p[0]); segs[p[1]].insertAdjacentElement('beforebegin', lb); lblSeg(lb, segs[p[1]]); } });
    s.resound = function () { var q = m4s5Q(s); m4Chord(s, q.f.map(function (f) { return { f: f, partials: M4_TIM.soft }; }), 4); };
    m4SndToggle(s, s.resound);
    m3TimeBar(s, false); m4NoPlay(s);
    /* アニメの下に五線譜と鍵盤（どの音を鳴らしているか。④-5 と同じ形。17 回目） */
    var cw2 = el('div', 'cvwrap m4s5kb'), cv2 = el('canvas'); cv2.setAttribute('aria-label', '鳴らしている音の五線譜と鍵盤'); cw2.appendChild(cv2); s.cw.insertAdjacentElement('afterend', cw2); s.kbCv = cv2;
    m4s5Sync(s);
  },
  draw: function (s, ctx, W, H) { drawM4S5(s, ctx, W, H); m4s5Scope(s); m4s5Keys(s); },
  right: function (s, R) { rightM4S5(s, R); }
};
function m4s5Sync(s) { m2Sync(s, M4S5_IV.map(function (iv, i) { return ['v' + i, s.ii === i]; }).concat([['tj', s.tune === 'just'], ['te', s.tune === 'et']])); if (s.Rdyn) s.renderRight(); }
/* 倍音のはしご：たて軸＝振動数。音ごとに 1 列、1〜6 倍音の横線。近い組は線で結んで「ずれ ○ Hz」 */
function drawM4S5(s, ctx, W, H) {
  var q = m4s5Q(s), P = m4s5Pairs(q), nar = W < 520, n = q.f.length;
  label(ctx, '倍音のはしご（' + (s.tune === 'just' ? '純正律' : '平均律') + '）', 8, 14, { size: 12, bold: true, color: COL.ink, align: 'left' });
  var y0 = 34, y1 = H - 40, FY = function (f) { return y1 - f / 2000 * (y1 - y0); };
  var cw = Math.min(nar ? 70 : 110, (W - 150) / n), cx0 = 56;
  axisArrow(ctx, 40, y1, 40, y0 - 6);
  [0, 500, 1000, 1500, 2000].forEach(function (f) { label(ctx, String(f), 36, FY(f), { size: 9.5, color: COL.sub, align: 'right' }); ctx.save(); ctx.strokeStyle = '#f0f1f3'; ctx.beginPath(); ctx.moveTo(42, FY(f)); ctx.lineTo(W - 8, FY(f)); ctx.stroke(); ctx.restore(); });
  label(ctx, 'Hz', 44, y0 - 10, { size: 10, color: COL.sub, align: 'left' });
  var colX = function (a) { return cx0 + a * (cw + 14); };
  q.f.forEach(function (f, a) {
    label(ctx, MUS.jp(q.iv.m[a]) + ' ' + sig(f, 4), colX(a) + cw / 2, y1 + 14, { size: 10.5, bold: true, color: M4S5_COL[a] });
    for (var k = 1; k * f < 2000; k++) {
      var y = FY(k * f);
      ctx.save(); ctx.strokeStyle = M4S5_COL[a]; ctx.lineWidth = k === 1 ? 3 : 2; ctx.globalAlpha = k === 1 ? 1 : 0.75; ctx.beginPath(); ctx.moveTo(colX(a), y); ctx.lineTo(colX(a) + cw, y); ctx.stroke(); ctx.restore();
      if (!nar || k <= 6) label(ctx, k === 1 ? '基音' : k + ' 倍', colX(a) + 4, y - 7, { size: 9, color: M4S5_COL[a], align: 'left' });
    }
  });
  /* 近い組を結ぶ（ぴったり＝緑、ずれ＝赤） */
  var tx = colX(n - 1) + cw + 16;
  P.forEach(function (p) {
    var ya = FY(p.fa), yb = FY(p.fb), ok = p.d < 0.05, col = ok ? '#14653a' : '#c0392b';
    ctx.save(); ctx.strokeStyle = col; ctx.lineWidth = 1.6; ctx.setLineDash(ok ? [] : [4, 3]);
    ctx.beginPath(); ctx.moveTo(colX(p.a) + cw, ya); ctx.lineTo(colX(p.b), yb); ctx.stroke(); ctx.restore();
    label(ctx, MUS.jp(q.iv.m[p.a]) + 'の' + p.i + '倍音と' + MUS.jp(q.iv.m[p.b]) + 'の' + p.j + '倍音：' + (ok ? 'ぴったり重なる' : sig(p.d, 2) + ' Hz ずれ → うなり ' + sig(p.d, 2) + ' 回/秒'), Math.min(tx, W - 8), (ya + yb) / 2, { size: nar ? 9.5 : 10.5, bold: true, color: col, align: tx > W - 160 ? 'right' : 'left' });
  });
  if (!P.length) label(ctx, '近い倍音どうしの組はない', W - 10, y0 + 10, { size: 11, color: COL.sub, align: 'right' });
}
/* 鳴らしている音：五線譜と鍵盤（④-5 の drawM4S3Row と同じ形） */
function m4s5Keys(s) {
  var cv = s.kbCv; if (!cv || !cv.offsetParent) return;
  var W = Math.max(240, Math.floor(cv.clientWidth || 300)), nar = W < 380, H = nar ? 256 : 158, key = [W, s.ii, s.tune].join('|');
  if (cv._k === key) return; cv._k = key;
  var ctx = prep(cv, W, H); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H);
  var q = m4s5Q(s), iv = q.iv, sp = nar ? 10 : 11, ncol = ['#d1353f', '#1663b5', '#c9970c'], kcol = ['#ffb3bf', '#a9cdfa', '#ffdf8a'];
  label(ctx, '鳴らしている音：' + iv.m.map(function (m) { return MUS.jp(m); }).join('・') + '（' + (s.tune === 'just' ? '純正律' : '平均律') + '）', 8, 12, { size: 12, bold: true, color: COL.ink, align: 'left' });
  var sw = nar ? W - 16 : Math.round(W * 0.36), yTop = 32 + 2 * sp, Y = staff(ctx, 8, 8 + sw, yTop, sp), cx = 8 + sw * 0.66;
  iv.m.forEach(function (m, i) { noteHead(ctx, cx, MUS.step(m), Y, sp, ncol[i], MUS.black(m)); });
  var kx = nar ? 8 : 8 + sw + 14, kw = W - kx - 8, ky = nar ? Y(-2) + 14 : yTop - 2 * sp + 4, kh = nar ? 84 : Math.round(Y(-2) - ky + 6);
  m4Keys(ctx, kx, ky, kw, kh, 60, 74, iv.m, kcol);
  var ty = Math.max(Y(-2), ky + kh) + 18;
  label(ctx, q.f.map(function (f, i) { return MUS.jp(iv.m[i]) + ' ' + sig(f, 5) + ' Hz'; }).join('、'), W / 2, ty, { size: nar ? 10.5 : 11.5, bold: true, color: COL.ink2 });
}
/* オシロスコープ：いちばん目立つ組の 2 つの倍音（各 1 段）と、それを重ねた波（2 s 間）。純正律では大きさが変わらない、平均律では大きくなったり小さくなったりする */
function m4s5Scope(s) {
  var sc = s.scope; if (!sc || !sc.cv.offsetParent) return;
  var q = m4s5Q(s), P = m4s5Pairs(q), p = m4s5Main(q, P), W = Math.max(240, Math.floor(sc.cv.clientWidth || 300)), lh = Math.round(clamp(W * 0.12, 42, 58));
  var key = [W, s.ii, s.tune].join('|'); if (sc._k === key) return; sc._k = key;
  var H = 3 * (15 + lh + 3) + 4, ctx = prep(sc.cv, W, H); ctx.clearRect(0, 0, W, H);
  if (!p) return;
  var d = p.fb - p.fa, span = 2, y = 0;
  var lanes = [
    { f: function (t) { return 0.8 * Math.sin(TAU * p.fa * t); }, col: '#ff9fa8', name: MUS.jp(q.iv.m[p.a]) + 'の ' + p.i + ' 倍音（' + sig(p.fa, 5) + ' Hz）' },
    { f: function (t) { return 0.8 * Math.sin(TAU * p.fb * t); }, col: '#9fc8ff', name: MUS.jp(q.iv.m[p.b]) + 'の ' + p.j + ' 倍音（' + sig(p.fb, 5) + ' Hz）' },
    { f: function (t) { return 0.4 * (Math.sin(TAU * p.fa * t) + Math.sin(TAU * p.fb * t)); }, col: '#7dffb4', name: '重ねた音：' + (p.d < 0.05 ? '大きさが変わらない（うならない）' : '大きさがゆれる（うなり ' + sig(p.d, 2) + ' 回/秒）'), env: function (t) { return 0.8 * Math.abs(Math.cos(Math.PI * d * t)); } }
  ];
  lanes.forEach(function (ln) { label(ctx, ln.name, 6, y + 7.5, { size: 10.5, bold: true, color: ln.col, align: 'left', halo: false }); sc.screen(ctx, 0, y + 15, W, lh, { t0: 0, span: span, yMax: 1, traces: [{ f: ln.f, col: ln.col, fmax: 2000 }], env: ln.env || null }); y += 15 + lh + 3; });
  var cap = '横 1 目盛り 0.2 s。' + (s.tune === 'just' ? '純正律では、2 つの倍音の振動数がぴったり同じなので、重ねても大きさが変わらない（すんだ響き）' : '平均律では、2 つの倍音の振動数が ' + sig(p.d, 2) + ' Hz ずれているので、1 秒に ' + sig(p.d, 2) + ' 回、大きくなったり小さくなったりする（音がゆれて聞こえる）');
  if (sc.cap._h !== cap) { sc.cap._h = cap; sc.cap.innerHTML = mathify(cap); }
}
function rightM4S5(s, R) {
  var h = '<div class="qcard"><p class="qt">聞き比べるポイント</p>' +
    '<p>① 楽器の音には、基音のほかに 2 倍・3 倍 … の<b>倍音</b>がふくまれる。</p>' +
    '<p>② ドとミ（長 3 度）を同時に鳴らすと、<b>ドの 5 倍音とミの 4 倍音</b>がほぼ同じ高さになる。純正律（ミ＝ドの $\\frac{5}{4}$ 倍）なら $5 \\times f_ド = 4 \\times f_ミ$ でぴったり重なり、うならない。平均律（ミ＝ドの $2^{\\frac{4}{12}} \\fallingdotseq 1.260$ 倍）では約 10 Hz ずれるので、<b>1 秒に約 10 回うなる</b>（音が細かくゆれる）。</p>' +
    '<p>③ ドとソ（完全 5 度）では、ドの 3 倍音とソの 2 倍音。平均律でもずれは 1 Hz 以下なので、ほとんど気にならない。</p>' +
    '<table class="reltab grid1"><thead><tr><th>音程</th><th>純正律</th><th>平均律</th></tr></thead><tbody>' +
    '<tr><th>長 3 度</th><td>$\\frac{5}{4} = 1.250$</td><td>$2^{\\frac{4}{12}} \\fallingdotseq 1.260$</td></tr>' +
    '<tr><th>完全 5 度</th><td>$\\frac{3}{2} = 1.500$</td><td>$2^{\\frac{7}{12}} \\fallingdotseq 1.498$</td></tr></tbody></table>' +
    '<p class="qnote">うなりは、内蔵スピーカーでは聞き取りにくいことがある。イヤホンで聞くとよくわかる。</p></div>';
  R.innerHTML = mathify(h);
}
