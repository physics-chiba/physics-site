/* =====================================================================
   ④-10 さらに勉強したい人のためのページと参考サイト（38 回目。⑤-5 と同じ作り。custom・文だけ）
   ・リンク先は 2026-11-22 に開いて、内容を確かめたもの。外部のサイトなので、ページを開いたときには読みこまない（リンクだけ）
   ===================================================================== */
DEFS.m4ref = {
  id: 'm4ref', mode: 'mode4', num: 10, custom: true,
  title: 'さらに勉強したい人のためのページと参考サイト', short: '勉強したい人へ・参考サイト',
  html: function () {
    var li = function (t, d) { return '<li><b>' + t + '</b>：' + d + '</li>'; };
    var a = function (u, t, d) { return '<li><a href="' + u + '" target="_blank" rel="noopener">' + t + '</a>：' + d + '</li>'; };
    return '<div class="secdesc">モード ④ で見たことを、さらに詳しく知るためのページ。<span class="todo">気になったテーマから調べてみよう。</span></div>' +
      '<div class="m5ideas"><ul>' +
      li('音色の違いはどこから？（④-1）', '同じ高さでも楽器や声で音色が違うのは、倍音の混ざり方と、音の大きさの時間変化（立ち上がり方・減り方）が違うから。スマートフォンのスペクトル表示アプリで、自分の声や身近な楽器を見てみよう。') +
      li('本物の楽器の倍音（④-2）', 'ピアノの弦は硬いので、高い成分ほど整数倍より少し高くなる。そのためピアノの調律では、高い音を少し高めに合わせることが多い。鉄琴の板は、弦とは違う式で振動する。') +
      li('声の振動体と定在波（④-3）', '音のもとは声帯（振動体）、音色を決めるのは声道（声帯〜くちびる）の共鳴。音の高さは声帯、母音は口の形で、別々に変えられる。ささやき声では声帯は振動せず、息の乱れ（雑音）が声道を共鳴させる。') +
      li('歌う人の工夫（④-3）', 'オペラ歌手は約 3 kHz の共鳴（歌手のフォルマント）で声を遠くまで届かせる。ソプラノは高い音で口の開け方を変え、声道の共鳴を歌う音の高さに合わせることがある。合唱では、まわりと溶け合う声（ビブラートが小さく、母音の形をそろえる）が大切。') +
      li('のどを大切に', '声帯は使いすぎると腫れて、声がかすれる（声がれ）。のどが痛いときやかすれているときは、無理に大きな声を出さない。') +
      li('長さと音の高さ・音律（④-4〜④-9）', '弦・管・板の長さと振動数の関係、和音がきれいに聞こえる振動数の比、純正律と平均律の違いを、身近な楽器で確かめてみよう。') +
      '</ul></div>' +
      '<div class="m5refs"><p class="m5rt">参考サイト：声・歌声（④-3）</p><ul>' +
      a('https://newt.phys.unsw.edu.au/jw/voice.html', 'Voice Acoustics: an introduction to the science of speech and singing（ニューサウスウェールズ大学、英語）', '声帯（音のもと）と声道（共鳴）、フォルマント、声区、歌手のフォルマントまで、図と音つきで説明') +
      a('https://newt.phys.unsw.edu.au/jw/glottis-vocal-tract-voice.html', 'Glottal signal, vocal tract resonances and output sound（同、英語）', '声帯の音・声道の共鳴・口から出る声を並べて比べる。ささやき声の例もある') +
      a('https://www.phys.unsw.edu.au/jw/reprints/whisper.pdf', 'Swerdlin, Smith, Wolfe「The effect of whisper and creak vocal mechanisms on vocal tract resonances」（論文 PDF、英語）', 'ささやき声では声帯側が少し開いているので、声道の共鳴が高くなる（④-3 のウィスパーボイスのもと）') +
      a('https://newt.phys.unsw.edu.au/jw/soprane.html', 'Vocal resonance tuning and vowel changes, especially for sopranos（ニューサウスウェールズ大学、英語）', 'ソプラノが高い音で、声道の共鳴を歌う音の高さに合わせるしくみ') +
      a('https://ir.lib.shimane-u.ac.jp/6846/files/10187', '佐々木直樹「合唱指導における発声練習に関する研究（1）―ヴァルター・シュナイダーの発声練習の理論と方法（呼吸と共鳴）―」（島根大学教育学部紀要 第 42 巻、2008、PDF）', '合唱の発声練習の考え方。呼吸の支え方や、共鳴（頭声・軟口蓋など）の練習') +
      '</ul><p class="m5rt">参考サイト：非整数次倍音・楽器のしくみ（④-2・④-4・④-5）</p><ul>' +
      a('https://www.acs.psu.edu/drussell/Demos/Stiffness-Inharmonicity/Stiffness-B.html', 'D. A. Russell「Inharmonicity due to Stiffness for Guitar Strings」（ペンシルベニア州立大学、英語）', '硬い弦の振動数 fₙ = n f₁ √(1 + B n²)（④-2 の式）の説明') +
      a('https://www.acs.psu.edu/drussell/Demos/Flexural-Bar/flexural.html', 'D. A. Russell「Flexural Vibration of a Rectangular Bar」（同、英語）', '板（棒）の曲げ振動のアニメーションと振動数。鉄琴の板の振動数が整数倍にならないことが分かる') +
      a('https://www.yamaha.com/ja/musical_instrument_guide/piano/mechanism/mechanism004.html', 'ヤマハ 楽器解体全書「ピアノのしくみ：音を豊かにする弦の工夫」', '弦の太さ・長さ・本数と、響きを豊かにする工夫') +
      a('https://www.yamaha.com/ja/musical_instrument_guide/acoustic_guitar/mechanism/', 'ヤマハ 楽器解体全書「アコースティックギター：音が鳴るしくみは？」', '弦の振動が胴に伝わって大きな音になるしくみ。サウンドホールや表板の実験もある') +
      a('https://newt.phys.unsw.edu.au/~jw/guitarintro.html', 'How does a guitar work?（ニューサウスウェールズ大学、英語）', '弦・胴・サウンドホールの共鳴') +
      a('https://www.yamaha.com/ja/musical_instrument_guide/piano/', 'ヤマハ 楽器解体全書「ピアノ」', 'ピアノのしくみ全体（音が出るしくみ、アクション、実験）') +
      '</ul><p class="m5note">外部のサイトです（内容は各サイトのもの）。英語のページは、ブラウザの翻訳機能を使うと読みやすい。</p></div>';
  },
  build: function (art) { }
};
