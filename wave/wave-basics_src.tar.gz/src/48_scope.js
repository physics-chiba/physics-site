/* ===== 48_scope.js ===== */
/* =========================================================================
   オシロスコープの絵（本当の測定はしない。y-t グラフを描くだけ）
   ・暗い画面・方眼（横 10 目盛り × 縦 8 目盛り）・光る線・つまみの飾り
   ・「グラフは白い面」の例外（装置の絵だから）
   ・線は式から描く。高い振動数でも 1 画素に 4 点以上とる（それでも細かすぎる所は、画素ごとの最大・最小で塗る）
   ========================================================================= */
'use strict';
function Scope(host, title) {
  var box = el('div', 'scope'), hd = el('div', 'scopehd');
  hd.appendChild(el('span', 'scopet', title || 'オシロスコープ'));
  var kn = el('span', 'scopekn', '<i></i><i></i><i></i>'); kn.setAttribute('aria-hidden', 'true'); hd.appendChild(kn);
  this.cv = el('canvas', 'scopecv'); box.appendChild(hd); box.appendChild(this.cv);
  this.cap = el('div', 'scopecap', ''); box.appendChild(this.cap);
  host.appendChild(box); this.box = box;
}
/* 画面 1 枚：(x, y, w, h) の中に、t0〜t0 + span の y(t) を描く。o：{ span, t0, traces:[{ f, col, lw, alpha }], yMax, env, cursor, label, labelR, divT } */
Scope.prototype.screen = function (ctx, x, y, w, h, o) {
  ctx.save();
  ctx.fillStyle = '#0d1a14'; rrect(ctx, x, y, w, h, 6); ctx.fill();
  ctx.beginPath(); rrect(ctx, x, y, w, h, 6); ctx.clip();
  /* 方眼 */
  ctx.strokeStyle = 'rgba(120,220,170,.13)'; ctx.lineWidth = 1;
  for (var i = 1; i < 10; i++) { var gx = Math.round(x + w * i / 10) + 0.5; ctx.beginPath(); ctx.moveTo(gx, y); ctx.lineTo(gx, y + h); ctx.stroke(); }
  for (var j = 1; j < 8; j++) { var gy = Math.round(y + h * j / 8) + 0.5; ctx.beginPath(); ctx.moveTo(x, gy); ctx.lineTo(x + w, gy); ctx.stroke(); }
  ctx.strokeStyle = 'rgba(120,220,170,.32)'; ctx.beginPath(); ctx.moveTo(x, y + h / 2 + 0.5); ctx.lineTo(x + w, y + h / 2 + 0.5); ctx.moveTo(x + w / 2 + 0.5, y); ctx.lineTo(x + w / 2 + 0.5, y + h); ctx.stroke();
  var yM = o.yMax || 1, Y = function (v) { return y + h / 2 - v / yM * (h * 0.42); };
  /* 包絡線（点線） */
  if (o.env) {
    ctx.strokeStyle = 'rgba(255,214,120,.75)'; ctx.lineWidth = 1.2; ctx.setLineDash([4, 4]);
    [1, -1].forEach(function (sg) { ctx.beginPath(); for (var p = 0; p <= w; p += 2) { var t = o.t0 + o.span * p / w, v = sg * o.env(t); if (p) ctx.lineTo(x + p, Y(v)); else ctx.moveTo(x + p, Y(v)); } ctx.stroke(); });
    ctx.setLineDash([]);
  }
  (o.traces || []).forEach(function (tr) {
    ctx.save(); ctx.globalAlpha = tr.alpha || 1; ctx.strokeStyle = tr.col || '#7dffb4'; ctx.lineWidth = tr.lw || 1.8;
    ctx.shadowColor = tr.col || '#7dffb4'; ctx.shadowBlur = tr.glow === false ? 0 : 6;
    var per = o.span * (tr.fmax || 0) / w;                              /* 1 画素あたりの周期の数 */
    if (per > 0.6) {
      /* 細かすぎる：画素ごとの最大・最小で塗る */
      ctx.fillStyle = ctx.strokeStyle; ctx.globalAlpha = (tr.alpha || 1) * 0.85;
      for (var p2 = 0; p2 < w; p2++) {
        var lo = 1e9, hi = -1e9;
        for (var k = 0; k <= 24; k++) { var tt = o.t0 + o.span * (p2 + k / 24) / w, vv = tr.f(tt); if (vv < lo) lo = vv; if (vv > hi) hi = vv; }
        ctx.fillRect(x + p2, Y(hi), 1, Math.max(1, Y(lo) - Y(hi)));
      }
    } else {
      var N = Math.max(400, Math.ceil(w * 4));
      ctx.beginPath();
      for (var n = 0; n <= N; n++) { var t2 = o.t0 + o.span * n / N, v2 = tr.f(t2); if (n) ctx.lineTo(x + w * n / N, Y(v2)); else ctx.moveTo(x + w * n / N, Y(v2)); }
      ctx.stroke();
    }
    ctx.restore();
  });
  if (o.cursor !== undefined) { var cx = x + (o.cursor - o.t0) / o.span * w; ctx.strokeStyle = 'rgba(255,214,120,.9)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(cx, y); ctx.lineTo(cx, y + h); ctx.stroke(); }
  if (o.mark) { ctx.fillStyle = 'rgba(255,214,120,.16)'; var mx0 = x + (o.mark[0] - o.t0) / o.span * w, mx1 = x + (o.mark[1] - o.t0) / o.span * w; ctx.fillRect(mx0, y, Math.max(2, mx1 - mx0), h); }
  ctx.restore();
  ctx.save(); ctx.font = '600 10.5px ' + FONT; ctx.fillStyle = 'rgba(190,240,215,.85)'; ctx.textBaseline = 'top';
  if (o.label) ctx.fillText(o.label, x + 6, y + 5);
  if (o.labelR) { ctx.textAlign = 'right'; ctx.fillText(o.labelR, x + w - 6, y + 5); }
  ctx.restore();
};
/* 1 目盛りの時間の書き方 */
function divTxt(s) { if (s >= 1) return sig(s, 2) + ' s'; if (s >= 1e-3) return sig(s * 1000, 2) + ' ms'; return sig(s * 1e6, 2) + ' μs'; }
