/* ===== 62_m2s4.js ===== */
/* =====================================================================
   ②-4 共振の例（2026-11-08 千葉さん 19 回目に新しく作った）
   上の段：振り子 A〜F（糸の長さがちがう）。張った糸の両端を手で持って、左右に振動させる（振動数 f のスライダー）
     ・支点（張った糸）の変位 X(t) = X₀ sin 2πft。振り子の角度 θ：θ'' = −(g/L)θ − γθ' − Ẍ/L （Ẍ = −(2πf)² X₀ sin 2πft）
     ・固有振動数 f₀ = (1/2π)√(g/L) が f に近い振り子だけが大きくゆれる（共振）
     ・数値計算（4 次のルンゲ・クッタ、刻み 1/600 s）。最初は全部止まっている → だんだんゆれが育つ
   下の段：おんさの共鳴（共鳴箱つきのおんさ 440 Hz と、振動数を変えられるもう 1 つのおんさ）
     ・たたいたおんさの音（振動数 f）が空気を伝わり、440 Hz のおんさをゆらす。ゆれの大きさ（定常）R = 1/√(1 + (2Q(f − 440)/440)²)、Q = 200
     ・育つ・おさまる速さは時定数 τ = Q/(π·440) ≒ 0.14 s（実際のおんさの Q はもっと大きく、もっとせまい範囲でしか共鳴しない）
     ・「たたいたおんさを手でおさえる」と、たたいた方は止まるが、共鳴した 440 Hz のおんさは鳴り続ける（教科書の実験）
     ・おんさの振動（440 Hz）は速すぎて見えないので、図では「ゆれの大きさ」をおんさの先の広がりで表す
   ===================================================================== */
'use strict';
var M2S4 = {
  g: 9.8, X0: 0.01, gam: 0.25,
  P: [['A', 0.20], ['B', 0.47], ['C', 0.74], ['D', 0.24], ['E', 0.47], ['F', 0.70]],   /* 写真の振り子 A〜F の長さ〔m〕（およそ） */
  fork: 440, Q: 200, TMAX: 60   /* 時間バーの最大（22 回目。60 s で止まる） */
};
function m2s4F0(L) { return Math.sqrt(M2S4.g / L) / TAU; }
function m2s4Reset(s) { m2s4ResetP(s); m2s4ResetF(s); }
function m2s4ResetP(s) { s.pd = M2S4.P.map(function () { return { th: 0, w: 0 }; }); s.tp = 0; s.stg = s.stg || [{}, {}]; s.stg[0] = { on: false, slow: false, t: 0 }; }
function m2s4ResetF(s) { s.fk = { aL: 0, aR: 0, hit: false, mute: false }; s.stg = s.stg || [{}, {}]; s.stg[1] = { on: false, slow: false, t: 0 }; }
DEFS.m2s4 = {
  id: 'm2s4', mode: 'mode2', num: 4,
  title: '共振の例', short: '共振の例',
  desc: '物体には、揺れやすい振動数（<b>固有振動数</b>）がある。外から与える振動の振動数が固有振動数に近いと、揺れがだんだん大きくなる。これを<b>共振</b>（音では<b>共鳴</b>）という。<span class="todo">与える振動の振動数を変えて、どれが大きく揺れるか見よう。</span>',
  strobe: false, stepDiv: 16,
  vars: [
    { k: 'fp', label: '手で揺らす振動数 $f$', aria: '手で揺らす振動数', min: 0.40, max: 1.30, step: 0.01, def: 0.73, fmt: function (x) { return x.toFixed(2) + ' Hz'; } },
    { k: 'ff', label: 'たたくおんさの振動数 $f$', aria: 'たたくおんさの振動数', min: 400, max: 480, step: 1, def: 440, fmt: function (x) { return Math.round(x) + ' Hz'; } }
  ],
  init: function (s) { m2s4Reset(s); },
  onDefaults: function (s) { m2s4Reset(s); s._stgSync && s._stgSync(); AUDIO.owner() === 'm2s4' && AUDIO.stop(); m2s4Btns(s); s.drvP && (s.drvP.sync(), s.drvF.sync()); },
  onChanged: function (s, k) { if (s.fk && s.fk.hit && !s.fk.mute) m2s4Sound(s); m2s4Btns(s); return 'keepT'; },
  buttons: [],
  tEnd: function () { return 1e6; },
  tInfo: function () { return ''; },
  gT: function () { return 1; },
  height: function (s, w) { return w < 560 ? 300 : Math.round(clamp(w * 0.42, 290, 340)); },
  afterBuild: function (s) {
    document.getElementById('m2s4').classList.add('wide1');
    var box = el('div', 'brows m2s4rows'); s.cw.insertAdjacentElement('beforebegin', box);
    s.bRows = [['(1) 振り子の共振：張った糸の両端を手で持って、左右に揺らす', 0], ['(2) おんさの共鳴：共鳴箱の口を向かい合わせて、一方をたたく', 1]].map(function (p) {
      var row = el('div', 'brow'), hd = el('p', 'browh', p[0]), lc = el('div', 'browl'), rc = el('div', 'browr');
      row.appendChild(hd); row.appendChild(lc); row.appendChild(rc); box.appendChild(row);
      return { row: row, L: lc, R: rc };
    });
    /* 段ごとの操作（図の左上。22 回目）。上のふつうの ▶ スタート・時間バーはかくす */
    var pbar0 = s.L.querySelector('.ctrls .playbar'); if (pbar0) pbar0.style.display = 'none';
    var bz = el('button', 'b m2s4zero', '全ての振り子を一度止める'); bz.type = 'button';
    bz.addEventListener('click', function () { s.pd.forEach(function (p) { p.th = 0; p.w = 0; }); s.draw(); });
    s.ctl = [m2s4Ctl(s, 0, s.bRows[0].L, bz), m2s4Ctl(s, 1, s.bRows[1].L)];
    s._stgSync = function (light) {
      s.stg.forEach(function (st, i) {
        var c = s.ctl[i], tx = st.on ? '❚❚ 一時停止' : (st.end ? '▶ 最初から' : '▶ スタート');
        if (c.bp.textContent !== tx) c.bp.textContent = tx;
        c.bs.classList.toggle('on', !!st.slow);
        c.rg.value = String(st.t); c.rg.style.setProperty('--p', (st.t / M2S4.TMAX * 100).toFixed(2) + '%');
        var tv = fmt(st.t, 1) + ' s'; if (c.tv.textContent !== tv) c.tv.textContent = tv;
      });
    };
    /* ほかの節が動き出して playing = false にされたら、両方の段を止める */
    s.syncPlayLabel = function () { if (!s.playing && s.stg) { s.stg[0].on = false; s.stg[1].on = false; } Sim.prototype.syncPlayLabel.call(s); if (s._stgSync) s._stgSync(); };
    s.bRows[0].L.appendChild(s.cw);
    var cw2 = el('div', 'cvwrap'), cv2 = el('canvas'); cw2.appendChild(cv2); s.bRows[1].L.appendChild(cw2); s.cv2 = cv2;
    /* 振動数の操作：②-3 の振動子と同じ「札＋スライダー」一体の形（2026-11-08 千葉さん 20 回目） */
    s.varbox.style.display = 'none';
    var chP = [], seen = {};
    M2S4.P.forEach(function (p) { var f = Math.round(m2s4F0(p[1]) * 100) / 100; if (seen[f]) { seen[f][0] += '・' + p[0]; return; } seen[f] = [p[0], f]; chP.push(seen[f]); });
    s.drvP = m2s4Drv(s, s.bRows[0].R, 'fp', 0.40, 1.30, 0.01, chP, function (v) { return '手で揺らす振動数　<b>' + v.toFixed(2) + ' Hz</b>'; });
    s.drvF = m2s4Drv(s, s.bRows[1].R, 'ff', 400, 480, 1, [['', 400], ['', 420], ['', 440], ['', 460], ['', 480]], function (v) { return 'たたくおんさの振動数　<b>' + Math.round(v) + ' Hz</b>'; });
    s.info1 = el('div', 'm2s4info'); s.bRows[0].R.appendChild(s.info1);
    /* おんさのボタン */
    var bb = el('div', 'm2s4btns');
    s.bHit = el('button', 'b glow', '🔨 おんさをたたく（音が鳴る）'); s.bHit.type = 'button';
    s.bMute = el('button', 'b', '✋ たたいたおんさを手で押さえる'); s.bMute.type = 'button';
    s.bStop = el('button', 'b', '■ 音を止める'); s.bStop.type = 'button';
    s.bHit.addEventListener('click', function () { s.fk.hit = true; s.fk.mute = false; s.fk.aL = 1; m2s4Sound(s); if (!s.stg[1].on) m2s4Go(s, 1, true); m2s4Btns(s); });
    s.bMute.addEventListener('click', function () { if (!s.fk.hit) return; s.fk.mute = true; m2s4Sound(s); m2s4Btns(s); });
    s.bStop.addEventListener('click', function () { s.fk.hit = false; s.fk.mute = false; s.fk.aL = 0; s.fk.aR = 0; AUDIO.owner() === 'm2s4' && AUDIO.stop(); m2s4Btns(s); s.draw(); });
    bb.appendChild(s.bHit); bb.appendChild(s.bMute); bb.appendChild(s.bStop); s.bRows[1].R.appendChild(bb);
    s.info2 = el('div', 'm2s4info'); s.bRows[1].R.appendChild(s.info2);
    AUDIO.onChange(function (o) { if (o !== 'm2s4' && s.fk && (s.fk.hit)) { s.fk.hit = false; s.fk.mute = false; s.fk.aL = 0; m2s4Btns(s); } });
    s.Rdyn = el('div', 'rdyn brcard'); box.insertAdjacentElement('afterend', s.Rdyn); s.R.innerHTML = '';
    m2s4Btns(s);
  },
  beforeStep: function (s, t0, t1) {
    /* 上の段・下の段は、それぞれの ▶ スタート・スロー・時間で進める（22 回目） */
    var raw = (t1 - t0) / s.rate;
    [0, 1].forEach(function (i) {
      var st = s.stg[i]; if (!st.on) return;
      var d = Math.min(raw * (st.slow ? 0.3 : 1), M2S4.TMAX - st.t);
      if (d > 0) { if (i) m2s4StepF(s, d); else m2s4StepP(s, d); st.t += d; }
      if (st.t >= M2S4.TMAX - 1e-9) { st.t = M2S4.TMAX; st.on = false; st.end = true; }
    });
    s.playing = s.stg[0].on || s.stg[1].on;
    if (!s.playing) { s._stgSync(); }
  },
  draw: function (s, ctx, W, H) {
    drawM2S4P(s, ctx, W, H);
    if (s.cv2 && s.cv2.offsetParent) { var w2 = Math.max(260, Math.floor(s.cv2.clientWidth || 300)), h2 = w2 < 560 ? 250 : 260, c2 = prep(s.cv2, w2, h2); c2.fillStyle = '#fff'; c2.fillRect(0, 0, w2, h2); drawM2S4F(s, c2, w2, h2); }
    m2s4Info(s); if (s._stgSync) s._stgSync(true);
  },
  right: function (s, R) { rightM2S4(s, R); }
};
/* 振り子：4 次のルンゲ・クッタ（刻み 1/600 s） */
function m2s4StepP(s, dt) {
  var t0 = 0, t1 = dt;
  {
    var w = TAU * s.v.fp, X0 = M2S4.X0, g = M2S4.g, gm = M2S4.gam, n = Math.max(1, Math.ceil((t1 - t0) * 600)), h = (t1 - t0) / n;
    s.pd.forEach(function (p, i) {
      var L = M2S4.P[i][1], acc = function (t, th, om) { return -(g / L) * th - gm * om + (X0 * w * w / L) * Math.sin(w * t); };
      for (var k = 0; k < n; k++) {
        var t = s.tp + k * h;
        var k1t = p.w, k1w = acc(t, p.th, p.w);
        var k2t = p.w + h / 2 * k1w, k2w = acc(t + h / 2, p.th + h / 2 * k1t, p.w + h / 2 * k1w);
        var k3t = p.w + h / 2 * k2w, k3w = acc(t + h / 2, p.th + h / 2 * k2t, p.w + h / 2 * k2w);
        var k4t = p.w + h * k3w, k4w = acc(t + h, p.th + h * k3t, p.w + h * k3w);
        p.th += h / 6 * (k1t + 2 * k2t + 2 * k3t + k4t); p.w += h / 6 * (k1w + 2 * k2w + 2 * k3w + k4w);
      }
    });
    s.tp += t1 - t0;
  }
}
/* おんさ：たたいた方は 8 s の時定数で弱まる（おさえたらすぐ 0）。440 Hz の方は R·aL に時定数 τ で近づく */
function m2s4StepF(s, dt) {
  var fk = s.fk, tau = M2S4.Q / (Math.PI * M2S4.fork);
  if (fk.hit) { fk.aL = fk.mute ? 0 : fk.aL * Math.exp(-dt / 8); var R = m2s4R(s), tgt = R * fk.aL; fk.aR += (tgt - fk.aR) * (1 - Math.exp(-dt / (fk.mute ? 8 : tau))); }
}
/* 段ごとの ▶ スタート・🐢 スロー・↺ リセット・時間バー（図の左上。22 回目）。時間バーは見るだけ（0〜60 s） */
function m2s4Ctl(s, i, host, extra) {
  var c = el('div', 'ctrls m2s4ctl'), pb = el('div', 'playbar'), r1 = el('div', 'row1'), bt = el('div', 'btns'), tr = el('div', 'trow'), tb = el('div', 'tbox m2s4tb');
  var bp = el('button', 'b play', '▶ スタート'), bs = el('button', 'b', '🐢 スロー'), br = el('button', 'b gapL', '↺ リセット');
  [bp, bs, br].forEach(function (b) { b.type = 'button'; bt.appendChild(b); });
  var rg = el('input'); rg.type = 'range'; rg.min = '0'; rg.max = String(M2S4.TMAX); rg.step = '0.01'; rg.value = '0'; rg.disabled = true; rg.tabIndex = -1; rg.setAttribute('aria-label', '時間');
  var tv = el('span', 'vv', '0.0 s');
  tb.appendChild(el('span', 'vl', '時間 ' + tex('t'))); tb.appendChild(rg); tb.appendChild(tv); tr.appendChild(tb);
  r1.appendChild(bt); pb.appendChild(r1); pb.appendChild(tr); c.appendChild(pb);
  if (extra) c.appendChild(extra);
  host.appendChild(c);
  bp.addEventListener('click', function () { m2s4Go(s, i, !s.stg[i].on); });
  bs.addEventListener('click', function () { s.stg[i].slow = !s.stg[i].slow; s._stgSync(); });
  br.addEventListener('click', function () {
    if (i) { m2s4ResetF(s); if (AUDIO.owner() === 'm2s4') AUDIO.stop(); m2s4Btns(s); } else m2s4ResetP(s);
    s.playing = s.stg[0].on || s.stg[1].on; s.draw();
  });
  return { bp: bp, bs: bs, rg: rg, tv: tv };
}
function m2s4Go(s, i, on) {
  var st = s.stg[i];
  if (on) {
    if (st.end) { if (i) { m2s4ResetF(s); m2s4Btns(s); } else m2s4ResetP(s); st = s.stg[i]; }   /* 60 s で止まっていたら最初から */
    SIMS.forEach(function (o) { if (o !== s && o.playing) { o.playing = false; o.syncPlayLabel(); } });
    st.on = true; s.playing = true; s._stgSync(); startLoop();
  } else { st.on = false; s.playing = s.stg[0].on || s.stg[1].on; s._stgSync(); }
}
function m2s4R(s) { var x = 2 * M2S4.Q * (s.v.ff - M2S4.fork) / M2S4.fork; return 1 / Math.sqrt(1 + x * x); }
function m2s4Sound(s) {
  var fk = s.fk, R = m2s4R(s), v = [];
  if (!fk.mute) v.push({ f: s.v.ff, amp: 1 });
  if (R > 0.05) v.push({ f: M2S4.fork, amp: fk.mute ? Math.max(0.05, fk.aR) : R });
  if (!v.length) { AUDIO.owner() === 'm2s4' && AUDIO.stop(); return; }
  AUDIO.play('m2s4', v, 0.8);
}
function m2s4Btns(s) {
  if (!s.bHit) return;
  var on = s.fk.hit;
  s.bHit.classList.toggle('glow', !on); s.bMute.disabled = !on || s.fk.mute; s.bStop.disabled = !on;
}
/* 上の段：振り子 A〜F */
function drawM2S4P(s, ctx, W, H) {
  var nar = W < 560, w = TAU * s.v.fp, X = M2S4.X0 * Math.sin(w * s.tp), sc = (H - 120) / 0.8;   /* 1 m → sc px */
  var x0 = nar ? 44 : 70, x1 = W - (nar ? 44 : 70), yT = 52, sag = 14, Xp = X * sc * 3;            /* 手と糸の動きは 3 倍に拡大して描く */
  var yS = function (x) { var u = (x - x0) / (x1 - x0); return yT + 4 * sag * u * (1 - u); };
  /* 張った糸と手 */
  ctx.save(); ctx.strokeStyle = '#5b6570'; ctx.lineWidth = 1.6; ctx.beginPath();
  for (var i = 0; i <= 60; i++) { var x = x0 + (x1 - x0) * i / 60; ctx.lineTo(x + Xp, yS(x)); } ctx.stroke(); ctx.restore();
  [x0, x1].forEach(function (xh, k) { m2s4Hand(ctx, xh + Xp, yT, k ? 1 : -1, nar ? 0.8 : 1); });
  label(ctx, '手で左右に揺らす　f = ' + s.v.fp.toFixed(2) + ' Hz', W / 2, 14, { size: nar ? 11 : 12.5, bold: true, color: '#c9670c' });
  /* 振り子 */
  M2S4.P.forEach(function (p, i) {
    var xs = x0 + (x1 - x0) * (i + 0.5) / 6, ys = yS(xs), L = p[1] * sc, th = s.pd[i].th, bx = xs + Xp + L * Math.sin(th), by = ys + L * Math.cos(th);
    var f0 = m2s4F0(p[1]), near = Math.abs(f0 - s.v.fp) < 0.03, big = Math.abs(th) * p[1] > 0.025;
    ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(xs + Xp, ys); ctx.lineTo(bx, by); ctx.stroke();
    var gr = ctx.createRadialGradient(bx - 3, by - 3, 1, bx, by, 9); gr.addColorStop(0, '#fff'); gr.addColorStop(1, big ? '#e07b18' : '#9aa3ad');
    ctx.fillStyle = gr; ctx.strokeStyle = big ? '#c9670c' : '#5b6570'; ctx.beginPath(); ctx.arc(bx, by, nar ? 7 : 9, 0, TAU); ctx.fill(); ctx.stroke(); ctx.restore();
    label(ctx, p[0], xs, ys + L + (nar ? 22 : 26), { size: nar ? 13 : 16, bold: true, color: big ? '#c9670c' : COL.ink });
    label(ctx, sig(f0, 3) + ' Hz', xs, ys + L + (nar ? 37 : 43), { size: nar ? 9 : 10.5, color: COL.sub });
    if (big) label(ctx, '共振', xs + (nar ? 18 : 24), ys + L + (nar ? 22 : 26), { size: nar ? 10 : 11.5, bold: true, color: '#c9670c' });
  });
  label(ctx, '数字：振り子の固有振動数　f₀ = (1/2π)√(g/L)', 8, H - 8, { size: nar ? 9.5 : 10.5, color: COL.sub, align: 'left' });
}
/* 手（糸の端を持つ）。dir：−1 左の手、1 右の手 */
function m2s4Hand(ctx, x, y, dir, k) {
  ctx.save(); ctx.translate(x, y); ctx.scale(dir * k, k);
  ctx.fillStyle = '#f6d9bb'; ctx.strokeStyle = '#8a5a3a'; ctx.lineWidth = 1.3;
  ctx.beginPath(); ctx.moveTo(-2, -9); ctx.quadraticCurveTo(10, -12, 20, -8); ctx.lineTo(34, -6); ctx.lineTo(34, 8); ctx.lineTo(20, 9); ctx.quadraticCurveTo(6, 13, -2, 8); ctx.quadraticCurveTo(-8, 0, -2, -9); ctx.closePath(); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(2, -3); ctx.lineTo(14, -3); ctx.moveTo(2, 3); ctx.lineTo(14, 3); ctx.stroke();
  ctx.fillStyle = '#1f2f4a'; ctx.fillRect(34, -9, 12, 18);   /* そで */
  ctx.restore();
}
/* 下の段：おんさの共鳴 */
function drawM2S4F(s, ctx, W, H) {
  var nar = W < 560, fk = s.fk, R = m2s4R(s), bw = nar ? 100 : 150, bh = nar ? 40 : 50, yb = H - bh - 34;
  var xL = nar ? 10 : 30, xR = W - (nar ? 10 : 30) - bw;
  /* 床 */
  ctx.save(); ctx.fillStyle = '#c9b48a'; ctx.fillRect(0, yb + bh, W, 8); ctx.restore();
  [[xL, true, s.v.ff, fk.aL, 'たたくおんさ'], [xR, false, M2S4.fork, fk.aR, 'おんさ（440 Hz）']].forEach(function (q) {
    var x = q[0], left = q[1], a = q[3];
    /* 共鳴箱（口は相手の方） */
    ctx.save(); ctx.fillStyle = '#d9a35a'; ctx.strokeStyle = '#8a5a2b'; ctx.lineWidth = 2; ctx.fillRect(x, yb, bw, bh); ctx.strokeRect(x, yb, bw, bh);
    ctx.fillStyle = '#9aa3ad'; ctx.fillRect(x + 8, yb + 8, bw - 16, bh - 16);
    ctx.fillStyle = '#5b3a1b'; var mx = left ? x + bw - 4 : x; ctx.fillRect(mx, yb + 8, 4, bh - 16);   /* 口 */
    ctx.restore();
    /* おんさ：先の広がり＝ゆれの大きさ（実際の振動は 440 回/s で見えないので、大きさだけ表す） */
    var cx = x + bw / 2, d = a * 6 * (0.6 + 0.4 * Math.abs(Math.sin(s.t * 30))), fh = nar ? 70 : 90;
    var fy = yb - 46; forkShape(ctx, cx, fy, fh, d, '#7d8794');
    if (a > 0.05) for (var k = 1; k <= 3; k++) { ctx.save(); ctx.strokeStyle = 'rgba(209,74,42,' + (a * (0.9 - k * 0.22)) + ')'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(cx, fy - fh / 2, 18 + k * 9, -0.55, 0.55); ctx.stroke(); ctx.beginPath(); ctx.arc(cx, fy - fh / 2, 18 + k * 9, Math.PI - 0.55, Math.PI + 0.55); ctx.stroke(); ctx.restore(); }
    label(ctx, q[4], cx, yb + bh + 20, { size: nar ? 10.5 : 12, bold: true, color: COL.ink });
    label(ctx, Math.round(q[2]) + ' Hz', cx, 14, { size: nar ? 12 : 14, bold: true, color: left ? '#c9670c' : '#1663b5' });
  });
  /* 箱の口から出る音（左 → 右） */
  if (fk.aL > 0.05) for (var j = 0; j < 4; j++) { var u = ((s.t * 0.9) + j / 4) % 1, xx = xL + bw + 10 + u * (xR - xL - bw - 20); ctx.save(); ctx.strokeStyle = 'rgba(209,74,42,' + (fk.aL * (1 - u) * 0.8) + ')'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(xx - 20, yb + bh / 2, 20, -0.6, 0.6); ctx.stroke(); ctx.restore(); }
  /* ハンマー（たたいた直後） */
  if (fk.hit && !fk.mute && fk.aL > 0.9) { ctx.save(); ctx.strokeStyle = '#8a5a2b'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(xL + bw / 2 - 16, yb - 70); ctx.lineTo(xL - 6, yb - 100); ctx.stroke(); ctx.fillStyle = '#c9670c'; ctx.beginPath(); ctx.ellipse(xL + bw / 2 - 18, yb - 70, 7, 5, 0.5, 0, TAU); ctx.fill(); ctx.restore(); }
  if (fk.mute) label(ctx, '✋ 押さえた', xL + bw / 2, yb - (nar ? 100 : 122), { size: 11, bold: true, color: '#9b2418' });
  /* 右のおんさのゆれの大きさ */
  var mw = nar ? 90 : 130, mxx = W / 2 - mw / 2, my = nar ? 44 : 50;
  ctx.save(); ctx.fillStyle = '#eef1f4'; rrect(ctx, mxx, my, mw, 10, 5); ctx.fill(); ctx.fillStyle = '#1663b5'; rrect(ctx, mxx, my, Math.max(0, mw * fk.aR), 10, 5); ctx.fill(); ctx.restore();
  label(ctx, '440 Hz のおんさの揺れ', W / 2, my - 9, { size: nar ? 9.5 : 10.5, color: COL.sub });
  if (fk.aR > 0.3) pill(ctx, '共鳴する', mxx + mw / 2 - 40, my + 16, { size: 12, bg: '#fff1dc', border: '#e07b18', color: '#6b3a0a' });
}
function m2s4Info(s) {
  if (!s.info1) return;
  var f = s.v.fp, best = M2S4.P.map(function (p) { return [p[0], m2s4F0(p[1])]; }).filter(function (q) { return Math.abs(q[1] - f) < 0.03; });
  var h1 = '<p>いまの $f$ に固有振動数が近い振り子：<b>' + (best.length ? best.map(function (q) { return q[0]; }).join('・') : 'なし') + '</b></p><p class="sub">揺れは少しずつ育つので、数秒〜十数秒待とう。B と E は同じ長さ。</p>';
  if (s.info1._h !== h1) { s.info1._h = h1; s.info1.innerHTML = mathify(h1); }
  var R = m2s4R(s), h2 = '<p>440 Hz のおんさが共鳴する大きさ（いちばん大きいときを 100 % とする）：<b>' + Math.round(R * 100) + ' %</b></p><p class="sub">振動数が同じ（440 Hz）ときだけ大きく共鳴する。たたいたおんさを手で押さえても、共鳴した 440 Hz のおんさは鳴り続ける。</p>';
  if (s.info2._h !== h2) { s.info2._h = h2; s.info2.innerHTML = mathify(h2); }
}
function rightM2S4(s, R) {
  R.innerHTML = mathify('<div class="qcard"><p class="qt">共振（共鳴）</p>' +
    '<p>振り子の<b>固有振動数</b>は糸の長さ $L$ で決まる。</p><div class="qeq">$$f_0 = \\dfrac{1}{2\\pi}\\sqrt{\\dfrac{g}{L}}$$</div>' +
    '<p>外から与える振動の振動数 $f$ が $f_0$ に等しいとき、1 回揺れるごとにちょうどよいタイミングで押されるので、揺れがどんどん大きくなる（<b>共振</b>）。音で起こる共振を<b>共鳴</b>という（気柱・弦の共鳴は <a class="xlink" href="#3-3">③-3</a>）。</p>' +
    '<p class="qnote">図の手と糸の動きは 3 倍に拡大している。おんさの Q（どれだけ狭い振動数でしか共鳴しないか）は、見やすくするために実際より小さくした。</p></div>');
}
/* 札＋スライダーの操作（②-3 の drvctl と同じ形）。chips：[[名前, 値]]（名前が空なら値を書く） */
function m2s4Drv(s, host, k, lo, hi, step, chips, txt) {
  var dv = el('div', 'drvctl'), dvv = el('div', 'drvval'), cb = el('div', 'drvchips'), rg = el('input'), bs = [];
  rg.type = 'range'; rg.min = String(lo); rg.max = String(hi); rg.step = String(step); rg.value = String(s.v[k]); rg.setAttribute('aria-label', k === 'fp' ? '手で揺らす振動数' : 'たたくおんさの振動数');
  var set = function (v) { s.v[k] = v; o.sync(); s.def.onChanged(s, k); s.draw(); };
  var lastX = -1, two = false;
  chips.slice().sort(function (a, b) { return a[1] - b[1]; }).forEach(function (c) {
    var u = (c[1] - lo) / (hi - lo), row = 0; if (lastX >= 0 && u - lastX < 0.16) { row = 1; two = true; lastX = -1; } else lastX = u;   /* 近い札は 2 段目に */
    var b = el('button', 'b drvchip', String(c[1])); b.type = 'button';
    if (c[0]) b.innerHTML = c[0] + ' <small>' + c[1].toFixed(2) + '</small>';
    b.style.left = 'calc(11px + (100% - 22px) * ' + u.toFixed(4) + ')'; if (row) b.style.top = '1.75em';
    b.addEventListener('click', function () { set(c[1]); }); cb.appendChild(b); bs.push([b, c[1]]);
  });
  rg.addEventListener('input', function () { set(+rg.value); });
  if (two) cb.style.height = '3.9em';
  var nd = function (sg) { set(clamp(+((Math.round(s.v[k] / step) + sg) * step).toFixed(4), lo, hi)); };   /* −／＋ で 1 目盛り（22 回目） */
  dv.appendChild(dvv); dv.appendChild(drvBar(rg, cb, nd)); host.appendChild(dv);
  var o = { sync: function () { if (+rg.value !== s.v[k]) rg.value = s.v[k]; drvFill(rg); dvv.innerHTML = txt(s.v[k]); bs.forEach(function (q) { q[0].classList.toggle('on', Math.abs(q[1] - s.v[k]) < step / 2); }); } };
  o.sync(); return o;
}
