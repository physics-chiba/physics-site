/* ===== 71_m3s4.js ===== */
/* =========================================================================
   ③-4 モノコード — 2026-11-05 千葉さん 8 回目、2026-11-06 9 回目に作り直し
   ・参考：https://xn--sim-5t0h90w.jp/simulations/036.html（モノコード実験室）
       こま・おもりをドラッグ、弦のクリックではじく。設定は 弦の長さ・おもりの数（弦の張り）・弦の太さ〔mm〕、はじく強さ
   ・③-3 の基本振動と同じく、おんさのような単音（基本振動だけ）が出るとする
   ・右はしは滑車。おもり（1 個 1.0 kg）を下げて弦を張る。張力 S = (おもりの数) × 1.0 × 9.8 N
   ・弦はナイロン（密度 1140 kg/m³）とし、太さ d〔mm〕から線密度 ρ = 1140 × πd²/4
   ・f₁ = v/(2l)、v = √(S/ρ)
   ・図の弦の動き：実際は 1 秒に f₁ 回（数百回）振動するので、目にはぼやけた「幅」に見える（うすい帯）。
     その中の線は、動きを実際の約 1/(f₁/0.6) の速さにして描いたもの（その倍率を図に書く）。小さくなっていく速さは音と同じ（実際の時間）
   ========================================================================= */
'use strict';
var M3S4 = { Lbox: 1.0, mW: 1.0, g: 9.8, dens: 1140, tau: 2.2, fS: 0.6, AMP: [[0.45, '弱く'], [0.7, 'ふつう'], [1.0, '強く']],
  /* チョーキング（2026-11-07 千葉さん 13 回目）：音を出さない側の弦を指で押し下げると張力が上がり、音が上がる。
     弱く 25 セント・ふつう 50 セント（4 分音）・強く 100 セント（半音）・ビブラート（0〜50 セントを 1 秒に 5 回） */
  BEND: [[0, 'なし'], [25, '弱く'], [50, 'ふつう'], [100, '強く'], [-1, 'ビブラート']], VIB: { rate: 5, depth: 50 } };
/* 音色（2026-11-07 千葉さん 14 回目）：基音のみ／本物の音（はじいた位置 p = 0.22 の三角形の形を固有振動に分けた倍音もふくむ） */
var M3S4_P = 0.22, M3S4_PARTS = (function () { var a = []; for (var n = 1; n <= 10; n++) a.push([n, 2 * Math.sin(n * Math.PI * M3S4_P) / (n * n * Math.PI * Math.PI * M3S4_P * (1 - M3S4_P))]); return a; })();
/* ハーモニクス（2026-11-07 千葉さん 15 回目）：弦の 1/n の所に軽く触れると、そこが節にならない振動は止まり、第 n 倍音（とその整数倍）だけが残る */
function m3s4Parts(s) { if (s.timb !== 'real') return [[1, 1]]; return s.harm ? M3S4_PARTS.filter(function (p) { return p[0] % s.harm === 0; }) : M3S4_PARTS; }
function m3s4Sounding(s) { return s.tPl !== null && s.t - s.tPl < 2.2 * M3S4.tau; }
/* いまの音の高さのずれ〔セント〕（ビブラートは時刻で変わる） */
function m3s4CentsAt(s, tp) { var c = M3S4.BEND[s.bi][0]; return c < 0 ? M3S4.VIB.depth / 2 * (1 - Math.cos(TAU * M3S4.VIB.rate * tp)) : c; }
function m3s4Cents(s) { var c = M3S4.BEND[s.bi][0]; return c < 0 ? M3S4.VIB.depth / 2 : c; }   /* ビブラートは真ん中の値で表示 */
function m3s4Q(s) {
  var d = s.v.d * 1e-3, rho = M3S4.dens * Math.PI * d * d / 4, S0 = s.v.nw * M3S4.mW * M3S4.g, c = m3s4Cents(s);
  var S = S0 * Math.pow(2, 2 * c / 1200), v = Math.sqrt(S / rho), l = s.v.l;   /* f ∝ √S なので、c セント上げる＝張力を 2^(2c/1200) 倍 */
  return { l: l, S: S, S0: S0, rho: rho, v: v, f1: v / (2 * l), f0: Math.sqrt(S0 / rho) / (2 * l), cents: c };
}
DEFS.m3s4 = {
  id: 'm3s4', mode: 'mode3', num: 4,
  title: 'モノコード', short: 'モノコード',
  desc: 'こまで弦の長さ $l$ を、おもりの数で弦の張りを変えると、音の高さが変わる。<span class="todo">こま・おもりをドラッグし、<b>Enter キー</b>（または弦をクリック）で弦をはじこう。</span>',
  noPlay: true,
  strobe: false, stepDiv: 16,
  varCols: [['l', 'nw', 'd'], ['vv', 'f1']],
  varColNote: { 1: '以下は、左の値で決まる（直接は変えられない）' },
  vars: [
    { k: 'l', label: '弦の長さ $l$', aria: '振動する弦の長さ', min: 0.10, max: 0.95, step: 0.005, def: 0.50, fmt: function (x) { return sig(x * 100, 3) + ' cm'; } },
    { k: 'nw', label: 'おもりの数', aria: 'おもりの数', stops: [1, 2, 3, 4, 5, 6, 7, 8], prop: true, stopLabels: ['1', '', '', '4', '', '', '', '8 個'], def: 4, fmt: function (x) { return x + ' 個（' + sig(x * M3S4.mW * M3S4.g, 3) + ' N）'; } },
    { k: 'd', label: '弦の太さ $d$', aria: '弦の太さ', min: 0.3, max: 2.5, step: 0.05, def: 0.5, fmt: function (x) { return fmt(x, 2) + ' mm'; } },   /* 既定 0.50 mm（2026-11-07 千葉さん 15 回目）。自由に変えられる（2026-11-07 千葉さん 13 回目） */
    meterVar('vv', '速さ $v$', '速さ', function (x) { return sig(x, 3) + ' m/s'; }, 450),
    meterVar('f1', '振動数 $f_1$', '基本振動数', function (x) { return sig(x, 3) + ' Hz'; }, 2300)
  ],
  disp: function (s, k) { var q = m3s4Q(s); if (k === 'vv') return q.v; if (k === 'f1') return q.f1; return s.v[k]; },
  init: function (s) { s.ai = 1; s.bi = 0; s.tPl = null; s.timb = 'pure'; s.harm = null; },
  onDefaults: function (s) { s.ai = 1; s.bi = 0; s.tPl = null; s.timb = 'pure'; s.harm = null; m3s4RealOn(s); m3s4Sync(s); },
  onChanged: function (s) { s._nMsg = null; s.tPl = null; s.harm = null; AUDIO.owner() === 'm3s4' && AUDIO.stop(); m3s4Sync(s); return 'keepT'; },   /* 長さ・張り・太さを変えたら、弦は静かになる（もう一度はじく） */
  buttons: M3S4.AMP.map(function (a, i) { return { k: 'a' + i, label: a[1], seg: 'amp', segLabel: 'はじく強さ', onClick: function (s) { s.ai = i; m3s4Sync(s); } }; })
    .concat([['pure', '基音のみ'], ['real', '本物の音']].map(function (p) { return { k: 't_' + p[0], label: p[1], seg: 'tim', segLabel: '音', onClick: function (s) { s.timb = p[0]; s.harm = null; m3s4Sync(s); s.draw(); } }; }))
    .concat(M3S4.BEND.map(function (b, i) { return { k: 'b' + i, label: b[1], seg: 'bend', segLabel: 'チョーキング', onClick: function (s) { s.bi = i; m3s4Bend(s); m3s4Sync(s); s.syncSliders && s.syncSliders(); s.draw(); } }; })),
  tEnd: function () { return M3_TEND; },
  tInfo: function (s) { return '<span class="tpl">音の高さ</span><b>' + sig(m3s4Q(s).f1, 3) + '</b> Hz'; },
  gT: function () { return 1; },
  height: function (s, w) { return Math.round(clamp(w * 0.44, 250, 300)); },
  afterBuild: function (s) {
    s.R.innerHTML = ''; var sw = el('div', 'row2 sliders inR'); sw.appendChild(s.varbox); s.R.appendChild(sw); s.varbox.classList.add('inR');
    /* 説明カードの上に、いまの音を五線譜で（2026-11-06 千葉さん 9 回目） */
    var sb = el('div', 'notebox'); s.noteCv = el('canvas', 'notecv'); s.noteCv.setAttribute('aria-label', '五線譜。音符をクリックするとその音が鳴る'); sb.appendChild(s.noteCv); s.R.appendChild(sb);
    s.noteCv.addEventListener('click', function (ev) { m3s4NoteClick(s, ev); });
    s.noteCv.addEventListener('pointermove', function (ev) { var r = s.noteCv.getBoundingClientRect(), x = ev.clientX - r.left; s.noteCv.style.cursor = (s._nHits || []).some(function (h) { return x >= h.x && x < h.x + h.w; }) ? 'pointer' : 'default'; });
    s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);
    var segs = s.row1b.querySelectorAll('.seg');
    [['はじく強さ', 0], ['音', 1], ['チョーキング', 2]].forEach(function (p) { if (segs[p[1]]) { var lb = el('span', 'seglbl', p[0]); segs[p[1]].insertAdjacentElement('beforebegin', lb); lblSeg(lb, segs[p[1]]); } });
    m3TimeBar(s, false);
    /* ハーモニクス（「音」の段の下。本物の音のときだけ出し、鳴っている間だけ押せる） */
    var hr = el('div', 'harmrow'); hr.appendChild(el('span', 'seglbl', 'ハーモニクス'));
    s.hBtns = [[2, '真ん中に<br>軽く触れる'], [3, '3 分の 1 に<br>触れる']].map(function (p) {
      var b = el('button', 'b hb'); b.type = 'button'; b.innerHTML = p[1]; b.title = '鳴っている間に押すと、弦のその所に軽く触れて、第 ' + p[0] + ' 倍音を鳴らす';
      b.addEventListener('click', function () { m3s4Harm(s, p[0]); }); hr.appendChild(b); return b;
    });
    s.hNote = el('span', 'hnote', '（音が鳴っている間に押す）'); hr.appendChild(s.hNote);
    if (segs[1]) segs[1].parentNode.insertBefore(hr, segs[1].nextSibling); else s.row1b.appendChild(hr);
    s.harmRow = hr;
    m3s4RealOn(s);                                                   /* 「本当の速さ」を最初から ON（2026-11-07 千葉さん 15 回目） */
    /* スタートの代わりに「🔊 音を鳴らす」を光らせて置く。その右に「Enter キーで音が鳴る」の札（2026-11-07 千葉さん 13 回目） */
    var pb = el('button', 'b plk glow m3s4pl', '🔊 音を鳴らす（弦をはじく・Enter）'); pb.type = 'button';
    pb.addEventListener('click', function () { m3s4Pluck(s); });
    s.bPlay.insertAdjacentElement('beforebegin', pb); s.bPlay.style.display = 'none'; s.plBtn = pb;
    var eb = el('span', 'entbadge', '⌨ Enter キーで音が鳴る'); pb.insertAdjacentElement('afterend', eb); s.entBadge = eb;
    var art = document.getElementById('m3s4');
    /* Enter が使えるか：このモノコードが画面に見えていて、ほかの節のボタン・入力欄にフォーカスがないとき */
    s.enterOK = function () {
      if (!s.cv.offsetParent) return false;
      var r = s.cv.getBoundingClientRect(); if (r.bottom < 0 || r.top > window.innerHeight) return false;
      var a = document.activeElement;
      if (!a || a === document.body || a === document.documentElement) return true;
      if (a.tagName === 'TEXTAREA' || (a.tagName === 'INPUT' && a.type !== 'range')) return false;
      return art.contains(a);
    };
    var upd = function () { var on = s.enterOK(); eb.classList.toggle('on', on); eb.textContent = on ? '⌨ Enter キーで音が鳴る' : '⌨ Enter キー：このモノコードをクリックすると使える'; };
    s.updEnter = upd;
    ['scroll', 'resize'].forEach(function (ev) { window.addEventListener(ev, upd, { passive: true }); });
    document.addEventListener('focusin', upd); document.addEventListener('focusout', function () { setTimeout(upd, 0); });
    art.addEventListener('pointerdown', function (ev) { if (ev.target.tagName !== 'INPUT') setTimeout(function () { var a = document.activeElement; if (a && a !== document.body && art.contains(a) && a.tagName === 'BUTTON') a.blur(); upd(); }, 0); });
    /* オシロスコープはモノコードの下 */
    s.scope = new Scope(s.L, 'オシロスコープ（弦の音）'); s.cw.insertAdjacentElement('afterend', s.scope.box); s.scope.box.classList.add('m3s4sc');
    /* ドラッグ：こま（左右）・おもり（上下で個数）。弦のクリックではじく */
    var drag = null, pos = function (ev) { var r = s.cv.getBoundingClientRect(); return { x: ev.clientX - r.left, y: ev.clientY - r.top }; };
    var onK = function (p) { var g = s._g; return g && Math.abs(p.x - g.X(s.v.l)) < 16 && p.y > g.cy - 16 && p.y < g.cy + 40; };
    var onW = function (p) { var g = s._g; return g && Math.abs(p.x - g.wx) < 20 && p.y > g.wy0 - 6 && p.y < g.wy0 + s.v.nw * g.wh + 16; };
    var onStr = function (p) { var g = s._g; return g && p.x > g.X(0) + 4 && p.x < g.X(s.v.l) - 8 && Math.abs(p.y - g.cy) < 22; };
    s.cv.addEventListener('pointerdown', function (ev) {
      var p = pos(ev);
      if (onK(p)) { drag = 'k'; s.cv.setPointerCapture(ev.pointerId); ev.preventDefault(); return; }
      if (onW(p)) { drag = 'w'; s.cv.setPointerCapture(ev.pointerId); ev.preventDefault(); return; }
      if (onStr(p)) { m3s4Pluck(s); ev.preventDefault(); }
    });
    s.cv.addEventListener('pointermove', function (ev) {
      var p = pos(ev), g = s._g; if (!g) return;
      if (!drag) { s.cv.style.cursor = onK(p) ? 'ew-resize' : (onW(p) ? 'ns-resize' : (onStr(p) ? 'pointer' : 'default')); return; }
      if (drag === 'k') { var l = clamp(Math.round((p.x - g.X(0)) / g.SX / 0.005) * 0.005, 0.10, 0.95); if (l !== s.v.l) { s.v.l = l; DEFS.m3s4.onChanged(s); s.syncSliders && s.syncSliders(); s.draw(); } }
      else { var n = clamp(Math.round((p.y - g.wy0) / g.wh), 1, 8); if (n !== s.v.nw) { s.v.nw = n; DEFS.m3s4.onChanged(s); s.syncSliders && s.syncSliders(); s.draw(); } }   /* 下へ引くほど、おもりが増える */
      ev.preventDefault();
    });
    var up = function () { drag = null; };
    s.cv.addEventListener('pointerup', up); s.cv.addEventListener('pointercancel', up);
    /* Enter キーではじく。このモノコードの中のボタン・スライダーを触ったあとでも使える（ボタンが押し直されないように先に受け取る） */
    window.addEventListener('keydown', function (ev) {
      if (ev.key !== 'Enter' || ev.repeat || !s.enterOK()) return;
      ev.preventDefault(); ev.stopPropagation(); m3s4Pluck(s);
    }, true);
    setTimeout(upd, 300);
    window.addEventListener('resize', function () { s._nk = null; });
    m3s4Sync(s);
  },
  draw: function (s, ctx, W, H) { drawM3S4(s, ctx, W, H); m3s4Scope(s); m3s4Note(s); },
  right: function (s, R) { rightM3S4(s, R); }
};
function m3s4Sync(s) { if (s.harmRow) { s.harmRow.hidden = s.timb !== 'real'; m3s4HarmUI(s); } m2Sync(s, M3S4.AMP.map(function (a, i) { return ['a' + i, s.ai === i]; }).concat([['t_pure', s.timb === 'pure'], ['t_real', s.timb === 'real']]).concat(M3S4.BEND.map(function (b, i) { return ['b' + i, s.bi === i]; }))); s._nk = null; if (s.Rdyn) s.renderRight(); }
/* 鳴っている間にチョーキングを変えたら、音の高さもなめらかに変える */
function m3s4Bend(s) { var c = M3S4.BEND[s.bi][0]; AUDIO.bend('m3s4', c < 0 ? 0 : c, c < 0 ? M3S4.VIB : null); }
/* 「本当の速さ」を ON にする（最初の設定） */
function m3s4RealOn(s) { if (!s.bReal) return; s.real = true; s.bReal.classList.add('on'); s.bReal.setAttribute('aria-pressed', 'true'); if (s.realNote) s.realNote.hidden = false; }
/* ハーモニクスのボタン：鳴っている間だけ押せる。押したものを選ばれた形に */
function m3s4HarmUI(s) {
  if (!s.hBtns) return;
  var on = m3s4Sounding(s), key = on + '|' + s.harm;
  if (s._hk === key) return; s._hk = key;
  if (s.plBtn) s.plBtn.classList.toggle('glow', !on);              /* 鳴っていないときだけ「音を鳴らす」を光らせる */
  s.hBtns.forEach(function (b, i) { var n = i + 2; b.disabled = !on && s.harm !== n; b.classList.toggle('on', s.harm === n); b.setAttribute('aria-pressed', s.harm === n ? 'true' : 'false'); });
  s.hNote.textContent = s.harm ? '第 ' + s.harm + ' 倍音（' + sig(s.harm * m3s4Q(s).f1, 3) + ' Hz）が鳴っている' : (on ? '' : '（音が鳴っている間に押す）');
}
/* ハーモニクス：押した瞬間から、第 n 倍音（とその整数倍）だけにする */
function m3s4Harm(s, n) {
  if (s.timb !== 'real' || !m3s4Sounding(s) || s.harm === n) return;
  var before = m3s4Parts(s), rms = function (a) { return Math.sqrt(a.reduce(function (z, p) { return z + p[1] * p[1]; }, 0)); };
  s.harm = n; var after = m3s4Parts(s);
  AUDIO.harm('m3s4', after.map(function (p) { return [p[0], Math.abs(p[1])]; }), rms(after) / rms(before));
  s._hk = null; m3s4HarmUI(s); s._nk = null; s.renderRight(); s.draw();
}
/* はじく：単音（基本振動だけ。おんさのような音）。音と図の小さくなり方は同じ時定数 */
function m3s4Pluck(s) {
  var q = m3s4Q(s);
  s.tPl = s.t; s.harm = null; s._hk = null;
  var c = M3S4.BEND[s.bi][0];
  AUDIO.pluck('m3s4', { f: q.f0, partials: s.timb === 'real' ? M3S4_PARTS.map(function (p) { return [p[0], Math.abs(p[1])]; }) : null, cents: c < 0 ? 0 : c, vib: c < 0 ? M3S4.VIB : null }, M3S4.AMP[s.ai][0], 3 * M3S4.tau + 0.5, M3S4.tau);   /* 張力そのままの高さ f₀ から、チョーキングの分だけ上げる */
  if (!s.playing) { SIMS.forEach(function (o) { if (o !== s && o.playing) { o.playing = false; o.syncPlayLabel(); } }); s.playing = true; s.syncPlayLabel(); startLoop(); }
  s.draw();
}
function drawM3S4(s, ctx, W, H) {
  var q = m3s4Q(s), nar = W < 520, x0 = nar ? 26 : 40, x1 = W - (nar ? 64 : 92), SX = (x1 - x0) / M3S4.Lbox, cy = Math.round(H * 0.34);
  var X = function (x) { return x0 + x * SX; };
  /* 共鳴箱 */
  ctx.save(); var gr = ctx.createLinearGradient(0, cy + 24, 0, cy + 64); gr.addColorStop(0, '#d9b98a'); gr.addColorStop(1, '#b48a55'); ctx.fillStyle = gr; rrect(ctx, x0 - 18, cy + 24, x1 - x0 + 34, 52, 6); ctx.fill();
  ctx.restore();   /* 響き穴は描かない（シミに見えるので。2026-11-06 千葉さん 10 回目） */
  /* 目盛り（10 cm ごと） */
  ctx.save(); ctx.strokeStyle = 'rgba(58,40,20,.55)'; ctx.lineWidth = 1; ctx.font = '600 9.5px ' + FONT; ctx.fillStyle = 'rgba(58,40,20,.85)'; ctx.textAlign = 'center';
  for (var c = 0; c <= 10; c++) { var px = X(c / 10); ctx.beginPath(); ctx.moveTo(px, cy + 24); ctx.lineTo(px, cy + (c % 5 ? 30 : 34)); ctx.stroke(); if (c % 2 === 0 && !(X(1) - X(0) < 260 && (c === 2 || c === 6 || c === 8))) { ctx.textAlign = c === 10 ? 'right' : 'center'; ctx.fillText(String(c * 10) + (c === 10 ? ' cm' : ''), c === 10 ? px - 2 : px, cy + 44); } }
  ctx.restore();
  /* 目盛りの数字の下に、ドレミ … の位置（いまの張力・太さで、その音になる弦の長さ）。チョーキングなしの値（2026-11-07 千葉さん 14 回目） */
  var v0 = 2 * q.l * q.f0, lastX = -99, lastW = 0;                  /* 名前は横一列に書く（23 回目。前は 2 段に交互で凸凹に見えた） */
  for (var mN = 36; mN <= 96; mN++) {                             /* 長い（低い）音から順に。となりの名前と重なる所で止める（とびとびにしない） */
    if (MUS.black(mN)) continue;
    var lN = v0 / (2 * MUS.fET(mN)); if (lN > 0.97) continue; if (lN < 0.1) break;
    var isC = mN % 12 === 0, nmN = MUS.jp(mN);
    ctx.save(); ctx.font = (isC ? '700 9.5px ' : '600 8.5px ') + FONT; var wN = ctx.measureText(nmN).width; ctx.restore();
    var pxN = X(lN); if (lastX > 0 && lastX - pxN < (lastW + wN) / 2 + 2) break; lastX = pxN; lastW = wN;
    ctx.save(); ctx.strokeStyle = isC ? '#7a3b12' : 'rgba(90,60,30,.6)'; ctx.lineWidth = isC ? 1.6 : 1; ctx.beginPath(); ctx.moveTo(pxN, cy + 50); ctx.lineTo(pxN, cy + 56); ctx.stroke(); ctx.restore();
    label(ctx, nmN, pxN, cy + 64, { size: isC ? 9.5 : 8.5, bold: isC, color: isC ? '#5a2a08' : '#6b4a2a', halo: false });
  }
  /* 左はしの駒（固定）・右はしの滑車とおもり */
  ctx.save(); ctx.fillStyle = '#6b4a2a'; ctx.beginPath(); ctx.moveTo(X(0) - 7, cy + 24); ctx.lineTo(X(0), cy); ctx.lineTo(X(0) + 7, cy + 24); ctx.closePath(); ctx.fill(); ctx.restore();
  var pr = 11, pcx = x1 + 22, pcy = cy + pr, wx = pcx + pr, wh = 13, wy0 = cy + 96;
  ctx.save(); ctx.fillStyle = '#5b6470'; ctx.fillRect(x1 + 2, cy + 22, 8, 24); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 2.4; ctx.beginPath(); ctx.arc(pcx, pcy, pr, 0, TAU); ctx.stroke(); ctx.beginPath(); ctx.arc(pcx, pcy, 2.5, 0, TAU); ctx.fillStyle = '#3a414c'; ctx.fill(); ctx.restore();
  /* 弦の太さ（図の線の太さも d に合わせる）。音を出さない側（こま〜滑車）の上に指。チョーキングでは指が弦を押し下げる */
  var sLw = 0.8 + 1.6 * s.v.d, cB = M3S4.BEND[s.bi][0], dep = cB < 0 ? 7 * (1 - Math.cos(TAU * 1.5 * s.t)) / 2 : 14 * cB / 100, xf = (X(q.l) + pcx) / 2;
  ctx.save(); ctx.strokeStyle = 'rgba(122,59,18,.55)'; ctx.lineWidth = sLw; ctx.beginPath(); ctx.moveTo(X(q.l), cy); ctx.lineTo(xf, cy + dep); ctx.lineTo(pcx, cy); ctx.arc(pcx, pcy, pr, -Math.PI / 2, 0); ctx.lineTo(wx, wy0); ctx.stroke(); ctx.restore();
  if (cB !== 0) m3s4Finger(ctx, xf, cy + dep - sLw / 2 - 1);      /* チョーキング「なし」のときは指をかかない（2026-11-08 千葉さん 16 回目） */
  if (cB !== 0) label(ctx, cB < 0 ? 'ビブラート' : 'チョーキング（+' + cB + ' セント）', xf, cy - 58, { size: 10.5, bold: true, color: '#9c4e06' });
  for (var k = 0; k < s.v.nw; k++) { ctx.save(); ctx.fillStyle = '#5b6470'; ctx.strokeStyle = '#3a414c'; rrect(ctx, wx - 14, wy0 + 2 + k * wh, 28, wh - 2, 3); ctx.fill(); ctx.stroke(); ctx.restore(); }
  label(ctx, 'おもり ' + s.v.nw + ' 個', Math.min(wx, W - 34), wy0 + s.v.nw * wh + 14, { size: 10.5, bold: true, color: COL.ink2 });
  label(ctx, '↕', wx + 24, wy0 + s.v.nw * wh / 2, { size: 13, bold: true, color: '#9c4e06' });
  s._g = { X: X, SX: SX, cy: cy, wx: wx, wy0: wy0, wh: wh };
  /* 振動する弦（基本振動だけ）。うすい帯＝目に見える振動の幅、線＝ゆっくりにした動き */
  var tp = s.tPl === null ? null : Math.max(0, s.t - s.tPl), amp = Math.min(24, H * 0.09) * M3S4.AMP[s.ai][0] / 0.7;
  var env = tp === null ? 0 : Math.exp(-tp / M3S4.tau), fSd = s.real ? M3_REALF : M3S4.fS, ph = tp === null ? 0 : Math.cos(TAU * fSd * tp);
  /* 本物の音：はじいた三角形の形（倍音の和）。基音のみ：基本振動だけ */
  var parts = m3s4Parts(s), shp = function (x, tt) { var y = 0; parts.forEach(function (p) { y += p[1] * Math.sin(p[0] * Math.PI * x / q.l) * Math.cos(TAU * p[0] * fSd * tt); }); return y; };
  var band = function (x) { var y = 0; parts.forEach(function (p) { y += Math.abs(p[1] * Math.sin(p[0] * Math.PI * x / q.l)); }); return y; };
  if (env > 0.01) {
    ctx.save(); ctx.fillStyle = 'rgba(122,59,18,.16)'; ctx.beginPath();
    for (var i = 0; i <= 120; i++) { var xx = q.l * i / 120; ctx.lineTo(X(xx), cy - env * amp * band(xx)); }
    for (var i2 = 120; i2 >= 0; i2--) { var x2 = q.l * i2 / 120; ctx.lineTo(X(x2), cy + env * amp * band(x2)); }
    ctx.closePath(); ctx.fill(); ctx.restore();
  }
  plotF(ctx, function (x) { return tp === null ? 0 : env * shp(x, tp); }, 0, q.l, X, function (y) { return cy - y * amp; }, '#7a3b12', sLw + 0.6);
  /* ハーモニクス：1/n の所に軽く触れている指 */
  if (s.harm && s.timb === 'real') { var xh = X(q.l / s.harm); m3s4Finger(ctx, xh, cy - 2); label(ctx, 'ハーモニクス（第 ' + s.harm + ' 倍音）', xh, cy - 58, { size: 10.5, bold: true, color: '#1663b5' }); }
  m3s4HarmUI(s);
  /* こま（動かせる） */
  var kx = X(q.l);
  ctx.save(); ctx.fillStyle = '#e07b18'; ctx.strokeStyle = '#9c4e06'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(kx - 10, cy + 24); ctx.lineTo(kx, cy - 1); ctx.lineTo(kx + 10, cy + 24); ctx.closePath(); ctx.fill(); ctx.stroke(); ctx.restore();
  label(ctx, 'こま', kx, cy - 34, { size: 11, bold: true, color: '#9c4e06' });
  /* l の寸法 */
  dimH(ctx, X(0), kx, cy + 94, '#3a414c', 'l', { ticks: false });
  label(ctx, '= ' + sig(q.l * 100, 3) + ' cm', (X(0) + kx) / 2 + 9, cy + 83, { size: 11.5, color: '#3a414c', align: 'left' });
  /* 音の高さ */
  label(ctx, '音の高さ ' + sig(q.f1, 3) + ' Hz' + (cB !== 0 ? '（チョーキングなしでは ' + sig(q.f0, 3) + ' Hz）' : ''), 8, 13, { size: nar ? 11.5 : 12.5, bold: true, color: '#6b3a0a', align: 'left' });
  if (tp === null || env <= 0.01) label(ctx, 'Enter キー・弦をクリックで、弦をはじく', (X(0) + kx) / 2, cy - 16, { size: nar ? 10 : 11, color: COL.faint });
  /* 動きの断り（うそをつかない：何倍ゆっくりにしているかを書く） */
  var slow = Math.round(q.f1 / fSd / (s.real ? 1 : 10)) * (s.real ? 1 : 10);
  var t1 = nar ? '薄い帯：見える振動の幅（実際は 1 秒に ' + sig(q.f1, 3) + ' 回）' : '薄い帯：目に見える振動の幅（実際は 1 秒に ' + sig(q.f1, 3) + ' 回振動）', t2 = nar ? '線：実際の約 ' + bigNum(slow) + ' 分の 1 の速さ（振幅は拡大）' : '線：動きを実際の約 ' + bigNum(slow) + ' 分の 1 の速さにしたもの（振幅は拡大）';   /* スマホでは短く（おもりと重ならないように） */
  label(ctx, t1, 8, H - 26, { size: nar ? 9.5 : 10.5, color: COL.ink2, align: 'left' });
  label(ctx, t2, 8, H - 10, { size: nar ? 9.5 : 10.5, color: COL.ink2, align: 'left' });
}
/* オシロスコープ：はじいてからの時間 tp の 10 ms（だんだん小さくなる）。
   ビブラート・チョーキングでは、そのときの振動数で描く（2026-11-07 千葉さん 14 回目：ビブラートで振動数が変わるのが見えるように） */
function m3s4Scope(s) {
  var sc = s.scope; if (!sc || !sc.cv.offsetParent) return;
  var q = m3s4Q(s), W = Math.max(240, Math.floor(sc.cv.clientWidth || 300)), h1 = Math.round(clamp(W * 0.22, 120, 160)), H = h1, ctx = prep(sc.cv, W, H);
  ctx.clearRect(0, 0, W, H);
  var tp = s.tPl === null ? null : Math.max(0, s.t - s.tPl), A = M3S4.AMP[s.ai][0], parts = m3s4Parts(s), pk = 0;
  for (var k = 0; k < 200; k++) { var y0 = 0; parts.forEach(function (p) { y0 += p[1] * Math.sin(TAU * p[0] * k / 200); }); pk = Math.max(pk, Math.abs(y0)); }
  var fNow = q.f0 * Math.pow(2, m3s4CentsAt(s, tp || 0) / 1200);
  var t0 = tp === null ? 0 : Math.floor(tp * fNow) / fNow;
  var f = function (t) { if (tp === null) return 0; var y = 0; parts.forEach(function (p) { y += p[1] * Math.sin(TAU * p[0] * fNow * t); }); return 0.9 * A * Math.exp(-t / M3S4.tau) * y / pk; };
  sc.screen(ctx, 0, 0, W, h1, { t0: t0, span: 0.010, yMax: 1, traces: [{ f: f, fmax: fNow * parts.length }], label: '横 1 目盛り 1 ms', labelR: sig(fNow * (s.harm || 1), 4) + ' Hz' });
  /* 下の「振動数の変化」の帯はなくした（2026-11-08 千葉さん 16 回目） */
  var cap = s.harm ? 'ハーモニクス：基本振動が止まり、振動数 $' + s.harm + 'f_1 = ' + sig(s.harm * fNow, 4) + '$ Hz（第 ' + s.harm + ' 倍音）の振動が残る（10 ms の間に ' + sig(0.010 * s.harm * fNow, 3) + ' 回振動）' : 'はじくと、振動数 $f = ' + sig(fNow, 4) + '$ Hz の音が出て、だんだん小さくなる（10 ms の間に ' + sig(0.010 * fNow, 3) + ' 回振動）' + (s.timb === 'real' ? '。本物の音なので倍音も含み、波形がとがる' : '');
  if (sc.cap._h !== cap) { sc.cap._h = cap; sc.cap.innerHTML = mathify(cap); }
}
/* 説明カードの上の五線譜（2026-11-07 千葉さん 14 回目：④-1 と同じく、音符をクリックするとその音が鳴る）
   C4〜C5 の白鍵。クリックすると、いまの張力・太さでその音になる位置へこまを動かして、はじく。いまの音（いちばん近い平均律の音）を橙で */
var M3S4_NOTES = [60, 62, 64, 65, 67, 69, 71, 72];                    /* 下のドからオクターブ上のドまで（2026-11-07 千葉さん 15 回目） */
function m3s4Note(s) {
  var cv = s.noteCv; if (!cv || !cv.offsetParent) return;
  var q = m3s4Q(s), W = Math.max(240, Math.floor(cv.clientWidth || 300)), H = 168, nr = MUS.near(q.f1), key = [W, nr.m, nr.cent, s._nMsg || ''].join('|');
  if (s._nk === key) return; s._nk = key;
  var ctx = prep(cv, W, H); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H);
  label(ctx, '五線譜（音符をクリックすると、その音になる位置にこまを動かして鳴らす）', 8, 12, { size: 10.5, bold: true, color: COL.ink2, align: 'left' });
  var sp = 10, yTop = 30 + 3 * sp, x0 = 8, x1 = W - 8, Y = staff(ctx, x0, x1, yTop, sp), nx0 = x0 + sp * 4, dx = (x1 - nx0 - 6) / M3S4_NOTES.length;
  s._nHits = [];
  M3S4_NOTES.forEach(function (m, i) {
    var x = nx0 + dx * (i + 0.5), on = nr.m === m && Math.abs(nr.cent) < 30;
    noteHead(ctx, x, MUS.step(m), Y, sp, on ? '#e07b18' : '#14171c', false, !on);
    label(ctx, MUS.jp(m), x, Y(-4) + 6, { size: 9.5, bold: on, color: on ? '#c9670c' : COL.ink2 });
    s._nHits.push({ x: x - dx / 2, w: dx, m: m });
  });
  var tx = s._nMsg || ('いまの音：' + sig(q.f1, 4) + ' Hz（いちばん近いのは ' + MUS.jp(nr.m) + '（' + MUS.en(nr.m) + '）、' + (Math.abs(nr.cent) < 3 ? 'ほぼぴったり' : (nr.cent > 0 ? '+' : '') + nr.cent + ' セント') + '）');
  label(ctx, tx, 8, H - 10, { size: 10.5, bold: true, color: s._nMsg ? '#9b2418' : '#c9670c', align: 'left' });
}
function m3s4NoteClick(s, ev) {
  var r = s.noteCv.getBoundingClientRect(), x = ev.clientX - r.left, hit = (s._nHits || []).filter(function (h) { return x >= h.x && x < h.x + h.w; })[0];
  if (!hit) return;
  var q = m3s4Q(s), l = (2 * q.l * q.f0) / (2 * MUS.fET(hit.m));      /* v₀/(2f)：チョーキングなしでその音になる長さ */
  if (l < 0.10 || l > 0.95) { s._nMsg = MUS.jp(hit.m) + '（' + MUS.en(hit.m) + '）は、いまのおもり・太さでは出せない（おもりや太さを変えよう）'; s._nk = null; m3s4Note(s); return; }
  s._nMsg = null; s.v.l = Math.round(l * 1000) / 1000; s.syncSliders && s.syncSliders(); s.renderRight(); m3s4Pluck(s);
}
function rightM3S4(s, R) {
  var q = m3s4Q(s);
  var h = '<div class="qcard"><p class="qt">モノコードの音の高さ</p>' +
    '<p>弦の両端（左端の固定されたこまと、動かせるこま）が節になる。基本振動では $l = \\dfrac{\\lambda}{2}$ なので</p>' +
    '<div class="qeq">$$f_1 = \\frac{v}{2l} = \\frac{1}{2l}\\sqrt{\\frac{S}{\\rho}}$$</div>' +
    '<p>（$S$：弦の張力＝おもりの重さ、$\\rho$：弦 1 m あたりの質量。太い弦ほど大きい）</p>' +
    '<table class="reltab grid1"><tbody><tr><th>$l$ を短く</th><td class="l">高い音（$l$ を半分にすると振動数は 2 倍＝1 オクターブ上）</td></tr>' +
    '<tr><th>おもりを増やす</th><td class="l">高い音（張力 $S$ が大きく、$v$ が大きくなる。4 倍にすると 1 オクターブ上）</td></tr><tr><th>弦を太く</th><td class="l">低い音（$\\rho$ が大きく、$v$ が小さくなる）</td></tr></tbody></table>' +
    '<p class="qnow"><span class="qtag now">いま</span>$S = ' + s.v.nw + ' \\times 1.0 \\times 9.8' + (q.cents ? ' \\times ' + sig(q.S / q.S0, 3) + '（チョーキング）' : '') + ' = ' + sig(q.S, 3) + '$ N、$v = \\sqrt{\\dfrac{S}{\\rho}} = ' + sig(q.v, 3) + '$ m/s、$f_1 = \\dfrac{' + sig(q.v, 3) + '}{2 \\times ' + fmt(q.l, 3) + '} = ' + sig(q.f1, 3) + '$ Hz</p>' +
    '<p><b>チョーキング</b>：音を出さない側（こま〜滑車）の弦を指で押し下げると、弦がのびて張力 $S$ が大きくなる。すると $v = \\sqrt{\\dfrac{S}{\\rho}}$ が大きくなり、音が高くなる。半音（100 セント）上げるには、$S$ を $2^{\\frac{2}{12}} \\fallingdotseq 1.12$ 倍にすればよい。ビブラートは、押す強さを繰り返し変えて $S$ を変化させる。</p>' +
    (s.timb === 'real' ? '<p><b>ハーモニクス</b>：鳴っている弦の真ん中（3 分の 1）の所に軽く触れると、そこが節になる振動だけが残り、第 2（第 3）倍音が鳴る（1 オクターブ上・1 オクターブと 5 度上）。</p>' : '') +
    '<p class="qnote">弦はナイロン（密度 1140 kg/m³）とした。「基音のみ」は ③-3 の基本振動と同じく単音、「本物の音」ははじいた弦のように倍音も含む。</p></div>';
  R.innerHTML = mathify(h);
}

/* 指（上から弦を押す。(x, y)＝指先） */
function m3s4Finger(ctx, x, y) {
  ctx.save();
  ctx.fillStyle = '#f2c7a5'; ctx.strokeStyle = '#a8704a'; ctx.lineWidth = 1.2;
  ctx.beginPath(); ctx.moveTo(x - 8, y - 40); ctx.lineTo(x - 8, y - 8); ctx.quadraticCurveTo(x - 8, y, x, y); ctx.quadraticCurveTo(x + 8, y, x + 8, y - 8); ctx.lineTo(x + 8, y - 40); ctx.closePath(); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#fbe3d2'; ctx.beginPath(); ctx.ellipse(x, y - 9, 4.5, 5.5, 0, 0, TAU); ctx.fill(); ctx.stroke();   /* つめ */
  ctx.restore();
  label(ctx, '指', x + 14, y - 30, { size: 10.5, bold: true, color: '#8a4f2a', align: 'left' });
}
