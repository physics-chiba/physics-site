/* ===== 80_page.js ===== */
/* =========================================================================
   80_page.js … ページの組み立て（ヒーロー・タブ列・章の扉・セクションのカード・コンテンツ一覧・アドレス）
   デザイン統一キット（momentum-and-collision.html）の骨組みと同じ。
   ========================================================================= */
'use strict';
var MODES = [
  { id: 'mode1', name: '波の基礎', secs: ['m1s1', 'm1s2', 'm1s3', 'm1s4'], rotSwitch: false,
    en: 'Basics of Waves',
    lead: 'ある場所で生じた振動が、次々と周りに伝わっていく現象を<b>波</b>という。波源の単振動が、となりの点へ少しずつ遅れて伝わることで、波の形が進んでいく。媒質の各点はその場で振動するだけで、進んでいくのは振動の状態である。振幅 $A$・波長 $\\lambda$・周期 $T$・振動数 $f$・速さ $v$ の関係を、自分で動かして確かめよう。単振動がまだ理解不十分な人は <a class="xlink" href="../mechanics/simple-harmonic-motion.html#mode1">単振動のページ（モード①）</a> を参照。' },
  { id: 'mode2', name: '波の重なり合い', secs: ['m2s1', 'm2s2', 'm2s3', 'm2s4'], rotSwitch: false,
    en: 'Superposition of Waves',
    lead: '2 つの波が出会うと、変位は足し合わされる（重ね合わせの原理）。逆向きに進む同じ波が重なると、どちらにも進まない波（定在波）ができる。波が端で反射すると、入射波と反射波が重なって定在波ができ、両端が固定された糸では固有振動が起こる。' },
  { id: 'mode3', name: '音波（物理基礎の範囲）', secs: ['m3s1', 'm3s2', 'm3s3', 'm3s4', 'm3s5'], rotSwitch: false,
    en: 'Sound Waves',
    lead: '音は空気を伝わる縦波である。音の三要素・うなり・弦と気柱の固有振動と共鳴・モノコード・気柱共鳴実験を、音を聞きながら確かめよう。' },
  { id: 'mode4', name: '音波（芸術の範囲）', secs: ['m4h', 'm4v', 'm4s1', 'm4p', 'm4s2', 'm4s3', 'm4s4', 'm4s5'], rotSwitch: false,
    en: 'Sound and Music',
    lead: 'このページは、あなたのより深い音楽への理解のために作りました。特に合唱・合奏で「長 3 度の音（ドに対するミの音）は下げ気味で」と聞いたことがある人は、その理由が理解できると思います。<br>これまで学んだように、弦と気柱は、基音の整数倍の振動数の音、倍音を発生させる（特に <a class="xlink" href="#3-3">③-3</a> と <a class="xlink" href="#3-4">③-4</a> から理解できる）。弦は弦楽器、気柱は管楽器と私たちの体から出る声の発音原理を理解できる。倍音の構成比の違いから、声や言葉、楽器は音色（y-t グラフの波形、オシロの波形）が違う。音色の原理、和音・平均律と純正律を、振動数の比から見てみよう。' },
  { id: 'mode5', name: 'より知りたい人へ：フーリエ変換などの大学レベルの内容', secs: ['m5s1', 'm5s2', 'm5s3', 'm5s4', 'm5s5'], rotSwitch: false,
    en: 'Fourier Transform',
    lead: '①〜④では、波を「いろいろな振動数の正弦波の重ね合わせ」として見てきた。特に ④ では、音を振動数の成分（倍音）に分けて見ることで、音色の正体（<a class="xlink" href="#4-1">④-1</a>）や、和音がきれいに響く理由（<a class="xlink" href="#4-6">④-6</a>・<a class="xlink" href="#4-7">④-7</a>）まで説明できた。成分に分けて見ることが、とても役に立つと分かったはずだ。<br>どんな波でも、その振動数の成分を計算で求める方法が<b>フーリエ変換</b>である。音・電波・画像など、波として表せるものなら何でも扱えるので、身の回りの技術で広く使われている。ここは大学で学ぶ内容なので、興味がある人が読めばよい（詳しくは <a class="xlink" href="#5-5">⑤-5</a> の参考サイトで）。' }
];
var CIRC = '①②③④⑤⑥⑦⑧⑨';
var GLOBAL = { hideEq: false, rot: false };
/* アドレスに ?rot=1 があれば、最初から「全て：一緒に円運動する観測者（非慣性系）から見る」を ON（2026-10-11 千葉さん） */
try { GLOBAL.rot = /(?:^|[?&])rot=(1|on|true)(?:&|$)/i.test(location.search); } catch (e) { }
var SIM_BY_ID = {}, MODE_BUILT = {};

function buildPage() {
  var wrap = document.getElementById('wrap'), h = '';
  document.getElementById('hero').innerHTML =
    '<div class="hero-in">' +
      '<div class="hero-top">' +
        '<nav class="crumbs" aria-label="現在地"><a class="crumb-home" href="' + SITE_HOME + '" title="楽楽（らくらく）高校物理のトップページへ"><svg class="atom" viewBox="0 0 32 32" aria-hidden="true"><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#3ea0e0" stroke-width="2"/><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#7b5bd6" stroke-width="2" transform="rotate(60 16 16)"/><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#e07b18" stroke-width="2" transform="rotate(120 16 16)"/><circle cx="16" cy="16" r="3.6" fill="#5aa7ff"/></svg><span>楽楽（らくらく）高校物理</span></a><span class="cs" aria-hidden="true">/</span><a class="crumb" href="' + SITE_HOME + '#sec-wave">波動</a><span class="cs" aria-hidden="true">/</span><span class="crumb now" aria-current="page">波の基礎</span><span class="kdot"></span><span class="en">Basics of Waves</span></nav>' +
        '<div class="topbtns" role="group" aria-label="ページ全体の表示"><button id="btnEq" type="button"></button></div>' +
      '</div>' +
      '<h1 class="hero-title"><span class="t1"><span class="nb" data-sh="波の基礎">波の基礎</span></span><span class="t2">〜単振動が次々と伝わっていく〜</span></h1>' +
      '<div class="introrow">' +
        '<p class="lead2">波源の単振動が、となりの点へ少しずつ遅れて伝わると、波の形が進んでいく。波の基本要素・重ね合わせ・音を、自分で動かし、音を聞いて理解しよう。</p>' +
        '<button id="bToc" class="tocbtn" type="button" aria-haspopup="true" aria-expanded="false"><span class="ti" aria-hidden="true"></span>コンテンツ一覧</button>' +
      '</div>' +
      '<div id="tocpanel" class="tocpanel" hidden></div>' +
      '<figure class="stage" aria-label="気柱の共鳴（水柱の実験）。おんさを管口で鳴らし、水面を下げていくと、L₁・L₂ で共鳴して大きな音になる">' +
        '<canvas id="heroCv"></canvas>' +
        '<figcaption class="stagecap"><span class="live" aria-hidden="true"></span><span class="sct">気柱の共鳴（水柱の実験）：管口でおんさを鳴らし、水面をゆっくり下げていくと、$L_1$・$L_2$ で共鳴して大きな音になる（右のグラフ）。腹は管口の少し外にでき、$L_2 - L_1 = \\dfrac{\\lambda}{2}$。</span>' +
        '<span class="stagectl" role="group" aria-label="アニメの操作"><button type="button" class="slow" aria-pressed="false" title="ゆっくり再生">🐢 スロー</button><button type="button" class="pp" aria-label="一時停止"><i></i></button></span></figcaption>' +
      '</figure>' +
      '<ol class="ideas">' +
        '<li><a href="#1-1"><span class="in" aria-label="①"><b>1</b></span><span class="ie">$v=f\\lambda$</span><span class="ij">1 周期で 1 波長進む</span><span class="ia" aria-hidden="true">→</span></a></li>' +
        '<li><a href="#2-1"><span class="in" aria-label="②"><b>2</b></span><span class="ie">$y=y_1+y_2$</span><span class="ij">重ね合わせで定在波ができる</span><span class="ia" aria-hidden="true">→</span></a></li>' +
        '<li><a href="#3-5"><span class="in" aria-label="③"><b>3</b></span><span class="ie">$L_2-L_1=\\dfrac{\\lambda}{2}$</span><span class="ij">気柱の共鳴（水柱の実験）</span><span class="ia" aria-hidden="true">→</span></a></li>' +
      '</ol>' +
    '</div>';
  document.getElementById('tabs').innerHTML = '<div class="tabs-in"><div class="navsite"><a class="navhome" href="' + SITE_HOME + '" aria-label="ホーム（楽楽高校物理のトップページ）" title="ホーム（楽楽高校物理のトップページ）"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3.5 10.8 12 4l8.5 6.8" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M6 9.5V20h4.5v-5.5h3V20H18V9.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg></a><button class="navpages" id="bPages" type="button" aria-haspopup="dialog" aria-expanded="false" aria-controls="siteDrawer"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="3.5" width="7" height="7" rx="1.6" fill="currentColor"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.6" fill="currentColor" opacity=".55"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.6" fill="currentColor" opacity=".55"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.6" fill="currentColor"/></svg><span>ページ一覧</span></button></div>' +
    MODES.map(function (m, i) { return '<button class="tab" type="button" data-mode="' + m.id + '"><span class="tn">' + CIRC[i] + '</span><span class="tl">' + m.name + '</span></button>'; }).join('') +
    '</div><span class="tprog" aria-hidden="true"></span>';

  MODES.forEach(function (m, i) {
    h += '<section class="mode" id="' + m.id + '">' +
      '<header class="modehead"><div class="mh-num" aria-hidden="true"><span>' + (i + 1) + '</span></div><div class="mh-body"><p class="mh-en">Chapter ' + String(i + 1).padStart(2, '0') + ' — ' + m.en + '</p>' +
      '<h2><span class="mh-c">' + CIRC[i] + '</span>' + m.name + '</h2><p class="mh-lead">' + m.lead + '</p></div></header>' +
      (m.secs.filter(function (sid) { return DEFS[sid]; }).length < 2 ? '' :          /* セクションが 1 つだけのモード（①）は、セクションへのリンクを出さない（2026-10-12 千葉さん） */
      '<div class="seclinks">' + m.secs.filter(function (sid) { return DEFS[sid]; }).map(function (sid) {
        return '<a href="#' + (i + 1) + '-' + DEFS[sid].num + '" data-toc="' + sid + '">' + CIRC[i] + '-' + DEFS[sid].num + '　' + (DEFS[sid].short || DEFS[sid].title) + '</a>'; }).join('') + '</div>') +
      '<div class="modebar" id="mbar_' + m.id + '"></div>';
    if (!m.secs.length) h += '<div class="sec soon"><div class="sL"><p class="secdesc">この章は、章 ① を確認していただいたあとで作ります。</p></div></div>';
    m.secs.forEach(function (sid) {
      var d = DEFS[sid]; if (!d) return;
      if (d.custom) {                                    /* 4-1 など：セクション独自のレイアウト（d.html で中身、d.build で図を作る） */
        h += '<article class="sec secwide" id="' + sid + '"><div class="swin"><div class="sechead"><span class="secnum">' + CIRC[i] + '-' + d.num + '</span><h2>' + d.title + '</h2>' + (d.exam ? examBtns(sid) : '') +
          (d.obsSeg ? '<div class="seg secobs" role="group" aria-label="どの観測者から見るか"><button type="button" class="b obs" data-rot="0">外（慣性系）から見る</button><button type="button" class="b obs rotb" data-rot="1">一緒に円運動する観測者（非慣性系）から見る</button></div>' : '') +
          '</div>' + d.html() + '</div></article>';
        return;
      }
      if (d.wideHead) {                                  /* 見出しと問題文（説明）は左右の列をまとめて横いっぱい。説明は 2 列に分けられる（d.desc2）。2026-10-18 千葉さん */
        h += '<article class="sec widehead" id="' + sid + '"><div class="shead"><div class="sechead"><span class="secnum">' + CIRC[i] + '-' + d.num + '</span><h2>' + d.title + '</h2>' + (d.exam ? examBtns(sid) : '') + '</div>' +
          (d.desc2 ? '<div class="secdesc desc2"><div>' + d.desc2[0] + '</div><div>' + d.desc2[1] + '</div></div>' : '') + (d.desc ? '<div class="secdesc">' + d.desc + '</div>' : '') + '</div>' +
          '<div class="sL"><div class="simhost" id="simL_' + sid + '"></div></div><div class="sR" id="simR_' + sid + '"></div></article>';
        return;
      }
      h += '<article class="sec" id="' + sid + '"><div class="sL">' +
        '<div class="sechead"><span class="secnum">' + CIRC[i] + '-' + d.num + '</span><h2>' + d.title + '</h2></div>' +
        '<div class="secdesc">' + (d.desc || '') + '</div><div class="simhost" id="simL_' + sid + '"></div></div>' +
        '<div class="sR" id="simR_' + sid + '"></div></article>';
    });
    h += '</section>';
  });
  h += '<div class="card purpose"><p class="lead">【目的】</p><ol>' +
    '<li>波は波源の振動が次々と伝わる現象であり、媒質の各点はその場で振動するだけであることを理解する。振幅 $A$・波長 $\\lambda$・周期 $T$・振動数 $f$・速さ $v$ の関係 $v=f\\lambda$、$f=\\dfrac{1}{T}$ を説明できるようになる。</li>' +
    '<li>$y$-$x$ グラフ（ある時刻の波形）と $y$-$t$ グラフ（ある点の振動）を読みかえられるようになる。縦波を横波のように表して、密・疎の位置を読み取れるようになる。</li>' +
    '<li>波の重ね合わせ・反射によってできる定在波と、弦・気柱の固有振動を理解する。</li>' +
    '<li>音の三要素・うなり・共鳴を、実際に音を聞きながら振動数の関係として理解する。</li></ol></div>';
  h += '<footer></footer>';
  wrap.innerHTML = h;
  document.title = '波の基礎';
  wrap.querySelectorAll('.purpose,.slownote,.modehead,.secdesc,.sechead h2,.seclinks a,.gnote').forEach(function (e) { e.innerHTML = mathify(e.innerHTML); });
  document.querySelectorAll('#hero .ideas .ie, #hero .ideas .ij, #hero .stagecap .sct').forEach(function (e) { e.innerHTML = mathify(e.innerHTML); });
  if (GLOBAL.rot) MODES.forEach(function (m) { if (m.rotSwitch) modeState(m.id).rot = true; });
  setupGlobalButtons();
  MODES.forEach(function (m) { buildModeBar(m); });
  buildToc();
  document.querySelectorAll('#tabs .tab').forEach(function (b) {
    b.addEventListener('click', function () {
      activateMode(b.dataset.mode); history.replaceState(null, '', '#' + modeHash(b.dataset.mode));
      window.scrollTo({ top: Math.min(window.pageYOffset, contentTop()), behavior: 'auto' });
    });
  });
  document.querySelectorAll('.seclinks a[data-toc]').forEach(function (a) {
    a.addEventListener('click', function (ev) { ev.preventDefault(); var sid = a.dataset.toc; history.replaceState(null, '', '#' + addrOf(sid)); scrollToSec(sid); });
  });
  window.addEventListener('hashchange', function () { gotoHash(); });
  gotoHash(true);
  if (document.fonts && document.fonts.load) {
    Promise.all(['italic 17px KaTeX_Math', '16px KaTeX_Main'].map(function (f) { return document.fonts.load(f); })).then(function () { SIMS.forEach(function (s) { s.draw(); }); alignAll(); });
  }
}

/* モードの見出しの下：「表示：力を表示」＋（モード2・3）観測者の切りかえスイッチ */
function buildModeBar(m) {
  var bar = document.getElementById('mbar_' + m.id); if (!bar) return;
  var ms = modeState(m.id);
  /* 力の表示は、各セクションの「合力のみを表示」「全ての力を個別表示」で切りかえる（モード全体のチェックはやめた。2026-10-16 千葉さん） */
  if (m.rotSwitch) {
    /* モード全体の観測者の切りかえ（各シムと同じ対のボタン。アドレスは #mode2-rot） */
    var rw = el('span', 'rotsw'); rw.appendChild(el('span', 'lbl', '全セクション：'));
    var sg = el('div', 'seg'); sg.setAttribute('role', 'group'); sg.setAttribute('aria-label', '全セクションをどの観測者から見るか');
    var b0 = el('button', 'b obs', '外（慣性系）から見る'), b1 = el('button', 'b obs rotb', '一緒に円運動する観測者（非慣性系）から見る');
    [b0, b1].forEach(function (b, i) { b.type = 'button'; b.addEventListener('click', function () { m2SetModeRot(m.id, i === 1); }); sg.appendChild(b); });
    rw.appendChild(sg); bar.appendChild(rw); ms._segb = [b0, b1];
    b0.classList.toggle('on', !ms.rot); b1.classList.toggle('on', !!ms.rot);
  }
}

function syncGlobalButtons() {
  var bE = document.getElementById('btnEq');
  bE.innerHTML = '<span class="sw" aria-hidden="true"><i></i></span><span class="swl">式・考え方エリアを閉じる</span><span class="swv">' + (GLOBAL.hideEq ? 'ON' : 'OFF') + '</span>';
  bE.setAttribute('aria-pressed', GLOBAL.hideEq ? 'true' : 'false'); bE.classList.toggle('off', !GLOBAL.hideEq);
  document.body.classList.toggle('hideeq', GLOBAL.hideEq);
  if (typeof alignAll === 'function') requestAnimationFrame(alignAll);
  var bR = document.getElementById('btnRot');
  if (bR) {
    bR.innerHTML = '<span class="sw" aria-hidden="true"><i></i></span><span class="swl">全て：一緒に円運動する観測者（非慣性系）から見る</span><span class="swv">' + (GLOBAL.rot ? 'ON' : 'OFF') + '</span>';
    bR.setAttribute('aria-pressed', GLOBAL.rot ? 'true' : 'false'); bR.classList.toggle('off', !GLOBAL.rot);
  }
}
function setupGlobalButtons() {
  var bE = document.getElementById('btnEq');
  bE.addEventListener('click', function () {
    GLOBAL.hideEq = !GLOBAL.hideEq; syncGlobalButtons();
    SIMS.forEach(function (s) { if (s.cv.offsetParent) { s.resize(); s.draw(); } });
  });
  var bR = document.getElementById('btnRot');
  if (bR) bR.addEventListener('click', function () { setGlobalRot(!GLOBAL.rot); });
  syncGlobalButtons();
}
/* 全てのモード（観測者を切りかえられるモード）の切りかえを、まとめて ON／OFF */
function setGlobalRot(on) {
  GLOBAL.rot = on;
  MODES.forEach(function (m) { if (m.rotSwitch) m2SetModeRot(m.id, on, true); });
  syncGlobalButtons();
}
/* どれか 1 つの切りかえを変えたら、右上の表示もそろえる（全部が非慣性系なら ON） */
function syncGlobalRot() {
  var rm = MODES.filter(function (m) { return m.rotSwitch; }).map(function (m) { return m.id; });
  var all = rm.every(function (id) { return !!modeState(id).rot; }) && SIMS.every(function (s) { return rm.indexOf(s.mode) < 0 || !!s.rot; });
  if (GLOBAL.rot !== all) { GLOBAL.rot = all; syncGlobalButtons(); }
}
function modeHash(mid) { var ms = modeState(mid); return mid + (ms.rot ? '-rot' : ''); }
function activateMode(id) {
  var m = MODES.find(function (x) { return x.id === id; }); if (!m) return;
  document.querySelectorAll('#tabs .tab').forEach(function (b) { b.classList.toggle('on', b.dataset.mode === id); });
  document.querySelectorAll('.mode').forEach(function (s) { s.classList.toggle('on', s.id === id); });
  document.body.classList.toggle('inm1', id === 'mode1');
  document.body.classList.toggle('inm2', id === 'mode2');            /* 文字クリックの注意はモード1 だけ */
  SIMS.forEach(function (s) { if (s.mode !== id && s.playing) { s.playing = false; s.syncPlayLabel(); } });
  if (window.AUDIO) AUDIO.stop();                                   /* 章を切りかえたら音は止める */
  if (!MODE_BUILT[id]) {
    MODE_BUILT[id] = 1;
    m.secs.forEach(function (sid) {
      var d = DEFS[sid]; if (!d) return;
      if (d.custom) { d.build(document.getElementById(sid)); return; }
      if (d.own) { SIM_BY_ID[sid] = d.own(document.getElementById('simL_' + sid), document.getElementById('simR_' + sid)); return; }   /* ②-8：表のように並べたアニメ（Sim を使わない） */
      SIM_BY_ID[sid] = new Sim(d, document.getElementById('simL_' + sid), document.getElementById('simR_' + sid));
      if (d.exam && !d.wideHead) { var R = document.getElementById('simR_' + sid), w = document.createElement('div'); w.innerHTML = examBtns(sid); R.insertBefore(w.firstChild, R.firstChild); }   /* モード④：右上に問題・解答（PDF） */
    });
  } else SIMS.forEach(function (s) { if (s.mode === id) { s.resize(); s.draw(); } });
  requestAnimationFrame(function () { requestAnimationFrame(alignAll); });
}
var hasDef = function (k) { return Object.prototype.hasOwnProperty.call(DEFS, k); };
function addrOf(sid) {
  var i = MODES.findIndex(function (x) { return x.secs.indexOf(sid) >= 0; });
  return (i < 0 || !hasDef(sid)) ? sid : (i + 1) + '-' + DEFS[sid].num;
}
/* アドレス：#mode1／#mode2／#mode2-rot（非慣性系で始める）／#1-1 のようなセクション */
function parseHash(hs) {
  hs = String(hs || '').replace('#', '');
  var m = /^(mode\d)(-rot)?$/.exec(hs);
  if (m) { var mo = MODES.find(function (x) { return x.id === m[1]; }); return mo ? { mode: mo, rot: !!m[2] } : {}; }
  var q = /^(\d+)-(\d+)$/.exec(hs);
  if (q) { var mo2 = MODES[+q[1] - 1]; if (mo2) { var sid = mo2.secs.find(function (s) { return hasDef(s) && String(DEFS[s].num) === q[2]; }); return sid ? { mode: mo2, sec: sid } : { mode: mo2 }; } }
  return {};
}
function contentTop() { var h = document.getElementById('hero'); return h ? h.offsetTop + h.offsetHeight : 0; }
function tabbarH() { var tb = document.getElementById('tabs'); if (!tb) return 0; return (getComputedStyle(tb).position === 'sticky') ? tb.getBoundingClientRect().height : 0; }
function scrollToSec(sid) {
  var go = function () { var e = document.getElementById(sid); if (!e) return; var y = e.getBoundingClientRect().top + window.pageYOffset - tabbarH() - 8; window.scrollTo({ top: Math.max(0, y), behavior: 'auto' }); };
  go(); requestAnimationFrame(function () { requestAnimationFrame(go); }); setTimeout(go, 180);
}
function buildToc() {
  var p = document.getElementById('tocpanel'), b = document.getElementById('bToc'); if (!p || !b) return;
  var h = '<div class="tochead"><b>コンテンツ一覧</b><button type="button" class="tocx" aria-label="閉じる">×</button></div>';
  MODES.forEach(function (m, i) {
    h += '<div class="tocmode">' + CIRC[i] + ' ' + m.name + '</div><ul>';
    m.secs.forEach(function (sid) { var d = DEFS[sid]; if (!d) return;
      h += '<li><a href="#' + addrOf(sid) + '" data-toc="' + sid + '">' + CIRC[i] + '-' + d.num + '　' + mathify(String(d.title).replace(/<[^>]+>/g, '')) + '</a></li>'; });
    if (!m.secs.length) h += '<li><a href="#' + m.id + '" data-tocm="' + m.id + '">（準備中）</a></li>';
    h += '</ul>';
  });
  p.innerHTML = h;
  var close = function () { p.hidden = true; b.setAttribute('aria-expanded', 'false'); };
  b.addEventListener('click', function (ev) { ev.stopPropagation(); p.hidden = !p.hidden; b.setAttribute('aria-expanded', p.hidden ? 'false' : 'true'); });
  p.querySelector('.tocx').addEventListener('click', close);
  document.addEventListener('click', function (ev) { if (!p.hidden && !p.contains(ev.target) && ev.target !== b) close(); });
  document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape') close(); });
  p.querySelectorAll('[data-toc]').forEach(function (a) {
    a.addEventListener('click', function (ev) {
      ev.preventDefault(); close();
      var sid = a.getAttribute('data-toc'), mo = MODES.find(function (x) { return x.secs.indexOf(sid) >= 0; }); if (!mo) return;
      activateMode(mo.id); history.replaceState(null, '', '#' + addrOf(sid)); scrollToSec(sid);
    });
  });
  p.querySelectorAll('[data-tocm]').forEach(function (a) {
    a.addEventListener('click', function (ev) { ev.preventDefault(); close(); activateMode(a.dataset.tocm); history.replaceState(null, '', '#' + a.dataset.tocm); window.scrollTo({ top: contentTop(), behavior: 'auto' }); });
  });
}
function gotoHash(first) {
  var q = parseHash(location.hash);
  if (!q.mode) { if (first) activateMode(MODES[0].id); return; }
  if (first && GLOBAL.rot && q.rot === false) q.rot = true;            /* ?rot=1 のときは、#mode2 などでも非慣性系で始める */
  if (q.rot !== undefined && q.mode.rotSwitch) { modeState(q.mode.id).rot = q.rot; }
  activateMode(q.mode.id);
  if (q.rot !== undefined && q.mode.rotSwitch && typeof m2SetModeRot === 'function') m2SetModeRot(q.mode.id, q.rot);
  if (q.sec) scrollToSec(q.sec);
  else if (!first) window.scrollTo({ top: contentTop(), behavior: 'auto' });
  else if (location.hash) scrollToSec(q.mode.id);
}

document.addEventListener('DOMContentLoaded', function () { buildPage(); });


