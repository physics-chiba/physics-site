/* ===== 60_m2.js ===== */
/* =========================================================================
   章 ② 波の重なり合い
   ②-1 左右の波源からの波（参考③）／②-2 波の反射（参考④）／②-3 固有振動と共振（教科書 図 39）
   ★ 波はすべて本当の式から描く（30_physics.js の M2）。見た目合わせの位相の細工はしない
   ========================================================================= */
'use strict';
var M2C = { R: '#e07b18', L: '#1663b5', S: '#1c8f4a' };     /* 右向きに進む波（入射波）・左向きに進む波（反射波）・合成波（参考③④と同じ色の分け方） */
/* 方眼（1 m ごと）。(x0, y0)〜(x1, y1)、step：1 m の画素 */
function gridPaper(ctx, x0, y0, x1, y1, step, cx, cy) {
  ctx.save(); ctx.strokeStyle = '#eef0f2'; ctx.lineWidth = 1; ctx.beginPath();
  for (var x = cx; x <= x1 + 0.5; x += step) { ctx.moveTo(Math.round(x) + 0.5, y0); ctx.lineTo(Math.round(x) + 0.5, y1); }
  for (var x2 = cx - step; x2 >= x0 - 0.5; x2 -= step) { ctx.moveTo(Math.round(x2) + 0.5, y0); ctx.lineTo(Math.round(x2) + 0.5, y1); }
  for (var y = cy; y <= y1 + 0.5; y += step) { ctx.moveTo(x0, Math.round(y) + 0.5); ctx.lineTo(x1, Math.round(y) + 0.5); }
  for (var y2 = cy - step; y2 >= y0 - 0.5; y2 -= step) { ctx.moveTo(x0, Math.round(y2) + 0.5); ctx.lineTo(x1, Math.round(y2) + 0.5); }
  ctx.stroke(); ctx.restore();
}
/* 関数 f(x)（x0m〜x1m）を線で描く */
function plotF(ctx, f, a, b, X, Y, col, lw, dash, alpha) {
  if (!(b > a)) return;
  ctx.save(); ctx.strokeStyle = col; ctx.lineWidth = lw; ctx.globalAlpha = alpha || 1; if (dash) ctx.setLineDash(dash); ctx.lineJoin = 'round'; ctx.beginPath();
  var N = Math.max(80, Math.round((X(b) - X(a)) / 1.5));
  for (var i = 0; i <= N; i++) { var x = a + (b - a) * i / N, px = X(x), py = Y(f(x)); if (i) ctx.lineTo(px, py); else ctx.moveTo(px, py); }
  ctx.stroke(); ctx.restore();
}
/* 小さな凡例（線の見本＋名前）を横に並べる。items：[{ col, dash, lw, txt }] */
/* 右寄せの凡例（右はし xr）。2026-11-05 千葉さん 7 回目：左上は「合成波を表示」のチェックの場所 */
function legendRowR(ctx, items, xr, y) {
  ctx.save(); ctx.font = '600 11px ' + FONT; var w = 0; items.forEach(function (it) { w += 27 + ctx.measureText(it.txt).width + 14; }); ctx.restore();
  legendRow(ctx, items, xr - w + 14, y);
}
/* 図の上の帯の高さ（チェックボックスと凡例の場所） */
function m2Top(W) { return W < 400 ? 70 : (W < 560 ? 54 : 38); }   /* とてもせまい画面では凡例を「合成波を表示」の下の段に（21 回目） */
function legendRow(ctx, items, x, y) {
  items.forEach(function (it) {
    ctx.save(); ctx.strokeStyle = it.col; ctx.lineWidth = it.lw || 2; if (it.dash) ctx.setLineDash(it.dash); ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 22, y); ctx.stroke(); ctx.restore();
    var b = label(ctx, it.txt, x + 27, y, { size: 11, color: COL.ink2, align: 'left' }); x = b.x + b.w + 14;
  });
}
function m2Sync(s, map) {
  map.forEach(function (p) { var b = s.extra[p[0]]; if (b) { var on = !!p[1]; b.classList.toggle('on', on); b.setAttribute('aria-pressed', on ? 'true' : 'false'); } });
}
var M2_SHAPES = [['sin', '連続波'], ['pulse', 'パルス波'], ['tri', '三角波']];
/* ウェーブマシンの玉（①-1 と同じ形）。玉は媒質そのものなので、位置は合成した変位 y(x)。玉どうしは線で結ばない（2026-11-05 千葉さん 8 回目：一度ためしに） */
function m2Beads(ctx, f, L, X, Y, SX) {
  var dx = SX < 34 ? 0.4 : 0.2, n = Math.round(L / dx);
  for (var k = 0; k <= n; k++) { var x = k * dx; bead(ctx, X(x), Y(f(x)), 4.2, WCOL.bead); }
}

/* =====================================================================
   ②-1 左右の波源からの波（参考③）
   ・ウェーブマシンの左右に波源。それぞれ 連続波／パルス波／三角波、振幅 A・振動数 f を別々に変えられる
   ・速さ v は同じ媒質なので共通（千葉さん 2026-11-03 の B）。λ = v/f
   ・既定は左右とも同じ A・f → 重なった所が定在波になる。腹・節の名札
   ===================================================================== */
function m2s1Q(s) {
  var v = s.v.v;
  return { L: M2.s1.L, v: v, A: [s.v.AL, s.v.AR], f: [s.v.fL, s.v.fR], sh: [s.shL, s.shR], lam: [v / s.v.fL, v / s.v.fR], T: [1 / s.v.fL, 1 / s.v.fR] };
}
function m2s1Geo(W, H) {
  var x0 = W < 520 ? 26 : 40, x1 = W - (W < 520 ? 22 : 34), SX = (x1 - x0) / M2.s1.L;
  return { x0: x0, x1: x1, SX: SX, cy: Math.round(H / 2) + 10, SY: SX };
}
DEFS.m2s1 = {
  id: 'm2s1', mode: 'mode2', num: 1,
  title: '左右の波源からの波', short: '左右の波源からの波',
  desc: 'ウェーブマシンに波を発生させる。2 つの波が重なると、変位は足し合わされる（<b>重ね合わせの原理</b>）。<span class="todo">同じ波が逆向きに進んで重なると、どんな波になるか見よう。</span>',
  strobe: false, stepDiv: 16,
  varCols: [['AL', 'fL'], ['AR', 'fR']], varWide: ['v'],
  varColNote: { 0: '左の波源', 1: '右の波源' },
  vars: [
    { k: 'AL', label: '振幅 $A$', aria: '左の波源の振幅', stops: M2.s1.A, prop: true, stopLabels: ['0.5', '1.0', '1.5 m'], def: 1.0, fmt: function (x) { return fmt(x, 1) + ' m'; } },
    { k: 'fL', label: '振動数 $f$', aria: '左の波源の振動数', stops: M2.s1.f, prop: true, stopLabels: ['0.25', '0.50', '0.75', '1.00 Hz'], def: 0.5, fmt: function (x) { return fmt(x, 2) + ' Hz'; } },
    { k: 'AR', label: '振幅 $A$', aria: '右の波源の振幅', stops: M2.s1.A, prop: true, stopLabels: ['0.5', '1.0', '1.5 m'], def: 1.0, fmt: function (x) { return fmt(x, 1) + ' m'; } },
    { k: 'fR', label: '振動数 $f$', aria: '右の波源の振動数', stops: M2.s1.f, prop: true, stopLabels: ['0.25', '0.50', '0.75', '1.00 Hz'], def: 0.5, fmt: function (x) { return fmt(x, 2) + ' Hz'; } },
    { k: 'v', label: '速さ $v$（左右共通：同じ媒質）', aria: '速さ', stops: M2.s1.v, prop: true, stopLabels: ['1', '2', '3', '4 m/s'], def: 2.0, fmt: function (x) { return fmt(x, 1) + ' m/s'; } }
  ],
  init: function (s) { s.shL = 'sin'; s.shR = 'sin'; s.showComp = true; s.showNodes = false; s.showDisp = false; s.showSum = false; s._nodeLink = false; s.showBead = true; },   /* 腹・節は既定 OFF。合成波を初めて ON にしたとき一緒に ON（2026-11-04 千葉さん 6 回目） */
  onDefaults: function (s) { m2s1Sync(s); },
  onChanged: function () { return 'stop'; },
  /* 波の形は左右まとめて 1 つ（2026-11-04 千葉さん 6 回目） */
  buttons: M2_SHAPES.map(function (p) { return { k: 'S_' + p[0], label: p[1], seg: 'wsh', segLabel: '波の形（左右とも）', onClick: function (s) { s.shL = p[0]; s.shR = p[0]; m2s1Sync(s); s.resetT(); } }; })
    .concat([
      /* 合成波を表示：いちばん左。既定は OFF で、押されるまで光らせる（2026-11-03 千葉さん 5 回目） */
      { k: 'sum', label: '合成波を表示', cls: 'chkb', onClick: function (s) { s.showSum = !s.showSum; s._sumT = true; if (s.showSum && !s._nodeLink) { s.showNodes = true; s._nodeLink = true; } m2s1Sync(s); s.draw(); } },
      { k: 'comp', label: '元の 2 つの波を表示', cls: 'chkb', onClick: function (s) { s.showComp = !s.showComp; m2s1Sync(s); s.draw(); } },
      { k: 'node', label: '腹・節を表示', cls: 'chkb', onClick: function (s) { s.showNodes = !s.showNodes; m2s1Sync(s); s.draw(); } },
      { k: 'disp', label: '変位を表示', cls: 'chkb', onClick: function (s) { s.showDisp = !s.showDisp; m2s1Sync(s); s.draw(); } },   /* ②-2 と同じ（2026-11-03 千葉さん 3 回目） */
      { k: 'bead', label: 'ウェーブマシンの玉を表示', cls: 'chkb', onClick: function (s) { s.showBead = !s.showBead; m2s1Sync(s); s.draw(); } }
    ]),
  tEnd: function (s) {
    var q = m2s1Q(s), t1 = 0;
    [0, 1].forEach(function (i) { t1 = Math.max(t1, q.sh[i] === 'sin' ? q.L / q.v + 6 * q.T[i] : q.L / q.v + q.T[i] / 2 + 0.6); });
    return Math.max(t1, (q.sh[0] === 'sin' || q.sh[1] === 'sin') ? 16 : 0);
  },
  tInfo: function (s) { return s.shL === 'sin' ? periodInfo(m2s1Q(s).T[0]) : ''; },   /* パルスには周期がない */
  gT: function (s) { return m2s1Q(s).T[0]; },
  height: function (s, w) { var g = m2s1Geo(w, 300); return Math.round(2 * 3.3 * g.SY + 60 + 2 * (m2Top(w) - 22)); },
  afterBuild: function (s) {
    /* チェック（合成波・元の 2 つ・腹節・変位）→ 波の形 → すべて最初の設定に戻す の順 */
    var seg = s.row1b.querySelector('.seg'), aft = s.extra.bead;
    [seg, s.bDef].forEach(function (e) { aft.insertAdjacentElement('afterend', e); aft = e; });
    s.cw.appendChild(s.extra.sum); s.extra.sum.classList.add('sumov');   /* 「合成波を表示」は図の左上（大きめ。2026-11-05 千葉さん 7 回目） */
    seg.classList.add('small');
    s.R.innerHTML = ''; var sw = el('div', 'row2 sliders inR'); sw.appendChild(s.varbox); s.R.appendChild(sw); s.varbox.classList.add('inR');
    s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);
    m2s1Sync(s);
  },
  draw: function (s, ctx, W, H) { drawM2S1(s, ctx, W, H); },
  right: function (s, R) { rightM2S1(s, R); }
};
function m2s1Sync(s) {
  var a = M2_SHAPES.map(function (p) { return ['S_' + p[0], s.shL === p[0]]; });
  m2Sync(s, a.concat([['sum', s.showSum], ['comp', s.showComp], ['node', s.showNodes], ['disp', s.showDisp], ['bead', s.showBead]]));
  if (s.extra.sum) s.extra.sum.classList.toggle('fglow', !s._sumT && !s.showSum);
  if (s.Rdyn) s.renderRight();
}
/* 定在波になっているか（左右とも連続波で、振幅・振動数が同じ） */
function m2s1Standing(q) { return q.sh[0] === 'sin' && q.sh[1] === 'sin' && Math.abs(q.A[0] - q.A[1]) < 1e-9 && Math.abs(q.f[0] - q.f[1]) < 1e-9; }
function drawM2S1(s, ctx, W, H) {
  var g = m2s1Geo(W, H), q = m2s1Q(s), t = s.t;
  var X = function (x) { return g.x0 + x * g.SX; }, Y = function (y) { return g.cy - y * g.SY; };
  var yR = function (x) { return M2.right(q.sh[0], q.A[0], q.f[0], q.v, x, t); }, yL = function (x) { return M2.left(q.sh[1], q.A[1], q.f[1], q.v, q.L, x, t); };
  gridPaper(ctx, g.x0, m2Top(W), g.x1, H - 6, g.SX, g.x0, g.cy);
  ctx.save(); ctx.strokeStyle = '#9aa1ab'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(g.x0, g.cy); ctx.lineTo(g.x1, g.cy); ctx.stroke(); ctx.restore();
  /* 腹・節（定在波のとき、2 つの波がどちらも届いている所だけ） */
  var both0 = Math.max(0, q.L - q.v * t), both1 = Math.min(q.L, q.v * t), st = m2s1Standing(q);
  if (s.showNodes && st && both1 > both0) {
    M2.nodes(q.L, q.lam[0]).forEach(function (n) {
      if (n.x < both0 - 1e-9 || n.x > both1 + 1e-9) return;
      var px = X(n.x);
      if (n.k === 'node') { ctx.save(); ctx.strokeStyle = '#7a4fb8'; ctx.lineWidth = 2; ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(px, g.cy, 5, 0, TAU); ctx.fill(); ctx.stroke(); ctx.restore(); label(ctx, '節', px, g.cy + 2 * q.A[0] * g.SY + 16, { size: 12, bold: true, color: '#5a2f99' }); }
      else { dotted(ctx, px, Y(2 * q.A[0]) - 4, px, Y(-2 * q.A[0]) + 4, 'rgba(28,143,74,.45)', [3, 3]); label(ctx, '腹', px, Y(2 * q.A[0]) - 14, { size: 12, bold: true, color: '#14653a' }); }
    });
  }
  /* 元の 2 つの波（届いている所だけ）と合成波 */
  if (s.showComp) {
    plotF(ctx, yR, 0, Math.min(q.L, q.v * t), X, Y, M2C.R, 2, [7, 4]);
    plotF(ctx, yL, Math.max(0, q.L - q.v * t), q.L, X, Y, M2C.L, 2, [7, 4]);
  }
  if (s.showSum) plotF(ctx, function (x) { return yR(x) + yL(x); }, 0, q.L, X, Y, M2C.S, 3.2);
  if (s.showBead) m2Beads(ctx, function (x) { return yR(x) + yL(x); }, q.L, X, Y, g.SX);
  /* 変位を表示：1 m ごとに、右向きの波（橙）・左向きの波（青）・合成波（緑）の変位を矢印で（②-2 と同じ。少しずつ横にずらす） */
  if (s.showDisp) for (var xd = 1; xd <= q.L - 0.5; xd += 1) {
    var da = yR(xd), db = yL(xd), dc = da + db, pxd = X(xd);
    if (s.showComp && Math.abs(da) > 0.02) vArrow2(ctx, pxd - 6, g.cy, Y(da), M2C.R, 2);
    if (s.showComp && Math.abs(db) > 0.02) vArrow2(ctx, pxd + 6, g.cy, Y(db), M2C.L, 2);
    if (s.showSum && Math.abs(dc) > 0.02) vArrow2(ctx, pxd, g.cy, Y(dc), M2C.S, 2.4);
  }
  /* 左右の波源（上下に動く板） */
  [[0, M2.right(q.sh[0], q.A[0], q.f[0], q.v, 0, t) + yL(0)], [q.L, yR(q.L) + M2.left(q.sh[1], q.A[1], q.f[1], q.v, q.L, q.L, t)]].forEach(function (p, i) {
    var px = X(p[0]), py = Y(p[1]);
    ctx.save(); ctx.fillStyle = i ? M2C.L : M2C.R; rrect(ctx, px - 6, py - 10, 12, 20, 3); ctx.fill(); ctx.restore();   /* 波源も色分け（左＝橙・右＝青） */
    label(ctx, i ? '右の波源' : '左の波源', px, H - 12, { size: 11, bold: true, color: i ? M2C.L : M2C.R });
  });
  var nar = W < 560;
  legendRowR(ctx, [{ col: M2C.R, dash: [7, 4], txt: nar ? '右向き' : '右向きに進む波' }, { col: M2C.L, dash: [7, 4], txt: nar ? '左向き' : '左向きに進む波' }, { col: M2C.S, lw: 3, txt: '合成波' }], g.x1, W < 400 ? 60 : (nar ? 42 : 14));
  label(ctx, '1 目盛り 1 m', (g.x0 + g.x1) / 2, H - 12, { size: 10.5, color: COL.sub });
  if (s.showNodes && !st && both1 > both0 + 0.5 && q.sh[0] === 'sin' && q.sh[1] === 'sin')
    bubble(ctx, '振幅か振動数が違うと、止まったままの点（節）はできない', X(q.L / 2), Y(-(q.A[0] + q.A[1])) + 8, { size: 11.5, side: 'up' });
}
function rightM2S1(s, R) {
  var q = m2s1Q(s), st = m2s1Standing(q);
  var h = '<div class="qcard"><p class="qt">重ね合わせと定在波</p>' +
    '<p><b>重ね合わせの原理</b>：2 つの波が重なると、変位は足し合わされる。$y = y_1 + y_2$　重なり終わると、それぞれの波は元の形のまま進む（波の独立性）。</p>' +
    '<p>振幅・波長（振動数）が同じで、逆向きに進む 2 つの波が重なると、どちらにも進まない波ができる。これを<b>定在波</b>という。</p>' +
    '<table class="reltab grid1"><tbody>' +
    '<tr><th>節</th><td class="l">まったく振動しない点。となりの節との間隔は $\\dfrac{\\lambda}{2}$</td></tr>' +
    '<tr><th>腹</th><td class="l">最も大きく振動する点。振幅は $2A$</td></tr></tbody></table>' +
    '<p>定在波に対して、ふつうに進む波を<b>進行波</b>という。</p>';
  if (st) h += '<p class="qnow"><span class="qtag now">いま</span>$\\lambda = \\dfrac{v}{f} = \\dfrac{' + fmt(q.v, 1) + '}{' + fmt(q.f[0], 2) + '} = ' + sig(q.lam[0], 2) + '$ m なので、節の間隔 $\\dfrac{\\lambda}{2} = ' + sig(q.lam[0] / 2, 2) + '$ m、腹の振幅 $2A = ' + fmt(2 * q.A[0], 1) + '$ m</p>';
  else h += '<p class="qnow"><span class="qtag now">いま</span>左右の波の形・振幅・振動数のどれかが違うので、きれいな定在波にはならない。</p>';
  h += '</div>';
  R.innerHTML = mathify(h);
}

/* =====================================================================
   ②-2 波の反射（固定端反射と自由端反射）（参考④）
   ・左から来る入射波（橙）が右端で反射し、反射波（青）になる。合成波（緑）
   ・端の向こうへ延ばした「仮想の波」：自由端＝そのまま折り返す／固定端＝上下を逆にして折り返す（ステップ表示）
   ・入射波の形：正弦波／パルス／三角パルス。「変位を表示」
   ===================================================================== */
var M2S2_STEPS = ['① 入射波を、端の向こうへそのまま延ばす', '② 延ばした波の上下を逆にする（固定端）', '③ 端を軸にして折り返す → 反射波', '④ 入射波と反射波を足す → 合成波'];
var M2S2_STEPS_FREE = ['① 入射波を、端の向こうへそのまま延ばす', '② 自由端では、延ばした波をそのまま使う', '③ 端を軸にして折り返す → 反射波', '④ 入射波と反射波を足す → 合成波'];
function m2s2Q(s) { return { L: M2.s2.L, ext: M2.s2.ext, v: M2.s2.v, A: M2.s2.A, f: M2.s2.f, T: 1 / M2.s2.f, lam: M2.s2.v / M2.s2.f, sh: s.sh, fixed: s.fixed }; }
function m2s2Geo(W, H) {
  var x0 = W < 520 ? 16 : 30, x1 = W - 14, SX = (x1 - x0) / (M2.s2.L + M2.s2.ext);
  return { x0: x0, x1: x1, SX: SX, cy: Math.round(H / 2) + 12, SY: SX };
}
DEFS.m2s2 = {
  id: 'm2s2', mode: 'mode2', num: 2,
  title: '波の反射（固定端反射と自由端反射）', short: '波の反射',
  desc: '端で反射した<b>反射波</b>が<b>入射波</b>と重なる。<span class="todo">固定端・自由端を切り替え（端をクリックしても切り替わる）、反射波の作図も確かめよう。</span>',
  strobe: false, stepDiv: 16,
  init: function (s) { s.sh = 'sin'; s.fixed = true; s.showDisp = false; s.stp = 0; s.showSum = false; s.showComp = true; s.showNodes = false; s.showVirt = false; s._nodeLink = false; s.showBead = true; },   /* 既定は連続波（2026-11-03 千葉さん 3 回目） */
  onDefaults: function (s) { m2s2Sync(s); },
  onReset: function (s) { if (s.stp) { s.stp = 0; m2s2Sync(s); } },
  buttons: [
    { k: 'fix', label: '固定端', seg: 'end', segLabel: '端のようす', onClick: function (s) { s.fixed = true; m2s2Sync(s); s.draw(); } },
    { k: 'free', label: '自由端', seg: 'end', onClick: function (s) { s.fixed = false; m2s2Sync(s); s.draw(); } }
  ].concat(M2_SHAPES.map(function (p) { return { k: 'S_' + p[0], label: p[0] === 'sin' ? '連続波' : (p[0] === 'pulse' ? 'パルス' : '三角パルス'), seg: 'shape', segLabel: '入射波の形', onClick: function (s) { s.sh = p[0]; m2s2Sync(s); s.resetT(); } }; }))
    .concat([
      /* ②-1 と同じチェック（2026-11-03 千葉さん 5 回目）。合成波は既定 OFF・押されるまで光る */
      { k: 'sum', label: '合成波を表示', cls: 'chkb', onClick: function (s) { s.showSum = !s.showSum; s._sumT = true; if (s.showSum && !s._nodeLink) { s.showNodes = true; s._nodeLink = true; } m2s2Sync(s); s.draw(); } },
      { k: 'comp', label: '入射波・反射波を表示', cls: 'chkb', onClick: function (s) { s.showComp = !s.showComp; m2s2Sync(s); s.draw(); } },
      { k: 'node', label: '腹・節を表示', cls: 'chkb', onClick: function (s) { s.showNodes = !s.showNodes; m2s2Sync(s); s.draw(); } },
      { k: 'disp', label: '変位を表示', cls: 'chkb', onClick: function (s) { s.showDisp = !s.showDisp; m2s2Sync(s); s.draw(); } },
      { k: 'bead', label: 'ウェーブマシンの玉を表示', cls: 'chkb', onClick: function (s) { s.showBead = !s.showBead; m2s2Sync(s); s.draw(); } },
      { k: 'stp', label: '反射波の<br>作図の手順を見る', cls: 'stepgo two', onClick: function (s) { m2s2Step(s, s.stp ? 0 : 1); } }
    ]),
  tEnd: function (s) { var q = m2s2Q(s); return q.sh === 'sin' ? 2 * q.L / q.v + 6 * q.T : 2 * q.L / q.v + q.T / 2 + 0.5; },
  tInfo: function (s) { return s.sh === 'sin' ? periodInfo(m2s2Q(s).T) : ''; },
  gT: function (s) { return m2s2Q(s).T; },
  height: function (s, w) { var g = m2s2Geo(w, 300); return Math.round(2 * 2.4 * g.SY + 70 + 2 * (m2Top(w) - 22)); },
  afterBuild: function (s) {
    var segs = s.row1b.querySelectorAll('.seg');
    if (segs[0]) segs[0].insertAdjacentElement('beforebegin', el('span', 'seglbl', '端'));
    if (segs[1]) segs[1].insertAdjacentElement('beforebegin', el('span', 'seglbl', '入射波の形'));
    var bar = el('div', 'stepbar oncv'); s.stepBar = bar;
    var bp = el('button', 'b', '◀ 前へ'), sn = el('span', 'stepn', ''), bn = el('button', 'b', '次へ ▶'), bx = el('button', 'b', '作図を終わる');
    [bp, bn, bx].forEach(function (b) { b.type = 'button'; bar.appendChild(b); });
    bar.insertBefore(sn, bn);
    bp.addEventListener('click', function () { m2s2Step(s, Math.max(1, s.stp - 1)); });
    bn.addEventListener('click', function () { m2s2Step(s, Math.min(4, s.stp + 1)); });
    bx.addEventListener('click', function () { m2s2Step(s, 0); });
    s.stepBtns = { bp: bp, bn: bn, sn: sn }; s.cw.appendChild(bar);
    /* 「変位を表示」は下の段（作図の手順を見る のとなり）へ */
    var br = el('span', 'rowbrk'); s.extra.stp.insertAdjacentElement('beforebegin', br);
    var aft = br; ['comp', 'node', 'disp', 'bead'].forEach(function (k) { aft.insertAdjacentElement('afterend', s.extra[k]); aft = s.extra[k]; });
    s.cw.appendChild(s.extra.sum); s.extra.sum.classList.add('sumov');   /* 「合成波を表示」は図の左上（②-1 と同じ） */
    var sl2 = s.row1b.querySelectorAll('.seglbl')[1]; if (sl2) sl2.classList.add('mgl2');   /* 「入射波の形」を 2 マス右へ */
    /* 端（固定端・自由端の線）をクリックしても切りかわる */
    s.cv.addEventListener('click', function (ev) {
      var r = s.cv.getBoundingClientRect(), g = m2s2Geo(s.W, s.H), xe = g.x0 + M2.s2.L * g.SX;
      if (Math.abs(ev.clientX - r.left - xe) < 16) { s.fixed = !s.fixed; m2s2Sync(s); s.draw(); }
    });
    s.cv.addEventListener('pointermove', function (ev) { var r = s.cv.getBoundingClientRect(), g = m2s2Geo(s.W, s.H), xe = g.x0 + M2.s2.L * g.SX; s.cv.style.cursor = Math.abs(ev.clientX - r.left - xe) < 16 ? 'pointer' : 'default'; });
    /* 「作図のために壁の右の波を表示する」：端の向こうの名前があった所に重ねる。既定は表示しない */
    var vb = el('button', 'b virtbtn two', '作図のために<br>壁の右の波を表示する'); vb.type = 'button';
    vb.addEventListener('click', function () { s.showVirt = !s.showVirt; m2s2Sync(s); s.draw(); });
    s.cw.appendChild(vb); s.virtBtn = vb;
    s.Rdyn = s.R;
    m2s2Sync(s);
  },
  draw: function (s, ctx, W, H) { drawM2S2(s, ctx, W, H); },
  right: function (s, R) { rightM2S2(s, R); }
};
function m2s2Step(s, n) {
  if ((n === 3 && s.stp === 2) || (n === 2 && s.stp === 1)) s.animS = { n: n, t0: performance.now() };   /* ③ 折り返す・② 上下を逆にする をアニメで（2026-11-03 千葉さん 3 回目） */
  else s.animS = null;
  s.stp = n;
  if (n) {
    if (s.playing) { s.playing = false; s.syncPlayLabel(); }
    var q = m2s2Q(s);
    if (s.t < 1e-9 || !M2.reflecting(q, s.t)) s.t = q.sh === 'sin' ? q.L / q.v + 1.25 * q.T : q.L / q.v + q.T * 0.35;   /* 反射が起こっている時刻で作図する（パルスは大部分が端の向こうへ出た時刻） */
  }
  m2s2Sync(s); s.draw();
}
function m2s2Sync(s) {
  if (s.extra.sum) s.extra.sum.classList.toggle('fglow', !s._sumT && !s.showSum);
  if (s.virtBtn) { s.virtBtn.classList.toggle('on', !!s.showVirt); s.virtBtn.innerHTML = s.showVirt ? '壁の右の波を<br>消す' : '作図のために<br>壁の右の波を表示する'; s.virtBtn.style.visibility = s.stp ? 'hidden' : 'visible'; }
  var a = [['fix', s.fixed], ['free', !s.fixed], ['disp', s.showDisp], ['sum', s.showSum], ['comp', s.showComp], ['node', s.showNodes], ['bead', s.showBead]].concat(M2_SHAPES.map(function (p) { return ['S_' + p[0], s.sh === p[0]]; }));
  m2Sync(s, a);
  var sb = s.extra.stp; if (sb) { sb.innerHTML = s.stp ? '作図の手順を<br>閉じる' : '反射波の<br>作図の手順を見る'; sb.classList.toggle('on', !!s.stp); }
  if (s.stepBar) { s.stepBar.style.visibility = s.stp ? 'visible' : 'hidden'; s.stepBtns.sn.textContent = s.stp ? s.stp + ' / 4' : ''; s.stepBtns.bp.disabled = s.stp <= 1; s.stepBtns.bn.disabled = s.stp >= 4; }
  if (s.R) s.renderRight();
}
function drawM2S2(s, ctx, W, H) {
  var g = m2s2Geo(W, H), q = m2s2Q(s), t = s.t, st = s.stp;
  var X = function (x) { return g.x0 + x * g.SX; }, Y = function (y) { return g.cy - y * g.SY; };
  var yi = function (x) { return M2.inc(q, x, t); }, yv = function (x) { return M2.virt(q, x, t); }, yr = function (x) { return M2.refl(q, x, t); };
  var xe = X(q.L);
  /* 端の向こう（仮想の領域）はうすくぬる */
  var gt = m2Top(W);
  ctx.save(); ctx.fillStyle = 'rgba(224,123,24,.07)'; ctx.fillRect(xe, gt, g.x1 - xe, H - gt - 6); ctx.restore();
  gridPaper(ctx, g.x0, gt, g.x1, H - 6, g.SX, xe, g.cy);
  ctx.save(); ctx.strokeStyle = '#9aa1ab'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(g.x0, g.cy); ctx.lineTo(g.x1, g.cy); ctx.stroke(); ctx.restore();
  /* 端（固定端：壁にとめてある／自由端：輪が棒にそって自由に動く） */
  ctx.save(); ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 2.2; ctx.setLineDash([6, 4]); ctx.beginPath(); ctx.moveTo(xe, gt + 4); ctx.lineTo(xe, H - 10); ctx.stroke(); ctx.restore();
  label(ctx, q.fixed ? '固定端' : '自由端', xe, H - 12, { size: 12, bold: true, color: COL.ink });
  if (st || s.showVirt) label(ctx, '壁の向こう（仮想の波）', (xe + g.x1) / 2, st ? gt + 12 : gt + 48, { size: 10.5, color: '#9c4e06' });
  var full = !st, virt = st || s.showVirt, comp = st || s.showComp;  /* ステップ表示のときは、手順ごとに出すものを決める */
  if (s.virtBtn) { var vl = Math.round(Math.min(W - s.virtBtn.offsetWidth - 6, Math.max(xe + 8, (xe + g.x1) / 2 - s.virtBtn.offsetWidth / 2))); if (s.virtBtn._l !== vl) { s.virtBtn._l = vl; s.virtBtn.style.left = vl + 'px'; } }
  /* 腹・節（連続波で、入射波と反射波が重なっている所） */
  if (!st && s.showNodes && q.sh === 'sin') m2s2Nodes(ctx, q, t, X, Y, g);
  /* ① 入射波（実際の所は実線、端の向こうは点線で延ばす） */
  if (comp) plotF(ctx, yi, 0, q.L, X, Y, M2C.R, 2.2, null, full || st >= 1 ? 1 : 0);
  if ((full && virt) || st >= 1) plotF(ctx, function (x) { return M2.incExt(q, x, t); }, q.L, q.L + q.ext, X, Y, M2C.R, 1.8, [6, 4], st === 2 && q.fixed ? 0.35 : 0.9);
  /* ② 延ばした波（固定端は上下を逆に）。③ 端を軸に折り返したものが反射波
     作図の ②・③ に進んだときは、ひっくり返す・折り返すようすを 1.4 秒のアニメで（端の線を軸に回すように見せる） */
  var an = s.animS && s.animS.n === st ? clamp((performance.now() - s.animS.t0) / 1400, 0, 1) : 1;
  if (an < 1) { var self = s; requestAnimationFrame(function () { if (self.animS) self.draw(); }); }
  else if (s.animS) s.animS = null;
  var ease = an < 0.5 ? 2 * an * an : 1 - 2 * (1 - an) * (1 - an), cth = Math.cos(Math.PI * ease);
  if (st === 2 && an < 1 && q.fixed) plotF(ctx, function (x) { return cth * M2.incExt(q, x, t); }, q.L, q.L + q.ext, X, Y, M2C.L, 1.8, [3, 3], 0.95);   /* 上下に回して逆さに */
  else if ((full && virt) || st >= 2) plotF(ctx, yv, q.L, q.L + q.ext, X, Y, M2C.L, 1.8, [3, 3], st === 3 && an < 1 ? 0.45 : 0.95);
  if (st === 3 && an < 1) {                                        /* 端の線を軸に、紙を折るように回す：x → L + (x − L) cos θ */
    ctx.save(); ctx.strokeStyle = M2C.L; ctx.lineWidth = 2.2; ctx.beginPath();
    for (var ia = 0; ia <= 240; ia++) { var xa = q.L + q.ext * ia / 240, pxa = X(q.L + (xa - q.L) * cth), pya = Y(yv(xa)); if (ia) ctx.lineTo(pxa, pya); else ctx.moveTo(pxa, pya); }
    ctx.stroke(); ctx.restore();
    spinArrow(ctx, xe, 52, 24, 8, -Math.PI * 0.15, -Math.PI * 0.85, M2C.L, 1.6);
  } else if ((full && comp) || st >= 3) plotF(ctx, yr, 0, q.L, X, Y, M2C.L, 2.2);
  /* ④ 合成波 */
  if ((full && s.showSum) || st >= 4) plotF(ctx, function (x) { return yi(x) + yr(x); }, 0, q.L, X, Y, M2C.S, 3.4);
  if (full && s.showBead) m2Beads(ctx, function (x) { return yi(x) + yr(x); }, q.L, X, Y, g.SX);   /* 作図の手順のときは出さない */
  /* 変位を表示：1 m ごとに、入射波（橙）・反射波（青）・合成波（緑）の変位を矢印で（少しずつ横にずらす） */
  if (s.showDisp && (full || st >= 4)) for (var x = 1; x <= q.L - 0.5; x += 1) {
    var a = yi(x), b = yr(x), c = a + b, px = X(x);
    if (comp && Math.abs(a) > 0.02) vArrow2(ctx, px - 6, g.cy, Y(a), M2C.R, 2);
    if (comp && Math.abs(b) > 0.02) vArrow2(ctx, px + 6, g.cy, Y(b), M2C.L, 2);
    if ((s.showSum || st >= 4) && Math.abs(c) > 0.02) vArrow2(ctx, px, g.cy, Y(c), M2C.S, 2.4);
  }
  /* 端の点の変位 */
  var ye = yi(q.L) + yr(q.L);
  ctx.save(); ctx.fillStyle = q.fixed ? '#2b323c' : '#fff'; ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(xe, Y(ye), 5, 0, TAU); ctx.fill(); ctx.stroke(); ctx.restore();
  legendRowR(ctx, [{ col: M2C.R, txt: '入射波' }, { col: M2C.L, txt: '反射波' }, { col: M2C.S, lw: 3, txt: '合成波' }], g.x1, W < 400 ? 60 : (W < 560 ? 42 : 14));
  if (st) {
    stepHead(ctx, (q.fixed ? M2S2_STEPS : M2S2_STEPS_FREE)[st - 1], 8, gt + 4);
    var calls = ['① 端をこえても進み続けたと考えて、入射波をそのまま延ばす（橙の点線）',
      q.fixed ? '② 固定端：延ばした波の上下を逆にする（青の点線）' : '② 自由端：延ばした波をそのまま使う（青の点線）',
      '③ 端の線を軸に左右に折り返すと、反射波（青の実線）になる',
      q.fixed ? '④ 固定端では、端の合成波の変位はいつも 0' : '④ 自由端では、端の合成波の変位は入射波の 2 倍になる'];
    /* 引き出し線の先：端の向こうの波（①②）・反射波（③）のいちばん大きい所、④は端の点 */
    var xm = q.L + 0.02, best = 0;
    for (var xx = q.L; xx <= q.L + q.ext; xx += 0.02) { var vv = Math.abs(M2.incExt(q, xx, t)); if (vv > best + 1e-9) { best = vv; xm = xx; } }
    var tx = st <= 2 ? X(xm) : (st === 3 ? X(2 * q.L - xm) : xe);
    var ty = st <= 2 ? Y(st === 1 ? M2.incExt(q, xm, t) : yv(xm)) : (st === 3 ? Y(yr(2 * q.L - xm)) : Y(ye));
    stepCallout(ctx, calls[st - 1], X(q.L * 0.08), H - 40, tx, ty, W - 30);
  }
}
/* ②-2 の腹・節：固定端は端が節、自由端は端が腹。となりの節の間は λ/2。反射波が届いている所（x ≧ 2L − vt）だけ */
function m2s2Nodes(ctx, q, t, X, Y, g) {
  var from = Math.max(0, 2 * q.L - q.v * t); if (from >= q.L) return;
  for (var n = 0; n < 40; n++) {
    var xn = q.L - (q.fixed ? 0 : q.lam / 4) - n * q.lam / 2, xa = q.L - (q.fixed ? q.lam / 4 : 0) - n * q.lam / 2;
    if (xn >= from - 1e-9 && xn >= 0) { var px = X(xn); ctx.save(); ctx.strokeStyle = '#7a4fb8'; ctx.lineWidth = 2; ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(px, g.cy, 5, 0, TAU); ctx.fill(); ctx.stroke(); ctx.restore(); var endN = xn > q.L - 0.05; label(ctx, '節', px - (endN ? 14 : 0), endN ? g.cy - 16 : g.cy + 2 * q.A * g.SY + 16, { size: 12, bold: true, color: '#5a2f99' }); }
    if (xa >= from - 1e-9 && xa >= 0) { var pa = X(xa); dotted(ctx, pa, Y(2 * q.A) - 4, pa, Y(-2 * q.A) + 4, 'rgba(28,143,74,.45)', [3, 3]); label(ctx, '腹', pa - (xa > q.L - 0.05 ? 14 : 0), Y(2 * q.A) - 14, { size: 12, bold: true, color: '#14653a' }); }
    if (xn < 0 && xa < 0) break;
  }
}
function rightM2S2(s, R) {
  var q = m2s2Q(s);
  var h = '<div class="qcard"><p class="qt">固定端反射と自由端反射</p>' +
    '<table class="reltab grid1"><thead><tr><th></th><th>固定端</th><th>自由端</th></tr></thead><tbody>' +
    '<tr><th>端のようす</th><td>動けない</td><td>自由に動ける</td></tr>' +
    '<tr><th>反射波</th><td>上下が逆になる<br>（山 → 谷）</td><td>そのまま<br>（山 → 山）</td></tr>' +
    '<tr><th>端の合成波</th><td>いつも 0（節）</td><td>入射波の 2 倍（腹）</td></tr></tbody></table>' +
    '<p><b>反射波の作図</b>：入射波を端の向こうへ延ばし、固定端なら上下を逆にしてから、端を軸に折り返す（自由端ならそのまま折り返す）。</p>' +
    '<p>連続した正弦波が反射すると、入射波と反射波が重なって<b>定在波</b>ができる。固定端は節、自由端は腹になる。</p>' +
    '<p class="qnow"><span class="qtag now">いま</span>' + (q.fixed ? '固定端' : '自由端') + '。$\\lambda = ' + fmt(q.lam, 1) + '$ m、$v = ' + fmt(q.v, 1) + '$ m/s</p></div>';
  R.innerHTML = mathify(h);
}

/* =====================================================================
   ②-3 固有振動と共振（教科書 図 39 弦の振動）
   ・両端が固定端の糸。「糸をはじく」：はじいた所から両側へ波が出て、両端で反射し、逆向きの波が重なって定在波になる
     （両端固定のダランベールの解：初めの形を奇関数で周期的に延長し、右向き・左向きの半分ずつの和）
   ・「だんだん張力を大きくしてはじく」：張力とともに v が大きくなる。速くなると、目（カメラ）には振動が重なって見え、
     実際の弦のように基本振動などが見える（倍音ほど早く減衰する：各固有振動に減衰をつけた和で描く）
   ===================================================================== */
function m2s3Q(s) { var v = Math.pow(10, s.v.lv); return { l: M2.s3.l, v: v, f1: v / (2 * M2.s3.l), xp: s.xp, h0: M2.s3.h0, w: s.pmode === 'ramp' ? 0 : 0.12 * M2.s3.l }; }
function m2s3Geo(W, H) { var x0 = W < 520 ? 24 : 44, x1 = W - (W < 520 ? 24 : 44); return { x0: x0, x1: x1, SX: (x1 - x0) / M2.s3.l, cy: Math.round(H * 0.5) + 6, SY: clamp(H * 0.30, 50, 96) / M2.s3.h0 }; }
var M2S3_V = [1, 2, 5, 10, 20, 50, 100, 200];
var M2S3_DF = [1, 1.5, 2, 2.5, 3];                                   /* 振動子の振動数（基本振動数 f₁ の何倍か） */
var M2S3_R = 0.9, M2S3_A = 0.0025;                                  /* 往復ごとの振幅の割合・振動子の振幅〔m〕 */
DEFS.m2s3 = {
  id: 'm2s3', mode: 'mode2', num: 3,
  title: '固有振動と共振', short: '固有振動と共振',
  desc: '両端を固定した糸では、両端が節の定在波（<b>固有振動</b>）だけが残る（詳しくは <a class="xlink" href="#3-3">③-3</a>）。<span class="todo">パルス波・連続波を起こして、共振を確かめよう。</span>',
  strobe: false, stepDiv: 16,
  varCols: [['lv']],
  vars: [
    { k: 'lv', label: '張力を変える → 速さ $v$', aria: '糸を伝わる波の速さ', stops: M2S3_V.map(function (v) { return Math.log(v) / Math.LN10; }), prop: true, stopLabels: ['1', '', '', '10', '', '', '100 m/s', ''], def: 0,
      fmt: function (x) { var v = Math.pow(10, x); return (v < 10 ? fmt(v, 0) : fmt(v, 0)) + ' m/s'; } }
  ],
  init: function (s) { s.xp = 0.3 * M2.s3.l; s.pmode = 'pluck'; s.showComp = true; s.ramp = null; s.dm = 1; },
  onDefaults: function (s) { s.pmode = 'pluck'; s.ramp = null; s.dm = 1; m2s3Sync(s); },
  onReset: function (s) { if (s.ramp) { s.ramp = null; s.setBusy(false); } if (!s._keepMode) s.pmode = 'pluck'; s._keepMode = false; s.tPl = 0; m2s3Sync(s); },
  onChanged: function (s) { if (s.pmode === 'ramp') return 'keepT'; s._keepMode = true; return 'stop'; },   /* 張力を変えても、連続波・パルス波の選択はそのまま（2026-11-07 千葉さん 15 回目） */
  buttons: [
    { k: 'pl', label: 'パルス波を起こす', cls: 'plk', afterPlay: false, onClick: function (s) { m2s3Pluck(s, 'pluck'); } },
    /* 「だんだん張力を大きくしてはじく」はやめて、「糸に連続波を起こす」（2026-11-03 千葉さん 5 回目） */
    { k: 'rp', label: '連続波を起こす', cls: 'plk', onClick: function (s) { m2s3Pluck(s, 'drive'); } },
    { k: 'cmp', label: '右向き・左向きの波を表示', cls: 'chkb', onClick: function (s) { s.showComp = !s.showComp; m2s3Sync(s); s.draw(); } }
  ],
  tEnd: function (s) { return s.pmode === 'drive' ? 24 : 12; },
  tInfo: function (s) { return '<span class="tpl">基本振動数</span><b>' + tex('f_1 =') + ' ' + sig(m2s3Q(s).f1, 2) + '</b> Hz'; },
  gT: function (s) { return 1 / m2s3Q(s).f1; },
  height: function (s, w) { return Math.round(clamp(w * 0.42, 230, 300)); },
  /* だんだん張力を大きくするとき：v を 1 → 200 m/s へ（対数で同じ割合ずつ）。1.6 秒ごとにはじき直す */
  beforeStep: function (s, t0, t1) {
    if (s.pmode !== 'ramp') return;
    var lv = clamp(Math.log(200) / Math.LN10 * Math.min(1, t1 / 12), 0, Math.log(200) / Math.LN10);
    s.v.lv = lv;
    if (Math.floor(t1 / 1.6) !== Math.floor(t0 / 1.6)) s.tPl = Math.floor(t1 / 1.6) * 1.6;
  },
  afterBuild: function (s) {
    s.R.innerHTML = ''; var sw = el('div', 'row2 sliders inR'); sw.appendChild(s.varbox); s.R.appendChild(sw); s.varbox.classList.add('inR');
    s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);
    /* 糸の上をクリック：その場所をはじく */
    s.cv.addEventListener('click', function (ev) {
      var r = s.cv.getBoundingClientRect(), g = m2s3Geo(s.W, s.H), x = (ev.clientX - r.left - g.x0) / g.SX, y = ev.clientY - r.top;
      if (x > 0.05 * M2.s3.l && x < 0.95 * M2.s3.l && Math.abs(y - g.cy) < 50) { s.xp = x; m2s3Pluck(s, 'pluck'); }
    });
    s.cv.style.cursor = 'pointer';
    /* 振動子の振動数：③-3 と同じ「札＋スライダー」一体の操作（2026-11-07 千葉さん 13 回目）。連続波のときだけ出す */
    var dv = el('div', 'drvctl'), chips = el('div', 'drvchips'), rg = el('input'), dvv = el('div', 'drvval');
    rg.type = 'range'; rg.min = '0.75'; rg.max = '3.25'; rg.step = '0.01'; rg.value = '1'; rg.setAttribute('aria-label', '振動子の振動数');
    var go = function () { if (s.pmode === 'drive') m2s3Pluck(s, 'drive'); else { m2s3Sync(s); s.draw(); } };
    M2S3_DF.forEach(function (r) { var b = el('button', 'b drvchip', (r === 1 ? '' : r) + 'f₁'); b.type = 'button'; b.style.left = 'calc(9px + (100% - 18px) * ' + ((r - 0.75) / 2.5).toFixed(4) + ')'; b.addEventListener('click', function () { s.dm = r; go(); }); chips.appendChild(b); });
    rg.addEventListener('input', function () { s.dm = +rg.value; go(); });
    dv.appendChild(dvv); dv.appendChild(chips); dv.appendChild(rg); s.Rdyn.insertAdjacentElement('beforebegin', dv); s.drv = dv; s.drvRg = rg; s.drvVal = dvv; s.drvChips = chips;
    m2s3Sync(s);
  },
  draw: function (s, ctx, W, H) { drawM2S3(s, ctx, W, H); },
  right: function (s, R) { rightM2S3(s, R); }
};
function m2s3Pluck(s, mode) {
  if (s.ramp) { s.setBusy(false); s.ramp = null; }
  s.pmode = mode; s.tPl = 0;
  s.endWindow(); s.t = 0; s.ended = false;
  if (mode === 'ramp') { s.v.lv = 0; s.ramp = true; }
  SIMS.forEach(function (o) { if (o.playing) { o.playing = false; o.syncPlayLabel(); } });
  s.playing = true; s.syncPlayLabel(); startLoop();
  m2s3Sync(s); s.renderRight();
}
function m2s3Sync(s) {
  m2Sync(s, [['pl', s.pmode === 'pluck'], ['rp', s.pmode === 'drive'], ['cmp', s.showComp]]);   /* 既定の「パルス波を起こす」も選ばれた形で（2026-11-07 千葉さん 13 回目） */
  if (s.drv) {
    var q = m2s3Q(s); s.drv.style.display = s.pmode === 'drive' ? '' : 'none';
    if (+s.drvRg.value !== s.dm) s.drvRg.value = s.dm;
    s.drvVal.innerHTML = '振動子の振動数　<b>' + sig(s.dm * q.f1, 2) + ' Hz</b>（' + fmt(s.dm, 2) + 'f₁）';
    Array.prototype.forEach.call(s.drvChips.children, function (b, i) { b.classList.toggle('on', Math.abs(M2S3_DF[i] - s.dm) < 1e-9); });
  }
  if (s.Rdyn) s.renderRight();
}
function drawM2S3(s, ctx, W, H) {
  var g = m2s3Geo(W, H), q = m2s3Q(s), t = s.t, tp = Math.max(0, t - (s.tPl || 0));
  var X = function (x) { return g.x0 + x * g.SX; }, Y = function (y) { return g.cy - y * g.SY; };
  dotted(ctx, X(0), g.cy, X(q.l), g.cy, 'rgba(20,23,28,.25)', [5, 4]);
  /* 両端の固定端（壁） */
  [0, q.l].forEach(function (x, i) { if (!i && s.pmode === 'drive') return; var px = X(x); ctx.save(); ctx.fillStyle = '#5b6470'; ctx.fillRect(px + (i ? 0 : -7), g.cy - 46, 7, 92); ctx.restore(); hatchSeg(ctx, px + (i ? 7 : -7), g.cy - 46, px + (i ? 7 : -7), g.cy + 46, i ? 1 : -1, 7, '#9aa1ab'); });
  if (s.pmode !== 'drive') label(ctx, '固定端', X(0) + 4, g.cy + 58, { size: 11, color: COL.sub, align: 'left' }); label(ctx, '固定端', X(q.l) - 4, g.cy + 58, { size: 11, color: COL.sub, align: 'right' });
  var started = s.t > 0 || s.playing;
  if (s.pmode === 'drive') {
    /* 左端の振動子が糸を揺らし続ける。振動子の振動数が固有振動数と同じときだけ大きな定在波（共振） */
    var fd = s.dm * q.f1, yD = function (x) { return M2.drive(q, x, tp, fd, M2S3_A, M2S3_R); };
    /* 右向き・左向きの波（2026-11-07 千葉さん 13 回目）：式の第 1 項の和（左端から出て右へ進む波）と第 2 項の和（右端で反射して左へ進む波） */
    if (s.showComp && started) {
      plotF(ctx, function (x) { return M2.drive(q, x, tp, fd, M2S3_A, M2S3_R, 1); }, 0, q.l, X, Y, M2C.R, 1.8, [6, 4]);
      plotF(ctx, function (x) { return M2.drive(q, x, tp, fd, M2S3_A, M2S3_R, -1); }, 0, q.l, X, Y, M2C.L, 1.8, [6, 4]);
      legendRow(ctx, [{ col: M2C.R, dash: [6, 4], txt: W < 560 ? '右向き' : '右向きに進む波' }, { col: M2C.L, dash: [6, 4], txt: W < 560 ? '左向き' : '左向きに進む波' }, { col: '#7a3b12', lw: 2.8, txt: W < 560 ? '糸（和）' : '糸（2 つの和）' }], X(0) + 40, H - 12);
    }
    plotF(ctx, yD, 0, q.l, X, Y, '#7a3b12', 2.8);
    var y0d = yD(0), px0 = X(0), py0 = Y(y0d);
    vibBox(ctx, px0, py0, g.cy + 66);                                /* 振動子の右の辺が糸の左端（つながっている） */
    var res = Math.abs(s.dm - Math.round(s.dm)) < 0.03;
    label(ctx, '振動子の振動数 ' + (s.dm === 1 ? '' : fmt(s.dm, 2)) + 'f₁ = ' + sig(fd, 2) + ' Hz' + (started ? (res ? '：固有振動数と同じ → 共振して大きく振動する' : '：固有振動数と違う → 大きくならない') : ''), (X(0) + X(q.l)) / 2, 16, { size: 12, bold: true, color: '#6b3a0a' });
  } else if (s.pmode === 'ramp') {
    /* 速くなると目には重なって見える：カメラのシャッター（1/30 s）の間の形を重ねて描く。倍音ほど早く減衰 */
    var M = 26, exp = 1 / 30;
    for (var k = 0; k < M; k++) {
      var tk = Math.max(0, tp - exp * k / M);
      plotF(ctx, function (x) { return M2.modal(q, x, tk, 0.25); }, 0, q.l, X, Y, '#7a3b12', 2.2, null, 1.6 / M + (k === 0 ? 0.35 : 0));
    }
    var vv = q.v;
    label(ctx, vv < 8 ? 'はじいた所から波が両側へ進み、両端で反射する' : (vv < 40 ? '波が速くなり、形がはっきり見えなくなってくる' : '速い振動が重なって、基本振動（腹が 1 つ）のように見える'), (X(0) + X(q.l)) / 2, 16, { size: 12, bold: true, color: '#6b3a0a' });
  } else {
    var yR = function (x) { return M2.dal(q, x, tp, 1); }, yL = function (x) { return M2.dal(q, x, tp, -1); };
    if (s.showComp && started) { plotF(ctx, yR, 0, q.l, X, Y, M2C.R, 1.8, [6, 4]); plotF(ctx, yL, 0, q.l, X, Y, M2C.L, 1.8, [6, 4]); }
    plotF(ctx, function (x) { return started ? yR(x) + yL(x) : M2.pluckShape(q, x); }, 0, q.l, X, Y, '#7a3b12', 2.8);
    /* 指：はじく前は糸を持ち上げている。はじくと上へはね上がって離れ、消える（2026-11-07 千葉さん 14 回目） */
    if (!started) m2Finger(ctx, X(q.xp), Y(q.h0) + 2, 1);
    else if (tp < 0.45) m2Finger(ctx, X(q.xp), Y(q.h0) + 2 - Math.min(1, tp / 0.12) * 26, tp < 0.12 ? 1 : Math.max(0, 1 - (tp - 0.12) / 0.33));
    if (!started) { bubble(ctx, W < 420 ? 'ここをはじく（クリックで場所を変える）' : 'ここをはじく（糸の上をクリックすると場所を変えられる）', X(q.xp), Y(q.h0) - 8, { size: 11.5 }); }
    else if (s.showComp) {
      var reflected = q.v * tp > Math.min(q.xp, q.l - q.xp);
      legendRow(ctx, [{ col: M2C.R, dash: [6, 4], txt: W < 560 ? '右向き' : '右向きに進む波' }, { col: M2C.L, dash: [6, 4], txt: W < 560 ? '左向き' : '左向きに進む波' }, { col: '#7a3b12', lw: 2.8, txt: W < 560 ? '糸（和）' : '糸（2 つの和）' }], X(0), 14);
      label(ctx, reflected ? '両端で反射した波（反射波）と重なり合う' : 'はじいた所から、波が両側へ進む（発生した波）', (X(0) + X(q.l)) / 2, H - 14, { size: 11.5, bold: true, color: '#6b3a0a' });
    }
  }
}
function rightM2S3(s, R) {
  var q = m2s3Q(s);
  var h = '<div class="qcard"><p class="qt">固有振動と共振</p>' +
    '<p>両端を固定した糸をはじくと、両側へ進む波が両端で反射し、逆向きに進む波が重なる。両端が<b>節</b>になる定在波だけが残る。この振動を<b>固有振動</b>、その振動数を<b>固有振動数</b>という。</p>' +
    '<p>長さ $l$ の糸の両端が節なので、腹が $m$ 個の定在波の波長は</p>' +
    '<div class="qeq">$$l = m\\cdot\\frac{\\lambda_m}{2},\\qquad f_m = \\frac{v}{\\lambda_m} = m\\cdot\\frac{v}{2l}\\quad (m = 1, 2, 3, \\cdots)$$</div>' +
    '<p>外から固有振動数と同じ振動数で揺すると、大きく振動する。これを<b>共振</b>（音では<b>共鳴</b>）という。</p>' +
    '<p class="qnow"><span class="qtag now">いま</span>$l = ' + fmt(q.l, 1) + '$ m、$v = ' + sig(q.v, 2) + '$ m/s なので　基本振動数 $f_1 = \\dfrac{v}{2l} = ' + sig(q.f1, 2) + '$ Hz</p>' +
    '<p class="qnote">「連続波を起こす」では、左端の振動子で糸を揺らし続ける。振動子の振動数が固有振動数（$f_1$・$2f_1$・$3f_1$ …）と同じときだけ、反射した波と強め合って大きな定在波になる（共振）。$1.5f_1$・$2.5f_1$ では大きくならない。反射のたびに少しずつ振幅が失われるとしている。</p></div>';
  R.innerHTML = mathify(h);
}

/* 糸をはじく指（下から上へ。(x, y)＝指先）。a：不透明度 */
function m2Finger(ctx, x, y, a) {
  if (a <= 0.01) return;
  ctx.save(); ctx.globalAlpha = a;
  ctx.fillStyle = '#f2c7a5'; ctx.strokeStyle = '#a8704a'; ctx.lineWidth = 1.2;
  ctx.beginPath(); ctx.moveTo(x - 8, y + 46); ctx.lineTo(x - 8, y + 8); ctx.quadraticCurveTo(x - 8, y, x, y); ctx.quadraticCurveTo(x + 8, y, x + 8, y + 8); ctx.lineTo(x + 8, y + 46); ctx.closePath(); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#fbe3d2'; ctx.beginPath(); ctx.ellipse(x, y + 9, 4.5, 5.5, 0, 0, TAU); ctx.fill(); ctx.stroke();
  ctx.restore();
}
