/* ===== 47_wgraph.js ===== */
/* =========================================================================
   47_wgraph.js … y-x グラフ・y-t グラフ（スキル experiment-graph-ui の規約）
   ・枠の中をドラッグ＝上下左右に移動（横は同じ横軸のグラフ全部で共有、縦はそのグラフだけ）
   ・横軸の目盛りをドラッグ＝横の拡大縮小（共有）、縦軸の目盛りをドラッグ＝縦の拡大縮小（そのグラフだけ）
   ・「スケールをリセット」、右上の「最大化」（四隅に向かう矢印の SVG）。ホイールは使わない
   ・曲線の点をクリック＝その点を選ぶ（座標を点のわきと見出しに。小数 2 けた・cm/s）。もう一度で解除
   ・y-t グラフには「dy/dt を表示」（既定 OFF）
   ・軸には矢印。縦軸は 0 を含むきりのいい目盛りで、上下に余裕。枠の外は描かない（clip）
   ========================================================================= */
'use strict';
var GPAD = { l: 50, r: 18, t: 22, b: 30 };
var XAXES = {};                                  /* 横軸の共有：キー → { lo, hi }（同じキーのグラフはいっしょに動く） */
function niceStep(range, target) {
  var raw = range / target, p = Math.pow(10, Math.floor(Math.log(raw) / Math.LN10)), c = [1, 2, 2.5, 5, 10];
  for (var i = 0; i < c.length; i++) if (raw <= c[i] * p * 1.0001) return c[i] * p;
  return 10 * p;
}
/* 0 を必ず入れた、きりのいい範囲。データが端まで 0.55 目盛り以内なら 1 目盛り外へ（0 がわの端はのばさない） */
function niceRange(lo, hi) {
  var dlo = lo, dhi = hi;
  lo = Math.min(lo, 0); hi = Math.max(hi, 0); if (hi - lo < 1e-12) hi = lo + 1;
  var st = niceStep(hi - lo, 4), a = Math.floor(lo / st + 1e-9) * st, b = Math.ceil(hi / st - 1e-9) * st;
  if (dhi > 1e-12 && dhi > b - st * 0.55) b += st;
  if (dlo < -1e-12 && dlo < a + st * 0.55) a -= st;
  return { lo: a, hi: b, step: st };
}
function fmtTick(v, st) {
  var dg = Math.max(0, -Math.floor(Math.log(st) / Math.LN10 + 1e-9) + (Math.abs(st / Math.pow(10, Math.floor(Math.log(st) / Math.LN10 + 1e-9)) - 2.5) < 1e-6 ? 1 : 0));
  var s = v.toFixed(Math.min(4, dg)); if (/^-0(\.0*)?$/.test(s)) s = s.slice(1);
  return s.replace('-', '−');
}
/* t 軸の目盛りの文字（T の分数）。n/4 を約分して T/4・T/2・3T/4・T … */
function tFracLabel(ctx, n, x, y, d, sym) {
  d = d || 4; sym = sym || 'T';
  var g = function (a, b) { return b ? g(b, a % b) : a; }, k = g(n, d), nn = n / k, dd = d / k;
  ctx.save(); ctx.fillStyle = '#5d6875'; ctx.textAlign = 'center';
  var num = (nn === 1 ? '' : String(nn));
  if (dd === 1) {
    ctx.textBaseline = 'top'; ctx.font = '600 10.5px ' + SER; var w0 = ctx.measureText(num).width;
    ctx.font = 'italic 11.5px ' + MATH; var w1 = ctx.measureText(sym).width, X = x - (w0 + w1) / 2;
    ctx.textAlign = 'left'; ctx.font = '600 10.5px ' + SER; ctx.fillText(num, X, y + 3);
    ctx.font = 'italic 11.5px ' + MATH; ctx.fillText(sym, X + w0, y + 2);
  } else {
    ctx.textBaseline = 'alphabetic'; ctx.font = '600 9.5px ' + SER; var a0 = ctx.measureText(num).width;
    ctx.font = 'italic 10.5px ' + MATH; var a1 = ctx.measureText(sym).width, X2 = x - (a0 + a1) / 2;
    ctx.textAlign = 'left'; ctx.font = '600 9.5px ' + SER; ctx.fillText(num, X2, y + 10);
    ctx.font = 'italic 10.5px ' + MATH; ctx.fillText(sym, X2 + a0, y + 10);
    ctx.strokeStyle = '#5d6875'; ctx.lineWidth = 0.9; var hw = Math.max(5, (a0 + a1) / 2 + 1);
    ctx.beginPath(); ctx.moveTo(x - hw, y + 12.5); ctx.lineTo(x + hw, y + 12.5); ctx.stroke();
    ctx.textAlign = 'center'; ctx.font = '600 9.5px ' + SER; ctx.fillText(String(dd), x, y + 22);
  }
  ctx.restore();
}
var MAX_SVG = '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M3 8V3h5M12 3h5v5M17 12v5h-5M8 17H3v-5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><path d="M3 3l5 5M17 3l-5 5M17 17l-5-5M3 17l5-5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>';

/* opt：
   host       … 置く場所
   key        … グラフの名前（テスト・CSS 用）
   title      … 見出し（KaTeX 可）
   xKey       … 横軸の共有キー（例 'm1s2-t'）
   xsym, xunit, ysym, yunit … 軸の名前
   xDef()     … 横軸の既定の範囲 { lo, hi }
   yDef()     … 縦軸の既定の範囲（データの範囲。きりのいい範囲と余裕はこちらでつける）
   series()   … [{ color, width, dash, f(x) → y, x0, x1 }]（x0〜x1 の間だけ描く）
   N          … 1 本あたりの点の数（既定 360）
   H()        … 高さ〔px〕
   padL       … 左の余白（既定 GPAD.l。①-2 の円はここに描く）
   xTicks     … 'T'（T の分数の目盛り：period() を使う）／'lam'（λ の分数）／省略（数値）
   period()   … xTicks のための T（または λ）
   now()      … いまの時刻・位置の縦線（null なら引かない）
   back(ctx, g), front(ctx, g) … 曲線の前・後に描く飾り（g.X・g.Y・g.R が使える）
   deriv(x)   … 選んだ点の dy/dt（あれば「dy/dt を表示」を出す）
   yCm        … 縦の値を cm で表示（座標の読み出し）
   drag(px, py, g) → { move(px, py), end() } … 枠の中の特別なドラッグ（①-2 の ★ の点）
*/
function WGraph(opt) {
  this.o = opt; this.sel = null; this.dOn = false; this.user = false;
  var self = this;
  var box = el('div', 'gbox wg g-' + (opt.key || '')), hd = el('div', 'ghead');
  hd.appendChild(el('span', 'gt', mathify(opt.title)));
  this.vv = el('span', 'gsel', ''); hd.appendChild(this.vv);
  var tools = el('span', 'gtools');
  if (opt.deriv) {
    var lb = el('label', 'gchk'), cb = el('input'); cb.type = 'checkbox'; cb.checked = false;
    lb.appendChild(cb); lb.appendChild(el('span', '', mathify('$dy/dt$ を表示')));
    cb.addEventListener('change', function () { self.dOn = cb.checked; self.head(); });
    tools.appendChild(lb); this.dChk = cb;
  }
  var br = el('button', 'b gbtn greset', 'スケールをリセット'); br.type = 'button';
  br.addEventListener('click', function () { self.reset(true); });
  var bm = el('button', 'b gbtn gmaxb', MAX_SVG); bm.type = 'button'; bm.title = '最大化'; bm.setAttribute('aria-label', 'グラフを最大化');
  bm.addEventListener('click', function () { self.toggleMax(); });
  if (!opt.noReset) tools.appendChild(br);                       /* opt.noReset：「スケールをリセット」を出さない（①-2。2026-11-03 千葉さん） */
  /* 最大化ボタンは出さない（2026-11-03 千葉さん 5 回目：グラフ全部） */
  hd.appendChild(tools);
  box.appendChild(hd);
  this.cv = el('canvas', 'gcv'); box.appendChild(this.cv);
  opt.host.appendChild(box);
  this.box = box; this.bMax = bm;
  this.reset(false);
  this.bind();
}
WGraph.prototype.xa = function () { return XAXES[this.o.xKey]; };
WGraph.prototype.reset = function (redraw) {
  var d = this.o.xDef(); XAXES[this.o.xKey] = { lo: d.lo, hi: d.hi };
  var r = this.o.yDef(); this.yr = niceRange(r.lo, r.hi); this.user = false;
  if (redraw) { WGraph.redrawKey(this.o.xKey); }
};
WGraph.all = [];
WGraph.redrawKey = function (k) { WGraph.all.forEach(function (g) { if (g.o.xKey === k) g.draw(); }); };
WGraph.prototype.rect = function () { var pl = this.o.padL || GPAD.l; return { x0: pl, x1: this.W - GPAD.r, y0: GPAD.t, y1: this.H - GPAD.b }; };
WGraph.prototype.toggleMax = function () {
  var on = !this.box.classList.contains('gmax'), self = this;
  this.box.classList.toggle('gmax', on); document.body.classList.toggle('hasgmax', on);
  this.bMax.title = on ? '元の大きさに戻す' : '最大化';
  if (on) {
    this._esc = function (ev) { if (ev.key === 'Escape') self.toggleMax(); };
    document.addEventListener('keydown', this._esc);
    this._bg = el('div', 'gmaxbg'); this._bg.addEventListener('click', function () { self.toggleMax(); }); document.body.appendChild(this._bg);
  } else { document.removeEventListener('keydown', this._esc); if (this._bg) this._bg.remove(); }
  this.draw();
};
WGraph.prototype.bind = function () {
  var self = this, down = null;
  var pos = function (ev) { var b = self.cv.getBoundingClientRect(); return { x: ev.clientX - b.left, y: ev.clientY - b.top }; };
  this.cv.addEventListener('pointerdown', function (ev) {
    /* 左右へのドラッグ（移動・横軸の拡大縮小）はしない（2026-11-03 千葉さん 5 回目）。枠の中のクリック＝点を選ぶ、と ★ のドラッグだけ */
    var p = pos(ev), R = self.rect(), zone = (p.x < R.x0 && p.y < R.y1) ? (self.o.lockY ? 'none' : 'y') : (p.x >= R.x0 && p.y <= R.y1 ? 'pan' : 'none');   /* opt.lockY：縦は動かさない（①-2：左右のグラフの縦の中心をそろえるため） */
    var xa = self.xa();
    down = { x: ev.clientX, y: ev.clientY, p: p, zone: zone, moved: false, gx: { lo: xa.lo, hi: xa.hi }, yr: { lo: self.yr.lo, hi: self.yr.hi, step: self.yr.step } };
    if (zone === 'pan' && self.o.drag && self.g) { var h = self.o.drag(p.x, p.y, self.g); if (h) down.h = h; }   /* self.g：最後に描いたときの座標の換算（X・Y・R） */
    if (zone === 'none' && !down.h) { down = null; return; }
    self.cv.setPointerCapture(ev.pointerId); ev.preventDefault();
  });
  this.cv.addEventListener('pointermove', function (ev) {
    var p = pos(ev);
    if (!down) { var R0 = self.rect(); self.cv.style.cursor = (self.o.drag && self.g && self.o.drag(p.x, p.y, self.g, true)) ? 'grab' : (p.x < R0.x0 ? (self.o.lockY ? 'default' : 'ns-resize') : (p.y > R0.y1 ? 'default' : (self.o.lockY ? 'default' : 'ns-resize'))); return; }
    var dx = ev.clientX - down.x, dy = ev.clientY - down.y, R = self.rect();
    if (Math.hypot(dx, dy) > 4) down.moved = true;
    if (down.h) { down.h.move(p.x, p.y); return; }
    if (!down.moved) return;
    if (!self.o.lockY) self.user = true;
    var xa = self.xa(), sx = (down.gx.hi - down.gx.lo) / (R.x1 - R.x0), sy = (down.yr.hi - down.yr.lo) / (R.y1 - R.y0);
    if (down.zone === 'pan') {
      if (!self.o.lockY) self.yr = { lo: down.yr.lo + dy * sy, hi: down.yr.hi + dy * sy, step: down.yr.step };   /* 上下だけ */
    } else if (down.zone === 'x') {
      var f = Math.exp(-dx * 0.01), c = (down.gx.lo + down.gx.hi) / 2, h = (down.gx.hi - down.gx.lo) / 2 * f;
      xa.lo = c - h; xa.hi = c + h;
    } else if (down.zone === 'y') {
      var f2 = Math.exp(dy * 0.01), c2 = (down.yr.lo + down.yr.hi) / 2, h2 = (down.yr.hi - down.yr.lo) / 2 * f2;
      self.yr = { lo: c2 - h2, hi: c2 + h2 };
    }
    WGraph.redrawKey(self.o.xKey);
  });
  var up = function () {
    if (down && down.h) { down.h.end(); down = null; return; }
    if (down && !down.moved && down.zone === 'pan') self.pick(down.p.x, down.p.y);
    down = null;
  };
  this.cv.addEventListener('pointerup', up);
  this.cv.addEventListener('pointercancel', function () { if (down && down.h) down.h.end(); down = null; });
  WGraph.all.push(this);
};
/* 曲線の点をクリック：いちばん近い点を選ぶ（12 px 以内）。同じ点をもう一度で解除 */
WGraph.prototype.pick = function (px, py) {
  var best = null, bd = 12;
  (this._pts || []).forEach(function (q) { var d = Math.hypot(q.px - px, q.py - py); if (d < bd) { bd = d; best = q; } });
  if (best && this.sel && Math.abs(this.sel.x - best.x) < 1e-9 && this.sel.si === best.si) this.sel = null;
  else this.sel = best ? { x: best.x, y: best.y, si: best.si } : null;
  this.draw(); this.head();
};
WGraph.prototype.head = function () {
  var o = this.o, h = '';
  if (this.sel) {
    var xs = this.sel.x, ys = this.sel.y;
    h = '（$' + o.xsym + '$ = ' + fmt(xs, 2) + ' ' + o.xunit + '、$' + o.ysym + '$ = ' + (o.yCm ? fmt(ys * 100, 2) + ' cm' : fmt(ys, 2) + ' ' + o.yunit) + '）';
    if (this.dOn && o.deriv) { var dv = o.deriv(xs, this.sel.si); h += '　$\\dfrac{dy}{dt}$ = ' + (o.yCm ? fmt(dv * 100, 2) + ' cm/s' : fmt(dv, 2) + ' ' + o.yunit + '/s'); }
  }
  if (this.vv._h !== h) { this.vv._h = h; this.vv.innerHTML = mathify(h); }
};
WGraph.prototype.draw = function () {
  var o = this.o, cv = this.cv;
  if (!cv.isConnected || !cv.offsetParent) return;
  var W = Math.max(220, Math.floor(cv.clientWidth || this.box.clientWidth || 300));
  var H = this.box.classList.contains('gmax') ? Math.max(260, Math.floor(this.box.clientHeight - 60)) : (o.H ? o.H() : 150);
  this.W = W; this.H = H;
  if (!this.user) { var r0 = o.yDef(); var nr = niceRange(r0.lo, r0.hi); this.yr = nr; }
  var ctx = prep(cv, W, H), R = this.rect(), xa = this.xa(), yr = this.yr;
  var X = function (x) { return R.x0 + (x - xa.lo) / (xa.hi - xa.lo) * (R.x1 - R.x0); };
  var Y = function (y) { return R.y1 - (y - yr.lo) / (yr.hi - yr.lo) * (R.y1 - R.y0); };
  var g = { X: X, Y: Y, R: R, W: W, H: H, xa: xa, yr: yr, ctx: ctx };
  this.g = g;
  ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H);
  /* 目盛り（縦）：きりのいいきざみで 3〜5 個 */
  var mx = clamp(Math.floor((R.y1 - R.y0) / 22), 3, 5), sy = niceStep(yr.hi - yr.lo, 4);
  var nTk = function (st) { return Math.floor(yr.hi / st + 1e-9) - Math.ceil(yr.lo / st - 1e-9) + 1; };
  for (var kk = 0; kk < 12 && nTk(sy) > mx; kk++) sy = niceStep(sy * 1.2, 1);
  ctx.save(); ctx.strokeStyle = '#eef0f2'; ctx.lineWidth = 1;
  ctx.font = '600 10px ' + FONT; ctx.fillStyle = '#5d6875'; ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
  for (var ty = Math.ceil(yr.lo / sy - 1e-9) * sy; ty <= yr.hi + 1e-9; ty += sy) {
    var py = Y(ty); ctx.beginPath(); ctx.moveTo(R.x0, py); ctx.lineTo(R.x1, py); ctx.stroke();
    ctx.save(); ctx.strokeStyle = '#fff'; ctx.lineWidth = 3; ctx.strokeText(fmtTick(ty, sy), R.x0 - 5, py); ctx.restore();
    ctx.fillText(fmtTick(ty, sy), R.x0 - 5, py);
  }
  /* 目盛り（横）：T・λ の分数、または数値 */
  var P = o.period ? o.period() : null;
  if (o.xTicks && P) {
    var q = P / 4, px1 = (R.x1 - R.x0) / (xa.hi - xa.lo) * q, every = px1 >= 30 ? 1 : (px1 >= 15 ? 2 : (px1 >= 7 ? 4 : 8));
    for (var n = Math.ceil(xa.lo / q - 1e-9); n * q <= xa.hi + 1e-9; n++) {
      if (n === 0) continue;
      var pxx = X(n * q);
      ctx.strokeStyle = (n % 4 === 0) ? '#e2e5e9' : '#f1f3f5'; ctx.beginPath(); ctx.moveTo(pxx, R.y0); ctx.lineTo(pxx, R.y1); ctx.stroke();
      if (n > 0 && n % every === 0) tFracLabel(ctx, n, pxx, R.y1 + 1, 4, o.xTicks === 'lam' ? 'λ' : 'T');
    }
  } else {
    var sx = niceStep(xa.hi - xa.lo, 5); ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    for (var tx = Math.ceil(xa.lo / sx - 1e-9) * sx; tx <= xa.hi + 1e-9; tx += sx) { var p2 = X(tx); ctx.beginPath(); ctx.moveTo(p2, R.y0); ctx.lineTo(p2, R.y1); ctx.stroke(); ctx.fillText(fmtTick(tx, sx), p2, R.y1 + 5); }
  }
  ctx.restore();
  /* 軸（矢印つき）。横軸は y = 0、縦軸は x（t）= 0 */
  var ax = clamp(Y(0), R.y0, R.y1), ay = clamp(X(0), R.x0, R.x1);
  ctx.save(); ctx.strokeStyle = '#2b323c'; ctx.fillStyle = '#2b323c'; ctx.lineWidth = 1.3;
  ctx.beginPath(); ctx.moveTo(R.x0, ax); ctx.lineTo(R.x1 + 4, ax); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(R.x1 + 10, ax); ctx.lineTo(R.x1 + 2, ax - 4); ctx.lineTo(R.x1 + 2, ax + 4); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(ay, R.y1); ctx.lineTo(ay, R.y0 - 2); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(ay, R.y0 - 9); ctx.lineTo(ay - 4, R.y0 - 1); ctx.lineTo(ay + 4, R.y0 - 1); ctx.closePath(); ctx.fill();
  ctx.font = 'italic 12px ' + MATH; ctx.textAlign = 'right'; ctx.textBaseline = 'bottom'; ctx.fillText(o.xsym, R.x1 + 10, ax - 5);
  ctx.font = '600 9.5px ' + FONT; ctx.textBaseline = 'top'; ctx.fillText('〔' + o.xunit + '〕', R.x1 + 12, ax + 6);
  ctx.textAlign = 'left'; ctx.textBaseline = 'top';
  ctx.font = 'italic 12px ' + MATH; ctx.fillText(o.ysym, ay + 7, 2);
  var wsym = ctx.measureText(o.ysym).width; ctx.font = '600 9.5px ' + FONT; ctx.fillText('〔' + o.yunit + '〕', ay + 7 + wsym + 1, 3);
  ctx.restore();
  if (o.back) { ctx.save(); o.back(ctx, g); ctx.restore(); }
  /* 曲線（枠の中だけ） */
  ctx.save(); ctx.beginPath(); ctx.rect(R.x0, R.y0 - 2, R.x1 - R.x0, R.y1 - R.y0 + 4); ctx.clip();
  var pts = [], N = o.N || 360;
  (o.series ? o.series() : []).forEach(function (sr, si) {
    var a = Math.max(xa.lo, sr.x0 === undefined ? -Infinity : sr.x0), b = Math.min(xa.hi, sr.x1 === undefined ? Infinity : sr.x1);
    if (!(b > a)) return;
    ctx.save(); ctx.strokeStyle = sr.color; ctx.lineWidth = sr.width || 2.2; ctx.setLineDash(sr.dash || []); ctx.globalAlpha = sr.alpha || 1; ctx.beginPath();
    for (var i = 0; i <= N; i++) {
      var x = a + (b - a) * i / N, y = sr.f(x), px = X(x), pyy = Y(y);
      if (i) ctx.lineTo(px, pyy); else ctx.moveTo(px, pyy);
      if (sr.pick !== false && i % 3 === 0) pts.push({ x: x, y: y, px: px, py: pyy, si: si });
    }
    ctx.stroke(); ctx.restore();
  });
  this._pts = pts;
  /* いまの縦線 */
  var nw = o.now ? o.now() : null;
  if (nw !== null && nw !== undefined && nw >= xa.lo && nw <= xa.hi) {
    ctx.strokeStyle = 'rgba(93,104,117,.7)'; ctx.lineWidth = 1.2; ctx.setLineDash([4, 3]); ctx.beginPath(); ctx.moveTo(X(nw), R.y0); ctx.lineTo(X(nw), R.y1); ctx.stroke(); ctx.setLineDash([]);
  }
  /* 選んだ点：両軸へ点線・点・わきの座標 */
  if (this.sel) {
    var sx2 = X(this.sel.x), sy2 = Y(this.sel.y);
    ctx.strokeStyle = 'rgba(20,23,28,.55)'; ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
    ctx.beginPath(); ctx.moveTo(sx2, sy2); ctx.lineTo(sx2, ax); ctx.moveTo(sx2, sy2); ctx.lineTo(ay, sy2); ctx.stroke(); ctx.setLineDash([]);
    ctx.fillStyle = '#14171c'; ctx.beginPath(); ctx.arc(sx2, sy2, 4, 0, TAU); ctx.fill();
  }
  ctx.restore();
  if (this.sel) {
    var t1 = o.xsym + ' = ' + fmt(this.sel.x, 2) + ' ' + o.xunit + '，' + o.ysym + ' = ' + (o.yCm ? fmt(this.sel.y * 100, 2) + ' cm' : fmt(this.sel.y, 2) + ' ' + o.yunit);
    ctx.save(); ctx.font = '600 11px ' + FONT; var tw = ctx.measureText(t1).width + 12;
    var bx = clamp(X(this.sel.x) + 8, R.x0 + 2, R.x1 - tw - 2), by = clamp(Y(this.sel.y) - 26, R.y0, R.y1 - 20);
    ctx.fillStyle = '#fff'; ctx.strokeStyle = 'rgba(20,23,28,.35)'; ctx.lineWidth = 1; rrect(ctx, bx, by, tw, 19, 4); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#14171c'; ctx.textBaseline = 'middle'; ctx.fillText(t1, bx + 6, by + 10); ctx.restore();
  }
  if (o.front) { ctx.save(); o.front(ctx, g); ctx.restore(); }
  this.head();
};
