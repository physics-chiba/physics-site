/* ===== 36_music.js ===== */
/* =========================================================================
   音楽の道具（③-4 モノコード・章 ④）
   ・音の高さ：MIDI 番号 m（A4 = 69）。平均律 f = 440 × 2^((m − 69)/12)（A4 = 440 Hz）
   ・五線譜：ト音記号。線の位置は「白鍵の段」で決める（C4 = 下第 1 線）
   ・ト音記号は文字（𝄞）を使わず、線で描く（端末によっては文字が出ないため）
   ========================================================================= */
'use strict';
var MUS = {
  A4: 440,
  /* 平均律の振動数 */
  fET: function (m) { return MUS.A4 * Math.pow(2, (m - 69) / 12); },
  /* 振動数 → いちばん近い音（MIDI 番号）とセント */
  near: function (f) { var x = 69 + 12 * Math.log(f / MUS.A4) / Math.LN2, m = Math.round(x); return { m: m, cent: Math.round((x - m) * 100) }; },
  PC: ['C', 'C♯', 'D', 'D♯', 'E', 'F', 'F♯', 'G', 'G♯', 'A', 'A♯', 'B'],
  DO: ['ド', 'ド♯', 'レ', 'レ♯', 'ミ', 'ファ', 'ファ♯', 'ソ', 'ソ♯', 'ラ', 'ラ♯', 'シ'],
  oct: function (m) { return Math.floor(m / 12) - 1; },
  en: function (m) { return MUS.PC[(m % 12 + 12) % 12] + MUS.oct(m); },
  jp: function (m) { return MUS.DO[(m % 12 + 12) % 12]; },
  black: function (m) { return [1, 3, 6, 8, 10].indexOf((m % 12 + 12) % 12) >= 0; },
  /* 五線譜の段（C4 = 0、D4 = 1 …）。黒鍵は下の白鍵と同じ段に♯をつける */
  step: function (m) { var pc = (m % 12 + 12) % 12, o = MUS.oct(m) - 4; return o * 7 + [0, 0, 1, 1, 2, 3, 3, 4, 4, 5, 5, 6][pc]; }
};
/* ト音記号（高さ h：第 1 線〜第 5 線の間かく × 4 が h）。(x, yG)＝第 2 線（ソ）の高さ */
function gClef(ctx, x, yG, sp, col) {
  ctx.save(); ctx.strokeStyle = col || '#14171c'; ctx.lineWidth = Math.max(1.6, sp * 0.22); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.beginPath();
  /* 第 2 線を中心に巻く渦 → 上へのびてループ → 下へ */
  ctx.moveTo(x + sp * 0.2, yG + sp * 0.15);
  ctx.bezierCurveTo(x - sp * 0.15, yG + sp * 0.2, x - sp * 0.2, yG - sp * 0.55, x + sp * 0.3, yG - sp * 0.6);
  ctx.bezierCurveTo(x + sp * 1.0, yG - sp * 0.6, x + sp * 1.05, yG + sp * 0.75, x + sp * 0.25, yG + sp * 0.85);
  ctx.bezierCurveTo(x - sp * 0.7, yG + sp * 0.9, x - sp * 0.95, yG - sp * 0.4, x - sp * 0.1, yG - sp * 1.4);
  ctx.bezierCurveTo(x + sp * 0.6, yG - sp * 2.1, x + sp * 0.75, yG - sp * 3.0, x + sp * 0.4, yG - sp * 3.4);
  ctx.bezierCurveTo(x + sp * 0.1, yG - sp * 3.6, x - sp * 0.15, yG - sp * 3.0, x + sp * 0.05, yG - sp * 2.2);
  ctx.lineTo(x + sp * 0.45, yG + sp * 2.0);
  ctx.bezierCurveTo(x + sp * 0.5, yG + sp * 2.5, x + sp * 0.1, yG + sp * 2.7, x - sp * 0.15, yG + sp * 2.4);
  ctx.stroke();
  ctx.fillStyle = col || '#14171c'; ctx.beginPath(); ctx.arc(x - sp * 0.08, yG + sp * 2.3, sp * 0.26, 0, TAU); ctx.fill();
  ctx.restore();
}
/* 五線譜：(x0〜x1)、yTop＝第 5 線、sp＝線の間かく。返り値 Y(step)：段 → y */
function staff(ctx, x0, x1, yTop, sp, clef) {
  ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1;
  for (var i = 0; i < 5; i++) { var y = Math.round(yTop + i * sp) + 0.5; ctx.beginPath(); ctx.moveTo(x0, y); ctx.lineTo(x1, y); ctx.stroke(); }
  ctx.restore();
  /* ト音記号：第 1 線が E4（段 2）。ヘ音記号：第 1 線が G2（段 −10） */
  var base = clef === 'F' ? -10 : 2;
  if (clef === 'F') fClef(ctx, x0 + sp * 0.9, yTop + sp, sp); else gClef(ctx, x0 + sp * 1.2, yTop + 3 * sp, sp);
  var Y = function (st) { return yTop + 4 * sp - (st - base) * sp / 2; };
  Y.base = base;
  return Y;
}
/* ヘ音記号（線で描く）。(x, yF)＝第 4 線（F3） */
function fClef(ctx, x, yF, sp, col) {
  ctx.save(); ctx.strokeStyle = col || '#14171c'; ctx.fillStyle = col || '#14171c'; ctx.lineWidth = Math.max(1.8, sp * 0.24); ctx.lineCap = 'round';
  ctx.beginPath(); ctx.arc(x + sp * 0.2, yF + sp * 0.05, sp * 0.3, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.moveTo(x, yF); ctx.bezierCurveTo(x - sp * 0.1, yF - sp * 1.1, x + sp * 1.7, yF - sp * 1.2, x + sp * 1.6, yF + sp * 0.4);
  ctx.bezierCurveTo(x + sp * 1.5, yF + sp * 1.6, x + sp * 0.6, yF + sp * 2.6, x - sp * 0.3, yF + sp * 3.0); ctx.stroke();
  [-0.5, 0.5].forEach(function (d) { ctx.beginPath(); ctx.arc(x + sp * 2.15, yF + d * sp, sp * 0.16, 0, TAU); ctx.fill(); });
  ctx.restore();
}
/* 音符（全音符のような玉）。加線も引く。sharp：♯ をつける。col：色 */
function noteHead(ctx, x, st, Y, sp, col, sharp, hollow) {
  var y = Y(st);
  ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1;
  var b0 = Y.base === undefined ? 2 : Y.base;
  for (var k = b0 - 2; k >= st; k -= 2) { var yl = Y(k); ctx.beginPath(); ctx.moveTo(x - sp * 0.95, yl); ctx.lineTo(x + sp * 0.95, yl); ctx.stroke(); }   /* 下の加線（C4 以下） */
  for (var k2 = b0 + 10; k2 <= st; k2 += 2) { var yl2 = Y(k2); ctx.beginPath(); ctx.moveTo(x - sp * 0.95, yl2); ctx.lineTo(x + sp * 0.95, yl2); ctx.stroke(); }   /* 上の加線（A5 以上） */
  ctx.translate(x, y); ctx.rotate(-0.35);
  ctx.beginPath(); ctx.ellipse(0, 0, sp * 0.62, sp * 0.44, 0, 0, TAU);
  if (hollow) { ctx.lineWidth = 2; ctx.strokeStyle = col || '#14171c'; ctx.stroke(); } else { ctx.fillStyle = col || '#14171c'; ctx.fill(); }
  ctx.restore();
  if (sharp) label(ctx, typeof sharp === 'string' ? sharp : '♯', x - sp * 1.25, y, { size: Math.round(sp * 1.3), bold: true, color: col || '#14171c' });   /* sharp：true＝♯、文字ならその記号（♭ など） */
}
