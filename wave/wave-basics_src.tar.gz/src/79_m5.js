/* ===== 79_m5.js ===== */
/* =========================================================================
   モード ⑤ フーリエ変換（大学の範囲）— 2026-11-08 千葉さん 19 回目に新しく作った
   興味のある生徒が読めばよい、という位置づけ。数学はざっくり。計算はすべてこのページの中の JavaScript で本当に行う
     ⑤-1 フーリエ変換とは何か（時間の波形 → 振動数の成分。成分から波形にもどす＝逆変換）
     ⑤-2 音の加工（ノイズを消す・低音を強める＝イコライザー）
     ⑤-3 電波で送る・受け取る（ラジオ。振動数で分けて 1 つの放送だけ取り出す）
     ⑤-4 画像の圧縮（JPEG。8 × 8 の区画ごとに振動数の成分に分け、細かい成分を捨てる）
     ⑤-5 ほかの使い道と参考サイト
   ========================================================================= */
'use strict';
/* ---------- 高速フーリエ変換（FFT、基数 2）。re・im はその場で書きかえる。inv：逆変換（1/N もかける） ---------- */
function m5FFT(re, im, inv) {
  var n = re.length, i, j, k, m;
  for (i = 1, j = 0; i < n; i++) { var bit = n >> 1; for (; j & bit; bit >>= 1) j ^= bit; j ^= bit; if (i < j) { var tr = re[i]; re[i] = re[j]; re[j] = tr; var ti = im[i]; im[i] = im[j]; im[j] = ti; } }
  for (m = 2; m <= n; m <<= 1) {
    var ang = (inv ? 2 : -2) * Math.PI / m, wr = Math.cos(ang), wi = Math.sin(ang);
    for (i = 0; i < n; i += m) {
      var cr = 1, ci = 0;
      for (k = 0; k < m / 2; k++) {
        var a = i + k, b = a + m / 2, xr = re[b] * cr - im[b] * ci, xi = re[b] * ci + im[b] * cr;
        re[b] = re[a] - xr; im[b] = im[a] - xi; re[a] += xr; im[a] += xi;
        var t = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = t;
      }
    }
  }
  if (inv) for (i = 0; i < n; i++) { re[i] /= n; im[i] /= n; }
}
/* 決まった乱数（毎回同じ） */
function m5Rnd(seed) { var r = seed; return function () { r = (r * 1103515245 + 12345) & 0x7fffffff; return r / 0x7fffffff; }; }
/* セクション共通：右の列にスライダーを移し、再生のバーを隠す */
function m5Layout(s) {
  s.R.innerHTML = '';
  if (s.def.vars && s.def.vars.length) { var sw = el('div', 'row2 sliders inR'); sw.appendChild(s.varbox); s.R.appendChild(sw); s.varbox.classList.add('inR'); }
  m3TimeBar(s, false); m4NoPlay(s);
}

/* =========================================================================
   ⑤-1 フーリエ変換とは何か
   ・いろいろな波形 y(t) を N = 1024 点で取り、FFT で振動数の成分（振幅）を求める（本当に計算している）
   ・逆変換：大きい成分から n 個だけ使って波形を作り直す（④-1 の倍音の合成と同じ）
   ========================================================================= */
var M5S1_SRC = [
  /* 20 回目：1 Hz では聞こえないので 400 Hz に（横軸は 2 周期分 = 5 ms） */
  { k: 'two', nm: '400 Hz と 800 Hz の正弦波', Tw: 0.005, FM: 2000, unit: 'ms', f: function (t) { return Math.sin(TAU * 400 * t) + 0.6 * Math.sin(TAU * 800 * t); }, play: function () { return [{ f: 400, amp: 1 }, { f: 800, amp: 0.6 }]; } },
  { k: 'sq', nm: '矩形波（400 Hz）', Tw: 0.005, FM: 8000, unit: 'ms', f: function (t) { var u = t * 400 - Math.floor(t * 400); return u < 0.5 ? 1 : -1; }, play: function () { var p = []; for (var n = 1; n <= 39; n += 2) p.push([n, 1 / n]); return [{ f: 400, partials: p }]; } },
  { k: 'ch', nm: 'ド・ミ・ソの和音', Tw: 0.05, FM: 1000, unit: 'ms', f: function (t) { return (Math.sin(TAU * 261.63 * t) + Math.sin(TAU * 329.63 * t) + Math.sin(TAU * 392 * t)) / 1.5; }, play: function () { return [{ f: 261.63 }, { f: 329.63 }, { f: 392 }]; } },
  { k: 'va', nm: '声「あ」（220 Hz）', Tw: 0.05, FM: 4000, unit: 'ms', f: null, play: function () { return [{ f: 220, partials: m3Voice('a', 220) }]; } }
];
(function () {   /* 声「あ」の波形：倍音の表から（③-1 と同じ）。いちばん大きい所を 1 に */
  var src = M5S1_SRC[3], p = m3Voice('a', 220), mx = 0;
  var raw = function (t) { var y = 0; p.forEach(function (q) { y += q[1] * Math.sin(TAU * q[0] * 220 * t); }); return y; };
  for (var i = 0; i < 2000; i++) mx = Math.max(mx, Math.abs(raw(i / 2000 / 220)));
  src.f = function (t) { return raw(t) / mx; };
})();
/* 波形を N 点で取り、FFT。返り値：成分の表 [{ f, a, ph }]（振幅の大きい順ではなく振動数の順。1% 未満は捨てる） */
function m5s1Spec(src) {
  if (src._sp) return src._sp;
  var N = 1024, re = new Float64Array(N), im = new Float64Array(N);
  for (var i = 0; i < N; i++) re[i] = src.f(src.Tw * i / N);
  m5FFT(re, im, false);
  var out = [], mx = 0;
  for (var k = 1; k < N / 2; k++) { var a = 2 * Math.sqrt(re[k] * re[k] + im[k] * im[k]) / N; mx = Math.max(mx, a); out.push({ f: k / src.Tw, a: a, ph: Math.atan2(im[k], re[k]) }); }
  return (src._sp = out.filter(function (c) { return c.a > mx * 0.01; }));
}
DEFS.m5s1 = {
  id: 'm5s1', mode: 'mode5', num: 1,
  title: 'フーリエ変換とは何か', short: 'フーリエ変換とは',
  desc: 'どんなに複雑な波も、いろいろな振動数の正弦波の重ね合わせで表せる。波の形（<b>時間</b>で見た姿）から、どの振動数の正弦波がどれだけ含まれているか（<b>振動数</b>で見た姿）を求める計算を<b>フーリエ変換</b>という。<span class="todo">波を選び、使う成分の数を変えて、元の波に戻る様子を見よう。</span>',
  strobe: false, stepDiv: 16,
  varCols: [['n']],   /* 名前と値を上、スライダーを下の段に（スマホで細くならないように） */
  vars: [{ k: 'n', label: '使う成分の数 $n$', aria: '使う成分の数', min: 1, max: 30, step: 1, def: 30, fmt: function (x) { return Math.round(x) + ' 個'; } }],
  init: function (s) { s.si = 0; },
  onDefaults: function (s) { s.si = 0; m5s1Sync(s); },
  onChanged: function (s) { m5s1Sync(s); return 'keepT'; },
  buttons: M5S1_SRC.map(function (c, i) { return { k: 'w' + i, label: c.nm, seg: 'src', segLabel: '波', onClick: function (s) { s.si = i; m5s1Sync(s); s.resound && AUDIO.owner() === 'm5s1' && s.resound(); s.draw(); } }; }),
  tEnd: function () { return 1e6; }, tInfo: function () { return ''; }, gT: function () { return 1; },
  height: function (s, w) { return w < 560 ? 560 : 330; },
  afterBuild: function (s) {
    m5Layout(s);
    var sp = el('span', 'spkrow'); s.row1b.appendChild(sp);
    m3SpkBtn(s, sp, function () { var c = M5S1_SRC[s.si]; return { voices: c.play(), vol: 0.8 }; });
    s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);
    m5s1Sync(s);
  },
  draw: function (s, ctx, W, H) { drawM5S1(s, ctx, W, H); },
  right: function (s, R) { rightM5S1(s, R); }
};
function m5s1Sync(s) { m2Sync(s, M5S1_SRC.map(function (c, i) { return ['w' + i, s.si === i]; })); if (s.Rdyn) s.renderRight(); }
function drawM5S1(s, ctx, W, H) {
  var c = M5S1_SRC[s.si], sp = m5s1Spec(c), n = Math.round(s.v.n), nar = W < 560;
  var use = sp.slice().sort(function (a, b) { return b.a - a.a; }).slice(0, n);   /* 大きい成分から n 個 */
  var rec = function (t) { var y = 0; use.forEach(function (q) { y += q.a * Math.cos(TAU * q.f * t + q.ph); }); return y; };
  /* 左（上）：時間で見た波形。右（下）：振動数で見た成分 */
  var pw = nar ? W - 16 : Math.round((W - 70) / 2), ph = nar ? Math.round((H - 120) / 2) : H - 70;
  var A = { x: 8, y: 34, w: pw, h: ph }, B = nar ? { x: 8, y: 34 + ph + 86, w: pw, h: ph } : { x: W - 8 - pw, y: 34, w: pw, h: ph };
  [[A, '時間で見た波形（時間領域）', '時間'], [B, '振動数で見た成分（周波数領域）', '振動数']].forEach(function (q) {
    var P = q[0]; ctx.save(); ctx.fillStyle = '#fafbfc'; ctx.strokeStyle = '#d5dae0'; rrect(ctx, P.x, P.y, P.w, P.h, 8); ctx.fill(); ctx.stroke(); ctx.restore();
    label(ctx, q[1], P.x + 6, P.y - 12, { size: nar ? 11 : 12.5, bold: true, color: COL.ink, align: 'left' });
  });
  /* 時間の図 */
  var yM = 2.0, ax0 = A.x + 30, ax1 = A.x + A.w - 10, aym = A.y + A.h / 2 - 6, ayA = (A.h / 2 - 22) / yM;
  var XT = function (t) { return ax0 + t / c.Tw * (ax1 - ax0); }, YT = function (y) { return aym - y * ayA; };
  ctx.save(); ctx.strokeStyle = '#9aa3ad'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(ax0, aym + 0.5); ctx.lineTo(ax1, aym + 0.5); ctx.moveTo(ax0 + 0.5, A.y + 10); ctx.lineTo(ax0 + 0.5, A.y + A.h - 22); ctx.stroke(); ctx.restore();
  for (var k = 0; k <= 4; k++) { var tt = c.Tw * k / 4; label(ctx, c.unit === 'ms' ? String(Math.round(tt * 1e5) / 100) : String(tt), XT(tt), A.y + A.h - 12, { size: 9.5, color: COL.sub }); }
  label(ctx, '時間〔' + c.unit + '〕', ax1, A.y + A.h - 26, { size: 9.5, color: COL.sub, align: 'right' });
  plotF(ctx, c.f, 0, c.Tw, XT, YT, '#14171c', 2);
  if (n < sp.length || true) plotF(ctx, rec, 0, c.Tw, XT, YT, 'rgba(224,123,24,.9)', 1.8, [6, 4]);
  label(ctx, '黒：元の波　オレンジの点線：成分 ' + Math.min(n, sp.length) + ' 個から戻した波', A.x + 8, A.y + 12, { size: 9.5, bold: true, color: COL.ink2, align: 'left' });
  /* 振動数の図：成分の棒 */
  var bx0 = B.x + 30, bx1 = B.x + B.w - 12, by1 = B.y + B.h - 24, by0 = B.y + 22, mx = 0;
  sp.forEach(function (q) { mx = Math.max(mx, q.a); });
  var XF = function (f) { return bx0 + f / c.FM * (bx1 - bx0); };
  ctx.save(); ctx.strokeStyle = '#9aa3ad'; ctx.beginPath(); ctx.moveTo(bx0, by1 + 0.5); ctx.lineTo(bx1, by1 + 0.5); ctx.moveTo(bx0 + 0.5, by0 - 6); ctx.lineTo(bx0 + 0.5, by1); ctx.stroke(); ctx.restore();
  for (var j = 0; j <= 5; j++) label(ctx, String(c.FM * j / 5), XF(c.FM * j / 5), by1 + 11, { size: 9.5, color: COL.sub });
  label(ctx, '振動数〔Hz〕', bx1, by1 - 10, { size: 9.5, color: COL.sub, align: 'right' });
  var useSet = use.map(function (q) { return q.f; });
  sp.forEach(function (q) {
    if (q.f > c.FM) return;
    var x = XF(q.f), on = useSet.indexOf(q.f) >= 0, h = q.a / mx * (by1 - by0);
    ctx.save(); ctx.strokeStyle = on ? '#e07b18' : '#b8c0c9'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(x, by1); ctx.lineTo(x, by1 - h); ctx.stroke(); ctx.fillStyle = ctx.strokeStyle; ctx.beginPath(); ctx.moveTo(x, by1 - h - 6); ctx.lineTo(x - 4, by1 - h + 1); ctx.lineTo(x + 4, by1 - h + 1); ctx.closePath(); ctx.fill(); ctx.restore();
  });
  label(ctx, 'オレンジ：戻すのに使った成分（大きい順に ' + Math.min(n, sp.length) + ' 個）', B.x + 8, B.y + 12, { size: 9.5, bold: true, color: COL.ink2, align: 'left' });
  /* 矢印：フーリエ変換 → ／ ← 逆変換 */
  if (!nar) {
    var mx2 = (A.x + A.w + B.x) / 2, my = A.y + A.h / 2;
    m5Arrow(ctx, A.x + A.w + 6, my - 14, B.x - 6, my - 14, '#1c8f4a'); label(ctx, 'フーリエ変換', mx2, my - 28, { size: 10.5, bold: true, color: '#1c8f4a' });
    m5Arrow(ctx, B.x - 6, my + 14, A.x + A.w + 6, my + 14, '#1663b5'); label(ctx, '逆変換', mx2, my + 30, { size: 10.5, bold: true, color: '#1663b5' });
  } else {
    var ay = A.y + A.h + 26; m5Arrow(ctx, W / 2 - 40, ay - 8, W / 2 - 40, ay + 14, '#1c8f4a'); label(ctx, 'フーリエ変換', W / 2 - 48, ay + 3, { size: 10, bold: true, color: '#1c8f4a', align: 'right' });
    m5Arrow(ctx, W / 2 + 40, ay + 14, W / 2 + 40, ay - 8, '#1663b5'); label(ctx, '逆変換', W / 2 + 48, ay + 3, { size: 10, bold: true, color: '#1663b5', align: 'left' });
  }
}
function m5Arrow(ctx, x0, y0, x1, y1, col) {
  var a = Math.atan2(y1 - y0, x1 - x0);
  ctx.save(); ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1 - 8 * Math.cos(a), y1 - 8 * Math.sin(a)); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x1 - 11 * Math.cos(a - 0.45), y1 - 11 * Math.sin(a - 0.45)); ctx.lineTo(x1 - 11 * Math.cos(a + 0.45), y1 - 11 * Math.sin(a + 0.45)); ctx.closePath(); ctx.fill(); ctx.restore();
}
function rightM5S1(s, R) {
  var c = M5S1_SRC[s.si], sp = m5s1Spec(c);
  R.innerHTML = mathify('<div class="qcard"><p class="qt">フーリエ変換</p>' +
    '<p>①〜④では、波を「いろいろな振動数の正弦波の重ね合わせ」として見てきた（④-1 の音色づくりは、成分から波を作る<b>逆変換</b>そのもの）。反対に、波形から成分を求めるのが<b>フーリエ変換</b>。</p>' +
    '<p>時間で見ると何が起きているか分かりにくい波も、振動数で見ると「何 Hz の成分がどれだけあるか」がひと目で分かる。</p>' +
    '<div class="qeq">$$F(f) = \\int_{-\\infty}^{\\infty} y(t)\\, e^{-i 2\\pi f t}\\, dt$$</div>' +
    '<p class="qnote">大学で学ぶ式（詳しくは ⑤-5 の参考サイトで）。$e^{-i2\\pi ft}$ は「振動数 $f$ の正弦波」を表し、波 $y(t)$ に振動数 $f$ の成分がどれだけ含まれるかを足し合わせて求めている。コンピュータでは高速フーリエ変換（FFT）という速い計算方法を使う。この図も、ページの中で本当に FFT を計算している。</p>' +
    '<p class="qnow"><span class="qtag now">いま</span>' + c.nm + '：成分 ' + sp.length + ' 個（' + (sp.length <= 12 ? sp.map(function (q) { return (Math.round(q.f * 100) / 100) + ' Hz'; }).join('、') : '振動数のとびとびの値') + '）</p>' +
    (c.k === 'sq' ? '<p class="qnote">矩形波は 400・1200・2000・2800 … Hz の成分（400 Hz の奇数倍）でできている。成分の数を減らすと角が丸くなる。かどの所の小さな出っぱりは、成分が有限個のときにかならず残る（ギブズ現象）。</p>' : '') +
    '</div>');
}

/* =========================================================================
   ⑤-2 音の加工（イコライザー・ノイズカット）
   ・音：ド・ミ・ソ（中音）＋低いド（C2、低音）＋「サー」というノイズ（高音まで平らに広がる）。2.97 s（22050 Hz × 65536 点）
   ・FFT で振動数の成分にし、低音（〜250 Hz）・中音（250〜2000 Hz）・高音（2000 Hz〜）の大きさを変えて、逆変換で音にもどす
   ========================================================================= */
var M5S2 = { sr: 22050, N: 65536 };
function m5s2Orig() {
  if (M5S2.x) return M5S2.x;
  var N = M5S2.N, sr = M5S2.sr, x = new Float32Array(N), rnd = m5Rnd(2026);
  var notes = [[261.63, 0.16], [329.63, 0.13], [392.0, 0.13]], bass = 65.41;
  for (var i = 0; i < N; i++) {
    var t = i / sr, y = 0;
    notes.forEach(function (q) { y += q[1] * (Math.sin(TAU * q[0] * t) + 0.45 * Math.sin(TAU * 2 * q[0] * t) + 0.2 * Math.sin(TAU * 3 * q[0] * t)); });
    y += 0.22 * (Math.sin(TAU * bass * t) + 0.35 * Math.sin(TAU * 2 * bass * t));
    y += 0.11 * (rnd() * 2 - 1);
    var e = Math.min(1, i / 600, (N - 1 - i) / 600); x[i] = y * e;   /* くり返しのつなぎ目をなめらかに */
  }
  var re = new Float64Array(N), im = new Float64Array(N); for (var j = 0; j < N; j++) re[j] = x[j];
  m5FFT(re, im, false); M5S2.X = { re: re, im: im };
  return (M5S2.x = x);
}
/* 振動数 f のときの倍率（帯の境目はなめらかにつなぐ） */
function m5s2Gain(s, f) {
  var lf = Math.log(Math.max(f, 1)), s1 = 1 / (1 + Math.exp((lf - Math.log(250)) * 8)), s3 = 1 / (1 + Math.exp(-(lf - Math.log(2000)) * 8)), s2 = Math.max(0, 1 - s1 - s3);
  return s.v.gL * s1 + s.v.gM * s2 + s.v.gH * s3;
}
function m5s2Proc(s) {
  var key = [s.v.gL, s.v.gM, s.v.gH].join('|'); if (s._pk === key) return s._py; s._pk = key;
  m5s2Orig(); var N = M5S2.N, sr = M5S2.sr, X = M5S2.X, re = new Float64Array(N), im = new Float64Array(N);
  for (var k = 0; k < N; k++) { var f = (k <= N / 2 ? k : N - k) * sr / N, g = m5s2Gain(s, f); re[k] = X.re[k] * g; im[k] = X.im[k] * g; }
  m5FFT(re, im, true);
  var y = new Float32Array(N); for (var i = 0; i < N; i++) y[i] = clamp(re[i], -1, 1);
  s._spY = null; return (s._py = y);
}
/* 対数の振動数の帯ごとの大きさ（dB）。X：{re, im} */
function m5s2Bands(X, gainFn) {
  var N = M5S2.N, sr = M5S2.sr, nb = 120, f0 = 30, f1 = 11000, out = [];
  for (var b = 0; b < nb; b++) {
    var fa = f0 * Math.pow(f1 / f0, b / nb), fb = f0 * Math.pow(f1 / f0, (b + 1) / nb), ka = Math.max(1, Math.floor(fa * N / sr)), kb = Math.max(ka + 1, Math.ceil(fb * N / sr)), mx = 0;
    for (var k = ka; k < kb; k++) { var g = gainFn ? gainFn(k * sr / N) : 1, a = Math.sqrt(X.re[k] * X.re[k] + X.im[k] * X.im[k]) * g; mx = Math.max(mx, a); }
    out.push({ f: Math.sqrt(fa * fb), db: 20 * Math.log(mx / N * 2 + 1e-9) / Math.LN10 });
  }
  return out;
}
DEFS.m5s2 = {
  id: 'm5s2', mode: 'mode5', num: 2,
  title: '音の加工（ノイズを消す・低音を強める）', short: '音の加工',
  desc: '録音した音をフーリエ変換すると、振動数ごとの成分に分かれる。ほしくない成分を小さくしたり、強めたい成分を大きくしたりしてから逆変換すれば、音を作り直せる（<b>イコライザー</b>）。<span class="todo">3 つの帯の大きさを変えて、元の音と聞き比べよう。</span>',
  strobe: false, stepDiv: 16,
  varCols: [['gL', 'gM', 'gH']],
  vars: [
    { k: 'gL', label: '低音（〜250 Hz）', aria: '低音の大きさ', min: 0, max: 2, step: 0.1, def: 1, fmt: function (x) { return Math.round(x * 100) + ' %'; } },
    { k: 'gM', label: '中音（250〜2000 Hz）', aria: '中音の大きさ', min: 0, max: 2, step: 0.1, def: 1, fmt: function (x) { return Math.round(x * 100) + ' %'; } },
    { k: 'gH', label: '高音（2000 Hz〜）', aria: '高音の大きさ', min: 0, max: 2, step: 0.1, def: 1, fmt: function (x) { return Math.round(x * 100) + ' %'; } }
  ],
  init: function (s) { s.which = 'proc'; },
  onDefaults: function (s) { s.which = 'proc'; m5s2Sync(s); m5s2Sound(s); },
  onChanged: function (s) { m5s2Sync(s); m5s2Sound(s, true); return 'keepT'; },
  buttons: [
    { k: 'wO', label: '元の音', seg: 'which', segLabel: '聞く音', onClick: function (s) { s.which = 'orig'; m5s2Sync(s); s.resound && s.resound(); } },
    { k: 'wP', label: '加工した音', seg: 'which', onClick: function (s) { s.which = 'proc'; m5s2Sync(s); s.resound && s.resound(); } },
    { k: 'pN', label: 'ノイズカット（高音を 0 に）', seg: 'pre', segLabel: 'おすすめ', onClick: function (s) { m5s2Set(s, 1, 1, 0); } },
    { k: 'pB', label: '低音を強調', seg: 'pre', onClick: function (s) { m5s2Set(s, 2, 1, 1); } },
    { k: 'pB2', label: '低音をより強調', seg: 'pre', onClick: function (s) { m5s2Set(s, 2, 0.5, 0.5); } },   /* 中音・高音を小さくする（22 回目） */
    { k: 'pV', label: 'ラジオ風（中音だけ）', seg: 'pre', onClick: function (s) { m5s2Set(s, 0, 1.4, 0); } }
  ],
  tEnd: function () { return 1e6; }, tInfo: function () { return ''; }, gT: function () { return 1; },
  height: function (s, w) { return w < 560 ? 380 : 340; },
  afterBuild: function (s) {
    m5Layout(s);
    /* 「聞く音」は ④-6 の純正律・平均律と同じ選ぶ形（どちらを選んでいるか分かるように。20 回目）。鳴らす・止めるは 🔊 のボタン */
    var sp = el('span', 'spkrow'); s.row1b.appendChild(sp);
    m3SpkBtn(s, sp, function () { return { voices: [{ data: s.which === 'orig' ? m5s2Orig() : m5s2Proc(s), sr: M5S2.sr }], vol: 1 }; });
    s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);
    m5s2Sync(s);
  },
  draw: function (s, ctx, W, H) { drawM5S2(s, ctx, W, H); },
  right: function (s, R) { rightM5S2(s, R); }
};
/* M5S2_PRE：おすすめの値。いまの値と同じものを選ばれた形にする（どれが ON か分かるように。22 回目） */
var M5S2_PRE = { pN: [1, 1, 0], pB: [2, 1, 1], pB2: [2, 0.5, 0.5], pV: [0, 1.4, 0] };
function m5s2Sync(s) {
  var a = [['wO', s.which === 'orig'], ['wP', s.which === 'proc']];
  Object.keys(M5S2_PRE).forEach(function (k) { var p = M5S2_PRE[k]; a.push([k, Math.abs(s.v.gL - p[0]) < 1e-6 && Math.abs(s.v.gM - p[1]) < 1e-6 && Math.abs(s.v.gH - p[2]) < 1e-6]); });
  m2Sync(s, a);
}
function m5s2Set(s, a, b, c) { s.v.gL = a; s.v.gM = b; s.v.gH = c; s.syncSliders && s.syncSliders(); s.which = 'proc'; m5s2Sync(s); m5s2Sound(s, true); s.draw(); s.renderRight(); }
/* 値を変えたとき：加工した音を鳴らしていれば鳴らし直す */
function m5s2Sound(s) { if (s.which === 'proc' && s.resound) s.resound(); }
function drawM5S2(s, ctx, W, H) {
  var nar = W < 560; m5s2Orig(); var y = m5s2Proc(s);
  var bo = s._bo || (s._bo = m5s2Bands(M5S2.X, null)), bp = m5s2Bands(M5S2.X, function (f) { return m5s2Gain(s, f); });
  /* 上：スペクトル（対数の振動数） */
  var x0 = 40, x1 = W - 10, y0 = 30, y1 = Math.round(H * 0.56), dbLo = -90, dbHi = -10;
  var XF = function (f) { return x0 + Math.log(f / 30) / Math.log(11000 / 30) * (x1 - x0); }, YD = function (d) { return y1 - (clamp(d, dbLo, dbHi) - dbLo) / (dbHi - dbLo) * (y1 - y0); };
  label(ctx, '振動数の成分（灰色：元の音、緑：加工した音）', 8, 12, { size: nar ? 11 : 12.5, bold: true, color: COL.ink, align: 'left' });
  [[30, 250, '#e9f1fb', '低音'], [250, 2000, '#f3f8ee', '中音'], [2000, 11000, '#fdf3e7', '高音']].forEach(function (b) { ctx.save(); ctx.fillStyle = b[2]; ctx.fillRect(XF(b[0]), y0, XF(b[1]) - XF(b[0]), y1 - y0); ctx.restore(); label(ctx, b[3], (XF(b[0]) + XF(b[1])) / 2, y1 - 9, { size: 10, bold: true, color: COL.sub }); });
  [50, 100, 200, 500, 1000, 2000, 5000, 10000].forEach(function (f) { label(ctx, f >= 1000 ? (f / 1000) + 'k' : String(f), XF(f), y1 + 11, { size: 9, color: COL.sub }); });
  label(ctx, 'Hz', x1, y1 + 24, { size: 9, color: COL.sub, align: 'right' });
  var line = function (B, col, lw) { ctx.save(); ctx.strokeStyle = col; ctx.lineWidth = lw; ctx.beginPath(); B.forEach(function (q, i) { var px = XF(q.f), py = YD(q.db); if (i) ctx.lineTo(px, py); else ctx.moveTo(px, py); }); ctx.stroke(); ctx.restore(); };
  line(bo, '#9aa3ad', 1.4); line(bp, '#1c8f4a', 2);
  label(ctx, 'ド・ミ・ソ', XF(330), YD(-22) - 8, { size: 10, bold: true, color: COL.ink2 });
  label(ctx, '低いド', XF(66), YD(-22) - 8, { size: 10, bold: true, color: COL.ink2 });
  label(ctx, 'ノイズ（サー）', XF(5000), YD(-55) - 14, { size: 10, bold: true, color: COL.ink2 });
  /* 下：波形（はじめの 30 ms） */
  var gy0 = y1 + 46, gy1 = H - 8, gm = (gy0 + gy1) / 2, ga = (gy1 - gy0) / 2 - 4, n = Math.round(0.03 * M5S2.sr), xo = m5s2Orig();
  label(ctx, '波形（0.3 s から 30 ms 間）　灰色：元の音、緑：加工した音', 8, gy0 - 10, { size: nar ? 10 : 11.5, bold: true, color: COL.ink2, align: 'left' });
  ctx.save(); ctx.strokeStyle = '#d5dae0'; ctx.beginPath(); ctx.moveTo(x0, gm + 0.5); ctx.lineTo(x1, gm + 0.5); ctx.stroke(); ctx.restore();
  [[xo, '#9aa3ad', 1.2], [y, '#1c8f4a', 1.6]].forEach(function (q) { ctx.save(); ctx.strokeStyle = q[1]; ctx.lineWidth = q[2]; ctx.beginPath(); for (var i = 0; i <= n; i++) { var px = x0 + (x1 - x0) * i / n, py = gm - q[0][6615 + i] / 0.6 * ga; if (i) ctx.lineTo(px, py); else ctx.moveTo(px, py); } ctx.stroke(); ctx.restore(); });
}
function rightM5S2(s, R) {
  R.innerHTML = mathify('<div class="qcard"><p class="qt">音楽をつくる人の仕事</p>' +
    '<p>録音した声や楽器の音には、ほしくないノイズ（「サー」という音や、低い「ブーン」という音）が混ざる。フーリエ変換で振動数ごとに分けると、ノイズのある振動数だけを小さくできる。</p>' +
    '<p>音楽プロデューサーやエンジニアは、低音を強めて迫力を出したり、こもる帯を少しけずったり、高すぎる成分をカットしたりして、曲全体の聞こえ方を整える（ミキシング・マスタリング）。ふだん聞いているアーティストの音源は、こうして整えられたもの。スマートフォンの音楽アプリの「イコライザー」も同じしくみ。</p>' +
    '<p class="qnote">この図の音：ド・ミ・ソ（中音）・低いド（C2 = 65 Hz、低音）・ノイズ。ノイズはあらゆる振動数に広がっているので、高音をカットすると「サー」は小さくなるが、中音・低音の中のノイズは残る。</p>' +
    '<p class="qnote">低音だけにすると、ノート PC やスマートフォンの内蔵スピーカーでは、ほとんど聞こえない（200 Hz より低い音がほとんど出ない）。イヤホンやヘッドホンで聞こう。</p></div>');
}

/* =========================================================================
   ⑤-3 電波で送る・受け取る（ラジオ）
   ・放送局 A・B・C は、それぞれの音を決まった振動数（搬送波）の電波にのせて送る（AM 放送：搬送波の振幅を音で変える）
   ・音にふくまれる振動数 fm は、電波では搬送波 fc の両どなり fc ± fm に移る（電波のスペクトル）
   ・アンテナには全部の電波がまざって届く。ラジオは振動数で 1 つだけ選んで取り出す（フィルター）。日本の AM 放送は 9 kHz おき
   ========================================================================= */
var M5S3_ST = [
  { nm: '放送局 A', fc: 594, col: '#d1353f', what: '声「あ」', v: function () { return [{ f: 220, partials: m3Voice('a', 220) }]; } },   /* ⑤-1 の声「あ」と同じ 220 Hz（22 回目） */
  { nm: '放送局 B', fc: 693, col: '#1663b5', what: 'フルートの音（ラ 880 Hz）', v: function () { return [{ f: 880, partials: M3_INST.flute }]; } },
  { nm: '放送局 C', fc: 954, col: '#c9970c', what: 'ド・ミ・ソの和音', v: function () { return [{ f: 261.63, partials: [[1, 1], [2, 0.4]] }, { f: 329.63, partials: [[1, 1], [2, 0.4]] }, { f: 392, partials: [[1, 1], [2, 0.4]] }]; } }
];
function m5s3Tune(s) {
  var best = null; M5S3_ST.forEach(function (st) { var d = Math.abs(s.v.tu - st.fc); if (!best || d < best.d) best = { st: st, d: d }; });
  best.q = best.d <= 1.5 ? 1 : (best.d <= 4.5 ? 0.5 : 0);   /* 1：きれいに入る、0.5：ノイズまじり、0：入らない */
  return best;
}
DEFS.m5s3 = {
  id: 'm5s3', mode: 'mode5', num: 3,
  title: '電波で送る・受け取る（ラジオ・電話）', short: '電波で送る',
  desc: 'ラジオやスマートフォンの電波は、それぞれ決まった振動数を使っている。アンテナには何十もの電波が混ざって届くが、振動数で分けて（フーリエ変換の考え方）、ほしい 1 つだけを取り出している。<span class="todo">受信する振動数を変えて、放送局を選ぼう。</span>',
  strobe: false, stepDiv: 16,
  vars: [{ k: 'tu', label: '受信する振動数', aria: '受信する振動数', min: 520, max: 1060, step: 1, def: 594, fmt: function (x) { return Math.round(x) + ' kHz'; } }],
  init: function (s) { },
  onDefaults: function (s) { m5s3Resound(s); },
  onChanged: function (s) { m5s3Resound(s); return 'keepT'; },
  buttons: M5S3_ST.map(function (st, i) { return { k: 'st' + i, label: st.nm + '（' + st.fc + ' kHz）', seg: 'st', segLabel: '合わせる', onClick: function (s) { s.v.tu = st.fc; s.syncSliders && s.syncSliders(); m5s3Resound(s); s.draw(); s.renderRight(); } }; }),
  tEnd: function () { return 1e6; }, tInfo: function () { return ''; }, gT: function () { return 1; },
  height: function (s, w) { return w < 560 ? 572 : 530; },
  afterBuild: function (s) {
    m5Layout(s);
    var sp = el('span', 'spkrow'); s.row1b.appendChild(sp);
    m3SpkBtn(s, sp, function () { return m5s3Voices(s); });
    /* 受信する振動数は、図の中の家のアンテナの上に置く（20 回目） */
    var sl = s.R.querySelector('.row2.sliders'); if (sl) sl.style.display = 'none';
    s.cw.style.position = 'relative';
    var tb = el('div', 'm5tune'), tl = el('div', 'm5tl'), rg = el('input');
    rg.type = 'range'; rg.min = '520'; rg.max = '1060'; rg.step = '1'; rg.value = String(s.v.tu); rg.setAttribute('aria-label', '受信する振動数');
    rg.addEventListener('input', function () { s.v.tu = +rg.value; m5s3Resound(s); s.draw(); });
    tb.appendChild(tl); tb.appendChild(rg); s.cw.appendChild(tb); s.tuneBox = tb; s.tuneRg = rg; s.tuneL = tl;
    s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);
  },
  draw: function (s, ctx, W, H) { drawM5S3(s, ctx, W, H); var b = m5s3Tune(s); m2Sync(s, M5S3_ST.map(function (st, i) { return ['st' + i, b.q === 1 && b.st === st]; })); },
  right: function (s, R) { rightM5S3(s, R); }
};
function m5s3Voices(s) {
  var b = m5s3Tune(s), v = [];
  if (b.q > 0) b.st.v().forEach(function (o) { o.amp = b.q; v.push(o); });
  if (b.q < 1) v.push({ noise: true, f: 1000, amp: b.q ? 0.25 : 0.35 });
  return { voices: v, vol: 0.7 };
}
function m5s3Resound(s) { if (AUDIO.owner() === 'm5s3' && s.resound) s.resound(); if (s.Rdyn) s.renderRight(); }
function drawM5S3(s, ctx, W, H) {
  var nar = W < 560, b = m5s3Tune(s), SH = nar ? 210 : 200;
  m5s3Scene(s, ctx, W, SH, nar, b);
  ctx.save(); ctx.translate(0, SH); H -= SH;
  /* 上：アンテナに届く電波のスペクトル（kHz） */
  var x0 = 30, x1 = W - 10, y0 = 34, y1 = Math.round(H * 0.5), FA = 520, FB = 1060;
  var XF = function (f) { return x0 + (f - FA) / (FB - FA) * (x1 - x0); };
  label(ctx, 'アンテナに届く電波の振動数の成分（スペクトル）', 8, 12, { size: nar ? 11 : 12.5, bold: true, color: COL.ink, align: 'left' });
  ctx.save(); ctx.strokeStyle = '#9aa3ad'; ctx.beginPath(); ctx.moveTo(x0, y1 + 0.5); ctx.lineTo(x1, y1 + 0.5); ctx.stroke(); ctx.restore();
  [600, 700, 800, 900, 1000].forEach(function (f) { label(ctx, String(f), XF(f), y1 + 11, { size: 9.5, color: COL.sub }); });
  label(ctx, 'kHz', x1, y1 + 24, { size: 9.5, color: COL.sub, align: 'right' });
  /* 受信の窓（± 4.5 kHz）。見やすいように幅を広げて描く */
  var tw = Math.max(10, XF(FA + 9) - XF(FA)), tx = XF(s.v.tu);
  ctx.save(); ctx.fillStyle = 'rgba(224,123,24,.18)'; ctx.fillRect(tx - tw / 2, y0, tw, y1 - y0); ctx.strokeStyle = '#e07b18'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(tx, y0 - 4); ctx.lineTo(tx, y1); ctx.stroke(); ctx.restore();
  label(ctx, '受信 ' + Math.round(s.v.tu) + ' kHz', clamp(tx, 50, W - 50), y0 - 8, { size: 10.5, bold: true, color: '#c9670c' });
  M5S3_ST.forEach(function (st) {
    var xc = XF(st.fc), hC = (y1 - y0) * 0.75, sideW = Math.max(14, tw * 0.9);
    /* 搬送波と、音の成分が移った両どなり（形は音のスペクトル。幅は見やすく広げた） */
    ctx.save(); ctx.strokeStyle = st.col; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(xc, y1); ctx.lineTo(xc, y1 - hC); ctx.stroke(); ctx.restore();
    var parts = []; st.v().forEach(function (o) { (o.partials || [[1, 1]]).forEach(function (p) { parts.push([o.f * p[0], Math.abs(p[1])]); }); });
    var mx = 0; parts.forEach(function (p) { mx = Math.max(mx, p[1]); });
    parts.forEach(function (p) { if (p[0] > 4500) return; var dx = p[0] / 4500 * sideW, h = p[1] / mx * hC * 0.45; [-1, 1].forEach(function (sg) { ctx.save(); ctx.strokeStyle = st.col; ctx.globalAlpha = 0.75; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(xc + sg * dx, y1); ctx.lineTo(xc + sg * dx, y1 - h); ctx.stroke(); ctx.restore(); }); });
    label(ctx, nar ? st.nm.replace('放送局 ', '') : st.nm, xc, y1 - hC - 10, { size: nar ? 10 : 11, bold: true, color: st.col });
  });
  /* 下：取り出した音の波形 */
  var gy0 = y1 + 50, gy1 = H - 8, gm = (gy0 + gy1) / 2, ga = (gy1 - gy0) / 2 - 6, span = 0.02;
  var title = b.q === 1 ? b.st.nm + ' の音（' + b.st.what + '）' : (b.q ? b.st.nm + ' の音（ずれていてノイズまじり）' : '放送局がない振動数：ノイズ（ザー）だけ');
  label(ctx, '取り出した音の波形（20 ms 間）　' + title, 8, gy0 - 10, { size: nar ? 10 : 11.5, bold: true, color: COL.ink2, align: 'left' });
  ctx.save(); ctx.fillStyle = '#0d1a14'; rrect(ctx, x0 - 22, gy0 - 2, x1 - x0 + 22, gy1 - gy0 + 4, 6); ctx.fill(); ctx.restore();
  var vs = b.q > 0 ? b.st.v() : [], rnd = m5Rnd(99), nz = [];
  for (var i = 0; i <= 600; i++) nz.push(rnd() * 2 - 1);
  var sig1 = function (t) { var y = 0, m = 0; vs.forEach(function (o) { (o.partials || [[1, 1]]).forEach(function (p) { y += p[1] * Math.sin(TAU * o.f * p[0] * t); m += Math.abs(p[1]); }); }); return m ? y / m * 1.6 : 0; };
  ctx.save(); ctx.strokeStyle = '#7dffb4'; ctx.lineWidth = 1.4; ctx.beginPath();
  for (var k = 0; k <= 600; k++) { var t = span * k / 600, yv = b.q * sig1(t) + (1 - b.q) * 0.8 * nz[k] + (b.q === 0.5 ? 0.25 * nz[k] : 0), px = x0 + (x1 - x0) * k / 600, py = gm - clamp(yv, -1.2, 1.2) * ga / 1.2; if (k) ctx.lineTo(px, py); else ctx.moveTo(px, py); }
  ctx.stroke(); ctx.restore();
  ctx.restore();
}
/* 図の上の段：放送局の電波塔 A・B・C と、受信する家のアンテナ。受信する振動数の操作は、アンテナの上に置く */
function m5s3Scene(s, ctx, W, SH, nar, b) {
  var gy = SH - 14;
  ctx.save(); ctx.fillStyle = '#eef6ea'; ctx.fillRect(0, gy, W, 14); ctx.strokeStyle = '#7a9a6a'; ctx.beginPath(); ctx.moveTo(0, gy + 0.5); ctx.lineTo(W, gy + 0.5); ctx.stroke(); ctx.restore();
  var tw = nar ? 0.56 : 0.5, hx = W * (nar ? 0.8 : 0.8);
  M5S3_ST.forEach(function (st, i) {
    var x = W * (0.08 + i * tw / 3), th = (nar ? 56 : 90) - i * (nar ? 4 : 6), top = gy - th, on = b.q === 1 && b.st === st;
    /* 電波塔（鉄骨の三角） */
    ctx.save(); ctx.strokeStyle = st.col; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x - 12, gy); ctx.lineTo(x, top); ctx.lineTo(x + 12, gy); ctx.stroke();
    ctx.lineWidth = 1; for (var k = 1; k < 5; k++) { var yy = gy - th * k / 5, hw = 12 * (1 - k / 5); ctx.beginPath(); ctx.moveTo(x - hw, yy); ctx.lineTo(x + hw, yy); ctx.stroke(); }
    ctx.fillStyle = st.col; ctx.beginPath(); ctx.arc(x, top, 3.5, 0, TAU); ctx.fill();
    /* 電波（右へ広がる弧） */
    for (var r = 1; r <= 3; r++) { ctx.globalAlpha = on ? 0.85 - r * 0.18 : 0.45 - r * 0.1; ctx.lineWidth = on ? 2 : 1.4; ctx.beginPath(); ctx.arc(x, top, 9 * r, -0.7, 0.7); ctx.stroke(); }
    ctx.restore();
    label(ctx, st.nm, x, gy + 7, { size: nar ? 9 : 10, bold: true, color: st.col });
    label(ctx, st.fc + ' kHz', x, top - (nar ? 10 : 12), { size: nar ? 9 : 10, bold: true, color: st.col });
  });
  /* 家とアンテナ */
  var hw2 = nar ? 46 : 60, hh = nar ? 30 : 38, roof = gy - hh, ax = hx + hw2 * 0.25, aTop = roof - (nar ? 40 : 48);
  ctx.save(); ctx.fillStyle = '#fff'; ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.4; ctx.fillRect(hx - hw2 / 2, roof, hw2, hh); ctx.strokeRect(hx - hw2 / 2, roof, hw2, hh);
  ctx.fillStyle = '#d24a2a'; ctx.beginPath(); ctx.moveTo(hx - hw2 / 2 - 6, roof); ctx.lineTo(hx, roof - (nar ? 16 : 20)); ctx.lineTo(hx + hw2 / 2 + 6, roof); ctx.closePath(); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#9fe6f2'; ctx.fillRect(hx - hw2 / 2 + 6, roof + 7, hw2 / 2 - 10, hh / 2 - 3); ctx.strokeRect(hx - hw2 / 2 + 6, roof + 7, hw2 / 2 - 10, hh / 2 - 3);
  ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(ax, roof - 8); ctx.lineTo(ax, aTop); ctx.stroke();
  [0, 1, 2, 3].forEach(function (k) { var yy = aTop + 3 + k * 7, l = (nar ? 16 : 22) - k * 4; ctx.beginPath(); ctx.moveTo(ax - l, yy); ctx.lineTo(ax + l, yy); ctx.stroke(); });
  label(ctx, 'アンテナ', ax + (nar ? 20 : 26), aTop + 12, { size: nar ? 9 : 10, bold: true, color: COL.ink2, align: 'left' });
  ctx.restore();
  label(ctx, '受信する家（ラジオ）', hx, gy + 7, { size: nar ? 9 : 10, bold: true, color: COL.ink });
  label(ctx, nar ? 'どの電波も届く →' : 'どの電波もアンテナに届く →', (W * (0.08 + 2 * tw / 3) + hx - hw2 / 2) / 2 + 6, gy - (nar ? 26 : 30), { size: nar ? 9 : 11, bold: true, color: COL.sub });
  /* 受信する振動数の操作：アンテナの上へ */
  if (s.tuneBox) {
    var bw = nar ? 172 : 200, bx = clamp(ax - bw / 2, 4, W - bw - 12), by = Math.max(2, aTop - (nar ? 62 : 66));
    s.tuneBox.style.left = (s.cv.offsetLeft + bx) + 'px'; s.tuneBox.style.top = (s.cv.offsetTop + by) + 'px'; s.tuneBox.style.width = bw + 'px';   /* canvas の位置（枠の内側のすき間）を足す */
    var txt = '受信する振動数 <b>' + Math.round(s.v.tu) + ' kHz</b>';
    if (s.tuneL._h !== txt) { s.tuneL._h = txt; s.tuneL.innerHTML = txt; }
    if (+s.tuneRg.value !== s.v.tu) s.tuneRg.value = s.v.tu;
    ctx.save(); ctx.strokeStyle = '#e07b18'; ctx.setLineDash([3, 3]); ctx.beginPath(); ctx.moveTo(ax, by + 48); ctx.lineTo(ax, aTop - 2); ctx.stroke(); ctx.restore();
  }
}
function rightM5S3(s, R) {
  var b = m5s3Tune(s);
  R.innerHTML = mathify('<div class="qcard"><p class="qt">振動数で分けて取り出す</p>' +
    '<p>放送局は、音を決まった振動数 $f_c$ の電波（<b>搬送波</b>）にのせて送る。音に含まれる振動数 $f$ の成分は、電波では $f_c \\pm f$ に移る。だから放送局ごとに $f_c$ を少しずつずらせば（日本の AM 放送は 9 kHz おき）、同じ空間を通っても混ざらずに分けられる。</p>' +
    '<p>ラジオは、選んだ振動数の近くの成分だけを通す（フィルター）ことで 1 つの放送を取り出し、元の音に戻す。</p>' +
    '<p><b>電話（スマートフォン）</b>も、声をマイクで電気信号にし、振動数の成分に分けて大事な成分だけを数値で送る（データを小さくする）。電波もたくさんの細かい振動数に分けて、多くの人が同時に使えるようにしている（4G・5G の OFDM という方式は、FFT そのものを使う）。</p>' +
    '<p class="qnow"><span class="qtag now">いま</span>' + (b.q === 1 ? b.st.nm + '（' + b.st.fc + ' kHz）を受信中：' + b.st.what : (b.q ? b.st.nm + 'に近いがずれている' : '放送局のない振動数')) + '</p>' +
    '<p class="qnote">放送局の振動数は例。音のスペクトルの幅（片側 約 4.5 kHz）は、見やすいように図では広げてある。</p></div>');
}

/* =========================================================================
   ⑤-4 画像の圧縮（JPEG）
   ・64 × 64 画素の色つきの絵（⑤-3 の家。式で作る。22 回目に白黒から変えた）を赤・緑・青に分け、それぞれ 8 × 8 画素の区画に分け、区画ごとに 2 次元の離散コサイン変換（DCT。フーリエ変換のなかま）
   ・振動数の低い成分から順（ジグザグ）に K 個だけ残し、残りを 0 にして逆変換 → 画像の質とデータ量をくらべる
   ========================================================================= */
var M5S4 = { N: 64 };
M5S4.zz = (function () { var o = []; for (var s = 0; s < 15; s++) { var a = []; for (var i = 0; i < 8; i++) { var j = s - i; if (j >= 0 && j < 8) a.push([i, j]); } if (s % 2 === 0) a.reverse(); o = o.concat(a); } return o; })();
/* 64 × 64 画素の色つきの絵（⑤-3 の家とアンテナ。22 回目に白黒から変えた）。画素ごとに [赤, 緑, 青]（0〜1）。チャンネルごとに Float32Array */
M5S4.img = (function () {
  var N = M5S4.N, ch = [new Float32Array(N * N), new Float32Array(N * N), new Float32Array(N * N)];
  var put = function (x, y, c) { if (x < 0 || y < 0 || x >= N || y >= N) return; for (var k = 0; k < 3; k++) ch[k][y * N + x] = c[k] / 255; };
  var INK = [58, 65, 76];
  for (var y = 0; y < N; y++) for (var x = 0; x < N; x++) {
    var u = y / 54, c = [150 + 65 * u, 205 + 31 * u, 245 + 5 * u];                         /* 空（下ほど白っぽい） */
    var dx = x - 52, dy = y - 11; if (dx * dx + dy * dy < 49) c = [255, 210, 80];            /* 太陽 */
    if (y >= 54) c = ((x >> 1) + (y >> 1)) % 2 ? [120, 190, 95] : [88, 160, 70];             /* 地面（草。細かいもよう） */
    put(x, y, c);
  }
  for (y = 23; y < 36; y++) for (x = 8; x < 47; x++) { var hw = (y - 23) * 18 / 13 + 1; if (Math.abs(x - 27) <= hw) put(x, y, Math.abs(Math.abs(x - 27) - hw) < 1.2 || y === 35 ? INK : [210, 74, 42]); }   /* 屋根（赤） */
  for (y = 36; y < 54; y++) for (x = 13; x < 42; x++) put(x, y, x === 13 || x === 41 ? INK : [248, 248, 244]);   /* かべ（白） */
  for (y = 39; y < 48; y++) for (x = 17; x < 27; x++) put(x, y, x === 17 || x === 26 || y === 39 || y === 47 || x === 21 ? INK : [159, 230, 242]);   /* 窓（水色） */
  for (y = 43; y < 54; y++) for (x = 30; x < 37; x++) put(x, y, x === 30 || x === 36 || y === 43 ? INK : [150, 96, 52]);   /* 戸（茶色） */
  for (y = 10; y < 30; y++) put(36, y, INK);                                                 /* アンテナの柱 */
  [[11, 6], [14, 5], [17, 4], [20, 3]].forEach(function (q) { for (x = 36 - q[1]; x <= 36 + q[1]; x++) put(x, q[0], INK); });   /* アンテナの横の棒 */
  return ch;
})();
function m5DctC(u) { return u === 0 ? Math.sqrt(1 / 8) : Math.sqrt(2 / 8); }
M5S4.cos = (function () { var c = []; for (var x = 0; x < 8; x++) { c.push([]); for (var u = 0; u < 8; u++) c[x].push(Math.cos((2 * x + 1) * u * Math.PI / 16)); } return c; })();
/* 区画ごとの DCT 係数（1 回だけ計算）。赤・緑・青のそれぞれで同じことをする */
M5S4.coef = M5S4.img.map(function (img) {
  var N = M5S4.N, C = M5S4.cos, out = [];
  for (var by = 0; by < N; by += 8) for (var bx = 0; bx < N; bx += 8) {
    var F = [];
    for (var u = 0; u < 8; u++) { F.push([]); for (var v = 0; v < 8; v++) { var sm = 0; for (var y = 0; y < 8; y++) for (var x = 0; x < 8; x++) sm += (img[(by + y) * N + bx + x] - 0.5) * C[y][u] * C[x][v]; F[u].push(m5DctC(u) * m5DctC(v) * sm); } }
    out.push({ bx: bx, by: by, F: F });
  }
  return out;
});
function m5s4Rec(K) {
  if (M5S4['r' + K]) return M5S4['r' + K];
  var N = M5S4.N, C = M5S4.cos, keep = {};
  M5S4.zz.slice(0, K).forEach(function (p) { keep[p[0] * 8 + p[1]] = true; });
  var res = M5S4.coef.map(function (cf) {
    var out = new Float32Array(N * N);
    cf.forEach(function (b) {
      for (var y = 0; y < 8; y++) for (var x = 0; x < 8; x++) {
        var sm = 0; for (var u = 0; u < 8; u++) for (var v = 0; v < 8; v++) if (keep[u * 8 + v]) sm += m5DctC(u) * m5DctC(v) * b.F[u][v] * C[y][u] * C[x][v];
        out[(b.by + y) * N + b.bx + x] = clamp(sm + 0.5, 0, 1);
      }
    });
    return out;
  });
  return (M5S4['r' + K] = res);
}
DEFS.m5s4 = {
  id: 'm5s4', mode: 'mode5', num: 4,
  title: '画像の圧縮（JPEG）', short: '画像の圧縮',
  desc: '写真の JPEG は、画像を 8 × 8 画素の区画に分け、区画ごとに明るさの変化を「振動数の成分」に分ける（フーリエ変換のなかまの<b>離散コサイン変換</b>）。人の目は細かい変化（振動数の高い成分）に気づきにくいので、その成分を捨ててデータを小さくする。<span class="todo">残す成分の数を変えて、画像とデータ量を比べよう。</span>',
  strobe: false, stepDiv: 16,
  varCols: [['K']],
  vars: [{ k: 'K', label: '残す成分の数 $K$', aria: '残す成分の数', stops: [1, 2, 3, 6, 10, 15, 21, 28, 36, 64], def: 10, prop: false, stopLabels: ['1', '', '', '', '10', '', '', '', '', '64'], fmt: function (x) { return Math.round(x) + ' 個'; } }],
  init: function (s) { },
  onChanged: function (s) { return 'keepT'; },
  buttons: [],
  tEnd: function () { return 1e6; }, tInfo: function () { return ''; }, gT: function () { return 1; },
  height: function (s, w) { return w < 560 ? 30 + 3 * Math.min(w - 24, 230) + 110 : Math.round(Math.min(Math.floor((w - 260) / 2), 250) + 74); },
  afterBuild: function (s) { m5Layout(s); s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn); },
  draw: function (s, ctx, W, H) { drawM5S4(s, ctx, W, H); if (s._lk !== s.v.K) { s._lk = s.v.K; s.renderRight(); } },
  right: function (s, R) { rightM5S4(s, R); }
};
function m5s4Paint(ctx, a, x, y, sz) {
  var N = M5S4.N, px = sz / N;
  for (var j = 0; j < N; j++) for (var i = 0; i < N; i++) { var q = j * N + i; ctx.fillStyle = 'rgb(' + Math.round(a[0][q] * 255) + ',' + Math.round(a[1][q] * 255) + ',' + Math.round(a[2][q] * 255) + ')'; ctx.fillRect(x + i * px, y + j * px, px + 0.6, px + 0.6); }
}
function drawM5S4(s, ctx, W, H) {
  var nar = W < 560, K = Math.round(s.v.K), rec = m5s4Rec(K);
  var sz = nar ? Math.min(W - 24, 230) : Math.min(Math.floor((W - 260) / 2), 250), y0 = 30;
  var xa = nar ? (W - sz) / 2 : 10, xb = nar ? (W - sz) / 2 : 10 + sz + 20, yb = nar ? y0 + sz + 34 : y0;
  label(ctx, '元の画像（64 × 64 画素）', xa, y0 - 12, { size: 11.5, bold: true, color: COL.ink, align: 'left' });
  label(ctx, '成分を ' + K + ' 個だけ残して戻した画像', xb, yb - 12, { size: 11.5, bold: true, color: '#c9670c', align: 'left' });
  m5s4Paint(ctx, M5S4.img, xa, y0, sz); m5s4Paint(ctx, rec, xb, yb, sz);
  /* 8 × 8 の区画の線 */
  [[xa, y0], [xb, yb]].forEach(function (p) { ctx.save(); ctx.strokeStyle = 'rgba(224,123,24,.35)'; ctx.lineWidth = 1; for (var k = 0; k <= 8; k++) { var d = Math.round(sz * k / 8) + 0.5; ctx.beginPath(); ctx.moveTo(p[0] + d, p[1]); ctx.lineTo(p[0] + d, p[1] + sz); ctx.moveTo(p[0], p[1] + d); ctx.lineTo(p[0] + sz, p[1] + d); ctx.stroke(); } ctx.restore(); });
  label(ctx, 'オレンジの線：8 × 8 画素の区画', xa, (nar ? yb : y0) + sz + 12, { size: 9.5, color: COL.sub, align: 'left' });
  /* 成分の形（8 × 8 = 64 種類）。残した成分を色で囲む */
  var gx = nar ? (W - Math.min(W - 24, 230)) / 2 : xb + sz + 24, gy = nar ? yb + sz + 44 : y0, gs = nar ? Math.min(W - 24, 230) : Math.min(W - gx - 10, 210), ts = gs / 8;
  label(ctx, '成分の形（左上ほど振動数が低い）', gx, gy - 12, { size: 11, bold: true, color: COL.ink, align: 'left' });
  var keep = {}; M5S4.zz.slice(0, K).forEach(function (p) { keep[p[0] * 8 + p[1]] = true; });
  for (var u = 0; u < 8; u++) for (var v = 0; v < 8; v++) {
    for (var yy = 0; yy < 8; yy++) for (var xx = 0; xx < 8; xx++) { var val = M5S4.cos[yy][u] * M5S4.cos[xx][v], g = Math.round(128 + 120 * val); ctx.fillStyle = 'rgb(' + g + ',' + g + ',' + g + ')'; ctx.fillRect(gx + v * ts + xx * ts / 8, gy + u * ts + yy * ts / 8, ts / 8 + 0.5, ts / 8 + 0.5); }
    if (!keep[u * 8 + v]) { ctx.save(); ctx.fillStyle = 'rgba(255,255,255,.72)'; ctx.fillRect(gx + v * ts, gy + u * ts, ts, ts); ctx.restore(); }
    else { ctx.save(); ctx.strokeStyle = '#e07b18'; ctx.lineWidth = 1.6; ctx.strokeRect(gx + v * ts + 1, gy + u * ts + 1, ts - 2, ts - 2); ctx.restore(); }
  }
  label(ctx, 'オレンジの枠：残した成分　薄い所：捨てた成分', gx, gy + gs + 12, { size: 9.5, color: COL.sub, align: 'left' });
}
function rightM5S4(s, R) {
  var K = Math.round(s.v.K);
  R.innerHTML = mathify('<div class="qcard"><p class="qt">画像の圧縮</p>' +
    '<p>画像も「明るさの波」と考えられる。8 × 8 画素の区画の明るさを、図の「成分の形」の 64 種類のもようの重ね合わせで表す（2 次元のフーリエ変換のなかま）。左上のもようほどゆっくり変わる（振動数が低い）。</p>' +
    '<p>ふつうの写真では、ほとんどの区画で振動数の低い成分が大きく、高い成分は小さい。そこで高い成分を捨てても、見た目はあまり変わらない。これが JPEG の考え方（実際は成分を「捨てる」代わりに「粗く丸める」）。</p>' +
    '<p class="qnow"><span class="qtag now">いま</span>64 個のうち ' + K + ' 個を残す → データ量は約 ' + Math.round(K / 64 * 100) + ' %</p>' +
    '<p class="qnote">成分を減らしすぎると、区画のさかいめが見える（ブロックノイズ）。屋根の斜めの線・アンテナの細い棒・草の細かいもようのように、変化の速い所から先にくずれる。</p>' +
    '<p class="qnote">色のついた画像は、赤・緑・青の 3 つの明るさに分けて、それぞれ同じことをしている（実際の JPEG は「明るさ」と「色み」に分け、人の目が気づきにくい色みの方をより粗くする）。</p></div>');
}

/* =========================================================================
   ⑤-5 ほかの使い道と参考サイト（文だけ）
   ========================================================================= */
DEFS.m5s5 = {
  id: 'm5s5', mode: 'mode5', num: 5, custom: true,
  title: 'ほかの使い道と参考サイト', short: '使い道・参考サイト',
  html: function () {
    var li = function (t, d) { return '<li><b>' + t + '</b>：' + d + '</li>'; };
    return '<div class="secdesc">フーリエ変換は、身の回りのいろいろな所で使われている。<span class="todo">気になったものを調べてみよう。</span></div>' +
      '<div class="m5ideas"><ul>' +
      li('ノイズキャンセリング・イヤホン', 'マイクで周りの音をとらえ、逆の形（位相が反対）の音を出して打ち消す（②-1 の重ね合わせ）。どの振動数の騒音が多いかを調べて打ち消し方を決める。') +
      li('チューナーアプリ・音声認識', '音をフーリエ変換していちばん強い成分（基音）を見つけ、音の高さを表示する（③-1・④-1）。声を文字にする音声認識も、まず声を振動数の成分に分けるところから始まる。') +
      li('スペクトログラム（声紋）', '短い時間ごとにフーリエ変換して、横に時間、縦に振動数、色で強さを表した図。声の特徴や鳥の鳴き声、楽器の分析に使われる。') +
      li('地震と建物', '地震の揺れをフーリエ変換すると、どの周期の揺れが強いかが分かる。建物の固有振動数と近いと大きく揺れる（②-4 の共振）ので、設計に使われる（①-4 の地震波）。') +
      li('病院の MRI', '体の中の水素の原子核が出す電波をとらえ、フーリエ変換で体の断面の画像を作っている。') +
      li('天体観測', '星の光を振動数（色）ごとに分けると、星に含まれる元素や、星が近づいているか遠ざかっているか（ドップラー効果）が分かる。') +
      '</ul></div>' +
      '<div class="m5refs"><p class="m5rt">参考サイト（詳しく知りたい人へ）</p><ul>' +
      '<li><a href="https://note.com/charu_star/n/n75281efae2cd" target="_blank" rel="noopener">高校生の自分のためのフーリエ変換（note、レチクル／ちゃる）</a>：フーリエ級数からフーリエ変換まで。音声のノイズ除去や画像の例を、動かせるプログラムつきで紹介</li>' +
      '<li><a href="https://u.muroran-it.ac.jp/hydrogen/lec/engmath2014_kamegawa02.pdf" target="_blank" rel="noopener">室蘭工業大学の講義資料（工業数学）</a>：「時間領域」と「周波数領域」の図（⑤-1 の左右の図のもと）</li>' +
      '<li><a href="https://www.youtube.com/watch?v=spUNpyF58BY" target="_blank" rel="noopener">3Blue1Brown「But what is the Fourier Transform?」（YouTube、英語）</a>：波を円に巻きつける見方で、式の意味を動画で説明</li>' +
      '<li><a href="https://svmeas.rion.co.jp/support/p38veq0000000cmg-att/FFT_07881.pdf" target="_blank" rel="noopener">リオン「音響・振動の FFT 解析」（PDF）</a>：音や振動を測る会社の技術資料。楽器の音色や固有振動数を FFT で調べる例</li>' +
      '<li><a href="https://www.isc.meiji.ac.jp/~kikn/CDN/CDN3-JPEGb.pdf" target="_blank" rel="noopener">菊池浩明「JPEG と量子化」（講義資料 PDF）</a>：8 × 8 区画の離散コサイン変換と量子化（⑤-4）</li>' +
      '<li><a href="https://developer.mozilla.org/ja/docs/Glossary/JPEG" target="_blank" rel="noopener">MDN「JPEG」</a>：JPEG がどんな画像形式か（短い説明）</li>' +
      '</ul><p class="m5note">外部のサイトです（内容は各サイトのもの）。</p></div>';
  },
  build: function (art) { }
};
