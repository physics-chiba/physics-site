/* ===== 77_m4h.js ===== */
/* =====================================================================
   ④-1 倍音と楽器ごとの音色 ～自由に音を作ろう～（2026-11-08 千葉さん 16 回目に新しく作った。id は m4h）
   ・千葉さんの「作音_電子オルガン」のように、倍音（1〜16 倍）の大きさを自分で決めて音を合成する
   ・左：倍音の大きさの棒（上下にドラッグ）と、合成した波（基本振動の 2 周期。うすい線はそれぞれの倍音）
   ・右：基本振動数のスライダー、その下に＜プリセット＞（このページで使った楽器・声の音、矩形波・三角波・ノコギリ波）、
         その下にオシロスコープとスペクトル（④-3 と同じ）
   ・音：y(t) = Σ aₙ sin(2π n f₁ t)。三角波は 3・7・11・15 倍の波が逆向き（aₙ < 0）
   ・音は「音を鳴らす」を押したときだけ。鳴らしている間に棒・振動数を変えると、鳴らしたまま音色が変わる（AUDIO.tone）
   ===================================================================== */
'use strict';
var M4H_N = 16;
/* プリセット：[キー, ボタンの名前, 倍音の表を返す関数（f₁ を受けとる）] */
function m4hOdd(fn) { var a = []; for (var n = 1; n <= M4H_N; n += 2) a.push([n, fn(n)]); return a; }
var M4H_PRE = [
  ['基本の波形', [
    ['sine', '正弦波（おんさ）', function () { return [[1, 1]]; }],
    ['square', '矩形波', function () { return m4hOdd(function (n) { return 1 / n; }); }],
    ['tri', '三角波', function () { return m4hOdd(function (n) { return (((n - 1) / 2) % 2 ? -1 : 1) / (n * n); }); }],
    ['saw', 'ノコギリ波', function () { var a = []; for (var n = 1; n <= M4H_N; n++) a.push([n, 1 / n]); return a; }]
  ]],
  ['声（③-1）', [
    ['va', '声「あ」', function (f) { return m3Voice('a', f); }],
    ['vi', '声「い」', function (f) { return m3Voice('i', f); }],
    ['vu', '声「う」', function (f) { return m3Voice('u', f); }]
  ]],
  ['楽器（③・④）', [
    ['recorder', 'リコーダー', function () { return M4_TIM.recorder; }],
    ['flute', 'フルート', function () { return M3_INST.flute; }],
    ['oboe', 'オーボエ', function () { return M4_TIM.oboe; }],
    ['clarinet', 'クラリネット', function () { return M3_INST.clarinet; }],
    ['trumpet', 'トランペット', function () { return M4_TIM.trumpet; }],
    ['violin', 'バイオリン', function () { return M3_INST.violin; }],
    ['guitar', 'ギター', function () { return M4_TIM.guitar; }],
    ['mono', 'モノコード（本物の音）', function () { return M3S4_PARTS; }],
    ['piano', 'ピアノ', function () { return M4_TIM.piano; }],
    ['tube', '試験管の笛', function () { return M4_TIM.tube; }],
    ['glock', '鉄琴', function () { return M4_TIM.glock; }],
    ['organ', 'パイプオルガン', function () { return [[1, 1], [2, 0.8], [4, 0.6], [8, 0.4]]; }]
  ]]
];
var M4H_BY = {}; M4H_PRE.forEach(function (g) { g[1].forEach(function (p) { M4H_BY[p[0]] = p; }); });
/* プリセットを s.a（大きさ 0〜1）と s.sg（向き ±1）にする。いちばん大きい倍音を 1 にそろえる */
function m4hSet(s, key) {
  var p = M4H_BY[key], tab = p[2](s.v.f), mx = 0;
  s.a = []; s.sg = []; for (var n = 0; n < M4H_N; n++) { s.a.push(0); s.sg.push(1); }
  tab.forEach(function (q) { if (q[0] <= M4H_N) mx = Math.max(mx, Math.abs(q[1])); });
  tab.forEach(function (q) { if (q[0] <= M4H_N && mx > 0) { s.a[q[0] - 1] = Math.round(Math.abs(q[1]) / mx * 1000) / 1000; s.sg[q[0] - 1] = q[1] < 0 ? -1 : 1; } });
  s.pre = key;
}
function m4hParts(s) { var out = []; s.a.forEach(function (a, i) { if (a > 0.004) out.push([i + 1, s.sg[i] * a]); }); return out; }
/* 合成した波のいちばん大きい所（強さそのまま。正規化しない） */
function m4hPeak(s) { var p = m4hParts(s), mx = 0; if (!p.length) return 0; for (var u = 0; u < 1; u += 1 / 800) { var y = 0; p.forEach(function (q) { y += q[1] * Math.sin(TAU * q[0] * u); }); mx = Math.max(mx, Math.abs(y)); } return mx; }
/* 図の縦の目盛り：強さ 200（a = 2）で枠いっぱい。それより大きいときだけ縮める（18 回目：相対値ではなく絶対値で描く） */
function m4hScale(s) { return Math.max(2, m4hPeak(s)); }
/* 音の大きさも強さに合わせる（ブラウザは波形を正規化するので、音量で合わせる） */
function m4hVol(s) { return 0.85 * clamp(m4hPeak(s), 0.08, 1.5) / 1.5; }
function m4hVoices(s) { var p = m4hParts(s); return { voices: p.length ? [{ f: s.v.f, partials: p }] : [], vol: m4hVol(s) }; }
/* 倍音の色：基音はオレンジ、第 2 倍音からは色相を少しずつ変える（dark：暗い画面の上で使う明るい色） */
function m4hCol(n, dark) { return n === 1 ? (dark ? '#ffb469' : '#e07b18') : 'hsl(' + Math.round((190 + (n - 2) * 300 / 14) % 360) + ',' + (dark ? '85%,72%)' : '70%,42%)'); }
/* 音色が変わったら：鳴っていれば鳴らしたまま入れかえる。倍音が 1 つもなければ止める */
function m4hRetone(s) {
  if (AUDIO.owner() !== 'm4h') return;
  var p = m4hParts(s);
  if (!p.length) { AUDIO.stop(); return; }
  if (!AUDIO.tone('m4h', s.v.f, p)) s.resound(); else AUDIO.setVol('m4h', m4hVol(s));
}
DEFS.m4h = {
  id: 'm4h', mode: 'mode4', num: 1,
  title: '倍音と楽器ごとの音色　～自由に音を作ろう～', short: '音色を作る',
  desc: '楽器や声の音は、基本振動数 $f_1$ の音（基音）に、その整数倍の振動数の音（倍音）がまざってできている。まざり方で<b>音色</b>が決まる。<span class="todo">つまみを上下に動かして倍音の大きさを変えたり、プリセットを選んだりして、自由に音を作ろう。</span>',
  strobe: false, stepDiv: 16,
  vars: [
    { k: 'f', label: '基本振動数 $f_1$', aria: '基本振動数', min: 110, max: 880, step: 1, def: 262, fmt: function (x) { return Math.round(x) + ' Hz（' + MUS.jp(MUS.near(x).m) + ' 付近）'; } }
  ],
  init: function (s) { m4hSet(s, 'sine'); s.a[0] = 0.5; s.drag = null; },   /* 最初は基音だけ・強さ 50 */
  onDefaults: function (s) { m4hSet(s, 'sine'); s.a[0] = 0.5; m4hSync(s); m4hRetone(s); },
  onChanged: function (s) { s.keyM = null; if (s.pre && /^v/.test(s.pre)) m4hSet(s, s.pre); m4hSync(s); m4hRetone(s); return 'keepT'; },   /* 声は口の形（フォルマント）で決まるので、f₁ を変えたら倍音の表を作り直す */
  buttons: [],
  tEnd: function () { return M4_TEND; },
  tInfo: function () { return ''; },
  gT: function () { return 1; },
  height: function (s, w) { return w < 560 ? 540 : Math.round(clamp(w * 0.9, 520, 580)); },
  afterBuild: function (s) {
    /* 右：スライダー → プリセット → オシロスコープ・スペクトル → 説明 */
    s.R.innerHTML = ''; var sw = el('div', 'row2 sliders inR'); sw.appendChild(s.varbox); s.R.appendChild(sw); s.varbox.classList.add('inR');
    var pb = el('div', 'm4hpre'); pb.appendChild(el('p', 'm4hpt', '＜プリセット＞　押すと、その音の倍音の大きさになる'));
    s.preBtns = {};
    M4H_PRE.forEach(function (g) {
      var row = el('div', 'm4hgrp'); row.appendChild(el('span', 'm4hgl', g[0]));
      var bx = el('div', 'm4hbtns');
      g[1].forEach(function (p) {
        var b = el('button', 'b m4hb', p[1]); b.type = 'button';
        b.addEventListener('click', function () { m4hSet(s, p[0]); m4hSync(s); m4hRetone(s); s.draw(); });
        bx.appendChild(b); s.preBtns[p[0]] = b;
      });
      row.appendChild(bx); pb.appendChild(row);
    });
    s.R.appendChild(pb);
    s.scope = new Scope(s.R, 'オシロスコープ（作った音）');
    s.specCv = el('canvas', 'scopecv speccv'); s.scope.cap.insertAdjacentElement('beforebegin', s.specCv);
    m3SpecPick(s, s.specCv, function () { s._sk = null; s.draw(); });
    s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);
    /* 音を鳴らす（押している間ずっと鳴る。もう一度押すと止まる） */
    var sp = el('span', 'spkrow'); s.row1b.appendChild(sp);
    m3SpkBtn(s, sp, function () { return m4hVoices(s); });
    m3TimeBar(s, false); m4NoPlay(s);
    s.tabBox = el('div', 'm4htab'); s.cw.insertAdjacentElement('afterend', s.tabBox);   /* 鍵盤の下：いまの音の aₙ・fₙ の表と式 */
    /* つまみ（フェーダー）：▲▼ で 5 ずつ、溝を押す・ドラッグでその高さに。鍵盤：押すとその高さ（f₁）で鳴る */
    var pos = function (ev) { var r = s.cv.getBoundingClientRect(); return { x: ev.clientX - r.left, y: ev.clientY - r.top }; };
    var col = function (p) { var g = s._fd; if (!g) return -1; var i = Math.floor((p.x - g.x0) / g.cw); return i >= 0 && i < M4H_N ? i : -1; };
    var setA = function (i, a) { s.a[i] = Math.round(clamp(a, 0, 1) * 100) / 100; s.pre = null; s.hot = i; m4hSync(s); m4hRetone(s); s.draw(); };
    var setAt = function (p) { var g = s._fd, i = col(p); if (i < 0) return; setA(i, (g.tb - p.y) / (g.tb - g.tt)); };
    var keyAt = function (p) { var hit = null; (s._keys || []).forEach(function (k) { if (p.x >= k.x && p.x < k.x + k.w && p.y >= k.y && p.y < k.y + k.h && (!hit || k.blk)) hit = k; }); return hit; };
    s.cv.addEventListener('pointerdown', function (ev) {
      var p = pos(ev), g = s._fd, i = col(p), k = keyAt(p);
      if (k) { s.keyM = k.m; s.v.f = MUS.fET(k.m); s.syncSliders && s.syncSliders(); if (s.pre && /^v/.test(s.pre)) m4hSet(s, s.pre); if (AUDIO.owner() === 'm4h') m4hRetone(s); else if (m4hParts(s).length) m3Sound(s, function () { return m4hVoices(s); }); m4hSync(s); s.draw(); ev.preventDefault(); return; }
      if (!g || i < 0) return;
      if (p.y >= g.ub && p.y < g.ub + g.bh) { setA(i, s.a[i] + 0.05); ev.preventDefault(); return; }
      if (p.y >= g.db && p.y < g.db + g.bh) { setA(i, s.a[i] - 0.05); ev.preventDefault(); return; }
      if (p.y >= g.tt - 10 && p.y <= g.tb + 10) { s.drag = true; try { s.cv.setPointerCapture(ev.pointerId); } catch (e) { } setAt(p); ev.preventDefault(); }
    });
    s.cv.addEventListener('pointermove', function (ev) {
      var p = pos(ev), g = s._fd;
      if (s.drag) { setAt(p); ev.preventDefault(); return; }
      var i = col(p), cur = 'default';
      if (keyAt(p)) cur = 'pointer'; else if (g && i >= 0) { if ((p.y >= g.ub && p.y < g.ub + g.bh) || (p.y >= g.db && p.y < g.db + g.bh)) cur = 'pointer'; else if (p.y >= g.tt - 10 && p.y <= g.tb + 10) cur = 'ns-resize'; }
      s.cv.style.cursor = cur;
    });
    ['pointerup', 'pointercancel'].forEach(function (k) { s.cv.addEventListener(k, function () { if (s.drag) { s.drag = null; s.hot = null; s.draw(); } }); });
    s.cv.style.touchAction = 'none';
    m4hSync(s);
  },
  draw: function (s, ctx, W, H) {
    drawM4H(s, ctx, W, H); m4hTab(s);
    var p = m4hParts(s), FM = Math.ceil(M4H_N * s.v.f / 1000) * 1000;
    s._emptyMsg = '倍音が 1 つもない（つまみを上げよう）';
    s._absK = 2 * m4hPeak(s) / m4hScale(s); m4Scope(s, p.length ? s.v.f : 0, p, p.length ? '波形の形（音色）は倍音のまざり方で決まる。縦は強さそのまま（つまみの強さを変えると、波の大きさも変わる）' : 'つまみを上げると、ここに波形が映る', FM);
  },
  right: function (s, R) { rightM4H(s, R); }
};
function m4hSync(s) {
  if (!s.preBtns) return;
  Object.keys(s.preBtns).forEach(function (k) { var b = s.preBtns[k], on = s.pre === k; b.classList.toggle('on', on); b.setAttribute('aria-pressed', on ? 'true' : 'false'); });
  if (s.Rdyn) s.renderRight();
}
function drawM4H(s, ctx, W, H) {
  var nar = W < 560, f = s.v.f;
  label(ctx, '倍音合成（つまみを上下に動かす。▲▼ で 5 ずつ）', 8, 12, { size: nar ? 11 : 12.5, bold: true, color: COL.ink, align: 'left' });
  /* 金属の板 */
  var x0 = 34, x1 = W - 6, cw = (x1 - x0) / M4H_N, py0 = 24, bh = nar ? 12 : 14;
  var ub = py0 + 18, tt = ub + bh + 10, tb = tt + Math.round(H * (nar ? 0.2 : 0.22)), db = tb + 10, vb = db + bh + 4, py1 = vb + 18;
  s._fd = { x0: x0, cw: cw, tt: tt, tb: tb, ub: ub, db: db, bh: bh };
  ctx.save(); var gr = ctx.createLinearGradient(0, py0, 0, py1); gr.addColorStop(0, '#eef0f2'); gr.addColorStop(0.5, '#d9dde1'); gr.addColorStop(1, '#eceff1'); ctx.fillStyle = gr; rrect(ctx, 4, py0, W - 8, py1 - py0 + 4, 8); ctx.fill(); ctx.strokeStyle = '#b9c0c7'; ctx.stroke(); ctx.restore();
  label(ctx, '倍音', x0 - 16, py0 + 9, { size: 9.5, bold: true, color: COL.ink2 });
  label(ctx, '強さ', x0 - 16, vb + 7, { size: 9.5, bold: true, color: COL.ink2 });
  var tri = function (cx, y, up) { ctx.beginPath(); if (up) { ctx.moveTo(cx - 4, y + bh - 4); ctx.lineTo(cx + 4, y + bh - 4); ctx.lineTo(cx, y + 3); } else { ctx.moveTo(cx - 4, y + 4); ctx.lineTo(cx + 4, y + 4); ctx.lineTo(cx, y + bh - 3); } ctx.closePath(); ctx.fill(); };
  for (var i = 0; i < M4H_N; i++) {
    var cx = x0 + cw * (i + 0.5), a = s.a[i], hot = s.hot === i, bw = Math.min(cw - 4, 26), fund = i === 0;
    label(ctx, String(i + 1), cx, py0 + 9, { size: nar ? 9.5 : 11, bold: true, color: m4hCol(i + 1) });
    /* ▲ ▼ */
    [[ub, true], [db, false]].forEach(function (q) { ctx.save(); ctx.fillStyle = '#f8f9fa'; ctx.strokeStyle = '#9aa3ad'; ctx.lineWidth = 1; rrect(ctx, cx - bw / 2, q[0], bw, bh, 3); ctx.fill(); ctx.stroke(); ctx.fillStyle = '#4a525c'; tri(cx, q[0], q[1]); ctx.restore(); });
    /* 溝と目盛り */
    ctx.save(); ctx.strokeStyle = 'rgba(80,90,100,.35)'; ctx.lineWidth = 1;
    for (var k = 0; k <= 4; k++) { var yk = Math.round(tb - k / 4 * (tb - tt)) + 0.5; ctx.beginPath(); ctx.moveTo(cx - bw / 2, yk); ctx.lineTo(cx - 5, yk); ctx.moveTo(cx + 5, yk); ctx.lineTo(cx + bw / 2, yk); ctx.stroke(); }
    ctx.fillStyle = '#3a414c'; rrect(ctx, cx - 2.5, tt - 4, 5, tb - tt + 8, 2.5); ctx.fill();
    if (a > 0) { ctx.fillStyle = m4hCol(i + 1); ctx.fillRect(cx - 2, tb - a * (tb - tt), 4, a * (tb - tt)); }
    ctx.restore();
    /* つまみ */
    var ky = tb - a * (tb - tt), kw = Math.min(cw - 3, 24), kh = nar ? 12 : 14;
    ctx.save(); var kg = ctx.createLinearGradient(0, ky - kh / 2, 0, ky + kh / 2); kg.addColorStop(0, hot ? '#fff3e2' : '#fdfdfd'); kg.addColorStop(0.5, hot ? '#f2c48c' : '#c9ced4'); kg.addColorStop(1, hot ? '#e9a95a' : '#9aa3ad');
    ctx.fillStyle = kg; ctx.strokeStyle = a > 0 ? m4hCol(i + 1) : '#5b6570'; ctx.lineWidth = 1.2; rrect(ctx, cx - kw / 2, ky - kh / 2, kw, kh, 3); ctx.fill(); ctx.stroke();
    ctx.strokeStyle = fund ? '#c9670c' : '#3a414c'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(cx - kw / 2 + 3, ky + 0.5); ctx.lineTo(cx + kw / 2 - 3, ky + 0.5); ctx.stroke(); ctx.restore();
    /* 強さ（最大 100） */
    var vw = Math.min(cw - 2, 30); ctx.save(); ctx.fillStyle = '#fff'; ctx.strokeStyle = '#9aa3ad'; ctx.lineWidth = 1; ctx.fillRect(cx - vw / 2, vb, vw, 15); ctx.strokeRect(cx - vw / 2 + 0.5, vb + 0.5, vw - 1, 14); ctx.restore();
    label(ctx, String(Math.round(a * 100)), cx, vb + 7.5, { size: nar ? 8.5 : 10, bold: a > 0, color: a > 0 ? (fund ? '#c9670c' : '#14171c') : COL.sub });
    if (a > 0 && s.sg[i] < 0) label(ctx, '逆', cx + bw / 2 - 2, py0 + 9, { size: 8, bold: true, color: '#9b2418', align: 'left' });
  }
  /* 合成した波（2 周期）。うすい線：それぞれの倍音 */
  var kbH = nar ? 70 : 84, gy0 = py1 + 26, gy1 = H - kbH - 26, gm = (gy0 + gy1) / 2, ga = (gy1 - gy0) / 2 - 4, p = m4hParts(s);
  label(ctx, nar ? '白：合成した波　オレンジ：基音　色：第 2 倍音〜' : '合成した波（白い太線）　オレンジ：基音　色つきの細い線：第 2 倍音〜（つまみの色）', 8, gy0 - 12, { size: nar ? 10 : 11.5, bold: true, color: COL.ink2, align: 'left' });
  ctx.save(); ctx.fillStyle = '#0e6f6c'; rrect(ctx, x0 - 26, gy0 - 4, x1 - x0 + 26, gy1 - gy0 + 8, 6); ctx.fill(); ctx.restore();
  var X = function (u) { return x0 - 18 + u / 2 * (x1 - x0 + 10); };
  ctx.save(); ctx.strokeStyle = 'rgba(255,255,255,.5)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(X(0), gm + 0.5); ctx.lineTo(X(2), gm + 0.5); ctx.stroke(); ctx.restore();
  if (!p.length) label(ctx, '倍音が 1 つもない（音は出ない）', (x0 + x1) / 2, gm - 14, { size: 12, color: '#e8f6f5' });
  else {
    var SC = m4hScale(s), YA = function (y) { return gm - y / SC * ga; };   /* 絶対値：強さ 200（a = 2）で枠いっぱい。基音だけなら白線とオレンジの線は重なる */
    p.forEach(function (q) { if (p.length > 1 || true) plotF(ctx, function (u) { return q[1] * Math.sin(TAU * q[0] * u); }, 0, 2, X, YA, m4hCol(q[0], true), q[0] === 1 ? 2 : 1.3); });
    plotF(ctx, function (u) { var y = 0; for (var k = 0; k < p.length; k++) y += p[k][1] * Math.sin(TAU * p[k][0] * u); return y; }, 0, 2, X, YA, 'rgba(255,255,255,.92)', p.length > 1 ? 2.6 : 1.4);
    label(ctx, '強さ 100', x0 - 22, gm - ga / SC + 0, { size: 8.5, color: 'rgba(230,250,248,.8)', align: 'left', halo: false });
    ctx.save(); ctx.strokeStyle = 'rgba(255,255,255,.22)'; ctx.setLineDash([3, 4]); [1, -1].forEach(function (sg) { var yy = Math.round(gm - sg * ga / SC) + 0.5; ctx.beginPath(); ctx.moveTo(X(0) + 30, yy); ctx.lineTo(X(2), yy); ctx.stroke(); }); ctx.restore();
  }
  /* 鍵盤（C3〜C5）：押すとその高さで鳴る */
  var ky0 = H - kbH - 6, lo = 48, hi = 72, whites = [], mm;
  for (mm = lo; mm <= hi; mm++) if (!MUS.black(mm)) whites.push(mm);
  var kx0 = 6, ww = (W - 12) / whites.length; s._keys = [];
  label(ctx, '鍵盤：押すと、その高さ（基本振動数）で鳴る', 8, ky0 - 10, { size: nar ? 10 : 11, bold: true, color: COL.ink2, align: 'left' });
  var near = MUS.near(f).m, onM = s.keyM !== null && s.keyM !== undefined ? s.keyM : (Math.abs(MUS.near(f).cent) < 3 ? near : null);
  whites.forEach(function (m2, j) {
    var x = kx0 + j * ww, on = onM === m2;
    ctx.save(); ctx.fillStyle = on ? '#ffd9a8' : '#fff'; ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1; rrect(ctx, x + 0.5, ky0, ww - 1, kbH, 3); ctx.fill(); ctx.stroke(); ctx.restore();
    if (m2 % 12 === 0) label(ctx, 'ド' + (m2 / 12 - 1), x + ww / 2, ky0 + kbH - 9, { size: nar ? 8 : 9.5, bold: true, color: COL.ink2 });
    s._keys.push({ x: x, y: ky0, w: ww, h: kbH, m: m2 });
  });
  for (mm = lo; mm <= hi; mm++) if (MUS.black(mm)) {
    var xb = kx0 + whites.indexOf(mm - 1) * ww + ww, bw2 = ww * 0.6, on2 = onM === mm;
    ctx.save(); ctx.fillStyle = on2 ? '#e07b18' : '#20242b'; rrect(ctx, xb - bw2 / 2, ky0, bw2, kbH * 0.6, 2); ctx.fill(); ctx.restore();
    s._keys.push({ x: xb - bw2 / 2, y: ky0, w: bw2, h: kbH * 0.6, m: mm, blk: true });
  }
}
function rightM4H(s, R) {
  var nm = s.pre ? M4H_BY[s.pre][1] : '自分で作った音', p = m4hParts(s);
  var h = '<div class="qcard"><p class="qt">音色と倍音</p>' +
    '<p>同じ高さ（同じ $f_1$）の音でも、楽器や声によって聞こえ方がちがう。このちがいを<b>音色</b>という。音色は、基音にまざる<b>倍音</b>（振動数 $2f_1, 3f_1, \\cdots$）の大きさで決まる。</p>' +
    '<div class="qeq">$$y = a_1 \\sin 2\\pi f_1 t + a_2 \\sin 2\\pi (2f_1) t + a_3 \\sin 2\\pi (3f_1) t + \\cdots$$</div>' +
    '<p>$a_1, a_2, a_3, \\cdots$ は、基音・第 2 倍音・第 3 倍音 … の<b>振幅</b>（それぞれの音の強さ）。左のつまみの数字 ÷ 100 にあたる。$f_1, 2f_1, 3f_1, \\cdots$ がそれぞれの振動数。</p>' +
    '<table class="reltab grid1"><tbody>' +
    '<tr><th>矩形波</th><td class="l">奇数倍の倍音だけ。大きさは $1, \\dfrac{1}{3}, \\dfrac{1}{5}, \\cdots$（クラリネットに近い）</td></tr>' +
    '<tr><th>三角波</th><td class="l">奇数倍の倍音だけ。大きさは $1, \\dfrac{1}{9}, \\dfrac{1}{25}, \\cdots$ で、正弦波に近いやわらかい音（「逆」は向きが反対の波）</td></tr>' +
    '<tr><th>ノコギリ波</th><td class="l">すべての倍音。大きさは $1, \\dfrac{1}{2}, \\dfrac{1}{3}, \\cdots$（バイオリンなどの弦をこする音に近い）</td></tr></tbody></table>';
  h += '<p class="qnow"><span class="qtag now">いま</span>' + nm + '：' + (p.length ? '倍音 ' + p.map(function (q) { return q[0]; }).join('・') + ' 倍' : '倍音なし') + '、$f_1 = ' + Math.round(s.v.f) + '$ Hz</p>';
  h += '<p class="qnote">倍音の大きさを変えても、周期 $T = \\dfrac{1}{f_1}$（音の高さ）は変わらない。変わるのは波形（音色）だけ。声の母音は、口の形で強くなる倍音（フォルマント）が決まるので、$f_1$ を変えると倍音の表も変わる。</p></div>';
  R.innerHTML = mathify(h);
}
/* 鍵盤の下の表と式：鳴らしている倍音の aₙ（強さ ÷ 100）と fₙ = n f₁、式（文字のまま・数を入れたもの） */
function m4hTab(s) {
  var box = s.tabBox; if (!box) return;
  var p = m4hParts(s), f = s.v.f, key = JSON.stringify(p) + '|' + Math.round(f * 100);
  if (box._k === key) return; box._k = key;
  if (!p.length) { box.innerHTML = '<p class="m4hnone">倍音が 1 つもないので、音は出ない。</p>'; return; }
  var sub = function (n) { return n; };
  var h = '<p class="m4htt">いま出している音</p><div class="m4hscroll"><table class="reltab m4ht"><thead><tr><th></th>' + p.map(function (q) { return '<th style="color:' + m4hCol(q[0]) + '">' + (q[0] === 1 ? '基音' : '第 ' + q[0] + ' 倍音') + '</th>'; }).join('') + '</tr></thead><tbody>' +
    '<tr><th>強さ $a_n$</th>' + p.map(function (q) { return '<td>$' + (q[1] < 0 ? '-' : '') + Math.abs(q[1]).toFixed(2) + '$</td>'; }).join('') + '</tr>' +
    '<tr><th>振動数 $f_n$</th>' + p.map(function (q) { return '<td>$' + Math.round(q[0] * f) + '$ Hz</td>'; }).join('') + '</tr></tbody></table></div>';
  var t1 = p.map(function (q, k) { return '$' + (k ? '+\\,' : 'y = ') + 'a_{' + q[0] + '} \\sin 2\\pi f_{' + q[0] + '} t$'; });
  var t2 = p.map(function (q, k) { var a = Math.abs(q[1]).toFixed(2); return '$' + (k ? (q[1] < 0 ? '-\\,' : '+\\,') : 'y = ' + (q[1] < 0 ? '-' : '')) + a + ' \\sin 2\\pi \\times ' + Math.round(q[0] * f) + '\\, t$'; });
  h += '<p class="m4heql">式（$f_n = n f_1$、$a_n$ は第 $n$ 倍音の振幅＝強さ ÷ 100）</p><div class="m4heq">' + t1.map(function (t) { return '<span>' + t + '</span>'; }).join('') + '</div>' +
    '<p class="m4heql">数を入れると</p><div class="m4heq">' + t2.map(function (t) { return '<span>' + t + '</span>'; }).join('') + '</div>';
  box.innerHTML = mathify(h);
}
