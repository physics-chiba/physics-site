/* ===== 30_physics.js ===== */
/* =========================================================================
   30_physics.js … 物理の計算だけ（純粋な関数。描画を混ぜない）
   記号は教科書にそろえる：振幅 A・波長 λ・周期 T・振動数 f・速さ v、音速 V、光速 c、弦・管の長さ l。
   ★ 波はすべて「波源の変位の記録 y₀(t)」から作る：媒質の点 x の変位は y(x, t) = y₀(t − x/v)
     （右端では反射しない）。連続波・パルス波・手で動かした波は、y₀(t) の形がちがうだけ。
     波の式 y = A sin 2π(t/T − x/λ) は物理の範囲なので本文には出さないが、中身はこれと同じになる。
   ========================================================================= */
'use strict';
var G = 9.8;
var TAU = Math.PI * 2;
function clamp(x, a, b) { return x < a ? a : (x > b ? b : x); }
function roundTo(x, step) { return Math.round(x / step) * step; }

var WAVE = {
  /* v = fλ・f = 1/T */
  f: function (v, lam) { return v / lam; },
  v: function (f, lam) { return f * lam; },
  lam: function (v, f) { return v / f; },
  T: function (f) { return 1 / f; },
  /* 音速 V = 331.5 + 0.6t（t：気温〔℃〕） */
  V: function (tC) { return 331.5 + 0.6 * tC; },
  /* 光の速さ：真空中 c、絶対屈折率 n の物質の中では c/n。振動数は変わらず、波長は 1/n 倍 */
  c0: 3.0e8,
  cIn: function (n) { return WAVE.c0 / n; },
  lamIn: function (lam0, n) { return lam0 / n; },
  /* 浅い水路の水面波（波長が深さよりずっと長いとき）：v ≒ √(gh) */
  vWater: function (h) { return Math.sqrt(G * h); },
  /* 糸（ゴムひも）を伝わる波：v = √(S/ρ)（S：張力、ρ：線密度）。本文では「張力が大きいほど速い」とだけ言う */
  vString: function (S, rho) { return Math.sqrt(S / rho); },
  /* 人に聞こえる音の範囲〔Hz〕 */
  AUD_LO: 20, AUD_HI: 20000,
  audible: function (f) { return f >= 20 && f <= 20000; },
  /* 固有振動数（開口端補正なし）：弦 fₘ = m·v/(2l)、開管 fₘ = m·V/(2l)、閉管 fₘ = m·V/(4l)（m は奇数） */
  fString: function (l, v, m) { return m * v / (2 * l); },
  fOpen: function (l, V, m) { return m * V / (2 * l); },
  fClosed: function (l, V, m) { return m * V / (4 * l); },
  beat: function (f1, f2) { return Math.abs(f1 - f2); }
};

/* ---------- 波源の記録 ----------
   pieces：時刻の順にならんだ「区間」。区間の外（最初の区間より前）は 0。
     { k:'sin',   t0, t1, A, f, ph0 }   … y = A sin(ph0 + 2πf(t − t0))（連続波）
     { k:'pulse', t0, t1, A, tau }      … 0 ≦ t − t0 ≦ tau で y = A sin(π(t − t0)/tau)（山 1 つのパルス）
     { k:'samp',  t0, t1, dt, ys, es }  … 手で動かした記録（等間隔 dt）。ys＝手の位置、es＝媒質へ送り出す変位
     { k:'rel',   t0, t1, yr, er, tauH, tau } … 手を放したあと：手は yr から 0 へ（tauH 秒）、送り出す変位は er から 0 へ（時定数 tau）
   t1 は区間のおわり（Infinity なら続いている）。
   ★ 手を同じ位置で止めておいても、そのずれ（変位の一定のぶん）はいつまでも伝わるのではなく、
     時定数 HAND_TAU で 0 にもどる形で送り出す（千葉さん 2026-11-03：ずれが伝わったあと、各点はつりあいの位置にもどる）。
     手のすぐ近くには、手のずれ（送り出しきれていないぶん）を残す：y(x, t) = e(t − x/v) + b(t)·exp(−x/HAND_LEN)
     （e：送り出す変位、b：手の位置 − e。x = 0 で手の位置と一致する） */
var HAND_TAU = 0.3, HAND_LEN = 0.25;
var SRC = {
  make: function () { return { pieces: [] }; },
  /* 送り出す変位 e（波として伝わるもの） */
  evalPiece: function (p, t) {
    var u = t - p.t0;
    if (p.k === 'sin') return p.A * Math.sin(p.ph0 + TAU * p.f * u);
    if (p.k === 'pulse') return (u >= 0 && u <= p.tau) ? p.A * Math.sin(Math.PI * u / p.tau) : 0;
    if (p.k === 'rel') return p.er * Math.exp(-u / p.tau) * (u > p.t1 - p.t0 - p.tau ? Math.max(0, (p.t1 - p.t0 - u) / p.tau) : 1);
    if (p.k === 'samp') return SRC.interp(p.es, p.dt, u);
    return 0;
  },
  /* 手の位置（手で動かしていないときは e と同じ） */
  handPiece: function (p, t) {
    var u = t - p.t0;
    if (p.k === 'samp') return SRC.interp(p.ys, p.dt, u);
    if (p.k === 'rel') return u >= p.tauH ? 0 : p.yr * 0.5 * (1 + Math.cos(Math.PI * u / p.tauH));
    return SRC.evalPiece(p, t);
  },
  interp: function (a, dt, u) {
    var n = a.length; if (!n) return 0;
    var q = u / dt, i = Math.floor(q);
    if (i < 0) return a[0];
    if (i >= n - 1) return a[n - 1];
    return a[i] + (a[i + 1] - a[i]) * (q - i);
  },
  at: function (src, t) { var P = src.pieces; for (var i = P.length - 1; i >= 0; i--) { var p = P[i]; if (t >= p.t0) return t <= p.t1 ? p : null; } return null; },
  /* 時刻 t に波源が送り出す変位 e(t)（＝ 波として伝わる y₀(t)） */
  y0: function (src, t) { var p = SRC.at(src, t); return p ? SRC.evalPiece(p, t) : 0; },
  /* 時刻 t の手（波源）の位置 */
  hand: function (src, t) { var p = SRC.at(src, t); return p ? SRC.handPiece(p, t) : 0; },
  /* 手のずれのうち、まだ送り出していないぶん b = 手の位置 − e */
  base: function (src, t) { return SRC.hand(src, t) - SRC.y0(src, t); },
  /* 時刻 t より後に始まる区間を消す（時間バーで前にもどしてから続けたとき） */
  trim: function (src, t) { var P = src.pieces; while (P.length && P[P.length - 1].t0 > t) P.pop(); },
  /* いま続いている区間を時刻 t で切る（その瞬間の送り出す変位を返す） */
  cut: function (src, t) {
    SRC.trim(src, t);
    var P = src.pieces, last = P[P.length - 1];
    if (!last) return 0;
    var y = SRC.y0(src, t);
    if (last.t1 > t) last.t1 = t;
    return y;
  },
  /* 連続波を時刻 t から始める。いまの変位と同じところからつなぐ（変位がとばない） */
  startSin: function (src, t, A, f) {
    var y = SRC.cut(src, t);
    var ph0 = Math.asin(clamp(y / A, -1, 1));
    src.pieces.push({ k: 'sin', t0: t, t1: Infinity, A: A, f: f, ph0: ph0 });
  },
  /* 連続波の振動数・振幅を時刻 t で変える（位相をつなぐ：波源の動きはなめらかなまま。すでに出た波はもとの波長のまま進む） */
  retune: function (src, t, A, f) {
    SRC.trim(src, t);
    var P = src.pieces, last = P[P.length - 1];
    if (!last || last.k !== 'sin' || last.t1 < t) return false;
    var ph = last.ph0 + TAU * last.f * (t - last.t0);
    last.t1 = t;
    P.push({ k: 'sin', t0: t, t1: Infinity, A: A, f: f, ph0: ph });
    return true;
  },
  pulse: function (src, t, A, tau) { SRC.cut(src, t); src.pieces.push({ k: 'pulse', t0: t, t1: t + tau, A: A, tau: tau }); },
  /* 手でつかんだ：ここから記録を始める（つかんだ瞬間の手の位置・送り出す変位を引きつぐ） */
  grab: function (src, t, dt) {
    var y = SRC.hand(src, t), e = SRC.y0(src, t);
    SRC.cut(src, t);
    var p = { k: 'samp', t0: t, t1: Infinity, dt: dt, ys: [y], es: [e] };
    src.pieces.push(p); return p;
  },
  /* 手の位置を 1 つ記録する。送り出す変位 e は、手の位置 y から「ゆっくり手の位置に追いつく基準 b」を引いたもの */
  push: function (p, y) {
    var n = p.ys.length, yl = p.ys[n - 1], el = p.es[n - 1], b = yl - el;
    b += (y - b) * Math.min(1, p.dt / HAND_TAU);
    p.ys.push(y); p.es.push(y - b);
  },
  /* 手を放した：手は 0 へもどり、送り出す変位も 0 へもどる */
  release: function (src, t) {
    var yr = SRC.hand(src, t), er = SRC.y0(src, t);
    SRC.cut(src, t);
    src.pieces.push({ k: 'rel', t0: t, t1: t + 8 * HAND_TAU, yr: yr, er: er, tauH: 0.25, tau: HAND_TAU });
  },
  /* 波源が最後に動いた時刻（それより後は 0 のまま）。連続波なら Infinity */
  lastActive: function (src) {
    var P = src.pieces, last = P[P.length - 1];
    if (!last) return -Infinity;
    return last.t1;
  }
};

/* 右へ進む波（右端では反射しない）：媒質の点 x〔m〕の変位。手のずれ b は手の近くだけに残る */
function waveY(src, v, x, t) {
  if (x < 0) return 0;
  var y = SRC.y0(src, t - x / v), b = SRC.base(src, t);
  return b ? y + b * Math.exp(-x / HAND_LEN) : y;
}

/* ---------- ①-2：連続した正弦波（t = 0 で媒質全体に波がある） ----------
   t = 0 の波形を y(x, 0) = A sin(2π(x − x0)/λ) とし、向き s（+1：x 軸の正の向き、−1：負の向き）に速さ v で進む。
   y(x, t) = A sin(2π(x − s v t − x0)/λ) */
var SINE = {
  y: function (A, lam, f, s, x0, x, t) { return A * Math.sin(TAU * (x - s * f * lam * t - x0) / lam); },
  /* 点 x の変位を y = A sin(ωt + φ) と書いたときの φ（等速円運動の位置） */
  phase: function (lam, s, x0, x) { var c = TAU * (x - x0) / lam; return s > 0 ? Math.PI - c : c; },
  /* 点 x の媒質の速度 dy/dt */
  vy: function (A, lam, f, s, x0, x, t) { return -A * TAU * f * s * Math.cos(TAU * (x - s * f * lam * t - x0) / lam); }
};

/* ---------- ①-3：縦波（右へ進む）。右向きの変位 u(x, t)。疎密は −∂u/∂x ---------- */
var LONG = {
  u: function (A, lam, f, x, t) { return t - x / (f * lam) < 0 ? 0 : A * Math.sin(TAU * f * (t - x / (f * lam))); },
  /* 媒質の密度の変化（つりあいのときを 0。正なら密）：−∂u/∂x */
  dens: function (A, lam, f, x, t) { return t - x / (f * lam) < 0 ? 0 : A * TAU / lam * Math.cos(TAU * f * (t - x / (f * lam))); },
  /* 時刻 t の、密・疎の点（つりあいの位置 x。0 ≦ x ≦ xmax、波の届いている所だけ） */
  marks: function (lam, f, t, xmax) {
    var v = f * lam, out = [], front = v * t;
    /* 密：位相 2πf(t − x/v) = 2πn（cos = 1）、疎：2πn + π */
    for (var n = -2; n < 400; n++) {
      [[0, 'mitsu'], [0.5, 'so']].forEach(function (p) {
        var x = v * (t - (n + p[0]) / f);
        if (x >= 0 && x <= Math.min(xmax, front)) out.push({ x: x, k: p[1] });
      });
      if (v * (t - n / f) < -xmax) break;
    }
    return out.sort(function (a, b) { return a.x - b.x; });
  }
};

/* ---------- ①-4：水面の表面波（深い水）。水の粒は円をえがく（深いほど小さい円） ----------
   つりあいの位置 (x0, z0)（z0 ≦ 0 が水面から下）の粒の位置。k = 2π/λ */
var SURF = {
  pos: function (a, lam, f, x0, z0, t) {
    var k = TAU / lam, ph = k * x0 - TAU * f * t, r = a * Math.exp(k * z0);
    return { x: x0 - r * Math.sin(ph), z: z0 + r * Math.cos(ph), r: r };
  }
};

/* ---------- ①-1 の検算用：波源と媒質の点の関係 ---------- */
var M1 = {
  s1: { L: 8.0, A: [0.05, 0.10, 0.15, 0.20, 0.25, 0.30], A0: 0.20, f: [0.5, 1.0, 1.5, 2.0, 2.5, 3.0], f0: 0.5, v: [1.0, 2.0, 3.0, 4.0, 5.0, 6.0], v0: 2.0 },   /* 既定 v = 2 m/s・f = 0.5 Hz → λ = 4.0 m（2026-11-03 千葉さん 2 回目） */
  s2: { A0: 0.10, lam0: 0.50, f: [0.25, 0.4, 0.5, 0.8, 1.0, 1.25, 2.0, 2.5, 4.0], f0: 2.0 },
  s3: { L: 2.4, A: [0.03, 0.06, 0.09, 0.12, 0.15], A0: 0.12, v: [0.4, 0.6, 0.8, 1.0, 1.2], v0: 0.6, f: [0.25, 0.5, 0.75, 1.0], f0: 0.5 }   /* 既定 λ = v/f = 1.2 m */
};

/* ---------- 章 ② 波の重なり合い ---------- */
var M2 = {
  s1: { L: 12, A: [0.5, 1.0, 1.5], f: [0.25, 0.5, 0.75, 1.0], v: [1, 2, 3, 4] },
  s2: { L: 8, ext: 4, v: 2.0, A: 1.0, f: 0.5 },
  s3: { l: 1.0, h0: 0.05 },
  /* 波源の変位：sin＝連続波、pulse＝山 1 つ（半周期・幅 λ/2）、tri＝三角の山 1 つ（同じ幅） */
  src: function (sh, A, f, tau) {
    if (tau < 0) return 0;
    if (sh === 'sin') return A * Math.sin(TAU * f * tau);
    var d = 0.5 / f;
    if (tau > d) return 0;
    if (sh === 'pulse') return A * Math.sin(Math.PI * tau / d);
    return A * (1 - Math.abs(2 * tau / d - 1));
  },
  /* ②-1：左の波源から右向きに進む波／右の波源（x = L）から左向きに進む波 */
  right: function (sh, A, f, v, x, t) { return M2.src(sh, A, f, t - x / v); },
  left: function (sh, A, f, v, L, x, t) { return M2.src(sh, A, f, t - (L - x) / v); },
  /* 左右とも同じ連続波のときの節と腹：y = 2A sin ω(t − L/2v) cos k(x − L/2) → 節 x = L/2 ± (2n+1)λ/4、腹 x = L/2 ± nλ/2 */
  nodes: function (L, lam) {
    var out = [];
    for (var n = -40; n <= 40; n++) {
      var xn = L / 2 + (2 * n + 1) * lam / 4, xa = L / 2 + n * lam / 2;
      if (xn >= -1e-9 && xn <= L + 1e-9) out.push({ x: xn, k: 'node' });
      if (xa >= -1e-9 && xa <= L + 1e-9) out.push({ x: xa, k: 'anti' });
    }
    return out.sort(function (a, b) { return a.x - b.x; });
  },
  /* ②-2：入射波（x ≦ L）・端の向こうへ延ばした入射波（x ≧ L）・仮想の波（固定端は上下逆）・反射波（仮想の波を端で折り返したもの） */
  inc: function (q, x, t) { return M2.src(q.sh, q.A, q.f, t - x / q.v); },
  incExt: function (q, x, t) { return M2.src(q.sh, q.A, q.f, t - x / q.v); },
  virt: function (q, x, t) { return (q.fixed ? -1 : 1) * M2.src(q.sh, q.A, q.f, t - x / q.v); },
  refl: function (q, x, t) { return (q.fixed ? -1 : 1) * M2.src(q.sh, q.A, q.f, t - (2 * q.L - x) / q.v); },
  reflecting: function (q, t) { return q.v * t > q.L; },
  /* ②-3：はじく前の形（xp を頂点とする三角形、高さ h0） */
  /* q.w があれば、はじいた所のまわり（半幅 w）だけの三角の山（発生した波が両側へ進むのが見やすい）。なければ糸全体が三角形（実際にはじいた弦） */
  pluckShape: function (q, x) {
    if (x <= 0 || x >= q.l) return 0;
    if (q.w) { var d = Math.abs(x - q.xp); return d >= q.w ? 0 : q.h0 * (1 - d / q.w); }
    return x <= q.xp ? q.h0 * x / q.xp : q.h0 * (q.l - x) / (q.l - q.xp);
  },
  /* 両端固定のダランベールの解：初めの形 F を奇関数で周期 2l に延長した F̃ を使い、y = ½F̃(x − vt) + ½F̃(x + vt)。dir＝+1 右向き・−1 左向き */
  ext: function (q, u) { var P = 2 * q.l, w = ((u % P) + P) % P; return w <= q.l ? M2.pluckShape(q, w) : -M2.pluckShape(q, P - w); },
  dal: function (q, x, t, dir) { return 0.5 * M2.ext(q, x - dir * q.v * t); },
  /* 固有振動の和（m 倍振動の振幅 b_m は三角形の形から）。gamma：m 倍振動の減衰 e^(−gamma m² t)（0 なら減衰なし） */
  /* 固有振動の振幅 b_m = (2/l)∫F(x) sin(mπx/l) dx（数値積分。形ごとに覚えておく） */
  _coef: {},
  coef: function (q, m) {
    var key = [q.l, q.xp, q.w, q.h0].join('|'), c = M2._coef[key];
    if (!c) { c = M2._coef[key] = []; for (var k = 1; k <= 60; k++) { var sum = 0, N = 2000; for (var i = 1; i < N; i++) { var x = q.l * i / N; sum += M2.pluckShape(q, x) * Math.sin(k * Math.PI * x / q.l); } c[k] = 2 / q.l * sum * q.l / N; } }
    return c[m];
  },
  modal: function (q, x, t, gamma) {
    var y = 0, l = q.l, xp = q.xp, f1 = q.v / (2 * l);
    for (var m = 1; m <= 60; m++) {
      var bm = q.w ? M2.coef(q, m) : 2 * q.h0 * l * l * Math.sin(m * Math.PI * xp / l) / (m * m * Math.PI * Math.PI * xp * (l - xp));
      y += bm * Math.sin(m * Math.PI * x / l) * Math.cos(TAU * m * f1 * t) * Math.exp(-gamma * m * m * t);
    }
    return y;
  },
  /* 左端（x = 0）を振動子で s(t) = a sin 2πft（t ≧ 0）と動かし続ける糸。右端は固定端（いつも 0）。
     両端で上下が逆になって反射し、1 往復するたびに振幅が r 倍になる（左端で少しずつ失われる）：
     y = Σₙ rⁿ [ s(t − (2nl + x)/v) − s(t − (2(n+1)l − x)/v) ]（届いていない項は 0） */
  drive: function (q, x, t, f, a, r, dir) {                       /* dir：1＝右向きに進む波だけ（第 1 項）、−1＝左向きに進む波だけ（第 2 項）、なし＝和 */
    var l = q.l, v = q.v, y = 0, w = TAU * f, k = 1;
    for (var n = 0; n < 400; n++) {
      var t1 = t - (2 * n * l + x) / v; if (t1 < 0) break;
      if (dir !== -1) y += k * Math.sin(w * t1);
      var t2 = t - (2 * (n + 1) * l - x) / v; if (t2 >= 0 && dir !== 1) y -= k * Math.sin(w * t2);
      k *= r; if (k < 1e-5) break;
    }
    return a * y;
  }
};
