/* ===== 54_m1s4.js ===== */
/* =========================================================================
   ①-4 色んな波（どれも単一の振動数の波）— 2026-11-03 千葉さんの指示で作り直し
   ・5 種類を全部同時に表示する。表の形：左に名前、まん中にアニメ、右にその波のスライダー
       ウェーブマシン／水面波（深さ）／糸（張力）／音波（気温・🔊）／光波（物質）／水面の表面波（スライダーなし）
   ・操作は左上の「▶ スタート」「↺ リセット」だけ（全部共通）。振幅のスライダー・右の説明カードはなし
   ・速さ v は媒質で決まり、振動数 f は波源で決まる。波長 λ = v/f と周期 T = 1/f は「決まる量」として表示
   ・音・光はけた違いなので、図はきりのいい倍率で拡大・縮小し、スローにして、その倍率を図に明記する
   ・λ の寸法は一時停止しているときだけ（①-1 と同じ）
   ========================================================================= */
'use strict';
var M4K = {
  machine: { name: 'ウェーブマシン', sub: '速さはウェーブマシン次第で決まる', L: 4, vFix: 1.0, f: { lo: 0.25, hi: 2.0, step: 0.25, def: 0.5, ticks: [0.5, 1.0, 1.5, 2.0], unit: 'Hz' } },
  water: { name: '水面波', sub: '深いほど速い', L: 3, f: { lo: 0.25, hi: 2.0, step: 0.25, def: 0.5, ticks: [0.5, 1.0, 1.5, 2.0], unit: 'Hz' },
    h: { lo: 0.01, hi: 0.10, step: 0.01, def: 0.04, ticks: [0.02, 0.04, 0.06, 0.08, 0.10] } },
  string: { name: '糸（弦）', sub: '張力が大きいほど速い', L: 4, rho: 0.10, f: { lo: 0.5, hi: 4.0, step: 0.5, def: 2.0, ticks: [1, 2, 3, 4], unit: 'Hz' },
    S: { lo: 0.5, hi: 4.0, step: 0.5, def: 1.5, ticks: [1, 2, 3, 4] } },
  sound: { name: '音波', sub: '気温が高いほど速い', f: { log: true, lo: 2, hi: 100000, def: 440,
    stops: [2, 5, 10, 20, 50, 100, 200, 440, 1000, 2000, 5000, 10000, 20000, 40000, 100000], ticks: [10, 100, 1000, 10000, 100000] },   /* 15 段（2026-11-03 千葉さん 3 回目：7〜15 段でよい） */
    tc: { lo: -20, hi: 40, step: 1, def: 15, ticks: [-20, 0, 20, 40] } },
  light: { name: '光波', sub: '物質によって速さが変わる', f: { lo: 2.0e14, hi: 15e14, step: 0.01e14, def: WAVE.c0 / 550e-9, ticks: [3e14, 6e14, 9e14, 12e14, 15e14] } }
};
var M4_ORDER = ['machine', 'water', 'string', 'sound', 'light'];
/* 光の波長（真空中）の段：12 段。振動数の段はここから f = c/λ₀ で作る（2 本のスライダーは同じ段で連動） */
var M4_LAM = [200, 300, 400, 450, 500, 550, 600, 650, 700, 800, 1000, 1500];
var M4_FL = M4_LAM.map(function (nm) { return WAVE.c0 / (nm * 1e-9); }).sort(function (a, b) { return a - b; });
M4K.light.f.stops = M4_FL;
var M4_N = [{ n: 1.00, nm: '真空' }, { n: 1.33, nm: '水' }, { n: 1.50, nm: 'ガラス' }, { n: 2.42, nm: 'ダイヤモンド' }];
var M4_AMP = 0.6;                         /* 図の振幅（スライダーはなし。どの波も同じ見た目の大きさ） */
var M4_TEND = Infinity;                   /* ①-4 は止めるまで動き続ける（スライダーで変えた波だけ最初から） */
/* 音波の空気の粒：縦に並んだ列（少しだけばらつかせる）。疎密が見えやすいように規則正しく並べる */
var M1S4_AIR = (function () {
  var r = 7, out = [], rnd = function () { r = (r * 1103515245 + 12345) % 2147483648; return r / 2147483648; };
  for (var i = 0; i <= 90; i++) for (var j = 0; j < 7; j++) out.push({ x: i / 90, y: (j + 0.5) / 7 });   /* 均一に並べる（①-3 と同じ。2026-11-03 千葉さん） */
  return out;
})();
/* その波の値：f・T・v・λ（光は真空中の波長 λ₀ も）。st＝①-4 の状態 */
function m4Q(st, k) {
  var f = st.f[k], v, lam0 = null;
  if (k === 'machine') v = M4K.machine.vFix;
  else if (k === 'water') v = WAVE.vWater(st.h);
  else if (k === 'string') v = WAVE.vString(st.S, M4K.string.rho);
  else if (k === 'sound') v = WAVE.V(st.tc);
  else { v = WAVE.cIn(st.n); lam0 = WAVE.c0 / f; }
  return { k: k, f: f, T: 1 / f, v: v, lam: v / f, lam0: lam0, n: st.n };
}
/* 長さ・振動数・時間・速さの書き方 */
function lenTxt(x) {
  if (x >= 1) return sig(x, 3) + ' m';
  if (x >= 0.01) return sig(x * 100, 3) + ' cm';
  if (x >= 1e-3) return sig(x * 1000, 3) + ' mm';
  if (x >= 1e-6) return sig(x * 1e6, 3) + ' μm';
  return sig(x * 1e9, 3) + ' nm';
}
function fTxt(f) { if (f >= 1e12) return sig(f / 1e14, 3) + '×10¹⁴ Hz'; return sig(f, f < 10 ? 2 : 3) + ' Hz'; }
function tTxt(T) { if (T < 1e-9) return sig(T * 1e15, 3) + '×10⁻¹⁵ s'; if (T < 1e-3) return sig(T * 1e6, 3) + ' μs'; if (T < 1) return sig(T * 1000, 3) + ' ms'; return sig(T, 3) + ' s'; }
function vTxt(v) { if (v >= 1e7) return sig(v / 1e8, 3) + '×10⁸ m/s'; return sig(v, 3) + ' m/s'; }
function niceUp(x) { var p = Math.pow(10, Math.floor(Math.log(x) / Math.LN10)), c = [1, 2, 5, 10]; for (var i = 0; i < c.length; i++) if (x <= c[i] * p * 1.0001) return c[i] * p; return 10 * p; }
function bigNum(x) {
  if (x < 1000) return String(Math.round(x));
  var e = Math.floor(Math.log(x) / Math.LN10 + 1e-9), m = x / Math.pow(10, e);
  if (m >= 9.95) { m /= 10; e += 1; }
  return (Math.abs(m - 1) < 0.05 ? '' : m.toFixed(1) + '×') + '10' + String(e).split('').map(function (c) { return '⁰¹²³⁴⁵⁶⁷⁸⁹'[+c]; }).join('');
}
/* 波長〔nm〕→ 色（可視光の範囲。外は端の色）。光電効果ページと同じ近似式 */
function nmToRGB(nm) {
  var r = 0, g = 0, b = 0, L = clamp(nm, 380, 780);
  if (L < 440) { r = -(L - 440) / 60; b = 1; }
  else if (L < 490) { g = (L - 440) / 50; b = 1; }
  else if (L < 510) { g = 1; b = -(L - 510) / 20; }
  else if (L < 580) { r = (L - 510) / 70; g = 1; }
  else if (L < 645) { r = 1; g = -(L - 645) / 65; }
  else { r = 1; }
  var f = L < 420 ? 0.45 + 0.55 * (L - 380) / 40 : (L > 700 ? 0.45 + 0.55 * (780 - L) / 80 : 1);
  var c = function (x) { return Math.round(255 * Math.pow(x * f, 0.8)); };
  return [c(r), c(g), c(b)];
}
/* 図の縮尺と速さ（音・光はけた違いなので、きりのいい倍率で拡大・縮小し、スローにする）
   L：図の横幅〔m〕、K：動きを実際の 1/K の速さにする、fShow：図の中の振動数 */
/* 波長が変わったことが見えるように（2026-11-03 千葉さん 3 回目）：
   光は、縮尺もスローの倍率も 1 つに決める（波長が変わると、図の中の波の数が変わる）。
   音は、けたが 5 つも違うので、1・2・5 の 3 段ごとに縮尺とスローの倍率を決める。同じ組の中では縮尺は変わらない。
   組が変わるときは、縮尺をなめらかに変える（拡大・縮小のようすが見える） */
var M4_SB = [2, 20, 200, 2000, 20000];
function m4SoundBase(f) { var b = M4_SB[0]; M4_SB.forEach(function (x) { if (f >= x * 0.9999) b = x; }); return b; }
function m4Disp(q) {
  var L, K = 1;
  if (q.k === 'sound') { var fb = m4SoundBase(q.f); L = niceUp(2.2 * WAVE.V(15) / fb); K = 2 * fb; }
  else if (q.k === 'light') { L = 2e-6; K = 5e14; }
  else L = M4K[q.k].L;
  return { L: L, K: K, fShow: q.f / K };
}

/* ---------- スライダー（Sim のスライダーと同じ見た目。目盛りの位置は値に比例＝均一。音は対数で均一） ---------- */
function m4Slider(o) {
  /* o：{ label, lo, hi, step, stops, log, value, ticks, tickFmt, fmt(v), onChange(v) } */
  var row = el('div', 'vrow cell hasstops'), head = el('div', 'vhead');
  head.appendChild(el('span', 'vl', mathify(o.label))); head.appendChild(el('span', 'vsp'));
  var val = el('span', 'vv', ''); head.appendChild(val); row.appendChild(head);
  var bar = el('div', 'vbar'), dn = el('button', 'tiny nudge', '−'), up = el('button', 'tiny nudge', '＋'), rw = el('span', 'rw'), inp = el('input');
  dn.type = up.type = 'button'; dn.title = '1 目盛り小さく'; up.title = '1 目盛り大きく';
  inp.type = 'range'; inp.min = '0'; inp.max = '1000'; inp.step = '1'; inp.setAttribute('aria-label', o.label.replace(/\$[^$]*\$/g, '').trim());
  var P = function (v) { return o.log ? (Math.log(v) - Math.log(o.lo)) / (Math.log(o.hi) - Math.log(o.lo)) : (v - o.lo) / (o.hi - o.lo); };
  var V = function (p) { return o.log ? Math.exp(Math.log(o.lo) + p * (Math.log(o.hi) - Math.log(o.lo))) : o.lo + p * (o.hi - o.lo); };
  var snap = function (v) {
    if (o.stops) { var b = o.stops[0]; o.stops.forEach(function (q) { if (Math.abs(P(q) - P(v)) < Math.abs(P(b) - P(v))) b = q; }); return b; }
    return clamp(Math.round((v - o.lo) / o.step) * o.step + o.lo, o.lo, o.hi);
  };
  var cur = o.value;
  var show = function () {
    var p = P(cur); inp.value = String(Math.round(p * 1000)); inp.style.setProperty('--p', (p * 100).toFixed(1) + '%');
    val.innerHTML = o.fmt(cur);
  };
  var set = function (v, quiet) { cur = snap(v); show(); if (!quiet) o.onChange(cur); };
  inp.addEventListener('input', function () { set(V(+inp.value / 1000)); });
  var nudge = function (sg) {
    if (o.stops) { var i = o.stops.indexOf(cur); i = clamp((i < 0 ? 0 : i) + sg, 0, o.stops.length - 1); set(o.stops[i]); }
    else set(cur + sg * o.step);
  };
  dn.addEventListener('click', function () { nudge(-1); }); up.addEventListener('click', function () { nudge(1); });
  rw.appendChild(inp);
  var tk = el('div', 'stoptk');
  (o.ticks || []).forEach(function (v, i, a) {
    var sp = el('span', '', o.tickFmt ? o.tickFmt(v, i === a.length - 1) : String(v));
    sp.style.left = 'calc(9px + (100% - 18px) * ' + P(v).toFixed(4) + ')'; tk.appendChild(sp);
  });
  rw.appendChild(tk);
  bar.appendChild(dn); bar.appendChild(rw); bar.appendChild(up); row.appendChild(bar);
  set(o.value, true);
  return { row: row, rw: rw, set: set, get: function () { return cur; }, P: P, inp: inp };
}
/* 値の帯（音：超低周波・可聴音・超音波／光：赤外線・可視光・紫外線）。光電効果ページの色の帯と同じ形 */
function m4Spec(sl, zones, marks) {
  var sp = el('div', 'specbar'), h = ''; sp.setAttribute('aria-hidden', 'true');
  zones.forEach(function (z) {
    var st = 'left:' + (z.a * 100).toFixed(2) + '%;width:' + ((z.b - z.a) * 100).toFixed(2) + '%';
    h += '<i class="' + (z.grad ? 'spv' : 'spz ' + z.t) + '" style="' + st + (z.grad ? ';background:' + z.grad : '') + '"></i>';
    if (z.lab) h += '<span class="spl ' + z.t + '" style="' + st + '">' + z.lab + '</span>';
  });
  (marks || []).forEach(function (x) { h += '<i class="spu" style="left:' + (x * 100).toFixed(2) + '%"></i>'; });
  sp.innerHTML = h; sl.rw.appendChild(sp); sl.row.classList.add('hasspec');
}

/* ---------- ①-4 の本体（Sim を使わない。SIMS に入れて「同時に動くのは 1 つ」を守る） ---------- */
function M4Sec(host) {
  this.mode = 'mode1'; this.playing = false; this.ended = false; this.t = 0;
  this.st = { f: {}, h: M4K.water.h.def, S: M4K.string.S.def, tc: M4K.sound.tc.def, n: 1.00 };
  var self = this;
  M4_ORDER.forEach(function (k) { self.st.f[k] = M4K[k].f.def; });
  this.build(host);
  SIMS.push(this);
  if (window.IntersectionObserver) new IntersectionObserver(function (es) { es.forEach(function (e) { if (!e.isIntersecting && self.playing) { self.playing = false; self.syncPlayLabel(); } }); }).observe(host);
  AUDIO.onChange(function () { self.syncSpk(); });
  this.resize(); this.draw();
}
M4Sec.prototype.build = function (host) {
  var self = this;
  var ctr = host.querySelector('.m4ctl');
  this.bPlay = el('button', 'b play', '▶ 全てスタート'); this.bPlay.type = 'button';   /* 全部の波をいっしょに（2026-11-03 千葉さん 3 回目） */
  this.bReset = el('button', 'b', '↺ リセット'); this.bReset.type = 'button';
  ctr.appendChild(this.bPlay); ctr.appendChild(this.bReset);
  this.bPlay.addEventListener('click', function () { self.togglePlay(); });
  this.bReset.addEventListener('click', function () { Object.keys(self.rows).forEach(function (k) { self.rows[k].tl = 0; self.rows[k].on = false; }); self.playing = false; self.syncPlayLabel(); self.draw(); });
  this.rows = {};
  var tab = host.querySelector('.m4tab');
  ['machine', 'water', 'string', 'quake', 'sound', 'light', 'surf'].forEach(function (k) {
    if (k === 'surf') { self.buildSurf(host); return; }
    if (k === 'quake') { self.buildQuake(tab); return; }   /* 糸（弦）の下に地震波（2026-11-08 千葉さん 19 回目） */
    var r = el('div', 'm4row m4-' + k), nm = el('div', 'm4name'), cvw = el('div', 'm4cv'), cv = el('canvas'), ct = el('div', 'm4side');
    nm.innerHTML = k === 'surf' ? '水面の表面波<small>水の粒の動き</small>' : M4K[k].name + '<small>' + M4K[k].sub + '</small>';
    cvw.appendChild(cv); r.appendChild(nm); r.appendChild(cvw); r.appendChild(ct); tab.appendChild(r);
    self.rows[k] = { row: r, cv: cv, side: ct, tl: 0, on: false };
    self.rowPlayBtn(k, nm);                                         /* 名前の下に、その波だけの ▶ スタート */
    if (k === 'water') nm.appendChild(el('span', 'm4gh', mathify('$v = \\sqrt{gh}$<br>（$g$ は重力加速度、$h$ は深さ）')));   /* 2026-11-03 千葉さん 5 回目 */
    if (k === 'surf') { ct.appendChild(el('p', 'm4note', '水面を伝わる波では、水の粒はその場で<b>円をえがくように</b>動く（深いところほど小さい円）。そのため、水面波は横波とも縦波とも言い切れない。赤い粒に注目しよう。')); return; }
    var vb = el('div', 'varbox m4vb'); ct.appendChild(vb);
    var fo = M4K[k].f, on = function () { self.changed(k); };
    var fsl = m4Slider({ label: '振動数 $f$', lo: fo.lo, hi: fo.hi, step: fo.step, stops: fo.stops, log: fo.log, value: fo.def, ticks: fo.ticks,
      tickFmt: k === 'light' ? function (v, last) { return String(Math.round(v / 1e14)) + (last ? '×10¹⁴' : ''); } : (k === 'sound' ? function (v, last) { return v >= 10000 ? (v / 10000) + '万' + (last ? ' Hz' : '') : String(v); } : function (v, last) { return fmt(v, v % 1 ? 1 : 0) + (last ? ' Hz' : ''); }),
      fmt: function (v) { return fTxt(v); }, onChange: function (v) { self.st.f[k] = v; if (self.rows[k].fsl.onExtra) self.rows[k].fsl.onExtra(v); on(); } });
    if (k === 'sound') vb.appendChild(el('p', 'm4hint', mathify('振動数 $f$ は音の高さに対応する。')));
    if (k === 'light') vb.appendChild(el('p', 'm4hint', mathify('振動数 $f$（波長 $\\lambda$）は色に対応する。')));
    vb.appendChild(fsl.row); self.rows[k].fsl = fsl; self.st.f[k] = fsl.get();   /* 段の値にそろえる */
    /* 光：振動数のスライダーの下に波長のスライダー（光電効果ページの「2 光電効果の実験」と同じ作り。2 本は連動し、色の帯は左右が逆） */
    if (k === 'light') {
      var lsl = m4Slider({ label: '波長 $\\lambda_0$（真空中）', lo: 200, hi: 1500, step: 1, stops: M4_LAM, value: WAVE.c0 / fo.def * 1e9, ticks: [200, 400, 600, 800, 1000, 1200, 1400],
        tickFmt: function (v, last) { return v + (last ? ' nm' : ''); }, fmt: function (v) { return Math.round(v) + ' nm'; },
        onChange: function (v) { self.st.f.light = WAVE.c0 / (v * 1e-9); fsl.set(self.st.f.light, true); self.lamIcon(); on(); } });
      vb.appendChild(lsl.row); self.lsl = lsl;                      /* 名前は振動数と同じくスライダーの上（2026-11-05 千葉さん 8 回目） */
      var ll = lsl.row.querySelector('.vhead .vl'), pc = el('canvas', 'lamph'); pc.setAttribute('aria-hidden', 'true'); self.lamPh = null;   /* 名前の横の小さな波の絵はなくした（2026-11-07 千葉さん 13 回目） */
      fsl.onExtra = function (v) { lsl.set(WAVE.c0 / v * 1e9, true); self.lamIcon(); };
      /* いまの媒質の中での波長（2026-11-03 千葉さん 5 回目） */
      self.lamMed = el('div', 'm4lamm'); vb.appendChild(self.lamMed);
    }
    /* 音：光と同じ形の波長のスライダー（空気中の波長 λ = V/f。2026-11-03 千葉さん 5 回目）。気温を変えると、同じ f でも λ が変わる */
    if (k === 'sound') {
      self.sLamStops = fo.stops.map(function (f) { return WAVE.V(self.st.tc) / f; }).sort(function (a, b) { return a - b; });
      var ssl = m4Slider({ label: '波長 $\\lambda$（空気中）', lo: 0.003, hi: 200, log: true, stops: self.sLamStops, value: WAVE.V(self.st.tc) / self.st.f.sound, ticks: [0.01, 0.1, 1, 10, 100],
        tickFmt: function (v, last) { return v < 1 ? Math.round(v * 100) + ' cm' : String(v) + (last ? ' m' : ''); }, fmt: function (v) { return lenTxt(v); },
        onChange: function (v) { self.st.f.sound = WAVE.V(self.st.tc) / v; fsl.set(self.st.f.sound, true); self.st.f.sound = fsl.get(); self.lamIcon(); on(); } });
      vb.appendChild(ssl.row); self.ssl = ssl;
      /* 波長の帯：短い波はぎっしり、長い波はのびた波で（電磁波の波長の図と同じ考え。2026-11-05 千葉さん 8 回目） */
      var chirp = el('canvas', 'chirp'); chirp.setAttribute('aria-hidden', 'true'); ssl.rw.appendChild(chirp); ssl.row.classList.add('haschirp'); self.chirp = chirp;
      window.addEventListener('resize', function () { setTimeout(function () { self.lamIcon(); }, 120); });
      var sll = ssl.row.querySelector('.vhead .vl'), spc = el('canvas', 'lamph'); spc.setAttribute('aria-hidden', 'true'); self.lamPhS = null;
      fsl.onExtra = function (v) { ssl.set(WAVE.V(self.st.tc) / v, true); self.lamIcon(); };
    }
    if (k === 'water') vb.appendChild(m4Slider({ label: '水の深さ $h$', lo: 0.01, hi: 0.10, step: 0.01, value: self.st.h, ticks: M4K.water.h.ticks, tickFmt: function (v, last) { return Math.round(v * 100) + (last ? ' cm' : ''); }, fmt: function (v) { return Math.round(v * 100) + ' cm'; }, onChange: function (v) { self.st.h = v; on(); } }).row);
    if (k === 'string') vb.appendChild(m4Slider({ label: '糸の張力', lo: 0.5, hi: 4.0, step: 0.5, value: self.st.S, ticks: M4K.string.S.ticks, tickFmt: function (v, last) { return v + (last ? ' N' : ''); }, fmt: function (v) { return fmt(v, 1) + ' N'; }, onChange: function (v) { self.st.S = v; on(); } }).row);
    if (k === 'sound') vb.appendChild(m4Slider({ label: '気温 $t$', lo: -20, hi: 40, step: 1, value: self.st.tc, ticks: M4K.sound.tc.ticks, tickFmt: function (v, last) { return String(v).replace('-', '−') + (last ? ' ℃' : ''); }, fmt: function (v) { return String(v).replace('-', '−') + ' ℃'; }, onChange: function (v) { self.st.tc = v; var V = WAVE.V(v), a = M4K.sound.f.stops.map(function (f) { return V / f; }).sort(function (p, q) { return p - q; }); a.forEach(function (x, i) { self.sLamStops[i] = x; }); self.ssl.set(V / self.st.f.sound, true); self.lamIcon(); on(); } }).row);
    if (k === 'light') {
      var nr = el('div', 'vrow cell segrow'), nh = el('div', 'vhead'); nh.appendChild(el('span', 'vl', mathify('物質（絶対屈折率 $n$）'))); nr.appendChild(nh);
      var sg = el('div', 'vseg'); self.nBtns = [];
      M4_N.forEach(function (o) { var b = el('button', 'b vsegb', o.nm + ' ' + o.n.toFixed(2)); b.type = 'button'; b.addEventListener('click', function () { self.st.n = o.n; self.syncN(); on(); }); sg.appendChild(b); self.nBtns.push({ b: b, n: o.n }); });
      nr.appendChild(sg); vb.appendChild(nr); self.syncN();
    }
    /* 決まる量：周期 T・速さ v・波長 λ（光は真空中の波長 λ₀ も） */
    var dv = el('div', 'm4dep'); ct.appendChild(dv); self.rows[k].dep = dv;
    if (k === 'sound') {                                             /* 🔊 は左の ▶ スタートの下（2026-11-05 千葉さん 8 回目） */
      var sr = el('div', 'spkrow m4spk'), sb = el('button', 'b spk rplay', '🔊 音を鳴らす'); sb.type = 'button';
      sb.addEventListener('click', function () { self.sound(false); });
      var msg = el('span', 'spkmsg', '人の耳には聞こえない（およそ 20〜20000 Hz の外）');
      sr.appendChild(sb); sr.appendChild(msg); nm.appendChild(sr); self.spk = sb; self.spkMsg = msg;
    }
  });
  /* 振動数の帯 */
  var fa = this.rows.sound.fsl, ia = fa.P(20), ib = fa.P(20000);
  m4Spec(fa, [{ a: 0, b: ia, t: 'inf', lab: '超低周波' }, { a: ia, b: ib, t: 'aud', lab: '人に聞こえる音（可聴音）' }, { a: ib, b: 1, t: 'ult', lab: '超音波' }], [ia, ib]);
  var fl = this.rows.light.fsl, iIR = fl.P(WAVE.c0 / 780e-9), iUV = fl.P(WAVE.c0 / 380e-9), stops = [];
  for (var j = 0; j <= 24; j++) { var L = 780 - 400 * j / 24, c = nmToRGB(L); stops.push('rgb(' + c.join(',') + ') ' + ((fl.P(WAVE.c0 / (L * 1e-9)) - iIR) / (iUV - iIR) * 100).toFixed(1) + '%'); }
  m4Spec(fl, [{ a: 0, b: iIR, t: 'ir', lab: '赤外線' }, { a: iIR, b: iUV, t: 'vis', lab: '可視光', grad: 'linear-gradient(90deg,' + stops.join(',') + ')' }, { a: iUV, b: 1, t: 'uv', lab: '紫外線' }], [iIR, iUV]);
  var ls = this.lsl, lUV = ls.P(380), lIR = ls.P(780), st2 = [];
  for (var j2 = 0; j2 <= 24; j2++) { var L2 = 380 + 400 * j2 / 24, c2 = nmToRGB(L2); st2.push('rgb(' + c2.join(',') + ') ' + ((ls.P(L2) - lUV) / (lIR - lUV) * 100).toFixed(1) + '%'); }
  m4Spec(ls, [{ a: 0, b: lUV, t: 'uv', lab: '紫外線' }, { a: lUV, b: lIR, t: 'vis', lab: '可視光', grad: 'linear-gradient(90deg,' + st2.join(',') + ')' }, { a: lIR, b: 1, t: 'ir', lab: '赤外線' }], [lUV, lIR]);
  var sl2 = this.ssl, V15 = WAVE.V(15), jU = sl2.P(V15 / 20000), jI = sl2.P(V15 / 20);
  m4Spec(sl2, [{ a: 0, b: jU, t: 'ult', lab: '超音波' }, { a: jU, b: jI, t: 'aud', lab: '人に聞こえる音（可聴音）' }, { a: jI, b: 1, t: 'inf', lab: '超低周波' }], [jU, jI]);
  this.lamIcon();
  this.cv = this.rows.machine.cv;
  this.syncDep(); this.syncSpk();
};
M4Sec.prototype.syncN = function () { var n = this.st.n; this.nBtns.forEach(function (o) { var on = Math.abs(o.n - n) < 1e-9; o.b.classList.toggle('on', on); o.b.setAttribute('aria-pressed', on ? 'true' : 'false'); }); };
M4Sec.prototype.syncDep = function () {
  var self = this;
  M4_ORDER.forEach(function (k) {
    var q = m4Q(self.st, k), h = '<span><i>T</i> = ' + tTxt(q.T) + '</span><span>' + (k === 'sound' ? '音速 <i>V</i>' : (k === 'light' ? '光の速さ' : '速さ <i>v</i>')) + ' = ' + vTxt(q.v) + '</span><span>波長 <i>λ</i> = ' + lenTxt(q.lam) + '</span>';
    if (k === 'light') {
      h += '<span>真空中の波長 <i>λ</i>₀ = ' + lenTxt(q.lam0) + '</span>';
      var mat = M4_N.filter(function (o) { return Math.abs(o.n - q.n) < 1e-6; })[0], mh = 'いまの媒質（' + mat.nm + '）の中での波長<br><b><i>λ</i> = ' + lenTxt(q.lam) + '</b>';
      if (self.lamMed && self.lamMed._h !== mh) { self.lamMed._h = mh; self.lamMed.innerHTML = mh; }
    }
    var d = self.rows[k].dep; if (d._h !== h) { d._h = h; d.innerHTML = h; }
  });
};
/* スライダーで変えた波だけ最初から（ほかの波は止めない。2026-11-03 千葉さん） */
M4Sec.prototype.changed = function (k) {
  this.syncDep();
  if (k === 'sound') this.sound(true);
  var r = this.rows[k];
  if (r) {
    if (r.on) r.tl = 0;                                              /* 動いているとき：その波だけ波源から出し直す */
    else { var q = m4Q(this.st, k), d = m4Disp(q); r.tl = d.L / (q.v / d.K) + 0.25 / d.fShow; }   /* 止まっているとき：新しい波が図の右はしまで届いた所で止めて見せる（λ を比べやすい） */
  }
  this.draw();
};
/* その波だけの ▶ スタート（名前の下） */
M4Sec.prototype.rowPlayBtn = function (k, host) {
  var self = this, b = el('button', 'b rplay', '▶ スタート'); b.type = 'button';
  b.addEventListener('click', function () { self.toggleRow(k); });
  host.appendChild(b); this.rows[k].pb = b;
};
M4Sec.prototype.anyOn = function () { var r = this.rows; return Object.keys(r).some(function (k) { return r[k].on; }); };
M4Sec.prototype.allOn = function () { var r = this.rows; return Object.keys(r).every(function (k) { return r[k].on; }); };
M4Sec.prototype.stopOthers = function () { var me = this; SIMS.forEach(function (s) { if (s !== me && s.playing) { s.playing = false; s.syncPlayLabel(); } }); };
M4Sec.prototype.toggleRow = function (k) {
  var r = this.rows[k];
  if (r.on) { r.on = false; this.playing = this.anyOn(); this.syncPlayLabel(); this.draw(); return; }
  if (k === 'quake' && r.tl >= M1Q.tEnd() - 1e-6) r.tl = 0;          /* 終わっていたら最初から */
  this.stopOthers(); r.on = true; this.playing = true; this.syncPlayLabel(); startLoop();
};
/* 波長のスライダーの名前と値の間の小さな波（色は波長の色。紫外線・赤外線は灰色がかった色で点線） */
M4Sec.prototype.lamIcon = function () {
  var c = this.lamPh; if (!c) { if (this.ssl) this.drawChirp(WAVE.V(this.st.tc) / this.st.f.sound); return; }
  var W = 46, H = 16, dpr = window.devicePixelRatio || 1;
  if (c.width !== Math.round(W * dpr)) { c.width = Math.round(W * dpr); c.height = Math.round(H * dpr); c.style.width = W + 'px'; c.style.height = H + 'px'; }
  var ctx = c.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, W, H);
  var nm = WAVE.c0 / this.st.f.light * 1e9, vis = nm >= 380 && nm <= 780, rgb = vis ? nmToRGB(nm) : (nm < 380 ? [92, 76, 140] : [128, 62, 56]);
  var cyc = clamp(1.5 + (780 - nm) / 160, 1, 5);                   /* 波長が短いほど、波の数を多く */
  ctx.strokeStyle = 'rgb(' + rgb.join(',') + ')'; ctx.lineWidth = 2; if (!vis) ctx.setLineDash([3, 2]); ctx.beginPath();
  for (var i = 0; i <= 60; i++) { var x = 3 + (W - 6) * i / 60; ctx.lineTo(x, H / 2 - 5 * Math.sin(TAU * cyc * i / 60)); }
  ctx.stroke();
  var c2 = this.lamPhS; if (!c2) return;                             /* 音：波長が短いほど波の数を多く（対数で） */
  if (c2.width !== Math.round(W * dpr)) { c2.width = Math.round(W * dpr); c2.height = Math.round(H * dpr); c2.style.width = W + 'px'; c2.style.height = H + 'px'; }
  var x2 = c2.getContext('2d'); x2.setTransform(dpr, 0, 0, dpr, 0, 0); x2.clearRect(0, 0, W, H);
  var lam = WAVE.V(this.st.tc) / this.st.f.sound, aud = WAVE.audible(this.st.f.sound), cy2 = clamp(1 + (Math.log(100) - Math.log(lam)) / Math.LN10 * 0.9, 1, 6.5);
  x2.strokeStyle = aud ? '#1f6f5c' : '#8a8f97'; x2.lineWidth = 2; if (!aud) x2.setLineDash([3, 2]); x2.beginPath();
  for (var i2 = 0; i2 <= 80; i2++) { var xx = 3 + (W - 6) * i2 / 80; x2.lineTo(xx, H / 2 - 5 * Math.sin(TAU * cy2 * i2 / 80)); }
  x2.stroke();
  this.drawChirp(lam);
};
/* 波長の帯（スライダーの下）。横の位置はスライダーと同じ（対数）。波の見た目の長さも左から右へ指数的にのばす（正確な縮尺ではない） */
M4Sec.prototype.drawChirp = function (lam) {
  var c = this.chirp; if (!c || !c.offsetParent) return;
  var W = Math.max(120, Math.floor(c.clientWidth || 200)), H = 30, ctx = prep(c, W, H);
  ctx.clearRect(0, 0, W, H);
  var la = 2.2, lb = W * 0.9, r = lb / la, cy = 12, A = 6;          /* 左端の見た目の波長 la px → 右端 lb px */
  var ph = function (p) { return W * (1 - Math.pow(r, -p)) / (la * Math.log(r)) * 1; };   /* φ(p) = ∫₀ᵖ W dp' / λ(p')（波の数） */
  ctx.save(); ctx.strokeStyle = '#3c6e8f'; ctx.lineWidth = 1.2; ctx.beginPath();
  for (var i = 0; i <= 900; i++) { var p = i / 900, x = p * W, y = cy - A * Math.sin(TAU * ph(p)); if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y); }
  ctx.stroke(); ctx.restore();
  var pm = this.ssl.P(lam), xm = clamp(pm, 0, 1) * W;               /* いまの波長の位置 */
  ctx.save(); ctx.fillStyle = 'rgba(224,123,24,.25)'; ctx.fillRect(xm - 3, 2, 6, 20); ctx.strokeStyle = '#c9670c'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(xm, 1); ctx.lineTo(xm, 23); ctx.stroke(); ctx.restore();
  label(ctx, '← 波長が短い', 1, H - 4, { size: 9.5, color: COL.ink2, align: 'left' });
  label(ctx, '波長が長い →', W - 1, H - 4, { size: 9.5, color: COL.ink2, align: 'right' });
};
/* ＜参考＞水面の表面波（表の外。2 行あけてから） */
M4Sec.prototype.buildSurf = function (host) {
  var box = host.querySelector('.m4ref'), cvw = el('div', 'm4refcv'), cv = el('canvas'), tx = el('div', 'm4reftx');
  cvw.appendChild(cv); box.appendChild(cvw); box.appendChild(tx);
  tx.innerHTML = mathify('<p>水面を伝わる波は、横波でも縦波でもない。水面近くの水の粒は、その場で<b>円をえがくように</b>回っている（赤い粒に注目）。</p>' +
    '<p class="m4cond"><b>この図のような動きになる条件</b>　波長が水深に比べて十分に短いとき（水が深いとき）。円の半径は深くなるほど急激に小さくなり、水底の水はほとんど動かない（表面だけの波なので<b>表面波</b>という）。</p>' +
    '');
  this.rows.surf = { row: box, cv: cv, side: tx, tl: 0, on: false };
  this.rowPlayBtn('surf', host.querySelector('.m4refh'));
};
M4Sec.prototype.syncSpk = function () {
  if (!this.spk) return;
  var on = AUDIO.owner() === 'm1s4', q = m4Q(this.st, 'sound');
  this.spk.textContent = on ? '■ 音を止める' : '🔊 音を鳴らす'; this.spk.classList.toggle('on', on); this.spk.classList.toggle('glow', !on);   /* 鳴っていないときは光らせる（16 回目） */
  this.spkMsg.classList.toggle('on', !WAVE.audible(q.f));
};
/* 音：押したら鳴らす／止める。retune＝値を変えたとき（鳴っていれば新しい値で鳴らし直す） */
M4Sec.prototype.sound = function (retune) {
  var q = m4Q(this.st, 'sound'), on = AUDIO.owner() === 'm1s4';
  if (retune) { if (on) AUDIO.play('m1s4', [{ f: q.f }], 0.75); this.syncSpk(); return; }   /* 聞こえない振動数でも止めない（音だけ出ない） */
  if (on) { AUDIO.stop(); return; }
  AUDIO.play('m1s4', [{ f: q.f }], 0.75);
  this.syncSpk();
};
/* ▶ 全てスタート：全部の波を動かす（どれか動いていれば、全部止める） */
M4Sec.prototype.togglePlay = function () {
  var self = this;
  if (this.anyOn()) { Object.keys(this.rows).forEach(function (k) { self.rows[k].on = false; }); this.playing = false; this.syncPlayLabel(); this.draw(); return; }
  this.stopOthers();
  Object.keys(this.rows).forEach(function (k) { if (k !== 'surf') self.rows[k].on = true; });   /* ＜参考＞の表面波は、全てスタートでは動かさない（2026-11-03 千葉さん 5 回目） */
  this.playing = true; this.syncPlayLabel(); startLoop();
};
/* ほかの節が動き出して playing = false にされたときも、ここで全部の波を止める */
M4Sec.prototype.syncPlayLabel = function () {
  var self = this;
  if (!this.playing) Object.keys(this.rows).forEach(function (k) { self.rows[k].on = false; });
  var txt = this.anyOn() ? '❚❚ 全て一時停止' : '▶ 全てスタート';
  if (this.bPlay.textContent !== txt) this.bPlay.textContent = txt;
  Object.keys(this.rows).forEach(function (k) { var r = self.rows[k]; if (!r.pb) return; var tx = r.on ? '❚❚ 一時停止' : '▶ スタート'; if (r.pb.textContent !== tx) r.pb.textContent = tx; r.pb.classList.toggle('on', r.on); });
};
M4Sec.prototype.step = function (dt) {
  var self = this;
  Object.keys(this.rows).forEach(function (k) {
    var r = self.rows[k]; if (!r.on) return;
    if (k === 'quake') {   /* 地震波：観測地に届いたら一時停止（えらんだとき）。全部通りすぎたら止める */
      var t0 = r.tl, t1 = r.tl + dt;
      if (r.auto) { var ev = M1Q.events().filter(function (e) { return e.t > t0 && e.t <= t1; })[0]; if (ev) { r.tl = ev.t + 1e-6; r.on = false; r.msg = ev; self.playing = self.anyOn(); self.syncPlayLabel(); return; } }
      r.tl = t1; r.msg = null; if (r.tl > M1Q.tEnd()) { r.tl = M1Q.tEnd(); r.on = false; self.playing = self.anyOn(); self.syncPlayLabel(); }
      return;
    }
    r.tl = Math.min(M4_TEND, r.tl + dt);
  });
  this.draw();
};
/* 音の図の横幅〔m〕。組が変わったら 0.8 秒かけて、なめらかに拡大・縮小する（対数で補間） */
M4Sec.prototype.soundL = function () {
  var self = this, target = m4Disp(m4Q(this.st, 'sound')).L, now = performance.now();
  if (this._sL === undefined) this._sL = target;
  if (this._sL !== target) { this._zoom = { a: this._curL || this._sL, b: target, s: now }; this._sL = target; }
  var z = this._zoom, L = target;
  if (z) {
    var p = clamp((now - z.s) / 800, 0, 1), e = p < 0.5 ? 2 * p * p : 1 - 2 * (1 - p) * (1 - p);
    L = Math.exp(Math.log(z.a) + (Math.log(z.b) - Math.log(z.a)) * e);
    this._zmsg = { txt: z.b < z.a ? '縮尺を変えた（' + bigNum(z.a / z.b) + ' 倍に拡大）' : '縮尺を変えた（' + bigNum(z.b / z.a) + ' 分の 1 に縮小）', until: z.s + 2600 };
    if (p >= 1) this._zoom = null;
    if (!this.playing) requestAnimationFrame(function () { self.draw(); });
  }
  if (this._zmsg && now < this._zmsg.until && !this.playing && !this._zoom) { var self2 = this; clearTimeout(this._zt); this._zt = setTimeout(function () { self2.draw(); }, this._zmsg.until - now + 20); }
  this._curL = L;
  return L;
};
M4Sec.prototype.resize = function () { var self = this; Object.keys(this.rows).forEach(function (k) { self.rows[k].W = 0; }); };
M4Sec.prototype.draw = function () {
  var self = this;
  Object.keys(this.rows).forEach(function (k) {
    var r = self.rows[k]; if (!r.cv.offsetParent) return;
    var W = Math.max(240, Math.floor(r.cv.clientWidth || 500)), H = k === 'quake' ? Math.round(clamp(W * 0.52, 230, 330)) : k === 'surf' ? Math.round(W < 520 ? clamp(W * 0.42, 120, 160) : clamp(W * 0.2, 124, 160)) : (k === 'sound' ? 250 : (k === 'light' ? 168 : (k === 'water' ? 150 : 132)));   /* 表面波は前の 60%。音は下に横波表示 */
    var ctx = prep(r.cv, W, H);
    var tl = r.tl;                                                  /* その波の時刻（波ごと。スライダーで変えた波は 0 から） */
    if (k === 'quake') drawQuake(ctx, W, H, tl, self.rows.quake); else if (k === 'surf') drawSurf(ctx, W, H, tl); else drawM4(ctx, W, H, m4Q(self.st, k), tl, !r.on && tl > 0, self.st, k === 'sound' ? self.soundL() : null);
    if (k === 'sound' && self._zmsg && performance.now() < self._zmsg.until) pill(ctx, self._zmsg.txt + '。右の波長の帯も見よう', W / 2 - 150, 74, { size: 11.5, bg: '#fff6dc', border: '#e07b18', color: '#6b3a0a' });
  });
};
DEFS.m1s4 = {
  id: 'm1s4', mode: 'mode1', num: 4, custom: true,
  title: '色んな波', short: '色んな波',
  html: function () {
    return '<div class="secdesc">波の速さ $v$ は<b>媒質</b>で、振動数 $f$ は<b>波源</b>で決まり、波長は $\\lambda = v/f$。<span class="todo">右のスライダーで値を変えて、$v$ と $\\lambda$ の変わり方を見よう（音波は 🔊 で聞ける）。</span></div>' +
      '<div class="ctrls m4ctlw"><div class="m4ctl"></div></div><div class="m4tab"></div>' +
      '<div class="m4refwrap"><p class="m4refh">＜参考＞水面の表面波　<small class="m4paren">（水の粒の動き）</small>　<span class="m4zero">※この波が問題として出題される可能性はゼロ</span></p><div class="m4ref"></div></div>';
  },
  build: function (art) { SIM_BY_ID.m1s4 = new M4Sec(art); }
};

/* ---------- 1 つの波を描く ---------- */
function drawM4(ctx, W, H, q, t, paused, st, Lz) {
  var d = m4Disp(q), k = q.k;
  if (Lz) d.L = Lz;                                                   /* 音：縮尺を変えている途中 */
  var x0 = W < 520 ? 44 : 64, x1 = W - 14, cy = Math.round(H * (k === 'light' ? 0.56 : 0.5)), amp = clamp(H * 0.24, 22, 40) * M4_AMP / 0.6;
  var SX = (x1 - x0) / d.L, X = function (x) { return x0 + x * SX; };
  /* 図の中の波：位相は 2π f_show (t − x/v_show)。f_show・v_show は f・v を同じ K で割ったもの（波長は変わらない） */
  var vS = q.v / d.K, fS = d.fShow;
  var y0 = function (tt) { return tt < 0 ? 0 : Math.sin(TAU * fS * tt); };
  var yx = function (x) { return y0(t - x / vS); };
  var front = vS * t;
  if (k === 'machine') {
    dotted(ctx, x0, cy, x1, cy, 'rgba(20,23,28,.28)', [5, 4]);
    var nb = W < 520 ? 24 : 40;
    for (var b = 1; b <= nb; b++) { var xb = d.L * b / nb; bead(ctx, X(xb), cy - yx(xb) * amp, 3.6, WCOL.bead); }
    ctx.save(); ctx.translate(x0, cy - y0(t) * amp); ctx.scale(0.62, 0.62); srcHand(ctx, 0, 0, false, false); ctx.restore();
  } else if (k === 'water') {
    var depth = clamp(st.h * 700, 10, 70), wTop = cy - 18, bot = wTop + depth + 10;
    var sY = function (x) { return wTop - yx(x) * amp * 0.45; };
    ctx.save(); ctx.beginPath(); ctx.moveTo(x0, sY(0));
    for (var i2 = 0; i2 <= 300; i2++) { var x2 = d.L * i2 / 300; ctx.lineTo(X(x2), sY(x2)); }
    ctx.lineTo(x1, bot); ctx.lineTo(x0, bot); ctx.closePath();
    var wg = ctx.createLinearGradient(0, wTop - 20, 0, bot); wg.addColorStop(0, '#9fd3ef'); wg.addColorStop(1, '#3f8fc0');
    ctx.fillStyle = wg; ctx.fill(); ctx.restore();
    ctx.save(); ctx.strokeStyle = '#1f5f8a'; ctx.lineWidth = 2; ctx.beginPath();
    for (var i3 = 0; i3 <= 300; i3++) { var x3 = d.L * i3 / 300; if (i3) ctx.lineTo(X(x3), sY(x3)); else ctx.moveTo(X(x3), sY(x3)); }
    ctx.stroke(); ctx.restore();
    groundLine(ctx, x0 - 8, x1 + 4, bot);
    var py = sY(0) - y0(t) * 0;
    ctx.save(); ctx.fillStyle = '#5b6470'; rrect(ctx, x0 - 8, wTop - y0(t) * amp * 0.45 - 16, 12, 26, 3); ctx.fill(); ctx.fillRect(x0 - 4, wTop - y0(t) * amp * 0.45 - 34, 4, 20); ctx.restore();
    label(ctx, '深さ ' + Math.round(st.h * 100) + ' cm（深さ・高さは拡大）', x0 + 8, Math.min(H - 9, bot + 12), { size: 10.5, color: COL.sub, align: 'left' });
  } else if (k === 'string') {
    /* 左端が波源（固定していない）、右端が固定端。右端で反射：入射波 y₀(t − x/v) と、上下を逆にした反射波 −y₀(t − (2L − x)/v) の和 */
    var Ls = d.L, yi = function (x) { return y0(t - x / vS); }, yr = function (x) { return -y0(t - (2 * Ls - x) / vS); };
    var line = function (f, col, lw, dash, a) { ctx.save(); ctx.strokeStyle = col; ctx.lineWidth = lw; ctx.globalAlpha = a || 1; if (dash) ctx.setLineDash(dash); ctx.beginPath(); for (var i4 = 0; i4 <= 400; i4++) { var x4 = Ls * i4 / 400; if (i4) ctx.lineTo(X(x4), cy - f(x4) * amp); else ctx.moveTo(X(x4), cy - f(x4) * amp); } ctx.stroke(); ctx.restore(); };
    dotted(ctx, x0, cy, x1, cy, 'rgba(20,23,28,.22)', [5, 4]);
    var refl = vS * t > Ls;
    if (refl) { line(yi, '#e07b18', 1.4, [5, 4], 0.9); line(yr, '#1663b5', 1.4, [5, 4], 0.9); }
    line(function (x) { return yi(x) + yr(x); }, '#7a3b12', 2.6);
    ctx.save(); ctx.fillStyle = '#5b6470'; rrect(ctx, x1 - 2, cy - amp - 10, 8, 2 * amp + 20, 3); ctx.fill(); ctx.restore();
    hatchSeg(ctx, x1 + 6, cy - amp - 10, x1 + 6, cy + amp + 10, 1, 7, '#9aa1ab');
    label(ctx, '固定端', x1 - 6, cy + amp + 18, { size: 10.5, color: COL.sub, align: 'right' });
    var vy = cy - (yi(0) + yr(0)) * amp;                             /* 左端の波源（振動子）。もどってきた反射波は波源で吸収されるとし、波源は糸の左端といっしょに動く */
    vibBox(ctx, x0, vy, cy + amp + 8, { w: 18, h: 14, label: false });   /* 振動子（②-3 と同じ形。糸の左端につながっている） */
    if (refl) { label(ctx, '入射波（橙の点線）', x0 + 10, 9, { size: 10, color: '#c9670c', align: 'left' }); label(ctx, '反射波（青の点線）', x0 + 118, 9, { size: 10, color: '#1663b5', align: 'left' }); label(ctx, '合成した波（実線）', x0 + 226, 9, { size: 10, color: '#7a3b12', align: 'left' }); }
    else if (paused || vS * t > 0.2) label(ctx, '右端に届くと反射する', x1 - 8, 9, { size: 10.5, color: COL.sub, align: 'right' });
  } else if (k === 'sound') {
    var uMax = 0.15 * q.lam * M4_AMP, band = 104, yT = 34;
    ctx.save(); ctx.fillStyle = 'rgba(91,122,144,.05)'; ctx.fillRect(x0, yT, x1 - x0, band); ctx.restore();
    for (var xp = x0; xp < x1; xp += 3) { var xe0 = (xp - x0) / SX, dd = vS * t > xe0 ? Math.cos(TAU * fS * (t - xe0 / vS)) : 0; if (dd > 0.05) { ctx.fillStyle = 'rgba(209,53,43,' + (0.10 * dd).toFixed(3) + ')'; ctx.fillRect(xp, yT, 3, band); } }
    ctx.save(); ctx.fillStyle = 'rgba(58,65,76,.62)';
    var thin = W < 560;                                              /* せまい画面では 1 列おき（粒がつながって線に見えないように） */
    M1S4_AIR.forEach(function (p, ip) { if (thin && Math.floor(ip / 7) % 2) return; var xe = p.x * d.L, px = X(xe + uMax * yx(xe)); if (px < x0 + 3 || px > x1) return; ctx.beginPath(); ctx.arc(px, yT + 4 + p.y * (band - 8), 1.8, 0, TAU); ctx.fill(); });
    ctx.restore();
    speakerShape(ctx, x0 - 2 + uMax * y0(t) * SX, yT + band / 2, Math.min(band, 70));
    /* 下：横波表示（右向きの変位を上向きに。2026-11-03 千葉さん 3 回目） */
    var yA = yT + band + 52, aT = 26;
    label(ctx, '横波表示', x0 + 10, yA - aT - 14, { size: 10.5, bold: true, color: COL.ink2, align: 'left' });   /* 「横波表示」だけ、グラフの上に（2026-11-04 千葉さん 6 回目） */
    axisArrow(ctx, x0 - 4, yA, x1 + 2, yA);
    axisArrow(ctx, x0, yA + aT + 6, x0, yA - aT - 10);
    ctx.save(); ctx.strokeStyle = '#7a3b12'; ctx.lineWidth = 2; ctx.beginPath(); var onT = false;
    for (var iT = 0; iT <= 500; iT++) { var xT = d.L * iT / 500, pxT = X(xT); if (pxT > x1 || xT > front) break; var pyT = yA - yx(xT) * aT; if (onT) ctx.lineTo(pxT, pyT); else { ctx.moveTo(pxT, pyT); onT = true; } }
    ctx.stroke(); ctx.restore();
  } else {
    var lam0nm = q.lam0 * 1e9, vis = lam0nm >= 380 && lam0nm <= 780, rgb = vis ? nmToRGB(lam0nm) : (lam0nm < 380 ? [92, 76, 140] : [128, 62, 56]);
    if (q.n > 1.001) { ctx.save(); ctx.fillStyle = q.n > 2 ? 'rgba(200,215,235,.6)' : (q.n > 1.4 ? 'rgba(190,205,225,.5)' : 'rgba(150,200,235,.4)'); rrect(ctx, x0 + 6, cy - amp - 16, x1 - x0 - 6, 2 * amp + 32, 8); ctx.fill(); ctx.restore(); }
    dotted(ctx, x0, cy, x1, cy, 'rgba(20,23,28,.25)', [5, 4]);
    ctx.save(); ctx.strokeStyle = 'rgb(' + rgb.join(',') + ')'; ctx.lineWidth = 2.8; if (!vis) ctx.setLineDash([7, 4]); ctx.beginPath();
    var on = false;
    for (var i5 = 0; i5 <= 500; i5++) { var x5 = d.L * i5 / 500; if (x5 > front) break; var py5 = cy - yx(x5) * amp; if (on) ctx.lineTo(X(x5), py5); else { ctx.moveTo(X(x5), py5); on = true; } }
    ctx.stroke(); ctx.restore();
    lampShape(ctx, x0, cy, 34, true);
    var mat = M4_N.filter(function (o) { return Math.abs(o.n - q.n) < 1e-6; })[0];
    label(ctx, (vis ? '可視光' : (lam0nm < 380 ? '紫外線（目に見えない）' : '赤外線（目に見えない）')) + '・' + mat.nm + 'の中', x0 + 4, H - 9, { size: 10.5, bold: true, color: vis ? COL.ink2 : (lam0nm < 380 ? '#4b3c7c' : '#7c2f28'), align: 'left' });
  }
  /* 一時停止しているときだけ：波長 λ（届いている所の、となりあう山と山） */
  if (paused && k !== 'string') {
    var ya = k === 'water' ? cy - 18 : cy, A2 = k === 'water' ? amp * 0.45 : (k === 'sound' ? 0 : amp);
    var crs = crestsOf(yx, 0.002 * d.L, Math.min(d.L, front) - 0.002 * d.L, d.L / 900, 0.9);
    if (k === 'sound') { ya = 34 + 104 + 52; A2 = 26; }               /* 音：下の横波表示の山と山で λ */
    if (crs.length >= 2) { var c1 = crs[crs.length - 2], c2 = crs[crs.length - 1]; dimH(ctx, X(c1), X(c2), ya - A2 - 10, '#c9670c', 'λ', { ticks: false }); }
  }
  /* ものさし（右下）と、拡大・スローの断り（音・光は右上） */
  var unit = niceUp(d.L / 6), upx = unit * SX, ry = H - 7;
  ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(x1 - upx, ry); ctx.lineTo(x1, ry); ctx.moveTo(x1 - upx, ry - 4); ctx.lineTo(x1 - upx, ry + 1); ctx.moveTo(x1, ry - 4); ctx.lineTo(x1, ry + 1); ctx.stroke(); ctx.restore();
  label(ctx, lenTxt(unit), x1 - upx / 2, ry - 9, { size: 10, color: COL.ink2 });
  if (k === 'light' || k === 'sound') {
    var mag = SX / 3780;                          /* 画面の 1 px ≒ 0.26 mm として、実物の何倍に描いているか */
    var t1 = k === 'light' ? '波長が非常に短いので、約 ' + bigNum(mag) + ' 倍に拡大して描いている' : (mag >= 1.5 ? '約 ' + bigNum(mag) + ' 倍に拡大して描いている' : (mag < 0.67 ? '約 ' + bigNum(1 / mag) + ' 分の 1 に縮小して描いている' : 'ほぼ実物大'));
    var t2 = d.K > 1 ? '動きは実際の約 ' + bigNum(d.K) + ' 分の 1 の速さ' : '';
    if (W < 640) {                                   /* せまい画面では 2 行に */
      label(ctx, t1, W - 8, 9, { size: 10, bold: k === 'light', color: k === 'light' ? '#6b3a0a' : COL.ink2, align: 'right' });
      if (t2) label(ctx, t2, W - 8, 22, { size: 10, color: COL.ink2, align: 'right' });
    } else label(ctx, t1 + (t2 ? '・' + t2 : ''), W - 8, 9, { size: 10.5, bold: k === 'light', color: k === 'light' ? '#6b3a0a' : COL.ink2, align: 'right' });
  }
}
/* スピーカー（横から）。(x, cy)＝振動板の中心 */
function speakerShape(ctx, x, cy, h) {
  ctx.save(); ctx.fillStyle = '#3a414c'; ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 1.4;
  rrect(ctx, x - 34, cy - h * 0.22, 16, h * 0.44, 3); ctx.fill();
  ctx.beginPath(); ctx.moveTo(x - 18, cy - h * 0.22); ctx.lineTo(x, cy - h / 2); ctx.lineTo(x, cy + h / 2); ctx.lineTo(x - 18, cy + h * 0.22); ctx.closePath(); ctx.fillStyle = '#69717d'; ctx.fill(); ctx.stroke();
  ctx.restore();
}
/* 水面の表面波（水の粒は円をえがく。深いほど小さい円）。動きは 0.5 Hz
   2026-11-05 千葉さん 8 回目：水そう（枠）は動かさない。円は決まった位置に並べ、白い粒がその上を回る。水面はその粒を通る線。左右は枠で切る */
function drawSurf(ctx, W, H, t) {
  var X0 = 12, X1 = W - 12, top = 24, bot = H - 6, lamPx = Math.min((X1 - X0) * 0.5, 320), a = lamPx * 0.05, f = 0.5;
  var yEq = top + a + 8, gap = lamPx / 8;                          /* 静かな水面の高さ・円の間かく */
  var Y = function (z) { return yEq - z; };
  /* 水（枠の中だけ） */
  ctx.save(); ctx.beginPath(); ctx.rect(X0, top - 4, X1 - X0, bot - top + 4); ctx.clip();
  ctx.beginPath(); var first = true;
  for (var x0 = X0 - lamPx; x0 <= X1 + lamPx; x0 += 2) { var p = SURF.pos(a, lamPx, f, x0, 0, t); if (first) { ctx.moveTo(p.x, Y(p.z)); first = false; } else ctx.lineTo(p.x, Y(p.z)); }
  ctx.lineTo(X1 + lamPx, bot); ctx.lineTo(X0 - lamPx, bot); ctx.closePath();
  var gr = ctx.createLinearGradient(0, top, 0, bot); gr.addColorStop(0, '#5aa9d6'); gr.addColorStop(1, '#2a6f9e'); ctx.fillStyle = gr; ctx.fill();
  ctx.strokeStyle = '#163f5c'; ctx.lineWidth = 2; ctx.beginPath(); first = true;
  for (var x1 = X0 - lamPx; x1 <= X1 + lamPx; x1 += 2) { var p1 = SURF.pos(a, lamPx, f, x1, 0, t); if (first) { ctx.moveTo(p1.x, Y(p1.z)); first = false; } else ctx.lineTo(p1.x, Y(p1.z)); }
  ctx.stroke();
  dotted(ctx, X0, yEq, X1, yEq, 'rgba(255,255,255,.75)', [5, 4]);   /* 静かなときの水面 */
  /* 決まった位置の円と、その上を回る粒（上の列が水面。下の列ほど小さい円） */
  var nC = Math.floor((X1 - X0) / gap), xs = X0 + ((X1 - X0) - nC * gap) / 2, hiI = Math.round(nC * 0.4);
  for (var j = 0; j < 3; j++) {
    var z0 = -j * lamPx * 0.12; if (Y(z0) > bot - 4) break;
    for (var i = 0; i <= nC; i++) {
      var cx = xs + i * gap, q = SURF.pos(a, lamPx, f, cx, z0, t), hi = j === 0 && i === hiI;
      ctx.beginPath(); ctx.arc(cx, Y(z0), Math.max(1.2, q.r), 0, TAU);
      ctx.fillStyle = j ? 'rgba(190,230,250,.25)' : 'rgba(190,230,250,.45)'; ctx.fill();
      ctx.strokeStyle = 'rgba(225,245,255,.9)'; ctx.lineWidth = 1; ctx.stroke();
      ctx.beginPath(); ctx.arc(q.x, Y(q.z), hi ? 4 : (j ? 2.2 : 3.2), 0, TAU); ctx.fillStyle = hi ? '#d1352b' : '#fff'; ctx.fill();
      ctx.strokeStyle = 'rgba(20,40,60,.6)'; ctx.lineWidth = 0.8; ctx.stroke();
    }
  }
  ctx.restore();
  /* 枠（動かない） */
  ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.6; ctx.strokeRect(X0, top - 4, X1 - X0, bot - top + 4); ctx.restore();
  arrow(ctx, W - 100, 11, W - 46, 11, 'vel', COL.vel);
  label(ctx, '波の進む向き', W - 106, 11, { size: 10.5, color: COL.vel, align: 'right' });
}

/* =========================================================================
   地震波（①-4 の糸（弦）の下。2026-11-08 千葉さん 19 回目）
   ・断面図：地表に観測地 C・A・震央・B・D、地下に震源 ×。震源から P 波（縦波）と S 波（横波）が同時に出る
   ・P 波 vP = 6.0 km/s、S 波 vS = 3.5 km/s（地殻のおよその値）。震源の深さ 20 km、観測地は震央から 40 km・80 km
   ・粒（地下の岩石の点）の動き：P 波は進む向き（震源から外向き）に前後、S 波は進む向きに垂直にゆれる。
     変位 u = a · g(r − v t)、g(ξ) = −(ξ/w) e^{−(ξ/w)²}（行って戻る 1 回のゆれ）、w = 5 km。粒の動きは拡大して描く
   ・実際の地震は断層のずれで起こるが、ここでは震源の 1 点から出るとした
   ・時間：実際の 4 倍の速さで動かす（図に書く）
   ========================================================================= */
var M1Q = { vP: 6.0, vS: 3.5, D: 20, X: 100, Y: 50, w: 5, K: 4,
  ST: [['観測地C', -80], ['観測地A', -40], ['震央', 0], ['観測地B', 40], ['観測地D', 80]],
  dist: function (x) { return Math.sqrt(x * x + M1Q.D * M1Q.D); },
  /* 図の時刻 t（s）→ 実際の時刻 t·K。到着の出来事（図の時刻） */
  events: function () {
    if (M1Q._ev) return M1Q._ev;
    var ev = [];
    M1Q.ST.forEach(function (st) { var r = M1Q.dist(st[1]); ev.push({ t: r / M1Q.vP / M1Q.K, st: st[0], w: 'P' }, { t: r / M1Q.vS / M1Q.K, st: st[0], w: 'S' }); });
    ev.sort(function (a, b) { return a.t - b.t; });
    var out = []; ev.forEach(function (e) { var l = out[out.length - 1]; if (l && Math.abs(l.t - e.t) < 1e-9 && l.w === e.w) l.st += '・' + e.st; else out.push(e); });   /* 同じ時刻（左右で同じ距離）はまとめる */
    return (M1Q._ev = out);
  },
  tEnd: function () { return (M1Q.dist(M1Q.X) / M1Q.vS + 3) / M1Q.K; }
};
function m1qG(xi) { var u = xi / M1Q.w; return -u * Math.exp(-u * u) * 2.33; }   /* 最大 1 になるように */
M4Sec.prototype.buildQuake = function (tab) {
  var self = this, r = el('div', 'm4row m4-quake'), nm = el('div', 'm4name'), cvw = el('div', 'm4cv'), cv = el('canvas'), ct = el('div', 'm4side');
  nm.innerHTML = '地震波<small>P 波（縦波）と S 波（横波）</small>';
  cvw.appendChild(cv); r.appendChild(nm); r.appendChild(cvw); r.appendChild(ct); tab.appendChild(r);
  this.rows.quake = { row: r, cv: cv, side: ct, tl: 0, on: false, auto: true, msg: null };
  this.rowPlayBtn('quake', nm);
  var lb = el('label', 'chk m1qauto'), ck = el('input'); ck.type = 'checkbox'; ck.checked = true;
  ck.addEventListener('change', function () { self.rows.quake.auto = ck.checked; });
  lb.appendChild(ck); lb.appendChild(document.createTextNode(' 観測地に届いたら一時停止')); nm.appendChild(lb);
  ct.innerHTML = mathify('<p class="m4note">震源で地震が起こると、<b style="color:#1663b5">P 波</b>（縦波、約 $6$ km/s）と <b style="color:#c9670c">S 波</b>（横波、約 $3.5$ km/s）が同時に出る。</p>' +
    '<p class="m4note">速い P 波が先に届いて小さくゆれ（<b>初期微動</b>）、おそい S 波があとから届いて大きくゆれる（<b>主要動</b>）。その時間の差（初期微動継続時間）は、震源から遠いほど長い。</p>' +
    '<p class="m4note">P 波は固体・液体・気体を伝わるが、S 波（横波）は固体しか伝わらない。</p>' +
    '<p class="m4note sub">実際の地震は断層のずれで起こるが、ここでは震源の 1 点から波が出るとした。</p>');
};
function drawQuake(ctx, W, H, t, row) {
  var nar = W < 520, x0 = 6, x1 = W - 6, gy = nar ? 64 : 70, gy1 = H - 6, S = (x1 - x0) / (2 * M1Q.X), Y0 = gy, Ykm = S, YK = (gy1 - gy) / S;   /* 縦横同じ縮尺（波面は円） */
  var X = function (km) { return (x0 + x1) / 2 + km * S; }, Yd = function (km) { return Y0 + km * Ykm; };
  var tr = t * M1Q.K, rP = M1Q.vP * tr, rS = M1Q.vS * tr, hx = X(0), hy = Yd(M1Q.D);
  /* 地面 */
  ctx.save(); ctx.fillStyle = '#fbf6dc'; ctx.fillRect(x0, gy, x1 - x0, gy1 - gy); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(x0, gy + 0.5); ctx.lineTo(x1, gy + 0.5); ctx.stroke(); ctx.restore();
  /* 波面（円）：地面の中だけ */
  ctx.save(); ctx.beginPath(); ctx.rect(x0, gy, x1 - x0, gy1 - gy); ctx.clip();
  [[rP, '#1663b5'], [rS, '#c9670c']].forEach(function (q) { if (q[0] <= 0) return; ctx.strokeStyle = q[1]; ctx.globalAlpha = 0.55; ctx.lineWidth = 2; ctx.setLineDash([6, 4]); ctx.beginPath(); ctx.ellipse(hx, hy, q[0] * S, q[0] * Ykm, 0, 0, TAU); ctx.stroke(); });
  ctx.restore();
  /* 地下の粒：P 波は外向きに前後、S 波は進む向きに垂直 */
  var nx = nar ? 30 : 46, ny = Math.max(6, Math.round(nx * (gy1 - gy) / (x1 - x0) * 2 * 1.0)), A = nar ? 5 : 6.5;
  for (var i = 0; i <= nx; i++) for (var j = 0; j < ny; j++) {
    var kx = -M1Q.X + 2 * M1Q.X * (i + 0.5 * (j % 2)) / nx, ky = YK * (j + 0.5) / ny;
    if (kx > M1Q.X) continue;
    var dx = kx, dy = ky - M1Q.D, r = Math.sqrt(dx * dx + dy * dy) || 1e-6, ux = dx / r, uy = dy / r;
    var aP = tr > 0 ? m1qG(r - rP) : 0, aS = tr > 0 ? m1qG(r - rS) : 0, fall = Math.min(1, 12 / Math.max(r, 12));
    var px = X(kx) + (ux * aP - uy * aS) * A * fall, py = Yd(ky) + (uy * aP + ux * aS) * A * fall;
    var cP = Math.abs(aP) * fall, cS = Math.abs(aS) * fall;
    ctx.fillStyle = cP > 0.15 && cP >= cS ? 'rgba(22,99,181,' + (0.45 + 0.5 * cP) + ')' : (cS > 0.15 ? 'rgba(201,103,12,' + (0.45 + 0.5 * cS) + ')' : 'rgba(90,80,60,.35)');
    ctx.beginPath(); ctx.arc(px, py, cP > 0.15 || cS > 0.15 ? 2.2 : 1.6, 0, TAU); ctx.fill();
  }
  /* 震源 */
  ctx.save(); ctx.strokeStyle = '#d1353f'; ctx.lineWidth = 3.5; ctx.lineCap = 'round'; [[-1, -1], [1, -1]].forEach(function (d) { ctx.beginPath(); ctx.moveTo(hx - 8 * d[0], hy - 8); ctx.lineTo(hx + 8 * d[0], hy + 8); ctx.stroke(); }); ctx.restore();
  label(ctx, '震源（深さ 20 km）', hx - 14, hy + 2, { size: nar ? 10 : 11.5, bold: true, color: '#d1353f', align: 'right' });
  /* 波の名前（波面の右下） */
  if (rP > 4 && rP * S < W) label(ctx, 'P 波（縦波）', clamp(hx + rP * S * 0.72, 40, x1 - 40), clamp(hy + rP * Ykm * 0.72, gy + 12, gy1 - 8), { size: nar ? 10 : 11.5, bold: true, color: '#1663b5' });
  if (rS > 4 && rS * S < W) label(ctx, 'S 波（横波）', clamp(hx + rS * S * 0.72, 40, x1 - 40), clamp(hy + rS * Ykm * 0.72 - 14, gy + 12, gy1 - 8), { size: nar ? 10 : 11.5, bold: true, color: '#c9670c' });
  /* 観測地：家。届いた波でゆれる（S 波のほうが大きく） */
  M1Q.ST.forEach(function (st) {
    var d = M1Q.dist(st[1]), tP = d / M1Q.vP, tS = d / M1Q.vS, sh = 0;
    if (tr > tP) sh += 1.2 * Math.sin(TAU * 2.2 * tr) * Math.exp(-(tr - tP) * 0.4) * (tr < tS ? 1 : 0.6);
    if (tr > tS) sh += 4 * Math.sin(TAU * 1.3 * tr) * Math.exp(-(tr - tS) * 0.35);
    var hxs = X(st[1]) + sh, hw = nar ? 22 : 30, hh = nar ? 16 : 20, yb = gy - 1, epi = st[1] === 0;
    ctx.save(); ctx.fillStyle = '#fff'; ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.2; ctx.fillRect(hxs - hw / 2, yb - hh, hw, hh); ctx.strokeRect(hxs - hw / 2, yb - hh, hw, hh);
    ctx.fillStyle = '#d24a2a'; ctx.beginPath(); ctx.moveTo(hxs - hw / 2 - 5, yb - hh); ctx.lineTo(hxs, yb - hh - (nar ? 12 : 15)); ctx.lineTo(hxs + hw / 2 + 5, yb - hh); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#9fe6f2'; ctx.fillRect(hxs - hw / 2 + 4, yb - hh + 4, hw / 2 - 6, hh / 2 - 2); ctx.fillRect(hxs + 2, yb - hh + 4, hw / 2 - 6, hh / 2 - 2); ctx.restore();
    label(ctx, st[0], X(st[1]), yb - hh - (nar ? 20 : 25), { size: nar ? 9.5 : 11, bold: true, color: epi ? '#d1353f' : COL.ink });
    var tag = tr > tS ? '主要動' : (tr > tP ? '初期微動' : '');
    if (tag) label(ctx, tag, X(st[1]), gy + 10, { size: nar ? 9 : 10, bold: true, color: tr > tS ? '#c9670c' : '#1663b5' });
  });
  /* 時刻と速さの注記 */
  label(ctx, nar ? '発生から ' + tr.toFixed(1) + ' s（実際の 4 倍速・粒の動きは拡大）' : '地震発生から ' + tr.toFixed(1) + ' s（実際の 4 倍の速さで動かしている。粒の動きは拡大）', x0 + 2, 10, { size: nar ? 9.5 : 11, bold: true, color: COL.ink2, align: 'left' });
  if (row && row.msg) pill(ctx, row.msg.st + 'に ' + row.msg.w + ' 波が届いた（' + (row.msg.t * M1Q.K).toFixed(1) + ' s）。▶ スタートで続き', W / 2 - (nar ? 140 : 190), gy1 - 30, { size: nar ? 10 : 11.5, bg: '#fff6dc', border: row.msg.w === 'P' ? '#1663b5' : '#e07b18', color: '#3a2a10' });
}
