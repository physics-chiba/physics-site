/* ===== 53_m1s3.js ===== */
/* =========================================================================
   ①-3 縦波（参考⑤）
   ・つるまきばね／空気の粒をボタンで切りかえ。左端の振動板（波源）が左右に単振動し、縦波が右へ進む
   ・横波表示：右向きの変位を、反時計回りに 90° 回して上向きに描く（教科書の約束）。密・疎の位置に名札
   ・作図の手順はステップ表示（左上の丸数字の見出し＋同じ丸数字の吹き出し。吹き出しは決め打ちの位置）
   ・横と縦は同じ縮尺（回した矢印の長さが変わらない）
   ========================================================================= */
'use strict';
/* 作図の手順（下の図＝粒の列の上で行う。2026-11-03 千葉さん 3 回目：湯浅氏の縦波のページと同じやり方） */
var M1S3_STEPS = [
  '① つりあいの位置からの変位を矢印で表す',
  '② 矢印を反時計回りに 90° 回して縦向きに',
  '③ 矢印の先の点をなめらかにつなぐ',
  '④ 密・疎の位置を読む'
];
var M1S3_CALL = [
  '① 縦の線（つりあいの位置）から粒までが変位。右向きが正',
  '② 右向き → 上向き、左向き → 下向き',
  '③ つなぐと、横波のような形になる',
  '④ 点が密集しているか離れているかで密・疎を選ぶ（変位が 0 の点となる）'
];
function m1s3Q(s) { var f = s.v.f, v = s.v.v; return { A: s.v.A, v: v, f: f, T: 1 / f, lam: v / f, L: M1.s3.L }; }
/* 振幅の上限：粒が追い越さないように λ/7 まで（kA ≦ 0.9） */
function m1s3AMax(s) { return Math.min(0.15, m1s3Q(s).lam / 7); }
function m1s3Geo(W, H) {
  var x0 = W < 520 ? 34 : 64, x1 = W - 20, SX = (x1 - x0) / M1.s3.L;
  var top = 52, band = clamp(W * 0.13, 64, 104), yb = top + band / 2;     /* 上の 0〜44 px はステップの見出しと操作のために空けておく。上：媒質（帯の中心 yb） */
  var AM = 0.15 * SX;                                                      /* 振幅の最大（0.15 m）の長さ。横と縦は同じ縮尺 */
  var yR = top + band + 120 + AM;                                          /* 下：粒の列（湯浅氏の縦波のページと同じ図）。上に名前と「縦波に戻す」ボタンの場所 */
  var yP = yR + AM + 6 + 92 + AM;                                         /* p-x グラフ（受験物理）の軸。上の図と同じ x0〜x1・同じ高さの幅（2026-11-07 千葉さん 15 回目） */
  return { x0: x0, x1: x1, SX: SX, top: top, band: band, yb: yb, yR: yR, ya: yR, AM: AM, yP: yP };
}
/* 空気の粒：均一に並べる（縦横に同じ間隔。2026-11-03 千葉さんの動画「音波の伝わり方」と同じ） */
var M1S3_AIR = (function () {
  var out = [], nx = 60, ny = 7;
  for (var i = 0; i <= nx; i++) for (var j = 0; j < ny; j++) out.push({ x: i * M1.s3.L / nx, y: (j + 0.5) / ny });
  return out;
})();
function m1s3Marks() { var a = []; for (var k = 0; k <= 12; k++) a.push(k * 0.2); return a; }   /* 0 から（左はしの赤い点。2026-11-03 千葉さん 5 回目） */
DEFS.m1s3 = {
  id: 'm1s3', mode: 'mode1', num: 3,
  title: '縦波', short: '縦波',
  desc: '媒質の振動の向きと波の進む向きが同じ波が<b>縦波</b>（疎密波）。<span class="todo">赤い点がその場で左右に振動するだけであることと、横波表示の作図を確かめよう。</span>',
  strobe: false, stepDiv: 16,
  varCols: [['A', 'v', 'f'], ['lam', 'T']],
  varColNote: { 1: '以下の 2 つは、左の値で決まる（直接は変えられない）' },
  vars: [
    { k: 'A', label: '振幅 $A$', aria: '振幅', stops: M1.s3.A, prop: true, stopLabels: ['0.03', '0.06', '0.09', '0.12', '0.15 m'], def: M1.s3.A0, fmt: function (x) { return fmt(x, 2) + ' m'; },
      allow: function (s) { return { lo: 0.03, hi: m1s3AMax(s) }; } },
    { k: 'v', label: '速さ $v$', aria: '速さ', stops: M1.s3.v, prop: true, stopLabels: ['0.4', '0.6', '0.8', '1.0', '1.2 m/s'], def: M1.s3.v0, fmt: function (x) { return fmt(x, 1) + ' m/s'; } },
    { k: 'f', label: '振動数 $f$', aria: '振動数', stops: M1.s3.f, prop: true, stopLabels: ['0.25', '0.50', '0.75', '1.00 Hz'], def: M1.s3.f0, fmt: function (x) { return fmt(x, 2) + ' Hz'; } },
    meterVar('lam', '波長 $\\lambda$', '波長', function (x) { return sig(x, 2) + ' m'; }, 4.8),
    meterVar('T', '周期 $T$', '周期', function (x) { return sig(x, 2) + ' s'; }, 4)
  ],
  disp: function (s, k) { var q = m1s3Q(s); if (k === 'T') return q.T; if (k === 'lam') return q.lam; return s.v[k]; },
  init: function (s) { s.med = 'spring'; s.trans = false; s.stp = 0; s.smode = 'fwd'; },
  onDefaults: function (s) { m1s3Sync(s); },
  onChanged: function (s) {
    var hi = m1s3AMax(s); if (s.v.A > hi + 1e-9) { var c = M1.s3.A.filter(function (a) { return a <= hi + 1e-9; }); s.v.A = c.length ? c[c.length - 1] : 0.03; }   /* λ が短くなったら振幅を下げる */
    if (s.stp) { s.stp = 0; m1s3Sync(s); }
  },
  onReset: function (s) { if (s.stp) { s.stp = 0; m1s3Sync(s); } },
  buttons: [
    { k: 'ms', label: 'つるまきばね', seg: 'med', segLabel: '媒質', onClick: function (s) { s.med = 'spring'; m1s3Sync(s); s.draw(); } },
    { k: 'ma', label: '空気の粒', seg: 'med', onClick: function (s) { s.med = 'air'; m1s3Sync(s); s.draw(); } },
    { k: 'tr', label: '横波表示', cls: 'chkb trbtn', onClick: function (s) { s.trans = !s.trans; s._trTouched = true; if (!s.trans) s.stp = 0; m1s3Sync(s); s.draw(); } },
    { k: 'st', label: '縦波→横波の<br>作図の手順を見る', cls: 'stepgo two', onClick: function (s) { m1s3StepGo(s, s.stp && s.smode === 'fwd' ? 0 : 1, 'fwd'); } }
  ],
  /* 最初は波が媒質の右端まで届いて少しあとまで（そのあとは「▶ 最初から」） */
  tEnd: function (s) { var q = m1s3Q(s); return q.L / q.v + 3 * q.T; },
  tInfo: function (s) { return periodInfo(m1s3Q(s).T); },
  gT: function (s) { return m1s3Q(s).T; },
  height: function (s, w) { var g = m1s3Geo(w, 400); return Math.round(g.yP + g.AM + 34); },
  afterBuild: function (s) {
    s.R.innerHTML = ''; var sw = el('div', 'row2 sliders inR'); sw.appendChild(s.varbox); s.R.appendChild(sw); s.varbox.classList.add('inR');
    s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);
    /* ステップの操作（前へ・次へ）。場所は最初からとっておく */
    var bar = el('div', 'stepbar'); s.stepBar = bar;
    var bp = el('button', 'b', '◀ 前へ'), sn = el('span', 'stepn', ''), bn = el('button', 'b', '次へ ▶'), bx = el('button', 'b', '作図を終わる');
    [bp, bn, bx].forEach(function (b) { b.type = 'button'; });
    bp.addEventListener('click', function () { m1s3StepGo(s, Math.max(1, s.stp - 1), s.smode); });
    bn.addEventListener('click', function () { m1s3StepGo(s, Math.min(m1s3NSteps(s), s.stp + 1), s.smode); });
    bx.addEventListener('click', function () { m1s3StepGo(s, 0); });
    bar.appendChild(bp); bar.appendChild(sn); bar.appendChild(bn); bar.appendChild(bx);
    s.stepBtns = { bp: bp, bn: bn, sn: sn, bx: bx };
    bar.classList.add('oncv'); s.cw.appendChild(bar);              /* 図の右上に重ねる（出たり消えたりで図が上下しない） */
    /* 「横波表示された縦波を縦波に戻す」ボタンは廃止（2026-11-03 千葉さん 5 回目） */
    /* 説明カード（ふだんは閉じている）の下に、縦波が 1 周期の間に進むようすの図（①-1 と同じ形） */
    s.perFig = periodFig(s.R, 'long'); setTimeout(function () { s.perFig.H = Math.round(s.H || 400); s.perFig.draw(); }, 60);
    m1s3Sync(s);
  },
  draw: function (s, ctx, W, H) { drawM1S3(s, ctx, W, H); },
  right: function (s, R) { rightM1S3(s, R); }
};
function m1s3NSteps(s) { return s.smode === 'back' ? 2 : 4; }
/* ステップ表示：mode＝'fwd'（縦波 → 横波表示の作図・4 段）／'back'（横波表示 → 縦波にもどす・2 段） */
function m1s3StepGo(s, n, mode) {
  s.stp = n; if (mode) s.smode = mode;
  if (n) { s.trans = true; if (s.playing) { s.playing = false; s.syncPlayLabel(); } if (s.t < 1e-9) { var q = m1s3Q(s); s.t = Math.min(s.tEnd(), q.L / q.v + 0.3 * q.T); } }   /* 波が全体に届いた時刻で作図する */
  m1s3Sync(s); s.draw();
}
function m1s3Sync(s) {
  [['ms', 'spring'], ['ma', 'air']].forEach(function (p) { var b = s.extra[p[0]]; if (b) { var on = s.med === p[1]; b.classList.toggle('on', on); b.setAttribute('aria-pressed', on ? 'true' : 'false'); } });
  var tb = s.extra.tr; if (tb) { tb.classList.toggle('on', !!s.trans); tb.setAttribute('aria-pressed', s.trans ? 'true' : 'false'); tb.classList.toggle('glowpick', !s._trTouched && !s.trans); }   /* 押されるまで光らせる */
  var fwd = s.stp && s.smode === 'fwd', back = s.stp && s.smode === 'back';
  var sb = s.extra.st; if (sb) { sb.innerHTML = fwd ? '作図の手順を<br>閉じる' : '縦波→横波の<br>作図の手順を見る';   /* どちらも 2 行（ボタンの高さが変わって図が上下しない） */ sb.classList.toggle('on', !!fwd); }
  if (s.backBtn) { s.backBtn.style.visibility = s.trans && !fwd ? 'visible' : 'hidden'; s.backBtn.innerHTML = back ? '縦波に戻す手順を閉じる' : '横波表示された縦波を<br>縦波に戻す'; s.backBtn.classList.toggle('on', !!back); }
  if (s.stepBar) {
    var N = m1s3NSteps(s);
    s.stepBar.style.visibility = s.stp ? 'visible' : 'hidden';
    s.stepBtns.sn.textContent = s.stp ? s.stp + ' / ' + N : '';
    s.stepBtns.bp.disabled = s.stp <= 1; s.stepBtns.bn.disabled = s.stp >= N;
    s.stepBtns.bn.classList.toggle('glow', !!s.stp && s.stp < N);   /* 「次へ」を光らせる（2026-11-04 千葉さん 6 回目） */
    s.stepBtns.bx.hidden = !!back;                              /* もどす手順は、左のボタン（手順を閉じる）で終わる */
  }
  if (s.Rdyn) s.renderRight();
}
/* 左上の丸数字の見出し（干渉シミュレーションの作法 1） */
function stepHead(ctx, text, x, y) {
  ctx.save(); ctx.font = '700 13px ' + FONT;
  var w = ctx.measureText(text).width + 22, h = 26;
  ctx.fillStyle = '#fff6dc'; ctx.strokeStyle = '#e07b18'; ctx.lineWidth = 1.6;
  rrect(ctx, x, y, w, h, 8); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#6b3a0a'; ctx.textBaseline = 'middle'; ctx.fillText(text, x + 11, y + h / 2 + 0.5);
  ctx.restore();
  return { x: x, y: y, w: w, h: h };
}
/* 同じ丸数字の吹き出し：箱は決め打ちの位置 (bx, by)、引き出し線だけを (tx, ty) へ */
function stepCallout(ctx, text, bx, by, tx, ty, maxW) {
  ctx.save(); ctx.font = '700 12px ' + FONT;
  var w = Math.min(maxW || 400, ctx.measureText(text).width + 20), h = 24;
  bx = clamp(bx, 4, CVW - w - 4); by = clamp(by, 4, CVH - h - 4);
  var cx = clamp(tx, bx + 8, bx + w - 8), cy = ty < by ? by : by + h;
  ctx.strokeStyle = '#c9670c'; ctx.lineWidth = 1.3; ctx.setLineDash([3, 3]);
  ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(tx, ty); ctx.stroke(); ctx.setLineDash([]);
  ctx.fillStyle = '#c9670c'; ctx.beginPath(); ctx.arc(tx, ty, 2.6, 0, TAU); ctx.fill();
  ctx.shadowColor = 'rgba(20,23,28,.16)'; ctx.shadowBlur = 12; ctx.shadowOffsetY = 3;
  ctx.fillStyle = '#fff6dc'; rrect(ctx, bx, by, w, h, 8); ctx.fill(); ctx.shadowColor = 'transparent';
  ctx.strokeStyle = '#e07b18'; ctx.lineWidth = 1.4; ctx.stroke();
  ctx.fillStyle = '#6b3a0a'; ctx.textBaseline = 'middle';
  var tt = text; while (ctx.measureText(tt).width > w - 18 && tt.length > 4) tt = tt.slice(0, -2) + '…';
  ctx.fillText(tt, bx + 10, by + h / 2 + 0.5);
  ctx.restore();
}
/* 横向きの細い矢印（変位）。col */
function hArrow(ctx, x1, x2, y, col, lw) {
  if (Math.abs(x2 - x1) < 2) { ctx.save(); ctx.fillStyle = col; ctx.beginPath(); ctx.arc(x1, y, 1.8, 0, TAU); ctx.fill(); ctx.restore(); return; }
  var d = x2 > x1 ? 1 : -1, hd = Math.min(7, Math.abs(x2 - x1) * 0.6);
  ctx.save(); ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = lw || 2;
  ctx.beginPath(); ctx.moveTo(x1, y); ctx.lineTo(x2 - d * hd, y); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(x2, y); ctx.lineTo(x2 - d * hd, y - 3.6); ctx.lineTo(x2 - d * hd, y + 3.6); ctx.closePath(); ctx.fill(); ctx.restore();
}
function vArrow2(ctx, x, y1, y2, col, lw) {
  if (Math.abs(y2 - y1) < 2) { ctx.save(); ctx.fillStyle = col; ctx.beginPath(); ctx.arc(x, y1, 1.8, 0, TAU); ctx.fill(); ctx.restore(); return; }
  var d = y2 > y1 ? 1 : -1, hd = Math.min(7, Math.abs(y2 - y1) * 0.6);
  ctx.save(); ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = lw || 2;
  ctx.beginPath(); ctx.moveTo(x, y1); ctx.lineTo(x, y2 - d * hd); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(x, y2); ctx.lineTo(x - 3.6, y2 - d * hd); ctx.lineTo(x + 3.6, y2 - d * hd); ctx.closePath(); ctx.fill(); ctx.restore();
}
var M1S3_BACK = ['① 縦向きの変位を横向きにもどす', '② 密・疎の位置を読む'];
var M1S3_BCALL = ['① 時計回りに 90° 回す。上向き → 右向き、下向き → 左向き', '② 矢印が向かい合う所が密、離れていく所が疎'];
/* 下の図の点（0.2 m ごと。0 は波源の所）。上の媒質の赤い点と同じ点 */
function m1s3Row() { var a = []; for (var k = 0; k <= 12; k++) a.push(k * 0.2); return a; }
function drawM1S3(s, ctx, W, H) {
  var g = m1s3Geo(W, H), q = m1s3Q(s), t = s.t, X = function (x) { return g.x0 + x * g.SX; };
  var u = function (x) { return LONG.u(q.A, q.lam, q.f, x, t); };
  var st = s.stp, fwd = st && s.smode === 'fwd' ? st : 0, back = st && s.smode === 'back' ? st : 0, MK = m1s3Marks(), ROW = m1s3Row();
  var yT = g.top, yB = g.top + g.band, yR = g.yR, SY = g.SX, AM = g.AM;
  var ps = X(u(0));                                                        /* 振動板（波源）の右の面 */
  /* 上：媒質 */
  ctx.save(); ctx.fillStyle = 'rgba(91,122,144,.06)'; ctx.fillRect(Math.min(g.x0, ps), yT, g.x1 - Math.min(g.x0, ps), g.band); ctx.restore();
  if (s.med === 'spring') {
    var n = Math.round(q.L / 0.04), ry = g.band * 0.36;
    ctx.save(); ctx.lineWidth = 1.5;
    for (var i = 0; i <= n; i++) {
      var xe = i * q.L / n, px = X(xe + u(xe));
      ctx.strokeStyle = 'rgba(58,65,76,.85)'; ctx.beginPath(); ctx.ellipse(px, g.yb, 3.2, ry, 0, Math.PI / 2, Math.PI * 1.5); ctx.stroke();
      ctx.strokeStyle = 'rgba(58,65,76,.35)'; ctx.beginPath(); ctx.ellipse(px, g.yb, 3.2, ry, 0, -Math.PI / 2, Math.PI / 2); ctx.stroke();
    }
    ctx.restore();
  } else {
    /* 空気の粒：波源の面のすぐ右から（左に寄ったときに粒のない帯ができないように。2026-11-03 千葉さん 3 回目の図 2） */
    ctx.save(); ctx.fillStyle = 'rgba(40,46,56,.78)';
    M1S3_AIR.forEach(function (p) { if (p.x < 1e-9) return; var px = X(p.x + u(p.x)); if (px > g.x1 + 2) return; ctx.beginPath(); ctx.arc(px, yT + p.y * g.band, 2.2, 0, TAU); ctx.fill(); });
    ctx.restore();
  }
  MK.forEach(function (xe) { bead(ctx, X(xe + u(xe)), g.yb, 4.4, WCOL.beadHi); });   /* 赤い点はばねの縦の中央 */
  /* 波源（振動板） */
  ctx.save(); ctx.fillStyle = '#5b6470'; rrect(ctx, ps - 9, yT - 4, 9, g.band + 8, 3); ctx.fill(); ctx.restore();
  dblHArrow(ctx, ps - 4, yT - 14, 12);
  label(ctx, '波源', ps - 4, yT - 26, { size: 11.5, color: COL.ink2, bold: true });
  arrow(ctx, g.x1 - 96, yT - 16, g.x1 - 40, yT - 16, 'vel', COL.vel);
  label(ctx, '波の進む向き', g.x1 - 102, yT - 16, { size: 11, color: COL.vel, align: 'right' });
  /* 密・疎の名札（届いている所だけ） */
  var marks = LONG.marks(q.lam, q.f, t, q.L);
  marks.forEach(function (m) {
    var px = X(m.x); if (px < g.x0 + 10 || px > g.x1 - 6) return;
    pill(ctx, m.k === 'mitsu' ? '密' : '疎', px - 13, yB + 9, { size: 11.5, bg: m.k === 'mitsu' ? '#fde2dc' : '#e3eefb', border: m.k === 'mitsu' ? '#d1352b' : '#1663b5', color: m.k === 'mitsu' ? '#9b2418' : '#123f73' });
  });
  /* ===== 下：粒の列（湯浅氏の縦波のページと同じ図）=====
     縦の線＝つりあいの位置。横の線＝つりあいの位置からの変位。横波表示：変位を反時計回りに 90° 回した点（橙）と縦の線 */
  var gl = yR - AM - 6, gb = yR + AM + 6;
  if (st) MK.forEach(function (xe) { dotted(ctx, X(xe), yB + 34, X(xe), gl, 'rgba(201,103,12,.45)', [2, 4]); });   /* 作図中は、上の赤い点と同じ点を点線で結ぶ */
  ctx.save(); ctx.strokeStyle = 'rgba(20,23,28,.22)'; ctx.lineWidth = 1;
  ROW.forEach(function (xe) { ctx.beginPath(); ctx.moveTo(X(xe), gl); ctx.lineTo(X(xe), gb); ctx.stroke(); });
  ctx.restore();
  axisArrow(ctx, g.x0 - 6, yR, g.x1 + 12, yR);
  if (s.trans) { axisArrow(ctx, g.x0 - 14, gb + 4, g.x0 - 14, gl - 6); sym(ctx, 'y', g.x0 - 3, gl - 4, { size: 13 }); }   /* y 軸は横波表示のときだけ（2026-11-05 千葉さん 7 回目） */
  sym(ctx, 'x', g.x1 + 8, yR + 13, { size: 13 });
  if (st) { /* 作図中は、この行にステップの見出し（下で描く） */ }
  else if (s.trans) {
    label(ctx, '横波表示された縦波', 12, gl - 58, { size: 12.5, bold: true, color: COL.ink, align: 'left' });
    if (W >= 520) label(ctx, '（右向きの変位を上向きに描く）', 140, gl - 58, { size: 10.5, color: COL.sub, align: 'left' });
  } else label(ctx, '粒の列（上と同じ点。縦の線がつりあいの位置）', 12, gl - 58, { size: 11.5, bold: true, color: COL.ink2, align: 'left' });
  var showDots = s.trans && !back && (!fwd || fwd >= 2);                  /* 横波表示の点 */
  var showCurve = s.trans && (!fwd || fwd >= 3);
  /* 横波表示の曲線（細い線。点をつないだもの） */
  if (showCurve) {
    ctx.save(); ctx.strokeStyle = back ? 'rgba(122,59,18,.35)' : 'rgba(122,59,18,.75)'; ctx.lineWidth = 2; ctx.beginPath();
    for (var k = 0; k <= 300; k++) { var xc = q.L * k / 300, py = yR - u(xc) * SY; if (k) ctx.lineTo(X(xc), py); else ctx.moveTo(X(xc), py); }
    ctx.stroke(); ctx.restore();
  }
  /* 横の線（変位）と縦の線（回した変位）。作図の ①・② では矢印 */
  ROW.forEach(function (xe) {
    var x0 = X(xe), x1 = X(xe + u(xe)), y1 = yR - u(xe) * SY;
    if (fwd === 1) hArrow(ctx, x0, x1, yR, '#d1352b', 2.6);
    else if (!back) { ctx.save(); ctx.strokeStyle = fwd ? 'rgba(209,53,43,.35)' : '#2b323c'; ctx.lineWidth = 3; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x0, yR); ctx.lineTo(x1, yR); ctx.stroke(); ctx.restore(); }
    if (fwd === 2) vArrow2(ctx, x0, yR, y1, '#d1352b', 2.4);
    else if (showDots) { ctx.save(); ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 2.4; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x0, yR); ctx.lineTo(x0, y1); ctx.stroke(); ctx.restore(); }
    if (back) {                                                          /* 縦波にもどす：縦の矢印（緑）→ 軸の上の横の矢印（緑） */
      vArrow2(ctx, x0, yR, y1, 'rgba(28,143,74,.55)', 2);
      hArrow(ctx, x0, x1, yR, '#1c8f4a', 2.6);
    }
  });
  /* ② の例：1 つの点で、横の矢印を 90° 回すようすを点線の弧で（もどすときは逆回り） */
  /* 例には「右に変位した点」（右向き → 上向き）を選ぶ。いちばん大きく右に変位している点（2026-11-07 千葉さん 13 回目） */
  var mkIn = MK.filter(function (xe) { var px = X(xe); return px > g.x0 + (g.x1 - g.x0) * 0.2 && px < g.x0 + (g.x1 - g.x0) * 0.75; }), xeA = mkIn.reduce(function (b, xe) { return u(xe) > u(b) ? xe : b; }, mkIn[0] || MK[4]),   /* 図のまん中あたりから選ぶ */ duA = u(xeA) * SY, cxA = X(xeA);
  if ((fwd === 2 || back === 1) && Math.abs(duA) > 6) {
    ctx.save(); ctx.strokeStyle = fwd ? '#c9670c' : '#1c8f4a'; ctx.setLineDash([3, 3]); ctx.lineWidth = 1.3;
    ctx.beginPath(); ctx.arc(cxA, yR, Math.abs(duA), duA > 0 ? 0 : Math.PI, duA > 0 ? -Math.PI / 2 : Math.PI / 2, duA > 0); ctx.stroke(); ctx.restore();
  }
  /* 粒（赤）。作図中はうすく（矢印を見やすく） */
  ROW.forEach(function (xe) {
    ctx.save(); if (fwd === 1 || fwd === 2) ctx.globalAlpha = 0.45;
    bead(ctx, X(xe + u(xe)), yR, 5.6, WCOL.beadHi); ctx.restore();
  });
  /* 横波表示の点（橙）。つりあいの位置の真上・真下 */
  if (showDots) ROW.forEach(function (xe) { var y1 = yR - u(xe) * SY; ctx.save(); ctx.fillStyle = '#f2a516'; ctx.strokeStyle = '#8a5000'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(X(xe), y1, 4.6, 0, TAU); ctx.fill(); ctx.stroke(); ctx.restore(); });
  /* 密・疎（作図 ④・もどす ②、ふつうの横波表示） */
  if (s.trans && (fwd >= 4 || back >= 2 || !st)) marks.forEach(function (m) {
    var px = X(m.x); if (px < g.x0 + 8 || px > g.x1 - 4) return;
    var mi = m.k === 'mitsu';
    if (back >= 2 || fwd >= 4) dotted(ctx, px, yB + 34, px, gb, mi ? 'rgba(209,53,43,.5)' : 'rgba(22,99,181,.5)', [3, 4]);
    ctx.save(); ctx.lineWidth = 2; ctx.strokeStyle = mi ? '#d1352b' : '#1663b5'; ctx.fillStyle = mi ? '#d1352b' : '#fff';
    ctx.beginPath(); ctx.arc(px, yR, 4.2, 0, TAU); ctx.fill(); ctx.stroke(); ctx.restore();
    label(ctx, mi ? '密' : '疎', px, gb + 13, { size: 12, bold: true, color: mi ? '#9b2418' : '#123f73' });
  });
  if (!s.trans) label(ctx, '「横波表示」を ON にすると、変位を縦向きに回した点が出る', (g.x0 + g.x1) / 2, gb + 22, { size: W < 560 ? 10.5 : 11.5, color: COL.faint });
  /* ===== いちばん下：p-x グラフ（受験物理）。p は圧力（つりあいからの変化）。p ∝ −∂u/∂x なので、密で最大・疎で最小 ===== */
  var yP = g.yP, pl = yP - AM - 6, pb = yP + AM + 6, kA = TAU / q.lam * q.A, du = function (x) { return t - x / q.v < 0 ? 0 : -kA * Math.cos(TAU * q.f * (t - x / q.v)); };   /* ∂u/∂x（u = A sin 2πf(t − x/v)） */
  label(ctx, 'p-x グラフ（受験物理）', 12, pl - 22, { size: 12.5, bold: true, color: COL.ink, align: 'left' });
  label(ctx, W >= 520 ? '（p：圧力の、つりあいからの変化。密で最大、疎で最小）' : '（密で最大、疎で最小）', W >= 520 ? 168 : 150, pl - 22, { size: 10.5, color: COL.sub, align: 'left' });
  ctx.save(); ctx.strokeStyle = 'rgba(20,23,28,.22)'; ctx.lineWidth = 1;
  ROW.forEach(function (xe) { ctx.beginPath(); ctx.moveTo(X(xe), pl); ctx.lineTo(X(xe), pb); ctx.stroke(); });
  ctx.restore();
  axisArrow(ctx, g.x0 - 6, yP, g.x1 + 12, yP); axisArrow(ctx, g.x0 - 14, pb + 4, g.x0 - 14, pl - 6);
  sym(ctx, 'p', g.x0 - 3, pl - 4, { size: 13 }); sym(ctx, 'x', g.x1 + 8, yP + 13, { size: 13 });
  ctx.save(); ctx.strokeStyle = '#6a3fa0'; ctx.lineWidth = 2.4; ctx.beginPath();
  var xf = Math.min(q.L, q.v * t);                                    /* 波の先頭（ここで p がとぶので、先頭の前と後ろは別に描く） */
  for (var kp = 0; kp <= 300; kp++) { var xp = xf * kp / 300, yy = yP + du(Math.min(xp, xf - 1e-4)) / kA * AM; if (kp) ctx.lineTo(X(xp), yy); else ctx.moveTo(X(xp), yy); }
  if (xf < q.L) { ctx.moveTo(X(xf), yP); ctx.lineTo(X(q.L), yP); }
  ctx.stroke(); ctx.restore();
  marks.forEach(function (m) {
    var px = X(m.x); if (px < g.x0 + 8 || px > g.x1 - 4) return;
    if (m.x > xf - 0.02) return;                                      /* 先頭の所の印は出さない */
    var mi = m.k === 'mitsu', yy = yP + du(m.x) / kA * AM;
    ctx.save(); ctx.lineWidth = 2; ctx.strokeStyle = mi ? '#d1352b' : '#1663b5'; ctx.fillStyle = mi ? '#d1352b' : '#fff';
    ctx.beginPath(); ctx.arc(px, yy, 4.2, 0, TAU); ctx.fill(); ctx.stroke(); ctx.restore();
    label(ctx, mi ? '密' : '疎', px, mi ? yy - 13 : yy + 13, { size: 12, bold: true, color: mi ? '#9b2418' : '#123f73' });
  });
  /* ステップの見出し（左上）と、同じ丸数字の吹き出し（決め打ちの位置：図の下） */
  var cy0 = gb + 26;
  if (fwd) {
    stepHead(ctx, M1S3_STEPS[fwd - 1], 8, gl - 72);                    /* 見出しと「前へ・次へ」は下の図のすぐ上（2026-11-05 千葉さん 7 回目） */
    var xe3 = MK[6], ut = u(xe3);
    if (fwd === 1) stepCallout(ctx, M1S3_CALL[0], X(0.9), cy0, X(xe3 + ut / 2), yR + 2, W - 40);
    if (fwd === 2) stepCallout(ctx, M1S3_CALL[1], X(0.9), cy0, X(xeA), yR - u(xeA) * SY, W - 40);
    if (fwd === 3) stepCallout(ctx, M1S3_CALL[2], X(0.9), cy0, X(1.5), yR - u(1.5) * SY, W - 40);
    if (fwd === 4) { var mm = marks.filter(function (m) { return m.k === 'mitsu' && m.x > 0.3; })[0]; if (mm) stepCallout(ctx, M1S3_CALL[3], X(0.9), cy0, X(mm.x), yR + 5, W - 40); }
  }
  if (back) {
    stepHead(ctx, M1S3_BACK[back - 1], 8, 6);
    if (back === 1) { var xb1 = MK[2]; stepCallout(ctx, M1S3_BCALL[0], X(0.9), cy0, X(xb1) + u(xb1) * SY / 2, yR, W - 40); }
    if (back === 2) { var mm2 = marks.filter(function (m) { return m.k === 'mitsu' && m.x > 0.3; })[0]; if (mm2) stepCallout(ctx, M1S3_BCALL[1], X(0.9), cy0, X(mm2.x), yR + 5, W - 40); }
  }
  /* 「縦波に戻す」ボタン：「横波表示された縦波」の下。戻す手順のステップの操作は、そのボタンの右（2026-11-03 千葉さん 3 回目） */
  var sb = s.stepBar, narrow = W < 560, want = narrow ? 'n' : '';
  want = narrow ? 'n' + Math.round(gl - 42) : 'w' + Math.round(gl - 72);
  if (sb && sb._pos !== want) { sb._pos = want; sb.style.top = Math.round(narrow ? gl - 42 : gl - 72) + 'px'; }   /* せまい画面では見出しの下 */
}
/* 小さな左右の両矢印（振動板の動き） */
function dblHArrow(ctx, x, y, hw) {
  ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.fillStyle = '#3a414c'; ctx.lineWidth = 1.4;
  ctx.beginPath(); ctx.moveTo(x - hw + 5, y); ctx.lineTo(x + hw - 5, y); ctx.stroke();
  [[x - hw, 1], [x + hw, -1]].forEach(function (p) { ctx.beginPath(); ctx.moveTo(p[0], y); ctx.lineTo(p[0] + 6 * p[1], y - 3.4); ctx.lineTo(p[0] + 6 * p[1], y + 3.4); ctx.closePath(); ctx.fill(); });
  ctx.restore();
}
function rightM1S3(s, R) {
  var q = m1s3Q(s);
  var h = foldOpen(s, '横波と縦波') +
    '<table class="reltab grid1"><tbody>' +
    '<tr><th>横波</th><td class="l">媒質の振動の向きが、波の進む向きに<b>垂直</b>（糸・ウェーブマシン・光）</td></tr>' +
    '<tr><th>縦波</th><td class="l">媒質の振動の向きが、波の進む向きと<b>同じ</b>（つるまきばね・音波）</td></tr></tbody></table>' +
    '<p>縦波は、媒質が<b>密</b>になった所と<b>疎</b>になった所が交互に並んで進む（疎密波）。</p>' +
    '<p><b>横波表示</b>：$x$ 軸の正の向き（右向き）の変位を $y$ 軸の正の向き（上向き）に、左向きの変位を下向きに描く。こうすると縦波も横波と同じように $A$・$\\lambda$ が読める。</p>' +
    '<div class="qeq">$$v = f\\lambda$$</div>' +
    '<p class="qnow"><span class="qtag now">いま</span>$f = ' + sig(q.f, 2) + '$ Hz、$\\lambda = ' + fmt(q.lam, 1) + '$ m なので　$v = f\\lambda = ' + sig(q.v, 2) + '$ m/s</p>' +
    '<p class="qnote">密・疎の位置は、変位が 0 の点。密では両側の点が近づいてくる（左の点は右向き、右の点は左向き）。疎では両側の点が離れていく。</p></div></details>';
  R.innerHTML = mathify(h); foldBind(s, R);
}
