/* ===== 50_m1.js ===== */
/* =========================================================================
   50_m1.js … 章 ① の共通部品と ①-1 波の発生と進み方と基本要素（参考①）
   ・ウェーブマシン：左端が波源（手で持つ）、右端は反射しない
   ・スライドバー：A・λ・v。f・T は「左の値で決まる」量（v = fλ、f = 1/T）
   ・波源の動かし方：[連続波｜パルス波]＋手でつかんで上下（つかんだら連続波は止まる）
   ・連続波のときは、原点（波源）の左に、波源に対応する等速円運動
   ========================================================================= */
'use strict';
var DEFS = {};
var SKIN = '#fbd7b7', SKINK = '#4a3730';
var WCOL = { wave: '#1663b5', bead: '#5b7a90', beadHi: '#d1352b', dim: '#14171c', circ: '#8d9097', src: '#2b323c' };

/* ---------- 共通の小さな部品 ---------- */
/* 2 けた（有効数字）の書き方 */
function sig(x, n) {
  if (!isFinite(x)) return '—';
  if (x === 0) return '0';
  n = n || 2;
  var e = Math.floor(Math.log(Math.abs(x)) / Math.LN10), d = Math.max(0, n - 1 - e);
  return x.toFixed(Math.min(6, d));
}
/* 10 のべき（×10ⁿ）の文字。KaTeX 用 */
function sciTex(x, n) {
  if (!isFinite(x) || x === 0) return String(x);
  var e = Math.floor(Math.log(Math.abs(x)) / Math.LN10 + 1e-12), m = x / Math.pow(10, e);
  if (Math.abs(m) >= 9.995) { m /= 10; e += 1; }
  if (e >= -2 && e <= 4) return sig(x, n || 3);
  return m.toFixed((n || 3) - 1) + '\\times 10^{' + e + '}';
}
/* 動かせない量（メーター）の行 */
function meterVar(k, label, aria, fmtFn, max) {
  return { k: k, label: label, aria: aria, min: 0, max: max || 1, step: 0.001, def: 0, meter: true, cls: 'grpW', fmt: fmtFn };
}
/* f の目盛りから、逆数の T の目盛りを作る（小さい順） */
function invStops(a) { return a.map(function (x) { return 1 / x; }).sort(function (p, q) { return p - q; }); }
/* 寸法（両矢印＋名前）。横 */
function dimH(ctx, x1, x2, y, col, name, opt) {
  opt = opt || {};
  if (Math.abs(x2 - x1) < 8) return null;
  var a = Math.min(x1, x2), b = Math.max(x1, x2);
  ctx.save(); ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = 1.3;
  ctx.beginPath(); ctx.moveTo(a + 1, y); ctx.lineTo(b - 1, y); ctx.stroke();
  [[a, 1], [b, -1]].forEach(function (q) { ctx.beginPath(); ctx.moveTo(q[0], y); ctx.lineTo(q[0] + 7 * q[1], y - 3.6); ctx.lineTo(q[0] + 7 * q[1], y + 3.6); ctx.closePath(); ctx.fill(); });
  if (opt.ticks !== false) { ctx.setLineDash([2, 3]); ctx.globalAlpha = 0.6; ctx.beginPath(); ctx.moveTo(a, y - 6); ctx.lineTo(a, opt.y2 !== undefined ? opt.y2 : y + 6); ctx.moveTo(b, y - 6); ctx.lineTo(b, opt.y2 !== undefined ? opt.y2 : y + 6); ctx.stroke(); }
  ctx.restore();
  return sym(ctx, name, (a + b) / 2, opt.below ? y + 12 : y - 11, { size: 15, color: col });
}
/* 寸法。縦（y1 → y2） */
function dimV(ctx, x, y1, y2, col, name, side) {
  if (Math.abs(y2 - y1) < 8) return null;
  var a = Math.min(y1, y2), b = Math.max(y1, y2);
  ctx.save(); ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = 1.3;
  ctx.beginPath(); ctx.moveTo(x, a + 1); ctx.lineTo(x, b - 1); ctx.stroke();
  [[a, 1], [b, -1]].forEach(function (q) { ctx.beginPath(); ctx.moveTo(x, q[0]); ctx.lineTo(x - 3.6, q[0] + 7 * q[1]); ctx.lineTo(x + 3.6, q[0] + 7 * q[1]); ctx.closePath(); ctx.fill(); });
  ctx.restore();
  return sym(ctx, name, x + (side || 1) * 11, (a + b) / 2, { size: 15, color: col });
}
/* 媒質の点（玉） */
function bead(ctx, x, y, r, col) {
  ctx.save(); var gr = ctx.createRadialGradient(x - r * .35, y - r * .4, r * .1, x, y, r);
  gr.addColorStop(0, '#ffffff'); gr.addColorStop(.35, col); gr.addColorStop(1, col);
  ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
  ctx.strokeStyle = 'rgba(20,23,28,.35)'; ctx.lineWidth = 0.8; ctx.stroke(); ctx.restore();
}
/* ウェーブマシンの持ち手（波源）を下からにぎる手。(x, y)＝持ち手の中心。hot：つかめる／つかんでいる */
function srcHand(ctx, x, y, hot, grab) {
  ctx.save(); ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  if (hot || grab) { ctx.fillStyle = grab ? 'rgba(224,123,24,.20)' : 'rgba(224,123,24,.12)'; ctx.beginPath(); ctx.arc(x, y + 12, 30, 0, TAU); ctx.fill(); }
  /* うで */
  ctx.beginPath(); ctx.moveTo(x - 2, y + 22); ctx.quadraticCurveTo(x - 10, y + 52, x - 34, y + 76);
  ctx.lineWidth = 19; ctx.strokeStyle = SKINK; ctx.stroke(); ctx.lineWidth = 15; ctx.strokeStyle = SKIN; ctx.stroke();
  /* にぎりこぶし */
  ctx.fillStyle = SKIN; ctx.strokeStyle = SKINK; ctx.lineWidth = 2;
  rrect(ctx, x - 13, y + 3, 26, 22, 8); ctx.fill(); ctx.stroke();
  ctx.lineWidth = 1.2; [9, 14, 19].forEach(function (dy) { ctx.beginPath(); ctx.moveTo(x + 3, y + 3 + dy); ctx.lineTo(x + 13, y + 3 + dy); ctx.stroke(); });
  /* 持ち手（波源）：手の上に出ている黒い玉 */
  ctx.fillStyle = WCOL.src; ctx.beginPath(); ctx.arc(x, y, 7.5, 0, TAU); ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,.55)'; ctx.beginPath(); ctx.arc(x - 2.4, y - 2.6, 2.4, 0, TAU); ctx.fill();
  /* 親指（持ち手の左から巻く） */
  ctx.beginPath(); ctx.moveTo(x - 12, y + 12); ctx.quadraticCurveTo(x - 15, y + 1, x - 6, y + 2);
  ctx.lineWidth = 9; ctx.strokeStyle = SKINK; ctx.stroke(); ctx.lineWidth = 6; ctx.strokeStyle = SKIN; ctx.stroke();
  ctx.restore();
}
/* 波源の左の等速円運動（半径 R＝A の大きさ）。th：角（反時計回り）。y が波源の高さと同じ */
function srcCircle(ctx, cx, cy, R, th, linkX, opt) {
  opt = opt || {};
  var px = cx + R * Math.cos(th), py = cy - R * Math.sin(th);
  ctx.save(); ctx.strokeStyle = WCOL.circ; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.stroke();
  ctx.strokeStyle = 'rgba(20,23,28,.45)'; ctx.lineWidth = 1.1; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(px, py); ctx.stroke();
  ctx.fillStyle = '#3a414c'; ctx.beginPath(); ctx.arc(cx, cy, 2.4, 0, TAU); ctx.fill(); ctx.restore();
  if (linkX !== undefined) dotted(ctx, px, py, linkX, py, 'rgba(22,99,181,.75)', [3, 4]);
  /* 円と原点の間に y 軸。円の点を y 軸に写した点（単振動ページ ①-1 と同じ考え。影ではなく点。2026-11-03 千葉さん 5 回目） */
  if (opt.axisX !== undefined) {
    var ax = opt.axisX;
    if (!opt.noAxis) {
    ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.fillStyle = '#3a414c'; ctx.lineWidth = 1.3;
    ctx.beginPath(); ctx.moveTo(ax, cy + R + 10); ctx.lineTo(ax, cy - R - 14); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(ax, cy - R - 20); ctx.lineTo(ax - 4, cy - R - 11); ctx.lineTo(ax + 4, cy - R - 11); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(ax - 4, cy); ctx.lineTo(ax + 4, cy); ctx.stroke(); ctx.restore();
    sym(ctx, 'y', ax + 9, cy - R - 16, { size: 13 });
    }
    /* 写した点：①-1 は黒い点、①-2 は青い〇（2026-11-05 千葉さん 7 回目） */
    ctx.save(); ctx.beginPath(); ctx.arc(ax, py, 4.6, 0, TAU);
    if (opt.ring) { ctx.fillStyle = '#fff'; ctx.fill(); ctx.strokeStyle = '#1663b5'; ctx.lineWidth = 2.2; ctx.stroke(); } else { ctx.fillStyle = '#14171c'; ctx.fill(); }
    ctx.restore();
  }
  spinArrow(ctx, cx, cy, R + 10, R + 10, -0.35, -1.15, '#3a414c', 1.5);    /* 反時計回り */
  bead(ctx, px, py, 5.2, '#1663b5');
  if (opt.label !== false) label(ctx, '等速円運動', cx, Math.min(CVH - 10, cy + R + 22), { size: 11.5, color: COL.ink2 });
  return { x: px, y: py };
}
/* 右の説明カードを折りたたむ（クリックしたときだけ開く。開いた・閉じたは節ごとに覚えておく）。2026-11-03 千葉さん 5 回目 */
function foldOpen(s, title) { return '<details class="qcard qfold"' + (s._fold ? ' open' : '') + '><summary class="qt">' + title + '<span class="qfh">クリックで' + (s._fold ? '閉じる' : '開く') + '</span></summary><div class="qfb">'; }
function foldBind(s, R) {
  var d = R.querySelector('details.qfold'); if (!d) return;
  d.addEventListener('toggle', function () { s._fold = d.open; var h = d.querySelector('.qfh'); if (h) h.textContent = 'クリックで' + (d.open ? '閉じる' : '開く'); });
}
/* 山（極大）の位置を、細かく調べて見つける（x0〜x1、xs 間隔）。値が amin 以上のものだけ */
function crestsOf(f, x0, x1, dx, amin) {
  var out = [], y0 = f(x0), y1 = f(x0 + dx);
  for (var x = x0 + dx; x < x1 - dx; x += dx) {
    var y2 = f(x + dx);
    if (y1 >= y0 && y1 > y2 && y1 >= amin) {
      var den = y0 - 2 * y1 + y2, off = den !== 0 ? 0.5 * (y0 - y2) / den : 0;   /* 放物線でなめらかに */
      out.push(x + off * dx);
    }
    y0 = y1; y1 = y2;
  }
  return out;
}

/* =====================================================================
   ①-1 波の発生と進み方と基本要素
   ===================================================================== */
function m1s1Q(s) { var v = s.v; return { A: v.A, f: v.f, v: v.v, lam: v.v / v.f, T: 1 / v.f, L: M1.s1.L }; }
function m1s1Geo(W, H) {
  var amp = clamp(Math.min(H * 0.27, W * 0.11), W < 480 ? 30 : 40, 100), SY = amp / 0.30;
  var cy = Math.round(H * 0.56), Rm = amp, cx = 14 + Rm;
  var x0 = cx + Rm + (W < 520 ? 44 : 64), x1 = W - 22;
  return { SY: SY, cy: cy, cx: cx, Rm: Rm, x0: x0, x1: x1, SX: (x1 - x0) / M1.s1.L, amp: amp };
}
/* 波源の記録を作り直す（いまのモードと値で、時刻 0 から）
   cont：連続波／pulse：山 1 つ（半周期）／one：ちょうど 1 周期だけ振動させる／hand：手で動かす */
function m1s1NewSrc(s) {
  var q = m1s1Q(s), src = SRC.make();
  if (s.srcMode === 'pulse') src.pieces.push({ k: 'pulse', t0: 0, t1: q.T / 2, A: q.A, tau: q.T / 2 });
  else if (s.srcMode === 'one') src.pieces.push({ k: 'sin', t0: 0, t1: (s.nPer || 1) * q.T, A: q.A, f: q.f, ph0: 0 });   /* 1 周期分・2 周期分（s.nPer） */
  else src.pieces.push({ k: 'sin', t0: 0, t1: Infinity, A: q.A, f: q.f, ph0: 0 });
  s.src = src;
}
/* 波源の角（連続波のとき）：y₀ = A sin θ */
function m1s1Theta(s, t) {
  var p = SRC.at(s.src, t);
  if (!p || p.k !== 'sin') return null;
  return p.ph0 + TAU * p.f * (t - p.t0);
}
function m1s1SetMode(s, m) {
  s.srcMode = m; s.grabbing = false;
  s.resetT();
  m1s1SyncBtns(s);
}
function m1s1SyncBtns(s) {
  [['cont', 'bc', 0], ['pulse', 'bp', 0], ['one', 'b1', 1], ['one', 'b2', 2]].forEach(function (p) { var b = s.extra[p[1]]; if (!b) return; var on = s.srcMode === p[0] && (!p[2] || s.nPer === p[2]); b.classList.toggle('on', on); b.setAttribute('aria-pressed', on ? 'true' : 'false'); });
  [['ph1', 'showSame'], ['ph2', 'showOpp']].forEach(function (p) { var b = s.extra[p[0]]; if (b) { b.classList.toggle('on', !!s[p[1]]); b.setAttribute('aria-pressed', s[p[1]] ? 'true' : 'false'); } });
  if (s.handTag) s.handTag.classList.toggle('on', s.srcMode === 'hand');
  if (s.phGrp) s.phGrp.style.visibility = s.srcMode === 'cont' ? 'visible' : 'hidden';   /* 同位相・逆位相は連続波のときだけ（場所はとっておく） */
}
DEFS.m1s1 = {
  id: 'm1s1', mode: 'mode1', num: 1,
  title: '波の発生と進み方と基本要素', short: '波の発生と進み方',
  desc: 'ウェーブマシンに波を発生させる。波源（左端の手）の単振動が、となりの点へ少しずつ遅れて伝わる。<span class="todo">「1 周期分振動させる」で、1 周期に波が何 m 進むか確かめよう。</span>',
  strobe: false, stepDiv: 16,
  varCols: [['A', 'f', 'v'], ['lam', 'T']],
  varColNote: { 1: '以下の 2 つは、左の値で決まる（直接は変えられない）' },
  vars: [
    { k: 'A', label: '振幅 $A$', aria: '振幅', stops: M1.s1.A, prop: true, stopLabels: ['', '0.10', '', '0.20', '', '0.30 m'], def: M1.s1.A0, fmt: function (x) { return fmt(x, 2) + ' m'; } },
    { k: 'f', label: '振動数 $f$', aria: '振動数', stops: M1.s1.f, prop: true, stopLabels: ['', '1.0', '', '2.0', '', '3.0 Hz'], def: M1.s1.f0, fmt: function (x) { return fmt(x, 1) + ' Hz'; } },
    { k: 'v', label: '速さ $v$', aria: '速さ', stops: M1.s1.v, prop: true, stopLabels: ['1', '2', '3', '4', '5', '6 m/s'], def: M1.s1.v0, fmt: function (x) { return fmt(x, 1) + ' m/s'; } },
    meterVar('lam', '波長 $\\lambda$', '波長', function (x) { return sig(x, 2) + ' m'; }, 6),
    meterVar('T', '周期 $T$', '周期', function (x) { return sig(x, 2) + ' s'; }, 2)
  ],
  disp: function (s, k) { var q = m1s1Q(s); if (k === 'lam') return q.lam; if (k === 'T') return q.T; return s.v[k]; },
  init: function (s) { if (!s.srcMode || s.srcMode === 'hand') s.srcMode = 'cont'; s.grabbing = false; m1s1NewSrc(s); },
  onReset: function (s) { if (s.srcMode === 'hand') s.srcMode = 'cont'; s.grabbing = false; m1s1NewSrc(s); m1s1SyncBtns(s); },
  onDefaults: function (s) { s.srcMode = 'cont'; s.grabbing = false; m1s1NewSrc(s); m1s1SyncBtns(s); },
  onRestart: function (s) { m1s1NewSrc(s); },
  /* f を変えた（連続波）：その時刻から波源の振動数だけ変える（すでに出た波はもとの波長のまま進む）。A・v を変えたら最初から */
  onChanged: function (s, k) {
    var q = m1s1Q(s);
    if (k === 'f' && s.srcMode === 'cont' && s.t > 0) { SRC.retune(s.src, s.t, q.A, q.f); return 'keepT'; }
    return 'stop';
  },
  buttons: [
    { k: 'bc', label: '連続波', seg: 'src', segLabel: '波源の動かし方', onClick: function (s) { m1s1SetMode(s, 'cont'); } },
    { k: 'bp', label: 'パルス波', seg: 'src', onClick: function (s) { m1s1SetMode(s, 'pulse'); } },
    /* 押すと最初から、波源をちょうど 1 周期だけ振動させる（2026-11-03 千葉さん） */
    { k: 'b1', label: '1 周期分<br>振動させる', cls: 'onep two', onClick: function (s) { m1s1Periods(s, 1); } },
    { k: 'b2', label: '2 周期分<br>振動させる', cls: 'onep two', onClick: function (s) { m1s1Periods(s, 2); } },
    /* 注目する点と同位相・逆位相の点に印（2026-11-03 千葉さん 2 回目） */
    { k: 'ph1', label: '同位相の点', cls: 'chkb', onClick: function (s) { s.showSame = !s.showSame; m1s1SyncBtns(s); s.draw(); } },
    { k: 'ph2', label: '逆位相の点', cls: 'chkb', onClick: function (s) { s.showOpp = !s.showOpp; m1s1SyncBtns(s); s.draw(); } }
  ],
  tEnd: function (s) {
    var q = m1s1Q(s);
    if (s.srcMode === 'pulse') return q.L / q.v + q.T / 2 + 0.4;
    if (s.srcMode === 'one') return q.L / q.v + (s.nPer || 1) * q.T + 0.4;
    if (s.srcMode === 'hand') return Math.max(s.t + 30, 60);
    return 16;
  },
  tInfo: function (s) { return s.srcMode === 'pulse' ? '' : periodInfo(m1s1Q(s).T); },   /* パルス波には周期がないので出さない（2026-11-07 千葉さん 13 回目） */
  gT: function (s) { return m1s1Q(s).T; },
  /* 手で動かしている間は、手の位置を記録する。手を放したあと、波が右端を出たら止める */
  beforeStep: function (s, t0, t1) {
    var q = m1s1Q(s);
    if (s.grabbing && s.grabP) {
      var p = s.grabP, ys = p.ys, last = ys[ys.length - 1], tl = p.t0 + (ys.length - 1) * p.dt, n = Math.floor((t1 - tl) / p.dt + 1e-9);
      for (var i = 1; i <= n; i++) SRC.push(p, last + (s.handY - last) * i / n);
    } else if (s.srcMode === 'hand' && t1 > SRC.lastActive(s.src) + q.L / q.v + 0.3) { s.playing = false; }
  },
  height: function (s, w) { return Math.round(clamp(w * 0.6, 320, 420)); },
  afterBuild: function (s) {
    s.R.innerHTML = ''; var sw = el('div', 'row2 sliders inR'); sw.appendChild(s.varbox); s.R.appendChild(sw); s.varbox.classList.add('inR');
    s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);
    /* 説明カード（ふだんは閉じている）の下に、1 周期分の波の進み方の図（教科書の図と同じ。2026-11-03 千葉さん 5 回目） */
    s.perFig = periodFig(s.R, 'trans'); setTimeout(function () { s.perFig.H = Math.round(s.H || 400); s.perFig.draw(); }, 60);
    /* 「1 周期分振動させる」は 連続波｜パルス波 のとなり。「手で動かしている」の表示はその右（場所は最初からとる） */
    var seg = s.row1b.querySelector('.seg');
    if (seg) { seg.insertAdjacentElement('afterend', s.extra.b1); s.extra.b1.insertAdjacentElement('afterend', s.extra.b2); }
    /* 「手で動かしている」は図の左上に重ねる（ボタンの列の場所をとらない。2026-11-03 千葉さん 3 回目：同位相・逆位相を同じ列に） */
    s.handTag = el('span', 'handtag oncv', '✋ 手で動かしている'); s.cv.parentNode.appendChild(s.handTag);
    /* 同位相・逆位相は、せまい画面でも必ず同じ列（2 つをひとまとめにして折り返さない） */
    var pg = el('span', 'phgrp'); s.extra.ph1.insertAdjacentElement('beforebegin', pg); pg.appendChild(s.extra.ph1); pg.appendChild(s.extra.ph2); s.phGrp = pg;
    m1s1SyncBtns(s);
    m1s1BindHand(s);
  },
  draw: function (s, ctx, W, H) { drawM1S1(s, ctx, W, H); },
  right: function (s, R) { rightM1S1(s, R); }
};
/* 手（波源）をつかんで上下に動かす。当たり判定は手と波源の点だけ */
function m1s1HandPos(s) { var g = m1s1Geo(s.W, s.H); return { x: g.x0, y: g.cy - SRC.hand(s.src, s.t) * g.SY, g: g }; }
function m1s1HitHand(s, x, y) { var h = m1s1HandPos(s); return Math.hypot(x - h.x, y - h.y) < 15 || (x > h.x - 16 && x < h.x + 16 && y > h.y && y < h.y + 30); }
function m1s1BindHand(s) {
  var cv = s.cv, drag = null;
  var pos = function (ev) { var r = cv.getBoundingClientRect(); return { x: ev.clientX - r.left, y: ev.clientY - r.top }; };
  cv.addEventListener('pointerdown', function (ev) {
    var p = pos(ev); if (!m1s1HitHand(s, p.x, p.y)) return;
    ev.stopImmediatePropagation(); ev.preventDefault(); cv.setPointerCapture(ev.pointerId);
    var h = m1s1HandPos(s), yh = SRC.hand(s.src, s.t);
    drag = { off: yh - (h.g.cy - p.y) / h.g.SY };
    s.srcMode = 'hand'; s.grabbing = true; s.handY = yh; s.ended = false;
    s.grabP = SRC.grab(s.src, s.t, 1 / 120);
    m1s1SyncBtns(s);
    if (!s.playing) { SIMS.forEach(function (o) { if (o.playing) { o.playing = false; o.syncPlayLabel(); } }); s.playing = true; s.syncPlayLabel(); startLoop(); }
    s.draw(); s.renderRight();
  }, true);
  cv.addEventListener('pointermove', function (ev) {
    var p = pos(ev);
    if (!drag) { if (m1s1HitHand(s, p.x, p.y)) { cv.style.cursor = 'grab'; s._hot = true; } else if (s._hot) { s._hot = false; cv.style.cursor = 'default'; } return; }
    var g = m1s1Geo(s.W, s.H);
    s.handY = clamp((g.cy - p.y) / g.SY + drag.off, -0.32, 0.32); cv.style.cursor = 'grabbing';
    ev.stopImmediatePropagation();
  }, true);
  var end = function (ev) {
    if (!drag) return; drag = null; ev.stopImmediatePropagation();
    s.grabbing = false; s.grabP = null; SRC.release(s.src, s.t);
    cv.style.cursor = 'grab'; s.draw();
  };
  cv.addEventListener('pointerup', end, true);
  cv.addEventListener('pointercancel', end, true);
  /* スマホ：手の上で指を動かしたときは、ページをスクロールさせない（手の外ならふつうにスクロール） */
  cv.addEventListener('touchstart', function (ev) {
    var r = cv.getBoundingClientRect(), t0 = ev.touches[0];
    if (t0 && m1s1HitHand(s, t0.clientX - r.left, t0.clientY - r.top)) ev.preventDefault();
  }, { passive: false });
  /* 手で動かしたあと ▶ スタートを押したら、その時刻から連続波にもどる */
  var tp = s.togglePlay;
  s.togglePlay = function () {
    if (s.srcMode === 'hand' && !s.playing) { var q = m1s1Q(s); s.srcMode = 'cont'; SRC.startSin(s.src, s.t, q.A, q.f); m1s1SyncBtns(s); s.renderRight(); }
    var r = tp.apply(s, arguments); s.draw(); return r;       /* 一時停止したら、A・λ・向きを出すために描き直す */
  };
}
/* 分数（canvas）：num／den を、横線をはさんで上下に。(x, y)＝横線の左はし。戻り値は幅 */
function fracText(ctx, num, den, x, y, size, col) {
  var wn = mathStr(ctx, num, 0, 0, size, col, true), wd = mathStr(ctx, den, 0, 0, size, col, true), w = Math.max(wn, wd) + 8;
  ctx.save(); ctx.textBaseline = 'alphabetic'; mathStr(ctx, num, x + (w - wn) / 2, y - 4, size, col);
  mathStr(ctx, den, x + (w - wd) / 2, y + 3 + size * 0.8, size, col);
  ctx.strokeStyle = col; ctx.lineWidth = 1.3; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + w, y); ctx.stroke(); ctx.restore();
  return w;
}
/* 数式の文字列：数字はたて書体（KaTeX_Main）、文字は斜体（KaTeX_Math）。(x, y)＝文字の基準線。measure なら幅だけ返す */
function mathStr(ctx, str, x, y, size, col, measure) {
  ctx.save(); ctx.fillStyle = col; ctx.textBaseline = 'alphabetic'; ctx.textAlign = 'left';
  var X = x;
  for (var i = 0; i < str.length; i++) {
    var c = str.charAt(i), dig = /[0-9.=+−]/.test(c);
    ctx.font = (dig ? '' : 'italic ') + size + 'px ' + (dig ? SER : MATH);
    if (!measure) ctx.fillText(c, X, y);
    X += ctx.measureText(c).width + (dig ? 0.5 : 0);
  }
  ctx.restore();
  return X - x;
}
/* 「1T（周期）で 1λ（波長）進んだので v = 1λ/1T = λ/T」（図の右上。1 周期分振動させたとき） */
function m1s1OneNote(ctx, W, n) {
  n = n || 1;
  var y0 = 8, col = '#14171c';
  ctx.save(); ctx.font = '700 13px ' + FONT;
  var t1 = n === 1 ? '1T（周期）で 1λ（波長）進んだので' : n + 'T（' + n + ' 周期）で ' + n + 'λ（' + n + ' 波長）進んだので', w1 = ctx.measureText(t1).width;
  ctx.restore();
  var bw = Math.max(w1, 150) + 24, bx = W - 12 - bw, bh = 70;   /* 図の右上（千葉さん指定）。波はその下を通るように図を高くしてある */
  ctx.save(); ctx.fillStyle = '#fff6dc'; ctx.strokeStyle = '#e07b18'; ctx.lineWidth = 1.5; rrect(ctx, bx, y0, bw, bh, 10); ctx.fill(); ctx.stroke(); ctx.restore();
  label(ctx, t1, bx + 12, y0 + 15, { size: 13, bold: true, color: '#6b3a0a', align: 'left', halo: false, clamp: false });
  /* v = 1λ / 1T = λ / T */
  var yl = y0 + 47, x = bx + 16;
  ctx.save(); ctx.font = 'italic 18px ' + MATH; ctx.fillStyle = col; ctx.textBaseline = 'middle'; ctx.fillText('v', x, yl); x += ctx.measureText('v').width + 6;
  ctx.font = '18px ' + SER; ctx.fillText('=', x, yl); x += ctx.measureText('=').width + 6; ctx.restore();
  x += fracText(ctx, n + 'λ', n + 'T', x, yl, 16, col) + 6;
  ctx.save(); ctx.font = '18px ' + SER; ctx.fillStyle = col; ctx.textBaseline = 'middle'; ctx.fillText('=', x, yl); x += ctx.measureText('=').width + 6; ctx.restore();
  fracText(ctx, 'λ', 'T', x, yl, 16, col);
}
/* 1 周期分・2 周期分振動させる：最初から、波源を n 周期だけ振動させ、nT たった瞬間に一時停止（2026-11-03 千葉さん） */
function m1s1Periods(s, n) {
  s.nPer = n; m1s1SetMode(s, 'one');
  s.stopAt = n * m1s1Q(s).T; s.stopCb = null; s.inWindow = true;   /* Sim の「決めた時刻で止める」しくみ。▶ スタート・リセットで解除 */
  s.togglePlay();
}
/* 同位相・逆位相の点の印（注目する点 xr が基準） */
function m1s1PhaseMarks(s, ctx, g, q, yAt, xr, X, Yv) {
  var front = Math.min(q.L, q.v * s.t);
  if (xr > front) return;
  var mark = function (x, col, txt) {
    if (x < 0.05 || x > front || x > q.L - 0.05) return;
    var px = X(x), py = Yv(yAt(x));
    ctx.save(); ctx.strokeStyle = col; ctx.lineWidth = 2.4; ctx.beginPath(); ctx.arc(px, py, 9, 0, TAU); ctx.stroke(); ctx.restore();
    label(ctx, txt, px, Yv(0.32) - 12, { size: 11, bold: true, color: col });
    dotted(ctx, px, Yv(0.32) - 4, px, Yv(-0.32), col, [2, 3]);
  };
  for (var n = -6; n <= 6; n++) {
    if (s.showSame && n !== 0) mark(xr + n * q.lam, '#1c8f4a', '同位相');
    if (s.showOpp) mark(xr + (n + 0.5) * q.lam, '#7a4fb8', '逆位相');
  }
  label(ctx, '基準', X(xr), Yv(0.32) - 12, { size: 11, bold: true, color: '#9b2418' });
}
function drawM1S1(s, ctx, W, H) {
  var g = m1s1Geo(W, H), q = m1s1Q(s), t = s.t, src = s.src;
  var X = function (x) { return g.x0 + x * g.SX; }, Yv = function (y) { return g.cy - y * g.SY; };
  var yAt = function (x) { return waveY(src, q.v, x, t); };
  var paused = !s.playing && t > 0;                      /* A・λ・山の進む向きは一時停止しているときだけ（2026-11-03 千葉さん） */
  /* つりあいの位置の線（媒質の軸） */
  dotted(ctx, g.x0, g.cy, g.x1 + 8, g.cy, 'rgba(20,23,28,.28)', [5, 4]);
  /* 右端：反射しない（波を吸収する） */
  ctx.save(); var gr = ctx.createLinearGradient(g.x1 - 30, 0, g.x1 + 14, 0); gr.addColorStop(0, 'rgba(91,122,144,0)'); gr.addColorStop(1, 'rgba(91,122,144,.22)');
  ctx.fillStyle = gr; ctx.fillRect(g.x1 - 30, g.cy - g.amp - 18, 44, 2 * g.amp + 36); ctx.restore();
  /* 媒質の点（0.2 m ごと）。点どうしを線で結ばない（ウェーブマシンらしく。2026-11-05 千葉さん 7 回目） */
  var dxB = g.SX < 34 ? 0.4 : 0.2, nB = Math.round(q.L / dxB), kHi = Math.round(3.0 / dxB);   /* 注目する点：x = 3.0 m（せまい画面では点を 0.4 m ごとに） */
  var xHi = X(kHi * dxB);
  if (s.srcMode !== 'one') { ctx.save(); ctx.strokeStyle = 'rgba(209,53,43,.45)'; ctx.setLineDash([2, 3]); ctx.beginPath(); ctx.moveTo(xHi, Yv(0.32)); ctx.lineTo(xHi, Yv(-0.32)); ctx.stroke(); ctx.restore(); }
  var hiOn = s.srcMode !== 'one';                                 /* 1・2 周期分振動させるときは、注目する点を出さない */
  for (var k = 1; k <= nB; k++) { var xb = k * dxB, hk = hiOn && k === kHi; bead(ctx, X(xb), Yv(yAt(xb)), hk ? 5.4 : 4.2, hk ? WCOL.beadHi : WCOL.bead); }
  if (hiOn) label(ctx, '注目する点', xHi, Yv(-0.32) + 12, { size: 11, color: '#9b2418' });
  /* 同位相の点（注目する点から λ の整数倍）・逆位相の点（λ/2 の奇数倍）。波が届いている所だけ */
  if (hiOn && s.srcMode === 'cont' && (s.showSame || s.showOpp)) m1s1PhaseMarks(s, ctx, g, q, yAt, kHi * dxB, X, Yv);   /* 連続波のときだけ */
  /* 一時停止中だけ：A・λ・山（波）の進む向き */
  var front = q.v * t, yTop = g.cy - g.amp - 26;
  var vArrow = function (xm, txt) {
    var px0 = X(xm);
    if (px0 < g.x0 + 4 || px0 > g.x1 - 40) return;
    arrow(ctx, px0, yTop, px0 + 44, yTop, 'vel', COL.vel, { lw: 2.4 });
    sym(ctx, 'v', px0 + 54, yTop, { size: 15, color: COL.vel, align: 'left' });
    label(ctx, txt, px0 - 6, yTop, { size: 11, color: COL.vel, align: 'right' });
  };
  if (paused && s.srcMode === 'cont') {
    var xe = Math.min(q.L, front) - 0.02;
    var crs = crestsOf(yAt, 0.02, xe, 0.005, q.A * 0.9), trs = crestsOf(function (x) { return -yAt(x); }, 0.02, xe, 0.005, q.A * 0.9);
    var useT = crs.length < 2 && trs.length >= 2, P2 = useT ? trs : crs;          /* 山が 2 つないときは谷と谷で λ */
    if (P2.length >= 2) {
      var c1 = P2[P2.length - 2], c2 = P2[P2.length - 1];
      if (front >= q.L && P2.length >= 3) { c1 = P2[Math.floor(P2.length / 2) - 1]; c2 = P2[Math.floor(P2.length / 2)]; }
      if (useT) dimH(ctx, X(c1), X(c2), Yv(-q.A) + 16, '#c9670c', 'λ', { y2: Yv(-q.A) + 6 });
      else dimH(ctx, X(c1), X(c2), Yv(q.A) - 16, '#c9670c', 'λ', { y2: Yv(q.A) - 6 });
    }
    if (crs.length) { var ca = crs[0]; dimV(ctx, X(ca), g.cy, Yv(yAt(ca)), '#1c8f4a', 'A', -1); vArrow(crs[crs.length - 1] + 0.05, '山の進む向き'); }   /* 山の真下から山の頂点まで */
    else if (front < q.L) vArrow(front, '波の先頭');
  } else if (paused && s.srcMode === 'pulse') {
    var pc = q.v * (t - q.T / 4);
    if (pc > 0 && pc < q.L) vArrow(pc + 0.15, '山の進む向き');
  }
  /* 1 周期分振動させたとき：1 周期のあいだに進んだ長さ（＝1 波長）と、右上の説明 */
  var nP = s.nPer || 1;
  if (s.srcMode === 'one' && t >= nP * q.T - 1e-9) {
    var xb0 = Math.max(0, q.v * (t - nP * q.T)), xb1 = Math.min(q.L, q.v * t);
    if (paused && xb1 > xb0) { dimH(ctx, X(xb0), X(xb1), Yv(q.A) - 16, '#c9670c', nP === 1 ? 'λ' : '2λ', { y2: g.cy }); vArrow(xb1, '山の進む向き'); }
    m1s1OneNote(ctx, W, nP);
  }
  /* 左：波源に対応する等速円運動（連続波・1 周期分のとき） */
  var th = (s.srcMode === 'cont' || s.srcMode === 'one') ? m1s1Theta(s, t) : null, hp = m1s1HandPos(s);
  var axX = Math.round(g.cx + g.Rm + (g.x0 - g.cx - g.Rm) * 0.42);
  if (th !== null) srcCircle(ctx, g.cx, g.cy, q.A * g.SY, th, g.x0, { axisX: axX });
  else if (s.srcMode === 'cont' || s.srcMode === 'one') srcCircle(ctx, g.cx, g.cy, q.A * g.SY, 0, g.x0, { axisX: axX });
  /* 波源と手 */
  srcHand(ctx, hp.x, hp.y, s._hot, s.grabbing);
  label(ctx, '波源', hp.x - 44, Math.min(H - 12, g.cy + 92), { size: 12, color: COL.ink2, bold: true });
  if (s.srcMode === 'pulse' && !s.playing && t === 0) bubble(ctx, '手をつかんで上下に動かせる', hp.x + 14, hp.y - 12, { size: 12 });
  (function () {                                                         /* 左上に大きく「y-x グラフ」（y・x は斜体。2026-11-07 千葉さん 15 回目） */
    var fs = W < 520 ? 17 : 21, x = 14, y = 24; ctx.save(); ctx.fillStyle = COL.ink; ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
    [['y', 'italic 600 ' + (fs + 1) + 'px "Times New Roman", serif'], ['-', '700 ' + fs + 'px ' + FONT], ['x', 'italic 600 ' + (fs + 1) + 'px "Times New Roman", serif'], [' グラフ', '800 ' + fs + 'px ' + FONT]].forEach(function (p) { ctx.font = p[1]; ctx.fillText(p[0], x, y); x += ctx.measureText(p[0]).width + (p[0] === '-' ? 1 : 0.5); });
    ctx.restore();
  })();
}
function rightM1S1(s, R) {
  var q = m1s1Q(s), h = foldOpen(s, '波の基本要素') +
    '<table class="reltab grid1"><tbody>' +
    '<tr><th>振幅 $A$〔m〕</th><td class="l">振動の中心から山の高さ（谷の深さ）まで</td></tr>' +
    '<tr><th>波長 $\\lambda$〔m〕</th><td class="l">山から次の山まで（1 つの波の長さ）</td></tr>' +
    '<tr><th>周期 $T$〔s〕</th><td class="l">媒質の点が 1 回振動する時間</td></tr>' +
    '<tr><th>振動数 $f$〔Hz〕</th><td class="l">1 秒間に振動する回数　$f = \\dfrac{1}{T}$</td></tr>' +
    '<tr><th>速さ $v$〔m/s〕</th><td class="l">波の形が進む速さ</td></tr></tbody></table>' +
    '<p>図の赤い<b>注目する点</b>は、その場で上下に振動するだけで、波といっしょに右へは進まない。進んでいくのは振動の状態（波の形）である。</p>' +
    '<p>波源が 1 回振動する間（周期 $T$）に、波は 1 波長 $\\lambda$ 進む。だから</p>' +
    '<div class="qeq">$$v = \\frac{\\lambda}{T} = f\\lambda$$</div>' +
    '<p class="qnow"><span class="qtag now">いま</span>$f = ' + fmt(q.f, 1) + '$ Hz、$v = ' + fmt(q.v, 1) + '$ m/s なので<br>$\\lambda = \\dfrac{v}{f} = \\dfrac{' + fmt(q.v, 1) + '}{' + fmt(q.f, 1) + '} = ' + sig(q.lam, 2) + '$ m、$T = \\dfrac{1}{f} = ' + sig(q.T, 2) + '$ s</p>';
  if (s.srcMode === 'pulse') h += '<p class="qnote">パルス波：山 1 つだけの波（ここでは連続波の半周期ぶん、幅 $\\dfrac{\\lambda}{2}$）。進む速さは連続波と同じ $v$。</p>';
  else if (s.srcMode === 'one') h += '<p class="qnote">' + (s.nPer === 2 ? '2 周期分振動させると、ちょうど 2 波長 $2\\lambda$ の波ができる（$2T$ 秒で $2\\lambda$ 進む）。' : '1 周期分だけ振動させると、ちょうど 1 波長 $\\lambda$ の波ができる。波源が振動している $T$ 秒の間に、波の先頭は $\\lambda$ 進んでいる。') + '</p>';
  if (s.srcMode === 'cont' && (s.showSame || s.showOpp)) h += '<p class="qnote"><b>同位相</b>：いつも同じ振動のようすの点（注目する点から $\\lambda$ の整数倍はなれた点）。<b>逆位相</b>：いつも逆の振動のようすの点（$\\dfrac{\\lambda}{2}$ の奇数倍はなれた点）。</p>';
  else if (s.srcMode === 'hand') h += '<p class="qnote">手で動かした形が、速さ $v$ で右へ進む。速さ $v$ は波源の動かし方では変わらない（媒質で決まる）。手をずらしたまま止めても、ずれが伝わったあとは、各点はつりあいの位置に戻る。</p>';
  else h += '<p class="qnote">$f$ を変えると、$v$ は同じなので $\\lambda$ が変わる。すでに出ていた波は、もとの波長のまま進む。</p>';
  h += '</div></details>';
  R.innerHTML = mathify(h); foldBind(s, R);
}
