/* ===== 70_m3.js ===== */
/* =========================================================================
   章 ③ 音波（物理基礎の範囲）
   ③-1 音の三要素／③-2 うなり／③-3 弦と気柱の固有振動と共鳴
   ★ 音と図は同じ値から作る：波形は「倍音の番号と大きさの表」(partials) を 1 つ持ち、
     図・オシロスコープは Σ aₙ sin(2π n f t)、音は AUDIO.play に同じ表を渡す
   ========================================================================= */
'use strict';
/* ---------- 音色（倍音の表）---------- */
/* 声：声帯の音（倍音ほど小さい）に、口の形で決まる共鳴（フォルマント）をかける。フォルマントは日本語の母音のおよその値 */
var M3_FORMANT = { a: [[800, 120], [1200, 150], [2500, 200]], i: [[300, 80], [2300, 160], [3000, 200]], u: [[320, 80], [1300, 150], [2400, 200]] };
function m3Voice(vow, f0) {
  var F = M3_FORMANT[vow], out = [];
  for (var n = 1; n * f0 <= 5000 && n <= 40; n++) {
    var fr = n * f0, g = 0;
    F.forEach(function (p, i) { g += [1, 0.7, 0.35][i] / (1 + Math.pow((fr - p[0]) / p[1], 2)); });
    out.push([n, g / n]);
  }
  return out;
}
var M3_INST = {
  fork: [[1, 1]],
  flute: [[1, 1], [2, 0.45], [3, 0.2], [4, 0.08], [5, 0.04]],
  clarinet: [[1, 1], [3, 0.75], [5, 0.5], [7, 0.32], [9, 0.2], [11, 0.12], [13, 0.06]],         /* 奇数倍の音が強い */
  violin: (function () { var a = []; for (var n = 1; n <= 14; n++) a.push([n, (1 / n) * (1 + 0.8 * Math.exp(-Math.pow(n - 4, 2) / 5))]); return a; })()
};
var M3_SRC = [['fork', 'おんさ'], ['voice', '声'], ['inst', '楽器']];
var M3_VOW = [['a', 'あ'], ['i', 'い'], ['u', 'う']];
var M3_INS = [['flute', 'フルート'], ['clarinet', 'クラリネット'], ['violin', 'バイオリン']];
function m3Parts(s, f) {
  if (s.src === 'fork') return M3_INST.fork;
  if (s.src === 'voice') return m3Voice(s.vow, f);
  return M3_INST[s.ins];
}
/* 波形：倍音の表から。いちばん大きい所が 1 になるようにそろえる（ピークはキャッシュ） */
var _m3pk = {};
function m3Wave(parts) {
  var key = parts.map(function (p) { return p[0] + ':' + p[1].toFixed(5); }).join('|'), pk = _m3pk[key];
  var raw = function (ph) { var y = 0; for (var i = 0; i < parts.length; i++) y += parts[i][1] * Math.sin(TAU * parts[i][0] * ph); return y; };
  if (!pk) { pk = 0; for (var i = 0; i < 2000; i++) pk = Math.max(pk, Math.abs(raw(i / 2000))); _m3pk[key] = pk; }
  return { f: function (ph) { return raw(ph) / pk; }, nMax: parts[parts.length - 1][0] };
}
/* 音のボタン（各節で共通）：鳴らす／止める。鳴らせないときは理由 */
function m3SpkBtn(s, host, getVoices) {
  var b = el('button', 'b spk m3spk', '🔊 音を鳴らす'); b.type = 'button';
  var msg = el('span', 'spkmsg', '人の耳には聞こえません（およそ 20〜20000 Hz）');
  b.addEventListener('click', function () {
    if (AUDIO.owner() === s.def.id) { AUDIO.stop(); s._resume = null; return; }
    m3Sound(s, getVoices);
  });
  host.appendChild(b); host.appendChild(msg);
  s.spk = b; s.spkMsg = msg;
  var sync = function () { var on = AUDIO.owner() === s.def.id || !!s._resume; b.textContent = on ? '■ 音を止める' : '🔊 音を鳴らす'; b.classList.toggle('on', on); b.classList.toggle('glow', !on); };   /* 鳴っていないときは光らせる（16 回目） */
  AUDIO.onChange(sync); sync(); s._spkSync = sync;
  s.resound = function () { if (AUDIO.owner() === s.def.id && s._sndGet) { var g = s._sndGet(); AUDIO.play(s.def.id, g.voices, g.vol); } };
  /* 一時停止したら音も止め、▶ で再開したら音も鳴らし直す（2026-11-05 千葉さん 7 回目） */
  var orig = s.syncPlayLabel;
  s.syncPlayLabel = function () {
    var r = orig.apply(s, arguments);
    if (!s.playing && AUDIO.owner() === s.def.id) { s._resume = s._sndGet; AUDIO.stop(); }
    else if (s.playing && s._resume) { var g = s._resume(); s._resume = null; AUDIO.play(s.def.id, g.voices, g.vol); }
    if (s._spkSync) s._spkSync();
    return r;
  };
}
/* 音を鳴らす（止まっていれば、アニメもいっしょに動かす） */
function m3Sound(s, getVoices) {
  s._sndGet = getVoices; s._resume = null;
  var g = getVoices(); AUDIO.play(s.def.id, g.voices, g.vol);
  if (!s.playing) s.togglePlay();
}
/* 章 ③ の操作の行：時間のバーを隠し、その場所に 🔊（2026-11-05 千葉さん 7 回目）。show＝時間のバーを出すか */
function m3TimeBar(s, show) {
  var tr = s.L.querySelector('.playbar .trow'); if (!tr) return;
  tr.style.display = show ? '' : 'none';
  if (s.spkRow && s.spkRow.parentNode !== tr.parentNode) tr.insertAdjacentElement('afterend', s.spkRow);
}
/* 章 ③ は、一時停止を押すまでずっと動く（2026-11-05 千葉さん 8 回目）。オシロスコープは最初から映す（音はもうマイクに届いているとする） */
var M3_TEND = 1e6;
/* スペクトルの線（倍音）。mult：声・楽器では、線の上に「基音の何倍か」（×2 …）を書く。s._spSel：クリックで選んだ線（振動数を表示） */
function m3SpecBars(c2, s, parts, f1, A, XF, fy0, fy1, FM, mult) {
  var mx = 0; parts.forEach(function (p) { mx = Math.max(mx, Math.abs(p[1])); });
  var gap = XF(f1) - XF(0), hits = [];
  c2.save(); c2.font = '700 9.5px ' + FONT; c2.textAlign = 'center'; c2.textBaseline = 'bottom';
  parts.forEach(function (p) {
    var f = p[0] * f1; if (f > FM) return;
    var h = Math.abs(p[1]) / mx * (fy1 - fy0 - 12) * A, x = XF(f), sel = s._spSel === p[0];
    c2.fillStyle = sel ? '#ffd678' : '#7dffb4'; c2.shadowColor = c2.fillStyle; c2.shadowBlur = 6; c2.fillRect(x - 2, fy1 - h, 4, h); c2.shadowBlur = 0;
    hits.push({ x: x, y: fy1 - h, n: p[0], f: f });
    var big = Math.abs(p[1]) / mx > 0.3;
    if (mult && (gap >= 17 || big || p[0] === 1)) { c2.fillStyle = 'rgba(255,214,120,.9)'; c2.fillText(p[0] === 1 ? '基音' : '×' + p[0], x, fy1 - h - 2); }
  });
  var hs = hits.filter(function (o) { return o.n === s._spSel; })[0];
  if (hs) {
    var t = 'f = ' + Math.round(hs.f) + ' Hz' + (hs.n === 1 ? '（基音）' : '（基音の ' + hs.n + ' 倍）'), W = c2.canvas.clientWidth || 300;
    c2.font = '700 11px ' + FONT; var w = c2.measureText(t).width + 12, bx = clamp(hs.x - w / 2, 4, W - w - 4), by = fy0 - 4;
    c2.fillStyle = '#ffd678'; rrect(c2, bx, by - 14, w, 18, 5); c2.fill(); c2.fillStyle = '#2a2006'; c2.textAlign = 'left'; c2.textBaseline = 'middle'; c2.fillText(t, bx + 6, by - 5);
  }
  c2.restore();
  s._spHits = hits;
}
/* スペクトルの線に近づくと指の形、クリックでその振動数を表示（もう一度クリックで消す） */
function m3SpecPick(s, cv, redraw) {
  var near = function (ev) {
    var r = cv.getBoundingClientRect(), x = ev.clientX - r.left, best = null, bd = 12;
    (s._spHits || []).forEach(function (o) { var d = Math.abs(o.x - x); if (d < bd) { bd = d; best = o; } });
    return best;
  };
  cv.addEventListener('pointermove', function (ev) { cv.style.cursor = near(ev) ? 'pointer' : 'default'; });
  cv.addEventListener('click', function (ev) { var o = near(ev); s._spSel = o && s._spSel !== o.n ? o.n : null; redraw(); });
}
/* おんさの絵：(x, y)＝ U 字の底。d：枝の開き〔px〕（振動のようす）。h：枝の長さ */
function forkShape(ctx, x, y, h, d, col) {
  ctx.save(); ctx.strokeStyle = col || '#7d8794'; ctx.lineCap = 'round'; ctx.lineWidth = 6;
  ctx.beginPath(); ctx.moveTo(x - 11 - d, y - h); ctx.lineTo(x - 11, y - 6); ctx.quadraticCurveTo(x - 11, y + 6, x, y + 6); ctx.quadraticCurveTo(x + 11, y + 6, x + 11, y - 6); ctx.lineTo(x + 11 + d, y - h); ctx.stroke();
  ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(x, y + 6); ctx.lineTo(x, y + 36); ctx.stroke();
  ctx.fillStyle = '#6b4a2a'; rrect(ctx, x - 26, y + 34, 52, 12, 3); ctx.fill();                 /* 共鳴箱の上の台 */
  ctx.restore();
}
/* 見出しの札とボタンの組を、折り返しで離れないようにまとめる */
function lblSeg(lbl, seg) { if (!lbl || !seg) return; var g = el('span', 'lsgrp'); lbl.insertAdjacentElement('beforebegin', g); g.appendChild(lbl); g.appendChild(seg); return g; }
/* マイク（右向きの音を受ける） */
function micShape(ctx, x, y) {
  ctx.save(); ctx.fillStyle = '#3a414c'; rrect(ctx, x - 6, y - 16, 16, 30, 8); ctx.fill();
  ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(x + 2, y + 14); ctx.lineTo(x + 2, y + 40); ctx.stroke();
  ctx.fillRect(x - 10, y + 40, 24, 4); ctx.restore();
}

/* =====================================================================
   ③-1 音の三要素
   ===================================================================== */
var M3S1_F = [131, 165, 196, 220, 262, 330, 392, 440, 523, 659, 784, 880];
var M3S1_K = 400;                                   /* 図の空気の振動は実際の 1/400 の速さ */
/* 「本当の速さ」（2026-11-06 千葉さん 12 回目）：押すと、図の振動を画面で描ける速さの近くまで速くする。
   画面は 1 秒に 60 コマなので、1 秒に 10 回ほどが限界（それより速いと逆向きに動いて見える）。実際は 1 秒に数百回 */
var M3_REALF = 10;
function m3K(s, f) { return s.real ? Math.max(1, f / M3_REALF) : M3S1_K; }          /* ③-1：実際の何分の 1 の速さで描くか */
function m3FS(s, slow) { return s.real ? slow * M3_REALF / 0.7 * 0.8 : slow; }      /* ③-3〜③-5：図の振動数（ふだん 0.5〜0.7 Hz → 本当の速さで約 6〜8 Hz） */
var M3S1_L = 4;                                     /* 図の空気の横幅〔m〕（縮尺は変えない：λ の長さが比べられる） */
function m3s1Q(s) { var f = s.v.f, V = WAVE.V(s.v.tc); return { A: s.v.A, f: f, T: 1 / f, V: V, lam: V / f }; }
DEFS.m3s1 = {
  id: 'm3s1', mode: 'mode3', num: 1,
  title: '音の三要素', short: '音の三要素',
  desc: '音の<b>高さ</b>・<b>大きさ</b>・<b>音色</b>（音の三要素）は、振動数・振幅・波形で決まる。<span class="todo">音源や $f$・$A$ を変えて、オシロスコープの波形と音を比べよう。</span>',
  strobe: false, stepDiv: 16,
  varCols: [['f', 'A', 'tc'], ['T', 'V', 'lam']],
  varColNote: { 1: '以下の 3 つは、左の値で決まる（直接は変えられない）' },
  vars: [
    { k: 'f', label: '振動数 $f$（音の高さ）', aria: '振動数', stops: M3S1_F, prop: true, stopLabels: ['131', '', '', '', '262', '', '', '440', '', '', '', '880 Hz'], def: 440, fmt: function (x) { return Math.round(x) + ' Hz'; } },
    { k: 'A', label: '振幅 $A$（音の大きさ）', aria: '振幅', stops: [0.2, 0.4, 0.6, 0.8, 1.0], prop: true, stopLabels: ['小', '', '', '', '大'], def: 0.6, fmt: function (x) { return Math.round(x * 5) + ' / 5'; } },
    { k: 'tc', label: '気温 $t$', aria: '気温', stops: [-10, -5, 0, 5, 10, 15, 20, 25, 30, 35, 40], prop: true, stopLabels: ['−10', '', '0', '', '10', '', '20', '', '30', '', '40 ℃'], def: 15, fmt: function (x) { return String(x).replace('-', '−') + ' ℃'; } },
    meterVar('T', '周期 $T$', '周期', function (x) { return sig(x * 1000, 3) + ' ms'; }, 0.008),
    meterVar('V', '音速 $V$', '音速', function (x) { return sig(x, 4) + ' m/s'; }, 360),
    meterVar('lam', '波長 $\\lambda$', '波長', function (x) { return sig(x, 3) + ' m'; }, 2.7)
  ],
  disp: function (s, k) { var q = m3s1Q(s); if (k === 'T') return q.T; if (k === 'V') return q.V; if (k === 'lam') return q.lam; return s.v[k]; },
  init: function (s) { s.src = 'fork'; s.vow = 'a'; s.ins = 'flute'; },
  onDefaults: function (s) { s.src = 'fork'; s.vow = 'a'; s.ins = 'flute'; m3s1Sync(s); },
  onChanged: function (s) { m3s1Sync(s); s.resound && s.resound(); return 'keepT'; },
  buttons: M3_SRC.map(function (p) { return { k: 's_' + p[0], label: p[1], seg: 'src', segLabel: '音源', onClick: function (s) { s.src = p[0]; m3s1Sync(s); s.resound(); s.draw(); } }; })
    .concat(M3_VOW.map(function (p) { return { k: 'v_' + p[0], label: '「' + p[1] + '」', seg: 'vow', segLabel: '声の母音', onClick: function (s) { s.vow = p[0]; m3s1Sync(s); s.resound(); s.draw(); } }; }))
    .concat(M3_INS.map(function (p) { return { k: 'i_' + p[0], label: p[1], seg: 'ins', segLabel: '楽器', onClick: function (s) { s.ins = p[0]; m3s1Sync(s); s.resound(); s.draw(); } }; })),
  tEnd: function () { return M3_TEND; },
  tInfo: function (s) { return '<span class="tpl">図の振動</span><b>実際の 1/' + Math.round(m3K(s, s.v.f)) + '</b>'; },
  gT: function (s) { return m3K(s, s.v.f) / s.v.f; },
  height: function (s, w) { return Math.round(clamp(w * 0.6, 340, 400)); },
  afterBuild: function (s) {
    s.R.innerHTML = ''; var sw = el('div', 'row2 sliders inR'); sw.appendChild(s.varbox); s.R.appendChild(sw); s.varbox.classList.add('inR');
    s.scope = new Scope(s.R, 'オシロスコープ（マイクで受けた空気の振動）');
    s.specCv = el('canvas', 'scopecv speccv'); s.scope.cap.insertAdjacentElement('beforebegin', s.specCv);   /* オシロスコープの下にスペクトル */
    m3SpecPick(s, s.specCv, function () { s.scope._k = null; m3s1Scope(s); });   /* 線をクリックすると振動数を表示（2026-11-05 千葉さん 8 回目） */
    s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);
    var segs = s.row1b.querySelectorAll('.seg');
    [['音源', 0], ['声', 1], ['楽器', 2]].forEach(function (p) { if (segs[p[1]]) segs[p[1]].insertAdjacentElement('beforebegin', el('span', 'seglbl' + (p[1] ? ' sub' + p[1] : ''), p[0])); });
    s.subSeg = [segs[1], segs[2]]; s.subLbl = [s.row1b.querySelector('.seglbl.sub1'), s.row1b.querySelector('.seglbl.sub2')];
    s.subGrp = [lblSeg(s.subLbl[0], segs[1]), lblSeg(s.subLbl[1], segs[2])]; lblSeg(segs[0].previousElementSibling, segs[0]);
    var sp = el('span', 'spkrow'); s.row1b.appendChild(sp); s.spkRow = sp;
    m3SpkBtn(s, sp, function () { var q = m3s1Q(s); return { voices: [{ f: q.f, partials: m3Parts(s, q.f) }], vol: q.A }; });
    m3TimeBar(s, false);
    m3s1Sync(s);
  },
  draw: function (s, ctx, W, H) { drawM3S1(s, ctx, W, H); m3s1Scope(s); },
  right: function (s, R) { rightM3S1(s, R); }
};
function m3s1Sync(s) {
  var a = M3_SRC.map(function (p) { return ['s_' + p[0], s.src === p[0]]; }).concat(M3_VOW.map(function (p) { return ['v_' + p[0], s.vow === p[0]]; }), M3_INS.map(function (p) { return ['i_' + p[0], s.ins === p[0]]; }));
  m2Sync(s, a);
  if (s.subGrp) [0, 1].forEach(function (i) { var on = (i === 0 && s.src === 'voice') || (i === 1 && s.src === 'inst'); if (s.subGrp[i]) s.subGrp[i].style.display = on ? '' : 'none'; });
  if (s.spkMsg) s.spkMsg.classList.toggle('on', !WAVE.audible(s.v.f));
  if (s.Rdyn) s.renderRight();
}
/* 音源の絵 */
function m3SrcShape(s, ctx, x, cy, ph, A) {
  var d = 3.5 * A * Math.sin(TAU * ph);
  if (s.src === 'fork') { forkShape(ctx, x, cy + 26, 66, d); label(ctx, 'おんさ', x, cy + 86, { size: 11, color: COL.ink2, bold: true }); return; }
  if (s.src === 'voice') {
    ctx.save(); ctx.fillStyle = '#f3dccb'; ctx.strokeStyle = '#6b4a3a'; ctx.lineWidth = 1.8;
    ctx.beginPath(); ctx.ellipse(x - 6, cy, 30, 36, 0, 0, TAU); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#3a2a22'; ctx.beginPath(); ctx.arc(x + 6, cy - 10, 3, 0, TAU); ctx.fill();
    var mo = 4 + 3 * Math.abs(Math.sin(TAU * ph)) * A, mh = s.vow === 'a' ? 9 : (s.vow === 'i' ? 3 : 5), mw = s.vow === 'i' ? 7 : (s.vow === 'u' ? 3.5 : 6);
    ctx.fillStyle = '#8a2c2c'; ctx.beginPath(); ctx.ellipse(x + 17, cy + 12, mw, Math.max(1.5, mh * mo / 7), 0, 0, TAU); ctx.fill(); ctx.restore();
    label(ctx, '声「' + { a: 'あ', i: 'い', u: 'う' }[s.vow] + '」', x - 6, cy + 54, { size: 11, color: COL.ink2, bold: true }); return;
  }
  ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 2;
  if (s.ins === 'flute') {
    ctx.fillStyle = '#c9ced6'; rrect(ctx, x - 44, cy - 6, 92, 12, 6); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#3a414c'; [-30, -16, -2, 12, 26, 38].forEach(function (dx) { ctx.beginPath(); ctx.arc(x + dx, cy, 2.2, 0, TAU); ctx.fill(); });
  } else if (s.ins === 'clarinet') {
    ctx.fillStyle = '#2b2b2f'; rrect(ctx, x - 6, cy - 52, 12, 92, 4); ctx.fill();
    ctx.beginPath(); ctx.moveTo(x - 6, cy + 36); ctx.lineTo(x - 15, cy + 54); ctx.lineTo(x + 15, cy + 54); ctx.lineTo(x + 6, cy + 36); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#c9ced6'; [-36, -22, -8, 6, 20].forEach(function (dy) { ctx.beginPath(); ctx.arc(x, cy + dy, 2.2, 0, TAU); ctx.fill(); });
  } else {
    ctx.fillStyle = '#b5683a'; ctx.beginPath(); ctx.ellipse(x, cy + 16, 22, 20, 0, 0, TAU); ctx.ellipse(x, cy - 14, 17, 16, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = '#3a2a22'; ctx.fillRect(x - 2.5, cy - 64, 5, 52);
    ctx.strokeStyle = '#2b2b2f'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(x - 9, cy - 22); ctx.quadraticCurveTo(x - 6, cy, x - 9, cy + 22); ctx.moveTo(x + 9, cy - 22); ctx.quadraticCurveTo(x + 6, cy, x + 9, cy + 22); ctx.stroke();
  }
  ctx.restore();
  label(ctx, { flute: 'フルート', clarinet: 'クラリネット', violin: 'バイオリン' }[s.ins], x, cy + 70, { size: 11, color: COL.ink2, bold: true });
}
function drawM3S1(s, ctx, W, H) {
  var q = m3s1Q(s), wv = m3Wave(m3Parts(s, q.f)), K = m3K(s, q.f), fS = q.f / K;
  var t = s.t + M3S1_L / (q.V / K);                            /* はじめから音がマイクまで届いている状態にする（2026-11-05 千葉さん 8 回目：添付図 4） */
  var sx = W < 520 ? 46 : 64, x0 = sx + (W < 520 ? 44 : 60), x1 = W - (W < 520 ? 34 : 50), cy = Math.round(H * 0.36);
  var SX = (x1 - x0) / M3S1_L, vS = q.V / K, uMax = 0.07 * Math.min(q.lam, 1.0) * q.A;    /* 空気の粒の変位（図のための大きさ） */
  m3SrcShape(s, ctx, sx, cy, fS * t, q.A);
  /* 空気の粒（均一に並べる）。変位は音源の波形 w(f(t − x/V)) */
  var band = Math.min(110, Math.round(H * 0.32)), yT = cy - band / 2, nx = Math.round((x1 - x0) / (W < 520 ? 9 : 7)), ny = 8;
  ctx.save(); ctx.fillStyle = 'rgba(91,122,144,.05)'; ctx.fillRect(x0, yT, x1 - x0, band); ctx.restore();
  ctx.save(); ctx.fillStyle = 'rgba(58,65,76,.62)';
  for (var i = 0; i <= nx; i++) {
    var xe = M3S1_L * i / nx, tr = t - xe / vS, u = tr < 0 ? 0 : uMax * wv.f(fS * tr), px = x0 + (xe + u) * SX;
    if (px < x0 || px > x1 + 2) continue;
    for (var j = 0; j < ny; j++) { ctx.beginPath(); ctx.arc(px, yT + band * (j + 0.5) / ny, 1.9, 0, TAU); ctx.fill(); }
  }
  ctx.restore();
  micShape(ctx, x1 + 14, cy);
  label(ctx, 'マイク（オシロスコープ）', W - 6, cy + 56, { size: 10.5, color: COL.ink2, bold: true, align: 'right' });   /* 聞く位置はどの節も同じ書き方（2026-11-04 千葉さん 6 回目） */
  /* 下：横波表示（右向きの変位を上向きに。①-4 の音波と同じ） */
  var yA = yT + band + 62, aT = 26;
  label(ctx, '横波表示', x0 + 10, yA - aT - 14, { size: 10.5, bold: true, color: COL.ink2, align: 'left' });
  axisArrow(ctx, x0 - 4, yA, x1 + 2, yA); axisArrow(ctx, x0, yA + aT + 6, x0, yA - aT - 10);
  ctx.save(); ctx.strokeStyle = '#7a3b12'; ctx.lineWidth = 2; ctx.beginPath();
  for (var iT = 0; iT <= 600; iT++) { var xT = M3S1_L * iT / 600, trT = t - xT / vS, yv = trT < 0 ? 0 : q.A * wv.f(fS * trT); if (iT) ctx.lineTo(x0 + xT * SX, yA - yv * aT); else ctx.moveTo(x0 + xT * SX, yA - yv * aT); }
  ctx.stroke(); ctx.restore();
  /* ものさし・断り書き */
  var ry = H - 8; ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(x1 - SX, ry); ctx.lineTo(x1, ry); ctx.moveTo(x1 - SX, ry - 4); ctx.lineTo(x1 - SX, ry + 1); ctx.moveTo(x1, ry - 4); ctx.lineTo(x1, ry + 1); ctx.stroke(); ctx.restore();
  label(ctx, '1 m', x1 - SX / 2, ry - 9, { size: 10, color: COL.ink2 });
  label(ctx, '空気の粒の動きは実際の約 1/' + Math.round(K) + ' の速さ（変位は拡大）', W - 8, 10, { size: 10.5, color: s.real ? '#c9670c' : COL.ink2, bold: !!s.real, align: 'right' });
  arrow(ctx, x0, yT - 14, x0 + 50, yT - 14, 'vel', COL.vel); label(ctx, '音の進む向き', x0 + 58, yT - 14, { size: 11, color: COL.vel, align: 'left' });
}
/* オシロスコープ：横 1 目盛り 1 ms（10 ms ぶん）。トリガーをかけた画面（波形は止まって見える） */
function m3s1Scope(s) {
  var sc = s.scope; if (!sc || !sc.cv.offsetParent) return;
  var q = m3s1Q(s), parts = m3Parts(s, q.f), wv = m3Wave(parts), W = Math.max(240, Math.floor(sc.cv.clientWidth || 300)), H = Math.round(clamp(W * 0.55, 150, 210));
  var arr = true;
  var key = [W, q.f, q.A, s.src, s.vow, s.ins, s._spSel].join('|'); if (sc._k === key) return; sc._k = key;   /* 変わったときだけ描き直す（波形は止まって見える） */
  var ctx = prep(sc.cv, W, H);
  ctx.clearRect(0, 0, W, H);
  sc.screen(ctx, 0, 0, W, H, { t0: 0, span: 0.010, yMax: 1, traces: arr ? [{ f: function (t) { return q.A * wv.f(q.f * t); }, fmax: q.f * wv.nMax }] : [], label: '横 1 目盛り 1 ms', labelR: arr ? q.f + ' Hz' : '' });
  /* 振動数のスペクトル：どの振動数の波が、どれだけの大きさでまざっているか（倍音の表そのもの） */
  var sv = s.specCv, SW = W, SH = Math.round(clamp(W * 0.3, 90, 120)), c2 = prep(sv, SW, SH);
  c2.clearRect(0, 0, SW, SH); c2.fillStyle = '#0d1a14'; rrect(c2, 0, 0, SW, SH, 6); c2.fill();
  var fx0 = 12, fx1 = SW - 12, fy0 = 22, fy1 = SH - 20, FM = 5000, XF = function (f) { return fx0 + f / FM * (fx1 - fx0); };
  c2.save(); c2.strokeStyle = 'rgba(120,220,170,.25)'; c2.lineWidth = 1;
  for (var k = 0; k <= 5; k++) { var gx = Math.round(XF(k * 1000)) + 0.5; c2.beginPath(); c2.moveTo(gx, fy0); c2.lineTo(gx, fy1); c2.stroke(); }
  c2.beginPath(); c2.moveTo(fx0, fy1 + 0.5); c2.lineTo(fx1, fy1 + 0.5); c2.stroke(); c2.restore();
  c2.save(); c2.font = '600 10px ' + FONT; c2.fillStyle = 'rgba(190,240,215,.85)'; c2.textBaseline = 'top'; c2.fillText('振動数のスペクトル（どの振動数の音が、どれだけまざっているか）', 6, 5);
  c2.textAlign = 'center'; for (var k2 = 0; k2 <= 5; k2++) c2.fillText(k2 === 5 ? '5000 Hz' : String(k2 * 1000), Math.min(fx1 - 18, XF(k2 * 1000)), fy1 + 4); c2.restore();
  m3SpecBars(c2, s, parts, q.f, q.A, XF, fy0, fy1, FM, s.src !== 'fork');
  var cap = '1 周期 $T = ' + sig(q.T * 1000, 3) + '$ ms（10 ms の間に ' + sig(0.010 * q.f, 3) + ' 回振動）。いちばん左の線が $f = ' + q.f + '$ Hz（基音）、ほかは倍音。線をクリックすると振動数を表示';
  if (sc.cap._h !== cap) { sc.cap._h = cap; sc.cap.innerHTML = mathify(cap); }
}
function rightM3S1(s, R) {
  var q = m3s1Q(s);
  var h = '<div class="qcard"><p class="qt">音の三要素</p>' +
    '<table class="reltab grid1"><thead><tr><th>音の要素</th><th>決めるもの</th><th>オシロスコープでは</th></tr></thead><tbody>' +
    '<tr><th>高さ</th><td>振動数 $f$</td><td>波の数（多いほど高い音）</td></tr>' +
    '<tr><th>大きさ</th><td>振幅 $A$</td><td>波の高さ（高いほど大きい音）</td></tr>' +
    '<tr><th>音色</th><td>波形</td><td>波の形</td></tr></tbody></table>' +
    '<p>おんさの音は、きれいな正弦波に近い。声や楽器の音は、振動数が $f$ の整数倍の波（倍音）がまざっているので、波形がちがう。同じ高さ（同じ $f$）でも音色がちがって聞こえる。</p>' +
    '<div class="qeq">$$V = 331.5 + 0.6t,\\qquad V = f\\lambda$$</div>' +
    '<p class="qnow"><span class="qtag now">いま</span>$t = ' + s.v.tc + '$ ℃ なので $V = ' + sig(q.V, 4) + '$ m/s、$\\lambda = \\dfrac{V}{f} = \\dfrac{' + sig(q.V, 4) + '}{' + Math.round(q.f) + '} = ' + sig(q.lam, 3) + '$ m</p>' +
    '<p class="qnote">気温を変えても振動数（音の高さ）は変わらない。変わるのは音速 $V$ と波長 $\\lambda$。</p></div>';
  R.innerHTML = mathify(h);
}

/* =====================================================================
   ③-2 うなり（2026-11-06 千葉さん 11 回目に組み直し。教科書の図 36・37 を参考に、3 組をたてにならべる）
   ・左右の比 4 : 6。各段：左＝おんさとマイクの図、右＝オシロスコープ
   ・(1) 4 Hz と 14 Hz：うなりのしくみ（耳には聞こえないので音はなし）。図は実際の時間で動く（1 秒に 10 回うなる）（2026-11-07 千葉さん 13 回目に 5 → 14 Hz）
   ・(2) 400 Hz と 410 Hz：本体。スライダーは 400〜410 Hz。音あり
   ・(3) 400 Hz と 4000 Hz：振動数の差が大きいと、うなりの形にならない。音あり
   ・y = sin 2πf₁t + sin 2πf₂t。包絡線 |cos π(f₁ − f₂)t|
   ===================================================================== */
var M3S2_F = [400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410];   /* 400〜410 Hz（2026-11-06 千葉さん 11 回目） */
var M3S2_ROWS = [{ f1: 4, f2: 14 }, null, { f1: 400, f2: 4000 }];
function m3s2Q(s) { return { f1: s.v.f1, f2: s.v.f2, fb: Math.abs(s.v.f1 - s.v.f2) }; }
function m3s2Qr(r) { return { f1: r.f1, f2: r.f2, fb: Math.abs(r.f1 - r.f2) }; }
function m3s2Y(q, t) { return 0.5 * (Math.sin(TAU * q.f1 * t) + Math.sin(TAU * q.f2 * t)); }
function m3s2Env(q, t) { return Math.abs(Math.cos(Math.PI * (q.f1 - q.f2) * t)); }
DEFS.m3s2 = {
  id: 'm3s2', mode: 'mode3', num: 2,
  title: 'うなり', short: 'うなり',
  desc: '振動数が少しちがう 2 つの音が重なると、音がうわんうわん聞こえる「<b>うなり</b>」が発生する。<span class="todo">(1)〜(3) を見比べ、どうして (2) ではうなりが聞こえるのかを理解しよう。</span>',
  strobe: false, stepDiv: 16,
  varCols: [['f1', 'f2', 'fb']],
  vars: [
    { k: 'f1', label: 'おんさ 1 の振動数 $f_1$', aria: 'おんさ 1 の振動数', stops: M3S2_F, prop: true, stopLabels: ['400', '', '', '', '', '405', '', '', '', '', '410 Hz'], def: 400, fmt: function (x) { return x + ' Hz'; } },
    { k: 'f2', label: 'おんさ 2 の振動数 $f_2$', aria: 'おんさ 2 の振動数', stops: M3S2_F, prop: true, stopLabels: ['400', '', '', '', '', '405', '', '', '', '', '410 Hz'], def: 410, fmt: function (x) { return x + ' Hz'; } },
    meterVar('fb', 'うなりの回数 $f$', 'うなりの回数', function (x) { return x + ' 回/秒'; }, 10)
  ],
  disp: function (s, k) { if (k === 'fb') return m3s2Q(s).fb; return s.v[k]; },
  init: function (s) { s.r1 = { f1: 4, f2: 14 }; },
  onChanged: function (s) { s.resound && s.resound(); return 'keepT'; },
  tEnd: function () { return M3_TEND; },
  tInfo: function () { return ''; },
  gT: function (s) { var q = m3s2Q(s); return q.fb ? 1 / q.fb : 1; },
  height: function (s, w) { return Math.round(clamp(w * 0.62, 230, 270)); },
  afterBuild: function (s) {
    m3TimeBar(s, false);
    var art = document.getElementById('m3s2'); art.classList.add('wide1');
    /* 3 段の入れ物（各段 4 : 6）。(2) の左に、いままでの図（s.cw）・スライダー・🔊 */
    var box = el('div', 'brows'); s.cw.insertAdjacentElement('beforebegin', box);
    var heads = ['(1) 4 Hz と 14 Hz：うなりのしくみ', '(2) 400 Hz と 410 Hz：うなりを聞いてみよう', '(3) 400 Hz と 4000 Hz：振動数の差が大きいとき　→うなりは聞こえない'];
    s.bRows = heads.map(function (h, i) {
      var row = el('div', 'brow'), hd = el('p', 'browh', h), lc = el('div', 'browl'), rc = el('div', 'browr');
      row.appendChild(hd); row.appendChild(lc); row.appendChild(rc); box.appendChild(row);
      return { row: row, L: lc, R: rc, hd: hd };
    });
    s.bRows[1].L.appendChild(s.cw);
    var sw = el('div', 'row2 sliders inL'); sw.appendChild(s.varbox); s.bRows[1].L.appendChild(sw);
    var sp = el('span', 'spkrow'); s.bRows[1].L.appendChild(sp);
    m3SpkBtn(s, sp, function () { var q = m3s2Q(s); return { voices: [{ f: q.f1 }, { f: q.f2 }], vol: 0.9 }; });
    s.spkRow = null;
    /* (1)・(3) の図とオシロスコープ */
    [0, 2].forEach(function (i) {
      var cw = el('div', 'cvwrap'), cv = el('canvas'); cw.appendChild(cv); s.bRows[i].L.appendChild(cw); s.bRows[i].cv = cv;
      s.bRows[i].sc = new Scope(s.bRows[i].R, i ? 'オシロスコープ（400 Hz と 4000 Hz）' : 'オシロスコープ（(1) の 2 つの音）');
      if (!i) {
        s.bRows[i].L.appendChild(el('p', 'brownote', '20 Hz より低いので耳には聞こえない。音はなし'));   /* アニメの下に（2026-11-07 千葉さん 13 回目） */
        /* (1) の振動数も 4〜14 Hz で変えられる（2026-11-07 千葉さん 14 回目） */
        var bs = el('div', 'bsliders');
        [['f1', 'おんさ 1 の振動数'], ['f2', 'おんさ 2 の振動数']].forEach(function (p) {
          var rw = el('label', 'bsl'), nm = el('span', 'bsn', p[1]), rg = el('input'), vv = el('b', 'bsv', s.r1[p[0]] + ' Hz');
          rg.type = 'range'; rg.min = '4'; rg.max = '14'; rg.step = '1'; rg.value = String(s.r1[p[0]]); rg.setAttribute('aria-label', '(1) の' + p[1]);
          rg.addEventListener('input', function () { s.r1[p[0]] = +rg.value; vv.textContent = rg.value + ' Hz'; s.bRows[0].hd.textContent = '(1) ' + s.r1.f1 + ' Hz と ' + s.r1.f2 + ' Hz：うなりのしくみ'; s.draw(); });
          rw.appendChild(nm); rw.appendChild(rg); rw.appendChild(vv); bs.appendChild(rw);
        });
        s.bRows[i].L.appendChild(bs);
      }
    });
    s.scope = new Scope(s.bRows[1].R, 'オシロスコープ（400 Hz 付近の 2 つの音）');
    /* (3) の 🔊（持ち主 m3s2c） */
    var sp3 = el('span', 'spkrow'), b3 = el('button', 'b spk m3spk', '🔊 音を鳴らす'); b3.type = 'button';
    b3.addEventListener('click', function () {
      if (AUDIO.owner() === 'm3s2c') { AUDIO.stop(); return; }
      AUDIO.play('m3s2c', [{ f: 400 }, { f: 4000 }], 0.9);
      if (!s.playing) { s.playing = true; SIMS.forEach(function (o) { if (o !== s && o.playing) { o.playing = false; o.syncPlayLabel(); } }); s.syncPlayLabel(); startLoop(); }
    });
    sp3.appendChild(b3); s.bRows[2].L.appendChild(sp3); s.spk3 = b3;
    var sy3 = function () { var on = AUDIO.owner() === 'm3s2c'; b3.textContent = on ? '■ 音を止める' : '🔊 音を鳴らす'; b3.classList.toggle('on', on); b3.classList.toggle('glow', !on); };
    AUDIO.onChange(sy3); sy3();
    var orig = s.syncPlayLabel;
    s.syncPlayLabel = function () { var r = orig.apply(s, arguments); if (!s.playing && AUDIO.owner() === 'm3s2c') AUDIO.stop(); return r; };
    /* 説明カードは 3 段の下 */
    s.Rdyn = el('div', 'rdyn brcard'); box.insertAdjacentElement('afterend', s.Rdyn);
    s.R.innerHTML = '';
  },
  draw: function (s, ctx, W, H) {
    drawM3S2(s, ctx, W, H, m3s2Q(s), { live: false });
    m3s2ScopeRow(s, 1);
    if (!s.bRows) return;
    [0, 2].forEach(function (i) {
      var b = s.bRows[i], cv = b.cv; if (!cv.offsetParent) return;
      var w = Math.max(240, Math.floor(cv.clientWidth || 300)), c2 = prep(cv, w, H);
      c2.fillStyle = '#fff'; c2.fillRect(0, 0, w, H);
      drawM3S2(s, c2, w, H, m3s2RowQ(s, i), { live: i === 0, far: i === 2 });
    });
    m3s2ScopeRow(s, 0); m3s2ScopeRow(s, 2);
  },
  right: function (s, R) { rightM3S2(s, R); }
};
/* 左の図：おんさ 2 つ・音の広がり・マイク・聞こえる音の大きさ。o.live：振動を実際の速さで描く（4・5 Hz）。o.far：差が大きい（400・4000 Hz） */
function drawM3S2(s, ctx, W, H, q, o) {
  var t = s.t, env = m3s2Env(q, t), nar = W < 420;
  var fx = nar ? 44 : 60, cy1 = Math.round(H * 0.32), cy2 = Math.round(H * 0.76);
  [[q.f1, cy1, 'おんさ 1'], [q.f2, cy2, 'おんさ 2']].forEach(function (p) {
    forkShape(ctx, fx, p[1] + 4, nar ? 34 : 42, o.live ? 4 * Math.sin(TAU * p[0] * t) : (s.real ? 2.5 * Math.sin(TAU * M3_REALF * t) : 0));
    /* 400 Hz 以上の振動は目で追えないので、枝のまわりをぼかして「振動している」ことだけを示す（4・5 Hz は実際に動かす） */
    if (!o.live) { ctx.save(); ctx.strokeStyle = 'rgba(224,123,24,.35)'; ctx.lineWidth = 1.2; [-1, 1].forEach(function (sg) { ctx.beginPath(); ctx.moveTo(fx + sg * 16, p[1] - 34); ctx.lineTo(fx + sg * 16, p[1] - 6); ctx.stroke(); }); ctx.restore(); }
    label(ctx, p[2] + '　' + p[0] + ' Hz', fx + 28, p[1] - 28, { size: 11.5, bold: true, color: COL.ink2, align: 'left' });
  });
  var ex = W - (nar ? 62 : 80), ey = Math.round(H * 0.54);
  micShape(ctx, ex, ey);
  label(ctx, 'マイク（オシロスコープ）', ex + 20, ey + 58, { size: 10.5, bold: true, color: COL.ink2, align: 'right' });
  var fast = q.fb > 10, gx0 = fx + 34, gx1 = ex - 24;
  for (var k = 0; k < 4; k++) {
    var r = (k + ((t * (s.real ? 5 : 1.5)) % 1)) / 4, ev = fast ? 0.6 : env;
    ctx.save(); ctx.strokeStyle = 'rgba(22,99,181,' + (0.12 + 0.5 * ev * (1 - r)).toFixed(3) + ')'; ctx.lineWidth = 1 + 3 * ev;
    ctx.beginPath(); ctx.arc(gx0 + (gx1 - gx0) * r, ey, 20 + 22 * r, -0.6, 0.6); ctx.stroke(); ctx.restore();
  }
  var mx = ex + (nar ? 24 : 30), mh = H * 0.52, my = ey - mh / 2;
  ctx.save(); ctx.fillStyle = '#eef0f2'; rrect(ctx, mx, my, 12, mh, 5); ctx.fill(); ctx.fillStyle = fast ? 'rgba(224,123,24,.35)' : '#e07b18'; if (fast) rrect(ctx, mx, my, 12, mh, 5); else rrect(ctx, mx, my + mh * (1 - env), 12, Math.max(2, mh * env), 5); ctx.fill(); ctx.restore();
  label(ctx, '大きさ', mx + 6, my - 10, { size: 10, color: COL.sub });
  var top = o.far ? '差が 3600 Hz と大きい：うなりとしては聞こえない' : '1 秒間に ' + q.fb + ' 回、大きくなる（うなりの回数 ' + q.fb + ' 回/秒）';
  label(ctx, top, W / 2, 12, { size: nar ? 10.5 : 11.5, bold: true, color: '#6b3a0a' });
  if (!o.far && s.t > 0 && q.fb) label(ctx, 'これまでに大きくなった回数：' + Math.floor(t * q.fb + 0.5) + ' 回（' + sig(t, 3) + ' 秒）', W / 2, H - 10, { size: 10.5, color: COL.ink2 });
}
/* オシロスコープ（2026-11-06 千葉さん 12 回目に作り直し）
   (1)(2)(3) とも、まず「1 s 間」（同じ横はば。横 1 目盛り 0.1 s）に おんさ 1・おんさ 2・合成した波 の 3 段。
   (2)(3) は、その下に横軸を拡大した 3 段（(2) は 0.1 s 間、(3) は 0.01 s 間）。
   言葉は波形と重ならないように、各段の上の帯に書く */
function m3Cnt(x) { return Math.abs(x - Math.round(x)) < 1e-6 ? String(Math.round(x)) : sig(x, 3); }
var M3S2_LBL = 15;
/* 1 組（3 段）を y から描く。o.x・o.w：横の位置とはば（拡大の吹き出しの中に描くとき）。返り値＝{ y：次の y, y0・y1：波の段の上下 } */
function m3s2Block(sc, ctx, y, W, q, o) {
  var lh = o.lh, t0 = o.t0 || 0, span = o.span, x0 = o.x || 0, w = o.w || W;
  label(ctx, o.title, x0 + 4, y + 8, { size: 11, bold: true, color: '#e8f2ec', align: 'left', halo: false });
  y += 18;
  var lanes = [
    { f: function (t) { return 0.8 * Math.sin(TAU * q.f1 * t); }, col: '#ffb27a', name: o.n1 },
    { f: function (t) { return 0.8 * Math.sin(TAU * q.f2 * t); }, col: '#9fc8ff', name: o.n2 },
    { f: function (t) { return 0.8 * m3s2Y(q, t); }, col: '#7dffb4', name: o.n3, env: q.fb && q.fb < 200 ? function (t) { return 0.8 * m3s2Env(q, t); } : null }
  ];
  var yl0 = y;
  lanes.forEach(function (ln) {
    label(ctx, ln.name, x0 + 6, y + M3S2_LBL / 2, { size: 10.5, bold: true, color: ln.col, align: 'left', halo: false });
    sc.screen(ctx, x0, y + M3S2_LBL, w, lh, { t0: t0, span: span, yMax: 1, traces: [{ f: ln.f, col: ln.col, fmax: Math.max(q.f1, q.f2) }], env: ln.env });
    y += M3S2_LBL + lh + 3;
  });
  var yl1 = y - 3;
  /* 強め合う（同位相）・弱め合う（逆位相）の時刻の縦線。数が多いときは強め合う所だけ、言葉なし */
  if (q.fb && q.fb < 200) {
    var half = 0.5 / q.fb, n0 = Math.ceil(t0 / half - 1e-9), n1 = Math.floor((t0 + span) / half + 1e-9), many = (n1 - n0) > 6;
    for (var m = n0; m <= n1; m++) {
      var same = m % 2 === 0; if (many && !same) continue;
      var px = x0 + clamp((m * half - t0) / span * w, 1, w - 1);
      ctx.save(); ctx.strokeStyle = same ? 'rgba(255,214,120,.85)' : 'rgba(150,190,255,.85)'; ctx.setLineDash([4, 3]); ctx.lineWidth = 1.3;
      ctx.beginPath(); ctx.moveTo(px, yl0 + M3S2_LBL); ctx.lineTo(px, y - 3); ctx.stroke(); ctx.restore();
      if (!many) label(ctx, same ? (o.words ? '同位相' : '強め合う') : (o.words ? '逆位相' : '弱め合う'), clamp(px, x0 + 24, x0 + w - 24), y + 7, { size: 10, bold: true, color: same ? '#ffd678' : '#9fc8ff', halo: false });
    }
    if (many) label(ctx, '黄色の線：強め合う時刻（同位相）', x0 + 6, y + 7, { size: 10, bold: true, color: '#ffd678', align: 'left', halo: false });
    y += 16;
  }
  return { y: y + 6, y0: yl0 + M3S2_LBL, y1: yl1 };
}
/* 拡大の吹き出し：上の段の [0, f×W] を黄色の枠で囲み、そこから下の吹き出しへ口を開けてつなぐ（2026-11-07 千葉さん 14 回目） */
function m3s2BubbleDraw(ctx, W, top, bot, yb, ye, frac) {
  var rx1 = Math.max(6, W * frac), bx0 = 2, bx1 = W - 2, r = 10, nk0 = Math.max(16, rx1 * 0.5 - 6), nk1 = Math.min(bx1 - 24, Math.max(rx1 + 70, W * 0.22));
  ctx.save(); ctx.strokeStyle = '#ffd678'; ctx.lineWidth = 2; ctx.strokeRect(1, top - 2, rx1, bot - top + 4); ctx.restore();
  ctx.save(); ctx.fillStyle = 'rgba(255,255,255,.05)'; ctx.strokeStyle = 'rgba(255,214,120,.9)'; ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.moveTo(nk1, yb); ctx.lineTo(bx1 - r, yb); ctx.arcTo(bx1, yb, bx1, yb + r, r); ctx.lineTo(bx1, ye - r); ctx.arcTo(bx1, ye, bx1 - r, ye, r);
  ctx.lineTo(bx0 + r, ye); ctx.arcTo(bx0, ye, bx0, ye - r, r); ctx.lineTo(bx0, yb + r); ctx.arcTo(bx0, yb, bx0 + r, yb, r); ctx.lineTo(nk0, yb);
  ctx.fill(); ctx.stroke();
  /* 口：枠の下の左右から、吹き出しの上の辺へ（口は開けておく） */
  ctx.beginPath(); ctx.moveTo(1, bot + 2); ctx.lineTo(nk0, yb); ctx.moveTo(rx1 + 1, bot + 2); ctx.lineTo(nk1, yb); ctx.stroke();
  ctx.restore();
}
/* 段 i（0：(1)、1：(2)、2：(3)）のオシロスコープ。
   波形は振動数が変わったときだけ描き直し（別の canvas にとっておく）、毎コマは時刻の線だけ（2026-11-07 千葉さん 14 回目：重いので） */
function m3s2RowQ(s, i) { return i === 1 ? m3s2Q(s) : m3s2Qr(i === 0 ? s.r1 : M3S2_ROWS[2]); }
function m3s2ScopeRow(s, i) {
  var sc = i === 1 ? s.scope : (s.bRows && s.bRows[i] && s.bRows[i].sc); if (!sc || !sc.cv.offsetParent) return;
  var q = m3s2RowQ(s, i), W = Math.max(240, Math.floor(sc.cv.clientWidth || 300)), lh = Math.round(clamp(W * 0.085, 40, 54));
  var blkH = 18 + 3 * (M3S2_LBL + lh + 3) + (q.fb && q.fb < 200 ? 16 : 0) + 6, zoom = i !== 0, H = zoom ? 2 * blkH + 26 : blkH;
  var key = [W, q.f1, q.f2].join('|'), dpr = Math.min(2, window.devicePixelRatio || 1);
  if (sc._key !== key) {
    sc._key = key;
    var off = sc._off || (sc._off = document.createElement('canvas'));
    off.width = Math.round(W * dpr); off.height = Math.round(H * dpr);
    var c = off.getContext('2d'); c.setTransform(dpr, 0, 0, dpr, 0, 0); c.clearRect(0, 0, W, H);
    CVW = W; CVH = H;                                                 /* 文字の位置の範囲（label）をこの canvas の大きさに */
    var fx = function (f) { return f + ' Hz'; };
    var b1 = m3s2Block(sc, c, 0, W, q, { span: 1, lh: lh, words: i === 0, title: '1 s 間（横 1 目盛り 0.1 s）',
      n1: 'おんさ 1（' + fx(q.f1) + '）' + (i === 0 ? '：1 s の間に ' + q.f1 + ' 個' : ''), n2: 'おんさ 2（' + fx(q.f2) + '）' + (i === 0 ? '：1 s の間に ' + q.f2 + ' 個' : ''),
      n3: '合成した波' + (q.fb && q.fb < 200 ? '：1 s の間に ' + q.fb + ' 回 大きくなる' : (q.fb ? '：大きさは変わらない（うなりの形にならない）' : '')) });
    sc._ly = [b1.y0, b1.y1];
    if (zoom) {
      var zs = i === 1 ? 0.1 : 0.01, yb = b1.y + 16, pad = 8;
      m3s2BubbleDraw(c, W, b1.y0, b1.y1, yb, H - 2, zs);
      if (i === 1) m3s2Block(sc, c, yb + 4, W, q, { x: pad, w: W - 2 * pad, span: 0.1, lh: lh, title: '拡大：はじめの 0.1 s 間（横 1 目盛り 0.01 s）', n1: 'おんさ 1（' + fx(q.f1) + '）：0.1 s の間に ' + m3Cnt(q.f1 / 10) + ' 個', n2: 'おんさ 2（' + fx(q.f2) + '）：0.1 s の間に ' + m3Cnt(q.f2 / 10) + ' 個', n3: '合成した波' });
      else m3s2Block(sc, c, yb + 4, W, q, { x: pad, w: W - 2 * pad, span: 0.01, lh: lh, title: '拡大：はじめの 0.01 s 間（横 1 目盛り 0.001 s）', n1: 'おんさ 1（400 Hz）：0.01 s の間に 4 個', n2: 'おんさ 2（4000 Hz）：0.01 s の間に 40 個', n3: '合成した波：400 Hz の波に 4000 Hz の細かい波がのった形' });
    }
    var cap;
    if (i === 0) cap = '合成した波の振幅は、同位相で重なるとき最大、逆位相で重なるとき最小。1 s の間に振動の数が ' + q.fb + ' 個ずれる → うなりは 1 秒に ' + q.fb + ' 回（$f = |' + q.f1 + ' - ' + q.f2 + '| = ' + q.fb + '$ 回/秒）';
    else if (i === 1) cap = 'うなりの回数 $f = |f_1 - f_2| = |' + q.f1 + ' - ' + q.f2 + '| = ' + q.fb + '$ 回/秒' + (q.fb ? '。強め合ってから次に強め合うまで（' + sig(1 / q.fb, 2) + ' s）に、おんさ 1 は ' + m3Cnt(q.f1 / q.fb) + ' 回、おんさ 2 は ' + m3Cnt(q.f2 / q.fb) + ' 回振動する（1 回ずれる）' : '。同じ振動数なので、いつも強め合ったまま（うなりは起こらない）');
    else cap = '振動数の差が大きいと、合成した波の大きさはほとんど変わらず、うなりの形にならない（2 つの高さの音が同時に聞こえる）';
    if (sc.cap._h !== cap) { sc.cap._h = cap; sc.cap.innerHTML = mathify(cap); }
  }
  var ctx = prep(sc.cv, W, H); ctx.clearRect(0, 0, W, H);
  ctx.drawImage(sc._off, 0, 0, W, H);
  var px = (s.t % 1) * W;                                            /* いまの時刻の線（上の 1 s 間だけ） */
  ctx.save(); ctx.strokeStyle = 'rgba(255,255,255,.75)'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(px, sc._ly[0]); ctx.lineTo(px, sc._ly[1]); ctx.stroke(); ctx.restore();
}
function rightM3S2(s, R) {
  var q = m3s2Q(s);
  var h = '<div class="qcard"><p class="qt">うなり</p>' +
    '<p>振動数 $f_1$・$f_2$ の音が重なると、山と山が重なって強め合う時刻と、山と谷が重なって弱め合う時刻が交互に来る。強め合ってから次に強め合うまでの時間がうなりの周期 $T$。</p>' +
    '<div class="qeq">$$f = |f_1 - f_2|$$</div>' +
    '<p>（$T$ 秒の間に、2 つの音の振動の回数が 1 回だけずれる：$|f_1 T - f_2 T| = 1$）</p>' +
    '<p class="qnow"><span class="qtag now">いま</span>$f = |' + q.f1 + ' - ' + q.f2 + '| = ' + q.fb + '$ 回/秒' + (q.fb ? '、$T = ' + sig(1 / q.fb, 2) + '$ s' : '（同じ振動数なので、うなりは起こらない）') + '</p>' +
    '<p>うなりが聞こえるのは、2 つの音の振動数が近いとき（(2)）。振動数の差が大きいと（(3)）、うなりにはならず、2 つの高さの音が同時に聞こえる。</p>' +
    '<p class="qnote">楽器の調律では、基準の音とのうなりが 0 になるように合わせる。</p></div>';
  R.innerHTML = mathify(h);
}

/* =====================================================================
   ③-3 弦と気柱の固有振動と共鳴
   ・楽器（共鳴体）：弦（モノコード）／開管／閉管（水柱の実験は ③-5）
   ・固有振動を聞く：4 段（基本・2 倍（閉管は 3 倍）・3 倍（閉管は 5 倍）・実際の振動）。右の列はなくして横長に
   ・共鳴を見る：弦は左はしが振動子（弦とつながったまま）、管はスピーカー。振動数は f₁ の 0.75〜3.25 倍
   ・「管の口と腹を一致させる」は既定 OFF（開口端補正を入れて、腹を管口の少し外 Δ = 0.6r に描く）
   ===================================================================== */
var M3S3 = { rho: 5.1e-4, mW: 0.5, g: 9.8, r: 0.02, fork: 800, Q: 40, Qw: 12 };
var M3S3_INS = [['string', '弦（モノコード）'], ['open', '開管'], ['closed', '閉管']];   /* 水柱の実験は ③-5 に独立（2026-11-05 千葉さん 8 回目） */
var M3S3_DR = [1, 1.5, 2, 2.5, 3];
function m3s3Q(s) {
  var ins = s.ins, l = s.v.l, V = WAVE.V(s.v.tc), v, f1, ms;
  if (ins === 'string') { v = Math.sqrt(s.v.nw * M3S3.mW * M3S3.g / M3S3.rho); f1 = WAVE.fString(l, v, 1); ms = [1, 2, 3, 4]; }
  else if (ins === 'open') { v = V; f1 = WAVE.fOpen(l, V, 1); ms = [1, 2, 3, 4]; }
  else { v = V; f1 = WAVE.fClosed(l, V, 1); ms = [1, 3, 5, 7]; }
  return { ins: ins, l: l, v: v, V: V, f1: f1, ms: ms, m: ms[s.mi], fm: ins === 'string' ? WAVE.fString(l, v, ms[s.mi]) : (ins === 'open' ? WAVE.fOpen(l, V, ms[s.mi]) : WAVE.fClosed(l, V, ms[s.mi])), fd: (s.fdr || 1) * f1 };
}
/* m 倍振動の形（変位の振幅の分布、0〜1）。x は 0（左はし）〜l。closed は左が開口・右が閉じた端。
   exact：開口端補正（腹を管口の外 Δ に）を入れて描く */
function m3s3Shape(ins, m, l, x, exact) {
  var d = exact ? 0.6 * M3S3.r : 0;
  if (ins === 'string') return Math.sin(m * Math.PI * x / l);
  if (ins === 'open') return Math.cos(m * Math.PI * (x + d) / (l + 2 * d));
  return Math.cos(m * Math.PI * (x + d) / (2 * (l + d)));                       /* 閉管・水柱：x = 0 が開口（腹）、x = l が閉じた端（節） */
}
/* 共鳴を見る：振動数 f で揺すったときの形 = Σ（m 倍振動の共振のしかた）×（m 倍振動の形）。共振の強さは 1/√((1 − r²)² + (r/Q)²)/Q（r = f/fₘ） */
function m3s3Resp(q, f) {
  var out = [], list = q.ins === 'string' || q.ins === 'open' ? [1, 2, 3, 4, 5, 6] : [1, 3, 5, 7, 9, 11];
  list.forEach(function (m) { var fm = m * q.f1, r = f / fm, a = 1 / Math.sqrt(Math.pow(1 - r * r, 2) + Math.pow(r / M3S3.Q, 2)) / M3S3.Q; out.push({ m: m, a: a }); });
  return out;
}
/* 水柱：おんさ 800 Hz、気柱の長さ L のときの共鳴の強さ（0〜1）。L が λ/4 の奇数倍に近いほど大きい */
function m3s3Water(V, L) {
  var lam = V / M3S3.fork, best = 0;
  for (var k = 1; k <= 7; k += 2) { var dlt = 4 * L / lam - k; best = Math.max(best, 1 / Math.sqrt(1 + Math.pow(M3S3.Qw * dlt, 2))); }
  return best;
}
DEFS.m3s3 = {
  id: 'm3s3', mode: 'mode3', num: 3,
  title: '弦と気柱の固有振動と共鳴', short: '弦と気柱',
  desc: '弦や気柱は、両端の条件で決まる振動数（<b>固有振動数</b>）で振動する。<span class="todo">楽器を選び、固有振動の音と共鳴を確かめよう。</span>',
  strobe: false, stepDiv: 16,
  varCols: [['l', 'nw', 'tc'], ['vv', 'f1']],
  varColNote: { 1: '以下は、左の値で決まる（直接は変えられない）' },
  vars: [
    { k: 'l', label: '長さ $l$', aria: '長さ', stops: [0.4, 0.6, 0.8, 1.0], prop: true, stopLabels: ['0.4', '0.6', '0.8', '1.0 m'], def: 0.6,   /* 4 つだけ（図の長さが見て分かるように。2026-11-05 千葉さん 7 回目） */ fmt: function (x) { return fmt(x, 2) + ' m'; } },
    { k: 'nw', label: 'おもりの個数（張力）', aria: 'おもりの個数', stops: [1, 2, 3, 4, 5, 6], prop: true, stopLabels: ['1', '2', '3', '4', '5', '6 個'], def: 6, fmt: function (x) { return x + ' 個（' + sig(x * M3S3.mW * M3S3.g, 3) + ' N）'; } },
    { k: 'tc', label: '気温 $t$', aria: '気温', stops: [-10, 0, 10, 15, 20, 30, 40], prop: true, stopLabels: ['−10', '0', '10', '', '20', '30', '40 ℃'], def: 15, fmt: function (x) { return String(x).replace('-', '−') + ' ℃'; } },
    meterVar('vv', '速さ $v$', '速さ', function (x) { return sig(x, 3) + ' m/s'; }, 360),
    meterVar('f1', '基本振動数 $f_1$', '基本振動数', function (x) { return sig(x, 3) + ' Hz'; }, 1800)
  ],
  disp: function (s, k) { var q = m3s3Q(s); if (k === 'vv') return q.v; if (k === 'f1') return q.f1; return s.v[k]; },
  /* 「管の口と腹を一致させる」は既定 OFF＝開口端補正を入れて、腹を管口の少し外に描く（2026-11-05 千葉さん 8 回目） */
  init: function (s) { s.ins = 'string'; s.mode3 = 'listen'; s.mi = 0; s.di = 0; s.fdr = 1; s.dmode = 'both'; s.mouthAB = false; s.exact = true; },
  onDefaults: function (s) { s.ins = 'string'; s.mode3 = 'listen'; s.mi = 0; s.di = 0; s.fdr = 1; s.dmode = 'both'; s.mouthAB = false; s.exact = true; m3s3Sync(s); },
  onChanged: function (s, k) { m3s3Sync(s); s.resound && s.resound(); return 'keepT'; },
  onReal: function (s) { m3s3Sync(s); },
  buttons: M3S3_INS.map(function (p) { return { k: 'n_' + p[0], label: p[1], seg: 'ins', segLabel: '楽器（共鳴体）', onClick: function (s) { m3s3SetIns(s, p[0]); } }; })
    .concat([
      { k: 'mL', label: '固有振動を聞く', seg: 'md', segLabel: 'モード', onClick: function (s) { s.mode3 = 'listen'; m3s3Sync(s); s.resound(); s.draw(); } },
      { k: 'mR', label: '共鳴を見る', seg: 'md', onClick: function (s) { s.mode3 = 'res'; m3s3Sync(s); s.resound(); s.draw(); } }
    ])
    .concat([0, 1, 2, 3].map(function (i) { return { k: 'm' + i, label: '基本振動', seg: 'mm', segLabel: '固有振動', onClick: function (s) { s.mi = i; m3s3Sync(s); s.resound(); s.draw(); } }; }))
    .concat(M3S3_DR.map(function (r, i) { return { k: 'd' + i, label: (r === 1 ? '' : r) + 'f₁', seg: 'dr', segLabel: '振動数', onClick: function (s) { s.di = i; m3s3Sync(s); s.resound(); s.draw(); } }; }))
    .concat([
      { k: 'dl', label: '元の縦波のみ', seg: 'dsp', segLabel: '管の中の表示', onClick: function (s) { s.dmode = 'long'; m3s3Sync(s); s.draw(); } },
      { k: 'dt', label: '横波表示のみ', seg: 'dsp', onClick: function (s) { s.dmode = 'trans'; m3s3Sync(s); s.draw(); } },
      { k: 'db', label: '両方重ねる', seg: 'dsp', onClick: function (s) { s.dmode = 'both'; m3s3Sync(s); s.draw(); } },
      { k: 'ex', label: '管の口と腹を一致させる', cls: 'chkb', onClick: function (s) { s.mouthAB = !s.mouthAB; s.exact = !s.mouthAB; m3s3Sync(s); s.draw(); } },
      /* 共鳴を見る（弦）：入射波・反射波を表示（本当の速さではないとき。2026-11-07 千葉さん 13 回目） */
      { k: 'cw', label: '入射波・反射波を表示', cls: 'chkb', onClick: function (s) { s.showCw = !s.showCw; m3s3Sync(s); s.draw(); } }
    ]),
  tEnd: function () { return M3_TEND; },
  tInfo: function (s) { var q = m3s3Q(s); return '<span class="tpl">基本振動数</span><b>' + tex('f_1 =') + ' ' + sig(q.f1, 3) + '</b> Hz'; },
  gT: function () { return 1; },
  height: function (s, w) { return m3s3Rows(s) ? (w < 520 ? 4 * 200 + 32 : Math.round(clamp(w * 0.5, 470, 560))) : Math.round(clamp(w * 0.5, 270, 330)) + 80; },   /* 下にマイク（オシロスコープ）の画面 */   /* 固有振動を聞く（弦・管）は 4 段 */
  afterBuild: function (s) {
    s.R.innerHTML = ''; var sw = el('div', 'row2 sliders inR'); sw.appendChild(s.varbox); s.R.appendChild(sw); s.varbox.classList.add('inR'); s._sw = sw;
    s.scope = new Scope(s.R, 'オシロスコープ');
    /* 4 段の図のスペクトル：線をクリックすると振動数を表示 */
    var nearS = function (ev) { var r = s.cv.getBoundingClientRect(), x = ev.clientX - r.left, y = ev.clientY - r.top, best = null; (s._spHits3 || []).forEach(function (o) { if (Math.abs(o.x - x) < 10 && y > o.y0 && y < o.y1) best = o; }); return best; };
    s.cv.addEventListener('pointermove', function (ev) { if (m3s3Rows(s)) s.cv.style.cursor = nearS(ev) ? 'pointer' : 'default'; });
    s.cv.addEventListener('click', function (ev) { if (!m3s3Rows(s)) return; var o = nearS(ev); s._spSel3 = o && !(s._spSel3 && s._spSel3.r === o.r && s._spSel3.n === o.n) ? { r: o.r, n: o.n } : null; s.draw(); });
    s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);
    var segs = s.row1b.querySelectorAll('.seg');
    s.segEl = { md: segs[1], mm: segs[2], dr: segs[3] };
    var lbD = el('span', 'seglbl', '管の中の表示'); segs[4].insertAdjacentElement('beforebegin', lbD); s.lblDSP = lblSeg(lbD, segs[4]);
    /* 共鳴を見る：スピーカー（振動子）の振動数。スライダーで選び、上の f₁・1.5f₁ … を押すとその振動数（2026-11-05 千葉さん 7 回目） */
    var dv = el('div', 'drvctl'), chips = el('div', 'drvchips'), rg = el('input'), dvv = el('div', 'drvval');
    rg.type = 'range'; rg.min = '0.75'; rg.max = '3.25'; rg.step = '0.01'; rg.value = '1'; rg.setAttribute('aria-label', 'スピーカーの振動数');
    M3S3_DR.forEach(function (r) { var b = el('button', 'b drvchip', (r === 1 ? '' : r) + 'f₁'); b.type = 'button'; b.style.left = 'calc(9px + (100% - 18px) * ' + ((r - 0.75) / 2.5).toFixed(4) + ')'; b.addEventListener('click', function () { s.fdr = r; m3s3DrvSync(s); s.resound(); s.draw(); }); chips.appendChild(b); });
    rg.addEventListener('input', function () { s.fdr = +rg.value; m3s3DrvSync(s); s.resound(); s.draw(); });
    dv.appendChild(dvv); dv.appendChild(chips); dv.appendChild(rg); s.scope.cv.insertAdjacentElement('beforebegin', dv); s.drv = dv; s.drvRg = rg; s.drvVal = dvv; s.drvChips = chips;
    [['楽器', 0], ['モード', 1], ['固有振動', 2], ['スピーカーの振動数', 3]].forEach(function (p) { var lb = el('span', 'seglbl', p[0]); segs[p[1]].insertAdjacentElement('beforebegin', lb); var g = lblSeg(lb, segs[p[1]]); if (p[1] === 2) s.lblMM = g; if (p[1] === 3) { s.lblDR = g; s.lblDRt = lb; } if (p[1] === 1) s.lblMD = g; });
    var sp = el('span', 'spkrow'); s.row1b.appendChild(sp);
    m3SpkBtn(s, sp, function () { return m3s3Voices(s); }); s.spkRow = sp;
    /* 4 段の図の左にならべる 🔊（基本振動・2 倍振動・3 倍振動・実際の振動） */
    s.rowSpk = [0, 1, 2, 3].map(function (i) {
      var b = el('button', 'b rowspk', '🔊<br>鳴らす'); b.type = 'button'; b.setAttribute('aria-label', '音を鳴らす');
      b.addEventListener('click', function () { m3s3RowSound(s, i); }); s.cw.appendChild(b); return b;
    });
    AUDIO.onChange(function () { m3s3RowSync(s); });
    m3s3Sync(s);
  },
  draw: function (s, ctx, W, H) { if (m3s3Rows(s)) drawM3S3Rows(s, ctx, W, H); else drawM3S3(s, ctx, W, H); m3s3Panel(s); },
  right: function (s, R) { rightM3S3(s, R); }
};
function m3s3SetIns(s, ins) {
  s.ins = ins; s.mi = 0; s.lowering = false;
  if (ins === 'string') s.v.l = 0.6; else if (ins === 'open') s.v.l = 0.8; else if (ins === 'closed') s.v.l = 0.6;
  s.resetT(); m3s3Sync(s); s.syncSliders && s.syncSliders(); s.resound(); s.draw();
}
/* 鳴らす音：聞く＝fₘ／共鳴＝スピーカーの振動数（音の大きさは共鳴の強さで）／水柱＝800 Hz（共鳴の強さで） */
function m3s3Voices(s) {
  var q = m3s3Q(s);
  if (s.mode3 === 'res') { var mx = 0; m3s3Resp(q, q.fd).forEach(function (o) { mx = Math.max(mx, o.a); }); return { voices: [{ f: q.fd }], vol: 0.12 + 0.88 * Math.min(1, mx) }; }
  return { voices: [{ f: q.fm }], vol: 0.8 };
}
function m3s3Sync(s) {
  var w = false, st = s.ins === 'string', q = m3s3Q(s);
  var a = M3S3_INS.map(function (p) { return ['n_' + p[0], s.ins === p[0]]; }).concat([['mL', s.mode3 === 'listen'], ['mR', s.mode3 === 'res'], ['ex', s.mouthAB]],
    [0, 1, 2, 3].map(function (i) { return ['m' + i, s.mi === i]; }), M3S3_DR.map(function (r, i) { return ['d' + i, s.di === i]; }), [['dl', s.dmode === 'long'], ['dt', s.dmode === 'trans'], ['db', s.dmode === 'both']]);
  m2Sync(s, a);
  var names = q.ms.map(function (m) { return m === 1 ? '基本振動' : m + ' 倍振動'; });
  [0, 1, 2, 3].forEach(function (i) { var b = s.extra['m' + i]; if (b && b.textContent !== names[i]) b.textContent = names[i]; });
  var show = function (e, on) { if (e) e.style.display = on ? '' : 'none'; };
  show(s.segEl && s.segEl.md, !w); show(s.lblMD, !w);
  show(s.segEl && s.segEl.mm, false); show(s.lblMM, false);          /* 固有振動は 4 段で全部見せるので、選ぶボタンはいらない */
  var rows = m3s3Rows(s); show(s.spkRow, !rows); show(s.scope && s.scope.box, !rows); m3TimeBar(s, false);
  /* 固有振動を聞く：右の列をなくして横長に。スライダーは図の上へ（2026-11-05 千葉さん 8 回目） */
  var art = document.getElementById('m3s3');
  if (art && s._sw) {
    art.classList.toggle('wide1', rows);
    if (rows && s._sw.parentNode !== s.L) { s.cw.insertAdjacentElement('beforebegin', s._sw); s._sw.classList.add('inL'); }
    if (!rows && s._sw.parentNode !== s.R) { s.R.insertBefore(s._sw, s.R.firstChild); s._sw.classList.remove('inL'); }
  }
  if (s.rowSpk) s.rowSpk.forEach(function (b) { b.style.display = rows ? '' : 'none'; });
  if (s._rowsWas !== undefined && s._rowsWas !== rows && s.resize) { s.resize(); }
  s._rowsWas = rows;
  m3s3RowSync(s);
  show(s.segEl && s.segEl.dr, false); show(s.lblDR, false);           /* 振動数はスピーカーの絵の上のスライダーで選ぶ */
  show(s.lblDSP, !w && !st && s.mode3 === 'listen');
  if (s.drv) { s.drv.style.display = !w && s.mode3 === 'res' ? '' : 'none'; m3s3DrvSync(s); }
  if (s.lblDRt) s.lblDRt.textContent = st ? '振動子の振動数' : 'スピーカーの振動数';
  show(s.extra.ex, !st); show(s.extra.cw, st && s.mode3 === 'res' && !s.real); if (s.extra.cw) { s.extra.cw.classList.toggle('on', !!s.showCw); s.extra.cw.setAttribute('aria-pressed', s.showCw ? 'true' : 'false'); }
  if (s.varbox) {
    var vis = { l: true, nw: st, tc: !st, vv: true, f1: true };
    Object.keys(vis).forEach(function (k) { var r = s.varbox.querySelector('.vrow[data-k="' + k + '"]'); if (r) r.style.display = vis[k] ? '' : 'none'; });
    var vl = s.varbox.querySelector('.vrow[data-k="vv"] .vl'); if (vl) { var tx = mathify(st ? '弦を伝わる波の速さ $v$' : '音速 $V$'); if (vl._h !== tx) { vl._h = tx; vl.innerHTML = tx; } }
  }
  if (s.spkMsg) s.spkMsg.classList.toggle('on', !WAVE.audible(m3s3Voices(s).voices[0].f));
  if (s.Rdyn) s.renderRight();
}
function drawM3S3(s, ctx, W, H) {
  var q = m3s3Q(s), t = s.t, nar = W < 520;
  /* 下の帯：マイク（オシロスコープ）で受けた音。大きさは共鳴の強さ */
  var Hf = H; H = H - 80;
  var rmax = 0; m3s3Resp(q, q.fd).forEach(function (o) { rmax = Math.max(rmax, o.a); });
  var sw2 = Math.min(260, W * 0.5), sx2 = W - sw2 - 6, my2 = H + 40;
  ctx.save(); ctx.strokeStyle = '#e6e2d8'; ctx.beginPath(); ctx.moveTo(6, H + 2); ctx.lineTo(W - 6, H + 2); ctx.stroke(); ctx.restore();
  label(ctx, 'オシロスコープ', sx2 - 12, my2 - 22, { size: 10.5, bold: true, color: COL.ink2, align: 'right' });
  label(ctx, rmax > 0.5 ? '共鳴して大きな音' : '小さな音', sx2 - 12, my2 - 4, { size: 10.5, color: rmax > 0.5 ? '#14653a' : COL.sub, align: 'right' });
  m3MiniScope(ctx, sx2, H + 8, sw2, 66, function (tt) { return (0.1 + 0.8 * Math.min(1, rmax)) * Math.sin(TAU * q.fd * tt); }, '横 1 目盛り 1 ms');
  var x0 = nar ? 44 : 74, xMax = W - (nar ? 40 : 60), SX = (xMax - x0) / 1.0, x1 = x0 + q.l * SX, cy = Math.round(H * (q.ins === 'string' ? 0.38 : 0.46));
  var X = function (x) { return x0 + x * SX; };
  var listen = s.mode3 === 'listen', fS = m3FS(s, 0.7);              /* 図の振動は 0.7 Hz に遅くして描く（本当の速さでは約 8 Hz） */
  var shapeAmp, terms;
  if (listen) terms = [{ m: q.m, a: 1 }];
  else terms = m3s3Resp(q, q.fd);
  var tot = 0; terms.forEach(function (o) { tot = Math.max(tot, o.a); });
  var yAt = function (x) { var y = 0; terms.forEach(function (o) { y += o.a * m3s3Shape(q.ins, o.m, q.l, x, s.exact); }); return y; };
  var amp = q.ins === 'string' ? 34 : 30, ph = Math.cos(TAU * fS * t);
  if (q.ins === 'string') {
    /* モノコード：両はしのこま・右の滑車・おもり */
    ctx.save(); ctx.fillStyle = '#c9a979'; rrect(ctx, x0 - 20, cy + 46, x1 - x0 + 60, 14, 4); ctx.fill(); ctx.restore();
    (listen ? [x0, x1] : [x1]).forEach(function (px) { ctx.save(); ctx.fillStyle = '#6b4a2a'; ctx.beginPath(); ctx.moveTo(px - 7, cy + 46); ctx.lineTo(px, cy); ctx.lineTo(px + 7, cy + 46); ctx.closePath(); ctx.fill(); ctx.restore(); });   /* 共鳴を見るときは、左はしが振動子 */
    var pr = 9, pxp = x1 + 26;
    ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(pxp, cy + pr, pr, 0, TAU); ctx.stroke(); ctx.beginPath(); ctx.moveTo(x1, cy); ctx.lineTo(pxp, cy); ctx.moveTo(pxp + pr, cy + pr); ctx.lineTo(pxp + pr, cy + 64); ctx.stroke(); ctx.restore();
    for (var k = 0; k < s.v.nw; k++) { ctx.save(); ctx.fillStyle = '#5b6470'; rrect(ctx, pxp + pr - 9, cy + 64 + k * 9, 18, 7.5, 2); ctx.fill(); ctx.restore(); }
    label(ctx, 'おもり ' + s.v.nw + ' 個', pxp + pr - 6, cy + 76 + s.v.nw * 9, { size: 10.5, color: COL.ink2, align: 'left' });
    /* 弦（振動のはばを点線で、いまの形を実線で） */
    if (!listen) { m3s3DrivenString(s, ctx, q, X, cy, amp, t); }
    else if (listen || tot > 0.05) { plotF(ctx, function (x) { return yAt(x) / Math.max(1, tot); }, 0, q.l, X, function (y) { return cy - y * amp; }, 'rgba(122,59,18,.35)', 1, [3, 3]); plotF(ctx, function (x) { return -yAt(x) / Math.max(1, tot); }, 0, q.l, X, function (y) { return cy - y * amp; }, 'rgba(122,59,18,.35)', 1, [3, 3]); }
    if (listen) plotF(ctx, function (x) { return yAt(x) / Math.max(1, tot) * ph * Math.min(1, tot); }, 0, q.l, X, function (y) { return cy - y * amp; }, '#7a3b12', 2.6);
  } else {
    /* 管：上下の壁。開管は両はしが開いている、閉管は右はしが閉じている */
    var tr = 30;
    ctx.save(); ctx.fillStyle = 'rgba(160,200,230,.18)'; ctx.fillRect(x0, cy - tr, x1 - x0, 2 * tr); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(x0, cy - tr); ctx.lineTo(x1, cy - tr); ctx.moveTo(x0, cy + tr); ctx.lineTo(x1, cy + tr); if (q.ins === 'closed') { ctx.moveTo(x1, cy - tr); ctx.lineTo(x1, cy + tr); } ctx.stroke(); ctx.restore();
    /* 空気の粒（縦波）：変位は形 × 時間の変化。横に動く */
    ctx.save(); ctx.fillStyle = 'rgba(58,65,76,.6)';
    for (var i = 0; i <= 50; i++) { var xe = q.l * i / 50, u = yAt(xe) / Math.max(1, tot) * ph * Math.min(1, tot) * 0.018 * q.l / (q.m || 1); for (var j = 0; j < 4; j++) { ctx.beginPath(); ctx.arc(X(xe + u), cy - tr + 2 * tr * (j + 0.5) / 4, 1.7, 0, TAU); ctx.fill(); } }
    ctx.restore();
    /* 横波表示した変位（管の下）。点線＝振動のはば、実線＝いま */
    var by = cy + tr + 50, ba = 26;
    label(ctx, '空気の変位（横波表示）', x0, by - ba - 12, { size: 10.5, bold: true, color: COL.ink2, align: 'left' });
    ctx.save(); ctx.strokeStyle = '#c9ced6'; ctx.beginPath(); ctx.moveTo(x0 - (s.exact ? 20 : 0), by); ctx.lineTo(x1 + (q.ins === 'open' && s.exact ? 20 : 0), by); ctx.stroke(); ctx.restore();
    var ext0 = s.exact ? -0.6 * M3S3.r : 0, ext1 = q.l + (q.ins === 'open' && s.exact ? 0.6 * M3S3.r : 0);
    if (listen || tot > 0.05) { plotF(ctx, function (x) { return yAt(x) / Math.max(1, tot); }, ext0, ext1, X, function (y) { return by - y * ba; }, 'rgba(122,59,18,.4)', 1, [3, 3]); plotF(ctx, function (x) { return -yAt(x) / Math.max(1, tot); }, ext0, ext1, X, function (y) { return by - y * ba; }, 'rgba(122,59,18,.4)', 1, [3, 3]); }
    plotF(ctx, function (x) { return yAt(x) / Math.max(1, tot) * ph * Math.min(1, tot); }, ext0, ext1, X, function (y) { return by - y * ba; }, '#7a3b12', 2.4);
    if (!listen) { var spx = x0 - 30; ctx.save(); ctx.fillStyle = '#3a414c'; rrect(ctx, spx - 14, cy - 12, 10, 24, 2); ctx.fill(); ctx.beginPath(); ctx.moveTo(spx - 4, cy - 12); ctx.lineTo(spx + 8, cy - 24); ctx.lineTo(spx + 8, cy + 24); ctx.lineTo(spx - 4, cy + 12); ctx.closePath(); ctx.fillStyle = '#69717d'; ctx.fill(); ctx.restore(); label(ctx, 'スピーカー', spx, cy + 38, { size: 10, color: COL.ink2, bold: true }); }
    if (s.exact) { label(ctx, '腹は管口より少し外（開口端補正）', x0, cy - tr - 14, { size: 10.5, color: '#9c4e06', align: 'left' }); }
  }
  /* 腹・節の名札（いま見ている形で） */
  if (listen) {
    var ybase = q.ins === 'string' ? cy + 74 : cy + 30 + 50 + 26 + 16;
    var lo = q.ins === 'string' ? 0 : (s.exact ? -0.6 * M3S3.r : 0), hi = q.ins === 'open' && s.exact ? q.l + 0.6 * M3S3.r : q.l;
    for (var p = 0; p <= 400; p++) {
      var x = lo + (hi - lo) * p / 400, xa = lo + (hi - lo) * (p - 1) / 400, xb = lo + (hi - lo) * (p + 1) / 400, v0 = Math.abs(m3s3Shape(q.ins, q.m, q.l, x, s.exact));
      if (p > 0 && p < 400) {
        var va = Math.abs(m3s3Shape(q.ins, q.m, q.l, xa, s.exact)), vb = Math.abs(m3s3Shape(q.ins, q.m, q.l, xb, s.exact));
        if (v0 < va && v0 <= vb && v0 < 0.05) label(ctx, '節', X(x), ybase, { size: 11.5, bold: true, color: '#5a2f99' });
        if (v0 > va && v0 >= vb && v0 > 0.95) label(ctx, '腹', X(x), ybase, { size: 11.5, bold: true, color: '#14653a' });
      }
      if ((p === 0 || p === 400) && (v0 < 0.05 || v0 > 0.95)) label(ctx, v0 < 0.05 ? '節' : '腹', X(x), ybase, { size: 11.5, bold: true, color: v0 < 0.05 ? '#5a2f99' : '#14653a' });
    }
  } else {
    var big = s.ins === 'string' ? s._dsBig : tot > 0.5;
    label(ctx, (s.ins === 'string' ? '振動子' : 'スピーカー') + 'の振動数 ' + m3s3Rt(s) + ' = ' + sig(q.fd, 3) + ' Hz：' + (big ? '固有振動数と同じ → 共鳴して大きく振動する' : '固有振動数とちがう → ほとんど振動しない'), W / 2, 14, { size: 12, bold: true, color: big ? '#14653a' : '#6b3a0a' });
  }
  /* 長さの寸法 */
  var dl = dimH(ctx, X(0), X(q.l), H - 18, '#3a414c', 'l', { ticks: false }); label(ctx, '= ' + fmt(q.l, 2) + ' m', (X(0) + X(q.l)) / 2 + 9, H - 29, { size: 12, color: '#3a414c', align: 'left' });
  if (listen) label(ctx, s.real ? '本当の速さに近づけた（実際はもっと速い）' : '図の振動はゆっくり（実際はもっと速い）', W - 8, 14, { size: 10, color: s.real ? '#c9670c' : COL.sub, bold: !!s.real, align: 'right' });
}
/* 右の装置：聞く＝オシロスコープ／共鳴＝スピーカー（振動子）／水柱＝気柱の長さと音の大きさのグラフ */
function m3s3Panel(s) {
  var sc = s.scope; if (!sc || !sc.cv.offsetParent) return;
  var q = m3s3Q(s), W = Math.max(240, Math.floor(sc.cv.clientWidth || 300)), H = Math.round(clamp(W * 0.55, 150, 210)), ctx = prep(sc.cv, W, H);
  var title = sc.box.querySelector('.scopet'), cap, mode = s.mode3;
  sc.box.classList.toggle('light', mode !== 'listen');
  ctx.clearRect(0, 0, W, H);
  if (mode === 'listen') {
    title.textContent = 'オシロスコープ（' + (q.m === 1 ? '基本振動' : q.m + ' 倍振動') + 'の音）';
    sc.screen(ctx, 0, 0, W, H, { t0: 0, span: 0.010, yMax: 1, traces: [{ f: function (t) { return 0.8 * Math.sin(TAU * q.fm * t); }, fmax: q.fm }], label: '横 1 目盛り 1 ms', labelR: sig(q.fm, 3) + ' Hz' });
    cap = '$f_{' + q.m + '} = ' + sig(q.fm, 3) + '$ Hz（基本振動数の ' + q.m + ' 倍）';
  } else if (mode === 'res') {
    var stg = s.ins === 'string';
    title.textContent = stg ? '振動子（弦を揺らす）' : 'スピーカー（管の口で鳴らす）';
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H);
    var cx = W * 0.3, cy = H / 2, ph = Math.sin(TAU * m3FS(s, 0.7) * s.t);
    if (stg) { ctx.save(); ctx.fillStyle = '#e07b18'; rrect(ctx, cx - 26, cy - 18 + 6 * ph, 52, 36, 6); ctx.fill(); ctx.fillStyle = '#3a414c'; ctx.fillRect(cx - 4, cy + 18 + 6 * ph, 8, 40); ctx.restore(); }
    else { ctx.save(); ctx.fillStyle = '#3a414c'; rrect(ctx, cx - 40, cy - 22, 22, 44, 4); ctx.fill(); ctx.beginPath(); ctx.moveTo(cx - 18 + 4 * ph, cy - 22); ctx.lineTo(cx + 20 + 4 * ph, cy - 50); ctx.lineTo(cx + 20 + 4 * ph, cy + 50); ctx.lineTo(cx - 18 + 4 * ph, cy + 22); ctx.closePath(); ctx.fillStyle = '#69717d'; ctx.fill(); ctx.restore(); }
    label(ctx, '振動数', W * 0.58, cy - 20, { size: 12, color: COL.ink2, align: 'left' });
    label(ctx, sig(q.fd, 3) + ' Hz', W * 0.58, cy + 6, { size: 20, bold: true, color: COL.ink, align: 'left' });
    label(ctx, '（' + m3s3Rt(s) + '）', W * 0.58, cy + 30, { size: 12, color: COL.ink2, align: 'left' });
    cap = 'スライダーで振動数を変える（上の $f_1$・$1.5f_1$ … を押すと、その振動数）';
  }
  if (sc.cap._h !== cap) { sc.cap._h = cap; sc.cap.innerHTML = mathify(cap); }
}
/* 共鳴を見る（弦）：左はしを振動子で y = a sin ωt と揺すり、右はしは固定。減衰を入れた定常状態の本当の式
   y(x, t) = a・Im[ sin k(l − x) / sin kl ・e^{iωt} ]、k l = π f/f₁ − i b（b：減衰の大きさ。共振のとき振幅は約 1/sinh b 倍）
   x = 0 では必ず y = a sin ωt になるので、弦と振動子はつながったまま（2026-11-05 千葉さん 8 回目） */
var M3S3_B = Math.PI / 16;
function m3s3DrivenY(q, x, dir) {
  var a = Math.PI * q.fd / q.f1, b = M3S3_B, u = (q.l - x) / q.l;
  if (dir) {
    /* sin z = (e^{iz} − e^{−iz})/(2i)。dir = 1：e^{ik(l−x)}/(2i sin kl)（右向き＝入射波）、dir = −1：−e^{−ik(l−x)}/(2i sin kl)（左向き＝反射波） */
    var er = Math.exp(dir * b * u), nr2 = dir * er * Math.cos(a * u), ni2 = er * Math.sin(a * u);   /* dir·e^{±i(a−ib)u} */
    var sr = Math.sin(a) * Math.cosh(b), si = -Math.cos(a) * Math.sinh(b), Dr = -2 * si, Di = 2 * sr, DD = Dr * Dr + Di * Di;
    return { re: (nr2 * Dr + ni2 * Di) / DD, im: (ni2 * Dr - nr2 * Di) / DD };
  }
  var nr = Math.sin(a * u) * Math.cosh(b * u), ni = -Math.cos(a * u) * Math.sinh(b * u);
  var dr = Math.sin(a) * Math.cosh(b), di = -Math.cos(a) * Math.sinh(b), dd = dr * dr + di * di;
  return { re: (nr * dr + ni * di) / dd, im: (ni * dr - nr * di) / dd };
}
function m3s3DrivenString(s, ctx, q, X, cy, amp, t) {
  var aPx = amp * Math.sinh(M3S3_B), th = TAU * m3FS(s, 0.7) * t, mx = 0;   /* 共振したときの振幅が amp になる大きさ */
  var yN = function (x) { var c = m3s3DrivenY(q, x); return c.re * Math.sin(th) + c.im * Math.cos(th); };
  var yE = function (x) { var c = m3s3DrivenY(q, x); return Math.hypot(c.re, c.im); };
  for (var i = 0; i <= 60; i++) mx = Math.max(mx, yE(q.l * i / 60));
  s._dsBig = mx > 2.5;
  [1, -1].forEach(function (sg) { plotF(ctx, function (x) { return sg * yE(x); }, 0, q.l, X, function (y) { return cy - y * aPx; }, 'rgba(122,59,18,.35)', 1, [3, 3]); });
  if (s.showCw && !s.real) {                                          /* 入射波（右向き）と反射波（左向き）。2 つの和が弦の形 */
    [1, -1].forEach(function (dir) { plotF(ctx, function (x) { var c = m3s3DrivenY(q, x, dir); return c.re * Math.sin(th) + c.im * Math.cos(th); }, 0, q.l, X, function (y) { return cy - y * aPx; }, dir > 0 ? M2C.R : M2C.L, 1.8, [6, 4]); });
    legendRow(ctx, [{ col: M2C.R, dash: [6, 4], txt: '入射波（右向き）' }, { col: M2C.L, dash: [6, 4], txt: '反射波（左向き）' }, { col: '#7a3b12', lw: 2.6, txt: '弦（2 つの和）' }], X(0), 36);
  }
  plotF(ctx, yN, 0, q.l, X, function (y) { return cy - y * aPx; }, '#7a3b12', 2.6);
  vibBox(ctx, X(0), cy - yN(0) * aPx, cy + 30, { label: false });
  label(ctx, '振動子', X(0) - 11, cy - 24, { size: 10.5, bold: true, color: '#9c4e06' });
}
/* 振動数の倍率の書き方（f₁・1.5f₁・1.73f₁ …） */
function m3s3Rt(s) { var r = s.fdr || 1; return Math.abs(r - 1) < 1e-9 ? 'f₁' : (Math.abs(r * 2 - Math.round(r * 2)) < 1e-9 ? String(r) : r.toFixed(2)) + 'f₁'; }
function m3s3DrvSync(s) {
  if (!s.drv) return; var q = m3s3Q(s);
  if (+s.drvRg.value !== s.fdr) s.drvRg.value = String(s.fdr);
  s.drvRg.style.setProperty('--p', ((s.fdr - 0.75) / 2.5 * 100).toFixed(1) + '%');
  var h = (s.ins === 'string' ? '振動子' : 'スピーカー') + 'の振動数　<b>' + sig(q.fd, 3) + ' Hz</b>（' + m3s3Rt(s) + '）';
  if (s.drvVal._h !== h) { s.drvVal._h = h; s.drvVal.innerHTML = h; }
  [].forEach.call(s.drvChips.children, function (b, i) { b.classList.toggle('on', Math.abs(M3S3_DR[i] - s.fdr) < 1e-9); });
}
/* 4 段の図を出すか（弦・開管・閉管で「固有振動を聞く」） */
function m3s3Rows(s) { return s.mode3 === 'listen'; }
var M3S3_MIX = [1, 0.6, 0.4];                                        /* 実際の振動：3 つの固有振動の大きさの割合（図と音で同じ） */
function m3s3Three(q) { return q.ins === 'closed' ? [1, 3, 5] : [1, 2, 3]; }
function m3s3RowSound(s, i) {
  var q = m3s3Q(s), ms = m3s3Three(q);
  if ((AUDIO.owner() === 'm3s3' || s._resume) && s.rowPlay === i) { AUDIO.stop(); s._resume = null; m3s3RowSync(s); return; }
  s.rowPlay = i;
  m3Sound(s, function () {
    var q2 = m3s3Q(s), m2 = m3s3Three(q2);
    return i < 3 ? { voices: [{ f: m2[i] * q2.f1 }], vol: 0.8 } : { voices: [{ f: q2.f1, partials: m2.map(function (m, k) { return [m, M3S3_MIX[k]]; }) }], vol: 0.8 };
  });
  m3s3RowSync(s);
}
function m3s3RowSync(s) {
  if (!s.rowSpk) return;
  var on = AUDIO.owner() === 'm3s3' || !!s._resume;
  s.rowSpk.forEach(function (b, i) { var p = on && s.rowPlay === i, h = p ? '■<br>止める' : '🔊<br>鳴らす'; if (b._h !== h) { b._h = h; b.innerHTML = h; } b.classList.toggle('on', p); b.classList.toggle('glow', !on); });   /* どれも鳴っていないときは全部光らせる */
}
/* マイクで受けた音の小さなオシロスコープの画面（キャンバスの中） */
function m3MiniScope(ctx, x, y, w, h, f, label1) {
  Scope.prototype.screen(ctx, x, y, w, h, { t0: 0, span: 0.010, yMax: 1, traces: [{ f: f, fmax: 3000 }], label: label1 || '' });
}
/* 固有振動を聞く：基本振動・2 倍振動・3 倍振動（閉管は 1・3・5 倍）と「実際の振動」（3 つの重ね合わせ）を縦に 4 段。
   各段：左に 🔊、まん中に弦・管の振動（ゆっくり）、右にマイク（オシロスコープ）の画面（横 1 目盛り 1 ms） */
function drawM3S3Rows(s, ctx, W, H) {
  var q = m3s3Q(s), t = s.t, nar = W < 520, ms = m3s3Three(q), top = 26, rh = (H - top - 6) / 4, tube = q.ins !== 'string';
  /* 広い画面：1 段に［🔊｜振動｜マイク｜オシロスコープ｜スペクトル］。せまい画面：振動の下にオシロスコープとスペクトル */
  var spw = Math.round(W * 0.15), sw = Math.round(W * 0.26), px0 = W - spw - 6, sx0 = px0 - sw - 6;
  if (nar) { sw = Math.round((W - 22) * 0.64); sx0 = 8; spw = W - 22 - sw; px0 = sx0 + sw + 6; }
  var ax0 = nar ? 62 : 74, axMax = (nar ? W - 34 : sx0 - 42) - (tube ? 0 : 18), fS = s.real ? 2.2 : 0.5;   /* 本当の速さ：5 倍振動でも 1 秒に 11 回まで */
  var ax1 = ax0 + (axMax - ax0) * q.l / 1.0;                          /* 長さ l に比例（l = 1.0 m で図の幅いっぱい。2026-11-05 千葉さん 7 回目） */
  var X = function (x) { return ax0 + x / q.l * (ax1 - ax0); }, ex = s.exact ? 0.6 * M3S3.r : 0, arr = true;
  var dm = s.dmode || 'both', showP = tube && dm !== 'trans', showC = !tube || dm !== 'long';
  label(ctx, s.real ? (nar ? '本当の速さに近づけた' : '本当の速さに近づけた（実際はもっと速い）') : (nar ? '図の振動はゆっくり' : '図の振動はゆっくり（実際はもっと速い）'), W - 6, 11, { size: 10.5, color: s.real ? '#c9670c' : COL.sub, bold: !!s.real, align: 'right' });
  for (var r = 0; r < 4; r++) {
    var y0 = top + r * rh, ah = nar ? rh * 0.5 : rh, cy = y0 + ah * 0.54, amp = ah * 0.24;
    var scY = nar ? y0 + ah + 2 : y0 + 6, scH = nar ? rh - ah - 10 : rh - 12;
    var terms = r < 3 ? [{ m: ms[r], a: 1 }] : ms.map(function (m, k) { return { m: m, a: M3S3_MIX[k] }; });
    var norm = 0; terms.forEach(function (o) { norm += o.a; });
    var shapeT = function (x, tt) { var y = 0; terms.forEach(function (o) { y += o.a * m3s3Shape(q.ins, o.m, q.l, x, s.exact) * Math.cos(TAU * o.m * fS * tt); }); return y / norm; };
    if (r) { ctx.save(); ctx.strokeStyle = '#e6e2d8'; ctx.beginPath(); ctx.moveTo(6, y0); ctx.lineTo(W - 6, y0); ctx.stroke(); ctx.restore(); }
    var name = r < 3 ? (ms[r] === 1 ? '基本振動' : ms[r] + ' 倍振動') : '実際の振動', fr = r < 3 ? ms[r] * q.f1 : q.f1;
    if (r === 0) { if (nar) label(ctx, '下：オシロスコープとスペクトル', 8, 11, { size: 10, bold: true, color: COL.ink2, align: 'left' }); else label(ctx, 'オシロスコープ', sx0 + 4, y0 - 5, { size: 10, bold: true, color: COL.ink2, align: 'left' }); }
    label(ctx, name + (r < 3 ? '　f' + '₁₂₃₄₅'[ms[r] - 1] + ' = ' + sig(fr, 3) + ' Hz' : (nar ? '' : '（上の 3 つの重ね合わせ）')), ax0, y0 + 12, { size: 11.5, bold: true, color: r < 3 ? COL.ink : '#9c4e06', align: 'left' });
    var lo = tube ? -ex : 0, hi = q.ins === 'open' ? q.l + ex : q.l;
    if (!tube) {
      [0, q.l].forEach(function (x) { ctx.save(); ctx.fillStyle = '#6b4a2a'; ctx.beginPath(); ctx.moveTo(X(x) - 5, cy + amp + 6); ctx.lineTo(X(x), cy); ctx.lineTo(X(x) + 5, cy + amp + 6); ctx.closePath(); ctx.fill(); ctx.restore(); });
      /* 右はしの滑車とおもり（弦の張力。おもりの個数のとおり） */
      var pr = 5, pxp = X(q.l) + 12;
      ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(X(q.l), cy); ctx.lineTo(pxp, cy); ctx.stroke(); ctx.beginPath(); ctx.arc(pxp, cy + pr, pr, 0, TAU); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(pxp + pr, cy + pr); ctx.lineTo(pxp + pr, cy + amp * 0.5); ctx.stroke(); ctx.fillStyle = '#5b6470';
      for (var k = 0; k < s.v.nw; k++) rrect(ctx, pxp + pr - 5, cy + amp * 0.5 + 1 + k * 4.2, 10, 3.4, 1), ctx.fill();
      ctx.restore();
    } else {
      var tr = amp + 6;
      ctx.save(); ctx.fillStyle = 'rgba(160,200,230,.16)'; ctx.fillRect(X(0), cy - tr, X(q.l) - X(0), 2 * tr); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 2.4; ctx.beginPath();
      ctx.moveTo(X(0), cy - tr); ctx.lineTo(X(q.l), cy - tr); ctx.moveTo(X(0), cy + tr); ctx.lineTo(X(q.l), cy + tr); if (q.ins === 'closed') { ctx.moveTo(X(q.l), cy - tr); ctx.lineTo(X(q.l), cy + tr); } ctx.stroke(); ctx.restore();
      /* 元の縦波：空気の粒（赤）。変位は横向き（2026-11-05 千葉さん 7 回目：添付図 3） */
      if (showP) {
        var nc = Math.max(8, Math.round((X(q.l) - X(0)) / 12)), umax = (X(q.l) - X(0)) / nc * 0.42;
        ctx.save(); ctx.fillStyle = showC ? 'rgba(209,53,43,.55)' : '#d1352b';
        for (var c = 0; c <= nc; c++) { var xe = q.l * (c + 0.5) / (nc + 1), pxe = X(xe) + umax * shapeT(xe, t); for (var j = 0; j < 5; j++) { ctx.beginPath(); ctx.arc(pxe, cy - tr + 2 * tr * (j + 0.5) / 5, 2.2, 0, TAU); ctx.fill(); } }
        ctx.restore();
      }
    }
    /* 振動のはば（点線。1 つの振動の段だけ）といまの形（横波表示） */
    if (showC) {
      if (r < 3) [1, -1].forEach(function (sg) { plotF(ctx, function (x) { return sg * m3s3Shape(q.ins, ms[r], q.l, x, s.exact); }, lo, hi, X, function (y) { return cy - y * amp; }, 'rgba(122,59,18,.35)', 1, [3, 3]); });
      plotF(ctx, function (x) { return shapeT(x, t); }, lo, hi, X, function (y) { return cy - y * amp; }, r < 3 ? (tube ? '#173a63' : '#7a3b12') : '#b5482a', 2.4);
    }
    /* 腹・節（1 つの振動の段） */
    if (r < 3) for (var p = 0; p <= 200; p++) {
      var xx = lo + (hi - lo) * p / 200, v0 = Math.abs(m3s3Shape(q.ins, ms[r], q.l, xx, s.exact)), va = p ? Math.abs(m3s3Shape(q.ins, ms[r], q.l, xx - (hi - lo) / 200, s.exact)) : 2, vb = p < 200 ? Math.abs(m3s3Shape(q.ins, ms[r], q.l, xx + (hi - lo) / 200, s.exact)) : 2;
      if (v0 < 0.04 && v0 <= va && v0 <= vb) label(ctx, '節', X(xx), cy + amp + 16, { size: 10, bold: true, color: '#5a2f99' });
      if (v0 > 0.97 && (p === 0 || p === 200 || (v0 >= va && v0 >= vb))) label(ctx, '腹', X(xx), cy + amp + 16, { size: 10, bold: true, color: '#14653a' });
    }
    /* マイク → オシロスコープの画面 → スペクトル */
    /* マイクの絵は描かない（2026-11-06 千葉さん 10 回目） */
    var fT = r < 3 ? (function (fm) { return function (tt) { return 0.85 * Math.sin(TAU * fm * tt); }; })(fr)
                   : function (tt) { var y = 0; ms.forEach(function (m, k) { y += M3S3_MIX[k] * Math.sin(TAU * m * q.f1 * tt); }); return 0.85 * y / 1.4; };
    Scope.prototype.screen(ctx, sx0, scY, sw, scH, { t0: 0, span: 0.010, yMax: 1, traces: arr ? [{ f: fT, fmax: 3000 }] : [], label: r === 0 ? '横 1 目盛り 1 ms' : '' });
    /* スペクトル（右の列にはみ出してよい：2026-11-05 千葉さん 7 回目。ここでは図の中に置く） */
    if (r === 0) s._spHits3 = [];
    m3SpecMini(ctx, px0, scY, spw, scH, q.f1, r < 3 ? [[ms[r], 1]] : ms.map(function (m, k) { return [m, M3S3_MIX[k]]; }), arr, r === 3, { s: s, r: r });
    var b = s.rowSpk && s.rowSpk[r]; if (b) { var tp = Math.round(cy - 20) + 'px'; if (b.style.top !== tp) b.style.top = tp; }
  }
}
/* 小さなスペクトル：横軸は f₁ の何倍か（1〜6）。ratio＝比も書く（実際の振動） */
function m3SpecMini(ctx, x, y, w, h, f1, parts, arr, ratio, hk) {
  ctx.save(); ctx.fillStyle = '#0d1a14'; rrect(ctx, x, y, w, h, 6); ctx.fill();
  var bx0 = x + 8, bx1 = x + w - 8, by1 = y + h - 16, by0 = y + 30, NX = 6, XF = function (n) { return bx0 + (n - 0.5) / NX * (bx1 - bx0); };
  ctx.strokeStyle = 'rgba(120,220,170,.3)'; ctx.beginPath(); ctx.moveTo(bx0, by1 + 0.5); ctx.lineTo(bx1, by1 + 0.5); ctx.stroke();
  ctx.font = '600 9px ' + FONT; ctx.fillStyle = 'rgba(190,240,215,.85)'; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
  for (var n = 1; n <= NX; n++) ctx.fillText(String(n), XF(n), by1 + 3);
  ctx.textAlign = 'left'; ctx.fillText('スペクトル（f₁ の何倍か）', x + 6, y + 4);
  if (arr) {
    var mx = 0; parts.forEach(function (p) { mx = Math.max(mx, p[1]); });
    ctx.fillStyle = '#7dffb4'; ctx.shadowColor = '#7dffb4'; ctx.shadowBlur = 5;
    var sel = hk && hk.s._spSel3 && hk.s._spSel3.r === hk.r ? hk.s._spSel3.n : null;
    parts.forEach(function (p) {
      if (p[0] > NX) return; var hh = p[1] / mx * (by1 - by0);
      ctx.fillStyle = p[0] === sel ? '#ffd678' : '#7dffb4'; ctx.shadowColor = ctx.fillStyle; ctx.fillRect(XF(p[0]) - 3, by1 - hh, 6, hh);
      if (hk) hk.s._spHits3.push({ x: XF(p[0]), y0: y, y1: y + h, r: hk.r, n: p[0] });   /* クリックで振動数を表示 */
    });
    ctx.shadowBlur = 0;
    if (sel) { var tt = sel + 'f₁ = ' + Math.round(sel * f1) + ' Hz'; ctx.font = '700 10px ' + FONT; var tw = ctx.measureText(tt).width + 10, tx = clamp(XF(sel) - tw / 2, x + 3, x + w - tw - 3); ctx.fillStyle = '#ffd678'; rrect(ctx, tx, y + 15, tw, 15, 4); ctx.fill(); ctx.fillStyle = '#2a2006'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(tt, tx + 5, y + 22.5); ctx.textBaseline = 'top'; }
    if (ratio) { ctx.textAlign = 'center'; ctx.fillStyle = '#ffd678'; ctx.font = '700 9.5px ' + FONT; parts.forEach(function (p) { if (p[0] <= NX) ctx.fillText(String(p[1]), XF(p[0]), by1 - p[1] / mx * (by1 - by0) - 12); }); }
  }
  ctx.restore();
}
function rightM3S3(s, R) { R.innerHTML = ''; }   /* 弦・開管・閉管では説明カードを出さない（2026-11-04 千葉さん 6 回目） */
