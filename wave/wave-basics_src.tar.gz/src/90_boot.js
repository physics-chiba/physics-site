/* ===== 90_boot.js ===== */
/* =========================================================================
   90_boot.js … 自動テスト用の窓口（window.TEST）と、物理の検算 check()
   千葉さんのプロンプト §5 の検算値（章 ① のぶん）と、波の作り方（y(x, t) = y₀(t − x/v)）の確かめ
   ========================================================================= */
'use strict';
function check() {
  var out = {}, near = function (a, b, tol) { return Math.abs(a - b) <= (tol || 1e-9) * Math.max(1, Math.abs(b)); };
  /* ①-1：λ = 2.0 m、v = 4.0 m/s → f = 2.0 Hz、T = 0.50 s（いまは f が変数なので、f = 2.0 Hz・v = 4.0 m/s → λ = 2.0 m・T = 0.50 s で確かめる）。既定 v = 2 m/s */
  var q1 = m1s1Q({ v: { A: 0.2, f: 2.0, v: 4.0 } });
  out.m1s1_lam = +q1.lam.toFixed(6); out.m1s1_T = +q1.T.toFixed(6);
  out.m1s1_ok = near(q1.lam, 2.0) && near(q1.T, 0.5) && near(q1.v / q1.lam, 2.0) && M1.s1.v0 === 2.0;
  /* ①-2：f = 2.0 Hz、λ = 0.50 m → v = 1.0 m/s、T = 1/f = 0.50 s（①-2 はスライダーなし。f = 1.25 Hz なら T = 0.8 s） */
  var s2 = { v: { A: 0.1, lam: 0.5, f: 2.0 }, dir: 1, x0i: 2 };
  var q2 = m1s2Q(s2); out.m1s2_v = +q2.v.toFixed(6);
  var q2b = m1s2Q({ v: { A: 0.1, lam: 0.5, f: 1.25 }, dir: 1, x0i: 2 });
  out.m1s2_ok = near(q2.v, 1.0) && near(q2.T, 0.5) && near(q2b.T, 0.8);
  /* ①-2：原点の左の等速円運動の高さ A sin θ と、原点の変位 y(0, t) が全時刻で一致（向き 2 つ × t = 0 の波形 4 つ） */
  var eC = 0;
  [1, -1].forEach(function (dir) { [0, 1, 2, 3].forEach(function (k) {
    var s = { v: { A: 0.1, lam: 0.5, f: 2.0 }, dir: dir, x0i: k }, q = m1s2Q(s), ph = SINE.phase(q.lam, q.dir, q.x0, 0);
    for (var t = 0; t < 2; t += 0.0137) eC = Math.max(eC, Math.abs(q.A * Math.sin(TAU * q.f * t + ph) - SINE.y(q.A, q.lam, q.f, q.dir, q.x0, 0, t)));
  }); });
  out.m1s2_circle_vs_origin = +eC.toExponential(2);
  /* ①-2：媒質の速度 dy/dt（数値微分と一致） */
  var eV = 0;
  for (var t2 = 0.01; t2 < 1; t2 += 0.031) { var h = 1e-6, num = (SINE.y(0.1, 0.5, 2, -1, 0.125, 0.3, t2 + h) - SINE.y(0.1, 0.5, 2, -1, 0.125, 0.3, t2 - h)) / (2 * h); eV = Math.max(eV, Math.abs(num - SINE.vy(0.1, 0.5, 2, -1, 0.125, 0.3, t2))); }
  out.m1s2_dydt_err = +eV.toExponential(2);
  /* 波源の記録から作った波 y₀(t − x/v) が、波の式 A sin 2π(t/T − x/λ) と一致（届いている所） */
  var src = SRC.make(); src.pieces.push({ k: 'sin', t0: 0, t1: Infinity, A: 0.2, f: 2.0, ph0: 0 });
  var eW = 0;
  for (var t3 = 0; t3 < 4; t3 += 0.0173) for (var x = 0; x <= 8; x += 0.0731) {
    var ref = (t3 - x / 4.0) < 0 ? 0 : 0.2 * Math.sin(TAU * (t3 / 0.5 - x / 2.0));
    eW = Math.max(eW, Math.abs(waveY(src, 4.0, x, t3) - ref));
  }
  out.wave_vs_formula = +eW.toExponential(2);
  /* 山は速さ v で進み（0.05 s で 0.20 m）、山と山の間は λ。1 周期 T（0.5 s）の間に、波の先頭は 1 波長 λ 進む */
  var c0 = crestsOf(function (x) { return waveY(src, 4.0, x, 3.0); }, 0.01, 7.9, 0.001, 0.19), c1 = crestsOf(function (x) { return waveY(src, 4.0, x, 3.05); }, 0.01, 7.9, 0.001, 0.19);
  out.crest_speed = c0.length && c1.length ? +((c1[0] - c0[0]) / 0.05).toFixed(3) : null;
  out.crest_spacing = c0.length > 1 ? +(c0[1] - c0[0]).toFixed(4) : null;
  var frontAt = function (t) { var x = 0; while (x < 20 && Math.abs(t - x / 4.0) > 1e-9 && t - x / 4.0 > 0) x += 0.0005; return x; };
  out.front_per_T = +(frontAt(1.0) - frontAt(0.5)).toFixed(3);
  /* 振動数を途中で変えても、波源の変位はとばない（位相をつなぐ） */
  var s3 = SRC.make(); s3.pieces.push({ k: 'sin', t0: 0, t1: Infinity, A: 0.2, f: 2.0, ph0: 0 });
  SRC.retune(s3, 1.37, 0.2, 1.0);
  out.retune_jump = +Math.abs(SRC.y0(s3, 1.37 - 1e-9) - SRC.y0(s3, 1.37 + 1e-9)).toExponential(2);
  /* 手で動かした記録：手の位置はそのまま返す。手を上にずらしたまま 3 s 止めても、ずれが伝わったあとの点はつりあいの位置にもどる。
     手の位置（x = 0）は手と一致し、放したあとは手も媒質も 0 にもどる */
  var s4 = SRC.make(), p = SRC.grab(s4, 0, 0.01); for (var k4 = 0; k4 < 300; k4++) SRC.push(p, 0.15);
  var farHeld = Math.abs(waveY(s4, 2.0, 6.0, 3.0)), nearHand = waveY(s4, 2.0, 0, 3.0), peak = 0;
  for (var tt4 = 0; tt4 < 3; tt4 += 0.01) peak = Math.max(peak, waveY(s4, 2.0, 2.0, tt4));
  SRC.release(s4, 3.0);
  var afterRel = 0; for (var x4 = 0; x4 <= 8; x4 += 0.1) afterRel = Math.max(afterRel, Math.abs(waveY(s4, 2.0, x4, 9.0)));
  out.hand_far_while_held = +farHeld.toExponential(2); out.hand_peak_passed = +peak.toFixed(3); out.hand_after_release = +afterRel.toExponential(2);
  out.hand_ok = near(SRC.hand(s4, 2.0), 0.15) && near(nearHand, 0.15, 1e-9) && farHeld < 1e-3 && peak > 0.1 && afterRel < 1e-3;
  /* ①-3：縦波の密・疎は変位 0 の点で、密では −∂u/∂x が最大（= 2πA/λ） */
  var mk = LONG.marks(1.2, 0.5, 6.0, 2.4), eM = 0, okM = mk.length > 0;
  mk.forEach(function (m) {
    eM = Math.max(eM, Math.abs(LONG.u(0.12, 1.2, 0.5, m.x, 6.0)));
    var d = LONG.dens(0.12, 1.2, 0.5, m.x, 6.0), dmax = TAU * 0.12 / 1.2;
    if (m.k === 'mitsu' && !near(d, dmax, 1e-9)) okM = false;
    if (m.k === 'so' && !near(d, -dmax, 1e-9)) okM = false;
  });
  out.m1s3_marks_u0 = +eM.toExponential(2); out.m1s3_marks_ok = okM; out.m1s3_n_marks = mk.length;
  /* ①-3：縦波の速さ v = fλ（λ = 1.2 m、f = 0.5 Hz → 0.60 m/s） */
  out.m1s3_lam = +m1s3Q({ v: { A: 0.12, v: 0.6, f: 0.5 } }).lam.toFixed(6);
  /* ①-4：気温 15 ℃ → V = 340.5 m/s。屈折率 1.33 → 光の速さ 2.26×10⁸ m/s、波長は 1/1.33 倍 */
  out.m1s4_V15 = +WAVE.V(15).toFixed(6);
  var st4 = { f: { light: WAVE.c0 / 550e-9, sound: 440 }, n: 1.33, tc: 15 }, ql = m4Q(st4, 'light');
  out.m1s4_c_n133 = +(ql.v / 1e8).toFixed(4);
  out.m1s4_lam_ratio = +(ql.lam / ql.lam0).toFixed(6);
  out.m1s4_ok = near(WAVE.V(15), 340.5) && Math.abs(ql.v - 2.26e8) < 0.005e8 && near(ql.lam / ql.lam0, 1 / 1.33) && near(ql.f, WAVE.c0 / 550e-9);
  /* ①-4：音波 440 Hz・15 ℃ → λ = 340.5/440 m、v = fλ */
  var qs = m4Q(st4, 'sound');
  out.m1s4_sound_lam = +qs.lam.toFixed(6); out.m1s4_sound_vfl = near(qs.f * qs.lam, qs.v);
  /* ①-4：水面の表面波の粒は円をえがく（半径は一定、深いほど小さい） */
  var r0 = [], eR = 0;
  [0, -0.1, -0.3].forEach(function (z0) {
    var rr = SURF.pos(0.05, 1, 0.5, 0.3, z0, 0).r; r0.push(rr);
    for (var t5 = 0; t5 < 2; t5 += 0.05) { var pp = SURF.pos(0.05, 1, 0.5, 0.3, z0, t5); eR = Math.max(eR, Math.abs(Math.hypot(pp.x - 0.3, pp.z - z0) - rr)); }
  });
  out.surf_circle_err = +eR.toExponential(2); out.surf_deeper_smaller = r0[0] > r0[1] && r0[1] > r0[2];
  /* 聞こえる範囲 */
  out.audible = [WAVE.audible(19), WAVE.audible(20), WAVE.audible(20000), WAVE.audible(20001)];
  /* ===== 章 ② ===== */
  /* ②-1：同じ A・λ・f のとき、節の位置で全時刻 |y| < 1e-9、節の間隔 λ/2、腹の振幅 2A。合成波 = 和 */
  var L1 = M2.s1.L, v1 = 2.0, f1 = 0.5, A1 = 1.0, lam1 = v1 / f1, nd = M2.nodes(L1, lam1), eN = 0, eS = 0, ampA = 0;
  var yS = function (x, t) { return M2.right('sin', A1, f1, v1, x, t) + M2.left('sin', A1, f1, v1, L1, x, t); };
  var ns = nd.filter(function (n) { return n.k === 'node'; }), an = nd.filter(function (n) { return n.k === 'anti'; });
  for (var t6 = L1 / v1; t6 < L1 / v1 + 8; t6 += 0.0173) {
    ns.forEach(function (n) { eN = Math.max(eN, Math.abs(yS(n.x, t6))); });
    ampA = Math.max(ampA, Math.abs(yS(an[1].x, t6)));
    for (var x6 = 0; x6 <= L1; x6 += 0.37) eS = Math.max(eS, Math.abs(yS(x6, t6) - (M2.right('sin', A1, f1, v1, x6, t6) + M2.left('sin', A1, f1, v1, L1, x6, t6))));
  }
  out.m2s1_node_max = +eN.toExponential(2); out.m2s1_node_spacing = ns.length > 1 ? +(ns[1].x - ns[0].x).toFixed(6) : null; out.m2s1_anti_amp = +ampA.toFixed(4); out.m2s1_sum_err = eS;
  /* ②-2：固定端では端の変位が全時刻 0。自由端ではパルスが重なった瞬間に端の変位が入射の 2 倍 */
  var qf = { L: M2.s2.L, v: M2.s2.v, A: M2.s2.A, f: M2.s2.f, sh: 'pulse', fixed: true }, qr = { L: M2.s2.L, v: M2.s2.v, A: M2.s2.A, f: M2.s2.f, sh: 'pulse', fixed: false }, eF = 0, mxFree = 0, mxInc = 0;
  for (var t7 = 0; t7 < 10; t7 += 0.001) {
    eF = Math.max(eF, Math.abs(M2.inc(qf, qf.L, t7) + M2.refl(qf, qf.L, t7)));
    mxFree = Math.max(mxFree, M2.inc(qr, qr.L, t7) + M2.refl(qr, qr.L, t7)); mxInc = Math.max(mxInc, M2.inc(qr, qr.L, t7));
  }
  ['sin', 'tri'].forEach(function (sh) { var q = { L: 8, v: 2, A: 1, f: 0.5, sh: sh, fixed: true }; for (var t8 = 0; t8 < 12; t8 += 0.0131) eF = Math.max(eF, Math.abs(M2.inc(q, q.L, t8) + M2.refl(q, q.L, t8))); });
  out.m2s2_fixed_end = eF; out.m2s2_free_ratio = +(mxFree / mxInc).toFixed(6);
  /* ②-3：両端固定のダランベールの解は両端でいつも 0、t = 0 で初めの形。固有振動の和（減衰なし）も同じ形になる */
  var q3 = { l: 1, v: 3, h0: 0.05, xp: 0.3, w: 0.12 }, eE = 0, e0 = 0, eMd = 0;
  for (var t9 = 0; t9 < 3; t9 += 0.0071) { eE = Math.max(eE, Math.abs(M2.dal(q3, 0, t9, 1) + M2.dal(q3, 0, t9, -1)), Math.abs(M2.dal(q3, 1, t9, 1) + M2.dal(q3, 1, t9, -1)), Math.abs(M2.modal(q3, 1, t9, 0.25))); }
  for (var x9 = 0; x9 <= 1; x9 += 0.01) { e0 = Math.max(e0, Math.abs(M2.dal(q3, x9, 0, 1) + M2.dal(q3, x9, 0, -1) - M2.pluckShape(q3, x9))); eMd = Math.max(eMd, Math.abs(M2.modal(q3, x9, 0.2, 0) - (M2.dal(q3, x9, 0.2, 1) + M2.dal(q3, x9, 0.2, -1)))); }
  out.m2s3_ends = +eE.toExponential(2); out.m2s3_t0_shape = e0; out.m2s3_modal_vs_dal = +(eMd / q3.h0).toFixed(4);
  out.m2_ok = eN < 1e-9 && Math.abs(out.m2s1_node_spacing - lam1 / 2) < 1e-9 && Math.abs(ampA - 2 * A1) < 2e-3 && eS < 1e-12 && eF < 1e-12 && Math.abs(out.m2s2_free_ratio - 2) < 1e-9 && eE < 1e-12 && e0 < 1e-12 && out.m2s3_modal_vs_dal < 0.03;
  /* ②-3 糸に連続波：右端（固定端）はいつも 0。f₁ で揺すると 1.5f₁ より大きく振動する（共振） */
  var qd = { l: 1, v: 2 }, eD = 0, amp1 = 0, amp15 = 0;
  for (var td = 0; td < 24; td += 0.0137) { eD = Math.max(eD, Math.abs(M2.drive(qd, 1, td, 1, 0.0025, 0.9))); if (td > 16) { amp1 = Math.max(amp1, Math.abs(M2.drive(qd, 0.5, td, 1, 0.0025, 0.9))); amp15 = Math.max(amp15, Math.abs(M2.drive(qd, 0.5, td, 1.5, 0.0025, 0.9)), Math.abs(M2.drive(qd, 0.33, td, 1.5, 0.0025, 0.9))); } }
  out.m2s3_drive_end = +eD.toExponential(2); out.m2s3_res_ratio = +(amp1 / amp15).toFixed(2);
  /* 章 ③：うなり・固有振動数（プロンプト §5 の検算） */
  out.m3_beat = [WAVE.beat(440, 442), WAVE.beat(400, 410), WAVE.beat(405, 403)];
  var eB = 0; for (var tb = 0; tb < 1; tb += 0.00037) eB = Math.max(eB, Math.abs(Math.abs(m3s2Y({ f1: 400, f2: 402 }, tb)) - Math.abs(m3s2Env({ f1: 400, f2: 402 }, tb) * Math.sin(TAU * 401 * tb))));
  out.m3_beat_env_err = +eB.toExponential(2);
  out.m3_string = [WAVE.fString(0.6, 240, 1), WAVE.fString(0.6, 240, 3)];
  out.m3_closed = +WAVE.fClosed(0.25, 340, 1).toFixed(9); out.m3_open = +WAVE.fOpen(0.5, 340, 1).toFixed(9);
  out.m3_mono_v = +Math.sqrt(6 * M3S3.mW * M3S3.g / M3S3.rho).toFixed(2);
  var fs = { wl: { pts: [], found: [] }, v: { tc: 15, Lw: 0.02 } };   /* ③-5 水柱：開口端補正を入れて L₁ = λ/4 − Δx */
  for (var Lx = 0.02; Lx <= 0.6; Lx += 0.003) { fs.v.Lw = Lx; m3s5Rec(fs, true); }
  var lamW = WAVE.V(15) / 800;
  out.m3_water_L = fs.wl.found.map(function (x) { return +(x * 100).toFixed(2); }); out.m3_water_dL_over_halflam = fs.wl.found.length > 1 ? +((fs.wl.found[1] - fs.wl.found[0]) / (lamW / 2)).toFixed(4) : null;
  out.m3_ok = out.m3_beat[0] === 2 && out.m3_beat[1] === 10 && eB < 1e-9 && near(out.m3_string[0], 200) && near(out.m3_string[1], 600) && near(out.m3_closed, 340) && near(out.m3_open, 340) &&
    Math.abs(out.m3_water_dL_over_halflam - 1) < 0.01 && Math.abs(fs.wl.found[0] - (lamW / 4 - M3S5.dx)) < 0.002 && eD < 1e-12 && out.m2s3_res_ratio > 5;
  /* ③-3 共鳴（弦）：振動子の所（x = 0）では必ず y = a sin ωt（弦と振動子がつながっている）。④-4：C5 = 523.25 Hz */
  var dq = { l: 0.6, f1: 200, fd: 300 }, d0 = m3s3DrivenY(dq, 0), dl = m3s3DrivenY(dq, 0.6);
  out.m3_drive_end = +(Math.abs(d0.re - 1) + Math.abs(d0.im) + Math.abs(dl.re) + Math.abs(dl.im)).toExponential(2);
  out.m4_c5 = +MUS.fET(72).toFixed(2);
  /* ③-3：入射波＋反射波 ＝ 弦の形。②-3：右向き＋左向き ＝ 糸の形 */
  var eCw = 0; [0, 0.13, 0.3, 0.47, 0.6].forEach(function (x) { var t0 = m3s3DrivenY(dq, x), p1 = m3s3DrivenY(dq, x, 1), p2 = m3s3DrivenY(dq, x, -1); eCw = Math.max(eCw, Math.abs(p1.re + p2.re - t0.re) + Math.abs(p1.im + p2.im - t0.im)); });
  var q2d = { l: M2.s3.l, v: 1 }, eDs = 0; [0.1, 0.4, 0.77].forEach(function (x) { [1.3, 5.2].forEach(function (t) { eDs = Math.max(eDs, Math.abs(M2.drive(q2d, x, t, 0.5, 1, 0.9, 1) + M2.drive(q2d, x, t, 0.5, 1, 0.9, -1) - M2.drive(q2d, x, t, 0.5, 1, 0.9))); }); });
  out.m3_cw_sum = +eCw.toExponential(2); out.m2_drive_split = +eDs.toExponential(2);
  out.m3_ok = out.m3_ok && eCw < 1e-12 && eDs < 1e-12 && out.m3_drive_end < 1e-12 && out.m4_c5 === 523.25;
  out.all_ok = out.m3_ok && out.m2_ok && out.m1s1_ok && out.m1s2_ok && eC < 1e-12 && eV < 1e-6 && eW < 1e-12 && Math.abs(out.crest_speed - 4.0) < 1e-2 && Math.abs(out.crest_spacing - 2.0) < 2e-3 && Math.abs(out.front_per_T - 2.0) < 2e-3 &&
    out.retune_jump < 1e-6 && out.hand_ok && eM < 1e-9 && okM && near(out.m1s3_lam, 1.2) && out.m1s4_ok && out.m1s4_sound_vfl && eR < 1e-12 && out.surf_deeper_smaller;
  return out;
}
window.TEST = {
  check: check,
  sims: function () { return SIM_BY_ID; },
  /* いまの状態（テストで 2 回比べる）：各節の値と時刻 */
  state: function () {
    var o = {};
    Object.keys(SIM_BY_ID).forEach(function (k) { var s = SIM_BY_ID[k]; o[k] = { v: s.v, t: +s.t.toFixed(6), playing: s.playing }; });
    return o;
  }
};
