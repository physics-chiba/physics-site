/* ===== 72_m3s5.js ===== */
/* =========================================================================
   ③-5 気柱の共鳴（水柱の実験）— 2026-11-05 千葉さん 8 回目：③-3 から独立
   ・たてのガラス管の上で 800 Hz のおんさを鳴らす。管の下はゴム管で水だめにつながっていて、
     水だめを上下に動かすと管の中の水面も上下する（水面の高さは水だめと同じ）
   ・開口端補正 Δx（腹は管口の少し外）を必ず入れる：共鳴するのは L + Δx = λ/4, 3λ/4, 5λ/4 …
   ・管の中の定在波は、水面が節：変位の振幅 ∝ |sin k(L − y)|（y は管口から下向き）。いまの L のまま描く
   ・L₁・L₂ の図を並べて、λ/4 = L₁ + Δx、3λ/4 = L₂ + Δx、L₂ − L₁ = λ/2 を説明
   ========================================================================= */
'use strict';
var M3S5 = { fork: 800, r: 0.02, Qw: 12, Lmin: 0.02, Lmax: 0.6, TL: 16 };
M3S5.dx = 0.6 * M3S5.r;                                    /* 開口端補正 Δx = 0.6r（r：管の半径） */
function m3s5Q(s) { var V = WAVE.V(s.v.tc), lam = V / M3S5.fork; return { V: V, lam: lam, L: s.v.Lw, L1: lam / 4 - M3S5.dx, L2: 3 * lam / 4 - M3S5.dx, L3: 5 * lam / 4 - M3S5.dx }; }
/* 共鳴の強さ（0〜1）。L + Δx が λ/4 の奇数倍に近いほど大きい */
function m3s5Amp(q, L) {
  var best = 0;
  for (var k = 1; k <= 7; k += 2) { var d = 4 * (L + M3S5.dx) / q.lam - k; best = Math.max(best, 1 / Math.sqrt(1 + Math.pow(M3S5.Qw * d, 2))); }
  return best;
}
DEFS.m3s5 = {
  id: 'm3s5', mode: 'mode3', num: 5,
  title: '気柱の共鳴（水柱の実験）', short: '水柱の実験',
  desc: '管口でおんさを鳴らし、水面を下げていくと、決まった低さで<b>共鳴</b>して大きな音になる。<span class="todo">右の水だめを上下に動かして、共鳴する水面の低さ $L_1$・$L_2$ を見つけよう。</span>',
  strobe: false, stepDiv: 16,
  varCols: [['Lw', 'tc'], ['lam', 'dx']],
  varColNote: { 1: '以下は、左の値で決まる（直接は変えられない）' },
  vars: [
    { k: 'Lw', label: '水面の管口からの低さ $L$', aria: '水面の管口からの低さ', min: M3S5.Lmin, max: M3S5.Lmax, step: 0.002, def: 0.04, fmt: function (x) { return sig(x * 100, 3) + ' cm'; } },
    { k: 'tc', label: '気温 $t$', aria: '気温', stops: [-10, 0, 10, 15, 20, 30, 40], prop: true, stopLabels: ['−10', '0', '10', '', '20', '30', '40 ℃'], def: 15, fmt: function (x) { return String(x).replace('-', '−') + ' ℃'; } },
    meterVar('lam', '波長 $\\lambda$（800 Hz）', '波長', function (x) { return sig(x * 100, 3) + ' cm'; }, 0.5),
    meterVar('dx', '開口端補正 $\\Delta x$', '開口端補正', function (x) { return sig(x * 100, 2) + ' cm'; }, 0.05)
  ],
  disp: function (s, k) { var q = m3s5Q(s); if (k === 'lam') return q.lam; if (k === 'dx') return M3S5.dx; return s.v[k]; },
  init: function (s) { s.wl = { pts: [], found: [] }; s.dmode = 'trans'; s.lowering = false; s.lowT = 0; },   /* 既定は横波表示のみ（2026-11-06 千葉さん 9 回目） */
  onDefaults: function (s) { s.wl = { pts: [], found: [] }; s.dmode = 'trans'; s.lowering = false; m3s5Sync(s); },
  onChanged: function (s, k) { if (k === 'tc') s.wl = { pts: [], found: [] }; if (k === 'Lw') m3s5Rec(s, false); m3s5Sync(s); m3s5Resound(s); return 'keepT'; },
  buttons: [
    { k: 'wd', label: '水面をゆっくり下げる', cls: 'plk', onClick: function (s) { m3s5Lower(s); } },
    { k: 'dl', label: '元の縦波のみ', seg: 'dsp', segLabel: '管の中の表示', onClick: function (s) { s.dmode = 'long'; m3s5Sync(s); s.draw(); } },
    { k: 'dt', label: '横波表示のみ', seg: 'dsp', onClick: function (s) { s.dmode = 'trans'; m3s5Sync(s); s.draw(); } },
    { k: 'db', label: '両方重ねる', seg: 'dsp', onClick: function (s) { s.dmode = 'both'; m3s5Sync(s); s.draw(); } }
  ],
  tEnd: function () { return M3_TEND; },
  tInfo: function () { return '<span class="tpl">おんさ</span><b>800 Hz</b>'; },
  gT: function () { return 1; },
  beforeStep: function (s, t0, t1) {
    if (!s.lowering) return;
    s.lowT += t1 - t0;
    s.v.Lw = clamp(M3S5.Lmin + (M3S5.Lmax - M3S5.Lmin) * s.lowT / M3S5.TL, M3S5.Lmin, M3S5.Lmax);
    m3s5Rec(s, true); s.syncSliders && s.syncSliders(); m3s5Resound(s);
    if (s.lowT >= M3S5.TL) s.lowering = false;
  },
  height: function (s, w) { return Math.round(clamp(w * 0.82, 440, 520)); },
  belowCanvas: true,
  below: function (s) { m3s5Dx(s); },
  afterBuild: function (s) {
    s.R.innerHTML = ''; var sw = el('div', 'row2 sliders inR'); sw.appendChild(s.varbox); s.R.appendChild(sw); s.varbox.classList.add('inR');
    s.scope = new Scope(s.R, '水面の低さと音の大きさ'); s.scope.box.classList.add('light');
    s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);
    var segs = s.row1b.querySelectorAll('.seg'); if (segs[0]) { var lb = el('span', 'seglbl', '管の中の表示'); segs[0].insertAdjacentElement('beforebegin', lb); lblSeg(lb, segs[0]); }
    var sp = el('span', 'spkrow'); s.row1b.appendChild(sp); s.spkRow = sp;
    m3SpkBtn(s, sp, function () { return m3s5Voices(s); });
    m3TimeBar(s, false);
    /* 水だめをドラッグして上下に動かす */
    var drag = null;
    var pos = function (ev) { var r = s.cv.getBoundingClientRect(); return { x: ev.clientX - r.left, y: ev.clientY - r.top }; };
    s.cv.addEventListener('pointerdown', function (ev) {
      var p = pos(ev), g = s._g; if (!g) return;
      if (p.x > g.rx - 34 && p.x < g.rx + 34 && p.y > g.rTop - 12 && p.y < g.rTop + g.rH + 12) { drag = { dy: p.y - g.ws }; s.lowering = false; s.cv.setPointerCapture(ev.pointerId); ev.preventDefault(); }
    });
    s.cv.addEventListener('pointermove', function (ev) {
      var p = pos(ev), g = s._g; if (!g) return;
      if (!drag) { s.cv.style.cursor = p.x > g.rx - 34 && p.x < g.rx + 34 && p.y > g.rTop - 12 && p.y < g.rTop + g.rH + 12 ? 'ns-resize' : 'default'; return; }
      s.v.Lw = clamp((p.y - drag.dy - g.top) / g.SY, M3S5.Lmin, M3S5.Lmax);
      m3s5Rec(s, false); s.syncSliders && s.syncSliders(); m3s5Resound(s); s.draw(); ev.preventDefault();
    });
    var up = function () { drag = null; };
    s.cv.addEventListener('pointerup', up); s.cv.addEventListener('pointercancel', up);
    m3s5Sync(s);
  },
  draw: function (s, ctx, W, H) { drawM3S5(s, ctx, W, H); m3s5Panel(s); m3s5Fig(s); },
  right: function (s, R) { rightM3S5(s, R); }
};
function m3s5Voices(s) { var q = m3s5Q(s); return { voices: [{ f: M3S5.fork }], vol: 0.12 + 0.88 * m3s5Amp(q, s.v.Lw) }; }
/* 水面を動かしているときは、鳴らし直さずに音の大きさだけを変える */
function m3s5Resound(s) { if (AUDIO.owner() !== 'm3s5') return; var g = m3s5Voices(s); if (!AUDIO.setVol('m3s5', g.vol)) AUDIO.play('m3s5', g.voices, g.vol); }
function m3s5Sync(s) {
  m2Sync(s, [['dl', s.dmode === 'long'], ['dt', s.dmode === 'trans'], ['db', s.dmode === 'both']]);
  if (s.Rdyn) s.renderRight();
}
function m3s5Lower(s) {
  s.wl = { pts: [], found: [] }; s.v.Lw = M3S5.Lmin; s.lowering = true; s.lowT = 0;
  SIMS.forEach(function (o) { if (o.playing && o !== s) { o.playing = false; o.syncPlayLabel(); } });
  if (!s.playing) { s.playing = true; s.syncPlayLabel(); startLoop(); }
  s.syncSliders && s.syncSliders(); m3s5Sync(s);
}
/* L と音の大きさを記録する。ゆっくり下げているときだけ、山（共鳴）を通りすぎたら L₁・L₂ … として残す */
function m3s5Rec(s, auto) {
  var q = m3s5Q(s), L = s.v.Lw, a = m3s5Amp(q, L), P = s.wl.pts;
  P.push([L, a]); if (P.length > 2000) P.shift();
  if (!auto) return;
  var n = P.length;
  if (n >= 3 && P[n - 2][1] >= P[n - 3][1] && P[n - 2][1] > P[n - 1][1] && P[n - 2][1] > 0.9) {
    /* 山の頂点を、前後 3 点を通る放物線で求める（記録の間かくより細かく） */
    var a0 = P[n - 3], a1 = P[n - 2], a2 = P[n - 1], h1 = a1[0] - a0[0], h2 = a2[0] - a1[0], d1 = (a1[1] - a0[1]) / h1, d2 = (a2[1] - a1[1]) / h2, c2 = (d2 - d1) / (h1 + h2);
    var xp = c2 !== 0 ? (a0[0] + a1[0]) / 2 - d1 / (2 * c2) : a1[0];
    if (s.wl.found.length < 3) s.wl.found.push(clamp(xp, a0[0], a2[0]));
  }
}
/* 図：左＝おんさとガラス管（管の中の定在波）、右＝ゴム管でつながった水だめ（ドラッグで上下）、右上＝マイク（オシロスコープ） */
function drawM3S5(s, ctx, W, H) {
  var q = m3s5Q(s), nar = W < 520, tx = nar ? 96 : 150, top = 104, bot = H - 22, SY = (bot - top - 8) / 0.62, tw = 26, L = s.v.Lw, ws = top + L * SY;
  var a = m3s5Amp(q, L), k = TAU / q.lam, th = TAU * m3FS(s, 0.7) * s.t, dm = s.dmode || 'both';
  /* おんさ（管口の上） */
  forkSide(ctx, tx, top - 22);                                       /* おんさは横に倒して、枝を管口の上に（2026-11-06 千葉さん 9 回目） */
  label(ctx, 'おんさ 800 Hz', Math.max(4, tx - 108), top - 44, { size: 11, bold: true, color: COL.ink2, align: 'left' });
  /* 水だめ（右）。水面の高さは管の中と同じ */
  var rx = Math.min(W - 44, tx + (nar ? 120 : 190)), rH = 64, rTop = ws - 26;
  s._g = { rx: rx, rTop: rTop, rH: rH, ws: ws, top: top, SY: SY };
  ctx.save(); ctx.strokeStyle = '#8a929c'; ctx.lineWidth = 7; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(tx, bot); ctx.bezierCurveTo(tx, bot + 16, rx, Math.max(bot + 16, rTop + rH + 30), rx, rTop + rH); ctx.stroke();
  ctx.strokeStyle = 'rgba(80,150,210,.8)'; ctx.lineWidth = 3.5; ctx.stroke(); ctx.restore();   /* ゴム管（中は水） */
  ctx.save(); ctx.fillStyle = 'rgba(80,150,210,.45)'; ctx.fillRect(rx - 24, ws, 48, rTop + rH - ws);
  ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 2.4; ctx.beginPath(); ctx.moveTo(rx - 24, rTop); ctx.lineTo(rx - 24, rTop + rH); ctx.lineTo(rx + 24, rTop + rH); ctx.lineTo(rx + 24, rTop); ctx.stroke(); ctx.restore();
  label(ctx, '水だめ', rx, rTop + rH + 12, { size: 11, bold: true, color: COL.ink2 });
  label(ctx, '↕ 上下に動かす', rx, rTop - 12, { size: 10.5, bold: true, color: '#9c4e06' });
  dotted(ctx, tx + tw + 4, ws, rx - 26, ws, 'rgba(31,95,138,.45)', [3, 3]);
  /* ガラス管と水 */
  ctx.save(); ctx.fillStyle = 'rgba(80,150,210,.45)'; ctx.fillRect(tx - tw, ws, 2 * tw, bot - ws); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(tx - tw, top); ctx.lineTo(tx - tw, bot); ctx.lineTo(tx + tw, bot); ctx.lineTo(tx + tw, top); ctx.stroke(); ctx.restore();
  label(ctx, '水', tx, Math.min(bot - 10, ws + 14), { size: 11, color: '#1f5f8a', bold: true });
  label(ctx, '管口', tx - tw - 6, top, { size: 10.5, color: COL.ink2, align: 'right' });
  /* 管の中の定在波：水面が節、腹は y = L − λ/4（共鳴のときは管口の Δx 上） */
  var shp = function (y) { return Math.sin(k * (L - y)); }, y0 = Math.max(-M3S5.dx, L - q.lam * 1.3);
  if (L > 0.005) {
    if (dm !== 'long') {
      [1, -1].forEach(function (sg) { ctx.save(); ctx.strokeStyle = 'rgba(122,59,18,.35)'; ctx.setLineDash([3, 3]); ctx.beginPath(); for (var i = 0; i <= 160; i++) { var y = -M3S5.dx + (L + M3S5.dx) * i / 160, px = tx + sg * a * (tw - 4) * shp(y); if (i) ctx.lineTo(px, top + y * SY); else ctx.moveTo(px, top + y * SY); } ctx.stroke(); ctx.restore(); });
      ctx.save(); ctx.strokeStyle = '#7a3b12'; ctx.lineWidth = 2.2; ctx.beginPath(); for (var i2 = 0; i2 <= 160; i2++) { var y2 = -M3S5.dx + (L + M3S5.dx) * i2 / 160, px2 = tx + a * (tw - 4) * shp(y2) * Math.cos(th); if (i2) ctx.lineTo(px2, top + y2 * SY); else ctx.moveTo(px2, top + y2 * SY); } ctx.stroke(); ctx.restore();
    }
    if (dm !== 'trans') {
      /* 元の縦波：空気の粒は上下に動く */
      var nr = Math.max(6, Math.round(L * SY / 9)), um = Math.min(7, L * SY / nr * 0.45);
      ctx.save(); ctx.fillStyle = dm === 'both' ? 'rgba(209,53,43,.55)' : '#d1352b';
      for (var r = 0; r < nr; r++) { var ye = L * (r + 0.5) / nr, py = top + ye * SY + um * a * shp(ye) * Math.cos(th); for (var c = 0; c < 4; c++) { ctx.beginPath(); ctx.arc(tx - tw + 2 * tw * (c + 0.5) / 4, py, 2, 0, TAU); ctx.fill(); } }
      ctx.restore();
    }
    /* 腹の位置（管口の上にはみ出すとき） */
    var yA = L - q.lam / 4;
    if (a > 0.6 && yA < 0.004 && yA > -0.03) { var pyA = top + yA * SY; dotted(ctx, tx - tw - 18, pyA, tx + tw + 18, pyA, '#14653a', [2, 2]); label(ctx, '腹', tx + tw + 22, pyA, { size: 11, bold: true, color: '#14653a', align: 'left' }); }
  }
  /* L の寸法（管の左） */
  var dxl = tx - tw - 18;
  ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(dxl, top); ctx.lineTo(dxl, ws); ctx.moveTo(dxl - 4, top); ctx.lineTo(dxl + 4, top); ctx.moveTo(dxl - 4, ws); ctx.lineTo(dxl + 4, ws); ctx.stroke(); ctx.restore();
  label(ctx, 'L = ' + sig(L * 100, 3) + ' cm', dxl - 6, (top + ws) / 2 + (L < 0.08 ? 14 : 0), { size: 11.5, bold: true, color: COL.ink, align: 'right' });
  s.wl.found.forEach(function (Lf, i) {
    var yy = top + Lf * SY; dotted(ctx, tx - tw - 6, yy, tx + tw + 6, yy, '#1c8f4a', [4, 3]);
    label(ctx, 'L' + '₁₂₃'[i] + ' = ' + sig(Lf * 100, 3) + ' cm', tx + tw + 10, yy, { size: 11, bold: true, color: '#14653a', align: 'left' });
  });
  /* マイク（オシロスコープ）：管口の近く。画面の大きさは共鳴の強さ */
  /* オシロスコープはアニメの上のまん中（2026-11-06 千葉さん 10 回目） */
  var mxw = tx + tw + 26, sww = Math.round(Math.min(210, W * 0.42)), sxx = Math.round(W / 2 - sww / 2);
  micShape(ctx, mxw, top - 18);
  m3MiniScope(ctx, sxx, 8, sww, 46, function (tt) { return (0.1 + 0.8 * a) * Math.sin(TAU * M3S5.fork * tt); }, '');
  label(ctx, 'オシロスコープ', W / 2, 64, { size: 10.5, bold: true, color: COL.ink2 });
  dotted(ctx, mxw + 6, top - 26, sxx + sww * 0.3, 56, 'rgba(58,65,76,.5)', [2, 3]);
  label(ctx, a > 0.6 ? '共鳴している（大きな音）' : '共鳴していない', W - 10, H - 10, { size: 12, bold: true, color: a > 0.6 ? '#14653a' : COL.sub, align: 'right' });
  label(ctx, s.real ? '本当の速さに近づけた（実際はもっと速い）' : '図の振動はゆっくり', 8, 12, { size: 10.5, color: s.real ? '#c9670c' : COL.sub, bold: !!s.real, align: 'left' });
}
/* 右のグラフ：水面の低さ L と音の大きさ（記録した点は L の順にならべて線で結ぶ） */
function m3s5Panel(s) {
  var sc = s.scope; if (!sc || !sc.cv.offsetParent) return;
  var q = m3s5Q(s), W = Math.max(240, Math.floor(sc.cv.clientWidth || 300)), H = Math.round(clamp(W * 0.5, 150, 190)), ctx = prep(sc.cv, W, H);
  ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H);
  var gx0 = 34, gx1 = W - 10, gy0 = 16, gy1 = H - 26, X = function (L) { return gx0 + L / 0.6 * (gx1 - gx0); }, Y = function (a) { return gy1 - a * (gy1 - gy0); };
  axisArrow(ctx, gx0, gy1, gx1, gy1); axisArrow(ctx, gx0, gy1, gx0, gy0 - 4);
  for (var c = 0; c <= 6; c++) label(ctx, String(c * 10), X(c * 0.1), gy1 + 11, { size: 9.5, color: COL.sub });
  label(ctx, 'L〔cm〕', gx1, gy1 - 10, { size: 10, color: COL.sub, align: 'right' }); label(ctx, '音の大きさ', gx0 + 4, gy0 + 2, { size: 10, color: COL.sub, align: 'left' });
  var P = s.wl.pts.slice().sort(function (p1, p2) { return p1[0] - p2[0]; });
  ctx.save(); ctx.strokeStyle = '#1c6b8f'; ctx.lineWidth = 2; ctx.beginPath(); var last = -1;
  P.forEach(function (p, i) { if (i && p[0] - last > 0.02) ctx.moveTo(X(p[0]), Y(p[1])); else if (i) ctx.lineTo(X(p[0]), Y(p[1])); else ctx.moveTo(X(p[0]), Y(p[1])); last = p[0]; });   /* 記録のない所は結ばない */
  ctx.stroke(); ctx.restore();
  s.wl.found.forEach(function (Lf, i) { dotted(ctx, X(Lf), gy0, X(Lf), gy1, '#1c8f4a', [3, 3]); label(ctx, 'L' + '₁₂₃'[i], X(Lf), gy0 + 4, { size: 10.5, bold: true, color: '#14653a' }); });
  ctx.fillStyle = '#e07b18'; ctx.beginPath(); ctx.arc(X(s.v.Lw), Y(m3s5Amp(q, s.v.Lw)), 4, 0, TAU); ctx.fill();
  var cap = '「水面をゆっくり下げる」で、$L$ を 2 cm から 60 cm まで変えながら記録する（水だめを動かしても記録される）';
  if (sc.cap._h !== cap) { sc.cap._h = cap; sc.cap.innerHTML = mathify(cap); }
}
function rightM3S5(s, R) {
  var q = m3s5Q(s), f = s.wl.found;
  var h = '<div class="qcard"><p class="qt">L₁・L₂ と開口端補正</p>' +
    '<canvas class="m3s5fig" aria-label="1 回目と 2 回目の共鳴のときの管の中の定在波"></canvas>' +
    '<p>腹は管口より少し外（上）にできる。管口から腹までを<b>開口端補正</b> $\\Delta x$ という。水面は節なので</p>' +
    '<div class="qeq">$$\\frac{\\lambda}{4} = L_1 + \\Delta x,\\qquad \\frac{3\\lambda}{4} = L_2 + \\Delta x$$</div>' +
    '<p>2 つの式の差をとると $\\Delta x$ が消えて、$L_2 - L_1 = \\dfrac{\\lambda}{2}$。$\\Delta x$ が分からなくても、$\\lambda = 2(L_2 - L_1)$ で波長が求められる。</p>' +
    '<p class="qnow"><span class="qtag now">いま</span>$V = ' + sig(q.V, 4) + '$ m/s なので $\\lambda = \\dfrac{V}{f} = ' + sig(q.lam * 100, 3) + '$ cm</p>';
  if (f.length >= 2) h += '<p class="qnow"><span class="qtag now">記録</span>$L_1 = ' + sig(f[0] * 100, 3) + '$ cm、$L_2 = ' + sig(f[1] * 100, 3) + '$ cm → $\\lambda = 2(L_2 - L_1) = ' + sig(2 * (f[1] - f[0]) * 100, 3) + '$ cm、$\\Delta x = \\dfrac{L_2 - 3L_1}{2} = ' + sig((f[1] - 3 * f[0]) / 2 * 100, 2) + '$ cm</p>';
  h += '</div>';
  R.innerHTML = mathify(h);
  s._figK = null; m3s5Fig(s);
}
/* L₁ と L₂ のときの管をならべた図（同じ縮尺。管口の高さをそろえる） */
function m3s5Fig(s) {
  var cv = s.Rdyn && s.Rdyn.querySelector('canvas.m3s5fig'); if (!cv || !cv.offsetParent) return;
  var q = m3s5Q(s), W = Math.max(240, Math.floor(cv.clientWidth || 300)), H = 260, key = W + '|' + q.lam;
  if (s._figK === key) return; s._figK = key;
  var ctx = prep(cv, W, H); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H);
  var top = 46, SY = (H - top - 22) / (q.L2 + 0.02), tw = 16, dxPx = M3S5.dx * SY;
  [[q.L1, 1, 'L₁（1 回目の共鳴）'], [q.L2, 3, 'L₂（2 回目の共鳴）']].forEach(function (o, i) {
    var cx = W * (i ? 0.66 : 0.22), L = o[0], ws = top + L * SY, kk = TAU / q.lam;
    label(ctx, o[2], cx, 12, { size: 11, bold: true, color: COL.ink });
    ctx.save(); ctx.fillStyle = 'rgba(80,150,210,.45)'; ctx.fillRect(cx - tw, ws, 2 * tw, H - 8 - ws); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 2.4; ctx.beginPath(); ctx.moveTo(cx - tw, top); ctx.lineTo(cx - tw, H - 8); ctx.lineTo(cx + tw, H - 8); ctx.lineTo(cx + tw, top); ctx.stroke(); ctx.restore();
    [1, -1].forEach(function (sg) { ctx.save(); ctx.strokeStyle = '#7a3b12'; ctx.lineWidth = 1.6; ctx.beginPath(); for (var j = 0; j <= 120; j++) { var y = -M3S5.dx + (L + M3S5.dx) * j / 120, px = cx + sg * (tw - 3) * Math.sin(kk * (L - y)); if (j) ctx.lineTo(px, top + y * SY); else ctx.moveTo(px, top + y * SY); } ctx.stroke(); ctx.restore(); });
    var yA = top - dxPx;
    dotted(ctx, cx - tw - 10, yA, cx + tw + 10, yA, '#14653a', [2, 2]); label(ctx, '腹', cx + tw + 13, yA - 6, { size: 10, bold: true, color: '#14653a', align: 'left' });
    /* 寸法：左に L、右に λ/4（3λ/4）、管口の上に Δx */
    var lx = cx - tw - 12;
    ctx.save(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(lx, top); ctx.lineTo(lx, ws); ctx.moveTo(lx - 3, top); ctx.lineTo(lx + 3, top); ctx.moveTo(lx - 3, ws); ctx.lineTo(lx + 3, ws); ctx.stroke(); ctx.restore();
    label(ctx, i ? 'L₂' : 'L₁', lx - 4, (top + ws) / 2, { size: 11, bold: true, color: COL.ink, align: 'right' });
    var rx2 = cx + tw + 30;
    ctx.save(); ctx.strokeStyle = '#c9670c'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(rx2, yA); ctx.lineTo(rx2, ws); ctx.moveTo(rx2 - 3, yA); ctx.lineTo(rx2 + 3, yA); ctx.moveTo(rx2 - 3, ws); ctx.lineTo(rx2 + 3, ws); ctx.stroke(); ctx.restore();
    label(ctx, i ? '3λ/4' : 'λ/4', rx2 + 4, (yA + ws) / 2, { size: 11, bold: true, color: '#c9670c', align: 'left' });
    label(ctx, 'Δx', cx - tw - 4, top - dxPx / 2 - 9, { size: 10, bold: true, color: '#14653a', align: 'right' });
    ctx.save(); ctx.strokeStyle = '#9aa1ab'; ctx.beginPath(); ctx.moveTo(cx - tw - 8, top); ctx.lineTo(cx - tw, top); ctx.stroke(); ctx.restore();
    if (i) {                                                         /* L₂ − L₁ = λ/2（水面から水面まで） */
      var y1 = top + q.L1 * SY, bx = cx + tw + 74;
      dotted(ctx, W * 0.22 + tw, y1, cx + tw, y1, 'rgba(28,143,74,.6)', [3, 3]);
      ctx.save(); ctx.strokeStyle = '#1c8f4a'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(bx, y1); ctx.lineTo(bx, ws); ctx.moveTo(bx - 3, y1); ctx.lineTo(bx + 3, y1); ctx.moveTo(bx - 3, ws); ctx.lineTo(bx + 3, ws); ctx.stroke(); ctx.restore();
      if (bx + 8 < W) label(ctx, 'λ/2', Math.min(bx + 4, W - 28), (y1 + ws) / 2, { size: 11, bold: true, color: '#14653a', align: 'left' });
    }
  });
}

/* 横に倒したおんさ：(cx, y)＝枝の先の中ほど（管口の真上）。左に柄、枝は 2 本が上下にならぶ。枝の上下の短い線＝振動している */
function forkSide(ctx, cx, y) {
  var x1 = cx + 22, xb = cx - 46, g = 7;
  ctx.save(); ctx.strokeStyle = '#7d8794'; ctx.lineCap = 'round'; ctx.lineWidth = 5.5;
  ctx.beginPath(); ctx.moveTo(x1, y - g); ctx.lineTo(xb, y - g); ctx.quadraticCurveTo(xb - 12, y - g, xb - 12, y); ctx.quadraticCurveTo(xb - 12, y + g, xb, y + g); ctx.lineTo(x1, y + g); ctx.stroke();
  ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(xb - 12, y); ctx.lineTo(xb - 50, y); ctx.stroke();      /* 柄（手で持つ） */
  ctx.strokeStyle = 'rgba(224,123,24,.45)'; ctx.lineWidth = 1.2;
  [-1, 1].forEach(function (sg) { for (var x = xb + 8; x <= x1; x += 9) { ctx.beginPath(); ctx.moveTo(x, y + sg * (g + 5)); ctx.lineTo(x, y + sg * (g + 10)); ctx.stroke(); } });
  ctx.restore();
}
/* アニメの下：管口のまわりを拡大して、開口端補正 Δx を大きく説明（2026-11-06 千葉さん 9 回目） */
function m3s5Dx(s) {
  var host = s.below; if (!host) return;
  if (!host._built) {
    host._built = true; host.classList.add('dxbox');
    host.innerHTML = '<p class="dxh">管口のまわりを拡大すると（開口端補正 <i>Δx</i>）</p><div class="dxrow"><canvas class="dxcv" aria-label="管口のまわりの拡大図"></canvas><div class="dxtx"></div></div>';
    host._cv = host.querySelector('canvas'); host._tx = host.querySelector('.dxtx');
    host._tx.innerHTML = mathify('<p>気柱の振動の<b>腹</b>は、ちょうど管口ではなく、管口より少し外（上）にできる。管口から腹までの長さ $\\Delta x$ を<b>開口端補正</b>という。</p>' +
      '<p>$L_1$ は $\\lambda/4$ より $\\Delta x$ だけ短い。</p>' +
      '<p>$L_2 - L_1 = \\lambda/2$ を使うと、$\\Delta x$ が分からなくても $\\lambda$ が求められる。</p>' +
      '<p class="qnote">（なお、管の半径を $r$ とすると、およそ $\\Delta x \\fallingdotseq 0.6r$ という実験結果が知られている）</p>');   /* 2026-11-06 千葉さん 10 回目の文 */
  }
  var cv = host._cv; if (!cv.offsetParent) return;
  var q = m3s5Q(s), W = Math.max(220, Math.floor(cv.clientWidth || 300)), H = 340, key = W + '|' + q.lam;
  if (host._k === key) return; host._k = key;
  var ctx = prep(cv, W, H); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H);
  /* 縦は 腹（管口の Δx 上）〜 L₁ の水面 が入る縮尺。1 cm = PX px。y は管口から下向き〔cm〕 */
  var dx = M3S5.dx * 100, L1 = q.L1 * 100, PX = Math.min(26, (H - 34) / (L1 + dx + 2.0)), cx = W * 0.42, yM = 22 + (dx + 0.8) * PX;
  var Y = function (cm) { return yM + cm * PX; }, rw = Math.min(M3S5.r * 100 * PX, W * 0.16), k = TAU / (q.lam * 100), A = rw * 0.85;
  /* 管の壁と、L₁ の水面 */
  ctx.save(); ctx.fillStyle = 'rgba(80,150,210,.45)'; ctx.fillRect(cx - rw, Y(L1), 2 * rw, H - Y(L1)); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 4;
  ctx.beginPath(); ctx.moveTo(cx - rw, Y(0)); ctx.lineTo(cx - rw, H); ctx.moveTo(cx + rw, Y(0)); ctx.lineTo(cx + rw, H); ctx.stroke(); ctx.restore();
  label(ctx, '水', cx, Math.min(H - 8, Y(L1) + 14), { size: 11, bold: true, color: '#1f5f8a' });
  /* 振動のはば（横波表示）：上は腹（y = −Δx）まで、下は L₁ の水面（節）まで（2026-11-06 千葉さん 10 回目） */
  [1, -1].forEach(function (sg) { ctx.save(); ctx.strokeStyle = '#7a3b12'; ctx.lineWidth = 2; ctx.beginPath(); for (var i = 0; i <= 120; i++) { var y = -dx + (L1 + dx) * i / 120, px = cx + sg * A * Math.cos(k * (y + dx)); if (i) ctx.lineTo(px, Y(y)); else ctx.moveTo(px, Y(y)); } ctx.stroke(); ctx.restore(); });
  /* 管口・腹・水面の線 */
  dotted(ctx, cx - rw - 40, Y(0), cx + rw + 30, Y(0), '#3a414c', [5, 4]);
  label(ctx, '管口', cx - rw - 44, Y(0) + 4, { size: 12, bold: true, color: COL.ink, align: 'right' });
  dotted(ctx, cx - rw - 40, Y(-dx), cx + rw + 30, Y(-dx), '#14653a', [3, 3]);
  label(ctx, '腹', cx - rw - 44, Y(-dx) - 4, { size: 12, bold: true, color: '#14653a', align: 'right' });
  label(ctx, '水面（節）', cx + rw + 6, Y(L1) + 13, { size: 11, bold: true, color: '#5a2f99', align: 'left' });
  /* 寸法：右に Δx（大きく）と λ/4、左に L₁ */
  var bx = cx + rw + 22, bx2 = cx + rw + 70, lx = cx - rw - 26;
  var bar = function (x, ya, yb, col) { ctx.save(); ctx.strokeStyle = col; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x, ya); ctx.lineTo(x, yb); ctx.moveTo(x - 6, ya); ctx.lineTo(x + 6, ya); ctx.moveTo(x - 6, yb); ctx.lineTo(x + 6, yb); ctx.stroke(); ctx.restore(); };
  bar(bx, Y(-dx), Y(0), '#c9670c'); label(ctx, 'Δx', bx + 9, Y(-dx / 2), { size: 18, bold: true, color: '#c9670c', align: 'left' });
  bar(bx2, Y(-dx), Y(L1), '#c9670c'); label(ctx, 'λ/4', bx2 + 8, Y(L1 / 2), { size: 15, bold: true, color: '#c9670c', align: 'left' });
  bar(lx, Y(0), Y(L1), '#3a414c'); label(ctx, 'L₁', lx - 8, Y(L1 / 2), { size: 15, bold: true, color: COL.ink, align: 'right' });
  dotted(ctx, cx + rw, Y(L1), bx2 + 6, Y(L1), 'rgba(90,47,153,.5)', [3, 3]);
  label(ctx, '（拡大図）', W - 6, H - 8, { size: 10, color: COL.sub, align: 'right' });
}
