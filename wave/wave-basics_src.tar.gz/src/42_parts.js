/* ===== 42_parts.js ===== */
/* =========================================================================
   42_parts.js … このページで使う図の部品（ばね・天井・壁・床・ライト・吹き出しの式など）
   ・ばねはコイルを横から見た形（縦長の楕円が少しずつずれて重なる＋両はしの引き出し線）
     「解説プリントの図_床のハッチとばねの描き方ルール.md」の spring() を canvas に移したもの
   ・ハッチ（斜線）は必ず面の線分の内がわにおさめる
   ========================================================================= */
'use strict';
function eqTag(kind) { return kind ? '<span class="eqtag ' + kind + '">' + (kind === 'eom' ? '運動方程式' : '力のつりあいの式') + '</span>' : ''; }

/* ばね：(x1,y1) → (x2,y2)。o = { n 巻き数, r 太さの半分, b 楕円の横半径, lead 引き出し線, col, lw }。
   伸び縮みしても n・r・b・lead は変えない（間隔だけが詰まる） */
function springCoil(ctx, x1, y1, x2, y2, o) {
  o = o || {};
  var L = Math.hypot(x2 - x1, y2 - y1); if (L < 1) return;
  var ux = (x2 - x1) / L, uy = (y2 - y1) / L, nx = -uy, ny = ux;
  var n = o.n || 8, r = o.r || 8, lead = (o.lead === undefined ? Math.min(14, L * 0.12) : o.lead), b = o.b || r * 0.62;
  var Lc = L - 2 * lead, p = (Lc - 2 * b) / (n - 0.5);
  if (p < 0.6) p = 0.6;
  ctx.save(); ctx.strokeStyle = o.col || '#2b323c'; ctx.lineWidth = o.lw || 1.5; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(x1, y1);
  var N = Math.max(40, Math.round(36 * n)), t0 = -Math.PI / 2, t1 = Math.PI / 2 + TAU * (n - 1);
  for (var i = 0; i <= N; i++) {
    var t = t0 + (t1 - t0) * i / N, al = lead + b + p * (t + Math.PI / 2) / TAU + b * Math.sin(t), pe = r * Math.cos(t);
    ctx.lineTo(x1 + ux * al + nx * pe, y1 + uy * al + ny * pe);
  }
  ctx.lineTo(x2, y2); ctx.stroke(); ctx.restore();
}
/* 面のハッチ。(x1,y1) → (x2,y2) の線分を描き、進む向きの side がわ（1：右手がわ＝画面で下・左→右のとき）に斜線。
   斜線は線分の内がわだけ（始点を d だけ内がわへ） */
function hatchSeg(ctx, x1, y1, x2, y2, side, depth, col) {
  var L = Math.hypot(x2 - x1, y2 - y1); if (L < 2) return;
  var ux = (x2 - x1) / L, uy = (y2 - y1) / L, sd = side || 1, nx = -uy * sd, ny = ux * sd, dp = depth || 8, d = dp * 0.8, step = 8;
  ctx.save(); ctx.strokeStyle = col || '#2b323c'; ctx.lineWidth = 1.6;
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
  ctx.lineWidth = 1; ctx.strokeStyle = '#a9a193';
  for (var t = d; t <= L + 0.01; t += step) {
    var ax = x1 + ux * t, ay = y1 + uy * t;
    ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(ax - ux * d + nx * dp, ay - uy * d + ny * dp); ctx.stroke();
  }
  ctx.restore();
}
/* 天井（左→右、斜線は上）・床（左→右、斜線は下）・左の壁（上→下、斜線は左） */
function ceilingAt(ctx, xa, xb, y) { hatchSeg(ctx, xa, y, xb, y, -1, 8); }
function floorAt(ctx, xa, xb, y) { hatchSeg(ctx, xa, y, xb, y, 1, 8); }
function wallLeftAt(ctx, x, ya, yb) { hatchSeg(ctx, x, ya, x, yb, 1, 8); }

/* 破線の成分の矢印（速度・加速度の成分） */
function compArrow(ctx, x1, y1, x2, y2, col) {
  var L = Math.hypot(x2 - x1, y2 - y1); if (L < 4) return;
  var ux = (x2 - x1) / L, uy = (y2 - y1) / L, h = Math.min(9, L * 0.6), bx = x2 - ux * h, by = y2 - uy * h;
  ctx.save(); ctx.strokeStyle = col; ctx.fillStyle = fade(col, .35); ctx.lineWidth = 1.8; ctx.setLineDash([5, 3]);
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(bx, by); ctx.stroke(); ctx.setLineDash([]);
  ctx.beginPath(); ctx.moveTo(x2, y2); ctx.lineTo(bx - uy * h * .5, by + ux * h * .5); ctx.lineTo(bx + uy * h * .5, by - ux * h * .5); ctx.closePath(); ctx.fill();
  ctx.lineWidth = 1.4; ctx.stroke(); ctx.restore();
}
/* 細い点線 */
/* 参考の図（つりあいの位置など）のエリア：背景を薄い色でぬり、スタートで動くアニメとの境に実線（2026-10-25 千葉さん）。
   参考の図より先に描く。(x0, y0)–(x1, y1) の長方形。side：境の線を引く辺（'r' 右・'b' 下） */
function refArea(ctx, x0, y0, x1, y1, side) {
  ctx.save(); ctx.fillStyle = '#f1efe8'; ctx.fillRect(x0, y0, x1 - x0, y1 - y0);
  ctx.strokeStyle = 'rgba(20,23,28,.30)'; ctx.lineWidth = 1.2; ctx.beginPath();
  if (side === 'b') { ctx.moveTo(x0, y1); ctx.lineTo(x1, y1); } else if (side !== 'n') { ctx.moveTo(x1, y0); ctx.lineTo(x1, y1); }   /* 'n'：線は引かない（あとで refLine） */
  ctx.stroke(); ctx.restore();
}
function refLine(ctx, x, y0, y1) { ctx.save(); ctx.strokeStyle = 'rgba(20,23,28,.30)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(x, y0); ctx.lineTo(x, y1); ctx.stroke(); ctx.restore(); }
function dotted(ctx, x1, y1, x2, y2, col, dash) {
  ctx.save(); ctx.strokeStyle = col || 'rgba(60,70,80,.55)'; ctx.lineWidth = 1.1; ctx.setLineDash(dash || [2, 3]);
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); ctx.restore();
}
/* 座標軸（矢印つき）。(x1,y1) → (x2,y2) */
function axisArrow(ctx, x1, y1, x2, y2, col) {
  var L = Math.hypot(x2 - x1, y2 - y1), ux = (x2 - x1) / L, uy = (y2 - y1) / L;
  ctx.save(); ctx.strokeStyle = col || '#2b323c'; ctx.fillStyle = col || '#2b323c'; ctx.lineWidth = 1.3;
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2 - ux * 6, y2 - uy * 6); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(x2, y2); ctx.lineTo(x2 - ux * 9 - uy * 4, y2 - uy * 9 + ux * 4); ctx.lineTo(x2 - ux * 9 + uy * 4, y2 - uy * 9 - ux * 4); ctx.closePath(); ctx.fill();
  ctx.restore();
}
/* ライト（横から光を当てる）。(x, y)＝光の出口の中央、h＝出口の高さ、on＝点灯 */
function lampShape(ctx, x, y, h, on) {
  ctx.save();
  var bw = h * 0.42, bh = h * 0.62;
  ctx.fillStyle = on ? '#8c8f96' : '#a4a8ae'; ctx.strokeStyle = '#3f4a54'; ctx.lineWidth = 1.4;
  ctx.fillRect(x - h * 0.42 - bw, y - bh / 2, bw, bh); ctx.strokeRect(x - h * 0.42 - bw, y - bh / 2, bw, bh);
  ctx.beginPath(); ctx.moveTo(x - h * 0.42, y - bh * 0.32); ctx.lineTo(x, y - h / 2); ctx.lineTo(x, y + h / 2); ctx.lineTo(x - h * 0.42, y + bh * 0.32); ctx.closePath();
  ctx.fillStyle = on ? '#ffe9a8' : '#e4e1da'; ctx.fill(); ctx.stroke();
  if (on) { ctx.globalAlpha = 0.5; ctx.fillStyle = '#ffd34d'; ctx.beginPath(); ctx.ellipse(x, y, 4, h / 2 - 2, 0, 0, TAU); ctx.fill(); }
  ctx.restore();
}
/* 小さな上下の両矢印（「上下に振動」など） */
function dblArrow(ctx, x, y1, y2, col) {
  ctx.save(); ctx.strokeStyle = col || '#3a414c'; ctx.fillStyle = col || '#3a414c'; ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.moveTo(x, y1 + 6); ctx.lineTo(x, y2 - 6); ctx.stroke();
  [[y1, 1], [y2, -1]].forEach(function (p) { ctx.beginPath(); ctx.moveTo(x, p[0]); ctx.lineTo(x - 4, p[0] + 8 * p[1]); ctx.lineTo(x + 4, p[0] + 8 * p[1]); ctx.closePath(); ctx.fill(); });
  ctx.restore();
}
/* 時間バーの右の「今の周期」（circular-motion.html #2-7 と同じ形。有効数字 2 けた） */
function periodInfo(T) { return '<span class="tpl">周期</span><b>' + tex('T =') + ' ' + (isFinite(T) ? sig2(T) : '—') + '</b> s'; }   /* 「周期 T = 〇 s」（2026-10-16 千葉さん） */
function sig2(x) { return x >= 99.5 ? String(Math.round(x)) : x.toPrecision(2); }
/* ばねの楕円の横半径：つりあいの長さ Leq のとき、となりの巻きと少し重なるように（1 巻きの前進量の 1.1 倍） */
function coilB(Leq, n, lead) { return 1.1 * (Leq - 2 * lead) / (n - 0.5 + 2.2); }
/* 巻き数：自然の長さ（つりあいの長さ）L0 のとき、1 巻きの前進量が楕円の横半径 b の 1.15 倍くらい（縦長の楕円が少しずつずれて重なる）。
   L0 は図の大きさだけで決まり、伸び縮みでは変えない */
function coilN(L0, b, lead) { return clamp(Math.round((L0 - 2 * lead - 2 * b) / (1.7 * b) + 0.5), 6, 26); }
/* ばね定数 k〔N/m〕のときのばねの線の太さ。ばね定数が大きいほど太い（2026-10-16 千葉さん。プロジェクト共通のルール）
   k = 2.5 → 0.9、5 → 1.4、10 → 1.9、20 → 2.4、40 → 2.9 px */
function springLW(k) { return clamp(0.9 + 0.5 * Math.log(k / 2.5) / Math.LN2, 0.9, 3.6); }
function springDense(ctx, x1, y1, x2, y2, L0, o) {
  o = o || {}; var r = o.r || 8, b = r * 0.55, lead = o.lead === undefined ? 8 : o.lead;
  var lw = o.lw || (o.k ? springLW(o.k) * (o.thin || 1) : 1.25);         /* o.k：ばね定数（太さが変わる）。o.thin：小さな図で細くする倍率 */
  var n = coilN(L0, b, lead);
  if (o.Lmin) n = Math.max(4, Math.min(n, Math.floor((o.Lmin - 2 * lead - 2 * b) / (0.4 * b + lw) + 0.5)));   /* o.Lmin：いちばん縮んだときの長さ。そのときも巻きがつぶれて黒くならない巻き数に */
  springCoil(ctx, x1, y1, x2, y2, { n: n, r: r, b: b, lead: lead, lw: lw, col: o.col });
}
/* 半径の横に、両矢印と「A」（止まっているときだけ。①-1・①-2。2026-10-16 千葉さん）。side：半径のどちら側にずらすか（±1） */
/* 同じ長さを表す「＝」の印（変位・速度の「‖」と区別する。加速度用。2026-10-18 千葉さん）。始点 (x, y)・向き (ux, uy)・長さ L の矢印の 45 % の所の横に */
/* 同じ大きさの印「＝」。速度の等長マークと同じく、矢印の上に（矢印を横切る 2 本の線で）書く（2026-10-19 千葉さん）。side は使わない */
function eqSign(ctx, x, y, ux, uy, L, col, side) {
  var n = Math.hypot(ux, uy) || 1; ux /= n; uy /= n;
  var pos = Math.max(6, Math.min(L * 0.42, L - 13)), mx = x + ux * pos, my = y + uy * pos, px = -uy, py = ux, w = 5.6;
  ctx.save(); ctx.strokeStyle = col || COL.acc; ctx.lineWidth = 2.1; ctx.lineCap = 'round'; ctx.setLineDash([]);
  [-2.3, 2.3].forEach(function (d) { var cx = mx + ux * d, cy = my + uy * d; ctx.beginPath(); ctx.moveTo(cx - px * w, cy - py * w); ctx.lineTo(cx + px * w, cy + py * w); ctx.stroke(); });
  ctx.restore();
}
function radiusA(ctx, cx, cy, px, py, side, col) {
  var L = Math.hypot(px - cx, py - cy); if (L < 12) return;
  var ux = (px - cx) / L, uy = (py - cy) / L, nx = -uy * (side || 1), ny = ux * (side || 1), o = 11;
  dimLine(ctx, cx + nx * o, cy + ny * o, px + nx * o, py + ny * o, col || '#14171c');
  sym(ctx, 'A', (cx + px) / 2 + nx * (o + 11), (cy + py) / 2 + ny * (o + 11), { size: 15, color: col || '#14171c' });
}
/* エネルギーの量を表す矢印（力の矢印と違い、作用点の「・」をつけない・等長マークの対象にしない） */
function eArrow(ctx, x1, y1, x2, y2, col) {
  var L = Math.hypot(x2 - x1, y2 - y1); if (L < 2) return;
  var ux = (x2 - x1) / L, uy = (y2 - y1) / L, h = Math.min(10, L * 0.5), bx = x2 - ux * h, by = y2 - uy * h;
  ctx.save(); ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = 3;
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(bx, by); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(x2, y2); ctx.lineTo(bx - uy * h * .5, by + ux * h * .5); ctx.lineTo(bx + uy * h * .5, by - ux * h * .5); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(x1 - uy * 5, y1 + ux * 5); ctx.lineTo(x1 + uy * 5, y1 - ux * 5); ctx.lineWidth = 2; ctx.stroke();
  ctx.restore();
}

/* 振動子（弦の左端につながっている。2026-11-05 千葉さん 8 回目：弦と振動子を切らずにつなぐ）
   (px, py)＝弦の左端（振動子といっしょに上下する）、baseY＝台の上の高さ。o：{ w, h, label } */
function vibBox(ctx, px, py, baseY, o) {
  o = o || {}; var w = o.w || 22, h = o.h || 18, rx = px - w / 2;
  ctx.save();
  ctx.fillStyle = '#3a414c'; ctx.fillRect(rx - 1.5, py + h / 2, 3, Math.max(0, baseY - py - h / 2));   /* 支え棒 */
  rrect(ctx, rx - 20, baseY, 40, 16, 4); ctx.fill();                                                    /* 台 */
  ctx.fillStyle = '#e07b18'; rrect(ctx, px - w, py - h / 2, w, h, 4); ctx.fill();                        /* 振動子（右の辺が弦の端） */
  ctx.fillStyle = '#7a3b12'; ctx.beginPath(); ctx.arc(px, py, 3.2, 0, TAU); ctx.fill();                   /* 弦とのつなぎ目 */
  ctx.restore();
  if (o.label !== false) label(ctx, o.label || '振動子', rx, baseY + 26, { size: 11, bold: true, color: '#9c4e06' });
}
