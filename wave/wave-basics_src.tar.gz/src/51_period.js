/* ===== 51_period.js ===== */
/* =========================================================================
   1 周期分の波の進み方の図（教科書の図と同じ考え。①-1 横波・①-3 縦波）
   ・時刻 0, T/8, 2T/8, …, T の 9 段。左に時刻、その右に波源の等速円運動（角を黄色の扇形で）
   ・横波：P₀〜P₈（λ/8 ごと）の点の変位を緑の矢印で。糸の形は y = A sin 2π(t/T − x/λ)（届いた所だけ）
   ・縦波：P₀〜P₉ の玉とつるまきばね。つりあいの位置から玉までを緑の矢印。玉の動きを青の点線で上下につなぐ
   ・値は図のための決まった値（A と λ の比だけ）。式はほかの図と同じ本当の式
   ========================================================================= */
'use strict';
function periodFig(host, kind) {
  var wrap = el('div', 'perfig'), cv = el('canvas');
  wrap.appendChild(el('p', 'perh', kind === 'long' ? '縦波が 1 周期の間に進むようす' : '横波が 1 周期の間に進むようす'));
  wrap.appendChild(cv); host.appendChild(wrap);
  var o = { cv: cv, kind: kind, H: 400, draw: function () { drawPeriodFig(o); } };
  window.addEventListener('resize', function () { setTimeout(o.draw, 120); });
  return o;
}
function drawPeriodFig(o) {
  var cv = o.cv; if (!cv.offsetParent) return;
  var W = Math.max(260, Math.floor(cv.clientWidth || 400)), H = o.H, ctx = prep(cv, W, H);
  ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H);
  var top = 24, rh = (H - top - 6) / 9, lx = 6, cr = Math.min(13, rh * 0.36), ccx = 54 + cr;
  var long = o.kind === 'long', N = 8;                               /* 縦波も P₈ まで（P₉ には 1 周期の間に波が届かない） */                       /* 点の数 − 1 */
  var gx0 = ccx + cr + (long ? 30 : 22), gx1 = W - 10, dx = (gx1 - gx0) / N;
  var A = long ? dx * 0.42 : Math.min(rh * 0.36, 16);                  /* 横波：縦の振幅〔px〕／縦波：横の振幅〔px〕 */
  var lamPx = 8 * dx;                                                  /* λ = 8 目盛り */
  var ph = function (t, x) { return t - x / lamPx; };                  /* t：周期を 1 とした時刻、x：画素 → 位相（周期単位） */
  var disp = function (t, x) { var p = ph(t, x); return p < 0 ? 0 : Math.sin(TAU * p); };
  /* 見出しの P₀〜P₈ */
  for (var k = 0; k <= N; k++) label(ctx, 'P' + '₀₁₂₃₄₅₆₇₈₉'[k], gx0 + k * dx, 11, { size: 11, color: COL.ink2, bold: true });
  var prev = null;
  for (var r = 0; r <= 8; r++) {
    var t = r / 8, cy = top + rh * (r + 0.5);
    /* 時刻 */
    if (r === 0) label(ctx, '時刻 0', lx, cy, { size: 11, color: COL.ink, align: 'left' });
    else if (r === 8) { ctx.save(); ctx.font = 'italic 13px ' + MATH; ctx.fillStyle = COL.ink; ctx.textBaseline = 'middle'; ctx.fillText('T', lx + 14, cy); ctx.restore(); }
    else fracText(ctx, String(r), '8', lx + 2, cy, 11, COL.ink), mathStr(ctx, 'T', lx + 18, cy + 4, 12, COL.ink);
    /* 波源の等速円運動（角 θ = 2πt を黄色の扇形で） */
    var th = TAU * t;
    ctx.save(); ctx.fillStyle = 'rgba(250,215,90,.75)'; ctx.beginPath(); ctx.moveTo(ccx, cy); ctx.arc(ccx, cy, cr, 0, -th, true); ctx.closePath(); if (r) ctx.fill();
    ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(ccx, cy, cr, 0, TAU); ctx.stroke();
    var qx = ccx + cr * Math.cos(th), qy = cy - cr * Math.sin(th);
    ctx.beginPath(); ctx.moveTo(ccx, cy); ctx.lineTo(qx, qy); ctx.stroke();
    ctx.fillStyle = '#14171c'; ctx.beginPath(); ctx.arc(qx, qy, 2.6, 0, TAU); ctx.fill(); ctx.restore();
    /* 方眼（縦の線＝P の位置） */
    ctx.save(); ctx.strokeStyle = '#e3e6ea'; ctx.lineWidth = 1;
    for (var k2 = 0; k2 <= N; k2++) { ctx.beginPath(); ctx.moveTo(gx0 + k2 * dx, cy - rh * 0.46); ctx.lineTo(gx0 + k2 * dx, cy + rh * 0.46); ctx.stroke(); }
    ctx.restore();
    if (!long) {
      /* 円の点 → P₀（波源）を点線で */
      dotted(ctx, qx, qy, gx0, qy, 'rgba(22,99,181,.6)', [2, 3]);
      ctx.save(); ctx.strokeStyle = '#d5d9de'; ctx.beginPath(); ctx.moveTo(gx0, cy); ctx.lineTo(gx1, cy); ctx.stroke(); ctx.restore();
      ctx.save(); ctx.strokeStyle = '#7a3b12'; ctx.lineWidth = 2.2; ctx.beginPath();
      for (var i = 0; i <= 200; i++) { var xx = (gx1 - gx0) * i / 200, py = cy - A * disp(t, xx); if (i) ctx.lineTo(gx0 + xx, py); else ctx.moveTo(gx0 + xx, py); }
      ctx.stroke(); ctx.restore();
      for (var k3 = 0; k3 <= N; k3++) {
        var d = disp(t, k3 * dx), px = gx0 + k3 * dx, pyk = cy - A * d;
        if (Math.abs(A * d) > 2) vArrow2(ctx, px + 4, cy, pyk, '#1c8f4a', 1.6);   /* 変位（点から少しずらす） */
        ctx.fillStyle = '#5b3a20'; ctx.beginPath(); ctx.arc(px, pyk, 2.4, 0, TAU); ctx.fill();
      }
    } else {
      /* 縦波：玉の位置 x = xₖ + A sin 2π(t − xₖ/λ)。密な所（ばねの間かくがせまい）をうすい橙で */
      var xs = []; for (var k4 = 0; k4 <= N; k4++) xs.push(gx0 + k4 * dx + A * disp(t, k4 * dx));
      for (var k5 = 0; k5 < N; k5++) { var gap = xs[k5 + 1] - xs[k5]; if (gap < dx * 0.85) { ctx.save(); ctx.fillStyle = 'rgba(224,123,24,' + (0.35 * (1 - gap / dx)).toFixed(3) + ')'; ctx.fillRect(xs[k5], cy - rh * 0.22, gap, rh * 0.44); ctx.restore(); } }
      /* つるまきばね（玉と玉の間に巻き 5 つ） */
      ctx.save(); ctx.strokeStyle = 'rgba(58,65,76,.45)'; ctx.lineWidth = 1;
      for (var k6 = 0; k6 < N; k6++) { var a0 = xs[k6], a1 = xs[k6 + 1]; for (var c = 0; c < 3; c++) { var xc = a0 + (a1 - a0) * (c + 0.5) / 3; ctx.beginPath(); ctx.ellipse(xc, cy, Math.max(1, (a1 - a0) / 8), rh * 0.17, 0, 0, TAU); ctx.stroke(); } }
      ctx.restore();
      /* 玉の動きの線（前の段の同じ玉と青の点線で） */
      if (prev) for (var k7 = 0; k7 <= N; k7++) dotted(ctx, prev.xs[k7], prev.cy + 5, xs[k7], cy - 5, 'rgba(22,99,181,.6)', [3, 3]);
      for (var k8 = 0; k8 <= N; k8++) {
        var e0 = gx0 + k8 * dx;
        if (Math.abs(xs[k8] - e0) > 2) hArrow(ctx, e0, xs[k8], cy + rh * 0.3, '#1c8f4a', 1.6);   /* 変位（玉の下に少し離して） */
        bead(ctx, xs[k8], cy, Math.min(4.6, rh * 0.16), '#8a6a43');
      }
      prev = { xs: xs, cy: cy };
    }
  }
}
