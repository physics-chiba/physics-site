/* ===== 52_m1s2.js ===== */
/* =========================================================================
   ①-2 y-x グラフと y-t グラフ（参考②）
   ・連続波だけ。t = 0 で媒質全体に波がある。y-x グラフ（左）の原点の左に、原点 O に対応する等速円運動
   ・y-t を見る点は 1 つ（吹き出し）。既定は右端の点 E。O〜E のボタンか、★ をドラッグして選ぶ
   ・波の進む向き（x 軸の正・負）、t = 0 の波形（▲▼ で 1/4 波長ずつずらす）、再生・コマ送り（T/8）・最初から
   ・スライドバー：A・λ・f・T（f と T は連動）。v は「左の値で決まる」
   ========================================================================= */
'use strict';
var M1S2_PTS = ['O', 'A', 'B', 'C', 'D', 'E'];
var M1S2_AMAX = 0.20;
function m1s2Q(s) { var f = s.v.f; return { A: s.v.A, lam: s.v.lam, f: f, T: 1 / f, v: f * s.v.lam, dir: s.dir, x0: s.x0i * s.v.lam / 4 }; }
function m1s2Xp(s) { var q = m1s2Q(s); return s.ptX !== null && s.ptX !== undefined ? s.ptX : s.pt * q.lam / 4; }
function m1s2PtName(s) { return (s.ptX !== null && s.ptX !== undefined) ? 'P' : M1S2_PTS[s.pt]; }
/* fromO（t = 0 から原点を波源として振動が始まる）：波がまだ届いていない点（t < x/v）は 0。届いた点は同じ式（波源の振動が x/v 遅れて伝わる） */
function m1s2Y(s, x, t) { var q = m1s2Q(s); if (s.fromO && x > 0 && t < x / q.v) return 0; return SINE.y(q.A, q.lam, q.f, q.dir, q.x0, x, t); }
DEFS.m1s2 = {
  id: 'm1s2', mode: 'mode1', num: 2,
  title: '$y$-$x$ グラフと $y$-$t$ グラフ', short: 'y-x グラフと y-t グラフ',
  desc: '左は<b>ある時刻の波形</b>（$y$-$x$ グラフ）、右は ★ の点の<b>変位の時間変化</b>（$y$-$t$ グラフ）。<span class="todo">「スタート」を押して、2 つのグラフを比べよう。</span>',
  strobe: false, stepDiv: 8,
  /* スライダーはなし（2026-11-03 千葉さん）。A = 0.10 m、λ = 0.50 m、f = 2.0 Hz で固定 */
  init: function (s) { s.v.A = M1.s2.A0; s.v.lam = M1.s2.lam0; s.v.f = M1.s2.f0; s.dir = 1; s.pt = 5; s.ptX = null; s.x0i = 2; s.showDt = false; s.fromO = false; },
  onDefaults: function (s) { if (s.wg) { s.wg.sel = null; s.wgt.sel = null; s.wg.reset(); s.wgt.reset(); } m1s2Sync(s); },
  onReset: function (s) { m1s2Sync(s); },
  buttons: [
    { k: 'dp', label: '$x$ 軸の正の向き', seg: 'dir', segLabel: '波の進む向き', onClick: function (s) { s.dir = 1; m1s2Sync(s); s.resetT(); } },
    { k: 'dn', label: '$x$ 軸の負の向き', seg: 'dir', onClick: function (s) { s.dir = -1; s.fromO = false; m1s2Sync(s); s.resetT(); } }   /* 原点が波源のときは正の向きだけ */
  ].concat(M1S2_PTS.map(function (n, i) {
    return { k: 'p' + i, label: n, seg: 'pt', segLabel: 'y-t グラフを見る点', cls: 'ptb', onClick: function (s) { s.pt = i; s.ptX = null; m1s2Sync(s); s.draw(); } };
  })),
  tEnd: function () { return 2.0; },                                 /* 時間は 2.0 s まで（2026-11-03 千葉さん） */
  baseRate: 0.24,                                                     /* ふだんの再生は実際の 0.24 倍（前のスロー 0.3 倍のさらに 0.8 倍）。🐢 スローはその 0.3 倍 */
  tInfo: function (s) { return periodInfo(m1s2Q(s).T); },
  gT: function (s) { return m1s2Q(s).T; },
  height: function () { return 8; },
  afterBuild: function (s) {
    /* ボタンの文字を KaTeX に／見出しの札 */
    ['dp', 'dn'].forEach(function (k) { s.extra[k].innerHTML = mathify(s.extra[k].innerHTML); });
    var segs = s.row1b.querySelectorAll('.seg');
    if (segs[0]) segs[0].insertAdjacentElement('beforebegin', el('span', 'seglbl', '波の進む向き'));
    if (segs[1]) segs[1].insertAdjacentElement('beforebegin', el('span', 'seglbl', mathify('$y$-$t$ を見る点')));
    /* t = 0 での波形（小さな図と ▲▼）と「Δt 後の波形を表示」 */
    var w0 = el('div', 'w0box'); w0.appendChild(el('span', 'seglbl', mathify('$t = 0$ での波形')));
    s.w0cv = el('canvas', 'w0cv'); w0.appendChild(s.w0cv);
    var ud = el('span', 'w0ud');
    [['▲', 1, '波形を 1/4 波長ずらす'], ['▼', -1, '波形を逆向きに 1/4 波長ずらす']].forEach(function (p) {
      var b = el('button', 'b w0b', p[0]); b.type = 'button'; b.title = p[2]; b.setAttribute('aria-label', p[2]);
      b.addEventListener('click', function () { s.x0i = (s.x0i + p[1] + 4) % 4; m1s2Sync(s); s.resetT(); });
      ud.appendChild(b);
    });
    w0.appendChild(ud);
    var bd = el('button', 'b chkb dtb', mathify('$\\Delta t$ 後の波形を表示')); bd.type = 'button'; bd.title = '少し時間が進んだ（T/8 後の）波形を点線で重ねる';
    bd.addEventListener('click', function () { s.showDt = !s.showDt; m1s2Sync(s); s.draw(); });
    w0.appendChild(bd); s.extra.dt = bd;
    /* 「t = 0 から原点を波源として振動が始まる」（Δt の下の段。2026-11-04 千葉さん 6 回目）：★ の点には遅れて波が届く */
    var bo = el('button', 'b chkb fob', mathify('$t = 0$ から原点を波源として振動が始まる場合')); bo.type = 'button';
    bo.title = '波が届くまで、★ の点は振動しない（y-t グラフに y = 0 の時間ができる）';
    bo.addEventListener('click', function () { s.fromO = !s.fromO; if (s.fromO) s.dir = 1; m1s2Sync(s); s.resetT(); });
    s.extra.fo = bo;
    s.row1b.appendChild(w0);
    var fr = el('div', 'forow'); fr.appendChild(s.extra.fo); s.row1b.appendChild(fr);
    /* 左：y-x グラフ（Sim の canvas の代わり）。原点の左に等速円運動 */
    s.cv.style.display = 'none';
    var GH = function () { return Math.round(clamp((s.W || 600) * 0.42, 220, 300)); };   /* y-x グラフの高さ */
    var GHs = function () { return Math.round(GH() * 0.78); };       /* y-t グラフ 2 つは、ひと回り・ふた回り小さく、同じ大きさ（2026-11-03 千葉さん 3 回目） */
    s.wg = new WGraph({
      host: s.cw, key: 'yx', title: '$y$-$x$ グラフ', xKey: 'm1s2-x', xsym: 'x', xunit: 'm', ysym: 'y', yunit: 'm',
      noReset: true, lockY: true,
      xDef: function () { return { lo: 0, hi: 1.5 * m1s2Q(s).lam }; },   /* 右に吹き出しの場所（★ の真上に吹き出しの左はし） */
      yDef: function () { return { lo: -M1S2_AMAX, hi: M1S2_AMAX }; },
      xTicks: 'lam', period: function () { return m1s2Q(s).lam; },
      H: GH,
      series: function () {
        var a = [{ color: '#7a3b12', width: 2.6, f: function (x) { return m1s2Y(s, x, s.t); } }];
        if (s.showDt) { var dt = m1s2Q(s).T / 8; a.push({ color: '#7a3b12', width: 2, dash: [6, 5], alpha: 0.75, pick: false, f: function (x) { return m1s2Y(s, x, s.t + dt); } }); }
        return a;
      },
      front: function (ctx, g) { m1s2Front(s, ctx, g); },
      drag: function (px, py, g, test) {
        var xp = m1s2Xp(s), sx = g.X(xp), sy = g.Y(m1s2Y(s, xp, s.t));
        if (Math.hypot(px - sx, py - sy) > 14) return null;
        if (test) return true;
        return {
          move: function (mx) {
            var q = m1s2Q(s), x = clamp(g.xa.lo + (mx - g.R.x0) / (g.R.x1 - g.R.x0) * (g.xa.hi - g.xa.lo), 0, 1.32 * q.lam), k = Math.round(x / (q.lam / 4));
            if (k >= 0 && k <= 5 && Math.abs(g.X(k * q.lam / 4) - mx) < 9) { s.pt = k; s.ptX = null; } else s.ptX = x;
            m1s2Sync(s); s.draw();
          },
          end: function () { }
        };
      }
    });
    /* 右の列：スライダーの場所に操作（波の進む向き・すべて最初の設定に戻す・見る点・t = 0 の波形・Δt 後）→ y-t グラフ → 説明 */
    s.R.innerHTML = ''; var cp = el('div', 'm2ctl'); cp.appendChild(s.row1b); s.R.appendChild(cp);
    var gh = el('div', 'ghost'); s.R.appendChild(gh); s.gHostR = gh;
    s.wg.box.classList.add('bigt');
    s.wgt = new WGraph({
      host: gh, key: 'yt', title: '$y$-$t$ グラフ', xKey: 'm1s2-t', xsym: 't', xunit: 's', ysym: 'y', yunit: 'm', yCm: true,
      noReset: true, lockY: true,
      xDef: function () { return { lo: 0, hi: 2.04 }; },
      yDef: function () { return { lo: -M1S2_AMAX, hi: M1S2_AMAX }; },
      xTicks: 'T', period: function () { return m1s2Q(s).T; },
      H: GHs,
      series: function () { var xp = m1s2Xp(s); return [{ color: '#1c6b8f', width: 2.6, x0: 0, x1: s.t, f: function (t) { return m1s2Y(s, xp, t); } }]; },
      now: function () { return s.t; },
      front: function (ctx, g) {
        var y = m1s2Y(s, m1s2Xp(s), s.t), px = g.X(s.t), py = g.Y(y);
        if (px >= g.R.x0 - 1 && px <= g.R.x1 + 1) starShape(ctx, px, py, 9, '#e07b18');   /* y-x グラフの ★ と同じ印 */
        if (!s.playing) { var xp2 = m1s2Xp(s); m1s2Dims(ctx, g, function (t) { return m1s2Y(s, xp2, t); }, 0, s.t, 'T'); }
      }
    });
    /* 左：y-x グラフの下に、点 O の y-t グラフ。その左に O に対応する等速円運動（2026-11-03 千葉さん） */
    /* 点 O の y-t グラフは、原点 O から伸びた吹き出しの中（図 1 のとおり。2026-11-03 千葉さん 3 回目） */
    s.obub = el('div', 'obub'); s.cw.appendChild(s.obub);
    s.bsvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); s.bsvg.setAttribute('class', 'obubsvg'); s.bsvg.setAttribute('aria-hidden', 'true');
    s.bpath = document.createElementNS('http://www.w3.org/2000/svg', 'path'); s.bsvg.appendChild(s.bpath);
    s.bhead = document.createElementNS('http://www.w3.org/2000/svg', 'path'); s.bsvg.appendChild(s.bhead);
    s.cw.appendChild(s.bsvg);
    s.wgo = new WGraph({
      host: s.obub, key: 'yo', title: '点 O（◆）の $y$-$t$ グラフ', xKey: 'm1s2-t', xsym: 't', xunit: 's', ysym: 'y', yunit: 'm', yCm: true,
      noReset: true, lockY: true,
      xDef: function () { return { lo: 0, hi: 2.04 }; },
      yDef: function () { return { lo: -M1S2_AMAX, hi: M1S2_AMAX }; },
      xTicks: 'T', period: function () { return m1s2Q(s).T; },
      padL: 0, H: GHs,
      series: function () { return [{ color: '#1c6b8f', width: 2.6, x0: 0, x1: s.t, f: function (t) { return m1s2Y(s, 0, t); } }]; },
      now: function () { return s.t; },
      back: function (ctx, g) { m1s2Circle(s, ctx, g); },
      front: function (ctx, g) {
        var px = g.X(s.t), py = g.Y(m1s2Y(s, 0, s.t));
        if (px >= g.R.x0 - 1 && px <= g.R.x1 + 1) oMark(ctx, px, py);   /* y-x グラフの原点の印と同じ */
        if (!s.playing) m1s2Dims(ctx, g, function (t) { return m1s2Y(s, 0, t); }, 0, s.t, 'T');
      }
    });
    s.Rdyn = el('div', 'rdyn m2read'); s.R.appendChild(s.Rdyn);
    m1s2Sync(s);
    window.addEventListener('resize', function () { setTimeout(function () { m1s2Align(s); }, 160); });
  },
  draw: function (s) {
    if (!s.wg) return;
    if (s.playing && s.showDt) { s.showDt = false; m1s2Sync(s); }      /* アニメが始まったら Δt 後の波形は消す */
    var R0 = M1S2_AMAX, H = s.wg.o.H(), plotH = H - GPAD.t - GPAD.b, yr = niceRange(-R0, R0), r = M1S2_AMAX / (yr.hi - yr.lo) * plotH;
    var Hs = s.wgt.o.H(), rs = M1S2_AMAX / (yr.hi - yr.lo) * (Hs - GPAD.t - GPAD.b);
    var pl = Math.round(2 * rs + 40); if (s.wgo.o.padL !== pl) s.wgo.o.padL = pl;
    m1s2Size(s, pl);
    s.wg.draw(); s.wgt.draw(); s.wgo.draw();
    m1s2DrawW0(s);
    if (!s.playing) m1s2Align(s);
    m1s2Bubble(s);
  },
  right: function (s, R) { rightM1S2(s, R); }
};
/* 左の y-x グラフと右の y-t グラフで、y = 0 の線の高さ（縦の中心）をそろえる。低い方の上にすきまを入れる（2 列のときだけ） */
function m1s2Align(s) {
  if (!s.wg || !s.wg.g || !s.wgt.g) return;
  var a = s.cw, b = s.gHostR; a.style.marginTop = ''; b.style.marginTop = '';
  if (window.innerWidth <= 880 || document.body.classList.contains('hideeq') || !a.offsetParent || !b.offsetParent) return;
  var z = function (g) { return g.cv.getBoundingClientRect().top + g.g.Y(0); };
  for (var i = 0; i < 3; i++) {
    var d = Math.round(z(s.wg) - z(s.wgt));
    if (Math.abs(d) < 1) break;
    if (d > 0) b.style.marginTop = (parseFloat(b.style.marginTop || 0) + d) + 'px';
    else a.style.marginTop = (parseFloat(a.style.marginTop || 0) - d) + 'px';
  }
}
/* y-t グラフ 2 つの大きさ：グラフの部分（枠の中）の幅と高さを同じにする。広い画面では右の列の 0.78 倍 */
function m1s2Size(s, padLo) {
  var bt = s.wgt.box, bo = s.wgo.box;
  if (bt.classList.contains('gmax') || bo.classList.contains('gmax')) { bt.style.width = ''; bo.style.width = ''; return; }
  var pad = 2 * parseFloat(getComputedStyle(bt).paddingLeft || 0);
  var wide = window.innerWidth > 880 && !document.body.classList.contains('hideeq');
  var aR = s.gHostR.clientWidth - pad - GPAD.l - GPAD.r, ob = getComputedStyle(s.obub), aL = s.obub.clientWidth - parseFloat(ob.paddingLeft) - parseFloat(ob.paddingRight) - pad - padLo - GPAD.r;
  if (!(aR > 0) || !(aL > 0)) return;
  var pw = Math.floor(Math.min(wide ? aR * 0.78 : aR, aL));
  var wR = (pad + GPAD.l + pw + GPAD.r) + 'px', wL = (pad + padLo + pw + GPAD.r) + 'px';
  if (bt.style.width !== wR) bt.style.width = wR;
  if (bo.style.width !== wL) bo.style.width = wL;
}
/* 原点 O から点 O の y-t グラフへの吹き出し（SVG を重ねる）。とがった先は原点 O、先に矢じり */
function m1s2Bubble(s) {
  var svg = s.bsvg; if (!svg || !s.wg.g) return;
  if (s.wgo.box.classList.contains('gmax') || !s.obub.offsetParent) { svg.style.display = 'none'; return; }
  svg.style.display = '';
  var c = s.cw.getBoundingClientRect(), a = s.wg.cv.getBoundingClientRect(), b = s.obub.getBoundingClientRect();
  var W = Math.round(c.width), H = Math.round(c.height);
  svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H); svg.setAttribute('width', W); svg.setAttribute('height', H);
  var ox = a.left - c.left + s.wg.g.X(0), oy = a.top - c.top + s.wg.g.Y(0);
  var x0 = b.left - c.left + 1, y0 = b.top - c.top + 1, x1 = b.right - c.left - 1, y1 = b.bottom - c.top - 1, r = 26;
  var bw = x1 - x0, t1 = x0 + Math.max(r + 6, bw * 0.14), t2 = x0 + Math.max(r + 70, bw * 0.36);
  /* とがった先は原点の少し手前（矢じりの分） */
  var dx = ox - (t1 + t2) / 2, dy = oy - y0, L = Math.hypot(dx, dy) || 1, ux = dx / L, uy = dy / L;
  var tx = ox - ux * 6, ty = oy - uy * 6;
  var d = 'M' + (x0 + r) + ' ' + y0 + ' L' + t1 + ' ' + y0 + ' L' + tx.toFixed(1) + ' ' + ty.toFixed(1) + ' L' + t2 + ' ' + y0 +
    ' L' + (x1 - r) + ' ' + y0 + ' Q' + x1 + ' ' + y0 + ' ' + x1 + ' ' + (y0 + r) + ' L' + x1 + ' ' + (y1 - r) + ' Q' + x1 + ' ' + y1 + ' ' + (x1 - r) + ' ' + y1 +
    ' L' + (x0 + r) + ' ' + y1 + ' Q' + x0 + ' ' + y1 + ' ' + x0 + ' ' + (y1 - r) + ' L' + x0 + ' ' + (y0 + r) + ' Q' + x0 + ' ' + y0 + ' ' + (x0 + r) + ' ' + y0 + ' Z';
  if (s.bpath._d !== d) { s.bpath._d = d; s.bpath.setAttribute('d', d); }
  /* 矢じり（原点に向ける） */
  var hx = ox - ux * 2, hy = oy - uy * 2, px = -uy, py = ux, hl = 11, hw = 5;
  var h = 'M' + hx.toFixed(1) + ' ' + hy.toFixed(1) + ' L' + (hx - ux * hl + px * hw).toFixed(1) + ' ' + (hy - uy * hl + py * hw).toFixed(1) + ' L' + (hx - ux * hl - px * hw).toFixed(1) + ' ' + (hy - uy * hl - py * hw).toFixed(1) + ' Z';
  if (s.bhead._d !== h) { s.bhead._d = h; s.bhead.setAttribute('d', h); }
  m1s2StarBubble(s);
}
/* ★ の点から右の列の y-t グラフへの吹き出し（広い画面のとき。2026-11-07 千葉さん 15 回目） */
function m1s2StarBubble(s) {
  var sec = document.getElementById('m1s2'); if (!sec || !s.wgt.g) return;
  if (!s.ssvg) {
    s.ssvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); s.ssvg.setAttribute('class', 'starbubsvg'); s.ssvg.setAttribute('aria-hidden', 'true');
    s.spath = document.createElementNS('http://www.w3.org/2000/svg', 'path'); s.ssvg.appendChild(s.spath); sec.appendChild(s.ssvg);
  }
  var narrow = window.innerWidth <= 880 || document.body.classList.contains('hideeq');
  var xp = m1s2Xp(s), g = s.wg.g, sxr = g.X(xp);
  if (narrow || s.wgt.box.classList.contains('gmax') || s.wg.box.classList.contains('gmax') || !s.gHostR.offsetParent || sxr < g.R.x0 - 2 || sxr > g.R.x1 + 2) { s.ssvg.style.display = 'none'; return; }
  s.ssvg.style.display = '';
  var c = sec.getBoundingClientRect(), a = s.wg.cv.getBoundingClientRect(), b = s.wgt.box.getBoundingClientRect();
  var W = Math.round(c.width), H = Math.round(c.height);
  s.ssvg.setAttribute('viewBox', '0 0 ' + W + ' ' + H); s.ssvg.setAttribute('width', W); s.ssvg.setAttribute('height', H);
  var sx = a.left - c.left + sxr + 12, sy = a.top - c.top + g.Y(0);   /* 先は ★ のつり合いの位置（y = 0）。点 O の吹き出しと同じく動かさない（22 回目） */
  var x0 = b.left - c.left - 8, y0 = b.top - c.top - 8, x1 = b.right - c.left + 8, y1 = b.bottom - c.top + 8, r = 18;
  var ty = clamp(sy, y0 + r + 16, y1 - r - 16), t1 = ty - 14, t2 = ty + 14;
  var d = 'M' + (x0 + r) + ' ' + y0 + ' L' + (x1 - r) + ' ' + y0 + ' Q' + x1 + ' ' + y0 + ' ' + x1 + ' ' + (y0 + r) + ' L' + x1 + ' ' + (y1 - r) + ' Q' + x1 + ' ' + y1 + ' ' + (x1 - r) + ' ' + y1 +
    ' L' + (x0 + r) + ' ' + y1 + ' Q' + x0 + ' ' + y1 + ' ' + x0 + ' ' + (y1 - r) + ' L' + x0 + ' ' + t2.toFixed(1) + ' L' + sx.toFixed(1) + ' ' + sy.toFixed(1) + ' L' + x0 + ' ' + t1.toFixed(1) +
    ' L' + x0 + ' ' + (y0 + r) + ' Q' + x0 + ' ' + y0 + ' ' + (x0 + r) + ' ' + y0 + ' Z';
  if (s.spath._d !== d) { s.spath._d = d; s.spath.setAttribute('d', d); }
}
/* 原点 O の印（y-x グラフの O と、点 O の y-t グラフの動く点） */
function oMark(ctx, x, y) {
  ctx.save(); ctx.beginPath(); ctx.moveTo(x, y - 8); ctx.lineTo(x + 7, y); ctx.lineTo(x, y + 8); ctx.lineTo(x - 7, y); ctx.closePath();
  ctx.fillStyle = '#1663b5'; ctx.fill(); ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.4; ctx.stroke(); ctx.restore();
}
function m1s2Sync(s) {
  [['dp', 1], ['dn', -1]].forEach(function (p) { var b = s.extra[p[0]]; if (b) { b.classList.toggle('on', s.dir === p[1]); b.setAttribute('aria-pressed', s.dir === p[1] ? 'true' : 'false'); } });
  M1S2_PTS.forEach(function (n, i) { var b = s.extra['p' + i]; if (b) { var on = (s.ptX === null || s.ptX === undefined) && s.pt === i; b.classList.toggle('on', on); b.setAttribute('aria-pressed', on ? 'true' : 'false'); } });
  if (s.extra.dt) { s.extra.dt.classList.toggle('on', !!s.showDt); s.extra.dt.setAttribute('aria-pressed', s.showDt ? 'true' : 'false'); }
  if (s.extra.fo) { s.extra.fo.classList.toggle('on', !!s.fromO); s.extra.fo.setAttribute('aria-pressed', s.fromO ? 'true' : 'false'); }
  if (s.wgt) {
    var tt = s.wgt.box.querySelector('.gt'), h = mathify('点 ' + m1s2PtName(s) + '（★）の $y$-$t$ グラフ');
    if (tt && tt._h !== h) { tt._h = h; tt.innerHTML = h; }
    s.wgt.sel = null;
  }
  if (s.Rdyn) s.renderRight();
}
/* 原点 O の左の等速円運動（半径＝A。縦の縮尺は y-x グラフと同じ） */
function m1s2Circle(s, ctx, g) {
  var q = m1s2Q(s), r = q.A / (g.yr.hi - g.yr.lo) * (g.R.y1 - g.R.y0), cy = g.Y(0), cx = g.R.x0 - 18 - M1S2_AMAX / (g.yr.hi - g.yr.lo) * (g.R.y1 - g.R.y0);
  if (cx - r < 2) return;
  var ph = SINE.phase(q.lam, q.dir, q.x0, 0), th = TAU * q.f * s.t + ph;
  var xNow = clamp(g.X(s.t), g.R.x0, g.R.x1);                        /* 円の上の点と、y-t グラフのいまの点を結ぶ */
  srcCircle(ctx, cx, cy, r, th, xNow, { label: false, axisX: g.R.x0, noAxis: true, ring: true });   /* y-t グラフの y 軸の上を動く点（①-1 と同じ） */
  label(ctx, '等速円運動', cx, Math.min(g.H - 8, cy + r + 18), { size: 10.5, color: COL.ink2 });
}
/* y-x グラフの前：点 O〜E、★ の点、吹き出し、波の進む向き */
function m1s2Front(s, ctx, g) {
  var q = m1s2Q(s), y0 = g.Y(0);
  ctx.save(); ctx.beginPath(); ctx.rect(g.R.x0 - 6, 0, g.R.x1 - g.R.x0 + 12, g.H); ctx.clip();
  M1S2_PTS.forEach(function (n, i) {
    var x = i * q.lam / 4, px = g.X(x); if (px < g.R.x0 - 2 || px > g.R.x1 + 2) return;
    var py = g.Y(m1s2Y(s, x, s.t));
    ctx.fillStyle = '#3a414c'; ctx.beginPath(); ctx.arc(px, y0, 2.4, 0, TAU); ctx.fill();
    label(ctx, n, px + (i === 0 ? -9 : 0), y0 + 12, { size: 12, color: COL.ink2, bold: true, clamp: false });
    ctx.fillStyle = '#7a3b12'; ctx.beginPath(); ctx.arc(px, py, 3.6, 0, TAU); ctx.fill();
  });
  /* 原点 O の印（◆）。点 O の y-t グラフの動く点と同じ */
  var o0x = g.X(0); if (o0x >= g.R.x0 - 2 && o0x <= g.R.x1 + 2) oMark(ctx, o0x, g.Y(m1s2Y(s, 0, s.t)));
  /* ★ の点（y-t を見る点） */
  var xp = m1s2Xp(s), sx = g.X(xp), sy = g.Y(m1s2Y(s, xp, s.t));
  if (sx >= g.R.x0 - 2 && sx <= g.R.x1 + 2) {
    starShape(ctx, sx, sy, 9, '#e07b18');
    if (s.ptX !== null && s.ptX !== undefined) label(ctx, 'P', sx, y0 + 12, { size: 12, color: '#c9670c', bold: true, clamp: false });
  }
  ctx.restore();
  var narrowS = window.innerWidth <= 880 || document.body.classList.contains('hideeq');
  if (narrowS && sx >= g.R.x0 - 2 && sx <= g.R.x1 + 2) {          /* せまい画面だけ。広い画面では ★ から右の y-t グラフへ吹き出し（m1s2Bubble）。吹き出し（2 行）。左はしを ★ の真上に（2026-11-03 千葉さん 5 回目）。引き出し線はまっすぐ下へ */
    var nm = m1s2PtName(s), narrow = window.innerWidth <= 880 || document.body.classList.contains('hideeq');
    var l1 = '点 ' + nm + ' の y-t', l2 = 'グラフは' + (narrow ? '下 ↓' : '右 →');
    ctx.save(); ctx.font = '700 11.5px ' + FONT; var bw = Math.max(ctx.measureText(l1).width, ctx.measureText(l2).width) + 20, bh = 38;
    var bx = Math.min(sx - 6, g.W - bw - 3), by = g.R.y0 + 4, lx = clamp(sx, bx + 6, bx + bw - 6);
    ctx.strokeStyle = '#c9670c'; ctx.lineWidth = 1.2; ctx.setLineDash([3, 3]); ctx.beginPath(); ctx.moveTo(lx, by + bh); ctx.lineTo(sx, g.Y(0) - 10); ctx.stroke();   /* 線の先は y = 0 の位置で止めておく（22 回目） */ ctx.setLineDash([]);
    ctx.shadowColor = 'rgba(20,23,28,.16)'; ctx.shadowBlur = 10; ctx.shadowOffsetY = 3; ctx.fillStyle = '#fff5d6'; rrect(ctx, bx, by, bw, bh, 10); ctx.fill(); ctx.shadowColor = 'transparent';
    ctx.strokeStyle = '#d9a545'; ctx.lineWidth = 1.4; ctx.stroke(); ctx.fillStyle = '#8a5000'; ctx.textBaseline = 'middle'; ctx.fillText(l1, bx + 10, by + 11.5); ctx.fillText(l2, bx + 10, by + 27); ctx.restore();
  }
  /* スタート前は図の上に「時刻 t = 0 の波形」。せまい画面では左に置き、右上の吹き出しと重なるときは吹き出しの下の段へ（21 回目） */
  if (!s.playing && s.t === 0) {
    var tSz = narrowS ? 14 : 19, tY = g.R.y0 + 12;
    if (narrowS && bx !== undefined) { ctx.save(); ctx.font = '700 ' + tSz + 'px ' + FONT; var tW = ctx.measureText('時刻 t = 0 の波形').width; ctx.restore(); if (g.R.x0 + 10 + tW > bx - 6) tY = by + bh + 12; }
    label(ctx, '時刻 t = 0 の波形', narrowS ? g.R.x0 + 10 : (g.R.x0 + g.R.x1) / 2, tY, { size: tSz, bold: true, color: COL.ink, align: narrowS ? 'left' : 'center' });
  }
  /* 止まっているときは λ と A（①-1 と同じ） */
  if (!s.playing) m1s2Dims(ctx, g, function (x) { return m1s2Y(s, x, s.t); }, Math.max(0, g.xa.lo), g.xa.hi, 'λ');
  /* Δt 後の波形の名札（点線の右はし近く） */
  /* Δt 後の波形の名札：点線の山の右（見やすい所）。点線の谷へ、もとの波の谷から矢印（Δt の間に波が進んだ向きと距離） */
  if (s.showDt) {
    var qd = m1s2Q(s), dtl = qd.T / 8, fd = function (x) { return m1s2Y(s, x, s.t + dtl); }, f0 = function (x) { return m1s2Y(s, x, s.t); };
    var lo = Math.max(0, g.xa.lo), hi = g.xa.hi, ddx = (hi - lo) / 600;
    var cD = crestsOf(fd, lo + ddx, hi - ddx, ddx, qd.A * 0.95), tD = crestsOf(function (x) { return -fd(x); }, lo + ddx, hi - ddx, ddx, qd.A * 0.95), t0s = crestsOf(function (x) { return -f0(x); }, lo + ddx, hi - ddx, ddx, qd.A * 0.95);
    var cx = cD.filter(function (x) { return g.X(x) < g.R.x1 - 150; }); cx = cx.length ? cx[0] : (cD[0] || lo + (hi - lo) * 0.3);
    label(ctx, 'Δt 後の波形（点線）', g.X(cx) + 12, g.Y(fd(cx)) - 2, { size: 11, bold: true, color: '#7a3b12', align: 'left' });
    /* もとの谷 → 点線の谷（同じ谷が Δt の間に動いた所） */
    tD.forEach(function (xd) {
      var x0 = qd.dir > 0 ? xd - qd.v * dtl : xd + qd.v * dtl, ok = t0s.some(function (z) { return Math.abs(z - x0) < 1e-3 * qd.lam + 2 * ddx; });
      if (!ok || g.X(x0) < g.R.x0 || g.X(xd) > g.R.x1) return;
      var yy = g.Y(-qd.A) + 28; dotted(ctx, g.X(x0), g.Y(-qd.A) + 4, g.X(x0), yy + 4, 'rgba(122,59,18,.5)', [2, 2]); dotted(ctx, g.X(xd), g.Y(-qd.A) + 4, g.X(xd), yy + 4, 'rgba(122,59,18,.5)', [2, 2]); hArrow(ctx, g.X(x0), g.X(xd), yy, '#7a3b12', 2);
    });
  }
  /* 波の進む向き（右下。右上は吹き出しの場所） */
  var ax = g.R.x1 - 64, ay = g.R.y1 - 10, d = q.dir;
  label(ctx, '波の進む向き', ax - 8, ay, { size: 11, color: '#1663b5', align: 'right' });
  arrow(ctx, d > 0 ? ax : ax + 54, ay, d > 0 ? ax + 54 : ax, ay, 'vel', COL.vel);
}
/* 止まっているときの寸法：となりあう山と山（なければ谷と谷）の間に λ（または T）、最初の山に A。f：横軸の値 → y */
function m1s2Dims(ctx, g, f, lo, hi, name) {
  if (!(hi > lo)) return;
  var dx = (hi - lo) / 800, A = M1.s2.A0, col = name === 'T' ? '#1c6b8f' : '#c9670c';
  var crs = crestsOf(f, lo + dx, hi - dx, dx, A * 0.95), trs = crestsOf(function (x) { return -f(x); }, lo + dx, hi - dx, dx, A * 0.95);
  /* 同じ位相の点の組：山と山 → 谷と谷 → 上向きに 0 を横切る点どうし → 下向き、の順に、2 つあるものを使う */
  var zu = [], zd = [];
  for (var x = lo + dx; x < hi - dx; x += dx) { var a1 = f(x), a2 = f(x + dx); if (a1 < 0 && a2 >= 0) zu.push(x + dx * (-a1) / (a2 - a1)); if (a1 > 0 && a2 <= 0) zd.push(x + dx * a1 / (a1 - a2)); }
  var pair = crs.length >= 2 ? crs : (trs.length >= 2 ? trs : (zu.length >= 2 ? zu : (zd.length >= 2 ? zd : null)));
  if (pair) {
    var p0 = pair[0], p1 = pair[1], low = pair === trs, yy = low ? g.Y(-A) + 14 : g.Y(A) - 14;
    if (g.X(p1) <= g.R.x1 + 1) dimH(ctx, g.X(p0), g.X(p1), yy, col, name, { y2: low ? g.Y(-A) + 4 : (pair === crs ? g.Y(A) - 4 : g.Y(0)) });
  }
  if (crs.length) { var c = crs[0]; if (g.X(c) >= g.R.x0 && g.X(c) <= g.R.x1) dimV(ctx, g.X(c), g.Y(0), g.Y(f(c)), '#1c8f4a', 'A', -1); }
}
function starShape(ctx, x, y, r, col) {
  ctx.save(); ctx.beginPath();
  for (var i = 0; i < 10; i++) { var a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? r * 0.45 : r; ctx.lineTo(x + rr * Math.cos(a), y + rr * Math.sin(a)); }
  ctx.closePath(); ctx.fillStyle = col; ctx.fill(); ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.4; ctx.stroke(); ctx.restore();
}
/* t = 0 での波形の小さな図 */
function m1s2DrawW0(s) {
  var c = s.w0cv; if (!c) return;
  var W = 84, H = 36, ctx = prep(c, W, H), q = m1s2Q(s);
  c.style.width = W + 'px';
  ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H);
  ctx.strokeStyle = '#9aa1ab'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(4, H / 2); ctx.lineTo(W - 3, H / 2); ctx.moveTo(10, 3); ctx.lineTo(10, H - 3); ctx.stroke();
  ctx.strokeStyle = '#e07b18'; ctx.lineWidth = 2; ctx.beginPath();
  for (var i = 0; i <= 60; i++) { var x = 1.32 * q.lam * i / 60, px = 10 + (W - 14) * i / 60, py = H / 2 - Math.sin(TAU * (x - q.x0) / q.lam) * (H / 2 - 5); if (i) ctx.lineTo(px, py); else ctx.moveTo(px, py); }
  ctx.stroke();
}
function rightM1S2(s, R) {
  var q = m1s2Q(s), nm = m1s2PtName(s);
  var h = '<div class="qcard"><p class="qt">2 つのグラフの読み分け</p>' +
    '<table class="reltab grid1"><thead><tr><th></th><th>$y$-$x$ グラフ</th><th>$y$-$t$ グラフ</th></tr></thead><tbody>' +
    '<tr><th>表すもの</th><td>ある時刻の波形<br>（写真）</td><td>ある点の振動<br>（記録）</td></tr>' +
    '<tr><th>横軸</th><td>位置 $x$〔m〕</td><td>時刻 $t$〔s〕</td></tr>' +
    '<tr><th>山から山まで</th><td>波長 $\\lambda$</td><td>周期 $T$</td></tr></tbody></table>' +
    '<p>$y$-$t$ グラフの形は、波の進む向きと点の位置で変わる。★ の点より<b>波が来る側</b>（波の進む向きと反対側）にある点の変位が、少しあとに ★ の点の変位になる。</p>' +
    '<div class="qeq">$$v = f\\lambda,\\qquad f = \\frac{1}{T}$$</div></div>';
  R.innerHTML = mathify(h);
}
