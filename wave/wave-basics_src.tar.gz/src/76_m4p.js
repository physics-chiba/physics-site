/* ===== 76_m4p.js ===== */
/* =====================================================================
   ④-2 波長（長さ）の違いが最初からある楽器（2026-11-07 千葉さん 15 回目に新しく作った。id は m4p）
   ・試験管の笛・ピアノ・鉄琴。どれも、音ごとに長さの違う管・弦・板が並んでいる（④-1 は 1 つの管・弦の長さを手で変える）
   ・伝えたいこと：短いと波長が短く、振動数が大きい（高い音）
   ・試験管の笛：閉管。水面が節、管口が腹。f = v / {4(L + Δx)}（v = 340 m/s、Δx = 0.6r = 0.45 cm、試験管 16 cm）
     → 空気の柱の長さ L = v/(4f) − Δx、水の高さ = 16 cm − L（添付の写真のとおり、低いドは空、高いドは水が多い）
   ・ピアノ：弦（両はしが節）f = v/(2l)。張力・太さが同じとして l ∝ 1/f（ド C4 = 65 cm）。本物は低い音ほど太い弦も使う
   ・鉄琴：板の曲げ振動（両はしが自由）。基本振動の波長 λ ≒ 1.33L。曲げの波は振動数が大きいほど速いので、f ∝ 1/L²（ド C5 = 12 cm）
     板を支える所は、振動の節（両はしから 0.224L）
   ===================================================================== */
'use strict';
var M4P_INS = [['tube', '試験管の笛'], ['piano', 'ピアノ'], ['glock', '鉄琴']];
var M4P_NOTES = { tube: [72, 74, 76, 77, 79, 81, 83, 84], piano: [60, 62, 64, 65, 67, 69, 71, 72], glock: [72, 74, 76, 77, 79, 81, 83, 84] };
var M4P = { v: 340, tubeL: 0.16, dx: 0.0045, pianoC4: 0.65, glockC5: 0.12 };
/* 長さ〔m〕：試験管は空気の柱、ピアノは弦、鉄琴は板 */
function m4pLen(ins, f) {
  if (ins === 'tube') return M4P.v / (4 * f) - M4P.dx;
  if (ins === 'piano') return M4P.pianoC4 * MUS.fET(60) / f;
  return M4P.glockC5 * Math.sqrt(MUS.fET(72) / f);
}
function m4pLam(ins, f) { var L = m4pLen(ins, f); return ins === 'tube' ? 4 * (L + M4P.dx) : (ins === 'piano' ? 2 * L : 2 * Math.PI * L / 4.730); }
DEFS.m4p = {
  id: 'm4p', mode: 'mode4', num: 4,
  title: '波長（長さ）の違いが最初からある楽器', short: '長さが最初から違う楽器',
  desc: '試験管の笛・ピアノ・鉄琴は、音ごとに長さの違う管・弦・板が並んでいる。<span class="todo">楽器を選び、管・弦・板か五線譜の音符をクリックしよう。短いほど波長が短く、振動数が大きい（高い音）。</span>',
  strobe: false, stepDiv: 16,
  vars: [],
  init: function (s) { s.ins = 'tube'; s.nm = null; s.tN = 0; },
  onDefaults: function (s) { s.ins = 'tube'; s.nm = null; m4pSync(s); },
  buttons: M4P_INS.map(function (p) { return { k: 'i_' + p[0], label: p[1], seg: 'ins', segLabel: '楽器', onClick: function (s) { s.ins = p[0]; s.nm = null; m4pSync(s); s.draw(); } }; }),
  tEnd: function () { return M4_TEND; },
  tInfo: function () { return ''; },
  gT: function () { return 1; },
  height: function (s, w) { return w < 620 ? 420 : Math.round(clamp(w * 0.64, 400, 450)); },
  afterBuild: function (s) {
    m4Right(s, 'オシロスコープ（楽器の音）');
    m4SndToggle(s, function () { if (s.nm === null) s.nm = M4P_NOTES[s.ins][0]; m4pPlay(s); });
    var segs = s.row1b.querySelectorAll('.seg'); if (segs[0]) { var lb = el('span', 'seglbl', '楽器'); segs[0].insertAdjacentElement('beforebegin', lb); lblSeg(lb, segs[0]); }
    m3TimeBar(s, false); m4NoPlay(s); m4Hits(s); m4pSync(s);
  },
  draw: function (s, ctx, W, H) {
    drawM4P(s, ctx, W, H);
    var f = s.nm === null ? 0 : MUS.fET(s.nm);
    m4Scope(s, f, M4_TIM[s.ins], f ? MUS.jp(s.nm) + '（' + MUS.en(s.nm) + '）$f = ' + sig(f, 4) + '$ Hz' : '管・弦・板か、音符をクリック', 5000);
  },
  right: function (s, R) { rightM4P(s, R); }
};
function m4pSync(s) { m2Sync(s, M4P_INS.map(function (p) { return ['i_' + p[0], s.ins === p[0]]; })); if (s.Rdyn) s.renderRight(); }
function m4pPlay(s) { s.tN = s.t; m4Note('m4p', MUS.fET(s.nm), s.ins); m4Go(s); m4pSync(s); }
function drawM4P(s, ctx, W, H) {
  s._h4 = [];
  var nar = W < 620, Hi = Math.round(H * 0.54), notes = M4P_NOTES[s.ins], n = notes.length, x0 = 14, dx = (W - 2 * x0) / n;
  var tp = s.t - (s.tN || 0), A = s.nm === null ? 0 : Math.cos(TAU * 0.8 * tp) * Math.exp(-tp / (s.ins === 'tube' ? 1e9 : 1.2)) * (s.ins === 'tube' && tp > 1.3 ? 0 : 1);
  var cx = function (i) { return x0 + dx * (i + 0.5); }, play = function (m) { return function () { s.nm = m; m4pPlay(s); }; };
  label(ctx, s.ins === 'tube' ? '試験管の笛：水の量で空気の柱の長さを変えてある' + (nar ? '' : '。試験管をクリックで吹く') : (s.ins === 'piano' ? 'ピアノ：音ごとに長さの違う弦' + (nar ? '' : '。鍵盤・弦をクリック') : '鉄琴：音ごとに長さの違う金属の板' + (nar ? '' : '。板をクリックでたたく')), 8, 12, { size: nar ? 10 : 11.5, bold: true, color: COL.ink2, align: 'left' });
  if (s.ins === 'tube') {
    var yT = 80, TL = Hi - 120, S = TL / M4P.tubeL, tw = Math.min(26, dx * 0.55);   /* 上に顔の場所をあける（16 回目） */
    ctx.save(); ctx.strokeStyle = '#9aa1ab'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(x0, yT + TL * 0.32); ctx.lineTo(W - x0, yT + TL * 0.32); ctx.moveTo(x0, yT + TL * 0.94); ctx.lineTo(W - x0, yT + TL * 0.94); ctx.stroke(); ctx.restore();   /* 試験管立て */
    notes.forEach(function (m, i) {
      var f = MUS.fET(m), L = m4pLen('tube', f), wat = M4P.tubeL - L, x = cx(i), yB = yT + TL, yW = yB - wat * S, sel = s.nm === m;
      ctx.save(); ctx.fillStyle = '#cfe6f7'; ctx.beginPath(); ctx.moveTo(x - tw / 2, yW); ctx.lineTo(x - tw / 2, yB - tw / 2); ctx.arc(x, yB - tw / 2, tw / 2, Math.PI, 0, true); ctx.lineTo(x + tw / 2, yW); ctx.closePath(); ctx.fill(); ctx.restore();   /* 水 */
      ctx.save(); ctx.strokeStyle = sel ? '#e07b18' : '#6b7480'; ctx.lineWidth = sel ? 2.4 : 1.4; ctx.beginPath(); ctx.moveTo(x - tw / 2, yT); ctx.lineTo(x - tw / 2, yB - tw / 2); ctx.arc(x, yB - tw / 2, tw / 2, Math.PI, 0, true); ctx.lineTo(x + tw / 2, yT); ctx.stroke(); ctx.restore();
      if (sel) {                                                   /* 空気の柱の定在波（管口が腹、水面が節） */
        var Lp = (L + M4P.dx) * S, amp = tw / 2 - 3;
        [1, -1].forEach(function (sg) { ctx.save(); ctx.strokeStyle = 'rgba(22,99,181,.45)'; ctx.setLineDash([3, 3]); ctx.lineWidth = 1; ctx.beginPath(); for (var k = 0; k <= 40; k++) { var y = yT + (yW - yT) * k / 40, a = Math.sin(Math.PI / 2 * (yW - y) / Lp); if (k) ctx.lineTo(x + sg * amp * a, y); else ctx.moveTo(x + sg * amp * a, y); } ctx.stroke(); ctx.restore(); });
        ctx.save(); ctx.strokeStyle = '#1663b5'; ctx.lineWidth = 2; ctx.beginPath(); for (var k2 = 0; k2 <= 40; k2++) { var y2 = yT + (yW - yT) * k2 / 40, a2 = Math.sin(Math.PI / 2 * (yW - y2) / Lp) * A; if (k2) ctx.lineTo(x + amp * a2, y2); else ctx.moveTo(x + amp * a2, y2); } ctx.stroke(); ctx.restore();
      }
      label(ctx, MUS.jp(m), x, yB + 13, { size: nar ? 13 : 15, bold: true, color: sel ? '#c9670c' : COL.ink });   /* 音名は下に（上は顔が通るので） */
      m4Hit(s, x - dx / 2, yT - 6, dx, TL + 26, play(m));
    });
    /* 吹く人の横顔：クリックした試験管の管口の右上へ動き、口を管口に近づけて吹く（2026-11-08 千葉さん 16 回目） */
    var iS = s.nm === null ? 0 : Math.max(0, notes.indexOf(s.nm)), blow = s.nm !== null && tp < 1.3, k = nar ? 0.8 : 1;
    var tx = cx(iS) + tw / 2 + 3 + (blow ? 0 : 10), ty = yT - 3 - (blow ? 0 : 12);
    if (s.fx === undefined || s._fIns !== s.ins) { s.fx = tx; s.fy = ty; s._fIns = s.ins; }
    s.fx += (tx - s.fx) * 0.3; s.fy += (ty - s.fy) * 0.3; if (Math.abs(tx - s.fx) < 0.5) s.fx = tx; if (Math.abs(ty - s.fy) < 0.5) s.fy = ty;
    m4pFace(ctx, s.fx, s.fy, k, blow && Math.abs(tx - s.fx) < 2 ? s.t : null);
    if (s.nm === null) label(ctx, '← 試験管をクリックすると吹く', s.fx + 46 * k, s.fy - 14 * k, { size: 11, bold: true, color: '#c9670c', align: 'left' });
  } else if (s.ins === 'piano') {
    var kh = 50, ky = Hi - kh - 26, yb = ky - 8, SL = (yb - 40) / M4P.pianoC4, kw = dx - 4;
    m4pPianoCase(ctx, x0, W - x0, yb - M4P.pianoC4 * SL - 16, yb - m4pLen('piano', MUS.fET(notes[n - 1])) * SL - 22, ky + kh + 6, ky);   /* 真上から見たグランドピアノの形（16 回目） */
    ctx.save(); ctx.fillStyle = '#7a5a3a'; ctx.fillRect(x0, yb - 3, W - 2 * x0, 6); ctx.restore();   /* 弦を支える駒 */
    notes.forEach(function (m, i) {
      var f = MUS.fET(m), l = m4pLen('piano', f), x = cx(i), yt = yb - l * SL, sel = s.nm === m;
      ctx.save(); ctx.strokeStyle = sel ? '#e07b18' : '#7a6a58'; ctx.lineWidth = sel ? 2.2 : 1.6; ctx.beginPath();
      for (var k = 0; k <= 40; k++) { var y = yt + (yb - yt) * k / 40, d = sel ? 7 * A * Math.sin(Math.PI * k / 40) : 0; if (k) ctx.lineTo(x + d, y); else ctx.moveTo(x + d, y); }
      ctx.stroke(); ctx.restore();
      ctx.save(); ctx.fillStyle = '#5b6470'; ctx.beginPath(); ctx.arc(x, yt - 3, 3.4, 0, TAU); ctx.fill(); ctx.restore();   /* 弦の上のはし（ピン） */
      ctx.save(); ctx.fillStyle = sel ? '#fde3c4' : '#fff'; ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.2; rrect(ctx, x - kw / 2, ky, kw, kh, 4); ctx.fill(); ctx.stroke(); ctx.restore();
      label(ctx, MUS.jp(m), x, ky + kh - 14, { size: 11, bold: sel, color: sel ? '#c9670c' : COL.ink });
      m4Hit(s, x - dx / 2, yt - 10, dx, ky + kh - yt + 10, play(m));
    });
    [0, 1, 3, 4, 5].forEach(function (i) { var xb = x0 + dx * (i + 1); ctx.save(); ctx.fillStyle = '#20242b'; rrect(ctx, xb - dx * 0.17, ky, dx * 0.34, kh * 0.55, 2); ctx.fill(); ctx.restore(); });   /* 黒鍵（飾り） */
  } else {
    var SB = (Hi - 136) / M4P.glockC5, yc = Math.round(64 + (Hi - 136) / 2), bw = Math.min(34, dx * 0.62);
    notes.forEach(function (m, i) {
      var f = MUS.fET(m), L = m4pLen('glock', f), x = cx(i), h = L * SB, sel = s.nm === m, y0 = yc - h / 2;
      if (sel && Math.abs(A) > 0.02) { ctx.save(); ctx.shadowColor = 'rgba(224,123,24,.8)'; ctx.shadowBlur = 16 * Math.abs(A); ctx.fillStyle = 'rgba(224,123,24,.25)'; rrect(ctx, x - bw / 2 - 2, y0 - 2, bw + 4, h + 4, 5); ctx.fill(); ctx.restore(); }
      ctx.save(); var gr = ctx.createLinearGradient(x - bw / 2, 0, x + bw / 2, 0); gr.addColorStop(0, '#aab3bd'); gr.addColorStop(0.45, '#eef1f4'); gr.addColorStop(1, '#9aa3ad');
      ctx.fillStyle = gr; ctx.strokeStyle = sel ? '#e07b18' : '#6b7480'; ctx.lineWidth = sel ? 2.4 : 1.2; rrect(ctx, x - bw / 2, y0, bw, h, 4); ctx.fill(); ctx.stroke(); ctx.restore();
      [0.224, 0.776].forEach(function (u) { ctx.save(); ctx.fillStyle = '#3a414c'; ctx.beginPath(); ctx.arc(x, y0 + u * h, 2.6, 0, TAU); ctx.fill(); ctx.restore(); });   /* 支える所＝節 */
      label(ctx, MUS.jp(m), x, y0 - 14, { size: nar ? 13 : 16, bold: true, color: sel ? '#c9670c' : COL.ink });
      m4Hit(s, x - dx / 2, y0 - 26, dx, h + 30, play(m));
    });
    label(ctx, '●：板を支える所（振動の節）', W - 10, Hi - 16, { size: 10, color: COL.sub, align: 'right' });
    /* つち（槌）：クリックした板の上へ動き、たたいてはね上がる（2026-11-08 千葉さん 18 回目） */
    var iG = s.nm === null ? 0 : Math.max(0, notes.indexOf(s.nm)), up = s.nm === null ? 1 : (tp < 0.1 ? 0 : Math.min(1, (tp - 0.1) / 0.25));
    var gx = cx(iG), gy = yc;
    if (s.mx === undefined || s._mIns !== s.ins) { s.mx = gx; s._mIns = s.ins; }
    s.mx += (gx - s.mx) * 0.45; if (Math.abs(gx - s.mx) < 0.5) s.mx = gx;
    m4pMallet(ctx, s.mx + up * 10, gy - up * 26, nar ? 0.85 : 1, up < 0.05);
    if (s.nm === null) label(ctx, '板をクリックすると、つちでたたく', 8, Hi - 34, { size: 11.5, bold: true, color: '#c9670c', align: 'left' });
  }
  /* 選んだ音の長さ・波長・振動数 */
  if (s.nm !== null) {
    var f2 = MUS.fET(s.nm), L2 = m4pLen(s.ins, f2), lam = m4pLam(s.ins, f2), nm = MUS.jp(s.nm) + '（' + MUS.en(s.nm) + '）' + sig(f2, 4) + ' Hz';
    var tx2 = s.ins === 'tube' ? '空気の柱 ' + sig(L2 * 100, 3) + ' cm → 波長 λ = 4(L + Δx) = ' + sig(lam * 100, 3) + ' cm' : (s.ins === 'piano' ? '弦の長さ ' + sig(L2 * 100, 3) + ' cm → 波長 λ = 2l = ' + sig(lam * 100, 3) + ' cm' : '板の長さ ' + sig(L2 * 100, 3) + ' cm → 波長 λ ≒ 1.33L = ' + sig(lam * 100, 3) + ' cm');
    label(ctx, tx2 + '　' + nm, 8, Hi - (s.ins === 'glock' ? 34 : 10), { size: nar ? 10 : 11.5, bold: true, color: '#c9670c', align: 'left' });
  }
  /* 下：五線譜。音符をクリックでその音 */
  ctx.save(); ctx.strokeStyle = '#e3e6ea'; ctx.beginPath(); ctx.moveTo(8, Hi + 4); ctx.lineTo(W - 8, Hi + 4); ctx.stroke(); ctx.restore();
  label(ctx, '五線譜（音符をクリック）', 8, Hi + 18, { size: 11.5, bold: true, color: COL.ink2, align: 'left' });
  var sp = nar ? 10 : 12, yTop = Hi + 30 + 3 * sp, Y = staff(ctx, 8, W - 8, yTop, sp), nx0 = 8 + sp * 4, ddx = (W - 8 - nx0 - 6) / n;
  notes.forEach(function (m, i) {
    var x = nx0 + ddx * (i + 0.5), sel = s.nm === m;
    noteHead(ctx, x, MUS.step(m), Y, sp, sel ? '#e07b18' : '#14171c', false, !sel);
    label(ctx, MUS.jp(m), x, Math.max(Y(0), Y(MUS.step(notes[0]) - 3)) + 8, { size: nar ? 9.5 : 11, bold: sel, color: sel ? '#c9670c' : COL.ink2 });
    m4Hit(s, x - ddx / 2, yTop - 4 * sp, ddx, 9 * sp, play(m));
  });
}
function rightM4P(s, R) {
  var h = '<div class="qcard"><p class="qt">短いほど高い音</p>' +
    '<p>音ごとに長さの違う管・弦・板を並べてある。短いほど<b>波長が短く</b>、<b>振動数が大きい</b>（高い音）。</p>' +
    '<table class="reltab grid1"><tbody>' +
    '<tr><th>試験管の笛</th><td class="l">空気の柱が振動する（閉管）。水面が節、管口が腹。水が多いほど空気の柱が短く、高い音。$f = \\dfrac{v}{4(L + \\Delta x)}$</td></tr>' +
    '<tr><th>ピアノ</th><td class="l">両端を固定した弦が振動する。短い弦ほど高い音。$f = \\dfrac{v}{2l}$</td></tr>' +
    '<tr><th>鉄琴</th><td class="l">金属の板が曲がるように振動する（両端が自由）。短い板ほど高い音</td></tr></tbody></table>';
  if (s.nm !== null) { var f = MUS.fET(s.nm); h += '<p class="qnow"><span class="qtag now">いま</span>' + MUS.jp(s.nm) + '（' + MUS.en(s.nm) + '）$f = ' + sig(f, 4) + '$ Hz、波長 $\\lambda = ' + sig(m4pLam(s.ins, f) * 100, 3) + '$ cm</p>'; }
  h += '<p class="qnote">' + (s.ins === 'tube' ? '試験管は長さ 16 cm、開口端補正 $\\Delta x = 0.45$ cm、音速 340 m/s とした。' : s.ins === 'piano' ? '図は、弦の張力・太さが同じとしたときの長さ（本物のピアノは、低い音ほど太い弦も使う）。' : '鉄琴の板を伝わる曲げの波は、振動数が大きいほど速く伝わる。そのため振動数は長さの 2 乗に反比例する（長さを半分にすると 4 倍）。') + '</p></div>';
  R.innerHTML = mathify(h);
}
/* 吹く人の横顔（左向き）。(mx, my)＝口。k：大きさ。tb：吹いているときの時刻（息の線を動かす）、null なら吹いていない */
function m4pFace(ctx, mx, my, k, tb) {
  var P = function (x, y) { return [mx + x * k, my + y * k]; };
  ctx.save(); ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  /* 首 */
  ctx.fillStyle = '#f2cfae'; ctx.beginPath(); var a = P(14, 8), b = P(30, 6); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); var c = P(34, 30), d = P(16, 30); ctx.lineTo(c[0], c[1]); ctx.lineTo(d[0], d[1]); ctx.closePath(); ctx.fill();
  /* 顔と頭 */
  ctx.fillStyle = '#f6d9bb'; ctx.strokeStyle = '#8a5a3a'; ctx.lineWidth = 1.4;
  ctx.beginPath();
  var p = [P(10, -40), P(4, -26), P(-4, -15), P(3, -10), P(-1, -5), P(-3, -1), P(-1, 3), P(3, 5), P(4, 12), P(16, 15), P(30, 8), P(40, -10), P(36, -38), P(22, -46)];
  ctx.moveTo(p[0][0], p[0][1]);
  ctx.quadraticCurveTo(p[1][0], p[1][1] - 4 * k, p[1][0], p[1][1]);   /* ひたい */
  ctx.lineTo(p[2][0], p[2][1]);                                     /* 鼻すじ → 鼻の先 */
  ctx.quadraticCurveTo(p[2][0] + 1 * k, p[3][1], p[3][0], p[3][1]);   /* 鼻の下 */
  ctx.lineTo(p[4][0], p[4][1]); ctx.quadraticCurveTo(p[5][0] - 2 * k, p[5][1] - 2 * k, p[5][0], p[5][1]);   /* 上くちびる（すぼめる） */
  ctx.quadraticCurveTo(p[6][0] - 2 * k, p[6][1] + 1 * k, p[7][0], p[7][1]);   /* 下くちびる */
  ctx.quadraticCurveTo(p[8][0] - 3 * k, p[8][1], p[8][0], p[8][1]);   /* あご */
  ctx.quadraticCurveTo(p[9][0], p[9][1] + 2 * k, p[10][0], p[10][1]);
  ctx.quadraticCurveTo(p[11][0] + 4 * k, p[11][1] + 6 * k, p[11][0], p[11][1]);
  ctx.quadraticCurveTo(p[12][0] + 6 * k, p[12][1] - 8 * k, p[13][0], p[13][1]);
  ctx.quadraticCurveTo(p[0][0] + 2 * k, p[13][1], p[0][0], p[0][1]);
  ctx.closePath(); ctx.fill(); ctx.stroke();
  /* かみの毛（高校生：前髪のある短めの髪。頭の上から後ろまでおおう） */
  ctx.fillStyle = '#2b1e17'; ctx.beginPath();
  var H = [P(3, -27), P(2, -44), P(22, -54), P(42, -46), P(48, -24), P(42, -2), P(34, -4), P(31, -14), P(30, -26), P(20, -32), P(12, -31)];
  ctx.moveTo(H[0][0], H[0][1]);
  ctx.quadraticCurveTo(H[1][0], H[1][1], H[2][0], H[2][1]);      /* 前髪 → 頭のてっぺん */
  ctx.quadraticCurveTo(H[3][0] + 4 * k, H[3][1], H[4][0], H[4][1]);   /* 後ろ頭 */
  ctx.quadraticCurveTo(H[4][0] + 1 * k, H[5][1] - 8 * k, H[5][0], H[5][1]);   /* えりあし */
  ctx.lineTo(H[6][0], H[6][1]);
  ctx.quadraticCurveTo(H[7][0] + 2 * k, H[7][1], H[8][0], H[8][1]);   /* 耳の後ろ */
  ctx.quadraticCurveTo(H[9][0] + 2 * k, H[9][1] - 4 * k, H[9][0], H[9][1]);   /* もみあげの上 → 生えぎわ */
  ctx.quadraticCurveTo(H[10][0], H[10][1] - 2 * k, H[10][0] - 3 * k, H[10][1] + 1 * k);
  ctx.quadraticCurveTo(H[0][0] + 4 * k, H[0][1] - 1 * k, H[0][0], H[0][1]);   /* 前髪の先 */
  ctx.closePath(); ctx.fill();
  /* 制服のえり（白いシャツと紺のブレザー） */
  var c1 = P(10, 26), c2 = P(42, 24), c3 = P(48, 40), c4 = P(4, 40);
  ctx.fillStyle = '#1f2f4a'; ctx.beginPath(); ctx.moveTo(c1[0], c1[1]); ctx.lineTo(c2[0], c2[1]); ctx.lineTo(c3[0], c3[1]); ctx.lineTo(c4[0], c4[1]); ctx.closePath(); ctx.fill();
  var w1 = P(14, 24), w2 = P(22, 34), w3 = P(30, 22); ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.moveTo(w1[0], w1[1]); ctx.lineTo(w2[0], w2[1]); ctx.lineTo(w3[0], w3[1]); ctx.closePath(); ctx.fill();
  /* 耳・目・まゆ */
  var e = P(27, -16); ctx.fillStyle = '#efc49f'; ctx.strokeStyle = '#8a5a3a'; ctx.lineWidth = 1.1; ctx.beginPath(); ctx.ellipse(e[0], e[1], 3.4 * k, 5 * k, 0, 0, TAU); ctx.fill(); ctx.stroke();
  var ey = P(8, -23); ctx.fillStyle = '#20242b'; ctx.beginPath(); ctx.ellipse(ey[0], ey[1], 1.6 * k, 2 * k, 0, 0, TAU); ctx.fill();
  var br = P(4, -28), br2 = P(12, -29); ctx.strokeStyle = '#3b2a20'; ctx.lineWidth = 1.6 * k; ctx.beginPath(); ctx.moveTo(br[0], br[1]); ctx.lineTo(br2[0], br2[1]); ctx.stroke();
  /* ふくらんだほお（吹いているとき） */
  if (tb !== null) { var ch = P(10, -6); ctx.fillStyle = 'rgba(232,140,120,.35)'; ctx.beginPath(); ctx.arc(ch[0], ch[1], 4.5 * k, 0, TAU); ctx.fill(); }
  ctx.restore();
  /* 息：口から管口へ（左下へ流れる短い線） */
  if (tb !== null) {
    ctx.save(); ctx.strokeStyle = 'rgba(22,99,181,.7)'; ctx.lineWidth = 1.4; ctx.lineCap = 'round';
    for (var i = 0; i < 3; i++) { var u = ((tb * 2.2) + i / 3) % 1, sx = mx - 4 * k - u * 10 * k, sy = my + u * 6 * k + (i - 1) * 2.5 * k; ctx.globalAlpha = 1 - u; ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(sx - 4 * k, sy + 2.4 * k); ctx.stroke(); }
    ctx.restore();
  }
}
/* 真上から見たグランドピアノのふち（低い音の側が長い）。xL〜xR、yTL：左上（低い音側）、yTR：右上、yBot：下（鍵盤の下）、yK：鍵盤の上 */
function m4pPianoCase(ctx, xL, xR, yTL, yTR, yBot, yK) {
  var L = xL - 8, R = xR + 8, w = R - L;
  ctx.save();
  ctx.beginPath(); ctx.moveTo(L, yBot); ctx.lineTo(L, yTL + 14); ctx.quadraticCurveTo(L, yTL, L + 14, yTL);
  ctx.lineTo(L + w * 0.18, yTL); ctx.bezierCurveTo(L + w * 0.55, yTL, L + w * 0.62, yTR, R - 14, yTR); ctx.quadraticCurveTo(R, yTR, R, yTR + 14); ctx.lineTo(R, yBot); ctx.closePath();
  ctx.fillStyle = '#f7efdf'; ctx.fill(); ctx.strokeStyle = '#8a6a40'; ctx.lineWidth = 3; ctx.stroke();
  /* 鉄のフレーム（金色）：まわりと、ななめの支え */
  ctx.clip();
  /* ななめの支え（3 本の線）は 18 回目になくした */
  ctx.fillStyle = 'rgba(160,180,200,.35)';
  [[0.82, 0.55], [0.9, 0.7]].forEach(function (q) { var cx = L + w * q[0], cy = yTR + (yK - yTR) * q[1] * 0.5; ctx.beginPath(); ctx.arc(cx, cy, 7, 0, TAU); ctx.fill(); });
  ctx.restore();
  /* 鍵盤の帯 */
  ctx.save(); ctx.fillStyle = '#2a2420'; ctx.fillRect(L, yK - 6, w, 6); ctx.restore();
}
/* つち（槌）：(hx, hy)＝頭（ゴムの玉）の中心。柄は右下へ。hit：板に当たっている（当たった所に小さな線） */
function m4pMallet(ctx, hx, hy, k, hit) {
  ctx.save(); ctx.lineCap = 'round';
  ctx.strokeStyle = '#8a5a2b'; ctx.lineWidth = 4.2 * k; ctx.beginPath(); ctx.moveTo(hx + 4 * k, hy + 4 * k); ctx.lineTo(hx + 46 * k, hy + 44 * k); ctx.stroke();   /* 柄 */
  ctx.strokeStyle = '#c99a62'; ctx.lineWidth = 1.4 * k; ctx.beginPath(); ctx.moveTo(hx + 5 * k, hy + 3 * k); ctx.lineTo(hx + 46 * k, hy + 42 * k); ctx.stroke();
  var g = ctx.createRadialGradient(hx - 2 * k, hy - 2 * k, 1, hx, hy, 8 * k); g.addColorStop(0, '#e86a5a'); g.addColorStop(1, '#9b2418');
  ctx.fillStyle = g; ctx.strokeStyle = '#6e1a12'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(hx, hy, 7.5 * k, 0, TAU); ctx.fill(); ctx.stroke();   /* 頭 */
  if (hit) { ctx.strokeStyle = '#e07b18'; ctx.lineWidth = 1.6; [-1, 1].forEach(function (d) { ctx.beginPath(); ctx.moveTo(hx + d * 11 * k, hy - 6 * k); ctx.lineTo(hx + d * 16 * k, hy - 11 * k); ctx.stroke(); }); }
  ctx.restore();
}
