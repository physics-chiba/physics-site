/* ===== 85_design.js ===== */
/* =========================================================================
   デザイン試作の動き（2026-10）
   ・ヒーローのステージ：等速円運動・鉛直ばね振り子・右へ流れるストロボを並べて、単振動は等速円運動の影であることを見せる。
   ・スライドバーの塗り（--p）、タブ列の下の進み具合（--prog）。
   ・画面に見えていないとき・動きを減らす設定のときは動かさない（重くしない：第 21 回の教訓）。
   ========================================================================= */
(function(){
  "use strict";
  const RM = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const MATH = '"KaTeX_Math","KaTeX_Main",serif',
        JP = '"Hiragino Sans","Hiragino Kaku Gothic ProN","Yu Gothic",YuGothic,"Noto Sans JP",Meiryo,sans-serif';

  /* ===== ヒーローのステージ：等速円運動（左）→ 波源（ウェーブマシンの左端）→ となりの点が少しずつ遅れて同じ単振動（右） =====
     単振動ページのヒーロー（等速円運動の影＝ばねのおもり）を受けて、波源の単振動が右へ伝わり、正弦波の形が進むようすを見せる。
     媒質の点の変位は y(x, t) = y₀(t − x/v)（30_physics.js と同じ考え方。右端では反射しない） */
  function initStage(){
    const cv = document.getElementById("heroCv"); if(!cv) return;
    const ctx = cv.getContext("2d");
    const C = { ink:"#f3f6fa", dim:"rgba(243,246,250,.69)", faint:"rgba(243,246,250,.2)", ball:"#9fd0ff", rim:"#2f7fd6", brand:"#2f7fd6", link:"rgba(79,168,255,1)", ray:"rgba(79,168,255,.144)" };   /* 黒の地 × 澄んだ青（案 A・2026-10-27 千葉さん） */
    let W=0, H=0, dpr=1, run=false, raf=0, last=0, t=0, paused=false, rate=1;
    const OM = 2.2, PER = 2*Math.PI/OM;
    let g = null;
    /* ヒーロー：③-5 気柱の共鳴（水柱の実験）。2026-11-06 千葉さん 12 回目
       水面を管口から 2 cm → 60 cm までゆっくり下げ（10 秒）、2 秒止めて、くり返す。
       右のグラフに、水面の低さ L と音の大きさ（m3s5Amp：開口端補正を入れた本当の式）を描いていく。L₁・L₂ で共鳴 */
    const CYC = 12, LT = 10;
    function setup(){
      const r = cv.getBoundingClientRect(); dpr = Math.min(2, window.devicePixelRatio||1);
      W = Math.max(280, r.width); H = Math.max(170, r.height);
      cv.width = Math.round(W*dpr); cv.height = Math.round(H*dpr); ctx.setTransform(dpr,0,0,dpr,0,0);
      const top = 50, bot = H - 14, SY = (bot - top) / 0.62, tx = Math.max(64, W*0.13), tw = Math.min(22, W*0.035);
      const gx0 = tx + tw + Math.max(90, W*0.16), gx1 = W - 18, gy0 = 26, gy1 = H - 34;
      g = { top, bot, SY, tx, tw, gx0, gx1, gy0, gy1 };
    }
    function text(s,x,y,col,size,al,bold){ ctx.save(); ctx.fillStyle=col; ctx.font=(bold?"700 ":"600 ")+size+"px "+JP; ctx.textAlign=al||"center"; ctx.textBaseline="middle"; ctx.fillText(s,x,y); ctx.restore(); }
    function Lof(tt){ const u = ((tt % CYC) + CYC) % CYC; return 0.02 + 0.58*Math.min(1, u/LT); }
    function draw(tt){
      if(!g) return;
      const { top, bot, SY, tx, tw, gx0, gx1, gy0, gy1 } = g;
      ctx.clearRect(0,0,W,H);
      const q = m3s5Q({ v:{ tc:15, Lw:0.3 } }), L = Lof(tt), a = m3s5Amp(q, L), k = 2*Math.PI/q.lam, dx = M3S5.dx, ws = top + L*SY;
      /* おんさ（横に倒して、枝を管口の上に） */
      ctx.save(); ctx.strokeStyle="rgba(243,246,250,.75)"; ctx.lineCap="round"; ctx.lineWidth=4.5;
      const fy = top - 20, xb = tx - 34;
      ctx.beginPath(); ctx.moveTo(tx+18, fy-6); ctx.lineTo(xb, fy-6); ctx.quadraticCurveTo(xb-10, fy-6, xb-10, fy); ctx.quadraticCurveTo(xb-10, fy+6, xb, fy+6); ctx.lineTo(tx+18, fy+6); ctx.stroke();
      ctx.lineWidth=4; ctx.beginPath(); ctx.moveTo(xb-10, fy); ctx.lineTo(xb-40, fy); ctx.stroke(); ctx.restore();
      text("おんさ 800 Hz", Math.max(4, xb-60), fy-18, C.dim, 10.5, "left");
      /* 管・水 */
      ctx.save(); ctx.fillStyle="rgba(79,168,255,.35)"; ctx.fillRect(tx-tw, ws, 2*tw, bot-ws);
      ctx.strokeStyle=C.dim; ctx.lineWidth=2.4; ctx.beginPath(); ctx.moveTo(tx-tw, top); ctx.lineTo(tx-tw, bot); ctx.lineTo(tx+tw, bot); ctx.lineTo(tx+tw, top); ctx.stroke(); ctx.restore();
      text("管口", tx-tw-8, top, C.dim, 10.5, "right");
      /* 管の中の定在波（横波表示）。水面が節、腹は y = L − λ/4（共鳴のとき管口の少し上） */
      const th = 2*Math.PI*1.3*tt;
      [1,-1].forEach(sg=>{ ctx.save(); ctx.strokeStyle="rgba(159,208,255,.35)"; ctx.setLineDash([3,3]); ctx.beginPath();
        for(let i=0;i<=120;i++){ const y = -dx + (L+dx)*i/120, X = tx + sg*a*(tw-3)*Math.sin(k*(L-y)); i? ctx.lineTo(X, top+y*SY) : ctx.moveTo(X, top+y*SY); } ctx.stroke(); ctx.restore(); });
      ctx.save(); ctx.strokeStyle="#9fd0ff"; ctx.lineWidth=2; ctx.beginPath();
      for(let i=0;i<=120;i++){ const y = -dx + (L+dx)*i/120, X = tx + a*(tw-3)*Math.sin(k*(L-y))*Math.cos(th); i? ctx.lineTo(X, top+y*SY) : ctx.moveTo(X, top+y*SY); } ctx.stroke(); ctx.restore();
      /* L の寸法 */
      const lx = tx + tw + 12;
      ctx.save(); ctx.strokeStyle=C.dim; ctx.lineWidth=1; ctx.beginPath(); ctx.moveTo(lx, top); ctx.lineTo(lx, ws); ctx.moveTo(lx-3, top); ctx.lineTo(lx+3, top); ctx.moveTo(lx-3, ws); ctx.lineTo(lx+3, ws); ctx.stroke(); ctx.restore();
      text("L = " + (L*100).toFixed(1) + " cm", lx+6, (top+ws)/2, C.ink, 11, "left", true);
      if(a > 0.8) text("共鳴！", tx, top + Math.min(L*SY*0.5, 30) + 4, "#ffd678", 13, "center", true);
      /* 右：水面の低さと音の大きさ */
      ctx.save(); ctx.strokeStyle=C.faint; ctx.lineWidth=1; ctx.beginPath(); ctx.moveTo(gx0, gy0); ctx.lineTo(gx0, gy1); ctx.lineTo(gx1, gy1); ctx.stroke(); ctx.restore();
      const GX = (l)=> gx0 + l/0.6*(gx1-gx0), GY = (v)=> gy1 - v*(gy1-gy0)*0.92;
      for(let c=0;c<=6;c++) text(String(c*10), GX(c*0.1), gy1+10, C.faint.replace(".2", ".55"), 9.5);
      text("管口から水面までの長さ L〔cm〕", gx1, gy1+24, C.dim, 10, "right");
      text("音の大きさ", gx0+6, gy0-10, C.dim, 10, "left");
      ctx.save(); ctx.strokeStyle="#4fa8ff"; ctx.lineWidth=2; ctx.beginPath();
      for(let l=0.02, i=0; l<=L+1e-9; l+=0.002, i++){ const X = GX(l), Y = GY(m3s5Amp(q, l)); i? ctx.lineTo(X,Y) : ctx.moveTo(X,Y); } ctx.stroke(); ctx.restore();
      [[q.L1,"L₁"],[q.L2,"L₂"],[q.L3,"L₃"]].forEach(([Lr,nm])=>{ if(L < Lr || Lr > 0.6) return;
        ctx.save(); ctx.strokeStyle="rgba(255,214,120,.6)"; ctx.setLineDash([3,3]); ctx.beginPath(); ctx.moveTo(GX(Lr), gy0); ctx.lineTo(GX(Lr), gy1); ctx.stroke(); ctx.restore();
        text(nm + " = " + (Lr*100).toFixed(1), GX(Lr)+4, gy0+2, "#ffd678", 10.5, "left", true); });
      ctx.save(); ctx.fillStyle="#ffd678"; ctx.beginPath(); ctx.arc(GX(L), GY(a), 4, 0, 7); ctx.fill(); ctx.restore();
      if(W > 620 && L >= q.L2) text("L₂ − L₁ = λ/2", (GX(q.L1)+GX(q.L2))/2, gy1-12, "rgba(255,214,120,.85)", 11, "center", true);
    }
    function frame(ts){
      if(!run) return;
      const dtm = last? Math.min(0.05,(ts-last)/1000) : 0; last = ts;
      t += dtm*rate; draw(t);
      raf = requestAnimationFrame(frame);
    }
    function start(){ if(run || RM || paused) return; run = true; last = 0; raf = requestAnimationFrame(frame); }
    function stop(){ run = false; cancelAnimationFrame(raf); }
    setup(); t = 5.2; draw(t);
    window.__hero = { frame:(tt)=>{ stop(); t = tt; draw(tt); }, start, stop };
    let rz = 0; window.addEventListener("resize", ()=>{ clearTimeout(rz); rz = setTimeout(()=>{ setup(); draw(t); }, 120); });
    if("IntersectionObserver" in window){
      new IntersectionObserver((es)=>{ es.forEach(en=>{ (en.isIntersecting && !document.hidden)? start() : stop(); }); }, {threshold:0.05}).observe(cv);
    } else start();
    document.addEventListener("visibilitychange", ()=>{ if(document.hidden) stop(); else { const r=cv.getBoundingClientRect(); if(r.bottom>0 && r.top<innerHeight) start(); } });
    const ctl = document.querySelector("#hero .stagectl");
    if(ctl){
      const pp = ctl.querySelector(".pp"), sl = ctl.querySelector(".slow");
      if(sl){ if(RM) sl.hidden = true;
        sl.addEventListener("click", ()=>{ rate = (rate===1? 0.3 : 1); sl.setAttribute("aria-pressed", rate<1? "true" : "false"); }); }
      if(pp){ if(RM){ pp.hidden = true; }
        pp.addEventListener("click", ()=>{ paused = !paused; pp.classList.toggle("paused", paused); pp.setAttribute("aria-label", paused? "再生" : "一時停止");
          if(paused){ stop(); draw(t); } else { start(); } }); }
    }
    /* 図の再生を始めたら止める（同時に動くのは 1 つだけ） */
    document.addEventListener("click", (ev)=>{ if(ev.target.closest && ev.target.closest("button.b.play")) stop(); }, true);
  }

  /* スライドバーの塗り：値が変わったら --p を書きかえる（プログラムから値を入れたときも、軽い見回りで拾う） */
  function syncRange(el){ const mn = parseFloat(el.min)||0, mx = parseFloat(el.max), v = parseFloat(el.value);
    const p = (isFinite(mx) && mx>mn)? (v-mn)/(mx-mn)*100 : 0; const s = p.toFixed(1)+"%";
    if(el._p !== s){ el._p = s; el.style.setProperty("--p", s); } }
  function initRanges(){
    document.addEventListener("input", (ev)=>{ if(ev.target && ev.target.type === "range") syncRange(ev.target); }, true);
    const sweep = ()=>{ if(document.hidden) return; document.querySelectorAll(".mode.on input[type=range], .modebar input[type=range]").forEach(syncRange); alignTicks(); };
    sweep(); setInterval(sweep, 120);
  }

  /* スライドバーの下の目盛りの文字（e=0・e=0.5・e=1）を、つまみの位置にきっちり合わせる（第 29 回）
     文字の列を「左右の余白」で合わせていたので、ラベルやボタンの幅が変わるとずれていた。
     スライドバーの実際の位置と幅を測り、つまみの中心が来る位置に 1 つずつ置く（等間隔の目盛りとして） */
  function alignTicks(){
    document.querySelectorAll(".mode.on .vrow.ticks, .modebar .vrow.ticks").forEach(tr=>{
      let row = tr.previousElementSibling; while(row && !row.querySelector("input[type=range]")) row = row.previousElementSibling;
      const inp = row && row.querySelector("input[type=range]"); if(!inp) return;
      const ri = inp.getBoundingClientRect(); if(ri.width < 10) return;
      tr.classList.add("tk-on");
      const rt = tr.getBoundingClientRect(), TH = 9, sp = tr.children, n = sp.length;
      const key = Math.round(ri.left - rt.left)+":"+Math.round(ri.width); if(tr._tk === key) return; tr._tk = key;
      for(let i=0; i<n; i++){ const f = n>1? i/(n-1) : 0.5; sp[i].style.left = (ri.left - rt.left + TH + f*(ri.width - 2*TH)).toFixed(1)+"px"; }
    });
  }
  window.addEventListener("resize", ()=>{ document.querySelectorAll(".vrow.ticks").forEach(t=>{ t._tk = null; }); alignTicks(); });

  /* タブ列の下の進み具合 */
  function initProgress(){
    const nav = document.getElementById("tabs"); if(!nav) return;
    let pend = false;
    const upd = ()=>{ pend = false; const h = document.documentElement, max = h.scrollHeight - innerHeight;
      nav.style.setProperty("--prog", max>0? Math.min(1, Math.max(0, scrollY/max)).toFixed(4) : 0); };
    window.addEventListener("scroll", ()=>{ if(!pend){ pend = true; requestAnimationFrame(upd); } }, {passive:true});
    window.addEventListener("resize", upd); upd();
  }

  /* ヒーローの 3 つの要点：その章を開いて、本文の頭までスクロール */
  function initIdeas(){
    document.querySelectorAll("#hero .ideas a").forEach(a=>{
      a.addEventListener("click", (ev)=>{ ev.preventDefault(); const id = a.getAttribute("href").slice(1);
        /* 「#3-2」のような節のアドレスなら、その章を開いて節までスクロール（2026-10-18：ヒーローの式③ → ③-2 が動かなかった） */
        const q = (typeof parseHash === "function") ? parseHash("#"+id) : {};
        if(q.mode && q.sec){ activateMode(q.mode.id); history.replaceState(null, "", "#"+id); scrollToSec(q.sec); return; }
        if(typeof activateMode === "function") activateMode(id);
        history.replaceState(null, "", "#"+id);
        window.scrollTo({top: (typeof contentTop === "function"? contentTop() : 0), behavior:"auto"}); });
    });
  }

  /* 「■ 見出し」の ■ を、色のついた小さな四角にする（文字の■は環境で形がばらつく） */
  function decorate(root){
    if(!root) return;
    root.querySelectorAll(".gtitle span, .stagetitle, .ttl, .mt").forEach(el=>{
      if(el.dataset.sq) return; const n = el.firstChild;
      if(n && n.nodeType === 3 && /^\s*■\s*/.test(n.nodeValue)){ n.nodeValue = n.nodeValue.replace(/^\s*■\s*/, ""); const i = document.createElement("i"); i.className = "sq"; i.setAttribute("aria-hidden","true"); el.insertBefore(i, n); }
      el.dataset.sq = "1";
    });
  }
  function initDecorate(){
    if(typeof activateMode !== "function") return;
    const orig = activateMode;
    const showTab = ()=>{ const row = document.querySelector("#tabs .tabs-in"), on = row && row.querySelector(".tab.on"); if(!on || row.scrollWidth <= row.clientWidth) return;
      const l = on.offsetLeft - 24, r = on.offsetLeft + on.offsetWidth + 24;
      if(l < row.scrollLeft) row.scrollLeft = l; else if(r > row.scrollLeft + row.clientWidth) row.scrollLeft = r - row.clientWidth; };   // スマホ：選んだタブが見えるように横に送る
    const cur = ()=>document.querySelectorAll("#tabs .tab").forEach(b=>{ if(b.classList.contains("on")) b.setAttribute("aria-current","page"); else b.removeAttribute("aria-current"); });
    activateMode = function(id){ const r = orig.apply(this, arguments); decorate(document.getElementById(id)); showTab(); cur(); return r; };   // 章を開いたあと（シムは初めて開いたときに作られる）
    showTab(); cur();
    document.querySelectorAll(".mode.on").forEach(decorate);
  }
  /* タブ列：ヒーローを過ぎたら .stuck */
  function initStuck(){
    const hero = document.getElementById("hero"), nav = document.getElementById("tabs"); if(!hero || !nav || !("IntersectionObserver" in window)) return;
    new IntersectionObserver((es)=>{ es.forEach(en=>nav.classList.toggle("stuck", !en.isIntersecting)); }, {threshold:0}).observe(hero);
    const nb = nav.querySelector(".navbrand"); if(nb) nb.addEventListener("click", (ev)=>{ ev.preventDefault(); window.scrollTo({top:0, behavior:"auto"}); });
  }
  /* フッター：題名と章の目次 */
  function initFooter(){
    const f = document.querySelector("#wrap footer") || document.querySelector("body > footer"); if(!f) return;
    document.body.appendChild(f);
    const C = "①②③④⑤⑥⑦⑧⑨";
    const items = (typeof MODES !== "undefined"? MODES : []).map((m,i)=>'<li><a href="#'+m.id+'" data-mode="'+m.id+'"><b>'+C[i]+'</b>'+m.name+'</a></li>').join("");
    f.innerHTML = '<div class="ft-in"><p class="ft-mark">Basics of Waves<span>波の基礎 〜単振動が次々と伝わっていく〜</span></p>'+
      '<ul class="ft-nav">'+items+'</ul>'+
      '<div class="ft-base"><span><a class="ft-home" href="'+SITE_HOME+'">⌂ 楽楽（らくらく）高校物理 トップページ</a>　／　高校物理 ・ 波動</span><span class="ft-r"><button type="button" class="ft-pages">ほかのページ一覧</button><a href="#top" class="ft-top">▲ ページの一番上へ</a></span></div></div>';
    f.querySelectorAll("a[data-mode]").forEach(a=>a.addEventListener("click", (ev)=>{ ev.preventDefault(); const id = a.dataset.mode;
      activateMode(id); history.replaceState(null, "", "#"+id); window.scrollTo({top:(typeof contentTop==="function"? contentTop() : 0), behavior:"auto"}); }));
    const fp = f.querySelector(".ft-pages"); if(fp) fp.addEventListener("click", ()=>{ if(window.SITENAV) window.SITENAV.open(); });
    const tp = f.querySelector(".ft-top"); if(tp) tp.addEventListener("click", (ev)=>{ ev.preventDefault(); window.scrollTo({top:0, behavior:"auto"}); });
  }

  document.addEventListener("DOMContentLoaded", ()=>{
    initFooter(); initDecorate(); initStage(); initRanges(); initProgress(); initIdeas(); initStuck();
  });
})();



