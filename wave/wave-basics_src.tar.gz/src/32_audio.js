/* ===== 32_audio.js ===== */
/* =========================================================================
   32_audio.js … 音（Web Audio）。約束：
   ・鳴らすのはボタンを押したときだけ（AudioContext は最初に押したときに作る）
   ・同時に鳴るのは 1 つだけ（新しく鳴らすと前の音は止まる）
   ・音量の上限（MAX_GAIN）と、鳴りはじめ・止めるときの短いフェード（プツッという音を出さない）
   ・人に聞こえない振動数（およそ 20〜20000 Hz の外）は鳴らさない
   ・タブを切りかえた・ページが隠れたときは止める
   ・音と図は同じ値（振動数・倍音の比）から作る：AUDIO.play には図に使っている値をそのまま渡す
   ========================================================================= */
'use strict';
var AUDIO = (function () {
  var ctx = null, master = null, comp = null, cur = null, listeners = [];
  var MAX_GAIN = 0.22, FADE = 0.03;
  function ensure() {
    if (ctx) return ctx;
    var AC = window.AudioContext || window.webkitAudioContext; if (!AC) return null;
    ctx = new AC();
    comp = ctx.createDynamicsCompressor(); comp.threshold.value = -10; comp.ratio.value = 6;
    master = ctx.createGain(); master.gain.value = MAX_GAIN;
    master.connect(comp); comp.connect(ctx.destination);
    return ctx;
  }
  function notify() { listeners.forEach(function (f) { try { f(cur ? cur.owner : null); } catch (e) { } }); }
  /* voices：[{ f, amp, partials:[[n, a], …] }]。partials がなければ正弦波。vol：0〜1（図の振幅から） */
  function play(owner, voices, vol) {
    stop(true);
    var c = ensure(); if (!c) return false;
    if (c.state === 'suspended' && c.resume) c.resume();
    var ok = voices.filter(function (v) { return WAVE.audible(v.f); });
    /* 聞こえない振動数だけのときも「鳴らしている」状態は続ける（音は出さない）。超音波などにしても勝手に止まらない（2026-11-05 千葉さん 8 回目） */
    if (!ok.length) { cur = { owner: owner, g: null, oscs: [], t0: c.currentTime, silent: true }; notify(); return false; }
    var g = c.createGain(), now = c.currentTime, target = clamp(vol === undefined ? 1 : vol, 0, 1) / Math.max(1, ok.length);
    g.gain.setValueAtTime(0, now); g.gain.linearRampToValueAtTime(target, now + FADE);
    g.connect(master);
    var oscs = ok.map(function (v) {
      var o = c.createOscillator();
      if (v.partials && v.partials.length) {
        var N = 0; v.partials.forEach(function (p) { N = Math.max(N, p[0]); });
        var re = new Float32Array(N + 1), im = new Float32Array(N + 1), sum = 0;
        v.partials.forEach(function (p) { if (p[0] * v.f <= 20000) { im[p[0]] = p[1]; sum += Math.abs(p[1]); } });
        o.setPeriodicWave(c.createPeriodicWave(re, im, { disableNormalization: false }));
      } else o.type = 'sine';
      o.frequency.setValueAtTime(v.f, now);
      var og = c.createGain(); og.gain.value = v.amp === undefined ? 1 : v.amp;
      o.connect(og); og.connect(g); o.start(now);
      return o;
    });
    cur = { owner: owner, g: g, oscs: oscs, t0: now, n: ok.length };
    notify();
    return true;
  }
  /* 鳴らしたまま、音の大きさだけをなめらかに変える（水面を動かしているときなど。鳴らし直すとプツプツいうので） */
  function setVol(owner, vol) {
    if (!cur || cur.owner !== owner || !cur.g || !ctx) return false;
    var tg = clamp(vol, 0, 1) / Math.max(1, cur.n);
    try { cur.g.gain.cancelScheduledValues(ctx.currentTime); cur.g.gain.setTargetAtTime(tg, ctx.currentTime, 0.04); } catch (e) { }
    return true;
  }
  /* はじいた音（モノコード・ギター）・短く鳴らす音（楽器の 1 音）。dur 秒で自然に消える。tau：減衰の時定数（なければ、dur の間ほぼ一定で最後にフェード） */
  function pluck(owner, v, vol, dur, tau) {
    stop(true);
    var c = ensure(); if (!c) return false;
    if (c.state === 'suspended' && c.resume) c.resume();
    if (!WAVE.audible(v.f)) { notify(); return false; }
    var now = c.currentTime, g = c.createGain(), A = clamp(vol === undefined ? 1 : vol, 0, 1);
    g.gain.setValueAtTime(0, now); g.gain.linearRampToValueAtTime(A, now + 0.006);
    if (tau) g.gain.setTargetAtTime(0, now + 0.01, tau); else { g.gain.setValueAtTime(A, now + Math.max(0.02, dur - 0.12)); g.gain.linearRampToValueAtTime(0, now + dur); }
    g.connect(master);
    var o = c.createOscillator();
    if (v.partials && v.partials.length) {
      var N = 0; v.partials.forEach(function (p) { N = Math.max(N, p[0]); });
      var re = new Float32Array(N + 1), im = new Float32Array(N + 1);
      v.partials.forEach(function (p) { if (p[0] * v.f <= 20000) im[p[0]] = p[1]; });
      o.setPeriodicWave(c.createPeriodicWave(re, im, { disableNormalization: false }));
    } else o.type = 'sine';
    var og = c.createGain(); og.gain.value = 1;                      /* 倍音だけにする（ハーモニクス）ときに、ここで入れかえる */
    o.frequency.setValueAtTime(v.f, now); o.connect(og); og.connect(g); o.start(now); o.stop(now + dur + 0.05);
    var me = { owner: owner, g: g, oscs: [o], t0: now, n: 1, once: true, o: o, og: og, f: v.f, lfo: null, tEnd: now + dur + 0.05 };
    if (v.cents || v.vib) bendOsc(me, v.cents || 0, v.vib, true);
    cur = me; notify();
    setTimeout(function () { if (cur === me) { cur = null; notify(); } try { g.disconnect(); } catch (e) { } }, (dur + 0.1) * 1000);
    return true;
  }
  /* 音の高さをセントでずらす（チョーキング）。vib：{ rate〔Hz〕, depth〔セント〕} なら 0〜depth を行き来する（ビブラート） */
  function bendOsc(me, cents, vib, now0) {
    var c = ctx, now = c.currentTime, d = me.o.detune;
    if (me.lfo) { try { me.lfo.stop(now); me.lfo.disconnect(); me.lg.disconnect(); } catch (e) { } me.lfo = null; }
    d.cancelScheduledValues(now);
    if (vib) {
      d.setValueAtTime(now0 ? vib.depth / 2 : d.value, now); if (!now0) d.linearRampToValueAtTime(vib.depth / 2, now + 0.1);
      var l = c.createOscillator(), lg = c.createGain(); l.frequency.value = vib.rate; lg.gain.value = vib.depth / 2; l.connect(lg); lg.connect(d); l.start(now); l.stop(me.tEnd); me.oscs.push(l);
      me.lfo = l; me.lg = lg;
    } else if (now0) d.setValueAtTime(cents, now);
    else { d.setValueAtTime(d.value, now); d.linearRampToValueAtTime(cents, now + 0.15); }
  }
  function bend(owner, cents, vib) { if (!cur || cur.owner !== owner || !cur.o || !ctx) return false; bendOsc(cur, cents, vib, false); return true; }
  /* ハーモニクス：鳴っているはじいた音を、partials（[[n, a], …]）の音色にすばやく（20 ms）入れかえる。gr：音の大きさの割合 */
  function harm(owner, partials, gr) {
    if (!cur || cur.owner !== owner || !cur.o || !ctx) return false;
    var c = ctx, me = cur, now = c.currentTime, N = 0;
    partials.forEach(function (p) { N = Math.max(N, p[0]); });
    var re = new Float32Array(N + 1), im = new Float32Array(N + 1);
    partials.forEach(function (p) { if (p[0] * me.f <= 20000) im[p[0]] = p[1]; });
    var o2 = c.createOscillator(), og2 = c.createGain();
    o2.setPeriodicWave(c.createPeriodicWave(re, im, { disableNormalization: false }));
    o2.frequency.setValueAtTime(me.f, now); o2.detune.setValueAtTime(me.o.detune.value, now);
    if (me.lg) { try { me.lg.connect(o2.detune); } catch (e) { } }
    og2.gain.setValueAtTime(0, now); og2.gain.linearRampToValueAtTime(clamp(gr, 0, 1), now + 0.02);
    o2.connect(og2); og2.connect(me.g); o2.start(now); o2.stop(me.tEnd);
    try { me.og.gain.cancelScheduledValues(now); me.og.gain.setValueAtTime(me.og.gain.value, now); me.og.gain.linearRampToValueAtTime(0, now + 0.02); me.o.stop(now + 0.05); } catch (e) { }
    me.o = o2; me.og = og2; me.oscs.push(o2);
    return true;
  }
  /* 鳴らしたまま、音色（倍音の表）と振動数を入れかえる（④-1 の音作り：棒を動かすたびに鳴らし直すとプツプツいうので） */
  function tone(owner, f, partials) {
    if (!cur || cur.owner !== owner || !cur.oscs.length || !ctx || cur.silent || !WAVE.audible(f)) return false;
    var c = ctx, now = c.currentTime, o = cur.oscs[0], N = 0;
    partials.forEach(function (p) { N = Math.max(N, p[0]); });
    var re = new Float32Array(N + 1), im = new Float32Array(N + 1);
    partials.forEach(function (p) { if (p[0] * f <= 20000) im[p[0]] = p[1]; });
    try { o.setPeriodicWave(c.createPeriodicWave(re, im, { disableNormalization: false })); o.frequency.setTargetAtTime(f, now, 0.015); } catch (e) { return false; }
    return true;
  }
  function stop(silent) {
    if (!cur || !ctx) { cur = null; if (!silent) notify(); return; }
    if (!cur.g) { cur = null; if (!silent) notify(); return; }
    var c = cur, now = ctx.currentTime;
    try { c.g.gain.cancelScheduledValues(now); c.g.gain.setValueAtTime(c.g.gain.value, now); c.g.gain.linearRampToValueAtTime(0, now + FADE); } catch (e) { }
    c.oscs.forEach(function (o) { try { o.stop(now + FADE + 0.02); } catch (e) { } });
    setTimeout(function () { try { c.g.disconnect(); } catch (e) { } }, (FADE + 0.1) * 1000);
    cur = null;
    if (!silent) notify();
  }
  /* 鳴らしている間に振動数・音量を変える（なめらかに） */
  function retune(owner, voices, vol) {
    if (!cur || cur.owner !== owner) return false;
    return play(owner, voices, vol);
  }
  document.addEventListener('visibilitychange', function () { if (document.hidden) stop(); });
  window.addEventListener('pagehide', function () { stop(); });
  return {
    play: play, stop: stop, retune: retune, setVol: setVol, pluck: pluck, bend: bend, harm: harm, tone: tone,
    owner: function () { return cur ? cur.owner : null; },
    onChange: function (f) { listeners.push(f); },
    MAX_GAIN: MAX_GAIN, FADE: FADE,
    /* テスト用：いま鳴らしている（はずの）音の中身 */
    _state: function () { return cur ? { owner: cur.owner, n: cur.oscs.length } : null; }
  };
})();
