const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();
for(const [name,url] of [['wave','file:///home/claude/wave/out/wave-basics.html'],['shm','file:///mnt/user-data/uploads/simple-harmonic-motion.html']]){
 for(const w of [1024,390]){ const p=await b.newPage({viewport:{width:w,height:820}});
  await p.goto(url+'#mode1'); await p.waitForTimeout(1200);
  await p.screenshot({path:`/tmp/claude-0/shots/cmp_${name}_${w}_head.png`});
  await p.evaluate(()=>window.scrollTo(0,document.body.scrollHeight)); await p.waitForTimeout(400);
  await p.screenshot({path:`/tmp/claude-0/shots/cmp_${name}_${w}_foot.png`});
  await p.evaluate(()=>{window.scrollTo(0,0); document.getElementById('bPages').click();}); await p.waitForTimeout(500);
  await p.screenshot({path:`/tmp/claude-0/shots/cmp_${name}_${w}_drawer.png`});
  await p.close(); }}
await b.close();})();
