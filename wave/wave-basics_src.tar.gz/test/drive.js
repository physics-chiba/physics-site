// node test/drive.js WIDTH HASH "js;js;..." name   … ステップごとに js を実行して最後に撮る
const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const errs=[];
const p=await b.newPage({viewport:{width:+process.argv[2],height:+(process.argv[6]||900)}});
p.on('pageerror',e=>errs.push('PAGEERR '+e.message));p.on('console',m=>{if(m.type()==='error'||m.text().startsWith('LOG'))errs.push(m.text())});
await p.goto('file:///home/claude/wave/out/wave-basics.html'+process.argv[3]);await p.waitForTimeout(900);
for(const st of (process.argv[4]||'').split(';;')){ if(!st.trim())continue; if(st.startsWith('wait ')){await p.waitForTimeout(+st.slice(5));continue;}
  if(st.startsWith('clip ')){ const sel=st.slice(5); const e=await p.$(sel); await e.screenshot({path:`/tmp/claude-0/shots/${process.argv[5]}.png`}); continue;}
  const r=await p.evaluate(st); if(r!==undefined) console.log('=>',JSON.stringify(r)); }
if(!(process.argv[4]||'').includes('clip ')) await p.screenshot({path:`/tmp/claude-0/shots/${process.argv[5]}.png`});
console.log('errs',errs);await b.close();})();
