// スマホ（タッチ）での確認：node test/phone.js
const {chromium, devices}=require('playwright');
(async()=>{const b=await chromium.launch();const out={};
for (const dn of ['iPhone 13','Pixel 7']) {
 const ctx=await b.newContext({...devices[dn]}); const p=await ctx.newPage(); const errs=[];
 p.on('pageerror',e=>errs.push(e.message));
 await p.goto('file:///home/claude/wave/out/wave-basics.html#1-1'); await p.waitForTimeout(900);
 const r={};
 // ▶ スタートをタップ
 await p.tap('#m1s1 .ctrls button.b.play'); await p.waitForTimeout(300);
 r.tap_play=await p.evaluate("TEST.sims().m1s1.playing");
 await p.tap('#m1s1 .ctrls button.b.play');
 await p.tap('#m1s1 .onep'); await p.waitForTimeout(200);
 r.tap_one=await p.evaluate("TEST.sims().m1s1.srcMode");
 // 手をタッチでドラッグ（CDP のタッチ）
 const cdp=await ctx.newCDPSession(p);
 const touchDrag=async(x,y,dx,dy)=>{await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x,y}]});
   for(let k=1;k<=10;k++){await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:x+dx*k/10,y:y+dy*k/10}]});await p.waitForTimeout(16);}
   await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});};
 await p.evaluate("TEST.sims().m1s1.toDefaults()");
 await p.evaluate("document.querySelector('#m1s1 canvas').scrollIntoView({block:'center'})"); await p.waitForTimeout(200);
 const h=await p.evaluate("(()=>{var s=TEST.sims().m1s1,h=m1s1HandPos(s),r=s.cv.getBoundingClientRect();return {x:r.left+h.x,y:r.top+h.y};})()");
 const sy0=await p.evaluate('scrollY');
 await touchDrag(h.x,h.y,0,-40);
 r.touch_hand=await p.evaluate("TEST.sims().m1s1.srcMode"); r.hand_no_scroll=Math.abs(await p.evaluate('scrollY')-sy0)<1;
 // ①-2 ★ をタッチでドラッグ
 await p.evaluate("location.hash='#1-2'"); await p.waitForTimeout(400);
 await p.evaluate("TEST.sims().m1s2.wg.cv.scrollIntoView({block:'center'})"); await p.waitForTimeout(200);
 const sp=await p.evaluate("(()=>{var s=TEST.sims().m1s2,g=s.wg.g,r=s.wg.cv.getBoundingClientRect(),xp=m1s2Xp(s);return {x:r.left+g.X(xp),y:r.top+g.Y(m1s2Y(s,xp,s.t)),bx:r.left+g.X(m1s2Q(s).lam/2)};})()");
 await touchDrag(sp.x,sp.y,sp.bx-sp.x+2,0);
 r.touch_star=await p.evaluate("TEST.sims().m1s2.pt");
 // ①-3 作図の手順・縦波に戻す をタップ
 await p.evaluate("location.hash='#1-3'"); await p.waitForTimeout(400);
 await p.tap('#m1s3 .trbtn'); await p.tap('#m1s3 .stepgo'); await p.waitForTimeout(150);
 r.tap_step=await p.evaluate("TEST.sims().m1s3.stp");
 await p.tap('#m1s3 details.qfold summary'); r.tap_fold=await p.evaluate("document.querySelector('#m1s3 details.qfold').open");
 const bb=await p.evaluate("(()=>{var s=TEST.sims().m1s3,a=s.stepBar.getBoundingClientRect(),c=s.cv.getBoundingClientRect();return a.right<=c.right+1 && a.left>=c.left-1;})()");
 r.m1s3_bar_inside=bb;
 await p.tap('#m1s3 .stepgo');
 // ①-4 行の ▶ スタート
 await p.evaluate("location.hash='#1-4'"); await p.waitForTimeout(400);
 await p.tap('#m1s4 .m4-sound .rplay'); await p.waitForTimeout(300);
 r.tap_row=await p.evaluate("[TEST.sims().m1s4.rows.sound.on, TEST.sims().m1s4.rows.light.on]");
 await p.tap('#m1s4 .m4-sound .rplay');
 // 文字が小さすぎないか（ボタンの高さ）
 r.min_btn_h=await p.evaluate("Math.round(Math.min.apply(null,[...document.querySelectorAll('.mode.on button.b')].filter(b=>b.offsetParent).map(b=>b.getBoundingClientRect().height)))");
 // 章 ② も
 await p.evaluate("document.querySelector('#tabs .tab[data-mode=mode2]').click()"); await p.waitForTimeout(400);
 await p.tap('#m2s2 .stepgo'); await p.waitForTimeout(100); await p.tap('#m2s2 .stepbar button:nth-child(3)'); await p.waitForTimeout(100);
 r.m2s2_step=await p.evaluate("TEST.sims().m2s2.stp");
 await p.evaluate("document.querySelector('#tabs .tab[data-mode=mode3]').click()"); await p.waitForTimeout(400);
 await p.tap('#m3s3 [data-k]'.replace('[data-k]','')+' .ctrls button.b.play'); await p.waitForTimeout(200);
 r.m3_play=await p.evaluate("TEST.sims().m3s3.playing");
 await p.tap('#m3s3 .ctrls button.b.play');
 r.hscroll=await p.evaluate("document.documentElement.scrollWidth-innerWidth");
 r.errs=errs;
 // 画面ごとの写真（自分で見る用）
 if (dn==='iPhone 13') for (const id of ['m1s1','m1s2','m1s3','m1s4','m2s1','m2s2','m2s3']) {
   const md=id.startsWith('m1')?'mode1':'mode2';
   await p.evaluate(`document.querySelector('#tabs .tab[data-mode=${md}]').click()`); await p.waitForTimeout(250);
   const e=await p.$('#'+id); await e.screenshot({path:`/tmp/claude-0/shots/ph/${id}.png`}); }
 out[dn]=r; await ctx.close(); }
console.log(JSON.stringify(out,null,1)); await b.close();})();
