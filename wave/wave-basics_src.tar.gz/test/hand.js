const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1440,height:900}});
await p.goto('file:///home/claude/wave/out/wave-basics.html#1-1');await p.waitForTimeout(800);
const box=await p.evaluate(()=>{var s=TEST.sims().m1s1,h=m1s1HandPos(s),r=s.cv.getBoundingClientRect();return {x:r.left+h.x,y:r.top+h.y};});
await p.mouse.move(box.x,box.y);await p.mouse.down();
for(let k=0;k<40;k++){await p.mouse.move(box.x,box.y-60*Math.sin(k/40*Math.PI*2));await p.waitForTimeout(20);}
await p.waitForTimeout(300);
const e=await p.$('#m1s1');await e.screenshot({path:'/tmp/claude-0/shots/hand.png'});await p.mouse.up();await b.close();})();
