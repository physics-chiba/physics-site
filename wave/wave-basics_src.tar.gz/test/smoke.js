const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const errs=[];let ext=0;
const p=await b.newPage({viewport:{width:+(process.argv[2]||1440),height:900}});
p.on('pageerror',e=>errs.push('PAGEERR '+e.message));p.on('console',m=>{if(m.type()==='error')errs.push('CONSOLE '+m.text())});
p.on('request',r=>{const u=r.url();if(!/^(file|data|blob):/.test(u))ext++});
await p.goto('file:///home/claude/wave/out/wave-basics.html'+(process.argv[3]||''));await p.waitForTimeout(1200);
const sh=process.argv[4]||'shot';
await p.screenshot({path:`/tmp/claude-0/shots/${sh}.png`,fullPage:process.argv[5]==='full'});
console.log('errs',errs,'ext',ext);await b.close();})();
