"""wave-basics.html の自動テスト。python3 test/run_test.py --twice
・物理の検算（TEST.check）／ページエラー 0／外部への通信 0
・320〜1440 px で横スクロールなし（章 ① の全部の節）
・共通フッターの文字列／▶ スタートが光って、押すと消える
・グラフの操作（experiment-graph-ui）／①-1 の手でつかむ／①-3 のステップで図が上下しない／音（①-4）
2 回走らせて、結果の JSON が完全に一致することを確かめる。
"""
import json, sys, os
from playwright.sync_api import sync_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
PAGE = 'file://' + os.path.join(HERE, '..', 'out', 'wave-basics.html')
HTML = open(os.path.join(HERE, '..', 'out', 'wave-basics.html'), encoding='utf-8').read()


def run_once():
    res = {}
    with sync_playwright() as p:
        b = p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
        errs, ext = [], []
        pg = b.new_page(viewport={'width': 1440, 'height': 900})
        pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' else None)
        pg.on('request', lambda r: ext.append(r.url) if not r.url.startswith(('file:', 'data:', 'blob:')) else None)
        pg.goto(PAGE + '#1-1'); pg.wait_for_timeout(900)
        res['check'] = pg.evaluate('TEST.check()')
        # ▶ スタートが光る → 押すと消える
        pg.wait_for_timeout(600)
        res['glow_on_load'] = pg.evaluate("document.getElementById('bPlay').classList.contains('sg-glow')")
        pg.click('#bPlay'); pg.wait_for_timeout(500)
        res['glow_after_click'] = pg.evaluate("document.getElementById('bPlay').classList.contains('sg-glow')")
        res['play_label'] = pg.evaluate("document.getElementById('bPlay').textContent")
        pg.click('#bPlay')
        # ①-1：手でつかんで上下に動かす（図が上下しないこと・手で動かした波が記録されること）
        top0 = pg.evaluate("document.querySelector('#m1s1 canvas').getBoundingClientRect().top + scrollY")
        pg.evaluate("TEST.sims().m1s1.resetT()")
        box = pg.evaluate("(()=>{var s=TEST.sims().m1s1,h=m1s1HandPos(s),r=s.cv.getBoundingClientRect();return {x:r.left+h.x,y:r.top+h.y};})()")
        pg.mouse.move(box['x'], box['y']); pg.mouse.down()
        for k in range(12):
            pg.mouse.move(box['x'], box['y'] - 4 * k); pg.wait_for_timeout(16)
        for k in range(12):
            pg.mouse.move(box['x'], box['y'] - 48 + 4 * k); pg.wait_for_timeout(16)
        pg.mouse.up(); pg.wait_for_timeout(200)
        st = pg.evaluate("(()=>{var s=TEST.sims().m1s1;var P=s.src.pieces;return {mode:s.srcMode,kinds:P.map(p=>p.k),maxY:Math.max.apply(null,(P.filter(p=>p.k==='samp')[0]||{ys:[0]}).ys),tag:s.handTag.classList.contains('on'),playing:s.playing};})()")
        res['hand'] = {'mode': st['mode'], 'kinds': st['kinds'], 'moved_up': st['maxY'] > 0.05, 'tag': st['tag']}
        top1 = pg.evaluate("document.querySelector('#m1s1 canvas').getBoundingClientRect().top + scrollY")
        res['hand_canvas_stays'] = abs(top1 - top0) < 0.5
        pg.evaluate("TEST.sims().m1s1.toDefaults()")
        # ①-1：「1 周期分振動させる」：最初から、波源はちょうど 1 周期だけ振動する
        pg.evaluate("document.querySelector('#m1s1 .onep').click()"); pg.wait_for_timeout(150)
        res['one_period'] = pg.evaluate("(()=>{var s=TEST.sims().m1s1,P=s.src.pieces,q=m1s1Q(s);return {mode:s.srcMode,playing:s.playing,n:P.length,t1_is_T:Math.abs(P[0].t1-q.T)<1e-12, after:SRC.y0(s.src,q.T+0.01)};})()")
        # 2 周期分：2T たった瞬間に一時停止する（注目する点は出さない）
        res['two_period_stop'] = pg.evaluate("(()=>{var s=TEST.sims().m1s1; s.toDefaults(); document.querySelectorAll('#m1s1 .onep')[1].click(); for(var i=0;i<400 && s.playing;i++) s.step(0.05); var q=m1s1Q(s); return {t:+s.t.toFixed(9), twoT:2*q.T, playing:s.playing, nPer:s.nPer};})()")
        pg.evaluate("TEST.sims().m1s1.toDefaults()")
        # ①-2：グラフの操作
        pg.evaluate("location.hash='#1-2'"); pg.wait_for_timeout(500)
        g = {}
        g['x0'] = pg.evaluate("[XAXES['m1s2-x'].lo, XAXES['m1s2-x'].hi]")
        cv = pg.evaluate("(()=>{var s=TEST.sims().m1s2,r=s.wg.cv.getBoundingClientRect(),R=s.wg.rect();return {l:r.left,t:r.top,x0:R.x0,x1:R.x1,y0:R.y0,y1:R.y1};})()")
        cx, cy = cv['l'] + (cv['x0'] + cv['x1']) / 2 + 30, cv['t'] + cv['y0'] + 20
        yt0 = pg.evaluate("[TEST.sims().m1s2.wgt.yr.lo, TEST.sims().m1s2.wgt.yr.hi]")
        pg.mouse.move(cx, cy); pg.mouse.down(); pg.mouse.move(cx - 60, cy + 30, steps=6); pg.mouse.up()
        g['pan_x_fixed'] = pg.evaluate("XAXES['m1s2-x'].lo") == g['x0'][0]   # 左右へのドラッグはしない
        g['pan_y_locked'] = not pg.evaluate("TEST.sims().m1s2.wg.user")
        g['other_graph_y_same'] = pg.evaluate("[TEST.sims().m1s2.wgt.yr.lo, TEST.sims().m1s2.wgt.yr.hi]") == yt0
        # 横軸の目盛りをドラッグ（拡大縮小）
        span0 = pg.evaluate("XAXES['m1s2-x'].hi-XAXES['m1s2-x'].lo")
        ax, ay = cv['l'] + (cv['x0'] + cv['x1']) / 2, cv['t'] + cv['y1'] + 12
        pg.mouse.move(ax, ay); pg.mouse.down(); pg.mouse.move(ax + 80, ay, steps=5); pg.mouse.up()
        g['xzoom_none'] = round(pg.evaluate("XAXES['m1s2-x'].hi-XAXES['m1s2-x'].lo") / span0, 3) == 1.0
        g['no_reset_btn'] = pg.evaluate("document.querySelectorAll('#m1s2 .greset').length===0 && document.querySelectorAll('#m1s2 .gchk').length===0")
        pg.evaluate("TEST.sims().m1s2.bDef.click()")
        g['reset_by_defaults'] = pg.evaluate("[XAXES['m1s2-x'].lo, XAXES['m1s2-x'].hi]") == g['x0']
        # y-t グラフ：再生してから点をクリック → 見出しに座標。dy/dt は既定 OFF
        pg.evaluate("var s=TEST.sims().m1s2; s.setT(s.tEnd()*0.9)")
        pt = pg.evaluate("(()=>{var s=TEST.sims().m1s2,g=s.wgt,r=g.cv.getBoundingClientRect(),q=g._pts[Math.floor(g._pts.length/2)];return {x:r.left+q.px,y:r.top+q.py};})()")
        pg.mouse.click(pt['x'], pt['y']); pg.wait_for_timeout(100)
        g['pick_head'] = pg.evaluate("document.querySelector('#m1s2 .g-yt .gsel').textContent.length>0")
        pg.mouse.click(pt['x'], pt['y']); pg.wait_for_timeout(100)
        g['pick_again_clears'] = pg.evaluate("document.querySelector('#m1s2 .g-yt .gsel').textContent.length===0")
        # 最大化のボタンはない
        g['no_max_btn'] = pg.evaluate("document.querySelectorAll('.gmaxb').length===0")
        # 枠の外は描かない：パンで曲線を外へ出しても、枠の外の画素は白
        res['graph'] = g
        # ①-2：y-t グラフ 2 つは、グラフの部分（枠の中）の大きさが同じ・原点 O からの吹き出しがある
        res['m1s2_yt_same'] = pg.evaluate("(()=>{var s=TEST.sims().m1s2,a=s.wgt.g.R,b=s.wgo.g.R;return [a.x1-a.x0===b.x1-b.x0, a.y1-a.y0===b.y1-b.y0, s.wgt.H<s.wg.H];})()")
        res['m1s2_bubble'] = pg.evaluate("(()=>{var s=TEST.sims().m1s2,d=s.bpath.getAttribute('d')||'';return d.length>40 && getComputedStyle(s.bsvg).display!=='none';})()")
        # ①-1：同位相・逆位相は同じ列（1440 では「すべて最初の設定に戻す」とも同じ列）
        res['m1s1_ph_row'] = pg.evaluate("(()=>{var s=TEST.sims().m1s1,t=e=>{var r=e.getBoundingClientRect();return r.top+r.height/2;},same=(a,b)=>Math.abs(t(a)-t(b))<4;return [same(s.extra.ph1,s.extra.ph2), same(s.extra.ph1,s.bDef), same(s.extra.b2,s.bDef)];})()")
        # ①-2：左右のグラフの y = 0 の高さがそろう／Δt 後の波形はボタンで出て、再生で消える
        pg.evaluate("TEST.sims().m1s2.resetT()"); pg.wait_for_timeout(100)
        res['m1s2_zero_align_px'] = pg.evaluate("(function(){var s=TEST.sims().m1s2;var z=g=>g.cv.getBoundingClientRect().top+g.g.Y(0);return Math.round(Math.abs(z(s.wg)-z(s.wgt))*10)/10;})()")
        pg.evaluate("document.querySelector('#m1s2 .dtb').click()")
        dt1 = pg.evaluate("TEST.sims().m1s2.showDt")
        pg.evaluate("TEST.sims().m1s2.togglePlay()"); pg.wait_for_timeout(120)
        dt2 = pg.evaluate("TEST.sims().m1s2.showDt")
        pg.evaluate("TEST.sims().m1s2.togglePlay()")
        res['m1s2_dt'] = [dt1, dt2]
        # ★ をドラッグして点 B（λ/2）に吸いつける
        pg.evaluate("TEST.sims().m1s2.resetT()")
        sp = pg.evaluate("(()=>{var s=TEST.sims().m1s2,g=s.wg.g,r=s.wg.cv.getBoundingClientRect(),xp=m1s2Xp(s);return {x:r.left+g.X(xp),y:r.top+g.Y(m1s2Y(s,xp,s.t)),bx:r.left+g.X(m1s2Q(s).lam/2)};})()")
        pg.mouse.move(sp['x'], sp['y']); pg.mouse.down(); pg.mouse.move(sp['bx'] + 3, sp['y'], steps=8); pg.mouse.up()
        res['star_drag_pt'] = pg.evaluate("[TEST.sims().m1s2.pt, TEST.sims().m1s2.ptX]")
        # 点 O〜E のボタン → y-t の題が変わる
        pg.evaluate("document.querySelectorAll('#m1s2 .seg')[1].querySelectorAll('button')[0].click()")
        res['yt_title_O'] = pg.evaluate("document.querySelector('#m1s2 .g-yt .gt').textContent")
        # ①-3：ステップ表示で図が上下しない
        pg.evaluate("location.hash='#1-3'"); pg.wait_for_timeout(400)
        c3 = "document.querySelector('#m1s3 canvas').getBoundingClientRect().top + scrollY"
        a = pg.evaluate(c3)
        res['tr_glow_before'] = pg.evaluate("document.querySelector('#m1s3 .trbtn').classList.contains('glowpick')")
        pg.evaluate("document.querySelector('#m1s3 .stepgo').click()")
        steps = []
        for k in range(4):
            steps.append(pg.evaluate("TEST.sims().m1s3.stp"))
            pg.evaluate("document.querySelectorAll('#m1s3 .stepbar button')[1].click()")
        b2 = pg.evaluate(c3)
        res['m1s3_steps'] = steps
        res['m1s3_canvas_stays'] = abs(a - b2) < 0.5
        pg.evaluate("document.querySelector('#m1s3 .stepgo').click()")
        # ①-3：「縦波に戻す」ボタンはない・説明カードは閉じていて、クリックで開く・1 周期の図がある
        res['m1s3_noback'] = pg.evaluate("document.querySelectorAll('#m1s3 .backbtn').length===0")
        res['fold'] = pg.evaluate("(()=>{var d=document.querySelector('#m1s3 details.qfold');var a=d.open;d.querySelector('summary').click();var b=d.open;d.querySelector('summary').click();return [a,b,document.querySelectorAll('.perfig canvas').length];})()")
        # ①-4：音（鳴らす・止める・聞こえない振動数・章を切りかえたら止まる）
        pg.evaluate("location.hash='#1-4'"); pg.wait_for_timeout(400)
        res['tr_glow_after'] = pg.evaluate("document.querySelector('#m1s3 .trbtn').classList.contains('glowpick')")
        pg.evaluate("document.querySelector('#m1s4 .spk').click()"); pg.wait_for_timeout(150)
        au = {'playing': pg.evaluate("AUDIO.owner()"), 'label': pg.evaluate("document.querySelector('#m1s4 .spk').textContent")}
        pg.evaluate("document.querySelector('#tabs .tab[data-mode=mode2]').click()"); pg.wait_for_timeout(100)
        au['after_tab'] = pg.evaluate("AUDIO.owner()")
        pg.evaluate("document.querySelector('#tabs .tab[data-mode=mode1]').click()"); pg.wait_for_timeout(200)
        pg.evaluate("var s=TEST.sims().m1s4; s.st.f.sound=5; s.changed('sound')")
        pg.evaluate("document.querySelector('#m1s4 .spk').click()"); pg.wait_for_timeout(100)
        au['inaudible_plays'] = pg.evaluate("AUDIO.owner()")
        au['inaudible_msg'] = pg.evaluate("document.querySelector('#m1s4 .spkmsg').classList.contains('on')")
        res['audio'] = au
        # ①-4：6 つの図（5 種類＋水面の表面波）がそろって出ている
        res['m1s4_rows'] = pg.evaluate("document.querySelectorAll('#m1s4 .m4row canvas').length")
        res['m1s4_one_play'] = pg.evaluate("document.querySelectorAll('#m1s4 button.b.play').length")
        # ①-4：スライダーで変えた波だけ最初から（ほかの波は止まらない）
        res['m1s4_row_restart'] = pg.evaluate("(()=>{var s=TEST.sims().m1s4; s.bReset.click(); s.togglePlay(); for(var i=0;i<40;i++) s.step(0.05); s.st.f.water=1.0; s.changed('water'); var r={playing:s.playing, water_tl:+s.rows.water.tl.toFixed(6), machine_tl:+s.rows.machine.tl.toFixed(6), label:s.bPlay.textContent}; s.togglePlay(); r.after=s.bPlay.textContent; return r;})()")
        # ①-4：名前の下の ▶ スタートは、その波だけを動かす・止める
        res['m1s4_row_play'] = pg.evaluate("(()=>{var s=TEST.sims().m1s4; s.bReset.click(); s.rows.string.pb.click(); for(var i=0;i<20;i++) s.step(0.05); var r={n_btn:document.querySelectorAll('#m1s4 .rplay').length, string_tl:+s.rows.string.tl.toFixed(6), sound_tl:s.rows.sound.tl, row_label:s.rows.string.pb.textContent, all_label:s.bPlay.textContent}; s.rows.string.pb.click(); r.stopped=!s.playing; return r;})()")
        # ①-4：音の段（15 段）と光の段（12 段）。同じ組の中では音の図の縮尺は変わらない
        res['m1s4_stops'] = pg.evaluate("(()=>{var a=M4K.sound.f.stops, d=f=>m4Disp(m4Q({f:{sound:f},tc:15},'sound')).L; return {sound:a.length, light:M4_LAM.length, sameL:d(200)===d(440)&&d(440)===d(1000), diffL:d(1000)!==d(2000), lightL:m4Disp(m4Q({f:{light:M4_FL[0]},n:1},'light')).L===m4Disp(m4Q({f:{light:M4_FL[11]},n:2.42},'light')).L};})()")
        # ①-4：光の振動数と波長のスライダーが連動（λ = c/f）
        res['m1s4_light_link'] = pg.evaluate("(()=>{var s=TEST.sims().m1s4; s.lsl.set(400); return [Math.round(WAVE.c0/s.st.f.light*1e9), Math.round(s.rows.light.fsl.get()/1e12)];})()")
        # 全部の節を最後まで再生（エラーなし・最後は「▶ 最初から」）
        pg.evaluate("document.querySelector('#tabs .tab[data-mode=mode2]').click()"); pg.wait_for_timeout(300)
        # ②-3：だんだん張力を大きくしてはじく → 最後は v = 200 m/s
        res['m2s3_drive'] = pg.evaluate("(()=>{var s=TEST.sims().m2s3; s.extra.rp.click(); for(var i=0;i<600 && s.playing;i++) s.step(0.05); return [s.pmode, s.bPlay.textContent, document.querySelectorAll('#m2s3 .plk').length];})()")
        # ②-1・②-2：合成波は既定で出さず、チェックが光っている。②-2 の壁の右の波は、ボタンで出す
        res['m2_sum'] = pg.evaluate("(()=>{var a=TEST.sims().m2s1,b=TEST.sims().m2s2;var r=[a.showSum,a.extra.sum.classList.contains('fglow'),b.showSum,b.extra.sum.classList.contains('fglow'),b.showVirt];b.virtBtn.click();r.push(b.showVirt);b.virtBtn.click();return r;})()")
        # 章 ③：音（三要素は倍音の表のとおり・うなりは 2 つの音）、水柱で L₁・L₂ が見つかる
        pg.evaluate("document.querySelector('#tabs .tab[data-mode=mode3]').click()"); pg.wait_for_timeout(300)
        m3 = {}
        m3['s1_voice'] = pg.evaluate("(()=>{var s=TEST.sims().m3s1; s.extra.s_inst.click(); s.extra.i_clarinet.click(); s.spk.click(); var r=[AUDIO.owner(), AUDIO._state()&&AUDIO._state().n, m3Parts(s,440).map(p=>p[0]).join(',')]; s.spk.click(); s.extra.s_fork.click(); return r;})()")
        m3['s2_two'] = pg.evaluate("(()=>{var s=TEST.sims().m3s2; s.spk.click(); var r=[AUDIO.owner(), AUDIO._state()&&AUDIO._state().n]; s.spk.click(); return r;})()")
        m3['s5_water'] = pg.evaluate("(()=>{var s=TEST.sims().m3s5; m3s5Lower(s); for(var i=0;i<400 && s.lowering;i++) s.step(0.05); var r=s.wl.found.map(x=>+(x*100).toFixed(1)); s.togglePlay(); return [r, +(m3s5Q(s).L1*100).toFixed(1), +(m3s5Q(s).L2*100).toFixed(1)];})()")
        m3['s4_pluck'] = pg.evaluate("(()=>{var s=TEST.sims().m3s4; m3s4Pluck(s); var r=[AUDIO.owner(), Math.round(m3s4Q(s).f1), s.playing]; s.v.l=0.3; var f2=Math.round(m3s4Q(s).f1); s.togglePlay(); AUDIO.stop(); s.toDefaults(); r.push(f2); return r;})()")
        m3['s3_wide'] = pg.evaluate("(()=>{var s=TEST.sims().m3s3; s.extra.mL.click(); var a=document.getElementById('m3s3').classList.contains('wide1'); s.extra.mR.click(); var b=document.getElementById('m3s3').classList.contains('wide1'); var e=[s.mouthAB, s.exact]; s.extra.mL.click(); return [a,b,e];})()")
        m3['s3_closed_modes'] = pg.evaluate("(()=>{var s=TEST.sims().m3s3; s.extra.n_closed.click(); var r=[0,1,2,3].map(i=>s.extra['m'+i].textContent); s.extra.n_string.click(); return r;})()")
        m3['s2_default'] = pg.evaluate("[TEST.sims().m3s2.v.f1, TEST.sims().m3s2.v.f2]")
        m3['s3_rows'] = pg.evaluate("(()=>{var s=TEST.sims().m3s3; s.extra.n_string.click(); s.extra.mL.click(); var vis=s.rowSpk.filter(b=>b.style.display!=='none').length; s.rowSpk[3].click(); var r=[vis, AUDIO.owner(), AUDIO._state()&&AUDIO._state().n, s.Rdyn.innerHTML.length, s.scope.box.style.display]; s.rowSpk[3].click(); return r;})()")
        # 一時停止で音も止まり、▶ で鳴り直す／③-2 下の画面の範囲を選ぶ／③-3 振動数のスライダー
        m3['pause_sound'] = pg.evaluate("(()=>{var s=TEST.sims().m3s1; s.spk.click(); var a=[AUDIO.owner(), s.playing]; s.togglePlay(); a.push(AUDIO.owner()); s.togglePlay(); a.push(AUDIO.owner()); s.spk.click(); s.togglePlay(); return a;})()")
        m3['s2_scope'] = pg.evaluate("(()=>{var s=TEST.sims().m3s2; s.toDefaults(); s.draw(); return [s.scope.cv.height>0, s.scope.cap.textContent.indexOf('41')>=0, document.querySelectorAll('#m3s2 .brow').length, !!s.bRows[2].sc.cv.height];})()")
        # 章 ④：音符・鍵盤をクリックすると鳴る（平均律 C5 = 523.25 Hz）
        pg.evaluate("document.querySelector('#tabs .tab[data-mode=mode4]').click()"); pg.wait_for_timeout(400)
        res['m4'] = pg.evaluate("(()=>{var S=TEST.sims(), r={}; r.c5=+MUS.fET(72).toFixed(2); var a=S.m4s1; a._h4[5].act(); r.s1=[AUDIO.owner(), a.nm]; var b=S.m4s2; b._h4[1].act(); r.s2=[AUDIO.owner(), b.n]; var d=S.m4s4; d._h4[0].act(); r.s4=[AUDIO.owner(), d.km]; var e=S.m4s5; e.extra.te.click(); r.s5=+m4s5Main(m4s5Q(e), m4s5Pairs(m4s5Q(e))).d.toFixed(2); e.extra.tj.click(); r.s5j=+m4s5Main(m4s5Q(e), m4s5Pairs(m4s5Q(e))).d.toFixed(2); r.j4=+m4Just(64).toFixed(2); AUDIO.stop(); r.n=['m4s1','m4s2','m4s3','m4s4','m4s5'].filter(k=>S[k]).length; r.snd=['m4s1','m4s2','m4s3','m4s4','m4s5'].map(k=>S[k].snd); S.m4s1.spk.click(); a._h4[2].act(); r.off=[AUDIO.owner(), S.m4s1.snd]; S.m4s1.spk.click(); AUDIO.stop(); return r;})()")
        pg.evaluate("document.querySelector('#tabs .tab[data-mode=mode3]').click()"); pg.wait_for_timeout(300)
        m3['s3_drive'] = pg.evaluate("(()=>{var s=TEST.sims().m3s3; s.extra.n_string.click(); s.extra.mR.click(); s.fdr=2; m3s3DrvSync(s); var q=m3s3Q(s); var r=[Math.round(q.fd), s.drv.style.display, [].filter.call(s.drvChips.children,b=>b.classList.contains('on')).length]; s.extra.mL.click(); return r;})()")
        m3['timebar_hidden'] = pg.evaluate("['m3s1','m3s2'].map(k=>TEST.sims()[k].L.querySelector('.playbar .trow').style.display)")
        res['m3'] = m3
        # ①-2：t = 0 から原点が波源：★（点 E）は波が届くまで 0。①-3：作図中は「次へ」が光る。②-1：形は左右共通・腹節は合成波と一緒に ON
        res['r6'] = pg.evaluate("(()=>{var a=TEST.sims().m1s2; a.extra.fo.click(); var q=m1s2Q(a), xE=5*q.lam/4, r={fromO_before:m1s2Y(a,xE,xE/q.v*0.99), fromO_after:Math.abs(m1s2Y(a,xE,xE/q.v+0.1))>1e-6}; a.extra.fo.click(); var b=TEST.sims().m1s3; m1s3StepGo(b,1,'fwd'); r.next_glow=b.stepBtns.bn.classList.contains('glow'); m1s3StepGo(b,4,'fwd'); r.next_glow_last=b.stepBtns.bn.classList.contains('glow'); m1s3StepGo(b,0); var c=TEST.sims().m2s1; r.node0=c.showNodes; c.extra.S_pulse.click(); r.both=[c.shL,c.shR]; c.extra.S_sin.click(); c.extra.sum.click(); r.node1=c.showNodes; c.extra.sum.click(); return r;})()")
        # ②-2：作図の手順 4 段
        res['m2s2_steps'] = pg.evaluate("(()=>{var s=TEST.sims().m2s2; document.querySelector('#m2s2 .stepgo').click(); var a=[s.stp]; for(var i=0;i<3;i++){ document.querySelectorAll('#m2s2 .stepbar button')[1].click(); a.push(s.stp);} document.querySelector('#m2s2 .stepgo').click(); return a;})()")
        # ②-1：変位を表示／②-2：既定は連続波・変位を表示は下の段
        res['m2_disp'] = pg.evaluate("(()=>{document.querySelector('#tabs .tab[data-mode=mode2]').click(); var a=TEST.sims().m2s1, b=TEST.sims().m2s2; a.extra.disp.click(); var on=a.showDisp; a.extra.disp.click(); return {m2s1_disp:on, m2s2_sh:b.sh, m2s2_lbl:b.extra.S_sin.textContent, disp_below:b.extra.disp.getBoundingClientRect().top>b.extra.fix.getBoundingClientRect().top+5};})()")
        ends = {}
        for sid in ['m1s1', 'm1s2', 'm1s3', 'm1s4', 'm2s1', 'm2s2', 'm2s3', 'm3s1', 'm3s2', 'm3s3']:
            ends[sid] = pg.evaluate(f"(()=>{{var s=TEST.sims().{sid}; if(s.toDefaults) s.toDefaults(); else {{s.t=0;s.ended=false;}} s.playing=true; for(var i=0;i<4000 && s.playing;i++) s.step(0.05); return s.bPlay.textContent;}})()")
        res['play_to_end'] = ends
        res['errors'] = errs[:]
        res['external'] = ext[:]
        pg.close()
        # 横スクロールなし（6 つの幅）・節ごと
        wide = {}
        for w in [320, 360, 390, 768, 1024, 1440]:
            pg2 = b.new_page(viewport={'width': w, 'height': 800})
            pg2.on('pageerror', lambda e: errs.append(str(e)))
            pg2.goto(PAGE + '#1-1'); pg2.wait_for_timeout(500)
            over = []
            for h in ['#1-1', '#1-2', '#1-3', '#1-4', '#2-1', '#2-2', '#2-3', '#3-1', '#3-2', '#3-3', '#3-4', '#3-5', '#4-1', '#4-2', '#4-3', '#4-4', '#4-5']:
                pg2.evaluate(f"location.hash='{h}'"); pg2.wait_for_timeout(250)
                sw = pg2.evaluate("document.documentElement.scrollWidth - innerWidth")
                if sw > 0: over.append([h, sw])
            wide[str(w)] = over
            pg2.close()
        res['hscroll'] = wide
        res['errors_all'] = errs[:]
        b.close()
    res['footer'] = {'goatcounter': 'physics-chiba.goatcounter.com' in HTML, 'sg_glow': 'sg-glow' in HTML, 'bPlay_in_html': True}
    return res


if __name__ == '__main__':
    n = 2 if '--twice' in sys.argv else 1
    outs = [run_once() for _ in range(n)]
    js = [json.dumps(o, ensure_ascii=False, sort_keys=True) for o in outs]
    print(json.dumps(outs[0], ensure_ascii=False, indent=1))
    if n == 2:
        print('IDENTICAL' if js[0] == js[1] else 'DIFFERENT')
        if js[0] != js[1]:
            a, b = outs
            for k in a:
                if json.dumps(a[k], sort_keys=True) != json.dumps(b.get(k), sort_keys=True): print('diff key', k, a[k], b.get(k))
