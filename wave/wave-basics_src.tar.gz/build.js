/* build.js … src/ を 1 枚の HTML（out/wave-basics.html）に連結する。KaTeX は vendor/ から埋め込む（完全オフライン） */
'use strict';
const fs = require('fs'), path = require('path');
const S = f => fs.readFileSync(path.join(__dirname, 'src', f), 'utf8');
const V = f => fs.readFileSync(path.join(__dirname, 'vendor', f), 'utf8');
const files = fs.readdirSync(path.join(__dirname, 'src')).sort();
const css = files.filter(f => f.endsWith('.css'));
const js = files.filter(f => f.endsWith('.js'));
let h = S('00_head.html').replace(/\s*$/, '\n');
h += V('katex_css.html').replace(/\s*$/, '\n');
h += '<style>\n' + css.map(f => S(f)).join('\n') + '\n</style>\n';
h += S('20_body.html');
h += V('katex_js.html').replace(/\s*$/, '\n');
h += '<script>\n' + js.map(f => S(f)).join('\n') + '\n</script>\n';
h += S('99_footer.html').replace(/\s*$/, '\n');
h += '\n</body>\n</html>\n';
fs.writeFileSync(path.join(__dirname, 'out', 'wave-basics.html'), h);
console.log('built', (h.length / 1024).toFixed(0) + ' KB', css.length + ' css', js.length + ' js');
