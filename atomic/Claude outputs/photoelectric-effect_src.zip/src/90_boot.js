/* =========================================================================
   90_boot.js … 自動テスト用の窓口（window.TEST）と検算 check()
   ========================================================================= */
'use strict';
function check() {
  var out = {}, rel = function (a, b) { return Math.abs(a - b) / Math.max(1e-12, Math.abs(b)); };
  /* hν = h × ν（係数 0.663 は 6.63×10⁻³⁴ × 10¹⁴ ÷ 10⁻¹⁹） */
  var e1 = 0; for (var nu = PE.NU_MIN; nu <= PE.NU_MAX + 1e-9; nu += 0.37) e1 = Math.max(e1, rel(photonE(nu) * 1e-19, PE.h * nu * 1e14), rel(nuOfE(photonE(nu)), nu));
  out.hv_eq_h_nu_rel_err = +e1.toExponential(2);
  /* ν₀ = W/h の前後で切りかわる。ν₀ ちょうどで K₀ = 0 */
  out.metals = PE.METALS.map(function (m) {
    var n0 = nu0Of(m.k);
    return { k: m.k, W_J: +(workW(m.k) * 1e-19).toExponential(3), nu0_1e14: +n0.toFixed(3),
      below_emits: emits(n0 - 0.01, m.k), above_emits: emits(n0 + 0.01, m.k), K0_at_nu0: K0Of(n0, m.k), hv_minus_W_at_nu0: +hvMinusW(n0, m.k).toExponential(1) };
  });
  /* K₀–ν：傾きが h（×10⁻¹⁹ J ÷ 10¹⁴ Hz = 0.663）で 3 本平行。ν = 0 で −W */
  out.slopes = PE.METALS.map(function (m) { var a = nu0Of(m.k) + 1, b = a + 5; return +((K0Of(b, m.k) - K0Of(a, m.k)) / (b - a)).toFixed(6); });
  out.slope_expected = +PE.H.toFixed(6);
  out.intercepts_minus_W = PE.METALS.map(function (m) { return +(hvMinusW(0, m.k) + workW(m.k)).toExponential(1); });
  /* V₀ = K₀/e */
  var e2 = 0; PE.METALS.forEach(function (m) { for (var nu = PE.NU_MIN; nu <= PE.NU_MAX; nu += 0.5) { var K = K0Of(nu, m.k); if (K > 0) e2 = Math.max(e2, Math.abs(V0Of(nu, m.k) * PE.e - K * 1e-19) / (K * 1e-19)); } });
  out.V0_eq_K0_over_e_rel_err = +e2.toExponential(2);
  /* 光の強さを変えても K₀・V₀ は変わらない。飽和電流だけが比例して変わる */
  var same = true, prop = 0;
  PE.METALS.forEach(function (m) { [7, 10, 14].forEach(function (nu) {
    var K = [10, 50, 100].map(function () { return K0Of(nu, m.k); });
    if (K[0] !== K[1] || K[1] !== K[2]) same = false;
    if (emits(nu, m.k)) { var I1 = currentI(5, nu, m.k, 20, 'dist'), I2 = currentI(5, nu, m.k, 80, 'dist'); prop = Math.max(prop, Math.abs(I2 / I1 - 4)); }
  }); });
  out.K0_V0_indep_of_intensity = same; out.Isat_ratio_err = +prop.toExponential(2);
  /* 光電流：−V₀ で 0、それより低い電位でも 0。−V₀ より少し高いと正 */
  var zeroOK = true;
  PE.METALS.forEach(function (m) { [7, 10, 14].forEach(function (nu) { ['dist', 'max'].forEach(function (md) {
    if (!emits(nu, m.k)) { if (currentI(1, nu, m.k, 50, md) !== 0) zeroOK = false; return; }
    var V0 = V0Of(nu, m.k);
    if (currentI(-V0, nu, m.k, 50, md) > 1e-9 || currentI(-V0 - 0.2, nu, m.k, 50, md) !== 0 || !(currentI(-V0 + 0.05, nu, m.k, 50, md) > 0)) zeroOK = false;
  }); }); });
  out.I_zero_at_minus_V0 = zeroOK;
  /* 光電流–V：正の側で飽和電流に近づく（+5 V で 99 % 以上）。分布のとき −V₀ の両側でなめらか（V = 0 で傾きがつながる） */
  var sat = 1, sm = 0;
  PE.METALS.forEach(function (m) { [8, 12, 16].forEach(function (nu) { if (!emits(nu, m.k)) return;
    sat = Math.min(sat, currentI(5, nu, m.k, 50, 'dist') / IsatOf(nu, m.k, 50));
    var h = 1e-4, dl = (currentI(0, nu, m.k, 50, 'dist') - currentI(-h, nu, m.k, 50, 'dist')) / h, dr = (currentI(h, nu, m.k, 50, 'dist') - currentI(0, nu, m.k, 50, 'dist')) / h;
    if (V0Of(nu, m.k) > 0.3) sm = Math.max(sm, Math.abs(dl - dr) / Math.max(dl, dr)); }); });
  out.I_at_plus5_over_Isat_min = +sat.toFixed(4); out.slope_jump_at_0_rel = +sm.toExponential(2);
  return out;
}
/* 図の上の動きを、決まった刻みで進める（テスト用。画面の再生とは別） */
function runFor(id, sec, dt) {
  var s = SIM_BY_ID[id]; dt = dt || 1 / 60; if (!s.g) s.draw();
  for (var t = 0; t < sec; t += dt) s.def.beforeStep(s, 0, dt);
  s.draw(); return s.P;
}
window.TEST = {
  check: check, runFor: runFor,
  sim: function (id) { return SIM_BY_ID[id]; },
  sims: function () { return SIMS.map(function (s) { return s.def.id; }); }
};
