/* =========================================================================
   45_sim.js … セクション 1 つぶんの「図と操作」のしくみ（どのモードでも共通）
   左の列：▶ スタート／スロー／↺ リセット／全てデフォルトに戻す／1 秒ごとのストロボ
           → 時間バー → そのセクションのスライダー（ラベル → バー → − → 数値 → ＋）
           → 図（canvas）→ 式の箱 → ひとこと
   右の列：説明と公式（def.right が書く）
   状態は sim のオブジェクトにまとめ、draw() はそれだけから描く。
   ========================================================================= */
'use strict';
var SIMS = [];
var MSTATE = {};                         /* モードごとの共有の状態（力を表示・観測者） */
function modeState(id) { return MSTATE[id] || (MSTATE[id] = { showF: true, rot: false }); }

/* φ は縦棒が貫く形（ϕ・\phi の形）にそろえる。\varphi と書いても \phi の形で表示。図（canvas）も 'ϕ'（2026-10-16 千葉さん） */
var KTX_MAC = { '\\varphi': '\\phi' };
/* $…$ を KaTeX にする（文中の数式） */
function mathify(html) {
  if (!window.katex) return html;
  return String(html).replace(/\$\$([\s\S]+?)\$\$|\$([^$]+?)\$/g, function (m, d, i) {
    try { return katex.renderToString(d || i, { displayMode: !!d, throwOnError: false, macros: KTX_MAC }); } catch (e) { return m; }
  });
}
function tex(s, disp) { try { return katex.renderToString(s, { displayMode: !!disp, throwOnError: false, macros: KTX_MAC }); } catch (e) { return s; } }
function fmt(x, d) { if (!isFinite(x)) return '—'; var s = x.toFixed(d); return (s === '-0' || /^-0\.0*$/.test(s)) ? s.slice(1) : s; }
function el(tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; }

function Sim(def, hostL, hostR) {
  this.def = def; this.L = hostL; this.R = hostR;
  this.mode = def.mode;
  this.ms = modeState(def.mode);
  this.v = {}; this.t = 0; this.playing = false; this.ended = false;
  this.base = def.baseRate || 1; this.slow = false; this.rate = this.base;   /* def.baseRate：ふだんの再生の速さ（モード3 は 1/3）。スローはその 0.3 倍 */
  this.strobe = false; this.sel = null; this.hits = [];
  this.reset0();
  this.build();
  this.locks = Object.assign({}, def.lockDefault || {}); this.syncLocks();
  if (def.afterBuild) def.afterBuild(this);
  SIMS.push(this);
  this.resize(); this.draw(); this.renderRight();
  var self0 = this; requestAnimationFrame(function () { self0.align(); });
  /* 画面から消えたら、動いているアニメは止める（いくつも動くと重くなる。2026-10-16 千葉さん） */
  if (window.IntersectionObserver) {
    new IntersectionObserver(function (es) { es.forEach(function (e) { if (!e.isIntersecting && self0.playing) { self0.playing = false; self0.syncPlayLabel(); } }); }).observe(this.cw);
  }
}
/* アニメの上のはしと、x–t グラフの上のはしを同じ高さに（2026-10-16 千葉さん。モード② 以降も全部）。
   グラフが右の列にあるときだけ。低い方の上にすきまを入れてそろえる（2 列のときだけ） */
Sim.prototype.align = function () {
  if (!this.gHost || this.gHost.parentNode !== this.R || !this.cw) return;
  var gb = [].filter.call(this.gHost.querySelectorAll('.gbox'), function (e) { return !e.hidden && e.offsetParent; })[0]; if (!gb) return;   /* 見えている最初のグラフ（たたんだグラフは測れない） */
  this.gHost.style.marginTop = ''; this.cw.style.marginTop = '';
  if (!this.L.offsetParent || window.innerWidth <= 880 || document.body.classList.contains('hideeq')) return;
  var self = this, dif = function () { return self.cw.getBoundingClientRect().top - gb.getBoundingClientRect().top; };
  var d = Math.round(dif()), tgt = d > 0 ? this.gHost : this.cw, m = Math.abs(d);
  if (!m) return;
  for (var i = 0; i < 3 && Math.abs(d) >= 1; i++) {        /* マージンの相殺（親の余白と重なる）があるので、測り直して合わせる */
    tgt.style.marginTop = m + 'px'; d = dif(); m = Math.max(0, m + (tgt === this.cw ? -d : d));
  }
};
function alignAll() { SIMS.forEach(function (s) { if (s.align) s.align(); }); }
Sim.prototype.reset0 = function () {
  var d = this.def, self = this;
  if (d.showFBtn) this.fmode = d.fDefault === undefined ? 'all' : d.fDefault;   /* null：最初はどちらも OFF（モード②） */
  this.hideVec = false; this.focus = null;
  (d.vars || []).forEach(function (vd) { self.v[vd.k] = vd.def; });
  if (d.init) d.init(this);
  this.t = 0; this.ended = false;
};
Sim.prototype.syncFBtns = function () {
  var self = this, glow = !!this.def.fGlow && !this._fTouched;      /* d.fGlow：押されるまで力のチェックを光らせる（モード②） */
  [this.extra.fNet, this.extra.fAll].forEach(function (b) { if (b) b.classList.toggle('fglow', glow); });
  [['net', this.extra.fNet], ['all', this.extra.fAll]].forEach(function (p) { var b = p[1]; if (!b) return; var on = self.fmode === p[0]; b.classList.toggle('on', on); b.setAttribute('aria-pressed', on ? 'true' : 'false'); });
};
/* 力の表示：fAll(s)＝全ての力を個別に、fNet(s)＝合力だけ */
function fAll(s) { return s.fmode === 'all'; }
function fNet(s) { return s.fmode === 'net'; }
Sim.prototype.tEnd = function () { return this.def.tEnd ? this.def.tEnd(this) : 10; };

Sim.prototype.build = function () {
  var self = this, d = this.def, L = this.L;
  var ctr = el('div', 'ctrls'); L.appendChild(ctr);
  var row1 = el('div', 'row1'); ctr.appendChild(row1);
  var btns = el('div', 'btns'); row1.appendChild(btns);
  this.bPlay = el('button', 'b play', '▶ スタート'); this.bPlay.type = 'button';
  if (!document.getElementById('bPlay')) this.bPlay.id = 'bPlay';
  this.bSlow = el('button', 'b', '🐢 スロー'); this.bSlow.type = 'button';
  this.bStep = el('button', 'b stepb two', 'コマ<br>送り'); this.bStep.type = 'button'; this.bStep.title = '押すごとに 1/16 周期ずつ進める';   /* 2026-10-16 千葉さん */
  this.bReset = el('button', 'b gapL', '↺ リセット');                 /* スロー｜リセット、デフォルト｜ストロボ の間はすきまをあける */ this.bReset.type = 'button';
  this.bDef = el('button', 'b resetall', 'すべて最初の<br>設定に戻す'); this.bDef.type = 'button';      /* rigid-body-dynamics.html と同じ見た目（赤字・白地・2 行・小さめ。2026-10-05 千葉さん） */
  this.bStrobe = el('button', 'b strobe two gapL','1 秒ごとの<br>ストロボ'); this.bStrobe.type = 'button'; this.bStrobe.setAttribute('aria-pressed', 'false');
  (d.noStep ? [this.bPlay, this.bSlow, this.bReset] : [this.bPlay, this.bStep, this.bSlow, this.bReset]).forEach(function (b) { btns.appendChild(b); });   /* 「すべて最初の設定に戻す」は観測者の切りかえのとなり（下で row1b へ）。d.noStep：コマ送りを出さない（光電効果） */
  if (d.strobe !== false) btns.appendChild(this.bStrobe);
  (d.buttons || []).forEach(function () { });
  this.extra = {};
  /* そのセクションだけのボタンは 2 段目に。bd.seg が同じものは「対」のボタン（左右つながった形）にまとめる */
  var row1b = null, segs = {};
  var cvBtns = [], rowTop = null, row1x = [], varBtns = [], playBtns = [], aftPlay = [];             /* bd.inCanvas：図（方眼紙）の左上に置くボタン／row1x：観測者の切りかえのとなりへ */
  (d.buttons || []).forEach(function (bd) {
    var b = el('button', 'b ' + (bd.cls || ''), bd.label); b.type = 'button';
    b.addEventListener('click', function () { bd.onClick(self, b); });
    self.extra[bd.k] = b;
    if (bd.inCanvas) { cvBtns.push(b); return; }
    if (bd.row1) { row1x.push(b); return; }                 /* bd.row1：観測者の切りかえのとなり（モード3 の「離れる瞬間」など。2026-10-05 千葉さん） */
    if (bd.inVar) { varBtns.push(b); return; }
    if (bd.inPlay) { playBtns.push(b); return; }
    if (bd.afterPlay) { aftPlay.push(b); return; }          /* bd.afterPlay：▶ スタートのすぐ右（①-1 の「ライトを点灯」） */
    /* bd.inPlay：時間バーの右（「⏱ 離れる瞬間をスローで」など）／bd.inVar：1 つめのスライダーの右 */
    if (bd.top) {                                          /* bd.top：スライダーの上に置くボタン（2-6 の電荷の正負など） */
      if (!rowTop) { rowTop = el('div', 'rowtop'); if (bd.topLabel) rowTop.appendChild(el('span', 'rtl', bd.topLabel)); }
      rowTop.appendChild(b); return;
    }
    if (!row1b) { row1b = el('div', 'row1 row1b'); }
    if (bd.seg) {
      if (!segs[bd.seg]) { segs[bd.seg] = el('div', 'seg'); segs[bd.seg].setAttribute('role', 'group'); if (bd.segLabel) segs[bd.seg].setAttribute('aria-label', bd.segLabel); row1b.appendChild(segs[bd.seg]); }
      segs[bd.seg].appendChild(b);
    } else row1b.appendChild(b);
  });
  /* d.trailBtn：「軌跡を表示」（既定は ON。1-1 と 2-6 だけ） */
  this.trailOn = !!d.trailBtn;
  if (d.trailBtn) {
    if (!row1b) row1b = el('div', 'row1 row1b');
    var tb0 = el('button', 'b chkb on', '軌跡を表示'); tb0.type = 'button'; tb0.setAttribute('aria-pressed', 'true');
    tb0.addEventListener('click', function () { self.trailOn = !self.trailOn; tb0.classList.toggle('on', self.trailOn); tb0.setAttribute('aria-pressed', self.trailOn ? 'true' : 'false'); self.draw(); });
    row1b.appendChild(tb0); this.extra.trail = tb0;
  }
  /* d.showFBtn：力の表示は 2 つのチェック「合力のみを表示」「全ての力を個別表示」。片方を ON にすると、もう片方は OFF（両方 OFF もできる）。
     既定は d.fDefault（'net'：合力のみ／'all'：個別）。セクションごとに持つ（2026-10-16 千葉さん） */
  if (d.showFBtn) {
    if (!row1b) row1b = el('div', 'row1 row1b');
    var mkF = function (key, txt) {
      var b = el('button', 'b chkb', txt); b.type = 'button';
      b.addEventListener('click', function () { self.fmode = (self.fmode === key ? null : key); self._fTouched = true; self.syncFBtns(); self.draw(); });
      row1b.appendChild(b); return b;
    };
    this.extra.fNet = mkF('net', d.fNetLabel || '合力のみを表示');   /* d.fNetLabel：②-6 は「復元力のみ表示」 */ this.extra.fAll = mkF('all', '全ての力を個別表示');
    this.syncFBtns();
  }
  /* d.vecBtn：アニメの x・v・a の矢印を消すチェック（v だけのシムは「v を消す」。2026-10-16 千葉さん） */
  if (d.vecBtn) {
    if (!row1b) row1b = el('div', 'row1 row1b');
    var vb0 = el('button', 'b chkb', d.vecBtn); vb0.type = 'button'; vb0.setAttribute('aria-pressed', 'false');
    vb0.addEventListener('click', function () { self.hideVec = !self.hideVec; vb0.classList.toggle('on', self.hideVec); vb0.setAttribute('aria-pressed', self.hideVec ? 'true' : 'false'); self.draw(); });
    row1b.appendChild(vb0); this.extra.vec = vb0;
  }
  /* 「すべて最初の設定に戻す」と「離れる瞬間」などは、観測者の切りかえ（対のボタン）のすぐ右。なければ 2 段目の最後 */
  if (!row1b) row1b = el('div', 'row1 row1b');
  aftPlay.forEach(function (b) { self.bPlay.insertAdjacentElement('afterend', b); });
  if (d.noDef) this.bDef.hidden = true;                    /* d.noDef：「すべて最初の設定に戻す」を出さない（①-1） */
  var segEl = row1b.querySelector('.seg'), after = segEl;
  /* 観測者の切りかえ（2 行）→ すべて最初の設定に戻す → チェックボックス（全部）→ 他のボタン、を 1 行に（2026-10-11 千葉さん） */
  var chks = [].slice.call(row1b.querySelectorAll(':scope > button.chkb'));
  [this.bDef].concat(row1x, chks).forEach(function (b) {
    if (after) { after.insertAdjacentElement('afterend', b); after = b; } else row1b.appendChild(b);
  });
  this.row1b = row1b;
  if (d.noDefBtn) this.bDef.hidden = true;                 /* d.noDefBtn：「すべて最初の設定に戻す」を出さない（①-1） */
  this.bPlay.addEventListener('click', function () { self.togglePlay(); });
  this.bSlow.addEventListener('click', function () { self.setSlow(!self.slow); });
  this.bStep.addEventListener('click', function () { self.stepFrame(); });
  this.bReset.addEventListener('click', function () { self.resetT(); });
  this.bDef.addEventListener('click', function () { self.toDefaults(); });
  this.bStrobe.addEventListener('click', function () { self.strobe = !self.strobe; self.bStrobe.classList.toggle('on', self.strobe); self.bStrobe.setAttribute('aria-pressed', self.strobe ? 'true' : 'false'); self.draw(); });

  if (rowTop) ctr.appendChild(rowTop);
  var sliders = el('div', 'row2 sliders'); ctr.appendChild(sliders);
  /* 時間バー（少し短く）＋ その右に def.tInfo（何回転したか など） */
  var trow = el('div', 'trow');
  var tb = el('div', 'tbox'); trow.appendChild(tb);
  this.tinfo = el('span', 'tinfo', ''); if (d.tInfo || d.tInfoNum) trow.appendChild(this.tinfo);
  if (d.tInfoNum) { this.tinfo.innerHTML = '<span class="tpre"></span><span class="roll"><span class="rin"><b class="r0">0</b><b class="r1">0</b></span></span><span class="tunit"></span>'; this._roll = 0; }
  tb.appendChild(el('span', 'vl', '時間 ' + tex('t')));
  this.tsl = el('input'); this.tsl.type = 'range'; this.tsl.min = '0'; this.tsl.step = '0.01'; this.tsl.value = '0';
  tb.appendChild(this.tsl);
  this.tval = el('span', 'vv', '0.00 s'); tb.appendChild(this.tval);
  this.tsl.addEventListener('input', function () { self.playing = false; self.setT(parseFloat(self.tsl.value)); self.syncPlayLabel(); });
  /* スライダー。vd.stops があれば「とびとびの値」（目盛りの位置＝番号）。def.lockable なら変数名の右に鍵。
     def.varCols があれば 2 列（[[左の列], [右の列]]）＋ def.varWide（2 列をまたぐ行） */
  this.sl = {};
  this.locks = {};
  if (d.vars && d.vars.length) {
    var vb = el('div', 'varbox' + (d.varCols ? ' cols2' : '')); sliders.appendChild(vb); this.varbox = vb;
    var holder = {};
    if (d.varCols) {
      d.varCols.forEach(function (col, ci) { var c = el('div', 'vcol vcol' + ci); vb.appendChild(c); if (d.varColNote && d.varColNote[ci]) c.appendChild(el('p', 'vcolnote', mathify(d.varColNote[ci]))); col.forEach(function (k) { holder[k] = c; }); });
      (d.varWide || []).forEach(function (k) { holder[k] = vb; });
    }
    var VD = {}; d.vars.forEach(function (vd) { VD[vd.k] = vd; });
    var order = d.varCols ? [].concat.apply([], d.varCols).concat(d.varWide || []) : d.vars.map(function (vd) { return vd.k; });
    order.forEach(function (k) {
      var vd = VD[k], two = !!d.varCols;
      var row = el('div', 'vrow' + (two ? ' cell' : '') + ((d.varWide || []).indexOf(k) >= 0 ? ' wide' : '') + (vd.cls ? ' ' + vd.cls : '')); row.dataset.k = vd.k;
      var head = two ? el('div', 'vhead') : row;
      var lab = el('span', 'vl', mathify(vd.label)); head.appendChild(lab);
      var lk = null;
      if (d.lockable && !vd.noLock) {                   /* vd.noLock：鍵をつけない量（1-1 の質量 m） */
        lk = el('button', 'lockbtn'); lk.type = 'button';
        lk.addEventListener('click', function () {
          var on = !self.locks[vd.k], grp = (d.lockGroups || []).filter(function (g) { return g.indexOf(vd.k) >= 0; })[0] || [vd.k];
          grp.forEach(function (q) { self.locks[q] = on; });      /* 同じ組（ω・T・n）は鍵を共有 */
          self.syncLocks();
        });
        head.appendChild(lk);
      }
      var inp = el('input'); inp.type = 'range';
      if (vd.btnOnly) inp.hidden = true;                 /* vd.btnOnly：スライダーを出さず「小さく」「大きく」のボタンだけ（①-2。2026-10 千葉さん） */
      if (vd.stops && vd.prop) { inp.min = String(vd.stops[0]); inp.max = String(vd.stops[vd.stops.length - 1]); inp.step = 'any'; }   /* vd.prop：とびとびの値を、値に比例した位置に置く（等間隔にしない） */
      else if (vd.stops) { inp.min = '0'; inp.max = String(vd.stops.length - 1); inp.step = '1'; }
      else { inp.min = String(vd.min); inp.max = String(vd.max); inp.step = String(vd.allow ? 0.01 : vd.step); }   /* allow の端（√2gr など）でつまみがきちんと止まるよう細かく */
      inp.setAttribute('aria-label', vd.aria || vd.k);
      var slot = inp, mk = null;                         /* vd.mark：スライダーの中に小さな目印（2-1 の ω₀ など） */
      if (vd.mark || vd.stops) { slot = el('span', 'rw'); slot.appendChild(inp); }      /* 目盛りの数字も、スライダーの線と同じ箱の中に置く（つまみの位置とそろえるため） */
      if (vd.mark) mk = [];                              /* 目印は複数でもよい（配列を返す） */
      var dn = el('button', 'tiny nudge', '−'); dn.type = 'button'; dn.title = '1 目盛り小さく';
      var val = el('span', 'vv', ''); var up = el('button', 'tiny nudge', '＋'); up.type = 'button'; up.title = '1 目盛り大きく';
      var segW = null;
      if (vd.seg) {                                      /* vd.seg：とびとびの値を、スライダーではなくボタンでえらぶ（初期位相 φ の 5 択。2026-10-16 千葉さん） */
        inp.hidden = true; segW = el('div', 'vseg'); segW.setAttribute('role', 'group'); segW.setAttribute('aria-label', vd.aria || vd.k);
        vd.stops.forEach(function (q, i) {
          var nt = (vd.stopNotes || []).filter(function (n) { return n.i === i; })[0];
          var cell = el('div', 'vsegc'), bb = el('button', 'b vsegb', mathify(vd.stopLabels[i])); bb.type = 'button';
          bb.addEventListener('click', function () { set(vd.stops[i]); });
          cell.appendChild(bb); if (nt) cell.appendChild(el('span', 'vsegn', mathify(nt.html)));
          segW.appendChild(cell);
        });
        row.classList.add('segrow');
        if (two) { head.appendChild(el('span', 'vsp')); head.appendChild(val); row.appendChild(head); } else { row.appendChild(val); }
        row.appendChild(segW);
      } else if (vd.btnOnly) {                                  /* 「小さく」「大きく」：文字のボタン（値は 2 つのボタンの間） */
        dn.className = 'b szb'; dn.textContent = '小さく'; dn.title = '1 段小さくする';
        up.className = 'b szb'; up.textContent = '大きく'; up.title = '1 段大きくする';
        row.classList.add('btnonly');
        if (two) row.appendChild(head);
        row.appendChild(dn); row.appendChild(val); row.appendChild(up);
      } else if (two) {
        head.appendChild(el('span', 'vsp')); head.appendChild(val);
        var bar = el('div', 'vbar'); bar.appendChild(dn); bar.appendChild(slot); bar.appendChild(up);
        row.appendChild(head); row.appendChild(bar);
      } else { row.appendChild(slot); row.appendChild(dn); row.appendChild(val); row.appendChild(up); }
      if (vd.stops && vd.stopLabels && !vd.seg) {                  /* 目盛りの数字：つまみの中心と同じ位置（つまみの幅 18px ぶん内がわ）に、数字のまん中をそろえる。単位は数字の右に */
        var tk = el('div', 'stoptk'), n1 = vd.stops.length - 1, s0 = vd.stops[0], s1 = vd.stops[n1];
        vd.stopLabels.forEach(function (t, i) {
          var f = vd.prop ? (vd.stops[i] - s0) / (s1 - s0) : i / n1, m = /^(\S+)\s+(.+)$/.exec(t);
          var tw = vd.meter ? 9 : 18, sp = el('span', '', mathify(m ? m[1] : t)); sp.style.left = 'calc(' + tw / 2 + 'px + (100% - ' + tw + 'px) * ' + f.toFixed(4) + ')';   /* メーターはつまみが 9px */
          if (m) sp.appendChild(el('i', 'tku', mathify(m[2])));
          tk.appendChild(sp);
        });
        slot.appendChild(tk); row.classList.add('hasstops');
        if (vd.stopNotes) {                               /* 目盛りの数字のさらに下の注記（初期位相 φ の「端で静かに放す」など） */
          var tn = el('div', 'stoptk stopnote');
          vd.stopNotes.forEach(function (q) { var f = vd.prop ? (vd.stops[q.i] - s0) / (s1 - s0) : q.i / n1, sp = el('span', '', mathify(q.html)); sp.style.left = 'calc(9px + (100% - 18px) * ' + f.toFixed(4) + ')'; tn.appendChild(sp); });
          slot.appendChild(tn); row.classList.add('hasnotes');
        }
      }
      if (vd.eqLine) { var eqd = el('div', 'veq'); row.appendChild(eqd); }
      (holder[k] || vb).appendChild(row);
      var set = function (x) {
        if (!vd.stops) x = clamp(x, vd.min, vd.max);
        var ok = true;
        if (d.onVar) ok = d.onVar(self, vd.k, x); else self.v[vd.k] = x;
        if (ok === false) { self.syncSliders(true); return; }
        self.changed(vd.k);
      };
      var idxOf = function (x) { var b = 0; vd.stops.forEach(function (q, i) { if (Math.abs(q - x) < Math.abs(vd.stops[b] - x)) b = i; }); return b; };
      inp.addEventListener('input', function () {
        var x = vd.stops ? (vd.prop ? vd.stops[idxOf(parseFloat(inp.value))] : vd.stops[+inp.value]) : parseFloat(inp.value);
        if (vd.prop) inp.value = String(x);                /* いちばん近い目盛りに吸いつく */
        if (vd.allow) { var al = vd.allow(self), xc = clamp(x, al.lo, al.hi); if (xc !== x) { inp.value = String(xc); x = xc; } }   /* 選べない範囲へはドラッグしても進まない（止まる） */
        set(x);
      });
      var nudge = function (sg) {
        if (vd.nudge) { if (vd.nudge(self, sg) !== false) self.changed(vd.k); return; }   /* vd.nudge：ほかの量を動かして変える（①-2 の ω・T は m を 1 段動かす） */
        var cur = self.disp(vd.k);
        if (vd.stops) { var i = clamp(idxOf(cur) + sg, 0, vd.stops.length - 1); set(vd.stops[i]); }
        else set(+(roundTo(cur, vd.step) + sg * vd.step).toFixed(6));
      };
      dn.addEventListener('click', function () { nudge(-1); });
      up.addEventListener('click', function () { nudge(+1); });
      if (vd.meter) {                                      /* vd.meter：動かせない量（値をメーターで見せるだけ）。押すとその量の説明 */
        row.classList.add('meter'); inp.disabled = true; inp.tabIndex = -1; dn.hidden = true; up.hidden = true;
        row.title = '他の量から決まる値（クリックで説明）';
        row.addEventListener('click', function () { if (d.onPick) d.onPick(self, vd.k); });
      }
      self.sl[vd.k] = { inp: inp, val: val, vd: vd, row: row, lk: lk, dn: dn, up: up, mk: mk, rw: slot, idxOf: vd.stops ? idxOf : null, eq: vd.eqLine ? row.querySelector('.veq') : null, seg: segW };
    });
    if (d.lockable) { this.lockmsg = el('div', 'lockmsg'); vb.appendChild(this.lockmsg); }
    if (varBtns.length) { var vr0 = this.sl[d.vars[0].k].row; vr0.classList.add('hasbtn'); varBtns.forEach(function (b) { vr0.appendChild(b); }); }
  }
  /* ならび：スライダー → ボタン（▶ スタート …）→ 時間バー → 図 */
  /* ▶ スタート・スロー・リセット（・ストロボ）と時間バーを 1 行にまとめ、図のすぐ上に置く（2026-10-05 千葉さん） */
  ctr.appendChild(row1b);
  var pbar = el('div', 'playbar' + (playBtns.length ? ' hasinst' : '')); pbar.appendChild(row1); if (!d.noTime) pbar.appendChild(trow);   /* d.noTime：時間バーを出さない（光電効果：光を当て続ける現象なので） */ playBtns.forEach(function (b) { pbar.appendChild(b); }); ctr.appendChild(pbar);
  /* 図 */
  var cw = el('div', 'cvwrap');
  if (d.graphs) {                                        /* d.graphs：図の右（せまいときは下）に x–t・v–t・a–t グラフを縦に重ねる */
    var stg = el('div', 'stg' + (d.stgCls ? ' ' + d.stgCls : '')); L.appendChild(stg); stg.appendChild(cw);
    this.gHost = el('div', 'ghost'); stg.appendChild(this.gHost); this.stg = stg;
  } else L.appendChild(cw);
  this.cw = cw;
  this.cv = el('canvas'); this.cv.id = 'cv_' + d.id; cw.appendChild(this.cv);
  if (cvBtns.length) { var tl = el('div', 'cvbtns'); cvBtns.forEach(function (b) { tl.appendChild(b); }); cw.appendChild(tl); }
  if (d.views) {
    var vbx = el('div', 'viewbtns'); cw.appendChild(vbx); this.vbtns = [];
    d.views.forEach(function (vw, i) {
      var b = el('button', 'b viewbtn', vw.label); b.type = 'button'; b.dataset.i = i;
      b.addEventListener('click', function () { self.setView(i, true); });
      vbx.appendChild(b); self.vbtns.push(b);
    });
  }
  if (d.belowCanvas) { this.below = el('div', 'belowcv'); L.appendChild(this.below); }
  this.msg = el('div', 'msgbox'); L.appendChild(this.msg);
  this.lastMsg = null;
  /* クリック（量をえらぶ）とドラッグ（視点を回す） */
  var down = null;
  this.cv.addEventListener('pointerdown', function (ev) {
    var r = self.cv.getBoundingClientRect();
    down = { x: ev.clientX, y: ev.clientY, lx: ev.clientX - r.left, ly: ev.clientY - r.top, moved: false, last: { x: ev.clientX, y: ev.clientY } };
    /* d.dragHit：スタート前に小球をつかんで動かす（離した位置がそのまま振幅になる） */
    if (d.dragHit && !self.playing && self.t === 0 && !self.busy && d.dragHit(self, down.lx, down.ly)) {
      down.ball = true; self.dragging = true; self.cv.setPointerCapture(ev.pointerId); ev.preventDefault();
      if (d.dragMove) d.dragMove(self, down.lx, down.ly); self.draw(); return;
    }
    if (d.drag3d) { self.cv.setPointerCapture(ev.pointerId); }
  });
  this.cv.addEventListener('pointermove', function (ev) {
    if (down && down.ball) { var rb = self.cv.getBoundingClientRect(); d.dragMove(self, ev.clientX - rb.left, ev.clientY - rb.top); self.draw(); ev.preventDefault(); return; }
    if (!down) { self.hover(ev); return; }
    var dx = ev.clientX - down.last.x, dy = ev.clientY - down.last.y;
    if (Math.hypot(ev.clientX - down.x, ev.clientY - down.y) > 4) down.moved = true;
    down.last = { x: ev.clientX, y: ev.clientY };
    if (down.moved && d.drag3d) { d.drag3d(self, dx, dy); self.draw(); ev.preventDefault(); }
  });
  var up = function () {
    if (down && down.ball) { down = null; self.dragging = false; if (d.dragEnd) d.dragEnd(self); self.changed('drag'); return; }
    if (down && !down.moved) self.clickAt(down.lx, down.ly);
    down = null;
  };
  this.cv.addEventListener('pointerup', up);
  this.cv.addEventListener('pointercancel', function () { if (down && down.ball) { self.dragging = false; if (d.dragEnd) d.dragEnd(self); self.changed('drag'); } down = null; });
  if (d.drag3d) this.cv.classList.add('cam3d');
  if (d.views && (d.view0 || 0) >= 0) this.setView(d.view0 || 0, false);
};
Sim.prototype.hover = function (ev) {
  var r = this.cv.getBoundingClientRect(), x = ev.clientX - r.left, y = ev.clientY - r.top;
  var h = this.hitAt(x, y);
  if (this.def.dragHit && !this.playing && this.t === 0 && this.def.dragHit(this, x, y)) { this.cv.style.cursor = 'grab'; return; }
  this.cv.style.cursor = h ? 'pointer' : (this.def.drag3d ? 'grab' : 'default');
};
Sim.prototype.hitAt = function (x, y) {
  for (var i = this.hits.length - 1; i >= 0; i--) {
    var h = this.hits[i];
    if (h.seg) {                                            /* 矢印（線分）からの近さ */
      var s = h.seg, dx = s[2] - s[0], dy = s[3] - s[1], L2 = dx * dx + dy * dy || 1;
      var u = clamp(((x - s[0]) * dx + (y - s[1]) * dy) / L2, 0, 1), px = s[0] + u * dx, py = s[1] + u * dy;
      if (Math.hypot(x - px, y - py) < 9) return h;
    } else if (x >= h.x - 4 && x <= h.x + h.w + 4 && y >= h.y - 4 && y <= h.y + h.h + 4) return h;
  }
  return null;
};
Sim.prototype.clickAt = function (x, y) {
  var h = this.hitAt(x, y);
  if (h && this.def.onPick) { this.def.onPick(this, h.k); }
};
Sim.prototype.setView = function (i, user) {
  this.view = i;
  var vw = this.def.views[i];
  if (this.def.onView) this.def.onView(this, i, user);
  (this.vbtns || []).forEach(function (b, j) { b.classList.toggle('on', j === i); });
  this.draw();
};
Sim.prototype.resize = function () {
  var w = Math.max(260, Math.floor(this.cw.clientWidth || 600));
  this.W = w; this.H = this.def.height ? this.def.height(this, w) : Math.round(Math.min(470, Math.max(300, w * 0.72)));
  if (this.def.onResize) this.def.onResize(this);
};
Sim.prototype.disp = function (k) { return this.def.disp ? this.def.disp(this, k) : this.v[k]; };
Sim.prototype.syncSliders = function (force) {
  var self = this;
  Object.keys(this.sl).forEach(function (k) {
    var s = self.sl[k], x = self.disp(k), vd = s.vd, pos, p;
    if (vd.stops && vd.prop) { pos = vd.stops[s.idxOf(x)]; p = (pos - vd.stops[0]) / (vd.stops[vd.stops.length - 1] - vd.stops[0]) * 100; }
    else if (vd.stops) { pos = s.idxOf(x); p = pos / (vd.stops.length - 1) * 100; }
    else { pos = clamp(x, vd.min, vd.max); p = (pos - vd.min) / (vd.max - vd.min) * 100; }
    if (force || document.activeElement !== s.inp) s.inp.value = String(pos);
    var html = vd.fmt ? vd.fmt(x, self) : (fmt(x, vd.dec) + (vd.unit ? ' ' + vd.unit : ''));
    if (s._html !== html) { s._html = html; s.val.innerHTML = vd.fmt ? mathify(html) : html; }
    s.inp.style.setProperty('--p', p.toFixed(1) + '%');
    if (s.seg) { var si = s.idxOf(x); [].forEach.call(s.seg.querySelectorAll('.vsegb'), function (b, i) { var on = i === si || (vd.modTau && Math.abs(Math.cos(vd.stops[i]) - Math.cos(vd.stops[si])) < 1e-9 && Math.abs(Math.sin(vd.stops[i]) - Math.sin(vd.stops[si])) < 1e-9); if (b.classList.contains('on') !== on) { b.classList.toggle('on', on); b.setAttribute('aria-pressed', on ? 'true' : 'false'); } }); }
    if (s.eq) { var eh = vd.eqLine(self); if (s._eh !== eh) { s._eh = eh; s.eq.innerHTML = mathify(eh); } }
    if (vd.btnOnly && !self.busy) {                        /* 端の段ではボタンを押せない */
      var cn = vd.canNudge ? [vd.canNudge(self, -1), vd.canNudge(self, 1)] : (vd.stops ? [s.idxOf(x) > 0, s.idxOf(x) < vd.stops.length - 1] : [true, true]);
      s.dn.disabled = !cn[0]; s.up.disabled = !cn[1];
    }
    if (vd.allow && s.rw) {                                /* vd.allow：選べる範囲だけ。範囲の外はスライダーの線を薄く（4-1・4-2） */
      var al = vd.allow(self);
      if (!s.dis) { s.dis = [el('i', 'vdis'), el('i', 'vdis')]; s.dis.forEach(function (sp) { sp.setAttribute('aria-hidden', 'true'); s.rw.insertBefore(sp, s.inp); }); }
      var f0 = (al.lo - vd.min) / (vd.max - vd.min), f1 = (al.hi - vd.min) / (vd.max - vd.min);
      s.dis[0].style.cssText = 'left:0;width:calc(-2px + (100% - 18px) * ' + f0.toFixed(4) + ');display:' + (f0 > 0.001 ? 'block' : 'none');
      s.dis[1].style.cssText = 'left:calc(20px + (100% - 18px) * ' + f1.toFixed(4) + ');right:0;display:' + (f1 < 0.999 ? 'block' : 'none');
    }
    if (s.mk) {
      var qs = [].concat(vd.mark(self) || []);
      while (s.mk.length < qs.length) { var sp = el('span', 'vmark'); sp.setAttribute('aria-hidden', 'true'); s.rw.appendChild(sp); s.mk.push(sp); }
      s.mk.forEach(function (sp, i) {
        var q = qs[i], on = q && q.x >= vd.min && q.x <= vd.max;
        sp.style.display = on ? '' : 'none';
        if (on) { sp.style.setProperty('--m', ((q.x - vd.min) / (vd.max - vd.min)).toFixed(4)); var mh = mathify(q.label); if (sp._h !== mh) { sp._h = mh; sp.innerHTML = mh; } sp.className = 'vmark' + (q.cls ? ' ' + q.cls : ''); }   /* q.cls：目印の種類（光電効果の「最初の設定」defm） */
      });
    }
  });
};
/* 鍵の見た目：固定ならスライダーと −／＋ を止める */
var LOCK_SVG = {
  on: '<svg viewBox="0 0 20 20" aria-hidden="true"><rect x="4" y="9" width="12" height="9" rx="2" fill="currentColor"/><path d="M6.5 9V6.5a3.5 3.5 0 0 1 7 0V9" fill="none" stroke="currentColor" stroke-width="2"/></svg>',
  off: '<svg viewBox="0 0 20 20" aria-hidden="true"><rect x="4" y="9" width="12" height="9" rx="2" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M6.5 9V6.5a3.5 3.5 0 0 1 6.6-1.6" fill="none" stroke="currentColor" stroke-width="1.8"/></svg>'
};
Sim.prototype.syncLocks = function () {
  var self = this;
  Object.keys(this.sl).forEach(function (k) {
    var s = self.sl[k], on = !!self.locks[k];
    if (!s.lk) return;
    s.lk.innerHTML = on ? LOCK_SVG.on : LOCK_SVG.off;
    s.lk.classList.toggle('on', on);
    s.lk.setAttribute('aria-pressed', on ? 'true' : 'false');
    s.lk.title = on ? '固定中（押すと鍵を外す）' : '固定していない（押すと鍵をかける）';
    s.lk.setAttribute('aria-label', (s.vd.aria || k) + (on ? 'の鍵を外す' : 'を固定する'));
    s.row.classList.toggle('locked', on);
    s.inp.disabled = on; s.dn.disabled = on; s.up.disabled = on;
  });
  if (this.lockmsg) this.lockmsg.innerHTML = '';
};
Sim.prototype.lockNote = function (html) {
  if (!this.lockmsg) return;
  this.lockmsg.innerHTML = mathify(html);
  clearTimeout(this._lmT); var lm = this.lockmsg;
  this._lmT = setTimeout(function () { lm.innerHTML = ''; }, 6000);
};
/* 変数が変わった：最初から（θ = ωt を保つため、時刻を 0 に戻す。動いていたら続けて動かす） */
Sim.prototype.changed = function (k) {
  var was = this.playing, keep = false, res = this.def.onChanged ? this.def.onChanged(this, k) : null;
  if (k === 'phi') res = 'stop';                                /* 初期位相を変えたら、止めて最初から（2026-10-16 千葉さん） */
  if (res === 'stop') { this.resetT(); return; }             /* 'stop'：↺ リセットと同じ（最初にもどして止める） */
  keep = res === 'keepT';
  if (!keep) this.t = 0;                                     /* 'keepT' を返したら時刻を保つ（なめらかに変える） */
  this.ended = false;
  this.playing = was;
  this.syncPlayLabel(); this.draw(); this.renderRight();
};
/* 「↗ ω を大きくしていく」など、量を自動で変えていく間（s.busy）：▶ スタートは「❚❚ 一時停止」になり、押すと止まる・続く。
   他の操作（スライダー・ボタン・図）は止めておく（2026-10-06 千葉さん） */
Sim.prototype.setBusy = function (on) {
  var ctr = this.L.querySelector('.ctrls'), self = this;
  if (on) {
    this.busy = { paused: false, dis: [] }; this.L.classList.add('m1busy'); this.cw.inert = true;
    if (ctr) ctr.querySelectorAll('button, input').forEach(function (e) { if (e !== self.bPlay && !e.disabled) { e.disabled = true; self.busy.dis.push(e); } });
  } else if (this.busy) {
    this.busy.dis.forEach(function (e) { e.disabled = false; }); this.busy = null; this.L.classList.remove('m1busy'); this.cw.inert = false;
    if (this.syncLocks) this.syncLocks();
  }
  this.syncPlayLabel();
};
Sim.prototype.togglePlay = function () {
  if (this.busy) { this.busy.paused = !this.busy.paused; this.syncPlayLabel(); return; }   /* 自動で変えている間は、一時停止・再開だけ */
  if (this.cutAnim && !this.cutAnim.snipped) return;        /* はさみで切っている最中は待つ */
  if (this.playing) { this.playing = false; this.syncPlayLabel(); return; }
  if (this.ended || this.t >= this.tEnd() - 1e-9) { this.t = 0; this.ended = false; if (this.def.onRestart) this.def.onRestart(this); }
  SIMS.forEach(function (s) { if (s.playing) { s.playing = false; s.syncPlayLabel(); } });
  this.playing = true; this.syncPlayLabel(); startLoop();
};
/* t0 から t1 までを、速さ rate で再生して止める（終わったら cb）。ふつうの再生・リセットで解除 */
Sim.prototype.playWindow = function (t0, t1, rate, cb, keepTrail) {
  SIMS.forEach(function (s) { if (s.playing) { s.playing = false; s.syncPlayLabel(); } });
  this.t = clamp(t0, 0, this.tEnd()); this.ended = false; if (!keepTrail) this.trail = [];
  this.stopAt = t1; this.stopCb = cb || null; this.rate = rate; this.inWindow = true;
  if (this.def.onWindow) this.def.onWindow(this, true);
  this.playing = true; this.syncPlayLabel(); this.draw(); startLoop();
};
Sim.prototype.endWindow = function () {
  if (!this.inWindow) return;
  this.inWindow = false; this.stopAt = null; this.stopCb = null; this.rate = this.base * (this.slow ? 0.3 : 1);
  if (this.def.onWindow) this.def.onWindow(this, false);
};
Sim.prototype.resetT = function () {
  this.endWindow();
  this.playing = false; this.t = 0; this.ended = false; this.trail = [];
  if (this.def.onReset) this.def.onReset(this);
  this.syncPlayLabel(); this.draw(); this.renderRight();
};
Sim.prototype.toDefaults = function () {
  this.endWindow();
  this.playing = false; this.setSlow(false); this.trail = [];
  this.strobe = false; this.bStrobe.classList.remove('on'); this.bStrobe.setAttribute('aria-pressed', 'false');
  this.reset0(); if (this.syncFBtns) this.syncFBtns();
  if (this.extra.vec) { this.extra.vec.classList.remove('on'); this.extra.vec.setAttribute('aria-pressed', 'false'); }
  this.locks = Object.assign({}, this.def.lockDefault || {}); this.syncLocks();
  if (this.def.onDefaults) this.def.onDefaults(this);
  if (this.def.views && (this.def.view0 || 0) >= 0) this.setView(this.def.view0 || 0, false);
  else if (this.vbtns) this.vbtns.forEach(function (b) { b.classList.remove('on'); });
  this.syncPlayLabel(); this.draw(); this.renderRight();
};
Sim.prototype.setSlow = function (on) { if (this.inWindow) this.endWindow(); this.slow = on; this.rate = this.base * (on ? 0.3 : 1); this.bSlow.classList.toggle('on', on); };
Sim.prototype.setT = function (t) {
  this.endWindow();
  this.trail = [];                                          /* 時間を飛ばしたら軌跡は消す（飛んだ線を引かない） */
  this.t = clamp(t, 0, this.tEnd());
  this.ended = this.t >= this.tEnd() - 1e-9;
  this.draw();
};
/* コマ送り：押すごとに T/16 ずつ進める。最初（T/16 の倍数でない時刻）は、いちばん近い T/16 の倍数の時刻へ */
Sim.prototype.periodNow = function () { var d = this.def; return d.gT ? d.gT(this) : (d.stepT ? d.stepT(this) : NaN); };
Sim.prototype.stepFrame = function () {
  if (this.busy) return;
  var T = this.periodNow(); if (!(T > 0)) return;
  var q = T / 16, n = this.t / q, nt = Math.abs(n - Math.round(n)) > 1e-6 ? Math.round(n) * q : this.t + q;
  this.playing = false; this.endWindow();
  this.t = clamp(nt, 0, this.tEnd()); this.ended = this.t >= this.tEnd() - 1e-9;
  this.syncPlayLabel(); this.draw();
};
Sim.prototype.syncPlayLabel = function () {
  var txt = this.busy ? (this.busy.paused ? '▶ スタート' : '❚❚ 一時停止') : (this.playing ? '❚❚ 一時停止' : (this.ended ? '▶ 最初から' : '▶ スタート'));
  if (this.bPlay.textContent !== txt) this.bPlay.textContent = txt;
};
Sim.prototype.step = function (dt) {
  var t1 = this.t + dt * this.rate, te = this.tEnd();
  if (this.def.beforeStep) this.def.beforeStep(this, this.t, t1);
  te = this.tEnd();
  if (this.stopAt != null && t1 >= this.stopAt && this.stopAt < te) {   /* 決めた時刻で止める（「離れる瞬間」のスロー再生など） */
    this.t = this.stopAt; var cb = this.stopCb; this.endWindow(); this.playing = false; this.syncPlayLabel(); this.draw();
    if (cb) cb(this);
    return;
  }
  if (t1 >= te) { t1 = te; this.t = t1; this.ended = true; this.playing = false; this.syncPlayLabel(); }   /* 値を入れてからラベルを更新 */
  else this.t = t1;
  this.draw();
};
Sim.prototype.draw = function () {
  if (!this.cv) return;
  if (!this.W) this.resize();
  var te = this.tEnd(), now = performance.now();
  /* 時間バー・数字・スライダーの書きかえはページ全体の組み直しを起こして重いので、再生中は 1 秒に 15 回まで */
  if (!this.playing || !this._domT || now - this._domT > 66) {
    this._domT = now;
    if (!this.def.noTime) {
      if (String(this.tsl.max) !== String(te)) this.tsl.max = String(te);
      this.tsl.value = String(this.t);
      this.tsl.style.setProperty('--p', (this.t / te * 100).toFixed(2) + '%');
      var tv = this.def.tFmt ? this.def.tFmt(this.t) : fmt(this.t, 1) + ' s';   /* def.tFmt：時刻の書き方（②-8 は「分」） */ if (this.tval.textContent !== tv) this.tval.textContent = tv;   /* 小数点以下 1 けた（2026-10-16 千葉さん） */
    }
    if (this.def.tInfo) { var ti = this.def.tInfo(this); if (this.tinfo.innerHTML !== ti) this.tinfo.innerHTML = ti; }
    if (this.def.tInfoNum) this.setRoll(this.def.tInfoNum(this));
    this.syncSliders();
  }
  var ctx = prep(this.cv, this.W, this.H);
  this.hits = [];
  this.def.draw(this, ctx, this.W, this.H);
  if (this.graphs && typeof shmDrawGraphs === 'function') shmDrawGraphs(this);
  if (this.def.msg) { var m = this.def.msg(this); if (m !== this.lastMsg) { this.lastMsg = m; this.msg.innerHTML = mathify(m); } }
  if (this.def.below) this.def.below(this);
  if (this.def.live) this.def.live(this);
  if (!this.playing && this.gHost && this.gHost.parentNode === this.R) this.align();   /* 止まっているときに、アニメとグラフの上のはしをそろえ直す */
};
Sim.prototype.addHit = function (k, box) { if (box) this.hits.push({ k: k, x: box.x, y: box.y, w: box.w, h: box.h }); };
Sim.prototype.addHitSeg = function (k, a) { if (a) this.hits.push({ k: k, seg: [a.x1, a.y1, a.x2, a.y2] }); };
Sim.prototype.renderRight = function () {
  if (this.def.right && this.R) this.def.right(this, this.Rdyn || this.R);
  if (this.def.left && this.Ldyn) this.def.left(this, this.Ldyn);       /* d.left：図の下（左の列）に置く説明 */
};

/* ---------- アニメの心臓（同時に動くのは 1 つだけ） ---------- */
var _loopOn = false, _lastTs = 0;
function startLoop() {
  if (_loopOn) return; _loopOn = true; _lastTs = 0;
  requestAnimationFrame(loop);
}
function loop(ts) {
  var dt = _lastTs ? Math.min(0.05, (ts - _lastTs) / 1000) : 0; _lastTs = ts;
  var any = false;
  SIMS.forEach(function (s) { if (s.playing) { any = true; s.step(dt); } });
  if (any) requestAnimationFrame(loop); else _loopOn = false;
}
window.addEventListener('resize', function () {
  clearTimeout(window.__rz); window.__rz = setTimeout(function () {
    SIMS.forEach(function (s) { (s.graphs || []).forEach(function (g) { g.Wc = 0; }); if (s.cv && s.cv.offsetParent) { s.resize(); s.draw(); } });
    alignAll();
  }, 80);
});

/* 時間バーの右の整数（何回転したか）：1 増えるたびに、下から新しい数字がせり上がる（ローリング） */
Sim.prototype.setRoll = function (q) {
  var box = this.tinfo, pre = box.querySelector('.tpre'), un = box.querySelector('.tunit'), rin = box.querySelector('.rin');
  if (pre.textContent !== q.pre) pre.textContent = q.pre;
  if (un.textContent !== q.unit) un.textContent = q.unit;
  if (q.n === this._roll) return;
  var r0 = rin.querySelector('.r0'), r1 = rin.querySelector('.r1');
  if (q.n === this._roll + 1 && this.playing) {               /* 再生中に 1 増えた → ローリング */
    rin.classList.remove('go'); r0.textContent = String(this._roll); r1.textContent = String(q.n);
    void rin.offsetWidth; rin.classList.add('go');
  } else { rin.classList.remove('go'); r0.textContent = String(q.n); r1.textContent = String(q.n); }
  this._roll = q.n;
};

/* ---------- 軌跡（モード2・3 の「軌跡を表示」） ----------
   毎回の描画で物体の位置を記録し、少し前（def.trailSec 秒）までの道すじを、古いほど薄く描く。
   p＝慣性系での位置（描画関数に渡す座標）、fr＝そのときの絵の回転角、pr＝回転の中心から見た位置（ふつうは p と同じ）。
   proj(x, y, z) は「いまの絵」で座標 → 画面。非慣性系では、記録したときの回転のぶんを戻して描く（＝回る観測者から見た道すじ）。
   fr の向きは proj の回転と同じ（いまの絵が R(fr_now) をかけるなら、R(fr_then − fr_now) をかけた点を渡す） */
function trailStep(ctx, s, proj, p, fr, pr) {
  if (!s.trail) s.trail = [];
  var T = s.trail, last = T[T.length - 1];
  if (last && (s.t < last.t - 1e-9 || s.t - last.t > 0.6)) { T.length = 0; last = null; }   /* 時間を戻した・飛ばしたら消す */
  if (!last || s.t - last.t > 0.006) T.push({ t: s.t, p: p.slice(), pr: (pr || p).slice(), fr: fr || 0 });
  var win = s.trailWin || s.def.trailSec || 1.5;                /* s.trailWin：場面で変える長さ（2-6 のらせん） */
  while (T.length > 2 && T[0].t < s.t - win) T.shift();
  if (!(s.trailOn || s.autoTrail) || T.length < 2) return;   /* ボタンで ON、または動きが大事な場面（滑る・糸が切れる・離れる）で自動 */
  var frNow = fr || 0;
  var pt = function (q) {
    var a = q.p;
    if (s.rot) { var d = q.fr - frNow, c = Math.cos(d), sn = Math.sin(d); a = [q.pr[0] * c - q.pr[1] * sn, q.pr[0] * sn + q.pr[1] * c, q.pr[2] || 0]; }
    return proj(a[0], a[1], a[2] || 0);
  };
  ctx.save(); ctx.lineCap = 'round'; ctx.lineWidth = 2.6;
  var prev = pt(T[0]);
  for (var i = 1; i < T.length; i++) {
    var cur = pt(T[i]), age = (s.t - T[i].t) / win;
    ctx.strokeStyle = 'rgba(22,99,181,' + (0.75 * (1 - clamp(age, 0, 1)) + 0.05).toFixed(3) + ')';
    ctx.beginPath(); ctx.moveTo(prev.x, prev.y); ctx.lineTo(cur.x, cur.y); ctx.stroke();
    prev = cur;
  }
  ctx.restore();
}


/* ---------- 操作の並べかえ（2026-10-18 千葉さん） ----------
   ctlOneRow：スライダーの右に時間バー（1 行）。ctlSide：左に［すべて最初の設定に戻す…・▶ スタート・時間バー］、右にスライダー */
function ctlOneRow(s) {
  var ctr = s.L.querySelector('.ctrls'), row = ctr && ctr.querySelector('.row2.sliders'), tr = ctr && ctr.querySelector('.playbar .trow');
  if (!row || !tr) return;
  if (s.varbox && s.varbox.parentNode !== row) row.insertBefore(s.varbox, row.firstChild);
  row.classList.add('onerow'); row.appendChild(tr);
}
function ctlSide(s) {
  var ctr = s.L.querySelector('.ctrls'); if (!ctr) return;
  var row = ctr.querySelector('.row2.sliders'), left = el('div', 'cleft');
  [].slice.call(ctr.children).forEach(function (c) { if (c !== row) left.appendChild(c); });
  ctr.insertBefore(left, ctr.firstChild); ctr.classList.add('side');
}
