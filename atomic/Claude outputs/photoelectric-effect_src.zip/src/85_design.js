/* =========================================================================
   85_design.js … デザイン統一キットの動き（simple-harmonic-motion の 85_design.js から、このページで使うものだけ）
   ・スライドバーの塗り（--p）、上の帯の下の進み具合（--prog）、上の帯の .stuck、フッター
   ========================================================================= */
(function () {
  'use strict';
  function syncRange(e) {
    var mn = parseFloat(e.min) || 0, mx = parseFloat(e.max), v = parseFloat(e.value);
    var p = (isFinite(mx) && mx > mn) ? (v - mn) / (mx - mn) * 100 : 0, s = p.toFixed(1) + '%';
    if (e._p !== s) { e._p = s; e.style.setProperty('--p', s); }
  }
  function initRanges() {
    document.addEventListener('input', function (ev) { if (ev.target && ev.target.type === 'range') syncRange(ev.target); }, true);
    var sweep = function () { if (document.hidden) return; document.querySelectorAll('.mode.on input[type=range]').forEach(syncRange); };
    sweep(); setInterval(sweep, 120);
  }
  function initProgress() {
    var nav = document.getElementById('tabs'); if (!nav) return;
    var pend = false;
    var upd = function () { pend = false; var h = document.documentElement, max = h.scrollHeight - innerHeight; nav.style.setProperty('--prog', max > 0 ? Math.min(1, Math.max(0, scrollY / max)).toFixed(4) : 0); };
    window.addEventListener('scroll', function () { if (!pend) { pend = true; requestAnimationFrame(upd); } }, { passive: true });
    window.addEventListener('resize', upd); upd();
  }
  function initStuck() {
    var hero = document.getElementById('hero'), nav = document.getElementById('tabs'); if (!hero || !nav || !('IntersectionObserver' in window)) return;
    new IntersectionObserver(function (es) { es.forEach(function (en) { nav.classList.toggle('stuck', !en.isIntersecting); }); }, { threshold: 0 }).observe(hero);
  }
  function initFooter() {
    var f = document.querySelector('#wrap footer'); if (!f) return;
    document.body.appendChild(f);
    var items = SECS.filter(function (sid) { return DEFS[sid]; }).map(function (sid) { return '<li><a href="#' + sid + '" data-sec="' + sid + '"><b>' + DEFS[sid].num + '</b>' + DEFS[sid].title + '</a></li>'; }).join('');
    f.innerHTML = '<div class="ft-in"><p class="ft-mark">Photoelectric Effect<span>光電効果</span></p>' +
      '<ul class="ft-nav">' + items + '</ul>' +
      '<div class="ft-base"><span><a class="ft-home" href="' + SITE_HOME + '">⌂ 楽楽（らくらく）高校物理 トップページ</a>　／　高校物理 ・ 原子</span><span class="ft-r"><button type="button" class="ft-pages">ほかのページ一覧</button><a href="#top" class="ft-top">▲ ページの一番上へ</a></span></div></div>';
    f.querySelectorAll('a[data-sec]').forEach(function (a) { a.addEventListener('click', function (ev) { ev.preventDefault(); history.replaceState(null, '', '#' + a.dataset.sec); scrollToSec(a.dataset.sec); }); });
    var fp = f.querySelector('.ft-pages'); if (fp) fp.addEventListener('click', function () { if (window.SITENAV) window.SITENAV.open(); });
    var tp = f.querySelector('.ft-top'); if (tp) tp.addEventListener('click', function (ev) { ev.preventDefault(); window.scrollTo({ top: 0, behavior: 'auto' }); });
  }
  document.addEventListener('DOMContentLoaded', function () { initFooter(); initRanges(); initProgress(); initStuck(); });
})();
