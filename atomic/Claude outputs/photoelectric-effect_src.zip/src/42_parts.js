/* =========================================================================
   42_parts.js … 小さな描画部品（simple-harmonic-motion の 42_parts.js から、このページで使うものだけ）
   ========================================================================= */
'use strict';
function dotted(ctx, x1, y1, x2, y2, col, dash) {
  ctx.save(); ctx.strokeStyle = col || 'rgba(60,70,80,.55)'; ctx.lineWidth = 1.1; ctx.setLineDash(dash || [2, 3]);
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); ctx.restore();
}
/* 座標軸（矢印つき）。(x1,y1) → (x2,y2) */
function axisArrow(ctx, x1, y1, x2, y2, col) {
  var L = Math.hypot(x2 - x1, y2 - y1), ux = (x2 - x1) / L, uy = (y2 - y1) / L;
  ctx.save(); ctx.strokeStyle = col || '#2b323c'; ctx.fillStyle = col || '#2b323c'; ctx.lineWidth = 1.3;
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2 - ux * 6, y2 - uy * 6); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(x2, y2); ctx.lineTo(x2 - ux * 9 - uy * 4, y2 - uy * 9 + ux * 4); ctx.lineTo(x2 - ux * 9 + uy * 4, y2 - uy * 9 - ux * 4); ctx.closePath(); ctx.fill();
  ctx.restore();
}
/* エネルギーの量を表す矢印（力の矢印と違い、作用点の「・」をつけない）。w：太さ */
function eArrow(ctx, x1, y1, x2, y2, col, w) {
  var L = Math.hypot(x2 - x1, y2 - y1); if (L < 2) return;
  var ux = (x2 - x1) / L, uy = (y2 - y1) / L, lw = w || 3, h = Math.min(4 + lw * 2.4, L * 0.6), bx = x2 - ux * h, by = y2 - uy * h, wa = h * 0.62;
  ctx.save(); ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = lw;
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(bx, by); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(x2, y2); ctx.lineTo(bx - uy * wa, by + ux * wa); ctx.lineTo(bx + uy * wa, by - ux * wa); ctx.closePath(); ctx.fill();
  ctx.restore();
}
/* 振動数 ν〔×10¹⁴ Hz〕→ 光子の波の数（4.0 で 1.5 個 … 12.0 で 5.0 個。0.5 個ずつの 8 段階）。波長が短いほど細かい波 */
function photonCycles(nu) { return 1.5 + 0.5 * Math.round(clamp((nu - PE.NU_MIN) / (PE.NU_MAX - PE.NU_MIN), 0, 1) * 7); }
/* 波のような線の光子（画像 2 の波線）。(x, y)＝先頭、(ux, uy)＝進む向き、L＝長さ、col＝色、uv＝紫外線（白いふちを点線に） */
/* cyc：波の数（光の振動数が大きい＝波長が短いほど多い。photonCycles(ν) で 8 段階） */
function photonWave(ctx, x, y, ux, uy, L, col, alpha, uv, cyc) {
  var px = -uy, py = ux, amp = 3.2, n = cyc || 2.5, N = Math.max(26, Math.round(n * 14));
  ctx.save(); ctx.globalAlpha = alpha === undefined ? 1 : alpha; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  var path = function () {
    ctx.beginPath();
    for (var i = 0; i <= N; i++) {
      var s = i / N, env = Math.sin(Math.PI * s), w = amp * env * Math.sin(TAU * n * s);
      var qx = x - ux * L * s + px * w, qy = y - uy * L * s + py * w;
      i ? ctx.lineTo(qx, qy) : ctx.moveTo(qx, qy);
    }
  };
  path(); ctx.strokeStyle = 'rgba(255,255,255,.85)'; ctx.lineWidth = 4.2; if (uv) ctx.setLineDash([3, 2]); ctx.stroke(); ctx.setLineDash([]);
  path(); ctx.strokeStyle = col; ctx.lineWidth = 2.0; ctx.stroke();
  ctx.beginPath(); ctx.arc(x, y, 2.6, 0, TAU); ctx.fillStyle = col; ctx.fill();          /* 先頭の粒 */
  ctx.restore();
}
/* 電子（小さな点）。hot：飛び出した電子（濃い青）、fade：うすさ */
function electronDot(ctx, x, y, r, alpha, hot) {
  ctx.save(); ctx.globalAlpha = alpha === undefined ? 1 : alpha;
  var g = ctx.createRadialGradient(x - r * 0.35, y - r * 0.4, r * 0.1, x, y, r);
  g.addColorStop(0, '#cfe3ff'); g.addColorStop(0.45, hot ? '#2f7de1' : '#4a86d6'); g.addColorStop(1, hot ? '#0b3f8c' : '#21497f');
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
  ctx.restore();
}
