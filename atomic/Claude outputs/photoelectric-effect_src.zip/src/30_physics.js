/* =========================================================================
   30_physics.js … 光電効果の計算だけ（描画を混ぜない・同じ入力 → 同じ出力）
   単位：振動数は ×10¹⁴ Hz、エネルギーは ×10⁻¹⁹ J で持つ（画面の数字と同じ）。
   値は教科書にそろえる：h = 6.63×10⁻³⁴ J·s、e = 1.60×10⁻¹⁹ C（1 eV = 1.60×10⁻¹⁹ J）、仕事関数は表 1。
   ========================================================================= */
'use strict';
var TAU = Math.PI * 2;
function clamp(x, a, b) { return x < a ? a : (x > b ? b : x); }
function roundTo(x, step) { return Math.round(x / step) * step; }

var PE = {
  h: 6.63e-34,            /* プランク定数〔J·s〕 */
  e: 1.60e-19,            /* 電気素量〔C〕 */
  c: 3.00e8,              /* 真空中の光の速さ〔m/s〕 */
  m: 9.11e-31,            /* 電子の質量〔kg〕 */
  NU_MIN: 4.0, NU_MAX: 12.0, NU_STEP: 0.1,      /* 振動数のスライダー〔×10¹⁴ Hz〕（2026-10-26 千葉さん。最大は 16 → 12 に） */
  V_MIN: -5.0, V_MAX: 5.0, V_STEP: 0.1,         /* 陽極の電位〔V〕 */
  ISAT100: 10.0,          /* 光の強さ 100 % のときの飽和電流〔μA〕 */
  C0: 0.85,               /* 陽極の電位が 0 のとき、陽極に届く電子の割合（図 10 の形） */
  /* 金属 3 種（教科書 表 1 の仕事関数〔eV〕） */
  METALS: [
    { k: 'Cs', name: 'セシウム', sym: 'Cs', eV: 2.14, col: '#c2367f' },
    { k: 'Na', name: 'ナトリウム', sym: 'Na', eV: 2.75, col: '#1663b5' },
    { k: 'Zn', name: '亜鉛', sym: 'Zn', eV: 4.33, col: '#1f7a3f' }
  ]
};
/* hν の係数：ν〔×10¹⁴ Hz〕→ hν〔×10⁻¹⁹ J〕。6.63×10⁻³⁴ × 10¹⁴ ÷ 10⁻¹⁹ = 0.663 */
PE.H = PE.h * 1e14 / 1e-19;
PE.E = PE.e / 1e-19;      /* eV〔×10⁻¹⁹ J〕/ V = 1.60 */
function metalOf(k) { return PE.METALS.filter(function (m) { return m.k === k; })[0] || PE.METALS[1]; }
/* 仕事関数 W〔×10⁻¹⁹ J〕 */
function workW(k) { return metalOf(k).eV * PE.E; }
/* 光子のエネルギー hν〔×10⁻¹⁹ J〕 */
function photonE(nu) { return PE.H * nu; }
/* hν〔×10⁻¹⁹ J〕→ ν〔×10¹⁴ Hz〕 */
function nuOfE(E) { return E / PE.H; }
/* 限界振動数 ν₀ = W/h〔×10¹⁴ Hz〕 */
function nu0Of(k) { return workW(k) / PE.H; }
/* hν − W（負なら飛び出さない） */
function hvMinusW(nu, k) { return photonE(nu) - workW(k); }
/* 運動エネルギーの最大値 K₀〔×10⁻¹⁹ J〕（飛び出さないときは 0）。ν₀ ちょうどの丸めの誤差は 0 に */
function K0Of(nu, k) { var d = hvMinusW(nu, k); return d > 1e-12 ? d : 0; }
function emits(nu, k) { return hvMinusW(nu, k) > 1e-12; }
/* 阻止電圧 V₀ = K₀/e〔V〕 */
function V0Of(nu, k) { return K0Of(nu, k) / PE.E; }
/* K〔×10⁻¹⁹ J〕の電子の速さ〔m/s〕：K = ½mv² */
function speedOfK(K) { return Math.sqrt(2 * K * 1e-19 / PE.m); }
/* 波長〔nm〕 */
function lambdaNm(nu) { return PE.c / (nu * 1e14) * 1e9; }
function isUV(nu) { return lambdaNm(nu) < 380; }
function isIR(nu) { return lambdaNm(nu) > 750; }

/* 飛び出す電子の運動エネルギーの分け方。
   'dist'：0〜K₀ に分布（深い所の電子ほど途中でエネルギーを失う）。K = K₀(1 − √u)、u は 0〜1 の一様乱数。
          このとき K が x をこえる割合は (1 − x/K₀)²（−V₀ でなめらかに 0 になる：図 10 の形）
   'max' ：全部 K₀ */
function KofU(K0, u, mode) { return mode === 'max' ? K0 : K0 * (1 - Math.sqrt(clamp(u, 0, 1))); }
function fracAbove(x, K0, mode) {                /* 運動エネルギーが x〔×10⁻¹⁹ J〕以上の電子の割合 */
  if (K0 <= 0) return 0;
  if (x <= 0) return 1;
  if (mode === 'max') return x < K0 - 1e-12 ? 1 : 0;           /* ちょうど e|V| = K₀ のときは、陽極の直前で止まる（届かない） */
  var r = 1 - x / K0; return r > 0 ? r * r : 0;
}
/* 陽極の電位 V〔V〕で、向きなどの関係で陽極にとどく割合（電位 0 で C0、正の側で 1 に近づく）。
   負の側との境目で傾きがそろうように τ を決める（分布のとき）。全部 K₀ のときは τ = 0.35 V */
function collectG(V, V0, mode) {
  if (V <= 0) return PE.C0;
  var tau = mode === 'max' || V0 <= 0 ? 0.35 : Math.max(0.005, (1 - PE.C0) * V0 / (2 * PE.C0));
  return 1 - (1 - PE.C0) * Math.exp(-V / tau);
}
/* 飽和電流〔μA〕：光の強さ（単位時間に当たる光子の数）に比例。飛び出さないときは 0 */
function IsatOf(nu, k, inten) { return emits(nu, k) ? PE.ISAT100 * inten / 100 : 0; }
/* 光電流 I〔μA〕 */
function currentI(V, nu, k, inten, mode) {
  var Is = IsatOf(nu, k, inten); if (Is <= 0) return 0;
  var K0 = K0Of(nu, k), need = V < 0 ? -V * PE.E : 0;           /* 陽極にとどくのに要る運動エネルギー e|V| */
  return Is * collectG(V, K0 / PE.E, mode) * fracAbove(need, K0, mode);
}

/* 波長〔nm〕→ 色（可視光の範囲。外は端の色）。よく使う近似式 */
function nmToRGB(nm) {
  var r = 0, g = 0, b = 0, L = clamp(nm, 380, 750);
  if (L < 440) { r = -(L - 440) / 60; b = 1; }
  else if (L < 490) { g = (L - 440) / 50; b = 1; }
  else if (L < 510) { g = 1; b = -(L - 510) / 20; }
  else if (L < 580) { r = (L - 510) / 70; g = 1; }
  else if (L < 645) { r = 1; g = -(L - 645) / 65; }
  else { r = 1; }
  var f = L < 420 ? 0.45 + 0.55 * (L - 380) / 40 : (L > 700 ? 0.45 + 0.55 * (750 - L) / 50 : 1);
  var c = function (x) { return Math.round(255 * Math.pow(x * f, 0.8)); };
  return [c(r), c(g), c(b)];
}
/* 光（光子）の色。紫外線は灰色がかった紫（目に見えない光だと分かるように、図では点線のふちもつける） */
var UV_RGB = [124, 108, 160];
function lightRGB(nu) { return isUV(nu) ? UV_RGB.slice() : nmToRGB(lambdaNm(nu)); }
function rgbStr(c, a) { return a === undefined ? 'rgb(' + c[0] + ',' + c[1] + ',' + c[2] + ')' : 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')'; }

/* 数字の書き方 */
function f2(x) { var s = (Math.abs(x) < 0.005 ? 0 : x).toFixed(2); return s.replace('-', '−'); }
function f1(x) { var s = (Math.abs(x) < 0.05 ? 0 : x).toFixed(1); return s.replace('-', '−'); }
/* ×10⁻¹⁹ J の値 → eV */
function toEV(Ej) { return Ej / PE.E; }
