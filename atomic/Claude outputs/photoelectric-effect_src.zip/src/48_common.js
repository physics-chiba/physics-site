/* =========================================================================
   48_common.js … 2 つのセクションに共通の部品
   ・スライダー：光子のエネルギー hν ⇄ 振動数 ν（連動）・光の強さ ／ 金属 3 種のボタン ／「ν₀ に合わせる」
   ・「最大の K₀ の電子だけ見る」（運動エネルギーを 0〜K₀ に分布させるか、全部 K₀ にするか）
   ・K₀–ν グラフ（3 本の直線、ν₀ より左は破線で −W まで。傾き h・仕事関数 W・限界振動数 ν₀ の書きこみ）
   ・解説エリア（いまの値を式に入れた形。Point を、いまの状態に合わせて強調）
   ・光子・電子の粒の動き（乱数は種つき：テストで同じ動きになる）
   ========================================================================= */
'use strict';
var DEFS = {};
var PE_DEF = { metal: 'Na', nu: 7.5, I: 50 };               /* 最初の設定：ナトリウム・7.50×10¹⁴ Hz（紫の光）・光の強さ 50 % */
var KAPPA = 105;                                            /* 電子の画面上の速さ〔px/s〕＝ KAPPA × √(K〔×10⁻¹⁹ J〕)：K = ½mv² で速さは √K に比例 */
var PH_SPEED = 430;                                         /* 光子の画面上の速さ〔px/s〕 */
var PH_RATE = 9;                                            /* 光の強さ 100 % のとき 1 秒に当たる光子の数（図の上） */

/* 種つきの乱数 */
function rng(seed) { var a = seed >>> 0; return function () { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

/* ---------- 数字を式に ---------- */
function sciParts(x, sig) {
  if (!x) return { m: '0', e: 0 };
  var e = Math.floor(Math.log(Math.abs(x)) / Math.LN10 + 1e-12), m = x / Math.pow(10, e);
  m = +m.toFixed(sig - 1); if (Math.abs(m) >= 10) { m /= 10; e++; }
  return { m: m.toFixed(sig - 1), e: e };
}
function sciTex(x, sig) { var p = sciParts(x, sig || 3); return p.e === 0 ? p.m : p.m + '\\times10^{' + p.e + '}'; }
/* ×10⁻¹⁹ J の値（小数第 2 位まで意味がある）を、ふつうの指数の形で */
function jTex(v) {
  var r = Math.round(v * 100) / 100, a = Math.abs(r);
  if (a < 0.005) return '0';
  return sciTex(r * 1e-19, a >= 1 ? 3 : (a >= 0.1 ? 2 : 1));
}
function eVtxt(v) { return f2(toEV(v)) + '\\ \\mathrm{eV}'; }

/* ---------- 状態 ---------- */
function peNu(s) { return s.v.nu; }
function peQ(s) {
  var nu = s.v.nu, k = s.metal, E = photonE(nu), W = workW(k), d = E - W;
  return { nu: nu, k: k, E: E, W: W, d: d, K0: K0Of(nu, k), nu0: nu0Of(k), V0: V0Of(nu, k), em: emits(nu, k), eq: Math.abs(d) < 1e-9, I: s.v.I, uv: isUV(nu), lam: lambdaNm(nu), rgb: lightRGB(nu), mode: s.kmode };
}

/* ---------- 共通の定義（セクションの def に足す） ---------- */
function peBase(d) {
  var base = {
    mode: 'main', strobe: false, noTime: true, noStep: true, baseRate: 1,
    vars: [
      { k: 'E', label: '光子のエネルギー $h\\nu$', min: +photonE(PE.NU_MIN).toFixed(2), max: +photonE(PE.NU_MAX).toFixed(2), step: 0.01,   /* 2.65〜7.96（×10⁻¹⁹ J）。はしの ν は 4.0・12.0 にそろえる */ def: photonE(PE_DEF.nu), aria: '光子のエネルギー',
        fmt: function (x) { return f2(x) + '×10<sup>−19</sup> J<small>（' + f2(toEV(x)) + ' eV）</small>'; },
        mark: function (s) { return [{ x: workW(s.metal), label: '$W$' }].concat(d.defMarks ? [{ x: photonE(PE_DEF.nu), label: '', cls: 'defm' }] : []); } },
      { k: 'nu', label: '振動数 $\\nu$', min: PE.NU_MIN, max: PE.NU_MAX, step: PE.NU_STEP, def: PE_DEF.nu, aria: '振動数',
        fmt: function (x) { return f2(x) + '×10<sup>14</sup> Hz'; },
        mark: function (s) { return [{ x: nu0Of(s.metal), label: '$\\nu_0$' }].concat(d.defMarks ? [{ x: PE_DEF.nu, label: '', cls: 'defm' }] : []); } },
      /* 波長 λ = c/ν（2026-10-26 千葉さん）。スライダーの位置は ν と同じ（右ほど短い波長）にして、ν のスライダーと光の色の帯をはさんで上下にそろえる */
      { k: 'lam', label: '波長 $\\lambda$', min: PE.NU_MIN, max: PE.NU_MAX, step: 0.01, def: PE_DEF.nu, aria: '波長', cls: 'lamrow',
        fmt: function (x) { return Math.round(lambdaNm(x)) + ' nm'; },
        nudge: function (s, sg) { var L = Math.round(lambdaNm(s.v.nu)) - sg; s.v.nu = clamp(PE.c / (L * 1e-9) / 1e14, PE.NU_MIN, PE.NU_MAX); return true; },   /* ＋（右）は波長を 1 nm 短く */
        mark: function (s) { return [{ x: nu0Of(s.metal), label: '' }].concat(d.defMarks ? [{ x: PE_DEF.nu, label: '', cls: 'defm' }] : []); } },
      { k: 'I', label: '光の強さ', min: 0, max: 100, step: 10, def: PE_DEF.I, aria: '光の強さ', fmt: function (x) { return Math.round(x) + ' %'; },
        mark: function () { return d.defMarks ? [{ x: PE_DEF.I, label: '', cls: 'defm' }] : []; } }
    ],
    varCols: [['E', 'nu', 'lam'], ['I']],
    varColNote: [null, null],
    disp: function (s, k) { return k === 'E' ? photonE(s.v.nu) : (k === 'lam' ? s.v.nu : s.v[k]); },
    onVar: function (s, k, x) {
      if (d.onVarX) d.onVarX(s, k, x);                                  /* 値を変える前に（2 の「前の曲線」を残すため） */
      if (k === 'E') s.v.nu = clamp(nuOfE(x), PE.NU_MIN, PE.NU_MAX);    /* hν を動かしたら ν も（hν = h × ν） */
      else if (k === 'lam') s.v.nu = clamp(x, PE.NU_MIN, PE.NU_MAX);    /* λ のスライダーの位置は ν と同じ（λ = c/ν） */
      else s.v[k] = x;
      return true;
    },
    onChanged: function (s, k) { if (d.onChangedX) d.onChangedX(s, k); return 'keepT'; },
    tEnd: function () { return 1e9; },
    buttons: [
      { k: 'kmax', label: '最大の $K_0$ の電子だけ見る', cls: 'chkb kmaxb', onClick: function (s, b) {
        s.kmode = s.kmode === 'max' ? 'dist' : 'max';
        if (s.kmode === 'max' && d.onKmax) d.onKmax(s);                 /* ON にした瞬間、K₀ でない電子は消す（2026-10-26 千葉さん） */
        peSyncBtns(s); s.changed('kmode'); } }
    ]
  };
  Object.keys(base).forEach(function (key) { if (d[key] === undefined) d[key] = base[key]; });
  /* ボタンの文字の $…$ を KaTeX に */
  d.buttons.forEach(function (bd) { bd.label = mathify(bd.label); });
  var init0 = d.init;
  d.init = function (s) { s.metal = PE_DEF.metal; s.kmode = 'dist'; s.P = peParticlesNew(s); if (init0) init0(s); };
  var def0 = d.onDefaults;
  d.onDefaults = function (s) { peSyncBtns(s); if (def0) def0(s); peRenderPlots(s); };
  var res0 = d.onReset;
  d.onReset = function (s) { s.P = peParticlesNew(s); if (res0) res0(s); };
  return d;
}

/* 操作の並び（2026-10-26 千葉さん 2 回目）：
   スライダーは ▶ スタートの上。2 列に並べる（1 行目：光子のエネルギー hν ｜ 振動数 ν、2 行目：光の強さ ｜ 金属）。
   ▶ スタート・スロー・リセットの右に「すべて最初の設定に戻す」「最大の K₀ の電子だけ見る」を 1 行で。その行の右はしに「束縛の様子」（1 のみ） */
function peArrange(s) {
  var ctr = s.L.querySelector('.ctrls'), sl = ctr.querySelector('.row2.sliders');
  ctr.insertBefore(sl, ctr.firstChild);
  sl.classList.add('pesliders');
  var grid = el('div', 'pegrid'); s.varbox.innerHTML = ''; s.varbox.classList.remove('cols2'); s.varbox.appendChild(grid);
  /* 並び：1 行目 hν ｜ ν、2 行目 光の強さ ｜ λ（ν と λ の間に光の色の帯）、3 行目 金属（横いっぱい）。
     hν・ν・λ は連動するので、同じ薄い色でぬる（2026-10-26 千葉さん） */
  ['E', 'nu', 'I', 'lam'].forEach(function (k) { grid.appendChild(s.sl[k].row); });
  ['E', 'nu', 'lam'].forEach(function (k) { s.sl[k].row.classList.add('linked'); });
  /* λ の目盛り（右ほど短い波長。位置は ν と同じ） */
  var lt = el('div', 'lamtk'); lt.setAttribute('aria-hidden', 'true');
  [700, 500, 400, 300, 250].forEach(function (L) { var nu = PE.c / (L * 1e-9) / 1e14; if (nu < PE.NU_MIN || nu > PE.NU_MAX) return; var sp = el('span', '', String(L)); sp.style.left = 'calc(9px + (100% - 18px) * ' + ((nu - PE.NU_MIN) / (PE.NU_MAX - PE.NU_MIN)).toFixed(4) + ')'; lt.appendChild(sp); });
  (s.sl.lam.rw || s.sl.lam.row).appendChild(lt);
  s.sl.lam.dn.title = '波長を 1 nm 長く'; s.sl.lam.up.title = '波長を 1 nm 短く';
  var btns = ctr.querySelector('.playbar .btns'), r1b = s.row1b;
  [s.bDef, s.extra.kmax].forEach(function (b) { if (b) { b.classList.remove('gapL'); btns.appendChild(b); } });
  s.bDef.classList.add('gapL');
  if (r1b) r1b.hidden = true;
  s.btnRow = btns;
  /* 金属のボタン（2 行目の右、光の強さのとなり） */
  var col = grid, row = el('div', 'metalrow');
  row.appendChild(el('span', 'mlab', '金属'));
  var sg = el('div', 'seg metalseg'); sg.setAttribute('role', 'group'); sg.setAttribute('aria-label', '金属の種類');
  s.mBtns = PE.METALS.map(function (m) {
    var b = el('button', 'b metalb', m.name + ' <span class="msym">' + m.sym + '</span>'); b.type = 'button'; b.dataset.k = m.k;
    b.addEventListener('click', function () { s.metal = m.k; peSyncBtns(s); s.changed('metal'); });
    sg.appendChild(b); return b;
  });
  row.appendChild(sg); col.appendChild(row);
  row.appendChild(el('span', 'mW', ''));                               /* 仕事関数はボタンの右（1 行に収める） */
  s.mW = row.lastChild;
  /* 「ν₀ に合わせる」（ν のスライダーの右） */
  var nr = s.sl.nu.row, nb = el('button', 'b nu0b', mathify('$\\nu_0$ に合わせる')); nb.type = 'button'; nb.title = 'いまの金属の限界振動数 ν₀ ちょうどにする（K₀ = 0）';
  nb.addEventListener('click', function () { s.v.nu = nu0Of(s.metal); s.changed('nu'); });
  var hd = nr.querySelector('.vhead'), lb = hd && hd.querySelector('.vl');                /* 「振動数 ν」の 2 文字あと（名前の行）に置く。つまみの行は λ と同じ長さにそろえる（2026-10-26 千葉さん 5 回目） */
  if (lb) lb.insertAdjacentElement('afterend', nb); else nr.appendChild(nb); s.nu0b = nb;
  /* ν のスライダーの下に、光の色の帯（可視光は色、紫外線は「紫外線」と分かる帯） */
  var sp = el('div', 'specbar'); sp.setAttribute('aria-hidden', 'true');
  var stops = [], N = 24;
  for (var i = 0; i <= N; i++) { var nu = PE.NU_MIN + (PE.NU_MAX - PE.NU_MIN) * i / N; stops.push(rgbStr(lightRGB(nu)) + ' ' + (i / N * 100).toFixed(1) + '%'); }
  var fUV = (PE.c / 380e-9 / 1e14 - PE.NU_MIN) / (PE.NU_MAX - PE.NU_MIN);
  sp.innerHTML = '<i class="spv" style="width:' + (fUV * 100).toFixed(1) + '%;background:linear-gradient(90deg,' + stops.filter(function (q, j) { return j / N <= fUV + 1e-9; }).map(function (q) { var a = q.split(' '); return a[0] + ' ' + (parseFloat(a[1]) / fUV).toFixed(1) + '%'; }).join(',') + ')"></i>' +
    '<i class="spu" style="left:' + (fUV * 100).toFixed(1) + '%"></i><span class="spl1" style="width:' + (fUV * 100).toFixed(1) + '%">可視光</span><span class="spl2" style="left:' + (fUV * 100).toFixed(1) + '%">紫外線（目に見えない）</span>';
  (s.sl.nu.rw || nr).appendChild(sp); nr.classList.add('hasspec');
  peSyncBtns(s);
}
function peSyncBtns(s) {
  (s.mBtns || []).forEach(function (b) { var on = b.dataset.k === s.metal; b.classList.toggle('on', on); b.setAttribute('aria-pressed', on ? 'true' : 'false'); });
  var kb = s.extra && s.extra.kmax; if (kb) { var on = s.kmode === 'max'; kb.classList.toggle('on', on); kb.setAttribute('aria-pressed', on ? 'true' : 'false'); }
  if (s.mW) { var m = metalOf(s.metal); s.mW.innerHTML = mathify('仕事関数 $W = ' + jTex(workW(s.metal)) + '$ J（' + m.eV.toFixed(2) + ' eV）'); }
}

/* ---------- 光子と電子の粒 ---------- */
function peParticlesNew(s) { return { ph: [], el: [], fx: [], acc: 0, rnd: rng(20261026 + (s.def.num || 0) * 7), heat: 0, first: true, nEmit: 0, nHit: 0, nHitA: 0, nBack: 0, lit: false, time: 0 }; }

/* ---------- K₀–ν グラフ ---------- */
function peMakePlotK(s, host) {
  var p = new Plot({
    host: host, title: '$K_0$–$\\nu$ グラフ',
    H: function (W) { return clamp(Math.round(W * 0.66), 230, 330); },
    xr0: function () { return { lo: -0.6, hi: 12.8 }; },
    yr0: function () { return { lo: -8.5, hi: 6.5 }; },
    xs: function (ctx, x, y) { sym(ctx, 'ν', x - 2, y - 11, { size: 15, align: 'right', clamp: false }); label(ctx, '〔×10¹⁴ Hz〕', x + 6, y + 14, { size: 9.5, align: 'right', color: '#69717d' }); },
    ys: function (ctx, x, y) { sym(ctx, 'K', x + 6, y + 3, { size: 15, sub: '0', align: 'left', clamp: false }); label(ctx, '〔×10⁻¹⁹ J〕', x + 30, y + 3, { size: 9.5, align: 'left', color: '#69717d' }); },
    avoidY: function (P) { return X0in(P) ? [P.Y(-workW(s.metal))] : []; },
    draw: function (ctx, P) { peDrawK0(s, ctx, P); },
    over: function (ctx, P) { peOverK0(s, ctx, P); }
  });
  return p;
}
function X0in(P) { var x = P.X(0); return x >= P.R.x0 - 2 && x <= P.R.x1 + 2; }
function peDrawK0(s, ctx, P) {
  var q = peQ(s), X = P.X, Y = P.Y, x1 = P.xr.hi + 1;
  /* 3 本の直線：選んでいない金属は薄く、選んでいる金属は濃く。ν₀ より左は破線で −W まで */
  var order = PE.METALS.filter(function (m) { return m.k !== q.k; }).concat([metalOf(q.k)]);
  order.forEach(function (m) {
    var sel = m.k === q.k, W = workW(m.k), n0 = W / PE.H;
    ctx.save(); ctx.strokeStyle = m.col; ctx.globalAlpha = sel ? 1 : 0.3; ctx.lineWidth = sel ? 2.8 : 1.7;
    ctx.setLineDash([6, 4]); ctx.beginPath(); ctx.moveTo(X(0), Y(-W)); ctx.lineTo(X(n0), Y(0)); ctx.stroke();
    ctx.setLineDash([]); ctx.beginPath(); ctx.moveTo(X(n0), Y(0)); ctx.lineTo(X(x1), Y(PE.H * x1 - W)); ctx.stroke();
    ctx.restore();
  });
  /* いまの ν の点（飛び出さないときは ν 軸の上に白抜き） */
  var px = X(q.nu), py = Y(q.em || q.eq ? q.d : 0);
  dotted(ctx, px, py, px, Y(0), 'rgba(20,23,28,.45)', [3, 3]);
  if (q.em) dotted(ctx, px, py, X(0), py, 'rgba(20,23,28,.45)', [3, 3]);
  ctx.save(); ctx.beginPath(); ctx.arc(px, py, 6, 0, TAU);
  if (q.em || q.eq) { ctx.fillStyle = '#e07b18'; ctx.fill(); ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.stroke(); }
  else { ctx.fillStyle = '#fff'; ctx.fill(); ctx.strokeStyle = '#e07b18'; ctx.lineWidth = 2.4; ctx.stroke(); }
  ctx.restore();
}
function peOverK0(s, ctx, P) {
  var q = peQ(s), X = P.X, Y = P.Y, R = P.R, m = metalOf(q.k), inR = function (x, y) { return x >= R.x0 - 2 && x <= R.x1 + 2 && y >= R.y0 - 2 && y <= R.y1 + 2; };
  /* 直線の名前（右のはし） */
  PE.METALS.forEach(function (mm) {
    var sel = mm.k === q.k, xe = Math.min(P.xr.hi, PE.NU_MAX), ye = PE.H * xe - workW(mm.k), x = X(xe), y = Y(ye);
    if (inR(x, y)) label(ctx, mm.sym, x - 4, y - 10, { size: sel ? 12 : 10.5, bold: sel, color: sel ? mm.col : fade(mm.col, 0.55), align: 'right' });
  });
  /* 限界振動数 ν₀（ν 軸の下、交点の右） */
  var xn = X(q.nu0), x0 = X(0), yW = Y(-q.W), yz = Y(0), nb = null;
  if (inR(xn, yz)) {
    ctx.save(); ctx.fillStyle = m.col; ctx.beginPath(); ctx.arc(xn, yz, 3.4, 0, TAU); ctx.fill(); ctx.restore();
    nb = pill2(ctx, '限界振動数 ν₀', xn + 6, clamp(yz + 16, R.y0 + 10, R.y1 - 8), m.col, 'left');
  }
  /* 仕事関数 W：縦軸の 0 から −W まで（ν₀ の札と重なるときは下へずらす） */
  if (inR(x0, yW)) {
    ctx.save(); ctx.strokeStyle = 'rgba(20,23,28,.4)'; ctx.setLineDash([2, 3]); ctx.beginPath(); ctx.moveTo(x0, yW); ctx.lineTo(x0 + 26, yW); ctx.stroke(); ctx.restore();
    dimV(ctx, x0 + 14, clamp(yz, R.y0, R.y1), yW, '#3a414c');
    var yp = (clamp(yz, R.y0, R.y1) + yW) / 2;
    if (nb) { ctx.save(); ctx.font = '700 10.5px ' + FONT; var pw = ctx.measureText('仕事関数 W').width + 10; ctx.restore();
      if (x0 + 22 + pw > nb.x - 2 && Math.abs(yp - (nb.y + nb.h / 2)) < 20) yp = nb.y + nb.h + 12; }
    pill2(ctx, '仕事関数 W', x0 + 22, yp, '#3a414c', 'left');
    label(ctx, '−W', x0 - 6, yW, { size: 11, bold: true, color: '#3a414c', align: 'right' });
  }
  /* いまの点の値（点の左上：直線より上の空いている所） */
  var px = X(q.nu), py = Y(q.em || q.eq ? q.d : 0);
  if (inR(px, py)) {
    var t = q.em ? 'いま K₀ = ' + f2(q.K0) : (q.eq ? 'いま K₀ = 0' : '飛び出さない');
    label(ctx, t, px - 8, py - 14, { size: 10.5, bold: true, color: '#b35a00', align: 'right' });
  }
  /* 見出しの横：いまの値 */
  var g = s.plotK && s.plotK.box.querySelector('.gsel');
  if (g) { var h = mathify(q.em || q.eq ? '$K_0 = h\\nu - W$' : '$h\\nu < W$'); if (g._h !== h) { g._h = h; g.innerHTML = h; } }
}
/* 「可視光」の字：光の色で（明るい色でも読めるよう、うすい黒のふちどり） */
function peLightLabel(ctx, text, x, y, rgb, al) {
  ctx.save(); ctx.font = '800 13px ' + FONT; ctx.textBaseline = 'middle'; ctx.textAlign = al || 'left';
  ctx.lineJoin = 'round'; ctx.strokeStyle = 'rgba(255,255,255,.95)'; ctx.lineWidth = 4.5; ctx.strokeText(text, x, y);
  ctx.strokeStyle = 'rgba(30,30,40,.45)'; ctx.lineWidth = 1.1; ctx.strokeText(text, x, y);
  ctx.fillStyle = rgbStr(rgb); ctx.fillText(text, x, y); ctx.restore();
}
/* いまの設定が 10 秒続いたときの数：金属に当たる光子 p、飛び出す光電子 e（光子 1 個で電子 1 個）、陽極に届く光電子 a */
function peCount10(q, V) {
  var p = Math.round(PH_RATE * q.I / 100 * 10), e = q.em ? p : 0;
  var a = V === undefined || !q.em ? e : Math.round(e * currentI(V, q.nu, q.k, q.I, q.mode) / IsatOf(q.nu, q.k, q.I));
  return { p: p, e: e, a: a };
}
/* 分数の形の文字：右はしが xr、分数の線が y。pre は左の「現在」 */
function peFrac(ctx, xr, y, pre, num, den, size) {
  size = size || 10;
  ctx.save(); ctx.font = '700 ' + size + 'px ' + FONT;
  var w = Math.max(ctx.measureText(num).width, ctx.measureText(den).width) + 8, wp = pre ? ctx.measureText(pre).width + 8 : 0;
  var x1 = xr, x0 = xr - w, xp = x0 - wp;
  ctx.fillStyle = 'rgba(255,255,255,.88)'; rrect(ctx, xp - 5, y - size * 1.55 - 3, w + wp + 10, size * 3.1 + 6, 6); ctx.fill();
  ctx.strokeStyle = 'rgba(20,23,28,.15)'; ctx.lineWidth = 1; ctx.stroke();
  ctx.fillStyle = '#2b323c'; ctx.textBaseline = 'middle'; ctx.textAlign = 'center';
  ctx.fillText(num, (x0 + x1) / 2, y - size * 0.8); ctx.fillText(den, (x0 + x1) / 2, y + size * 0.85);
  ctx.strokeStyle = '#2b323c'; ctx.lineWidth = 1.1; ctx.beginPath(); ctx.moveTo(x0 + 2, y); ctx.lineTo(x1 - 2, y); ctx.stroke();
  if (pre) { ctx.textAlign = 'left'; ctx.fillStyle = '#b35a00'; ctx.fillText(pre, xp, y); }
  ctx.restore();
  return { x: xp - 5, w: w + wp + 10 };
}
/* 小さな札（白地・色の文字） */
function pill2(ctx, text, x, y, col, al) {
  ctx.save(); ctx.font = '700 10.5px ' + FONT; var w = ctx.measureText(text).width + 10, h = 17;
  var left = al === 'left' ? x : (al === 'right' ? x - w : x - w / 2);
  left = clamp(left, 2, Math.max(2, CVW - w - 2)); y = clamp(y, h / 2 + 2, CVH - h / 2 - 2);
  ctx.fillStyle = 'rgba(255,255,255,.93)'; ctx.strokeStyle = fade(col.length === 7 ? col : '#3a414c', 0.55); ctx.lineWidth = 1;
  rrect(ctx, left, y - h / 2, w, h, 5); ctx.fill(); ctx.stroke();
  ctx.fillStyle = col; ctx.textBaseline = 'middle'; ctx.fillText(text, left + 5, y + 0.5);
  ctx.restore();
  return { x: left, y: y - h / 2, w: w, h: h };
}
/* 縦の両矢印（寸法） */
function dimV(ctx, x, y1, y2, col) {
  if (Math.abs(y2 - y1) < 6) return;
  var sg = y2 > y1 ? 1 : -1;
  ctx.save(); ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = 1.2;
  ctx.beginPath(); ctx.moveTo(x, y1 + sg * 5); ctx.lineTo(x, y2 - sg * 5); ctx.stroke();
  [[y1, sg], [y2, -sg]].forEach(function (p) { ctx.beginPath(); ctx.moveTo(x, p[0]); ctx.lineTo(x - 3.5, p[0] + p[1] * 7); ctx.lineTo(x + 3.5, p[0] + p[1] * 7); ctx.closePath(); ctx.fill(); });
  ctx.restore();
}
function peRenderPlots(s) { (s.plots || []).forEach(function (p) { p.render(); }); }
/* K₀–ν グラフ（右の列のいちばん上のグラフ）の上のはしを、左のスライダーの箱の上のはしにそろえる（2 列のときだけ。2026-10-26 千葉さん） */
function peAlignTop(s) {
  var gh = s.R && s.R.querySelector('.pgraphs'); if (!gh || !s.cw) return;
  gh.style.marginTop = '';
  if (!s.cw.offsetParent || s.R.getBoundingClientRect().left < s.L.getBoundingClientRect().right - 10) return;   /* 1 列（右の列が下）のときはそろえない */
  var tg = s.L.querySelector('.pesliders .varbox') || s.cw;                /* スライダーの箱の上のはしにそろえる（2026-10-26 千葉さん 4 回目） */
  var d = Math.round(tg.getBoundingClientRect().top - gh.getBoundingClientRect().top);
  if (d > 0) gh.style.marginTop = d + 'px';
}
window.addEventListener('resize', function () { clearTimeout(window.__peAl); window.__peAl = setTimeout(function () { SIMS.forEach(peAlignTop); PLOTS.forEach(function (p) { p.render(); }); }, 120); });

/* ---------- 解説エリア ---------- */
function pePointHTML(q) {
  var a = q.em ? ' on' : '', b = (!q.em && !q.eq) ? ' on' : '';
  return '<div class="ptbox"><span class="ptag">Point</span>' +
    '<p class="pt' + a + '">$h\\nu > W$ → 光が弱くても電子は飛び出す。' + (a ? '<em>いまはこちら</em>' : '') + '</p>' +
    '<p class="pt' + b + '">$h\\nu < W$ → 光が強くても電子は飛び出さない。' + (b ? '<em>いまはこちら</em>' : '') + '</p>' +
    (q.eq ? '<p class="pt on eqline">$h\\nu = W$（$\\nu = \\nu_0$）→ $K_0 = 0$。電子は金属の表面までしか出られない。<em>いまはこちら</em></p>' : '') +
    '</div>';
}
function peValuesHTML(q) {
  var m = metalOf(q.k), h = '';
  h += '<p class="eqr"><span class="eql">光子のエネルギー</span>$h\\nu = ' + sciTex(PE.h, 3) + '\\times' + sciTex(q.nu * 1e14, 3) + '$ $= ' + jTex(q.E) + '$ J<span class="ev">（' + f2(toEV(q.E)) + ' eV）</span></p>';
  h += '<p class="eqr"><span class="eql">仕事関数（' + m.name + '）</span>$W = ' + jTex(q.W) + '$ J<span class="ev">（' + m.eV.toFixed(2) + ' eV）</span></p>';
  if (q.em) {
    h += '<p class="eqr hl"><span class="eql">運動エネルギーの最大値</span>$K_0 = h\\nu - W$ $= ' + jTex(q.E) + ' - ' + jTex(q.W) + '$ $= ' + jTex(q.K0) + '$ J<span class="ev">（' + f2(toEV(q.K0)) + ' eV）</span></p>';
    h += '<p class="eqr sub">$K_0 = \\dfrac{1}{2}mv^2$ より、飛び出す電子の速さの最大値は $v = ' + sciTex(speedOfK(q.K0), 2) + '$ m/s</p>';
  } else if (q.eq) {
    h += '<p class="eqr hl"><span class="eql">運動エネルギーの最大値</span>$K_0 = h\\nu - W = 0$</p>';
  } else {
    h += '<p class="eqr hl no"><span class="eql">運動エネルギーの最大値</span>$h\\nu - W = ' + jTex(q.d) + '$ J $< 0$ なので、電子は飛び出さない</p>';
  }
  h += '<p class="eqr"><span class="eql">限界振動数</span>$\\nu_0 = \\dfrac{W}{h}$ $= \\dfrac{' + jTex(q.W) + '}{' + sciTex(PE.h, 3) + '}$ $= ' + sciTex(q.nu0 * 1e14, 3) + '$ Hz</p>';
  return h;
}
/* 「現在の値」：最初はたたんでおく（2026-10-26 千葉さん）。開いたかどうかは s.valOpen に覚えておく（書きかえても閉じない） */
function peValuesBox(s, inner) {
  return '<details class="pevals"' + (s.valOpen ? ' open' : '') + '><summary><span class="qt">現在の値</span><span class="qopen">（クリックして' + (s.valOpen ? '閉じる' : '開く') + '）</span></summary>' + inner + '</details>';
}
function peBindValues(s, R) {
  var dt = R.querySelector('details.pevals'); if (!dt) return;
  dt.addEventListener('toggle', function () { s.valOpen = dt.open; var o = dt.querySelector('.qopen'); if (o) o.textContent = '（クリックして' + (dt.open ? '閉じる' : '開く') + '）'; });
}
function peEVnote() { return '<p class="evnote">※ 1 eV（電子ボルト）＝ $1.60\\times10^{-19}$ J。（　）の中は eV で表した値。</p>'; }
