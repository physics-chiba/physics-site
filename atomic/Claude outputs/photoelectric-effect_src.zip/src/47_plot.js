/* =========================================================================
   47_plot.js … ドラッグできるグラフ（skill experiment-graph-ui と同じ操作）
   ・枠の中をドラッグ＝移動、縦軸の目盛り（左）をドラッグ＝縦の拡大縮小、横軸の目盛り（下）をドラッグ＝横の拡大縮小
   ・「スケールをリセット」で最初の範囲へ。ホイールは使わない
   ・軸には矢印。目盛りはきりのいいきざみ（1・2・5×10ⁿ）で 0 を含み、薄い格子線。枠の外は描かない（clip）
   o = { host, title, H(W), xr0() / yr0() → {lo, hi}, xs: 軸の記号の描き方 fn(ctx,x,y), ys: 同,
         xunit, yunit, draw(ctx, P)（枠の中）, over(ctx, P)（枠の外も可）}
   ========================================================================= */
'use strict';
var PLOTS = [];
function niceStep(range, target) {
  var raw = range / target, p = Math.pow(10, Math.floor(Math.log(raw) / Math.LN10)), c = [1, 2, 2.5, 5, 10];
  for (var i = 0; i < c.length; i++) if (raw <= c[i] * p * 1.0001) return c[i] * p;
  return 10 * p;
}
function fmtTick(v, st) {
  var dg = Math.max(0, -Math.floor(Math.log(st) / Math.LN10 + 1e-9) + (Math.abs(st / Math.pow(10, Math.floor(Math.log(st) / Math.LN10 + 1e-9)) - 2.5) < 1e-6 ? 1 : 0));
  var s = v.toFixed(Math.min(4, dg)); if (/^-0(\.0*)?$/.test(s)) s = s.slice(1);
  return s.replace('-', '−');
}
/* データの範囲 → 0 を含むきりのいい範囲。データが端まで 0.55 目盛り以内なら 1 目盛り外へ（0 がわの端はのばさない） */
function niceRange(lo, hi, target) {
  var dlo = lo, dhi = hi;
  lo = Math.min(lo, 0); hi = Math.max(hi, 0); if (hi - lo < 1e-12) hi = lo + 1;
  var st = niceStep(hi - lo, target || 5), a = Math.floor(lo / st + 1e-9) * st, b = Math.ceil(hi / st - 1e-9) * st;
  if (dhi > 1e-12 && dhi > b - st * 0.55) b += st;
  if (dlo < -1e-12 && dlo < a + st * 0.55) a -= st;
  return { lo: a, hi: b };
}
var PPAD = { l: 44, r: 30, t: 30, b: 26 };
function Plot(o) {
  var self = this; this.o = o;
  var box = el('div', 'gbox pplot'), hd = el('div', 'ghead');
  hd.appendChild(el('span', 'gt', mathify(o.title)));
  hd.appendChild(el('span', 'gsel', ''));
  var rb = el('button', 'tiny greset', 'スケールをリセット'); rb.type = 'button'; rb.title = 'グラフの範囲を最初にもどす';
  rb.addEventListener('click', function () { self.reset(); self.render(); });
  hd.appendChild(rb);
  box.appendChild(hd);
  this.cv = el('canvas', 'gcv'); box.appendChild(this.cv);
  if (o.legend) { this.leg = el('div', 'gleg'); box.appendChild(this.leg); }
  box.appendChild(el('p', 'gtip', 'ドラッグで移動・目盛りをドラッグで拡大縮小'));
  o.host.appendChild(box); this.box = box; this.rb = rb;
  this.reset(); this.bind(); PLOTS.push(this);
}
Plot.prototype.reset = function () { this.xr = this.o.xr0(); this.yr = this.o.yr0(); this.user = false; this.rb.classList.remove('on'); };
Plot.prototype.rect = function () { return { x0: PPAD.l, x1: this.W - PPAD.r, y0: PPAD.t, y1: this.H - PPAD.b }; };
Plot.prototype.bind = function () {
  var self = this, down = null, cv = this.cv;
  cv.addEventListener('pointerdown', function (ev) {
    if (!self.W) return;
    var b = cv.getBoundingClientRect(), x = ev.clientX - b.left, y = ev.clientY - b.top, R = self.rect();
    var zone = (x < R.x0) ? 'y' : (y > R.y1 ? 'x' : 'pan');
    down = { x: ev.clientX, y: ev.clientY, zone: zone, moved: false, xr: { lo: self.xr.lo, hi: self.xr.hi }, yr: { lo: self.yr.lo, hi: self.yr.hi } };
    cv.setPointerCapture(ev.pointerId); ev.preventDefault();
  });
  cv.addEventListener('pointermove', function (ev) {
    if (!down) return;
    var dx = ev.clientX - down.x, dy = ev.clientY - down.y, R = self.rect();
    if (Math.hypot(dx, dy) > 3) down.moved = true;
    if (!down.moved) return;
    self.user = true; self.rb.classList.add('on');
    var sx = (down.xr.hi - down.xr.lo) / (R.x1 - R.x0), sy = (down.yr.hi - down.yr.lo) / (R.y1 - R.y0);
    if (down.zone === 'pan') {
      self.xr = { lo: down.xr.lo - dx * sx, hi: down.xr.hi - dx * sx };
      self.yr = { lo: down.yr.lo + dy * sy, hi: down.yr.hi + dy * sy };
    } else if (down.zone === 'x') {
      var f = Math.exp(-dx * 0.01), c = (down.xr.lo + down.xr.hi) / 2, h = (down.xr.hi - down.xr.lo) / 2 * f;
      self.xr = { lo: c - h, hi: c + h };
    } else {
      var f2 = Math.exp(dy * 0.01), c2 = (down.yr.lo + down.yr.hi) / 2, h2 = (down.yr.hi - down.yr.lo) / 2 * f2;
      self.yr = { lo: c2 - h2, hi: c2 + h2 };
    }
    self.render();
  });
  var up = function () { down = null; };
  cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
};
Plot.prototype.render = function () {
  var cv = this.cv, o = this.o; if (!cv.isConnected || !cv.offsetParent) return;
  var W = Math.max(220, Math.floor(cv.clientWidth || 300)), H = o.H ? o.H(W) : 220;
  this.W = W; this.H = H;
  var ctx = prep(cv, W, H), R = this.rect(), xr = this.xr, yr = this.yr;
  var X = function (v) { return R.x0 + (v - xr.lo) / (xr.hi - xr.lo) * (R.x1 - R.x0); };
  var Y = function (v) { return R.y1 - (v - yr.lo) / (yr.hi - yr.lo) * (R.y1 - R.y0); };
  var P = { X: X, Y: Y, R: R, W: W, H: H, xr: xr, yr: yr };
  /* 格子線と目盛り */
  var sx = niceStep(xr.hi - xr.lo, W < 300 ? 4 : 6), sy = niceStep(yr.hi - yr.lo, H < 200 ? 4 : 5);
  ctx.save(); ctx.strokeStyle = 'rgba(20,23,28,.07)'; ctx.lineWidth = 1;
  for (var gx = Math.ceil(xr.lo / sx - 1e-9) * sx; gx <= xr.hi + 1e-9; gx += sx) { var px = Math.round(X(gx)) + 0.5; ctx.beginPath(); ctx.moveTo(px, R.y0); ctx.lineTo(px, R.y1); ctx.stroke(); }
  for (var gy = Math.ceil(yr.lo / sy - 1e-9) * sy; gy <= yr.hi + 1e-9; gy += sy) { var py = Math.round(Y(gy)) + 0.5; ctx.beginPath(); ctx.moveTo(R.x0, py); ctx.lineTo(R.x1, py); ctx.stroke(); }
  ctx.restore();
  ctx.save(); ctx.fillStyle = '#5d6875'; ctx.font = '600 10.5px ' + SER; ctx.textBaseline = 'top'; ctx.textAlign = 'center';
  for (gx = Math.ceil(xr.lo / sx - 1e-9) * sx; gx <= xr.hi + 1e-9; gx += sx) { if (Math.abs(gx) < sx * 1e-6) continue; ctx.fillText(fmtTick(gx, sx), X(gx), R.y1 + 6); }
  ctx.textBaseline = 'middle'; ctx.textAlign = 'right';
  var avoid = o.avoidY ? o.avoidY(P) : [];                     /* 書きこみ（−W など）と重なる目盛りの数字は出さない */
  for (gy = Math.ceil(yr.lo / sy - 1e-9) * sy; gy <= yr.hi + 1e-9; gy += sy) {
    if (Math.abs(gy) < sy * 1e-6) continue;
    var yy = Y(gy); if (avoid.some(function (a) { return Math.abs(a - yy) < 11; })) continue;
    ctx.fillText(fmtTick(gy, sy), R.x0 - 5, yy);
  }
  ctx.restore();
  /* 軸（0 の線。範囲の外なら枠の端）と矢印 */
  var ax = clamp(Y(0), R.y0, R.y1), ay = clamp(X(0), R.x0, R.x1);
  axisArrow(ctx, R.x0 - 2, ax, R.x1 + 14, ax);
  axisArrow(ctx, ay, R.y1 + 2, ay, R.y0 - 14);
  if (X(0) >= R.x0 - 1 && X(0) <= R.x1 && Y(0) >= R.y0 && Y(0) <= R.y1 + 1) label(ctx, 'O', X(0) - 9, Y(0) + 9, { size: 11, color: '#3a414c' });
  if (o.xs) o.xs(ctx, R.x1 + 12, ax, P);
  if (o.ys) o.ys(ctx, ay, R.y0 - 14, P);
  /* 中身（枠の中だけ） */
  ctx.save(); ctx.beginPath(); ctx.rect(R.x0, R.y0 - 1, R.x1 - R.x0, R.y1 - R.y0 + 2); ctx.clip();
  if (o.draw) o.draw(ctx, P);
  ctx.restore();
  if (o.over) o.over(ctx, P);
  this.P = P;
};
window.addEventListener('resize', function () { clearTimeout(window.__prz); window.__prz = setTimeout(function () { PLOTS.forEach(function (p) { p.render(); }); }, 90); });
