/* =========================================================================
   50_sec1.js … 1　光電効果の基礎
   左上：金属の表面に光子が当たるアニメ（右に「電子のエネルギー」の図）。その下にスライダーと金属のボタン、「束縛の様子」。
   右上：K₀–ν グラフ、右下：解説エリア。
   ・光子（波のような線の小さな粒、光の色）が金属の中の電子に当たる。
     hν ≧ W：電子はすぐに飛び出す（速さは K = ½mv² から。図の上の速さは √K に比例）
     hν < W：電子は少しゆれるだけ。光子のエネルギーは金属の中で熱になる（オレンジのにじみ）
   ・光の強さ＝1 秒あたりに当たる光子の数。強くすると飛び出す電子の数が増えるが、速さ（K₀）は変わらない
   ========================================================================= */
'use strict';
var S1_ANG = 56 * Math.PI / 180;                 /* 光の向き（水平から下へ 56°。右上から左下へ進む） */
var S1_NROW = 6;                                 /* 金属の中の電子の段の数（上の 4 段に光子が当たる） */

function s1Geo(s, W, H) {
  var wide = W >= 520, dw = wide ? clamp(Math.round(W * 0.27), 150, 196) : 0;
  var aw = W - dw, ah = wide ? H : H - 178;
  var ys = Math.round(ah * 0.47);
  return { W: W, H: H, wide: wide, aw: aw, ah: ah, ys: ys, ux: -Math.cos(S1_ANG), uy: Math.sin(S1_ANG),
    xa: aw * 0.18, xb: aw * 0.66,
    ebox: wide ? { x0: aw, y0: 0, x1: W, y1: H } : { x0: 0, y0: ah, x1: W, y1: H } };
}
/* 金属の中の電子（ならびは図の大きさで決める。乱数は種つき） */
function s1Lattice(s, g) {
  var key = g.W + 'x' + g.H; if (s.lat && s.lat.key === key) return s.lat;
  var r = rng(77), els = [], ions = [], dx = 26, dy = 19;
  for (var row = 0; row < S1_NROW; row++) {
    var y = g.ys + 12 + row * dy; if (y > g.ah - 8) break;
    for (var x = 14 + (row % 2) * dx / 2; x < g.aw - 8; x += dx) {
      ions.push({ x: x + dx / 2, y: y + dy / 2 });
      els.push({ hx: x + (r() - 0.5) * 8, hy: y + (r() - 0.5) * 5, row: row, ph: r() * TAU, st: 'home', born: -9, x: 0, y: 0 });
    }
  }
  s.lat = { key: key, els: els, ions: ions };
  return s.lat;
}
function s1ResetLattice(s) { if (s.lat) s.lat.els.forEach(function (e) { e.st = 'home'; e.born = -9; delete e.K; }); }

/* 時間を進める（dt〔s〕。スローでは小さい） */
function s1Step(s, dt) {
  var g = s.g; if (!g) return;
  var P = s.P, q = peQ(s), lat = s1Lattice(s, g), tt = (P.time = (P.time || 0) + dt);
  /* 光子を出す（1 秒あたり PH_RATE × 光の強さ） */
  if (q.I > 0) {
    P.acc += dt * PH_RATE * q.I / 100;
    if (P.first) { P.acc = Math.max(P.acc, 1); P.first = false; }           /* スタートしたら、すぐに 1 個目 */
    var guard = 0;
    while (P.acc >= 1 && guard++ < 6) { P.acc -= 1; s1Spawn(s, g, lat); }
  }
  /* 光子を動かす。電子に着いたら吸収 */
  P.ph = P.ph.filter(function (p) {
    p.d += PH_SPEED * dt;
    if (p.d >= p.L) { s1Absorb(s, g, p.e, q, tt); return false; }
    return true;
  });
  /* 電子 */
  lat.els.forEach(function (e) {
    if (e.st === 'out') {
      if (e.y > g.ys) {                                                    /* 金属の中：表面まで上がる */
        e.y -= Math.max(e.v, 70) * dt;
        if (e.y <= g.ys) { e.y = g.ys; if (e.v < 2) { e.st = 'surf'; e.t0 = tt; } }
      } else { e.x += e.vx * dt; e.y += e.vy * dt; }
      if (e.y < -14 || e.x < -14 || e.x > g.aw + 14) { e.st = 'gone'; e.t0 = tt; }
    } else if (e.st === 'surf') { if (tt - e.t0 > 1.4) { e.st = 'gone'; e.t0 = tt; } }
    else if (e.st === 'shake') { if (tt - e.t0 > 1.0) e.st = 'home'; }
    else if (e.st === 'gone') { if (tt - e.t0 > 0.9) { e.st = 'home'; e.born = tt; } }   /* 電子は補われる（新しい電子がうすく出てくる） */
  });
  P.fx = P.fx.filter(function (f) { return tt - f.t0 < 1.3; });
  P.heat *= Math.exp(-dt / 3.5);
}
function s1Spawn(s, g, lat) {
  var P = s.P, c = lat.els.filter(function (e) {
    if (e.st !== 'home' || e.row > 3) return false;
    var xs = e.hx - g.ux * (e.hy - g.ys) / g.uy;                            /* この電子に向かう光子が表面に入る位置 */
    return xs >= g.xa && xs <= g.xb;
  });
  if (!c.length) return;
  var e = c[Math.floor(P.rnd() * c.length)], L = (e.hy + 30) / g.uy;
  e.st = 'target';
  P.ph.push({ e: e, L: L, d: 0, x0: e.hx - g.ux * L, y0: e.hy - g.uy * L });
}
function s1Absorb(s, g, e, q, tt) {
  var P = s.P; P.nHit++;
  if (q.d >= -1e-12) {                                                     /* hν ≧ W：その場ですぐ飛び出す */
    var u = clamp((e.row + P.rnd()) / 4, 0, 1), K = KofU(q.K0, u, q.mode), ang = (P.rnd() - 0.5) * 60 * Math.PI / 180;
    e.st = 'out'; e.K = K; e.v = KAPPA * Math.sqrt(K); e.vx = e.v * Math.sin(ang); e.vy = -e.v * Math.cos(ang);
    e.x = e.hx; e.y = e.hy; e.t0 = tt; P.nEmit++;
    P.log && P.log.push({ t: tt, em: true, K: K, st: e.st });
  } else {                                                                 /* hν < W：ゆれるだけ。エネルギーは熱に */
    e.st = 'shake'; e.t0 = tt; P.fx.push({ x: e.hx, y: e.hy, t0: tt }); P.heat += q.E;
    P.log && P.log.push({ t: tt, em: false, st: e.st });
  }
}

/* ---------- 描く ---------- */
function drawS1(s, ctx, W, H) {
  var g = s.g = s1Geo(s, W, H), q = peQ(s), lat = s1Lattice(s, g), P = s.P, tt = P.time || 0;
  var on = s.playing || P.ph.length || P.nHit;
  ctx.save(); ctx.beginPath(); ctx.rect(0, 0, g.aw, g.ah); ctx.clip();
  /* 背景（真空）と金属 */
  ctx.fillStyle = '#fbfcfe'; ctx.fillRect(0, 0, g.aw, g.ys);
  var mg = ctx.createLinearGradient(0, g.ys, 0, g.ah); mg.addColorStop(0, '#f2d4a6'); mg.addColorStop(1, '#e6bf86');
  ctx.fillStyle = mg; ctx.fillRect(0, g.ys, g.aw, g.ah - g.ys);
  if (P.heat > 0.05) { ctx.fillStyle = 'rgba(232,96,40,' + Math.min(0.22, P.heat * 0.006).toFixed(3) + ')'; ctx.fillRect(0, g.ys, g.aw, g.ah - g.ys); }
  ctx.strokeStyle = '#3a2a14'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(0, g.ys); ctx.lineTo(g.aw, g.ys); ctx.stroke();
  /* 原子核（＋の小さな丸） */
  lat.ions.forEach(function (o) { ctx.beginPath(); ctx.arc(o.x, o.y, 4.2, 0, TAU); ctx.fillStyle = 'rgba(80,52,20,.18)'; ctx.fill(); });
  /* 光の帯 */
  var rgb = q.rgb;
  var ta = { x: g.xa + g.ux * ((-40 - g.ys) / g.uy), y: -40 }, tb = { x: g.xb + g.ux * ((-40 - g.ys) / g.uy), y: -40 };
  ctx.save(); ctx.beginPath(); ctx.moveTo(ta.x, ta.y); ctx.lineTo(tb.x, tb.y); ctx.lineTo(g.xb, g.ys); ctx.lineTo(g.xa, g.ys); ctx.closePath();
  ctx.fillStyle = rgbStr(rgb, on ? (q.uv ? 0.10 : 0.16) * (0.35 + 0.65 * q.I / 100) : 0.05); ctx.fill();
  if (q.uv) { ctx.setLineDash([5, 5]); ctx.strokeStyle = rgbStr(rgb, 0.55); ctx.lineWidth = 1; ctx.stroke(); }
  ctx.restore();
  /* 熱（オレンジのにじみ） */
  P.fx.forEach(function (f) {
    var a = 1 - (tt - f.t0) / 1.3, r = 8 + 22 * (1 - a);
    var gr = ctx.createRadialGradient(f.x, f.y, 1, f.x, f.y, r); gr.addColorStop(0, 'rgba(240,110,30,' + (0.55 * a).toFixed(3) + ')'); gr.addColorStop(1, 'rgba(240,110,30,0)');
    ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(f.x, f.y, r, 0, TAU); ctx.fill();
    if (a > 0.25) label(ctx, '熱', f.x + 12, f.y - 12 - 8 * (1 - a), { size: 11, bold: true, color: 'rgba(196,72,10,' + a.toFixed(2) + ')', haloColor: 'rgba(255,240,220,.7)' });
  });
  /* 電子 */
  lat.els.forEach(function (e) {
    var x = e.hx, y = e.hy, al = 1, hot = false;
    if (e.st === 'home' || e.st === 'target') { x += 1.4 * Math.sin(3.1 * tt + e.ph); y += 1.0 * Math.cos(2.3 * tt + e.ph * 1.7); al = clamp((tt - e.born) / 0.6, 0.15, 1); }
    else if (e.st === 'shake') { var a = tt - e.t0; x += 5 * Math.sin(TAU * 7 * a) * Math.exp(-3 * a); }
    else if (e.st === 'out') { x = e.x; y = e.y; hot = true; }
    else if (e.st === 'surf') { x = e.hx; y = g.ys - 1; al = clamp(1 - (tt - e.t0) / 1.4, 0, 1); hot = true; }
    else return;
    electronDot(ctx, x, y, hot ? 4.6 : 3.8, al, hot);
  });
  /* 飛び出した電子の速度の矢印（電子の上に少し離して） */
  lat.els.forEach(function (e) {
    if (e.st !== 'out' || e.y >= g.ys - 2 || e.v < 2) return;
    var L = clamp(0.12 * e.v, 7, 44), ux = e.vx / e.v, uy = e.vy / e.v;
    arrow(ctx, e.x, e.y - 10, e.x + ux * L, e.y - 10 + uy * L, 'vel');
  });
  /* 光子 */
  P.ph.forEach(function (p) {
    var x = p.x0 + g.ux * p.d, y = p.y0 + g.uy * p.d;
    photonWave(ctx, x, y, g.ux, g.uy, 30, rgbStr(q.uv ? [92, 76, 140] : q.rgb), y > g.ys ? 0.55 : 1, q.uv);
  });
  ctx.restore();
  /* 文字 */
  var lab = q.uv ? '紫外線（目に見えない光）' : '光';
  label(ctx, lab, Math.min(g.aw - 10, tb.x + g.ux * -60), 20, { size: 12.5, bold: true, color: q.uv ? '#5c4c8c' : '#3a414c', align: 'right' });
  label(ctx, '金属', 12, g.ah - 14, { size: 12, bold: true, color: '#5a3d14', align: 'left' });
  label(ctx, '真空', 12, 16, { size: 11, color: '#8a939d', align: 'left' });
  s1Legend(ctx, g, q);
  if (!on) label(ctx, '▶ スタートで光を当てる', g.aw / 2, g.ys / 2 + 10, { size: 13, bold: true, color: '#b35a00' });
  if (q.I === 0 && on) label(ctx, '光の強さが 0（光子が来ない）', g.aw / 2, g.ys / 2 + 10, { size: 12.5, bold: true, color: '#69717d' });
  /* 電子のエネルギーの図 */
  s1Energy(ctx, g.ebox, q, g.wide);
}
function s1Legend(ctx, g, q) {
  var x = 12, y = g.ys - 16;
  if (g.aw < 380) return;
  electronDot(ctx, x + 4, y, 4, 1, true); label(ctx, '電子', x + 13, y, { size: 10.5, align: 'left', color: '#3a414c' });
  photonWave(ctx, x + 78, y, 1, 0, 26, rgbStr(q.uv ? [92, 76, 140] : q.rgb), 1, q.uv); label(ctx, '光子（1 個のエネルギー hν）', x + 84, y, { size: 10.5, align: 'left', color: '#3a414c' });
}
/* 電子のエネルギーの図（教科書の図と同じ形：hν を受け取り、W を使って外へ。残りが K₀） */
function s1Energy(ctx, b, q, wide) {
  var w = b.x1 - b.x0, h = b.y1 - b.y0;
  ctx.save();
  ctx.fillStyle = '#faf8f3'; ctx.fillRect(b.x0, b.y0, w, h);
  ctx.strokeStyle = 'rgba(20,23,28,.14)'; ctx.lineWidth = 1; ctx.beginPath();
  if (wide) { ctx.moveTo(b.x0 + 0.5, b.y0); ctx.lineTo(b.x0 + 0.5, b.y1); } else { ctx.moveTo(b.x0, b.y0 + 0.5); ctx.lineTo(b.x1, b.y0 + 0.5); }
  ctx.stroke(); ctx.restore();
  label(ctx, '電子のエネルギー', b.x0 + w / 2, b.y0 + 15, { size: 11.5, bold: true, color: '#3a414c' });
  var top = b.y0 + 40, yb = b.y1 - 30, sc = (yb - top) / 10.8, yv = yb - q.W * sc, yE = yb - q.E * sc;
  var xa = b.x0 + Math.max(w * 0.46, 70), xw = b.x0 + Math.max(w * 0.74, 120);
  if (!wide) { xa = b.x0 + w * 0.42; xw = b.x0 + w * 0.6; }
  /* 金属の中（灰色）と、金属の外の境（破線）。名前は左のはし */
  ctx.save(); ctx.fillStyle = 'rgba(120,128,140,.13)'; ctx.fillRect(b.x0 + 8, yv, w - 16, yb - yv + 8); ctx.restore();
  dotted(ctx, b.x0 + 8, yv, b.x1 - 8, yv, 'rgba(20,23,28,.55)', [5, 4]);
  label(ctx, '金属の外', b.x0 + 12, yv - 9, { size: 9.5, color: '#69717d', align: 'left' });
  label(ctx, '金属の中', b.x0 + 12, yv + 10, { size: 9.5, color: '#69717d', align: 'left' });
  electronDot(ctx, (xa + xw) / 2, yb, 4.2, 1, false);
  label(ctx, '自由電子', (xa + xw) / 2, yb + 15, { size: 10, color: '#3a414c' });
  /* hν（オレンジ） */
  eArrow(ctx, xa, yb - 2, xa, yE, '#e07b18', 5);
  sym(ctx, 'hν', xa - 8, (yb + yE) / 2, { size: 15, color: '#c0610a', align: 'right' });
  /* W（灰色）と K₀（青） */
  eArrow(ctx, xw, yb - 2, xw, yv + 1, '#6b7480', 5);
  sym(ctx, 'W', xw + 9, (yb + yv) / 2, { size: 15, color: '#4a525d', align: 'left' });
  if (q.d > 1e-9) {
    eArrow(ctx, xw, yv - 1, xw, yE, '#1663b5', 5);
    if (yv - yE > 14) sym(ctx, 'K', xw + 9, (yv + yE) / 2, { size: 15, sub: '0', color: '#1663b5', align: 'left' });
    dotted(ctx, xa, yE, xw + 4, yE, 'rgba(224,123,24,.6)', [3, 3]);
    label(ctx, '外へ飛び出せる', (xa + xw) / 2, Math.min(yE, yv) - 16, { size: 10.5, bold: true, color: '#1663b5' });
  } else if (q.eq) {
    label(ctx, 'ちょうど K₀ = 0', (xa + xw) / 2, yv - 16, { size: 10.5, bold: true, color: '#1663b5' });
  } else {
    dotted(ctx, xa, yE, xw + 4, yE, 'rgba(224,123,24,.6)', [3, 3]);
    label(ctx, 'W に足りない', (xa + xw) / 2, yv - 30, { size: 10.5, bold: true, color: '#c0392b' });
    label(ctx, '→ 熱になる', (xa + xw) / 2, yv - 15, { size: 10.5, bold: true, color: '#c0392b' });
  }
}

DEFS.s1 = peBase({
  id: 's1', num: 1, title: '光電効果の基礎',
  desc: '金属の表面に光を当てる。光は、エネルギー $h\\nu$ をもつ粒（光子）の集まりである。光子 1 個が金属の中の電子 1 個にエネルギー $h\\nu$ を与え、それが仕事関数 $W$ より大きいと、電子は金属の外へ飛び出す（光電子）。<span class="todo">振動数 $\\nu$ を変えて、電子が飛び出す／飛び出さないの境目（限界振動数 $\\nu_0$）を探そう。光の強さを変えると、何が変わって何が変わらないかも確かめよう。</span>',
  /* 横置きのスマホ（高さ 390 など）でも図が 1 画面に入るように、画面の高さでおさえる */
  height: function (s, w) { return w >= 520 ? Math.round(clamp(Math.min(w * 0.6, innerHeight - 70), 300, 420)) : Math.round(w * 0.82) + 178; },
  afterBuild: function (s) {
    peArrange(s);
    /* 「束縛の様子」スイッチ（スライダーの下） */
    var bb = el('button', 'b chkb bindb', '束縛の様子'); bb.type = 'button'; bb.setAttribute('aria-pressed', 'false');
    bb.title = '金属の中の電子が、どのように束縛されているかを見る';
    s.btnRow.appendChild(bb);                                       /* ▶ スタートの行の右はし */
    var bx = el('div', 'bindbox'); bx.hidden = true; s.L.appendChild(bx); s.bindBox = bx; s.bindBtn = bb;
    bb.addEventListener('click', function () { s1Bind(s, bx.hidden); });
    /* 右：K₀–ν グラフ と 解説 */
    s.R.innerHTML = '';
    var gh = el('div', 'pgraphs'); s.R.appendChild(gh);
    s.plotK = peMakePlotK(s, gh); s.plots = [s.plotK];
    s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);
  },
  onDefaults: function (s) { s1Bind(s, false); s1ResetLattice(s); },
  onReset: function (s) { s1ResetLattice(s); },
  beforeStep: function (s, t0, t1) { s1Step(s, t1 - t0); },
  draw: function (s, ctx, W, H) { drawS1(s, ctx, W, H); },
  msg: function (s) {
    var q = peQ(s);
    if (q.em) return '$h\\nu > W$：光子が当たった電子は、<b>すぐに</b>飛び出す（光が弱くても）。飛び出す電子の運動エネルギーは最大で $K_0 = h\\nu - W$。';
    if (q.eq) return '$h\\nu = W$（$\\nu = \\nu_0$）：電子は表面までは出られるが、運動エネルギーは $0$。';
    return '$h\\nu < W$：光をどれだけ強くしても、電子は飛び出さない。電子は少しゆれるだけで、光子のエネルギーは金属の中で<b>熱</b>になる。';
  },
  right: function (s, R) {
    var q = peQ(s);
    R.innerHTML = mathify('<div class="qcard pex"><p class="qt">いまの値</p>' + peValuesHTML(q) + pePointHTML(q) +
      '<p class="qnote">光の強さ＝1 秒あたりに当たる光子の数。強くすると、飛び出す電子の<b>数</b>が増える。光子 1 個のエネルギー $h\\nu$ は変わらないので、$K_0$ は変わらない。' +
      (s.kmode === 'max' ? '<br>（いまは、どの電子も最大の $K_0$ で飛び出すとして描いている）' : '<br>（金属の深い所の電子は、外へ出るまでにエネルギーの一部を失うので、$K_0$ より遅く飛び出す）') + '</p>' +
      peEVnote() + '</div>');
    peRenderPlots(s);
  }
});

/* ---------- 「束縛の様子」：2 つの図を並べる（もう一度押すと閉じる） ---------- */
function s1Bind(s, open) {
  var bx = s.bindBox, bb = s.bindBtn; if (!bx) return;
  bx.hidden = !open; bb.classList.toggle('on', open); bb.setAttribute('aria-pressed', open ? 'true' : 'false');
  if (open) {
    if (!bx.firstChild) {
      bx.innerHTML = '<div class="bindcells"><figure><canvas></canvas><figcaption>原子核のまわりを回る電子として見ると</figcaption></figure>' +
        '<figure><canvas></canvas><figcaption>ばねのように束縛された電子として見ると</figcaption></figure></div>' +
        '<p class="bindcap">' + mathify('どちらの見方でも、電子は金属に<b>束縛</b>されている。電子が金属の外へ出るには、束縛を切るだけのエネルギーが要る。その最小値が<b>仕事関数 $W$</b>（金属ごとに決まっている）。光子 1 個のエネルギー $h\\nu$ が $W$ より大きいときだけ、電子は外へ飛び出せる。') + '</p>';
    }
    s.bindT0 = performance.now();
    s1DrawBind(bx, 0.8);                                           /* 開いたらすぐに 1 枚描く（画面の外でも絵がある） */
    if (s.bindLoop) return;
    s.bindLoop = true;
    var loop = function (ts) {
      if (bx.hidden) { s.bindLoop = false; return; }
      var r = bx.getBoundingClientRect();
      if (r.bottom > 0 && r.top < innerHeight) s1DrawBind(bx, 0.8 + (ts - s.bindT0) / 1000);   /* 見えているときだけ動かす */
      requestAnimationFrame(loop);
    };
    requestAnimationFrame(loop);
  }
}
function s1DrawBind(bx, t) {
  var cvs = bx.querySelectorAll('canvas');
  [s1BindAtoms, s1BindSprings].forEach(function (f, i) {
    var cv = cvs[i], W = Math.max(150, Math.floor(cv.clientWidth || 260)), H = Math.round(clamp(W * 0.72, 150, 230));
    var ctx = prep(cv, W, H); f(ctx, W, H, t);
  });
}
/* 左：原子核のまわりを回る電子。上の 1 個が光子を受けて外へ（赤い曲がった矢印） */
function s1BindAtoms(ctx, W, H, t) {
  var ys = H * 0.42, r0 = Math.min(W / 9.5, 20);
  ctx.fillStyle = '#f2d4a6'; ctx.fillRect(0, ys, W, H - ys);
  ctx.strokeStyle = '#3a2a14'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(0, ys); ctx.lineTo(W, ys); ctx.stroke();
  var n = Math.max(3, Math.floor(W / (2.3 * r0))), dx = W / n;
  for (var row = 0; row < 2; row++) for (var i = 0; i < n; i++) {
    var cx = dx * (i + 0.5) + (row ? dx / 2 : 0), cy = ys + r0 + 6 + row * (2 * r0 + 6); if (cx > W - 4 || cy > H - 4) continue;
    ctx.strokeStyle = 'rgba(58,42,20,.55)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(cx, cy, r0, 0, TAU); ctx.stroke();
    ctx.fillStyle = '#2b2b2b'; ctx.beginPath(); ctx.arc(cx, cy, 3.4, 0, TAU); ctx.fill();
    var a = t * 2.2 + i * 1.3 + row;
    electronDot(ctx, cx + r0 * Math.cos(a), cy + r0 * Math.sin(a), 3, 1, false);
  }
  /* 外へ出ていく電子 */
  var ex = dx * 1.5, k = (t % 2.6) / 2.6, p0 = { x: ex, y: ys + 6 }, p1 = { x: ex - dx * 0.9, y: ys - H * 0.3 };
  ctx.save(); ctx.strokeStyle = '#d1352b'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(p0.x, p0.y); ctx.quadraticCurveTo(ex + 6, ys - H * 0.28, p1.x + 6, p1.y + 4); ctx.stroke(); ctx.restore();
  eArrow(ctx, p1.x + 12, p1.y + 4, p1.x + 2, p1.y + 2, '#d1352b', 1.6);
  electronDot(ctx, p0.x + (p1.x - p0.x) * k, p0.y + (p1.y - p0.y) * k - Math.sin(Math.PI * k) * 14, 3.4, 1, true);
  photonWave(ctx, ex + 8, ys - 4, -0.55, 0.83, 26, '#3a7bd5', 1, false);
  label(ctx, '電子', p1.x - 2, p1.y - 12, { size: 10.5, align: 'center' });
  label(ctx, '原子核', 30, H - 10, { size: 10, align: 'center', color: '#3a2a14' });
}
/* 右：ばねのように束縛された電子。光子を受けた 1 個は束縛が切れて外へ */
function s1BindSprings(ctx, W, H, t) {
  var ys = H * 0.42;
  ctx.fillStyle = '#f2d4a6'; ctx.fillRect(0, ys, W, H - ys);
  ctx.strokeStyle = '#3a2a14'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(0, ys); ctx.lineTo(W, ys); ctx.stroke();
  var nuc = [{ x: W * 0.22, y: ys + (H - ys) * 0.6 }, { x: W * 0.74, y: ys + (H - ys) * 0.55 }];
  nuc.forEach(function (n) { ctx.fillStyle = '#1e1e1e'; ctx.beginPath(); ctx.arc(n.x, n.y, 7, 0, TAU); ctx.fill(); });
  var zig = function (x1, y1, x2, y2) {
    var L = Math.hypot(x2 - x1, y2 - y1), ux = (x2 - x1) / L, uy = (y2 - y1) / L, N = 9;
    ctx.save(); ctx.strokeStyle = '#6b6f75'; ctx.lineWidth = 1.1; ctx.beginPath(); ctx.moveTo(x1, y1);
    for (var i = 1; i < N * 2; i++) { var s = i / (N * 2), w = 3.2 * Math.sin(i * Math.PI / 2 * 2) ; ctx.lineTo(x1 + ux * L * s - uy * w * (i % 2 ? 1 : -1), y1 + uy * L * s + ux * w * (i % 2 ? 1 : -1)); }
    ctx.lineTo(x2, y2); ctx.stroke(); ctx.restore();
  };
  var els = [{ n: 0, a: -1.9, r: 34 }, { n: 0, a: -0.3, r: 32 }, { n: 0, a: 2.6, r: 30 }, { n: 1, a: -1.2, r: 34 }, { n: 1, a: 0.6, r: 32 }, { n: 1, a: 3.6, r: 30 }];
  els.forEach(function (e, i) {
    var n = nuc[e.n], j = Math.sin(t * 5 + i) * 2, x = n.x + (e.r + j) * Math.cos(e.a), y = n.y + (e.r + j) * Math.sin(e.a);
    if (y < ys + 4) y = ys + 4;
    zig(n.x, n.y, x, y); electronDot(ctx, x, y, 3.2, 1, false);
  });
  /* 束縛が切れて外へ */
  var k = (t % 2.6) / 2.6, sx = W * 0.5, sy = ys + 10, ex = W * 0.4, ey = ys - H * 0.32;
  zig(nuc[0].x, nuc[0].y, nuc[0].x + 18, nuc[0].y - 26);
  ctx.save(); ctx.strokeStyle = '#6b6f75'; ctx.lineWidth = 1.1; ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(sx - 6, sy + 10); ctx.stroke(); ctx.restore();
  ctx.save(); ctx.fillStyle = '#ffd34d'; ctx.beginPath(); for (var i = 0; i < 10; i++) { var a = i * Math.PI / 5, rr = i % 2 ? 4 : 9; ctx.lineTo(sx + rr * Math.cos(a), sy - 8 + rr * Math.sin(a)); } ctx.closePath(); ctx.fill(); ctx.restore();
  electronDot(ctx, sx + (ex - sx) * k, sy + (ey - sy) * k, 3.4, 1, true);
  photonWave(ctx, sx + 6, sy - 10, -0.5, 0.86, 28, '#3a7bd5', 1, false);
  label(ctx, '束縛が切れて外に飛び出す電子', clamp(ex, 70, W - 70), ey - 12, { size: 10, align: 'center' });
  label(ctx, '束縛されている電子', W * 0.5, H - 10, { size: 10, align: 'center', color: '#3a2a14' });
}
