/* =========================================================================
   50_sec1.js … 1　光電効果の基礎
   上からスライダー → ▶ スタートの行 → アニメ（右に「電子のエネルギー」の図）→ ひとこと → 自由電子の束縛の様子（いつも表示）。
   右上：K₀–ν グラフ（上のはしをアニメにそろえる）、右下：解説エリア。
   ・光子（波のような線の小さな粒、光の色）が金属の中の電子に当たる。
     hν ≧ W：電子はすぐに飛び出す（速さは K = ½mv² から。図の上の速さは √K に比例）
     hν < W：電子は少しゆれるだけ。光子のエネルギーは金属の中で熱になる（オレンジのにじみ）
   ・光の強さ＝1 秒あたりに当たる光子の数。強くすると飛び出す電子の数が増えるが、速さ（K₀）は変わらない
     光の当たる幅も光の強さに比例させる（幅あたりの光子の数は同じ。2026-10-26 千葉さん）
   ========================================================================= */
'use strict';
var S1_ANG = 56 * Math.PI / 180;                 /* 光の向き（水平から下へ 56°。右上から左下へ進む） */
var S1_NROW = 6;                                 /* 金属の中の電子の段の数（上の 4 段に光子が当たる） */

function s1Geo(s, W, H) {
  var wide = W >= 520, dw = wide ? clamp(Math.round(W * 0.27), 150, 196) : 0;
  var aw = W - dw, ah = wide ? H : H - 178;
  var ys = Math.round(ah * 0.47), xc = aw * 0.42, hw = aw * 0.24 * clamp(s.v.I, 0, 100) / 100;   /* 光の当たる幅は光の強さに比例 */
  return { W: W, H: H, wide: wide, aw: aw, ah: ah, ys: ys, ux: -Math.cos(S1_ANG), uy: Math.sin(S1_ANG),
    xa: xc - hw, xb: xc + hw, xc: xc,
    ebox: wide ? { x0: aw, y0: 0, x1: W, y1: H } : { x0: 0, y0: ah, x1: W, y1: H } };
}
/* 金属の中の電子（ならびは図の大きさで決める。乱数は種つき） */
function s1Lattice(s, g) {
  var key = g.W + 'x' + g.H; if (s.lat && s.lat.key === key) return s.lat;
  var r = rng(77), els = [], ions = [], dx = 26, dy = 19;
  for (var row = 0; row < S1_NROW; row++) {
    var y = g.ys + 12 + row * dy; if (y > g.ah - 8) break;
    for (var x = 14 + (row % 2) * dx / 2; x < g.aw - 8; x += dx) {
      ions.push({ x: x + dx / 2, y: y + dy / 2 });
      els.push({ hx: x + (r() - 0.5) * 8, hy: y + (r() - 0.5) * 5, row: row, ph: r() * TAU, st: 'home', born: -9, x: 0, y: 0 });
    }
  }
  s.lat = { key: key, els: els, ions: ions };
  return s.lat;
}
function s1ResetLattice(s) { if (s.lat) s.lat.els.forEach(function (e) { e.st = 'home'; e.born = -9; delete e.K; }); }

/* 時間を進める（dt〔s〕。スローでは小さい） */
function s1Step(s, dt) {
  var g = s.g; if (!g) return;
  var P = s.P, q = peQ(s), lat = s1Lattice(s, g), tt = (P.time = (P.time || 0) + dt);
  /* 光子を出す（1 秒あたり PH_RATE × 光の強さ） */
  if (q.I > 0) {
    P.acc += dt * PH_RATE * q.I / 100;
    if (P.first) { P.acc = Math.max(P.acc, 1); P.first = false; }           /* スタートしたら、すぐに 1 個目 */
    var guard = 0;
    while (P.acc >= 1 && guard++ < 6) { P.acc -= 1; s1Spawn(s, g, lat); }
  }
  /* 光子を動かす。電子に着いたら吸収 */
  P.ph = P.ph.filter(function (p) {
    p.d += PH_SPEED * dt;
    if (p.d >= p.L) { s1Absorb(s, g, p.e, q, tt); return false; }
    return true;
  });
  /* 電子 */
  lat.els.forEach(function (e) {
    if (e.st === 'out') {
      if (e.y > g.ys) {                                                    /* 金属の中：表面まで上がる */
        e.y -= Math.max(e.v, 70) * dt;
        if (e.y <= g.ys) { e.y = g.ys; if (e.v < 2) { e.st = 'surf'; e.t0 = tt; } }
      } else { e.x += e.vx * dt; e.y += e.vy * dt; }
      if (e.y < -14 || e.x < -14 || e.x > g.aw + 14) { e.st = 'gone'; e.t0 = tt; }
    } else if (e.st === 'surf') { if (tt - e.t0 > 1.4) { e.st = 'gone'; e.t0 = tt; } }
    else if (e.st === 'shake') { if (tt - e.t0 > 1.0) e.st = 'home'; }
    else if (e.st === 'gone') { if (tt - e.t0 > 0.9) { e.st = 'home'; e.born = tt; } }   /* 電子は補われる（新しい電子がうすく出てくる） */
  });
  P.fx = P.fx.filter(function (f) { return tt - f.t0 < 1.3; });
  P.heat *= Math.exp(-dt / 3.5);
}
function s1Spawn(s, g, lat) {
  var P = s.P, c = lat.els.filter(function (e) {
    if (e.st !== 'home' || e.row > 3) return false;
    var xs = e.hx - g.ux * (e.hy - g.ys) / g.uy;                            /* この電子に向かう光子が表面に入る位置 */
    return xs >= g.xa && xs <= g.xb;
  });
  if (!c.length) {                                                         /* 幅がせまくて電子がないときは、まん中にいちばん近い電子 */
    var best = null, bd = 1e9;
    lat.els.forEach(function (e) { if (e.st !== 'home' || e.row > 3) return; var d = Math.abs(e.hx - g.ux * (e.hy - g.ys) / g.uy - g.xc); if (d < bd) { bd = d; best = e; } });
    if (!best) return; c = [best];
  }
  var e = c[Math.floor(P.rnd() * c.length)], L = (e.hy + 30) / g.uy;
  e.st = 'target';
  P.ph.push({ e: e, L: L, d: 0, x0: e.hx - g.ux * L, y0: e.hy - g.uy * L });
}
function s1Absorb(s, g, e, q, tt) {
  var P = s.P; P.nHit++;
  if (q.d >= -1e-12) {                                                     /* hν ≧ W：その場ですぐ飛び出す */
    var u = clamp((e.row + P.rnd()) / 4, 0, 1), K = KofU(q.K0, u, q.mode), ang = (P.rnd() - 0.5) * 60 * Math.PI / 180;
    e.st = 'out'; e.K = K; e.v = KAPPA * Math.sqrt(K); e.vx = e.v * Math.sin(ang); e.vy = -e.v * Math.cos(ang);
    e.x = e.hx; e.y = e.hy; e.t0 = tt; P.nEmit++;
    P.log && P.log.push({ t: tt, em: true, K: K, st: e.st });
  } else {                                                                 /* hν < W：ゆれるだけ。エネルギーは熱に */
    e.st = 'shake'; e.t0 = tt; P.fx.push({ x: e.hx, y: e.hy, t0: tt }); P.heat += q.E;
    P.log && P.log.push({ t: tt, em: false, st: e.st });
  }
}

/* ---------- 描く ---------- */
function drawS1(s, ctx, W, H) {
  var g = s.g = s1Geo(s, W, H), q = peQ(s), lat = s1Lattice(s, g), P = s.P, tt = P.time || 0;
  var on = s.playing || P.ph.length || P.nHit;
  ctx.save(); ctx.beginPath(); ctx.rect(0, 0, g.aw, g.ah); ctx.clip();
  /* 背景（真空）と金属 */
  ctx.fillStyle = '#fbfcfe'; ctx.fillRect(0, 0, g.aw, g.ys);
  var mg = ctx.createLinearGradient(0, g.ys, 0, g.ah); mg.addColorStop(0, '#f2d4a6'); mg.addColorStop(1, '#e6bf86');
  ctx.fillStyle = mg; ctx.fillRect(0, g.ys, g.aw, g.ah - g.ys);
  if (P.heat > 0.05) { ctx.fillStyle = 'rgba(232,96,40,' + Math.min(0.22, P.heat * 0.006).toFixed(3) + ')'; ctx.fillRect(0, g.ys, g.aw, g.ah - g.ys); }
  ctx.strokeStyle = '#3a2a14'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(0, g.ys); ctx.lineTo(g.aw, g.ys); ctx.stroke();
  /* 原子核（＋の小さな丸） */
  lat.ions.forEach(function (o) { ctx.beginPath(); ctx.arc(o.x, o.y, 4.2, 0, TAU); ctx.fillStyle = 'rgba(80,52,20,.18)'; ctx.fill(); });
  /* 光の帯 */
  var rgb = q.rgb;
  var ta = { x: g.xa + g.ux * ((-40 - g.ys) / g.uy), y: -40 }, tb = { x: g.xb + g.ux * ((-40 - g.ys) / g.uy), y: -40 };
  ctx.save(); ctx.beginPath(); ctx.moveTo(ta.x, ta.y); ctx.lineTo(tb.x, tb.y); ctx.lineTo(g.xb, g.ys); ctx.lineTo(g.xa, g.ys); ctx.closePath();
  ctx.fillStyle = rgbStr(rgb, on ? (q.uv ? 0.11 : 0.17) : 0.06); ctx.fill();     /* 光の強さは幅で表す（濃さは同じ） */
  if (q.uv) { ctx.setLineDash([5, 5]); ctx.strokeStyle = rgbStr(rgb, 0.55); ctx.lineWidth = 1; ctx.stroke(); }
  ctx.restore();
  /* 熱（オレンジのにじみ） */
  P.fx.forEach(function (f) {
    var a = 1 - (tt - f.t0) / 1.3, r = 8 + 22 * (1 - a);
    var gr = ctx.createRadialGradient(f.x, f.y, 1, f.x, f.y, r); gr.addColorStop(0, 'rgba(240,110,30,' + (0.55 * a).toFixed(3) + ')'); gr.addColorStop(1, 'rgba(240,110,30,0)');
    ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(f.x, f.y, r, 0, TAU); ctx.fill();
    if (a > 0.25) label(ctx, '熱', f.x + 12, f.y - 12 - 8 * (1 - a), { size: 11, bold: true, color: 'rgba(196,72,10,' + a.toFixed(2) + ')', haloColor: 'rgba(255,240,220,.7)' });
  });
  /* 電子 */
  lat.els.forEach(function (e) {
    var x = e.hx, y = e.hy, al = 1, hot = false;
    if (e.st === 'home' || e.st === 'target') { x += 1.4 * Math.sin(3.1 * tt + e.ph); y += 1.0 * Math.cos(2.3 * tt + e.ph * 1.7); al = clamp((tt - e.born) / 0.6, 0.15, 1); }
    else if (e.st === 'shake') { var a = tt - e.t0; x += 5 * Math.sin(TAU * 7 * a) * Math.exp(-3 * a); }
    else if (e.st === 'out') { x = e.x; y = e.y; hot = true; }
    else if (e.st === 'surf') { x = e.hx; y = g.ys - 1; al = clamp(1 - (tt - e.t0) / 1.4, 0, 1); hot = true; }
    else return;
    electronDot(ctx, x, y, hot ? 4.6 : 3.8, al, hot);
  });
  /* 飛び出した電子の速度の矢印（電子の上に少し離して） */
  lat.els.forEach(function (e) {
    if (e.st !== 'out' || e.y >= g.ys - 2 || e.v < 2) return;
    var L = clamp(0.12 * e.v, 7, 44), ux = e.vx / e.v, uy = e.vy / e.v;
    arrow(ctx, e.x, e.y - 10, e.x + ux * L, e.y - 10 + uy * L, 'vel');
  });
  /* 光子 */
  P.ph.forEach(function (p) {
    var x = p.x0 + g.ux * p.d, y = p.y0 + g.uy * p.d;
    photonWave(ctx, x, y, g.ux, g.uy, 34, rgbStr(q.uv ? [92, 76, 140] : q.rgb), y > g.ys ? 0.55 : 1, q.uv, photonCycles(q.nu));
  });
  ctx.restore();
  /* 文字 */
  if (q.uv) label(ctx, '紫外線（目に見えない光）', Math.min(g.aw - 10, tb.x + g.ux * -60), 20, { size: 12.5, bold: true, color: '#5c4c8c', align: 'right' });
  else peLightLabel(ctx, '可視光', Math.min(g.aw - 10, tb.x + g.ux * -60), 20, q.rgb, 'right');      /* 字の色は光の色（2026-10-26 千葉さん） */
  label(ctx, '金属', 12, g.ah - 14, { size: 12, bold: true, color: '#5a3d14', align: 'left' });
  label(ctx, '真空', 12, 16, { size: 11, color: '#8a939d', align: 'left' });
  s1Legend(ctx, g, q);
  /* 境界面の上：10 秒あたりの数（いまの設定が 10 秒続いたとき） */
  var c10 = peCount10(q);
  peFrac(ctx, g.aw - 8, g.ys - 50, '現在', '10 秒あたりに飛び出した光電子 ' + c10.e + ' 個', '10 秒あたりに金属に当たった光子 ' + c10.p + ' 個', 9.5);
  if (!on) label(ctx, '▶ スタートで光を当てる', g.aw / 2, g.ys / 2 + 10, { size: 13, bold: true, color: '#b35a00' });
  if (q.I === 0 && on) label(ctx, '光の強さが 0（光子が来ない）', g.aw / 2, g.ys / 2 + 10, { size: 12.5, bold: true, color: '#69717d' });
  /* 電子のエネルギーの図 */
  s1Energy(ctx, g.ebox, q, g.wide, g.ys);
}
/* 凡例：左上（「真空」の下）に 2 行で「電子」「光子」（2026-10-26 千葉さん 5 回目） */
function s1Legend(ctx, g, q) {
  var x = 12, y = 38;
  electronDot(ctx, x + 14, y, 4, 1, true); label(ctx, '電子', x + 34, y, { size: 10.5, align: 'left', color: '#3a414c' });
  photonWave(ctx, x + 28, y + 18, 1, 0, 28, rgbStr(q.uv ? [92, 76, 140] : q.rgb), 1, q.uv, photonCycles(q.nu)); label(ctx, '光子', x + 34, y + 18, { size: 10.5, align: 'left', color: '#3a414c' });
}
/* 電子のエネルギーの図（教科書の図と同じ形：hν を受け取り、W を使って外へ。残りが K₀） */
function s1Energy(ctx, b, q, wide, ysurf) {
  var w = b.x1 - b.x0, h = b.y1 - b.y0;
  ctx.save();
  ctx.fillStyle = '#faf8f3'; ctx.fillRect(b.x0, b.y0, w, h);
  ctx.strokeStyle = 'rgba(20,23,28,.14)'; ctx.lineWidth = 1; ctx.beginPath();
  if (wide) { ctx.moveTo(b.x0 + 0.5, b.y0); ctx.lineTo(b.x0 + 0.5, b.y1); } else { ctx.moveTo(b.x0, b.y0 + 0.5); ctx.lineTo(b.x1, b.y0 + 0.5); }
  ctx.stroke(); ctx.restore();
  label(ctx, '電子のエネルギー', b.x0 + w / 2, b.y0 + 15, { size: 11.5, bold: true, color: '#3a414c' });
  var top = b.y0 + 40, yb = b.y1 - 30, sc = (yb - top) / 10.8;
  /* 横に並ぶとき（wide）：金属の外と中の境（破線）を、左のアニメの金属の表面と同じ高さに（2026-10-26 千葉さん 5 回目）。
     縮尺は金属で変わる。hν が図の上をこえるときは、矢印を上で切って ≈ の印 */
  if (wide && ysurf) sc = (yb - ysurf) / q.W;
  var yv = yb - q.W * sc, yE0 = yb - q.E * sc, cut = yE0 < top - 6, yE = cut ? top - 6 : yE0;
  var xa = b.x0 + Math.max(w * 0.46, 70), xw = b.x0 + Math.max(w * 0.74, 120);
  if (!wide) { xa = b.x0 + w * 0.42; xw = b.x0 + w * 0.6; }
  /* 金属の中（灰色）と、金属の外の境（破線）。名前は左のはし */
  ctx.save(); ctx.fillStyle = 'rgba(120,128,140,.13)'; ctx.fillRect(b.x0 + 8, yv, w - 16, yb - yv + 8); ctx.restore();
  dotted(ctx, b.x0 + 8, yv, b.x1 - 8, yv, 'rgba(20,23,28,.55)', [5, 4]);
  label(ctx, '金属の外', b.x0 + 12, yv - 9, { size: 9.5, color: '#69717d', align: 'left' });
  label(ctx, '金属の中', b.x0 + 12, yv + 10, { size: 9.5, color: '#69717d', align: 'left' });
  electronDot(ctx, (xa + xw) / 2, yb, 4.2, 1, false);
  label(ctx, '自由電子', (xa + xw) / 2, yb + 15, { size: 10, color: '#3a414c' });
  /* hν（オレンジ） */
  eArrow(ctx, xa, yb - 2, xa, yE, '#e07b18', 5);
  sym(ctx, 'hν', xa - 8, (yb + yE) / 2, { size: 15, color: '#c0610a', align: 'right' });
  /* W（灰色）と K₀（青） */
  eArrow(ctx, xw, yb - 2, xw, yv + 1, '#6b7480', 5);
  sym(ctx, 'W', xw + 9, (yb + yv) / 2, { size: 15, color: '#4a525d', align: 'left' });
  if (q.d > 1e-9) {
    eArrow(ctx, xw, yv - 1, xw, yE, '#1663b5', 5);
    if (yv - yE > 14) sym(ctx, 'K', xw + 9, (yv + yE) / 2, { size: 15, sub: '0', color: '#1663b5', align: 'left' });
    dotted(ctx, xa, yE, xw + 4, yE, 'rgba(224,123,24,.6)', [3, 3]);
    label(ctx, '外へ飛び出せる', (xa + xw) / 2, Math.max(b.y0 + 32, Math.min(yE, yv) - 16), { size: 10.5, bold: true, color: '#1663b5' });
  } else if (q.eq) {
    label(ctx, 'ちょうど K₀ = 0', (xa + xw) / 2, yv - 16, { size: 10.5, bold: true, color: '#1663b5' });
  } else {
    dotted(ctx, xa, yE, xw + 4, yE, 'rgba(224,123,24,.6)', [3, 3]);
    label(ctx, 'W より小さい', (xa + xw) / 2, yv - 38, { size: 10.5, bold: true, color: '#c0392b' });
    label(ctx, '→ 電子は脱出できない', (xa + xw) / 2, yv - 23, { size: 10.5, bold: true, color: '#c0392b' });
  }
  if (cut) [xa, xw].forEach(function (x) { if (x === xw && q.d <= 1e-9) return; var yc = Math.max(top + 14, (yv + yE) / 2 + (x === xa ? 30 : 0)); ctx.save(); ctx.strokeStyle = '#faf8f3'; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(x - 7, yc + 3); ctx.lineTo(x + 7, yc - 3); ctx.moveTo(x - 7, yc + 9); ctx.lineTo(x + 7, yc + 3); ctx.stroke(); ctx.strokeStyle = '#3a414c'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(x - 7, yc + 2); ctx.lineTo(x + 7, yc - 4); ctx.moveTo(x - 7, yc + 10); ctx.lineTo(x + 7, yc + 4); ctx.stroke(); ctx.restore(); });   /* 途中を省いた印 */
}

DEFS.s1 = peBase({
  id: 's1', num: 1, title: '光電効果の基礎',
  desc: '金属の表面に光を当てる。光は、エネルギー $h\\nu$ をもつ粒（光子）の集まりである。光子 1 個が金属の中の電子 1 個にエネルギー $h\\nu$ を与え、それが仕事関数 $W$ より大きいと、電子は金属の外へ飛び出す（光電子）。<span class="todo">振動数 $\\nu$ を変えて、電子が飛び出す／飛び出さないの境目（限界振動数 $\\nu_0$）を探そう。光の強さを変えると、何が変わって何が変わらないかも確かめよう。</span>',
  /* 横置きのスマホ（高さ 390 など）でも図が 1 画面に入るように、画面の高さでおさえる */
  height: function (s, w) { return w >= 520 ? Math.round(clamp(Math.min(w * 0.6, innerHeight - 70), 300, 420)) : Math.round(w * 0.82) + 178; },
  afterBuild: function (s) {
    peArrange(s);
    /* 自由電子の束縛の様子（チェックなしで、いつも表示。ひとことの下） */
    s1BindBuild(s);
    /* 右：K₀–ν グラフ と 解説 */
    s.R.innerHTML = '';
    var gh = el('div', 'pgraphs'); s.R.appendChild(gh);
    s.plotK = peMakePlotK(s, gh); s.plots = [s.plotK];
    s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);
  },
  onDefaults: function (s) { s1ResetLattice(s); },
  /* 「最大の K₀ の電子だけ見る」を ON にした瞬間：K₀ でない（遅い）電子は消す */
  onKmax: function (s) { var K0 = peQ(s).K0; if (s.lat) s.lat.els.forEach(function (e) { if ((e.st === 'out' || e.st === 'surf') && Math.abs(e.K - K0) > 1e-9) { e.st = 'gone'; e.t0 = s.P.time || 0; } }); s.draw(); },
  onReset: function (s) { s1ResetLattice(s); },
  beforeStep: function (s, t0, t1) { s1Step(s, t1 - t0); },
  draw: function (s, ctx, W, H) { drawS1(s, ctx, W, H); },
  msg: function (s) {
    var q = peQ(s);
    if (q.em) return '$h\\nu > W$：光子が当たった電子は、<b>すぐに</b>飛び出す（光が弱くても）。飛び出す電子の運動エネルギーは最大で $K_0 = h\\nu - W$。';
    if (q.eq) return '$h\\nu = W$（$\\nu = \\nu_0$）：電子は表面までは出られるが、運動エネルギーは $0$。';
    return '$h\\nu < W$：光をどれだけ強くしても、電子は飛び出さない。電子は少し揺れるだけで、光子のエネルギーは金属の中で熱になる。';
  },
  right: function (s, R) {
    var q = peQ(s);
    R.innerHTML = mathify('<div class="qcard pex">' + peValuesBox(s, peValuesHTML(q)) + pePointHTML(q) +
      '<p class="qnote">光の強さ＝1 秒あたりに当たる光子の数。強くすると、飛び出す電子の<b>数</b>が増える。光子 1 個のエネルギー $h\\nu$ は変わらないので、$K_0$ は変わらない。' +
      (s.kmode === 'max' ? '<br>（いまは、どの電子も最大の $K_0$ で飛び出すとして描いている）' : '<br>（金属の深い所の電子は、外へ出るまでにエネルギーの一部を失うので、$K_0$ より遅く飛び出す）') + '</p>' +
      peEVnote() + '</div>');
    peBindValues(s, R);
    peRenderPlots(s); peAlignTop(s);
  }
});

/* ---------- 自由電子の束縛の様子：2 つの図を並べる（いつも表示。2026-10-26 千葉さん） ----------
   左右とも、ときどき光子が飛んできて電子にぶつかり、電子が外へ飛んでいく（1 回 3.2 秒）。
   0〜0.35：光子が近づく → 0.35〜0.45：ぶつかる（黄色の光）→ 0.45〜1：電子が外へ（右はばねが切れる） */
var BIND_T = 3.2;
function s1BindBuild(s) {
  /* 最初はたたんでおき、クリックで開く（「現在の値」と同じ見た目。2026-10-26 千葉さん 4 回目） */
  var dt = el('details', 'bindbox'); s.L.appendChild(dt); s.bindDet = dt;
  dt.innerHTML = '<summary><span class="bindttl">＜自由電子の束縛の様子＞</span><span class="qopen">（クリックして開く）</span></summary><div class="bindin"></div>';
  var bx = dt.querySelector('.bindin'); s.bindBox = bx;
  dt.addEventListener('toggle', function () { dt.querySelector('.qopen').textContent = '（クリックして' + (dt.open ? '閉じる' : '開く') + '）'; if (dt.open) s1DrawBind(bx, 0.9 + (performance.now() - t0) / 1000, s); });
  bx.innerHTML = '' +
    '<div class="bindcells"><figure><canvas></canvas><figcaption>原子核のまわりを回る電子として見ると</figcaption></figure>' +
    '<figure><canvas></canvas><figcaption>ばねのように束縛された電子として見ると</figcaption></figure></div>' +
    '<p class="bindcap">' + mathify('どちらの見方でも、電子は金属に<b>束縛</b>されている。電子が金属の外へ出るには、束縛を切るだけのエネルギーが要る。その最小値が<b>仕事関数 $W$</b>（金属ごとに決まっている）。光子 1 個のエネルギー $h\\nu$ が $W$ より大きいときだけ、電子は外へ飛び出せる。') + '</p>';
  var t0 = performance.now();
  var loop = function (ts) {
    var r = bx.getBoundingClientRect();
    if (dt.open && r.bottom > 0 && r.top < innerHeight && !document.hidden) s1DrawBind(bx, 0.9 + (ts - t0) / 1000, s);   /* 開いていて見えているときだけ動かす */
    requestAnimationFrame(loop);
  };
  requestAnimationFrame(loop);
  window.addEventListener('resize', function () { if (dt.open) s1DrawBind(bx, 0.9 + (performance.now() - t0) / 1000, s); });
}
/* 上のアニメと連動：hν > W なら飛び出す（'out'）、hν = W なら表面まで（'surf'）、hν < W なら飛び出せない（'stay'） */
function s1BindMode(s) { var q = peQ(s); return q.em ? 'out' : (q.eq ? 'surf' : 'stay'); }
function s1DrawBind(bx, t, s) {
  var cvs = bx.querySelectorAll('canvas'), m = s ? s1BindMode(s) : 'out';
  [s1BindAtoms, s1BindSprings].forEach(function (f, i) {
    var cv = cvs[i]; if (!cv.offsetParent) return;
    var W = Math.max(150, Math.floor(cv.clientWidth || 260)), H = Math.round(clamp(W * 0.72, 160, 230));
    var ctx = prep(cv, W, H); f(ctx, W, H, t + i * BIND_T / 2, m);   /* 左右で、ぶつかる時をずらす */
  });
}
/* 飛び出せないとき：ぶつかった電子は少し揺れて、オレンジのにじみ（熱） */
function s1BindStay(ctx, x, y, k, txt) {
  var f = clamp((k - 0.35) / 0.65, 0, 1), a = 1 - f;
  var gr = ctx.createRadialGradient(x, y, 1, x, y, 10 + 14 * f); gr.addColorStop(0, 'rgba(240,110,30,' + (0.55 * a).toFixed(3) + ')'); gr.addColorStop(1, 'rgba(240,110,30,0)');
  ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(x, y, 10 + 14 * f, 0, TAU); ctx.fill();
  if (f > 0.05 && f < 0.9) label(ctx, txt, x, y - 24, { size: 10, align: 'center', color: '#b02a20' });
}
/* 1 回ぶんの進み具合 */
function s1BindPhase(t) { var c = Math.floor(t / BIND_T); return { c: c, k: (t - c * BIND_T) / BIND_T }; }
function s1Metal(ctx, W, H, ys) {
  ctx.fillStyle = '#f2d4a6'; ctx.fillRect(0, ys, W, H - ys);
  ctx.strokeStyle = '#3a2a14'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(0, ys); ctx.lineTo(W, ys); ctx.stroke();
}
/* 光子が右上から (x, y) に近づき、ぶつかる。k は 1 回ぶんの進み具合 */
function s1BindPhoton(ctx, x, y, k, W) {
  var ux = -0.55, uy = 0.835, L = 34;
  if (k < 0.35) {
    var f = k / 0.35, d = (1 - f) * Math.min(150, W * 0.55), hx = x - ux * d, hy = y - uy * d;
    photonWave(ctx, hx, hy, ux, uy, L, '#2f6fd0', 1, false, 3);
    if (f < 0.75) label(ctx, '光子', hx + 14, hy - 4, { size: 10, align: 'left', color: '#2f6fd0' });
  } else if (k < 0.47) {
    var a = 1 - (k - 0.35) / 0.12;
    ctx.save(); ctx.globalAlpha = a; ctx.fillStyle = '#ffd34d'; ctx.strokeStyle = '#e0a400'; ctx.lineWidth = 1;
    ctx.beginPath(); for (var i = 0; i < 12; i++) { var an = i * Math.PI / 6, rr = i % 2 ? 4.5 : 11; ctx.lineTo(x + rr * Math.cos(an), y + rr * Math.sin(an)); } ctx.closePath(); ctx.fill(); ctx.stroke(); ctx.restore();
  }
}
/* 左：原子核のまわりを回る電子 */
function s1BindAtoms(ctx, W, H, t, m) {
  var ys = H * 0.4, r0 = Math.min(W / 9.5, 19), ph = s1BindPhase(t);
  s1Metal(ctx, W, H, ys);
  var n = Math.max(3, Math.floor(W / (2.3 * r0))), dx = W / n, top = [];
  for (var row = 0; row < 2; row++) for (var i = 0; i < n; i++) {
    var cx = dx * (i + 0.5) + (row ? dx / 2 : 0), cy = ys + r0 + 6 + row * (2 * r0 + 6); if (cx > W - 4 || cy > H - 4) continue;
    ctx.strokeStyle = 'rgba(58,42,20,.5)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(cx, cy, r0, 0, TAU); ctx.stroke();
    ctx.fillStyle = '#2b2b2b'; ctx.beginPath(); ctx.arc(cx, cy, 3.4, 0, TAU); ctx.fill();
    var a = t * 2.2 + i * 1.3 + row, tgt = row === 0 && i === 1 + (ph.c % Math.max(1, n - 2));
    if (tgt) { a = -Math.PI / 2 - 2.2 * (0.35 - ph.k) * BIND_T; top.push({ cx: cx, cy: cy }); }   /* ぶつかる時刻に、ちょうど軌道のいちばん上に来る */
    if (tgt && ph.k >= 0.35 && m !== 'stay') continue;                  /* ぶつかったあとは、この電子は軌道を離れる */
    if (tgt && ph.k >= 0.35) { var sh = clamp((ph.k - 0.35) / 0.65, 0, 1); a = -Math.PI / 2 + 2.2 * (ph.k - 0.35) * BIND_T; electronDot(ctx, cx + r0 * Math.cos(a) + 3 * Math.sin(40 * sh) * (1 - sh), cy + r0 * Math.sin(a), 3, 1, false); continue; }   /* 飛び出せない：揺れるだけ */
    electronDot(ctx, cx + r0 * Math.cos(a), cy + r0 * Math.sin(a), 3, 1, false);
  }
  var T = top[0]; if (!T) return;
  /* ぶつかる点：軌道のいちばん上（光子はそこへ向かう） */
  var hx = T.cx, hy = T.cy - r0;
  s1BindPhoton(ctx, hx, hy, ph.k, W);
  if (ph.k >= 0.35 && m === 'stay') s1BindStay(ctx, hx, hy, ph.k, '飛び出せない（熱になる）');
  else if (ph.k >= 0.35 && m === 'surf') {
    var fs = clamp((ph.k - 0.4) / 0.3, 0, 1), sy0 = hy + (ys - 2 - hy) * fs;
    electronDot(ctx, hx, sy0, 3.6, 1 - clamp((ph.k - 0.85) / 0.15, 0, 1), true);
    label(ctx, '表面で止まる（K₀ = 0）', hx, ys - 16, { size: 10, align: 'center', color: '#b02a20' });
  } else if (ph.k >= 0.35) {
    var f = clamp((ph.k - 0.4) / 0.6, 0, 1), ex = hx - f * W * 0.32, ey = hy - f * H * 0.42 - Math.sin(Math.PI * f) * 10;
    ctx.save(); ctx.strokeStyle = 'rgba(209,53,43,.85)'; ctx.lineWidth = 1.6; ctx.setLineDash([4, 3]); ctx.beginPath(); ctx.moveTo(hx, hy);
    for (var j = 1; j <= 12; j++) { var g = f * j / 12; ctx.lineTo(hx - g * W * 0.32, hy - g * H * 0.42 - Math.sin(Math.PI * g) * 10); } ctx.stroke(); ctx.restore();
    electronDot(ctx, ex, ey, 3.6, 1 - clamp((f - 0.85) / 0.15, 0, 1), true);
    if (f > 0.15) label(ctx, '飛び出す電子', ex, ey - 13, { size: 10, align: 'center', color: '#b02a20' });
  }
  label(ctx, '原子核', 30, H - 10, { size: 10, align: 'center', color: '#3a2a14' });
}
/* 右：ばねのように束縛された電子 */
function s1BindSprings(ctx, W, H, t, m) {
  var ys = H * 0.4, ph = s1BindPhase(t);
  s1Metal(ctx, W, H, ys);
  var zig = function (x1, y1, x2, y2, col) {
    var L = Math.hypot(x2 - x1, y2 - y1); if (L < 4) return;
    var ux = (x2 - x1) / L, uy = (y2 - y1) / L, N = Math.max(4, Math.round(L / 5));
    ctx.save(); ctx.strokeStyle = col || '#6b6f75'; ctx.lineWidth = 1.1; ctx.beginPath(); ctx.moveTo(x1, y1);
    for (var i = 1; i < N; i++) { var sgn = i % 2 ? 1 : -1; ctx.lineTo(x1 + ux * L * i / N - uy * 3 * sgn, y1 + uy * L * i / N + ux * 3 * sgn); }
    ctx.lineTo(x2, y2); ctx.stroke(); ctx.restore();
  };
  var nN = W < 230 ? 2 : 3, nuc = [];
  var R = Math.min(30, (H - ys) * 0.38, W / nN * 0.36);
  for (var i = 0; i < nN; i++) nuc.push({ x: W * (i + 0.5) / nN, y: ys + R + 12 });          /* 上の電子が表面のすぐ下に来る深さ */
  var arms = [-Math.PI / 2, -0.25, Math.PI - 0.25, Math.PI / 2 + 0.2];
  var tn = ph.c % nN, hit = ph.k >= 0.35 && m !== 'stay', hitS = ph.k >= 0.35 && m === 'stay';
  nuc.forEach(function (n, ni) {
    arms.forEach(function (a, ai) {
      var j = Math.sin(t * 6 + ni * 2 + ai) * 2.2, x = n.x + (R + j) * Math.cos(a), y = Math.max(ys + 5, n.y + (R + j) * Math.sin(a));
      var isT = ni === tn && ai === 0;
      if (isT && hit) {                                                 /* ばねが切れた */
        zig(n.x, n.y, n.x, n.y - R * 0.45, '#9aa1ab');
        return;
      }
      if (isT && hitS) { var sh = clamp((ph.k - 0.35) / 0.65, 0, 1); x += 4 * Math.sin(45 * sh) * (1 - sh); }   /* 飛び出せない：強く揺れるだけ */
      zig(n.x, n.y, x, y); electronDot(ctx, x, y, 3.2, 1, false);
    });
    ctx.fillStyle = '#1e1e1e'; ctx.beginPath(); ctx.arc(n.x, n.y, 6.5, 0, TAU); ctx.fill();
  });
  var T = nuc[tn], hx = T.x, hy = Math.max(ys + 5, T.y - R);
  s1BindPhoton(ctx, hx, hy, ph.k, W);
  if (hitS) s1BindStay(ctx, hx, hy, ph.k, '束縛を切れない（熱になる）');
  if (hit) {
    var f = clamp((ph.k - 0.4) / 0.6, 0, 1), ex = hx - f * W * 0.16, ey = m === 'surf' ? hy + (ys - 2 - hy) * clamp(f * 2, 0, 1) : hy - f * (hy - 16);
    zig(hx, hy, hx + 2, hy + R * 0.3, f < 0.15 ? '#9aa1ab' : 'rgba(154,161,171,' + (1 - f).toFixed(2) + ')');   /* 切れたばねの先 */
    electronDot(ctx, ex, ey, 3.6, 1 - clamp((f - 0.85) / 0.15, 0, 1), true);
    if (f > 0.15) label(ctx, m === 'surf' ? '表面で止まる（K₀ = 0）' : '束縛が切れて外に飛び出す電子', clamp(ex, 80, W - 80), ey - 13, { size: 10, align: 'center', color: '#b02a20' });
  }
  label(ctx, '束縛されている電子', W * 0.5, H - 10, { size: 10, align: 'center', color: '#3a2a14' });
}
