/* =========================================================================
   80_page.js … ページの組み立て（小さな見出し・セクションのカード・アドレス）
   ヒーロー（大きな見出しのアニメ）とモードのタブは作らない（2026-10-26 千葉さん）。
   上は「パンくず・タイトル・ひとことの説明・右上の式・考え方エリアを閉じる」だけ。
   ========================================================================= */
'use strict';
var SECS = ['s1', 's2'];
var GLOBAL = { hideEq: false };
var SIM_BY_ID = {};
var MODES = [];                                   /* 45_sim.js などとの互換のため（モードはない） */

function buildPage() {
  var wrap = document.getElementById('wrap'), h = '';
  document.getElementById('hero').innerHTML =
    '<div class="hero-in">' +
      '<div class="hero-top">' +
        '<nav class="crumbs" aria-label="現在地"><a class="crumb-home" href="' + SITE_HOME + '" title="楽楽（らくらく）高校物理のトップページへ"><svg class="atom" viewBox="0 0 32 32" aria-hidden="true"><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#3ea0e0" stroke-width="2"/><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#7b5bd6" stroke-width="2" transform="rotate(60 16 16)"/><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#e07b18" stroke-width="2" transform="rotate(120 16 16)"/><circle cx="16" cy="16" r="3.6" fill="#5aa7ff"/></svg><span>楽楽（らくらく）高校物理</span></a><span class="cs" aria-hidden="true">/</span><a class="crumb" href="' + SITE_HOME + '">原子</a><span class="cs" aria-hidden="true">/</span><span class="crumb now" aria-current="page">光電効果</span><span class="kdot"></span><span class="en">Photoelectric Effect</span></nav>' +
        '<div class="topbtns" role="group" aria-label="ページ全体の表示"><button id="btnEq" type="button"></button></div>' +
      '</div>' +
      '<h1 class="hero-title"><span class="t1">光電効果</span></h1>' +
      '<div class="introrow"><p class="lead2">' + mathify('光を、エネルギー $h\\nu$ の粒（光子）の集まりと考えると、光電効果のふしぎな性質がすべて説明できる。振動数・光の強さ・金属を変えて確かめよう。') + '</p></div>' +
    '</div>';
  document.getElementById('tabs').innerHTML = '<div class="tabs-in"><div class="navsite"><a class="navhome" href="' + SITE_HOME + '" aria-label="ホーム（楽楽高校物理のトップページ）" title="ホーム（楽楽高校物理のトップページ）"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3.5 10.8 12 4l8.5 6.8" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M6 9.5V20h4.5v-5.5h3V20H18V9.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg></a><button class="navpages" id="bPages" type="button" aria-haspopup="dialog" aria-expanded="false" aria-controls="siteDrawer"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="3.5" width="7" height="7" rx="1.6" fill="currentColor"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.6" fill="currentColor" opacity=".55"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.6" fill="currentColor" opacity=".55"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.6" fill="currentColor"/></svg><span>ページ一覧</span></button></div>' +
    '</div><span class="tprog" aria-hidden="true"></span>';

  h += '<section class="mode on" id="main">';
  SECS.forEach(function (sid) {
    var d = DEFS[sid]; if (!d) return;
    h += '<article class="sec pesec" id="' + sid + '"><div class="sL">' +
      '<div class="sechead"><span class="secnum">' + d.num + '</span><h2>' + d.title + '</h2></div>' +
      '<div class="secdesc">' + (d.desc || '') + '</div><div class="simhost" id="simL_' + sid + '"></div></div>' +
      '<div class="sR" id="simR_' + sid + '"></div></article>';
  });
  h += '</section><footer></footer>';
  wrap.innerHTML = h;
  document.title = '光電効果';
  wrap.querySelectorAll('.secdesc,.sechead h2').forEach(function (e) { e.innerHTML = mathify(e.innerHTML); });
  setupGlobalButtons();
  SECS.forEach(function (sid) {
    var d = DEFS[sid]; if (!d) return;
    SIM_BY_ID[sid] = new Sim(d, document.getElementById('simL_' + sid), document.getElementById('simR_' + sid));
  });
  if (location.hash && document.getElementById(location.hash.slice(1))) scrollToSec(location.hash.slice(1));
  if (document.fonts && document.fonts.load) {
    Promise.all(['italic 17px KaTeX_Math', '16px KaTeX_Main'].map(function (f) { return document.fonts.load(f); })).then(function () { SIMS.forEach(function (s) { s.draw(); }); PLOTS.forEach(function (p) { p.render(); }); });
  }
}
function syncGlobalButtons() {
  var bE = document.getElementById('btnEq');
  bE.innerHTML = '<span class="sw" aria-hidden="true"><i></i></span><span class="swl">式・考え方エリアを閉じる</span><span class="swv">' + (GLOBAL.hideEq ? 'ON' : 'OFF') + '</span>';
  bE.setAttribute('aria-pressed', GLOBAL.hideEq ? 'true' : 'false'); bE.classList.toggle('off', !GLOBAL.hideEq);
  document.body.classList.toggle('hideeq', GLOBAL.hideEq);
}
function setupGlobalButtons() {
  var bE = document.getElementById('btnEq');
  bE.addEventListener('click', function () {
    GLOBAL.hideEq = !GLOBAL.hideEq; syncGlobalButtons();
    SIMS.forEach(function (s) { if (s.cv.offsetParent) { s.resize(); s.draw(); } });
    PLOTS.forEach(function (p) { p.render(); });
  });
  syncGlobalButtons();
}
function contentTop() { var h = document.getElementById('hero'); return h ? h.offsetTop + h.offsetHeight : 0; }
function tabbarH() { var tb = document.getElementById('tabs'); if (!tb) return 0; return (getComputedStyle(tb).position === 'sticky') ? tb.getBoundingClientRect().height : 0; }
function scrollToSec(sid) {
  var go = function () { var e = document.getElementById(sid); if (!e) return; var y = e.getBoundingClientRect().top + window.pageYOffset - tabbarH() - 8; window.scrollTo({ top: Math.max(0, y), behavior: 'auto' }); };
  go(); requestAnimationFrame(function () { requestAnimationFrame(go); }); setTimeout(go, 180);
}
document.addEventListener('DOMContentLoaded', function () { buildPage(); });
