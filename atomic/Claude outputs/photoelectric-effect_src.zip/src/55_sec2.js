/* =========================================================================
   55_sec2.js … 2　光電効果の実験（光電管・電流計 A・電圧計 V・電源）
   装置は教科書の光電管の図にそろえる：曲がった陰極（電位 0）と、中の陽極。陽極の電位 V は電源（電池を入れかえて正にも負にも）。
   ・陽極の電位 V のスライダーだけは、図の中の電源の位置に置く（ほかのスライダーと金属のボタンは 1 と同じ場所・同じ形）
   ・V > 0：電子は加速され、ほぼすべて陽極に届く。V < 0：減速され、運動エネルギーが e|V| に足りない電子はもどる。V = −V₀ で光電流 0
   ・右上に K₀–ν グラフ、その下に光電流–V グラフ。最初の設定（その金属・ν = 7.50×10¹⁴ Hz・光の強さ 50 %）の曲線をいつも破線で
   ・光電子が陽極に届いた瞬間、電流計の上に「光電流が流れた」の吹き出し（0.2 秒）
   電子の動き：陰極の点 P から陽極の点 T へ一直線（距離 D）。加速度は一定（一様な電場）で、
   画面の上で a = KAPPA²·eV/(2D)。止まるまでに進む距離は D·K/(e|V|) なので、K ≧ e|V| のときだけ陽極に届く（式と同じ）。
   ========================================================================= */
'use strict';
var S2_DEF_V = 1.0;                                    /* 最初の陽極の電位〔V〕（2026-10-26 千葉さん：1.0 V） */
var S2_BUB = 0.2;                                      /* 「光電流が流れた」の吹き出しを出す時間〔s〕 */
function s2Rg(W) { return clamp(Math.min(W * 0.2, 120, (innerHeight - 70 - 196) / 2), 62, 120); }   /* 横置きのスマホでも図が 1 画面に入るように */
function s2Geo(s, W, H) {
  var Rg = s2Rg(W), cx = Math.max(W * 0.38, Rg + 70), cy = Rg + 34, Rc = Rg * 0.84;
  var xR = Math.min(W - 34, cx + Rg + Math.max(64, W * 0.17)), ax = cx - Rg * 0.16, ah = Rg * 0.24;
  var yV = cy + Rg + 34, yB = yV + 52;
  return { W: W, H: H, Rg: Rg, cx: cx, cy: cy, Rc: Rc, xR: xR, ax: ax, ah: ah, yV: yV, yB: yB, band: 0.55,
    xA: (cx + Rg + xR) / 2, xm: (ax + xR) / 2 };
}
function s2Lit(s) { return !!(s.P && s.P.lit); }
function s2Step(s, dt) {
  var g = s.g; if (!g) return;
  var P = s.P, q = peQ(s), tt = (P.time = (P.time || 0) + dt), V = s.V;
  P.lit = true;
  if (q.I > 0) {
    P.acc += dt * PH_RATE * q.I / 100;
    if (P.first) { P.acc = Math.max(P.acc, 1); P.first = false; }
    var guard = 0;
    while (P.acc >= 1 && guard++ < 6) {
      P.acc -= 1;
      var y = g.cy + (P.rnd() * 2 - 1) * g.Rc * g.band, phi = Math.asin((y - g.cy) / g.Rc);
      P.ph.push({ x: -16, y: y, xe: g.cx + g.Rc * Math.cos(phi), phi: phi });
    }
  }
  P.ph = P.ph.filter(function (p) {
    p.x += PH_SPEED * dt;
    if (p.x >= p.xe) { s2Emit(s, g, p, q, tt); return false; }
    return true;
  });
  P.el = P.el.filter(function (e) {
    if (e.st === 'hit' || e.st === 'back') return tt - e.t0 < 0.35;
    if (e.miss) {
      e.x += e.vx * dt; e.y += e.vy * dt;
      if (Math.hypot(e.x - g.cx, e.y - g.cy) > g.Rg - 5 || tt - e.t0 > 4) { e.st = 'back'; e.t0 = tt; }
      return true;
    }
    var a = KAPPA * KAPPA * PE.E * V / (2 * e.D);
    e.v += a * dt; e.s += e.v * dt;
    if (e.s >= e.D) { e.s = e.D; e.st = 'hit'; e.t0 = tt; P.nHitA++; P.lastHitT = tt; }
    else if (e.s <= 0 && (e.v < 0 || tt - e.t0 > 0.6)) { e.s = 0; e.st = 'back'; e.t0 = tt; P.nBack++; }
    return true;
  });
}
function s2Emit(s, g, p, q, tt) {
  var P = s.P; P.nHit++;
  if (q.d < -1e-12) { P.fx.push({ x: p.xe, y: p.y, t0: tt }); return; }       /* hν < W：飛び出さない（熱） */
  var u = P.rnd(), K = KofU(q.K0, u, q.mode), x0 = p.xe - 3 * Math.cos(p.phi), y0 = p.y - 3 * Math.sin(p.phi);
  var tx = g.ax + 4, ty = g.cy + (p.y - g.cy) * 0.3, D = Math.hypot(tx - x0, ty - y0);
  var e = { x0: x0, y0: y0, ux: (tx - x0) / D, uy: (ty - y0) / D, D: D, s: 0, v: KAPPA * Math.sqrt(K), K: K, st: 'fly', t0: tt, miss: false };
  if (P.rnd() > collectG(s.V, q.V0, q.mode)) {                                /* 向きの関係で陽極に届かない電子（ガラスへ） */
    var ang = (P.rnd() < 0.5 ? -1 : 1) * (0.7 + 0.5 * P.rnd()), c = Math.cos(ang), sn = Math.sin(ang), sp = Math.max(40, e.v);
    e.miss = true; e.x = x0; e.y = y0; e.vx = (e.ux * c - e.uy * sn) * sp; e.vy = (e.ux * sn + e.uy * c) * sp;
  }
  P.el.push(e); P.nEmit++;
}

/* ---------- 描く ---------- */
function drawS2(s, ctx, W, H) {
  var g = s.g = s2Geo(s, W, H), q = peQ(s), P = s.P, tt = P.time || 0, lit = s2Lit(s);
  var wire = '#3b414a';
  ctx.fillStyle = '#fbfcfe'; ctx.fillRect(0, 0, W, H);
  /* 導線（あとから光電管を上に描く） */
  ctx.save(); ctx.strokeStyle = wire; ctx.lineWidth = 2.4; ctx.lineJoin = 'round';
  ctx.beginPath(); ctx.moveTo(g.cx + g.Rc, g.cy); ctx.lineTo(g.xR, g.cy); ctx.lineTo(g.xR, g.yB); ctx.lineTo(g.xm + 16, g.yB); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(g.ax, g.cy + g.ah); ctx.lineTo(g.ax, g.yB); ctx.lineTo(g.xm - 16, g.yB); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(g.ax, g.yV); ctx.lineTo(g.xR, g.yV); ctx.stroke();
  [[g.ax, g.yV], [g.xR, g.yV], [g.xR, g.cy]].forEach(function (p) { ctx.beginPath(); ctx.arc(p[0], p[1], 3.2, 0, TAU); ctx.fillStyle = wire; ctx.fill(); });
  ctx.restore();
  /* アース（陰極の電位を 0 に） */
  s2Ground(ctx, g.xR, g.cy, wire);
  /* 光電管：ガラス */
  ctx.save(); ctx.beginPath(); ctx.arc(g.cx, g.cy, g.Rg, 0, TAU); ctx.fillStyle = 'rgba(214,232,248,.35)'; ctx.fill();
  ctx.strokeStyle = 'rgba(70,110,150,.55)'; ctx.lineWidth = 2; ctx.stroke(); ctx.restore();
  /* 光の帯（左から入り、陰極に当たる） */
  var a0 = Math.asin(-g.band), a1 = Math.asin(g.band), yt = g.cy - g.Rc * g.band, yb = g.cy + g.Rc * g.band, on = lit || P.ph.length;
  ctx.save(); ctx.beginPath(); ctx.moveTo(0, yt); ctx.lineTo(g.cx + g.Rc * Math.cos(a0), yt); ctx.arc(g.cx, g.cy, g.Rc, a0, a1); ctx.lineTo(0, yb); ctx.closePath();
  ctx.fillStyle = rgbStr(q.rgb, on ? (q.uv ? 0.10 : 0.17) * (0.35 + 0.65 * q.I / 100) : 0.05); ctx.fill();   /* 2 は光の強さを濃さで（光の当たる幅は陰極に合わせて同じ） */
  if (q.uv) { ctx.setLineDash([5, 5]); ctx.strokeStyle = rgbStr(q.rgb, 0.5); ctx.lineWidth = 1; ctx.stroke(); }
  ctx.restore();
  /* 陰極（曲がった金属の板）。内がわに金属の色 */
  ctx.save(); ctx.lineCap = 'round';
  ctx.beginPath(); ctx.arc(g.cx, g.cy, g.Rc + 3, -1.1, 1.1); ctx.strokeStyle = '#6c6a66'; ctx.lineWidth = 5; ctx.stroke();
  ctx.beginPath(); ctx.arc(g.cx, g.cy, g.Rc, -1.08, 1.08); ctx.strokeStyle = '#e2b877'; ctx.lineWidth = 3; ctx.stroke();
  ctx.restore();
  /* 熱（hν < W のとき） */
  P.fx = P.fx.filter(function (f) { return tt - f.t0 < 1.0; });
  P.fx.forEach(function (f) { var a = 1 - (tt - f.t0); var gr = ctx.createRadialGradient(f.x, f.y, 1, f.x, f.y, 12); gr.addColorStop(0, 'rgba(240,110,30,' + (0.6 * a).toFixed(3) + ')'); gr.addColorStop(1, 'rgba(240,110,30,0)'); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(f.x, f.y, 12, 0, TAU); ctx.fill(); });
  /* 陽極 */
  ctx.save(); ctx.fillStyle = '#4d5763'; rrect(ctx, g.ax - 3.5, g.cy - g.ah, 7, 2 * g.ah, 2.5); ctx.fill(); ctx.restore();
  /* 電子 */
  P.el.forEach(function (e) {
    var x = e.miss ? e.x : e.x0 + e.ux * e.s, y = e.miss ? e.y : e.y0 + e.uy * e.s, al = 1;
    if (e.st === 'hit' || e.st === 'back') al = clamp(1 - (tt - e.t0) / 0.35, 0, 1);
    electronDot(ctx, x, y, 3.9, al, true);
    if (e.st === 'fly' && !e.miss && Math.abs(e.v) > 4) {
      var L = clamp(0.11 * Math.abs(e.v), 6, 34) * (e.v > 0 ? 1 : -1);
      velArrow(ctx, x, y - 9, x + e.ux * L, y - 9 + e.uy * L);
    }
  });
  /* 光子 */
  P.ph.forEach(function (p) { photonWave(ctx, p.x, p.y, 1, 0, 34, rgbStr(q.uv ? [92, 76, 140] : q.rgb), 1, q.uv, photonCycles(q.nu)); });
  /* 電流計 A */
  var I = lit ? currentI(s.V, q.nu, q.k, q.I, q.mode) : 0;
  s2Meter(ctx, g.xA, g.cy, 'A');
  ctx.save(); ctx.font = '700 12px ' + FONT; var itw = ctx.measureText('光電流 I = 00.0 μA').width; ctx.restore();
  label(ctx, '光電流 I = ' + f1(I) + ' μA', Math.max(g.xA, g.cx + g.Rg + 6 + itw / 2), g.cy + 30, { size: 12, bold: true, color: '#1c6b3a' });   /* ガラスと重ねない */
  /* I の正の向き：矢印も字も電流計の右（2026-10-26 千葉さん 6 回目） */
  var ia0 = g.xA + 17, ia1 = Math.max(ia0 + 18, g.xR - 8);
  eArrow(ctx, ia0, g.cy - 11, ia1, g.cy - 11, '#e07b18', 2);
  label(ctx, 'I の正の向き', ia0, g.cy - 25, { size: 10.5, bold: true, color: '#c0610a', align: 'left' });
  /* 光電子が陽極に届いた瞬間：電流計の上に下向きの吹き出し */
  if (lit && P.lastHitT !== undefined && tt - P.lastHitT < S2_BUB) s2Bubble(ctx, g.xA, g.cy - 15, '光電流が流れた');
  /* 電圧計 V */
  s2Meter(ctx, g.xm, g.yV, 'V');
  label(ctx, '電圧計', g.xm + 22, g.yV - 12, { size: 10, color: '#69717d', align: 'left' });
  /* 電源（電池の向きは V の符号で入れかわる） */
  s2Battery(ctx, g.xm, g.yB, s.V, wire);
  /* 文字 */
  if (q.uv) label(ctx, '紫外線', 14, yt - 12, { size: 12.5, bold: true, color: '#5c4c8c', align: 'left' });
  else peLightLabel(ctx, '可視光', 14, yt - 12, q.rgb, 'left');
  /* 右上：10 秒あたりの数（いまの設定が 10 秒続いたとき）。光電流に比例するのは「陽極に届いた」数 */
  var c10 = peCount10(q, s.V);
  peCountBox(ctx, W - 8, 8, [[{ t: '金属に当たった光子 ' + c10.p + ' 個' }], [{ t: '→ 飛び出した光電子 ' + c10.e + ' 個', col: '#1663b5' }],
    [{ t: 'そのうち陽極に届いた光電子 ' + c10.a + ' 個 ', col: '#1c6b3a' }, { t: '∝', size: 14, col: '#1c6b3a' }, { t: ' 光電流の大きさ', col: '#1c6b3a' }]], 10.5);
  label(ctx, '陽極', g.ax - 8, g.cy - g.ah - 10, { size: 11.5, bold: true, align: 'right' });
  label(ctx, '陰極（電位 0）', g.cx + g.Rg * 0.75, g.cy - g.Rg - 14, { size: 11.5, bold: true, align: 'right' });   /* 右上の数の箱と重ねない */
  label(ctx, '光電管', g.cx - g.Rg * 0.72, g.cy + g.Rg + 4, { size: 11, color: '#3d5a78', align: 'right' });
  if (!lit && !P.ph.length) label(ctx, '▶ スタートで光を当てる', g.cx, g.cy - g.Rg - 14 < 14 ? 14 : 16, { size: 12.5, bold: true, color: '#b35a00', align: 'right' });
  s2PlaceVin(s, g);
}
/* 下向きの吹き出し（とがった先が (x, y)） */
function s2Bubble(ctx, x, y, text) {
  ctx.save(); ctx.font = '700 12px ' + FONT; var w = ctx.measureText(text).width + 16, h = 24, cx = clamp(x + 16, w / 2 + 3, CVW - w / 2 - 3), top = y - 26 - h;   /* 「I の正の向き」の字より上に */
  ctx.fillStyle = '#fff8e6'; ctx.strokeStyle = '#e07b18'; ctx.lineWidth = 1.6;
  ctx.beginPath(); ctx.moveTo(cx - w / 2 + 6, top); ctx.lineTo(cx + w / 2 - 6, top); ctx.quadraticCurveTo(cx + w / 2, top, cx + w / 2, top + 6); ctx.lineTo(cx + w / 2, top + h - 6); ctx.quadraticCurveTo(cx + w / 2, top + h, cx + w / 2 - 6, top + h);
  ctx.lineTo(x + 6, top + h); ctx.lineTo(x, y); ctx.lineTo(x - 4, top + h);
  ctx.lineTo(cx - w / 2 + 6, top + h); ctx.quadraticCurveTo(cx - w / 2, top + h, cx - w / 2, top + h - 6); ctx.lineTo(cx - w / 2, top + 6); ctx.quadraticCurveTo(cx - w / 2, top, cx - w / 2 + 6, top); ctx.closePath();
  ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#8a4300'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(text, cx, top + h / 2 + 0.5);
  ctx.restore();
}
function s2Meter(ctx, x, y, t) {
  ctx.save(); ctx.beginPath(); ctx.arc(x, y, 13, 0, TAU); ctx.fillStyle = '#fff'; ctx.fill(); ctx.strokeStyle = '#3b414a'; ctx.lineWidth = 2; ctx.stroke(); ctx.restore();
  label(ctx, t, x, y + 0.5, { size: 13, bold: true, halo: false });
}
function s2Ground(ctx, x, y, col) {
  ctx.save(); ctx.strokeStyle = col; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 16, y); ctx.lineTo(x + 16, y + 8); ctx.stroke();
  [[9, 0], [6, 4], [3, 8]].forEach(function (p) { ctx.beginPath(); ctx.moveTo(x + 16 - p[0], y + 9 + p[1]); ctx.lineTo(x + 16 + p[0], y + 9 + p[1]); ctx.stroke(); });
  ctx.restore();
}
/* 電池：長い板が＋。V > 0 なら陽極（左）がわが＋ */
function s2Battery(ctx, x, y, V, col) {
  ctx.save(); ctx.strokeStyle = col; ctx.lineWidth = 2.4;
  if (Math.abs(V) < 0.05) { ctx.beginPath(); ctx.moveTo(x - 16, y); ctx.lineTo(x + 16, y); ctx.stroke(); ctx.restore(); label(ctx, '電源 0 V', x, y - 14, { size: 10.5, color: '#69717d' }); return; }
  var sg = V > 0 ? 1 : -1, n = Math.abs(V) > 2.5 ? 2 : 1, gap = 7, w = n * 2 * gap;
  ctx.beginPath(); ctx.moveTo(x - 16, y); ctx.lineTo(x - w / 2, y); ctx.moveTo(x + w / 2, y); ctx.lineTo(x + 16, y); ctx.stroke();
  for (var i = 0; i < n; i++) {
    var xl = x - w / 2 + i * 2 * gap, xL = sg > 0 ? xl : xl + gap, xS = sg > 0 ? xl + gap : xl;      /* 長い板（＋）・短い板（−） */
    ctx.lineWidth = 2.2; ctx.beginPath(); ctx.moveTo(xL, y - 13); ctx.lineTo(xL, y + 13); ctx.stroke();
    ctx.lineWidth = 4.2; ctx.beginPath(); ctx.moveTo(xS, y - 6.5); ctx.lineTo(xS, y + 6.5); ctx.stroke();
  }
  ctx.restore();
  label(ctx, '＋', x - sg * (w / 2 + 10), y - 14, { size: 11, bold: true, color: '#c0392b' });
  label(ctx, '−', x + sg * (w / 2 + 10), y - 14, { size: 12, bold: true, color: '#1663b5' });
}
/* 図の中の「陽極の電位 V」のスライダーを、電源の真下に置く */
function s2PlaceVin(s, g) {
  var v = s.vin; if (!v) return;
  var w = v.offsetWidth || 240, left = clamp(g.xm - w / 2, 4, Math.max(4, g.W - w - 4));
  v.style.left = Math.round(left) + 'px'; v.style.top = Math.round(g.yB + 18) + 'px';
}
function s2SetV(s, V) {
  s.V = clamp(Math.round(V * 1000) / 1000, PE.V_MIN, PE.V_MAX);
  s2SyncVin(s); s.draw(); s.renderRight();
}
function s2SyncVin(s) {
  if (!s.vin) return;
  var r = s.vin.querySelector('input'), vv = s.vin.querySelector('.vinv');
  if (document.activeElement !== r) r.value = String(s.V);
  r.style.setProperty('--p', ((s.V - PE.V_MIN) / (PE.V_MAX - PE.V_MIN) * 100).toFixed(1) + '%');
  vv.textContent = (s.V > 0.0005 ? '+' : '') + f2(s.V) + ' V';
}

/* ---------- 光電流–V グラフ ---------- */
function s2MakePlotI(s, host) {
  return new Plot({
    host: host, title: '光電流 $I$ と陽極の電位 $V$', legend: true,
    H: function (W) { return clamp(Math.round(W * 0.6), 220, 300); },
    xr0: function () { return { lo: -5.6, hi: 5.6 }; },
    yr0: function () { return { lo: -3.2, hi: 12.4 }; },
    xs: function (ctx, x, y) { sym(ctx, 'V', x - 2, y - 11, { size: 15, align: 'right', clamp: false }); label(ctx, '〔V〕', x + 6, y + 14, { size: 9.5, align: 'right', color: '#69717d' }); },
    ys: function (ctx, x, y) { sym(ctx, 'I', x + 6, y + 3, { size: 15, align: 'left', clamp: false }); label(ctx, '〔μA〕', x + 18, y + 3, { size: 9.5, align: 'left', color: '#69717d' }); },
    draw: function (ctx, P) { s2DrawIV(s, ctx, P); },
    over: function (ctx, P) { s2OverIV(s, ctx, P); }
  });
}
function s2Curve(ctx, P, nu, k, inten, mode, col, w, dash) {
  var N = 360, lo = P.xr.lo, hi = P.xr.hi;
  ctx.save(); ctx.strokeStyle = col; ctx.lineWidth = w; if (dash) ctx.setLineDash(dash); ctx.lineJoin = 'round';
  ctx.beginPath();
  for (var i = 0; i <= N; i++) { var V = lo + (hi - lo) * i / N, I = currentI(V, nu, k, inten, mode), x = P.X(V), y = P.Y(I); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }
  ctx.stroke(); ctx.restore();
}
function s2DrawIV(s, ctx, P) {
  var q = peQ(s);
  if (q.mode === 'max') {                                              /* 「最大の K₀ の電子だけ見る」のとき：選んでいないときのグラフを薄く（2026-10-26 千葉さん） */
    ctx.save(); ctx.globalAlpha = 0.25;
    s2Curve(ctx, P, PE_DEF.nu, q.k, PE_DEF.I, 'dist', '#8a93a0', 2.2, [7, 5]);
    s2Curve(ctx, P, q.nu, q.k, q.I, 'dist', PE_SEL, 2.8);
    ctx.restore(); return;
  }
  s2Curve(ctx, P, PE_DEF.nu, q.k, PE_DEF.I, q.mode, '#8a93a0', 2.2, [7, 5]);     /* 最初の設定（その金属）の曲線：いつも破線で */
  s2Curve(ctx, P, q.nu, q.k, q.I, q.mode, PE_SEL, 2.8);
  /* −V₀ の点 */
  if (q.em) { var x = P.X(-q.V0), y = P.Y(0); dotted(ctx, x, y, x, P.Y(-1.4), 'rgba(20,23,28,.4)', [3, 3]); ctx.save(); ctx.fillStyle = '#c0392b'; ctx.beginPath(); ctx.arc(x, y, 3.6, 0, TAU); ctx.fill(); ctx.restore(); }
  /* いまの V の点 */
  var I = currentI(s.V, q.nu, q.k, q.I, q.mode), px = P.X(s.V), py = P.Y(I);
  dotted(ctx, px, py, px, P.Y(0), 'rgba(20,23,28,.45)', [3, 3]);
  ctx.save(); ctx.beginPath(); ctx.arc(px, py, 6, 0, TAU); ctx.fillStyle = '#e07b18'; ctx.fill(); ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.stroke(); ctx.restore();
}
function s2OverIV(s, ctx, P) {
  var q = peQ(s), R = P.R, X = P.X, Y = P.Y, y0 = Y(0);
  if (q.mode === 'max') {
    var cy = (R.y0 + R.y1) / 2, cx = (R.x0 + R.x1) / 2;
    ctx.save(); ctx.font = '700 12px ' + FONT; var tw = Math.max(ctx.measureText('最大の K₀ の電子だけ見ているので、').width, ctx.measureText('表示できません').width) + 24;
    ctx.fillStyle = 'rgba(255,255,255,.92)'; ctx.strokeStyle = 'rgba(192,57,43,.5)'; rrect(ctx, cx - tw / 2, cy - 24, tw, 48, 8); ctx.fill(); ctx.stroke(); ctx.restore();
    label(ctx, '最大の K₀ の電子だけ見ているので、', cx, cy - 9, { size: 12, bold: true, color: '#c0392b' });
    label(ctx, '表示できません', cx, cy + 10, { size: 12, bold: true, color: '#c0392b' });
    return;
  }
  var inX = function (x) { return x >= R.x0 && x <= R.x1; };
  /* 下の帯：電子の流れを妨げる電圧／加速する電圧 */
  if (y0 > R.y0 && y0 < R.y1 - 30) {
    var yl = Math.min(R.y1 - 8, y0 + 34), xz = clamp(X(0), R.x0, R.x1);
    if (xz - R.x0 > 90) label(ctx, '← 電子の流れを妨げる', xz - 6, yl, { size: 10, color: '#7b3fd4', align: 'right' });
    if (R.x1 - xz > 90) label(ctx, '電子を加速する →', xz + 6, yl, { size: 10, color: '#1c6b3a', align: 'left' });
  }
  /* −V₀ と 阻止電圧 V₀ */
  if (q.em && inX(X(-q.V0))) {
    var x = X(-q.V0);
    label(ctx, '−V₀', x, y0 + 13, { size: 11, bold: true, color: '#c0392b' });
    pill2(ctx, '阻止電圧 V₀ = ' + f2(q.V0) + ' V', x - 6, Math.max(R.y0 + 12, y0 - 24), '#c0392b', 'right');
  } else if (!q.em && !q.eq) {
    label(ctx, 'hν < W：光電流はいつも 0', (R.x0 + R.x1) / 2, Y(4), { size: 11.5, bold: true, color: '#c0392b' });
  }
  /* いまの値 */
  var I = currentI(s.V, q.nu, q.k, q.I, q.mode), px = X(s.V), py = Y(I);
  if (inX(px) && py > R.y0 - 4 && py < R.y1 + 4) label(ctx, 'I = ' + f1(I) + ' μA', px + (s.V > 2.5 ? -10 : 10), py - 13, { size: 10.5, bold: true, color: '#b35a00', align: s.V > 2.5 ? 'right' : 'left' });
  /* 見出しの横、凡例 */
  var gs = s.plotI.box.querySelector('.gsel'), t = mathify('$V = ' + (s.V > 0.0005 ? '+' : '') + f2(s.V).replace('−', '-') + '$ V');
  if (gs._h !== t) { gs._h = t; gs.innerHTML = t; }
  var lg = s.plotI.leg, lh = '<span><i style="border-top:3px solid ' + PE_SEL + '"></i>現在の設定</span>' +
    '<span><i style="border-top:2px dashed #8a93a0"></i>最初の設定（' + metalOf(q.k).name + '・' + mathify('$\\nu = ' + f2(PE_DEF.nu) + '\\times10^{14}$') + ' Hz・光の強さ ' + PE_DEF.I + ' %）</span>';
  if (lg._h !== lh) { lg._h = lh; lg.innerHTML = lh; }
}

DEFS.s2 = peBase({
  id: 's2', num: 2, title: '光電効果の実験',
  desc: '光電管（ほぼ真空のガラス管に陽極と陰極を封入したもの）の陰極に光を当てる。飛び出した光電子が陽極に流れこむと、回路に電流（<b>光電流</b> $I$）が流れる。電源で陽極の電位 $V$ を変えて、光電流がどう変わるかを調べる。<span class="todo">図の中の電源の下のスライダーで陽極の電位を負にしていき、光電流が 0 になる電位 $-V_0$（阻止電圧 $V_0$）を探そう。光の強さ・振動数を変えると $V_0$ は変わるだろうか。</span>',
  height: function (s, w) { return Math.round(2 * s2Rg(w) + 196); },
  init: function (s) { s.V = S2_DEF_V; s.metal = 'Cs'; },     /* 最初はセシウム（可視光で V₀ ≒ 1 V。光電流が 0 になる所を見つけやすい） */
  defMarks: true,                                                       /* スライダーの中に最初の設定の ▼ */
  afterBuild: function (s) {
    peArrange(s);
    s.varbox.querySelector('.pegrid').appendChild(el('p', 'defnote', '▼ は光電流–V グラフの破線の設定'));   /* 金属のエリアの上（2026-10-26 千葉さん 6 回目） */
    s.cw.classList.add('s2wrap');
    /* 陽極の電位 V のスライダー（図の中、電源の位置） */
    var vin = el('div', 'vin'); vin.innerHTML = '<span class="vinl">' + mathify('陽極の電位 $V$') + '</span>';
    var dn = el('button', 'tiny nudge', '−'), r = el('input'), val = el('span', 'vinv', ''), up = el('button', 'tiny nudge', '＋'), z = el('button', 'tiny v0b', mathify('$-V_0$'));
    dn.type = up.type = z.type = 'button'; dn.title = '0.1 V 下げる'; up.title = '0.1 V 上げる'; z.title = '−V₀ ちょうどにする（光電流が 0 になる電位）';
    r.type = 'range'; r.min = String(PE.V_MIN); r.max = String(PE.V_MAX); r.step = String(PE.V_STEP); r.setAttribute('aria-label', '陽極の電位 V');
    var rw = el('span', 'vrw'); rw.appendChild(r); rw.appendChild(el('i', 'v0mk', '<b>0 V</b>'));   /* 0 V の位置に目印（2026-10-26 千葉さん） */
    [dn, rw, val, up, z].forEach(function (e) { vin.appendChild(e); });
    s.cw.appendChild(vin); s.vin = vin;
    r.addEventListener('input', function () { s2SetV(s, parseFloat(r.value)); });
    dn.addEventListener('click', function () { s2SetV(s, roundTo(s.V, PE.V_STEP) - PE.V_STEP); });
    up.addEventListener('click', function () { s2SetV(s, roundTo(s.V, PE.V_STEP) + PE.V_STEP); });
    z.addEventListener('click', function () { var q = peQ(s); s2SetV(s, -q.V0); });
    s2SyncVin(s);
    /* 右：K₀–ν グラフ・光電流–V グラフ・解説 */
    s.R.innerHTML = '';
    var gh = el('div', 'pgraphs two'); s.R.appendChild(gh);
    s.plotK = peMakePlotK(s, gh);                                      /* K₀–ν グラフを上に（2026-10-26 千葉さん） */
    s.plotI = s2MakePlotI(s, gh);
    s.plots = [s.plotK, s.plotI];
    s.Rdyn = el('div', 'rdyn'); s.R.appendChild(s.Rdyn);
  },
  onDefaults: function (s) { s2SyncVin(s); if (s.plotI) s.plotI.reset(); },
  /* 「最大の K₀ の電子だけ見る」を ON にした瞬間：K₀ でない電子は消す */
  onKmax: function (s) { var K0 = peQ(s).K0; s.P.el = s.P.el.filter(function (e) { return Math.abs(e.K - K0) < 1e-9; }); s.draw(); },
  beforeStep: function (s, t0, t1) { s2Step(s, t1 - t0); },
  draw: function (s, ctx, W, H) { drawS2(s, ctx, W, H); },
  msg: function (s) {
    var q = peQ(s), V = s.V;
    if (!q.em && !q.eq) return '$h\\nu < W$：電子が飛び出さないので、陽極の電位をどう変えても光電流は 0。';
    if (V >= 0) return '陽極の電位が正（または 0）：飛び出した光電子はほぼすべて陽極に流れこむ。電位を高くしても、光電流は一定（飽和電流）に近づく。';
    if (V <= -q.V0 + 1e-9) return '$V \\le -V_0$：最も速い電子（運動エネルギー $K_0$）でも、陽極に届く直前で運動エネルギーが 0 になる。光電流は 0。';
    return '陽極の電位が負：光電子は陰極に引き戻されるので減速される。運動エネルギーが $e|V|$ より小さい電子は、陽極に届く前にもどる。';
  },
  right: function (s, R) {
    var q = peQ(s), V = s.V, I = currentI(V, q.nu, q.k, q.I, q.mode), Is = IsatOf(q.nu, q.k, q.I), h = '';
    h += peValuesHTML(q);
    if (q.em) h += '<p class="eqr hl"><span class="eql">阻止電圧</span>$K_0 = eV_0$ より　$V_0 = \\dfrac{K_0}{e}$ $= \\dfrac{' + jTex(q.K0) + '}{' + sciTex(PE.e, 3) + '}$ $= ' + f2(q.V0) + '$ V</p>';
    var st = V >= 0 ? '陽極が正：電子は加速され、ほぼすべて陽極に届く。' :
      (q.em && V > -q.V0 ? '陽極に届くのは、運動エネルギーが $e|V| = ' + jTex(PE.E * -V) + '$ J 以上の電子だけ。' : '陽極に届く電子はない。');
    h += '<p class="vstate">陽極の電位 $V = ' + (V > 0.0005 ? '+' : '') + f2(V).replace('−', '-') + '$ V：' + st + '<br>光電流 $I = ' + f1(I) + '$ μA（飽和電流 ' + f1(Is) + ' μA）</p>';
    R.innerHTML = mathify('<div class="qcard pex">' + peValuesBox(s, h) + pePointHTML(q) +
      '<p class="qnote">振動数は変えずに光を強くすると、光電流（飽和電流）は大きくなるが、阻止電圧 $V_0$ は変わらない（$K_0$ が変わらないから）。振動数を大きくすると $K_0$ が大きくなり、$V_0$ も大きくなる。' +
      (s.kmode === 'max' ? '<br>（いまは、どの電子も $K_0$ で飛び出すとして描いている。このとき光電流は $-V_0$ で急に 0 になる）' : '') + '</p>' +
      peEVnote() + '</div>');
    peBindValues(s, R);
    s2SyncVin(s);
    peRenderPlots(s); peAlignTop(s);
  }
});
