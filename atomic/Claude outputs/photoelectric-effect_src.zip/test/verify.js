// photoelectric-effect.html の検証（physics-sim-page §6 ＋ 光電効果の決まり）
// 使い方：node test/verify.js  → 結果を JSON で表示（ok がすべて true なら合格）
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');
const URL = 'file://' + path.join(__dirname, '..', 'dist', 'photoelectric-effect.html');

(async () => {
  const b = await chromium.launch();
  const R = { ok: {} };
  const newPage = async (w, h) => {
    const p = await b.newPage({ viewport: { width: w, height: h || 900 } });
    p.__errs = []; p.__reqs = [];
    p.on('pageerror', e => p.__errs.push(e.message));
    p.on('console', m => { if (m.type() === 'error') p.__errs.push(m.text()); });
    p.on('request', r => { const u = r.url(); if (!/^(file|data|blob):/.test(u)) p.__reqs.push(u); });
    await p.goto(URL); await p.waitForTimeout(700);
    return p;
  };
  const html = fs.readFileSync(path.join(__dirname, '..', 'dist', 'photoelectric-effect.html'), 'utf8');
  R.ok.footer_strings = html.includes('physics-chiba.goatcounter.com') && html.includes('sg-glow');
  R.ok.no_shi_mu = !/シム/.test(html.replace(/<script[\s\S]*?<\/script>/g, '').replace(/\/\*[\s\S]*?\*\//g, ''));

  const p = await newPage(1440);
  /* 検算 */
  R.check = await p.evaluate(() => TEST.check());
  const c = R.check;
  R.ok.hv_linked_formula = c.hv_eq_h_nu_rel_err < 1e-12;
  R.ok.threshold = c.metals.every(m => !m.below_emits && m.above_emits && m.K0_at_nu0 === 0);
  R.ok.slope_h_parallel = c.slopes.every(s => Math.abs(s - c.slope_expected) < 1e-9) && c.intercepts_minus_W.every(v => Math.abs(v) < 1e-9);
  R.ok.V0_eq_K0_over_e = c.V0_eq_K0_over_e_rel_err < 1e-12;
  R.ok.intensity_only_Isat = c.K0_V0_indep_of_intensity && c.Isat_ratio_err < 1e-9;
  R.ok.I_zero_at_minus_V0 = c.I_zero_at_minus_V0;
  R.ok.I_saturates = c.I_at_plus5_over_Isat_min > 0.99 && c.slope_jump_at_0_rel < 1e-2;

  /* スライダーの連動：hν を動かすと ν、ν を動かすと hν（画面の入力から） */
  R.link = await p.evaluate(() => {
    const out = [];
    ['s1', 's2'].forEach(id => {
      const s = TEST.sim(id), ie = s.sl.E.inp, inu = s.sl.nu.inp;
      [3.1, 5.55, 8.02, 10.6].forEach(E => { ie.value = String(E); ie.dispatchEvent(new Event('input', { bubbles: true }));
        out.push({ id, from: 'E', E: s.disp('E'), nu: s.v.nu, err: Math.abs(s.disp('E') - PE.H * s.v.nu), sliderNu: +inu.value, txt: s.sl.nu.val.textContent }); });
      [4.0, 6.6, 9.9, 16.0].forEach(nu => { inu.value = String(nu); inu.dispatchEvent(new Event('input', { bubbles: true }));
        out.push({ id, from: 'nu', E: s.disp('E'), nu: s.v.nu, err: Math.abs(s.disp('E') - PE.H * s.v.nu), sliderE: +ie.value, txt: s.sl.E.val.textContent }); });
    });
    return out;
  });
  R.ok.slider_link = R.link.every(r => r.err < 1e-12 && (r.from === 'E' ? Math.abs(r.sliderNu - r.nu) < 0.051 : Math.abs(r.sliderE - r.E) < 0.0051));

  /* アニメ：3 種の金属で ν₀ の前後。ν₀ ちょうど（ボタン）で K₀ = 0 */
  R.anim = await p.evaluate(() => {
    const s = TEST.sim('s1'), out = [];
    PE.METALS.forEach(m => {
      [-0.1, 0.1, 0].forEach(dn => {
        s.toDefaults(); s.metal = m.k; peSyncBtns(s);
        if (dn === 0) s.nu0b.click(); else { s.v.nu = nu0Of(m.k) + dn; s.changed('nu'); }
        s.v.I = 100; s.changed('I'); s.resetT();
        const P = TEST.runFor('s1', 3);
        const q = peQ(s);
        out.push({ k: m.k, dn, nu: +s.v.nu.toFixed(4), hits: P.nHit, emits: P.nEmit, K0: q.K0, eq: q.eq, maxK: Math.max(0, ...s.lat.els.filter(e => e.K !== undefined && e.st === 'out').map(e => e.K)) });
      });
    });
    return out;
  });
  R.ok.anim_threshold = R.anim.every(a => a.hits > 5 && (a.dn < 0 ? a.emits === 0 : a.emits === a.hits) && (a.dn === 0 ? a.K0 === 0 && a.eq : true));

  /* 光が弱くても、すぐ飛び出す（最初の光子が着いたその時刻に電子が 'out'） */
  R.immediate = await p.evaluate(() => {
    const s = TEST.sim('s1'); s.toDefaults(); s.v.I = 10; s.changed('I'); s.resetT(); s.P.log = [];
    TEST.runFor('s1', 1.2, 1 / 120);
    const first = s.P.log[0];
    return { n: s.P.log.length, firstT: first && +first.t.toFixed(3), firstEm: first && first.em, firstSt: first && first.st };
  });
  R.ok.immediate_emission = R.immediate.n >= 1 && R.immediate.firstEm === true && R.immediate.firstSt === 'out' && R.immediate.firstT < 1.0;

  /* 光の強さ：電子の数は変わるが、K の最大値（速さ）は変わらない */
  R.intensity = await p.evaluate(() => {
    const s = TEST.sim('s1'), out = {};
    [20, 100].forEach(I => { s.toDefaults(); s.kmode = 'max'; s.v.I = I; s.changed('I'); s.resetT(); const P = TEST.runFor('s1', 4);
      out[I] = { emits: P.nEmit, K: s.lat.els.filter(e => e.K !== undefined).map(e => +e.K.toFixed(6)).filter((v, i, a) => a.indexOf(v) === i), K0: +peQ(s).K0.toFixed(6) }; });
    s.toDefaults();
    return out;
  });
  R.ok.intensity_count_not_speed = R.intensity[100].emits > 3 * R.intensity[20].emits && R.intensity[20].K.length === 1 && R.intensity[20].K[0] === R.intensity[100].K[0];

  /* 2：アニメで陽極に届く割合 ≒ I/I_sat（統計） */
  R.tube = await p.evaluate(() => {
    const s = TEST.sim('s2'), out = [];
    [[1.0, 'dist'], [0, 'dist'], [-0.4, 'dist'], [-0.8, 'dist'], [-0.97, 'dist'], [-1.2, 'dist'], [-0.5, 'max'], [-1.0, 'max']].forEach(([V, md]) => {
      s.toDefaults(); s.kmode = md; s.v.I = 100; s.changed('I'); s2SetV(s, V); s.resetT();
      s.P.rnd = (function (a) { return function () { a = (a * 1664525 + 1013904223) >>> 0; return a / 4294967296; }; })(12345);
      TEST.runFor('s2', 60, 1 / 60);
      const q = peQ(s), done = s.P.nHitA + s.P.nBack + s.P.el.filter(e => e.miss && e.st === 'back').length;
      out.push({ V, md, V0: +q.V0.toFixed(3), frac: +(s.P.nHitA / Math.max(1, s.P.nEmit)).toFixed(3), expect: +(currentI(V, q.nu, q.k, 100, md) / IsatOf(q.nu, q.k, 100)).toFixed(3), n: s.P.nEmit });
    });
    s.toDefaults();
    return out;
  });
  R.ok.tube_matches_formula = R.tube.every(r => Math.abs(r.frac - r.expect) < 0.06);

  /* 2：最初の設定の曲線（破線）・スライダーの ▼・V の最初は 0・「光電流が流れた」 */
  R.def2 = await p.evaluate(() => {
    const s = TEST.sim('s2'); s.toDefaults(); peRenderPlots(s);
    const marks = [...s.L.querySelectorAll('.vmark.defm')].filter(m => m.style.display !== 'none').map(m => +m.style.getPropertyValue('--m'));
    const exp = [(photonE(PE_DEF.nu) - s.sl.E.vd.min) / (s.sl.E.vd.max - s.sl.E.vd.min), (PE_DEF.nu - PE.NU_MIN) / (PE.NU_MAX - PE.NU_MIN), (lambdaNm(PE_DEF.nu) - 250) / 500, PE_DEF.I / 100];
    s.v.I = 100; s.changed('I'); s.resetT(); const P = TEST.runFor('s2', 3);
    return { V: s.V, legend: s.plotI.leg.textContent, marks, exp, lastHit: P.lastHitT, time: P.time, nHitA: P.nHitA, noPrev: !('prevC' in s) || !s.prevC };
  });
  R.ok.s2_defaults = R.def2.V === 1 && /最初の設定/.test(R.def2.legend) && R.def2.marks.length === 4 && R.def2.marks.slice().sort().every((m, i) => Math.abs(m - R.def2.exp.slice().sort()[i]) < 1e-3) && R.def2.noPrev && R.def2.nHitA > 0 && R.def2.time - R.def2.lastHit < 0.5;
  /* 2026-10-26 の変更：式・考え方エリアのスイッチなし、グラフのドラッグ・リセットなし、ν は 12×10¹⁴ Hz まで、現在の値はたたむ */
  R.misc = await p.evaluate(() => ({ btnEq: !!document.getElementById('btnEq'), reset: document.querySelectorAll('.greset').length, tip: document.querySelectorAll('.gtip').length,
    nuMax: TEST.sim('s1').sl.nu.inp.max, valsClosed: [...document.querySelectorAll('details.pevals')].map(d => !d.open && /現在の値（クリックして開く）/.test(d.querySelector('summary').textContent)),
    bindAlways: !!document.querySelector('#s1 details.bindbox') && !document.querySelector('#s1 details.bindbox').open && !document.querySelector('.bindb') && /＜自由電子の束縛の様子＞（クリックして開く）/.test(document.querySelector('#s1 details.bindbox summary').textContent),
    cyc: [4, 5.2, 6.4, 7.5, 8.6, 9.8, 10.9, 12].map(photonCycles) }));
  R.ok.misc = !R.misc.btnEq && R.misc.reset === 0 && R.misc.tip === 0 && +R.misc.nuMax === 12 && R.misc.valsClosed.length === 2 && R.misc.valsClosed.every(Boolean) && R.misc.bindAlways && new Set(R.misc.cyc).size === 8;
  /* 1：光の強さで光の当たる幅が変わる（比例） */
  R.beam = await p.evaluate(() => { const s = TEST.sim('s1'), out = {}; [20, 50, 100].forEach(I => { s.v.I = I; s.changed('I'); out[I] = s.g.xb - s.g.xa; }); s.toDefaults(); return out; });
  R.ok.beam_width = Math.abs(R.beam[100] / R.beam[50] - 2) < 1e-6 && Math.abs(R.beam[100] / R.beam[20] - 5) < 1e-6;
  /* K₀–ν グラフの上のはし ＝ アニメの上のはし（1440 px） */
  R.align = await p.evaluate(() => ['s1', 's2'].map(id => { const s = TEST.sim(id); peAlignTop(s); return Math.round(s.R.querySelector('.gbox').getBoundingClientRect().top - s.L.querySelector('.pesliders .varbox').getBoundingClientRect().top); }));
  /* λ のスライダー：hν・ν・λ が連動（λ = c/ν） */
  R.lam = await p.evaluate(() => { const s = TEST.sim('s1'), li = s.sl.lam.inp, out = [];
    [260, 300, 400, 500, 700].forEach(L => { li.value = String(L); li.dispatchEvent(new Event('input', { bubbles: true })); const nu = PE.c / (L * 1e-9) / 1e14;
      out.push({ L, nu: s.v.nu, lamTxt: s.sl.lam.val.textContent, E: s.disp('E'), ok: Math.abs(s.v.nu - nu) < 1e-9 && s.sl.lam.val.textContent === L + ' nm' && Math.abs(s.disp('E') - PE.H * nu) < 1e-12 && Math.abs(+s.sl.nu.inp.value - nu) < 0.051 }); });
    s.toDefaults(); const mk = [...s.sl.lam.row.querySelectorAll('.vmark')].filter(m => m.style.display !== 'none').map(m => ({ m: +m.style.getPropertyValue('--m'), t: m.textContent }));
    return { out, leftIsShort: +li.min === 250 && +li.max === 750, mk, lam0: (lambdaNm(nu0Of(s.metal)) - 250) / 500 }; });
  R.ok.lambda_linked = R.lam.out.every(o => o.ok) && R.lam.leftIsShort && R.lam.mk.some(k => Math.abs(k.m - R.lam.lam0) < 1e-3 && /λ/.test(k.t));
  /* 「最大の K₀ の電子だけ見る」を ON にした瞬間に、K₀ でない電子が消える */
  R.kmax = await p.evaluate(() => { const r = {};
    const s = TEST.sim('s1'); s.toDefaults(); s.v.I = 100; s.changed('I'); s.resetT(); TEST.runFor('s1', 2.5); const K0 = peQ(s).K0;
    r.before1 = s.lat.els.filter(e => e.st === 'out' && Math.abs(e.K - K0) > 1e-9).length; s.extra.kmax.click();
    r.after1 = s.lat.els.filter(e => e.st === 'out' && Math.abs(e.K - K0) > 1e-9).length;
    const t = TEST.sim('s2'); t.toDefaults(); t.v.I = 100; t.changed('I'); t.resetT(); TEST.runFor('s2', 1.5); const K2 = peQ(t).K0;
    r.before2 = t.P.el.filter(e => Math.abs(e.K - K2) > 1e-9).length; t.extra.kmax.click(); r.after2 = t.P.el.filter(e => Math.abs(e.K - K2) > 1e-9).length;
    peRenderPlots(t); r.msg = true; s.toDefaults(); t.toDefaults(); return r; });
  R.ok.kmax_clears = R.kmax.before1 > 0 && R.kmax.after1 === 0 && R.kmax.before2 > 0 && R.kmax.after2 === 0;
  /* 束縛の様子は上のアニメと連動（亜鉛・7.5 では飛び出さない） */
  R.bindLink = await p.evaluate(() => { const s = TEST.sim('s1'); const a = s1BindMode(s); s.metal = 'Zn'; const b = s1BindMode(s); s.nu0b.click(); const c = s1BindMode(s); s.toDefaults(); return [a, b, c]; });
  R.ok.bind_linked = R.bindLink.join() === 'out,stay,surf';
  /* 10 秒あたりの数 */
  R.c10 = await p.evaluate(() => { const s = TEST.sim('s2'); s.toDefaults(); const q = peQ(s); return [peCount10(q, 0), peCount10(q, -q.V0), peCount10(q, 5)]; });
  R.ok.count10 = R.c10[0].p === 45 && R.c10[0].e === 45 && R.c10[1].a === 0 && R.c10[2].a === 45;
  R.ok.graph_top_aligned = R.align.every(d => Math.abs(d) <= 1);
  /* スライダーの目印：字のまん中が線の上 */
  R.markAlign = await p.evaluate(() => [...document.querySelectorAll('.pesliders .vmark:not(.defm)')].filter(m => m.offsetParent).map(m => { const k = m.querySelector('.katex'); if (!k) return 0; const a = m.getBoundingClientRect(), b = k.getBoundingClientRect(); return +((b.left + b.right) / 2 - (a.left + 1)).toFixed(1); }));
  R.ok.mark_label_centered = R.markAlign.length >= 4 && R.markAlign.every(d => Math.abs(d) <= 1.5);

  /* 「−V₀」ボタン：光電流 0 */
  R.v0btn = await p.evaluate(() => { const s = TEST.sim('s2'); s.toDefaults(); s.vin.querySelector('.v0b').click(); const q = peQ(s); return { V: s.V, V0: q.V0, I: currentI(s.V, q.nu, q.k, q.I, q.mode), txt: s.vin.querySelector('.vinv').textContent }; });
  R.ok.v0_button = Math.abs(R.v0btn.V + R.v0btn.V0) < 1e-3 && R.v0btn.I < 1e-6;

  /* 縦軸の余裕 */
  R.headroom = await p.evaluate(() => PLOTS.map(P => { const H = P.yr.hi - P.yr.lo; return { lo: P.yr.lo, hi: P.yr.hi, top: (P.yr.hi - (P.o.title.indexOf('光電流') >= 0 ? PE.ISAT100 : photonE(PE.NU_MAX) - workW('Cs'))) / H }; }));
  R.ok.graph_headroom = R.headroom.every(h => h.top >= 0.04);

  /* ▶ スタートのラベル・光る */
  R.play = await p.evaluate(async () => {
    window.scrollTo(0, 0); const b = document.getElementById('bPlay'); const g0 = b.classList.contains('sg-glow'); const t0 = b.textContent; b.click();
    await new Promise(r => setTimeout(r, 300)); const t1 = b.textContent, g1 = b.classList.contains('sg-glow'); b.click(); return { t0, t1, g0, g1, t2: b.textContent };
  });
  R.ok.play_label = R.play.t0 === '▶ スタート' && R.play.t1 === '❚❚ 一時停止' && R.play.t2 === '▶ スタート' && R.play.g0 && !R.play.g1;

  /* すべて最初の設定に戻す */
  R.defaults = await p.evaluate(() => { const s = TEST.sim('s1'); s.v.nu = 12; s.metal = 'Zn'; s.kmode = 'max'; s.v.I = 10; s.bDef.click(); return { nu: s.v.nu, metal: s.metal, kmode: s.kmode, I: s.v.I, label: s.bDef.textContent }; });
  R.ok.defaults = R.defaults.nu === 7.5 && R.defaults.metal === 'Na' && R.defaults.kmode === 'dist' && R.defaults.I === 50 && R.defaults.label === 'すべて最初の設定に戻す';
  R.errs1440 = p.__errs; R.reqs1440 = p.__reqs;
  await p.close();

  /* 幅ごとの横スクロール・ページエラー・外部リクエスト */
  R.widths = [];
  for (const w of [320, 360, 390, 768, 1024, 1440]) {
    const q = await newPage(w, 800);
    await q.evaluate(() => { TEST.sim('s1').bPlay.click(); });
    await q.waitForTimeout(500);
    const r = await q.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth,
      wide: [...document.querySelectorAll('#wrap *')].filter(e => { const b = e.getBoundingClientRect(); return b.width > 0 && b.right > document.documentElement.clientWidth + 1; }).slice(0, 3).map(e => e.className) }));
    R.widths.push({ w, sw: r.sw, cw: r.cw, over: r.wide, errs: q.__errs.length, reqs: q.__reqs.length });
    await q.close();
  }
  R.ok.no_hscroll = R.widths.every(r => r.sw <= r.cw && r.errs === 0 && r.reqs === 0);
  R.ok.errors_requests = R.errs1440.length === 0 && R.reqs1440.length === 0;

  /* スマホ：図の中の V のスライダーが見えていて、指で動かせる */
  const m = await b.newPage({ viewport: { width: 360, height: 740 }, hasTouch: true, isMobile: true, deviceScaleFactor: 2 });
  await m.goto(URL); await m.waitForTimeout(600);
  const inp = await m.$('#s2 .vin input'); await inp.scrollIntoViewIfNeeded(); await m.waitForTimeout(300); const bb = await inp.boundingBox();
  const top = await m.evaluate(([x, y]) => { const e = document.elementFromPoint(x, y); return e && e.matches('input[type=range]'); }, [bb.x + bb.width / 2, bb.y + bb.height / 2]);
  await m.touchscreen.tap(bb.x + bb.width * 0.1, bb.y + bb.height / 2); await m.waitForTimeout(150);
  const V1 = await m.evaluate(() => TEST.sim('s2').V);
  R.mobileV = { box: bb, onTop: top, V_after_tap: V1, inView: bb.x >= 0 && bb.x + bb.width <= 360 };
  R.ok.mobile_V_slider = top && R.mobileV.inView && V1 < 0;
  await m.close();

  /* 横置き：図が 1 画面に入る */
  R.landscape = [];
  for (const [w, h] of [[844, 390], [1024, 768]]) {
    const q = await newPage(w, h);
    const r = await q.evaluate(() => ['s1', 's2'].map(id => { const cv = TEST.sim(id).cv; return { id, h: cv.getBoundingClientRect().height }; }));
    R.landscape.push({ w, h, figs: r }); await q.close();
  }
  R.ok.landscape_fits = R.landscape.every(l => l.figs.every(f => f.h <= l.h));

  await b.close();
  R.allOK = Object.values(R.ok).every(Boolean);
  console.log(JSON.stringify(R, null, 1));
})();
