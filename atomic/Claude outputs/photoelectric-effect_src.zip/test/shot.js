// 使い方：node test/shot.js <幅> <出力 png> [full] [js を実行してから撮る]
const {chromium}=require('playwright');
(async()=>{const [w,out,full,js,sel]=process.argv.slice(2);
const b=await chromium.launch();const p=await b.newPage({viewport:{width:+w,height:900}});
const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('console',m=>{if(m.type()==='error')errs.push(m.text())});
const reqs=[];p.on('request',r=>{if(!r.url().startsWith('file:')&&!r.url().startsWith('data:')&&!r.url().startsWith('blob:'))reqs.push(r.url())});
await p.goto('file:///home/claude/work/pe/dist/photoelectric-effect.html');await p.waitForTimeout(900);
if(js){await p.evaluate(js);await p.waitForTimeout(+(process.env.WAIT||1500));}
if(sel){const e=await p.$(sel);await e.screenshot({path:out});}
else await p.screenshot({path:out,fullPage:full==='full'});
const sw=await p.evaluate(()=>document.documentElement.scrollWidth);
console.log(JSON.stringify({errs,reqs,scrollW:sw,w:+w}));await b.close();})();
