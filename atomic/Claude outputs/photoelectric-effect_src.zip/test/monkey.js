// 全部のボタン・スライダーをでたらめに押して、エラーが出ないか・フレームが重くないかを見る
const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1280,height:900}});
const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file://'+require('path').join(__dirname,'..','dist','photoelectric-effect.html'));await p.waitForTimeout(600);
const r=await p.evaluate(async()=>{let seed=7;const rnd=()=>{seed=(seed*16807)%2147483647;return seed/2147483647;};
 const btns=[...document.querySelectorAll('#wrap button')].filter(b=>!b.closest('footer')&&!b.classList.contains('ft-pages'));
 const ins=[...document.querySelectorAll('#wrap input[type=range]')];let n=0,worst=0;
 for(let i=0;i<400;i++){ if(rnd()<0.6){const b=btns[Math.floor(rnd()*btns.length)];if(b.offsetParent&&!b.disabled){b.click();n++;}}
  else{const e=ins[Math.floor(rnd()*ins.length)];if(e.offsetParent){e.value=String(+e.min+(e.max-e.min)*rnd());e.dispatchEvent(new Event('input',{bubbles:true}));n++;}}
  const t0=performance.now();await new Promise(r=>requestAnimationFrame(()=>r()));worst=Math.max(worst,performance.now()-t0);}
 return {n,worst:Math.round(worst)};});
console.log(JSON.stringify({actions:r.n,worstFrameMs:r.worst,errs}));await b.close();})();
