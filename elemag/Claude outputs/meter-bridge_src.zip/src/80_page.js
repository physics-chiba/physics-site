/* =========================================================================
   80_page.js … ページの組み立て（photoelectric-effect.html と同じ骨組み：低い見出しの帯・モードのタブ・章の扉・セクションのカード）
   モード ①メートルブリッジ（1-1・1-2）、②メートルブリッジの原理（2-1〜2-4）
   ========================================================================= */
'use strict';
var MODES = [
  { id: 'mode1', name: 'メートルブリッジ', secs: ['s1', 's2'], en: 'The Meter Bridge',
    lead: '接点の位置を変えて、検流計に流れる電流の向きと大きさ、金属線の各点の電位を確かめよう。つり合いの位置が分かったら、隠された抵抗の値を求めよう。' },
  { id: 'mode2', name: 'メートルブリッジの原理', secs: ['p1', 'p2', 'p3'], en: 'Why the Meter Bridge Works',
    lead: 'つり合いの式 $\\dfrac{R}{X}=\\dfrac{L}{100-L}$ はどこから来るのか。なぜ精密に測れるのか。3 つの点から確かめよう。' }
];
var SECS = [].concat.apply([], MODES.map(function (m) { return m.secs; }));
var CIRC = '①②③④⑤⑥⑦⑧⑨';
var MODE_BUILT = {};

function buildPage() {
  var wrap = document.getElementById('wrap'), h = '';
  document.getElementById('hero').innerHTML =
    '<div class="hero-in">' +
      '<div class="hero-top">' +
        '<nav class="crumbs" aria-label="現在地"><a class="crumb-home" href="' + SITE_HOME + '" title="楽楽（らくらく）高校物理のトップページへ"><svg class="atom" viewBox="0 0 32 32" aria-hidden="true"><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#3ea0e0" stroke-width="2"/><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#7b5bd6" stroke-width="2" transform="rotate(60 16 16)"/><ellipse cx="16" cy="16" rx="14" ry="5.6" fill="none" stroke="#e07b18" stroke-width="2" transform="rotate(120 16 16)"/><circle cx="16" cy="16" r="3.6" fill="#5aa7ff"/></svg><span>楽楽（らくらく）高校物理</span></a><span class="cs" aria-hidden="true">/</span><a class="crumb" href="' + SITE_HOME + '#sec-elemag">電磁気</a><span class="cs" aria-hidden="true">/</span><span class="crumb now" aria-current="page">メートルブリッジ</span><span class="kdot"></span><span class="en">Meter Bridge</span></nav>' +
      '</div>' +
      '<h1 class="hero-title"><span class="t1">メートルブリッジ</span><span class="t2">〜接点を動かして「同じ高さ」の点を探そう〜</span></h1>' +
      '<div class="introrow"><p class="lead2">' + mathify('一様な金属線の上で接点をすべらせると、検流計の針は右へ左へとふれます。針が 0 を指すのはどこでしょう？　電位を「高さ」で見ると、つり合いの意味がひと目で分かります。') + '</p>' +
        '<button id="bToc" class="tocbtn" type="button" aria-haspopup="true" aria-expanded="false"><span class="ti" aria-hidden="true"></span>コンテンツ一覧</button></div>' +
      '<div id="tocpanel" class="tocpanel" hidden></div>' +
    '</div>';
  document.getElementById('tabs').innerHTML = '<div class="tabs-in"><div class="navsite"><a class="navhome" href="' + SITE_HOME + '" aria-label="ホーム（楽楽高校物理のトップページ）" title="ホーム（楽楽高校物理のトップページ）"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3.5 10.8 12 4l8.5 6.8" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M6 9.5V20h4.5v-5.5h3V20H18V9.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg></a><button class="navpages" id="bPages" type="button" aria-haspopup="dialog" aria-expanded="false" aria-controls="siteDrawer"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="3.5" width="7" height="7" rx="1.6" fill="currentColor"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.6" fill="currentColor" opacity=".55"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.6" fill="currentColor" opacity=".55"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.6" fill="currentColor"/></svg><span>ページ一覧</span></button></div>' +
    MODES.map(function (m, i) { return '<button class="tab" type="button" data-mode="' + m.id + '"><span class="tn">' + CIRC[i] + '</span><span class="tl">' + m.name + '</span></button>'; }).join('') +
    '</div><span class="tprog" aria-hidden="true"></span>';

  MODES.forEach(function (m, i) {
    var secs = m.secs.filter(function (sid) { return DEFS[sid]; });
    h += '<section class="mode" id="' + m.id + '">' +
      '<header class="modehead"><div class="mh-num" aria-hidden="true"><span>' + (i + 1) + '</span></div><div class="mh-body"><p class="mh-en">Chapter ' + String(i + 1).padStart(2, '0') + ' — ' + m.en + '</p>' +
      '<h2><span class="mh-c">' + CIRC[i] + '</span>' + m.name + '</h2><p class="mh-lead">' + m.lead + '</p></div></header>' +
      (secs.length < 2 ? '' : '<div class="seclinks">' + secs.map(function (sid) {
        return '<a href="#' + (i + 1) + '-' + DEFS[sid].num + '" data-toc="' + sid + '">' + CIRC[i] + '-' + DEFS[sid].num + '　' + (DEFS[sid].short || DEFS[sid].title) + '</a>'; }).join('') + '</div>');
    secs.forEach(function (sid) {
      var d = DEFS[sid];
      h += '<article class="sec pesec mbsec' + (d.secCls ? ' ' + d.secCls : '') + '" id="' + sid + '"><div class="sL">' +
        '<div class="sechead"><span class="secnum">' + CIRC[i] + '-' + d.num + '</span><h2>' + d.title + '</h2></div>' +
        '<div class="secdesc">' + (d.desc || '') + '</div><div class="simhost" id="simL_' + sid + '"></div></div>' +
        '<div class="sR" id="simR_' + sid + '"></div></article>';
    });
    h += '</section>';
  });
  h += '<footer></footer>';
  wrap.innerHTML = h;
  document.title = 'メートルブリッジ';
  wrap.querySelectorAll('.modehead,.secdesc,.sechead h2,.seclinks a').forEach(function (e) { e.innerHTML = mathify(e.innerHTML); });
  buildToc();
  document.querySelectorAll('#tabs .tab').forEach(function (b) {
    b.addEventListener('click', function () {
      activateMode(b.dataset.mode); history.replaceState(null, '', '#' + b.dataset.mode);
      window.scrollTo({ top: Math.min(window.pageYOffset, contentTop()), behavior: 'auto' });
    });
  });
  document.querySelectorAll('.seclinks a[data-toc]').forEach(function (a) {
    a.addEventListener('click', function (ev) { ev.preventDefault(); var sid = a.dataset.toc; history.replaceState(null, '', '#' + addrOf(sid)); scrollToSec(sid); });
  });
  window.addEventListener('hashchange', function () { gotoHash(); });
  gotoHash(true);
  if (document.fonts && document.fonts.load) {
    Promise.all(['italic 17px KaTeX_Math', '16px KaTeX_Main'].map(function (f) { return document.fonts.load(f); })).then(function () { LIVE.forEach(function (x) { x.redraw(); }); });
  }
}
/* モードを開く。セクションの図は、はじめて開いたときに作る（隠れている間は大きさが測れないため） */
function activateMode(id) {
  var m = MODES.find(function (x) { return x.id === id; }); if (!m) return;
  document.querySelectorAll('#tabs .tab').forEach(function (b) { var on = b.dataset.mode === id; b.classList.toggle('on', on); b.setAttribute('aria-selected', on ? 'true' : 'false'); });
  document.querySelectorAll('.mode').forEach(function (s) { s.classList.toggle('on', s.id === id); });
  if (!MODE_BUILT[id]) {
    MODE_BUILT[id] = 1;
    m.secs.forEach(function (sid) { var d = DEFS[sid]; if (d) d.build(document.getElementById('simL_' + sid), document.getElementById('simR_' + sid)); });
  } else requestAnimationFrame(function () { LIVE.forEach(function (x) { x.redraw(); }); });
}
function modeOfSec(sid) { return MODES.find(function (x) { return x.secs.indexOf(sid) >= 0; }); }
function addrOf(sid) {
  var i = MODES.findIndex(function (x) { return x.secs.indexOf(sid) >= 0; });
  return (i < 0 || !DEFS[sid]) ? sid : (i + 1) + '-' + DEFS[sid].num;
}
/* アドレス：#mode1／#mode2／#1-1 のようなセクション（前の #s1・#s2 も通す） */
function parseHash(hs) {
  hs = String(hs || '').replace('#', '');
  var m = /^(mode\d)$/.exec(hs);
  if (m) { var mo = MODES.find(function (x) { return x.id === m[1]; }); return mo ? { mode: mo } : {}; }
  var q = /^(\d+)-(\d+)$/.exec(hs);
  if (q) { var mo2 = MODES[+q[1] - 1]; if (mo2) { var sid = mo2.secs.find(function (s) { return DEFS[s] && String(DEFS[s].num) === q[2]; }); return sid ? { mode: mo2, sec: sid } : { mode: mo2 }; } }
  if (DEFS[hs] && modeOfSec(hs)) return { mode: modeOfSec(hs), sec: hs };
  return {};
}
function gotoHash(first) {
  var q = parseHash(location.hash);
  if (!q.mode) { if (first) activateMode(MODES[0].id); return; }
  activateMode(q.mode.id);
  if (q.sec) scrollToSec(q.sec);
  else if (!first) window.scrollTo({ top: contentTop(), behavior: 'auto' });
  else if (location.hash) scrollToSec(q.mode.id);
}
function buildToc() {
  var p = document.getElementById('tocpanel'), b = document.getElementById('bToc'); if (!p || !b) return;
  var h = '<div class="tochead"><b>コンテンツ一覧</b><button type="button" class="tocx" aria-label="閉じる">×</button></div>';
  MODES.forEach(function (m, i) {
    h += '<div class="tocmode">' + CIRC[i] + ' ' + m.name + '</div><ul>';
    m.secs.forEach(function (sid) { var d = DEFS[sid]; if (!d) return;
      h += '<li><a href="#' + addrOf(sid) + '" data-toc="' + sid + '">' + CIRC[i] + '-' + d.num + '　' + mathify(String(d.title).replace(/<[^>]+>/g, '')) + '</a></li>'; });
    h += '</ul>';
  });
  p.innerHTML = h;
  var close = function () { p.hidden = true; b.setAttribute('aria-expanded', 'false'); };
  /* 見出しの帯（低い）は overflow:hidden なので、一覧は画面に固定して、ボタンのすぐ下に出す（途中で切れていた。2026-11-05 千葉さん） */
  document.body.appendChild(p);                       /* 見出しの帯の外へ（帯の重なりの順番と overflow:hidden から出す） */
  var place = function () { if (p.hidden) return; var r = b.getBoundingClientRect(), top = Math.max(8, r.bottom + 8); p.style.position = 'fixed'; p.style.top = top + 'px'; p.style.maxHeight = (innerHeight - top - 12) + 'px'; };
  b.addEventListener('click', function (ev) { ev.stopPropagation(); p.hidden = !p.hidden; b.setAttribute('aria-expanded', p.hidden ? 'false' : 'true'); place(); });
  window.addEventListener('resize', place); window.addEventListener('scroll', place, { passive: true });
  p.querySelector('.tocx').addEventListener('click', close);
  document.addEventListener('click', function (ev) { if (!p.hidden && !p.contains(ev.target) && ev.target !== b) close(); });
  document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape') close(); });
  p.querySelectorAll('[data-toc]').forEach(function (a) {
    a.addEventListener('click', function (ev) {
      ev.preventDefault(); close();
      var sid = a.getAttribute('data-toc'), mo = modeOfSec(sid); if (!mo) return;
      activateMode(mo.id); history.replaceState(null, '', '#' + addrOf(sid)); scrollToSec(sid);
    });
  });
}
function contentTop() { var h = document.getElementById('hero'); return h ? h.offsetTop + h.offsetHeight : 0; }
function tabbarH() { var tb = document.getElementById('tabs'); if (!tb) return 0; return (getComputedStyle(tb).position === 'sticky') ? tb.getBoundingClientRect().height : 0; }
function scrollToSec(sid) {
  var go = function () { var e = document.getElementById(sid); if (!e) return; var y = e.getBoundingClientRect().top + window.pageYOffset - tabbarH() - 8; window.scrollTo({ top: Math.max(0, y), behavior: 'auto' }); };
  go(); requestAnimationFrame(function () { requestAnimationFrame(go); }); setTimeout(go, 180);
}
document.addEventListener('DOMContentLoaded', function () { buildPage(); });

