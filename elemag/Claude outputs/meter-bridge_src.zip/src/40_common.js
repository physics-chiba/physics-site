/* =========================================================================
   40_common.js … 共通の小道具（数式・数値の整形・色・canvas）
   ========================================================================= */
'use strict';
var FONT = '"Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif';   /* canvas の書体（circuit-water-model-3d の CFG.FONT と同じ） */
var MATHF = '"KaTeX_Math","KaTeX_Main",serif', SERF = '"KaTeX_Main","Times New Roman",serif';
var KTX_MAC = {};
function mathify(html) {
  if (!window.katex) return html;
  return String(html).replace(/\$\$([\s\S]+?)\$\$|\$([^$]+?)\$/g, function (m, d, i) {
    try { return katex.renderToString(d || i, { displayMode: !!d, throwOnError: false, macros: KTX_MAC }); } catch (e) { return m; }
  });
}
function tex(s, disp) { try { return katex.renderToString(s, { displayMode: !!disp, throwOnError: false, macros: KTX_MAC }); } catch (e) { return s; } }
function el(tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; }
function fmt(x, d) { if (!isFinite(x)) return '—'; var s = x.toFixed(d); return (/^-0(\.0*)?$/.test(s)) ? s.slice(1) : s; }
function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
/* 電流・電圧の表示（circuit-water-model-3d の fmtVal と同じ考え方。マイナスは「−」） */
function fmtVal(x, unit) {
  if (x === null || x === undefined || isNaN(x)) return '—';
  var a = Math.abs(x), s = x < 0 ? '−' : '', v, u;
  if (unit === 'A') {
    if (a >= 1) { v = a; u = 'A'; } else if (a >= 1e-3) { v = a * 1e3; u = 'mA'; } else if (a >= 1e-6) { v = a * 1e6; u = 'µA'; } else return '0 A';
  } else if (unit === 'V') {
    if (a < 1e-6) return '0 V';
    if (a >= 1) { v = a; u = 'V'; } else { v = a * 1e3; u = 'mV'; }
  } else { v = a; u = unit || ''; }
  var dg = v >= 100 ? 0 : v >= 10 ? 1 : v >= 1 ? 2 : 3;
  return s + v.toFixed(dg) + ' ' + u;
}
/* 検流計の電流は mA で、つねに同じ書き方（小数 2 けた） */
function fmtIg(I) { var m = I * 1000; if (Math.abs(m) < 0.005) return '0.00 mA'; return (m > 0 ? '+' : '−') + Math.abs(m).toFixed(2) + ' mA'; }
/* 電位→色（最低電位＝青、最高電位＝赤。circuit-water-model-3d の potentialColor と同じ） */
function potentialColor(v, vmin, vmax, alpha) {
  var range = vmax - vmin, t = range > 1e-9 ? (v - vmin) / range : 0.5;
  t = Math.max(0, Math.min(1, t));
  return 'hsla(' + (220 * (1 - t)).toFixed(0) + ',75%,50%,' + (alpha === undefined ? 1 : alpha) + ')';
}
/* canvas の大きさを CSS の幅に合わせる（高さは幅×比、最小・最大つき） */
function fitCanvas(cv, ratio, hmin, hmax) {
  var dpr = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
  var w = Math.max(200, cv.clientWidth || (cv.parentNode && cv.parentNode.clientWidth) || 480);
  var h = Math.round(clamp(w * ratio, hmin || 0, hmax || 9999));
  if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); }
  cv.style.height = h + 'px';
  var c = cv.getContext('2d'); c.setTransform(dpr, 0, 0, dpr, 0, 0);
  return { c: c, W: w, H: h, dpr: dpr };
}
/* 白いふちつきの文字 */
function haloText(c, txt, x, y, col, lw) {
  c.save(); c.lineJoin = 'round'; c.lineWidth = lw || 3.5; c.strokeStyle = 'rgba(255,255,255,.92)'; c.strokeText(txt, x, y);
  c.fillStyle = col || '#14171c'; c.fillText(txt, x, y); c.restore();
}
/* 斜体の文字＋添え字（R_AP など）。戻り値は幅 */
function symText(c, x, y, base, sub, col, size, align) {
  c.save(); c.fillStyle = col || '#14171c'; c.textBaseline = 'alphabetic';
  c.font = 'italic ' + size + 'px ' + MATHF; var wb = c.measureText(base).width;
  c.font = Math.round(size * 0.7) + 'px ' + SERF; var ws = sub ? c.measureText(sub).width + 1 : 0;
  var X = x; if (align === 'center') X -= (wb + ws) / 2; else if (align === 'right') X -= wb + ws;
  c.font = 'italic ' + size + 'px ' + MATHF; c.fillText(base, X, y);
  if (sub) { c.font = Math.round(size * 0.7) + 'px ' + SERF; c.fillText(sub, X + wb + 1, y + size * 0.24); }
  c.restore(); return wb + ws;
}
function rrect(c, x, y, w, h, r) { c.beginPath(); if (c.roundRect) c.roundRect(x, y, w, h, r); else c.rect(x, y, w, h); }
function arrowHead(c, x, y, ux, uy, s) { c.beginPath(); c.moveTo(x + ux * s, y + uy * s); c.lineTo(x - ux * s - uy * s * 0.7, y - uy * s + ux * s * 0.7); c.lineTo(x - ux * s + uy * s * 0.7, y - uy * s - ux * s * 0.7); c.closePath(); c.fill(); }
/* 描き直しは「操作したとき・状態が変わったとき」だけ。何度呼ばれても 1 フレームに 1 回 */
var REDRAW = { q: [], pend: false };
function requestDraw(fn) {
  if (REDRAW.q.indexOf(fn) < 0) REDRAW.q.push(fn);
  if (REDRAW.pend) return; REDRAW.pend = true;
  requestAnimationFrame(function () { var q = REDRAW.q; REDRAW.q = []; REDRAW.pend = false; q.forEach(function (f) { f(); }); });
}
