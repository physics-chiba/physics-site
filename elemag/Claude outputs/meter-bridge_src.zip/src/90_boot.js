/* =========================================================================
   90_boot.js … 自動テスト用の窓口（window.TEST）と検算 check()
   ========================================================================= */
'use strict';
function check() {
  var out = {}, worstBal = 0, worstKCL = 0, worstLoop = 0, signOK = true, rgOK = 0, cases = 0;
  [[10, 15], [10, 10], [5, 45], [33, 7], [1, 50], [50, 1], [12, 18], [22, 4.7]].forEach(function (rx) {
    [1, 3, 6].forEach(function (V) {
      var R = rx[0], X = rx[1], Lb = mbBalanceL(R, X); cases++;
      var s = mbSolve({ V: V, R: R, X: X, L: Lb });
      worstBal = Math.max(worstBal, Math.abs(s.I.G));                                        /* つり合いの位置で検流計の電流 0 */
      [20, Lb, 70].forEach(function (L) { var q = mbSolve({ V: V, R: R, X: X, L: L });
        worstKCL = Math.max(worstKCL, Math.abs(q.I.R + q.I.G - q.I.X),                          /* D：入る R＋G ＝ 出る X */
          Math.abs(q.I.AP - q.I.G - q.I.PB)); });                                              /* P：入る AP ＝ 出る G＋PB */
      worstLoop = Math.max(worstLoop, Math.abs(s.U.R + s.U.X - V), Math.abs(s.U.AP + s.U.PB - V), Math.abs(s.U.AP + s.U.G - s.U.R));
      var a = mbSolve({ V: V, R: R, X: X, L: Math.max(MB.LMIN, Lb - 1) }), b = mbSolve({ V: V, R: R, X: X, L: Math.min(MB.LMAX, Lb + 1) });
      if (!(a.I.G > 0 && b.I.G < 0)) signOK = false;                                         /* 手前は P→D（正）、先は D→P（負） */
      [1, 100, 1000].forEach(function (rg) { rgOK = Math.max(rgOK, Math.abs(mbSolve({ V: V, R: R, X: X, L: Lb, Rg: rg }).I.G)); });
    });
  });
  out.cases = cases;
  out.Ig_at_balance_max_A = +worstBal.toExponential(2);
  out.Ig_at_balance_any_Rg_max_A = +rgOK.toExponential(2);
  out.KCL_err_max_A = +worstKCL.toExponential(2);
  out.KVL_err_max_V = +worstLoop.toExponential(2);
  out.sign_before_after_balance = signOK;
  var d = mbSolve({ V: 3, R: 10, X: 15, L: 40 });
  out.default_balance_L = mbBalanceL(10, 15); out.default_VP = +d.v.P.toFixed(6); out.default_VD = +d.v.D.toFixed(6);
  out.table_L20_30_40_50_60_mA = [20, 30, 40, 50, 60].map(function (L) { return +(mbSolve({ V: 3, R: 10, X: 15, L: L }).I.G * 1000).toFixed(2); });
  out.X_from_L_roundtrip = +mbXfromL(10, 40).toFixed(6);
  return out;
}
window.TEST = {
  w1: function () { return DEFS.w1.st; },
  setW1: function (o) { var st = DEFS.w1.st; for (var k in o) st[k] = o[k]; DEFS.w1.changed(); },
  w2: function () { return DEFS.w2.st; },
  check: check,
  s1: function () { return DEFS.s1.st; },
  setL: function (L) { var st = DEFS.s1.st; st.L = L; DEFS.s1.changed(); },
  set1: function (o) { var st = DEFS.s1.st; for (var k in o) st[k] = o[k]; DEFS.s1.changed(); },
  s2: function () { return DEFS.s2.st; },
  set2: function (o) { var st = DEFS.s2.st; for (var k in o) st[k] = o[k]; DEFS.s2.changed(); }
};
