/* =========================================================================
   44_circuit2d.js … 回路図（ひし形のホイートストンブリッジの形）
   ・左上 R（A–D）、右上 X（D–B）、左下 金属線 AP、右下 金属線 PB、まん中 検流計（D–P）
   ・金属線の 2 つの部分は、長さ（L と 100−L）に比例した長さの箱でかく → 接点を動かすと箱の長さが変わる
   ・導線の色＝電位の色（立体図と同じ）。緑の矢印＝電流の向き（電源の＋から出る向きが正）
   仮の座標 640×430 で描く
   ========================================================================= */
'use strict';
var C2 = { VW: 640, VH: 450, A: [110, 205], B: [530, 205], D: [320, 62], P: [320, 348], BY: 412, LX: 46, RX: 594 };

/* o = { s, hideX, labels: 'val' | 'sym'（②-2 の図は I₁・I₂ を書く） } */
function drawCircuit2d(cv, o) {
  var f = fitCanvas(cv, C2.VH / C2.VW, 220, 520), c = f.c, k = f.W / C2.VW, s = o.s;
  var nar = f.W < 500, fz = function (px) { return Math.max(px >= 17 ? 17 : 14, px * k) / k; };   /* 回路図は小さく置くので、文字は 14〜17px より小さくしない */
  c.clearRect(0, 0, f.W, f.H); c.save(); c.scale(k, k); c.lineCap = 'round'; c.lineJoin = 'round';
  var vmin = 0, vmax = s.V, pc = function (v) { return potentialColor(v, vmin, vmax, 1); };
  var A = C2.A, B = C2.B, D = C2.D, P = C2.P;
  var wire = function (pts, v) {
    c.strokeStyle = 'rgba(20,23,28,.55)'; c.lineWidth = 6.5; c.beginPath(); c.moveTo(pts[0][0], pts[0][1]); pts.slice(1).forEach(function (q) { c.lineTo(q[0], q[1]); }); c.stroke();
    c.strokeStyle = pc(v); c.lineWidth = 4; c.beginPath(); c.moveTo(pts[0][0], pts[0][1]); pts.slice(1).forEach(function (q) { c.lineTo(q[0], q[1]); }); c.stroke();
  };
  var lerp = function (a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]; };
  /* 1 本の辺に抵抗の箱。frac＝箱の長さの割合、col＝ふちの色。戻り値＝箱の両はし */
  var edge = function (a, b, va, vb, frac, col, inner) {
    var len = Math.hypot(b[0] - a[0], b[1] - a[1]), bl = len * frac, t0 = (1 - frac) / 2, t1 = 1 - t0;
    var p0 = lerp(a, b, t0), p1 = lerp(a, b, t1);
    wire([a, p0], va); wire([p1, b], vb);
    var ang = Math.atan2(b[1] - a[1], b[0] - a[0]);
    c.save(); c.translate((p0[0] + p1[0]) / 2, (p0[1] + p1[1]) / 2); c.rotate(ang);
    if (inner === 'grad') { var g = c.createLinearGradient(-bl / 2, 0, bl / 2, 0); g.addColorStop(0, pc(va)); g.addColorStop(1, pc(vb)); c.fillStyle = g; c.globalAlpha = .35; c.fillRect(-bl / 2, -11, bl, 22); c.globalAlpha = 1; }
    else { c.fillStyle = '#fff'; c.fillRect(-bl / 2, -11, bl, 22); }
    c.strokeStyle = col; c.lineWidth = 2.6; c.strokeRect(-bl / 2, -11, bl, 22);
    c.restore();
    return [p0, p1];
  };
  /* 電源のまわり（A の網＝電位 V、B の網＝0） */
  wire([A, [C2.LX, A[1]], [C2.LX, C2.BY], [300, C2.BY]], s.V);
  wire([B, [C2.RX, B[1]], [C2.RX, C2.BY], [340, C2.BY]], 0);
  /* 電源の記号（長い板＝＋が左） */
  c.strokeStyle = '#c2249a'; c.lineCap = 'butt';
  c.lineWidth = 3; c.beginPath(); c.moveTo(304, C2.BY - 22); c.lineTo(304, C2.BY + 22); c.stroke();
  c.lineWidth = 7; c.beginPath(); c.moveTo(336, C2.BY - 12); c.lineTo(336, C2.BY + 12); c.stroke(); c.lineCap = 'round';
  c.font = '700 ' + fz(15) + 'px ' + FONT; c.textAlign = 'center'; c.textBaseline = 'middle';
  c.fillStyle = '#c0392b'; c.fillText('＋', 290, C2.BY - 22); c.fillStyle = '#2b5c8a'; c.fillText('−', 352, C2.BY - 22);
  c.fillStyle = '#14171c'; c.font = fz(13) + 'px ' + FONT; c.fillText(fmt(s.V, 1) + ' V', 320, C2.BY + 30);

  /* 4 つの辺 */
  var eR = edge(A, D, s.V, s.v.D, 0.42, '#e07b18');
  var eX = edge(D, B, s.v.D, 0, 0.42, '#e07b18');
  var fl = 0.12 + 0.66 * s.L / 100, fr = 0.12 + 0.66 * (100 - s.L) / 100;
  var eAP = edge(A, P, s.V, s.v.P, fl, '#5f6670', 'grad');
  var ePB = edge(P, B, s.v.P, 0, fr, '#5f6670', 'grad');
  /* 検流計（D–P） */
  var gc = [320, 205], gr = 25;
  wire([D, [gc[0], gc[1] - gr]], s.v.D); wire([[gc[0], gc[1] + gr], P], s.v.P);
  c.fillStyle = '#fff'; c.beginPath(); c.arc(gc[0], gc[1], gr, 0, 7); c.fill();
  c.strokeStyle = '#2b3038'; c.lineWidth = 2.4; c.stroke();
  c.fillStyle = '#14171c'; c.font = 'italic ' + fz(19) + 'px ' + MATHF; c.fillText('G', gc[0], gc[1] + 1);

  /* 電流の矢印（緑。電流 0 のところは出さない） */
  var flowArrow = function (a, b, I, t) {
    if (Math.abs(I) < 1e-5) return;
    var p = lerp(a, b, t), ux = b[0] - a[0], uy = b[1] - a[1], l = Math.hypot(ux, uy); ux /= l; uy /= l;
    if (I < 0) { ux = -ux; uy = -uy; }
    c.fillStyle = '#1c8f4a'; arrowHead(c, p[0], p[1], ux, uy, 8);
  };
  flowArrow(A, eR[0], s.I.R, 0.55); flowArrow(eX[1], B, s.I.X, 0.45);
  flowArrow(A, eAP[0], s.I.AP, 0.6); flowArrow(ePB[1], B, s.I.PB, 0.4);
  flowArrow(P, [gc[0], gc[1] + gr], s.I.G, 0.5);                 /* 正＝P→D（下から上） */
  flowArrow([C2.LX, C2.BY], [C2.LX, A[1]], s.Itot, 0.5);
  flowArrow([C2.RX, B[1]], [C2.RX, C2.BY], s.Itot, 0.5);

  /* 点 */
  c.fillStyle = '#14171c'; [A, B, D, P].forEach(function (q) { c.beginPath(); c.arc(q[0], q[1], 5, 0, 7); c.fill(); });
  var lab = function (t, x, y) { c.font = 'italic ' + fz(21) + 'px ' + MATHF; c.fillStyle = '#14171c'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(t, x, y); };
  lab('A', A[0] + 2, A[1] - 22); lab('B', B[0] - 2, B[1] - 22); lab('D', D[0], D[1] - 22); lab('P', P[0] + 22, P[1] + 16);

  /* 値の名前 */
  var mid = function (e) { return [(e[0][0] + e[1][0]) / 2, (e[0][1] + e[1][1]) / 2]; };
  var name2 = function (e, base, sub, val, side, col) {
    var m = mid(e), dx = side[0], dy = side[1];
    var w = symText(c, m[0] + dx, m[1] + dy, base, sub, col || '#14171c', fz(19), dx < 0 ? 'right' : 'left');
    if (val) { c.font = fz(13) + 'px ' + FONT; c.fillStyle = '#5f6670'; c.textAlign = dx < 0 ? 'right' : 'left'; c.textBaseline = 'alphabetic'; c.fillText(val, m[0] + dx, m[1] + dy + fz(13) * 1.2); }
  };
  var om = function (r) { return fmt(r, r < 10 ? 2 : 1) + ' Ω'; };
  var lo = fz(13) * 1.2;                                 /* 値の行の高さ（文字の大きさに合わせてずらす） */
  name2(eR, 'R', '', om(s.R), [-30, -lo - 6]);
  name2(eX, 'X', '', o.hideX ? '？ Ω' : om(s.X), [30, -lo - 6]);
  name2(eAP, 'R', 'AP', om(s.Rap), [-34, 36]);
  name2(ePB, 'R', 'PB', om(s.Rpb), [34, 36]);
  if (o.labels === 'sym') {
    c.font = 'italic ' + fz(17) + 'px ' + MATHF;
    symText(c, 178, 190, 'I', '1', '#1c8f4a', fz(17), 'center'); symText(c, 462, 190, 'I', '1', '#1c8f4a', fz(17), 'center');
    symText(c, 178, 236, 'I', '2', '#1c8f4a', fz(17), 'center'); symText(c, 462, 236, 'I', '2', '#1c8f4a', fz(17), 'center');
  }
  /* 検流計の電流 */
  if (nar) { c.restore(); return; }
  c.font = '700 ' + fz(13) + 'px ' + FONT; c.textAlign = 'left'; c.textBaseline = 'middle';
  var z = Math.abs(s.I.G) < 5e-6;
  haloText(c, '検流計 ' + fmtIg(s.I.G), gc[0] + gr + 10, gc[1], z ? '#1c8f4a' : '#14171c');
  c.font = fz(11.5) + 'px ' + FONT; haloText(c, z ? '電流が流れない' : (s.I.G > 0 ? '（P → D の向き）' : '（D → P の向き）'), gc[0] + gr + 10, gc[1] + 18, '#69717d');
  c.restore();
}
