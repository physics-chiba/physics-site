/* =========================================================================
   50_sections.js … セクションの中身（①-1・①-2・②-1〜②-3。②-4 は 2026-11-13 にカット）
   DEFS[sid] = { num, title, short, desc, build(L, R) }。build はモードをはじめて開いたときに呼ばれる
   ========================================================================= */
'use strict';
var DEFS = {};
var LIVE = [];          /* 開いているセクション（{ redraw, play? }）。大きさが変わったら描き直す */

/* ---------- 操作の部品 ---------- */
/* スライダー 1 行（名前・値・−／スライダー／＋）。o = { label, min, max, step, get, set, fmtv, num:数値入力 } */
function mkSlider(host, o) {
  var row = el('div', 'vrow cell' + (o.cls ? ' ' + o.cls : '')), head = el('div', 'vhead'), bar = el('div', 'vbar');
  head.appendChild(el('span', 'vl', mathify(o.label))); head.appendChild(el('span', 'vsp'));
  var vv = el('span', 'vv'), ni = null;
  if (o.num) {
    ni = el('input', 'numin'); ni.type = 'number'; ni.min = o.min; ni.max = o.max; ni.step = o.step; ni.inputMode = 'decimal'; ni.setAttribute('aria-label', o.aria || o.label.replace(/<[^>]+>|\$/g, ''));
    vv.appendChild(ni); vv.appendChild(el('span', 'unit', o.unit || ''));
  }
  head.appendChild(vv);
  var dn = el('button', 'tiny nudge', '−'), up = el('button', 'tiny nudge', '＋'), inp = el('input');
  dn.type = up.type = 'button'; dn.title = '1 目盛り小さく'; up.title = '1 目盛り大きく';
  inp.type = 'range'; inp.min = o.min; inp.max = o.max; inp.step = o.step; inp.setAttribute('aria-label', o.aria || o.label.replace(/<[^>]+>|\$/g, ''));
  bar.appendChild(dn); bar.appendChild(inp); bar.appendChild(up);
  row.appendChild(head); row.appendChild(bar); host.appendChild(row);
  var dec = (String(o.step).split('.')[1] || '').length;
  var set = function (x) { x = +clamp(Math.round(x / o.step) * o.step, o.min, o.max).toFixed(dec); o.set(x); };
  inp.addEventListener('input', function () { var x = parseFloat(inp.value); if (o.snap) { var y = o.snap(x); if (y !== null) { o.set(y); return; } } set(x); });   /* スライダーを動かしたときだけ吸いつく（−／＋ボタンでは吸いつかない） */
  dn.addEventListener('click', function () { set(o.get() - o.step); });
  up.addEventListener('click', function () { set(o.get() + o.step); });
  if (ni) {
    ni.addEventListener('change', function () { var x = parseFloat(ni.value); if (isFinite(x)) set(x); else sync(); });
    ni.addEventListener('keydown', function (ev) { if (ev.key === 'Enter') ni.blur(); });
  }
  var sync = function () {
    var x = o.get(); inp.value = String(x); inp.style.setProperty('--p', ((x - o.min) / (o.max - o.min) * 100).toFixed(1) + '%');
    if (ni) { if (document.activeElement !== ni) ni.value = x.toFixed(dec); } else vv.innerHTML = o.fmtv ? o.fmtv(x) : x.toFixed(dec);
  };
  sync();
  return { row: row, sync: sync, inp: inp };
}
/* ボタンの組（えらぶ） */
function mkSeg(host, label, items, get, set) {
  var w = el('div', 'mbseg'); if (label) w.appendChild(el('span', 'seglab', label));
  var bs = items.map(function (it) {
    var b = el('button', 'b tiny segb', it[1]); b.type = 'button'; b.addEventListener('click', function () { set(it[0]); sync(); }); w.appendChild(b); return b;
  });
  var sync = function () { bs.forEach(function (b, i) { var on = items[i][0] === get(); b.classList.toggle('on', on); b.setAttribute('aria-pressed', on ? 'true' : 'false'); }); };
  sync(); host.appendChild(w); return { sync: sync, el: w };
}
function mkBox(host, title, extra) {
  var b = el('div', 'gbox mbbox'), h = el('div', 'ghead'); h.appendChild(el('span', 'gt', mathify(title)));
  if (extra) h.appendChild(extra);
  b.appendChild(h); host.appendChild(b); return b;
}
function mkCanvas(host, cls) { var w = el('div', 'cvwrap mbcv' + (cls ? ' ' + cls : '')), cv = el('canvas'); w.appendChild(cv); host.appendChild(w); return cv; }

/* ---------- 再生（水の流れ）。再生しているときだけ requestAnimationFrame を回す ---------- */
var PLAY = { list: [], raf: 0, last: 0 };
function playLoop(ts) {
  var on = PLAY.list.filter(function (p) { return p.playing; });
  if (!on.length || document.hidden) { PLAY.raf = 0; PLAY.last = 0; return; }
  var dt = PLAY.last ? Math.min(0.05, (ts - PLAY.last) / 1000) : 0; PLAY.last = ts;
  on.forEach(function (p) { p.tick(dt); });
  PLAY.raf = requestAnimationFrame(playLoop);
}
function playKick() { if (!PLAY.raf) { PLAY.last = 0; PLAY.raf = requestAnimationFrame(playLoop); } }
document.addEventListener('visibilitychange', function () { if (!document.hidden) playKick(); });

/* 状態ことば（検流計の針・P と D の電位） */
function mbStatus(s, opt) {
  var Lb = mbBalanceL(s.R, s.X), I = s.I.G, near = Math.abs(s.L - Lb) < 0.05;
  if (Math.abs(I) < 5e-6) return { cls: 'ok', html: '<b>検流計に電流が流れない（針は 0）。</b>点 P と点 D が同じ電位（同じ高さ）になっている。これが<b>つり合いの位置</b>。' };
  if (near) return { cls: 'ok', html: '<b>ほぼ 0 A</b>（検流計 ' + fmtIg(I) + '）。接点の目盛り 0.1 cm では、これ以上は合わせられない。ここがつり合いの位置。' };
  var pv = function (gt) { return opt.hide ? '' : '（' + fmt(s.v.P, 2) + ' V ' + (gt ? '＞' : '＜') + ' ' + fmt(s.v.D, 2) + ' V）'; };
  if (I > 0) return { cls: '', html: '検流計の針は<b>右</b>にふれる（電流は <b>P → D</b>）。点 P のほうが点 D より電位が高い' + pv(true) + '。接点を <b>B の側（右）</b>へ動かすと、P の電位が下がる。' };
  return { cls: '', html: '検流計の針は<b>左</b>にふれる（電流は <b>D → P</b>）。点 P のほうが点 D より電位が低い' + pv(false) + '。接点を <b>A の側（左）</b>へ動かすと、P の電位が上がる。' };
}
function fmtR(r) { return fmt(r, r < 10 ? 2 : 1) + ' Ω'; }

/* ====================== ①-1・①-2 で共通の部品 ====================== */
var DRAG_HINT = '<span class="deschint">▶ 接点（オレンジの持ち手）をドラッグ</span><button type="button" class="b tiny zerob">0 A の接点にする</button>';
var GO_P2 = '原理は <a href="#" class="golink" data-go="p2">③-2 つり合いの式の導き方</a> へ。';
/* 説明文の中のリンク（③-2 へ移る） */
function bindGoLinks(root) {
  root.querySelectorAll('a.golink').forEach(function (a) {
    a.addEventListener('click', function (ev) { ev.preventDefault(); var sid = a.dataset.go; activateMode(modeOfSec(sid).id); history.replaceState(null, '', '#' + addrOf(sid)); scrollToSec(sid); });
  });
}
/* 0 A の位置に吸いつく：つり合いの位置 Lb から SNAP cm 以内なら Lb ちょうどにする。それ以外は null */
var SNAP = 0.5;
function snapBal(st, L) { var Lb = mbBalanceL(st.R, st.X); return Math.abs(L - Lb) < SNAP ? Lb : null; }
/* 接点のドラッグ・スライダーで動かしたときの位置（吸いつき → 0.1 cm 刻み） */
function dragL(st, L) { var y = snapBal(st, L); return y !== null ? y : +clamp(Math.round(L * 10) / 10, MB.LMIN, MB.LMAX).toFixed(1); }
/* つり合っているか（接点の目盛り 0.1 cm 以内） */
function mbNearBal(s) { return Math.abs(s.L - mbBalanceL(s.R, s.X)) < 0.05 || Math.abs(s.I.G) < 5e-6; }
/* 回路図の右上：つり合いの式。hideX のときは X を求める式の形まで */
function balFormula(box, s, hideX) {
  if (!mbNearBal(s)) { box.hidden = true; return; }
  box.hidden = false;
  var Ls = fmt(s.L, 1), Ms = fmt(100 - s.L, 1), r = s.L / (100 - s.L);
  var h = '<p class="fh">0 A になった！ つり合いの式</p><div class="fe">$\\dfrac{R}{X}=\\dfrac{L}{100-L}$</div>';
  if (hideX) h += '<p>$R$ ＝ ' + s.R + ' Ω、$L$ ＝ ' + Ls + ' cm を入れると</p><div class="fe">$\\dfrac{' + s.R + '}{X}=\\dfrac{' + Ls + '}{' + Ms + '}$</div><p>が成り立つ。ここから $X$ を求めよう。</p>';
  else h += '<div class="fe">$\\dfrac{R}{X}=\\dfrac{' + s.R + '}{' + s.X + '}\\fallingdotseq ' + fmt(s.R / s.X, 3) + '$</div><div class="fe">$\\dfrac{L}{100-L}=\\dfrac{' + Ls + '}{' + Ms + '}\\fallingdotseq ' + fmt(r, 3) + '$</div><p class="ok">両辺が等しく、式が成り立っている。</p>';
  box.innerHTML = mathify(h);
}
function circBox(host, title) {
  var b = mkBox(host, title); b.classList.add('circbox'); var row = el('div', 'circrow'); b.appendChild(row);
  var cv = mkCanvas(row, 'half');                              /* 回路図は半分の大きさ。右につり合いの式（0 A のときだけ） */
  var fm = el('div', 'mbformula'); fm.hidden = true; row.appendChild(fm);
  return { box: b, cv: cv, fm: fm };
}

/* ====================== ①-1 メートルブリッジのしくみ ====================== */
DEFS.s1 = {
  num: 1, title: 'メートルブリッジのしくみ', short: 'しくみ',
  desc: '接点 P を金属線の上で動かして、検流計の針が 0 を指す位置を探そう。そのとき、点 P と点 D の電位（立体図の高さ）はどうなっているか。' + GO_P2 + '<br>' + DRAG_HINT,
  build: function (Lh, Rh) {
    var st = { V: MB_DEF.V, R: MB_DEF.R, X: MB_DEF.X, L: MB_DEF.L, Rg: MB.RG, fs: 0.05, hm: 1.6, showBal: false, view: { az: D3.VIEW_TOP.az, tilt: D3.VIEW_TOP.tilt }, phase: {} };
    var solve = function () { st.s = mbSolve(st); };
    solve();
    bindGoLinks(Lh.parentNode);
    var zb = Lh.parentNode.querySelector('.zerob');          /* 「0 A の接点にする」：つり合いの位置（R/X = L/(100−L)）へ接点を動かす */
    if (zb) zb.addEventListener('click', function () { st.L = mbBalanceL(st.R, st.X); changed(); });
    /* 左：装置 → 状態 → 回路図 */
    var bApp = mkBox(Lh, '実験装置'); var cvA = mkCanvas(bApp);
    var msg = el('div', 'msgbox mbmsg'); Lh.appendChild(msg);
    var cb = circBox(Lh, '回路図　<small>導線の色＝電位の色（立体図と同じ）、緑の矢印＝電流の向き</small>');

    /* 右：操作 → 立体図 → 電位のグラフ・表 */
    var ctr = el('div', 'ctrls mbctrls'); Rh.appendChild(ctr);
    var vb = el('div', 'varbox cols2 mbvars'); ctr.appendChild(vb);
    var sl = [];
    sl.push(mkSlider(vb, { label: '接点の位置 $L$', cls: 'wide lrow', min: MB.LMIN, max: MB.LMAX, step: 0.1, num: true, unit: 'cm', aria: '接点の位置 L', snap: function (x) { return snapBal(st, x); }, get: function () { return st.L; }, set: function (x) { st.L = x; changed(); } }));
    sl.push(mkSlider(vb, { label: '電源の電圧 $V$', min: 1, max: 6, step: 0.5, get: function () { return st.V; }, set: function (x) { st.V = x; changed(); }, fmtv: function (x) { return fmt(x, 1) + ' V'; } }));
    sl.push(mkSlider(vb, { label: '既知の抵抗 $R$', min: 1, max: 50, step: 1, get: function () { return st.R; }, set: function (x) { st.R = x; changed(); }, fmtv: function (x) { return x + ' Ω'; } }));
    sl.push(mkSlider(vb, { label: '未知の抵抗 $X$', min: 1, max: 50, step: 1, get: function () { return st.X; }, set: function (x) { st.X = x; changed(); }, fmtv: function (x) { return x + ' Ω'; } }));
    var rgc = el('div', 'vrow cell rgcell'); vb.appendChild(rgc);
    var segRg = mkSeg(rgc, mathify('検流計の内部抵抗 $R_g$'), [[1, '1 Ω'], [10, '10 Ω'], [100, '100 Ω'], [1000, '1000 Ω']], function () { return st.Rg; }, function (v) { st.Rg = v; changed(); });
    var row = el('div', 'row1 mbrow'); ctr.appendChild(row);
    var seg = mkSeg(row, '検流計の目盛り', [[0.05, '±50 mA'], [0.001, '±1 mA（細かく）']], function () { return st.fs; }, function (v) { st.fs = v; draw(); });
    var bDef = el('button', 'b tiny resetall', 'すべて最初の設定に戻す'); bDef.type = 'button'; row.appendChild(bDef);
    bDef.addEventListener('click', function () { st.V = MB_DEF.V; st.R = MB_DEF.R; st.X = MB_DEF.X; st.L = MB_DEF.L; st.Rg = MB.RG; st.fs = 0.05; seg.sync(); segRg.sync(); changed(); });

    var vbtn = el('span', 'viewbtns'), bTop = el('button', 'b tiny viewb on', '斜め上'), bSide = el('button', 'b tiny viewb', '真横');
    bTop.type = bSide.type = 'button'; vbtn.appendChild(bTop); vbtn.appendChild(bSide);
    var b3 = mkBox(Rh, '水流モデルの立体図', vbtn); b3.classList.add('box3d');
    var pbar = el('div', 'mbplay'); b3.appendChild(pbar);
    var bPlay = el('button', 'b play', '▶ 水の流れを見る'); bPlay.type = 'button'; bPlay.id = 'bPlayM'; pbar.appendChild(bPlay);
    pbar.appendChild(el('span', 'mbnote', '高さ＝電位、色＝電位の色、水の粒の速さ＝電流'));
    var hv = el('div', 'varbox mbvars hmvars'); b3.appendChild(hv);
    var slH = mkSlider(hv, { label: '縦の倍率（高さ＝電位の目盛り）', min: 0.5, max: 3, step: 0.1, get: function () { return st.hm; }, set: function (x) { st.hm = x; slH.sync(); requestDraw(draw3); }, fmtv: function (x) { return '× ' + fmt(x, 1); } });
    var cv3 = mkCanvas(b3, 'cv3d');
    var pair = el('div', 'mbpair'); Rh.appendChild(pair);
    var chk = el('label', 'mbchk'); chk.innerHTML = '<input type="checkbox"> つり合いの位置';
    var bV = mkBox(pair, '金属線に沿った電位', chk); var cvV = mkCanvas(bV);
    bV.appendChild(el('p', 'mbcap', mathify('色つきの線＝金属線の電位、オレンジの点線＝点 D の電位。P（○）が点線にのると 0 A。')));
    var bT = mkBox(pair, '各部分の電圧と電流'); var tbl = el('div', 'mbtbl'); bT.appendChild(tbl);
    chk.querySelector('input').addEventListener('change', function (ev) { st.showBal = ev.target.checked; draw(); });

    var setView = function (top) { if (top) { st.view.az = D3.VIEW_TOP.az; st.view.tilt = D3.VIEW_TOP.tilt; } else st.view.tilt = 0.05; bTop.classList.toggle('on', top); bSide.classList.toggle('on', !top); draw3(); };
    bTop.addEventListener('click', function () { setView(true); }); bSide.addEventListener('click', function () { setView(false); });
    D3.bindDrag(cv3, st, function () { requestDraw(draw3); }, function () { bTop.classList.remove('on'); bSide.classList.remove('on'); });
    bindApparatusDrag(cvA, function () { return st.L; }, function (L) {
      st.L = dragL(st, L); changed();
      if (!play.playing) { play.playing = true; syncPlay(); playKick(); }   /* 接点をドラッグしたら、水の流れを見せはじめる */
    });

    var play = { playing: false, tick: function (dt) { D3.advance(st, dt); draw3(); } };
    PLAY.list.push(play);
    var syncPlay = function () { bPlay.textContent = play.playing ? '❚❚ 一時停止' : '▶ 水の流れを見る'; bPlay.classList.toggle('on', play.playing); };
    bPlay.addEventListener('click', function () { play.playing = !play.playing; syncPlay(); if (play.playing) playKick(); else draw3(); });

    function draw3() { D3.render(cv3, st); }
    function drawTbl() {
      var s = st.s, r = function (nm, R, U, I, cls) { return '<tr' + (cls ? ' class="' + cls + '"' : '') + '><th>' + mathify(nm) + '</th><td>' + R + '</td><td>' + fmtVal(U, 'V') + '</td><td>' + fmtVal(I, 'A') + '</td></tr>'; };
      tbl.innerHTML = '<table><thead><tr><th></th><th>抵抗</th><th>電圧</th><th>電流</th></tr></thead><tbody>' +
        r('$R$', fmtR(s.R), s.U.R, s.I.R) + r('$X$', fmtR(s.X), s.U.X, s.I.X) +
        r('AP', fmtR(s.Rap), s.U.AP, s.I.AP) + r('PB', fmtR(s.Rpb), s.U.PB, s.I.PB) +
        r('検流計', fmtR(s.Rg), s.U.G, s.I.G, Math.abs(s.I.G) < 5e-6 ? 'zero' : 'g') + '</tbody></table>' +
        '<p class="mbpot">P の電位 <b>' + fmt(s.v.P, 3) + ' V</b><br>D の電位 <b>' + fmt(s.v.D, 3) + ' V</b></p>' +
        '<p class="mbfoot">B を 0 V とする。電流は電源の＋から出る向きが正（検流計は P → D が正）。AP・PB は金属線の左右の部分。金属線全体の抵抗は ' + MB.RW + ' Ω。</p>';
    }
    function draw() {
      drawApparatus(cvA, { s: st.s, fs: st.fs, showLen: true });
      drawCircuit2d(cb.cv, { s: st.s }); balFormula(cb.fm, st.s, false);
      draw3(); drawVplot(cvV, { s: st.s, showBal: st.showBal, small: true }); drawTbl();
      var m = mbStatus(st.s, {}); msg.className = 'msgbox mbmsg ' + m.cls; msg.innerHTML = m.html;
    }
    function changed() { solve(); sl.forEach(function (q) { q.sync(); }); segRg.sync(); requestDraw(draw); }
    syncPlay(); draw();
    LIVE.push({ redraw: draw });
    DEFS.s1.st = st; DEFS.s1.draw = draw; DEFS.s1.changed = changed;
  }
};

/* ====================== ①-2 未知の抵抗を求めよう ====================== */
var XLIST = [5, 7, 8, 12, 18, 22, 27, 33, 39];
DEFS.s2 = {
  num: 2, title: '未知の抵抗を求めよう', short: '未知の抵抗を求めよう',
  desc: '$X$ の値は隠してあります。検流計の針が 0 になる接点の位置 $L$ を見つけて、$\\dfrac{R}{X}=\\dfrac{L}{100-L}$ から $X$ を求めよう。' + GO_P2 + '<br>' + DRAG_HINT,
  build: function (Lh, Rh) {
    var pick = function (not) { var c; do { c = XLIST[Math.floor(Math.random() * XLIST.length)]; } while (c === not); return c; };
    var st = { V: MB_DEF.V, R: 10, X: 5, L: 50, fs: 0.05 };   /* はじめの X は計算しやすい 5 Ω（「新しい X にする」からはランダム） */
    var solve = function () { st.s = mbSolve(st); }; solve();
    bindGoLinks(Lh.parentNode);
    var zb = Lh.parentNode.querySelector('.zerob');
    if (zb) zb.addEventListener('click', function () { st.L = mbBalanceL(st.R, st.X); changed(); });
    /* 左：装置 → 状態 */
    var bApp = mkBox(Lh, '実験装置'); var cvA = mkCanvas(bApp);
    var msg = el('div', 'msgbox mbmsg'); Lh.appendChild(msg);
    /* 右：操作 → 答えのカード → 回路図 */
    var ctr = el('div', 'ctrls mbctrls'); Rh.appendChild(ctr);
    var vb = el('div', 'varbox cols2 mbvars'); ctr.appendChild(vb);
    var sl = [];
    sl.push(mkSlider(vb, { label: '接点の位置 $L$', cls: 'wide lrow', min: MB.LMIN, max: MB.LMAX, step: 0.1, num: true, unit: 'cm', aria: '接点の位置 L', snap: function (x) { return snapBal(st, x); }, get: function () { return st.L; }, set: function (x) { st.L = x; changed(); } }));
    sl.push(mkSlider(vb, { label: '既知の抵抗 $R$', min: 1, max: 50, step: 1, get: function () { return st.R; }, set: function (x) { st.R = x; changed(); }, fmtv: function (x) { return x + ' Ω'; } }));
    sl.push(mkSlider(vb, { label: '電源の電圧 $V$', min: 1, max: 6, step: 0.5, get: function () { return st.V; }, set: function (x) { st.V = x; changed(); }, fmtv: function (x) { return fmt(x, 1) + ' V'; } }));
    var card = el('div', 'qcard mbq'); Rh.appendChild(card);
    card.innerHTML = mathify('<p class="qt">求め方</p>' +
      '<ol class="mbsteps"><li>接点を動かして、検流計の針が 0 を指す位置を探す。</li>' +
      '<li>そのときの $L$ をものさしで読む。</li>' +
      '<li>つり合いの式 $\\dfrac{R}{X}=\\dfrac{L}{100-L}$ を $X$ について解き、数値を入れて計算する（整数の位まで合っていれば正解）。</li></ol>' +
      '<div class="mbans"><label>$X$ ＝ <span class="spin"><input type="number" class="numin ansin" step="any" min="0" inputmode="decimal" aria-label="X の値"><span class="spinb"><button type="button" class="sup" aria-label="1 大きく">▲</button><button type="button" class="sdn" aria-label="1 小さく">▼</button></span></span> Ω</label>' +
      '<button type="button" class="b chk">答え合わせ</button></div>' +
      '<div class="mbfb" aria-live="polite"></div>' +
      '<div class="mbbtns"><button type="button" class="b tiny newx">新しい X にする</button><button type="button" class="b tiny show">答えを見る</button></div>');
    var cb = circBox(Rh, '回路図');
    var ans = card.querySelector('.ansin'), fb = card.querySelector('.mbfb');
    /* ▲▼ で 1 Ω ずつ選ぶ（整数の位まで合っていれば正解なので） */
    var stepAns = function (d) { var x = parseFloat(ans.value); x = isFinite(x) ? Math.round(x) + d : (d > 0 ? 1 : 0); ans.value = String(Math.max(0, Math.min(99, x))); };
    card.querySelector('.sup').addEventListener('click', function () { stepAns(1); });
    card.querySelector('.sdn').addEventListener('click', function () { stepAns(-1); });
    ans.addEventListener('keydown', function (ev) { if (ev.key === 'ArrowUp') { ev.preventDefault(); stepAns(1); } else if (ev.key === 'ArrowDown') { ev.preventDefault(); stepAns(-1); } });
    card.querySelector('.chk').addEventListener('click', function () {
      var x = parseFloat(ans.value);
      if (!isFinite(x) || x <= 0) { fb.className = 'mbfb ng'; fb.innerHTML = mathify('$X$ の値を数字で入れよう。'); return; }
      if (Math.abs(x - st.X) < 1) { fb.className = 'mbfb ok'; fb.innerHTML = mathify('<b>正解！</b>　$X$ ＝ ' + st.X + ' Ω。'); }
      else { fb.className = 'mbfb ng'; fb.innerHTML = mathify('<b>ちがうようです。</b>' + (mbNearBal(st.s) ? '$L$ の読みと、式の $L$ と $100-L$ の位置を確かめよう。' : '検流計の針はまだ 0 になっていない。接点をもう少し動かそう。')); }
    });
    card.querySelector('.newx').addEventListener('click', function () { st.X = pick(st.X); st.L = 50; ans.value = ''; fb.className = 'mbfb'; fb.innerHTML = ''; changed(); });
    card.querySelector('.show').addEventListener('click', function () {
      var Lb = mbBalanceL(st.R, st.X);
      fb.className = 'mbfb show'; fb.innerHTML = mathify('$X$ ＝ <b>' + st.X + ' Ω</b>。いまの $R$ ＝ ' + st.R + ' Ω では、つり合いの位置は $L$ ＝ ' + fmt(Lb, 1) + ' cm。<br>$X = R\\times\\dfrac{100-L}{L} = ' + st.R + '\\times\\dfrac{' + fmt(100 - Lb, 1) + '}{' + fmt(Lb, 1) + '}\\fallingdotseq ' + fmt(mbXfromL(st.R, +Lb.toFixed(1)), 1) + '$ Ω');
    });
    function draw() {
      drawApparatus(cvA, { s: st.s, fs: st.fs, hideX: true, showLen: true });
      drawCircuit2d(cb.cv, { s: st.s, hideX: true }); balFormula(cb.fm, st.s, true);
      var m = mbStatus(st.s, { hide: true }); msg.className = 'msgbox mbmsg ' + m.cls; msg.innerHTML = m.html;
    }
    function changed() { solve(); sl.forEach(function (q) { q.sync(); }); requestDraw(draw); }
    bindApparatusDrag(cvA, function () { return st.L; }, function (L) { st.L = dragL(st, L); changed(); });
    draw(); LIVE.push({ redraw: draw });
    DEFS.s2.st = st; DEFS.s2.changed = changed;
  }
};

/* ====================== ②-1 金属線の抵抗が長さに比例する理由 ====================== */
DEFS.p1 = {
  num: 1, title: '金属線の抵抗が長さに比例する理由（$R=\\rho\\dfrac{l}{S}$）', short: '抵抗は長さに比例',
  desc: '金属の中の電子の動きと、短い区間を直列・並列につないだ見方から、抵抗が長さに比例し、断面積に反比例することを確かめよう。長さ $l$ と断面積 $S$ を変えてみよう。',
  build: function (Lh, Rh) {
    var st = { l: 40, S: 1 };
    /* 左：操作（いちばん上）→ 10 cm ずつの図 → 円筒の図 */
    var ctr = el('div', 'ctrls mbctrls'); Lh.appendChild(ctr); var vb = el('div', 'varbox cols2 mbvars'); ctr.appendChild(vb);
    var s1 = mkSlider(vb, { label: '長さ $l$', min: 10, max: 100, step: 10, get: function () { return st.l; }, set: function (x) { st.l = x; s1.sync(); EL.setup(st.l, st.S); requestDraw(draw); }, fmtv: function (x) { return x + ' cm'; } });
    var s2 = mkSlider(vb, { label: '断面積', min: 1, max: 3, step: 1, get: function () { return st.S; }, set: function (x) { st.S = x; s2.sync(); EL.setup(st.l, st.S); requestDraw(draw); }, fmtv: function (x) { return mathify(x === 1 ? '$S$' : '$' + x + 'S$'); } });
    var bx = mkBox(Lh, '金属線を 10 cm ずつに分けて考える'); var cv = mkCanvas(bx);
    var vals = el('p', 'mbcap'); bx.appendChild(vals);
    var by = mkBox(Lh, '円筒の形の抵抗で見ると'); var cvY = mkCanvas(by);

    /* 右上：金属の中の電子の動き */
    var pb = el('span', 'viewbtns'), bP = el('button', 'b play eplay', '▶ 電子の動きを見る'); bP.type = 'button'; pb.appendChild(bP);
    var be = mkBox(Rh, '金属の中の電子の動き', pb); var cvE = mkCanvas(be);
    var ecap = el('div', 'mbcap ecap'); be.appendChild(ecap);
    var EL = ELEC.make(cvE);
    var eplay = { playing: false, tick: function (dt) { EL.step(dt); EL.draw(); } };
    PLAY.list.push(eplay);
    bP.addEventListener('click', function () { eplay.playing = !eplay.playing; bP.textContent = eplay.playing ? '❚❚ 一時停止' : '▶ 電子の動きを見る'; if (eplay.playing) playKick(); });
    var ecard = el('div', 'qcard mbq'); Rh.appendChild(ecard);
    ecard.innerHTML = mathify('<p class="qt">電子の動きから考える</p>' +
      '<p>金属の中では、自由電子（青の −）が、ならんだ金属イオン（赤の ＋）にぶつかりながら進む。電池が電子を押すはたらきは、電圧 $V$ が同じなら、<b>金属線が長いほど弱い</b>（電圧が長さ全体に分けられるから）。</p>' +
      '<ul class="mbsteps"><li><b>長さ $l$ が 2 倍</b> → 電子を押すはたらきが $\\dfrac{1}{2}$ → 電子の進む速さが $\\dfrac{1}{2}$ → 電流が $\\dfrac{1}{2}$ → <b>抵抗は 2 倍</b>（$R\\propto l$）</li>' +
      '<li><b>断面積 $S$ が 2 倍</b> → 同じ速さで並んで進む電子の数が 2 倍 → 電流が 2 倍 → <b>抵抗は $\\dfrac{1}{2}$</b>（$R\\propto \\dfrac{1}{S}$）</li></ul>' +
      '<div class="eqbox">$R=\\rho\\dfrac{l}{S}$　（$\\rho$：抵抗率。物質で決まる）</div>');
    var card = el('div', 'qcard mbq'); Rh.appendChild(card);
    card.innerHTML = mathify('<p class="qt">長さに比例する</p><p>同じ金属線の 10 cm の区間は、どこをとっても同じ抵抗 $r$ をもつ（一様だから）。長さ $l$ の金属線は、この区間を $n=\\dfrac{l}{10\\ \\mathrm{cm}}$ 個、<b>直列</b>につないだものなので</p>' +
      '<div class="eqbox">$R = nr \\ \\propto\\ l$</div>' +
      '<p class="qt">断面積に反比例する</p><p>断面積が $2S$ の金属線は、断面積 $S$ の金属線 2 本を<b>並列</b>につないだものと同じなので、抵抗は $\\dfrac{1}{2}$ になる。</p>' +
      '<div class="eqbox">$R=\\rho\\dfrac{l}{S}$　（$\\rho$：抵抗率。物質で決まる）</div>' +
      '<p class="qt">メートルブリッジでは</p><p>1 本の金属線を接点 P で 2 つに分けるので、$\\rho$ と $S$ は共通。</p>' +
      '<div class="eqbox">$\\dfrac{R_{\\mathrm{AP}}}{R_{\\mathrm{PB}}}=\\dfrac{\\rho\\dfrac{L}{S}}{\\rho\\dfrac{100-L}{S}}=\\dfrac{L}{100-L}$</div>' +
      '<p>抵抗の比が、ものさしで読む<b>長さの比</b>におきかわる。これがメートルブリッジの工夫である。</p>');
    function draw() {
      drawCyl(); EL.draw();
      var Ir = st.S / (st.l / 100);
      ecap.innerHTML = mathify('電子の進む速さ：$l$ ＝ 100 cm のときの <b>' + fmt(100 / st.l, 2) + ' 倍</b>　／　電流：$l$ ＝ 100 cm・断面積 $S$ のときの <b>' + fmt(Ir, 2) + ' 倍</b>　→ 抵抗は <b>' + fmt(1 / Ir, 2) + ' 倍</b>');
      var f = fitCanvas(cv, 0.24, 150, 220), c = f.c, W = f.W, H = f.H; c.clearRect(0, 0, W, H);
      var x0 = 36, x1 = W - 20, unit = (x1 - x0) / 10, n = st.l / 10, rr = MB.RW / 10;
      var yc = H * 0.44, gap = 26;
      for (var j = 0; j < st.S; j++) {
        var y = yc + (j - (st.S - 1) / 2) * gap;
        for (var i = 0; i < 10; i++) {
          var on = i < n, xa = x0 + i * unit;
          c.fillStyle = on ? (i % 2 ? '#b9c2cc' : '#9aa4ae') : '#eef1f4'; rrect(c, xa + 1.5, y - 9, unit - 3, 18, 4); c.fill();
          if (on && j === 0 && st.S === 1) { c.font = 'italic 16px ' + MATHF; c.fillStyle = '#3a414c'; c.textAlign = 'center'; c.textBaseline = 'bottom'; c.fillText('r', xa + unit / 2, y - 12); }
        }
      }
      /* はしの導線 */
      c.strokeStyle = '#2b3038'; c.lineWidth = 2;
      var yt = yc - (st.S - 1) / 2 * gap, yb = yc + (st.S - 1) / 2 * gap, xe = x0 + n * unit;
      c.beginPath(); c.moveTo(x0, yt); c.lineTo(x0, yb); c.moveTo(xe, yt); c.lineTo(xe, yb); c.moveTo(x0 - 18, yc); c.lineTo(x0, yc); c.moveTo(xe, yc); c.lineTo(xe + 14, yc); c.stroke();
      /* 長さの寸法 */
      var dy = H - 34; c.strokeStyle = '#9c4e06'; c.fillStyle = '#9c4e06'; c.lineWidth = 1.4;
      c.beginPath(); c.moveTo(x0, dy); c.lineTo(xe, dy); c.stroke(); arrowHead(c, x0 + 5, dy, -1, 0, 5); arrowHead(c, xe - 5, dy, 1, 0, 5);
      c.font = 'bold 13px ' + FONT; c.textAlign = 'center'; c.textBaseline = 'top'; c.fillText('l = ' + st.l + ' cm（10 cm の区間 ' + n + ' 個）', (x0 + xe) / 2 < 120 ? 120 : (x0 + xe) / 2, dy + 5);
      var R = rr * n / st.S;
      vals.innerHTML = mathify('10 cm の区間 1 つの抵抗を $r$ ＝ ' + fmt(rr, 1) + ' Ω とすると（断面積 $S$ のとき）、$R$ ＝ ' + (st.S > 1 ? '$\\dfrac{' + n + '\\times' + fmt(rr, 1) + '}{' + st.S + '}$' : '$' + n + '\\times' + fmt(rr, 1) + '$') + ' ＝ <b>' + fmt(R, 2) + ' Ω</b>');
    }
    /* 円筒の形の抵抗（長さ＝l、断面積＝S の何倍か。太さは断面積の平方根に比例） */
    function drawCyl() {
      var f = fitCanvas(cvY, 0.34, 170, 260), c = f.c, W = f.W, H = f.H; c.clearRect(0, 0, W, H);
      var bw = Math.min(170, W * 0.3), x0 = 34, xmax = W - bw - 40, len = (xmax - x0) * st.l / 100;
      var r0 = Math.min(H * 0.11, 22), ry = r0 * Math.sqrt(st.S), rx = ry * 0.32, yc = H * 0.55, x1 = x0 + len;
      /* 導線 */
      c.strokeStyle = '#3a414c'; c.lineWidth = 1.6; c.beginPath(); c.moveTo(x0 - 26, yc); c.lineTo(x0, yc); c.moveTo(x1, yc); c.lineTo(x1 + rx + 22, yc); c.stroke();
      /* 胴 */
      var g = c.createLinearGradient(0, yc - ry, 0, yc + ry); g.addColorStop(0, '#eef4f9'); g.addColorStop(.35, '#cfdeea'); g.addColorStop(1, '#8fa6ba');
      c.fillStyle = g; c.beginPath(); c.moveTo(x0, yc - ry); c.lineTo(x1, yc - ry); c.ellipse(x1, yc, rx, ry, 0, -Math.PI / 2, Math.PI / 2); c.lineTo(x0, yc + ry); c.closePath(); c.fill();
      c.strokeStyle = '#4a5866'; c.lineWidth = 1.4; c.beginPath(); c.moveTo(x0, yc - ry); c.lineTo(x1, yc - ry); c.ellipse(x1, yc, rx, ry, 0, -Math.PI / 2, Math.PI / 2); c.lineTo(x0, yc + ry); c.stroke();
      /* 左の切り口（断面積） */
      c.fillStyle = '#dfe9f2'; c.beginPath(); c.ellipse(x0, yc, rx, ry, 0, 0, 7); c.fill(); c.stroke();
      c.strokeStyle = '#3a414c'; c.beginPath(); c.moveTo(x0 - 26, yc); c.lineTo(x0 + rx * 0.4, yc); c.stroke();
      /* S の引き出し線 */
      c.font = 'italic 16px ' + MATHF; c.fillStyle = '#14171c'; c.textAlign = 'right'; c.textBaseline = 'middle';
      c.strokeStyle = '#3a414c'; c.lineWidth = 1; c.beginPath(); c.moveTo(x0 - rx * 0.3, yc - ry * 0.75); c.lineTo(x0 - 14, yc - ry - 12); c.stroke();
      c.fillText(st.S === 1 ? 'S' : st.S + 'S', x0 - 15, yc - ry - 14);
      /* 長さ l の寸法 */
      var dy = yc - ry - 22; c.strokeStyle = '#3a414c'; c.fillStyle = '#3a414c'; c.lineWidth = 1.2;
      c.beginPath(); c.moveTo(x0, dy - 7); c.lineTo(x0, dy + 7); c.moveTo(x1, dy - 7); c.lineTo(x1, dy + 7); c.moveTo(x0, dy); c.lineTo(x1, dy); c.stroke();
      arrowHead(c, x0 + 5, dy, -1, 0, 4.5); arrowHead(c, x1 - 5, dy, 1, 0, 4.5);
      c.font = 'bold 13px ' + FONT; var lt = ' = ' + st.l + ' cm', tw = c.measureText(lt).width + 10, mx = (x0 + x1) / 2;
      c.fillStyle = '#fff'; c.fillRect(mx - tw / 2 - 6, dy - 18, tw + 12, 16);
      symText(c, mx - tw / 2 + 4, dy - 4, 'l', '', '#14171c', 16, 'right'); c.fillStyle = '#14171c'; c.textAlign = 'left'; c.textBaseline = 'alphabetic'; c.fillText(lt, mx - tw / 2 + 4, dy - 4);
      /* 抵抗の値（右の枠） */
      var R = MB.RW * st.l / 100 / st.S, bx0 = W - bw - 12, by0 = yc - 26;
      c.fillStyle = '#fff'; rrect(c, bx0, by0, bw, 52, 8); c.fill(); c.strokeStyle = '#e07b18'; c.lineWidth = 2; rrect(c, bx0, by0, bw, 52, 8); c.stroke();
      c.fillStyle = '#14171c'; c.font = 'bold 13px ' + FONT; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('抵抗', bx0 + bw / 2, by0 + 15);
      c.fillStyle = '#9c4e06'; c.font = 'bold 18px ' + FONT; c.fillText(fmt(R, 2) + ' Ω', bx0 + bw / 2, by0 + 36);
      c.fillStyle = '#69717d'; c.font = '12px ' + FONT; c.textBaseline = 'top'; c.textAlign = 'left';
      c.fillText('長さ 100 cm・断面積 S のとき ' + MB.RW + ' Ω', 12, H - 20);
    }
    EL.setup(st.l, st.S); draw(); LIVE.push({ redraw: function () { EL.setup(st.l, st.S); draw(); } });
  }
};

/* ====================== ②-2 つり合いの式の導き方 ====================== */
DEFS.p2 = {
  num: 2, title: 'つり合いの式の導き方', short: 'つり合いの式',
  desc: '検流計に電流が流れないとき、点 P と点 D は等電位である。ここから $\\dfrac{R}{X}=\\dfrac{L}{100-L}$ を導こう。',
  build: function (Lh, Rh) {
    var s = mbSolve({ V: MB_DEF.V, R: MB_DEF.R, X: MB_DEF.X, L: mbBalanceL(MB_DEF.R, MB_DEF.X) });
    var bx = mkBox(Lh, 'つり合っているときの回路（$R$ ＝ ' + MB_DEF.R + ' Ω、$X$ ＝ ' + MB_DEF.X + ' Ω、$L$ ＝ ' + fmt(s.L, 1) + ' cm）'); var cv = mkCanvas(bx, 'w70');
    var bv = mkBox(Lh, '金属線に沿った電位'); var cvV = mkCanvas(bv, 'w70');
    bv.appendChild(el('p', 'mbcap', mathify('A から D へ下がる電圧（$R$ にかかる電圧）と、A から P へ下がる電圧（金属線 AP にかかる電圧）が等しい。')));
    var card = el('div', 'qcard mbq'); Rh.appendChild(card);
    card.innerHTML = mathify('<ol class="mbderiv">' +
      '<li><b>検流計の電流が 0</b> → 検流計の両はしの電圧も 0 なので、<b>P と D は等電位</b>。</li>' +
      '<li>検流計に電流が分かれないので、$R$ と $X$ には<b>同じ電流</b> $I_1$、金属線 AP と PB には<b>同じ電流</b> $I_2$ が流れる。</li>' +
      '<li>A と D の電位差 ＝ A と P の電位差（D と P が等電位だから）<div class="eqbox">$RI_1 = R_{\\mathrm{AP}}I_2$　…①</div>' +
      'D と B の電位差 ＝ P と B の電位差<div class="eqbox">$XI_1 = R_{\\mathrm{PB}}I_2$　…②</div></li>' +
      '<li>① ÷ ② で $I_1$・$I_2$ が消える。<div class="eqbox">$\\dfrac{R}{X}=\\dfrac{R_{\\mathrm{AP}}}{R_{\\mathrm{PB}}}$</div></li>' +
      '<li>金属線の抵抗は長さに比例する（③-1）ので <div class="eqbox">$\\dfrac{R}{X}=\\dfrac{L}{100-L}$　よって　$X=R\\times\\dfrac{100-L}{L}$</div></li></ol>' +
      '<p class="mbcap">数値で確かめる：$\\dfrac{R}{X}=\\dfrac{' + MB_DEF.R + '}{' + MB_DEF.X + '}=' + fmt(MB_DEF.R / MB_DEF.X, 3) + '$、$\\dfrac{L}{100-L}=\\dfrac{' + fmt(s.L, 1) + '}{' + fmt(100 - s.L, 1) + '}=' + fmt(s.L / (100 - s.L), 3) + '$。<br>$I_1$ ＝ ' + fmtVal(s.I.R, 'A') + '、$I_2$ ＝ ' + fmtVal(s.I.AP, 'A') + '、$RI_1$ ＝ ' + fmt(s.U.R, 3) + ' V ＝ $R_{\\mathrm{AP}}I_2$ ＝ ' + fmt(s.U.AP, 3) + ' V。</p>');
    function draw() { drawCircuit2d(cv, { s: s, labels: 'sym', small: true }); drawVplot(cvV, { s: s, showBal: false, small: true }); }
    draw(); LIVE.push({ redraw: draw });
  }
};

/* ====================== ②-3 検流計の内部抵抗の影響を受けない ====================== */
var RG_LIST = [1, 10, 100, 1000];
DEFS.p3 = {
  num: 3, title: '検流計の内部抵抗の影響を受けず、精密に測れる理由', short: '内部抵抗の影響を受けない',
  desc: '検流計の内部抵抗 $R_g$ を変えると、検流計の電流のグラフはどう変わるか。電流が 0 になる位置に注目しよう。',
  build: function (Lh, Rh) {
    var st = { Rg: 10 };
    var bx = mkBox(Lh, '検流計の電流と接点の位置（$R$ ＝ ' + MB_DEF.R + ' Ω、$X$ ＝ ' + MB_DEF.X + ' Ω、$V$ ＝ ' + fmt(MB_DEF.V, 1) + ' V）'); var cv = mkCanvas(bx);
    var ctr = el('div', 'ctrls mbctrls'); Lh.appendChild(ctr); var row = el('div', 'row1 mbrow'); ctr.appendChild(row);
    var seg = mkSeg(row, mathify('検流計の内部抵抗 $R_g$'), RG_LIST.map(function (r) { return [r, r + ' Ω']; }), function () { return st.Rg; }, function (v) { st.Rg = v; requestDraw(draw); });
    var card = el('div', 'qcard mbq'); Rh.appendChild(card);
    card.innerHTML = mathify('<p class="qt">つり合いの式に $R_g$ は出てこない</p><p>つり合いのとき検流計の電流は 0 なので、検流計の両はしの電圧 $R_g\\times 0$ も 0。$R_g$ がいくつでも P と D は等電位で、②-2 の式に $R_g$ は入らない。</p>' +
      '<p>グラフの曲線は $R_g$ によって<b>かたむき（感度）</b>が変わるが、<b>0 を横切る位置は同じ</b>である。</p>' +
      '<p class="qt">なぜ精密か</p><p>電流計・電圧計で抵抗を測るときは、計器の内部抵抗のぶんだけ電流や電圧がずれる。メートルブリッジは「電流が 0 かどうか」だけを見るので、計器の内部抵抗によるずれがない。$X$ は、正確な $R$ と、ものさしで読む長さだけで決まる。</p>' +
      '<p class="mbcap">電源の電圧や金属線全体の抵抗も、つり合いの位置には影響しない（②-1 で $V$ を変えて確かめよう）。</p>');
    var vals = el('p', 'mbcap'); bx.appendChild(vals);
    function draw() {
      drawIgPlot(cv, { V: MB_DEF.V, R: MB_DEF.R, X: MB_DEF.X, Rg: st.Rg, list: RG_LIST });
      var q = mbSolve({ V: MB_DEF.V, R: MB_DEF.R, X: MB_DEF.X, L: 30, Rg: st.Rg });
      vals.innerHTML = mathify('$R_g$ ＝ ' + st.Rg + ' Ω のとき：$L$ ＝ 30.0 cm で検流計の電流 ' + fmtIg(q.I.G) + '、つり合いの位置は ' + fmt(mbBalanceL(MB_DEF.R, MB_DEF.X), 1) + ' cm（$R_g$ によらない）。');
    }
    draw(); LIVE.push({ redraw: draw });
  }
};

/* 画面の幅が変わったら描き直す */
(function () { var t = 0, w = 0; window.addEventListener('resize', function () { clearTimeout(t); t = setTimeout(function () { if (innerWidth === w) return; w = innerWidth; LIVE.forEach(function (x) { x.redraw(); }); }, 120); }); })();
