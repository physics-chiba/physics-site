/* =========================================================================
   42_apparatus.js … 実験装置の図（教科書の実験の挿絵ふう。2026-11-13 千葉さんの見本の図に合わせて作り直し）
   ・中央：メートルブリッジ（木の台。上の面に金属線、手前の面にものさし 0〜100 cm）。左はし A、右はし B
   ・上：左に既知の抵抗 R（丸い抵抗箱）、まん中に検流計 G、右に未知の抵抗 X（板に 2 つのたんし）
   ・右上：検流計の拡大（目盛りに mA の数値）。せまい画面では図の上に大きく出す
       R の右のたんしと X の左のたんしを検流計の左のたんしにつなぐ（この点が D）。R の左 → A、X の右 → B
       検流計の右のたんし → ペン形の接点 P（金属線の上をすべらせる）
   ・下：電池 1 つ（＋を A 側に）
   ・接点はドラッグで動かす。金属線やものさしをクリックしても、そこへ動く
   座標は 1000×560 の仮の座標で描き、canvas の幅に合わせて縮める
   ========================================================================= */
'use strict';
var APP = { VW: 1000, VH: 580, X0: 120, X1: 880, WY: 346, OFF: 0 };   /* OFF：せまい画面で、拡大した検流計のぶん図を下げる量 */
var BAT = { x0: 375, w: 250, cy: 506 };   /* 電池の画像：左はし x0、幅 w、まん中の高さ cy。金具の穴は画像の (34, 97)・(687, 97)（幅 720 のとき） */
var BAR = { x0: 50, x1: 930, top: 330, front: 362, bot: 410, dx: 24 };   /* 台：上の面（奥 top〜手前 front、奥は dx だけ右へずれる）、手前の面（front〜bot） */
function appX(L) { return APP.X0 + (APP.X1 - APP.X0) * L / MB.LEN; }
function appL(x) { return (x - APP.X0) / (APP.X1 - APP.X0) * MB.LEN; }

/* o = { s: 解, hideX, fs: 検流計の目盛り〔A〕, showLen: L と 100−L の寸法を出す } */
function drawApparatus(cv, o) {
  var nar = (cv.clientWidth || 600) < 560;
  APP.OFF = nar ? 300 : 0; APP.WY = 346 + APP.OFF;
  var f = fitCanvas(cv, (580 + APP.OFF) / APP.VW, 190, 760), c = f.c, k = f.W / APP.VW;
  var s = o.s, L = s.L, xp = appX(L), WY = 346;
  var fz = function (px) { return Math.max(nar ? 9.5 : 10.5, px * k) / k; };
  var F = function (px, w) { c.font = (w || '') + ' ' + fz(px) + 'px ' + FONT; };
  var Fm = function (px) { c.font = 'italic ' + fz(px) + 'px ' + MATHF; };
  c.clearRect(0, 0, f.W, f.H);
  c.save(); c.scale(k, k); c.lineCap = 'round'; c.lineJoin = 'round';
  if (nar) { galvZoom(c, s, o.fs || 0.05, 110, 6, 890, 288, F); c.translate(0, APP.OFF); }

  /* ---- 導線 ---- */
  var curve = function (pts) { c.beginPath(); c.moveTo(pts[0][0], pts[0][1]); for (var i = 1; i < pts.length; i++) { var p = pts[i]; if (p.length === 6) c.bezierCurveTo(p[0], p[1], p[2], p[3], p[4], p[5]); else if (p.length === 4) c.quadraticCurveTo(p[0], p[1], p[2], p[3]); else c.lineTo(p[0], p[1]); } };
  var lead = function (pts, col) { c.strokeStyle = 'rgba(20,23,28,.14)'; c.lineWidth = 5.5; curve(pts); c.stroke(); c.strokeStyle = col || '#2b3038'; c.lineWidth = 2.8; curve(pts); c.stroke(); };
  var A = [APP.X0 - 36, WY], B = [APP.X1 + 36, WY];            /* A・B のたんし（台の上の面のはし） */
  var gL = [462, 46], gR = [538, 46];                           /* 検流計のたんし（左＝D、右＝接点へ） */
  var rL = [94, 104], rR = [206, 104];                          /* 抵抗箱のたんし（上に立つ金具の頭。導線はここにつなぐ） */
  var xo = nar ? 0 : 76;                                        /* 広い画面：右上に拡大した検流計を置くので、未知の抵抗を下げる */
  var xL = [770, 150 + xo], xR = [880, 150 + xo];               /* 未知抵抗のたんし */
  var pTop = [xp + 46, WY - 92];                                /* ペン（接点）の上のはし */
  /* 電池のまわり（台の下を通る） */
  lead([A, [A[0] - 40, A[1] + 6, A[0] - 52, 470], [A[0] - 52, 506, 375 + 34.4 * 250 / 720, 506 + (96.7 - 93.5) * 250 / 720]], '#c0392b');
  lead([B, [B[0] + 40, B[1] + 6, B[0] + 52, 470], [B[0] + 52, 506, 375 + 686.6 * 250 / 720, 506 + (96.7 - 93.5) * 250 / 720]]);
  /* R・X・検流計・接点 */

  /* ---- 台（メートルブリッジ） ---- */
  c.save(); c.shadowColor = 'rgba(20,23,28,.18)'; c.shadowBlur = 16; c.shadowOffsetY = 6;
  c.fillStyle = '#d6b98d'; c.beginPath(); c.moveTo(BAR.x0, BAR.front); c.lineTo(BAR.x1, BAR.front); c.lineTo(BAR.x1, BAR.bot); c.lineTo(BAR.x0, BAR.bot); c.closePath(); c.fill(); c.restore();
  var gt = c.createLinearGradient(0, BAR.top, 0, BAR.front); gt.addColorStop(0, '#f1e3c9'); gt.addColorStop(1, '#e5d0ab');
  c.fillStyle = gt; c.beginPath(); c.moveTo(BAR.x0 + BAR.dx, BAR.top); c.lineTo(BAR.x1 + BAR.dx, BAR.top); c.lineTo(BAR.x1, BAR.front); c.lineTo(BAR.x0, BAR.front); c.closePath(); c.fill();
  c.fillStyle = '#c9a774'; c.beginPath(); c.moveTo(BAR.x1, BAR.front); c.lineTo(BAR.x1 + BAR.dx, BAR.top); c.lineTo(BAR.x1 + BAR.dx, BAR.bot - (BAR.front - BAR.top)); c.lineTo(BAR.x1, BAR.bot); c.closePath(); c.fill();
  c.strokeStyle = 'rgba(110,78,36,.5)'; c.lineWidth = 1.3;
  c.beginPath(); c.moveTo(BAR.x0 + BAR.dx, BAR.top); c.lineTo(BAR.x1 + BAR.dx, BAR.top); c.lineTo(BAR.x1 + BAR.dx, BAR.bot - (BAR.front - BAR.top)); c.lineTo(BAR.x1, BAR.bot); c.lineTo(BAR.x0, BAR.bot); c.lineTo(BAR.x0, BAR.front); c.closePath(); c.stroke();
  c.beginPath(); c.moveTo(BAR.x0, BAR.front); c.lineTo(BAR.x1, BAR.front); c.lineTo(BAR.x1 + BAR.dx, BAR.top); c.stroke();
  /* 手前の面：ものさし */
  var tx = function (Lc) { return appX(Lc) - BAR.dx / 2; };
  if (o.showLen) { c.fillStyle = 'rgba(224,123,24,.20)'; c.fillRect(tx(0), BAR.front + 1, tx(L) - tx(0), BAR.bot - BAR.front - 2); }
  c.strokeStyle = '#5a4a1a'; c.fillStyle = '#5a4a1a'; c.textAlign = 'center'; c.textBaseline = 'top';
  for (var i = 0; i <= 100; i++) {
    var x = tx(i), big = i % 10 === 0, mid = i % 5 === 0;
    c.lineWidth = big ? 1.4 : 0.8; c.beginPath(); c.moveTo(x, BAR.front); c.lineTo(x, BAR.front + (big ? 15 : mid ? 10 : 6)); c.stroke();
    if (big && (!nar || i % 20 === 0)) { F(13); c.fillText(String(i), x, BAR.front + 18); }
  }
  if (!nar) { F(12); c.textAlign = 'left'; c.fillText('cm', tx(100) + 14, BAR.front + 18); }

  /* 上の面：金属線と A・B のたんし */
  c.strokeStyle = 'rgba(20,23,28,.25)'; c.lineWidth = 4.5; c.beginPath(); c.moveTo(A[0], WY + 1.5); c.lineTo(B[0], WY + 1.5); c.stroke();
  c.strokeStyle = '#8d96a0'; c.lineWidth = 3.2; c.beginPath(); c.moveTo(A[0], WY); c.lineTo(B[0], WY); c.stroke();
  c.strokeStyle = '#f4f6f8'; c.lineWidth = 1; c.beginPath(); c.moveTo(A[0], WY - 0.8); c.lineTo(B[0], WY - 0.8); c.stroke();
  var screw = function (p) { c.fillStyle = '#6b5a45'; c.beginPath(); c.ellipse(p[0], p[1], 10, 6, 0, 0, 7); c.fill(); c.fillStyle = '#d8ccb8'; c.beginPath(); c.ellipse(p[0], p[1] - 1.5, 7, 4, 0, 0, 7); c.fill(); };
  screw(A); screw(B);
  var tag = function (t, x, y) { Fm(22); c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillStyle = '#14171c'; c.fillText(t, x, y); };
  tag('A', A[0] - 6, WY - 30); tag('B', B[0] + 4, WY - 30);
  if (!nar) { F(12); c.fillStyle = '#69717d'; c.textAlign = 'left'; c.textBaseline = 'bottom'; c.fillText(L < 50 ? '' : '金属線（一様・100 cm）', APP.X0 + 6, WY - 8); c.textAlign = 'right'; c.fillText(L < 50 ? '金属線（一様・100 cm）' : '', APP.X1 - 6, WY - 8); }

  /* 寸法 L と 100−L（台の下） */
  if (o.showLen) {
    var dy = BAR.bot + 22;
    var dim = function (x0, x1, txt) {
      c.strokeStyle = '#9c4e06'; c.fillStyle = '#9c4e06'; c.lineWidth = 1.4;
      c.beginPath(); c.moveTo(x0, dy); c.lineTo(x1, dy); c.moveTo(x0, dy - 7); c.lineTo(x0, dy + 7); c.moveTo(x1, dy - 7); c.lineTo(x1, dy + 7); c.stroke();
      arrowHead(c, x0 + 5, dy, -1, 0, 5); arrowHead(c, x1 - 5, dy, 1, 0, 5);
      F(14, '700'); var tw = c.measureText(txt).width + 12;
      if (Math.abs(x1 - x0) > tw + 14) { c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillStyle = '#f5f3ee'; c.fillRect((x0 + x1) / 2 - tw / 2, dy - 10, tw, 20); c.fillStyle = '#9c4e06'; c.fillText(txt, (x0 + x1) / 2, dy); }
    };
    dim(tx(0), tx(L), 'L = ' + fmt(L, 1) + ' cm'); dim(tx(L), tx(100), '100 − L = ' + fmt(100 - L, 1) + ' cm');
  }

  /* ---- 抵抗箱 R ---- */
  (function () {
    var cx = 150, cy = 118, rx = 84, ry = 26, h = 44;
    c.save(); c.shadowColor = 'rgba(20,23,28,.18)'; c.shadowBlur = 12; c.shadowOffsetY = 4;
    var g = c.createLinearGradient(cx - rx, 0, cx + rx, 0); g.addColorStop(0, '#d9dde2'); g.addColorStop(.5, '#f6f7f8'); g.addColorStop(1, '#c4cad1');
    c.fillStyle = g; c.beginPath(); c.moveTo(cx - rx, cy); c.lineTo(cx - rx, cy + h); c.ellipse(cx, cy + h, rx, ry, 0, Math.PI, 0, true); c.lineTo(cx + rx, cy); c.closePath(); c.fill(); c.restore();
    c.strokeStyle = '#4a4f57'; c.lineWidth = 1.6; c.beginPath(); c.moveTo(cx - rx, cy); c.lineTo(cx - rx, cy + h); c.ellipse(cx, cy + h, rx, ry, 0, Math.PI, 0, true); c.lineTo(cx + rx, cy); c.stroke();
    c.fillStyle = '#fbfaf7'; c.beginPath(); c.ellipse(cx, cy, rx, ry, 0, 0, 7); c.fill(); c.stroke();
    [[-46, -4], [-18, -12], [14, -12], [44, -4], [-28, 10], [4, 12], [34, 10]].forEach(function (q) {
      c.fillStyle = '#3a414c'; c.beginPath(); c.ellipse(cx + q[0], cy + q[1], 6, 4, 0, 0, 7); c.fill(); c.fillStyle = '#9aa1ab'; c.beginPath(); c.ellipse(cx + q[0], cy + q[1] - 1.5, 4, 2.4, 0, 0, 7); c.fill(); });

    F(14, '700'); c.fillStyle = '#14171c'; c.textAlign = 'center'; c.textBaseline = 'top';
    if (nar) { F(15, '700'); c.fillStyle = '#9c4e06'; c.fillText('R ' + fmt(s.R, s.R < 10 ? 1 : 0) + ' Ω', cx, cy + h + ry + 8); }   /* せまい画面は 1 行だけ */
    else { c.fillText('既知の抵抗', cx - 14, cy + h + ry + 6); Fm(17); c.fillText('R', cx + 48, cy + h + ry + 5);
      F(14, '700'); c.fillStyle = '#9c4e06'; c.fillText(fmt(s.R, s.R < 10 ? 1 : 0) + ' Ω', cx, cy + h + ry + 26); }
  })();

  /* ---- 未知抵抗 X ---- */
  (function () {
    c.save(); c.translate(0, xo); var xL = [770, 150], xR = [880, 150];
    var x0 = 742, x1 = 906, y0 = 160, d = 16;
    c.save(); c.shadowColor = 'rgba(20,23,28,.18)'; c.shadowBlur = 10; c.shadowOffsetY = 4;
    c.fillStyle = '#e8d6b4'; c.beginPath(); c.moveTo(x0, y0); c.lineTo(x1, y0); c.lineTo(x1 + d, y0 - 22); c.lineTo(x0 + d, y0 - 22); c.closePath(); c.fill(); c.restore();
    c.fillStyle = '#cdb489'; c.fillRect(x0, y0, x1 - x0, 9);
    c.strokeStyle = 'rgba(110,78,36,.55)'; c.lineWidth = 1.2; c.strokeRect(x0, y0, x1 - x0, 9);
    c.beginPath(); c.moveTo(x0, y0); c.lineTo(x0 + d, y0 - 22); c.lineTo(x1 + d, y0 - 22); c.lineTo(x1, y0); c.stroke();
    /* 抵抗の本体（たんしの間） */
    c.fillStyle = '#fff'; rrect(c, 800, 138, 50, 14, 4); c.fill(); c.strokeStyle = '#e07b18'; c.lineWidth = 2; rrect(c, 800, 138, 50, 14, 4); c.stroke();
    c.strokeStyle = '#4a4f57'; c.lineWidth = 2; c.beginPath(); c.moveTo(xL[0], xL[1] - 5); c.lineTo(800, 145); c.moveTo(850, 145); c.lineTo(xR[0], xR[1] - 5); c.stroke();
    [xL, xR].forEach(function (p) { c.fillStyle = '#6b5a45'; c.beginPath(); c.ellipse(p[0], p[1] - 4, 7, 4.5, 0, 0, 7); c.fill(); c.fillStyle = '#c9a26a'; rrect(c, p[0] - 5, p[1] - 18, 10, 13, 3); c.fill(); });
    F(14, '700'); c.fillStyle = '#14171c'; c.textAlign = 'center'; c.textBaseline = 'top';
    var xv = o.hideX ? '？ Ω' : fmt(s.X, s.X < 10 ? 1 : 0) + ' Ω';
    if (nar) { F(15, '700'); c.fillStyle = '#9c4e06'; c.fillText('X ' + xv, 824, y0 + 18); }
    else { c.fillText('未知の抵抗', 812, y0 + 16); Fm(17); c.fillText('X', 874, y0 + 15);
      F(14, '700'); c.fillStyle = '#9c4e06'; c.fillText(xv, 824, y0 + 36); }
    c.restore();
  })();

  /* ---- 抵抗につなぐ導線（抵抗の絵のあとに描き、たんしの金具の頭につなぐ） ---- */
  var post = function (p, h) {                         /* たんし（真ちゅうの金具） */
    c.fillStyle = '#6b5a45'; c.beginPath(); c.ellipse(p[0], p[1] + h, 8, 4.5, 0, 0, 7); c.fill();
    var g = c.createLinearGradient(p[0] - 6, 0, p[0] + 6, 0); g.addColorStop(0, '#a77c3e'); g.addColorStop(.5, '#e9c88f'); g.addColorStop(1, '#a77c3e');
    c.fillStyle = g; c.fillRect(p[0] - 6, p[1], 12, h); c.fillStyle = '#c9a26a'; c.beginPath(); c.ellipse(p[0], p[1], 6, 3, 0, 0, 7); c.fill();
  };
  post(rL, 18); post(rR, 18);
  var xLt = [xL[0], xL[1] - 18], xRt = [xR[0], xR[1] - 18];
  lead([rL, [20, 110, 30, 290, A[0], A[1]]]);
  lead([rR, [300, 70, 380, 20, gL[0], gL[1]]]);
  lead([xLt, [700, 110 + xo, 560, 0, gL[0], gL[1]]]);
  lead([xRt, [980, 120 + xo, 975, 290, B[0], B[1]]]);
  [rL, rR, xLt, xRt].forEach(function (p) { c.fillStyle = '#e9c88f'; c.beginPath(); c.arc(p[0], p[1], 3.2, 0, 7); c.fill(); c.strokeStyle = '#6b5a45'; c.lineWidth = 1; c.stroke(); });   /* 導線をとめるねじの頭 */

  /* ---- 検流計 G ---- */
  (function () {
    var x0 = 432, x1 = 568, y0 = 58, y1 = 206, d = 12, cx = 500;
    c.save(); c.shadowColor = 'rgba(20,23,28,.22)'; c.shadowBlur = 14; c.shadowOffsetY = 5;
    var gb = c.createLinearGradient(x0, 0, x1, 0); gb.addColorStop(0, '#c9d9ec'); gb.addColorStop(.5, '#e4eef8'); gb.addColorStop(1, '#b7cbe2');   /* 検流計は明るい青。黒いケーブルと見分けられるように */
    c.fillStyle = gb; rrect(c, x0, y0, x1 - x0, y1 - y0, 10); c.fill(); c.restore();
    c.strokeStyle = '#1663b5'; c.lineWidth = 2; rrect(c, x0, y0, x1 - x0, y1 - y0, 10); c.stroke();
    c.fillStyle = '#9fb8d6'; c.beginPath(); c.moveTo(x0 + 6, y0); c.lineTo(x0 + 6 + d, y0 - 10); c.lineTo(x1 - 6 + d, y0 - 10); c.lineTo(x1 - 6, y0); c.closePath(); c.fill();
    [gL, gR].forEach(function (p) { c.fillStyle = '#9aa1ab'; rrect(c, p[0] - 6, p[1] - 4, 12, 14, 3); c.fill(); c.fillStyle = '#6b737e'; c.beginPath(); c.ellipse(p[0], p[1] - 4, 6, 3, 0, 0, 7); c.fill(); });
    c.fillStyle = '#fbfaf7'; rrect(c, x0 + 10, y0 + 10, x1 - x0 - 20, 96, 8); c.fill();
    var pcx = cx, pcy = y0 + 98, R = 68, Aa = 50 * Math.PI / 180;
    c.strokeStyle = '#14171c'; c.fillStyle = '#14171c';
    for (var j = -10; j <= 10; j++) {
      var a = -Math.PI / 2 + Aa * j / 10, big = j % 5 === 0, r0 = R - (big ? 12 : 7);
      c.lineWidth = big ? 1.6 : 1; c.beginPath(); c.moveTo(pcx + Math.cos(a) * r0, pcy + Math.sin(a) * r0); c.lineTo(pcx + Math.cos(a) * R, pcy + Math.sin(a) * R); c.stroke();
    }
    F(11, '800'); c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('0', pcx, pcy - R + 20);
    c.font = 'italic bold ' + fz(16) + 'px ' + MATHF; c.fillStyle = '#1663b5'; c.fillText('G', pcx, pcy - 26);
    var I = s.I.G, fs = o.fs || 0.05, q = I / fs, over = Math.abs(q) > 1.04;
    var an = -Math.PI / 2 + Aa * clamp(q, -1.08, 1.08);
    c.strokeStyle = '#c0392b'; c.lineWidth = 2.4; c.beginPath(); c.moveTo(pcx, pcy); c.lineTo(pcx + Math.cos(an) * (R - 4), pcy + Math.sin(an) * (R - 4)); c.stroke();
    c.fillStyle = '#2b3038'; c.beginPath(); c.arc(pcx, pcy, 5, 0, 7); c.fill();
    if (over) { F(11, '700'); c.fillStyle = '#c0392b'; c.fillText(I > 0 ? 'ふり切れ →' : '← ふり切れ', cx, y0 + 22); }
    if (!nar) { F(14, '700'); c.fillStyle = '#14171c'; c.textAlign = 'right'; c.textBaseline = 'middle'; c.fillText('検流計', x0 - 12, y0 + 72); }
    tag('D', gL[0] - 22, gL[1] - 10);
  })();

  /* 検流計 → 接点のリード線：検流計の前を通る（接点を A 側にしたとき、検流計の後ろにかくれないように、検流計のあとに描く） */
  lead([gR, [620, 0, pTop[0] + 120, pTop[1] - 140, pTop[0], pTop[1]]]);
  if (!nar) galvZoom(c, s, o.fs || 0.05, 690, 2, 994, 178, F);

  /* ---- 接点 P（ペン形。先が金属線にふれる。持ち手はオレンジ） ---- */
  (function () {
    var tip = [xp, WY], top = pTop, ux = top[0] - tip[0], uy = top[1] - tip[1], l = Math.hypot(ux, uy); ux /= l; uy /= l;
    var nx = -uy, ny = ux, at = function (t, w) { return [tip[0] + ux * t + nx * w, tip[1] + uy * t + ny * w]; };
    c.fillStyle = 'rgba(20,23,28,.2)'; c.beginPath(); c.ellipse(xp + 4, WY + 4, 12, 3, 0, 0, 7); c.fill();
    var poly = function (pts, col) { c.fillStyle = col; c.beginPath(); c.moveTo(pts[0][0], pts[0][1]); pts.slice(1).forEach(function (p) { c.lineTo(p[0], p[1]); }); c.closePath(); c.fill(); };
    poly([at(0, 0), at(16, 4), at(16, -4)], '#9aa1ab');                                    /* 金属の先 */
    poly([at(16, 6), at(46, 7), at(46, -7), at(16, -6)], '#4a4f57');
    poly([at(46, 9), at(l, 9), at(l, -9), at(46, -9)], '#e07b18');                         /* 持ち手 */
    c.strokeStyle = 'rgba(120,60,10,.6)'; c.lineWidth = 1.2; c.beginPath(); var q = [at(46, 9), at(l, 9), at(l, -9), at(46, -9)]; c.moveTo(q[0][0], q[0][1]); q.slice(1).forEach(function (p) { c.lineTo(p[0], p[1]); }); c.closePath(); c.stroke();
    c.strokeStyle = 'rgba(255,255,255,.6)'; c.lineWidth = 2; var h0 = at(54, -4), h1 = at(l - 8, -4); c.beginPath(); c.moveTo(h0[0], h0[1]); c.lineTo(h1[0], h1[1]); c.stroke();
    c.fillStyle = '#fff'; c.beginPath(); c.arc(xp, WY, 3.2, 0, 7); c.fill(); c.strokeStyle = '#14171c'; c.lineWidth = 1.5; c.stroke();
    tag('P', xp - 18, WY - 26);
  })();

  /* ---- 電池：千葉さんが用意した画像（電池ボックスに入った単一形の電池、＋が左）をそのまま使う（41_battery_img.js） ---- */
  (function () {
    var x0 = BAT.x0, w = BAT.w, h = w * 187 / 720, y0 = BAT.cy - h / 2, sc = w / 720;
    if (BAT_IMG.complete && BAT_IMG.naturalWidth) c.drawImage(BAT_IMG, x0, y0, w, h);
    F(14, '800'); c.fillStyle = '#fff'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(fmt(s.V, 1) + ' V', x0 + 368 * sc, y0 + 93 * sc);   /* 黒いところに電圧 */
    F(13, '700'); c.fillStyle = '#14171c'; c.textBaseline = 'top'; c.fillText('電池', x0 + w / 2, y0 + h + 4);
  })();
  c.restore();
  return { k: k, xp: xp * k, wy: WY * k, W: f.W, H: f.H };
}

/* 検流計の拡大（目盛りに数値と mA）。(x0,y0)–(x1,y1) の枠に描く */
function galvZoom(c, s, fs, x0, y0, x1, y1, F) {
  var w = x1 - x0, h = y1 - y0, cx = (x0 + x1) / 2, pcy = y1 - h * 0.30, R = Math.min(w * 0.40, h * 0.62), A = 52 * Math.PI / 180;
  c.save(); c.shadowColor = 'rgba(20,23,28,.18)'; c.shadowBlur = 10; c.shadowOffsetY = 3;
  c.fillStyle = '#fbfaf7'; rrect(c, x0, y0, w, h, 12); c.fill(); c.restore();
  c.strokeStyle = '#2b3038'; c.lineWidth = 2; rrect(c, x0, y0, w, h, 12); c.stroke();
  var big = fs >= 0.01, maj = big ? [-50, -25, 0, 25, 50] : [-1, -0.5, 0, 0.5, 1], fsm = fs * 1000;
  c.strokeStyle = '#14171c'; c.fillStyle = '#14171c'; c.textAlign = 'center'; c.textBaseline = 'middle';
  for (var j = -10; j <= 10; j++) {
    var a = -Math.PI / 2 + A * j / 10, mj = j % 5 === 0, r0 = R - (mj ? R * 0.16 : R * 0.09);
    c.lineWidth = mj ? 2 : 1.1; c.beginPath(); c.moveTo(cx + Math.cos(a) * r0, pcy + Math.sin(a) * r0); c.lineTo(cx + Math.cos(a) * R, pcy + Math.sin(a) * R); c.stroke();
  }
  F(15, '700');
  maj.forEach(function (v, i) { var a = -Math.PI / 2 + A * (i - 2) / 2, rr = R * 0.66; c.fillText((v > 0 ? '+' : v < 0 ? '−' : '') + Math.abs(v), cx + Math.cos(a) * rr, pcy + Math.sin(a) * rr + 2); });
  F(12, '700'); c.fillStyle = '#69717d'; c.fillText('mA', cx + R * 0.28, pcy - R * 0.12);
  var I = s.I.G, q = clamp(I / fs, -1.08, 1.08), an = -Math.PI / 2 + A * q;
  c.strokeStyle = '#c0392b'; c.lineWidth = 3; c.beginPath(); c.moveTo(cx, pcy); c.lineTo(cx + Math.cos(an) * (R - 3), pcy + Math.sin(an) * (R - 3)); c.stroke();
  c.fillStyle = '#2b3038'; c.beginPath(); c.arc(cx, pcy, 6, 0, 7); c.fill();
  var zero = Math.abs(I) < 5e-6;
  F(17, '800'); c.fillStyle = zero ? '#1c8f4a' : '#14171c'; c.textBaseline = 'middle'; c.fillText(fmtIg(I), cx, y1 - h * 0.13);
  F(11.5); c.fillStyle = '#69717d'; c.textAlign = 'left'; c.fillText('← D→P', x0 + 10, y1 - h * 0.13); c.textAlign = 'right'; c.fillText('P→D →', x1 - 10, y1 - h * 0.13);
  F(12, '700'); c.fillStyle = '#14171c'; c.textAlign = 'left'; c.textBaseline = 'top'; c.fillText('検流計（拡大）', x0 + 10, y0 + 7);
  if (Math.abs(I / fs) > 1.04) { c.fillStyle = '#c0392b'; c.textAlign = 'right'; c.fillText('ふり切れ', x1 - 10, y0 + 7); }
}

/* 接点のドラッグ。onL(L) を呼ぶ */
function bindApparatusDrag(cv, getL, onL) {
  var drag = false, off = 0, tol = 34;
  var toV = function (ev) { var r = cv.getBoundingClientRect(), k = r.width / APP.VW; tol = Math.max(34, 22 / k); return { x: (ev.clientX - r.left) / k, y: (ev.clientY - r.top) / k }; };
  var near = function (p) { var xp = appX(getL()); return p.y > APP.WY - 100 && p.y < APP.WY + 16 && Math.abs(p.x - (xp + (APP.WY - p.y) * 0.5)) < tol; };   /* ペンはななめなので、上ほど右 */
  var onRail = function (p) { return p.x > APP.X0 - 30 && p.x < APP.X1 + 30 && p.y > APP.WY - 20 && p.y < BAR.bot + APP.OFF + 4; };
  cv.style.touchAction = 'pan-y';
  cv.addEventListener('pointerdown', function (ev) {
    var p = toV(ev);
    if (near(p)) { drag = true; off = p.x - appX(getL()); }
    else if (onRail(p)) { drag = true; off = 0; onL(appL(p.x)); }
    else return;
    cv.setPointerCapture && cv.setPointerCapture(ev.pointerId); cv.style.cursor = 'grabbing'; ev.preventDefault();
  });
  cv.addEventListener('pointermove', function (ev) {
    var p = toV(ev);
    if (drag) { onL(appL(p.x - off)); return; }
    cv.style.cursor = near(p) ? 'grab' : onRail(p) ? 'pointer' : 'default';
  });
  var end = function () { drag = false; cv.style.cursor = 'default'; };
  cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end);
}
