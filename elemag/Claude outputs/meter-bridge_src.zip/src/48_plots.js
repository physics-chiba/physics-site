/* =========================================================================
   48_plots.js … グラフ（白い面・うすい目盛り線・外枠なし：デザイン統一キット 7-6）
   ・金属線に沿った電位（①-1）
   ・検流計の電流 − 接点の位置（②-3：検流計の内部抵抗を変えても 0 になる位置は同じ）
   ========================================================================= */
'use strict';
function niceStep(span, n) { var r = span / (n || 5), p = Math.pow(10, Math.floor(Math.log10(r))), m = r / p; return (m < 1.5 ? 1 : m < 3.5 ? 2 : m < 7.5 ? 5 : 10) * p; }
/* 軸つきの枠を用意。o = { xa, xb, ya, yb, xt, yt, xlab, ylab, pad } */
function plotFrame(c, W, H, o) {
  var L = o.padL || 52, R = W - (o.padR || 16), T = o.padT || 26, B = H - (o.padB || 40);
  var X = function (x) { return L + (x - o.xa) / (o.xb - o.xa) * (R - L); }, Y = function (y) { return B - (y - o.ya) / (o.yb - o.ya) * (B - T); };
  c.fillStyle = '#fff'; rrect(c, L, T, R - L, B - T, 6); c.fill();
  c.strokeStyle = '#eef1f4'; c.lineWidth = 1; c.font = '11px ' + FONT; c.fillStyle = '#69717d';
  var xs = o.xt || niceStep(o.xb - o.xa, 5), ys = o.yt || niceStep(o.yb - o.ya, 5);
  c.textAlign = 'center'; c.textBaseline = 'top';
  for (var x = Math.ceil(o.xa / xs - 1e-9) * xs; x <= o.xb + 1e-9; x += xs) { var px = Math.round(X(x)) + .5; c.beginPath(); c.moveTo(px, T); c.lineTo(px, B); c.stroke(); c.fillText(fmt(x, xs < 1 ? 1 : 0), px, B + 5); }
  c.textAlign = 'right'; c.textBaseline = 'middle';
  for (var y = Math.ceil(o.ya / ys - 1e-9) * ys; y <= o.yb + 1e-9; y += ys) { var py = Math.round(Y(y)) + .5; c.beginPath(); c.moveTo(L, py); c.lineTo(R, py); c.stroke(); c.fillText(o.yfmt ? o.yfmt(y) : fmt(y, ys < 0.1 ? 2 : ys < 1 ? 1 : 0), L - 6, py); }
  if (o.ya < 0 && o.yb > 0) { c.strokeStyle = '#9aa1ab'; c.lineWidth = 1.2; c.beginPath(); c.moveTo(L, Y(0)); c.lineTo(R, Y(0)); c.stroke(); }
  c.fillStyle = '#3a414c'; c.font = '12px ' + FONT;
  if (o.xlab) { c.textAlign = 'right'; c.textBaseline = 'top'; c.fillText(o.xlab, R, B + 21); }
  if (o.ylab) { c.textAlign = 'left'; c.textBaseline = 'bottom'; c.fillText(o.ylab, Math.max(2, L - 40), T - 8); }
  return { X: X, Y: Y, L: L, R: R, T: T, B: B };
}

/* 金属線に沿った電位。o = { s, showBal } */
function drawVplot(cv, o) {
  var f = o.small ? fitCanvas(cv, 0.8, 170, 300) : fitCanvas(cv, 0.62, 230, 380), c = f.c, s = o.s;
  c.clearRect(0, 0, f.W, f.H);
  var ym = s.V * 1.08, P = plotFrame(c, f.W, f.H, { xa: 0, xb: 100, ya: 0, yb: ym, xt: o.small ? 20 : 10, padL: o.small ? 36 : 52, padR: o.small ? 10 : 16, xlab: o.small ? 'A からの位置〔cm〕' : '金属線の位置〔cm〕（A から）', ylab: '電位〔V〕' });
  /* 金属線（色＝電位の色） */
  c.lineCap = 'round'; c.lineWidth = 4;
  for (var x = 0; x < 100; x += 1) {
    var v0 = mbWireV(s, x), v1 = mbWireV(s, Math.min(100, x + 1));
    c.strokeStyle = potentialColor((v0 + v1) / 2, 0, s.V, 1); c.beginPath(); c.moveTo(P.X(x), P.Y(v0)); c.lineTo(P.X(x + 1), P.Y(v1)); c.stroke();
  }
  /* つり合いの位置（チェックしたときだけ） */
  if (o.showBal) {
    var Lb = mbBalanceL(s.R, s.X), xb = P.X(Lb);
    c.save(); c.setLineDash([3, 4]); c.strokeStyle = '#1c8f4a'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(xb, P.T); c.lineTo(xb, P.B); c.stroke(); c.restore();
    c.font = 'bold 11.5px ' + FONT; c.textAlign = Lb > 70 ? 'right' : 'left'; c.textBaseline = 'top';
    haloText(c, 'つり合いの位置 ' + fmt(Lb, 1) + ' cm', xb + (Lb > 70 ? -5 : 5), P.T + 4, '#1c8f4a');
  }
  /* D の電位（横線） */
  var yd = P.Y(s.v.D);
  c.save(); c.setLineDash([7, 5]); c.strokeStyle = '#e07b18'; c.lineWidth = 2; c.beginPath(); c.moveTo(P.L, yd); c.lineTo(P.R, yd); c.stroke(); c.restore();
  c.font = 'bold 12px ' + FONT; c.textBaseline = 'bottom';
  var dRight = s.L < 55;
  c.textAlign = dRight ? 'right' : 'left'; haloText(c, (f.W < 480 ? 'D ' : '点 D の電位 ') + fmt(s.v.D, 2) + ' V', dRight ? P.R - 4 : P.L + 4, yd - 4, '#9c4e06');
  /* 接点 P と、P・D の電位の差（検流計にかかる電圧） */
  var xp = P.X(s.L), yp = P.Y(s.v.P);
  if (Math.abs(yp - yd) > 6) {
    c.strokeStyle = '#14171c'; c.lineWidth = 1.4; c.beginPath(); c.moveTo(xp, yp); c.lineTo(xp, yd); c.stroke();
    c.fillStyle = '#14171c'; var dn = yd > yp ? 1 : -1; arrowHead(c, xp, yd - dn * 5, 0, dn, 4.5); arrowHead(c, xp, yp + dn * 5, 0, -dn, 4.5);
    c.font = '11.5px ' + FONT; c.textAlign = s.L > 60 ? 'right' : 'left'; c.textBaseline = 'middle';
    haloText(c, (f.W < 480 ? '' : '検流計にかかる') + '電圧 ' + fmt(Math.abs(s.U.G), 3) + ' V', xp + (s.L > 60 ? -8 : 8), (yp + yd) / 2, '#14171c');
  }
  c.fillStyle = '#fff'; c.beginPath(); c.arc(xp, yp, 6.5, 0, 7); c.fill(); c.strokeStyle = '#14171c'; c.lineWidth = 2.2; c.stroke();
  c.font = 'italic bold 15px ' + MATHF; c.textAlign = 'center'; c.textBaseline = 'bottom'; haloText(c, 'P', xp, yp - 9, '#14171c');
  /* A・B の名前 */
  c.font = 'italic 14px ' + MATHF; c.textBaseline = 'middle';
  c.textAlign = 'left'; haloText(c, 'A', P.L + 5, P.Y(s.V) - 10, '#14171c'); c.textAlign = 'right'; haloText(c, 'B', P.R - 5, P.Y(0) - 10, '#14171c');
}

/* ②-3：検流計の電流 − 接点の位置。Rg の値をいくつか重ねる */
function drawIgPlot(cv, o) {
  var f = fitCanvas(cv, 0.66, 240, 400), c = f.c;
  c.clearRect(0, 0, f.W, f.H);
  var base = { V: o.V, R: o.R, X: o.X }, lim = 120;
  var P = plotFrame(c, f.W, f.H, { xa: 0, xb: 100, ya: -lim, yb: lim, xt: 10, yt: 40, padL: 50, xlab: '接点の位置 L〔cm〕', ylab: '検流計の電流〔mA〕' });
  c.save(); c.beginPath(); c.rect(P.L, P.T, P.R - P.L, P.B - P.T); c.clip();
  var list = o.list;
  list.forEach(function (rg) {
    var on = Math.abs(rg - o.Rg) < 1e-9;
    c.strokeStyle = on ? '#e07b18' : 'rgba(105,113,125,.45)'; c.lineWidth = on ? 3 : 1.5;
    c.beginPath();
    for (var L = 1; L <= 99; L += 0.5) { var q = mbSolve({ V: base.V, R: base.R, X: base.X, L: L, Rg: rg }); var y = P.Y(q.I.G * 1000); if (L === 1) c.moveTo(P.X(L), y); else c.lineTo(P.X(L), y); }
    c.stroke();
  });
  c.restore();
  var Lb = mbBalanceL(o.R, o.X), xb = P.X(Lb);
  c.fillStyle = '#1c8f4a'; c.beginPath(); c.arc(xb, P.Y(0), 6, 0, 7); c.fill();
  c.font = 'bold 12px ' + FONT; c.textAlign = 'left'; c.textBaseline = 'top'; haloText(c, 'どの曲線も L = ' + fmt(Lb, 1) + ' cm で 0', xb + 8, P.Y(0) + 6, '#1c8f4a');
  /* 曲線の名前（右はし） */
  c.font = '11px ' + FONT; c.textAlign = 'right'; c.textBaseline = 'middle';
  list.forEach(function (rg) {
    var q = mbSolve({ V: base.V, R: base.R, X: base.X, L: 92, Rg: rg }), y = P.Y(q.I.G * 1000);
    if (y > P.T + 6 && y < P.B - 6) { var col = Math.abs(rg - o.Rg) < 1e-9 ? '#9c4e06' : '#69717d', tx = ' = ' + rg + ' Ω'; c.font = '11.5px ' + FONT; var tw = c.measureText(tx).width; c.textAlign = 'right'; c.textBaseline = 'middle'; haloText(c, tx, P.X(92) - 4, y - 9, col); symText(c, P.X(92) - 4 - tw, y - 5, 'R', 'g', col, 13, 'right'); }
  });
}
