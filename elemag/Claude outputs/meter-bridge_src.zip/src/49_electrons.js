/* =========================================================================
   49_electrons.js … ②-1 右上：金属の中を電子が動くようす（円筒の金属線）
   ・赤い ＋ ＝ 金属イオン（ならんで動かない）、青い − ＝ 自由電子
   ・電子は熱運動（ばらばらの向き）をしながら、電池に押されて左（＋極の側）へ流れる。イオンにぶつかると黄色く光る
   ・左はしから出た電子は導線を通って電池へ、電池から右はしの導線を通ってまた金属に入る（電子の数は増えも減りもしない）
   ・電池の電圧 V は一定。長さ l が長いと、電子を押すはたらき（電場 V/l）が弱く、流れる速さが遅い
     断面積 S が大きいと、並んで流れる電子が多い → 電流 I ∝ S/l、抵抗 R = V/I ∝ l/S
   ・側面から見た図なので、円筒の太さ（直径）は √S に比例してかく。電子の数は体積（l×S）に比例
   ========================================================================= */
'use strict';
var ELEC = (function () {
  function make(cv) {
    var E = { cv: cv, l: 40, S: 1, ions: [], els: [], geo: null, flash: [], t: 0 };
    E.setup = function (l, S) {
      E.l = l; E.S = S;
      var W = cv.clientWidth || 480, H = Math.round(clamp(W * 0.56, 230, 340));
      var x0 = 40, xmax = W - 34, len = (xmax - x0) * l / 100, rmax = H * 0.34, ry = rmax * Math.sqrt(S / 3), rx = ry * 0.3, yc = H * 0.4;
      E.geo = { W: W, H: H, x0: x0, x1: x0 + len, ry: ry, rx: rx, yc: yc };
      var g = 26; E.ions = [];
      for (var x = x0 + g * 0.7; x < x0 + len - 6; x += g) for (var y = yc - ry + g * 0.55; y < yc + ry - 6; y += g * 0.9) E.ions.push({ x: x, y: y, f: 0 });
      var n = Math.max(3, Math.round(len * 2 * ry / 620 * Math.sqrt(S)));   /* 電子の数（側面の面積 × 奥行き √S ＝ 体積に比例） */
      E.els = [];
      for (var i = 0; i < n; i++) { var a = Math.random() * 6.283; E.els.push({ x: x0 + Math.random() * len, y: yc - ry + 6 + Math.random() * (2 * ry - 12), vx: Math.cos(a), vy: Math.sin(a) }); }
      /* 導線の道すじ：金属の左はし → 左下 → 電池（＋極から入って−極へ）→ 右下 → 金属の右はし */
      var yb = H - 26, xl = 18, xr = W - 14;
      E.path = [[x0, yc], [xl, yc], [xl, yb], [xr, yb], [xr, yc], [x0 + len + rx, yc]];
      E.plen = 0; for (var k = 1; k < E.path.length; k++) E.plen += Math.hypot(E.path[k][0] - E.path[k - 1][0], E.path[k][1] - E.path[k - 1][1]);
      /* 導線の中の電子：いまの流れの量（1 秒あたりに金属の左はしから出る数）に合わせて、等間隔に置いておく */
      var flux = n * E.vd() / len, T = E.plen / E.vw, m = Math.max(2, Math.round(flux * T));
      E.wire = []; for (var j = 0; j < m; j++) E.wire.push({ s: E.plen * (j + 0.5) / m });
    };
    E.vd = function () { return 14 * (100 / E.l); };      /* 電子の流れる速さ（電場 V/l に比例） */
    E.vw = 90;                                            /* 導線の中を進む速さ（見やすさのための一定の値） */
    E.at = function (sv) {                                /* 道すじの上で s だけ進んだ点 */
      for (var k = 1; k < E.path.length; k++) { var a = E.path[k - 1], b = E.path[k], d = Math.hypot(b[0] - a[0], b[1] - a[1]); if (sv <= d) return [a[0] + (b[0] - a[0]) * sv / d, a[1] + (b[1] - a[1]) * sv / d]; sv -= d; }
      return E.path[E.path.length - 1];
    };
    /* 1 フレーム進める */
    E.step = function (dt) {
      var G = E.geo; if (!G) return;
      var vt = 34, vd = E.vd();                              /* 熱運動の速さ（一定）、流れる速さ（電場 V/l に比例） */
      var out = [];
      E.els.forEach(function (e, idx) {
        e.x += (e.vx * vt - vd) * dt; e.y += e.vy * vt * dt;
        if (e.y < G.yc - G.ry + 5) { e.y = G.yc - G.ry + 5; e.vy = Math.abs(e.vy); }
        if (e.y > G.yc + G.ry - 5) { e.y = G.yc + G.ry - 5; e.vy = -Math.abs(e.vy); }
        if (e.x < G.x0) { out.push(idx); return; }                 /* 左はしから出た電子は、導線へ */
        if (e.x > G.x1 - 2) { e.x = G.x1 - 2; e.vx = -Math.abs(e.vx); }
        for (var i = 0; i < E.ions.length; i++) {             /* イオンにぶつかったら、向きがばらばらに変わる */
          var o = E.ions[i], dx = e.x - o.x, dy = e.y - o.y;
          if (dx * dx + dy * dy < 81 && o.f < 0.4) { var a = Math.random() * 6.283; e.vx = Math.cos(a); e.vy = Math.sin(a); o.f = 1; break; }
        }
      });
      for (var q = out.length - 1; q >= 0; q--) { E.els.splice(out[q], 1); E.wire.push({ s: 0 }); }
      /* 導線の中の電子を進め、右はしまで来たら金属に入れる */
      var keep = [];
      E.wire.forEach(function (w) {
        w.s += E.vw * dt;
        if (w.s >= E.plen) { var a = Math.random() * 6.283; E.els.push({ x: G.x1 - 4, y: G.yc - G.ry * 0.8 + Math.random() * G.ry * 1.6, vx: -Math.abs(Math.cos(a)), vy: Math.sin(a) }); }
        else keep.push(w);
      });
      E.wire = keep;
      E.ions.forEach(function (o) { o.f = Math.max(0, o.f - dt * 2.2); });
    };
    E.draw = function () {
      var G = E.geo, f = fitCanvas(cv, G.H / G.W, 230, 340), c = f.c;
      if (Math.abs(f.W - G.W) > 2) { E.setup(E.l, E.S); G = E.geo; }
      c.clearRect(0, 0, f.W, f.H);
      var x0 = G.x0, x1 = G.x1, ry = G.ry, rx = G.rx, yc = G.yc;
      /* 電池とスイッチのない回路（左が＋極） */
      var yb = G.H - 26, xl = 18, xr = G.W - 14;
      c.strokeStyle = '#2b3038'; c.lineWidth = 1.6;
      c.beginPath(); c.moveTo(x0, yc); c.lineTo(xl, yc); c.lineTo(xl, yb); c.lineTo(G.W / 2 - 8, yb); c.moveTo(G.W / 2 + 6, yb); c.lineTo(xr, yb); c.lineTo(xr, yc); c.lineTo(x1 + rx, yc); c.stroke();
      c.lineWidth = 2; c.beginPath(); c.moveTo(G.W / 2 - 8, yb - 14); c.lineTo(G.W / 2 - 8, yb + 14); c.stroke();
      c.lineWidth = 5; c.beginPath(); c.moveTo(G.W / 2 + 4, yb - 8); c.lineTo(G.W / 2 + 4, yb + 8); c.stroke();
      c.font = 'bold 12px ' + FONT; c.textAlign = 'center'; c.textBaseline = 'bottom'; c.fillStyle = '#c0392b'; c.fillText('＋', G.W / 2 - 20, yb - 6); c.fillStyle = '#1663b5'; c.fillText('−', G.W / 2 + 18, yb - 6);
      /* 円筒 */
      var gr = c.createLinearGradient(0, yc - ry, 0, yc + ry); gr.addColorStop(0, '#f6eeea'); gr.addColorStop(.5, '#efe1db'); gr.addColorStop(1, '#dcc7c0');
      c.fillStyle = gr; c.beginPath(); c.moveTo(x0, yc - ry); c.lineTo(x1, yc - ry); c.ellipse(x1, yc, rx, ry, 0, -Math.PI / 2, Math.PI / 2); c.lineTo(x0, yc + ry); c.closePath(); c.fill();
      c.strokeStyle = '#3a414c'; c.lineWidth = 1.4; c.beginPath(); c.moveTo(x0, yc - ry); c.lineTo(x1, yc - ry); c.ellipse(x1, yc, rx, ry, 0, -Math.PI / 2, Math.PI / 2); c.lineTo(x0, yc + ry); c.stroke();
      c.fillStyle = 'rgba(200,180,172,.75)'; c.beginPath(); c.ellipse(x0, yc, rx, ry, 0, 0, 7); c.fill(); c.stroke();
      c.fillStyle = '#2b3038'; c.beginPath(); c.arc(x0, yc, 2.5, 0, 7); c.fill();
      /* イオン（＋） */
      E.ions.forEach(function (o) {
        if (o.f > 0) { c.fillStyle = 'rgba(255,230,60,' + (0.85 * o.f).toFixed(2) + ')'; c.beginPath(); c.arc(o.x, o.y, 13, 0, 7); c.fill(); }
        var g = c.createRadialGradient(o.x - 2, o.y - 2, 1, o.x, o.y, 8); g.addColorStop(0, '#ff8aa6'); g.addColorStop(1, '#c8174a');
        c.fillStyle = g; c.beginPath(); c.arc(o.x, o.y, 7.5, 0, 7); c.fill();
        c.strokeStyle = '#fff'; c.lineWidth = 1.8; c.beginPath(); c.moveTo(o.x - 4, o.y); c.lineTo(o.x + 4, o.y); c.moveTo(o.x, o.y - 4); c.lineTo(o.x, o.y + 4); c.stroke();
      });
      /* 電子（−） */
      E.els.forEach(function (e) {
        var g = c.createRadialGradient(e.x - 1.5, e.y - 1.5, 1, e.x, e.y, 6); g.addColorStop(0, '#7fb2d6'); g.addColorStop(1, '#1d5a86');
        c.fillStyle = g; c.beginPath(); c.arc(e.x, e.y, 5.5, 0, 7); c.fill();
        c.strokeStyle = '#fff'; c.lineWidth = 1.6; c.beginPath(); c.moveTo(e.x - 3, e.y); c.lineTo(e.x + 3, e.y); c.stroke();
      });
      /* 寸法：長さ l と断面積 S */
      var dy = yc - ry - 16; c.strokeStyle = '#3a414c'; c.fillStyle = '#3a414c'; c.lineWidth = 1.1;
      c.beginPath(); c.moveTo(x0, dy - 6); c.lineTo(x0, dy + 6); c.moveTo(x1, dy - 6); c.lineTo(x1, dy + 6); c.moveTo(x0, dy); c.lineTo(x1, dy); c.stroke();
      arrowHead(c, x0 + 4, dy, -1, 0, 4); arrowHead(c, x1 - 4, dy, 1, 0, 4);
      c.font = 'bold 12px ' + FONT; var lt = ' = ' + E.l + ' cm', tw = c.measureText(lt).width, mx = (x0 + x1) / 2;
      c.fillStyle = '#fff'; c.fillRect(mx - tw / 2 - 12, dy - 9, tw + 22, 16);
      symText(c, mx - tw / 2, dy + 4, 'l', '', '#14171c', 15, 'right'); c.fillStyle = '#14171c'; c.textAlign = 'left'; c.textBaseline = 'alphabetic'; c.fillText(lt, mx - tw / 2, dy + 4);
      c.font = 'italic 14px ' + MATHF; c.textAlign = 'left'; c.textBaseline = 'middle'; c.fillStyle = '#14171c'; c.fillText(E.S === 1 ? 'S' : E.S + 'S', 4, yc - ry * 0.55);
      /* 導線の中の電子 */
      E.wire.forEach(function (w) {
        var p = E.at(w.s), g = c.createRadialGradient(p[0] - 1.5, p[1] - 1.5, 1, p[0], p[1], 6); g.addColorStop(0, '#7fb2d6'); g.addColorStop(1, '#1d5a86');
        c.fillStyle = g; c.beginPath(); c.arc(p[0], p[1], 5, 0, 7); c.fill();
        c.strokeStyle = '#fff'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(p[0] - 2.6, p[1]); c.lineTo(p[0] + 2.6, p[1]); c.stroke();
      });
      /* 電子の流れる向き（太い矢印） */
      var ay = yc + ry + 22, ax1 = x0 + 8, ax0 = Math.max(x0 + 90, Math.min(x1 - 10, x0 + 120));
      c.fillStyle = '#1d5a86';
      c.beginPath(); c.moveTo(ax1, ay); c.lineTo(ax1 + 16, ay - 11); c.lineTo(ax1 + 16, ay - 4.5); c.lineTo(ax0, ay - 4.5); c.lineTo(ax0, ay + 4.5); c.lineTo(ax1 + 16, ay + 4.5); c.lineTo(ax1 + 16, ay + 11); c.closePath(); c.fill();
      c.font = 'bold 13px ' + FONT; c.textAlign = 'left'; c.textBaseline = 'middle'; c.fillText('電子の流れ', ax0 + 8, ay);
      /* 電流の向き（電子と逆） */
      c.fillStyle = '#1c8f4a'; c.font = 'bold 12px ' + FONT; c.textAlign = 'left'; c.textBaseline = 'middle';
      c.fillText('（電流の向きは逆の →）', ax0 + 8, ay + 19);
    };
    return E;
  }
  return { make: make };
})();
