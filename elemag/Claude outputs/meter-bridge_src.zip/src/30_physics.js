/* =========================================================================
   30_physics.js … メートルブリッジの回路を解く（計算だけ。描画はしない）
   ・節点：A（金属線の左はし＝電源の＋）、B（右はし＝電源の−、電位 0）、D（R と X のあいだ）、P（接点）
   ・素子：電源 E（理想・内部抵抗 0）、R（A–D）、X（D–B）、金属線の左 AP（A–P）、右 PB（P–B）、検流計 G（P–D）
   ・金属線は一様：R_AP = R_w × L/100、R_PB = R_w × (100 − L)/100
   ・節点電位法（MNA と同じ考え方）。未知数は P・D の電位。つり合いのときだけ 0 にする、のような作り方はしない。
   ・電流の正の向き：電源の＋から出る向き（circuit-water-model-3d と同じ）。
       R：A→D、X：D→B、AP：A→P、PB：P→B、検流計：P→D（このとき針は右にふれる）
   ========================================================================= */
'use strict';
var MB = {
  LEN: 100,          /* 金属線の長さ〔cm〕 */
  RW: 10,            /* 金属線全体の抵抗〔Ω〕（実際の装置は数 Ω） */
  RG: 10,            /* 検流計の内部抵抗〔Ω〕 */
  LMIN: 0.5, LMAX: 99.5
};
var MB_DEF = { V: 3.0, R: 10, X: 15, L: 20 };

/* 連立 1 次方程式（ガウスの消去法・部分ピボット） */
function mbLinSolve(G, b) {
  var n = b.length, A = G.map(function (r, i) { return r.slice().concat([b[i]]); });
  for (var c = 0; c < n; c++) {
    var p = c; for (var r = c + 1; r < n; r++) if (Math.abs(A[r][c]) > Math.abs(A[p][c])) p = r;
    var t = A[c]; A[c] = A[p]; A[p] = t;
    for (var r2 = c + 1; r2 < n; r2++) { var f = A[r2][c] / A[c][c]; for (var k = c; k <= n; k++) A[r2][k] -= f * A[c][k]; }
  }
  var x = new Array(n);
  for (var i = n - 1; i >= 0; i--) { var s = A[i][n]; for (var j = i + 1; j < n; j++) s -= A[i][j] * x[j]; x[i] = s / A[i][i]; }
  return x;
}

/* 回路全体を解く。o = { V, R, X, L, Rw?, Rg? } */
function mbSolve(o) {
  var V = o.V, R = o.R, X = o.X, L = Math.max(MB.LMIN, Math.min(MB.LMAX, o.L));
  var Rw = o.Rw || MB.RW, Rg = o.Rg || MB.RG;
  var Rap = Rw * L / MB.LEN, Rpb = Rw * (MB.LEN - L) / MB.LEN;
  /* 素子の表（節点 a→b、コンダクタンス g） */
  var el = [
    { k: 'R',  a: 'A', b: 'D', r: R },
    { k: 'X',  a: 'D', b: 'B', r: X },
    { k: 'AP', a: 'A', b: 'P', r: Rap },
    { k: 'PB', a: 'P', b: 'B', r: Rpb },
    { k: 'G',  a: 'P', b: 'D', r: Rg }
  ];
  var known = { A: V, B: 0 }, unk = ['P', 'D'], idx = { P: 0, D: 1 };
  var G = [[0, 0], [0, 0]], b = [0, 0];
  el.forEach(function (e) {
    var g = 1 / e.r;
    [[e.a, e.b], [e.b, e.a]].forEach(function (q) {
      var n = q[0], m = q[1]; if (!(n in idx)) return;
      G[idx[n]][idx[n]] += g;
      if (m in idx) G[idx[n]][idx[m]] -= g; else b[idx[n]] += g * known[m];
    });
  });
  var x = mbLinSolve(G, b);
  var v = { A: V, B: 0, P: x[0], D: x[1] };
  var I = {}, U = {};
  el.forEach(function (e) { U[e.k] = v[e.a] - v[e.b]; I[e.k] = U[e.k] / e.r; });
  var Itot = I.R + I.AP;                       /* 電源から流れ出す電流 */
  return { V: V, R: R, X: X, L: L, Rw: Rw, Rg: Rg, Rap: Rap, Rpb: Rpb, v: v, I: I, U: U, Itot: Itot, el: el };
}
/* 金属線の位置 x〔cm〕の電位（接点で折れる） */
function mbWireV(s, x) {
  if (x <= s.L) return s.V - s.I.AP * s.Rw * x / MB.LEN;
  return s.v.P - s.I.PB * s.Rw * (x - s.L) / MB.LEN;
}
/* つり合いの位置〔cm〕：R/X = L/(100 − L) */
function mbBalanceL(R, X) { return MB.LEN * R / (R + X); }
/* 読み取った L から X を求める */
function mbXfromL(R, L) { return R * (MB.LEN - L) / L; }
