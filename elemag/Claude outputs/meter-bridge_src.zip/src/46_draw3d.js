/* =========================================================================
   46_draw3d.js … 水流モデルの立体図（circuit-water-model-3d の 50_draw3d.js と同じ描き方）
   ・地面に平面の回路図。その上に「電位＝高さ」で水路が持ち上がる。色＝電位の色（低＝青 → 高＝赤）
   ・水の粒（濃い青の三角）の速さ＝電流（circuit-water-model-3d と同じ：px/秒 ＝ |I|×200、12〜260 に収める）
   ・視点：ドラッグで回す（横に動かす＝回転、縦に動かす＝倒す）。「斜め上」az −1.45・tilt 0.42、「真横」tilt 0.05
   ・金属線は、電位が一様に下がっていく坂（10 cm ごとの細い柱で坂が見えるように）
   地面の配置（格子の座標）：
     上の段 y=1：A の銅板 (0,1)–(1,1)、R (1,1)–(4,1)、D の銅板 (4,1)–(6,1)、X (6,1)–(9,1)、B の銅板 (9,1)–(10,1)
     金属線 y=3：A (0,3) → P (L/10, 3) → B (10,3)。たて (0,1)–(0,3)・(10,1)–(10,3) は銅板
     検流計：D (5,1) → P
     電源 y=5：A → (0,5) → ＋ (4.5,5) | 電源 | (5.5,5) − → (10,5) → B
   ========================================================================= */
'use strict';
var D3 = (function () {
  var COS30 = Math.cos(Math.PI / 6), V = null;
  var BX0 = -0.6, BX1 = 10.6, BY0 = 0, BY1 = 6;
  var VIEW_TOP = { az: -0.22, tilt: 0.15 };   /* 「斜め上」（既定）：2026-11-13 千葉さんの指定の角度（A が左奥、B が右手前、坂が横から見える） */
  var H0 = 2.2;                                 /* 縦の倍率 1 のとき、最大電位の高さ ＝ 2.2 マス */
  function proj(gx, gy, z) {
    var dx = gx - V.cx, dy = gy - V.cy, rx = dx * V.ca - dy * V.sa, ry = dx * V.sa + dy * V.ca;
    return [V.ox + (rx - ry) * COS30 * V.tile, V.oy + (rx + ry) * V.tilt * V.tile - z];
  }
  function depthXY(x, y) { var dx = x - V.cx, dy = y - V.cy; return (dx * V.ca - dy * V.sa) + (dx * V.sa + dy * V.ca); }
  function fit(cv, view, hm) {
    var dpr = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
    var cw = cv.clientWidth || 480, ch = Math.max(300, Math.round(cw * 0.74));
    if (cv.width !== Math.round(cw * dpr) || cv.height !== Math.round(ch * dpr)) { cv.width = Math.round(cw * dpr); cv.height = Math.round(ch * dpr); }
    cv.style.height = ch + 'px';
    V = { dpr: dpr, cw: cw, ch: ch, cx: (BX0 + BX1) / 2, cy: (BY0 + BY1) / 2, ca: Math.cos(view.az), sa: Math.sin(view.az), tilt: view.tilt, tile: 1, ox: 0, oy: 0 };
    var minX = 1e9, maxX = -1e9, minY = 1e9, maxY = -1e9;
    [[BX0, BY0], [BX1, BY0], [BX1, BY1], [BX0, BY1]].forEach(function (q) {
      var dx = q[0] - V.cx, dy = q[1] - V.cy, rx = dx * V.ca - dy * V.sa, ry = dx * V.sa + dy * V.ca;
      var X = (rx - ry) * COS30, Y = (rx + ry) * V.tilt;
      minX = Math.min(minX, X); maxX = Math.max(maxX, X); minY = Math.min(minY, Y); maxY = Math.max(maxY, Y);
    });
    var padX = cw * 0.07, padTop = ch * 0.16, padBot = ch * 0.07, Ht = H0 * hm;   /* 高さのぶん（Ht マス）を上にあけて、地面の大きさを決める */
    V.tile = Math.min((cw - 2 * padX) / (maxX - minX), (ch - padTop - padBot) / (maxY - minY + Ht));
    V.ox = padX + (cw - 2 * padX) / 2 - ((minX + maxX) / 2) * V.tile;
    V.oy = padTop + Ht * V.tile - minY * V.tile;
  }
  function label(c, txt, x, y, col) { c.lineWidth = 3; c.strokeStyle = 'rgba(255,255,255,.85)'; c.lineJoin = 'round'; c.strokeText(txt, x, y); c.fillStyle = col || '#333'; c.fillText(txt, x, y); }
  function fmt2sig(v) { if (Math.abs(v) < 1e-4) return '0.0'; return v.toPrecision(2); }

  /* 回路の水路の一覧（素子ごと）。z は描くときに電位×スケール */
  function channels(s) {
    var xp = s.L / 10, v = s.v;
    return [
      { id: 'cuA1', t: 'W', a: [0, 3], b: [0, 1], va: v.A, vb: v.A, I: s.I.R },         /* 銅板（A→上）。R へ向かう電流は上向き＝ b 向き */
      { id: 'cuA2', t: 'W', a: [0, 1], b: [1, 1], va: v.A, vb: v.A, I: s.I.R },
      { id: 'R', t: 'R', a: [1, 1], b: [4, 1], va: v.A, vb: v.D, I: s.I.R, name: 'R', val: s.R },
      { id: 'cuD1', t: 'W', a: [4, 1], b: [5, 1], va: v.D, vb: v.D, I: s.I.R },
      { id: 'cuD2', t: 'W', a: [5, 1], b: [6, 1], va: v.D, vb: v.D, I: s.I.X },
      { id: 'X', t: 'R', a: [6, 1], b: [9, 1], va: v.D, vb: 0, I: s.I.X, name: 'X', val: s.X },
      { id: 'cuB1', t: 'W', a: [9, 1], b: [10, 1], va: 0, vb: 0, I: s.I.X },
      { id: 'cuB2', t: 'W', a: [10, 1], b: [10, 3], va: 0, vb: 0, I: s.I.X },
      { id: 'AP', t: 'MW', a: [0, 3], b: [xp, 3], va: v.A, vb: v.P, I: s.I.AP },
      { id: 'PB', t: 'MW', a: [xp, 3], b: [10, 3], va: v.P, vb: 0, I: s.I.PB },
      { id: 'G', t: 'G', a: [xp, 3], b: [5, 1], va: v.P, vb: v.D, I: s.I.G },
      { id: 'bA', t: 'W', a: [0, 5], b: [0, 3], va: v.A, vb: v.A, I: s.Itot },
      { id: 'bA2', t: 'W', a: [4.5, 5], b: [0, 5], va: v.A, vb: v.A, I: s.Itot },
      { id: 'E', t: 'E', a: [5.5, 5], b: [4.5, 5], va: 0, vb: v.A, I: s.Itot },
      { id: 'bB2', t: 'W', a: [10, 5], b: [5.5, 5], va: 0, vb: 0, I: s.Itot },
      { id: 'bB', t: 'W', a: [10, 3], b: [10, 5], va: 0, vb: 0, I: s.Itot }
    ];
  }
  function flowSpeed(I) { return Math.max(12, Math.min(260, Math.abs(I) * 200)); }

  /* st = { s, view:{az,tilt}, phase:{id:累積}, hideX } */
  function render(cv, st) {
    fit(cv, st.view, st.hm || 1);
    var c = cv.getContext('2d'); c.setTransform(V.dpr, 0, 0, V.dpr, 0, 0); c.clearRect(0, 0, V.cw, V.ch);
    c.lineJoin = 'round'; c.lineCap = 'round';
    var s = st.s, vmin = 0, vmax = s.V, hs = V.tile * H0 * (st.hm || 1) / Math.max(0.1, s.V);   /* 最大電位 ＝ 2.2 × 縦の倍率 マスの高さ */
    var Z = function (v) { return v * hs; };
    var pc = function (v, a) { return potentialColor(v, vmin, vmax, a === undefined ? 0.95 : a); };
    drawGround(c);
    var chs = channels(s);
    /* 地面の平面の回路図 */
    chs.forEach(function (h) { groundSym(c, h); });
    var items = [];
    var colAt = {};
    var addCol = function (x, y, v, thin) { var key = x.toFixed(2) + '_' + y; if (colAt[key]) return; colAt[key] = 1; items.push({ d: depthXY(x, y) - 1e-4, fn: function () { column(c, x, y, Z(v), thin); } }); };
    chs.forEach(function (h) {
      addCol(h.a[0], h.a[1], h.va); addCol(h.b[0], h.b[1], h.vb);
      var d = (depthXY(h.a[0], h.a[1]) + depthXY(h.b[0], h.b[1])) / 2;
      if (h.t === 'MW') {                                   /* 金属線：短く区切って電位の色でぬる（坂） */
        var n = Math.max(1, Math.ceil(Math.abs(h.b[0] - h.a[0]) / 0.25));
        for (var i = 0; i < n; i++) (function (i) {
          var x0 = h.a[0] + (h.b[0] - h.a[0]) * i / n, x1 = h.a[0] + (h.b[0] - h.a[0]) * (i + 1) / n;
          var v0 = mbWireV(s, x0 * 10), v1 = mbWireV(s, x1 * 10);
          items.push({ d: depthXY((x0 + x1) / 2, 3), fn: function () { pipe(c, [x0, 3], [x1, 3], Z(v0), Z(v1), '#5f6670', pc((v0 + v1) / 2)); } });
        })(i);
        items.push({ d: d + 0.02, fn: function () { flow(c, proj(h.a[0], h.a[1], Z(h.va)), proj(h.b[0], h.b[1], Z(h.vb)), h.I, phaseOf(st, h)); } });
      } else {
        items.push({ d: d, fn: function () { drawCh(c, st, h, Z, pc); } });
      }
    });
    /* 金属線の 10 cm ごとの柱（坂が見えるように） */
    for (var cm = 10; cm < 100; cm += 10) (function (cm) { items.push({ d: depthXY(cm / 10, 3) - 2e-4, fn: function () { column(c, cm / 10, 3, Z(mbWireV(s, cm)), true); } }); })(cm);
    /* P と D の電位の矢印・同じ高さの線 */
    var xp = s.L / 10;
    items.push({ d: 99, fn: function () { levelLine(c, s, Z, xp); } });
    items.sort(function (a, b) { return a.d - b.d; });
    items.forEach(function (it) { it.fn(); });
    /* 点の名前 */
    c.font = 'italic bold 15px ' + MATHF; c.textAlign = 'center'; c.textBaseline = 'bottom';
    [['A', 0, 3, s.V, -12], ['B', 10, 3, 0, -12], ['D', 5, 1, s.v.D, 14], ['P', xp, 3, s.v.P, -14]].forEach(function (q) { var p = proj(q[1], q[2], Z(q[3])); label(c, q[0], p[0] + q[4], p[1] - 8, '#14171c'); });
    colorbar(c, s);
    c.fillStyle = 'rgba(70,90,110,.6)'; c.font = '11px ' + FONT; c.textAlign = 'right'; c.textBaseline = 'bottom';
    c.fillText('ドラッグで回転', V.cw - 8, V.ch - 6);
  }
  function phaseOf(st, h) { return (st.phase && st.phase[h.id] != null) ? st.phase[h.id] : 0; }
  function drawGround(c) {
    var p = [proj(BX0, BY0, 0), proj(BX1, BY0, 0), proj(BX1, BY1, 0), proj(BX0, BY1, 0)];
    c.beginPath(); c.moveTo(p[0][0], p[0][1]); for (var i = 1; i < 4; i++) c.lineTo(p[i][0], p[i][1]); c.closePath();
    c.fillStyle = 'rgba(255,255,255,.45)'; c.fill();
    c.strokeStyle = 'rgba(120,140,160,.30)'; c.lineWidth = 1;
    for (var x = 0; x <= 10; x++) { var a = proj(x, BY0, 0), b = proj(x, BY1, 0); c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.stroke(); }
    for (var y = BY0; y <= BY1; y++) { var q = proj(BX0, y, 0), r = proj(BX1, y, 0); c.beginPath(); c.moveTo(q[0], q[1]); c.lineTo(r[0], r[1]); c.stroke(); }
  }
  function groundSym(c, h) {
    var a = h.a, b = h.b, ux = b[0] - a[0], uy = b[1] - a[1], len = Math.hypot(ux, uy) || 1, nx = -uy / len, ny = ux / len;
    var gp = function (t, sd) { return proj(a[0] + ux * t + nx * sd, a[1] + uy * t + ny * sd, 0); };
    var seg = function (t0, t1) { var p = gp(t0, 0), q = gp(t1, 0); c.beginPath(); c.moveTo(p[0], p[1]); c.lineTo(q[0], q[1]); c.stroke(); };
    c.lineWidth = 2;
    if (h.t === 'R') {
      c.strokeStyle = '#e07b18'; var g0 = 0.5 - 0.6 / len, g1 = 0.5 + 0.6 / len; seg(0, g0); seg(g1, 1);
      var q = [gp(g0, -0.16), gp(g1, -0.16), gp(g1, 0.16), gp(g0, 0.16)];
      c.beginPath(); c.moveTo(q[0][0], q[0][1]); for (var i = 1; i < 4; i++) c.lineTo(q[i][0], q[i][1]); c.closePath(); c.fillStyle = '#fff'; c.fill(); c.stroke();
    } else if (h.t === 'E') {
      c.strokeStyle = '#c2249a'; seg(0, 0.42); seg(0.58, 1);
      var l1 = gp(0.58, -0.24), l2 = gp(0.58, 0.24), s1 = gp(0.42, -0.13), s2 = gp(0.42, 0.13);     /* b 側（左）が＋ */
      c.lineWidth = 2; c.beginPath(); c.moveTo(l1[0], l1[1]); c.lineTo(l2[0], l2[1]); c.stroke();
      c.lineWidth = 4; c.beginPath(); c.moveTo(s1[0], s1[1]); c.lineTo(s2[0], s2[1]); c.stroke();
    } else if (h.t === 'MW') { c.strokeStyle = '#8d96a0'; seg(0, 1); }
    else if (h.t === 'G') { c.strokeStyle = '#39434e'; c.setLineDash([4, 3]); seg(0, 1); c.setLineDash([]); }
    else { c.strokeStyle = '#39434e'; seg(0, 1); }
  }
  function column(c, gx, gy, z, thin) {
    var g = proj(gx, gy, 0), t = proj(gx, gy, z);
    if (Math.abs(z) > 1) { c.strokeStyle = thin ? 'rgba(70,120,170,.22)' : 'rgba(70,120,170,.30)'; c.lineWidth = thin ? 1.2 : 2; c.beginPath(); c.moveTo(g[0], g[1]); c.lineTo(t[0], t[1]); c.stroke(); }
    if (!thin) { var r = 0.15, q = [proj(gx + r, gy, z), proj(gx, gy + r, z), proj(gx - r, gy, z), proj(gx, gy - r, z)];
      c.beginPath(); c.moveTo(q[0][0], q[0][1]); for (var i = 1; i < 4; i++) c.lineTo(q[i][0], q[i][1]); c.closePath(); c.fillStyle = 'rgba(90,165,215,.6)'; c.fill(); c.strokeStyle = 'rgba(40,60,80,.5)'; c.lineWidth = 1; c.stroke(); }
  }
  function pipe(c, a, b, za, zb, border, inner) {
    var A = proj(a[0], a[1], za), B = proj(b[0], b[1], zb), w = Math.max(5, V.tile * 0.12);
    c.strokeStyle = border; c.lineWidth = w + 3; c.beginPath(); c.moveTo(A[0], A[1]); c.lineTo(B[0], B[1]); c.stroke();
    c.strokeStyle = inner; c.lineWidth = Math.max(1, w); c.beginPath(); c.moveTo(A[0], A[1]); c.lineTo(B[0], B[1]); c.stroke();
    return [A, B, w];
  }
  function drawCh(c, st, h, Z, pc) {
    var za = Z(h.va), zb = Z(h.vb), r;
    if (h.t === 'W') r = pipe(c, h.a, h.b, za, zb, '#2b3038', pc(h.va));
    else if (h.t === 'R') r = pipe(c, h.a, h.b, za, zb, '#e07b18', 'rgba(120,200,235,.92)');
    else if (h.t === 'G') r = pipe(c, h.a, h.b, za, zb, '#2b3038', Math.abs(h.va - h.vb) < 1e-4 ? pc(h.va) : 'rgba(120,200,235,.92)');
    else if (h.t === 'E') r = pipe(c, h.a, h.b, za, zb, '#c2249a', 'rgba(120,200,235,.92)');
    flow(c, r[0], r[1], h.I, phaseOf(st, h), r[2]);
    if (h.t === 'E') battery(c, h, za, zb);
    if (h.t === 'G') gauge(c, h, za, zb);
    if (h.t === 'R') {
      var m = proj((h.a[0] + h.b[0]) / 2, (h.a[1] + h.b[1]) / 2, (za + zb) / 2);
      c.font = 'bold 12px ' + FONT; c.textAlign = 'center'; c.textBaseline = 'bottom';
      label(c, h.name + ' ' + ((h.name === 'X' && st.hideX) ? '？' : fmt(h.val, h.val < 10 ? 1 : 0)) + ' Ω', m[0], m[1] - 12, '#9c4e06');
    }
  }
  function flow(c, A, B, I, phase, w) {
    if (Math.abs(I) < 1e-4) return;                       /* |I| < 0.1 mA は「電流なし」（circuit-water-model-3d と同じ基準） */
    var dir = I >= 0 ? 1 : -1, dx = B[0] - A[0], dy = B[1] - A[1], len = Math.hypot(dx, dy) || 1, ux = dx / len, uy = dy / len;
    var gap = 22, n = Math.max(1, Math.floor(len / gap)), ph = ((phase % gap) + gap) % gap, size = Math.max(3, (w || Math.max(5, V.tile * 0.12)) * 0.7);
    c.fillStyle = '#0b3d66';
    for (var i = 0; i <= n; i++) {
      var d = i * gap + (dir > 0 ? ph : gap - ph); if (d < 4 || d > len - 4) continue;
      var cx = A[0] + ux * d, cy = A[1] + uy * d, fx = ux * dir, fy = uy * dir;
      c.beginPath(); c.moveTo(cx + fx * size, cy + fy * size);
      c.lineTo(cx - fx * size - fy * size * 0.6, cy - fy * size + fx * size * 0.6); c.lineTo(cx - fx * size + fy * size * 0.6, cy - fy * size - fx * size * 0.6); c.closePath(); c.fill();
    }
  }
  function battery(c, h, za, zb) {
    var mx = (h.a[0] + h.b[0]) / 2, my = (h.a[1] + h.b[1]) / 2, mz = (za + zb) / 2, nx = 0, ny = 1, tile = V.tile;
    var zL = mz + 0.30 * tile, zS = mz + 0.10 * tile;
    c.lineCap = 'round'; c.strokeStyle = '#c2249a';
    var l1 = proj(mx - nx * 0.34, my - ny * 0.34, zL), l2 = proj(mx + nx * 0.34, my + ny * 0.34, zL);
    c.lineWidth = 2.6; c.beginPath(); c.moveTo(l1[0], l1[1]); c.lineTo(l2[0], l2[1]); c.stroke();
    var s1 = proj(mx - nx * 0.16, my - ny * 0.16, zS), s2 = proj(mx + nx * 0.16, my + ny * 0.16, zS);
    c.lineWidth = 6; c.beginPath(); c.moveTo(s1[0], s1[1]); c.lineTo(s2[0], s2[1]); c.stroke();
    var pL = proj(mx, my, zL + 0.16 * tile), mL = proj(mx, my, zS - 0.12 * tile);
    c.font = 'bold 15px ' + FONT; c.textAlign = 'center'; c.textBaseline = 'middle';
    c.fillStyle = '#c0392b'; c.fillText('＋', pL[0], pL[1]); c.fillStyle = '#2b5c8a'; c.fillText('−', mL[0], mL[1]);
  }
  /* 検流計：水路のまん中に立つ丸い目盛り板（針は電流の向き・大きさ） */
  function gauge(c, h, za, zb) {
    var mx = (h.a[0] + h.b[0]) / 2, my = (h.a[1] + h.b[1]) / 2, mz = (za + zb) / 2, tile = V.tile;
    var ux = h.b[0] - h.a[0], uy = h.b[1] - h.a[1], l = Math.hypot(ux, uy); ux /= l; uy /= l;
    var nx = -uy, ny = ux, r = 0.32, cz = mz + 0.62 * tile, rp = r * tile;
    var st = proj(mx, my, mz), cb = proj(mx, my, cz - rp);
    c.strokeStyle = '#2b3038'; c.lineWidth = 2; c.beginPath(); c.moveTo(st[0], st[1]); c.lineTo(cb[0], cb[1]); c.stroke();
    c.beginPath();
    for (var a = 0; a <= Math.PI * 2 + 1e-3; a += 0.2) { var p = proj(mx + nx * r * Math.cos(a), my + ny * r * Math.cos(a), cz + rp * Math.sin(a)); if (a === 0) c.moveTo(p[0], p[1]); else c.lineTo(p[0], p[1]); }
    c.closePath(); c.fillStyle = 'rgba(255,255,255,.95)'; c.fill(); c.strokeStyle = '#2b3038'; c.lineWidth = 2; c.stroke();
    var q = clamp(h.I / 0.05, -1, 1) * 0.9, base = proj(mx, my, cz - rp * 0.55);
    var tip = proj(mx + nx * r * 0.85 * Math.sin(q), my + ny * r * 0.85 * Math.sin(q), cz - rp * 0.55 + rp * 1.3 * Math.cos(q));
    c.strokeStyle = '#c0392b'; c.lineWidth = 2; c.beginPath(); c.moveTo(base[0], base[1]); c.lineTo(tip[0], tip[1]); c.stroke();
    var gl = proj(mx - nx * (r + 0.12), my - ny * (r + 0.12), cz);
    c.font = 'italic bold 13px ' + MATHF; c.textAlign = 'center'; c.textBaseline = 'middle'; label(c, 'G', gl[0], gl[1], '#14171c');
  }
  /* P と D：電位の矢印（二重線）＋ 2 つの頂上を結ぶ点線。同じ高さなら緑で「同じ高さ」 */
  function levelLine(c, s, Z, xp) {
    var tp = proj(xp, 3, Z(s.v.P)), td = proj(5, 1, Z(s.v.D)), same = Math.abs(s.I.G) < 5e-6;
    c.save(); c.setLineDash([6, 4]); c.strokeStyle = same ? '#1c8f4a' : 'rgba(20,23,28,.55)'; c.lineWidth = same ? 2.4 : 1.5;
    c.beginPath(); c.moveTo(tp[0], tp[1]); c.lineTo(td[0], td[1]); c.stroke(); c.restore();
    [[xp, 3, s.v.P, 'P'], [5, 1, s.v.D, 'D']].forEach(function (q) {
      var b = proj(q[0], q[1], 0), t = proj(q[0], q[1], Z(q[2]));
      c.lineCap = 'butt'; c.strokeStyle = '#151a20'; c.lineWidth = 5; c.beginPath(); c.moveTo(b[0], b[1]); c.lineTo(t[0], t[1]); c.stroke();
      c.strokeStyle = '#fff'; c.lineWidth = 1.6; c.beginPath(); c.moveTo(b[0], b[1]); c.lineTo(t[0], t[1]); c.stroke(); c.lineCap = 'round';
      c.fillStyle = '#151a20'; c.beginPath(); c.moveTo(t[0], t[1] - 2); c.lineTo(t[0] - 9, t[1] + 9); c.lineTo(t[0] + 9, t[1] + 9); c.closePath(); c.fill();
    });
    c.font = 'bold 13px ' + FONT; c.textBaseline = 'middle';
    if (same) {                                        /* 同じ高さ：上に 1 つだけ大きく書く（ラベルが重ならないように） */
      c.textAlign = 'center'; c.font = 'bold 15px ' + FONT;
      label(c, 'P と D が同じ高さ（等電位）：' + fmt(s.v.P, 2) + ' V', V.cw / 2 + 20, 24, '#1c8f4a'); return;
    }
    var left = tp[0] < td[0];
    c.textAlign = left ? 'right' : 'left'; label(c, 'P ' + fmt(s.v.P, 2) + ' V', tp[0] + (left ? -12 : 12), tp[1] + 16, '#111820');
    c.textAlign = left ? 'left' : 'right'; label(c, 'D ' + fmt(s.v.D, 2) + ' V', td[0] + (left ? 12 : -12), td[1] + 16, '#111820');
  }
  function colorbar(c, s) {
    var vmin = 0, vmax = s.V, x = 14, w = 13, top = Math.round(V.ch * 0.30), bot = Math.round(V.ch * 0.80), h = bot - top, n = 48;
    for (var i = 0; i < n; i++) { var t = 1 - i / (n - 1); c.fillStyle = potentialColor(vmin + t * (vmax - vmin), vmin, vmax, 1); c.fillRect(x, top + Math.floor(i * h / n), w, Math.ceil(h / n) + 1); }
    c.strokeStyle = 'rgba(40,50,60,.55)'; c.lineWidth = 1; c.strokeRect(x + 0.5, top + 0.5, w, h);
    c.font = '11px ' + FONT; c.textBaseline = 'middle'; c.textAlign = 'left';
    label(c, '高 ' + fmt2sig(vmax) + ' V', x + w + 5, top + 6, '#b23b2e'); label(c, '低 0.0 V', x + w + 5, bot - 6, '#1663b5');
    c.textBaseline = 'bottom'; label(c, '導線の電位', x, top - 4, '#33414f');
  }
  /* 流れの位相を進める（再生中だけ） */
  function advance(st, dt) {
    if (!st.phase) st.phase = {};
    channels(st.s).forEach(function (h) { st.phase[h.id] = (st.phase[h.id] || 0) + flowSpeed(h.I) * dt * (Math.abs(h.I) < 1e-4 ? 0 : 1); });
  }
  /* ドラッグで回す（circuit-water-model-3d と同じ量） */
  function bindDrag(cv, st, redraw, onRotate) {
    var last = null;
    cv.style.cursor = 'grab'; cv.style.touchAction = 'none';
    cv.addEventListener('pointerdown', function (ev) { last = { x: ev.clientX, y: ev.clientY }; cv.setPointerCapture && cv.setPointerCapture(ev.pointerId); cv.style.cursor = 'grabbing'; });
    cv.addEventListener('pointermove', function (ev) {
      if (!last) return; var dx = ev.clientX - last.x, dy = ev.clientY - last.y; last = { x: ev.clientX, y: ev.clientY };
      st.view.az -= dx * 0.009; st.view.tilt = Math.max(0.03, Math.min(0.62, st.view.tilt - dy * 0.004));
      if (onRotate) onRotate(); redraw();
    });
    var end = function () { last = null; cv.style.cursor = 'grab'; };
    cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end);
  }
  return { render: render, advance: advance, bindDrag: bindDrag, VIEW_TOP: VIEW_TOP, channels: channels };
})();
