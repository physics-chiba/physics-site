import sys, json
from playwright.sync_api import sync_playwright
URL="file:///home/claude/mb/dist/meter-bridge.html"
def run(w, h, name, hash_="", js=None, full=True, scroll=None, clip_sel=None):
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path="/usr/bin/google-chrome", args=["--no-sandbox"])
        pg = b.new_page(viewport={"width":w,"height":h}, device_scale_factor=1)
        errs=[]; reqs=[]
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.on("console", lambda m: errs.append("console:"+m.text) if m.type=="error" else None)
        pg.on("request", lambda r: reqs.append(r.url) if not r.url.startswith(("file:","data:")) else None)
        pg.goto(URL+hash_); pg.wait_for_timeout(1200)
        if js: print(json.dumps(pg.evaluate(js), ensure_ascii=False)); pg.wait_for_timeout(400)
        if scroll: pg.evaluate(f"document.querySelector('{scroll}').scrollIntoView({{block:'start'}})"); pg.wait_for_timeout(300)
        sw = pg.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
        if clip_sel:
            pg.locator(clip_sel).screenshot(path=name)
        else:
            pg.screenshot(path=name, full_page=full)
        print(name, "errors", errs, "ext", reqs, "hscroll", sw)
        b.close()
if __name__=="__main__":
    a=sys.argv
    run(int(a[1]), int(a[2]), a[3], a[4] if len(a)>4 else "", a[5] if len(a)>5 and a[5] else None, full=(a[6]!="view") if len(a)>6 else True, clip_sel=a[7] if len(a)>7 else None)
