import json, time
from playwright.sync_api import sync_playwright
URL="file:///home/claude/mb/dist/meter-bridge.html"
with sync_playwright() as p:
    b = p.chromium.launch(executable_path="/usr/bin/google-chrome", args=["--no-sandbox"])
    out={}
    for w,h in [(320,640),(360,740),(390,844),(430,932),(768,1024),(1024,768),(1440,900),(844,390)]:
        pg=b.new_page(viewport={"width":w,"height":h}); errs=[]; ext=[]
        pg.on("pageerror", lambda e: errs.append(str(e))); pg.on("request", lambda r: ext.append(r.url) if not r.url.startswith(("file:","data:")) else None)
        res=[]
        for hs in ["","#mode2","#mode3"]:
            pg.goto(URL+hs); pg.wait_for_timeout(700)
            res.append(pg.evaluate("document.documentElement.scrollWidth-document.documentElement.clientWidth"))
        out[f"{w}x{h}"]={"hscroll":res,"errors":errs,"ext":ext}
        pg.close()
    print(json.dumps(out,ensure_ascii=False))
    # drag test + balance + answer check
    pg=b.new_page(viewport={"width":1440,"height":900}); pg.goto(URL+"#mode2"); pg.wait_for_timeout(800)
    cv=pg.locator("#simL_s1 canvas").first; cv.scroll_into_view_if_needed(); pg.wait_for_timeout(200); bb=cv.bounding_box()
    k=bb["width"]/1000; wy=402*k
    x0=bb["x"]+(110+780*0.2)*k; y0=bb["y"]+wy-30*k
    pg.mouse.move(x0,y0); pg.mouse.down(); pg.mouse.move(bb["x"]+(110+780*0.4)*k,y0,steps=8); pg.mouse.up()
    print("after drag L =", pg.evaluate("TEST.s1().L"), "Ig =", pg.evaluate("TEST.s1().s.I.G"))
    pg.evaluate("TEST.setL(40)"); pg.wait_for_timeout(200)
    print("L=40 Ig", pg.evaluate("TEST.s1().s.I.G"), pg.evaluate("[TEST.s1().s.v.P, TEST.s1().s.v.D]"), pg.inner_text("#simL_s1 .mbmsg"))
    # answer check in s2
    X=pg.evaluate("TEST.s2().X"); pg.fill("#simR_s2 .ansin", str(X)); pg.click("#simR_s2 button.chk"); print("s2 X",X, pg.inner_text("#simR_s2 .mbfb"))
    pg.fill("#simR_s2 .ansin", str(X*1.2)); pg.click("#simR_s2 button.chk"); print(pg.inner_text("#simR_s2 .mbfb"))
    # CPU idle: count rAF callbacks and long tasks over 5 s
    pg.goto(URL+"#mode2"); pg.reload(); pg.wait_for_timeout(800)
    cdp=pg.context.new_cdp_session(pg); cdp.send("Performance.enable")
    def m(): return {x["name"]:x["value"] for x in cdp.send("Performance.getMetrics")["metrics"]}
    pg.evaluate("window.scrollTo(0,600)"); pg.wait_for_timeout(1500)
    a=m(); t=time.time(); pg.wait_for_timeout(5000); c=m(); dt=time.time()-t
    print("idle CPU %% (TaskDuration/wall): %.2f" % (100*(c["TaskDuration"]-a["TaskDuration"])/dt), "script %.2f" % (100*(c["ScriptDuration"]-a["ScriptDuration"])/dt))
    pg.click("#bPlayM"); pg.wait_for_timeout(800); a=m(); t=time.time(); pg.wait_for_timeout(4000); c=m(); dt=time.time()-t
    print("playing CPU %%: %.2f" % (100*(c["TaskDuration"]-a["TaskDuration"])/dt), pg.inner_text("#bPlayM"))
    pg.click("#bPlayM"); pg.wait_for_timeout(800); a=m(); t=time.time(); pg.wait_for_timeout(4000); c=m(); dt=time.time()-t
    print("paused again CPU %%: %.2f" % (100*(c["TaskDuration"]-a["TaskDuration"])/dt))
    b.close()
