#!/usr/bin/env node
/* メートルブリッジ（meter-bridge.html）の単一 HTML ビルド（photoelectric-effect の build.js と同じ形）
 * src/ の部品を決まった順に連結する。KaTeX（CSS・フォント base64・JS）は vendor/ にあるものを埋め込み、完全オフライン。
 * 共通フッター（src/99_footer.html）は </body> の直前にそのまま入れる（一字も変えない）。
 * src にファイルを足したら、下の CSS・JS の並びにも足すこと。
 */
'use strict';
const fs = require('fs');
const path = require('path');
const ROOT = __dirname, SRC = path.join(ROOT, 'src'), VEN = path.join(ROOT, 'vendor');
const OUT = path.join(ROOT, 'dist', 'meter-bridge.html');
const read = (p) => fs.readFileSync(p, 'utf8');
const CSS = ['10_style.css', '15_page.css', '16_shm.css', '17_pe.css', '19_mb.css'];
const JS = ['30_physics.js', '40_common.js', '41_battery_img.js', '42_apparatus.js', '43_rheostat_img.js', '44_circuit2d.js', '46_draw3d.js', '48_plots.js', '49_electrons.js', '50_sections.js', '52_wheatstone.js', '80_page.js', '84_sitenav.js', '85_design.js', '90_boot.js'];

const css = CSS.map(f => '/* ===== ' + f + ' ===== */\n' + read(path.join(SRC, f))).join('\n');
const js = JS.map(f => '/* ===== ' + f + ' ===== */\n' + read(path.join(SRC, f))).join('\n');
const html = '<!DOCTYPE html>\n<html lang="ja">\n<head>\n' + read(path.join(SRC, '00_head.html')) +
  '<style>' + read(path.join(VEN, 'katex_css.css')) + '</style>\n<style>\n' + css + '\n</style>\n</head>\n<body id="top">\n' +
  read(path.join(SRC, '20_body.html')) + '\n' +
  '<script>' + read(path.join(VEN, 'katex.min.js')) + '</script>\n<script>\n' + js + '\n</script>\n' +
  read(path.join(SRC, '99_footer.html')) + '\n</body>\n</html>\n';

/* 完全性チェック：フッター・KaTeX・ページの骨組みが入っていなければ失敗 */
['physics-chiba.goatcounter.com', 'sg-glow', 'KaTeX_Main', 'katex', 'buildSiteDrawer', 'id="hero"', 'function mbSolve', 'id = \'bPlay\''].forEach(k => {
  if (html.indexOf(k) < 0) { console.error('完全性チェックで失敗: ' + k + ' がない'); process.exit(1); }
});
if (/(?:src|href)\s*=\s*["']https?:\/\/(?!physics-chiba\.github\.io|docs\.google\.com)/.test(html.replace(read(path.join(SRC, '99_footer.html')), ''))) { console.error('外部への読みこみがある'); process.exit(1); }
fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, html, 'utf8');
console.log('出力: ' + OUT + ' (' + (Buffer.byteLength(html) / 1024).toFixed(0) + ' KB)');
